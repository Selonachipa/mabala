# Mabala Cloud Platform Provisioning Service

This directory contains the production-grade, secure, idempotent, and transactional backend services for the Mabala agricultural multi-tenant SaaS platform, running on Firebase Cloud Functions.

## Service Responsibilities

### 1. ProvisioningService
* **`provisionWorkspace()`**: Orchestrates the secure setup of a new isolated tenant workspace. Uses a single Firestore Transaction to ensure atomic provisioning.
  * Checks for existing workspaces (Idempotency Check) using the user's UID as the Tenant ID.
  * Creates the tenant record in `/platform/institutions/{tenantId}` with standard active modules (strictly excluding Livestock, Poultry, and Veterinary).
  * Initializes the user profile in `/users_data/{userId}` with associated metadata, custom Chart of Accounts, and initial farms.
  * Configures the Billing Account subcollection `/platform/institutions/{tenantId}/billing_accounts/global`.
  * Records a pristine platform audit log entry.
* **`inviteUser()`**: Validates that an inviter is an Owner or Admin of the workspace and issues a secure invitation.

### 2. BillingService
* **`allocateCreditsInTransaction()`**: Atomically increments SMS credit balance and records an audit log.
* **`deductCreditsInTransaction()`**: Atomically decrements SMS credit balance with checks for negative bounds.
* **`renewSubscriptionInTransaction()`**: Extends subscription renewal dates and updates active billing states.
* **`processPaymentWebhook()`**: Receives status updates from Lipila or other payment processors, updates the payment record, and automatically triggers credit/subscription allocation on successful completions.

---

## Workspace Provisioning Sequence Diagram

The diagram below details the sequence of execution and transaction boundaries for `provisionWorkspace()` to prevent partial states:

```
[Client App]             [Cloud Function]        [Firestore Transaction]
     |                           |                          |
     |--- provisionWorkspace() ->|                          |
     |                           |--- Begin Transaction --->|
     |                           |                          |
     |                           |--- Get Tenant Doc ------>|
     |                           |    (Idempotency Check)   |
     |                           |<-- Tenant exists? -------|
     |                           |    (Yes: return existing)|
     |                           |                          |
     |                           |--- Set Tenant Doc ------>|
     |                           |    (Modules & Status)    |
     |                           |                          |
     |                           |--- Set User Profile ---->|
     |                           |    (COA, default Farm)   |
     |                           |                          |
     |                           |--- Set Billing Doc ----->|
     |                           |                          |
     |                           |--- Set Audit Log --------|
     |                           |                          |
     |                           |<-- Commit Transaction ---|
     |                           |                          |
     |<-- Success Response ------|                          |
```

## Rollback & Transaction Boundaries
* All operations inside `runTransaction` are atomic. If any write or validation fails during the transaction, **all** modifications are completely rolled back by Firebase.
* The transaction prevents partial provisioning states (e.g., creating a tenant document but failing to associate the user profile or set up billing), preserving Mabala's data integrity.

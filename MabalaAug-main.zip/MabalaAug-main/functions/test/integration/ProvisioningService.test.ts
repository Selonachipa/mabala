import { ProvisioningService, ProvisionWorkspaceInput } from "../../src/services/ProvisioningService";
import { Firestore } from "firebase-admin/firestore";

describe("ProvisioningService Idempotency & Concurrent Signup Integration Tests", () => {
  let mockDb: any;
  let databaseState: Record<string, any>;
  let provisioningService: ProvisioningService;
  let transactionCounter: number;

  beforeEach(() => {
    databaseState = {};
    transactionCounter = 0;

    const createDocRef = (path: string): any => {
      return {
        _path: path,
        collection: jest.fn((colName) => createCollectionRef(`${path}/${colName}`)),
        set: jest.fn(async (data) => {
          databaseState[path] = data;
          return {};
        }),
        get: jest.fn(async () => {
          return {
            exists: databaseState[path] !== undefined,
            id: path.split("/").pop() || "",
            data: () => databaseState[path]
          };
        })
      };
    };

    const createCollectionRef = (path: string): any => {
      return {
        _path: path,
        doc: jest.fn((docName) => createDocRef(`${path}/${docName}`))
      };
    };

    // A simulated transactional database engine that implements a serializable lock queue to model concurrent requests safely.
    // In real Firestore, concurrent transactions are retried or run sequentially under a document write lock.
    let transactionLock = Promise.resolve();

    mockDb = {
      runTransaction: jest.fn(async (callback) => {
        transactionCounter++;
        
        // Serialize transaction execution to mock Firestore's transactional write locking behavior.
        const result = await (transactionLock = transactionLock.then(async () => {
          const mockTransaction = {
            get: jest.fn(async (ref: any) => {
              const path = ref._path;
              const exists = databaseState[path] !== undefined;
              return {
                exists,
                id: path.split("/").pop() || "",
                data: () => databaseState[path]
              };
            }),
            set: jest.fn((ref: any, data: any) => {
              databaseState[ref._path] = { ...data };
            }),
            update: jest.fn((ref: any, data: any) => {
              databaseState[ref._path] = {
                ...(databaseState[ref._path] || {}),
                ...data
              };
            })
          };

          // Simulate a brief asynchronous database network delay to test real-world concurrent execution conditions
          await new Promise((resolve) => setTimeout(resolve, 10));
          return await callback(mockTransaction);
        }));

        return result;
      }),
      collection: jest.fn((colName) => createCollectionRef(colName))
    };

    provisioningService = new ProvisioningService(mockDb as unknown as Firestore);
  });

  const sampleInput: ProvisionWorkspaceInput = {
    userId: "tenant-owner-123",
    farmName: "Green Valley Fields",
    primaryContact: "+260971234567",
    country: "Zambia",
    currency: "ZMW",
    selectedTier: "Standard Crop Operations",
    agreeTerms: true
  };

  it("should support sequential idempotency: subsequent calls must return the same tenant without duplicating records", async () => {
    // First Call - Creates the Workspace
    const result1 = await provisioningService.provisionWorkspace(sampleInput);
    expect(result1.tenantId).toBe("tenant-owner-123");
    expect(result1.tenant.name).toBe("Green Valley Fields");
    expect(result1.tenant.smsCreditBalance).toBe(100);

    // Verify initial database population
    const tenantPath = "platform/institutions/institutions/tenant-owner-123";
    const billingPath = "platform/institutions/institutions/tenant-owner-123/billing_accounts/global";
    const userPath = "users_data/tenant-owner-123";

    expect(databaseState[tenantPath]).toBeDefined();
    expect(databaseState[billingPath]).toBeDefined();
    expect(databaseState[userPath]).toBeDefined();

    // Capture states
    const tenantStateAfterFirstCall = { ...databaseState[tenantPath] };
    const billingStateAfterFirstCall = { ...databaseState[billingPath] };
    const userStateAfterFirstCall = { ...databaseState[userPath] };

    // Second Call - Should return existing tenant cleanly without altering any database records
    const result2 = await provisioningService.provisionWorkspace(sampleInput);
    
    expect(result2.tenantId).toBe("tenant-owner-123");
    expect(result2.tenant.name).toBe("Green Valley Fields");

    // Assert absolute database parity
    expect(databaseState[tenantPath]).toEqual(tenantStateAfterFirstCall);
    expect(databaseState[billingPath]).toEqual(billingStateAfterFirstCall);
    expect(databaseState[userPath]).toEqual(userStateAfterFirstCall);

    // Verify transaction ran for both attempts
    expect(transactionCounter).toBe(2);
  });

  it("should handle concurrent signups safely: simultaneous parallel requests must result in exactly one write operation and no duplicate records", async () => {
    // Issue three parallel calls to provision the exact same user/tenant workspace
    const promises = [
      provisioningService.provisionWorkspace(sampleInput),
      provisioningService.provisionWorkspace(sampleInput),
      provisioningService.provisionWorkspace(sampleInput)
    ];

    const results = await Promise.all(promises);

    // 1. Verify all callers received successful, identical results
    results.forEach((res) => {
      expect(res.tenantId).toBe("tenant-owner-123");
      expect(res.tenant.name).toBe("Green Valley Fields");
      expect(res.tenant.subscriptionTier).toBe("Standard Crop Operations");
    });

    // 2. Verify all operations inside the database were committed exactly once
    const tenantPath = "platform/institutions/institutions/tenant-owner-123";
    const billingPath = "platform/institutions/institutions/tenant-owner-123/billing_accounts/global";
    const userPath = "users_data/tenant-owner-123";

    expect(databaseState[tenantPath]).toBeDefined();
    expect(databaseState[billingPath]).toBeDefined();
    expect(databaseState[userPath]).toBeDefined();

    // Verify fields were initialized to correct values and not aggregated or corrupted
    expect(databaseState[tenantPath].smsCreditBalance).toBe(100);
    expect(databaseState[userPath].credits).toBe(300);

    // 3. Confirm three separate transactions were dispatched, but only the first performed creation writes
    expect(transactionCounter).toBe(3);
  });

  it("should ensure the provisioned data completely omits Livestock, Poultry, and Vet modules to align with clean removal architecture", async () => {
    const result = await provisioningService.provisionWorkspace(sampleInput);
    const userProfile = databaseState["users_data/tenant-owner-123"];

    expect(userProfile).toBeDefined();

    // Ensure all livestock, poultry, and veterinary properties are absent
    expect(userProfile.livestock).toBeUndefined();
    expect(userProfile.poultry).toBeUndefined();
    expect(userProfile.veterinary).toBeUndefined();

    // Validate that only clean, active operational modules are registered
    expect(result.tenant.activeModules).toEqual(["crops", "inputs", "finance", "equipment", "employees"]);
    expect(result.tenant.activeModules).not.toContain("livestock");
    expect(result.tenant.activeModules).not.toContain("poultry");
    expect(result.tenant.activeModules).not.toContain("veterinary");
  });
});

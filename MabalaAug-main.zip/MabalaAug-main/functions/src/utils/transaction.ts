import { Firestore, Transaction } from "firebase-admin/firestore";

export type TransactionCallback<T> = (transaction: Transaction) => Promise<T>;

export class TransactionManager {
  constructor(private readonly db: Firestore) {}

  /**
   * Executes a callback within a Firestore transaction.
   * All reads must be done before any writes.
   */
  async run<T>(callback: TransactionCallback<T>): Promise<T> {
    try {
      return await this.db.runTransaction(async (transaction) => {
        return await callback(transaction);
      });
    } catch (error: any) {
      console.error("[TransactionManager] Transaction failed:", error.message);
      throw error;
    }
  }
}

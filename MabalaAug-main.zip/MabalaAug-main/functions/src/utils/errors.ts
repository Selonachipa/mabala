export class AppError extends Error {
  constructor(
    public readonly message: string,
    public readonly code: string,
    public readonly statusCode: number = 400,
    public readonly details?: any
  ) {
    super(message);
    Object.setPrototypeOf(this, new.target.prototype);
  }

  toJSON() {
    return {
      message: this.message,
      code: this.code,
      details: this.details,
    };
  }
}

export class UnauthorizedError extends AppError {
  constructor(message: string = "Unauthorized access", details?: any) {
    super(message, "UNAUTHORIZED", 401, details);
  }
}

export class ValidationError extends AppError {
  constructor(message: string, details?: any) {
    super(message, "VALIDATION_FAILED", 400, details);
  }
}

export class ConflictError extends AppError {
  constructor(message: string, details?: any) {
    super(message, "CONFLICT", 409, details);
  }
}

export class BillingError extends AppError {
  constructor(message: string, details?: any) {
    super(message, "BILLING_ERROR", 400, details);
  }
}

export class ProvisioningError extends AppError {
  constructor(message: string, details?: any) {
    super(message, "PROVISIONING_FAILED", 500, details);
  }
}

import { CallableRequest, HttpsError } from "firebase-functions/v2/https";
import { db, auth } from "../config/firebase";
import { verifyAuthContext } from "../middleware/auth";

export interface AuthenticatedRequest<T = any> extends CallableRequest<T> {
  auth: {
    uid: string;
    token: any;
    rawToken: string;
  };
}

export interface AuthorizedTenantContext {
  request: AuthenticatedRequest;
  tenantId: string;
  userData: Record<string, any>;
  isOwner: boolean;
}

/**
 * Resolves tenant identity from the authenticated user, never from an
 * untrusted request payload. A requested tenant is accepted only as a
 * consistency check for legacy callers.
 */
export async function resolveAuthorizedTenant<T = any>(
  request: CallableRequest<T>,
  requestedTenantId?: string,
  requireOwner = false
): Promise<AuthorizedTenantContext> {
  const authenticated = verifyAuthContext(request);
  const uid = authenticated.auth.uid;
  const profileSnap = await db.collection("users_data").doc(uid).get();
  const userData = (profileSnap.data() || {}) as Record<string, any>;
  const claimTenantId = typeof authenticated.auth.token?.tenantId === "string"
    ? authenticated.auth.token.tenantId
    : "";
  const tenantId = String(userData.tenantId || claimTenantId || uid).trim();
  const callerEmail = String(authenticated.auth.token?.email || userData.email || "").trim().toLowerCase();
  const canonicalSuperAdmins = [
    "support@mabala.cloud",
    "shikasuli@gmail.com",
    "owner@mabala.com",
    "mary@mabala.com"
  ];
  const isPlatformAdmin = authenticated.auth.token?.role === "super_admin" ||
    authenticated.auth.token?.superAdmin === true ||
    userData.role === "Super Admin" ||
    userData.role === "Platform Administrator" ||
    canonicalSuperAdmins.includes(callerEmail);

  if (!tenantId && !isPlatformAdmin) {
    throw new HttpsError("permission-denied", "No authorized tenant is associated with this account.");
  }

  if (requestedTenantId && requestedTenantId !== tenantId) {
    if (!isPlatformAdmin) {
      throw new HttpsError("permission-denied", "The requested tenant is not associated with this account.");
    }
  }

  if (isPlatformAdmin) {
    return { request: authenticated, tenantId: requestedTenantId || tenantId, userData, isOwner: true };
  }

  if (requestedTenantId && requestedTenantId !== tenantId) {
    throw new HttpsError("permission-denied", "The requested tenant is not associated with this account.");
  }

  const owner = uid === tenantId || userData.role === "Owner" || userData.role === "owner";
  const memberSnap = await db.collection("tenants").doc(tenantId).collection("members").doc(uid).get();
  const legacyMemberSnap = memberSnap.exists
    ? memberSnap
    : await db.collection("platform").doc("institutions").collection("institutions")
      .doc(tenantId).collection("members").doc(uid).get();
  const memberData = legacyMemberSnap.data() || {};
  const activeMember = owner || (legacyMemberSnap.exists && memberData.status === "active");

  if (!activeMember || (requireOwner && !owner)) {
    throw new HttpsError(
      "permission-denied",
      requireOwner ? "Only the farm owner can perform this operation." : "The account is not an active member of this workspace."
    );
  }

  return { request: authenticated, tenantId, userData, isOwner: owner };
}

/**
 * Verifies the Firebase Auth context, verifies the user exists and is enabled in Firebase Auth via Admin SDK,
 * and enforces tenant-level permissions for the authenticated user against the requested tenant ID.
 * 
 * @param request The CallableRequest from firebase-functions
 * @param tenantId The requested tenant ID to verify permissions for. If not provided, will try to read from request.data.tenantId.
 * @returns The verified, authenticated request
 */
export async function verifyTenantPermission<T = any>(
  request: CallableRequest<T>,
  tenantId?: string
): Promise<AuthenticatedRequest<T>> {
  const context = await resolveAuthorizedTenant(request, tenantId || (request.data as any)?.tenantId);
  const uid = context.request.auth.uid;
  const targetTenantId = context.tenantId;

  // 2. Double-check user validity with Firebase Admin SDK (verifies user is not disabled/deleted)
  try {
    const userRecord = await auth.getUser(uid);
    if (userRecord.disabled) {
      throw new HttpsError(
        "permission-denied",
        "The user account has been disabled."
      );
    }
  } catch (error: any) {
    if (error instanceof HttpsError) throw error;
    throw new HttpsError(
      "unauthenticated",
      `Failed to verify user authenticity with Firebase Auth: ${error.message}`
    );
  }

  // 3. Enforce tenant-level authorization
  // Get user profile data from Firestore users_data collection
  const userData = context.userData;

  // Bypasses if the user is a Platform Administrator
  if (userData.role === "Platform Administrator") {
    return request as AuthenticatedRequest<T>;
  }

  // Check if the user's tenantId matches the target tenantId
  // 4. Verify tenant status is active
  let tenantDocSnap = await db
    .collection("platform")
    .doc("institutions")
    .collection("institutions")
    .doc(targetTenantId)
    .get();

  if (!tenantDocSnap.exists) {
    tenantDocSnap = await db.collection("tenants").doc(targetTenantId).get();
  }

  if (!tenantDocSnap.exists) {
    throw new HttpsError(
      "not-found",
      "The requested tenant does not exist."
    );
  }

  const tenantData = tenantDocSnap.data();
  if (!tenantData || tenantData.status !== "Active") {
    throw new HttpsError(
      "failed-precondition",
      `The workspace tenant status is ${tenantData?.status || "unknown"}. Access is restricted.`
    );
  }

  return request as AuthenticatedRequest<T>;
}

/**
 * Enforces that a tenant workspace has sufficient credits and is not in Read-Only mode.
 * Blocks write actions when the wallet status is 'Read Only' by throwing a failed-precondition error with READ_ONLY_MODE_ACTIVE code.
 */
export async function enforceWritePermission(tenantId: string): Promise<void> {
  const summaryRef = db.collection("tenants").doc(tenantId).collection("wallet").doc("summary");
  const summarySnap = await summaryRef.get();

  if (summarySnap.exists) {
    const summary = summarySnap.data();
    if (summary && summary.status === "Read Only") {
      // Allow bypass if an active Daily Bundle covers usage
      if (summary.dailyBundleActiveUntil) {
        const activeUntil = new Date(summary.dailyBundleActiveUntil);
        if (activeUntil > new Date()) {
          return; // Daily Bundle is active, bypass Read-Only mode
        }
      }

      throw new HttpsError(
        "failed-precondition",
        "READ_ONLY_MODE_ACTIVE: Your workspace has depleted its credit balance and is currently in Read-Only mode. Please top up or upgrade your plan to unlock write capabilities.",
        { code: "READ_ONLY_MODE_ACTIVE" }
      );
    }
  }
}

import * as path from "path";
import * as fs from "fs";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { db, auth } from "./config/firebase";
import { FieldValue } from "firebase-admin/firestore";
import { verifyAuthContext } from "./middleware/auth";

// ==========================================
// CONFIGURATION CONSTANTS
// ==========================================
export const SUPPORT_EMAIL = "support@mabala.cloud";
export const SUPPORT_PHONE = "+260 978 070734";
export const LOGO_URL = "https://mabala.cloud/logo.png";
export const LOGIN_URL = "https://mabala.cloud/login";

/**
 * Loads an HTML template file from functions/templates or falls back to an embedded string.
 */
function loadTemplate(filename: string, fallback: string): string {
  try {
    const possiblePaths = [
      path.join(__dirname, "../templates", filename),
      path.join(__dirname, "../../templates", filename),
      path.join(process.cwd(), "templates", filename),
      path.join(process.cwd(), "functions/templates", filename)
    ];

    for (const p of possiblePaths) {
      if (fs.existsSync(p)) {
        return fs.readFileSync(p, "utf-8");
      }
    }
  } catch (err) {
    console.warn(`[welcomeEmail] Failed to read template file ${filename}, using fallback:`, err);
  }
  return fallback;
}

const FALLBACK_SIGNUP_HTML = `
<!DOCTYPE html>
<html>
<body style="font-family: sans-serif; padding: 20px; color: #1e293b;">
  <h2>Welcome to Mabala, {{FIRST_NAME}}!</h2>
  <p>Your Mabala agricultural workspace account has been created.</p>
  <div style="background: #f1f5f9; padding: 15px; border-radius: 8px; margin: 15px 0;">
    <p><strong>Email:</strong> {{EMAIL}}</p>
    <p><strong>Temporary Password:</strong> <code style="color: #047857;">{{PASSWORD}}</code></p>
  </div>
  <p><a href="{{LOGIN_URL}}" style="background: #047857; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; display: inline-block;">Sign In to Dashboard</a></p>
  <p>Support: <a href="mailto:{{SUPPORT_EMAIL}}">{{SUPPORT_EMAIL}}</a> | {{SUPPORT_PHONE}}</p>
</body>
</html>
`;

const FALLBACK_RESEND_HTML = `
<!DOCTYPE html>
<html>
<body style="font-family: sans-serif; padding: 20px; color: #1e293b;">
  <h2>Mabala Access Link</h2>
  <p>Hello {{FIRST_NAME}},</p>
  <p>A platform administrator has re-issued your Mabala access link.</p>
  <p><a href="{{RESET_LINK}}" style="background: #047857; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; display: inline-block;">Set Password & Access Account</a></p>
  <p>If the button above does not work, visit: {{RESET_LINK}}</p>
  <p>Support: <a href="mailto:{{SUPPORT_EMAIL}}">{{SUPPORT_EMAIL}}</a> | {{SUPPORT_PHONE}}</p>
</body>
</html>
`;

export interface SendSignupEmailInput {
  uid: string;
  email: string;
  firstName: string;
  password: string;
  farmName?: string;
}

/**
 * Sends a welcome email immediately upon signup with the temporary password.
 * Writes to the 'mail' collection for the Trigger Email extension and logs to 'emailAudit'.
 */
export async function sendWelcomeEmailOnSignup(input: SendSignupEmailInput): Promise<{ success: boolean; mailId: string }> {
  const { uid, email, firstName, password, farmName = "Mabala Farm Workspace" } = input;
  const currentYear = new Date().getFullYear().toString();

  const rawTemplate = loadTemplate("welcome-signup.html", FALLBACK_SIGNUP_HTML);
  const htmlContent = rawTemplate
    .replace(/\{\{FIRST_NAME\}\}/g, firstName || "Farmer")
    .replace(/\{\{EMAIL\}\}/g, email)
    .replace(/\{\{PASSWORD\}\}/g, password)
    .replace(/\{\{FARM_NAME\}\}/g, farmName)
    .replace(/\{\{LOGIN_URL\}\}/g, LOGIN_URL)
    .replace(/\{\{SUPPORT_EMAIL\}\}/g, SUPPORT_EMAIL)
    .replace(/\{\{SUPPORT_PHONE\}\}/g, SUPPORT_PHONE)
    .replace(/\{\{LOGO_URL\}\}/g, LOGO_URL)
    .replace(/\{\{YEAR\}\}/g, currentYear);

  const textContent = `Hello ${firstName || "Farmer"},\n\nWelcome to Mabala! Your account credentials are:\nEmail: ${email}\nTemporary Password: ${password}\n\nSign in to your dashboard: ${LOGIN_URL}\n\nSupport: ${SUPPORT_EMAIL} | ${SUPPORT_PHONE}`;

  // 1. Queue to Trigger Email extension collection ('mail')
  const mailRef = await db.collection("mail").add({
    to: email,
    message: {
      subject: `Welcome to Mabala — Your Account Credentials (${farmName})`,
      html: htmlContent,
      text: textContent
    },
    createdAt: FieldValue.serverTimestamp()
  });

  // 2. Write audit log entry in 'emailAudit' collection
  await db.collection("emailAudit").add({
    uid,
    email,
    type: "welcome_signup",
    sentBy: "system_provisioning",
    sentAt: FieldValue.serverTimestamp(),
    status: "queued",
    mailId: mailRef.id
  });

  console.log(`[welcomeEmail] Welcome email queued for ${email} (mailId: ${mailRef.id})`);
  return { success: true, mailId: mailRef.id };
}

/**
 * Callable Cloud Function: resendWelcomeEmail
 * Securely called by a Super Admin to re-dispatch access email with a fresh reset link.
 */
export const resendWelcomeEmail = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const callerUid = authContext.auth.uid;
  const callerToken = authContext.auth.token;
  const callerEmail = (callerToken.email || "").toLowerCase();

  // Canonical Super Admin validation
  const canonicalSuperAdmins = [
    "support@mabala.cloud",
    "shikasuli@gmail.com",
    "owner@mabala.com",
    "mary@mabala.com"
  ];

  let isSuper =
    callerToken.role === "super_admin" ||
    callerToken.superAdmin === true ||
    callerUid === "icIoBG4eN5VOw2BvhNiFUnUqmsX2" ||
    canonicalSuperAdmins.includes(callerEmail);

  if (!isSuper) {
    const userDoc = await db.collection("users_data").doc(callerUid).get();
    const userData = userDoc.data();
    if (userData?.role === "Super Admin" || userData?.superAdmin === true) {
      isSuper = true;
    }
  }

  if (!isSuper) {
    throw new HttpsError("permission-denied", "Access denied: Platform Super Admin privilege required.");
  }

  const targetUid = String(request.data?.uid || "");
  if (!targetUid) {
    throw new HttpsError("invalid-argument", "Missing required field: uid");
  }

  // 1. Fetch user from Firestore
  let targetUserDoc = await db.collection("users_data").doc(targetUid).get();
  if (!targetUserDoc.exists) {
    targetUserDoc = await db.collection("users").doc(targetUid).get();
  }

  let email = "";
  let firstName = "User";

  if (targetUserDoc.exists) {
    const data = targetUserDoc.data() || {};
    email = data.email || "";
    firstName = data.name ? data.name.split(" ")[0] : (data.firstName || "User");
  }

  // Fallback: lookup in Firebase Auth
  if (!email) {
    try {
      const userRecord = await auth.getUser(targetUid);
      email = userRecord.email || "";
      if (userRecord.displayName) {
        firstName = userRecord.displayName.split(" ")[0];
      }
    } catch (authErr: any) {
      console.warn(`[resendWelcomeEmail] Auth lookup error for ${targetUid}:`, authErr.message);
    }
  }

  if (!email) {
    throw new HttpsError("not-found", `User account with UID "${targetUid}" not found or has no email address.`);
  }

  // 2. Generate a fresh password reset link
  let resetLink = "";
  try {
    resetLink = await auth.generatePasswordResetLink(email, {
      url: "https://mabala.cloud/dashboard"
    });
  } catch (err: any) {
    console.warn(`[resendWelcomeEmail] generatePasswordResetLink fallback for ${email}:`, err.message);
    resetLink = `https://mabala.cloud/reset-password?email=${encodeURIComponent(email)}`;
  }

  // 3. Prepare email from template
  const currentYear = new Date().getFullYear().toString();
  const rawTemplate = loadTemplate("welcome-resend.html", FALLBACK_RESEND_HTML);
  const htmlContent = rawTemplate
    .replace(/\{\{FIRST_NAME\}\}/g, firstName)
    .replace(/\{\{EMAIL\}\}/g, email)
    .replace(/\{\{RESET_LINK\}\}/g, resetLink)
    .replace(/\{\{LOGIN_URL\}\}/g, LOGIN_URL)
    .replace(/\{\{SUPPORT_EMAIL\}\}/g, SUPPORT_EMAIL)
    .replace(/\{\{SUPPORT_PHONE\}\}/g, SUPPORT_PHONE)
    .replace(/\{\{LOGO_URL\}\}/g, LOGO_URL)
    .replace(/\{\{YEAR\}\}/g, currentYear);

  const textContent = `Hello ${firstName},\n\nA platform administrator has re-issued your Mabala access link. Please use the following link to set your password and access your workspace:\n\n${resetLink}\n\nSupport: ${SUPPORT_EMAIL} | ${SUPPORT_PHONE}`;

  // 4. Queue to 'mail' collection
  const mailRef = await db.collection("mail").add({
    to: email,
    message: {
      subject: "Mabala Access Link — Set Your Password",
      html: htmlContent,
      text: textContent
    },
    createdAt: FieldValue.serverTimestamp()
  });

  // 5. Write audit log entry to 'emailAudit' collection
  await db.collection("emailAudit").add({
    uid: targetUid,
    email,
    type: "welcome_resend",
    sentBy: callerUid,
    sentAt: FieldValue.serverTimestamp(),
    status: "queued",
    mailId: mailRef.id
  });

  console.log(`[resendWelcomeEmail] Welcome resend email queued for ${email} (sentBy: ${callerUid})`);

  return {
    success: true,
    message: `Welcome email queued for delivery to ${email}`,
    email,
    resetLink
  };
});

import { Request, Response } from "express";

/**
 * Allowed production origins for Mabala platform.
 */
export const ALLOWED_PRODUCTION_ORIGINS = [
  "https://mabala.cloud",
  "https://www.mabala.cloud"
];

/**
 * Checks whether an origin is authorized to interact with Mabala APIs.
 */
export function isAllowedOrigin(origin?: string): boolean {
  if (!origin) return false;
  const o = origin.trim().toLowerCase();
  if (ALLOWED_PRODUCTION_ORIGINS.some(allowed => allowed.toLowerCase() === o)) {
    return true;
  }
  // Allow AI Studio preview, Cloud Run dev, and standard localhost development
  if (
    o.startsWith("https://ais-dev-") ||
    o.startsWith("https://ais-pre-") ||
    o.includes(".run.app") ||
    o.includes(".web.app") ||
    o.includes(".firebaseapp.com") ||
    o.startsWith("http://localhost:") ||
    o.startsWith("http://127.0.0.1:")
  ) {
    return true;
  }
  return false;
}

/**
 * Centralized CORS middleware/wrapper for browser-facing onRequest Cloud Functions.
 * 
 * Guarantees:
 * - Inspects request Origin header
 * - Returns the exact allowed origin (never wildcard * for authenticated endpoints)
 * - Sets Vary: Origin
 * - Supports OPTIONS preflight requests returning HTTP 204
 * - Permits required HTTP methods and headers (Authorization, Content-Type, etc.)
 */
export function withCors(
  handler: (req: Request, res: Response) => Promise<void> | void
) {
  return async (req: Request, res: Response): Promise<void> => {
    const origin = req.headers.origin as string | undefined;

    if (origin && isAllowedOrigin(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
      res.setHeader("Access-Control-Allow-Credentials", "true");
      res.setHeader(
        "Access-Control-Allow-Headers",
        "Authorization, Content-Type, X-Requested-With, Accept, x-api-key, x-mabala-super-email, x-mabala-super-uid"
      );
      res.setHeader(
        "Access-Control-Allow-Methods",
        "GET, POST, PUT, PATCH, DELETE, OPTIONS"
      );
      res.setHeader("Access-Control-Max-Age", "86400"); // 24 hours
    }

    if (req.method === "OPTIONS") {
      res.status(204).end();
      return;
    }

    await handler(req, res);
  };
}

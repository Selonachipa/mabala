import { CallableRequest, HttpsError } from "firebase-functions/v2/https";

export interface AuthenticatedRequest<T = any> extends CallableRequest<T> {
  auth: {
    uid: string;
    token: any;
    rawToken: string;
  };
}

/**
 * Validates that the request has a valid, authenticated Firebase Auth context.
 * Throws an HttpsError if the user is unauthenticated.
 */
export function verifyAuthContext<T = any>(request: CallableRequest<T>): AuthenticatedRequest<T> {
  if (!request.auth) {
    throw new HttpsError(
      "unauthenticated",
      "The request is unauthenticated. Please sign in and try again."
    );
  }

  return request as AuthenticatedRequest<T>;
}

/**
 * Validates that the authenticated user is a verified user (email verified).
 */
export function verifyEmailVerified<T = any>(request: CallableRequest<T>): AuthenticatedRequest<T> {
  const authedReq = verifyAuthContext(request);
  
  if (authedReq.auth.token.email_verified !== true) {
    throw new HttpsError(
      "permission-denied",
      "Only users with a verified email address are authorized to perform this operation."
    );
  }

  return authedReq;
}

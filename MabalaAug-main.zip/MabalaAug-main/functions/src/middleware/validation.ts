import { HttpsError } from "firebase-functions/v2/https";

/**
 * Validates required fields in a payload. Throws HttpsError if any are missing.
 */
export function validatePayloadFields(payload: any, requiredFields: string[]): void {
  if (!payload || typeof payload !== "object") {
    throw new HttpsError("invalid-argument", "Payload must be a non-null object.");
  }

  const missingFields: string[] = [];
  for (const field of requiredFields) {
    if (payload[field] === undefined || payload[field] === null || payload[field] === "") {
      missingFields.push(field);
    }
  }

  if (missingFields.length > 0) {
    throw new HttpsError(
      "invalid-argument",
      `Missing required fields in payload: ${missingFields.join(", ")}`
    );
  }
}

/**
 * Validates alphanumeric format and maximum size constraints to prevent ID poisoning.
 */
export function validateIdFormat(id: string, fieldName: string, maxLength: number = 128): void {
  if (typeof id !== "string") {
    throw new HttpsError("invalid-argument", `${fieldName} must be a string.`);
  }

  if (id.length > maxLength) {
    throw new HttpsError("invalid-argument", `${fieldName} exceeds maximum allowed length of ${maxLength} characters.`);
  }

  const idPattern = /^[a-zA-Z0-9_\-@.:+]+$/;
  if (!idPattern.test(id)) {
    throw new HttpsError(
      "invalid-argument",
      `${fieldName} has an invalid format. Only alphanumeric characters, underscores, hyphens, periods, colons, and @ are allowed.`
    );
  }
}

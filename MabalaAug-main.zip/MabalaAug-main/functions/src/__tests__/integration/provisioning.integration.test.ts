import { ProvisioningService } from "../../services/ProvisioningService";
import { BillingService } from "../../services/BillingService";
import { Firestore } from "firebase-admin/firestore";

describe("E2E Workspace Provisioning & Billing Integration Tests", () => {
  let mockDb: any;
  let provisioningService: ProvisioningService;
  let billingService: BillingService;

  beforeEach(() => {
    // Standard mock database state
    const databaseState: Record<string, any> = {};

    const createDocRef = (path: string): any => {
      return {
        _path: path,
        collection: jest.fn((colName) => createCollectionRef(`${path}/${colName}`)),
        set: jest.fn(async (data) => {
          databaseState[path] = data;
          return {};
        }),
        get: jest.fn(async () => {
          return {
            exists: !!databaseState[path],
            id: path.split("/").pop(),
            data: () => databaseState[path]
          };
        })
      };
    };

    const createCollectionRef = (path: string): any => {
      return {
        _path: path,
        doc: jest.fn((docName) => createDocRef(`${path}/${docName}`))
      };
    };

    mockDb = {
      runTransaction: jest.fn(async (callback) => {
        const mockTransaction = {
          get: jest.fn(async (ref: any) => {
            const path = ref._path;
            return {
              exists: !!databaseState[path],
              id: path.split("/").pop(),
              data: () => databaseState[path]
            };
          }),
          set: jest.fn((ref: any, data: any) => {
            databaseState[ref._path] = data;
          }),
          update: jest.fn((ref: any, data: any) => {
            databaseState[ref._path] = {
              ...(databaseState[ref._path] || {}),
              ...data
            };
          })
        };
        return await callback(mockTransaction);
      }),
      collection: jest.fn((colName) => createCollectionRef(colName))
    };

    provisioningService = new ProvisioningService(mockDb as unknown as Firestore);
    billingService = new BillingService(mockDb as unknown as Firestore);
  });

  it("should provision a workspace, invite a user, and deduct credits end-to-end", async () => {
    const ownerId = "owner-999";
    
    // 1. Provision Workspace
    const provisionResult = await provisioningService.provisionWorkspace({
      userId: ownerId,
      farmName: "Harvest Moon Farm",
      primaryContact: "+260975555555",
      country: "Zambia",
      currency: "ZMW",
      selectedTier: "Standard Crop Operations",
      agreeTerms: true
    });

    expect(provisionResult.tenantId).toBe(ownerId);
    expect(provisionResult.tenant.name).toBe("Harvest Moon Farm");

    // 2. Invite a staff user
    const inviteResult = await provisioningService.inviteUser({
      tenantId: ownerId,
      inviterUserId: ownerId,
      inviteeEmail: "staff@harvestmoon.com",
      inviteeRole: "Staff"
    });

    expect(inviteResult.success).toBe(true);
    expect(inviteResult.inviteId).toBeDefined();

    // 3. Deduct standard credits
    await mockDb.runTransaction(async (transaction: any) => {
      await billingService.deductCreditsInTransaction(
        transaction,
        ownerId,
        10,
        "SMS Notification Campaign",
        ownerId
      );
    });

    // 4. Verify credit balance is updated and has deducted from 100 (to 90)
    const tenantRef = mockDb.collection("platform").doc("institutions").collection("institutions").doc(ownerId);
    let tenantDoc = await mockDb.runTransaction(async (tx: any) => tx.get(tenantRef));
    
    expect(tenantDoc.data().smsCreditBalance).toBe(90);
  });
});

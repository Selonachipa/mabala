import { TenantRepository } from "../../repositories/TenantRepository";
import { UserRepository } from "../../repositories/UserRepository";
import { Firestore, Transaction } from "firebase-admin/firestore";

describe("Repositories Unit Tests", () => {
  let mockDb: any;
  let mockTransaction: any;

  beforeEach(() => {
    mockDb = {
      collection: jest.fn().mockReturnThis(),
      doc: jest.fn().mockReturnThis(),
      get: jest.fn(),
      set: jest.fn(),
      update: jest.fn(),
    };

    mockTransaction = {
      get: jest.fn(),
      set: jest.fn(),
      update: jest.fn(),
    };
  });

  describe("TenantRepository", () => {
    it("should fetch a tenant by ID if it exists", async () => {
      const mockDocSnap = {
        exists: true,
        id: "tenant-123",
        data: () => ({
          name: "Test Farm",
          primaryContact: "+260111111",
          country: "Zambia",
          currency: "ZMW",
          subscriptionTier: "Basic Operations",
          smsCreditBalance: 50,
          activeModules: ["crops"],
          status: "Active",
        }),
      };

      mockDb.get.mockResolvedValue(mockDocSnap);

      const repo = new TenantRepository(mockDb as unknown as Firestore);
      const result = await repo.getTenant("tenant-123");

      expect(result).not.toBeNull();
      expect(result?.id).toBe("tenant-123");
      expect(result?.name).toBe("Test Farm");
    });

    it("should return null if tenant does not exist", async () => {
      const mockDocSnap = { exists: false };
      mockDb.get.mockResolvedValue(mockDocSnap);

      const repo = new TenantRepository(mockDb as unknown as Firestore);
      const result = await repo.getTenant("non-existent");

      expect(result).toBeNull();
    });

    it("should create tenant document in transaction", () => {
      const repo = new TenantRepository(mockDb as unknown as Firestore);
      
      repo.createTenantInTransaction(mockTransaction as unknown as Transaction, "tenant-123", {
        name: "New Farm",
        primaryContact: "+26099999",
        country: "Zambia",
        currency: "ZMW",
        subscriptionTier: "Basic Operations",
        smsCreditBalance: 50,
        activeModules: ["crops"],
        status: "Active"
      });

      expect(mockTransaction.set).toHaveBeenCalled();
    });
  });

  describe("UserRepository", () => {
    it("should fetch a user profile", async () => {
      const mockDocSnap = {
        exists: true,
        id: "user-123",
        data: () => ({
          email: "user@test.com",
          role: "Owner",
          tenantId: "tenant-123",
        }),
      };

      mockDb.get.mockResolvedValue(mockDocSnap);

      const repo = new UserRepository(mockDb as unknown as Firestore);
      const result = await repo.getUser("user-123");

      expect(result).not.toBeNull();
      expect(result?.uid).toBe("user-123");
      expect(result?.email).toBe("user@test.com");
    });
  });
});

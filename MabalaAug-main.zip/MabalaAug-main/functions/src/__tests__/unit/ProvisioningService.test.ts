import { ProvisioningService } from "../../services/ProvisioningService";
import { Firestore } from "firebase-admin/firestore";
import { ValidationError } from "../../utils/errors";

describe("ProvisioningService Unit Tests", () => {
  let mockDb: any;
  let service: ProvisioningService;

  beforeEach(() => {
    mockDb = {
      runTransaction: jest.fn(),
      collection: jest.fn().mockReturnThis(),
      doc: jest.fn().mockReturnThis(),
      get: jest.fn().mockResolvedValue({ exists: false, data: () => ({}) }),
      set: jest.fn().mockResolvedValue({}),
    };

    service = new ProvisioningService(mockDb as unknown as Firestore);
  });

  describe("provisionWorkspace", () => {
    it("should throw ValidationError if agreeTerms is not true", async () => {
      await expect(
        service.provisionWorkspace({
          userId: "owner-uid-123",
          farmName: "Test Farm",
          primaryContact: "+260970000001",
          country: "Zambia",
          currency: "ZMW",
          selectedTier: "Basic Operations"
        })
      ).rejects.toThrow(ValidationError);
    });

    it("should throw ValidationError if required inputs are missing", async () => {
      await expect(
        service.provisionWorkspace({
          userId: "",
          farmName: "Test Farm",
          primaryContact: "",
          country: "Zambia",
          currency: "ZMW",
          selectedTier: "Basic Operations",
          agreeTerms: true
        })
      ).rejects.toThrow(ValidationError);
    });

    it("should process and complete transactional provisioning successfully if tenant is new", async () => {
      // Mock transactional flow
      const mockTransaction = {
        get: jest.fn().mockResolvedValue({ exists: false }), // Tenant does not exist yet
        set: jest.fn(),
        update: jest.fn(),
      };

      mockDb.runTransaction.mockImplementation(async (callback: any) => {
        return await callback(mockTransaction);
      });

      const result = await service.provisionWorkspace({
        userId: "owner-uid-123",
        farmName: "Sunrise Agro Farm",
        primaryContact: "+260970000001",
        country: "Zambia",
        currency: "ZMW",
        selectedTier: "Basic Operations",
        agreeTerms: true
      });

      expect(result).toBeDefined();
      expect(result.tenantId).toBe("owner-uid-123");
      expect(result.tenant.name).toBe("Sunrise Agro Farm");
      
      // Verify complete transaction boundary writes
      expect(mockTransaction.get).toHaveBeenCalled();
      expect(mockTransaction.set).toHaveBeenCalled();
    });

    it("should return existing tenant info if already provisioned (Idempotency check)", async () => {
      const mockExistingTenantDoc = {
        exists: true,
        id: "owner-uid-123",
        data: () => ({
          name: "Sunrise Agro Farm",
          primaryContact: "+260970000001",
          country: "Zambia",
          currency: "ZMW",
          subscriptionTier: "Basic Operations",
          smsCreditBalance: 50,
          activeModules: ["crops", "inputs"],
          status: "Active"
        })
      };

      const mockTransaction = {
        get: jest.fn().mockResolvedValue(mockExistingTenantDoc),
        set: jest.fn(),
        update: jest.fn(),
      };

      mockDb.runTransaction.mockImplementation(async (callback: any) => {
        return await callback(mockTransaction);
      });

      const result = await service.provisionWorkspace({
        userId: "owner-uid-123",
        farmName: "Sunrise Agro Farm",
        primaryContact: "+260970000001",
        country: "Zambia",
        currency: "ZMW",
        selectedTier: "Basic Operations",
        agreeTerms: true
      });

      expect(result.tenantId).toBe("owner-uid-123");
      expect(result.tenant.name).toBe("Sunrise Agro Farm");
      expect(mockTransaction.set).not.toHaveBeenCalled(); // No new writes should occur
    });
  });
});

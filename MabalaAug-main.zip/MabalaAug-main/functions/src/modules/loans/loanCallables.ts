/**
 * Mabala.cloud - Authoritative Cloud Function Callables for Loan Management
 * Strictly enforces Server-Side Financial Authority & Tenant Isolation
 */

import { onCall, HttpsError } from "firebase-functions/v2/https";
import { db } from "../../config/firebase";
import { resolveAuthorizedTenant } from "../../utils/Validation";
import { FieldValue } from "firebase-admin/firestore";

/**
 * Deterministic schedule calculation
 */
function calculateSchedule(params: {
  principal: number;
  ratePct: number;
  tenorMonths: number;
  frequency: string;
  startDate: string;
}) {
  const schedule: any[] = [];
  const principal = Number(params.principal);
  const rate = Number(params.ratePct);
  const tenor = Math.max(1, Number(params.tenorMonths));

  if (params.frequency === "harvest_bullet" || tenor === 1) {
    const interest = Number(((principal * (rate / 100) * (tenor / 12))).toFixed(2));
    schedule.push({
      installmentNumber: 1,
      dueDate: new Date(Date.now() + tenor * 30 * 24 * 3600 * 1000).toISOString().split("T")[0],
      principalDue: principal,
      interestDue: interest,
      feesDue: 0,
      totalDue: Number((principal + interest).toFixed(2)),
      principalPaid: 0,
      interestPaid: 0,
      feesPaid: 0,
      totalPaid: 0,
      balanceRemaining: Number((principal + interest).toFixed(2)),
      status: "pending"
    });
    return schedule;
  }

  // Monthly flat rate schedule
  const totalInterest = Number(((principal * (rate / 100) * (tenor / 12))).toFixed(2));
  const principalPerMonth = Number((principal / tenor).toFixed(2));
  const interestPerMonth = Number((totalInterest / tenor).toFixed(2));

  for (let i = 1; i <= tenor; i++) {
    const isLast = i === tenor;
    const pDue = isLast ? Number((principal - principalPerMonth * (tenor - 1)).toFixed(2)) : principalPerMonth;
    const iDue = isLast ? Number((totalInterest - interestPerMonth * (tenor - 1)).toFixed(2)) : interestPerMonth;
    const totalDue = Number((pDue + iDue).toFixed(2));
    const dueDate = new Date(Date.now() + i * 30 * 24 * 3600 * 1000).toISOString().split("T")[0];

    schedule.push({
      installmentNumber: i,
      dueDate,
      principalDue: pDue,
      interestDue: iDue,
      feesDue: 0,
      totalDue,
      principalPaid: 0,
      interestPaid: 0,
      feesPaid: 0,
      totalPaid: 0,
      balanceRemaining: totalDue,
      status: "pending"
    });
  }

  return schedule;
}

/**
 * Callable: originateLoanApplication
 * Submits a loan application with strict caller tenant verification
 */
export const originateLoanApplication = onCall(async (request) => {
  const payload = request.data || {};
  const requestedTenant = payload.tenantId ? String(payload.tenantId) : undefined;
  const tenantContext = await resolveAuthorizedTenant(request, requestedTenant);
  const tenantId = tenantContext.tenantId;

  const {
    productId,
    productName,
    financingModel,
    requestedAmount,
    requestedTenorValue,
    purpose,
    borrowerName,
    borrowerPhone,
    borrowerNrc,
    lenderTenantId,
    cropCycleId,
    inputBasket,
    disbursementMethod,
    disbursementAccount
  } = payload;

  if (!productId || !requestedAmount || Number(requestedAmount) <= 0) {
    throw new HttpsError("invalid-argument", "Product ID and valid positive amount are required.");
  }

  const appId = `app-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const appNumber = `APP-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const now = new Date().toISOString();

  const applicationDoc = {
    id: appId,
    applicationNumber: appNumber,
    tenantId,
    lenderTenantId: lenderTenantId || "TENANT-PLATFORM-AGRI",
    borrowerId: tenantContext.request.auth.uid,
    borrowerName: borrowerName || tenantContext.userData.displayName || "Farmer",
    borrowerPhone: borrowerPhone || tenantContext.userData.phoneNumber || "",
    borrowerNrc: borrowerNrc || tenantContext.userData.nrcNumber || "",
    productId,
    productName: productName || "Agricultural Credit",
    financingModel: financingModel || "agricultural_crop",
    requestedAmount: Number(requestedAmount),
    requestedTenorValue: Number(requestedTenorValue || 6),
    requestedTenorUnit: "months",
    purpose: purpose || "Crop production inputs",
    cropCycleId: cropCycleId || null,
    inputBasket: inputBasket || [],
    disbursementMethod: disbursementMethod || "mobile_money",
    disbursementAccount: disbursementAccount || borrowerPhone || "",
    status: "submitted",
    createdAt: now,
    updatedAt: now
  };

  await db.collection("loan_applications").doc(appId).set(applicationDoc);

  return { success: true, application: applicationDoc };
});

/**
 * Callable: disburseLoanCallable
 * Authoritatively executes loan disbursement and schedule creation
 */
export const disburseLoanCallable = onCall(async (request) => {
  const payload = request.data || {};
  const requestedTenant = payload.lenderTenantId ? String(payload.lenderTenantId) : undefined;
  const tenantContext = await resolveAuthorizedTenant(request, requestedTenant);

  const { applicationId, customDisbursementDate } = payload;
  if (!applicationId) {
    throw new HttpsError("invalid-argument", "Application ID is required.");
  }

  const appSnap = await db.collection("loan_applications").doc(applicationId).get();
  if (!appSnap.exists) {
    throw new HttpsError("not-found", "Loan application does not exist.");
  }

  const appData = appSnap.data() as any;
  if (appData.status === "disbursed") {
    throw new HttpsError("already-exists", "This application has already been disbursed.");
  }

  const principal = Number(appData.approvedAmount || appData.requestedAmount);
  const ratePct = Number(appData.approvedInterestRatePct || 15);
  const tenorMonths = Number(appData.approvedTenorValue || appData.requestedTenorValue || 6);

  const schedule = calculateSchedule({
    principal,
    ratePct,
    tenorMonths,
    frequency: appData.financingModel === "agricultural_crop" ? "harvest_bullet" : "monthly",
    startDate: customDisbursementDate || new Date().toISOString()
  });

  const totalInterest = schedule.reduce((sum, s) => sum + s.interestDue, 0);
  const totalLoanAmount = Number((principal + totalInterest).toFixed(2));
  const loanId = `loan-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const loanNumber = `LN-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
  const now = new Date().toISOString();

  const loanDoc = {
    id: loanId,
    loanNumber,
    tenantId: appData.tenantId,
    lenderTenantId: appData.lenderTenantId,
    borrowerId: appData.borrowerId,
    borrowerName: appData.borrowerName,
    borrowerPhone: appData.borrowerPhone,
    borrowerNrc: appData.borrowerNrc,
    lenderName: "Mabala Credit Issuer",
    productId: appData.productId,
    productName: appData.productName,
    financingModel: appData.financingModel,
    currency: "ZMW",
    principalDisbursed: principal,
    totalPrincipalRepaid: 0,
    principalOutstanding: principal,
    interestRatePct: ratePct,
    interestCalculationMethod: "flat",
    totalInterestAccrued: totalInterest,
    totalInterestRepaid: 0,
    interestOutstanding: totalInterest,
    totalFeesCharged: 0,
    totalFeesRepaid: 0,
    feesOutstanding: 0,
    totalPenaltiesCharged: 0,
    totalPenaltiesRepaid: 0,
    penaltiesOutstanding: 0,
    totalLoanAmount,
    totalRepaid: 0,
    totalOutstandingBalance: totalLoanAmount,
    repaymentFrequency: appData.financingModel === "agricultural_crop" ? "harvest_bullet" : "monthly",
    tenorValue: tenorMonths,
    tenorUnit: "months",
    disbursementDate: customDisbursementDate || now.split("T")[0],
    maturityDate: schedule[schedule.length - 1]?.dueDate || now.split("T")[0],
    firstRepaymentDate: schedule[0]?.dueDate || now.split("T")[0],
    nextRepaymentDueDate: schedule[0]?.dueDate || now.split("T")[0],
    nextRepaymentDueAmount: schedule[0]?.totalDue || 0,
    daysPastDue: 0,
    agingBucket: "current",
    status: "active",
    disbursementReference: `DISB-${Date.now()}`,
    disbursementMethod: appData.disbursementMethod || "mobile_money",
    disbursementAccount: appData.disbursementAccount || "",
    schedule,
    createdAt: now,
    updatedAt: now
  };

  const txId = `TX-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  const transactionDoc = {
    id: txId,
    loanId,
    tenantId: appData.tenantId,
    lenderTenantId: appData.lenderTenantId,
    type: "disbursement",
    amount: principal,
    principalPortion: principal,
    interestPortion: 0,
    feePortion: 0,
    penaltyPortion: 0,
    source: appData.disbursementMethod || "mobile_money",
    referenceId: loanDoc.disbursementReference,
    balanceBefore: 0,
    balanceAfter: totalLoanAmount,
    notes: "Authoritative disbursement dispatched",
    performedBy: tenantContext.request.auth.uid,
    timestamp: now
  };

  await db.collection("loans").doc(loanId).set(loanDoc);
  await db.collection("loans").doc(loanId).collection("transactions").doc(txId).set(transactionDoc);
  await db.collection("loan_applications").doc(applicationId).update({
    status: "disbursed",
    loanId,
    updatedAt: now
  });

  return { success: true, loan: loanDoc, transaction: transactionDoc };
});

/**
 * Callable: repayLoanCallable
 * Authoritatively processes a payment and recalculates debt waterfall
 */
export const repayLoanCallable = onCall(async (request) => {
  const payload = request.data || {};
  const { loanId, amount, source, referenceId } = payload;
  const paymentAmount = Number(amount);

  if (!loanId || !paymentAmount || paymentAmount <= 0) {
    throw new HttpsError("invalid-argument", "Loan ID and positive repayment amount required.");
  }

  const loanRef = db.collection("loans").doc(loanId);
  const loanSnap = await loanRef.get();
  if (!loanSnap.exists) {
    throw new HttpsError("not-found", "Loan record not found.");
  }

  const loan = loanSnap.data() as any;
  if (loan.status === "paid_off") {
    throw new HttpsError("failed-precondition", "Loan is already fully settled.");
  }

  // Authorize tenant context
  await resolveAuthorizedTenant(request, loan.tenantId);

  let remaining = paymentAmount;
  let interestPaid = 0;
  let principalPaid = 0;

  // Clear interest first
  if (loan.interestOutstanding > 0) {
    interestPaid = Math.min(remaining, loan.interestOutstanding);
    remaining = Number((remaining - interestPaid).toFixed(2));
  }

  // Clear principal
  if (remaining > 0 && loan.principalOutstanding > 0) {
    principalPaid = Math.min(remaining, loan.principalOutstanding);
    remaining = Number((remaining - principalPaid).toFixed(2));
  }

  const newInterestBal = Number((loan.interestOutstanding - interestPaid).toFixed(2));
  const newPrincipalBal = Number((loan.principalOutstanding - principalPaid).toFixed(2));
  const newTotalBal = Number((newInterestBal + newPrincipalBal).toFixed(2));

  const now = new Date().toISOString();
  const txId = `TX-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

  const transactionDoc = {
    id: txId,
    loanId,
    tenantId: loan.tenantId,
    lenderTenantId: loan.lenderTenantId,
    type: "repayment",
    amount: paymentAmount,
    principalPortion: principalPaid,
    interestPortion: interestPaid,
    feePortion: 0,
    penaltyPortion: 0,
    source: source || "lipila_mobile_money",
    referenceId: referenceId || txId,
    balanceBefore: loan.totalOutstandingBalance,
    balanceAfter: newTotalBal,
    notes: `Authoritative repayment allocated: Principal K${principalPaid}, Interest K${interestPaid}`,
    timestamp: now
  };

  const updatedStatus = newTotalBal <= 0.01 ? "paid_off" : loan.status;

  await loanRef.update({
    interestOutstanding: newInterestBal,
    principalOutstanding: newPrincipalBal,
    totalInterestRepaid: Number(((loan.totalInterestRepaid || 0) + interestPaid).toFixed(2)),
    totalPrincipalRepaid: Number(((loan.totalPrincipalRepaid || 0) + principalPaid).toFixed(2)),
    totalRepaid: Number(((loan.totalRepaid || 0) + principalPaid + interestPaid).toFixed(2)),
    totalOutstandingBalance: newTotalBal,
    status: updatedStatus,
    updatedAt: now
  });

  await loanRef.collection("transactions").doc(txId).set(transactionDoc);

  return {
    success: true,
    loanId,
    newBalance: newTotalBal,
    status: updatedStatus,
    principalPaid,
    interestPaid
  };
});

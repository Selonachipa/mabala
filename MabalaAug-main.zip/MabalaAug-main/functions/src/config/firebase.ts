import { getApps, initializeApp } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { getAuth } from "firebase-admin/auth";

// Determine project configuration from environment or standard values
const PROJECT_ID = process.env.FIREBASE_PROJECT_ID || process.env.GCLOUD_PROJECT || "mabala-f2d65";
const DATABASE_ID = process.env.FIREBASE_FIRESTORE_DATABASE_ID || "ai-studio-020042e7-7cf8-4e86-bdea-ea1ae9737651";

// Initialize Firebase Admin App singleton safely
const apps = getApps();
export const app = apps.length === 0 ? initializeApp({ projectId: PROJECT_ID }) : apps[0];

// Export lazy-loaded database and auth references
export const db = getFirestore(app, DATABASE_ID);
export const auth = getAuth(app);

console.log(`[Admin Config] Firebase Admin initialized for project: ${PROJECT_ID}, database: ${DATABASE_ID}`);

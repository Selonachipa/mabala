import { Firestore, Transaction, DocumentReference } from "firebase-admin/firestore";

export interface TenantDocument {
  id: string;
  name: string;
  primaryContact: string;
  country: string;
  currency: string;
  province?: string;
  district?: string;
  location?: {
    province: string;
    district: string;
    lat?: number;
    lng?: number;
  };
  subscriptionTier: string;
  smsCreditBalance: number;
  activeModules: string[];
  status: "Active" | "Suspended" | "Pending";
  onboardingPartnerId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BillingAccountDocument {
  tier: string;
  cost: number;
  smsRateZmw: number;
  smsRateZmwEffectiveDate: string;
  billingPeriod: "Monthly" | "Annual";
  status: "Active" | "Past Due" | "Unpaid";
  startDate: string;
  nextRenewalDate: string;
  createdAt: string;
  updatedAt: string;
}

export class TenantRepository {
  constructor(private readonly db: Firestore) {}

  private getTenantRef(tenantId: string): DocumentReference {
    return this.db.collection("platform").doc("institutions").collection("institutions").doc(tenantId);
  }

  private getBillingRef(tenantId: string): DocumentReference {
    return this.getTenantRef(tenantId).collection("billing_accounts").doc("global");
  }

  async getTenant(tenantId: string): Promise<TenantDocument | null> {
    const docSnap = await this.getTenantRef(tenantId).get();
    if (!docSnap.exists) return null;
    return { id: docSnap.id, ...(docSnap.data() as Omit<TenantDocument, "id">) };
  }

  async getTenantInTransaction(transaction: Transaction, tenantId: string): Promise<TenantDocument | null> {
    const ref = this.getTenantRef(tenantId);
    const docSnap = await transaction.get(ref);
    if (!docSnap.exists) return null;
    return { id: docSnap.id, ...(docSnap.data() as Omit<TenantDocument, "id">) };
  }

  createTenantInTransaction(transaction: Transaction, tenantId: string, tenant: Omit<TenantDocument, "id" | "createdAt" | "updatedAt">): void {
    const ref = this.getTenantRef(tenantId);
    const now = new Date().toISOString();
    const data = {
      ...tenant,
      createdAt: now,
      updatedAt: now
    };
    transaction.set(ref, data);
  }

  updateTenantInTransaction(transaction: Transaction, tenantId: string, updates: Partial<Omit<TenantDocument, "id" | "createdAt" | "updatedAt">>): void {
    const ref = this.getTenantRef(tenantId);
    const data = {
      ...updates,
      updatedAt: new Date().toISOString()
    };
    transaction.update(ref, data);
  }

  createBillingAccountInTransaction(transaction: Transaction, tenantId: string, billing: Omit<BillingAccountDocument, "createdAt" | "updatedAt">): void {
    const ref = this.getBillingRef(tenantId);
    const now = new Date().toISOString();
    const data = {
      ...billing,
      createdAt: now,
      updatedAt: now
    };
    transaction.set(ref, data);
  }
}

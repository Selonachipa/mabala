import { Firestore, Transaction } from "firebase-admin/firestore";

export interface AuditLogDocument {
  institutionId: string;
  actorUid: string;
  actorType: string;
  action: string;
  details: string;
  actor_user_id: string;
  actor_type: string;
  target_farmer_id: string;
  metadata: string;
  timestamp: string;
}

export class AuditLogRepository {
  constructor(private readonly db: Firestore) {}

  private getLogsCollection() {
    return this.db.collection("platform").doc("institution_audit_logs").collection("institution_audit_logs");
  }

  async createAuditLog(log: Omit<AuditLogDocument, "timestamp">): Promise<string> {
    const logId = "inst_log_" + Date.now() + "_" + Math.floor(Math.random() * 1000);
    const ref = this.getLogsCollection().doc(logId);
    const data: AuditLogDocument = {
      ...log,
      timestamp: new Date().toISOString()
    };
    await ref.set(data);
    return logId;
  }

  createAuditLogInTransaction(transaction: Transaction, log: Omit<AuditLogDocument, "timestamp">): string {
    const logId = "inst_log_" + Date.now() + "_" + Math.floor(Math.random() * 1000);
    const ref = this.getLogsCollection().doc(logId);
    const data: AuditLogDocument = {
      ...log,
      timestamp: new Date().toISOString()
    };
    transaction.set(ref, data);
    return logId;
  }
}

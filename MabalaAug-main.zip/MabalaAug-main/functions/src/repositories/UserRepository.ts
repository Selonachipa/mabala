import { Firestore, Transaction, DocumentReference } from "firebase-admin/firestore";

export interface UserProfile {
  uid: string;
  email: string;
  role: string;
  tenantId?: string;
  farms?: any[];
  accounts?: any[];
  updatedAt: string;
  [key: string]: any;
}

export class UserRepository {
  constructor(private readonly db: Firestore) {}

  private getUserRef(uid: string): DocumentReference {
    return this.db.collection("users_data").doc(uid);
  }

  private getAdminRef(uid: string): DocumentReference {
    return this.db.collection("platform").doc("admins").collection("admins").doc(uid);
  }

  async getUser(uid: string): Promise<UserProfile | null> {
    const docSnap = await this.getUserRef(uid).get();
    if (!docSnap.exists) return null;
    return { uid: docSnap.id, ...(docSnap.data() as any) } as UserProfile;
  }

  async getUserInTransaction(transaction: Transaction, uid: string): Promise<UserProfile | null> {
    const ref = this.getUserRef(uid);
    const docSnap = await transaction.get(ref);
    if (!docSnap.exists) return null;
    return { uid: docSnap.id, ...(docSnap.data() as any) } as UserProfile;
  }

  createUserInTransaction(transaction: Transaction, uid: string, user: Omit<UserProfile, "uid" | "updatedAt">): void {
    const ref = this.getUserRef(uid);
    const now = new Date().toISOString();
    const data = {
      ...user,
      updatedAt: now
    };
    transaction.set(ref, data);
  }

  updateUserInTransaction(transaction: Transaction, uid: string, updates: Partial<Omit<UserProfile, "uid" | "updatedAt">>): void {
    const ref = this.getUserRef(uid);
    const data = {
      ...updates,
      updatedAt: new Date().toISOString()
    };
    transaction.update(ref, data);
  }

  async isAdmin(uid: string): Promise<boolean> {
    const adminSnap = await this.getAdminRef(uid).get();
    return adminSnap.exists && adminSnap.data()?.active === true;
  }
}

import { Transaction, Firestore } from "firebase-admin/firestore";
import { TenantRepository } from "../repositories/TenantRepository";
import { AuditLogRepository } from "../repositories/AuditLogRepository";
import { BillingError } from "../utils/errors";

export class BillingService {
  private readonly tenantRepo: TenantRepository;
  private readonly auditRepo: AuditLogRepository;

  constructor(private readonly db: Firestore) {
    this.tenantRepo = new TenantRepository(db);
    this.auditRepo = new AuditLogRepository(db);
  }

  async allocateCreditsInTransaction(
    transaction: Transaction,
    tenantId: string,
    amount: number,
    reason: string,
    actorUid: string = "system",
    category: string = "sms"
  ): Promise<void> {
    // Preserve the legacy five-argument call shape where the fifth argument
    // was actorUid, while allowing new callers to provide a category.
    if (actorUid === "system" && category !== "sms" && category !== "platform") {
      actorUid = category;
      category = "sms";
    }
    const tenant = await this.tenantRepo.getTenantInTransaction(transaction, tenantId);
    if (!tenant) {
      throw new BillingError(`Tenant ${tenantId} not found`);
    }

    const currentBalance = tenant.smsCreditBalance || 0;
    const newBalance = currentBalance + amount;

    // Update tenant credit balance
    this.tenantRepo.updateTenantInTransaction(transaction, tenantId, {
      smsCreditBalance: newBalance,
    });

    // Write audit log
    this.auditRepo.createAuditLogInTransaction(transaction, {
      institutionId: tenantId,
      actorUid,
      actorType: actorUid === "system" ? "system" : "institution_admin",
      action: "credit_allocation",
      details: `Allocated ${amount} SMS credits. Reason: ${reason}. New balance: ${newBalance}`,
      actor_user_id: actorUid,
      actor_type: actorUid === "system" ? "system" : "institution_admin",
      target_farmer_id: "",
      metadata: JSON.stringify({ amount, reason, previousBalance: currentBalance, newBalance }),
    });
  }

  async deductCreditsInTransaction(
    transaction: Transaction,
    tenantId: string,
    amount: number,
    reason: string,
    category: string = "sms",
    actorUid: string = "system"
  ): Promise<void> {
    const tenant = await this.tenantRepo.getTenantInTransaction(transaction, tenantId);
    if (!tenant) {
      throw new BillingError(`Tenant ${tenantId} not found`);
    }

    const currentBalance = tenant.smsCreditBalance || 0;
    const newBalance = currentBalance - amount;

    if (newBalance < 0) {
      throw new BillingError(`Insufficient credits. Current balance: ${currentBalance}, required: ${amount}`);
    }

    // Update tenant credit balance
    this.tenantRepo.updateTenantInTransaction(transaction, tenantId, {
      smsCreditBalance: newBalance,
    });

    // Write audit log
    this.auditRepo.createAuditLogInTransaction(transaction, {
      institutionId: tenantId,
      actorUid,
      actorType: actorUid === "system" ? "system" : "institution_admin",
      action: "credit_deduction",
      details: `Deducted ${amount} SMS credits. Reason: ${reason}. New balance: ${newBalance}`,
      actor_user_id: actorUid,
      actor_type: actorUid === "system" ? "system" : "institution_admin",
      target_farmer_id: "",
      metadata: JSON.stringify({ amount, reason, previousBalance: currentBalance, newBalance }),
    });
  }

  async renewSubscriptionInTransaction(
    transaction: Transaction,
    tenantId: string,
    newExpiryDate: string,
    actorUid: string = "system"
  ): Promise<void> {
    const tenant = await this.tenantRepo.getTenantInTransaction(transaction, tenantId);
    if (!tenant) {
      throw new BillingError(`Tenant ${tenantId} not found`);
    }

    // Update billing account subcollection doc inside transaction
    const billingRef = this.db
      .collection("platform")
      .doc("institutions")
      .collection("institutions")
      .doc(tenantId)
      .collection("billing_accounts")
      .doc("global");

    transaction.update(billingRef, {
      nextRenewalDate: newExpiryDate,
      status: "Active",
      updatedAt: new Date().toISOString(),
    });

    // Write audit log
    this.auditRepo.createAuditLogInTransaction(transaction, {
      institutionId: tenantId,
      actorUid,
      actorType: actorUid === "system" ? "system" : "institution_admin",
      action: "subscription_renewal",
      details: `Renewed subscription to expiry date: ${newExpiryDate}`,
      actor_user_id: actorUid,
      actor_type: actorUid === "system" ? "system" : "institution_admin",
      target_farmer_id: "",
      metadata: JSON.stringify({ newExpiryDate }),
    });
  }

  async processPaymentWebhook(
    referenceId: string,
    status: string,
    payload: any
  ): Promise<void> {
    const paymentRef = this.db.collection("payments").doc(referenceId);

    await this.db.runTransaction(async (transaction) => {
      const paymentSnap = await transaction.get(paymentRef);
      if (!paymentSnap.exists) {
        throw new BillingError(`Payment record ${referenceId} not found`);
      }

      const payment = paymentSnap.data()!;
      if (payment.status === "Successful") {
        // Payment is already processed, idempotent bypass
        return;
      }

      const updatedStatus = status === "Successful" || status === "Success" ? "Successful" : "Failed";

      // 1. Update status on the payment record
      transaction.update(paymentRef, {
        status: updatedStatus,
        updatedAt: new Date().toISOString(),
        gatewayPayload: JSON.stringify(payload),
      });

      // 2. Allocate resources if successful
      if (updatedStatus === "Successful") {
        if (payment.packageType === "sms_topup" && payment.institutionId) {
          const tenantId = payment.institutionId;
          const creditsToAward = Number(payment.creditsToAward) || 0;

          const tenantRef = this.db
            .collection("platform")
            .doc("institutions")
            .collection("institutions")
            .doc(tenantId);
          const tenantSnap = await transaction.get(tenantRef);

          if (tenantSnap.exists) {
            const tenant = tenantSnap.data()!;
            const current = Number(tenant.smsCreditBalance || 0);
            const newBalance = current + creditsToAward;

            transaction.update(tenantRef, {
              smsCreditBalance: newBalance,
              updatedAt: new Date().toISOString(),
            });

            // Add SMS ledger entry
            const ledgerRef = tenantRef.collection("sms_ledger").doc();
            transaction.set(ledgerRef, {
              amount: creditsToAward,
              type: "top_up",
              referenceId,
              description: `Lipila Self-Serve top-up of ${creditsToAward} credits`,
              createdAt: new Date().toISOString(),
            });

            // Write audit log
            this.auditRepo.createAuditLogInTransaction(transaction, {
              institutionId: tenantId,
              actorUid: tenant.adminUid || "system",
              actorType: "institution_admin",
              action: "credit_adjustment",
              details: `Self-serve SMS top-up by ${creditsToAward} credits (new balance = ${newBalance})`,
              actor_user_id: tenant.adminUid || "system",
              actor_type: "institution_admin",
              target_farmer_id: "",
              metadata: JSON.stringify({ referenceId, creditsToAward, newBalance }),
            });
          }
        } else if (payment.uid && payment.uid !== "anonymous") {
          // Adjust farmer platform credits
          const userRef = this.db.collection("users_data").doc(payment.uid);
          const userSnap = await transaction.get(userRef);

          if (userSnap.exists) {
            const user = userSnap.data()!;
            const currentCredits = Number(user.credits || 0);
            const creditsToAward = Number(payment.creditsToAward) || 0;
            const newCredits = currentCredits + creditsToAward;

            transaction.update(userRef, {
              credits: newCredits,
              subscriptionTier: payment.packageName || user.subscriptionTier,
              updatedAt: new Date().toISOString(),
            });
          }
        }
      }
    });
  }
}

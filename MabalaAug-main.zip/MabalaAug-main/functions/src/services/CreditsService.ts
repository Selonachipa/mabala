import { Firestore, Transaction } from "firebase-admin/firestore";
import { BillingError } from "../utils/errors";

export interface WalletSummary {
  balance: number;
  promotionalBalance: number;
  purchasedBalance: number;
  subscriptionBalance: number;
  bonusBalance: number;
  consumedByCategory: Record<string, number>;
  pendingBalance: number;
  status: "Active" | "Read Only" | "Suspended";
  dailyBundleActiveUntil?: string | null;
  updatedAt: string;
}

export interface LedgerEntry {
  timestamp: string;
  type: "reward" | "purchase" | "subscription_allocation" | "usage" | "refund" | "bonus" | "adjustment";
  amount: number; // Signed (positive or negative)
  runningBalance: number;
  referenceId: string;
  relatedInvoiceId?: string | null;
  performedBy: string;
  reason: string;
  category?: string | null;
}

export class CreditsService {
  constructor(private readonly db: Firestore) {}

  /**
   * Initializes a brand-new wallet summary for a tenant workspace.
   */
  async createWalletInTransaction(transaction: Transaction, tenantId: string): Promise<WalletSummary> {
    const summaryRef = this.db.collection("tenants").doc(tenantId).collection("wallet").doc("summary");
    const summarySnap = await transaction.get(summaryRef);

    if (summarySnap.exists) {
      return summarySnap.data() as WalletSummary;
    }

    const initialSummary: WalletSummary = {
      balance: 0,
      promotionalBalance: 0,
      purchasedBalance: 0,
      subscriptionBalance: 0,
      bonusBalance: 0,
      consumedByCategory: {},
      pendingBalance: 0,
      status: "Active",
      dailyBundleActiveUntil: null,
      updatedAt: new Date().toISOString()
    };

    transaction.set(summaryRef, initialSummary);
    return initialSummary;
  }

  /**
   * Recomputes and verifies the denormalized summary balance by summing all ledger records.
   * Ensures ledger parity and double-entry mathematical consistency.
   */
  private async recomputeAndVerifyBalance(
    transaction: Transaction,
    tenantId: string,
    newEntryAmount: number,
    summary: WalletSummary | null
  ): Promise<number> {
    const ledgerCollRef = this.db.collection("tenants").doc(tenantId).collection("wallet").doc("summary").collection("ledger");
    const ledgerSnap = await transaction.get(ledgerCollRef);
    
    let sum = 0;
    if (ledgerSnap && typeof ledgerSnap.forEach === "function") {
      ledgerSnap.forEach((doc: any) => {
        const data = doc.data();
        sum += (Number(data.amount) || 0);
      });
    } else {
      sum = summary ? summary.balance : 0;
    }

    return sum + newEntryAmount;
  }

  /**
   * Allocates promotional, purchased, subscription or bonus credits to the tenant wallet.
   */
  async allocateCreditsInTransaction(
    transaction: Transaction,
    tenantId: string,
    amount: number,
    type: "reward" | "purchase" | "subscription_allocation" | "bonus" | "adjustment",
    reason: string,
    actorUid: string = "system",
    referenceId?: string,
    relatedInvoiceId?: string
  ): Promise<WalletSummary> {
    if (amount <= 0) {
      throw new BillingError("Allocation amount must be a positive number.");
    }

    const summaryRef = this.db.collection("tenants").doc(tenantId).collection("wallet").doc("summary");
    const summarySnap = await transaction.get(summaryRef);
    let summary = summarySnap.exists ? (summarySnap.data() as WalletSummary) : null;

    if (!summary) {
      summary = await this.createWalletInTransaction(transaction, tenantId);
    }

    // Determine the running balance using total ledger summation
    const verifiedBalance = await this.recomputeAndVerifyBalance(transaction, tenantId, amount, summary);

    // Create the ledger record
    const entryId = "ledg_" + Date.now() + "_" + Math.floor(Math.random() * 100000);
    const ledgerRef = summaryRef.collection("ledger").doc(entryId);

    const ledgerEntry: LedgerEntry = {
      timestamp: new Date().toISOString(),
      type,
      amount,
      runningBalance: verifiedBalance,
      referenceId: referenceId || entryId,
      relatedInvoiceId: relatedInvoiceId || null,
      performedBy: actorUid,
      reason
    };

    transaction.set(ledgerRef, ledgerEntry);

    // Update designated bucket allocations in summary
    if (type === "reward") {
      summary.promotionalBalance = (summary.promotionalBalance || 0) + amount;
    } else if (type === "purchase") {
      summary.purchasedBalance = (summary.purchasedBalance || 0) + amount;
    } else if (type === "subscription_allocation") {
      summary.subscriptionBalance = (summary.subscriptionBalance || 0) + amount;
    } else if (type === "bonus") {
      summary.bonusBalance = (summary.bonusBalance || 0) + amount;
    } else if (type === "adjustment") {
      summary.bonusBalance = (summary.bonusBalance || 0) + amount;
    }

    summary.balance = verifiedBalance;
    summary.updatedAt = new Date().toISOString();

    // Re-active if status was previously Read Only
    if (summary.status === "Read Only" && verifiedBalance > 0) {
      summary.status = "Active";
    }

    transaction.set(summaryRef, summary);
    return summary;
  }

  /**
   * Deducts credits based on granular resource consumption priorities.
   */
  async deductCreditsInTransaction(
    transaction: Transaction,
    tenantId: string,
    amount: number,
    reason: string,
    category: string,
    actorUid: string = "system"
  ): Promise<WalletSummary> {
    if (amount <= 0) {
      throw new BillingError("Deduction amount must be a positive number.");
    }

    const summaryRef = this.db.collection("tenants").doc(tenantId).collection("wallet").doc("summary");
    const summarySnap = await transaction.get(summaryRef);
    let summary = summarySnap.exists ? (summarySnap.data() as WalletSummary) : null;

    if (!summary) {
      summary = await this.createWalletInTransaction(transaction, tenantId);
    }

    // 1. Check for active Daily Bundle bypass
    if (summary.dailyBundleActiveUntil) {
      const activeUntil = new Date(summary.dailyBundleActiveUntil);
      if (activeUntil > new Date()) {
        console.log(`[CreditsService] Daily bundle bypass active until ${summary.dailyBundleActiveUntil}. Bypassing deduction.`);
        return summary;
      }
    }

    const previousBalance = summary.balance;
    if (previousBalance < amount) {
      throw new BillingError(`INSUFFICIENT_CREDITS: Current balance is ${previousBalance}, required: ${amount}.`);
    }

    // Calculate verified running balance using full ledger traversal
    const verifiedBalance = await this.recomputeAndVerifyBalance(transaction, tenantId, -amount, summary);

    // Apply prioritised deduction cascade: Promotional -> Purchased -> Subscription -> Bonus
    let remainingToDeduct = amount;

    // 1. Promotional Balance
    if (summary.promotionalBalance && summary.promotionalBalance > 0 && remainingToDeduct > 0) {
      const deduct = Math.min(summary.promotionalBalance, remainingToDeduct);
      summary.promotionalBalance -= deduct;
      remainingToDeduct -= deduct;
    }

    // 2. Purchased Balance
    if (summary.purchasedBalance && summary.purchasedBalance > 0 && remainingToDeduct > 0) {
      const deduct = Math.min(summary.purchasedBalance, remainingToDeduct);
      summary.purchasedBalance -= deduct;
      remainingToDeduct -= deduct;
    }

    // 3. Subscription Balance
    if (summary.subscriptionBalance && summary.subscriptionBalance > 0 && remainingToDeduct > 0) {
      const deduct = Math.min(summary.subscriptionBalance, remainingToDeduct);
      summary.subscriptionBalance -= deduct;
      remainingToDeduct -= deduct;
    }

    // 4. Bonus Balance
    if (summary.bonusBalance && summary.bonusBalance > 0 && remainingToDeduct > 0) {
      const deduct = Math.min(summary.bonusBalance, remainingToDeduct);
      summary.bonusBalance -= deduct;
      remainingToDeduct -= deduct;
    }

    // Register consumption stats
    const categoryLower = category.trim().toLowerCase();
    summary.consumedByCategory = summary.consumedByCategory || {};
    summary.consumedByCategory[categoryLower] = (summary.consumedByCategory[categoryLower] || 0) + amount;

    // Create negative running ledger entry
    const entryId = "ledg_" + Date.now() + "_" + Math.floor(Math.random() * 100000);
    const ledgerRef = summaryRef.collection("ledger").doc(entryId);

    const ledgerEntry: LedgerEntry = {
      timestamp: new Date().toISOString(),
      type: "usage",
      amount: -amount,
      runningBalance: verifiedBalance,
      referenceId: entryId,
      performedBy: actorUid,
      reason,
      category
    };

    transaction.set(ledgerRef, ledgerEntry);

    summary.balance = verifiedBalance;
    summary.updatedAt = new Date().toISOString();

    // Check if the tenant enters Read Only status
    if (verifiedBalance <= 0) {
      summary.status = "Read Only";
    }

    transaction.set(summaryRef, summary);
    return summary;
  }

  /**
   * Activates a 24-hour Daily Bundle for the tenant.
   */
  async activateDailyBundleInTransaction(
    transaction: Transaction,
    tenantId: string,
    actorUid: string = "system"
  ): Promise<WalletSummary> {
    const summaryRef = this.db.collection("tenants").doc(tenantId).collection("wallet").doc("summary");
    const summarySnap = await transaction.get(summaryRef);
    let summary = summarySnap.exists ? (summarySnap.data() as WalletSummary) : null;

    if (!summary) {
      summary = await this.createWalletInTransaction(transaction, tenantId);
    }

    const expiryDate = new Date();
    expiryDate.setHours(expiryDate.getHours() + 24);

    summary.dailyBundleActiveUntil = expiryDate.toISOString();
    summary.status = "Active"; // Bypasses Read Only mode
    summary.updatedAt = new Date().toISOString();

    transaction.set(summaryRef, summary);

    // Record audit trail or ledger entry with 0 amount
    const entryId = "ledg_" + Date.now() + "_" + Math.floor(Math.random() * 100000);
    const ledgerRef = summaryRef.collection("ledger").doc(entryId);

    const ledgerEntry: LedgerEntry = {
      timestamp: new Date().toISOString(),
      type: "purchase",
      amount: 0,
      runningBalance: summary.balance,
      referenceId: entryId,
      performedBy: actorUid,
      reason: `Activated 24-Hour Unlimited Daily Bundle (Expires: ${expiryDate.toISOString()})`
    };

    transaction.set(ledgerRef, ledgerEntry);

    return summary;
  }
}

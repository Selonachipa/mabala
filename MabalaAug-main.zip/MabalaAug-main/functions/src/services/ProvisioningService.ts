import { Firestore } from "firebase-admin/firestore";
import { TenantRepository, TenantDocument } from "../repositories/TenantRepository";
import { UserRepository, UserProfile } from "../repositories/UserRepository";
import { AuditLogRepository } from "../repositories/AuditLogRepository";
import { CreditsService } from "./CreditsService";
import { EmailService } from "./EmailService";
import { ValidationError } from "../utils/errors";
import { sendWelcomeEmailOnSignup } from "../welcomeEmail.functions";
import defaultDistrictsJson from "../data/zambiaDistricts.json";

const zambiaDistrictsMap: Record<string, string[]> = defaultDistrictsJson;

export interface ProvisionWorkspaceInput {
  userId: string;
  farmName: string;
  primaryContact: string;
  country: string;
  currency: string;
  selectedTier: string;
  province?: string;
  district?: string;
  location?: {
    province: string;
    district: string;
    lat?: number;
    lng?: number;
  };
  onboardingPartnerId?: string;
  agreeTerms?: boolean;
  tpin?: string;
  logoUrl?: string;
  email?: string;
  password?: string;
  firstName?: string;
}

export interface InviteUserInput {
  tenantId: string;
  inviterUserId: string;
  inviteeEmail: string;
  inviteeRole: "Administrator" | "Staff" | "Viewer";
}

export class ProvisioningService {
  private readonly tenantRepo: TenantRepository;
  private readonly userRepo: UserRepository;
  private readonly auditRepo: AuditLogRepository;
  private readonly emailService: EmailService;

  constructor(private readonly db: Firestore) {
    this.tenantRepo = new TenantRepository(db);
    this.userRepo = new UserRepository(db);
    this.auditRepo = new AuditLogRepository(db);
    this.emailService = new EmailService(db);
  }

  /**
   * Orchestrates the secure, idempotent, and transactional provisioning of a new multi-tenant workspace.
   */
  async provisionWorkspace(input: ProvisionWorkspaceInput): Promise<{ tenantId: string; tenant: TenantDocument }> {
    const { userId, farmName, primaryContact, country, currency, selectedTier, onboardingPartnerId, agreeTerms, tpin, logoUrl } = input;

    if (agreeTerms !== true) {
      throw new ValidationError("You must accept the Terms of Service to provision a workspace.");
    }

    if (!userId || !farmName || !primaryContact || !country || !currency || !selectedTier) {
      throw new ValidationError("All fields except onboardingPartnerId are required to provision a workspace.");
    }

    const tenantId = userId; // Leverage Owner UID as Tenant ID to guarantee idempotency and simple indexing

    const province = input.province || input.location?.province || "Lusaka";
    const district = input.district || input.location?.district || "Lusaka";

    // Server-side district vs province boundary integrity check
    if (input.province && input.district && zambiaDistrictsMap[input.province]) {
      const allowedDistricts = zambiaDistrictsMap[input.province] || [];
      const isValid = allowedDistricts.some(d => d.toLowerCase() === input.district?.trim().toLowerCase());
      if (!isValid) {
        throw new ValidationError(`District "${input.district}" is not a valid gazetted district in ${input.province} Province.`);
      }
    }

    // Execute the core atomic Firestore transactional pipeline
    const result = await this.db.runTransaction(async (transaction) => {
      // 1. Idempotency Check: Verify if a tenant with this ID already exists
      const existingTenant = await this.tenantRepo.getTenantInTransaction(transaction, tenantId);
      if (existingTenant) {
        console.log(`[ProvisioningService] Tenant workspace already exists for tenantId: ${tenantId}. Returning existing.`);
        return { tenantId, tenant: existingTenant };
      }

      // 2. Validate selected subscription tier
      const validTiers = ["Basic Operations", "Standard Crop Operations", "Capital Finance Hub", "Statutory & Reports Pro", "Advanced Livestock & Poultry Pro"];
      const matchedTier = validTiers.find(t => selectedTier.includes(t)) || "Basic Operations";

      // 3. Define active operational modules (CRITICAL: Livestock, Poultry, and Vet modules are permanently removed!)
      const defaultActiveModules = ["crops", "inputs", "finance", "equipment", "employees"];

      // 4. Set up default isolated Farm record
      const defaultFarm = {
        id: "farm-1",
        name: farmName,
        tpin: tpin || "1002345678",
        address: `${district}, ${province}, ${country}`,
        province,
        district,
        town: district,
        location: {
          province,
          district,
          lat: input.location?.lat,
          lng: input.location?.lng
        },
        phone: primaryContact,
        email: `${userId.slice(0, 8)}@mabala.cloud`,
        financialYearStart: `${new Date().getFullYear()}-01-01`,
        financialYearEnd: `${new Date().getFullYear()}-12-31`,
        currency,
        currencySymbol: currency === "ZMW" ? "K" : "$",
        taxSystem: country === "Zambia" ? "ZRA-Standard" : "VAT-Standard"
      };

      // 5. Establish standard Chart of Accounts (COA) for standard bookkeeping isolation
      const defaultAccounts = [
        { code: "1000", name: "Cash on Hand", type: "Asset", balance: 0 },
        { code: "1100", name: "Bank Account", type: "Asset", balance: 0 },
        { code: "1200", name: "Accounts Receivable", type: "Asset", balance: 0 },
        { code: "1300", name: "Inventory Asset", type: "Asset", balance: 0 },
        { code: "2000", name: "Accounts Payable", type: "Liability", balance: 0 },
        { code: "2100", name: "Short-Term Loans", type: "Liability", balance: 0 },
        { code: "3000", name: "Owner Equity", type: "Equity", balance: 0 },
        { code: "4000", name: "Crop Sales Revenue", type: "Revenue", balance: 0 },
        { code: "5000", name: "Fertilizer & Seed Cost", type: "Expense", balance: 0 },
        { code: "5100", name: "Employee Payroll Expense", type: "Expense", balance: 0 }
      ];

      // 6. Write Tenant Document (Set initial SMS credit balance to 100 to align with Wallet Engine)
      const tenantData: Omit<TenantDocument, "id" | "createdAt" | "updatedAt"> = {
        name: farmName,
        primaryContact,
        country,
        currency,
        province,
        district,
        location: {
          province,
          district,
          lat: input.location?.lat,
          lng: input.location?.lng
        },
        subscriptionTier: matchedTier,
        smsCreditBalance: 100, // Denormalized cache of Wallet summary total
        activeModules: defaultActiveModules,
        status: "Active",
        onboardingPartnerId: onboardingPartnerId || ""
      };
      this.tenantRepo.createTenantInTransaction(transaction, tenantId, tenantData);

      // 7. Write/Update User Profile (ensure exact workspace reference alignment)
      const userProfile: Omit<UserProfile, "uid" | "updatedAt"> = {
        email: `${userId.slice(0, 8)}@mabala.cloud`,
        role: "Owner",
        tenantId,
        credits: 300, // Developer bundle
        subscriptionTier: matchedTier,
        workspaceMode: "Farmer",
        farms: [defaultFarm],
        accounts: defaultAccounts,
        suppliers: [],
        customers: [],
        expenses: [],
        invoices: [],
        quotations: [],
        crops: [],
        employees: [],
        payslips: [],
        fish: [],
        inventory: [],
        loans: [],
        investments: [],
        cashSales: [],
        assets: [],
        otherRevenues: [],
        leaveRecords: [],
        employeeAdvances: [],
        auditLogs: [],
        archivedRecords: []
      };
      this.userRepo.createUserInTransaction(transaction, userId, userProfile);

      // 8. Write Billing Account Configuration
      const now = new Date();
      const nextMonth = new Date();
      nextMonth.setDate(now.getDate() + 30);

      const billingData = {
        tier: matchedTier,
        cost: matchedTier.includes("Pro") ? 5.0 : 1.0,
        smsRateZmw: 0.25,
        smsRateZmwEffectiveDate: now.toISOString(),
        billingPeriod: "Monthly" as const,
        status: "Active" as const,
        startDate: now.toISOString(),
        nextRenewalDate: nextMonth.toISOString()
      };
      this.tenantRepo.createBillingAccountInTransaction(transaction, tenantId, billingData);

      // 9. Initialize Tenant SaaS Wallet & Credit with 100 Free Promotional Credits (Deduplicated Welcome Bonus)
      const creditsService = new CreditsService(this.db);
      await creditsService.createWalletInTransaction(transaction, tenantId);
      await creditsService.allocateCreditsInTransaction(
        transaction,
        tenantId,
        100,
        "reward",
        "Onboarding Welcome Sign-up Bonus",
        "system"
      );

      // 10. Initialize the Farm Letterhead Profile Document (tenants/{tenantId}/farmProfile/primary)
      const farmProfileRef = this.db.collection("tenants").doc(tenantId).collection("farmProfile").doc("primary");
      const farmProfileData = {
        logo: logoUrl || "",
        farmName: farmName,
        farmRegistrationNumber: "",
        tpin: tpin || "1002345678",
        vatRegistrationNumber: "",
        address: `Primary Node, ${country}`,
        province: "",
        district: "",
        country: country,
        postalAddress: "",
        gpsCoordinates: "",
        email: `${userId.slice(0, 8)}@mabala.cloud`,
        phone: primaryContact,
        alternativePhone: "",
        website: "",
        farmSize: 0,
        primaryEnterprise: "Crops",
        ownerName: "Farm Owner",
        defaultCurrency: currency,
        timeZone: "Africa/Lusaka",
        businessRegistrationNumber: "",
        socialFacebook: "",
        socialInstagram: "",
        socialLinkedIn: "",
        socialX: "",
        farmDescription: "",
        digitalSignature: "",
        companyStamp: "",
        createdAt: now.toISOString(),
        updatedAt: now.toISOString()
      };
      transaction.set(farmProfileRef, farmProfileData);

      // 11. Record pristine audit trail
      this.auditRepo.createAuditLogInTransaction(transaction, {
        institutionId: tenantId,
        actorUid: userId,
        actorType: "institution_admin",
        action: "workspace_provisioning",
        details: `Successfully provisioned isolated agricultural workspace "${farmName}" for Tenant ID ${tenantId}`,
        actor_user_id: userId,
        actor_type: "institution_admin",
        target_farmer_id: "",
        metadata: JSON.stringify({ farmName, country, matchedTier, defaultActiveModules })
      });

      const fullTenantDoc: TenantDocument = {
        id: tenantId,
        ...tenantData,
        createdAt: now.toISOString(),
        updatedAt: now.toISOString()
      };

      return { tenantId, tenant: fullTenantDoc };
    });

    // 12. Trigger non-blocking, post-commit side effect (Welcome Email and setup link generation)
    // Runs asynchronously so that any mail latency never impacts client-response speed.
    const emailToUse = input.email || `${userId.slice(0, 8)}@mabala.cloud`;
    if (input.email && input.password) {
      sendWelcomeEmailOnSignup({
        uid: userId,
        email: input.email,
        firstName: input.firstName || farmName.split(" ")[0] || "Farmer",
        password: input.password,
        farmName: farmName
      }).catch((err) => {
        console.error("[ProvisioningService] sendWelcomeEmailOnSignup background job failed:", err.message);
      });
    } else {
      this.emailService.sendWelcomeEmail(
        emailToUse,
        "Farm Owner",
        farmName,
        result.tenantId,
        "FREE",
        100
      ).catch((err) => {
        console.error("[ProvisioningService] Welcome Email background job failed:", err.message);
      });
    }

    return result;
  }

  /**
   * Invites a new user to join an existing tenant workspace.
   */
  async inviteUser(input: InviteUserInput): Promise<{ success: boolean; inviteId: string }> {
    const { tenantId, inviterUserId, inviteeEmail, inviteeRole } = input;

    if (!tenantId || !inviterUserId || !inviteeEmail || !inviteeRole) {
      throw new ValidationError("All fields are required to invite a user.");
    }

    const emailLower = inviteeEmail.trim().toLowerCase();

    return await this.db.runTransaction(async (transaction) => {
      // 1. Verify inviter is the Owner or Admin of the workspace
      const inviterProfile = await this.userRepo.getUserInTransaction(transaction, inviterUserId);
      if (!inviterProfile) {
        throw new ValidationError("Inviter profile not found.");
      }

      if (inviterProfile.tenantId !== tenantId) {
        throw new ValidationError("Inviter is not associated with the requested tenant workspace.");
      }

      const isAuthorized = inviterProfile.role === "Owner" || inviterProfile.role === "Administrator";
      if (!isAuthorized) {
        throw new ValidationError("Only Owners and Administrators can invite new users to this workspace.");
      }

      // 2. Write the pending invitation to a subcollection
      const inviteId = "inv_" + Date.now() + "_" + Math.floor(Math.random() * 1000);
      const inviteRef = this.db
        .collection("platform")
        .doc("institutions")
        .collection("institutions")
        .doc(tenantId)
        .collection("invitations")
        .doc(inviteId);

      transaction.set(inviteRef, {
        email: emailLower,
        role: inviteeRole,
        status: "Pending",
        invitedBy: inviterUserId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });

      // 3. Record audit trail
      this.auditRepo.createAuditLogInTransaction(transaction, {
        institutionId: tenantId,
        actorUid: inviterUserId,
        actorType: inviterProfile.role || "institution_staff",
        action: "user_invite",
        details: `Invited user ${emailLower} as ${inviteeRole}`,
        actor_user_id: inviterUserId,
        actor_type: inviterProfile.role || "institution_staff",
        target_farmer_id: "",
        metadata: JSON.stringify({ inviteeEmail: emailLower, inviteeRole, inviteId })
      });

      return { success: true, inviteId };
    });
  }
}

export interface RemoteAccessClaims {
  accessNodeTenantId?: string;
  actingAs?: string;
  accessNodeExpiresAt?: string;
  accessNodeSessionId?: string;
  [key: string]: unknown;
}

export interface RemoteAccessSession {
  sessionId: string;
  superAdminId: string;
  targetTenantId: string;
  expiresAt: string;
  status: "active" | "ended";
}

export function isSuperAdminClaims(claims: Record<string, any>, email = ""): boolean {
  const normalizedEmail = email.trim().toLowerCase();
  return claims.role === "super_admin" ||
    claims.superAdmin === true ||
    ["support@mabala.cloud", "shikasuli@gmail.com", "owner@mabala.com", "mary@mabala.com"].includes(normalizedEmail);
}

export function addRemoteAccessClaims(
  existingClaims: RemoteAccessClaims,
  context: { tenantId: string; sessionId: string; expiresAt: string }
): RemoteAccessClaims {
  return {
    ...existingClaims,
    accessNodeTenantId: context.tenantId,
    actingAs: "super_admin_access_node",
    accessNodeExpiresAt: context.expiresAt,
    accessNodeSessionId: context.sessionId
  };
}

export function removeRemoteAccessClaims(existingClaims: RemoteAccessClaims): RemoteAccessClaims {
  const claims = { ...existingClaims };
  delete claims.accessNodeTenantId;
  delete claims.actingAs;
  delete claims.accessNodeExpiresAt;
  delete claims.accessNodeSessionId;
  return claims;
}

export function isRemoteAccessSessionActive(session: RemoteAccessSession, now = new Date()): boolean {
  return session.status === "active" && new Date(session.expiresAt).getTime() > now.getTime();
}

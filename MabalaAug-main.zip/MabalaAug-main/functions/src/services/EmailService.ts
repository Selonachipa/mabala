import { Firestore } from "firebase-admin/firestore";

export interface EmailConfig {
  smtpHost: string;
  smtpPort: number;
  secure: boolean;
  senderName: string;
  senderAddress: string;
  retryCount: number;
  loggingTrigger: boolean;
}

export interface EmailTemplate {
  id: string;
  templateName: string;
  category: string;
  subject: string;
  htmlContent: string;
  textContent: string;
  active: boolean;
  version: number;
}

export class EmailService {
  private readonly configCollection = "system_settings";
  private readonly templatesCollection = "emailTemplates";
  private readonly auditLogCollection = "emailAuditLog";

  constructor(private readonly db: Firestore) {}

  /**
   * Retrieves the current active email configuration, or defaults to standard local fallback.
   */
  async getEmailConfig(): Promise<EmailConfig> {
    try {
      const doc = await this.db.collection(this.configCollection).doc("email_config").get();
      if (doc.exists) {
        return doc.data() as EmailConfig;
      }
    } catch (e) {
      console.warn("[EmailService] Failed to load email config, falling back to default.", e);
    }

    return {
      smtpHost: "smtp.mabala.cloud",
      smtpPort: 587,
      secure: false,
      senderName: "Mabala Cloud Operations",
      senderAddress: "onboarding@mabala.cloud",
      retryCount: 3,
      loggingTrigger: true
    };
  }

  /**
   * Ensures the Welcome Email template is pre-seeded in the database.
   */
  async seedWelcomeTemplateIfMissing(): Promise<void> {
    const templateRef = this.db.collection(this.templatesCollection).doc("welcome_email");
    const doc = await templateRef.get();

    if (!doc.exists) {
      const defaultTemplate: EmailTemplate = {
        id: "welcome_email",
        templateName: "Welcome Email",
        category: "onboarding",
        subject: "Welcome to Mabala.cloud — Let's Grow Together, {{OwnerName}}!",
        htmlContent: `
          <div style="font-family: 'Inter', sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e1e1e1; border-radius: 8px;">
            <div style="text-align: center; margin-bottom: 24px;">
              <h1 style="color: #111827; font-size: 24px; font-weight: 600; margin: 0;">Mabala.cloud</h1>
              <p style="color: #6b7280; font-size: 14px; margin-top: 4px;">Agronomic Enterprise Platform</p>
            </div>
            <div style="margin-bottom: 24px;">
              <p style="font-size: 16px; color: #374151; line-height: 1.5;">Hello <strong>{{OwnerName}}</strong>,</p>
              <p style="font-size: 16px; color: #374151; line-height: 1.5;">
                Welcome to Mabala.cloud! Your isolated agricultural workspace <strong>{{FarmName}}</strong> has been successfully provisioned. You are ready to start managing your operations in under two minutes!
              </p>
            </div>
            <div style="background-color: #f9fafb; border-radius: 6px; padding: 16px; margin-bottom: 24px;">
              <h2 style="font-size: 16px; font-weight: 500; color: #111827; margin-top: 0; margin-bottom: 12px;">Workspace Credentials & Details:</h2>
              <table style="width: 100%; border-collapse: collapse; font-size: 14px; color: #4b5563;">
                <tr>
                  <td style="padding: 6px 0; font-weight: 500;">Farm ID:</td>
                  <td style="padding: 6px 0; text-align: right; font-family: monospace;">{{FarmID}}</td>
                </tr>
                <tr>
                  <td style="padding: 6px 0; font-weight: 500;">Plan:</td>
                  <td style="padding: 6px 0; text-align: right; color: #059669; font-weight: 600;">{{PlanName}}</td>
                </tr>
                <tr>
                  <td style="padding: 6px 0; font-weight: 500;">Onboarding SMS Credits:</td>
                  <td style="padding: 6px 0; text-align: right; font-weight: 600;">{{WalletCredits}} Free Credits</td>
                </tr>
                <tr>
                  <td style="padding: 6px 0; font-weight: 500;">Login Email:</td>
                  <td style="padding: 6px 0; text-align: right;">{{Email}}</td>
                </tr>
              </table>
            </div>
            <div style="text-align: center; margin-bottom: 24px;">
              <a href="{{LoginURL}}" style="background-color: #111827; color: #ffffff; text-decoration: none; padding: 12px 24px; font-size: 15px; font-weight: 500; border-radius: 6px; display: inline-block;">
                Access Dashboard & Set Your Password
              </a>
            </div>
            <p style="font-size: 13px; color: #6b7280; line-height: 1.5; text-align: center;">
              If the button above does not work, copy and paste the following link into your browser:<br>
              <span style="word-break: break-all; color: #3b82f6;">{{LoginURL}}</span>
            </p>
            <hr style="border: 0; border-top: 1px solid #e5e7eb; margin: 24px 0;">
            <p style="font-size: 12px; color: #9ca3af; text-align: center; margin: 0;">
              This is an automated operational welcome message from Mabala.cloud.
            </p>
          </div>
        `,
        textContent: "Hello {{OwnerName}},\n\nWelcome to Mabala.cloud! Your isolated agricultural workspace {{FarmName}} (ID: {{FarmID}}) has been successfully provisioned on the {{PlanName}} tier.\n\nYour onboarding wallet is credited with {{WalletCredits}} Free SMS Credits.\n\nPlease set your password and access your dashboard by visiting this link: {{LoginURL}}\n\nSincerely,\nMabala Cloud Team",
        active: true,
        version: 1
      };

      await templateRef.set(defaultTemplate);
    }
  }

  /**
   * Post-commit non-blocking Welcome Email sender.
   * Generates Set-Password Link, substitutes template tags, sends (mocks/logs) and logs to emailAuditLog.
   */
  async sendWelcomeEmail(
    email: string,
    ownerName: string,
    farmName: string,
    farmId: string,
    planName: string,
    walletCredits: number
  ): Promise<void> {
    const auditId = "aud_em_" + Date.now() + "_" + Math.floor(Math.random() * 1000);
    const auditRef = this.db.collection(this.auditLogCollection).doc(auditId);

    try {
      // 1. Generate secure Firebase password setup link
      let setupLink = "";
      try {
        const { auth: adminAuth } = await import("../config/firebase");
        setupLink = await adminAuth.generatePasswordResetLink(email, {
          url: "https://mabala.cloud/dashboard"
        });
      } catch (authErr: any) {
        console.warn("[EmailService] Auth reset link generation failed, falling back to mock link:", authErr.message);
        setupLink = `https://mabala.cloud/set-password?email=${encodeURIComponent(email)}&tenantId=${farmId}`;
      }

      // 2. Load template
      await this.seedWelcomeTemplateIfMissing();
      const templateDoc = await this.db.collection(this.templatesCollection).doc("welcome_email").get();
      const template = templateDoc.data() as EmailTemplate;

      // 3. Apply substitutions
      const replacements: Record<string, string> = {
        "{{OwnerName}}": ownerName,
        "{{FarmName}}": farmName,
        "{{FarmID}}": farmId,
        "{{PlanName}}": planName,
        "{{WalletCredits}}": String(walletCredits),
        "{{Email}}": email,
        "{{LoginURL}}": setupLink
      };

      let html = template.htmlContent;
      let text = template.textContent;
      let subject = template.subject;

      for (const [key, value] of Object.entries(replacements)) {
        html = html.replace(new RegExp(key, "g"), value);
        text = text.replace(new RegExp(key, "g"), value);
        subject = subject.replace(new RegExp(key, "g"), value);
      }

      // 4. Send email (log details clearly for Cloud Run / Functions console capture)
      console.log(`=========================================`);
      console.log(`[EmailService] SEND WELCOME EMAIL SUCCESS`);
      console.log(`TO: ${email}`);
      console.log(`SUBJECT: ${subject}`);
      console.log(`LINK: ${setupLink}`);
      console.log(`=========================================`);

      // 5. Write successful audit log entry
      await auditRef.set({
        recipient: email,
        templateId: "welcome_email",
        sendStatus: "SUCCESS",
        errorMessage: null,
        subject,
        timestamp: new Date().toISOString()
      });

    } catch (err: any) {
      console.error("[EmailService] Failed to send welcome email:", err.message);

      // Write failed audit log entry
      try {
        await auditRef.set({
          recipient: email,
          templateId: "welcome_email",
          sendStatus: "FAILED",
          errorMessage: err.message || "Unknown error",
          timestamp: new Date().toISOString()
        });
      } catch (logErr) {
        console.error("[EmailService] Failed to log email audit:", logErr);
      }
    }
  }
}

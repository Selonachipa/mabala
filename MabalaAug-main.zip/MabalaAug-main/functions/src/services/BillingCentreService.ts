import { Firestore } from "firebase-admin/firestore";
import { CreditsService } from "./CreditsService";
import { BillingError } from "../utils/errors";

export interface FarmProfileData {
  logo?: string;
  farmName: string;
  farmRegistrationNumber?: string;
  tpin?: string;
  vatRegistrationNumber?: string;
  address?: string;
  province?: string;
  district?: string;
  country: string;
  postalAddress?: string;
  gpsCoordinates?: string;
  email?: string;
  phone?: string;
  alternativePhone?: string;
  website?: string;
  farmSize?: number;
  primaryEnterprise?: string;
  ownerName?: string;
  defaultCurrency?: string;
  timeZone?: string;
  businessRegistrationNumber?: string;
  socialFacebook?: string;
  socialInstagram?: string;
  socialLinkedIn?: string;
  socialX?: string;
  farmDescription?: string;
  digitalSignature?: string;
  companyStamp?: string;
}

export class BillingCentreService {
  private readonly creditsService: CreditsService;

  constructor(private readonly db: Firestore) {
    this.creditsService = new CreditsService(db);
  }

  /**
   * Retrieves the current farm profile letterhead.
   */
  async getFarmProfile(tenantId: string): Promise<FarmProfileData | null> {
    const doc = await this.db.collection("tenants").doc(tenantId).collection("farmProfile").doc("primary").get();
    if (!doc.exists) {
      return null;
    }
    return doc.data() as FarmProfileData;
  }

  /**
   * Updates the farm profile document.
   */
  async updateFarmProfile(tenantId: string, profileData: Partial<FarmProfileData>): Promise<void> {
    const profileRef = this.db.collection("tenants").doc(tenantId).collection("farmProfile").doc("primary");
    
    await this.db.runTransaction(async (transaction) => {
      const doc = await transaction.get(profileRef);
      const now = new Date().toISOString();
      const initialData = {
        logo: "",
        farmRegistrationNumber: "",
        tpin: "",
        vatRegistrationNumber: "",
        address: "",
        province: "",
        district: "",
        postalAddress: "",
        gpsCoordinates: "",
        alternativePhone: "",
        website: "",
        farmSize: 0,
        primaryEnterprise: "Crops",
        ownerName: "",
        timeZone: "Africa/Lusaka",
        businessRegistrationNumber: "",
        socialFacebook: "",
        socialInstagram: "",
        socialLinkedIn: "",
        socialX: "",
        farmDescription: "",
        digitalSignature: "",
        companyStamp: "",
        createdAt: now,
        ...profileData,
        updatedAt: now
      };

      if (!doc.exists) {
        transaction.set(profileRef, initialData);
      } else {
        transaction.update(profileRef, {
          ...profileData,
          updatedAt: now
        });
      }
    });
  }

  /**
   * Retrieves the wallet summary and recent ledger transactions for the dashboard.
   */
  async getWalletDetails(tenantId: string): Promise<any> {
    const summaryRef = this.db.collection("tenants").doc(tenantId).collection("wallet").doc("summary");
    const summarySnap = await summaryRef.get();

    if (!summarySnap.exists) {
      // Lazy auto-creation of wallet summary if it somehow doesn't exist
      await this.db.runTransaction(async (transaction) => {
        await this.creditsService.createWalletInTransaction(transaction, tenantId);
      });
      const freshSnap = await summaryRef.get();
      return {
        summary: freshSnap.data(),
        ledger: []
      };
    }

    const ledgerColl = summaryRef.collection("ledger").orderBy("timestamp", "desc").limit(50);
    const ledgerSnap = await ledgerColl.get();
    const ledger: any[] = [];
    ledgerSnap.forEach((doc) => {
      ledger.push({ id: doc.id, ...doc.data() });
    });

    return {
      summary: summarySnap.data(),
      ledger
    };
  }

  /**
   * Processes a self-serve credit top-up purchase via Lipila simulation.
   */
  async purchaseCredits(tenantId: string, amount: number, amountPaidZmw: number, actorUid: string): Promise<any> {
    if (amount <= 0) {
      throw new BillingError("Purchase amount must be positive.");
    }

    const paymentId = "pay_lp_" + Date.now() + "_" + Math.floor(Math.random() * 1000);
    const paymentRef = this.db.collection("payments").doc(paymentId);

    // Save payment record representing Lipila gateway invoice
    await paymentRef.set({
      id: paymentId,
      tenantId,
      amount: amountPaidZmw,
      currency: "ZMW",
      creditsToAward: amount,
      status: "Successful", // Auto-approved for simulation/seamless frictionless flow
      packageType: "sms_topup",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    // Award credits to the SaaS Wallet
    await this.db.runTransaction(async (transaction) => {
      await this.creditsService.allocateCreditsInTransaction(
        transaction,
        tenantId,
        amount,
        "purchase",
        `Purchased ${amount} SMS Credits via Lipila (Ref: ${paymentId})`,
        actorUid,
        paymentId,
        paymentId
      );

      // Reconcile and update the legacy tenant credit balance so legacy features don't break
      const tenantRef = this.db.collection("platform").doc("institutions").collection("institutions").doc(tenantId);
      const tenantSnap = await transaction.get(tenantRef);
      if (tenantSnap.exists) {
        const tenant = tenantSnap.data()!;
        const currentBalance = Number(tenant.smsCreditBalance || 0);
        transaction.update(tenantRef, {
          smsCreditBalance: currentBalance + amount,
          updatedAt: new Date().toISOString()
        });
      }
    });

    return { success: true, paymentId, amountAwarded: amount };
  }

  /**
   * Activates the 24-hour Unlimited Daily Bundle for flat rate bypass.
   */
  async activateDailyBundle(tenantId: string, costZmw: number, actorUid: string): Promise<any> {
    // Save daily bundle activation record
    const paymentId = "pay_bun_" + Date.now() + "_" + Math.floor(Math.random() * 1000);
    const paymentRef = this.db.collection("payments").doc(paymentId);

    await paymentRef.set({
      id: paymentId,
      tenantId,
      amount: costZmw,
      currency: "ZMW",
      status: "Successful",
      packageType: "daily_bundle",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    await this.db.runTransaction(async (transaction) => {
      await this.creditsService.activateDailyBundleInTransaction(transaction, tenantId, actorUid);

      // Also record payment in legacy structures if needed
      const auditLogRef = this.db.collection("super_admin_audit").doc();
      transaction.set(auditLogRef, {
        timestamp: new Date().toISOString(),
        actorUid,
        action: "DAILY_BUNDLE_ACTIVATION",
        details: `Activated Daily Bundle for tenant ${tenantId}. Cost: ${costZmw} ZMW.`,
        tenantId
      });
    });

    return { success: true, paymentId };
  }
}

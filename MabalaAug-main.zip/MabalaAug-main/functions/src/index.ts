import { onCall, onRequest, HttpsError } from "firebase-functions/v2/https";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { db, auth } from "./config/firebase";
import { FieldValue } from "firebase-admin/firestore";
import { ProvisioningService } from "./services/ProvisioningService";
import { BillingService } from "./services/BillingService";
import { BillingCentreService } from "./services/BillingCentreService";
import { sendWelcomeEmailOnSignup } from "./welcomeEmail.functions";
import { verifyTenantPermission, enforceWritePermission, resolveAuthorizedTenant } from "./utils/Validation";
import { verifyAuthContext, verifyEmailVerified } from "./middleware/auth";
import { validatePayloadFields, validateIdFormat } from "./middleware/validation";
import { AppError } from "./utils/errors";
import { addRemoteAccessClaims, isSuperAdminClaims, removeRemoteAccessClaims } from "./services/remoteAccessPolicy";

const provisioningService = new ProvisioningService(db);
const billingService = new BillingService(db);
const billingCentreService = new BillingCentreService(db);

/**
 * Callable: provisionWorkspace
 */
export const provisionWorkspace = onCall(async (request) => {
  // 1. Enforce strict authorization context
  const authContext = verifyAuthContext(request);
  const userId = authContext.auth.uid;

  const payload = request.data;
  
  // 2. Enforce payload schema validation
  validatePayloadFields(payload, ["farmName", "primaryContact", "country", "currency", "selectedTier"]);
  validateIdFormat(userId, "userId");

  if (payload.agreeTerms !== true) {
    throw new HttpsError("invalid-argument", "You must accept the Terms of Service to provision a workspace.");
  }

  try {
    const result = await provisioningService.provisionWorkspace({
      userId,
      farmName: String(payload.farmName),
      primaryContact: String(payload.primaryContact),
      country: String(payload.country),
      currency: String(payload.currency),
      selectedTier: String(payload.selectedTier),
      onboardingPartnerId: payload.onboardingPartnerId ? String(payload.onboardingPartnerId) : undefined,
      agreeTerms: Boolean(payload.agreeTerms),
      tpin: payload.tpin ? String(payload.tpin) : undefined,
      logoUrl: payload.logoUrl ? String(payload.logoUrl) : undefined
    });
    
    return {
      success: true,
      ...result
    };
  } catch (error: any) {
    console.error("[provisionWorkspace] Error running provisioning:", error.message);
    if (error instanceof AppError) {
      throw new HttpsError("aborted", error.message, error.toJSON());
    }
    throw new HttpsError("internal", error.message || "Internal provisioning error");
  }
});

/**
 * Callable: inviteUser
 */
export const inviteUser = onCall(async (request) => {
  // 1. Enforce strict authorization context and verified emails
  const authContext = verifyEmailVerified(request);
  const inviterUserId = authContext.auth.uid;

  const payload = request.data;
  
  // 2. Validate payload fields
  validatePayloadFields(payload, ["tenantId", "inviteeEmail", "inviteeRole"]);
  validateIdFormat(String(payload.tenantId), "tenantId");

  try {
    const result = await provisioningService.inviteUser({
      tenantId: String(payload.tenantId),
      inviterUserId,
      inviteeEmail: String(payload.inviteeEmail),
      inviteeRole: payload.inviteeRole
    });

    return result;
  } catch (error: any) {
    console.error("[inviteUser] Error inviting user:", error.message);
    if (error instanceof AppError) {
      throw new HttpsError("aborted", error.message, error.toJSON());
    }
    throw new HttpsError("internal", error.message || "Internal user invitation error");
  }
});

/**
 * Callable: allocateCredits
 */
export const allocateCredits = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const actorUid = authContext.auth.uid;
  const payload = request.data || {};
  const claims = authContext.auth.token || {};
  const actorEmail = String(claims.email || "").toLowerCase();
  if (!isSuperAdminClaims(claims, actorEmail)) {
    throw new HttpsError("permission-denied", "Only Super Admins may allocate credits.");
  }

  const creditType = payload.creditType === "sms" ? "sms" : payload.creditType === "platform" ? "platform" : "";
  if (!creditType) throw new HttpsError("invalid-argument", "creditType must be platform or sms.");
  const amount = Number(payload.amount);
  if (!Number.isFinite(amount) || amount < 0 || amount > 100000000) {
    throw new HttpsError("invalid-argument", "amount must be a finite non-negative value within the supported range.");
  }
  const requestedTenantId = payload.tenantId ? String(payload.tenantId).trim() : "";
  const targetEmail = String(payload.targetEmail || "").trim().toLowerCase();
  const idempotencyKey = String(payload.idempotencyKey || `${actorUid}:${requestedTenantId || targetEmail}:${creditType}:${amount}:${String(payload.reason || "")}`).slice(0, 180);
  const reason = String(payload.reason || "Super Admin credit allocation").trim();

  try {
    const result = await db.runTransaction(async (transaction) => {
      let tenantId = requestedTenantId;
      if (!tenantId && targetEmail) {
        const userQuery = await db.collection("users_data").where("email", "==", targetEmail).limit(1).get();
        if (!userQuery.empty) tenantId = String(userQuery.docs[0].data()?.tenantId || userQuery.docs[0].id);
      }
      if (!tenantId) throw new HttpsError("invalid-argument", "tenantId or targetEmail is required.");
      validateIdFormat(tenantId, "tenantId");

      const idempotencyRef = db.collection("tenants").doc(tenantId).collection("creditLedger").doc(`allocation-${idempotencyKey}`);
      const existing = await transaction.get(idempotencyRef);
      if (existing.exists) return { ...(existing.data() || {}), duplicate: true, tenantId };

      const tenantRef = db.collection("platform").doc("institutions").collection("institutions").doc(tenantId);
      const tenantFallbackRef = db.collection("tenants").doc(tenantId);
      const walletRef = db.collection("tenants").doc(tenantId).collection("wallet").doc("credits");
      const smsWalletRef = db.collection("tenants").doc(tenantId).collection("wallet").doc("sms");
      const userRef = db.collection("users_data").doc(tenantId);
      const auditRef = db.collection("super_admin_audit").doc(`allocation-${idempotencyKey}`);
      const [tenantSnap, fallbackSnap, walletSnap, smsWalletSnap, userSnap] = await Promise.all([
        transaction.get(tenantRef), transaction.get(tenantFallbackRef), transaction.get(walletRef), transaction.get(smsWalletRef), transaction.get(userRef)
      ]);
      const tenantData = tenantSnap.exists ? (tenantSnap.data() || {}) : (fallbackSnap.data() || {});
      const status = String(tenantData.status || userSnap.data()?.status || "Active").toLowerCase();
      if (!tenantSnap.exists && !fallbackSnap.exists && !userSnap.exists) throw new HttpsError("not-found", "Farm node not found.");
      if (["active", "enabled"].includes(status) === false) throw new HttpsError("failed-precondition", "Credits can only be allocated to an active farm node.");

      const now = new Date().toISOString();
      const currentPlatform = Number(walletSnap.data()?.currentBalance ?? userSnap.data()?.credits ?? 0);
      const currentSms = Number(smsWalletSnap.data()?.currentBalance ?? tenantData.smsCreditBalance ?? userSnap.data()?.smsCredits ?? 0);
      const previousBalance = creditType === "platform" ? currentPlatform : currentSms;
      const adjustmentType = String(payload.adjustmentType || "allocate");
      const newBalance = adjustmentType === "deduct"
        ? previousBalance - amount
        : adjustmentType === "set"
          ? amount
          : previousBalance + amount;
      if (newBalance < 0) throw new HttpsError("failed-precondition", "Credit balance cannot become negative.");
      const ledgerRecord = {
        id: idempotencyRef.id, tenantId, type: adjustmentType === "deduct" ? "deduction" : "credit_grant", creditType, amount,
        previousBalance, balanceAfter: newBalance, reason, performedBy: actorUid,
        timestamp: now, idempotencyKey
      };
      transaction.set(idempotencyRef, ledgerRecord);
      if (creditType === "platform") {
        transaction.set(walletRef, { currentBalance: newBalance, lifetimeIssued: Number(walletSnap.data()?.lifetimeIssued || 0) + amount, planAllotment: newBalance, updatedAt: now }, { merge: true });
        transaction.set(userRef, { credits: newBalance, updatedAt: now }, { merge: true });
      } else {
        transaction.set(smsWalletRef, { currentBalance: newBalance, balance: newBalance, smsCredits: newBalance, updatedAt: now }, { merge: true });
        transaction.set(tenantRef, { smsCreditBalance: newBalance, updatedAt: now }, { merge: true });
        transaction.set(userRef, { smsCredits: newBalance, updatedAt: now }, { merge: true });
      }
      if (payload.subscriptionPackage && payload.subscriptionPackage !== "UNCHANGED") {
        const expiry = new Date(Date.now() + Math.max(1, Number(payload.subscriptionDurationDays) || 30) * 24 * 60 * 60 * 1000).toISOString();
        transaction.set(userRef, {
          subscriptionPackage: String(payload.subscriptionPackage),
          subscriptionTier: String(payload.subscriptionPackage),
          subscriptionStatus: String(payload.subscriptionStatus || "ACTIVE"),
          subscriptionExpiresAt: expiry,
          planExpiryDate: expiry,
          isPassActive: payload.subscriptionPackage === "Daily Bundle",
          updatedAt: now
        }, { merge: true });
      }
      transaction.set(auditRef, {
        id: auditRef.id, actionType: "credit_allocation", superAdminId: actorUid, superAdminEmail: actorEmail,
        targetTenantId: tenantId, creditType, amount, previousBalance, newBalance, reason, idempotencyKey, timestamp: now
      });
      return { success: true, tenantId, creditType, previousBalance, newBalance, platformBalance: creditType === "platform" ? newBalance : currentPlatform, smsBalance: creditType === "sms" ? newBalance : currentSms, duplicate: false };
    });
    return { ...result, message: result.duplicate ? "Duplicate allocation ignored." : `Allocated ${amount} ${creditType} credits.` };
  } catch (error: any) {
    console.error("[allocateCredits] Error allocating credits:", error.message);
    if (error instanceof AppError) {
      throw new HttpsError("aborted", error.message, error.toJSON());
    }
    throw new HttpsError("internal", error.message || "Internal credit allocation error");
  }
});

/**
 * Callable: deductCredits
 */
export const deductCredits = onCall(async (request) => {
  // 1. Enforce strict authorization context
  const authContext = verifyAuthContext(request);
  const actorUid = authContext.auth.uid;

  const payload = request.data;
  
  // 2. Validate payload fields
  validatePayloadFields(payload, ["tenantId", "amount", "reason"]);
  validateIdFormat(String(payload.tenantId), "tenantId");

  const amount = Number(payload.amount);
  if (isNaN(amount) || amount <= 0) {
    throw new HttpsError("invalid-argument", "Amount must be a positive number.");
  }

  try {
    await db.runTransaction(async (transaction) => {
      await billingService.deductCreditsInTransaction(
        transaction,
        String(payload.tenantId),
        amount,
        String(payload.reason),
        String(payload.category || "platform"),
        actorUid
      );
    });

    return { success: true, message: `Successfully deducted ${amount} SMS credits.` };
  } catch (error: any) {
    console.error("[deductCredits] Error deducting credits:", error.message);
    if (error instanceof AppError) {
      throw new HttpsError("aborted", error.message, error.toJSON());
    }
    throw new HttpsError("internal", error.message || "Internal credit deduction error");
  }
});

/**
 * Callable: renewSubscription
 */
export const renewSubscription = onCall(async (request) => {
  // 1. Enforce strict authorization context
  const authContext = verifyAuthContext(request);
  const actorUid = authContext.auth.uid;

  const payload = request.data;
  
  // 2. Validate payload fields
  validatePayloadFields(payload, ["tenantId", "newExpiryDate"]);
  validateIdFormat(String(payload.tenantId), "tenantId");

  try {
    await db.runTransaction(async (transaction) => {
      await billingService.renewSubscriptionInTransaction(
        transaction,
        String(payload.tenantId),
        String(payload.newExpiryDate),
        actorUid
      );
    });

    return { success: true, message: `Successfully renewed subscription to ${payload.newExpiryDate}.` };
  } catch (error: any) {
    console.error("[renewSubscription] Error renewing subscription:", error.message);
    if (error instanceof AppError) {
      throw new HttpsError("aborted", error.message, error.toJSON());
    }
    throw new HttpsError("internal", error.message || "Internal subscription renewal error");
  }
});

/**
 * HTTPS-triggered: processPaymentWebhook
 * Standard Webhook pattern handling JSON callback payloads
 */
export const processPaymentWebhook = onRequest(async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).send("Method Not Allowed");
    return;
  }

  const payload = req.body;
  if (!payload || !payload.referenceId || !payload.status) {
    res.status(400).send("Bad Request: Missing referenceId or status.");
    return;
  }

  try {
    await billingService.processPaymentWebhook(
      String(payload.referenceId),
      String(payload.status),
      payload
    );

    res.status(200).json({ success: true, message: "Webhook successfully processed and reconciled." });
  } catch (error: any) {
    console.error("[processPaymentWebhook] Webhook capture error:", error.message);
    res.status(500).json({ success: false, error: error.message || "Webhook processing failure" });
  }
});

/**
 * Callable: getFarmProfile
 */
export const getFarmProfile = onCall(async (request) => {
  await verifyTenantPermission(request);
  const tenantId = String(request.data.tenantId);

  try {
    const profile = await billingCentreService.getFarmProfile(tenantId);
    return { success: true, profile };
  } catch (error: any) {
    console.error("[getFarmProfile] Error fetching profile:", error.message);
    throw new HttpsError("internal", error.message || "Failed to fetch profile");
  }
});

/**
 * Callable: updateFarmNodeSettings
 * Persists the farm settings and compatibility representations atomically.
 * The tenant is resolved from authenticated membership; a supplied tenantId
 * is only a consistency check for legacy clients and remote Super Admins.
 */
export const updateFarmNodeSettings = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const payload = request.data || {};
  const requestedTenantId = payload.tenantId ? String(payload.tenantId).trim() : undefined;
  const tenantContext = await resolveAuthorizedTenant(request, requestedTenantId);
  const claims = authContext.auth.token || {};
  const callerEmail = String(claims.email || "").toLowerCase();
  const isSuperAdmin = isSuperAdminClaims(claims, callerEmail);
  if (!tenantContext.isOwner && !isSuperAdmin) {
    throw new HttpsError("permission-denied", "Only the farm owner or an authorized Super Admin can modify farm settings.");
  }

  const incoming = payload.settings;
  if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) {
    throw new HttpsError("invalid-argument", "settings must be an object.");
  }

  const allowedFields = [
    "name", "letterheadTitle", "letterheadSubtitle", "letterheadAddress", "tpin", "vatNumber", "address", "province", "district", "town",
    "phone", "financialYearStart", "financialYearEnd", "currency", "currencySymbol", "taxSystem",
    "taxType", "customTaxName", "customTaxRate", "size", "sizeUnit", "farmingType", "registrationNumber",
    "managerName", "logo", "farmDescription", "country", "location", "farmLocation", "latitude", "longitude"
  ];
  const internalFields = ["id", "tenantId", "createdAt", "createdBy", "createdByName", "updatedAt", "updatedBy", "lastModifiedBy", "lastModifiedByName", "isArchived"];
  const unsupportedFields = Object.keys(incoming).filter(key => !allowedFields.includes(key) && key !== "email" && !internalFields.includes(key));
  if (unsupportedFields.length > 0) {
    throw new HttpsError("invalid-argument", `Unsupported farm setting: ${unsupportedFields[0]}`);
  }

  const targetTenantId = tenantContext.tenantId;
  const ownerProfileRef = db.collection("users_data").doc(targetTenantId);
  const farmModuleRef = ownerProfileRef.collection("modules").doc("farms");
  const tenantRef = db.collection("tenants").doc(targetTenantId);
  const farmProfileRef = tenantRef.collection("farmProfile").doc("primary");
  const auditRef = tenantRef.collection("auditLogs").doc();
  const now = new Date().toISOString();

  const result = await db.runTransaction(async (transaction) => {
    const [ownerProfileSnap, farmModuleSnap, tenantSnap, farmProfileSnap] = await Promise.all([
      transaction.get(ownerProfileRef),
      transaction.get(farmModuleRef),
      transaction.get(tenantRef),
      transaction.get(farmProfileRef)
    ]);
    const ownerData = ownerProfileSnap.data() || {};
    const currentFarms = Array.isArray(ownerData.farms)
      ? ownerData.farms
      : (farmModuleSnap.data()?.data && Array.isArray(farmModuleSnap.data()?.data) ? farmModuleSnap.data()?.data : []);
    const farmId = String(payload.farmId || currentFarms[0]?.id || "farm-1");
    const farmIndex = currentFarms.findIndex((farm: any) => String(farm?.id || "") === farmId);
    const currentFarm = farmIndex >= 0 ? currentFarms[farmIndex] : (currentFarms[0] || {});
    const originalEmail = String(currentFarm.email || ownerData.email || ownerData.userProfile?.email || "").trim().toLowerCase();
    if (incoming.email !== undefined && String(incoming.email).trim().toLowerCase() !== originalEmail) {
      throw new HttpsError("failed-precondition", "Farm node email is immutable and cannot be changed.");
    }

    const nextFarm = { ...currentFarm };
    for (const field of allowedFields) {
      if (incoming[field] !== undefined) nextFarm[field] = incoming[field];
    }
    nextFarm.id = currentFarm.id || farmId;
    nextFarm.email = originalEmail;
    nextFarm.updatedAt = now;
    nextFarm.updatedBy = authContext.auth.uid;
    if (nextFarm.customTaxRate !== undefined && (typeof nextFarm.customTaxRate !== "number" || nextFarm.customTaxRate < 0 || nextFarm.customTaxRate > 100)) {
      throw new HttpsError("invalid-argument", "customTaxRate must be a number between 0 and 100.");
    }
    if (nextFarm.financialYearStart && nextFarm.financialYearEnd && new Date(nextFarm.financialYearStart) > new Date(nextFarm.financialYearEnd)) {
      throw new HttpsError("invalid-argument", "Financial year end cannot precede financial year start.");
    }

    const nextFarms = [...currentFarms];
    if (farmIndex >= 0) nextFarms[farmIndex] = nextFarm;
    else nextFarms.push(nextFarm);
    const tenantData = tenantSnap.data() || {};
    const farmProfileData = farmProfileSnap.data() || {};
    const nextProfile = { ...farmProfileData };
    for (const field of allowedFields) {
      if (incoming[field] !== undefined) nextProfile[field] = incoming[field];
    }
    nextProfile.email = originalEmail;
    nextProfile.updatedAt = now;

    transaction.set(ownerProfileRef, { farms: nextFarms, updatedAt: now }, { merge: true });
    transaction.set(farmModuleRef, { data: nextFarms, updatedAt: now }, { merge: true });
    transaction.set(tenantRef, {
      name: nextFarm.name,
      ownerUid: tenantData.ownerUid || targetTenantId,
      phone: nextFarm.phone || "",
      address: nextFarm.address || "",
      province: nextFarm.province || "",
      district: nextFarm.district || "",
      tpin: nextFarm.tpin || "",
      updatedAt: now
    }, { merge: true });
    transaction.set(farmProfileRef, nextProfile, { merge: true });
    transaction.set(auditRef, {
      action: "UPDATE",
      entity: "farm_settings",
      farmNodeId: targetTenantId,
      recordId: nextFarm.id,
      actorUserId: authContext.auth.uid,
      actorRole: claims.role || (isSuperAdmin ? "super_admin" : "owner"),
      timestamp: now,
      previousValue: currentFarm,
      newValue: nextFarm,
      source: "settings_ui"
    });
    return { farm: nextFarm, auditId: auditRef.id };
  });

  return { success: true, tenantId: targetTenantId, settings: result.farm, auditId: result.auditId };
});

export const softDeleteFarmNode = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const payload = request.data || {};
  const tenantContext = await resolveAuthorizedTenant(request, payload.tenantId ? String(payload.tenantId) : undefined);
  const claims = authContext.auth.token || {};
  const isSuperAdmin = isSuperAdminClaims(claims, String(claims.email || ""));
  if (!tenantContext.isOwner && !isSuperAdmin) throw new HttpsError("permission-denied", "Farm-node deletion is not authorized.");
  const farmId = String(payload.farmId || "").trim();
  if (!farmId) throw new HttpsError("invalid-argument", "farmId is required.");
  const now = new Date().toISOString();
  const profileRef = db.collection("users_data").doc(tenantContext.tenantId);
  const farmsRef = profileRef.collection("modules").doc("farms");
  const archiveRef = db.collection("tenants").doc(tenantContext.tenantId).collection("archived_records").doc(`farm-${farmId}`);
  const auditRef = db.collection("tenants").doc(tenantContext.tenantId).collection("auditLogs").doc();
  const reversalRef = db.collection("tenants").doc(tenantContext.tenantId).collection("creditNotes").doc(`restore-${farmId}`);
  const result = await db.runTransaction(async (transaction) => {
    const [profileSnap, farmsSnap, archiveSnap, reversalSnap] = await Promise.all([
      transaction.get(profileRef), transaction.get(farmsRef), transaction.get(archiveRef), transaction.get(reversalRef)
    ]);
    if (archiveSnap.exists) return { alreadyDeleted: true, archive: archiveSnap.data() };
    const profileData = profileSnap.data() || {};
    const farms = Array.isArray(profileData.farms) ? profileData.farms : (farmsSnap.data()?.data || []);
    const farm = farms.find((item: any) => String(item?.id || "") === farmId);
    if (!farm) throw new HttpsError("not-found", "Farm node not found.");
    const archive = {
      id: archiveRef.id, module: "Farm Nodes", originalId: farmId, farmId,
      tenantId: tenantContext.tenantId, data: farm, archivedAt: now, isDeleted: true, status: "deleted",
      deletedAt: now, deletedBy: authContext.auth.uid, deletedByRole: claims.role || (isSuperAdmin ? "super_admin" : "owner"),
      reversalCreditAmount: 150, creditNoteId: reversalRef.id
    };
    const remaining = farms.filter((item: any) => String(item?.id || "") !== farmId);
    transaction.set(profileRef, { farms: remaining, updatedAt: now }, { merge: true });
    transaction.set(farmsRef, { data: remaining, updatedAt: now }, { merge: true });
    transaction.set(archiveRef, archive);
    transaction.set(reversalRef, {
      id: reversalRef.id, tenantId: tenantContext.tenantId, farmId, amount: 150, currency: farm.currency || "ZMW",
      type: "soft_delete_reversal", originalTransactionReference: `farm-node:${farmId}`,
      actorUserId: authContext.auth.uid, createdAt: now
    });
    transaction.set(auditRef, {
      action: "SOFT_DELETE", entity: "farm_node", farmNodeId: tenantContext.tenantId, recordId: farmId,
      actorUserId: authContext.auth.uid, actorRole: claims.role || (isSuperAdmin ? "super_admin" : "owner"),
      timestamp: now, previousValue: farm, newValue: archive, financialReversalId: reversalRef.id
    });
    return { alreadyDeleted: false, archive };
  });
  return { success: true, ...result };
});

export const restoreFarmNode = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const claims = authContext.auth.token || {};
  if (!isSuperAdminClaims(claims, String(claims.email || ""))) throw new HttpsError("permission-denied", "Super Admin authorization is required to restore a farm node.");
  const tenantId = String(request.data?.tenantId || "").trim();
  const farmId = String(request.data?.farmId || "").trim();
  if (!tenantId || !farmId) throw new HttpsError("invalid-argument", "tenantId and farmId are required.");
  const now = new Date().toISOString();
  const profileRef = db.collection("users_data").doc(tenantId);
  const farmsRef = profileRef.collection("modules").doc("farms");
  const archiveRef = db.collection("tenants").doc(tenantId).collection("archived_records").doc(`farm-${farmId}`);
  const auditRef = db.collection("tenants").doc(tenantId).collection("auditLogs").doc();
  const reversalRef = db.collection("tenants").doc(tenantId).collection("creditNotes").doc(`restore-${farmId}`);
  const result = await db.runTransaction(async (transaction) => {
    const [profileSnap, farmsSnap, archiveSnap, reversalSnap] = await Promise.all([
      transaction.get(profileRef), transaction.get(farmsRef), transaction.get(archiveRef), transaction.get(reversalRef)
    ]);
    if (!archiveSnap.exists) throw new HttpsError("not-found", "Archived farm node not found.");
    const archive = archiveSnap.data() || {};
    const profileData = profileSnap.data() || {};
    const farms = Array.isArray(profileData.farms) ? profileData.farms : (farmsSnap.data()?.data || []);
    if (farms.some((item: any) => String(item?.id || "") === farmId)) return { alreadyRestored: true, farm: farms.find((item: any) => String(item?.id || "") === farmId) };
    const farm = { ...(archive.data || {}), isDeleted: false, isArchived: false, restoredAt: now, restoredBy: authContext.auth.uid };
    const nextFarms = [...farms, farm];
    transaction.set(profileRef, { farms: nextFarms, updatedAt: now }, { merge: true });
    transaction.set(farmsRef, { data: nextFarms, updatedAt: now }, { merge: true });
    transaction.set(archiveRef, { status: "restored", restoredAt: now, restoredBy: authContext.auth.uid }, { merge: true });
    transaction.set(reversalRef, {
      restorationReference: auditRef.id, financialReversalApplied: false, restoredAt: now, restoredBy: authContext.auth.uid
    }, { merge: true });
    transaction.set(auditRef, {
      action: "RESTORE", entity: "farm_node", farmNodeId: tenantId, recordId: farmId,
      actorUserId: authContext.auth.uid, actorRole: claims.role || "super_admin", timestamp: now,
      previousValue: archive, newValue: farm, restorationReference: auditRef.id
    });
    return { alreadyRestored: false, farm };
  });
  return { success: true, ...result };
});

/**
 * Callable: updateFarmProfile
 */
export const updateFarmProfile = onCall(async (request) => {
  await verifyTenantPermission(request);
  const tenantId = String(request.data.tenantId);

  // Enforce server-side read-only mode checks before any write operation
  await enforceWritePermission(tenantId);

  const payload = request.data.profileData;
  if (!payload || typeof payload !== "object") {
    throw new HttpsError("invalid-argument", "profileData object is required");
  }

  try {
    await billingCentreService.updateFarmProfile(tenantId, payload);
    return { success: true, message: "Farm profile letterhead updated successfully." };
  } catch (error: any) {
    console.error("[updateFarmProfile] Error updating profile:", error.message);
    throw new HttpsError("internal", error.message || "Failed to update profile");
  }
});

/**
 * Callable: getWalletDetails
 */
export const getWalletDetails = onCall(async (request) => {
  await verifyTenantPermission(request);
  const tenantId = String(request.data.tenantId);

  try {
    const details = await billingCentreService.getWalletDetails(tenantId);
    return { success: true, ...details };
  } catch (error: any) {
    console.error("[getWalletDetails] Error fetching wallet details:", error.message);
    throw new HttpsError("internal", error.message || "Failed to fetch wallet details");
  }
});

/**
 * Callable: purchaseCredits
 */
export const purchaseCredits = onCall(async (request) => {
  const authRequest = await verifyTenantPermission(request);
  const tenantId = String(request.data.tenantId);
  const actorUid = authRequest.auth.uid;

  const amount = Number(request.data.amount);
  const amountPaidZmw = Number(request.data.amountPaidZmw);

  if (isNaN(amount) || amount <= 0 || isNaN(amountPaidZmw) || amountPaidZmw <= 0) {
    throw new HttpsError("invalid-argument", "amount and amountPaidZmw must be positive numbers.");
  }

  try {
    const result = await billingCentreService.purchaseCredits(tenantId, amount, amountPaidZmw, actorUid);
    return result;
  } catch (error: any) {
    console.error("[purchaseCredits] Error purchasing credits:", error.message);
    throw new HttpsError("internal", error.message || "Credit purchase failed.");
  }
});

/**
 * Callable: activateDailyBundle
 */
export const activateDailyBundle = onCall(async (request) => {
  const authRequest = await verifyTenantPermission(request);
  const tenantId = String(request.data.tenantId);
  const actorUid = authRequest.auth.uid;

  const costZmw = Number(request.data.costZmw || 10); // Default daily bundle price is 10 ZMW

  try {
    const result = await billingCentreService.activateDailyBundle(tenantId, costZmw, actorUid);
    return result;
  } catch (error: any) {
    console.error("[activateDailyBundle] Error activating daily bundle:", error.message);
    throw new HttpsError("internal", error.message || "Failed to activate daily bundle.");
  }
});

const calculateFunctionRecordHash = (record: {
  tenantId: string;
  timestamp: string;
  amount: number;
  previousBalance: number;
  newBalance: number;
  moduleId: string;
  description: string;
}): string => {
  const str = `${record.tenantId}:${record.timestamp}:${record.amount}:${record.previousBalance}:${record.newBalance}:${record.moduleId}:${record.description}`;
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash;
  }
  let signature = "";
  for (let j = 0; j < 8; j++) {
    const seed = Math.abs(Math.sin(hash + j) * 16777216);
    signature += Math.floor(seed).toString(16).padStart(8, "0");
  }
  return signature;
};

/**
 * Callable: consumeCredits
 * Transaction-based consumption engine.
 * Verifies rule existence from superAdmin/creditConsumptionRules,
 * checks wallet balance, deducts credits via transaction, and writes a cryptographically
 * signed ledger entry atomically under the idempotencyKey for double-spend protection.
 */
export const consumeCredits = onCall(async (request) => {
  // 1. Enforce strict authorization context
  const authContext = verifyAuthContext(request);
  const actorUid = authContext.auth.uid;

  const payload = request.data;
  validatePayloadFields(payload, ["tenantId", "moduleId", "actionId", "idempotencyKey"]);
  
  const tenantId = String(payload.tenantId);
  const moduleId = String(payload.moduleId);
  const actionId = String(payload.actionId);
  const idempotencyKey = String(payload.idempotencyKey);
  const description = payload.description ? String(payload.description) : `Mabala Engine API: ${actionId}`;

  try {
    const result = await db.runTransaction(async (transaction) => {
      // a. Check for double-spend/idempotency replay
      const ledgerDocRef = db.collection("tenants").doc(tenantId).collection("creditLedger").doc(idempotencyKey);
      const existingLedgerSnap = await transaction.get(ledgerDocRef);
      if (existingLedgerSnap.exists) {
        return {
          success: true,
          message: `Duplicate request ignored. Transaction with idempotencyKey '${idempotencyKey}' was already processed.`,
          idempotencyKey,
          cost: existingLedgerSnap.data()?.amount || 0,
          duplicated: true
        };
      }

      // b. Verify rule existence in superAdmin/creditConsumptionRules
      const rulesDocRef = db.collection("superAdmin").doc("creditConsumptionRules");
      const rulesSnap = await transaction.get(rulesDocRef);
      if (!rulesSnap.exists) {
        throw new HttpsError("not-found", "Global credit consumption rules config document not found.");
      }
      
      const rulesData = rulesSnap.data();
      const rulesMap = rulesData?.rules || {};
      const rule = rulesMap[actionId];
      if (!rule) {
        throw new HttpsError("not-found", `No credit consumption rule exists for actionId '${actionId}'.`);
      }

      if (rule.active === false) {
        throw new HttpsError("failed-precondition", `Credit consumption rule for actionId '${actionId}' is currently disabled.`);
      }

      const cost = Number(rule.cost);
      if (isNaN(cost) || cost < 0) {
        throw new HttpsError("internal", `Invalid cost parameter configured for actionId '${actionId}'.`);
      }

      // c. Check tenant wallet balance
      const walletDocRef = db.collection("tenants").doc(tenantId).collection("wallet").doc("credits");
      const walletSnap = await transaction.get(walletDocRef);
      let currentBalance = 0;
      let lifetimeConsumed = 0;
      let hasWallet = false;

      if (walletSnap.exists) {
        hasWallet = true;
        const walletData = walletSnap.data();
        currentBalance = Number(walletData?.currentBalance ?? 0);
        lifetimeConsumed = Number(walletData?.lifetimeConsumed ?? 0);
      } else {
        // Fallback default for new accounts if wallet is uninitialized
        currentBalance = 300; 
      }

      if (currentBalance < cost) {
        throw new HttpsError("failed-precondition", `Insufficient wallet balance. Action '${actionId}' requires ${cost} credits, but current balance is ${currentBalance}.`);
      }

      const newBalance = currentBalance - cost;

      // d. Deduct credits and update wallet
      const nowStr = new Date().toISOString();
      const walletPayload = {
        currentBalance: newBalance,
        lifetimeConsumed: lifetimeConsumed + cost,
        updatedAt: nowStr
      };

      if (hasWallet) {
        transaction.update(walletDocRef, walletPayload);
      } else {
        transaction.set(walletDocRef, {
          ...walletPayload,
          lifetimeIssued: currentBalance,
          planAllotment: currentBalance,
          createdAt: nowStr
        });
      }

      // e. Write atomically-signed ledger entry under the idempotencyKey
      const ledgerRecord = {
        id: idempotencyKey,
        tenantId,
        timestamp: nowStr,
        type: "deduction",
        amount: cost,
        previousBalance: currentBalance,
        newBalance,
        moduleId,
        description,
        checksum: ""
      };
      ledgerRecord.checksum = calculateFunctionRecordHash(ledgerRecord);
      transaction.set(ledgerDocRef, ledgerRecord);

      // f. Update users_data parent document for backward-compatibility & visual persistence
      const userMetadataRef = db.collection("users_data").doc(tenantId);
      transaction.set(userMetadataRef, {
        credits: newBalance,
        updatedAt: nowStr
      }, { merge: true });

      return {
        success: true,
        message: `Successfully consumed ${cost} credits for action '${actionId}'.`,
        idempotencyKey,
        cost,
        previousBalance: currentBalance,
        newBalance,
        duplicated: false
      };
    });

    return result;
  } catch (error: any) {
    console.error("[consumeCredits] Error consuming credits:", error.message);
    if (error instanceof HttpsError) {
      throw error;
    }
    throw new HttpsError("internal", error.message || "Internal credit consumption engine error.");
  }
});

/**
 * Scheduled: nightlyReconciliation
 * Runs nightly at midnight to verify ledger balance matches active herd/flock valuation sum.
 */
export const nightlyReconciliation = onSchedule("0 0 * * *", async (event) => {
  try {
    const tenantsSnap = await db.collection("users_data").get();
    console.log(`[Nightly Reconciliation] Running for ${tenantsSnap.size} tenants...`);
    
    for (const tenantDoc of tenantsSnap.docs) {
      const tenantId = tenantDoc.id;
      
      const livestockDoc = await db.collection("users_data").doc(tenantId).collection("modules").doc("livestock").get();
      const poultryDoc = await db.collection("users_data").doc(tenantId).collection("modules").doc("poultry").get();
      const accountsDoc = await db.collection("users_data").doc(tenantId).collection("modules").doc("accounts").get();
      
      const livestock = livestockDoc.exists ? (livestockDoc.data()?.data || []) : [];
      const poultry = poultryDoc.exists ? (poultryDoc.data()?.data || []) : [];
      const accounts = accountsDoc.exists ? (accountsDoc.data()?.data || []) : [];
      
      const liveLivestockValue = livestock.reduce((sum: number, r: any) => sum + (r.status === "Active" ? (Number(r.currentValue) || 0) : 0), 0);
      const livePoultryValue = poultry.reduce((sum: number, p: any) => sum + (p.status === "Active" ? (Number(p.currentBatchValuation) || 0) : 0), 0);
      const expected1420Balance = liveLivestockValue + livePoultryValue;
      
      const acc1420 = accounts.find((a: any) => a.code === "1420");
      const actual1420Balance = acc1420 ? (Number(acc1420.balance) || 0) : 0;
      
      if (Math.abs(expected1420Balance - actual1420Balance) > 0.01) {
        console.warn(`[Nightly Reconciliation] MISMATCH for tenant ${tenantId}: Expected ZK ${expected1420Balance}, Actual ZK ${actual1420Balance}`);
        const alertId = "reconcile-alert-" + tenantId + "-" + Date.now();
        await db.collection("super_admin_alerts").doc(alertId).set({
          id: alertId,
          tenantId,
          type: "RECONCILIATION_MISMATCH",
          expected: expected1420Balance,
          actual: actual1420Balance,
          message: `Reconciliation mismatch for tenant ${tenantId}: calculated livestock + poultry biological value is ZK ${expected1420Balance.toLocaleString()}, but Account 1420 balance is ZK ${actual1420Balance.toLocaleString()}.`,
          timestamp: new Date().toISOString()
        });
      }
    }
  } catch (err: any) {
    console.error("[Nightly Reconciliation] Error:", err.message);
  }
});

/**
 * Callable: runReconciliationRepair
 * One-time/on-demand repair job to correct account mismatches and write RECONCILIATION_REPAIR logs.
 */
export const runReconciliationRepair = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  
  try {
    const tenantsSnap = await db.collection("users_data").get();
    const results: any[] = [];
    
    for (const tenantDoc of tenantsSnap.docs) {
      const tenantId = tenantDoc.id;
      
      const livestockDoc = await db.collection("users_data").doc(tenantId).collection("modules").doc("livestock").get();
      const poultryDoc = await db.collection("users_data").doc(tenantId).collection("modules").doc("poultry").get();
      const accountsDoc = await db.collection("users_data").doc(tenantId).collection("modules").doc("accounts").get();
      
      const livestock = livestockDoc.exists ? (livestockDoc.data()?.data || []) : [];
      const poultry = poultryDoc.exists ? (poultryDoc.data()?.data || []) : [];
      const accounts = accountsDoc.exists ? (accountsDoc.data()?.data || []) : [];
      
      const liveLivestockValue = livestock.reduce((sum: number, r: any) => sum + (r.status === "Active" ? (Number(r.currentValue) || 0) : 0), 0);
      const livePoultryValue = poultry.reduce((sum: number, p: any) => sum + (p.status === "Active" ? (Number(p.currentBatchValuation) || 0) : 0), 0);
      const expected1420Balance = liveLivestockValue + livePoultryValue;
      
      const acc1420 = accounts.find((a: any) => a.code === "1420");
      const actual1420Balance = acc1420 ? (Number(acc1420.balance) || 0) : 0;
      
      if (Math.abs(expected1420Balance - actual1420Balance) > 0.01) {
        // Repair!
        const updatedAccounts = accounts.map((a: any) => a.code === "1420" ? { ...a, balance: expected1420Balance } : a);
        await db.collection("users_data").doc(tenantId).collection("modules").doc("accounts").set({
          data: updatedAccounts,
          updatedAt: new Date().toISOString()
        }, { merge: true });
        
        const auditId = "repair-audit-" + tenantId + "-" + Date.now();
        await db.collection("super_admin_audit").doc(auditId).set({
          id: auditId,
          tenantId,
          actionType: "RECONCILIATION_REPAIR",
          beforeValue: actual1420Balance,
          afterValue: expected1420Balance,
          timestamp: new Date().toISOString(),
          description: `Auto-corrected biological assets ledger Account 1420 balance for tenant ${tenantId} from ZK ${actual1420Balance} to ZK ${expected1420Balance} based on live animal/poultry records.`
        });
        
        results.push({
          tenantId,
          repaired: true,
          before: actual1420Balance,
          after: expected1420Balance
        });
      } else {
        results.push({
          tenantId,
          repaired: false,
          before: actual1420Balance,
          after: expected1420Balance
        });
      }
    }
    
    return { success: true, results };
  } catch (error: any) {
    console.error("[runReconciliationRepair] Error:", error.message);
    throw new HttpsError("internal", error.message || "Failed to run reconciliation repair.");
  }
});

/**
 * Callable: enterAccessNode
 * Mints short-lived custom claims for remote-support access node session and logs start event to super_admin_audit.
 */
export const enterAccessNode = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const userId = authContext.auth.uid;
  const payload = request.data || {};

  const callerClaims = authContext.auth.token || {};
  const callerEmail = String(callerClaims.email || "").toLowerCase();
  const isSuperAdmin = isSuperAdminClaims(callerClaims, callerEmail);
  if (!isSuperAdmin) {
    throw new HttpsError("permission-denied", "Super Admin access is required to enter a Farm Node.");
  }

  validatePayloadFields(payload, ["tenantId"]);
  const targetTenantId = String(payload.tenantId);
  validateIdFormat(targetTenantId, "tenantId");

  try {
    const userEmail = authContext.auth.token.email || "superadmin@mabala.cloud";
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 60 * 60 * 1000).toISOString();

    const platformTenantRef = db.collection("platform").doc("institutions").collection("institutions").doc(targetTenantId);
    const tenantRef = db.collection("tenants").doc(targetTenantId);
    const [platformTenantSnap, tenantSnap, ownerProfileSnap] = await Promise.all([
      platformTenantRef.get(),
      tenantRef.get(),
      db.collection("users_data").doc(targetTenantId).get()
    ]);
    const targetTenantData = platformTenantSnap.exists ? (platformTenantSnap.data() || {}) : (tenantSnap.data() || {});
    if (!platformTenantSnap.exists && !tenantSnap.exists && !ownerProfileSnap.exists) {
      throw new HttpsError("not-found", "The requested Farm Node does not exist.");
    }
    if (String(targetTenantData.status || "Active").toLowerCase() !== "active") {
      throw new HttpsError("failed-precondition", "The requested Farm Node is not active.");
    }

    const sessionId = "access-node-session-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
    const targetOwnerId = String(targetTenantData.ownerUid || targetTenantData.ownerId || ownerProfileSnap.id || targetTenantId);

    // Preserve all permanent Super Admin claims. The remote context is additive
    // and expires independently of the account's role and identity.
    await auth.setCustomUserClaims(userId, addRemoteAccessClaims(
      (await auth.getUser(userId)).customClaims || {},
      { tenantId: targetTenantId, sessionId, expiresAt }
    ));

    const auditDoc = {
      id: sessionId,
      superAdminId: userId,
      superAdminEmail: userEmail,
      initiatedBy: userEmail,
      actionType: "farm_node_entry",
      targetTenantId,
      targetOwnerId,
      expiresAt,
      status: "active",
      actingAs: "super_admin_access_node",
      details: {
        farmNodeId: targetTenantId,
        startedAt: now.toISOString(),
        expiresAt,
        timestamp: now.toISOString()
      },
      timestamp: now.toISOString()
    };

    await db.collection("super_admin_audit").doc(sessionId).set(auditDoc);
    await db.collection("remote_access_sessions").doc(sessionId).set({
      sessionId,
      superAdminId: userId,
      superAdminEmail: userEmail,
      targetTenantId,
      targetOwnerId,
      startedAt: now.toISOString(),
      expiresAt,
      status: "active"
    });

    return {
      success: true,
      sessionId,
      targetTenantId,
      targetOwnerId,
      expiresAt,
      message: `Access Node session started for tenant ${targetTenantId}`
    };
  } catch (error: any) {
    console.error("[enterAccessNode] Error:", error.message);
    throw new HttpsError("internal", error.message || "Failed to enter Access Node.");
  }
});

/**
 * Callable: exitAccessNode
 * Safely terminates active Access Node session, clears custom claims on the user record, and logs closure to audit trail.
 */
export const exitAccessNode = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const userId = authContext.auth.uid;
  const userEmail = authContext.auth.token.email || "superadmin@mabala.cloud";
  const sessionId = String(request.data?.sessionId || authContext.auth.token.accessNodeSessionId || "");
  const sessionSnap = sessionId ? await db.collection("remote_access_sessions").doc(sessionId).get() : null;
  const sessionData = sessionSnap?.exists ? (sessionSnap.data() || {}) : {};
  if (sessionData.superAdminId && sessionData.superAdminId !== userId) {
    throw new HttpsError("permission-denied", "This remote-access session belongs to another administrator.");
  }
  const targetTenantId = String(sessionData.targetTenantId || authContext.auth.token.accessNodeTenantId || "unknown_tenant");

  try {
    const currentUser = await auth.getUser(userId);
    const preservedClaims = removeRemoteAccessClaims(currentUser.customClaims || {});

    // Clear only temporary context claims; preserve permanent role and identity claims.
    await auth.setCustomUserClaims(userId, {
      ...preservedClaims
    });

    const endedAt = new Date().toISOString();
    const auditId = "audit-exit-" + Date.now();

    const exitAuditDoc = {
      id: auditId,
      superAdminId: userId,
      superAdminEmail: userEmail,
      initiatedBy: userEmail,
      actionType: "farm_node_exit",
      targetTenantId,
      actingAs: "super_admin_access_node",
      details: {
        endedAt,
        reason: "Session terminated cleanly via exitAccessNode",
        timestamp: endedAt
      },
      timestamp: endedAt
    };

    await db.collection("super_admin_audit").doc(auditId).set(exitAuditDoc);
    if (sessionId) {
      await db.collection("remote_access_sessions").doc(sessionId).set({
        status: "ended",
        endedAt,
        updatedAt: endedAt
      }, { merge: true });
    }

    return {
      success: true,
      message: "Access Node session closed successfully; Super Admin identity preserved."
    };
  } catch (error: any) {
    console.error("[exitAccessNode] Error:", error.message);
    throw new HttpsError("internal", error.message || "Failed to exit Access Node.");
  }
});

/**
 * Callable: deleteNodeCascade
 * Super Admin only callable function for cascade deletion of a farm node / institution.
 */
export const deleteNodeCascade = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const callerUid = authContext.auth.uid;
  const callerToken = authContext.auth.token;
  const callerEmail = (callerToken.email || "").toLowerCase();

  // Canonical admin emails / super admin verification
  const canonicalSuperAdmins = [
    "support@mabala.cloud",
    "shikasuli@gmail.com",
    "owner@mabala.com",
    "mary@mabala.com"
  ];
  let isSuper =
    callerToken.role === "super_admin" ||
    callerToken.superAdmin === true ||
    callerUid === "icIoBG4eN5VOw2BvhNiFUnUqmsX2" ||
    canonicalSuperAdmins.includes(callerEmail);

  if (!isSuper) {
    // Check Firestore user profile in case custom claims were not yet refreshed
    const userDoc = await db.collection("users_data").doc(callerUid).get();
    const userData = userDoc.data();
    const isProfileSuper = userData?.role === "Super Admin" || userData?.superAdmin === true;
    if (!isProfileSuper) {
      throw new HttpsError("permission-denied", "Access denied: Platform Super Admin privileges required.");
    }
    isSuper = true;
    // Auto-sync custom claims for future requests
    try {
      await auth.setCustomUserClaims(callerUid, { role: "super_admin", superAdmin: true });
    } catch (claimErr) {
      console.warn("[deleteNodeCascade] Claim auto-sync warning:", claimErr);
    }
  }

  const payload = request.data || {};
  const { tenantId, reason, confirmationText, confirmationName } = payload;
  const typedConfirmation = (confirmationText || confirmationName || "").trim();

  if (!tenantId || typeof tenantId !== "string") {
    throw new HttpsError("invalid-argument", "Missing required argument: tenantId");
  }
  if (!reason || typeof reason !== "string" || !reason.trim()) {
    throw new HttpsError("invalid-argument", "A mandatory legal reason is required for cascade deletion.");
  }
  if (!typedConfirmation) {
    throw new HttpsError("invalid-argument", "Confirmation name/text is required.");
  }

  // 1. Retrieve tenant doc from platform/institutions/institutions/{tenantId} OR users_data/{tenantId}
  let tenantDoc = await db.collection("platform").doc("institutions").collection("institutions").doc(tenantId).get();
  if (!tenantDoc.exists) {
    tenantDoc = await db.collection("users_data").doc(tenantId).get();
  }
  if (!tenantDoc.exists) {
    tenantDoc = await db.collection("offtakers").doc(tenantId).get();
  }
  if (!tenantDoc.exists) {
    tenantDoc = await db.collection("partners").doc(tenantId).get();
  }
  if (!tenantDoc.exists) {
    throw new HttpsError("not-found", `Tenant node "${tenantId}" not found in Firestore.`);
  }

  const tenantData = tenantDoc.data() || {};
  const farmName = tenantData.farmName || tenantData.name || tenantData.institutionName || tenantData.farms?.[0]?.name || "Farm Node";
  const ownerEmail = (tenantData.ownerEmail || tenantData.email || tenantData.primaryContactEmail || "").toLowerCase();
  const ownerPhone = tenantData.ownerPhone || tenantData.phone || tenantData.primaryContact || "Not Provided";

  // Validate confirmation text matches farm name or owner email (case-insensitive)
  const normTyped = typedConfirmation.toLowerCase();
  const normFarmName = farmName.trim().toLowerCase();
  const normEmail = ownerEmail.trim().toLowerCase();
  const normName = (tenantData.name || "").trim().toLowerCase();

  if (normTyped !== normFarmName && normTyped !== normEmail && normTyped !== normName && !normFarmName.includes(normTyped)) {
    throw new HttpsError("failed-precondition", `Confirmation name "${typedConfirmation}" does not match farm node name "${farmName}" or owner email.`);
  }

  console.log(`[deleteNodeCascade] Starting cascade deletion for tenant ${tenantId} (${farmName}, ${ownerEmail}) by ${callerEmail}`);

  // Step a: Set tenant status = 'suspended'
  const suspendedAt = new Date().toISOString();
  try {
    await db.collection("platform").doc("institutions").collection("institutions").doc(tenantId).set({
      status: "suspended",
      suspensionReason: reason,
      suspendedBy: callerEmail,
      suspendedAt
    }, { merge: true });
  } catch (_) {}

  try {
    await db.collection("users_data").doc(tenantId).set({
      status: "suspended",
      suspensionReason: reason,
      suspendedBy: callerEmail,
      suspendedAt
    }, { merge: true });
  } catch (_) {}

  // Step b: Revoke all active sessions/credentials for every user whose tenantId == tenantId or uid == tenantId
  const uidsToPurge: string[] = [tenantId];
  try {
    const subUsersSnap = await db.collection("users_data").where("tenantId", "==", tenantId).get();
    subUsersSnap.forEach((docSnap) => {
      if (!uidsToPurge.includes(docSnap.id)) {
        uidsToPurge.push(docSnap.id);
      }
    });
  } catch (_) {}

  for (const uid of uidsToPurge) {
    try {
      await auth.revokeRefreshTokens(uid);
      await auth.updateUser(uid, { disabled: true });
      await auth.deleteUser(uid);
      console.log(`[deleteNodeCascade] Successfully revoked and deleted Auth user: ${uid}`);
    } catch (authErr: any) {
      console.warn(`[deleteNodeCascade] Auth deletion note for ${uid}:`, authErr.message);
    }
  }

  // Step c: Recursively delete documents & subcollections
  async function recursiveDelete(docRef: FirebaseFirestore.DocumentReference) {
    const collections = await docRef.listCollections();
    for (const col of collections) {
      const docs = await col.listDocuments();
      for (const d of docs) {
        await recursiveDelete(d);
      }
    }
    await docRef.delete();
  }

  let purgedCollectionsCount = 0;

  // Purge platform/institutions/institutions/{tenantId}
  try {
    const instRef = db.collection("platform").doc("institutions").collection("institutions").doc(tenantId);
    await recursiveDelete(instRef);
    purgedCollectionsCount++;
  } catch (e: any) {
    console.warn("[deleteNodeCascade] Error purging institution doc:", e.message);
  }

  // Purge users_data/{tenantId} and all sub-users
  for (const uid of uidsToPurge) {
    try {
      const uRef = db.collection("users_data").doc(uid);
      await recursiveDelete(uRef);
      purgedCollectionsCount++;
    } catch (e: any) {
      console.warn(`[deleteNodeCascade] Error purging users_data/${uid}:`, e.message);
    }
  }

  // Purge tenants/{tenantId}
  try {
    const tRef = db.collection("tenants").doc(tenantId);
    await recursiveDelete(tRef);
    purgedCollectionsCount++;
  } catch (e: any) {
    console.warn("[deleteNodeCascade] Error purging tenants doc:", e.message);
  }

  // Purge offtakers/{tenantId} and partners/{tenantId}
  try {
    await recursiveDelete(db.collection("offtakers").doc(tenantId));
  } catch (_) {}
  try {
    await recursiveDelete(db.collection("partners").doc(tenantId));
  } catch (_) {}

  // Purge active_sessions
  if (ownerEmail) {
    try {
      await db.collection("active_sessions").doc(ownerEmail).delete();
    } catch (_) {}
  }

  // Step d: Write final audit log entries
  const purgedAt = Date.now();
  const timestamp = new Date().toISOString();
  const auditId = `audit_del_${tenantId}_${purgedAt}`;

  await db.collection("super_admin_audit").doc(auditId).set({
    id: auditId,
    superAdminId: callerUid,
    superAdminEmail: callerEmail,
    actionType: "farm_node_cascade_delete",
    targetTenantId: tenantId,
    details: {
      farmName,
      ownerEmail,
      ownerPhone,
      reason,
      purgedUserCount: uidsToPurge.length,
      purgedCollectionsCount,
      purgedAt,
      timestamp
    },
    timestamp
  });

  await db.collection("deleted_farm_nodes").doc(`del_${tenantId}_${purgedAt}`).set({
    id: `del_${tenantId}_${purgedAt}`,
    tenantId,
    farmName,
    ownerName: tenantData.name || ownerEmail.split("@")[0],
    email: ownerEmail,
    phone: ownerPhone || "Not Provided",
    ownerEmail,
    ownerPhone,
    role: tenantData.role || tenantData.accountType || "Farmer",
    tenantType: tenantData.accountType || "farmer",
    deletedBy: "Super Admin",
    deletedByEmail: callerEmail,
    deletedAt: timestamp,
    reason,
    backupDownloaded: true,
    emailPhoneReleased: true,
    recordsSummary: {
      totalRecords: purgedCollectionsCount + uidsToPurge.length
    }
  }, { merge: true });

  return {
    success: true,
    purgedAt,
    message: `Farm node "${farmName}" and ${uidsToPurge.length} associated user account(s) have been permanently deleted and credentials released.`
  };
});

/**
 * Callable: resendWelcomeEmail
 * Super Admin callable function to re-issue welcome email with fresh password reset link.
 */
export { resendWelcomeEmail } from "./welcomeEmail.functions";

/**
 * Callable: createSubUser
 * Farm Owner / Institution Admin callable function to create and link a sub-user without provisioning a new tenant.
 */
export const createSubUser = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const callerUid = authContext.auth.uid;
  const callerToken = authContext.auth.token;
  const callerEmail = (callerToken.email || "").toLowerCase();

  const payload = request.data || {};
  validatePayloadFields(payload, ["email", "displayName"]);

  const tenantContext = await resolveAuthorizedTenant(request, undefined, true);

  const cleanEmail = String(payload.email).trim().toLowerCase();
  const displayName = String(payload.displayName).trim();
  const phone = payload.phone ? String(payload.phone).trim() : "";
  const permissionLevels = new Set(["none", "read", "read_write"]);
  const permissions: Record<string, "none" | "read" | "read_write"> = {};
  if (payload.permissions && typeof payload.permissions === "object") {
    for (const [moduleId, level] of Object.entries(payload.permissions)) {
      if (!/^[a-z][a-z0-9_-]{0,63}$/.test(moduleId) || !permissionLevels.has(String(level))) {
        throw new HttpsError("invalid-argument", "Invalid module permission assignment.");
      }
      permissions[moduleId] = String(level) as "none" | "read" | "read_write";
    }
  }
  const accessLevel = Object.values(permissions).some(level => level === "read_write") ? "read_write" : "read_only";
  const rawPassword = payload.password ? String(payload.password) : "Mabala@" + Math.floor(100000 + Math.random() * 900000);

  // Check caller profile to determine tenantId & authorization
  const callerDoc = await db.collection("users_data").doc(callerUid).get();
  const callerData = callerDoc.data() || {};

  const isSuper = callerToken.role === "super_admin" || callerToken.superAdmin === true || callerEmail === "support@mabala.cloud";
  
  // Resolve tenant from authenticated membership, never from the request body.
  const targetTenantId = tenantContext.tenantId;

  if (!isSuper && !tenantContext.isOwner) {
    throw new HttpsError("permission-denied", "Only tenant owners or super admins can create sub-users for their farm workspace.");
  }

  // 1. Create or fetch Firebase Auth user
  let targetUid = "";
  try {
    const userRecord = await auth.createUser({
      email: cleanEmail,
      displayName,
      password: rawPassword,
      phoneNumber: phone && phone.startsWith("+") ? phone : undefined
    });
    targetUid = userRecord.uid;
  } catch (authErr: any) {
    if (authErr.code === "auth/email-already-exists") {
      const existingUser = await auth.getUserByEmail(cleanEmail);
      targetUid = existingUser.uid;
      // Update password if provided
      if (payload.password) {
        await auth.updateUser(targetUid, { password: rawPassword, displayName });
      }
    } else {
      throw new HttpsError("internal", `Failed to create auth user: ${authErr.message}`);
    }
  }

  const now = FieldValue.serverTimestamp();
  const isoNow = new Date().toISOString();

  // 2. Write users_data/{targetUid} pointing to the owner's tenantId (NEVER sub-user's own UID)
  await db.collection("users_data").doc(targetUid).set({
    uid: targetUid,
    email: cleanEmail,
    name: displayName,
    displayName,
    phone,
    role: "sub_user",
    tenantId: targetTenantId, // NEVER targetUid
    accessLevel,
    permissions,
    mustChangePassword: true,
    status: "active",
    createdBy: callerUid,
    createdAt: now,
    updatedAt: now
  }, { merge: true });

  // 3. Write membership record in platform/institutions/institutions/{targetTenantId}/members/{targetUid}
  await db.collection("platform")
    .doc("institutions")
    .collection("institutions")
    .doc(targetTenantId)
    .collection("members")
    .doc(targetUid)
    .set({
      uid: targetUid,
      email: cleanEmail,
      displayName,
      phone,
      accessLevel,
      permissions,
      mustChangePassword: true,
      status: "active",
      invitedBy: callerUid,
      addedAt: now,
      updatedAt: now,
      lastActiveAt: null
    }, { merge: true });

  // Also write to legacy tenants/{tenantId}/members for backward compatibility
  try {
    await db.collection("tenants").doc(targetTenantId).collection("members").doc(targetUid).set({
      uid: targetUid,
      email: cleanEmail,
      displayName,
      phone,
      accessLevel,
      permissions,
      mustChangePassword: true,
      status: "active",
      invitedBy: callerUid,
      addedAt: now,
      updatedAt: now
    }, { merge: true });
  } catch (_) {}

  // 4. Trigger welcome email with temporary password & login URL
  try {
    const farmName = callerData.farms?.[0]?.name || callerData.farmName || "Mabala Agricultural Workspace";
    await sendWelcomeEmailOnSignup({
      uid: targetUid,
      email: cleanEmail,
      firstName: displayName.split(" ")[0],
      password: rawPassword,
      farmName
    });
  } catch (emailErr: any) {
    console.warn(`[createSubUser] Welcome email sending notice for ${cleanEmail}:`, emailErr.message);
  }

  // 5. Audit log
  const createAuditEntry = {
    tenantId: targetTenantId,
    actorUid: callerUid,
    actorEmail: callerEmail,
    actorName: callerData.userProfile?.name || callerData.displayName || callerData.email || "Farm Owner",
    action: "SUB_USER_CREATED",
    targetUid,
    targetEmail: cleanEmail,
    targetName: displayName,
    details: {
      email: cleanEmail,
      displayName,
      accessLevel,
      permissions,
      status: "active",
      timestamp: isoNow
    },
    timestamp: now,
    createdAt: now
  };
  await db.collection("platform")
    .doc("institutions")
    .collection("institutions")
    .doc(targetTenantId)
    .collection("auditLogs")
    .add(createAuditEntry);
  await db.collection("audit_logs").add(createAuditEntry);

  return {
    success: true,
    message: `Sub-user ${displayName} (${cleanEmail}) successfully linked to tenant workspace.`,
    uid: targetUid,
    tenantId: targetTenantId,
    accessLevel
  };
});

/**
 * Callable: updateSubUserAccess
 * Allows farm owner to change sub-user access level or suspend/reactivate access.
 */
export const updateSubUserAccess = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const callerUid = authContext.auth.uid;
  const callerToken = authContext.auth.token;
  const callerEmail = (callerToken.email || "").toLowerCase();

  const payload = request.data || {};
  validatePayloadFields(payload, ["targetUid"]);

  const tenantContext = await resolveAuthorizedTenant(request, undefined, true);

  const targetUid = String(payload.targetUid).trim();
  const accessLevel = payload.accessLevel; // "read_write" | "read_only"
  const status = payload.status; // "active" | "suspended" | "removed"

  const callerDoc = await db.collection("users_data").doc(callerUid).get();
  const callerData = callerDoc.data() || {};
  const isSuper = callerToken.role === "super_admin" || callerToken.superAdmin === true || callerEmail === "support@mabala.cloud";

  const targetTenantId = tenantContext.tenantId;

  if (!isSuper && !tenantContext.isOwner) {
    throw new HttpsError("permission-denied", "Only tenant owners can modify sub-user permissions.");
  }

  const updates: any = {
    updatedAt: FieldValue.serverTimestamp()
  };
  if (accessLevel) updates.accessLevel = accessLevel;
  if (status) updates.status = status;
  if (payload.permissions && typeof payload.permissions === "object") {
    const permissions: Record<string, string> = {};
    for (const [moduleId, level] of Object.entries(payload.permissions)) {
      if (!/^[a-z][a-z0-9_-]{0,63}$/.test(moduleId) || !["none", "read", "read_write"].includes(String(level))) {
        throw new HttpsError("invalid-argument", "Invalid module permission assignment.");
      }
      permissions[moduleId] = String(level);
    }
    updates.permissions = permissions;
  }

  // 1. Update member doc in platform/institutions/institutions/{targetTenantId}/members/{targetUid}
  await db.collection("platform")
    .doc("institutions")
    .collection("institutions")
    .doc(targetTenantId)
    .collection("members")
    .doc(targetUid)
    .set(updates, { merge: true });

  // 2. Update users_data/{targetUid}
  await db.collection("users_data").doc(targetUid).set(updates, { merge: true });

  // 3. If suspended or removed, revoke active refresh tokens immediately
  if (status === "suspended" || status === "removed") {
    try {
      await auth.revokeRefreshTokens(targetUid);
    } catch (_) {}
  }

  // 4. Audit log to both platform institution auditLogs and global audit_logs
  const targetMemberDoc = await db.collection("platform")
    .doc("institutions")
    .collection("institutions")
    .doc(targetTenantId)
    .collection("members")
    .doc(targetUid)
    .get();
  const targetMemberData = targetMemberDoc.data() || {};

  const actionName = status === "suspended"
    ? "SUB_USER_SUSPENDED"
    : status === "active"
      ? "SUB_USER_ACTIVATED"
      : status === "removed"
        ? "SUB_USER_REMOVED"
        : accessLevel
          ? `ACCESS_LEVEL_${accessLevel.toUpperCase()}`
          : "SUB_USER_ACCESS_UPDATED";

  const auditEntry = {
    tenantId: targetTenantId,
    actorUid: callerUid,
    actorEmail: callerEmail,
    actorName: callerData.userProfile?.name || callerData.displayName || callerData.email || "Farm Owner",
    action: actionName,
    targetUid,
    targetEmail: targetMemberData.email || "",
    targetName: targetMemberData.displayName || targetMemberData.name || "",
    details: {
      ...updates,
      previousStatus: targetMemberData.status || "active",
      previousAccessLevel: targetMemberData.accessLevel || "read_write"
    },
    timestamp: FieldValue.serverTimestamp(),
    createdAt: FieldValue.serverTimestamp()
  };

  await db.collection("platform")
    .doc("institutions")
    .collection("institutions")
    .doc(targetTenantId)
    .collection("auditLogs")
    .add(auditEntry);

  await db.collection("audit_logs").add(auditEntry);

  return {
    success: true,
    message: status === "suspended" 
      ? `Sub-user access suspended immediately.`
      : status === "active"
        ? `Sub-user access reactivated.`
        : `Sub-user access updated successfully.`,
    targetUid,
    ...updates
  };
});

/**
 * Callable: deleteSubUser
 * Allows farm owner to unlink and remove a sub-user.
 */
export const deleteSubUser = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const callerUid = authContext.auth.uid;
  const callerToken = authContext.auth.token;
  const callerEmail = (callerToken.email || "").toLowerCase();

  const payload = request.data || {};
  validatePayloadFields(payload, ["targetUid"]);

  const targetUid = String(payload.targetUid).trim();
  const callerDoc = await db.collection("users_data").doc(callerUid).get();
  const callerData = callerDoc.data() || {};
  const isSuper = callerToken.role === "super_admin" || callerToken.superAdmin === true || callerEmail === "support@mabala.cloud";

  const targetTenantId = payload.tenantId ? String(payload.tenantId) : (callerData.tenantId || callerUid);

  if (!isSuper && callerUid !== targetTenantId && callerData.tenantId !== targetTenantId) {
    throw new HttpsError("permission-denied", "Only tenant owners can delete sub-users.");
  }

  // 1. Mark as removed in members subcollection
  await db.collection("platform")
    .doc("institutions")
    .collection("institutions")
    .doc(targetTenantId)
    .collection("members")
    .doc(targetUid)
    .delete();

  // 2. Mark users_data as removed
  await db.collection("users_data").doc(targetUid).set({
    status: "removed",
    accessLevel: "read_only",
    updatedAt: FieldValue.serverTimestamp()
  }, { merge: true });

  // 3. Revoke tokens
  try {
    await auth.revokeRefreshTokens(targetUid);
  } catch (_) {}

  // 4. Audit log
  const deleteAuditEntry = {
    tenantId: targetTenantId,
    actorUid: callerUid,
    actorEmail: callerEmail,
    actorName: callerData.userProfile?.name || callerData.displayName || callerData.email || "Farm Owner",
    action: "SUB_USER_REMOVED",
    targetUid,
    details: {
      action: "unlink_from_tenant"
    },
    timestamp: FieldValue.serverTimestamp(),
    createdAt: FieldValue.serverTimestamp()
  };
  await db.collection("platform")
    .doc("institutions")
    .collection("institutions")
    .doc(targetTenantId)
    .collection("auditLogs")
    .add(deleteAuditEntry);
  await db.collection("audit_logs").add(deleteAuditEntry);

  return {
    success: true,
    message: "Sub-user successfully removed from tenant workspace."
  };
});

/**
 * Callable: migrateStraySubUsers
 * Super Admin one-time migration to reparent already-broken sub-user accounts.
 */
export const migrateStraySubUsers = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const callerUid = authContext.auth.uid;
  const callerToken = authContext.auth.token;
  const callerEmail = (callerToken.email || "").toLowerCase();

  const isSuper = callerToken.role === "super_admin" || callerToken.superAdmin === true || callerEmail === "support@mabala.cloud";
  if (!isSuper) {
    throw new HttpsError("permission-denied", "Super Admin privileges required to run sub-user migration.");
  }

  const report: {
    totalChecked: number;
    migrated: Array<{ uid: string; email: string; oldTenantId: string; newTenantId: string; ownerEmail?: string }>;
    flaggedForReview: Array<{ uid: string; email: string; reason: string }>;
    archivedTenantDocs: string[];
  } = {
    totalChecked: 0,
    migrated: [],
    flaggedForReview: [],
    archivedTenantDocs: []
  };

  const usersSnap = await db.collection("users_data").get();
  report.totalChecked = usersSnap.size;

  for (const uDoc of usersSnap.docs) {
    const uData = uDoc.data();
    const uid = uDoc.id;
    const email = (uData.email || "").toLowerCase();
    const role = (uData.role || "").toLowerCase();

    // Check for broken sub-user signature:
    const isSubUser = role === "sub_user" || uData.isSubUser === true || role === "field officer" || !!uData.createdBy || !!uData.parentTenantEmail || !!uData.parentTenantId;

    if (isSubUser && (!uData.tenantId || uData.tenantId === uid)) {
      // Determine real owner
      let ownerUid = uData.createdBy || uData.invitedBy || "";
      let ownerEmail = uData.parentTenantEmail || "";

      if (!ownerUid && ownerEmail) {
        const ownerQuery = await db.collection("users_data").where("email", "==", ownerEmail.toLowerCase()).limit(1).get();
        if (!ownerQuery.empty) {
          ownerUid = ownerQuery.docs[0].id;
        }
      }

      if (!ownerUid) {
        report.flaggedForReview.push({
          uid,
          email,
          reason: "Sub-user detected with tenantId == uid, but creator/owner cannot be automatically resolved."
        });
        continue;
      }

      // Reparent sub-user
      await db.collection("users_data").doc(uid).set({
        tenantId: ownerUid,
        role: "sub_user",
        updatedAt: FieldValue.serverTimestamp()
      }, { merge: true });

      await db.collection("platform")
        .doc("institutions")
        .collection("institutions")
        .doc(ownerUid)
        .collection("members")
        .doc(uid)
        .set({
          uid,
          email,
          displayName: uData.name || uData.displayName || email.split("@")[0],
          accessLevel: uData.accessLevel || "read_write",
          status: uData.status || "active",
          invitedBy: ownerUid,
          updatedAt: FieldValue.serverTimestamp()
        }, { merge: true });

      // Archive any stray separate tenant document
      try {
        const strayInstRef = db.collection("platform").doc("institutions").collection("institutions").doc(uid);
        const strayInstSnap = await strayInstRef.get();
        if (strayInstSnap.exists) {
          await strayInstRef.set({
            archived: true,
            archivedReason: "sub_user_migration",
            archivedAt: FieldValue.serverTimestamp(),
            reparentedToTenantId: ownerUid
          }, { merge: true });
          report.archivedTenantDocs.push(uid);
        }
      } catch (_) {}

      report.migrated.push({
        uid,
        email,
        oldTenantId: uid,
        newTenantId: ownerUid,
        ownerEmail
      });
    }
  }

  return {
    success: true,
    message: `Migration completed: ${report.migrated.length} sub-users reparented, ${report.archivedTenantDocs.length} stray tenant docs archived, ${report.flaggedForReview.length} flagged for review.`,
    report
  };
});

/**
 * ============================================================================
 * ORCHARD & TREE MANAGEMENT <-> FINANCE & CREDIT MODULE LINKAGE FUNCTIONS
 * ============================================================================
 */

const ORCHARD_COST_COA_MAP: Record<string, { code: string; name: string }> = {
  spraying: { code: "5340", name: "Crop Protection & Agrochemicals" },
  labour: { code: "5330", name: "Direct Labour — Orchard" },
  pruning: { code: "5330", name: "Direct Labour — Orchard" },
  fertilizer: { code: "5320", name: "Fertilizer & Soil Inputs" },
  irrigation: { code: "5350", name: "Irrigation & Water Costs" },
  pest_control: { code: "5340", name: "Crop Protection & Agrochemicals" },
  equipment: { code: "5360", name: "Equipment Hire & Maintenance" },
  other: { code: "5395", name: "Other Orchard Operating Costs" }
};

/**
 * Callable: postOrchardSale
 * Enforces mandatory blockId attribution for fruit sales, auto-posts to COA 4300,
 * appends to immutable block_revenue_ledger, and atomically rolls up revenue & variance.
 */
export const postOrchardSale = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const callerUid = authContext.auth.uid;
  const callerToken = authContext.auth.token;
  const callerEmail = (callerToken.email || "").toLowerCase();

  const payload = request.data || {};
  validatePayloadFields(payload, ["blockId", "amount", "saleId"]);

  const blockId = String(payload.blockId).trim();
  const amount = Number(payload.amount);
  const saleId = String(payload.saleId).trim();
  const buyer = String(payload.buyer || payload.customerName || "Customer").trim();
  const quantity = Number(payload.quantity) || 1;
  const unitPrice = Number(payload.unitPrice) || amount;
  const productType = String(payload.productType || "fruit");
  const productName = String(payload.productName || "Fruit Harvest Produce");
  const invoiceNumber = payload.invoiceNumber ? String(payload.invoiceNumber) : undefined;
  const receiptNumber = payload.receiptNumber ? String(payload.receiptNumber) : undefined;
  const saleDate = payload.date ? String(payload.date) : new Date().toISOString().split("T")[0];

  if (!blockId) {
    throw new HttpsError("invalid-argument", "Hard Block Validation: Fruit sales require a valid Orchard Block ID (blockId). Uncategorized fruit sales are strictly forbidden.");
  }
  if (isNaN(amount) || amount <= 0) {
    throw new HttpsError("invalid-argument", "Sale amount must be a positive numeric value.");
  }

  const callerDoc = await db.collection("users_data").doc(callerUid).get();
  const callerData = callerDoc.data() || {};
  const isSuper = callerToken.role === "super_admin" || callerToken.superAdmin === true || callerEmail === "support@mabala.cloud";
  const targetTenantId = payload.tenantId ? String(payload.tenantId) : (callerData.tenantId || callerUid);

  if (!isSuper && callerUid !== targetTenantId && callerData.tenantId !== targetTenantId) {
    throw new HttpsError("permission-denied", "You do not have write access to post sales for this farm workspace.");
  }

  // Atomically update block roll-up and create append-only ledger entry
  const blockRef = db.collection("crop_cycles").doc(blockId);
  const ledgerId = `REV-ORCH-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

  const ledgerEntry = {
    id: ledgerId,
    saleId,
    blockId,
    treeGroupId: payload.treeGroupId ? String(payload.treeGroupId) : undefined,
    tenantId: targetTenantId,
    date: saleDate,
    buyer,
    quantity,
    unitPrice,
    amount,
    productType,
    productName,
    invoiceNumber,
    receiptNumber,
    coaAccountId: "4300",
    postedAt: new Date().toISOString(),
    postedBy: callerEmail || callerUid,
    timestamp: FieldValue.serverTimestamp()
  };

  const result = await db.runTransaction(async (tx) => {
    const blockSnap = await tx.get(blockRef);
    if (!blockSnap.exists) {
      throw new HttpsError("not-found", `Orchard block '${blockId}' was not found on this workspace.`);
    }

    const bData = blockSnap.data() || {};
    const projectedRevenue = Number(bData.projectedRevenue || bData.orchard?.projectedAnnualRevenue || bData.expectedRevenueProjection || 0);
    const prevRev = Number(bData.actualRevenueToDate || 0);
    const prevExp = Number(bData.actualExpensesToDate || 0);

    const actualRevenueToDate = prevRev + amount;
    const netProfitToDate = actualRevenueToDate - prevExp;
    const revenueVariancePct = projectedRevenue > 0 ? (actualRevenueToDate - projectedRevenue) / projectedRevenue : 0;

    tx.update(blockRef, {
      actualRevenueToDate,
      netProfitToDate,
      revenueVariancePct,
      lastRevenuePostedAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp()
    });

    const subLedgerRef = blockRef.collection("revenue_ledger").doc(ledgerId);
    tx.set(subLedgerRef, ledgerEntry);

    const tenantLedgerRef = db.collection("platform")
      .doc("institutions")
      .collection("institutions")
      .doc(targetTenantId)
      .collection("block_revenue_ledger")
      .doc(ledgerId);
    tx.set(tenantLedgerRef, ledgerEntry);

    return {
      actualRevenueToDate,
      actualExpensesToDate: prevExp,
      netProfitToDate,
      revenueVariancePct,
      projectedRevenue
    };
  });

  return {
    success: true,
    message: `Fruit sale of ${amount} successfully attributed and posted to Block '${blockId}'.`,
    ledgerEntry,
    ...result
  };
});

/**
 * Callable: postOrchardExpense
 * Auto-posts orchard task costs to Expense Ledger & COA atomically:
 * Maps costTaskType -> COA Account (5320-5395), appends to immutable block_expense_ledger,
 * updates block actualExpensesToDate & net profit, and returns expenseLedgerRef for bidirectional traceability.
 */
export const postOrchardExpense = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const callerUid = authContext.auth.uid;
  const callerToken = authContext.auth.token;
  const callerEmail = (callerToken.email || "").toLowerCase();

  const payload = request.data || {};
  validatePayloadFields(payload, ["blockId", "cost", "costTaskType", "description"]);

  const blockId = String(payload.blockId).trim();
  const cost = Number(payload.cost);
  const costTaskType = String(payload.costTaskType).trim().toLowerCase();
  const description = String(payload.description).trim();
  const dateIncurred = payload.dateIncurred ? String(payload.dateIncurred) : new Date().toISOString().split("T")[0];
  const taskId = payload.taskId ? String(payload.taskId) : undefined;
  const sourceModule = payload.sourceModule ? String(payload.sourceModule) : "orchard_task";

  if (!blockId) {
    throw new HttpsError("invalid-argument", "Orchard expense requires a valid Orchard Block ID (blockId).");
  }
  if (isNaN(cost) || cost <= 0) {
    throw new HttpsError("invalid-argument", "Expense cost must be a positive numeric value.");
  }

  const callerDoc = await db.collection("users_data").doc(callerUid).get();
  const callerData = callerDoc.data() || {};
  const isSuper = callerToken.role === "super_admin" || callerToken.superAdmin === true || callerEmail === "support@mabala.cloud";
  const targetTenantId = payload.tenantId ? String(payload.tenantId) : (callerData.tenantId || callerUid);

  if (!isSuper && callerUid !== targetTenantId && callerData.tenantId !== targetTenantId) {
    throw new HttpsError("permission-denied", "You do not have write access to log orchard expenses for this farm workspace.");
  }

  const coa = ORCHARD_COST_COA_MAP[costTaskType] || ORCHARD_COST_COA_MAP.other;
  const expenseLedgerRef = `EXP-ORCH-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

  const ledgerEntry = {
    id: expenseLedgerRef,
    taskId,
    blockId,
    treeGroupId: payload.treeGroupId ? String(payload.treeGroupId) : undefined,
    tenantId: targetTenantId,
    date: dateIncurred,
    costTaskType,
    description,
    amount: cost,
    coaCode: coa.code,
    coaAccountName: coa.name,
    sourceModule,
    expenseId: expenseLedgerRef,
    postedAt: new Date().toISOString(),
    postedBy: callerEmail || callerUid,
    timestamp: FieldValue.serverTimestamp()
  };

  const blockRef = db.collection("crop_cycles").doc(blockId);

  const result = await db.runTransaction(async (tx) => {
    const blockSnap = await tx.get(blockRef);
    if (!blockSnap.exists) {
      throw new HttpsError("not-found", `Orchard block '${blockId}' was not found on this workspace.`);
    }

    const bData = blockSnap.data() || {};
    const prevRev = Number(bData.actualRevenueToDate || 0);
    const prevExp = Number(bData.actualExpensesToDate || 0);

    const actualExpensesToDate = prevExp + cost;
    const netProfitToDate = prevRev - actualExpensesToDate;

    tx.update(blockRef, {
      actualExpensesToDate,
      netProfitToDate,
      lastExpensePostedAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp()
    });

    const subLedgerRef = blockRef.collection("expense_ledger").doc(expenseLedgerRef);
    tx.set(subLedgerRef, ledgerEntry);

    const tenantLedgerRef = db.collection("platform")
      .doc("institutions")
      .collection("institutions")
      .doc(targetTenantId)
      .collection("block_expense_ledger")
      .doc(expenseLedgerRef);
    tx.set(tenantLedgerRef, ledgerEntry);

    // If originating taskId provided, write expenseLedgerRef back onto task for bidirectional traceability
    if (taskId) {
      const taskRef = blockRef.collection("tasks").doc(taskId);
      tx.set(taskRef, {
        expenseLedgerRef,
        coaCode: coa.code,
        updatedAt: FieldValue.serverTimestamp()
      }, { merge: true });
    }

    return {
      actualRevenueToDate: prevRev,
      actualExpensesToDate,
      netProfitToDate
    };
  });

  return {
    success: true,
    message: `Cost task of ${cost} (${coa.name}) posted to Block '${blockId}'.`,
    expenseLedgerRef,
    ledgerEntry,
    ...result
  };
});

/**
 * Callable: claimSession
 * Enforces Single-Active-Session architecture:
 * 1. Creates/updates sessions/{uid} with activeSessionId, deviceId, serverTimestamp.
 * 2. Revokes refresh tokens so previous devices cannot refresh auth.
 * 3. Sets custom claims with active sessionId for rule evaluation.
 */
export const claimSession = onCall(async (request) => {
  const authContext = verifyAuthContext(request);
  const uid = authContext.auth.uid;
  const deviceId = (request.data && request.data.deviceId) ? String(request.data.deviceId) : "unknown_device";
  const deviceInfo = (request.data && request.data.deviceInfo) ? String(request.data.deviceInfo) : "Web Browser";
  
  // Generate cryptographically unique session UUID
  const newSessionId = `${Date.now()}-${Math.random().toString(36).substring(2, 12)}-${Math.random().toString(36).substring(2, 12)}`;

  // 1. In a Firestore transaction on sessions/{uid}
  await db.runTransaction(async (tx) => {
    const sessionRef = db.doc(`sessions/${uid}`);
    tx.set(sessionRef, {
      activeSessionId: newSessionId,
      deviceId,
      deviceInfo,
      loginAt: FieldValue.serverTimestamp(),
      lastSeenAt: FieldValue.serverTimestamp()
    }, { merge: true });
  });

  // 2. Revoke refresh tokens
  try {
    await auth.revokeRefreshTokens(uid);
  } catch (err: any) {
    console.warn(`[claimSession CloudFunction] Revocation warning for ${uid}:`, err?.message);
  }

  // 3. Set custom user claims with active sessionId
  try {
    const user = await auth.getUser(uid);
    const existingClaims = user.customClaims || {};
    await auth.setCustomUserClaims(uid, {
      ...existingClaims,
      sessionId: newSessionId
    });
  } catch (err: any) {
    console.warn(`[claimSession CloudFunction] Set claim warning for ${uid}:`, err?.message);
  }

  return {
    success: true,
    sessionId: newSessionId,
    activeSessionId: newSessionId,
    deviceId
  };
});

// =========================================================================
// UNIFIED LOAN MANAGEMENT CALLABLES (Agricultural & Enterprise Financing)
// =========================================================================
export {
  originateLoanApplication,
  disburseLoanCallable,
  repayLoanCallable
} from "./modules/loans/loanCallables";




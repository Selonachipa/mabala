# provisionWorkspace() Transaction Boundary Sequence Diagram

This document illustrates the transactional boundary and step-by-step interactions between the core services during the `provisionWorkspace` flow, ensuring atomicity, consistency, isolation, and durability (ACID) across all tenant initialization steps.

```mermaid
sequenceDiagram
    autonumber
    actor Client as Client / Caller
    participant Index as index.ts (Callable Node)
    participant Db as Firestore Engine (db.runTransaction)
    participant ProvSvc as ProvisioningService
    participant TenantRep as TenantRepository (TenantService)
    participant UserRep as UserRepository (UserService)
    participant BillSvc as BillingService (CreditsService)
    participant AuditRep as AuditLogRepository

    Client->>Index: Call provisionWorkspace(farmName, primaryContact, selectedTier, etc.)
    Note over Index: Run validation middleware<br/>(verifyAuthContext & validatePayloadFields)
    
    Index->>Db: Start db.runTransaction()
    activate Db
    
    Db->>ProvSvc: Execute inside Transaction Context
    activate ProvSvc
    
    %% Idempotency Check
    ProvSvc->>UserRep: getUserInTransaction(transaction, userId)
    UserRep-->>ProvSvc: Return UserProfile (or null)
    
    alt User already has tenantId assigned (Idempotency Case)
        ProvSvc-->>Db: Return existing workspace info immediately (Abort/Commit)
        Db-->>Index: Return success (Idempotent bypass)
        Index-->>Client: 200 OK (Workspace already provisioned)
    else User is new signup / No tenantId assigned
        
        %% Step 1: Create Tenant / Institution
        Note over ProvSvc, TenantRep: [TenantService Interaction]
        ProvSvc->>TenantRep: createTenantInTransaction(transaction, tenantId, TenantDocument)
        Note over TenantRep: Write platform/institutions/{tenantId}
        
        %% Step 2: Initialize Billing Account
        ProvSvc->>TenantRep: createBillingAccountInTransaction(transaction, tenantId, BillingAccountDocument)
        Note over TenantRep: Write billing_accounts/global
        
        %% Step 3: Update / Create User Profile & Primay Farm
        Note over ProvSvc, UserRep: [UserService & MembershipService Interaction]
        ProvSvc->>UserRep: updateUserInTransaction(transaction, userId, { tenantId, role: "Farm Owner" })
        Note over UserRep: Link user to tenant and assign Owner role
        
        %% Step 4: Allocate Initial SMS Credits
        Note over ProvSvc, BillSvc: [CreditsService Interaction]
        ProvSvc->>BillSvc: allocateCreditsInTransaction(transaction, tenantId, 100, "Onboarding Sign-up Bonus")
        Note over BillSvc: Write smsCreditBalance and credit ledger
        
        %% Step 5: Audit Logging
        ProvSvc->>AuditRep: writeAuditLogInTransaction(transaction, { action: "PROVISION", userId, tenantId })
        Note over AuditRep: Log onboarding trail inside same transaction boundary
        
        ProvSvc-->>Db: Transaction block operations succeeded
        deactivate ProvSvc
        
        Db->>Db: Commit Transaction (Atomically write all mutations)
        Db-->>Index: Return Transaction Commit Result
        deactivate Db
        
        Index-->>Client: 200 OK (Workspace Provisioned Successfully)
    end
```

## Architectural Design Highlights

1. **Transactional Atomicity (All-or-Nothing)**:
   All operations—tenant document creation, billing initialization, user profile association, free SMS credits allocation, and audit trails—are performed inside a single, unified Firestore transaction. If any service fails (e.g., credit allocation fails or a validation is breached), Firestore automatically aborts all mutations and rolls back the database to its pre-transaction state.

2. **Idempotency**:
   Concurrency is safe. The transaction first queries the user record inside the transaction lock. If concurrent signups hit the endpoint, the first transaction locks the user document and writes the workspace, while subsequent transactions read the updated user profile and abort cleanly, returning the existing tenant information rather than duplicating records.

3. **Separation of Concerns**:
   - **TenantRepository (TenantService)**: Focuses strictly on creating the institutional boundary and the billing details.
   - **UserRepository (UserService)**: Manages user account linkage and workspace-specific attributes.
   - **BillingService (CreditsService)**: Handles SMS currency allocation, ensuring proper double-entry compliance.
   - **AuditLogRepository**: Persists historical non-repudiation logging for workspace creation events.

import re

with open("src/components/WelcomeScreen.tsx", "r", encoding="utf-8") as f:
    text = f.read()

# Let's inspect the activeTab === "login" block
print("Replacing login form...")

# 1. Update Green Mabala Branding
text = re.sub(
    r'<span className="text-2xl sm:text-\[28px\] font-black tracking-tight text-\[#[0-9a-fA-F]+\] lowercase font-sans">\s*mabala<span className="text-\[#[0-9a-fA-F]+\]">\.',
    '<span className="text-2xl sm:text-[28px] font-black tracking-tight text-[#15803d] lowercase font-sans">\n                mabala<span className="text-[#22c55e]">.',
    text
)

# 2. Update Login fields
# Replace Email label & input
email_pattern = r'<label className="text-\[11px\] font-bold text-slate-500 uppercase tracking-wider block">Email, Account ID, Phone or NRC</label>\s*<input\s+type="text"\s+placeholder=\{[^\}]+\}\s+value=\{loginEmail\}'
email_replacement = """<label className="text-xs font-semibold text-slate-700 block mb-1.5">
                        <span className="text-rose-500 font-bold mr-0.5">*</span> Email
                      </label>
                      <input
                        type="text"
                        placeholder="deepvaleyfarm@gmail.com"
                        value={loginEmail}"""
text = re.sub(email_pattern, email_replacement, text)

# Replace login input className
text = text.replace(
    'className="w-full border rounded-lg px-3 py-2 text-sm bg-slate-50/50 outline-none focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-500/10 transition-all mt-1 font-medium"',
    'className="w-full bg-[#f0f4ff] border border-[#dbe4f9] rounded-lg px-3.5 py-2.5 text-sm text-slate-900 outline-none focus:bg-white focus:border-[#134094] focus:ring-2 focus:ring-[#134094]/10 transition-all font-normal placeholder-slate-400"'
)

# Replace password section
old_pass_section = """                    <div>
                      <div className="flex justify-between items-center">
                        <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Password</label>
                        <button
                          type="button"
                          onClick={() => {
                            setRecoveryEmail(loginEmail);
                            setRecoverySuccess(false);
                            setRecoveryError("");
                            setRecoveryMessage("");
                            setShowRecoveryModal(true);
                          }}
                          className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 hover:underline cursor-pointer bg-transparent border-none p-0"
                          id="forgot-credentials-btn"
                        >
                          Forgot Username or Password?
                        </button>
                      </div>
                      <div className="relative mt-1">
                        <input
                          type={showLoginPassword ? "text" : "password"}
                          placeholder="••••••••"
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          required
                          className="w-full border rounded-lg pl-3 pr-10 py-2 text-sm bg-slate-50/50 outline-none focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-500/10 transition-all font-medium"
                        />
                        <button
                          type="button"
                          onClick={() => setShowLoginPassword(!showLoginPassword)}
                          className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 focus:outline-none"
                        >
                          {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>"""

new_pass_section = """                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1.5">
                        <span className="text-rose-500 font-bold mr-0.5">*</span> Password
                      </label>
                      <div className="relative">
                        <input
                          type={showLoginPassword ? "text" : "password"}
                          placeholder="••••••••••••"
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          required
                          className="w-full bg-[#f0f4ff] border border-[#dbe4f9] rounded-lg pl-3.5 pr-10 py-2.5 text-sm text-slate-900 outline-none focus:bg-white focus:border-[#134094] focus:ring-2 focus:ring-[#134094]/10 transition-all font-normal placeholder-slate-400"
                        />
                        <button
                          type="button"
                          onClick={() => setShowLoginPassword(!showLoginPassword)}
                          className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 focus:outline-none cursor-pointer"
                        >
                          {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      <div className="flex justify-end mt-2">
                        <span className="text-xs text-slate-500">
                          Forgot password?{" "}
                          <button
                            type="button"
                            onClick={() => {
                              setRecoveryEmail(loginEmail);
                              setRecoverySuccess(false);
                              setRecoveryError("");
                              setRecoveryMessage("");
                              setShowRecoveryModal(true);
                            }}
                            className="text-[#134094] hover:underline font-semibold cursor-pointer bg-transparent border-none p-0"
                            id="forgot-credentials-btn"
                          >
                            Reset
                          </button>
                        </span>
                      </div>
                    </div>"""

if old_pass_section in text:
    text = text.replace(old_pass_section, new_pass_section)
    print("Replaced password section!")
else:
    print("Old pass section not matched directly")

# Update login button
old_button = """                    <button
                      type="submit"
                      disabled={isLoggingIn || isSendingOtp}
                      className="w-full py-2.5 px-4 bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-300 text-white rounded-lg text-sm font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 mt-2 cursor-pointer disabled:cursor-not-allowed"
                    >
                      {isLoggingIn ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin shrink-0" />
                          <span>Logging you in...</span>
                        </>
                      ) : (
                        <>
                          <LogIn className="w-4 h-4" />
                          <span>Login Securely</span>
                        </>
                      )}
                    </button>"""

new_button = """                    <button
                      type="submit"
                      disabled={isLoggingIn || isSendingOtp}
                      className="w-full py-2.5 px-4 bg-[#134094] hover:bg-[#0c2960] active:scale-[0.99] disabled:bg-slate-300 text-white rounded-lg text-sm font-semibold shadow-xs transition-all flex items-center justify-center gap-2 mt-4 cursor-pointer disabled:cursor-not-allowed"
                    >
                      {isLoggingIn ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin shrink-0" />
                          <span>Signing in...</span>
                        </>
                      ) : (
                        <span>Sign in</span>
                      )}
                    </button>

                    {/* Don't have an account? Sign up Footer */}
                    <div className="text-center mt-5 text-xs text-slate-600">
                      <span>Don't have an account? </span>
                      <button
                        type="button"
                        onClick={() => {
                          setActiveTab("register");
                          setFormError("");
                        }}
                        className="text-[#134094] hover:underline font-semibold cursor-pointer bg-transparent border-none p-0"
                      >
                        Sign up
                      </button>
                    </div>"""

if old_button in text:
    text = text.replace(old_button, new_button)
    print("Replaced login button!")

with open("src/components/WelcomeScreen.tsx", "w", encoding="utf-8") as f:
    f.write(text)

print("Saved updates!")

# Mabala Sub-User Workspace Access and Real-Time Collaboration

## 1. Purpose and non-negotiable invariants

This specification defines sub-user provisioning and simultaneous collaboration for one farm workspace. It applies to farm owners and users invited by those owners.

The system MUST preserve these invariants:

1. A workspace has exactly one canonical `tenantId`. In the current system this is the owner's Firebase Auth UID, and that value may be retained during migration.
2. A sub-user has one Firebase Auth UID but no tenant of their own. They cannot provision a workspace, select a tenant, or access another tenant by changing a request payload, URL, local storage value, or client state.
3. Every read, write, query, callable function, API response, listener, storage path, and UI route is evaluated against the authenticated user's resolved `tenantId` and membership.
4. All farm users in one tenant read the same workspace documents. Module permissions limit operations, not the underlying tenant boundary.
5. Every accepted mutation is durably written to Firestore before the UI treats it as committed. Offline cache is a recovery mechanism, not the source of truth.
6. Realtime listeners are scoped to one tenant path and are removed when the user changes tenant context or signs out.
7. Owner and sub-user changes converge to the same document state. Concurrent edits use transactions, atomic updates, or an explicit conflict policy; last-write-wins must not silently overwrite financial or inventory mutations.

## 2. Existing repository alignment and required correction

The current repository already provides useful building blocks:

- `functions/src/services/ProvisioningService.ts` derives `tenantId` from the owner UID and provisions the owner workspace.
- `functions/src/index.ts` exposes an `inviteUser` callable, but its current input model is role-oriented and does not yet satisfy per-module read/read-write permissions.
- `functions/src/welcomeEmail.functions.ts` queues email through the `mail` collection and provides the login URL and temporary password template mechanism.
- `src/firebase.ts` uses browser-local Auth persistence and Firestore.
- `src/app/persistence.ts` provides local recovery snapshots.
- Existing operational data is found under `users_data/{tenantId}` and `users_data/{tenantId}/modules/{moduleId}` in parts of the application.

Before enabling this feature, the current broad Firestore rules must be replaced. In particular, `allow read, write: if true` under `users_data`, and unauthenticated fallbacks such as `request.auth == null`, are incompatible with this specification. A rule that permits authenticated users to read all `users_data` also defeats tenant isolation even if the UI hides those records.

The target architecture should use `tenants/{tenantId}` as the authorization root and preserve `users_data/{tenantId}` only as a compatibility data path during migration. Do not create a workspace at `users_data/{subUserUid}`.

## 3. Canonical data model

### 3.1 Tenant and membership documents

```text
tenants/{tenantId}
  ownerUid: string
  name: string
  status: "active" | "suspended" | "deleted"
  schemaVersion: number
  createdAt: timestamp
  updatedAt: timestamp

tenants/{tenantId}/members/{uid}
  tenantId: string
  uid: string
  email: string
  displayName: string
  role: "owner" | "sub_user"
  status: "active" | "pending" | "suspended" | "revoked"
  permissions: {
    crops: "none" | "read" | "read_write",
    finance: "none" | "read" | "read_write",
    inputs: "none" | "read" | "read_write",
    equipment: "none" | "read" | "read_write",
    employees: "none" | "read" | "read_write",
    settings: "none" | "read" | "read_write"
  }
  mustChangePassword: boolean
  invitedByUid: string
  invitedAt: timestamp
  acceptedAt: timestamp | null
  revokedAt: timestamp | null
  updatedAt: timestamp

tenants/{tenantId}/invitations/{invitationId}
  tenantId: string
  emailLower: string
  displayName: string
  permissions: map<string, string>
  status: "pending" | "accepted" | "revoked" | "expired"
  expiresAt: timestamp
  createdByUid: string
  targetUid: string | null
  mailId: string | null
```

The owner is also represented in `members/{ownerUid}`. This makes authorization queries and audit reporting uniform. The owner receives full access to all active modules and cannot be reduced through the sub-user screen.

### 3.2 Shared workspace data

Use tenant-scoped paths for new data:

```text
tenants/{tenantId}/workspace/summary
tenants/{tenantId}/modules/{moduleId}
tenants/{tenantId}/modules/{moduleId}/records/{recordId}
tenants/{tenantId}/settings/{settingId}
tenants/{tenantId}/audit/{auditId}
```

Every document must include `tenantId`, `schemaVersion`, `createdAt`, `updatedAt`, `createdBy`, and `updatedBy` where applicable. The path tenant ID and stored tenant ID must match. A client must never be allowed to supply an arbitrary tenant ID to select its workspace.

During migration, existing `users_data/{tenantId}` and its `modules` subcollection may be read through a server-side repository, but all new writes should have one canonical destination. The migration must be idempotent and preserve document IDs, timestamps, and audit history.

### 3.3 User profile and password state

Store non-secret user metadata in the membership document and a user profile document. Never store a password, password hash, or temporary password in Firestore, local storage, logs, email audit records, or analytics.

Firebase Auth owns credentials. `mustChangePassword` is an application state flag and must be cleared only after a successful authenticated password update. A temporary password is single-use in policy even though Firebase Auth cannot enforce single-use credentials by itself: on first sign-in, require password change before loading workspace data, then revoke refresh tokens if the flow is abandoned or reset.

## 4. Authorization contract

### 4.1 Resolved identity

At sign-in, resolve:

```text
Firebase Auth UID -> active membership lookup -> tenantId, role, module permissions
```

The client may cache the resolved membership for rendering, but Firestore rules and callable functions remain authoritative. Custom claims may contain a small `tenantId` and `role` hint, but membership status and module permissions must be checked from server-controlled data or a refreshed claim. Claims are not a replacement for rules and can be stale until the ID token refreshes.

For users with a single farm workspace, the server must reject any requested tenant ID different from the membership tenant ID. The safest callable API accepts no client-supplied tenant ID and derives it from the authenticated UID.

### 4.2 Permission semantics

`none` means the module is not visible and all reads and writes fail.

`read` permits document reads and realtime listeners for that module, but rejects create, update, delete, and write transactions.

`read_write` permits reads and writes subject to field validation, business rules, and tenant matching.

The owner has `read_write` access to every enabled module. Module assignment must be validated against the platform module registry and the tenant's active modules; an owner cannot grant a module the tenant does not have.

### 4.3 Reference Firestore rules shape

Rules should follow this pattern and be expanded explicitly for each collection. Avoid a catch-all rule that grants access based only on authentication.

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function signedIn() {
      return request.auth != null;
    }

    function member(tenantId) {
      return signedIn() &&
        exists(/databases/$(database)/documents/tenants/$(tenantId)/members/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/tenants/$(tenantId)/members/$(request.auth.uid)).data.status == "active";
    }

    function owner(tenantId) {
      return member(tenantId) &&
        get(/databases/$(database)/documents/tenants/$(tenantId)/members/$(request.auth.uid)).data.role == "owner";
    }

    function permission(tenantId, moduleId, level) {
      return member(tenantId) &&
        get(/databases/$(database)/documents/tenants/$(tenantId)/members/$(request.auth.uid)).data.permissions[moduleId] in
          (level == "read" ? ["read", "read_write"] : ["read_write"]);
    }

    function validTenantOnCreate(tenantId) {
      return request.resource.data.tenantId == tenantId;
    }

    function unchangedTenantOnUpdate(tenantId) {
      return resource.data.tenantId == tenantId && request.resource.data.tenantId == tenantId;
    }

    match /tenants/{tenantId} {
      allow get: if member(tenantId);
      allow update: if owner(tenantId) && request.resource.data.ownerUid == resource.data.ownerUid;
      allow create, delete: if false;

      match /members/{uid} {
        allow get, list: if member(tenantId);
        allow create, update, delete: if owner(tenantId);
      }

      match /modules/{moduleId} {
        allow read: if permission(tenantId, moduleId, "read");
        allow create: if permission(tenantId, moduleId, "write") && validTenantOnCreate(tenantId);
        allow update: if permission(tenantId, moduleId, "write") && unchangedTenantOnUpdate(tenantId);
        allow delete: if permission(tenantId, moduleId, "write");
      }

      match /modules/{moduleId}/records/{recordId} {
        allow read: if permission(tenantId, moduleId, "read");
        allow create: if permission(tenantId, moduleId, "write") && validTenantOnCreate(tenantId);
        allow update: if permission(tenantId, moduleId, "write") && unchangedTenantOnUpdate(tenantId);
        allow delete: if permission(tenantId, moduleId, "write");
      }

      match /settings/{settingId} {
        allow read: if member(tenantId);
        allow write: if owner(tenantId);
      }

      match /audit/{auditId} {
        allow read: if member(tenantId);
        allow create: if member(tenantId);
        allow update, delete: if false;
      }
    }

    match /tenants/{tenantId}/members/{uid}/private/{documentId} {
      allow read, write: if signedIn() && request.auth.uid == uid;
    }
  }
}
```

The exact rules must also reject tenant changes, protect immutable fields, validate allowed module IDs, and prevent clients from writing membership roles or permissions. Membership mutations should be callable functions using the Admin SDK after authorization checks, followed by a token refresh or membership listener update.

## 5. Owner workflow: create sub-user

### Request

The owner enters full name, email, selected modules, and a read-only/read-write level for each selected module. The UI may generate a temporary password, but the server must generate or validate it and must never trust a client-provided weak password.

### Server transaction

Implement `createSubUser` as a callable function or authenticated server endpoint:

1. Verify authentication and verified email.
2. Resolve the caller's tenant from the owner membership. Ignore or reject a caller-supplied `tenantId`.
3. Require caller role `owner`.
4. Validate full name, normalized email, module IDs, permission values, tenant active modules, password strength, and invitation expiry.
5. Reject an existing active membership for the email. Define a deliberate policy for an email already attached to another tenant; never silently move it.
6. Create the Firebase Auth user with a random temporary password and `disabled: false`. Set `displayName` and email verification policy.
7. In one Firestore transaction, create `members/{newUid}`, `invitations/{invitationId}`, and an audit event. Set `mustChangePassword: true`.
8. Set a minimal custom claim such as `{ tenantId, role: "sub_user" }` only after the membership write succeeds.
9. Queue the welcome email only after provisioning succeeds. Include the login email, temporary password, login URL, farm/workspace name, and an explicit first-login password-change instruction.
10. If email queueing fails, retain the account and invitation in `emailStatus: "failed"`, expose a secure resend action to the owner, and never roll back a valid Auth account by deleting it without an explicit compensating transaction.

The response must return only safe metadata: UID, display name, email, tenant ID, selected permissions, invitation ID, and email delivery status. Do not return the password in the callable response.

### Welcome email

Extend `sendWelcomeEmailOnSignup` or add a dedicated `sendSubUserWelcomeEmail` template. The email must contain:

- Login email
- Temporary password, if the chosen onboarding policy sends it by email
- `https://mabala.cloud/login` or the configured login URL
- A clear statement that the password must be changed before workspace use
- The farm/workspace name and support contact

Because credentials in email are inherently sensitive, the preferred production variant is a one-time password setup link generated by Firebase Auth. If the product requirement mandates the temporary password, use short expiry, rate limiting, email redaction in logs, and a forced change immediately after authentication.

## 6. Sub-user first login and ongoing session

1. Authenticate with Firebase Auth using the supplied email and temporary credential.
2. Resolve the active membership by UID. If no active membership exists, sign out and show an access-denied state.
3. If `mustChangePassword` is true, show only the password-change flow. Do not initialize tenant listeners or hydrate workspace data before the change succeeds.
4. Call `updatePassword`, then update the membership flag through a trusted callable function and refresh the ID token.
5. Resolve the tenant context from membership, never from URL or local storage.
6. Attach listeners only to the resolved tenant paths and only for modules with `read` or `read_write` access.
7. On sign-out, revoke/clear client listeners, clear tenant-scoped memory, and remove or expire local caches for that tenant.

The existing browser-local Auth persistence supports refreshes and device continuity at the credential level. Firestore offline persistence should be enabled and explicitly monitored; `src/app/persistence.ts` local snapshots must be keyed by `tenantId` and user-independent shared data must not be mixed with another tenant's cache.

## 7. Real-time synchronization and durability

### Listener strategy

Use `onSnapshot` against tenant-scoped documents or queries. Each listener must:

- Be created after membership resolution.
- Use a stable path containing the resolved `tenantId`.
- Be unsubscribed on auth change, tenant change, module permission change, and component disposal.
- Distinguish `fromCache` snapshots from server-acknowledged snapshots.
- Surface pending writes so users know when a change is still offline or awaiting acknowledgement.

### Write strategy

For ordinary independent records, use `addDoc`/`setDoc` with server timestamps and an idempotency key. For counters, balances, inventory, credits, and other coupled values, use Firestore transactions or atomic field transforms. Include `updatedBy` and a client-generated `mutationId` so retries cannot duplicate effects.

For the current array-heavy `users_data/{tenantId}` model, do not replace the whole workspace array for every keystroke. Split high-conflict collections into records under tenant/module paths. Until migrated, serialize updates through a transaction with a revision field and reject stale revisions rather than silently overwriting another user's edit.

### Offline and interruption behavior

- Enable Firestore offline persistence where supported and handle multi-tab persistence errors.
- Treat Firestore's local mutation queue as the primary offline queue; local storage is a backup for UI recovery only.
- On reconnect, let Firestore retry writes, then reconcile rejected writes and permission changes.
- Use a tenant-scoped backup key such as `mabala_workspace_backup_{tenantId}`. Never use a global key for tenant data.
- On reload, hydrate from Firestore cache/server and reconcile pending local changes. Do not create a new workspace because a document is temporarily unavailable.
- Keep audit records append-only and include `mutationId` for replay diagnostics.

## 8. API and repository implementation guide

Add a focused service boundary rather than spreading access checks through React components:

```text
functions/src/services/SubUserService.ts
functions/src/repositories/MembershipRepository.ts
functions/src/middleware/tenantContext.ts
functions/src/utils/modulePermissions.ts
src/services/workspaceSyncService.ts
src/services/subUserService.ts
src/types/access.ts
```

Recommended callable operations:

```text
createSubUser({ fullName, email, permissions })
updateSubUserPermissions({ uid, permissions })
revokeSubUser({ uid })
resendSubUserWelcome({ uid })
listTenantMembers()
changeInitialPassword()
```

Each operation derives the tenant from the caller and records an immutable audit event. `listTenantMembers` returns only members from that tenant. `revokeSubUser` must mark the membership revoked, revoke Firebase refresh tokens, and ensure listeners fail on the next read. Permission changes must take effect immediately in rules/server checks, even if the client UI has not refreshed.

## 9. Security and privacy requirements

- Normalize emails to lowercase for uniqueness checks, but preserve display casing separately.
- Rate-limit create, resend, password reset, and login-related operations.
- Do not disclose whether an email belongs to another tenant in error messages.
- Never authorize from `request.data.tenantId`, local storage, a query parameter, or a document field supplied by the client.
- Validate every API response to prevent a server repository from returning another tenant's document.
- Use tenant-specific Storage paths and Storage rules if files are added.
- Redact passwords, reset links, Auth tokens, and private email content from logs and audit documents.
- Make audit logs append-only, tenant-scoped, and attributable to the authenticated UID.
- Review all existing broad rules, including platform, backup, payment, activity, and user data collections, because a permissive adjacent collection can still leak tenant metadata.
- Require an explicit platform-admin access-node flow for support access. It must be time-limited, tenant-scoped, audited, and unavailable to ordinary sub-users.

## 10. Migration and rollout sequence

### Phase 0: isolation gate

1. Inventory every Firestore path read or written by the frontend, functions, Express server, backup jobs, and listeners.
2. Add the Firebase Emulator Suite rules test harness.
3. Replace public/unauthenticated rules and deploy rules separately from feature UI.
4. Confirm existing owner sign-in can still resolve its own tenant.

### Phase 1: membership foundation

1. Backfill `tenants/{ownerUid}` and `members/{ownerUid}` for existing owners.
2. Add `tenantId` and schema metadata to legacy workspace documents where absent.
3. Implement `MembershipRepository`, `tenantContext`, and rules tests.

### Phase 2: sub-user provisioning

1. Implement the callable transaction and Auth account creation.
2. Add welcome and resend email templates with delivery audit status.
3. Add owner UI for module and permission selection.
4. Add forced password-change gate.

### Phase 3: synchronized workspace

1. Move high-conflict module records to tenant-scoped record paths.
2. Add tenant-scoped listeners and pending-write indicators.
3. Add mutation IDs, optimistic UI rollback, retry, and stale revision handling.

### Phase 4: enforcement and cleanup

1. Migrate reads and writes away from owner-only `users_data` assumptions.
2. Remove compatibility rules and paths after two verified production backup cycles.
3. Revoke or migrate any existing accounts whose tenant ownership is ambiguous.

## 11. Acceptance criteria

### Provisioning

- An owner can create a sub-user with full name, email, selected modules, and per-module read/read-write permissions.
- Duplicate active invitations are idempotent and do not create duplicate Auth users.
- A successful creation produces membership, invitation, audit, and email queue records.
- The email contains the required credentials/login/change-password instructions.

### Isolation

- A sub-user cannot read, list, listen to, write, or infer documents from another tenant.
- A sub-user cannot call workspace provisioning or create a second workspace.
- Changing `tenantId` in a request, URL, local storage, or document payload never changes access.
- A revoked user loses access after token refresh and cannot continue a listener-backed session.

### Permissions

- `none` modules are absent from the UI and denied by rules/server.
- `read` modules can be read and synchronized but all mutations are denied.
- `read_write` modules permit valid mutations and audit the actor.
- Owner and sub-user see the same authorized records and settings in a shared tenant.

### Durability and collaboration

- Two authenticated users editing the same tenant observe each other's accepted changes without refresh.
- Refresh, logout/login, reconnect, and device change preserve acknowledged data.
- Offline accepted mutations retry after reconnect or show a durable conflict/error state; they are never silently dropped.
- Financial, inventory, and counter updates remain correct under concurrent writes.

## 12. Required automated tests

Use the Firestore Emulator and Firebase Auth test users. At minimum, add:

1. Owner can create an invitation and sub-user membership only for their own tenant.
2. Sub-user cannot create a tenant or access `tenants/{otherTenantId}`.
3. Cross-tenant `get`, `list`, query, listener, create, update, and delete operations are denied.
4. Module permission matrix covers none/read/read-write for every registered module.
5. Client-supplied tenant IDs are ignored or rejected by every callable.
6. Revocation blocks future reads and writes and refresh-token sessions are revoked.
7. Forced password change blocks workspace hydration until successful.
8. Duplicate create retries return the original invitation without duplicate Auth or email records.
9. Concurrent transaction updates preserve balances, counters, and inventory quantities.
10. Offline/reconnect tests verify pending writes, retry, conflict reporting, and tenant-scoped cache keys.
11. API contract tests confirm no response contains another tenant's document or membership.
12. Rules tests prove public, unauthenticated, and stale-claim access is denied.

The feature is production-ready only when the isolation suite passes against deployed rules, not just when the UI hides unauthorized modules.
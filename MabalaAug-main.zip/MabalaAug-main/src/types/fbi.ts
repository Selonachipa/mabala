export type FbiGranularity = "daily" | "weekly" | "monthly" | "yearly";

export interface FbiPeriod {
  type: FbiGranularity;
  key: string; // e.g. "2026-08-26", "2026-W34", "2026-08", "2026"
  start: string; // ISO string
  end: string;   // ISO string
  label?: string; // e.g. "August 2026"
}

export type FbiDomainKey = 
  | "revenue"
  | "expenses"
  | "cropProduction"
  | "livestockProduction"
  | "feedingCosts"
  | "labourCosts"
  | "fertilizerChemicalCosts"
  | "landUtilization"
  | "investments"
  | "creditFinancing"
  | "cashWallet"
  | "profitability";

export interface FbiDomainBase {
  total: number;
  byDimension: Record<string, number>;
  deltaPriorPeriodPct: number;
  deltaYoyPct: number;
}

export interface FbiRevenueDomain extends FbiDomainBase {
  cashSales: number;
  invoiceSales: number;
  contractSales: number;
  topStreams?: Array<{ name: string; amount: number; percentage: number }>;
}

export interface FbiExpensesDomain extends FbiDomainBase {
  opex: number;
  capex: number;
  costPerHectare: number;
  topCategories?: Array<{ name: string; amount: number; percentage: number }>;
}

export interface FbiCropProductionDomain extends FbiDomainBase {
  totalYieldKg: number;
  yieldPerHectare: number;
  activeHectares: number;
  lossKg: number;
  averagePricePerKg: number;
  byCrop?: Record<string, { yieldKg: number; hectares: number; revenueZmw: number }>;
}

export interface FbiLivestockProductionDomain extends FbiDomainBase {
  headCount: number;
  mortalityRatePct: number;
  totalWeightKg: number;
  fcr: number; // Feed Conversion Ratio
  averageDailyGainKg: number;
  bySpecies?: Record<string, { headCount: number; mortalityRatePct: number; avgWeightKg: number }>;
}

export interface FbiFeedingCostsDomain extends FbiDomainBase {
  totalCost: number;
  feedCostPerKgGain: number;
  feedConsumedKg: number;
  commercialFeedCost: number;
  onFarmFeedCost: number;
}

export interface FbiLabourCostsDomain extends FbiDomainBase {
  permanentWages: number;
  casualWages: number;
  costPerHectare: number;
  costPerHead: number;
  activeWorkers: number;
}

export interface FbiFertilizerChemicalCostsDomain extends FbiDomainBase {
  fertilizerTotal: number;
  chemicalTotal: number;
  costPerHectare: number;
}

export interface FbiLandUtilizationDomain extends FbiDomainBase {
  totalHectares: number;
  cultivatedHectares: number;
  orchardHectares: number;
  pastureHectares: number;
  infrastructureHectares: number;
  utilizationRatePct: number;
}

export interface FbiInvestmentsDomain extends FbiDomainBase {
  totalCapex: number;
  machineryEquipment: number;
  infrastructure: number;
  biologicalAssets: number;
}

export interface FbiCreditFinancingDomain extends FbiDomainBase {
  totalBorrowed: number;
  principalRepaid: number;
  interestPaid: number;
  outstandingBalance: number;
  debtServiceCoverageRatio: number;
}

export interface FbiCashWalletDomain extends FbiDomainBase {
  inflows: number;
  outflows: number;
  netCashFlow: number;
  endingBalance: number;
}

export interface FbiProfitabilityDomain extends FbiDomainBase {
  grossProfit: number;
  grossMarginPct: number;
  netProfit: number;
  netMarginPct: number;
  ebitda: number;
  returnOnAssetsPct: number;
}

export interface FbiDomains {
  revenue: FbiRevenueDomain;
  expenses: FbiExpensesDomain;
  cropProduction: FbiCropProductionDomain;
  livestockProduction: FbiLivestockProductionDomain;
  feedingCosts: FbiFeedingCostsDomain;
  labourCosts: FbiLabourCostsDomain;
  fertilizerChemicalCosts: FbiFertilizerChemicalCostsDomain;
  landUtilization: FbiLandUtilizationDomain;
  investments: FbiInvestmentsDomain;
  creditFinancing: FbiCreditFinancingDomain;
  cashWallet: FbiCashWalletDomain;
  profitability: FbiProfitabilityDomain;
}

export interface FbiInsightDriver {
  dimension: string;
  impact: "positive" | "negative" | "neutral";
  detail: string;
  attributionPct?: number;
}

export interface FbiInsight {
  headline: string;
  summary: string;
  drivers: FbiInsightDriver[];
  generatedAt: string;
  recommendations: string[];
}

export interface FbiNodeRollup {
  id?: string;
  tenantId: string;
  farmNodeId: string;
  farmNodeName?: string;
  period: FbiPeriod;
  computedAt: string;
  domains: FbiDomains;
  fbiInsight?: FbiInsight;
  sourceRollupVersions: {
    reportCentre: string;
    orchardFinance: string;
    coa: string;
  };
}

export interface FbiFarmNodeComparisonItem {
  farmNodeId: string;
  farmNodeName: string;
  revenue: number;
  expenses: number;
  netProfit: number;
  netMarginPct: number;
  cropYieldKg: number;
  fcr: number;
  landUtilizationPct: number;
  costPerHectare: number;
  domains: Partial<FbiDomains>;
}

export interface FbiTenantRollup {
  id?: string;
  tenantId: string;
  period: FbiPeriod;
  computedAt: string;
  domains: FbiDomains;
  byFarmNode: Record<string, FbiFarmNodeComparisonItem>;
  fbiInsight?: FbiInsight;
  sourceRollupVersions: {
    reportCentre: string;
    orchardFinance: string;
    coa: string;
  };
}

export interface FbiKpiRegistryItem {
  kpiId: string;
  domain: FbiDomainKey;
  label: string;
  unit: string;
  description?: string;
  sourcePath: string;
  aggregation: "sum" | "avg" | "latest" | "ratio";
  sliceableBy: string[];
  requiresRollupVersion: string;
  enabled?: boolean;
}

export interface FbiPlatformRollup {
  id: string;
  period: FbiPeriod;
  computedAt: string;
  totalActiveTenants: number;
  totalActiveNodes: number;
  aggregateRevenueZmw: number;
  aggregateNetProfitZmw: number;
  benchmarkYields: Record<string, { p25: number; median: number; p75: number; unit: string }>;
  benchmarkMargins: { p25: number; median: number; p75: number };
  benchmarkFcr: Record<string, { p25: number; median: number; p75: number }>;
}

export type FbiViewMode = "single_node" | "consolidated" | "compare_nodes";

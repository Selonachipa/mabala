import {
  canViewUnmasked as canViewUnmaskedBase,
  maskPII as maskPIIBase,
  maskMobile as maskMobileBase,
  maskEmail as maskEmailBase,
  maskNRC as maskNRCBase,
  maskUserId as maskUserIdBase,
  maskCard as maskCardBase,
  maskPIIObject as maskPIIObjectBase,
  PIIFieldType,
  MaskPIIOptions
} from "./privacyMasking";

export type { PIIFieldType, MaskPIIOptions };

/**
 * Source of truth for PII unmasking permissions:
 * - Returns true if the viewer is Super Admin or the data owner themselves.
 */
export function canViewUnmasked(
  fieldOrViewerRole?: string,
  viewerRoleOrDataOwnerId?: string,
  dataOwnerIdOrCurrentUserId?: string,
  currentUserId?: string
): boolean {
  return canViewUnmaskedBase(
    fieldOrViewerRole,
    viewerRoleOrDataOwnerId,
    dataOwnerIdOrCurrentUserId,
    currentUserId
  );
}

/**
 * Shared PII Masking utility enforcing consistent masking rules:
 * - Mobile/Phone: Show last 4 digits (e.g., •••••2345)
 * - Email: Mask username prefix while maintaining email domain format (e.g., ••••@domain.com)
 * - NRC: First 4 characters visible, remainder masked (e.g., 1234••••/••/1)
 * - User ID / UID: Masked display token (e.g., ••••7f2a)
 * - Card/PAN: Last 4 digits only (e.g., •••• •••• •••• 4242)
 */
export function maskPII(
  value: string | null | undefined,
  fieldType: PIIFieldType,
  options?: MaskPIIOptions
): string {
  return maskPIIBase(value, fieldType, options);
}

export const maskMobile = maskMobileBase;
export const maskEmail = maskEmailBase;
export const maskNRC = maskNRCBase;
export const maskUserId = maskUserIdBase;
export const maskCard = maskCardBase;
export const maskPIIObject = maskPIIObjectBase;

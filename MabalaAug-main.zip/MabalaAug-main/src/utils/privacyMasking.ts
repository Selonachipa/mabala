/**
 * Shared PII Masking Utilities for Mabala SaaS Platform
 * Enforces privacy masking for Agro-Dealers, Institutional Suppliers, Offtakers, and public-facing reports.
 */

export type PIIFieldType = "mobile" | "phone" | "email" | "nrc" | "uid" | "userId" | "card" | "pan";

export interface MaskPIIOptions {
  field?: string;
  viewerRole?: string;
  dataOwnerId?: string;
  currentUserId?: string;
}

/**
 * Role-based permission check: Single source of truth for unmasked PII viewing.
 * Returns true if the viewer is Super Admin or the data owner themselves.
 */
export function canViewUnmasked(
  fieldOrViewerRole?: string,
  viewerRoleOrDataOwnerId?: string,
  dataOwnerIdOrCurrentUserId?: string,
  currentUserId?: string
): boolean {
  let viewerRole = "";
  let dataOwnerId = "";
  let userId = "";

  const knownFields = ["mobile", "phone", "email", "nrc", "uid", "userid", "card", "pan"];
  if (fieldOrViewerRole && knownFields.includes(fieldOrViewerRole.toLowerCase().trim())) {
    viewerRole = viewerRoleOrDataOwnerId || "";
    dataOwnerId = dataOwnerIdOrCurrentUserId || "";
    userId = currentUserId || "";
  } else {
    viewerRole = fieldOrViewerRole || "";
    dataOwnerId = viewerRoleOrDataOwnerId || "";
    userId = dataOwnerIdOrCurrentUserId || "";
  }

  const roleClean = viewerRole.toLowerCase().trim();
  if (roleClean === "super_admin" || roleClean === "super admin" || roleClean === "superadmin") {
    return true;
  }

  if (dataOwnerId && userId && dataOwnerId.trim() === userId.trim()) {
    return true;
  }

  return false;
}

/**
 * Mobile number: Show last 4 digits only, mask the rest with •
 * Example: •••••2345
 */
export function maskMobile(phone: string | null | undefined): string {
  if (!phone) return "••••";
  const clean = phone.trim().replace(/\s+/g, "");
  if (clean.length <= 4) {
    return "••••" + clean;
  }
  const last4 = clean.slice(-4);
  const maskedPrefix = "•".repeat(Math.max(5, clean.length - 4));
  return `${maskedPrefix}${last4}`;
}

/**
 * Email address: Show last 4 characters only (including domain characters as they fall), mask the rest
 * Example: ••••••••@ex.com → normalize to consistent mask length, e.g. ••••ail.com
 */
export function maskEmail(email: string | null | undefined): string {
  if (!email) return "••••";
  const clean = email.trim();
  if (clean.length <= 4) {
    return "••••";
  }
  const last4 = clean.slice(-4);
  return `••••${last4}`;
}

/**
 * NRC (National Registration Card): Show first 4 characters only, mask the rest
 * Example: 1234••••••/••/1
 */
export function maskNRC(nrc: string | null | undefined): string {
  if (!nrc) return "••••••••/••/•";
  const clean = nrc.trim();
  if (clean.length <= 4) {
    return clean + "••••";
  }
  const first4 = clean.slice(0, 4);
  const rest = clean.slice(4);
  const maskedRest = rest.replace(/[^\/]/g, "•");
  return `${first4}${maskedRest}`;
}

/**
 * User ID: Fully masked except a short non-guessable display token (e.g. last 4 of raw uid/hash)
 * Example: ••••7f2a
 */
export function maskUserId(uid: string | null | undefined): string {
  if (!uid) return "••••0000";
  const clean = uid.trim();
  if (clean.length <= 4) {
    return "••••" + clean;
  }
  const last4 = clean.slice(-4);
  return `••••${last4}`;
}

/**
 * Card payment details (PAN): Show last 4 digits only (PCI masking)
 * Example: •••• •••• •••• 4242
 */
export function maskCard(pan: string | null | undefined): string {
  if (!pan) return "•••• •••• •••• ••••";
  const digits = pan.replace(/\D/g, "");
  if (digits.length <= 4) {
    return `•••• •••• •••• ${digits.padStart(4, "0")}`;
  }
  const last4 = digits.slice(-4);
  return `•••• •••• •••• ${last4}`;
}

/**
 * Universal PII Masking function
 */
export function maskPII(
  value: string | null | undefined,
  fieldType: PIIFieldType,
  options?: MaskPIIOptions
): string {
  const role = options?.viewerRole || "";
  const ownerId = options?.dataOwnerId;
  const currentId = options?.currentUserId;

  if (canViewUnmasked(fieldType, role, ownerId, currentId)) {
    return value ?? "";
  }

  switch (fieldType) {
    case "mobile":
    case "phone":
      return maskMobile(value);
    case "email":
      return maskEmail(value);
    case "nrc":
      return maskNRC(value);
    case "uid":
    case "userId":
      return maskUserId(value);
    case "card":
    case "pan":
      return maskCard(value);
    default:
      return value ? "••••" : "";
  }
}

/**
 * Mask PII fields on a data object for non-privileged viewers
 */
export function maskPIIObject<T extends Record<string, any>>(obj: T, options: MaskPIIOptions): T {
  const { viewerRole = "user", dataOwnerId, currentUserId } = options;
  if (canViewUnmasked(viewerRole, dataOwnerId, currentUserId)) {
    return obj;
  }

  const masked: any = { ...obj };
  if (masked.phone) masked.phone = maskMobile(masked.phone);
  if (masked.contactPhone) masked.contactPhone = maskMobile(masked.contactPhone);
  if (masked.phoneNumber) masked.phoneNumber = maskMobile(masked.phoneNumber);
  if (masked.mobile) masked.mobile = maskMobile(masked.mobile);
  if (masked.email) masked.email = maskEmail(masked.email);
  if (masked.nrc) masked.nrc = maskNRC(masked.nrc);
  if (masked.uid) masked.uid = maskUserId(masked.uid);
  if (masked.userId) masked.userId = maskUserId(masked.userId);
  if (masked.cardNumber) masked.cardNumber = maskCard(masked.cardNumber);
  if (masked.pan) masked.pan = maskCard(masked.pan);

  return masked as T;
}

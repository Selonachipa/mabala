// Safe browser-compatible shim for Node.js 'tty' module

export function isatty(fd: number): boolean {
  return false;
}

export class ReadStream {
  isTTY = false;
  setRawMode() {
    return this;
  }
}

export class WriteStream {
  isTTY = false;
  columns = 80;
  rows = 24;
  getColorDepth() {
    return 1;
  }
  hasColors() {
    return false;
  }
}

export default {
  isatty,
  ReadStream,
  WriteStream
};

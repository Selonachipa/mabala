// Safe browser-compatible shim for Node.js 'path' module

function normalizeArray(parts: string[], allowAboveRoot: boolean): string[] {
  let res: string[] = [];
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    if (!p || p === '.') continue;
    if (p === '..') {
      if (res.length && res[res.length - 1] !== '..') {
        res.pop();
      } else if (allowAboveRoot) {
        res.push('..');
      }
    } else {
      res.push(p);
    }
  }
  return res;
}

export function resolve(...args: string[]): string {
  let resolvedPath = '';
  let resolvedAbsolute = false;

  for (let i = args.length - 1; i >= -1 && !resolvedAbsolute; i--) {
    const path = i >= 0 ? args[i] : '/';
    if (!path || typeof path !== 'string') continue;
    resolvedPath = path + '/' + resolvedPath;
    resolvedAbsolute = path.charAt(0) === '/';
  }

  const parts = resolvedPath.split('/').filter(p => !!p);
  const normalized = normalizeArray(parts, !resolvedAbsolute).join('/');
  return (resolvedAbsolute ? '/' : '') + normalized || (resolvedAbsolute ? '/' : '.');
}

export function normalize(path: string): string {
  if (typeof path !== 'string') return '';
  const isAbs = isAbsolute(path);
  const trailingSlash = path.endsWith('/');
  const parts = path.split('/').filter(Boolean);
  let normalized = normalizeArray(parts, !isAbs).join('/');
  if (!normalized && !isAbs) normalized = '.';
  if (normalized && trailingSlash) normalized += '/';
  return (isAbs ? '/' : '') + normalized;
}

export function isAbsolute(path: string): boolean {
  return typeof path === 'string' && path.charAt(0) === '/';
}

export function join(...args: string[]): string {
  let paths = '';
  for (let i = 0; i < args.length; i++) {
    const segment = args[i];
    if (typeof segment !== 'string') continue;
    if (!segment) continue;
    if (!paths) {
      paths += segment;
    } else {
      paths += '/' + segment;
    }
  }
  return normalize(paths);
}

export function relative(from: string, to: string): string {
  from = resolve(from).substr(1);
  to = resolve(to).substr(1);

  const fromParts = from.split('/').filter(Boolean);
  const toParts = to.split('/').filter(Boolean);

  const length = Math.min(fromParts.length, toParts.length);
  let samePartsLength = length;
  for (let i = 0; i < length; i++) {
    if (fromParts[i] !== toParts[i]) {
      samePartsLength = i;
      break;
    }
  }

  let outputParts: string[] = [];
  for (let i = samePartsLength; i < fromParts.length; i++) {
    outputParts.push('..');
  }

  outputParts = outputParts.concat(toParts.slice(samePartsLength));
  return outputParts.join('/');
}

export function dirname(path: string): string {
  if (typeof path !== 'string' || path.length === 0) return '.';
  const isAbs = path.charAt(0) === '/';
  const parts = path.split('/').filter(Boolean);
  if (parts.length <= 1) return isAbs ? '/' : '.';
  parts.pop();
  return (isAbs ? '/' : '') + parts.join('/');
}

export function basename(path: string, ext?: string): string {
  if (typeof path !== 'string' || path.length === 0) return '';
  let f = path.substring(path.lastIndexOf('/') + 1);
  if (ext && f.endsWith(ext)) {
    f = f.slice(0, -ext.length);
  }
  return f;
}

export function extname(path: string): string {
  if (typeof path !== 'string') return '';
  const idx = path.lastIndexOf('.');
  if (idx <= 0) return '';
  return path.slice(idx);
}

export const sep = '/';
export const delimiter = ':';
export const posix = {
  resolve,
  normalize,
  isAbsolute,
  join,
  relative,
  dirname,
  basename,
  extname,
  sep,
  delimiter
};
export const win32 = posix;

const path = {
  resolve,
  normalize,
  isAbsolute,
  join,
  relative,
  dirname,
  basename,
  extname,
  sep,
  delimiter,
  posix,
  win32
};

export default path;

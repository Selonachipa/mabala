import { getStatutoryTaxConfig, StatutoryTaxConfig } from "../services/taxConfigService";

export interface PayrollDeductionInput {
  basicSalary: number;
  housingAllowance?: number;
  transportAllowance?: number;
  otherAllowance?: number;
  isZambia?: boolean;
  taxConfig?: StatutoryTaxConfig;
  customTaxRate?: number;
  customThreshold?: number;
}

export interface PayrollDeductionResult {
  basicSalary: number;
  housingAllowance: number;
  transportAllowance: number;
  otherAllowance: number;
  grossSalary: number;
  paye: number;
  napsaEmployee: number;
  napsaEmployer: number;
  nhimaEmployee: number;
  nhimaEmployer: number;
  wcfEmployer: number;
  skillsLevyEmployer: number;
  totalEmployeeDeductions: number;
  totalEmployerContributions: number;
  netPay: number;
  activeTaxSystem: "VAT" | "TOT" | "CUSTOM" | "EXEMPT";
  effectivePayeRate: number;
  effectiveThreshold: number;
  taxSystemDescription: string;
}

/**
 * Auto-calculates statutory deductions (PAYE, NAPSA, NHIMA, WCF, Skills Levy)
 * based on the farm's active statutory tax system (VAT, TOT, CUSTOM, EXEMPT).
 * Used for pre-filling employee payslip generation flows.
 */
export function calculateStatutoryDeductions(input: PayrollDeductionInput): PayrollDeductionResult {
  const basicSalary = Math.max(0, input.basicSalary || 0);
  const housingAllowance = Math.max(0, input.housingAllowance || 0);
  const transportAllowance = Math.max(0, input.transportAllowance || 0);
  const otherAllowance = Math.max(0, input.otherAllowance || 0);

  const grossSalary = basicSalary + housingAllowance + transportAllowance + otherAllowance;

  const taxConfig = input.taxConfig || getStatutoryTaxConfig();
  const activeTaxSystem = taxConfig.activeTaxSystem || "VAT";
  const isZambia = input.isZambia !== undefined ? input.isZambia : (taxConfig.countryIso2 === "ZM");

  let effectivePayeRate = taxConfig.payeFlatRate || 10.0;
  let effectiveThreshold = taxConfig.payeThreshold || 5100.0;

  if (input.customTaxRate !== undefined && input.customTaxRate > 0) {
    effectivePayeRate = input.customTaxRate;
  }
  if (input.customThreshold !== undefined && input.customThreshold > 0) {
    effectiveThreshold = input.customThreshold;
  }

  let taxSystemDescription = "Standard Statutory Tax System";
  let paye = 0;

  switch (activeTaxSystem) {
    case "EXEMPT":
      paye = 0;
      taxSystemDescription = "Agricultural Tax Exempt (0% PAYE)";
      break;

    case "TOT":
      taxSystemDescription = `Turnover Tax System (${taxConfig.totRate || 5}% Rate)`;
      const totRate = input.customTaxRate && input.customTaxRate > 0 ? input.customTaxRate : (taxConfig.totRate || 5.0);
      paye = grossSalary * (totRate / 100);
      effectivePayeRate = totRate;
      break;

    case "CUSTOM":
      const customRate = input.customTaxRate && input.customTaxRate > 0 ? input.customTaxRate : (taxConfig.customTaxRate || 16.0);
      taxSystemDescription = `${taxConfig.customTaxName || "Custom Tax"} (${customRate}%)`;
      if (grossSalary > effectiveThreshold) {
        paye = (grossSalary - effectiveThreshold) * (customRate / 100);
      } else {
        paye = 0;
      }
      effectivePayeRate = customRate;
      break;

    case "VAT":
    default:
      taxSystemDescription = isZambia ? "ZRA Cap 331 Statutory Tax Band" : "Standard Statutory Tax System";
      if (isZambia) {
        if (grossSalary > effectiveThreshold) {
          paye = (grossSalary - effectiveThreshold) * (effectivePayeRate / 100);
        } else {
          paye = 0;
        }
      } else {
        paye = grossSalary * (effectivePayeRate / 100);
      }
      break;
  }

  // Statutory Pension & Health Insurance Deductions (Uses Configurable Percentages)
  const napsaEeRate = taxConfig.napsaEmployeeRate ?? 5.0;
  const napsaErRate = taxConfig.napsaEmployerRate ?? 5.0;
  const nhimaEeRate = taxConfig.nhimaEmployeeRate ?? 1.0;
  const nhimaErRate = taxConfig.nhimaEmployerRate ?? 1.0;
  const wcfErRate = taxConfig.wcfEmployerRate ?? 1.0;
  const skillsErRate = taxConfig.skillsLevyEmployerRate ?? 0.5;

  let napsaEmployee = 0;
  let napsaEmployer = 0;
  let nhimaEmployee = 0;
  let nhimaEmployer = 0;
  let wcfEmployer = 0;
  let skillsLevyEmployer = 0;

  if (isZambia) {
    // NAPSA Pension
    napsaEmployee = grossSalary * (napsaEeRate / 100);
    napsaEmployer = grossSalary * (napsaErRate / 100);

    // NHIMA Health Scheme
    nhimaEmployee = grossSalary * (nhimaEeRate / 100);
    nhimaEmployer = grossSalary * (nhimaErRate / 100);

    // Workers Compensation Fund (WCF)
    wcfEmployer = grossSalary * (wcfErRate / 100);

    // Skills Development Levy
    skillsLevyEmployer = grossSalary * (skillsErRate / 100);
  } else {
    // Generic International Statutory Pension
    napsaEmployee = grossSalary * (napsaEeRate / 100);
    napsaEmployer = grossSalary * (napsaErRate / 100);
  }

  const totalEmployeeDeductions = paye + napsaEmployee + nhimaEmployee;
  const totalEmployerContributions = napsaEmployer + nhimaEmployer + wcfEmployer + skillsLevyEmployer;
  const netPay = Math.max(0, grossSalary - totalEmployeeDeductions);

  return {
    basicSalary,
    housingAllowance,
    transportAllowance,
    otherAllowance,
    grossSalary,
    paye,
    napsaEmployee,
    napsaEmployer,
    nhimaEmployee,
    nhimaEmployer,
    wcfEmployer,
    skillsLevyEmployer,
    totalEmployeeDeductions,
    totalEmployerContributions,
    netPay,
    activeTaxSystem,
    effectivePayeRate,
    effectiveThreshold,
    taxSystemDescription,
  };
}

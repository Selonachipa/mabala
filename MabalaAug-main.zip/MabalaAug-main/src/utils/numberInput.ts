/**
 * Utility functions for handling numerical input fields that default to 0.
 */

/**
 * Handles numeric value updates.
 * If the field was 0, typing a new number should replace/clear the 0, rather than appending to it.
 * If the field is cleared to an empty string, it returns 0 (handling empty string gracefully to prevent NaN).
 * If the user types a new digit next to 0 (e.g. resulting in "05" or "50" if appended),
 * this handles the zero replacement/clearing correctly.
 */
export function handleAmountInput(newValue: string, prevValue: number): number {
  if (newValue === "") {
    return 0;
  }

  // Handle case where newValue has a leading zero from appending (e.g. "05")
  if (prevValue === 0 && newValue.length > 1 && newValue.startsWith("0") && !newValue.startsWith("0.")) {
    const withoutLeadingZero = newValue.replace(/^0+/, "");
    if (withoutLeadingZero === "") {
      return 0;
    }
    const parsed = parseFloat(withoutLeadingZero);
    return isNaN(parsed) ? 0 : parsed;
  }

  const parsed = parseFloat(newValue);
  return isNaN(parsed) ? 0 : parsed;
}

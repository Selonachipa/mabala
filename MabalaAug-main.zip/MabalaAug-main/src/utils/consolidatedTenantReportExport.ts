/**
 * Export Utilities for Consolidated Tenant Financial Report
 * Generates institutional PDF and CSV/Excel exports.
 */

import { jsPDF } from 'jspdf';
import { ConsolidatedTenantFinancialReport } from '../services/consolidatedTenantReportService';

/**
 * Export Consolidated Tenant Financial Report as PDF
 */
export function exportConsolidatedTenantReportPdf(
  report: ConsolidatedTenantFinancialReport,
  institutionName: string = 'Mabala Institutional Portal',
  currency: string = 'ZMW'
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  let y = 26;

  // 1. Top Header Banner
  doc.setFillColor(15, 23, 42); // Slate 900
  doc.rect(0, 0, 210, 18, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('MABALA SAAS • CONSOLIDATED TENANT FINANCIAL REPORT', 14, 11);
  doc.text((report.institution.name || institutionName).toUpperCase(), 196, 11, { align: 'right' });

  // 2. Report Title & Subtitle
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('Consolidated Financial Summary Across Tenant Farm Nodes', 14, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139);
  doc.text(`Tenant ID: ${report.institution.id}   •   Reporting Period: ${report.reportingPeriod.preset} (${report.reportingPeriod.from} to ${report.reportingPeriod.to})`, 14, y);
  y += 4.5;
  doc.setFontSize(8);
  doc.text(`Generated: ${new Date().toLocaleString('en-GB')}   •   Active Farm Nodes: ${report.portfolioTotals.activeFarmNodesCount} of ${report.portfolioTotals.totalFarmNodesCount}   •   Total Area: ${report.portfolioTotals.totalCultivatedHectares.toLocaleString()} ha`, 14, y);
  y += 6;

  // Divider
  doc.setDrawColor(226, 232, 240);
  doc.line(14, y, 196, y);
  y += 7;

  // 3. Executive KPI Cards
  const kpis = [
    { label: 'CONSOLIDATED REVENUE', val: `${currency} ${report.portfolioTotals.consolidatedGrossRevenue.toLocaleString()}` },
    { label: 'CONSOLIDATED OPEX', val: `${currency} ${report.portfolioTotals.consolidatedOperatingExpenses.toLocaleString()}` },
    { label: 'NET OPERATING INCOME', val: `${currency} ${report.portfolioTotals.consolidatedNetOperatingIncome.toLocaleString()}` },
    { label: 'NET PROFIT MARGIN', val: `${report.portfolioTotals.consolidatedNetProfitMarginPct.toFixed(1)}%` }
  ];

  const cardW = 43;
  const cardH = 15;
  const gap = 3;

  kpis.forEach((k, idx) => {
    const x = 14 + idx * (cardW + gap);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(x, y, cardW, cardH, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(k.label, x + 3, y + 4.5);

    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    doc.text(k.val, x + 3, y + 11.5);
  });

  y += cardH + 7;

  // 4. Consolidated Income Statement (P&L Rollup) Table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text('1. Consolidated Income Statement (P&L Rollup)', 14, y);
  y += 5;

  // P&L Statement Table
  doc.setFillColor(241, 245, 249);
  doc.rect(14, y, 182, 6, 'F');
  doc.setFontSize(7.5);
  doc.setTextColor(51, 65, 85);
  doc.text('Financial Line Item', 16, y + 4);
  doc.text(`Amount (${currency})`, 140, y + 4);
  doc.text('% of Gross Revenue', 194, y + 4, { align: 'right' });
  y += 7;

  const grossRev = report.portfolioTotals.consolidatedGrossRevenue || 1;

  const plRows = [
    { name: 'Gross Agricultural Revenue (Crops, Livestock, Produce, Services)', amt: report.portfolioTotals.consolidatedGrossRevenue, pct: 100, bold: true, fill: true },
    { name: '  Less: Direct Crop Inputs & Animal Feed Costs (COGS)', amt: -report.portfolioTotals.consolidatedDirectCosts, pct: (report.portfolioTotals.consolidatedDirectCosts / grossRev) * 100 },
    { name: 'Gross Profit', amt: report.portfolioTotals.consolidatedGrossProfit, pct: report.portfolioTotals.consolidatedGrossMarginPct, bold: true, fill: true },
    { name: '  Less: Field Labor Wages & Payroll', amt: -report.portfolioTotals.consolidatedOperatingExpenses * 0.28, pct: 28 },
    { name: '  Less: Machinery Fuel & Equipment Maintenance', amt: -report.portfolioTotals.consolidatedOperatingExpenses * 0.20, pct: 20 },
    { name: '  Less: Logistics, Storage & Post-Harvest Utilities', amt: -report.portfolioTotals.consolidatedOperatingExpenses * 0.15, pct: 15 },
    { name: '  Less: Administrative, Land & Irrigation Overheads', amt: -report.portfolioTotals.consolidatedOperatingExpenses * 0.12, pct: 12 },
    { name: 'Total Operating Expenses (OPEX)', amt: -report.portfolioTotals.consolidatedOperatingExpenses, pct: (report.portfolioTotals.consolidatedOperatingExpenses / grossRev) * 100, bold: true },
    { name: 'Net Operating Income (EBITDA)', amt: report.portfolioTotals.consolidatedNetOperatingIncome, pct: report.portfolioTotals.consolidatedNetProfitMarginPct, bold: true, fill: true, highlight: true }
  ];

  plRows.forEach(row => {
    if (row.fill) {
      doc.setFillColor(row.highlight ? 236 : 248, row.highlight ? 253 : 250, row.highlight ? 245 : 252);
      doc.rect(14, y - 3.5, 182, 5.5, 'F');
    }
    doc.setFont('helvetica', row.bold ? 'bold' : 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(row.highlight ? 4 : 15, row.highlight ? 120 : 23, row.highlight ? 87 : 42);
    
    doc.text(row.name, 16, y);
    doc.text(`${row.amt < 0 ? '-' : ''}${currency} ${Math.abs(Math.round(row.amt)).toLocaleString()}`, 140, y);
    doc.text(`${row.pct.toFixed(1)}%`, 194, y, { align: 'right' });
    y += 5.5;
  });

  y += 4;

  // 5. Consolidated Balance Sheet Snapshot
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text('2. Consolidated Balance Sheet & Capital Position', 14, y);
  y += 5;

  const bsCards = [
    { label: 'TOTAL ASSET BASE', val: `${currency} ${report.portfolioTotals.consolidatedTotalAssets.toLocaleString()}`, sub: `Bio/Inv: ${currency} ${(report.portfolioTotals.consolidatedBiologicalAssets + report.portfolioTotals.consolidatedInventoryValuation).toLocaleString()}` },
    { label: 'TOTAL LIABILITIES', val: `${currency} ${report.portfolioTotals.consolidatedTotalLiabilities.toLocaleString()}`, sub: `Long-Term Debt: ${currency} ${report.portfolioTotals.consolidatedLongTermDebt.toLocaleString()}` },
    { label: 'TENANT NET WORTH', val: `${currency} ${report.portfolioTotals.consolidatedNetWorth.toLocaleString()}`, sub: `Debt-to-Asset: ${(report.portfolioTotals.consolidatedDebtToAssetRatio * 100).toFixed(1)}%` }
  ];

  const bsW = 59;
  bsCards.forEach((b, idx) => {
    const x = 14 + idx * (bsW + 2.5);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(x, y, bsW, 14, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(b.label, x + 3, y + 4);

    doc.setFontSize(8.5);
    doc.setTextColor(15, 23, 42);
    doc.text(b.val, x + 3, y + 8.5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(71, 85, 105);
    doc.text(b.sub, x + 3, y + 12);
  });

  y += 19;

  // 6. Farm Node Comparative Breakdown Table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text('3. Farm Node Comparative Financial Performance Matrix', 14, y);
  y += 5;

  // Table Header
  doc.setFillColor(15, 23, 42);
  doc.rect(14, y, 182, 6, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');

  doc.text('Farm Node / Owner', 16, y + 4);
  doc.text('Location', 60, y + 4);
  doc.text('Area (ha)', 92, y + 4);
  doc.text(`Revenue (${currency})`, 122, y + 4, { align: 'right' });
  doc.text(`Expenses (${currency})`, 152, y + 4, { align: 'right' });
  doc.text('Net Margin', 174, y + 4, { align: 'right' });
  doc.text('Rating', 194, y + 4, { align: 'right' });
  y += 7;

  // Render top 12 farm nodes in PDF
  const displayNodes = report.farmNodesMatrix.slice(0, 14);

  displayNodes.forEach((node, idx) => {
    // Check if new page needed
    if (y > 275) {
      doc.addPage();
      y = 20;
    }

    if (idx % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, y - 3, 182, 5, 'F');
    }

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(15, 23, 42);

    const truncatedName = node.farmName.length > 22 ? node.farmName.substring(0, 20) + '..' : node.farmName;
    doc.text(truncatedName, 16, y);
    doc.text(`${node.district}, ${node.province.substring(0, 8)}`, 60, y);
    doc.text(`${node.hectarage} ha`, 92, y);
    doc.text(node.revenue.total.toLocaleString(), 122, y, { align: 'right' });
    doc.text(node.expenses.total.toLocaleString(), 152, y, { align: 'right' });

    // Net margin color
    if (node.profitability.netMarginPct >= 20) {
      doc.setTextColor(5, 150, 105);
    } else if (node.profitability.netMarginPct < 0) {
      doc.setTextColor(220, 38, 38);
    } else {
      doc.setTextColor(71, 85, 105);
    }
    doc.text(`${node.profitability.netMarginPct.toFixed(1)}%`, 174, y, { align: 'right' });

    // Health Rating Badge
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.text(`Grade ${node.financialHealthBand}`, 194, y, { align: 'right' });

    y += 5;
  });

  // Footer / Disclaimer
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(148, 163, 184);
    doc.text(`Mabala SaaS • Consolidated Tenant Report • Page ${i} of ${pageCount}`, 14, 290);
    doc.text('CONFIDENTIAL • STRICTLY FOR INSTITUTIONAL ADMINISTRATION & GOVERNANCE', 196, 290, { align: 'right' });
  }

  // Save PDF
  const filename = `consolidated_tenant_report_${report.institution.id}_${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(filename);
}

/**
 * Export Consolidated Tenant Financial Report as CSV
 */
export function exportConsolidatedTenantReportCsv(
  report: ConsolidatedTenantFinancialReport,
  currency: string = 'ZMW'
): void {
  const lines: string[] = [];

  // Header Metadata
  lines.push(`"MABALA SAAS - CONSOLIDATED TENANT FINANCIAL REPORT"`);
  lines.push(`"Institution Name","${report.institution.name}"`);
  lines.push(`"Institution ID","${report.institution.id}"`);
  lines.push(`"Institution Type","${report.institution.type}"`);
  lines.push(`"Reporting Period","${report.reportingPeriod.preset}"`);
  lines.push(`"From Date","${report.reportingPeriod.from}"`);
  lines.push(`"To Date","${report.reportingPeriod.to}"`);
  lines.push(`"Generated At","${report.reportingPeriod.generatedAt}"`);
  lines.push(`"Currency","${currency}"`);
  lines.push('');

  // Portfolio Totals
  lines.push(`"PORTFOLIO EXECUTIVE TOTALS"`);
  lines.push(`"Metric","Value"`);
  lines.push(`"Total Farm Nodes","${report.portfolioTotals.totalFarmNodesCount}"`);
  lines.push(`"Active Farm Nodes","${report.portfolioTotals.activeFarmNodesCount}"`);
  lines.push(`"Total Cultivated Hectares","${report.portfolioTotals.totalCultivatedHectares}"`);
  lines.push(`"Total Staff Employed","${report.portfolioTotals.totalStaffEmployed}"`);
  lines.push(`"Consolidated Gross Revenue (${currency})","${report.portfolioTotals.consolidatedGrossRevenue}"`);
  lines.push(`"Consolidated Direct Costs / COGS (${currency})","${report.portfolioTotals.consolidatedDirectCosts}"`);
  lines.push(`"Consolidated Gross Profit (${currency})","${report.portfolioTotals.consolidatedGrossProfit}"`);
  lines.push(`"Consolidated Gross Margin (%)","${report.portfolioTotals.consolidatedGrossMarginPct}%"`);
  lines.push(`"Consolidated Operating Expenses (${currency})","${report.portfolioTotals.consolidatedOperatingExpenses}"`);
  lines.push(`"Consolidated Net Operating Income (${currency})","${report.portfolioTotals.consolidatedNetOperatingIncome}"`);
  lines.push(`"Consolidated Net Profit Margin (%)","${report.portfolioTotals.consolidatedNetProfitMarginPct}%"`);
  lines.push(`"Consolidated Total Assets (${currency})","${report.portfolioTotals.consolidatedTotalAssets}"`);
  lines.push(`"Consolidated Total Liabilities (${currency})","${report.portfolioTotals.consolidatedTotalLiabilities}"`);
  lines.push(`"Consolidated Net Worth (${currency})","${report.portfolioTotals.consolidatedNetWorth}"`);
  lines.push(`"Debt to Asset Ratio","${report.portfolioTotals.consolidatedDebtToAssetRatio}"`);
  lines.push(`"Average Revenue per Hectare (${currency}/ha)","${report.portfolioTotals.portfolioAvgRevenuePerHectare}"`);
  lines.push('');

  // Farm Nodes Matrix
  lines.push(`"FARM NODE COMPARATIVE FINANCIAL BREAKDOWN"`);
  const headers = [
    'Node ID',
    'Farm Name',
    'TPIN',
    'Owner Name',
    'Phone',
    'Province',
    'District',
    'Hectarage (ha)',
    `Crop Revenue (${currency})`,
    `Livestock Revenue (${currency})`,
    `Produce Revenue (${currency})`,
    `Services Revenue (${currency})`,
    `Other Revenue (${currency})`,
    `Total Revenue (${currency})`,
    `Direct Inputs Exp (${currency})`,
    `Feed & Vet Exp (${currency})`,
    `Labor Payroll Exp (${currency})`,
    `Machinery Fuel Exp (${currency})`,
    `Logistics Storage Exp (${currency})`,
    `Utilities Admin Exp (${currency})`,
    `Total Expenses (${currency})`,
    `Gross Profit (${currency})`,
    'Gross Margin (%)',
    `Net Operating Income (${currency})`,
    'Net Margin (%)',
    'Opex Ratio (%)',
    `Revenue per Ha (${currency})`,
    `Cash & Bank (${currency})`,
    `Accounts Receivable (${currency})`,
    `Biological Assets (${currency})`,
    `Inventory Valuation (${currency})`,
    `Fixed Assets (${currency})`,
    `Total Assets (${currency})`,
    `Current Liabilities (${currency})`,
    `Long-term Debt (${currency})`,
    `Total Liabilities (${currency})`,
    `Net Worth (${currency})`,
    'Debt to Asset Ratio',
    'Active Staff',
    'Health Band',
    'Risk Flags'
  ];

  lines.push(headers.map(h => `"${h}"`).join(','));

  report.farmNodesMatrix.forEach(n => {
    const row = [
      n.nodeId,
      n.farmName,
      n.tpin || '',
      n.ownerName,
      n.phone || '',
      n.province,
      n.district,
      n.hectarage,
      n.revenue.cropSales,
      n.revenue.livestockSales,
      n.revenue.produceSales,
      n.revenue.servicesAgri,
      n.revenue.otherRevenue,
      n.revenue.total,
      n.expenses.directInputs,
      n.expenses.feedAndVet,
      n.expenses.laborPayroll,
      n.expenses.machineryFuel,
      n.expenses.logisticsStorage,
      n.expenses.utilitiesAdmin,
      n.expenses.total,
      n.profitability.grossProfit,
      n.profitability.grossMarginPct,
      n.profitability.netOperatingIncome,
      n.profitability.netMarginPct,
      n.profitability.opexRatio,
      n.profitability.revenuePerHectare,
      n.balanceSheet.cashAndBank,
      n.balanceSheet.accountsReceivable,
      n.balanceSheet.biologicalAssets,
      n.balanceSheet.inventoryValue,
      n.balanceSheet.fixedCapitalAssets,
      n.balanceSheet.totalAssets,
      n.balanceSheet.currentLiabilities,
      n.balanceSheet.longTermDebt,
      n.balanceSheet.totalLiabilities,
      n.balanceSheet.netWorth,
      n.balanceSheet.debtToAssetRatio,
      n.operations.staffCount,
      n.financialHealthBand,
      n.riskFlags.join('; ')
    ];
    lines.push(row.map(v => `"${String(v).replace(/"/g, '""')}"`).join(','));
  });

  const csvContent = '\uFEFF' + lines.join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `consolidated_tenant_report_${report.institution.id}_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

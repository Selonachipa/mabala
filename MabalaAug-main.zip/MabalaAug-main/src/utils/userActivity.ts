/**
 * User Activity Tracker for Mabala SaaS Platform
 * Tracks last login and last module accessed with debouncing to prevent excessive writes.
 */

import { db } from "../firebase";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";

let lastRecordedModule = "";
let lastRecordedTime = 0;
const DEBOUNCE_MS = 15000; // 15 seconds debounce per module change

export async function recordUserActivity(uid: string, moduleName: string) {
  if (!uid || !moduleName || !db || (db as any)._dummy) return;

  const now = Date.now();
  if (lastRecordedModule === moduleName && now - lastRecordedTime < DEBOUNCE_MS) {
    return;
  }

  lastRecordedModule = moduleName;
  lastRecordedTime = now;

  try {
    const payload = {
      lastLoginAt: new Date().toISOString(),
      lastModuleAccessed: moduleName,
      lastModuleAccessedAt: new Date().toISOString(),
      updatedAt: serverTimestamp()
    };

    // Update both userActivity/{uid} and users_data/{uid}
    await Promise.allSettled([
      setDoc(doc(db, "userActivity", uid), payload, { merge: true }),
      setDoc(doc(db, "users_data", uid), payload, { merge: true })
    ]);
  } catch (err) {
    console.warn("[UserActivity] Failed to record user activity:", err);
  }
}

export function formatRelativeTime(isoStringOrTimestamp: string | number | undefined | null): string {
  if (!isoStringOrTimestamp) return "Never";
  const time = typeof isoStringOrTimestamp === "number" ? isoStringOrTimestamp : new Date(isoStringOrTimestamp).getTime();
  if (isNaN(time) || time <= 0) return "Never";

  const diffMs = Date.now() - time;
  const diffMinutes = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffMinutes < 1) return "Just now";
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays === 1) return "Yesterday";
  if (diffDays < 30) return `${diffDays}d ago`;
  if (diffDays < 365) return `${Math.floor(diffDays / 30)}mo ago`;
  return `${Math.floor(diffDays / 365)}y ago`;
}

export function isUserInactive(isoStringOrTimestamp: string | number | undefined | null, daysThreshold: number): boolean {
  if (!isoStringOrTimestamp) return true;
  const time = typeof isoStringOrTimestamp === "number" ? isoStringOrTimestamp : new Date(isoStringOrTimestamp).getTime();
  if (isNaN(time) || time <= 0) return true;

  const diffDays = (Date.now() - time) / (1000 * 60 * 60 * 24);
  return diffDays >= daysThreshold;
}

/**
 * Zambian Mobile Money & E.164 Phone Normalization and Validation Engine
 *
 * Canonical Format: 260XXXXXXXXX (12 digits, E.164 format without '+')
 * Operators:
 * - Airtel: 26097..., 26077...
 * - MTN:    26096..., 26076...
 * - Zamtel: 26095..., 26075...
 * - ZedMobile: 26079...
 */

/**
 * Normalizes phone numbers to standard Zambian mobile format (260XXXXXXXXX without '+').
 */
export function normalizeZambianPhone(phone: string | number | undefined | null): string {
  return normalizeZambianMobileNumber(phone);
}

/**
 * Normalizes any raw phone input into the canonical 12-digit Zambian format: 260XXXXXXXXX.
 *
 * Handles:
 * - Trimming whitespace, removal of tabs, dashes, parentheses, +, dots, and non-numeric chars
 * - Standard local formats: "0977123456" -> "260977123456", "0761234567" -> "260761234567"
 * - Short 9-digit formats: "977123456" -> "260977123456", "771234567" -> "260771234567"
 * - International formats: "+260977123456" -> "260977123456"
 * - Redundant trunk zeros: "+260 097 7123456" or "260097123456" -> "260977123456"
 * - Common typo variants: "206977..." -> "260977...", "00260...", "0260..."
 */
export function normalizeZambianMobileNumber(rawPhone: string | number | undefined | null): string {
  if (rawPhone === undefined || rawPhone === null) return "";

  // Convert to string and strip all non-numeric characters
  let digits = String(rawPhone).trim().replace(/\D/g, "");

  if (!digits) return "";

  // Handle common typo variant where 206 was entered instead of 260
  if (digits.startsWith("206") && digits.length >= 11) {
    digits = "260" + digits.slice(3);
  }

  // Handle leading international dial-out prefixes: 00260... -> 260...
  if (digits.startsWith("00260")) {
    digits = digits.slice(2);
  } else if (digits.startsWith("0260") && digits.length >= 12) {
    digits = digits.slice(1);
  }

  // Handle international numbers with redundant trunk zero: 260097... (13 digits) -> 26097...
  if (digits.startsWith("2600") && digits.length === 13) {
    digits = "260" + digits.slice(4);
  }

  // Handle standard 10-digit numbers starting with 0 (e.g., 0977123456, 096..., 095..., 077..., 076..., 075...)
  if (digits.length === 10 && digits.startsWith("0")) {
    digits = "260" + digits.slice(1);
  }

  // Handle 9-digit local numbers without leading 0 (e.g., 977123456 or 771234567)
  if (digits.length === 9 && (digits.startsWith("9") || digits.startsWith("7"))) {
    digits = "260" + digits;
  }

  return digits;
}

export interface ZambianPhoneValidationResult {
  isValid: boolean;
  normalized: string;
  error?: string;
}

/**
 * Validates whether a given phone number is a valid Zambian mobile number and returns a structured result.
 */
export function validateZambianMobileNumber(rawPhone: string | number | undefined | null): ZambianPhoneValidationResult {
  if (!rawPhone || String(rawPhone).trim() === "") {
    return {
      isValid: false,
      normalized: "",
      error: "Mobile phone number is required."
    };
  }

  const normalized = normalizeZambianMobileNumber(rawPhone);

  if (!normalized) {
    return {
      isValid: false,
      normalized: "",
      error: "Phone number contains no numeric digits."
    };
  }

  if (!normalized.startsWith("260")) {
    return {
      isValid: false,
      normalized,
      error: `Invalid country code: '${rawPhone}' normalized to '${normalized}'. Must start with Zambian country code 260.`
    };
  }

  if (normalized.length !== 12) {
    return {
      isValid: false,
      normalized,
      error: `Invalid length: '${normalized}' is ${normalized.length} digits. Expected exactly 12 digits in 260XXXXXXXXX format.`
    };
  }

  // Check valid mobile operator prefixes: 2609X or 2607X
  if (!/^260[79]\d{8}$/.test(normalized)) {
    return {
      isValid: false,
      normalized,
      error: `Invalid mobile operator prefix: '${normalized}'. Zambian mobile numbers must start with 2609 or 2607 (Airtel, MTN, Zamtel, ZedMobile).`
    };
  }

  return {
    isValid: true,
    normalized
  };
}

/**
 * Validates the phone number and throws an explicit Error if invalid.
 * Enforces exactly 12 digits beginning with 260.
 */
export function assertValidZambianMobileNumber(rawPhone: string | number | undefined | null): string {
  const result = validateZambianMobileNumber(rawPhone);
  if (!result.isValid) {
    throw new Error(result.error || `Invalid Zambian mobile number: '${rawPhone}'. Must be exactly 12 digits beginning with 260.`);
  }
  return result.normalized;
}

/**
 * Boolean validation check for Zambian mobile number.
 */
export function isValidZambianMobileNumber(rawPhone: string | number | undefined | null): boolean {
  if (!rawPhone) return false;
  const canonical = normalizeZambianMobileNumber(rawPhone);
  return canonical.startsWith("260") && canonical.length === 12 && /^260[79]\d{8}$/.test(canonical);
}

/**
 * Formats a normalized number for user-friendly display (+260 977 344556 or +260 97 7344556).
 * Safely handles any raw input (e.g. "977344556", "0977344556", "+260977344556", "260977344556").
 */
export function formatZambianMobileDisplay(rawPhone: string | number | undefined | null): string {
  const canonical = normalizeZambianMobileNumber(rawPhone);
  if (canonical && canonical.length === 12 && canonical.startsWith("260")) {
    return `+260 ${canonical.slice(3, 5)} ${canonical.slice(5, 8)} ${canonical.slice(8)}`;
  }
  const clean = String(rawPhone || "").trim();
  if (!clean) return "";
  if (clean.startsWith("+")) return clean;
  if (clean.startsWith("260")) return `+${clean}`;
  if (clean.startsWith("0")) return `+260 ${clean.slice(1)}`;
  return `+260 ${clean}`;
}

/**
 * Returns the exact 12-digit format required by Lipila API (260XXXXXXXXX without '+' or leading '0').
 */
export function getLipilaApiPhone(rawPhone: string | number | undefined | null): string {
  return normalizeZambianMobileNumber(rawPhone);
}


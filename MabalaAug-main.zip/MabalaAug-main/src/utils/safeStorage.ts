// LZW Compression and Decompression utilities to minimize localStorage footprint
export function lzw_compress(uncompressed: string): string {
  if (!uncompressed || typeof uncompressed !== "string") return uncompressed;
  if (uncompressed.startsWith("⚡LZW⚡")) return uncompressed;

  try {
    const encoded = encodeURIComponent(uncompressed);
    const dictionary: Record<string, number> = {};
    for (let i = 0; i < 256; i++) {
      dictionary[String.fromCharCode(i)] = i;
    }

    let word = "";
    const result: number[] = [];
    let dictSize = 256;

    for (let i = 0; i < encoded.length; i++) {
      const c = encoded[i];
      const wc = word + c;
      if (dictionary.hasOwnProperty(wc)) {
        word = wc;
      } else {
        result.push(dictionary[word]);
        if (dictSize < 65500) {
          dictionary[wc] = dictSize++;
        }
        word = String(c);
      }
    }

    if (word !== "") {
      result.push(dictionary[word]);
    }

    // Prepend special signature to indicate compressed state
    return "⚡LZW⚡" + result.map(code => String.fromCharCode(code)).join("");
  } catch (err) {
    console.warn("[lzw_compress] Compression failed, falling back to raw:", err);
    return uncompressed;
  }
}

export function lzw_decompress(compressed: string): string {
  if (!compressed || typeof compressed !== "string" || !compressed.startsWith("⚡LZW⚡")) return compressed;
  const data = compressed.substring(5);
  if (!data) return "";

  try {
    const dictionary: Record<number, string> = {};
    for (let i = 0; i < 256; i++) {
      dictionary[i] = String.fromCharCode(i);
    }

    const result: string[] = [];
    let dictSize = 256;

    const firstChar = data[0];
    const oldCode = firstChar.charCodeAt(0);
    let word = dictionary.hasOwnProperty(oldCode) ? dictionary[oldCode] : firstChar;
    result.push(word);

    for (let i = 1; i < data.length; i++) {
      const code = data[i].charCodeAt(0);
      let entry = "";
      if (dictionary.hasOwnProperty(code)) {
        entry = dictionary[code];
      } else if (code === dictSize) {
        entry = word + (word.charAt(0) || "");
      } else {
        entry = word + (word.charAt(0) || "");
      }

      result.push(entry);

      if (dictSize < 65500) {
        dictionary[dictSize++] = word + (entry.charAt(0) || "");
      }
      word = entry;
    }

    const decompressedStr = result.join("");
    try {
      return decodeURIComponent(decompressedStr);
    } catch {
      return decompressedStr;
    }
  } catch (err) {
    console.warn("[lzw_decompress] Decompression failed, attempting fallback:", err);
    return data;
  }
}

/**
 * Universal safe JSON parser that automatically strips LZW compression headers if present
 * and gracefully falls back to a default value rather than crashing the React component tree.
 */
export function safeParseJSON<T>(rawVal: any, fallback: T): T {
  if (rawVal === null || rawVal === undefined) return fallback;
  if (typeof rawVal === "object") return rawVal as T;
  if (typeof rawVal !== "string") return fallback;

  let str = rawVal.trim();
  if (str.startsWith("⚡LZW⚡")) {
    try {
      str = lzw_decompress(str).trim();
    } catch (e) {
      console.warn("[safeParseJSON] Decompress attempt notice:", e);
    }
  }

  if (!str || str === "undefined" || str === "null") return fallback;

  try {
    return JSON.parse(str);
  } catch (err) {
    if (str.includes("⚡LZW⚡")) {
      const cleaned = str.replace(/⚡LZW⚡/g, "").trim();
      try {
        return JSON.parse(cleaned);
      } catch {}
    }
    return fallback;
  }
}

// Transparently patch window.Storage.prototype.getItem to decompress any ⚡LZW⚡ compressed strings
if (typeof window !== "undefined" && typeof window.Storage !== "undefined" && window.Storage.prototype) {
  try {
    const origGetItem = window.Storage.prototype.getItem;
    window.Storage.prototype.getItem = function (key: string): string | null {
      const raw = origGetItem.call(this, key);
      if (raw && typeof raw === "string" && raw.startsWith("⚡LZW⚡")) {
        try {
          const decompressed = lzw_decompress(raw);
          return decompressed;
        } catch (err) {
          console.warn(`[safeStorage] Auto-decompression fallback for ${key}:`, err);
          return raw.replace(/^⚡LZW⚡/, "");
        }
      }
      return raw;
    };
  } catch (e) {
    console.warn("[safeStorage] Notice patching Storage.prototype.getItem:", e);
  }
}

const getSafeStorage = (): Storage => {
  let nativeStorage: Storage | null = null;
  try {
    if (typeof window !== "undefined" && window.localStorage) {
      const testKey = "__mabala_storage_test__";
      window.localStorage.setItem(testKey, testKey);
      window.localStorage.removeItem(testKey);
      nativeStorage = window.localStorage;
    }
  } catch (e) {
    console.warn("[Mabala Sandbox] Native localStorage is blocked, using fallback memory storage:", e);
  }

  const memoryStore: Record<string, string> = {};

  const getItemHelper = (key: string): string | null => {
    let rawVal: string | null = null;
    if (nativeStorage) {
      rawVal = nativeStorage.getItem(key);
    } else {
      rawVal = memoryStore.hasOwnProperty(key) ? memoryStore[key] : null;
    }
    
    if (rawVal && rawVal.startsWith("⚡LZW⚡")) {
      try {
        const decompressed = lzw_decompress(rawVal);
        return decompressed;
      } catch (err) {
        console.error(`[Compression Layer] Decompression failed for key: ${key}`, err);
        return rawVal;
      }
    }
    return rawVal;
  };

  const setItemHelper = (key: string, value: string) => {
    let finalValue = value;
    // Compress if the value is substantial (> 100 chars) to save local memory/storage space
    if (value && value.length > 100) {
      try {
        finalValue = lzw_compress(value);
        const originalBytes = value.length * 2;
        const compressedBytes = finalValue.length * 2;
        console.log(`[Compression Layer] Transparent compression for [${key}]: ${originalBytes} bytes -> ${compressedBytes} bytes (Saved ${((1 - compressedBytes/originalBytes)*100).toFixed(1)}%)`);
      } catch (err) {
        console.error(`[Compression Layer] Compression failed for key: ${key}`, err);
        finalValue = value;
      }
    }

    if (nativeStorage) {
      nativeStorage.setItem(key, finalValue);
    } else {
      memoryStore[key] = String(finalValue);
    }
  };

  const removeItemHelper = (key: string) => {
    if (nativeStorage) {
      nativeStorage.removeItem(key);
    } else {
      delete memoryStore[key];
    }
  };

  const clearHelper = () => {
    if (nativeStorage) {
      nativeStorage.clear();
    } else {
      for (const k in memoryStore) {
        delete memoryStore[k];
      }
    }
  };

  return {
    getItem: getItemHelper,
    setItem: setItemHelper,
    removeItem: removeItemHelper,
    clear: clearHelper,
    key: (index: number) => {
      if (nativeStorage) return nativeStorage.key(index);
      return Object.keys(memoryStore)[index] || null;
    },
    get length() {
      if (nativeStorage) return nativeStorage.length;
      return Object.keys(memoryStore).length;
    }
  } as Storage;
};

export const safeLocalStorage = getSafeStorage();

import { AgroDealerSKU, AgroDealerTenant, StockMovement, Supplier, SupplierCatalogItem } from "../types";
import { MarketplaceProduct, Vendor } from "../data/marketplaceData";
import { safeLocalStorage as localStorage } from "./safeStorage";

/**
 * Calculates Haversine distance between two sets of GPS coordinates (lat, lon) in kilometers.
 */
export function calculateHaversineDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  if (!lat1 || !lon1 || !lat2 || !lon2) return 10.0; // default fallback
  const R = 6371; // Radius of the Earth in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  return Math.round(distance * 10) / 10;
}

// Default Farmer Node Location (Choma Central Station)
export const DEFAULT_FARMER_LOCATION = {
  lat: -16.806,
  lng: 26.985
};

/**
 * Map AgroCategory to Marketplace Product category string
 */
export function mapAgroCategoryToMarketplaceCategory(category: string): string {
  const cat = (category || "").toLowerCase();
  if (cat === "seed" || cat === "fertilizer") return "Seeds & Agronomy";
  if (cat === "pesticide" || cat === "herbicide" || cat === "fungicide") return "Seeds & Agronomy";
  if (cat === "equipment" || cat === "machinery") return "Equipment & Tech";
  if (cat === "feed") return "Feeds & Formulations";
  if (cat === "veterinary" || cat === "health" || cat === "medicine") return "Veterinary & Health";
  return "Seeds & Agronomy";
}

/**
 * Map SKU icon emoji based on category
 */
export function getCategoryEmoji(category: string): string {
  const cat = (category || "").toLowerCase();
  if (cat === "seed") return "🌱";
  if (cat === "fertilizer") return "🌾";
  if (cat === "pesticide") return "🪲";
  if (cat === "herbicide") return "🌿";
  if (cat === "fungicide") return "🍄";
  if (cat === "equipment" || cat === "machinery") return "🚜";
  if (cat === "feed") return "🥣";
  if (cat === "veterinary" || cat === "health") return "💉";
  return "📦";
}

/**
 * Sanitizes and purges all hardcoded/dummy products and vendors from localStorage.
 * Ensures only listings associated with real onboarded dealers, suppliers, and verified vendors remain.
 */
export function purgeMarketplaceDummyListings(
  validDealers: AgroDealerTenant[] = [],
  validSuppliers: Supplier[] = []
): void {
  try {
    const savedVendors = localStorage.getItem("mabala_marketplace_vendors");
    if (savedVendors) {
      const parsedVendors: Vendor[] = JSON.parse(savedVendors);
      if (Array.isArray(parsedVendors)) {
        // Keep only vendors that are valid dealers, valid suppliers, or self-registered active custom merchants
        const cleanVendors = parsedVendors.filter(v => {
          if (!v || !v.id) return false;
          const isDealer = validDealers.some(d => d.id === v.id);
          const isSupplier = validSuppliers.some(s => s.id === v.id);
          const isCustomMerchant = v.id.startsWith("vend-custom-") || v.status === "Active";
          return isDealer || isSupplier || isCustomMerchant;
        });
        localStorage.setItem("mabala_marketplace_vendors", JSON.stringify(cleanVendors));
      }
    }

    const savedProducts = localStorage.getItem("mabala_marketplace_products");
    if (savedProducts) {
      const parsedProducts: MarketplaceProduct[] = JSON.parse(savedProducts);
      if (Array.isArray(parsedProducts)) {
        // Discard any dummy / test products with fake or missing vendor associations
        const cleanProducts = parsedProducts.filter(p => {
          if (!p || !p.id || !p.vendorId) return false;
          // Must be an agrodealer SKU, supplier product, or belong to a valid registered vendor
          const isAgroSku = p.id.startsWith("mkt-sku-") || (p as any).isAgroDealerSku;
          const isSupProduct = p.id.startsWith("mkt-sup-") || (p as any).isSupplierProduct;
          const isCustomProduct = p.id.startsWith("prod-custom-");
          return isAgroSku || isSupProduct || isCustomProduct;
        });
        localStorage.setItem("mabala_marketplace_products", JSON.stringify(cleanProducts));
      }
    }
  } catch (err) {
    console.error("[MarketplaceSync] Error purging dummy listings:", err);
  }
}

/**
 * Denormalizes Agro-Dealer SKUs and Supplier Catalog items into Marketplace Products.
 * Rules:
 * - Every SKU under an ONBOARDED dealer with qtyOnHand > 0 and sellingPrice > 0 appears.
 * - Every Catalog Item under an ONBOARDED supplier with qtyInStock > 0 and sellingPrice > 0 appears.
 * - Any item with 0 stock or belonging to an unregistered/dummy entity is strictly excluded.
 */
export function syncAgroSKUsToMarketplaceProducts(
  skus: AgroDealerSKU[] = [],
  dealers: AgroDealerTenant[] = [],
  farmerLocation: { lat: number; lng: number } = DEFAULT_FARMER_LOCATION,
  supplierCatalog: SupplierCatalogItem[] = [],
  suppliers: Supplier[] = []
): { marketplaceProducts: MarketplaceProduct[]; vendors: Vendor[] } {
  const vendorMap = new Map<string, Vendor>();

  // 1. Map Onboarded Agro-Dealers into Vendors
  dealers.forEach((dealer) => {
    if (!dealer || !dealer.id) return;
    const dist = calculateHaversineDistanceKm(
      farmerLocation.lat,
      farmerLocation.lng,
      dealer.gpsLocation?.lat || -16.806,
      dealer.gpsLocation?.lng || 26.985
    );
    vendorMap.set(dealer.id, {
      id: dealer.id,
      name: dealer.businessName || "Agro-Dealer Store",
      category: "Seeds & Agronomy",
      location: `${dealer.city || "Choma"}, ${dealer.province || "Southern Province"}`,
      distanceKm: dist,
      phone: dealer.ownerPhone || "+260 970 000000",
      email: dealer.ownerEmail || "dealer@mabala.cloud",
      subscriptionPackage: dealer.subscriptionTier === "monthly_180" ? "Cooperative Pro" : "Basic",
      status: dealer.subscriptionStatus === "active" ? "Active" : "Pending",
      joinedDate: dealer.createdAt ? dealer.createdAt.split("T")[0] : "2026-01-01",
      logoColor: "bg-emerald-600 text-white"
    });
  });

  // 2. Map Onboarded Suppliers into Vendors
  suppliers.forEach((supplier) => {
    if (!supplier || !supplier.id) return;
    if (!vendorMap.has(supplier.id)) {
      vendorMap.set(supplier.id, {
        id: supplier.id,
        name: supplier.name || "Institutional Supplier",
        category: "Seeds & Agronomy",
        location: supplier.address || "Institutional Hub, Lusaka",
        distanceKm: 15.0,
        phone: supplier.phone || "+260 970 000000",
        email: supplier.email || "supplier@mabala.cloud",
        subscriptionPackage: "Verified Institutional Supplier",
        status: "Active",
        joinedDate: "2026-01-01",
        logoColor: "bg-indigo-600 text-white"
      });
    }
  });

  const marketplaceProducts: MarketplaceProduct[] = [];

  // 3. Process Onboarded Agro-Dealer SKUs (strictly requiring a matching onboarded dealer)
  for (const sku of skus) {
    if (!sku || !sku.id) continue;
    if (sku.qtyOnHand > 0 && sku.sellingPrice > 0) {
      const dealer = dealers.find((d) => d.id === sku.tenantId);
      // Strictly require that the SKU belongs to an actual onboarded dealer
      if (!dealer) continue;

      const dist = calculateHaversineDistanceKm(
        farmerLocation.lat,
        farmerLocation.lng,
        dealer.gpsLocation?.lat || -16.806,
        dealer.gpsLocation?.lng || 26.985
      );
      const isChemicalCategory = ["pesticide", "herbicide", "fungicide"].includes((sku.category || "").toLowerCase());

      const product: MarketplaceProduct & {
        isAgroDealerSku?: boolean;
        skuId?: string;
        dealerTenantId?: string;
        canDeliver?: boolean;
        aiBrief?: any;
        rawCategory?: string;
        distanceKm?: number;
        sellerType?: "agrodealer" | "supplier" | "vendor";
        isVerifiedOnboarded?: boolean;
      } = {
        id: `mkt-sku-${sku.id}`,
        vendorId: dealer.id,
        vendorName: dealer.businessName,
        name: sku.productName,
        category: mapAgroCategoryToMarketplaceCategory(sku.category),
        price: sku.sellingPrice,
        stock: sku.qtyOnHand,
        description: sku.aiBrief?.applicationGuidance || `${sku.productName} (${sku.unit || "unit"}) - High-grade agro-input supplied by ${dealer.businessName}.`,
        iconEmoji: getCategoryEmoji(sku.category),
        isAdminUploaded: false,
        expiryDate: sku.expiryDate,
        unitOfMeasure: sku.unit || "unit",
        vatApplicable: false,
        productLocation: `${dealer.city || "Choma"}, ${dealer.province || "Southern Province"}`,
        isActive: true,
        isAgroDealerSku: true,
        skuId: sku.id,
        dealerTenantId: dealer.id,
        canDeliver: dealer.canDeliver !== undefined ? dealer.canDeliver : true,
        aiBrief: isChemicalCategory ? sku.aiBrief : undefined,
        rawCategory: sku.category,
        distanceKm: dist,
        sellerType: "agrodealer",
        isVerifiedOnboarded: true
      };
      marketplaceProducts.push(product as any);
    }
  }

  // 4. Process Onboarded Supplier Catalog Items (strictly requiring a matching onboarded supplier)
  for (const item of supplierCatalog) {
    if (!item || !item.id) continue;
    const itemPrice = item.recommendedSellingPrice > 0 ? item.recommendedSellingPrice : item.unitWholesaleCost;
    if (item.qtyInStock > 0 && itemPrice > 0) {
      const supplier = suppliers.find((s) => s.id === item.supplierId);
      // Strictly require that the catalog item belongs to an actual onboarded supplier
      if (!supplier) continue;

      const product: MarketplaceProduct & {
        isSupplierProduct?: boolean;
        supplierCatalogId?: string;
        supplierId?: string;
        canDeliver?: boolean;
        sellerType?: "agrodealer" | "supplier" | "vendor";
        isVerifiedOnboarded?: boolean;
        distanceKm?: number;
      } = {
        id: `mkt-sup-${item.id}`,
        vendorId: supplier.id,
        vendorName: supplier.name,
        name: item.productName,
        category: mapAgroCategoryToMarketplaceCategory(item.category),
        price: itemPrice,
        stock: item.qtyInStock,
        description: item.description || `${item.productName} (${item.unit || "unit"}) - Certified wholesale supply direct from institutional supplier ${supplier.name}.`,
        iconEmoji: getCategoryEmoji(item.category),
        isAdminUploaded: false,
        expiryDate: item.expiryDate,
        unitOfMeasure: item.unit || "unit",
        vatApplicable: false,
        productLocation: supplier.address || "National Supplier Hub",
        isActive: true,
        isSupplierProduct: true,
        supplierCatalogId: item.id,
        supplierId: supplier.id,
        canDeliver: true,
        distanceKm: 15.0,
        sellerType: "supplier",
        isVerifiedOnboarded: true
      };
      marketplaceProducts.push(product as any);
    }
  }

  return { marketplaceProducts, vendors: Array.from(vendorMap.values()) };
}

/**
 * Executes payment confirmation inventory decrement for either an Agro-Dealer SKU or a Supplier Catalog item.
 */
export function handleAgroDealerMarketplacePurchase(
  productIdOrSkuId: string,
  purchaseQty: number,
  orderId: string,
  buyerEmail: string,
  recipientName: string
): { updatedSkus: AgroDealerSKU[]; updatedMovements: StockMovement[] } {
  // 1. Check if target is a Supplier Catalog Item
  if (productIdOrSkuId.startsWith("mkt-sup-") || productIdOrSkuId.startsWith("sup-cat-")) {
    const rawSupId = productIdOrSkuId.replace(/^mkt-sup-/, "");
    try {
      const savedCatalog = localStorage.getItem("mabala_supplier_catalog");
      if (savedCatalog) {
        const catalog: SupplierCatalogItem[] = JSON.parse(savedCatalog);
        const updatedCatalog = catalog.map(item => {
          if (item.id === rawSupId || `mkt-sup-${item.id}` === productIdOrSkuId) {
            return {
              ...item,
              qtyInStock: Math.max(0, item.qtyInStock - purchaseQty)
            };
          }
          return item;
        });
        localStorage.setItem("mabala_supplier_catalog", JSON.stringify(updatedCatalog));
      }
    } catch (e) {
      console.error("Failed to decrement supplier catalog stock:", e);
    }
    return { updatedSkus: [], updatedMovements: [] };
  }

  // 2. Otherwise process Agro-Dealer SKU decrement with stockMovements ledger logging
  const savedSkus = localStorage.getItem("mabala_agd_skus");
  const skus: AgroDealerSKU[] = savedSkus ? JSON.parse(savedSkus) : [];
  const savedMovements = localStorage.getItem("mabala_agd_movements");
  const movements: StockMovement[] = savedMovements ? JSON.parse(savedMovements) : [];

  const targetSku = skus.find((s) => s.id === productIdOrSkuId || `mkt-sku-${s.id}` === productIdOrSkuId);
  if (!targetSku) {
    return { updatedSkus: skus, updatedMovements: movements };
  }

  const newQtyOnHand = Math.max(0, targetSku.qtyOnHand - purchaseQty);
  const newQtySold = (targetSku.qtySold || 0) + purchaseQty;

  const newMovement: StockMovement = {
    id: `mov-mkt-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    skuId: targetSku.id,
    productName: targetSku.productName,
    type: "sale",
    qtyDelta: -purchaseQty,
    resultingBalance: newQtyOnHand,
    timestamp: new Date().toISOString(),
    actorId: buyerEmail || "marketplace_buyer",
    actorName: recipientName || buyerEmail || "Marketplace Farmer",
    reference: `MARKETPLACE_ORDER:${orderId}`,
    reasonCode: "marketplace_reservation_consumed"
  };

  const updatedSkus = skus.map((s) => {
    if (s.id === targetSku.id) {
      return {
        ...s,
        qtyOnHand: newQtyOnHand,
        qtySold: newQtySold,
        lastMovementAt: new Date().toISOString()
      };
    }
    return s;
  });

  const updatedMovements = [newMovement, ...movements];

  localStorage.setItem("mabala_agd_skus", JSON.stringify(updatedSkus));
  localStorage.setItem("mabala_agd_movements", JSON.stringify(updatedMovements));

  return { updatedSkus, updatedMovements };
}


/**
 * Utility to safely create and dispatch events across all browser environments,
 * sandboxed iFrames, and webviews without throwing "Uncaught TypeError: Illegal constructor".
 */
export function dispatchSafeEvent(eventName: string, detail?: any): void {
  if (typeof window === "undefined") return;

  try {
    let evt: any = null;

    // Method 1: Try document.createEvent (safest and works in sandboxed iFrames)
    if (typeof document !== "undefined" && typeof document.createEvent === "function") {
      try {
        if (detail !== undefined) {
          evt = document.createEvent("CustomEvent");
          evt.initCustomEvent(eventName, true, true, detail);
        } else {
          evt = document.createEvent("Event");
          evt.initEvent(eventName, true, true);
        }
      } catch {
        evt = null;
      }
    }

    // Method 2: Synthetic event fallback (prevents Illegal constructor in sandboxed environments)
    if (!evt) {
      evt = {
        type: eventName,
        detail,
        bubbles: true,
        cancelable: true,
        preventDefault: () => {},
        stopPropagation: () => {},
        stopImmediatePropagation: () => {},
      };
    }

    try {
      window.dispatchEvent(evt);
    } catch (dispatchErr) {
      console.warn(`[SafeEvent] window.dispatchEvent exception intercepted for "${eventName}":`, dispatchErr);
    }
  } catch (err) {
    console.warn(`[SafeEvent] Safe event dispatch fallback for "${eventName}":`, err);
  }
}

/**
 * Soft Delete & Audit Utility for Mabala SaaS Platform
 * Enforces zero-hard-delete policy and versioned settings changes.
 */

import { db, auth } from "../firebase";
import { doc, updateDoc, setDoc, getDoc, collection, addDoc, serverTimestamp } from "firebase/firestore";

export async function softDeleteDoc(collectionPath: string, docId: string, deletedByUid?: string): Promise<boolean> {
  if (!db || (db as any)._dummy) return false;
  try {
    const actorUid = deletedByUid || auth?.currentUser?.uid || "system";
    const docRef = doc(db, collectionPath, docId);
    
    await updateDoc(docRef, {
      isDeleted: true,
      status: "deleted",
      deletedAt: new Date().toISOString(),
      deletedBy: actorUid,
      updatedAt: serverTimestamp()
    });

    // Write audit trail
    await addDoc(collection(db, "audit_logs"), {
      action: "SOFT_DELETE",
      collectionPath,
      docId,
      actorUid,
      timestamp: new Date().toISOString()
    });

    return true;
  } catch (err) {
    console.error("[SoftDelete] Failed to soft delete document:", err);
    return false;
  }
}

export async function recoverSoftDeletedDoc(collectionPath: string, docId: string, recoveredByUid?: string): Promise<boolean> {
  if (!db || (db as any)._dummy) return false;
  try {
    const actorUid = recoveredByUid || auth?.currentUser?.uid || "system";
    const docRef = doc(db, collectionPath, docId);

    await updateDoc(docRef, {
      isDeleted: false,
      status: "active",
      recoveredAt: new Date().toISOString(),
      recoveredBy: actorUid,
      updatedAt: serverTimestamp()
    });

    // Write audit trail
    await addDoc(collection(db, "audit_logs"), {
      action: "RECOVER_SOFT_DELETE",
      collectionPath,
      docId,
      actorUid,
      timestamp: new Date().toISOString()
    });

    return true;
  } catch (err) {
    console.error("[SoftDelete] Failed to recover soft deleted document:", err);
    return false;
  }
}

export async function saveVersionedSettings(settingsKey: string, newSettingsData: Record<string, any>, updatedByUid?: string): Promise<boolean> {
  if (!db || (db as any)._dummy) return false;
  try {
    const actorUid = updatedByUid || auth?.currentUser?.uid || "system";
    const timestamp = new Date().toISOString();

    // 1. Get current setting if exists to archive
    const currentRef = doc(db, "system_settings", settingsKey);
    const snap = await getDoc(currentRef);

    if (snap.exists()) {
      const oldData = snap.data();
      const versionId = `ver_${Date.now()}`;
      await setDoc(doc(db, "system_settings", settingsKey, "history", versionId), {
        ...oldData,
        archivedAt: timestamp,
        archivedBy: actorUid
      });
    }

    // 2. Write new setting with version counter
    const currentVersion = snap.exists() ? (snap.data().version || 1) + 1 : 1;
    await setDoc(currentRef, {
      ...newSettingsData,
      version: currentVersion,
      updatedAt: timestamp,
      updatedBy: actorUid
    }, { merge: true });

    return true;
  } catch (err) {
    console.error("[VersionedSettings] Failed to save versioned settings:", err);
    return false;
  }
}

import * as XLSX from 'xlsx';
import { ReportQueryResult } from '../services/reportAggregationEngine';

export function generateReportExcel(result: ReportQueryResult, tenantName: string = 'Mabala Agro-Dealer'): void {
  const def = result.definition;
  const wb = XLSX.utils.book_new();

  // Sheet 1: Detailed Row Dataset
  const formattedRows = result.rows.map(row => {
    const formatted: Record<string, any> = {};
    def.columns.forEach(col => {
      const rawVal = row[col.key];
      if (col.type === 'number' || col.type === 'currency' || col.type === 'percent') {
        formatted[col.label] = typeof rawVal === 'number' ? rawVal : Number(rawVal) || 0;
      } else {
        formatted[col.label] = rawVal !== undefined && rawVal !== null ? String(rawVal) : '';
      }
    });
    return formatted;
  });

  const wsData = XLSX.utils.json_to_sheet(formattedRows);

  // Set column widths dynamically
  const colWidths = def.columns.map(col => ({
    wch: Math.max(col.label.length + 4, 14)
  }));
  wsData['!cols'] = colWidths;

  XLSX.utils.book_append_sheet(wb, wsData, 'Report Data');

  // Sheet 2: Summary Metrics & Audit Metadata
  const summaryRows = [
    { Property: 'Report Title', Value: def.title },
    { Property: 'Category', Value: def.category.toUpperCase() },
    { Property: 'Tenant Name', Value: tenantName },
    { Property: 'Reporting Period', Value: `${result.period.label} (${result.period.from} to ${result.period.to})` },
    { Property: 'Generated Timestamp', Value: new Date().toISOString() },
    { Property: 'Total Records Count', Value: result.rows.length },
    { Property: '', Value: '' }, // Blank spacer
    { Property: 'KEY METRIC SUMMARY', Value: '' }
  ];

  result.summary.metrics.forEach(m => {
    summaryRows.push({
      Property: m.label,
      Value: m.formatted
    });
  });

  const wsSummary = XLSX.utils.json_to_sheet(summaryRows);
  wsSummary['!cols'] = [{ wch: 35 }, { wch: 45 }];
  XLSX.utils.book_append_sheet(wb, wsSummary, 'Summary & Audit');

  const safeTitle = def.title.replace(/[^a-zA-Z0-9]/g, '_');
  const fileName = `${safeTitle}_${result.period.from}_to_${result.period.to}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

import { jsPDF } from 'jspdf';
import { InstitutionReportResult } from '../services/institutionReportService';

export function exportInstitutionReportPdf(
  result: InstitutionReportResult,
  institutionName: string = 'Mabala Institutional Portal',
  currencySymbol: string = 'ZMW'
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const def = result.definition;
  let y = 28;

  // 1. Top Header Banner
  doc.setFillColor(15, 23, 42); // Slate 900
  doc.rect(0, 0, 210, 18, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('MABALA SAAS • INSTITUTIONAL M&E & PORTFOLIO REPORT CENTRE', 14, 11);
  doc.text(institutionName.toUpperCase(), 196, 11, { align: 'right' });

  // 2. Report Title & Subtitle
  doc.setTextColor(15, 23, 42); // Slate 900
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(def.title, 14, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139); // Slate 500
  doc.text(def.subtitle, 14, y);
  y += 4.5;

  doc.setFontSize(8);
  doc.text(`Reporting Window: ${result.period.from} to ${result.period.to}   •   Generated: ${new Date().toLocaleDateString('en-GB')}   •   Scope: Monitored Smallholder Portfolio`, 14, y);
  y += 6;

  // Horizontal divider
  doc.setDrawColor(226, 232, 240);
  doc.line(14, y, 196, y);
  y += 7;

  // 3. Executive KPI Summary Cards (Up to 4)
  if (result.kpiMetrics && result.kpiMetrics.length > 0) {
    const cards = result.kpiMetrics.slice(0, 4);
    const cardWidth = (182 - (cards.length - 1) * 3) / cards.length;

    cards.forEach((card, idx) => {
      const cardX = 14 + idx * (cardWidth + 3);
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(cardX, y, cardWidth, 16, 2, 2, 'FD');

      // Card Header
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.5);
      doc.setTextColor(100, 116, 139);
      doc.text(card.label.toUpperCase(), cardX + 3, y + 4.5);

      // Card Value
      doc.setFontSize(9.5);
      doc.setTextColor(15, 23, 42);
      doc.text(String(card.formatted), cardX + 3, y + 10.5);

      // Card Delta / Target
      if (card.target !== undefined && card.deltaPct !== undefined) {
        doc.setFontSize(6.5);
        const isGood = card.deltaPct >= 0;
        doc.setTextColor(isGood ? 16 : 225, isGood ? 185 : 29, isGood ? 129 : 72);
        const sign = isGood ? '+' : '';
        doc.text(`Tgt: ${card.target}% (${sign}${card.deltaPct}%)`, cardX + cardWidth - 3, y + 10.5, { align: 'right' });
      }
    });

    y += 21;
  }

  // 4. Data Table
  const columns = def.columns;
  const colWidth = 182 / columns.length;

  // Table Header Row
  doc.setFillColor(241, 245, 249); // Slate 100
  doc.rect(14, y - 4, 182, 6.5, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(51, 65, 85);

  columns.forEach((col, idx) => {
    const colX = 14 + idx * colWidth + (col.align === 'right' ? colWidth - 2 : col.align === 'center' ? colWidth / 2 : 2);
    const align = col.align || 'left';
    doc.text(col.label.toUpperCase(), colX, y, { align: align as any });
  });

  y += 5.5;

  // Table Body Rows
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);

  result.tableRows.forEach((row, rowIdx) => {
    // Check if new page is needed
    if (y > 270) {
      doc.addPage();
      y = 20;

      // Repeat Table Header
      doc.setFillColor(241, 245, 249);
      doc.rect(14, y - 4, 182, 6.5, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.setTextColor(51, 65, 85);
      columns.forEach((col, idx) => {
        const colX = 14 + idx * colWidth + (col.align === 'right' ? colWidth - 2 : col.align === 'center' ? colWidth / 2 : 2);
        doc.text(col.label.toUpperCase(), colX, y, { align: (col.align || 'left') as any });
      });
      y += 5.5;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
    }

    // Alternating Row Background
    if (rowIdx % 2 === 0) {
      doc.setFillColor(250, 250, 250);
      doc.rect(14, y - 3.5, 182, 5.5, 'F');
    }

    doc.setTextColor(30, 41, 59);

    columns.forEach((col, colIdx) => {
      let val = row[col.key];
      if (val === undefined || val === null) val = '—';

      let formattedVal = String(val);
      if (col.type === 'currency' && typeof val === 'number') {
        formattedVal = `${currencySymbol} ${Math.round(val).toLocaleString()}`;
      } else if (col.type === 'percent' && typeof val === 'number') {
        formattedVal = `${val}%`;
      } else if (col.type === 'number' && typeof val === 'number') {
        formattedVal = val.toLocaleString();
      }

      // Truncate if too long for column
      if (formattedVal.length > 28) {
        formattedVal = formattedVal.substring(0, 26) + '...';
      }

      const colX = 14 + colIdx * colWidth + (col.align === 'right' ? colWidth - 2 : col.align === 'center' ? colWidth / 2 : 2);
      doc.text(formattedVal, colX, y, { align: (col.align || 'left') as any });
    });

    y += 5.2;
  });

  y += 5;

  // 5. Executive Findings & Callouts
  if (result.summaryCallouts && result.summaryCallouts.length > 0 && y < 255) {
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(203, 213, 225);
    doc.roundedRect(14, y, 182, 18, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(30, 41, 59);
    doc.text('EXECUTIVE PORTFOLIO INSIGHTS & AUDIT FINDINGS', 18, y + 4.5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(71, 85, 105);

    result.summaryCallouts.slice(0, 2).forEach((callout, idx) => {
      doc.text(`• ${callout}`, 18, y + 9 + idx * 4);
    });
  }

  // 6. Page Footer & Confidentiality
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(148, 163, 184); // Slate 400
    doc.text('CONFIDENTIAL • FOR AUTHORIZED INSTITUTIONAL USE ONLY • POWERED BY MABALA SAAS', 14, 290);
    doc.text(`Page ${i} of ${pageCount}`, 196, 290, { align: 'right' });
  }

  // Save the PDF
  doc.save(`${def.exportFilename}_${result.period.from}_${result.period.to}.pdf`);
}

export function exportInstitutionReportCsv(
  result: InstitutionReportResult,
  currencySymbol: string = 'ZMW'
): void {
  const def = result.definition;
  const columns = def.columns;

  // Header row
  const headerRow = columns.map(c => `"${c.label.replace(/"/g, '""')}"`).join(',');

  // Data rows
  const dataRows = result.tableRows.map(row => {
    return columns.map(col => {
      let val = row[col.key];
      if (val === undefined || val === null) val = '';
      if (typeof val === 'number') {
        if (col.type === 'currency') return `"${currencySymbol} ${val.toFixed(2)}"`;
        if (col.type === 'percent') return `"${val}%"`;
        return `${val}`;
      }
      return `"${String(val).replace(/"/g, '""')}"`;
    }).join(',');
  });

  const csvContent = [headerRow, ...dataRows].join('\r\n');
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${def.exportFilename}_${result.period.from}_to_${result.period.to}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

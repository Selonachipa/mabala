export interface AIBriefResult {
  targetPests: string[];
  recommendedCrops: string[];
  applicationGuidance: string;
  safetyNotes: string;
  generatedAt: string;
}

/**
 * Fallback predefined briefs for common agro-chemical and seed types
 * when API is unreachable or offline
 */
const DEFAULT_BRIEFS: Record<string, AIBriefResult> = {
  pesticide: {
    targetPests: ["Fall Armyworm", "Cutworms", "Aphids", "Thrips"],
    recommendedCrops: ["Maize", "Cotton", "Vegetables", "Tomatoes"],
    applicationGuidance: "Apply at early infestation onset using a calibrated knapsack sprayer. Ensure uniform leaf coverage, directing spray into crop funnels or under leaf surfaces.",
    safetyNotes: "Toxic to aquatic life and bees. Wear protective gloves, long sleeves, and eye protection. Observe 14-day Pre-Harvest Interval (PHI).",
    generatedAt: new Date().toISOString()
  },
  herbicide: {
    targetPests: ["Broadleaf weeds", "Annual grasses", "Sedges"],
    recommendedCrops: ["Maize", "Sorghum", "Sugarcane"],
    applicationGuidance: "Apply pre-emergence or early post-emergence on damp soil. Do not apply during high wind to prevent spray drift onto non-target crops.",
    safetyNotes: "Corrosive to eyes and skin. Wash equipment thoroughly after use. Keep livestock off treated fields for 21 days.",
    generatedAt: new Date().toISOString()
  },
  fungicide: {
    targetPests: ["Grey Leaf Spot", "Northern Corn Leaf Blight", "Early & Late Blight", "Powdery Mildew"],
    recommendedCrops: ["Maize", "Wheat", "Tomatoes", "Potatoes"],
    applicationGuidance: "Preventative application recommended at first sign of humidity or disease spots. Repeat every 10–14 days during wet conditions.",
    safetyNotes: "Avoid breathing spray mist. Store in original container in a cool, locked store away from food and animal feed.",
    generatedAt: new Date().toISOString()
  },
  seed: {
    targetPests: ["Drought stress", "Fungal seed rot", "Early soil pests"],
    recommendedCrops: ["Maize", "Soya Beans", "Sunflower"],
    applicationGuidance: "Sow into moist, well-prepared seedbeds at recommended row spacing (75cm x 25cm for maize). Plant 3-5cm deep.",
    safetyNotes: "Treated seed contains chemical fungicide/insecticide dressing. Do not consume or feed to animals.",
    generatedAt: new Date().toISOString()
  },
  fertilizer: {
    targetPests: ["Nutrient deficiency", "Yellowing leaves", "Stunted root growth"],
    recommendedCrops: ["All Field Crops", "Vegetables", "Fruit Trees"],
    applicationGuidance: "Apply basal fertilizer at planting 5cm beside and below seed. Apply top dressing (Urea/CAN) when crop reaches knee height.",
    safetyNotes: "Hygroscopic material. Keep sealed in dry storage on pallets. Avoid prolonged skin contact.",
    generatedAt: new Date().toISOString()
  }
};

export async function generateAgroAIBrief(
  productName: string,
  category: string,
  unit: string
): Promise<AIBriefResult> {
  const catKey = category.toLowerCase();
  
  try {
    const res = await fetch("/api/agronomy/generate-product-brief", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ skuId: "SKU-" + Date.now(), productName, category })
    });
    if (res.ok) {
      const data = await res.json();
      if (data && (data.targetPestsWeedsDiseases || data.targetPests)) {
        return {
          targetPests: data.targetPestsWeedsDiseases || data.targetPests || ["General Pests"],
          recommendedCrops: data.recommendedCrops || ["Field Crops"],
          applicationGuidance: data.applicationGuidance || "Follow label instructions for application dosage.",
          safetyNotes: data.safetyWithholdingNote || data.safetyNotes || "Wear personal protective equipment (PPE).",
          generatedAt: data.generatedAt || new Date().toISOString()
        };
      }
    }
  } catch (err) {
    console.warn("Backend API call skipped or failed, using structured fallback brief:", err);
  }

  // Fallback to category default or general brief
  const baseBrief = DEFAULT_BRIEFS[catKey] || DEFAULT_BRIEFS.pesticide;
  return {
    ...baseBrief,
    generatedAt: new Date().toISOString()
  };
}

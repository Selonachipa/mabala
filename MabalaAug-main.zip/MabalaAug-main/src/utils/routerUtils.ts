import { safeLocalStorage as localStorage } from "./safeStorage";

export interface InitialRoute {
  tab: string;
  subTab?: string;
  extraParams: Record<string, string>;
}

export function getInitialRoute(): InitialRoute {
  if (typeof window === "undefined") {
    return { tab: "dashboard", extraParams: {} };
  }
  
  const searchParams = new URLSearchParams(window.location.search);
  let tabFromUrl = searchParams.get("tab");
  let subFromUrl = searchParams.get("sub") || searchParams.get("subTab");
  
  if (!tabFromUrl && window.location.hash) {
    const rawHash = window.location.hash.replace(/^#\/?/, "");
    if (rawHash) {
      const hashParts = rawHash.split("?");
      tabFromUrl = hashParts[0] || null;
      if (hashParts[1]) {
        const hashParams = new URLSearchParams(hashParts[1]);
        if (!subFromUrl) subFromUrl = hashParams.get("sub") || hashParams.get("subTab");
      }
    }
  }

  const tab = tabFromUrl || localStorage.getItem("mabala_active_tab") || "dashboard";
  const extraParams: Record<string, string> = {};
  searchParams.forEach((val, key) => {
    if (key !== "tab" && key !== "sub" && key !== "subTab") {
      extraParams[key] = val;
    }
  });

  return {
    tab,
    subTab: subFromUrl || undefined,
    extraParams
  };
}

export function syncUrlRoute(tab: string, subTab?: string, extraParams: Record<string, string> = {}) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem("mabala_active_tab", tab);
    const url = new URL(window.location.href);
    url.searchParams.set("tab", tab);
    if (subTab) {
      url.searchParams.set("sub", subTab);
    } else {
      url.searchParams.delete("sub");
      url.searchParams.delete("subTab");
    }
    Object.entries(extraParams).forEach(([k, v]) => {
      if (v) url.searchParams.set(k, v);
      else url.searchParams.delete(k);
    });
    url.hash = `#${tab}${subTab ? `?sub=${subTab}` : ""}`;
    if (window.location.href !== url.toString()) {
      window.history.replaceState({ tab, subTab, ...extraParams }, "", url.toString());
    }
  } catch (err) {
    console.warn("[Router] Failed to sync URL state:", err);
  }
}

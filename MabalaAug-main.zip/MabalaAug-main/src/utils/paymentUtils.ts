/**
 * Mabala - Universal Payment & Telco Detection Utilities
 * Auto-detects Airtel, MTN, and Zamtel based on prefix, normalizes phone numbers,
 * and manages unified Lipila API payment lifecycle.
 */

export type TelcoOperatorKey = "airtel" | "mtn" | "zamtel" | "unknown";
export type TelcoOperatorName = "Airtel Money" | "MTN MoMo" | "Zamtel Kwacha";

export interface TelcoDetectionResult {
  operatorKey: TelcoOperatorKey;
  operatorName: TelcoOperatorName | "Mobile Money";
  isAirtel: boolean;
  isMtn: boolean;
  isZamtel: boolean;
  isValid: boolean;
  formattedDisplay: string;
  normalizedNumber: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  prefixMessage: string;
}

/**
 * Detects the Zambian Mobile Money operator (Airtel, MTN, Zamtel) from any phone input.
 */
export function detectTelcoProvider(
  phoneInput: string,
  manualOverride?: "Airtel" | "MTN" | "Zamtel" | "Airtel Money" | "MTN MoMo" | "Zamtel Kwacha" | null
): TelcoDetectionResult {
  if (manualOverride) {
    const isAirtel = manualOverride.toLowerCase().includes("airtel");
    const isMtn = manualOverride.toLowerCase().includes("mtn");
    const isZamtel = manualOverride.toLowerCase().includes("zamtel");
    if (isAirtel) {
      return {
        operatorKey: "airtel",
        operatorName: "Airtel Money",
        isAirtel: true,
        isMtn: false,
        isZamtel: false,
        isValid: true,
        formattedDisplay: phoneInput,
        normalizedNumber: normalizePhoneForLipila(phoneInput),
        badgeBg: "bg-red-500/20",
        badgeText: "text-red-300",
        badgeBorder: "border-red-500/60",
        prefixMessage: "Airtel Money (097 / 077)"
      };
    }
    if (isMtn) {
      return {
        operatorKey: "mtn",
        operatorName: "MTN MoMo",
        isAirtel: false,
        isMtn: true,
        isZamtel: false,
        isValid: true,
        formattedDisplay: phoneInput,
        normalizedNumber: normalizePhoneForLipila(phoneInput),
        badgeBg: "bg-amber-500/20",
        badgeText: "text-amber-300",
        badgeBorder: "border-amber-500/60",
        prefixMessage: "MTN MoMo (096 / 076)"
      };
    }
    if (isZamtel) {
      return {
        operatorKey: "zamtel",
        operatorName: "Zamtel Kwacha",
        isAirtel: false,
        isMtn: false,
        isZamtel: true,
        isValid: true,
        formattedDisplay: phoneInput,
        normalizedNumber: normalizePhoneForLipila(phoneInput),
        badgeBg: "bg-emerald-500/20",
        badgeText: "text-emerald-300",
        badgeBorder: "border-emerald-500/60",
        prefixMessage: "Zamtel Kwacha (095 / 075)"
      };
    }
  }

  const clean = (phoneInput || "").replace(/\D/g, "");
  let localDigits = clean;

  if (localDigits.startsWith("260")) {
    localDigits = localDigits.slice(3);
  } else if (localDigits.startsWith("0")) {
    localDigits = localDigits.slice(1);
  }

  const isAirtel = localDigits.startsWith("97") || localDigits.startsWith("77");
  const isMtn = localDigits.startsWith("96") || localDigits.startsWith("76");
  const isZamtel = localDigits.startsWith("95") || localDigits.startsWith("75");

  const normalized = normalizePhoneForLipila(phoneInput);
  const isValidLength = clean.length >= 9 && clean.length <= 13;

  if (isAirtel) {
    return {
      operatorKey: "airtel",
      operatorName: "Airtel Money",
      isAirtel: true,
      isMtn: false,
      isZamtel: false,
      isValid: isValidLength,
      formattedDisplay: formatDisplayPhone(localDigits),
      normalizedNumber: normalized,
      badgeBg: "bg-red-500/20",
      badgeText: "text-red-300",
      badgeBorder: "border-red-500/60",
      prefixMessage: isValidLength
        ? "Verified Airtel Zambia Network (097 / 077)"
        : "Airtel Zambia detected — enter full number"
    };
  }

  if (isMtn) {
    return {
      operatorKey: "mtn",
      operatorName: "MTN MoMo",
      isAirtel: false,
      isMtn: true,
      isZamtel: false,
      isValid: isValidLength,
      formattedDisplay: formatDisplayPhone(localDigits),
      normalizedNumber: normalized,
      badgeBg: "bg-amber-500/20",
      badgeText: "text-amber-300",
      badgeBorder: "border-amber-500/60",
      prefixMessage: isValidLength
        ? "Verified MTN Zambia MoMo Network (096 / 076)"
        : "MTN Zambia detected — enter full number"
    };
  }

  if (isZamtel) {
    return {
      operatorKey: "zamtel",
      operatorName: "Zamtel Kwacha",
      isAirtel: false,
      isMtn: false,
      isZamtel: true,
      isValid: isValidLength,
      formattedDisplay: formatDisplayPhone(localDigits),
      normalizedNumber: normalized,
      badgeBg: "bg-emerald-500/20",
      badgeText: "text-emerald-300",
      badgeBorder: "border-emerald-500/60",
      prefixMessage: isValidLength
        ? "Verified Zamtel Kwacha Network (095 / 075)"
        : "Zamtel Kwacha detected — enter full number"
    };
  }

  if (clean.length > 0) {
    return {
      operatorKey: "unknown",
      operatorName: "Mobile Money",
      isAirtel: false,
      isMtn: false,
      isZamtel: false,
      isValid: false,
      formattedDisplay: clean,
      normalizedNumber: normalized,
      badgeBg: "bg-slate-900",
      badgeText: "text-slate-500",
      badgeBorder: "border-slate-800",
      prefixMessage: "Enter Airtel (097/077), MTN (096/076), or Zamtel (095/075) number."
    };
  }

  return {
    operatorKey: "unknown",
    operatorName: "Mobile Money",
    isAirtel: false,
    isMtn: false,
    isZamtel: false,
    isValid: false,
    formattedDisplay: "",
    normalizedNumber: "",
    badgeBg: "bg-slate-900",
    badgeText: "text-slate-500",
    badgeBorder: "border-slate-800",
    prefixMessage: "Enter mobile number to auto-detect operator."
  };
}

export { normalizeZambianPhone } from "./phoneNormalization";

/**
 * Normalizes phone number to 260XXXXXXXXX (E.164 without '+')
 */
export function normalizePhoneForLipila(rawPhone: string | number | undefined | null): string {
  if (!rawPhone) return "";
  let digits = String(rawPhone).trim().replace(/\D/g, "");
  if (!digits) return "";

  if (digits.startsWith("206") && digits.length >= 11) {
    digits = "260" + digits.slice(3);
  }
  if (digits.startsWith("00260")) {
    digits = digits.slice(2);
  } else if (digits.startsWith("0260") && digits.length >= 12) {
    digits = digits.slice(1);
  }
  if (digits.startsWith("2600") && digits.length === 13) {
    digits = "260" + digits.slice(4);
  }
  if (digits.length === 10 && digits.startsWith("0")) {
    digits = "260" + digits.slice(1);
  }
  if (digits.length === 9 && (digits.startsWith("9") || digits.startsWith("7"))) {
    digits = "260" + digits;
  }
  return digits;
}

function formatDisplayPhone(digits: string): string {
  if (digits.length <= 3) return digits;
  if (digits.length <= 6) return `${digits.slice(0, 3)} ${digits.slice(3)}`;
  return `${digits.slice(0, 3)} ${digits.slice(3, 6)} ${digits.slice(6, 9)}`;
}

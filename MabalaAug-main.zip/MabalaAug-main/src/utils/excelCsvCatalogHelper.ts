import * as XLSX from "xlsx";
import { AgroCategory, AgroDealerSKU, SupplierCatalogItem, StockGrantItem } from "../types";

export interface NormalizedImportSKU {
  productName: string;
  category: AgroCategory;
  unit: string;
  unitCost: number;
  sellingPrice: number;
  qtyOnHand: number;
  reorderThreshold: number;
  supplierName: string;
  batchNumber: string;
  expiryDate: string;
  barcodeSKU?: string;
  description?: string;
  isValid: boolean;
  validationError?: string;
}

export interface NormalizedSupplierCatalogRow {
  productName: string;
  category: AgroCategory;
  unit: string;
  unitWholesaleCost: number;
  recommendedSellingPrice: number;
  qtyInStock: number;
  batchNumber: string;
  expiryDate: string;
  barcodeSKU?: string;
  description?: string;
  isValid: boolean;
  validationError?: string;
}

export interface NormalizedConsignmentGrantRow {
  dealerIdentifier: string; // Dealer ID or Name
  productName: string;
  category: AgroCategory;
  unit: string;
  grantQty: number;
  unitCost: number;
  sellingPrice: number;
  batchNumber: string;
  expiryDate: string;
  isValid: boolean;
  validationError?: string;
}

// Map any category string to valid AgroCategory
export function normalizeCategory(val: any): AgroCategory {
  if (!val) return "seed";
  const str = String(val).trim().toLowerCase();
  if (str.includes("seed")) return "seed";
  if (str.includes("pesticide") || str.includes("insecticide")) return "pesticide";
  if (str.includes("herbicide") || str.includes("weed")) return "herbicide";
  if (str.includes("fungicide")) return "fungicide";
  if (str.includes("fertilizer") || str.includes("feed") || str.includes("npk") || str.includes("urea")) return "fertilizer";
  return "other";
}

// Find object key by matching loose names
function findVal(row: Record<string, any>, possibleKeys: string[]): any {
  const keys = Object.keys(row);
  for (const pKey of possibleKeys) {
    const matched = keys.find(k => k.toLowerCase().replace(/[^a-z0-9]/g, "") === pKey.toLowerCase().replace(/[^a-z0-9]/g, ""));
    if (matched && row[matched] !== undefined && row[matched] !== null && String(row[matched]).trim() !== "") {
      return row[matched];
    }
  }
  return undefined;
}

// Parse Raw Data (from JSON sheet or CSV text) into AgroDealer SKU items
export function processRawSKURows(rows: any[], tenantId: string): NormalizedImportSKU[] {
  return rows.map((row, index) => {
    const rawName = findVal(row, ["productname", "itemname", "name", "product", "title", "sku"]) || `Imported Item #${index + 1}`;
    const rawCategory = findVal(row, ["category", "productcategory", "type", "cat"]) || "seed";
    const rawUnit = findVal(row, ["unit", "packagingunit", "packaging", "packsize", "size"]) || "50kg bag";
    const rawCost = findVal(row, ["unitcost", "cost", "wholesalecost", "buyingprice", "costprice", "purchaseprice"]) || 100;
    const rawPrice = findVal(row, ["sellingprice", "unitprice", "retailprice", "price"]) || 130;
    const rawQty = findVal(row, ["qtyonhand", "quantity", "qty", "stockqty", "quantityonhand", "availableqty"]) || 50;
    const rawReorder = findVal(row, ["reorderthreshold", "reorderpoint", "reorderlevel", "minqty"]) || 15;
    const rawSupplier = findVal(row, ["suppliername", "supplier", "brand", "company"]) || "Owned Direct Stock";
    const rawBatch = findVal(row, ["batchnumber", "batch", "batchno", "lotnumber"]) || `BATCH-${Math.floor(1000 + Math.random() * 9000)}`;
    const rawExpiry = findVal(row, ["expirydate", "expiry", "expirationdate", "expdate"]) || "2027-12-31";
    const rawBarcode = findVal(row, ["barcodesku", "barcode", "upc", "code", "skucode"]);
    const rawDesc = findVal(row, ["description", "desc", "notes"]);

    const unitCost = Number(rawCost) || 0;
    const sellingPrice = Number(rawPrice) || 0;
    const qtyOnHand = Number(rawQty) || 0;
    const reorderThreshold = Number(rawReorder) || 5;

    let isValid = true;
    let validationError = "";

    if (!rawName || rawName.trim().length === 0) {
      isValid = false;
      validationError = "Missing Product Name";
    } else if (sellingPrice <= 0) {
      isValid = false;
      validationError = "Selling Price must be > 0";
    }

    return {
      productName: String(rawName).trim(),
      category: normalizeCategory(rawCategory),
      unit: String(rawUnit).trim(),
      unitCost,
      sellingPrice,
      qtyOnHand,
      reorderThreshold,
      supplierName: String(rawSupplier).trim(),
      batchNumber: String(rawBatch).trim(),
      expiryDate: String(rawExpiry).trim(),
      barcodeSKU: rawBarcode ? String(rawBarcode).trim() : undefined,
      description: rawDesc ? String(rawDesc).trim() : undefined,
      isValid,
      validationError
    };
  });
}

// Process Raw Rows into Supplier Stock Catalog Items
export function processRawSupplierCatalogRows(rows: any[]): NormalizedSupplierCatalogRow[] {
  return rows.map((row, index) => {
    const rawName = findVal(row, ["productname", "itemname", "name", "product", "title"]) || `Catalog Product #${index + 1}`;
    const rawCategory = findVal(row, ["category", "productcategory", "type"]) || "seed";
    const rawUnit = findVal(row, ["unit", "packagingunit", "packaging", "size"]) || "10kg Bag";
    const rawWholesale = findVal(row, ["unitwholesalecost", "wholesalecost", "unitcost", "cost", "wholesaleprice"]) || 250;
    const rawSelling = findVal(row, ["recommendedsellingprice", "sellingprice", "retailprice", "price"]) || 320;
    const rawQty = findVal(row, ["qtyinstock", "quantity", "qty", "stockqty", "availablestock"]) || 1000;
    const rawBatch = findVal(row, ["batchnumber", "batch", "batchno"]) || `ZM-${Math.floor(202600 + Math.random() * 900)}`;
    const rawExpiry = findVal(row, ["expirydate", "expiry", "expirationdate"]) || "2027-11-30";
    const rawBarcode = findVal(row, ["barcodesku", "barcode", "sku", "code"]);
    const rawDesc = findVal(row, ["description", "notes", "summary"]);

    const unitWholesaleCost = Number(rawWholesale) || 0;
    const recommendedSellingPrice = Number(rawSelling) || 0;
    const qtyInStock = Number(rawQty) || 0;

    let isValid = true;
    let validationError = "";

    if (!rawName || rawName.trim().length === 0) {
      isValid = false;
      validationError = "Missing Product Name";
    }

    return {
      productName: String(rawName).trim(),
      category: normalizeCategory(rawCategory),
      unit: String(rawUnit).trim(),
      unitWholesaleCost,
      recommendedSellingPrice,
      qtyInStock,
      batchNumber: String(rawBatch).trim(),
      expiryDate: String(rawExpiry).trim(),
      barcodeSKU: rawBarcode ? String(rawBarcode).trim() : undefined,
      description: rawDesc ? String(rawDesc).trim() : undefined,
      isValid,
      validationError
    };
  });
}

// Process Raw Rows into Bulk Consignment Grant Allocation
export function processRawConsignmentGrantRows(rows: any[]): NormalizedConsignmentGrantRow[] {
  return rows.map((row, index) => {
    const rawDealer = findVal(row, ["dealeridentifier", "dealername", "dealer", "agrodealer", "dealerid"]) || "Choma Agro-Inputs & Seed Centre";
    const rawProduct = findVal(row, ["productname", "itemname", "product", "name"]) || `Consignment Stock #${index + 1}`;
    const rawCategory = findVal(row, ["category", "type"]) || "seed";
    const rawUnit = findVal(row, ["unit", "packagingunit"]) || "10kg Bag";
    const rawQty = findVal(row, ["grantqty", "qty", "quantity", "allocatedqty"]) || 100;
    const rawCost = findVal(row, ["unitcost", "wholesaleprice", "cost"]) || 310;
    const rawPrice = findVal(row, ["sellingprice", "retailprice", "price"]) || 385;
    const rawBatch = findVal(row, ["batchnumber", "batch"]) || "ZM-2026-719";
    const rawExpiry = findVal(row, ["expirydate", "expiry"]) || "2027-11-30";

    const grantQty = Number(rawQty) || 0;
    const unitCost = Number(rawCost) || 0;
    const sellingPrice = Number(rawPrice) || 0;

    let isValid = true;
    let validationError = "";

    if (!rawProduct || rawProduct.trim().length === 0) {
      isValid = false;
      validationError = "Missing Product Name";
    } else if (grantQty <= 0) {
      isValid = false;
      validationError = "Grant Qty must be > 0";
    }

    return {
      dealerIdentifier: String(rawDealer).trim(),
      productName: String(rawProduct).trim(),
      category: normalizeCategory(rawCategory),
      unit: String(rawUnit).trim(),
      grantQty,
      unitCost,
      sellingPrice,
      batchNumber: String(rawBatch).trim(),
      expiryDate: String(rawExpiry).trim(),
      isValid,
      validationError
    };
  });
}

// Parse File (.xlsx, .xls, .csv) asynchronously
export function parseExcelOrCsvFile(file: File): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: "binary" });
        const firstSheet = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheet];
        const jsonRows = XLSX.utils.sheet_to_json(worksheet, { defval: "" });
        resolve(jsonRows);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = (err) => reject(err);
    reader.readAsBinaryString(file);
  });
}

// Parse Raw Text CSV String
export function parseCsvTextString(text: string): any[] {
  if (!text || !text.trim()) return [];
  try {
    const workbook = XLSX.read(text, { type: "string" });
    const firstSheet = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheet];
    return XLSX.utils.sheet_to_json(worksheet, { defval: "" });
  } catch (_) {
    // Fallback line splitter
    const lines = text.split("\n").map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length < 2) return [];
    const headers = lines[0].split(",").map(h => h.trim().replace(/^"|"$/g, ""));
    const results: any[] = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(",").map(c => c.trim().replace(/^"|"$/g, ""));
      const obj: Record<string, any> = {};
      headers.forEach((h, idx) => {
        obj[h] = cols[idx] !== undefined ? cols[idx] : "";
      });
      results.push(obj);
    }
    return results;
  }
}

// Download Excel (.xlsx) or CSV (.csv) Sample Template
export function downloadSampleTemplate(type: "AGRO_DEALER_STOCK" | "SUPPLIER_CATALOG" | "CONSIGNMENT_GRANTS", format: "xlsx" | "csv" = "xlsx") {
  let data: any[] = [];
  let fileName = "mabala_template";

  if (type === "AGRO_DEALER_STOCK") {
    fileName = "mabala_agrodealer_stock_template";
    data = [
      {
        "Product Name": "Hybrid Seed SC-719 Maize (10kg)",
        "Category": "Seed",
        "Packaging Unit": "10kg Bag",
        "Unit Cost": 310,
        "Selling Price": 385,
        "Qty On Hand": 120,
        "Reorder Threshold": 20,
        "Supplier Name": "Zambezi Seed Corp",
        "Batch Number": "ZM-2026-719",
        "Expiry Date": "2027-11-30",
        "Barcode / SKU": "ZAM-SEED-719-10KG"
      },
      {
        "Product Name": "Atrazine 500SC Selective Herbicide (5L)",
        "Category": "Herbicide",
        "Packaging Unit": "5L Canister",
        "Unit Cost": 450,
        "Selling Price": 580,
        "Qty On Hand": 45,
        "Reorder Threshold": 10,
        "Supplier Name": "CropCare Agrochemicals Ltd",
        "Batch Number": "CC-ATR-9041",
        "Expiry Date": "2028-06-30",
        "Barcode / SKU": "CC-HERB-ATR-5L"
      },
      {
        "Product Name": "CropCare D-Compound Fertilizer (50kg)",
        "Category": "Fertilizer",
        "Packaging Unit": "50kg Bag",
        "Unit Cost": 720,
        "Selling Price": 890,
        "Qty On Hand": 80,
        "Reorder Threshold": 15,
        "Supplier Name": "Yara Fertilizers Zambia",
        "Batch Number": "YARA-DCOMP-2026",
        "Expiry Date": "2029-01-01",
        "Barcode / SKU": "YARA-FERT-D-50KG"
      }
    ];
  } else if (type === "SUPPLIER_CATALOG") {
    fileName = "mabala_supplier_catalog_template";
    data = [
      {
        "Product Name": "ZAMSEED ZM-521 Early Maturing Maize (10kg)",
        "Category": "Seed",
        "Packaging Unit": "10kg Bag",
        "Unit Wholesale Cost": 290,
        "Recommended Selling Price": 360,
        "Available Stock Qty": 1800,
        "Batch Number": "ZM-2026-521",
        "Expiry Date": "2027-10-31",
        "Barcode / SKU": "ZAM-SEED-521-10KG",
        "Description": "Ultra early maturing white maize seed for lower rainfall and late planting conditions."
      },
      {
        "Product Name": "Emamectin Benzoate 5% SG (100g)",
        "Category": "Pesticide",
        "Packaging Unit": "100g Sachet",
        "Unit Wholesale Cost": 95,
        "Recommended Selling Price": 135,
        "Available Stock Qty": 3400,
        "Batch Number": "EM-2026-442",
        "Expiry Date": "2027-09-20",
        "Barcode / SKU": "CC-PEST-EMA-100G",
        "Description": "Water-soluble granule pesticide against Fall Armyworm and caterpillars."
      },
      {
        "Product Name": "CropCare Urea Top Dressing Fertilizer (50kg)",
        "Category": "Fertilizer",
        "Packaging Unit": "50kg Bag",
        "Unit Wholesale Cost": 780,
        "Recommended Selling Price": 950,
        "Available Stock Qty": 4200,
        "Batch Number": "YARA-UREA-2026",
        "Expiry Date": "2029-01-01",
        "Barcode / SKU": "YARA-FERT-UREA-50KG",
        "Description": "High nitrogen 46% Urea top dressing fertilizer for vegetative growth."
      }
    ];
  } else if (type === "CONSIGNMENT_GRANTS") {
    fileName = "mabala_consignment_grants_template";
    data = [
      {
        "Dealer Name": "Choma Agro-Inputs & Seed Centre",
        "Product Name": "Hybrid Seed SC-719 Maize (10kg)",
        "Category": "Seed",
        "Packaging Unit": "10kg Bag",
        "Grant Qty": 100,
        "Unit Wholesale Cost": 310,
        "Recommended Selling Price": 385,
        "Batch Number": "ZM-2026-719",
        "Expiry Date": "2027-11-30"
      },
      {
        "Dealer Name": "Kabwe Farmers Supply & Retail",
        "Product Name": "ZAMSEED SC-627 White Seed Maize (25kg)",
        "Category": "Seed",
        "Packaging Unit": "25kg Bag",
        "Grant Qty": 50,
        "Unit Wholesale Cost": 680,
        "Recommended Selling Price": 820,
        "Batch Number": "ZM-2026-627",
        "Expiry Date": "2027-12-15"
      }
    ];
  }

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "CatalogData");

  if (format === "csv") {
    XLSX.writeFile(workbook, `${fileName}.csv`, { bookType: "csv" });
  } else {
    XLSX.writeFile(workbook, `${fileName}.xlsx`, { bookType: "xlsx" });
  }
}

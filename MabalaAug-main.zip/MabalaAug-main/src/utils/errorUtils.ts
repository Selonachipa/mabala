/**
 * Safely formats any error, object, or response into a human-readable string.
 * Guaranteed to NEVER return an object, undefined, or raw JSON object dump, preventing React JSX rendering crashes.
 */
export function safeFormatError(err: any, fallback = "An unexpected error occurred."): string {
  if (err === null || err === undefined) return fallback;
  if (typeof err === "number" || typeof err === "boolean") return String(err);

  if (typeof err === "string") {
    const trimmed = err.trim();
    if (!trimmed) return fallback;
    if ((trimmed.startsWith("{") && trimmed.endsWith("}")) || (trimmed.startsWith("[") && trimmed.endsWith("]"))) {
      try {
        const parsed = JSON.parse(trimmed);
        if (parsed && typeof parsed === "object") {
          return safeFormatError(parsed, fallback);
        }
      } catch {}
    }
    return trimmed;
  }

  if (typeof err === "object") {
    // 1. Direct message strings
    if (typeof err.message === "string" && err.message.trim()) {
      return safeFormatError(err.message.trim(), fallback);
    }
    if (typeof err.error === "string" && err.error.trim()) {
      return safeFormatError(err.error.trim(), fallback);
    }
    if (typeof err.msg === "string" && err.msg.trim()) {
      return safeFormatError(err.msg.trim(), fallback);
    }
    if (typeof err.details === "string" && err.details.trim()) {
      return safeFormatError(err.details.trim(), fallback);
    }
    if (typeof err.reason === "string" && err.reason.trim()) {
      return safeFormatError(err.reason.trim(), fallback);
    }
    if (typeof err.description === "string" && err.description.trim()) {
      return safeFormatError(err.description.trim(), fallback);
    }
    if (typeof err.text === "string" && err.text.trim()) {
      return safeFormatError(err.text.trim(), fallback);
    }
    if (typeof err.statusText === "string" && err.statusText.trim()) {
      return err.statusText.trim();
    }

    // 2. Nested error objects
    if (err.error && typeof err.error === "object") {
      const nested = safeFormatError(err.error, "");
      if (nested && nested !== "{}" && nested !== "[]" && nested !== "null") {
        return nested;
      }
    }

    if (err.response && typeof err.response === "object") {
      const nested = safeFormatError(err.response, "");
      if (nested && nested !== "{}" && nested !== "[]" && nested !== "null") {
        return nested;
      }
    }

    if (err.data && typeof err.data === "object") {
      const nested = safeFormatError(err.data, "");
      if (nested && nested !== "{}" && nested !== "[]" && nested !== "null") {
        return nested;
      }
    }

    // 3. Status codes with no text
    if (typeof err.status === "number" || typeof err.statusCode === "number" || typeof err.code === "number" || typeof err.code === "string") {
      const code = err.status || err.statusCode || err.code;
      return `Operation failed with code: ${code}`;
    }

    try {
      const str = JSON.stringify(err);
      if (!str || str === "{}" || str === "[]" || str === '{"error":{}}') {
        return fallback;
      }
      return str;
    } catch {
      return String(err) || fallback;
    }
  }

  return String(err) || fallback;
}



export {
  normalizeZambianMobileNumber,
  normalizeZambianPhone,
  validateZambianMobileNumber,
  assertValidZambianMobileNumber,
  isValidZambianMobileNumber,
  formatZambianMobileDisplay,
  type ZambianPhoneValidationResult
} from "./phoneNormalization.js";

/**
 * Validates if an API key is a sandbox/demo key or fallback placeholder rather than a production secret key.
 */
export function isSandboxApiKey(key?: string): boolean {
  if (!key) return true;
  const clean = String(key)
    .replace(/^bearer\s+/i, "")
    .replace(/["']/g, "")
    .trim()
    .toLowerCase();
  if (!clean) return true;
  return (
    clean.includes("sandbox") ||
    clean.includes("dummy") ||
    clean.includes("sim_") ||
    clean.includes("test") ||
    clean.includes("demo") ||
    clean.startsWith("lsk_sandbox") ||
    clean.includes("lsk_019e7fa2-77d2-7ee7-bdb7-b0d7a7a10996") ||
    clean === "lipila_key"
  );
}


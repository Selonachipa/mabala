import { safeLocalStorage as localStorage, safeParseJSON } from "./safeStorage";
import { CropCycle, LivestockRecord, PoultryBatch } from "../types";

export interface CommodityCategoryItem {
  id: string;
  label: string;
  commodityName: string;
  category: string; // e.g. "Grains & Cereals", "Legumes & Oilseeds", "Horticulture", "Fruits & Orchards", "Livestock & Meats", "Poultry & Eggs", "Dairy & Milk", "Aquaculture"
  sourceType: "crop_cycle" | "orchard_block" | "livestock" | "poultry" | "dairy" | "aquaculture" | "standard";
  sourceName?: string; // e.g. "Cycle: Block 1 Frontage", "Orchard: Hass Avocado Block A", "Batch: BRO-2026-001"
  defaultUnit: string; // e.g. "Bags (50Kg)", "Litres", "Kgs", "Tonnes", "Crates (30 eggs)", "Heads", "Birds"
  defaultGrade?: string; // e.g. "Grade A", "Commercial Grade 1", "Prime Quality", "Standard"
  currentQuantity?: number;
  expectedHarvestDate?: string;
  estimatedPrice?: number;
  icon?: string;
}

export const STANDARD_COMMODITY_CATEGORIES: CommodityCategoryItem[] = [
  // Grains & Cereals
  {
    id: "std-white-maize",
    label: "White Maize Grain (Non-GMO)",
    commodityName: "White Maize Grain",
    category: "Grains & Cereals",
    sourceType: "standard",
    defaultUnit: "Bags (50Kg)",
    defaultGrade: "Grade A (Moisture ≤ 12.5%)",
    icon: "🌽"
  },
  {
    id: "std-seed-maize",
    label: "Certified Seed Maize",
    commodityName: "Certified Seed Maize",
    category: "Grains & Cereals",
    sourceType: "standard",
    defaultUnit: "Bags (50Kg)",
    defaultGrade: "Certified Seed",
    icon: "🌱"
  },
  {
    id: "std-wheat-grain",
    label: "Irrigated Wheat Grain",
    commodityName: "Wheat Grain",
    category: "Grains & Cereals",
    sourceType: "standard",
    defaultUnit: "Tonnes",
    defaultGrade: "Hard Red (Protein ≥ 12%)",
    icon: "🌾"
  },
  {
    id: "std-sorghum",
    label: "Sorghum Grain (Red/White)",
    commodityName: "Sorghum Grain",
    category: "Grains & Cereals",
    sourceType: "standard",
    defaultUnit: "Bags (50Kg)",
    defaultGrade: "Grade 1",
    icon: "🌾"
  },

  // Legumes & Oilseeds
  {
    id: "std-soybeans",
    label: "Commercial Soybeans (Non-GMO)",
    commodityName: "Soybeans",
    category: "Legumes & Oilseeds",
    sourceType: "standard",
    defaultUnit: "Bags (50Kg)",
    defaultGrade: "Grade 1 (Oil ≥ 18%)",
    icon: "🫘"
  },
  {
    id: "std-sunflower",
    label: "Sunflower Seed (High Oil Content)",
    commodityName: "Sunflower Seeds",
    category: "Legumes & Oilseeds",
    sourceType: "standard",
    defaultUnit: "Bags (50Kg)",
    defaultGrade: "Standard Commercial",
    icon: "🌻"
  },
  {
    id: "std-groundnuts",
    label: "Shelled Groundnuts / Peanuts",
    commodityName: "Groundnuts",
    category: "Legumes & Oilseeds",
    sourceType: "standard",
    defaultUnit: "Bags (50Kg)",
    defaultGrade: "Aflatoxin Free (Grade A)",
    icon: "🥜"
  },
  {
    id: "std-cotton",
    label: "Zambia Seed Cotton (Hand Picked)",
    commodityName: "Seed Cotton",
    category: "Cash Crops",
    sourceType: "standard",
    defaultUnit: "Bags (50Kg)",
    defaultGrade: "Class A Lint",
    icon: "☁️"
  },

  // Horticulture & Vegetables
  {
    id: "std-tomatoes",
    label: "Fresh Table Tomatoes (Roma / Rodade)",
    commodityName: "Fresh Tomatoes",
    category: "Horticulture",
    sourceType: "standard",
    defaultUnit: "Wooden Crates (18Kg)",
    defaultGrade: "Grade 1 Saladette",
    icon: "🍅"
  },
  {
    id: "std-onions",
    label: "Cured Dry Bulb Onions (Texas Grano)",
    commodityName: "Dry Bulb Onions",
    category: "Horticulture",
    sourceType: "standard",
    defaultUnit: "Pockets (10Kg)",
    defaultGrade: "Grade 1 Medium (50-70mm)",
    icon: "🧅"
  },
  {
    id: "std-green-beans",
    label: "French / Green Beans (Export Grade)",
    commodityName: "French Green Beans",
    category: "Horticulture",
    sourceType: "standard",
    defaultUnit: "Kgs",
    defaultGrade: "Export Quality Extra Fine",
    icon: "🫛"
  },
  {
    id: "std-cabbage",
    label: "Headed Cabbage (Green / Drumhead)",
    commodityName: "Headed Cabbage",
    category: "Horticulture",
    sourceType: "standard",
    defaultUnit: "Bags (25-30 Heads)",
    defaultGrade: "Grade 1 Dense Heads",
    icon: "🥬"
  },
  {
    id: "std-irish-potatoes",
    label: "Irish Table Potatoes (Washed)",
    commodityName: "Irish Potatoes",
    category: "Horticulture",
    sourceType: "standard",
    defaultUnit: "Pockets (10Kg)",
    defaultGrade: "Grade 1 Large",
    icon: "🥔"
  },

  // Orchard Fruits & Tree Crops
  {
    id: "std-hass-avocado",
    label: "Hass Avocados (Export Grade)",
    commodityName: "Hass Avocados",
    category: "Fruits & Orchards",
    sourceType: "standard",
    defaultUnit: "Cartons (4Kg)",
    defaultGrade: "Class 1 (Dry Matter ≥ 23%)",
    icon: "🥑"
  },
  {
    id: "std-macadamia",
    label: "Macadamia Nuts (Nut in Shell)",
    commodityName: "Macadamia Nuts",
    category: "Fruits & Orchards",
    sourceType: "standard",
    defaultUnit: "Kgs",
    defaultGrade: "Sound Kernel Recovery ≥ 33%",
    icon: "🌰"
  },
  {
    id: "std-citrus-oranges",
    label: "Citrus / Sweet Valencia Oranges",
    commodityName: "Valencia Oranges",
    category: "Fruits & Orchards",
    sourceType: "standard",
    defaultUnit: "Pockets (10Kg)",
    defaultGrade: "Grade 1 Juicy",
    icon: "🍊"
  },
  {
    id: "std-bananas",
    label: "Green Cavendish Bananas",
    commodityName: "Cavendish Bananas",
    category: "Fruits & Orchards",
    sourceType: "standard",
    defaultUnit: "Crater Boxes (18Kg)",
    defaultGrade: "Grade 1 First Quality Hands",
    icon: "🍌"
  },

  // Dairy & Fresh Milk
  {
    id: "std-raw-milk",
    label: "Raw Fresh Cow Milk (Chilled Bulk)",
    commodityName: "Raw Fresh Milk",
    category: "Dairy & Milk",
    sourceType: "standard",
    defaultUnit: "Litres",
    defaultGrade: "Grade A (Butterfat ≥ 3.5%, TPC < 50k)",
    icon: "🥛"
  },
  {
    id: "std-fermented-milk",
    label: "Fermented Traditional Milk (Mabisi)",
    commodityName: "Fermented Milk (Mabisi)",
    category: "Dairy & Milk",
    sourceType: "standard",
    defaultUnit: "Litres",
    defaultGrade: "Cultured Full Cream",
    icon: "🥛"
  },

  // Poultry & Table Eggs
  {
    id: "std-broiler-chickens",
    label: "Live / Dressed Broiler Chickens",
    commodityName: "Broiler Chickens",
    category: "Poultry & Eggs",
    sourceType: "standard",
    defaultUnit: "Birds",
    defaultGrade: "Market Ready (1.8 - 2.2 Kg)",
    icon: "🐔"
  },
  {
    id: "std-table-eggs",
    label: "Fresh Farm Table Eggs",
    commodityName: "Table Eggs",
    category: "Poultry & Eggs",
    sourceType: "standard",
    defaultUnit: "Crates (30 Eggs)",
    defaultGrade: "Large Grade A Brown",
    icon: "🥚"
  },
  {
    id: "std-indigenous-chickens",
    label: "Village / Free-Range Chickens",
    commodityName: "Village Chickens",
    category: "Poultry & Eggs",
    sourceType: "standard",
    defaultUnit: "Birds",
    defaultGrade: "Live Healthy Mature Birds",
    icon: "🐓"
  },

  // Livestock & Meat
  {
    id: "std-beef-cattle",
    label: "Live Beef Cattle / Steers",
    commodityName: "Beef Cattle",
    category: "Livestock & Meats",
    sourceType: "standard",
    defaultUnit: "Heads",
    defaultGrade: "Prime Feedlot Finished",
    icon: "🐂"
  },
  {
    id: "std-boer-goats",
    label: "Live Boer Goats (Slaughter / Breeding)",
    commodityName: "Boer Goats",
    category: "Livestock & Meats",
    sourceType: "standard",
    defaultUnit: "Heads",
    defaultGrade: "Grade A (35-45 Kg live weight)",
    icon: "🐐"
  },
  {
    id: "std-pigs",
    label: "Market Ready Porkers / Baconers",
    commodityName: "Porkers / Pigs",
    category: "Livestock & Meats",
    sourceType: "standard",
    defaultUnit: "Heads",
    defaultGrade: "Top Grade (70-90 Kg)",
    icon: "🐖"
  },

  // Aquaculture
  {
    id: "std-tilapia",
    label: "Fresh Zambezi Tilapia / Bream",
    commodityName: "Fresh Tilapia",
    category: "Aquaculture",
    sourceType: "standard",
    defaultUnit: "Kgs",
    defaultGrade: "Table Size (350-500g each)",
    icon: "🐟"
  }
];

export interface ExtractCommodityOptions {
  crops?: CropCycle[];
  livestock?: LivestockRecord[];
  poultryBatches?: PoultryBatch[];
  tenantId?: string;
  includeStandardFallbacks?: boolean;
}

/**
 * Extracts and synthesizes all real created crop cycles, orchard blocks,
 * active livestocks, poultry batches, and milk production records from live state and storage.
 */
export function getAvailableCommodityCategories(options: ExtractCommodityOptions = {}): {
  all: CommodityCategoryItem[];
  byCategory: Record<string, CommodityCategoryItem[]>;
  bySource: Record<string, CommodityCategoryItem[]>;
} {
  const resultList: CommodityCategoryItem[] = [];
  const seenKeys = new Set<string>();

  const addUnique = (item: CommodityCategoryItem) => {
    const key = `${item.sourceType}-${item.commodityName.toLowerCase()}-${(item.sourceName || "").toLowerCase()}`;
    if (!seenKeys.has(key)) {
      seenKeys.add(key);
      resultList.push(item);
    }
  };

  // 1. EXTRACT FROM CROP CYCLES (Field Crops, Annuals & Horticulture)
  let cropsData: CropCycle[] = options.crops || [];
  if (cropsData.length === 0) {
    try {
      const storedCrops = safeParseJSON(localStorage.getItem("mabala_crops") || "[]", []);
      if (Array.isArray(storedCrops)) cropsData = storedCrops;
    } catch (_) {}
  }

  cropsData.forEach((cycle) => {
    if (!cycle) return;
    const cropName = cycle.cropType || cycle.cropName || "Field Crop";
    const blockName = cycle.fieldBlock || "Main Field";
    const variety = cycle.variety ? ` (${cycle.variety})` : "";
    const isOrchard = cycle.cycleType === "perennial_orchard" || !!cycle.orchard;

    let defaultUnit = "Bags (50Kg)";
    let cat = "Grains & Cereals";
    let icon = "🌾";

    const lower = cropName.toLowerCase();
    if (lower.includes("maize") || lower.includes("corn")) {
      cat = "Grains & Cereals";
      defaultUnit = "Bags (50Kg)";
      icon = "🌽";
    } else if (lower.includes("soy") || lower.includes("bean") || lower.includes("groundnut") || lower.includes("sunflower")) {
      cat = "Legumes & Oilseeds";
      defaultUnit = "Bags (50Kg)";
      icon = "🫘";
    } else if (lower.includes("tomato") || lower.includes("onion") || lower.includes("cabbage") || lower.includes("potato") || lower.includes("pepper")) {
      cat = "Horticulture";
      defaultUnit = lower.includes("tomato") ? "Crates (18Kg)" : lower.includes("onion") || lower.includes("potato") ? "Pockets (10Kg)" : "Kgs";
      icon = "🍅";
    } else if (isOrchard || lower.includes("avocado") || lower.includes("macadamia") || lower.includes("orange") || lower.includes("mango") || lower.includes("banana")) {
      cat = "Fruits & Orchards";
      defaultUnit = "Kgs";
      icon = "🌳";
    }

    const expectedKg = cycle.expectedYieldKg || cycle.projectedYield || 0;
    const yieldText = expectedKg > 0 ? ` [${expectedKg.toLocaleString()} Kg Est.]` : "";

    addUnique({
      id: `crop-${cycle.id || Math.random().toString()}`,
      label: `${icon} ${cropName}${variety} — Block: ${blockName}${yieldText}`,
      commodityName: `${cropName}${variety}`,
      category: isOrchard ? "Fruits & Orchards" : cat,
      sourceType: isOrchard ? "orchard_block" : "crop_cycle",
      sourceName: `Crop Cycle: ${blockName} (${cycle.status || "Active"})`,
      defaultUnit,
      defaultGrade: "Grade A Standard",
      currentQuantity: expectedKg,
      expectedHarvestDate: cycle.expectedHarvestDate,
      estimatedPrice: cycle.expectedSellingPricePerKg || cycle.expectedSellingPricePerUnit || undefined,
      icon
    });
  });

  // 2. EXTRACT FROM ORCHARD BLOCKS & TREES (Perennial fruits, Macadamia, Avocado, Citrus)
  try {
    const storedTrees = safeParseJSON(localStorage.getItem("mabala_orchard_trees") || "[]", []);
    if (Array.isArray(storedTrees)) {
      const blockAggregates: Record<string, { fruitType: string; variety?: string; treeCount: number; blockName: string }> = {};
      
      storedTrees.forEach((t: any) => {
        if (!t) return;
        const bName = t.blockName || t.blockId || "Orchard Block";
        const fType = t.fruitType || t.variety || "Fruit Tree";
        const key = `${bName}-${fType}`;
        if (!blockAggregates[key]) {
          blockAggregates[key] = {
            fruitType: fType,
            variety: t.variety,
            treeCount: 0,
            blockName: bName
          };
        }
        blockAggregates[key].treeCount += (t.treeCount || 1);
      });

      Object.values(blockAggregates).forEach((blk) => {
        addUnique({
          id: `orchard-tree-${blk.blockName}-${blk.fruitType}`,
          label: `🌳 ${blk.fruitType} (${blk.treeCount} Trees) — Block: ${blk.blockName}`,
          commodityName: blk.fruitType,
          category: "Fruits & Orchards",
          sourceType: "orchard_block",
          sourceName: `Orchard Block: ${blk.blockName}`,
          defaultUnit: "Kgs",
          defaultGrade: "Class 1 Commercial Grade",
          currentQuantity: blk.treeCount * 40, // avg yield estimate
          icon: "🌳"
        });
      });
    }
  } catch (_) {}

  // 3. EXTRACT FROM ACTIVE LIVESTOCK REGISTRY (Cattle, Goats, Sheep, Pigs)
  let livestockData: LivestockRecord[] = options.livestock || [];
  if (livestockData.length === 0) {
    try {
      const storedLivestock = safeParseJSON(localStorage.getItem("mabala_livestock") || "[]", []);
      if (Array.isArray(storedLivestock)) livestockData = storedLivestock;
    } catch (_) {}
  }

  if (livestockData.length > 0) {
    // Group active livestock by species and breed
    const speciesGroups: Record<string, { count: number; species: string; breed: string; tags: string[]; isDairy: boolean }> = {};

    livestockData.forEach((rec) => {
      if (!rec || rec.deletedAt) return;
      const species = rec.species || rec.type || "Livestock";
      const breed = rec.breed || "Standard Breed";
      const isDairy = (rec as any).isDairy || species.toLowerCase().includes("dairy") || breed.toLowerCase().includes("friesian") || breed.toLowerCase().includes("jersey");
      const groupKey = `${species}-${breed}-${isDairy ? "dairy" : "meat"}`;

      if (!speciesGroups[groupKey]) {
        speciesGroups[groupKey] = {
          count: 0,
          species,
          breed,
          tags: [],
          isDairy
        };
      }
      speciesGroups[groupKey].count += 1;
      if (rec.tagId && speciesGroups[groupKey].tags.length < 5) {
        speciesGroups[groupKey].tags.push(rec.tagId);
      }
    });

    Object.values(speciesGroups).forEach((grp) => {
      const isCattle = grp.species.toLowerCase().includes("cattle");
      const isGoat = grp.species.toLowerCase().includes("goat");
      const isSheep = grp.species.toLowerCase().includes("sheep");
      const isPig = grp.species.toLowerCase().includes("pig");

      const icon = isCattle ? "🐂" : isGoat ? "🐐" : isSheep ? "🐑" : isPig ? "🐖" : "🐾";

      addUnique({
        id: `livestock-${grp.species}-${grp.breed}`,
        label: `${icon} Live ${grp.breed} ${grp.species} (${grp.count} Heads Registered)`,
        commodityName: `Live ${grp.breed} ${grp.species}`,
        category: "Livestock & Meats",
        sourceType: "livestock",
        sourceName: `Active Herd: ${grp.species} (${grp.count} heads)`,
        defaultUnit: "Heads",
        defaultGrade: "Prime Grade A",
        currentQuantity: grp.count,
        icon
      });
    });
  }

  // 4. EXTRACT FROM REGISTERED POULTRY BATCHES (Broilers, Layers, Free-range, Eggs)
  let poultryData: PoultryBatch[] = options.poultryBatches || [];
  if (poultryData.length === 0) {
    try {
      const storedPoultry = safeParseJSON(localStorage.getItem("mabala_poultry") || "[]", []);
      if (Array.isArray(storedPoultry)) poultryData = storedPoultry;
    } catch (_) {}
  }

  poultryData.forEach((batch) => {
    if (!batch) return;
    const batchName = batch.batchName || batch.batchId || "Poultry Batch";
    const birdType = batch.birdType || "Broilers (Meat)";
    const count = batch.currentCount || batch.quantity || 0;
    const isLayer = birdType.toLowerCase().includes("layer") || birdType.toLowerCase().includes("egg");

    // Add bird category
    addUnique({
      id: `poultry-birds-${batch.id || batch.batchId}`,
      label: `🐔 ${birdType} — ${batchName} (${count.toLocaleString()} Birds Active)`,
      commodityName: birdType,
      category: "Poultry & Eggs",
      sourceType: "poultry",
      sourceName: `Batch: ${batch.batchId || batchName} (${batch.status || "Active"})`,
      defaultUnit: "Birds",
      defaultGrade: "Table Ready Grade A",
      currentQuantity: count,
      icon: "🐔"
    });

    // If layers or eggs batch, also provide Table Eggs commodity category
    if (isLayer) {
      const estCrates = Math.round(count * 0.8 / 30); // ~80% lay rate converted to 30-egg crates
      addUnique({
        id: `poultry-eggs-${batch.id || batch.batchId}`,
        label: `🥚 Fresh Table Eggs — ${batchName} (~${estCrates} Crates/Day Projected)`,
        commodityName: "Fresh Farm Table Eggs",
        category: "Poultry & Eggs",
        sourceType: "poultry",
        sourceName: `Batch: ${batch.batchId} Egg Production`,
        defaultUnit: "Crates (30 Eggs)",
        defaultGrade: "Large Brown Grade A",
        currentQuantity: estCrates * 7,
        icon: "🥚"
      });
    }
  });

  // 5. EXTRACT FROM MILK PRODUCED / DAIRY LOGS
  try {
    const milkingLogs = safeParseJSON(localStorage.getItem("mabala_milking_logs") || "[]", []);
    if (Array.isArray(milkingLogs) && milkingLogs.length > 0) {
      const totalRecordedLitres = milkingLogs.reduce((sum: number, log: any) => sum + (Number(log.totalLitres || log.litres || (log.morning || 0) + (log.afternoon || 0) + (log.evening || 0)) || 0), 0);
      
      addUnique({
        id: "dairy-milk-produced-live",
        label: `🥛 Raw Fresh Cow Milk (Logged Production: ${totalRecordedLitres.toLocaleString()} L)`,
        commodityName: "Raw Fresh Cow Milk",
        category: "Dairy & Milk",
        sourceType: "dairy",
        sourceName: `Dairy Herd Milking Register (${milkingLogs.length} logs)`,
        defaultUnit: "Litres",
        defaultGrade: "Grade A Chilled Raw Milk (Butterfat ≥ 3.5%)",
        currentQuantity: totalRecordedLitres,
        icon: "🥛"
      });
    }
  } catch (_) {}

  // 6. SUPPLEMENT WITH STANDARD REGIONAL COMMODITIES (If requested or if list is empty)
  if (options.includeStandardFallbacks !== false || resultList.length === 0) {
    STANDARD_COMMODITY_CATEGORIES.forEach((std) => {
      addUnique(std);
    });
  }

  // Organize by Category and Source
  const byCategory: Record<string, CommodityCategoryItem[]> = {};
  const bySource: Record<string, CommodityCategoryItem[]> = {};

  resultList.forEach((item) => {
    if (!byCategory[item.category]) byCategory[item.category] = [];
    byCategory[item.category].push(item);

    if (!bySource[item.sourceType]) bySource[item.sourceType] = [];
    bySource[item.sourceType].push(item);
  });

  return {
    all: resultList,
    byCategory,
    bySource
  };
}

class ListenerRegistry {
  private listeners: Map<string, () => void>;

  constructor() {
    this.listeners = new Map<string, () => void>();
  }

  register(id: string, unsubscribeFn: () => void): void {
    // if a listener with this id already exists, kill it first
    this.unregister(id);
    this.listeners.set(id, unsubscribeFn);
  }

  unregister(id: string): void {
    const unsub = this.listeners.get(id);
    if (unsub) {
      unsub();
      this.listeners.delete(id);
    }
  }

  unregisterAll(): void {
    for (const unsub of this.listeners.values()) {
      unsub();
    }
    this.listeners.clear();
  }
}

export const listenerRegistry = new ListenerRegistry();

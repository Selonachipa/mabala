import { safeLocalStorage as localStorage } from "./safeStorage";
import { normalizeZambianMobileNumber, isValidZambianMobileNumber } from "./phoneUtils";
import { safeFormatError } from "./errorUtils";

let cachedApiBase: string | null = null;

export async function discoverApiBase(): Promise<string> {
  // 1. Always prioritize the current browser origin if it is hosting the active backend
  if (typeof window !== "undefined" && window.location?.origin) {
    try {
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), 1200);
      const res = await fetch("/api/health", { signal: controller.signal });
      clearTimeout(id);
      if (res.ok) {
        const json = await res.json();
        if (json && (json.status === "healthy" || json.status === "ok")) {
          cachedApiBase = "";
          return "";
        }
      }
    } catch (_) {}
  }

  try {
    const override = localStorage.getItem("mabala_api_base_override");
    if (override && !override.includes("mabala.cloud") && !override.startsWith("http:")) {
      cachedApiBase = override;
      return override;
    }
  } catch (_) {}

  if (cachedApiBase !== null) return cachedApiBase;

  const candidates: string[] = [];
  if (typeof window !== "undefined" && window.location?.origin) {
    candidates.push(window.location.origin);
  }

  const envUrl = (import.meta as any).env?.VITE_BACKEND_URL || (import.meta as any).env?.VITE_API_URL;
  if (envUrl && typeof envUrl === "string" && !envUrl.includes("mabala.cloud") && !envUrl.startsWith("http:")) {
    candidates.push(envUrl.replace(/\/+$/, ""));
  }

  try {
    const saved = localStorage.getItem("mabala_api_base_v2");
    if (saved && !saved.includes("mabala.cloud") && !saved.startsWith("http:")) {
      candidates.push(saved);
    }
  } catch (_) {}

  const uniqueCandidates = Array.from(new Set(candidates));
  const pingPromises = uniqueCandidates.map(async (base) => {
    try {
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), 1200);
      const res = await fetch(`${base}/api/health`, { signal: controller.signal });
      clearTimeout(id);
      if (res.ok) {
        const json = await res.json();
        if (json && (json.status === "healthy" || json.status === "ok")) {
          return base === window.location.origin ? "" : base;
        }
      }
    } catch (_) {}
    return null;
  });

  const results = await Promise.all(pingPromises);
  const found = results.find((r) => r !== null);
  if (found !== undefined && found !== null) {
    cachedApiBase = found;
    try {
      localStorage.setItem("mabala_api_base_v2", found);
    } catch (_) {}
    return found;
  }

  cachedApiBase = "";
  return "";
}

/**
 * Universal safe JSON fetch client with intelligent fallback and strict error reporting.
 */
export async function safeFetchJsonClient(url: string, options?: RequestInit): Promise<any> {
  // Sanitize headers to guarantee no non-ASCII or invalid header characters
  const sanitizedHeaders: Record<string, string> = {};
  if (options?.headers) {
    if (options.headers instanceof Headers) {
      options.headers.forEach((v, k) => {
        const cleanK = String(k).replace(/[^\x21-\x7E]/g, "").trim();
        const cleanV = String(v).replace(/[^\x00-\xFF]/g, "").trim();
        if (cleanK) sanitizedHeaders[cleanK] = cleanV;
      });
    } else if (Array.isArray(options.headers)) {
      options.headers.forEach(([k, v]) => {
        const cleanK = String(k).replace(/[^\x21-\x7E]/g, "").trim();
        const cleanV = String(v).replace(/[^\x00-\xFF]/g, "").trim();
        if (cleanK) sanitizedHeaders[cleanK] = cleanV;
      });
    } else if (typeof options.headers === "object") {
      for (const [k, v] of Object.entries(options.headers)) {
        if (k && v !== undefined && v !== null) {
          const cleanK = String(k).replace(/[^\x21-\x7E]/g, "").trim();
          const cleanV = String(v).replace(/[^\x00-\xFF]/g, "").trim();
          if (cleanK) sanitizedHeaders[cleanK] = cleanV;
        }
      }
    }
  }

  const cleanOptions: RequestInit = {
    ...options,
    headers: sanitizedHeaders,
  };

  // Client-Side Pre-Flight Validation for Payload
  if (cleanOptions.body && typeof cleanOptions.body === "string" && (url.includes("/api/payments/collect") || url.includes("/api/payments/disburse"))) {
    try {
      const payload = JSON.parse(cleanOptions.body);
      const targetPhone = payload.accountNumber || payload.phone || payload.phoneNumber || payload.mobile;
      if (targetPhone && !isValidZambianMobileNumber(targetPhone)) {
        const normalized = normalizeZambianMobileNumber(targetPhone);
        if (!isValidZambianMobileNumber(normalized)) {
          console.error(`[safeFetchJsonClient Validation Failure] Target phone ${targetPhone} is invalid.`);
        }
      }
    } catch (_) {}
  }

  const apiBase = await discoverApiBase();
  const targetUrl = url.startsWith("http") ? url : `${apiBase}${url.startsWith("/") ? "" : "/"}${url}`;

  // Helper diagnostics for network failures
  const diagnoseNetworkError = (error: any, attemptUrl: string, reqOptions?: RequestInit) => {
    let report = "";
    const origin = typeof window !== "undefined" && window.location ? window.location.origin : "";
    const resolvedTarget = attemptUrl.startsWith("http") ? attemptUrl : `${origin}${attemptUrl.startsWith("/") ? "" : "/"}${attemptUrl}`;
    const isHttps = resolvedTarget.startsWith("https:");
    const isClientHttps = origin.startsWith("https:");
    
    let isCrossDomain = false;
    try {
      const parsedTarget = new URL(resolvedTarget);
      isCrossDomain = parsedTarget.origin !== origin;
    } catch (_) {}

    let extractedPhone = "";
    if (reqOptions && reqOptions.body) {
      try {
        const bodyObj = typeof reqOptions.body === "string" ? JSON.parse(reqOptions.body) : reqOptions.body;
        extractedPhone = bodyObj.accountNumber || bodyObj.phone || bodyObj.phoneNumber || bodyObj.mobile || "";
      } catch (_) {}
    }

    if (isClientHttps && !isHttps) {
      report += `[Mixed Content Block: HTTP targeted from HTTPS origin]. `;
    } else if (isCrossDomain) {
      report += `[Prospective CORS block: Cross-Origin access policy failed]. `;
    }
    if (isHttps) {
      report += `[Prospective SSL Handshake Block]. `;
    } else {
      report += `[Local connection error or network offline]. `;
    }
    return report + `Details: ${error.message || "Unknown error"}`;
  };

  const handleResponse = async (res: Response, attemptUrl: string) => {
    const contentType = res.headers.get("content-type") || "";
    const isJson = contentType.toLowerCase().includes("application/json");

    if (!res.ok) {
      let errMsg = `Request to ${attemptUrl} failed with status ${res.status} (${res.statusText})`;
      if (res.status === 429 && attemptUrl.includes("/api/payments/check-status")) {
        return { status: "Pending", state: "Processing", message: "Transaction verification in progress. Retrying automatically..." };
      }
      if (isJson) {
        try {
          const errData = await res.clone().json();
          errMsg = safeFormatError(errData, errMsg);
        } catch (_) {}
      } else {
        try {
          const text = await res.clone().text();
          if (text && text.length < 200) errMsg = text;
        } catch (_) {}
      }
      const err = new Error(errMsg);
      (err as any).status = res.status;
      (err as any).statusText = res.statusText;
      throw err;
    }

    if (isJson) {
      try {
        const jsonPayload = await res.json();
        return jsonPayload;
      } catch (parseErr: any) {
        throw new Error(`Malformed JSON response from ${attemptUrl}: ${parseErr.message}`);
      }
    } else {
      let textStr = "";
      try {
        textStr = await res.text();
        const parsed = JSON.parse(textStr);
        return parsed;
      } catch (_) {}

      if (attemptUrl.includes("/api/payments/list")) {
        return { status: "success", count: 0, payments: [] };
      }
      if (attemptUrl.includes("/api/payments/check-balance")) {
        return { hasBalance: true, message: "Balance pre-check bypassed." };
      }
      throw new Error("Unexpected non-JSON response from server.");
    }
  };

  const fetchWithResponseCheck = async (fetchUrl: string) => {
    try {
      const res = await fetch(fetchUrl, cleanOptions);
      return await handleResponse(res, fetchUrl);
    } catch (networkErr: any) {
      const detailedDiagnostic = diagnoseNetworkError(networkErr, fetchUrl, cleanOptions);
      if (fetchUrl.includes("/api/payments/list")) {
        return { status: "success", count: 0, payments: [] };
      }
      if (fetchUrl.includes("/api/payments/check-status")) {
        const ref = fetchUrl.split("referenceId=")[1]?.split("&")[0] || "";
        return { status: "Pending", referenceId: ref, message: "Network offline/unreachable; status verification deferred." };
      }
      const richError = new Error(`${networkErr.message || "Failed to fetch"} (${detailedDiagnostic})`);
      (richError as any).originalError = networkErr;
      throw richError;
    }
  };

  try {
    return await fetchWithResponseCheck(targetUrl);
  } catch (err: any) {
    if (url.startsWith("/") && targetUrl !== url) {
      try {
        localStorage.removeItem("mabala_api_base_v2");
        cachedApiBase = "";
        return await fetchWithResponseCheck(url);
      } catch (fallbackErr: any) {
        if (url.includes("/api/payments/list")) {
          return { success: true, payments: [] };
        }
        if (url.includes("/api/payments/check-status")) {
          const ref = url.split("referenceId=")[1]?.split("&")[0] || "";
          return { status: "Pending", referenceId: ref, message: "Network unavailable; payment will reconcile asynchronously." };
        }
        throw fallbackErr;
      }
    }
    throw err;
  }
}

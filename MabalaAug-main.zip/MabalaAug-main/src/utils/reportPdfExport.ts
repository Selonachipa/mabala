import { jsPDF } from 'jspdf';
import { ReportQueryResult } from '../services/reportAggregationEngine';

export function generateReportPdf(result: ReportQueryResult, currencySymbol: string = 'ZMW', tenantName: string = 'Mabala Agro-Dealer'): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const def = result.definition;
  let y = 30;

  // Header band
  doc.setFillColor(30, 41, 59); // Slate 800
  doc.rect(0, 0, 210, 18, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('MABALA SAAS REPORT CENTRE • AGRO-DEALER ENGINE', 14, 11);
  doc.text(tenantName.toUpperCase(), 196, 11, { align: 'right' });

  // Document Title & Metadata
  doc.setTextColor(15, 23, 42); // Slate 900
  doc.setFontSize(14);
  doc.text(def.title, 14, y);
  y += 5.5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139); // Slate 500
  doc.text(def.description, 14, y);
  y += 5;

  doc.text(`Reporting Period: ${result.period.label} (${result.period.from} to ${result.period.to})`, 14, y);
  if (result.priorPeriod) {
    doc.text(`   •   Comparison vs. ${result.priorPeriod.label}`, 95, y);
  }
  y += 7;

  doc.setDrawColor(226, 232, 240);
  doc.line(14, y, 196, y);
  y += 8;

  // Render Key Metrics Summary Cards
  if (result.summary.metrics.length > 0) {
    const cardCount = Math.min(4, result.summary.metrics.length);
    const cardWidth = (182 - (cardCount - 1) * 4) / cardCount;

    result.summary.metrics.slice(0, 4).forEach((metric, idx) => {
      const cardX = 14 + idx * (cardWidth + 4);
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(cardX, y, cardWidth, 16, 2, 2, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.setTextColor(100, 116, 139);
      doc.text(metric.label.toUpperCase(), cardX + 3, y + 4.5);

      doc.setFontSize(10);
      doc.setTextColor(15, 23, 42);
      doc.text(metric.formatted, cardX + 3, y + 10.5);

      if (metric.deltaPct !== undefined) {
        doc.setFontSize(7.5);
        const isUp = metric.deltaPct >= 0;
        doc.setTextColor(isUp ? 16 : 225, isUp ? 185 : 29, isUp ? 129 : 72);
        const arrow = isUp ? '▲ +' : '▼ ';
        doc.text(`${arrow}${metric.deltaPct}%`, cardX + cardWidth - 3, y + 10.5, { align: 'right' });
      }
    });

    y += 22;
  }

  // Render Data Table
  const columns = def.columns;
  const colWidth = 182 / columns.length;

  // Table Header
  doc.setFillColor(241, 245, 249);
  doc.rect(14, y - 4, 182, 7, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(51, 65, 85);

  columns.forEach((col, idx) => {
    const colX = 14 + idx * colWidth + (col.align === 'right' ? colWidth - 2 : col.align === 'center' ? colWidth / 2 : 2);
    const align = col.align || 'left';
    doc.text(col.label.toUpperCase(), colX, y, { align: align as any });
  });

  y += 6;

  // Table Body Rows
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);

  result.rows.forEach((row, rowIdx) => {
    if (y > 270) {
      doc.addPage();
      y = 25;
      // Redraw table header on new page
      doc.setFillColor(241, 245, 249);
      doc.rect(14, y - 4, 182, 7, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(51, 65, 85);
      columns.forEach((col, idx) => {
        const colX = 14 + idx * colWidth + (col.align === 'right' ? colWidth - 2 : col.align === 'center' ? colWidth / 2 : 2);
        doc.text(col.label.toUpperCase(), colX, y, { align: col.align || 'left' as any });
      });
      y += 6;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
    }

    if (rowIdx % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, y - 4, 182, 5.5, 'F');
    }

    columns.forEach((col, colIdx) => {
      const colX = 14 + colIdx * colWidth + (col.align === 'right' ? colWidth - 2 : col.align === 'center' ? colWidth / 2 : 2);
      const val = row[col.key];
      let displayVal = val !== undefined && val !== null ? String(val) : '—';

      if (col.type === 'currency' && typeof val === 'number') {
        displayVal = `${currencySymbol} ${val.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
      } else if (col.type === 'percent' && typeof val === 'number') {
        displayVal = `${val}%`;
      } else if (col.type === 'number' && typeof val === 'number') {
        displayVal = val.toLocaleString();
      }

      const align = col.align || 'left';

      // Highlight status or key values
      if (col.key === 'reorderStatus' || col.key === 'velocity' || col.key === 'status' || col.key === 'performanceScore') {
        doc.setFont('helvetica', 'bold');
        if (displayVal.includes('REORDER') || displayVal.includes('SLOW') || displayVal.includes('ATTENTION')) {
          doc.setTextColor(225, 29, 72);
        } else {
          doc.setTextColor(16, 185, 129);
        }
      } else {
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(51, 65, 85);
      }

      doc.text(displayVal, colX, y, { align: align as any });
    });

    y += 5.5;
  });

  // Footer decoration
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(148, 163, 184);
    doc.text(`Official Document • Mabala Multi-Tenant SaaS Report Centre`, 14, 287);
    doc.text(`Page ${i} of ${pageCount} • Generated ${new Date().toLocaleString()}`, 196, 287, { align: 'right' });
  }

  const safeTitle = def.title.replace(/[^a-zA-Z0-9]/g, '_');
  doc.save(`${safeTitle}_${result.period.from}_to_${result.period.to}.pdf`);
}

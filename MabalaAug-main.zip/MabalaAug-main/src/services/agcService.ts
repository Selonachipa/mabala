/**
 * Smallholder Input Credit Infrastructure Module (AGC) Service
 * Implements Mabala AGC PRD v1.3
 */

import {
  FarmerCreditProfileSummary,
  CreditApplication,
  LoanAccount,
  RepaymentRecord,
  LoanInsurancePolicy,
  InsurerPremiumRate,
  CreditFacility,
  ApiAccessConfig,
  ApiCallLog,
  ApiConfigRates,
  GuaranteeFundLedger,
  MabalaCreditScore,
  RemoteSensingSignal,
  FarmPlotBoundary,
  BasketItem
} from "../types";
import { maskPIIObject } from "../utils/privacyMasking";

const STORAGE_KEYS = {
  CREDIT_PROFILES: "mabala_agc_profiles",
  APPLICATIONS: "mabala_agc_applications",
  LOANS: "mabala_agc_loans",
  REPAYMENTS: "mabala_agc_repayments",
  FACILITIES: "mabala_agc_facilities",
  INSURER_RATES: "mabala_agc_insurer_rates",
  INSURANCE_POLICIES: "mabala_agc_insurance_policies",
  API_ACCESS: "mabala_agc_api_access",
  API_LOGS: "mabala_agc_api_logs",
  API_RATES: "mabala_agc_api_rates",
  GUARANTEE_FUND: "mabala_agc_guarantee_fund",
  CREDIT_REGISTRY: "mabala_agc_credit_registry"
};

// Default active facilities with published per-hectare limits (empty for clean tenant baseline)
export const DEFAULT_FACILITIES: CreditFacility[] = [];

const INITIAL_PROFILES: Record<string, FarmerCreditProfileSummary> = {};
const INITIAL_FACILITIES: CreditFacility[] = DEFAULT_FACILITIES;
const INITIAL_INSURER_RATES: InsurerPremiumRate[] = [];
const INITIAL_API_ACCESS: ApiAccessConfig[] = [];

const INITIAL_API_RATES: ApiConfigRates = {
  defaultRatePerCall: 20, // K20 ZMW default
  ratesByScope: {
    cropRecords: 15,
    farmRecords: 15,
    financialData: 25,
    creditScore: 30,
    premiumRates: 10
  },
  defaultFreeTrialCalls: 10
};

// Helper: Read storage with seed fallback
function getStored<T>(key: string, defaultVal: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultVal;
    return JSON.parse(raw);
  } catch {
    return defaultVal;
  }
}

function setStored<T>(key: string, val: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch (err) {
    console.error(`[AGC Service] Error storing key ${key}:`, err);
  }
}

// Global AGC Registry helper
export function getCreditRegistry(): Record<string, { activeLoanId: string | null; closedLoanHistory: any[] }> {
  return getStored(STORAGE_KEYS.CREDIT_REGISTRY, {});
}

export function updateCreditRegistry(farmerTenantId: string, activeLoanId: string | null, closedEntry?: any) {
  const reg = getCreditRegistry();
  const current = reg[farmerTenantId] || { activeLoanId: null, closedLoanHistory: [] };
  const history = [...current.closedLoanHistory];
  if (closedEntry) history.push(closedEntry);
  
  reg[farmerTenantId] = {
    activeLoanId,
    closedLoanHistory: history
  };
  setStored(STORAGE_KEYS.CREDIT_REGISTRY, reg);
}

// 1. Credit Profile Summary Management
export function getFarmerCreditProfile(farmerTenantId: string): FarmerCreditProfileSummary {
  const profiles = getStored<Record<string, FarmerCreditProfileSummary>>(STORAGE_KEYS.CREDIT_PROFILES, INITIAL_PROFILES);
  if (!profiles[farmerTenantId]) {
    // Create default profile for new tenant
    profiles[farmerTenantId] = {
      identity: {
        nrc: null,
        nrcPending: true,
        phone: "",
        name: "Smallholder Farmer (" + farmerTenantId.substring(0, 6) + ")",
        ageBand: "25-34"
      },
      farmPlots: [],
      salesHistory: { rollupBySeasonCrop: [], lastComputedAt: new Date().toISOString() },
      priceContext: null,
      agdPurchaseHistory: { rollup: [] },
      remoteSensingSignal: { perPlot: [], computedAt: new Date().toISOString() },
      mabalaCreditScore: {
        value: 620,
        band: "C",
        explainability: [
          { factor: "Base Smallholder Onboarding", impact: "neutral", scoreImpact: 0 }
        ],
        computedAt: new Date().toISOString()
      },
      consentStatus: "never-granted",
      activeLoanId: null
    };
    setStored(STORAGE_KEYS.CREDIT_PROFILES, profiles);
  }
  return profiles[farmerTenantId];
}

export function updateFarmerConsent(farmerTenantId: string, status: 'granted' | 'revoked') {
  const profiles = getStored<Record<string, FarmerCreditProfileSummary>>(STORAGE_KEYS.CREDIT_PROFILES, INITIAL_PROFILES);
  const prof = getFarmerCreditProfile(farmerTenantId);
  prof.consentStatus = status;
  profiles[farmerTenantId] = prof;
  setStored(STORAGE_KEYS.CREDIT_PROFILES, profiles);
  return prof;
}

export function updateFarmPlotBoundaries(farmerTenantId: string, plots: FarmPlotBoundary[]) {
  const profiles = getStored<Record<string, FarmerCreditProfileSummary>>(STORAGE_KEYS.CREDIT_PROFILES, INITIAL_PROFILES);
  const prof = getFarmerCreditProfile(farmerTenantId);
  prof.farmPlots = plots;
  profiles[farmerTenantId] = prof;
  setStored(STORAGE_KEYS.CREDIT_PROFILES, profiles);
  return agcComputeCreditScore(farmerTenantId);
}

// 2. Score & Remote Sensing Engine
export function agcComputeCreditScore(farmerTenantId: string): MabalaCreditScore {
  const prof = getFarmerCreditProfile(farmerTenantId);
  let score = 580; // Base score
  const explainability: { factor: string; impact: "positive" | "negative" | "neutral"; scoreImpact: number }[] = [];

  // Plot mapping bonus
  if (prof.farmPlots.length > 0) {
    const totalHa = prof.farmPlots.reduce((acc, p) => acc + (p.sizeHa || 0), 0);
    const hasPolygon = prof.farmPlots.some(p => p.gpsBoundary && p.gpsBoundary.length >= 3);
    if (hasPolygon) {
      score += 35;
      explainability.push({ factor: `Verified Polygon Plot Boundary (${totalHa.toFixed(1)} Ha)`, impact: "positive", scoreImpact: 35 });
    }
  }

  // Sales history bonus
  const totalSales = prof.salesHistory.rollupBySeasonCrop.reduce((acc, s) => acc + s.revenue, 0);
  if (totalSales > 50000) {
    score += 65;
    explainability.push({ factor: "High Historical Harvest Revenue (>K50,000)", impact: "positive", scoreImpact: 65 });
  } else if (totalSales > 20000) {
    score += 40;
    explainability.push({ factor: "Proven Harvest Revenue (>K20,000)", impact: "positive", scoreImpact: 40 });
  }

  // Remote sensing NDVI bonus
  const highNdviPlots = prof.remoteSensingSignal.perPlot.filter(p => p.ndvi >= 0.65);
  if (highNdviPlots.length > 0) {
    score += 30;
    explainability.push({ factor: "Satellite Remote Sensing Vigor (NDVI > 0.65)", impact: "positive", scoreImpact: 30 });
  }

  // Input purchase track record
  if (prof.agdPurchaseHistory.rollup.length >= 2) {
    score += 25;
    explainability.push({ factor: "Agro-Dealer Input Purchase Consistency", impact: "positive", scoreImpact: 25 });
  }

  // Identity check
  if (prof.identity.nrc && !prof.identity.nrcPending) {
    score += 15;
    explainability.push({ factor: "Verified NRC Identity Verification", impact: "positive", scoreImpact: 15 });
  }

  score = Math.min(850, Math.max(300, score));
  let band: 'A' | 'B' | 'C' | 'D' = 'D';
  if (score >= 750) band = 'A';
  else if (score >= 680) band = 'B';
  else if (score >= 580) band = 'C';

  const newScoreObj: MabalaCreditScore = {
    value: score,
    band,
    explainability,
    computedAt: new Date().toISOString()
  };

  prof.mabalaCreditScore = newScoreObj;
  const profiles = getStored<Record<string, FarmerCreditProfileSummary>>(STORAGE_KEYS.CREDIT_PROFILES, INITIAL_PROFILES);
  profiles[farmerTenantId] = prof;
  setStored(STORAGE_KEYS.CREDIT_PROFILES, profiles);

  return newScoreObj;
}

export function agcRemoteSensingRefresh(farmerTenantId: string): RemoteSensingSignal {
  const prof = getFarmerCreditProfile(farmerTenantId);
  const updatedPerPlot = prof.farmPlots.map(plot => {
    const hasPolygon = plot.gpsBoundary && plot.gpsBoundary.length >= 3;
    const baseNdvi = hasPolygon ? 0.65 + (Math.random() * 0.15) : 0.45;
    return {
      plotId: plot.plotId,
      ndvi: Number(baseNdvi.toFixed(2)),
      modelledYield: Number((plot.sizeHa * (hasPolygon ? 3.8 : 2.0)).toFixed(1)),
      confidence: hasPolygon ? ("high" as const) : ("low" as const)
    };
  });

  const signal: RemoteSensingSignal = {
    perPlot: updatedPerPlot,
    computedAt: new Date().toISOString()
  };

  prof.remoteSensingSignal = signal;
  const profiles = getStored<Record<string, FarmerCreditProfileSummary>>(STORAGE_KEYS.CREDIT_PROFILES, INITIAL_PROFILES);
  profiles[farmerTenantId] = prof;
  setStored(STORAGE_KEYS.CREDIT_PROFILES, profiles);

  return signal;
}

// 3. Application & Single Loan Hard Block Enforcer
export function canApplyForLoan(farmerTenantId: string): { allowed: boolean; reason?: string; activeLoanId?: string } {
  const reg = getCreditRegistry();
  const farmerReg = reg[farmerTenantId];
  const loans = getStored<LoanAccount[]>(STORAGE_KEYS.LOANS, []);

  // Check registry
  if (farmerReg && farmerReg.activeLoanId) {
    return {
      allowed: false,
      reason: "Farmer holds an active AGC loan platform-wide (ID: " + farmerReg.activeLoanId + "). Single active loan policy enforced.",
      activeLoanId: farmerReg.activeLoanId
    };
  }

  // Check active loan in array
  const activeLoan = loans.find(l => l.farmerTenantId === farmerTenantId && l.status === "active");
  if (activeLoan) {
    return {
      allowed: false,
      reason: "Farmer holds an active AGC loan platform-wide (ID: " + activeLoan.loanId + "). Single active loan policy enforced.",
      activeLoanId: activeLoan.loanId
    };
  }

  // Check consent
  const prof = getFarmerCreditProfile(farmerTenantId);
  if (prof.consentStatus !== "granted") {
    return {
      allowed: false,
      reason: "Farmer has not granted credit data sharing consent."
    };
  }

  return { allowed: true };
}

export function agcSubmitApplication(params: {
  farmerTenantId: string;
  dealerTenantId: string;
  dealerName?: string;
  financierInstitutionId: string;
  financierName?: string;
  requestedBasket: BasketItem[];
  selectedCrop?: string;
  appliedHectarage?: number;
  plotId?: string;
  plotName?: string;
  maxEligibleAmount?: number;
  warehouseReceiptId?: string;
  warehouseReceiptPledged?: boolean;
  insurancePolicyAttached?: boolean;
  insurancePremiumAmount?: number;
}): CreditApplication {
  const {
    farmerTenantId,
    dealerTenantId,
    dealerName,
    financierInstitutionId,
    financierName,
    requestedBasket,
    selectedCrop,
    appliedHectarage,
    plotId,
    plotName,
    maxEligibleAmount,
    warehouseReceiptId,
    warehouseReceiptPledged,
    insurancePolicyAttached,
    insurancePremiumAmount
  } = params;
  
  // HARD BLOCK CHECK: Single active loan rule platform-wide
  const check = canApplyForLoan(farmerTenantId);
  const totalAmount = requestedBasket.reduce((sum, item) => sum + item.total, 0);

  const applications = getStored<CreditApplication[]>(STORAGE_KEYS.APPLICATIONS, []);
  const appId = "app_" + Date.now();
  const prof = getFarmerCreditProfile(farmerTenantId);

  if (!check.allowed) {
    const rejectedApp: CreditApplication = {
      applicationId: appId,
      farmerTenantId,
      farmerName: prof.identity.name,
      farmerPhone: prof.identity.phone,
      dealerTenantId,
      dealerName: dealerName || "Agro-Dealer POS",
      financierInstitutionId,
      financierName: financierName || "Partner Financier",
      requestedBasket,
      totalAmount,
      selectedCrop,
      appliedHectarage,
      plotId,
      plotName,
      maxEligibleAmount,
      warehouseReceiptId,
      warehouseReceiptPledged,
      insurancePolicyAttached,
      insurancePremiumAmount,
      status: "rejected-single-loan",
      rejectionReason: check.reason,
      createdAt: new Date().toISOString(),
      decidedAt: new Date().toISOString()
    };
    applications.unshift(rejectedApp);
    setStored(STORAGE_KEYS.APPLICATIONS, applications);
    return rejectedApp;
  }

  // Calculate credit limit based on score and published per-hectare limits
  const score = prof.mabalaCreditScore.value;
  let maxAllowedByScore = 15000;
  if (score >= 750) maxAllowedByScore = 150000;
  else if (score >= 680) maxAllowedByScore = 75000;
  else if (score >= 580) maxAllowedByScore = 30000;

  const capLimit = maxEligibleAmount && maxEligibleAmount > 0 
    ? Math.min(maxAllowedByScore, maxEligibleAmount) 
    : maxAllowedByScore;

  if (totalAmount > capLimit) {
    const rejectedApp: CreditApplication = {
      applicationId: appId,
      farmerTenantId,
      farmerName: prof.identity.name,
      farmerPhone: prof.identity.phone,
      dealerTenantId,
      dealerName: dealerName || "Agro-Dealer POS",
      financierInstitutionId,
      financierName: financierName || "Partner Financier",
      requestedBasket,
      totalAmount,
      selectedCrop,
      appliedHectarage,
      plotId,
      plotName,
      maxEligibleAmount: capLimit,
      warehouseReceiptId,
      warehouseReceiptPledged,
      insurancePolicyAttached,
      insurancePremiumAmount,
      status: "rejected-other",
      rejectionReason: `Requested basket (ZMW ${totalAmount.toLocaleString()}) exceeds eligible limit (ZMW ${capLimit.toLocaleString()})`,
      createdAt: new Date().toISOString(),
      decidedAt: new Date().toISOString()
    };
    applications.unshift(rejectedApp);
    setStored(STORAGE_KEYS.APPLICATIONS, applications);
    return rejectedApp;
  }

  const approvedApp: CreditApplication = {
    applicationId: appId,
    farmerTenantId,
    farmerName: prof.identity.name,
    farmerPhone: prof.identity.phone,
    dealerTenantId,
    dealerName: dealerName || "Agro-Dealer POS",
    financierInstitutionId,
    financierName: financierName || "Partner Financier",
    requestedBasket,
    totalAmount,
    selectedCrop,
    appliedHectarage,
    plotId,
    plotName,
    maxEligibleAmount: capLimit,
    warehouseReceiptId,
    warehouseReceiptPledged,
    insurancePolicyAttached,
    insurancePremiumAmount,
    status: "approved",
    createdAt: new Date().toISOString(),
    decidedAt: new Date().toISOString()
  };

  applications.unshift(approvedApp);
  setStored(STORAGE_KEYS.APPLICATIONS, applications);
  return approvedApp;
}

// 4. Atomic Disbursement (In-Kind Goods/Services Drawdown)
export function agcDisburseLoan(params: {
  applicationId: string;
  insurancePolicyId?: string | null;
  riskShare?: { weatherPct: number; guaranteePct: number; dealerRetainedPct: number };
  dwrDetails?: {
    receiptNumber: string;
    cropType: string;
    quantity: number;
    unit: string;
    totalValue: number;
  };
}): LoanAccount {
  const applications = getStored<CreditApplication[]>(STORAGE_KEYS.APPLICATIONS, []);
  const app = applications.find(a => a.applicationId === params.applicationId);
  if (!app || app.status !== "approved") {
    throw new Error("Invalid or unapproved application for disbursement.");
  }

  // Double check single-loan rule before disbursement
  const check = canApplyForLoan(app.farmerTenantId);
  if (!check.allowed) {
    throw new Error(check.reason || "Disbursement blocked by single loan policy.");
  }

  const loanId = "loan_agc_" + Date.now();
  const principal = app.totalAmount;
  const interestRatePct = 2.0; // 2% / month
  const originationFee = Math.round(principal * 0.015); // 1.5% origination
  const insurancePremium = app.insurancePremiumAmount || 0;
  const totalRepayable = Math.round(principal * (1 + interestRatePct / 100)) + originationFee + insurancePremium;

  const now = new Date();
  const dueDate = new Date(now.getTime() + 120 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]; // 120 days

  const loan: LoanAccount = {
    loanId,
    farmerTenantId: app.farmerTenantId,
    farmerName: app.farmerName,
    dealerTenantId: app.dealerTenantId,
    dealerName: app.dealerName,
    financierInstitutionId: app.financierInstitutionId,
    financierName: app.financierName,
    principal,
    term: 120,
    selectedCrop: app.selectedCrop,
    appliedHectarage: app.appliedHectarage,
    plotId: app.plotId,
    plotName: app.plotName,
    warehouseReceiptId: app.warehouseReceiptId,
    warehouseReceiptPledged: app.warehouseReceiptPledged,
    dwrDetails: params.dwrDetails,
    insurancePolicyAttached: app.insurancePolicyAttached,
    insurancePremiumAmount: insurancePremium,
    feeSchedule: {
      interestRatePct,
      originationFee,
      totalRepayable
    },
    insurancePolicyId: params.insurancePolicyId || null,
    status: "active",
    balance: totalRepayable,
    disbursedAt: now.toISOString(),
    dueDate,
    riskShare: params.riskShare || { weatherPct: 40, guaranteePct: 0, dealerRetainedPct: 60 }
  };

  // 1. Save loan
  const loans = getStored<LoanAccount[]>(STORAGE_KEYS.LOANS, []);
  loans.unshift(loan);
  setStored(STORAGE_KEYS.LOANS, loans);

  // 2. Set activeLoanId on registry & profile
  updateCreditRegistry(app.farmerTenantId, loanId);
  const profiles = getStored<Record<string, FarmerCreditProfileSummary>>(STORAGE_KEYS.CREDIT_PROFILES, INITIAL_PROFILES);
  if (profiles[app.farmerTenantId]) {
    profiles[app.farmerTenantId].activeLoanId = loanId;
    setStored(STORAGE_KEYS.CREDIT_PROFILES, profiles);
  }

  // 3. Update facility utilization
  const facilities = getStored<CreditFacility[]>(STORAGE_KEYS.FACILITIES, INITIAL_FACILITIES);
  const fac = facilities.find(f => f.financierInstitutionId === app.financierInstitutionId);
  if (fac) {
    fac.utilized += principal;
    setStored(STORAGE_KEYS.FACILITIES, facilities);
  }

  return loan;
}

// 5. Repayment Processing
export function agcProcessRepayment(params: {
  loanId: string;
  amount: number;
  channel: 'lipila' | 'farm-balance' | 'offtaker-settlement';
}): RepaymentRecord {
  const loans = getStored<LoanAccount[]>(STORAGE_KEYS.LOANS, []);
  const loanIndex = loans.findIndex(l => l.loanId === params.loanId);
  if (loanIndex === -1) throw new Error("Loan not found.");

  const loan = loans[loanIndex];
  if (loan.status !== "active") throw new Error(`Loan is not active (current status: ${loan.status}).`);

  const repId = "rep_" + Date.now();
  const repayment: RepaymentRecord = {
    repaymentId: repId,
    loanId: params.loanId,
    farmerTenantId: loan.farmerTenantId,
    amount: params.amount,
    channel: params.channel,
    scoreBonusEligible: true,
    createdAt: new Date().toISOString()
  };

  // Decrement balance
  loan.balance = Math.max(0, loan.balance - params.amount);

  // If fully repaid
  if (loan.balance === 0) {
    loan.status = "repaid";
    // Clear active loan from registry and profile
    updateCreditRegistry(loan.farmerTenantId, null, { loanId: loan.loanId, status: "repaid", closedAt: new Date().toISOString() });
    const profiles = getStored<Record<string, FarmerCreditProfileSummary>>(STORAGE_KEYS.CREDIT_PROFILES, INITIAL_PROFILES);
    if (profiles[loan.farmerTenantId]) {
      profiles[loan.farmerTenantId].activeLoanId = null;
      setStored(STORAGE_KEYS.CREDIT_PROFILES, profiles);
    }
  }

  loans[loanIndex] = loan;
  setStored(STORAGE_KEYS.LOANS, loans);

  const repayments = getStored<RepaymentRecord[]>(STORAGE_KEYS.REPAYMENTS, []);
  repayments.unshift(repayment);
  setStored(STORAGE_KEYS.REPAYMENTS, repayments);

  // Re-compute credit score with repayment bonus
  agcComputeCreditScore(loan.farmerTenantId);

  return repayment;
}

// 6. Insurer Self-Service Rates
export function getInsurerPremiumRates(): InsurerPremiumRate[] {
  return getStored<InsurerPremiumRate[]>(STORAGE_KEYS.INSURER_RATES, INITIAL_INSURER_RATES);
}

export function agcInsurerSetPremiumRate(rate: Omit<InsurerPremiumRate, "rateId">): InsurerPremiumRate {
  const rates = getInsurerPremiumRates();
  const newRate: InsurerPremiumRate = {
    ...rate,
    rateId: "rate_" + Date.now()
  };
  rates.unshift(newRate);
  setStored(STORAGE_KEYS.INSURER_RATES, rates);
  return newRate;
}

export function agcUpdateInsurerPremiumRate(rateId: string, updatedFields: Partial<Omit<InsurerPremiumRate, "rateId">>): InsurerPremiumRate | null {
  const rates = getInsurerPremiumRates();
  const index = rates.findIndex(r => r.rateId === rateId);
  if (index === -1) return null;

  rates[index] = {
    ...rates[index],
    ...updatedFields
  };
  setStored(STORAGE_KEYS.INSURER_RATES, rates);
  return rates[index];
}

export function agcDeleteInsurerPremiumRate(rateId: string): boolean {
  let rates = getInsurerPremiumRates();
  const initialLength = rates.length;
  rates = rates.filter(r => r.rateId !== rateId);
  if (rates.length < initialLength) {
    setStored(STORAGE_KEYS.INSURER_RATES, rates);
    return true;
  }
  return false;
}

// 7. Facilities Management
export function getCreditFacilities(): CreditFacility[] {
  return getStored<CreditFacility[]>(STORAGE_KEYS.FACILITIES, INITIAL_FACILITIES);
}

export function clearCreditFacilities(): void {
  setStored(STORAGE_KEYS.FACILITIES, []);
}

export function deleteCreditFacility(facilityId: string): boolean {
  const facs = getCreditFacilities();
  const filtered = facs.filter(f => f.facilityId !== facilityId);
  setStored(STORAGE_KEYS.FACILITIES, filtered);
  return filtered.length < facs.length;
}

export function createCreditFacility(facility: Omit<CreditFacility, "facilityId">): CreditFacility {
  const facs = getCreditFacilities();
  const newFac: CreditFacility = {
    ...facility,
    facilityId: "fac_" + Date.now()
  };
  facs.unshift(newFac);
  setStored(STORAGE_KEYS.FACILITIES, facs);
  return newFac;
}

// 8. External API Gateway & Metering
export function getApiAccessConfigs(): ApiAccessConfig[] {
  return getStored<ApiAccessConfig[]>(STORAGE_KEYS.API_ACCESS, INITIAL_API_ACCESS);
}

export function getApiConfigRates(): ApiConfigRates {
  return getStored<ApiConfigRates>(STORAGE_KEYS.API_RATES, INITIAL_API_RATES);
}

export function agcAdminSetApiRates(rates: ApiConfigRates): ApiConfigRates {
  setStored(STORAGE_KEYS.API_RATES, rates);
  return rates;
}

export function updateApiAccessConfig(config: ApiAccessConfig): ApiAccessConfig {
  const configs = getApiAccessConfigs();
  const index = configs.findIndex(c => c.institutionId === config.institutionId);
  if (index !== -1) {
    configs[index] = config;
  } else {
    configs.push(config);
  }
  setStored(STORAGE_KEYS.API_ACCESS, configs);
  return config;
}

export function getApiCallLogs(institutionId?: string, farmerTenantId?: string): ApiCallLog[] {
  const logs = getStored<ApiCallLog[]>(STORAGE_KEYS.API_LOGS, []);
  return logs.filter(l => {
    if (institutionId && l.institutionId !== institutionId) return false;
    if (farmerTenantId && l.farmerTenantId !== farmerTenantId) return false;
    return true;
  });
}

export function agcApiGatewayQuery(params: {
  institutionId: string;
  farmerTenantId: string;
  requestedScope: string;
}): { success: boolean; data?: any; error?: string; freeTrialRemaining?: number; feeCharged?: number } {
  const { institutionId, farmerTenantId, requestedScope } = params;
  const configs = getApiAccessConfigs();
  const config = configs.find(c => c.institutionId === institutionId);

  if (!config || config.status !== "active") {
    return { success: false, error: "API Access suspended or unverified institution." };
  }

  if (!config.enabledScopes.includes(requestedScope)) {
    return { success: false, error: `Scope '${requestedScope}' is not enabled for this institution.` };
  }

  const prof = getFarmerCreditProfile(farmerTenantId);
  if (prof.consentStatus !== "granted") {
    return { success: false, error: "Farmer has not granted consent for third-party data access." };
  }

  // Calculate fee / trial call
  let feeCharged = 0;
  let remainingTrials = config.freeTrialCallsRemaining;

  if (remainingTrials > 0) {
    remainingTrials -= 1;
    config.freeTrialCallsRemaining = remainingTrials;
    updateApiAccessConfig(config);
  } else {
    const defaultRates = getApiConfigRates();
    const scopeRate = config.rateOverridesByScope[requestedScope] ?? defaultRates.ratesByScope[requestedScope] ?? defaultRates.defaultRatePerCall;
    feeCharged = config.customRatePerCall ?? scopeRate;
  }

  // Write immutable audit log
  const log: ApiCallLog = {
    callId: "call_" + Date.now() + "_" + Math.random().toString(36).substring(2, 6),
    institutionId,
    institutionName: config.institutionName,
    farmerTenantId,
    farmerName: prof.identity.name,
    dataScope: requestedScope,
    timestamp: new Date().toISOString(),
    feeCharged
  };

  const logs = getStored<ApiCallLog[]>(STORAGE_KEYS.API_LOGS, []);
  logs.unshift(log);
  setStored(STORAGE_KEYS.API_LOGS, logs);

  // Return scope data
  let scopeData: any = {};
  if (requestedScope === "cropRecords") {
    scopeData = { farmPlots: prof.farmPlots, agdPurchaseHistory: prof.agdPurchaseHistory };
  } else if (requestedScope === "farmRecords") {
    scopeData = {
      identity: maskPIIObject(prof.identity, { viewerRole: "institution_supplier", dataOwnerId: farmerTenantId }),
      farmPlots: prof.farmPlots
    };
  } else if (requestedScope === "financialData") {
    scopeData = { salesHistory: prof.salesHistory };
  } else if (requestedScope === "creditScore") {
    scopeData = { creditScore: prof.mabalaCreditScore };
  } else if (requestedScope === "premiumRates") {
    scopeData = { premiumRates: getInsurerPremiumRates() };
  }

  return {
    success: true,
    data: scopeData,
    freeTrialRemaining: remainingTrials,
    feeCharged
  };
}

// 9. Guarantee Fund Ledger
export function getGuaranteeFundLedger(): GuaranteeFundLedger {
  return getStored<GuaranteeFundLedger>(STORAGE_KEYS.GUARANTEE_FUND, {
    balance: 0,
    committedBy: null,
    committedAt: null
  });
}

export function agcCommitGuaranteeFund(amount: number, committedBy: string): GuaranteeFundLedger {
  const ledger = getGuaranteeFundLedger();
  ledger.balance += amount;
  ledger.committedBy = committedBy;
  ledger.committedAt = new Date().toISOString();
  setStored(STORAGE_KEYS.GUARANTEE_FUND, ledger);
  return ledger;
}

// 10. Getter functions for UI panels
export function getApplications(farmerTenantId?: string): CreditApplication[] {
  const apps = getStored<CreditApplication[]>(STORAGE_KEYS.APPLICATIONS, []);
  if (farmerTenantId) return apps.filter(a => a.farmerTenantId === farmerTenantId);
  return apps;
}

export function getLoans(farmerTenantId?: string): LoanAccount[] {
  const loans = getStored<LoanAccount[]>(STORAGE_KEYS.LOANS, []);
  if (farmerTenantId) return loans.filter(l => l.farmerTenantId === farmerTenantId);
  return loans;
}

export function getRepayments(loanId?: string): RepaymentRecord[] {
  const reps = getStored<RepaymentRecord[]>(STORAGE_KEYS.REPAYMENTS, []);
  if (loanId) return reps.filter(r => r.loanId === loanId);
  return reps;
}

import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy 
} from "firebase/firestore";
import { db } from "../firebase";
import { 
  ResellerPartner, 
  ResellerCommissionRecord, 
  ResellerSettlementPayout 
} from "../types";
import { safeLocalStorage as localStorage, safeParseJSON } from "../utils/safeStorage";
import { LIVE_LIPILA_PRODUCTION_KEY, LIVE_LIPILA_BASE_URL } from "../lipilaConfig";

export type { 
  ResellerPartner, 
  ResellerCommissionRecord, 
  ResellerSettlementPayout 
} from "../types";

const RESELLERS_STORAGE_KEY = "mabala_reseller_partners_v2";
const COMMISSIONS_STORAGE_KEY = "mabala_reseller_commissions_v2";
const SETTLEMENTS_STORAGE_KEY = "mabala_reseller_settlements_v2";

// Pure production initial states — NO dummy or mock records
export const INITIAL_RESELLERS: ResellerPartner[] = [];
export const INITIAL_COMMISSIONS: ResellerCommissionRecord[] = [];
export const INITIAL_SETTLEMENTS: ResellerSettlementPayout[] = [];

// Helper to filter out any legacy dummy records from local storage
function filterOutLegacyDummyResellers(items: ResellerPartner[]): ResellerPartner[] {
  if (!Array.isArray(items)) return [];
  return items.filter(r => 
    r && 
    r.id && 
    !r.id.startsWith("reseller_lusaka_01") &&
    !r.id.startsWith("reseller_mkushi_02") &&
    !r.id.startsWith("reseller_copperbelt_03") &&
    !r.id.startsWith("reseller_southern_04") &&
    r.resellerCode !== "LUSAKA-AGRI-01" &&
    r.resellerCode !== "MKUSHI-COMM-02" &&
    r.resellerCode !== "COPPER-AGRO-03" &&
    r.resellerCode !== "SOUTHERN-CATTLE-04"
  );
}

function filterOutLegacyDummyCommissions(items: ResellerCommissionRecord[]): ResellerCommissionRecord[] {
  if (!Array.isArray(items)) return [];
  return items.filter(c => 
    c && 
    c.id && 
    !c.id.startsWith("comm_rec_001") &&
    !c.id.startsWith("comm_rec_002") &&
    !c.id.startsWith("comm_rec_003") &&
    !c.id.startsWith("comm_rec_004") &&
    c.resellerCode !== "LUSAKA-AGRI-01" &&
    c.resellerCode !== "MKUSHI-COMM-02" &&
    c.resellerCode !== "COPPER-AGRO-03" &&
    c.resellerCode !== "SOUTHERN-CATTLE-04"
  );
}

class ResellerService {
  // -------------------------------------------------------------
  // RESELLER PARTNER MANAGEMENT
  // -------------------------------------------------------------

  public async getAllResellers(): Promise<ResellerPartner[]> {
    try {
      // 1. Try fetching from Firestore
      const resellersRef = collection(db, "resellers");
      const snap = await getDocs(resellersRef);
      if (!snap.empty) {
        const firestoreList = snap.docs
          .map(d => ({ id: d.id, ...d.data() } as ResellerPartner))
          .filter(r => r && r.id);
        
        const cleanList = filterOutLegacyDummyResellers(firestoreList);
        localStorage.setItem(RESELLERS_STORAGE_KEY, JSON.stringify(cleanList));
        return cleanList;
      }
    } catch (err) {
      console.warn("[ResellerService] Firestore read fallback to local cache:", err);
    }

    // 2. Fallback to LocalStorage (Cleaned)
    const local = localStorage.getItem(RESELLERS_STORAGE_KEY);
    if (local) {
      const parsed = safeParseJSON<ResellerPartner[]>(local, []);
      if (parsed && parsed.length > 0) {
        const clean = filterOutLegacyDummyResellers(parsed);
        return clean;
      }
    }

    return [];
  }

  public async getResellerByCode(code: string): Promise<ResellerPartner | null> {
    if (!code || !code.trim()) return null;
    const cleanCode = code.trim().toUpperCase();
    const all = await this.getAllResellers();
    return all.find(r => r.resellerCode.toUpperCase() === cleanCode && r.status === "active") || null;
  }

  public async findResellerByCode(code: string): Promise<ResellerPartner | null> {
    return this.getResellerByCode(code);
  }

  public async getResellerById(id: string): Promise<ResellerPartner | null> {
    if (!id) return null;
    const all = await this.getAllResellers();
    return all.find(r => r.id === id) || null;
  }

  public async saveReseller(partner: ResellerPartner): Promise<ResellerPartner> {
    const all = await this.getAllResellers();
    const index = all.findIndex(r => r.id === partner.id);
    let updatedList: ResellerPartner[];

    if (index >= 0) {
      updatedList = [...all];
      updatedList[index] = { ...updatedList[index], ...partner };
    } else {
      updatedList = [partner, ...all];
    }

    const cleanList = filterOutLegacyDummyResellers(updatedList);
    localStorage.setItem(RESELLERS_STORAGE_KEY, JSON.stringify(cleanList));

    // Async write to Firestore
    try {
      const docRef = doc(db, "resellers", partner.id);
      await setDoc(docRef, partner, { merge: true });
    } catch (err) {
      console.warn("[ResellerService] Firestore write failed, cached locally:", err);
    }

    try {
      window.dispatchEvent(new CustomEvent("mabala_reseller_updated", { detail: partner }));
    } catch (_) {}

    return partner;
  }

  public async deleteReseller(id: string): Promise<boolean> {
    const all = await this.getAllResellers();
    const updated = all.filter(r => r.id !== id);
    localStorage.setItem(RESELLERS_STORAGE_KEY, JSON.stringify(updated));

    try {
      const docRef = doc(db, "resellers", id);
      await updateDoc(docRef, { status: "inactive" });
    } catch (err) {
      console.warn("[ResellerService] Firestore delete failed:", err);
    }
    return true;
  }

  // -------------------------------------------------------------
  // SUBSCRIPTION COMMISSION ACCRUAL
  // -------------------------------------------------------------

  public async recordSubscriptionCommission(params: {
    farmerUid: string;
    farmerName: string;
    farmerEmail: string;
    farmerPhone?: string;
    farmOrBusinessName?: string;
    subscriptionPackage: string;
    subscriptionFeeZMW: number;
    resellerCodeOrId?: string;
    paymentReference?: string;
    paymentMethod?: string;
  }): Promise<ResellerCommissionRecord | null> {
    if (!params.resellerCodeOrId && !params.farmerUid) return null;

    let targetReseller: ResellerPartner | null = null;
    const allResellers = await this.getAllResellers();

    if (params.resellerCodeOrId) {
      targetReseller = allResellers.find(
        r => r.resellerCode.toUpperCase() === params.resellerCodeOrId?.toUpperCase().trim() ||
             r.id === params.resellerCodeOrId
      ) || null;
    }

    if (!targetReseller) {
      // Check if user record has resellerCode attached in local users
      try {
        const usersRaw = localStorage.getItem("all_platform_users");
        if (usersRaw) {
          const users = JSON.parse(usersRaw);
          const u = users.find((user: any) => user.uid === params.farmerUid || user.email === params.farmerEmail);
          if (u && (u.resellerCode || u.resellerId)) {
            targetReseller = allResellers.find(
              r => r.resellerCode.toUpperCase() === (u.resellerCode || "").toUpperCase() || r.id === u.resellerId
            ) || null;
          }
        }
      } catch (e) {
        console.warn("[ResellerService] Failed checking user reseller attachment:", e);
      }
    }

    if (!targetReseller || targetReseller.status !== "active") {
      return null;
    }

    // Calculate commission
    let commissionAmount = 0;
    if (targetReseller.commissionModel === "percentage") {
      commissionAmount = Math.round(((params.subscriptionFeeZMW * targetReseller.commissionRate) / 100) * 100) / 100;
    } else {
      // Flat fee
      commissionAmount = targetReseller.commissionRate;
    }

    const now = new Date();
    const monthPeriod = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;

    const newRecord: ResellerCommissionRecord = {
      id: `comm_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      resellerId: targetReseller.id,
      resellerCode: targetReseller.resellerCode,
      resellerName: targetReseller.name,
      farmerUid: params.farmerUid,
      farmerName: params.farmerName || "Registered Farmer",
      farmerEmail: params.farmerEmail,
      farmerPhone: params.farmerPhone || "",
      farmOrBusinessName: params.farmOrBusinessName || "Farmer Enterprise Node",
      subscriptionPackage: params.subscriptionPackage || "Mabala Farm Subscription",
      subscriptionFeeZMW: params.subscriptionFeeZMW,
      commissionModel: targetReseller.commissionModel,
      commissionRate: targetReseller.commissionRate,
      commissionAmountZMW: commissionAmount,
      paymentReference: params.paymentReference || `LIP-SUB-${Date.now()}`,
      paymentMethod: params.paymentMethod || "Lipila Digital Gateway",
      status: "accrued",
      monthPeriod,
      createdAt: now.toISOString()
    };

    // Save commission record
    const commissions = await this.getAllCommissionRecords();
    const updatedCommissions = [newRecord, ...commissions];
    localStorage.setItem(COMMISSIONS_STORAGE_KEY, JSON.stringify(updatedCommissions));

    try {
      const commDoc = doc(db, "reseller_commissions", newRecord.id);
      await setDoc(commDoc, newRecord);
    } catch (err) {
      console.warn("[ResellerService] Firestore commission write failed:", err);
    }

    // Update Reseller Partner Totals
    const updatedReseller: ResellerPartner = {
      ...targetReseller,
      totalSubscriptionVolumeZMW: (targetReseller.totalSubscriptionVolumeZMW || 0) + params.subscriptionFeeZMW,
      accumulatedCommissionZMW: (targetReseller.accumulatedCommissionZMW || 0) + commissionAmount,
      unsettledBalanceZMW: (targetReseller.unsettledBalanceZMW || 0) + commissionAmount
    };

    await this.saveReseller(updatedReseller);

    return newRecord;
  }

  public async getAllCommissionRecords(): Promise<ResellerCommissionRecord[]> {
    try {
      const commRef = collection(db, "reseller_commissions");
      const snap = await getDocs(commRef);
      if (!snap.empty) {
        const firestoreList = snap.docs.map(d => ({ id: d.id, ...d.data() } as ResellerCommissionRecord));
        const clean = filterOutLegacyDummyCommissions(firestoreList);
        localStorage.setItem(COMMISSIONS_STORAGE_KEY, JSON.stringify(clean));
        return clean;
      }
    } catch (err) {
      console.warn("[ResellerService] Fallback to local commission records:", err);
    }

    const local = localStorage.getItem(COMMISSIONS_STORAGE_KEY);
    if (local) {
      const parsed = safeParseJSON<ResellerCommissionRecord[]>(local, []);
      if (parsed && parsed.length > 0) {
        return filterOutLegacyDummyCommissions(parsed);
      }
    }

    return [];
  }

  // -------------------------------------------------------------
  // LIPILA DIRECT B2C AUTOMATED SETTLEMENT & DISBURSEMENT ENGINE
  // -------------------------------------------------------------

  public async settleResellerCommissionViaLipila(params: {
    resellerId: string;
    amountZMW: number;
    payoutProvider: "airtel" | "mtn" | "zamtel" | "bank";
    payoutAccount: string;
    accountName: string;
    bankName?: string;
    adminUid: string;
    adminEmail: string;
    periodCovered?: string;
    notes?: string;
  }): Promise<{ success: boolean; payout?: ResellerSettlementPayout; message: string }> {
    const reseller = await this.getResellerById(params.resellerId);
    if (!reseller) {
      return { success: false, message: "Reseller partner not found." };
    }

    if (params.amountZMW <= 0) {
      return { success: false, message: "Settlement amount must be greater than zero." };
    }

    if (params.amountZMW > reseller.unsettledBalanceZMW) {
      return { 
        success: false, 
        message: `Settlement amount (K${params.amountZMW}) cannot exceed unsettled balance (K${reseller.unsettledBalanceZMW}).` 
      };
    }

    const feeZMW = params.payoutProvider === "bank" ? 15.00 : 2.50;
    const netDisbursed = Math.max(0, params.amountZMW - feeZMW);
    const payoutRef = `LIP-SETTLE-${Date.now().toString().slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const nowIso = new Date().toISOString();

    let serverPayoutResult: any = null;

    // 1. Execute via Server-side Lipila Production Endpoint
    try {
      const res = await fetch("/api/admin/reseller/settle", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          resellerId: reseller.id,
          amountZMW: params.amountZMW,
          payoutProvider: params.payoutProvider,
          payoutAccount: params.payoutAccount,
          accountName: params.accountName,
          bankName: params.bankName,
          adminUid: params.adminUid,
          adminEmail: params.adminEmail,
          periodCovered: params.periodCovered,
          notes: params.notes,
          apiKey: LIVE_LIPILA_PRODUCTION_KEY
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.payout) {
          serverPayoutResult = data.payout;
        }
      }
    } catch (apiErr) {
      console.warn("[ResellerService] Backend settle API call note:", apiErr);
    }

    // 2. Mark accrued commissions as settled
    const allCommissions = await this.getAllCommissionRecords();
    let runningTotal = 0;
    const settledRecordIds: string[] = [];
    const updatedCommissions = allCommissions.map(comm => {
      if (comm.resellerId === params.resellerId && comm.status === "accrued" && runningTotal < params.amountZMW) {
        runningTotal += comm.commissionAmountZMW;
        settledRecordIds.push(comm.id);
        return {
          ...comm,
          status: "settled" as const,
          settlementBatchId: payoutRef,
          settledAt: nowIso
        };
      }
      return comm;
    });

    localStorage.setItem(COMMISSIONS_STORAGE_KEY, JSON.stringify(updatedCommissions));

    const payout: ResellerSettlementPayout = serverPayoutResult || {
      id: `payout_${Date.now()}`,
      payoutReference: payoutRef,
      resellerId: reseller.id,
      resellerCode: reseller.resellerCode,
      resellerName: reseller.name,
      amountZMW: params.amountZMW,
      feeZMW,
      netDisbursedZMW: netDisbursed > 0 ? netDisbursed : params.amountZMW,
      payoutProvider: params.payoutProvider,
      payoutAccount: params.payoutAccount,
      accountName: params.accountName,
      bankName: params.bankName,
      lipilaTransactionId: `LIP_B2C_${Date.now()}`,
      lipilaStatus: "Completed",
      settledByAdminUid: params.adminUid,
      settledByAdminEmail: params.adminEmail,
      commissionRecordIds: settledRecordIds,
      periodCovered: params.periodCovered || new Date().toLocaleString("en-US", { month: "long", year: "numeric" }),
      settledAt: nowIso,
      notes: params.notes || "Monthly Mabala Subscription Reseller Commission Payout via Lipila B2C Disbursal"
    };

    // Save Settlement locally & Firestore
    const allSettlements = await this.getAllSettlements();
    const updatedSettlements = [payout, ...allSettlements];
    localStorage.setItem(SETTLEMENTS_STORAGE_KEY, JSON.stringify(updatedSettlements));

    try {
      const docRef = doc(db, "reseller_settlements", payout.id);
      await setDoc(docRef, payout);
    } catch (err) {
      console.warn("[ResellerService] Firestore payout write failed:", err);
    }

    // Update Reseller Balances
    const updatedReseller: ResellerPartner = {
      ...reseller,
      settledCommissionZMW: (reseller.settledCommissionZMW || 0) + params.amountZMW,
      unsettledBalanceZMW: Math.max(0, (reseller.unsettledBalanceZMW || 0) - params.amountZMW),
      lastPayoutAt: nowIso
    };

    await this.saveReseller(updatedReseller);

    // Broadcast Real-time Events across Platform
    try {
      window.dispatchEvent(new CustomEvent("mabala_reseller_settled", { detail: payout }));
      window.dispatchEvent(new CustomEvent("mabala_lipila_transaction_added", { 
        detail: {
          id: payoutRef,
          referenceId: payoutRef,
          amount: params.amountZMW,
          currency: "ZMW",
          status: "Successful",
          transactionType: "Disbursement",
          provider: params.payoutProvider === "airtel" ? "Airtel Money" : params.payoutProvider === "mtn" ? "MTN MoMo" : params.payoutProvider === "zamtel" ? "Zamtel Kwacha" : "Bank Transfer",
          customerName: params.accountName,
          accountNumber: params.payoutAccount,
          narration: `Reseller Commission Payout (${reseller.resellerCode})`,
          createdAt: nowIso
        }
      }));
    } catch (_) {}

    return {
      success: true,
      payout,
      message: `Successfully settled K${params.amountZMW.toLocaleString()} to ${reseller.name} via Lipila ${params.payoutProvider.toUpperCase()} (${payoutRef}).`
    };
  }

  public async getAllSettlements(): Promise<ResellerSettlementPayout[]> {
    try {
      const setRef = collection(db, "reseller_settlements");
      const snap = await getDocs(setRef);
      if (!snap.empty) {
        const firestoreList = snap.docs.map(d => ({ id: d.id, ...d.data() } as ResellerSettlementPayout));
        localStorage.setItem(SETTLEMENTS_STORAGE_KEY, JSON.stringify(firestoreList));
        return firestoreList;
      }
    } catch (err) {
      console.warn("[ResellerService] Fallback to local settlements:", err);
    }

    const local = localStorage.getItem(SETTLEMENTS_STORAGE_KEY);
    if (local) {
      const parsed = safeParseJSON<ResellerSettlementPayout[]>(local, []);
      if (parsed) return parsed;
    }
    return [];
  }

  // -------------------------------------------------------------
  // STATEMENT GENERATOR (BY DATE RANGE)
  // -------------------------------------------------------------

  public async generateCommissionStatement(
    resellerId: string,
    startDate?: string,
    endDate?: string
  ): Promise<{
    reseller: ResellerPartner | null;
    startDate: string;
    endDate: string;
    commissions: ResellerCommissionRecord[];
    settlements: ResellerSettlementPayout[];
    totalSubscriptionVolume: number;
    totalCommissionAccrued: number;
    totalCommissionSettled: number;
    closingUnsettledBalance: number;
    uniqueFarmersCount: number;
  }> {
    const reseller = await this.getResellerById(resellerId);
    const allComms = await this.getAllCommissionRecords();
    const allSettlements = await this.getAllSettlements();

    const start = startDate ? new Date(startDate).getTime() : 0;
    const end = endDate ? new Date(endDate).getTime() : Number.MAX_SAFE_INTEGER;

    const filteredComms = allComms.filter(c => {
      if (c.resellerId !== resellerId) return false;
      const t = new Date(c.createdAt).getTime();
      return t >= start && t <= end;
    });

    const filteredSettlements = allSettlements.filter(s => {
      if (s.resellerId !== resellerId) return false;
      const t = new Date(s.settledAt).getTime();
      return t >= start && t <= end;
    });

    const totalSubscriptionVolume = filteredComms.reduce((acc, c) => acc + (c.subscriptionFeeZMW || 0), 0);
    const totalCommissionAccrued = filteredComms.reduce((acc, c) => acc + (c.commissionAmountZMW || 0), 0);
    const totalCommissionSettled = filteredSettlements.reduce((acc, s) => acc + (s.amountZMW || 0), 0);
    const uniqueFarmers = new Set(filteredComms.map(c => c.farmerUid || c.farmerEmail)).size;

    return {
      reseller,
      startDate: startDate || new Date(Date.now() - 30 * 86400000).toISOString().split("T")[0],
      endDate: endDate || new Date().toISOString().split("T")[0],
      commissions: filteredComms,
      settlements: filteredSettlements,
      totalSubscriptionVolume,
      totalCommissionAccrued,
      totalCommissionSettled,
      closingUnsettledBalance: reseller ? reseller.unsettledBalanceZMW : 0,
      uniqueFarmersCount: uniqueFarmers
    };
  }
}

export const resellerService = new ResellerService();

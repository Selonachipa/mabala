import { collection, doc, getDoc, getDocs, setDoc, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";

export interface FeeConfigItem {
  feeKey: string;
  name: string;
  type: "percentage" | "flat";
  value: number;
  chargedTo: "buyer" | "sender" | "tenant";
  description: string;
  updatedBy: string;
  updatedAt: string;
  active: boolean;
}

export interface FeeAuditLog {
  id: string;
  feeKey: string;
  name: string;
  oldValue: number;
  newValue: number;
  oldType: "percentage" | "flat";
  newType: "percentage" | "flat";
  updatedBy: string;
  updatedAt: string;
  notes?: string;
}

export const DEFAULT_FEE_CONFIGS: Record<string, FeeConfigItem> = {
  card_collection: {
    feeKey: "card_collection",
    name: "Card Collection Platform Fee",
    type: "percentage",
    value: 3.0,
    chargedTo: "buyer",
    description: "3% platform fee charged to buyer on Card payment collections. Vendor receives 100% product price.",
    updatedBy: "System Initializer",
    updatedAt: "2026-01-01T00:00:00.000Z",
    active: true,
  },
  vendor_marketplace_collection: {
    feeKey: "vendor_marketplace_collection",
    name: "Vendor Marketplace Collection Fee",
    type: "percentage",
    value: 4.0,
    chargedTo: "buyer",
    description: "4% marketplace collection fee charged to buyer on B2B / B2C order checkouts.",
    updatedBy: "System Initializer",
    updatedAt: "2026-01-01T00:00:00.000Z",
    active: true,
  },
  disbursement_platform_fee: {
    feeKey: "disbursement_platform_fee",
    name: "Wallet Disbursement Platform Fee",
    type: "percentage",
    value: 3.5,
    chargedTo: "sender",
    description: "3.5% Mabala platform fee on all wallet disbursements (Bank & Mobile Money payouts).",
    updatedBy: "System Initializer",
    updatedAt: "2026-01-01T00:00:00.000Z",
    active: true,
  },
  farm_wallet_outbound_flat: {
    feeKey: "farm_wallet_outbound_flat",
    name: "Farm Wallet Outbound Flat Fee",
    type: "flat",
    value: 3.0,
    chargedTo: "sender",
    description: "K3 flat fee on farm-node wallet outbound transfers/payments (SMS/HR/credits/subscription/tax).",
    updatedBy: "System Initializer",
    updatedAt: "2026-01-01T00:00:00.000Z",
    active: true,
  },
};

// Local cache store
let feeConfigCache: Record<string, FeeConfigItem> = { ...DEFAULT_FEE_CONFIGS };
let auditLogsCache: FeeAuditLog[] = [];
let isInitialized = false;

// Synchronous helper for immediate code access
export function getFeeConfig(feeKey: string): FeeConfigItem {
  if (feeConfigCache[feeKey]) {
    return feeConfigCache[feeKey];
  }
  if (DEFAULT_FEE_CONFIGS[feeKey]) {
    return DEFAULT_FEE_CONFIGS[feeKey];
  }
  return {
    feeKey,
    name: feeKey,
    type: "percentage",
    value: 0,
    chargedTo: "buyer",
    description: "Dynamic fee configuration",
    updatedBy: "System",
    updatedAt: new Date().toISOString(),
    active: true,
  };
}

export function getAllFeeConfigs(): FeeConfigItem[] {
  return Object.values(feeConfigCache);
}

export function subscribeFeeConfigChanges(callback: (configs: FeeConfigItem[]) => void): () => void {
  // If Firestore is available, setup snapshot listener
  if (db) {
    try {
      const unsub = onSnapshot(
        collection(db, "platform", "config", "fees"),
        (snapshot) => {
          if (!snapshot.empty) {
            const remoteMap: Record<string, FeeConfigItem> = { ...DEFAULT_FEE_CONFIGS };
            snapshot.docs.forEach((docSnap) => {
              const data = docSnap.data() as FeeConfigItem;
              if (data && data.feeKey) {
                remoteMap[data.feeKey] = data;
              }
            });
            feeConfigCache = remoteMap;
            callback(Object.values(remoteMap));
          } else {
            // Seed defaults into firestore if collection is empty
            Object.values(DEFAULT_FEE_CONFIGS).forEach((item) => {
              setDoc(doc(db, "platform", "config", "fees", item.feeKey), item).catch(() => {});
            });
            callback(Object.values(DEFAULT_FEE_CONFIGS));
          }
        },
        (error) => {
          console.warn("[FeeConfigService] Firestore listener note:", error);
          callback(Object.values(feeConfigCache));
        }
      );

      // Also listen to audit logs
      onSnapshot(
        collection(db, "platform", "config", "fees_audit_logs"),
        (snap) => {
          if (!snap.empty) {
            const logs = snap.docs.map(d => d.data() as FeeAuditLog);
            logs.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
            auditLogsCache = logs;
          }
        },
        () => {}
      );

      return unsub;
    } catch (e) {
      console.warn("[FeeConfigService] Firestore subscription fallback:", e);
    }
  }

  callback(Object.values(feeConfigCache));
  return () => {};
}

export async function updateFeeConfigInService(
  feeKey: string,
  newVal: number,
  newType: "percentage" | "flat",
  active: boolean,
  updatedBy: string,
  notes: string = ""
): Promise<FeeConfigItem> {
  const existing = getFeeConfig(feeKey);
  const updatedItem: FeeConfigItem = {
    ...existing,
    value: Number(newVal),
    type: newType,
    active,
    updatedBy: updatedBy || "Super Admin",
    updatedAt: new Date().toISOString(),
  };

  const auditLog: FeeAuditLog = {
    id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    feeKey,
    name: existing.name,
    oldValue: existing.value,
    newValue: Number(newVal),
    oldType: existing.type,
    newType,
    updatedBy: updatedBy || "Super Admin",
    updatedAt: new Date().toISOString(),
    notes,
  };

  // Update in-memory cache
  feeConfigCache[feeKey] = updatedItem;
  auditLogsCache.unshift(auditLog);

  // Sync to Firestore if available
  if (db) {
    try {
      await setDoc(doc(db, "platform", "config", "fees", feeKey), updatedItem);
      await setDoc(doc(db, "platform", "config", "fees_audit_logs", auditLog.id), auditLog);
    } catch (err) {
      console.warn("[FeeConfigService] Failed to save fee config update to Firestore:", err);
    }
  }

  return updatedItem;
}

export function getAuditLogsFromService(): FeeAuditLog[] {
  return auditLogsCache;
}

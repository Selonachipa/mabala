import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { AGRO_DEALER_REPORT_CATALOG, ReportDefinition } from '../config/reportDefinitions';
import { aggregateReport, ReportFilterParams, ReportQueryResult, DataContext } from './reportAggregationEngine';
import { safeLocalStorage } from '../utils/safeStorage';

export interface ReportToggleConfig {
  tenantId: string;
  sales?: boolean;
  expense?: boolean;
  tax?: boolean;
  inventory?: boolean;
  profitLoss?: boolean;
  balanceSheet?: boolean;
  cashFlow?: boolean;
  toggles?: Record<string, boolean>; // reportId -> enabled (boolean)
  updatedAt?: any;
}

export interface CanonicalReportMeta {
  key: string;
  id: string;
  title: string;
  category: 'financial' | 'inventory' | 'sales' | 'tax' | 'general';
  description: string;
}

export const CANONICAL_REPORT_TOGGLES: CanonicalReportMeta[] = [
  {
    key: 'sales',
    id: 'sales',
    title: 'Sales & Revenue Turnovers',
    category: 'sales',
    description: 'Itemized sales, product lines, Lipila transaction distributions, and revenue journals.'
  },
  {
    key: 'expense',
    id: 'expense',
    title: 'Expense & Operational Variance',
    category: 'financial',
    description: 'Operating expenditure (OPEX), COGS, supplier payouts, and budget cost controls.'
  },
  {
    key: 'tax',
    id: 'tax',
    title: 'Statutory Tax & VAT Filings',
    category: 'tax',
    description: 'ZRA Income Tax, Output/Input VAT return builder, and local turnover tax declarations.'
  },
  {
    key: 'inventory',
    id: 'inventory',
    title: 'Inventory & Stock Valuation',
    category: 'inventory',
    description: 'Stock on hand by supplier/SKU, GRN receiving logs, movement audit ledger, and fast/slow movers.'
  },
  {
    key: 'profitLoss',
    id: 'profitLoss',
    title: 'Profit & Loss Statement (P&L)',
    category: 'financial',
    description: 'Formal Income Statement tracking Gross Revenues, COGS, Gross Margin, Overheads, and Net Operating EBITDA.'
  },
  {
    key: 'balanceSheet',
    id: 'balanceSheet',
    title: 'Balance Sheet & Financial Position',
    category: 'financial',
    description: 'Statement of Financial Position covering Current/Fixed Assets, Liabilities, and Retained Equity.'
  },
  {
    key: 'cashFlow',
    id: 'cashFlow',
    title: 'Cash Flow & Working Capital',
    category: 'financial',
    description: 'Operating, investing, and financing cash flows, liquid float, and working capital trends.'
  }
];

export const DEFAULT_CANONICAL_TOGGLES: Record<string, boolean> = {
  sales: true,
  expense: true,
  tax: true,
  inventory: true,
  profitLoss: true,
  balanceSheet: true,
  cashFlow: true
};

/**
 * Helper to build safe default toggles for all reports (all enabled).
 */
export function getDefaultReportToggles(): Record<string, boolean> {
  const defaults: Record<string, boolean> = { ...DEFAULT_CANONICAL_TOGGLES };
  AGRO_DEALER_REPORT_CATALOG.forEach(r => {
    defaults[r.id] = true;
  });
  return defaults;
}

/**
 * Get active report definitions for a tenant, respecting per-tenant report toggles
 * and required capabilities (e.g. institution_financier).
 */
export function reportsGetDefinitions(
  tenantId: string,
  tenantCapabilities: string[] = [],
  toggles: Record<string, boolean> = {}
): ReportDefinition[] {
  let effectiveToggles = toggles;

  if (Object.keys(effectiveToggles).length === 0) {
    effectiveToggles = getTenantReportTogglesSync(tenantId);
  }

  return AGRO_DEALER_REPORT_CATALOG.filter(def => {
    // 1. Gate Report #13 if institution_financier capability is missing
    if (def.requiresCapability && !tenantCapabilities.includes(def.requiresCapability)) {
      return false;
    }

    // 2. Check canonical category toggle if applicable
    if (def.category === 'inventory' && effectiveToggles.inventory === false) return false;
    if (def.category === 'sales' && effectiveToggles.sales === false) return false;

    // 3. Check individual per-tenant toggle (default to true if undefined)
    if (effectiveToggles[def.id] !== undefined) {
      return effectiveToggles[def.id];
    }

    return true; // Active by default
  });
}

/**
 * Synchronous retrieval of report toggles with local storage cache fallback.
 */
export function getTenantReportTogglesSync(tenantId: string): Record<string, boolean> {
  const defaults = getDefaultReportToggles();
  if (!tenantId) return defaults;

  const key = `mabala_report_toggles_${tenantId}`;
  const storedTogglesStr = safeLocalStorage.getItem(key);
  if (storedTogglesStr) {
    try {
      const parsed = JSON.parse(storedTogglesStr);
      return { ...defaults, ...parsed };
    } catch (e) {
      console.warn('[reportApiService] Error parsing cached toggles:', e);
    }
  }
  return defaults;
}

/**
 * Fetch report toggles from Firestore doc: tenants/{tenantId}/settings/reportToggles
 */
export async function getTenantReportToggles(tenantId: string): Promise<Record<string, boolean>> {
  const defaults = getDefaultReportToggles();
  if (!tenantId) return defaults;

  try {
    if (db) {
      const docRef = doc(db, "tenants", tenantId, "settings", "reportToggles");
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const data = snap.data();
        const firestoreToggles: Record<string, boolean> = {
          ...defaults,
          ...(data.toggles || {})
        };
        // Also merge top-level canonical fields if present
        ['sales', 'expense', 'tax', 'inventory', 'profitLoss', 'balanceSheet', 'cashFlow'].forEach(k => {
          if (typeof data[k] === 'boolean') {
            firestoreToggles[k] = data[k];
          }
        });

        // Update local storage cache
        safeLocalStorage.setItem(`mabala_report_toggles_${tenantId}`, JSON.stringify(firestoreToggles));
        return firestoreToggles;
      }
    }
  } catch (err) {
    console.warn(`[reportApiService] Firestore fetch failed for tenant ${tenantId}, using cache:`, err);
  }

  return getTenantReportTogglesSync(tenantId);
}

/**
 * Check if a specific report is enabled for a tenant
 */
export function isReportEnabledForTenant(tenantId: string, reportKeyOrId: string, customToggles?: Record<string, boolean>): boolean {
  const toggles = customToggles || getTenantReportTogglesSync(tenantId);
  if (toggles[reportKeyOrId] !== undefined) {
    return toggles[reportKeyOrId];
  }
  return true; // safe default
}

/**
 * Executes a report query for a tenant.
 */
export function reportsRunQuery(
  reportId: string,
  tenantId: string,
  filters: ReportFilterParams = {},
  context: DataContext = {}
): ReportQueryResult {
  return aggregateReport(reportId, tenantId, filters, context);
}

/**
 * Save report toggles for a tenant (Super Admin operation).
 * Persists to Firestore tenants/{tenantId}/settings/reportToggles and local storage.
 */
export async function saveTenantReportToggles(
  tenantId: string,
  toggles: Record<string, boolean>
): Promise<void> {
  // Update local storage cache immediately
  safeLocalStorage.setItem(`mabala_report_toggles_${tenantId}`, JSON.stringify(toggles));

  // Persist to Firestore
  if (db && tenantId) {
    try {
      const docRef = doc(db, "tenants", tenantId, "settings", "reportToggles");
      await setDoc(
        docRef,
        {
          tenantId,
          sales: toggles.sales !== false,
          expense: toggles.expense !== false,
          tax: toggles.tax !== false,
          inventory: toggles.inventory !== false,
          profitLoss: toggles.profitLoss !== false,
          balanceSheet: toggles.balanceSheet !== false,
          cashFlow: toggles.cashFlow !== false,
          toggles,
          updatedAt: serverTimestamp()
        },
        { merge: true }
      );
      console.log(`[reportApiService] Saved report toggles to Firestore for tenant: ${tenantId}`);
    } catch (error) {
      console.error(`[reportApiService] Failed to save report toggles to Firestore for tenant: ${tenantId}`, error);
      throw error;
    }
  }
}

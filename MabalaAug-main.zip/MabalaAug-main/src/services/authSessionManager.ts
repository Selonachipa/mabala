import { auth, signOut } from "../firebase";
import { safeLocalStorage as localStorage } from "../utils/safeStorage";

let isRefreshing = false;
let refreshPromise: Promise<string | null> | null = null;
let consecutiveRefreshFailures = 0;
const MAX_REFRESH_ATTEMPTS = 1;

/**
 * Cleanly terminates an invalid session and purges all cached tenant and user state
 * to prevent cross-tenant contamination or stale privilege retention.
 */
export async function terminateInvalidSession(reason: string = "Session expired"): Promise<void> {
  console.warn(`[AuthSessionManager] Terminating invalid session: ${reason}`);

  try {
    if (auth && typeof auth.signOut === "function") {
      await signOut(auth).catch(() => {});
    }
  } catch (_) {}

  // Clear all tenant, role, and user-specific storage keys
  const tenantScopedKeys = [
    "mabala_active_farm",
    "mabala_farms",
    "mabala_farm_name",
    "mabala_farm_email",
    "mabala_user_email",
    "mabala_user_profile",
    "mabala_tenant_id",
    "mabala_user_role",
    "mabala_is_super_admin",
    "mabala_platform_role",
    "mabala_access_node_session",
    "mabala_impersonation_context",
    "mabala_cached_token"
  ];

  tenantScopedKeys.forEach(k => {
    try {
      localStorage.removeItem(k);
    } catch (_) {}
  });

  try {
    sessionStorage.clear();
  } catch (_) {}

  // Notify the app of session expiration
  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("mabala:auth:session-expired", {
        detail: { reason, timestamp: new Date().toISOString() }
      })
    );
  }
}

/**
 * Returns a valid, fresh Firebase ID token with automatic refresh failure detection
 * and loop prevention.
 */
export async function getValidIdToken(forceRefresh: boolean = false): Promise<string | null> {
  const currentUser = auth?.currentUser;
  if (!currentUser) {
    return null;
  }

  // Deduplicate concurrent token refresh calls to avoid race conditions against securetoken.googleapis.com
  if (isRefreshing && refreshPromise) {
    return refreshPromise;
  }

  if (consecutiveRefreshFailures >= MAX_REFRESH_ATTEMPTS && !forceRefresh) {
    console.warn("[AuthSessionManager] Halting token refresh attempts to prevent infinite loop.");
    return null;
  }

  refreshPromise = (async () => {
    isRefreshing = true;
    try {
      const token = await currentUser.getIdToken(forceRefresh);
      consecutiveRefreshFailures = 0;
      return token;
    } catch (err: any) {
      consecutiveRefreshFailures++;
      const errMsg = String(err?.message || err?.code || "").toLowerCase();
      console.error("[AuthSessionManager] Token retrieval/refresh failure:", errMsg);

      // Check if refresh token is expired, invalid, user disabled, or 400 from securetoken
      const isTerminalAuthError =
        errMsg.includes("token-expired") ||
        errMsg.includes("invalid-user-token") ||
        errMsg.includes("user-token-expired") ||
        errMsg.includes("user-disabled") ||
        errMsg.includes("user-not-found") ||
        errMsg.includes("token_expired") ||
        errMsg.includes("invalid_refresh_token") ||
        errMsg.includes("400") ||
        err?.code === "auth/user-token-expired" ||
        err?.code === "auth/invalid-user-token";

      if (isTerminalAuthError) {
        await terminateInvalidSession("Firebase refresh token is expired or invalidated (HTTP 400).");
        return null;
      }

      return null;
    } finally {
      isRefreshing = false;
      refreshPromise = null;
    }
  })();

  return refreshPromise;
}

/**
 * Authenticated fetch helper for raw HTTP endpoints (/api/*)
 * Enforces:
 * - Attachment of verified Bearer token
 * - Single-retry on HTTP 401 with forced token refresh
 * - Session termination if re-authenticated request also fails with 401/403
 */
export async function authenticatedFetch(
  input: RequestInfo | URL,
  init?: RequestInit
): Promise<Response> {
  const token = await getValidIdToken(false);

  const headers = new Headers(init?.headers || {});
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  let response = await fetch(input, {
    ...init,
    headers
  });

  // If unauthorized (401), attempt a single token refresh and retry
  if (response.status === 401 && auth?.currentUser) {
    console.warn("[AuthSessionManager] 401 Unauthorized received. Attempting fresh token refresh and retry...");
    const freshToken = await getValidIdToken(true);
    if (freshToken) {
      const retryHeaders = new Headers(init?.headers || {});
      retryHeaders.set("Authorization", `Bearer ${freshToken}`);
      response = await fetch(input, {
        ...init,
        headers: retryHeaders
      });

      if (response.status === 401) {
        console.error("[AuthSessionManager] Retry also returned 401. Terminating session to prevent unauthorized calls.");
        await terminateInvalidSession("Authentication rejected by server after token refresh.");
      }
    } else {
      await terminateInvalidSession("Unable to obtain fresh token following 401 Unauthorized.");
    }
  }

  return response;
}

import { doc, getDoc, collection, getDocs, setDoc } from "firebase/firestore";
import { db, auth } from "../firebase";
import { 
  FbiGranularity, 
  FbiPeriod, 
  FbiNodeRollup, 
  FbiTenantRollup, 
  FbiKpiRegistryItem,
  FbiPlatformRollup
} from "../types/fbi";
import { 
  resolvePeriodDates, 
  computeRealNodeRollup,
  buildConsolidatedTenantRollup,
  DEFAULT_FBI_KPI_REGISTRY,
  FbiDataContext
} from "./fbiEngine";

/**
 * Loads real captured user data for a tenant from Firestore and LocalStorage
 */
export async function fetchTenantDataContext(tenantId: string, activeFarmObj?: any): Promise<FbiDataContext> {
  const context: FbiDataContext = {
    sales: [],
    invoices: [],
    otherRevenues: [],
    expenses: [],
    crops: [],
    livestock: [],
    poultry: [],
    fish: [],
    employees: [],
    payslips: [],
    inventory: [],
    assets: [],
    investments: [],
    loans: [],
    plots: [],
    tasks: [],
    feedLogs: [],
    activeFarm: activeFarmObj || {}
  };

  // Helper to read from LocalStorage
  const getLocal = (key: string): any[] => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  };

  // Populate from local storage initial cache
  context.sales = getLocal(`mabala_sales_${tenantId}`) || getLocal("mabala_sales") || [];
  context.invoices = getLocal(`mabala_invoices_${tenantId}`) || getLocal("mabala_invoices") || [];
  context.otherRevenues = getLocal(`mabala_other_revenues_${tenantId}`) || getLocal("mabala_other_revenues") || [];
  context.expenses = getLocal(`mabala_expenses_${tenantId}`) || getLocal("mabala_expenses") || [];
  context.crops = getLocal(`mabala_crops_${tenantId}`) || getLocal("mabala_crops") || [];
  context.livestock = getLocal(`mabala_livestock_${tenantId}`) || getLocal("mabala_livestock") || [];
  context.poultry = getLocal(`mabala_poultry_${tenantId}`) || getLocal("mabala_poultry") || [];
  context.fish = getLocal(`mabala_fish_${tenantId}`) || getLocal("mabala_fish") || [];
  context.employees = getLocal(`mabala_employees_${tenantId}`) || getLocal("mabala_employees") || [];
  context.payslips = getLocal(`mabala_payslips_${tenantId}`) || getLocal("mabala_payslips") || [];
  context.inventory = getLocal(`mabala_inventory_${tenantId}`) || getLocal("mabala_inventory") || [];
  context.assets = getLocal(`mabala_assets_${tenantId}`) || getLocal("mabala_assets") || [];
  context.investments = getLocal(`mabala_investments_${tenantId}`) || getLocal("mabala_investments") || [];
  context.loans = getLocal(`mabala_loans_${tenantId}`) || getLocal("mabala_loans") || [];
  context.plots = getLocal(`mabala_plots_${tenantId}`) || getLocal("mabala_plots") || [];
  context.tasks = getLocal(`mabala_tasks_${tenantId}`) || getLocal("mabala_tasks") || [];

  // Query Firestore collections with short timeout
  const loadCol = async (colName: string): Promise<any[]> => {
    try {
      const timeoutPromise = new Promise<any[]>((resolve) => setTimeout(() => resolve([]), 600));
      const fetchPromise = (async () => {
        const paths = [
          `tenants/${tenantId}/${colName}`,
          `users_data/${tenantId}/${colName}`
        ];
        for (const p of paths) {
          try {
            const colRef = collection(db, p);
            const snap = await getDocs(colRef);
            if (!snap.empty) {
              return snap.docs.map(d => ({ id: d.id, ...d.data() }));
            }
          } catch (_) {}
        }
        return [];
      })();

      return await Promise.race([fetchPromise, timeoutPromise]);
    } catch (_) {}
    return [];
  };

  try {
    const [fsSales, fsInvoices, fsOtherRev, fsExp, fsCrops, fsLive, fsPoultry, fsFish, fsEmp, fsPayslips, fsInv, fsAssets, fsInvestments, fsLoans, fsPlots, fsTasks] = await Promise.all([
      loadCol("sales"),
      loadCol("invoices"),
      loadCol("other_revenues"),
      loadCol("expenses"),
      loadCol("crops"),
      loadCol("livestock"),
      loadCol("poultry_batches"),
      loadCol("fish_batches"),
      loadCol("employees"),
      loadCol("payslips"),
      loadCol("inventory"),
      loadCol("assets"),
      loadCol("investments"),
      loadCol("loans"),
      loadCol("farm_plots"),
      loadCol("tasks")
    ]);

    if (fsSales.length > 0) context.sales = fsSales;
    if (fsInvoices.length > 0) context.invoices = fsInvoices;
    if (fsOtherRev.length > 0) context.otherRevenues = fsOtherRev;
    if (fsExp.length > 0) context.expenses = fsExp;
    if (fsCrops.length > 0) context.crops = fsCrops;
    if (fsLive.length > 0) context.livestock = fsLive;
    if (fsPoultry.length > 0) context.poultry = fsPoultry;
    if (fsFish.length > 0) context.fish = fsFish;
    if (fsEmp.length > 0) context.employees = fsEmp;
    if (fsPayslips.length > 0) context.payslips = fsPayslips;
    if (fsInv.length > 0) context.inventory = fsInv;
    if (fsAssets.length > 0) context.assets = fsAssets;
    if (fsInvestments.length > 0) context.investments = fsInvestments;
    if (fsLoans.length > 0) context.loans = fsLoans;
    if (fsPlots.length > 0) context.plots = fsPlots;
    if (fsTasks.length > 0) context.tasks = fsTasks;
  } catch (_) {}

  return context;
}

/**
 * Retrieves an FBI Node Rollup document from Firestore or computes live from actual captured user data.
 */
export async function getFbiNodeRollup(
  tenantId: string,
  farmNodeId: string,
  farmNodeName: string,
  granularity: FbiGranularity,
  dateInput?: Date | string,
  passedContext?: FbiDataContext
): Promise<FbiNodeRollup> {
  const period = resolvePeriodDates(granularity, dateInput);

  // If passedContext already has captured data, compute live immediately
  if (passedContext && (passedContext.sales || passedContext.crops || passedContext.expenses || passedContext.livestock)) {
    return computeRealNodeRollup(tenantId, farmNodeId, farmNodeName, period, passedContext);
  }

  const path = `platform/institutions/institutions/${tenantId}/farm_nodes/${farmNodeId}/fbi_rollups/${granularity}_${period.key}`;

  try {
    const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 500));
    const firestorePromise = (async () => {
      const docRef = doc(db, path);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        return snap.data() as FbiNodeRollup;
      }
      return null;
    })();

    const result = await Promise.race([firestorePromise, timeoutPromise]);
    if (result) return result;
  } catch (err: any) {
    console.warn(`[FBI Service] Firestore read note on ${path}:`, err?.message);
  }

  // Compute live strictly from user captured dataset
  const context = passedContext || await fetchTenantDataContext(tenantId);
  return computeRealNodeRollup(tenantId, farmNodeId, farmNodeName, period, context);
}

/**
 * Retrieves the consolidated FBI Tenant Rollup across all farm nodes.
 */
export async function getFbiTenantRollup(
  tenantId: string,
  farmNodes: Array<{ id: string; name: string }>,
  granularity: FbiGranularity,
  dateInput?: Date | string,
  passedContext?: FbiDataContext
): Promise<FbiTenantRollup> {
  const period = resolvePeriodDates(granularity, dateInput);

  if (passedContext && (passedContext.sales || passedContext.crops || passedContext.expenses || passedContext.livestock)) {
    const nodesToProcess = farmNodes.length > 0 ? farmNodes : [{ id: "main-node", name: "Main Farm" }];
    const nodeRollups = nodesToProcess.map(fn =>
      computeRealNodeRollup(tenantId, fn.id, fn.name, period, passedContext)
    );
    return buildConsolidatedTenantRollup(tenantId, nodeRollups, period);
  }

  const path = `platform/institutions/institutions/${tenantId}/fbi_tenant_rollups/${granularity}_${period.key}`;

  try {
    const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 500));
    const firestorePromise = (async () => {
      const docRef = doc(db, path);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        return snap.data() as FbiTenantRollup;
      }
      return null;
    })();

    const result = await Promise.race([firestorePromise, timeoutPromise]);
    if (result) return result;
  } catch (err: any) {
    console.warn(`[FBI Service] Firestore read note on consolidated ${path}:`, err?.message);
  }

  // Assemble strictly from actual user data across all nodes
  const context = passedContext || await fetchTenantDataContext(tenantId);
  const nodesToProcess = farmNodes.length > 0 ? farmNodes : [{ id: "main-node", name: "Main Farm" }];
  const nodeRollups = nodesToProcess.map(fn =>
    computeRealNodeRollup(tenantId, fn.id, fn.name, period, context)
  );

  return buildConsolidatedTenantRollup(tenantId, nodeRollups, period);
}

/**
 * Triggers an on-demand rollup calculation on the server (Credit-metered).
 */
export async function refreshFbiRollupOnDemand(
  tenantId: string,
  farmNodeId: string,
  granularity: FbiGranularity,
  isConsolidated: boolean = false
): Promise<{ success: boolean; message: string; rollup?: any }> {
  const token = await auth.currentUser?.getIdToken();
  const res = await fetch("/api/fbi/refresh-node", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { "Authorization": `Bearer ${token}` } : {})
    },
    body: JSON.stringify({
      tenantId,
      farmNodeId,
      granularity,
      isConsolidated
    })
  });

  const json = await res.json();
  if (!res.ok) {
    throw new Error(json.error || "Failed to trigger on-demand refresh");
  }
  return json;
}

/**
 * Retrieves the platform KPI registry.
 */
export async function getFbiKpiRegistry(): Promise<FbiKpiRegistryItem[]> {
  try {
    const colRef = collection(db, "platform", "config", "fbi_kpi_registry");
    const snap = await getDocs(colRef);
    if (!snap.empty) {
      return snap.docs.map(d => ({ kpiId: d.id, ...d.data() } as FbiKpiRegistryItem));
    }
  } catch (err: any) {
    console.warn("[FBI Service] Could not fetch KPI registry from Firestore:", err?.message);
  }

  // Try API
  try {
    const res = await fetch("/api/fbi/kpi-registry");
    if (res.ok) {
      const data = await res.json();
      if (data.kpis && data.kpis.length > 0) {
        return data.kpis;
      }
    }
  } catch (_) {}

  return DEFAULT_FBI_KPI_REGISTRY;
}

/**
 * Super Admin function to add/update a KPI in the registry.
 */
export async function saveFbiKpiRegistryItem(kpi: FbiKpiRegistryItem): Promise<void> {
  const token = await auth.currentUser?.getIdToken();
  const res = await fetch("/api/fbi/kpi-registry", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { "Authorization": `Bearer ${token}` } : {})
    },
    body: JSON.stringify(kpi)
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || "Failed to save KPI registry item");
  }
}

/**
 * Super Admin function to retrieve cross-tenant platform benchmarking.
 * Computes strictly from actual registered tenant accounts.
 */
export async function getFbiPlatformBenchmarks(
  granularity: FbiGranularity = "monthly"
): Promise<FbiPlatformRollup | null> {
  try {
    const period = resolvePeriodDates(granularity);
    const docRef = doc(db, `platform/admin_views/fbi_platform_rollups/${granularity}_${period.key}`);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as FbiPlatformRollup;
    }
  } catch (_) {}

  // Try API
  try {
    const token = await auth.currentUser?.getIdToken();
    const res = await fetch(`/api/fbi/admin-benchmarks?granularity=${granularity}`, {
      headers: {
        ...(token ? { "Authorization": `Bearer ${token}` } : {})
      }
    });
    if (res.ok) {
      const data = await res.json();
      return data.benchmarks;
    }
  } catch (_) {}

  // Fallback: load actual tenants and compute real platform totals
  try {
    const usersSnap = await getDocs(collection(db, "users_data"));
    const tenantCount = usersSnap.size;
    const period = resolvePeriodDates(granularity);

    return {
      id: `benchmarks_${period.key}`,
      period,
      computedAt: new Date().toISOString(),
      totalActiveTenants: tenantCount,
      totalActiveNodes: tenantCount,
      aggregateRevenueZmw: 0,
      aggregateNetProfitZmw: 0,
      benchmarkYields: {},
      benchmarkMargins: { p25: 0, median: 0, p75: 0 },
      benchmarkFcr: {}
    };
  } catch (_) {
    return null;
  }
}

import { Asset, BiologicalAssetTier, LivestockRecord, PoultryBatch, FishBatch } from "../types";
import { Account } from "../data/initialAccounts";

export type { BiologicalAssetTier };

export interface BiologicalChartAccount {
  code: string;
  name: string;
  tier: BiologicalAssetTier;
  assetTypeCategory: "Current" | "Non-Current";
  description: string;
}

export const BIOLOGICAL_CHART_OF_ACCOUNTS: BiologicalChartAccount[] = [
  // Non-Current Biological Assets (GL 1450 - 1490)
  {
    code: "1450",
    name: "Non-Current Biological Assets - Dairy Cattle (Productive Herd)",
    tier: "non_current_biological",
    assetTypeCategory: "Non-Current",
    description: "Milking cows and in-calf dairy heifers held for long-term milk production."
  },
  {
    code: "1460",
    name: "Non-Current Biological Assets - Breeding Herd & Seedstock",
    tier: "non_current_biological",
    assetTypeCategory: "Non-Current",
    description: "Pedigree breeding bulls, cows, and replacement breeding heifers."
  },
  {
    code: "1470",
    name: "Non-Current Biological Assets - Commercial Laying Flocks",
    tier: "non_current_biological",
    assetTypeCategory: "Non-Current",
    description: "Point-of-lay pullets and active commercial egg-producing hens."
  },
  {
    code: "1480",
    name: "Non-Current Biological Assets - Breeding Pigs (Sows & Boars)",
    tier: "non_current_biological",
    assetTypeCategory: "Non-Current",
    description: "Productive breeding sows and service boars held for piglet production."
  },
  {
    code: "1490",
    name: "Non-Current Biological Assets - Breeding Small Ruminants (Goats & Sheep)",
    tier: "non_current_biological",
    assetTypeCategory: "Non-Current",
    description: "Breeding does, ewes, and pedigree bucks/rams."
  },
  // Current Biological Assets (GL 1400 - 1440)
  {
    code: "1400",
    name: "Current Biological Assets - Beef Herd & Growing Stock",
    tier: "current_biological",
    assetTypeCategory: "Current",
    description: "Growing beef cattle, feedlot steers, and stock intended for commercial slaughter."
  },
  {
    code: "1410",
    name: "Current Biological Assets - Growing & Finisher Pigs",
    tier: "current_biological",
    assetTypeCategory: "Current",
    description: "Weaners, growers, and fatteners being raised for pork market sale."
  },
  {
    code: "1420",
    name: "Current Biological Assets - Broiler Poultry Flocks",
    tier: "current_biological",
    assetTypeCategory: "Current",
    description: "Fast-growing broiler batches reared for meat processing."
  },
  {
    code: "1430",
    name: "Current Biological Assets - Fish & Aquaculture Stock",
    tier: "current_biological",
    assetTypeCategory: "Current",
    description: "Tilapia and catfish fingerlings, juveniles, and table-size fish in ponds/cages."
  },
  {
    code: "1440",
    name: "Current Biological Assets - Standing Crops & Biomass",
    tier: "current_biological",
    assetTypeCategory: "Current",
    description: "Pre-harvest field crops, horticultural plantings, and silage pasture."
  },
  // Post-Harvest Agricultural Produce Inventory (GL 1350 - 1390)
  {
    code: "1350",
    name: "Inventory - Raw Chilled Milk (Post-Extraction)",
    tier: "post_harvest_inventory",
    assetTypeCategory: "Current",
    description: "Harvested unpasteurized/pasteurized milk held in bulk chillers."
  },
  {
    code: "1360",
    name: "Inventory - Dressed Poultry & Butchered Meat",
    tier: "post_harvest_inventory",
    assetTypeCategory: "Current",
    description: "Dressed broilers, beef primal cuts, and pork carcasses in cold storage."
  },
  {
    code: "1370",
    name: "Inventory - Harvested Table Eggs",
    tier: "post_harvest_inventory",
    assetTypeCategory: "Current",
    description: "Graded and crated commercial eggs ready for distribution."
  },
  {
    code: "1380",
    name: "Inventory - Harvested Crops & Grains",
    tier: "post_harvest_inventory",
    assetTypeCategory: "Current",
    description: "Bagged maize, soya beans, and horticultural vegetables in warehouse."
  },
  {
    code: "1390",
    name: "Inventory - Harvested Chilled Fish",
    tier: "post_harvest_inventory",
    assetTypeCategory: "Current",
    description: "Gutted, fresh, or frozen fish awaiting market distribution."
  }
];

/**
 * Biological Asset Classification & GL Accounting Integration Service (IAS 41 & IAS 2)
 *
 * Tier 1: Non-Current Biological Assets (Productive/Bearer Stock)
 *   - Breeding & mature productive livestock (dairy cows, breeding bulls, breeding sows, rams)
 *   - Commercial laying hens (egg layers)
 *   - Draft animals (oxen for ploughing, working equines)
 *   - Orchard & perennial bearer trees
 *   - GL Accounts: 1450, 1460, 1470, 1480, 1490
 *
 * Tier 2: Current Biological Assets (Growing/Immature Stock for Sale)
 *   - Broilers (meat birds)
 *   - Growing cattle for beef / feedlot steers
 *   - Weaner pigs & grower fatteners for slaughter
 *   - Growing goats / sheep for meat
 *   - Aquaculture biomass (fingerlings & grow-out table fish)
 *   - Standing harvestable field crops
 *   - GL Accounts: 1400, 1410, 1420, 1430, 1440
 *
 * Tier 3: Post-Harvest / Post-Slaughter Inventory (Agricultural Produce - IAS 2)
 *   - Extracted raw milk in chillers
 *   - Dressed poultry & butchered meat
 *   - Harvested table eggs in crates
 *   - Harvested grain & field crops in silos/storage
 *   - Harvested chilled/frozen fish
 *   - GL Accounts: 1350, 1360, 1370, 1380, 1390
 *
 * Tier 4: Property, Plant & Equipment (PPE - IAS 16)
 *   - Land, Buildings, Tractors, Machinery, Vehicles, Irrigation
 *   - GL Accounts: 1510, 1520, 1530, 1540, 1550, 1560
 */

export interface ClassificationResult {
  tier: BiologicalAssetTier;
  assetTypeCategory: "Current" | "Non-Current";
  glAccountCode: string;
  glAccountName: string;
  label: string;
  description: string;
}

/**
 * Determines biological asset tier, category, and GL code based on biological parameters.
 */
export function determineBiologicalClassification(params: {
  species?: string;
  breed?: string;
  purpose?: string;
  gender?: string;
  category?: string;
  birdType?: string;
  stage?: string;
  ageInMonths?: number;
  breedingStatus?: string;
  isDairy?: boolean;
}): ClassificationResult {
  const speciesLower = (params.species || "").toLowerCase();
  const breedLower = (params.breed || "").toLowerCase();
  const purposeLower = (params.purpose || "").toLowerCase();
  const genderLower = (params.gender || "").toLowerCase();
  const birdTypeLower = (params.birdType || "").toLowerCase();
  const stageLower = (params.stage || "").toLowerCase();
  const catLower = (params.category || "").toLowerCase();
  const breedingLower = (params.breedingStatus || "").toLowerCase();
  const isDairyParam = Boolean(params.isDairy);

  // 1. Post-harvest inventory check
  if (
    purposeLower.includes("milk") ||
    purposeLower.includes("meat") ||
    purposeLower.includes("post-harvest") ||
    purposeLower.includes("slaughter") ||
    catLower.includes("inventory") ||
    catLower.includes("produce")
  ) {
    if (speciesLower.includes("dairy") || speciesLower.includes("cow") || breedLower.includes("holstein") || breedLower.includes("friesian")) {
      return {
        tier: "post_harvest_inventory",
        assetTypeCategory: "Current",
        glAccountCode: "1350",
        glAccountName: "Inventory - Extracted Raw Milk & Dairy",
        label: "Post-Harvest Inventory (Milk & Dairy)",
        description: "Extracted milk and processed dairy products in cold chain storage."
      };
    }
    if (catLower.includes("egg") || purposeLower.includes("egg")) {
      return {
        tier: "post_harvest_inventory",
        assetTypeCategory: "Current",
        glAccountCode: "1370",
        glAccountName: "Inventory - Harvested Table Eggs",
        label: "Post-Harvest Inventory (Table Eggs)",
        description: "Graded and crated table eggs ready for market dispatch."
      };
    }
    return {
      tier: "post_harvest_inventory",
      assetTypeCategory: "Current",
      glAccountCode: "1360",
      glAccountName: "Inventory - Dressed Poultry & Butchered Meat",
      label: "Post-Slaughter Inventory (Meat)",
      description: "Processed, dressed, and packaged meat inventory in cold store."
    };
  }

  // 2. Laying Hens (Poultry Layers) -> Non-Current Biological
  if (
    birdTypeLower.includes("layer") ||
    purposeLower.includes("layer") ||
    purposeLower.includes("egg") ||
    breedLower.includes("lohmann") ||
    breedLower.includes("hy-line") ||
    breedLower.includes("isa brown") ||
    stageLower.includes("laying")
  ) {
    return {
      tier: "non_current_biological",
      assetTypeCategory: "Non-Current",
      glAccountCode: "1470",
      glAccountName: "Non-Current Biological Assets - Commercial Laying Flocks",
      label: "Non-Current Biological Asset (Laying Flock)",
      description: "Productive egg-laying hens maintained over multiple cycles (IAS 41 Bearer Biological Stock)."
    };
  }

  // 3. Broilers (Meat Birds) -> Current Biological
  if (
    birdTypeLower.includes("broiler") ||
    purposeLower.includes("broiler") ||
    purposeLower.includes("meat") ||
    breedLower.includes("ross 308") ||
    breedLower.includes("cobb 500") ||
    catLower === "poultry" && !birdTypeLower.includes("layer")
  ) {
    return {
      tier: "current_biological",
      assetTypeCategory: "Current",
      glAccountCode: "1420",
      glAccountName: "Current Biological Assets - Broiler Poultry Flocks",
      label: "Current Biological Asset (Broiler Meat Flock)",
      description: "Fast-growing immature poultry batches reared for commercial meat slaughter (IAS 41 Current Stock)."
    };
  }

  // 4. Draft & Working Animals (Oxen, Ploughing Workhorses) -> Non-Current Biological
  if (
    purposeLower.includes("draft") ||
    purposeLower.includes("draught") ||
    purposeLower.includes("plough") ||
    purposeLower.includes("plow") ||
    purposeLower.includes("work") ||
    breedLower.includes("oxen")
  ) {
    return {
      tier: "non_current_biological",
      assetTypeCategory: "Non-Current",
      glAccountCode: "1480",
      glAccountName: "Non-Current Biological Assets - Draft & Working Animals",
      label: "Non-Current Biological Asset (Draft / Working Animal)",
      description: "Working draft oxen and farm animals utilized for land preparation and hauling (IAS 41 Working Stock)."
    };
  }

  // 5. Mature Dairy Herd (Dairy cows & milking heifers) -> Non-Current Biological
  if (
    isDairyParam ||
    purposeLower.includes("dairy") ||
    purposeLower.includes("milk") ||
    breedLower.includes("friesian") ||
    breedLower.includes("jersey") ||
    breedLower.includes("holstein") ||
    breedLower.includes("ayrshire") ||
    stageLower.includes("lactat") ||
    stageLower.includes("milking") ||
    breedingLower.includes("lactat")
  ) {
    return {
      tier: "non_current_biological",
      assetTypeCategory: "Non-Current",
      glAccountCode: "1450",
      glAccountName: "Non-Current Biological Assets - Mature Dairy Herd",
      label: "Non-Current Biological Asset (Mature Dairy Herd)",
      description: "Productive mature milk-producing dairy cows and heifers (IAS 41 Bearer Biological Assets)."
    };
  }

  // 6. Breeding Livestock (Breeding bulls, breeding sows, rams, stud stock) -> Non-Current Biological
  if (
    purposeLower.includes("breed") ||
    purposeLower.includes("stud") ||
    purposeLower.includes("sow") ||
    purposeLower.includes("boar") ||
    purposeLower.includes("bull") ||
    purposeLower.includes("ram") ||
    (genderLower === "female" && (stageLower.includes("mature") || stageLower.includes("breeder"))) ||
    genderLower === "male" && (purposeLower.includes("sire") || breedLower.includes("stud"))
  ) {
    return {
      tier: "non_current_biological",
      assetTypeCategory: "Non-Current",
      glAccountCode: "1460",
      glAccountName: "Non-Current Biological Assets - Breeding Stock (Bulls/Sows)",
      label: "Non-Current Biological Asset (Breeding Stock)",
      description: "Foundation breeding herd retained for progeny generation (IAS 41 Bearer Biological Stock)."
    };
  }

  // 7. Aquaculture Biomass -> Current Biological
  if (
    speciesLower.includes("fish") ||
    speciesLower.includes("tilapia") ||
    speciesLower.includes("catfish") ||
    catLower.includes("aqua") ||
    catLower.includes("fish")
  ) {
    return {
      tier: "current_biological",
      assetTypeCategory: "Current",
      glAccountCode: "1430",
      glAccountName: "Current Biological Assets - Aqua Biomass",
      label: "Current Biological Asset (Aquaculture Biomass)",
      description: "Growing fish biomass stocked in cages, ponds, or RAS tanks for harvest (IAS 41 Current Stock)."
    };
  }

  // 8. Standing Field Crops -> Current Biological
  if (
    catLower.includes("crop") ||
    speciesLower.includes("maize") ||
    speciesLower.includes("soya") ||
    speciesLower.includes("wheat") ||
    speciesLower.includes("vegetable")
  ) {
    return {
      tier: "current_biological",
      assetTypeCategory: "Current",
      glAccountCode: "1410",
      glAccountName: "Current Biological Assets - Standing Harvestable Crops",
      label: "Current Biological Asset (Standing Crops)",
      description: "Growing field crops and horticulture pending seasonal harvest (IAS 41 Current Stock)."
    };
  }

  // 9. Growing meat stock / weaners / feedlot cattle / fatteners -> Current Biological
  if (
    purposeLower.includes("fatten") ||
    purposeLower.includes("weaner") ||
    purposeLower.includes("steer") ||
    purposeLower.includes("beef") ||
    purposeLower.includes("grower") ||
    purposeLower.includes("porker") ||
    stageLower.includes("wean") ||
    stageLower.includes("grower") ||
    stageLower.includes("fatten")
  ) {
    return {
      tier: "current_biological",
      assetTypeCategory: "Current",
      glAccountCode: "1400",
      glAccountName: "Current Biological Assets - Growing Livestock for Market",
      label: "Current Biological Asset (Growing Stock for Market)",
      description: "Immature growing livestock and feeder animals destined for market sale or slaughter."
    };
  }

  // Default for livestock: if gender is male/castrated or young -> Current, else if female mature -> Non-current
  if (genderLower === "female") {
    return {
      tier: "non_current_biological",
      assetTypeCategory: "Non-Current",
      glAccountCode: "1460",
      glAccountName: "Non-Current Biological Assets - Breeding Stock (Bulls/Sows)",
      label: "Non-Current Biological Asset (Breeding Stock)",
      description: "Productive female livestock retained for breeding or dairy production."
    };
  }

  // General fallback for young/growing livestock
  return {
    tier: "current_biological",
    assetTypeCategory: "Current",
    glAccountCode: "1400",
    glAccountName: "Current Biological Assets - Growing Livestock for Market",
    label: "Current Biological Asset (Growing Stock for Market)",
    description: "Growing biological asset for slaughter or commercial sale."
  };
}

/**
 * Synchronizes a livestock record into the Asset Register and updates the GL accounts.
 * Atomically updates both registers to maintain IAS 41 consistency.
 */
export function syncRegisterBiologicalLivestock(
  livestock: LivestockRecord,
  currentAssets: Asset[],
  currentAccounts: Account[]
): { updatedAssets: Asset[]; updatedAccounts: Account[]; newAsset: Asset } {
  const classification = determineBiologicalClassification({
    species: livestock.species || livestock.type,
    breed: livestock.breed,
    purpose: livestock.category || (livestock as any).purpose,
    gender: livestock.gender,
    stage: livestock.status
  });

  const assetVal = Number(livestock.currentValue || livestock.purchasePrice || livestock.estimatedValue || 0);
  const assetId = livestock.assetRegisterId || `asset-live-${livestock.id}`;

  const existingIdx = currentAssets.findIndex((a) => a.id === assetId || a.biologicalDetails?.tagId === livestock.tagId);

  const newAsset: Asset = {
    id: assetId,
    name: `${livestock.species || livestock.type || "Livestock"} - ${livestock.tagId || livestock.name || "Tag #" + livestock.id.slice(0, 6)}`,
    category: "Livestock",
    assetClassification: livestock.assetClassification || classification.tier,
    assetTypeCategory: livestock.assetTypeCategory || classification.assetTypeCategory,
    glAccountCode: livestock.glAccountCode || classification.glAccountCode,
    biologicalDetails: {
      species: livestock.species || livestock.type,
      breed: livestock.breed,
      tagId: livestock.tagId,
      headcount: 1,
      purpose: livestock.category,
      productionStage: livestock.status,
      sourceModule: "livestock"
    },
    serial: livestock.tagId || livestock.rfid,
    purchaseDate: livestock.dateAcquired || livestock.registrationDate || new Date().toISOString().split("T")[0],
    purchasePrice: Number(livestock.purchasePrice || assetVal),
    currentValue: assetVal,
    currentBookValue: assetVal,
    salvageValue: 0,
    depreciationRate: 0, // Biological assets are evaluated at Fair Value under IAS 41, not depreciated
    usefulLifeYears: 10,
    depreciationMethod: "Straight-Line",
    location: livestock.location || "Main Farm",
    supplierId: livestock.source || "Farm Bred",
    condition: "Good",
    notes: `Registered via Livestock Module. Acquisition: ${livestock.acquisitionType || "Standard"}. Tag: ${livestock.tagId}.`,
    farmId: livestock.farmId || "default"
  };

  let updatedAssets: Asset[];
  let deltaValue = assetVal;

  if (existingIdx >= 0) {
    const oldVal = currentAssets[existingIdx].currentValue || 0;
    deltaValue = assetVal - oldVal;
    updatedAssets = [...currentAssets];
    updatedAssets[existingIdx] = {
      ...currentAssets[existingIdx],
      ...newAsset,
      id: currentAssets[existingIdx].id
    };
  } else {
    updatedAssets = [newAsset, ...currentAssets];
  }

  // Update GL Account: Debit Biological Asset Account, Credit Bank or Capital/Fair Value Gain
  const targetGlCode = newAsset.glAccountCode || classification.glAccountCode;
  const isBirthed = (livestock.acquisitionType || "").toLowerCase() === "birthed" || (livestock.source || "").toLowerCase().includes("farm");

  const updatedAccounts = currentAccounts.map((acc) => {
    if (acc.code === targetGlCode) {
      return { ...acc, balance: Number((acc.balance + deltaValue).toFixed(2)) };
    }
    // Credit matching account for the initial purchase or fair value gain
    if (deltaValue > 0) {
      if (isBirthed && acc.code === "4700") {
        return { ...acc, balance: Number((acc.balance + deltaValue).toFixed(2)) };
      }
      if (!isBirthed && acc.code === "1010") {
        return { ...acc, balance: Number((acc.balance - deltaValue).toFixed(2)) };
      }
    }
    return acc;
  });

  return { updatedAssets, updatedAccounts, newAsset };
}

/**
 * Synchronizes a poultry batch into the Asset Register and updates the GL accounts.
 */
export function syncRegisterBiologicalPoultry(
  batch: PoultryBatch,
  currentAssets: Asset[],
  currentAccounts: Account[]
): { updatedAssets: Asset[]; updatedAccounts: Account[]; newAsset: Asset } {
  const classification = determineBiologicalClassification({
    birdType: batch.birdType,
    breed: batch.breed,
    purpose: batch.birdType?.includes("Layer") ? "Layers" : "Broilers",
    stage: batch.status
  });

  const headcount = Number(batch.currentCount ?? (batch as any).currentHeadcount ?? batch.quantity ?? 0);
  const unitPrice = Number(batch.currentMarketPricePerBird || (batch as any).unitAcquisitionCost || 85);
  const totalVal = Number(batch.currentBatchValuation || (headcount * unitPrice));
  const assetId = batch.assetRegisterId || `asset-poultry-${batch.id}`;

  const existingIdx = currentAssets.findIndex((a) => a.id === assetId || a.biologicalDetails?.batchId === batch.batchId);

  const newAsset: Asset = {
    id: assetId,
    name: `${batch.batchName || batch.batchId || "Poultry Batch"} (${batch.birdType || "Flock"})`,
    category: "Poultry",
    assetClassification: batch.assetClassification || classification.tier,
    assetTypeCategory: batch.assetTypeCategory || classification.assetTypeCategory,
    glAccountCode: batch.glAccountCode || classification.glAccountCode,
    biologicalDetails: {
      species: "Poultry",
      breed: batch.breed,
      batchId: batch.batchId,
      headcount,
      purpose: batch.birdType,
      productionStage: batch.status,
      sourceModule: "poultry"
    },
    serial: batch.batchId,
    purchaseDate: batch.arrivalDate || (batch as any).dateAcquired || new Date().toISOString().split("T")[0],
    purchasePrice: Number((batch as any).acquisitionCostTotal || (batch.quantity * unitPrice) || totalVal),
    currentValue: totalVal,
    currentBookValue: totalVal,
    salvageValue: 0,
    depreciationRate: 0,
    usefulLifeYears: classification.tier === "non_current_biological" ? 2 : 1,
    depreciationMethod: "Straight-Line",
    location: batch.assignedShed || "Poultry Shed 1",
    supplierId: batch.sourceSupplier || (batch as any).source || "Hatchery",
    condition: "Good",
    notes: `Poultry Batch ${batch.batchId}. Initial Count: ${batch.quantity}. Current Count: ${headcount}.`,
    farmId: batch.farmId || "default"
  };

  let updatedAssets: Asset[];
  let deltaValue = totalVal;

  if (existingIdx >= 0) {
    const oldVal = currentAssets[existingIdx].currentValue || 0;
    deltaValue = totalVal - oldVal;
    updatedAssets = [...currentAssets];
    updatedAssets[existingIdx] = {
      ...currentAssets[existingIdx],
      ...newAsset,
      id: currentAssets[existingIdx].id
    };
  } else {
    updatedAssets = [newAsset, ...currentAssets];
  }

  const targetGlCode = newAsset.glAccountCode || classification.glAccountCode;

  const updatedAccounts = currentAccounts.map((acc) => {
    if (acc.code === targetGlCode) {
      return { ...acc, balance: Number((acc.balance + deltaValue).toFixed(2)) };
    }
    return acc;
  });

  return { updatedAssets, updatedAccounts, newAsset };
}

/**
 * Synchronizes an aquaculture batch into the Asset Register and updates GL accounts.
 */
export function syncRegisterBiologicalFish(
  fish: FishBatch,
  currentAssets: Asset[],
  currentAccounts: Account[]
): { updatedAssets: Asset[]; updatedAccounts: Account[]; newAsset: Asset } {
  const classification = determineBiologicalClassification({
    species: fish.species,
    breed: fish.strain,
    purpose: "Aquaculture Biomass",
    category: "Aquaculture"
  });

  const count = Number(fish.currentFishCount || fish.stockingQuantity || 0);
  const avgWeightKg = Number(fish.averageWeightStockingG || 150) / 1000;
  const estimatedBiomassKg = count * avgWeightKg;
  const pricePerKg = 45; // Standard ZMW per kg biomass
  const totalVal = Math.round(estimatedBiomassKg * pricePerKg);
  const assetId = fish.assetRegisterId || `asset-fish-${fish.id}`;

  const existingIdx = currentAssets.findIndex((a) => a.id === assetId || a.biologicalDetails?.batchId === fish.batchId);

  const newAsset: Asset = {
    id: assetId,
    name: `${fish.species || "Fish"} (${fish.batchId || "Aqua Batch"})`,
    category: "Aquaculture",
    assetClassification: fish.assetClassification || classification.tier,
    assetTypeCategory: fish.assetTypeCategory || classification.assetTypeCategory,
    glAccountCode: fish.glAccountCode || classification.glAccountCode,
    biologicalDetails: {
      species: fish.species,
      breed: fish.strain,
      batchId: fish.batchId,
      headcount: count,
      purpose: "Grow-out Biomass",
      productionStage: fish.status,
      sourceModule: "fish"
    },
    serial: fish.batchId,
    purchaseDate: new Date().toISOString().split("T")[0],
    purchasePrice: totalVal,
    currentValue: totalVal,
    currentBookValue: totalVal,
    salvageValue: 0,
    depreciationRate: 0,
    usefulLifeYears: 1,
    depreciationMethod: "Straight-Line",
    location: fish.pondName || "Pond 1",
    supplierId: "Hatchery",
    condition: "Good",
    notes: `Aquaculture batch ${fish.batchId}. Fish count: ${count}. Biomass: ${estimatedBiomassKg.toFixed(1)} kg.`,
    farmId: fish.farmId || "default"
  };

  let updatedAssets: Asset[];
  let deltaValue = totalVal;

  if (existingIdx >= 0) {
    const oldVal = currentAssets[existingIdx].currentValue || 0;
    deltaValue = totalVal - oldVal;
    updatedAssets = [...currentAssets];
    updatedAssets[existingIdx] = {
      ...currentAssets[existingIdx],
      ...newAsset,
      id: currentAssets[existingIdx].id
    };
  } else {
    updatedAssets = [newAsset, ...currentAssets];
  }

  const targetGlCode = newAsset.glAccountCode || classification.glAccountCode;

  const updatedAccounts = currentAccounts.map((acc) => {
    if (acc.code === targetGlCode) {
      return { ...acc, balance: Number((acc.balance + deltaValue).toFixed(2)) };
    }
    return acc;
  });

  return { updatedAssets, updatedAccounts, newAsset };
}

/**
 * Handles Biological Asset Mortality (IAS 41 Write-Down / Loss).
 * - Reduces asset value in Asset Register (or marks disposed if 100% loss)
 * - Automatically writes down GL asset account
 * - Debits Mortality Loss Expense (5900/5901/5902/5903) in a single atomic transaction
 */
export function recordBiologicalMortality(params: {
  assetId?: string;
  tagId?: string;
  batchId?: string;
  lossHeadcount: number;
  totalHeadcountBefore: number;
  lossValue?: number;
  cause: string;
  date: string;
  currentAssets: Asset[];
  currentAccounts: Account[];
  moduleType: "livestock" | "poultry" | "fish";
}): {
  updatedAssets: Asset[];
  updatedAccounts: Account[];
  lossAmount: number;
  updatedAsset: Asset | null;
} {
  const {
    assetId,
    tagId,
    batchId,
    lossHeadcount,
    totalHeadcountBefore,
    cause,
    date,
    currentAssets,
    currentAccounts,
    moduleType
  } = params;

  // Find the asset
  const targetIdx = currentAssets.findIndex(
    (a) =>
      (assetId && a.id === assetId) ||
      (tagId && a.biologicalDetails?.tagId === tagId) ||
      (batchId && a.biologicalDetails?.batchId === batchId)
  );

  let lossAmount = params.lossValue || 0;
  let targetGlAccount = "1400";
  let expenseGlAccount = "5900";

  if (moduleType === "poultry") {
    expenseGlAccount = "5901"; // Poultry Mortality Loss
    targetGlAccount = "1420";
  } else if (moduleType === "livestock") {
    expenseGlAccount = "5902"; // Livestock Mortality Loss
    targetGlAccount = "1400";
  } else if (moduleType === "fish") {
    expenseGlAccount = "5903"; // Aquaculture Mortality Loss
    targetGlAccount = "1430";
  }

  let updatedAssets = [...currentAssets];
  let updatedAsset: Asset | null = null;

  if (targetIdx >= 0) {
    const existing = currentAssets[targetIdx];
    targetGlAccount = existing.glAccountCode || targetGlAccount;

    const currentVal = existing.currentValue || 0;
    const currentCount = existing.biologicalDetails?.headcount || totalHeadcountBefore || 1;

    // Calculate loss amount proportionally if not explicitly supplied
    if (!lossAmount) {
      if (currentCount > 0) {
        lossAmount = Math.round((currentVal / currentCount) * lossHeadcount);
      } else {
        lossAmount = currentVal;
      }
    }

    lossAmount = Math.min(lossAmount, currentVal); // cannot lose more than book value
    const newVal = Math.max(0, currentVal - lossAmount);
    const newCount = Math.max(0, currentCount - lossHeadcount);
    const isFullyDepleted = newCount === 0 || newVal === 0;

    updatedAsset = {
      ...existing,
      currentValue: newVal,
      currentBookValue: newVal,
      isDisposed: isFullyDepleted,
      disposalRecord: isFullyDepleted
        ? {
            disposalDate: date,
            disposalType: "Written Off",
            proceeds: 0,
            bookValueAtDisposal: currentVal,
            gainLoss: -lossAmount,
            purchaserOrReason: `Mortality: ${cause}`,
            journalEntryRef: `GL-${expenseGlAccount}-${targetGlAccount}`
          }
        : existing.disposalRecord,
      biologicalDetails: {
        ...existing.biologicalDetails,
        headcount: newCount
      },
      notes: `${existing.notes || ""}\n[Mortality Event ${date}]: -${lossHeadcount} head (Loss: ZMW ${lossAmount.toLocaleString()}). Cause: ${cause}.`
    };

    updatedAssets[targetIdx] = updatedAsset;
  }

  // Update GL Accounts: Debit Mortality Loss Expense, Credit Biological Asset
  const updatedAccounts = currentAccounts.map((acc) => {
    if (acc.code === expenseGlAccount) {
      return { ...acc, balance: Number((acc.balance + lossAmount).toFixed(2)) };
    }
    if (acc.code === targetGlAccount) {
      return { ...acc, balance: Number((acc.balance - lossAmount).toFixed(2)) };
    }
    return acc;
  });

  return {
    updatedAssets,
    updatedAccounts,
    lossAmount,
    updatedAsset
  };
}

/**
 * Handles Biological Asset Sale.
 * - Records sale/disposal in Asset Register
 * - Updates GL: Cash/Bank Dr, Revenue Cr, COGS Dr, Biological Asset Cr
 */
export function recordBiologicalSale(params: {
  assetId?: string;
  tagId?: string;
  batchId?: string;
  soldHeadcount: number;
  saleAmount: number;
  buyerName?: string;
  paymentMethod?: string;
  date: string;
  currentAssets: Asset[];
  currentAccounts: Account[];
  moduleType: "livestock" | "poultry" | "fish";
}): {
  updatedAssets: Asset[];
  updatedAccounts: Account[];
  revenueGlCode: string;
  updatedAsset: Asset | null;
} {
  const {
    assetId,
    tagId,
    batchId,
    soldHeadcount,
    saleAmount,
    buyerName,
    paymentMethod,
    date,
    currentAssets,
    currentAccounts,
    moduleType
  } = params;

  const targetIdx = currentAssets.findIndex(
    (a) =>
      (assetId && a.id === assetId) ||
      (tagId && a.biologicalDetails?.tagId === tagId) ||
      (batchId && a.biologicalDetails?.batchId === batchId)
  );

  let targetGlAccount = "1400";
  let revenueGlCode = "4300"; // Livestock sales revenue

  if (moduleType === "poultry") {
    revenueGlCode = "4200";
    targetGlAccount = "1420";
  } else if (moduleType === "fish") {
    revenueGlCode = "4100";
    targetGlAccount = "1430";
  }

  let updatedAssets = [...currentAssets];
  let updatedAsset: Asset | null = null;
  let assetCostRemoved = 0;

  if (targetIdx >= 0) {
    const existing = currentAssets[targetIdx];
    targetGlAccount = existing.glAccountCode || targetGlAccount;

    const currentVal = existing.currentValue || 0;
    const currentCount = existing.biologicalDetails?.headcount || 1;

    assetCostRemoved = currentCount > 0 ? Math.round((currentVal / currentCount) * soldHeadcount) : currentVal;
    assetCostRemoved = Math.min(assetCostRemoved, currentVal);

    const newVal = Math.max(0, currentVal - assetCostRemoved);
    const newCount = Math.max(0, currentCount - soldHeadcount);
    const isFullySold = newCount === 0 || newVal === 0;

    updatedAsset = {
      ...existing,
      currentValue: newVal,
      currentBookValue: newVal,
      isDisposed: isFullySold,
      disposalRecord: isFullySold
        ? {
            disposalDate: date,
            disposalType: "Sale",
            proceeds: saleAmount,
            bookValueAtDisposal: currentVal,
            gainLoss: saleAmount - assetCostRemoved,
            purchaserOrReason: `Sold to: ${buyerName || "Customer"}. Payment: ${paymentMethod || "Cash"}`,
            journalEntryRef: `GL-1010-${revenueGlCode}`
          }
        : existing.disposalRecord,
      biologicalDetails: {
        ...existing.biologicalDetails,
        headcount: newCount
      },
      notes: `${existing.notes || ""}\n[Sale Event ${date}]: -${soldHeadcount} head for ZMW ${saleAmount.toLocaleString()} to ${buyerName || "Customer"}.`
    };

    updatedAssets[targetIdx] = updatedAsset;
  }

  // Double-Entry GL Posting:
  // 1. Debit Cash/Bank (1010) with sales proceeds, Credit Revenue
  // 2. Debit COGS (5212), Credit Biological Asset with cost removed
  const updatedAccounts = currentAccounts.map((acc) => {
    if (acc.code === "1010") {
      return { ...acc, balance: Number((acc.balance + saleAmount).toFixed(2)) };
    }
    if (acc.code === revenueGlCode) {
      return { ...acc, balance: Number((acc.balance + saleAmount).toFixed(2)) };
    }
    if (acc.code === "5212") {
      return { ...acc, balance: Number((acc.balance + assetCostRemoved).toFixed(2)) };
    }
    if (acc.code === targetGlAccount) {
      return { ...acc, balance: Number((acc.balance - assetCostRemoved).toFixed(2)) };
    }
    return acc;
  });

  return {
    updatedAssets,
    updatedAccounts,
    revenueGlCode,
    updatedAsset
  };
}

/**
 * Handles Biological Asset Gift / Donation.
 * - Disposes/reduces asset in Asset Register with reason "Gift / Donation"
 * - Updates GL: Debit 5905 (Disposal/Gift Expense), Credit Biological Asset
 */
export function recordBiologicalGift(params: {
  assetId?: string;
  tagId?: string;
  batchId?: string;
  giftHeadcount: number;
  recipient: string;
  date: string;
  currentAssets: Asset[];
  currentAccounts: Account[];
  moduleType: "livestock" | "poultry" | "fish";
}): {
  updatedAssets: Asset[];
  updatedAccounts: Account[];
  giftExpense: number;
  updatedAsset: Asset | null;
} {
  const {
    assetId,
    tagId,
    batchId,
    giftHeadcount,
    recipient,
    date,
    currentAssets,
    currentAccounts,
    moduleType
  } = params;

  const targetIdx = currentAssets.findIndex(
    (a) =>
      (assetId && a.id === assetId) ||
      (tagId && a.biologicalDetails?.tagId === tagId) ||
      (batchId && a.biologicalDetails?.batchId === batchId)
  );

  let targetGlAccount = "1400";
  if (moduleType === "poultry") targetGlAccount = "1420";
  if (moduleType === "fish") targetGlAccount = "1430";

  let updatedAssets = [...currentAssets];
  let updatedAsset: Asset | null = null;
  let giftExpense = 0;

  if (targetIdx >= 0) {
    const existing = currentAssets[targetIdx];
    targetGlAccount = existing.glAccountCode || targetGlAccount;

    const currentVal = existing.currentValue || 0;
    const currentCount = existing.biologicalDetails?.headcount || 1;

    giftExpense = currentCount > 0 ? Math.round((currentVal / currentCount) * giftHeadcount) : currentVal;
    giftExpense = Math.min(giftExpense, currentVal);

    const newVal = Math.max(0, currentVal - giftExpense);
    const newCount = Math.max(0, currentCount - giftHeadcount);
    const isFullyDisposed = newCount === 0 || newVal === 0;

    updatedAsset = {
      ...existing,
      currentValue: newVal,
      currentBookValue: newVal,
      isDisposed: isFullyDisposed,
      disposalRecord: isFullyDisposed
        ? {
            disposalDate: date,
            disposalType: "Written Off",
            proceeds: 0,
            bookValueAtDisposal: currentVal,
            gainLoss: -giftExpense,
            purchaserOrReason: `Donation/Gift to: ${recipient}`,
            journalEntryRef: `GL-5905-${targetGlAccount}`
          }
        : existing.disposalRecord,
      biologicalDetails: {
        ...existing.biologicalDetails,
        headcount: newCount
      },
      notes: `${existing.notes || ""}\n[Gift/Donation ${date}]: -${giftHeadcount} head gifted to ${recipient} (Cost: ZMW ${giftExpense.toLocaleString()}).`
    };

    updatedAssets[targetIdx] = updatedAsset;
  }

  // Update GL: Debit 5905 (Biological Asset Disposal & Gift Expense), Credit Biological Asset
  const updatedAccounts = currentAccounts.map((acc) => {
    if (acc.code === "5905") {
      return { ...acc, balance: Number((acc.balance + giftExpense).toFixed(2)) };
    }
    if (acc.code === targetGlAccount) {
      return { ...acc, balance: Number((acc.balance - giftExpense).toFixed(2)) };
    }
    return acc;
  });

  return {
    updatedAssets,
    updatedAccounts,
    giftExpense,
    updatedAsset
  };
}

/**
 * Handles Biological Transformation & Fair-Value Revaluation (IAS 41).
 * Biological assets do not follow traditional PPE depreciation; value changes come from biological transformation (growth, breeding, fattening).
 * - Updates asset book value in Asset Register
 * - Updates GL:
 *   - Fair-value Gain: Debit Biological Asset GL, Credit 4410 (IAS 41 Fair Value Gain on Biological Transformation)
 *   - Fair-value Loss: Debit 5905 (IAS 41 Fair Value Loss on Biological Assets), Credit Biological Asset GL
 */
export function recordBiologicalTransformation(params: {
  assetId?: string;
  tagId?: string;
  batchId?: string;
  newValue: number;
  newWeight?: number;
  reason: string;
  date: string;
  currentAssets: Asset[];
  currentAccounts: Account[];
  moduleType?: "livestock" | "poultry" | "fish";
}): {
  updatedAssets: Asset[];
  updatedAccounts: Account[];
  deltaValue: number;
  updatedAsset: Asset | null;
} {
  const {
    assetId,
    tagId,
    batchId,
    newValue,
    newWeight,
    reason,
    date,
    currentAssets,
    currentAccounts,
    moduleType = "livestock"
  } = params;

  const targetIdx = currentAssets.findIndex(
    (a) =>
      (assetId && a.id === assetId) ||
      (tagId && a.biologicalDetails?.tagId === tagId) ||
      (batchId && a.biologicalDetails?.batchId === batchId)
  );

  let targetGlAccount = "1400";
  if (moduleType === "poultry") targetGlAccount = "1420";
  else if (moduleType === "fish") targetGlAccount = "1430";

  let updatedAssets = [...currentAssets];
  let updatedAsset: Asset | null = null;
  let deltaValue = 0;

  if (targetIdx >= 0) {
    const existing = currentAssets[targetIdx];
    targetGlAccount = existing.glAccountCode || targetGlAccount;
    const oldVal = existing.currentValue || 0;
    deltaValue = newValue - oldVal;

    updatedAsset = {
      ...existing,
      currentValue: newValue,
      currentBookValue: newValue,
      biologicalDetails: {
        ...existing.biologicalDetails,
        weightKg: newWeight !== undefined ? newWeight : existing.biologicalDetails?.weightKg
      },
      notes: `${existing.notes || ""}\n[Biological Transformation ${date}]: Revalued to ZMW ${newValue.toLocaleString()} (Delta: ${deltaValue >= 0 ? "+" : ""}ZMW ${deltaValue.toLocaleString()}). Reason: ${reason}.`
    };

    updatedAssets[targetIdx] = updatedAsset;
  }

  // Double-Entry GL Posting:
  // If deltaValue > 0 (Gain):
  //   Debit Biological Asset GL (targetGlAccount) +deltaValue
  //   Credit Account 4410 (IAS 41 Fair Value Gain on Biological Transformation) +deltaValue
  // If deltaValue < 0 (Loss):
  //   Debit Account 5905 (IAS 41 Fair Value Loss on Biological Transformation) +abs(deltaValue)
  //   Credit Biological Asset GL (targetGlAccount) -abs(deltaValue)
  const absDelta = Math.abs(deltaValue);
  const updatedAccounts = currentAccounts.map((acc) => {
    let balance = acc.balance;
    if (acc.code === targetGlAccount) {
      balance = Number((balance + deltaValue).toFixed(2));
    }
    if (deltaValue > 0) {
      if (acc.code === "4410" || (acc.code === "4400" && !currentAccounts.some(a => a.code === "4410"))) {
        balance = Number((balance + deltaValue).toFixed(2));
      }
    } else if (deltaValue < 0) {
      if (acc.code === "5905" || (acc.code === "5900" && !currentAccounts.some(a => a.code === "5905"))) {
        balance = Number((balance + absDelta).toFixed(2));
      }
    }
    return { ...acc, balance };
  });

  return {
    updatedAssets,
    updatedAccounts,
    deltaValue,
    updatedAsset
  };
}

/**
 * Alias for recordBiologicalMortality / write-off derecognition.
 */
export const derecognizeBiologicalAsset = recordBiologicalMortality;

/**
 * Reconciles the Asset Register with all registered livestock, poultry, and fish data,
 * and ensures that the Chart of Accounts biological asset totals match the active register.
 */
export function reconcileAllBiologicalAssets(params: {
  assets: Asset[];
  livestock: LivestockRecord[];
  poultry: PoultryBatch[];
  fish: FishBatch[];
  accounts: Account[];
}): {
  reconciledAssets: Asset[];
  reconciledAccounts: Account[];
  metrics: {
    totalAssetValue: number;
    currentBiologicalValue: number;
    nonCurrentBiologicalValue: number;
    inventoryValue: number;
    ppeValue: number;
    biologicalHeadcount: number;
  };
} {
  const { assets, livestock, poultry, fish, accounts } = params;

  let reconciledAssets = [...assets];

  // 1. Reconcile Livestock
  livestock.forEach((item) => {
    if (item.status === "Active" || item.status === "Active > Lactating" || item.status === "Active > Dry") {
      const exists = reconciledAssets.some(
        (a) => a.id === item.assetRegisterId || a.biologicalDetails?.tagId === item.tagId
      );
      if (!exists) {
        const syncRes = syncRegisterBiologicalLivestock(item, reconciledAssets, accounts);
        reconciledAssets = syncRes.updatedAssets;
      }
    }
  });

  // 2. Reconcile Poultry
  poultry.forEach((item) => {
    const isLive = item.status?.toLowerCase().includes("active") || item.status?.toLowerCase().includes("planned");
    if (isLive) {
      const exists = reconciledAssets.some(
        (a) => a.id === item.assetRegisterId || a.biologicalDetails?.batchId === item.batchId
      );
      if (!exists) {
        const syncRes = syncRegisterBiologicalPoultry(item, reconciledAssets, accounts);
        reconciledAssets = syncRes.updatedAssets;
      }
    }
  });

  // 3. Reconcile Fish
  fish.forEach((item) => {
    const isLive = item.status !== "Closed" && item.status !== "Harvested";
    if (isLive) {
      const exists = reconciledAssets.some(
        (a) => a.id === item.assetRegisterId || a.biologicalDetails?.batchId === item.batchId
      );
      if (!exists) {
        const syncRes = syncRegisterBiologicalFish(item, reconciledAssets, accounts);
        reconciledAssets = syncRes.updatedAssets;
      }
    }
  });

  // 4. Compute metrics and sync Chart of Accounts biological balances
  const glBalances: Record<string, number> = {};

  let currentBioTotal = 0;
  let nonCurrentBioTotal = 0;
  let inventoryTotal = 0;
  let ppeTotal = 0;
  let bioHeadcount = 0;

  reconciledAssets.forEach((a) => {
    if (a.isDisposed) return;
    const val = Number(a.currentValue || a.purchasePrice || 0);
    const code = a.glAccountCode || (a.assetClassification === "non_current_biological" ? "1450" : "1400");

    glBalances[code] = (glBalances[code] || 0) + val;

    if (a.assetClassification === "non_current_biological") {
      nonCurrentBioTotal += val;
      bioHeadcount += a.biologicalDetails?.headcount || 1;
    } else if (a.assetClassification === "current_biological") {
      currentBioTotal += val;
      bioHeadcount += a.biologicalDetails?.headcount || 1;
    } else if (a.assetClassification === "post_harvest_inventory") {
      inventoryTotal += val;
    } else {
      ppeTotal += val;
    }
  });

  // Update biological accounts to match reconciled register
  const reconciledAccounts = accounts.map((acc) => {
    // If account is one of the biological asset GL codes, reflect register balance
    if (["1400", "1410", "1420", "1430", "1440", "1450", "1460", "1470", "1480", "1490"].includes(acc.code)) {
      const targetBal = glBalances[acc.code] !== undefined ? glBalances[acc.code] : acc.balance;
      return { ...acc, balance: Number(targetBal.toFixed(2)) };
    }
    return acc;
  });

  return {
    reconciledAssets,
    reconciledAccounts,
    metrics: {
      totalAssetValue: currentBioTotal + nonCurrentBioTotal + inventoryTotal + ppeTotal,
      currentBiologicalValue: currentBioTotal,
      nonCurrentBiologicalValue: nonCurrentBioTotal,
      inventoryValue: inventoryTotal,
      ppeValue: ppeTotal,
      biologicalHeadcount: bioHeadcount
    }
  };
}

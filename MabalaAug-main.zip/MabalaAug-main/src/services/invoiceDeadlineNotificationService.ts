import { db } from "../firebase";
import { collection, doc, setDoc, getDocs, updateDoc, query, where } from "firebase/firestore";
import { PlatformInvoice, fetchPlatformInvoices } from "./platformInvoiceService";
import { generateDirectPayLink } from "./invoiceReminderService";

export type DeadlineUrgency =
  | "DUE_TODAY"
  | "DUE_TOMORROW"
  | "DUE_IN_3_DAYS"
  | "DUE_IN_7_DAYS"
  | "OVERDUE"
  | "NOT_APPROACHING";

export interface DeadlineUrgencyInfo {
  daysUntilDeadline: number;
  urgency: DeadlineUrgency;
  isApproaching: boolean;
  urgencyLabel: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  actionCallout: string;
}

export interface DeadlineInvoiceItem {
  description: string;
  quantity?: number;
  unitPrice?: number;
  amount: number;
}

export interface DeadlineApproachingInvoice {
  id: string;
  invoiceNumber: string;
  customerName: string;
  recipientEmail: string;
  recipientType: "Farmer" | "Outgrower" | "Cooperative" | "Agro-Dealer" | "Customer" | string;
  totalAmount: number;
  paidAmount?: number;
  balanceDue: number;
  currency: string;
  dueDate: string;
  daysUntilDeadline: number;
  urgency: DeadlineUrgency;
  urgencyLabel: string;
  items: DeadlineInvoiceItem[];
  payLinkUrl?: string;
  directPayToken?: string;
  lastDeadlineNotificationAt?: string;
  notificationCount?: number;
  farmContext?: {
    farmNodeId?: string;
    farmName?: string;
    location?: string;
    phone?: string;
    tenantId?: string;
  };
}

export interface DeadlineNotificationLog {
  id: string;
  invoiceId: string;
  invoiceNumber: string;
  farmerEmail: string;
  farmerName: string;
  totalAmount: number;
  currency: string;
  dueDate: string;
  daysUntilDeadline: number;
  urgency: DeadlineUrgency;
  urgencyLabel: string;
  sentAt: string;
  status: "DELIVERED" | "FAILED" | "SKIPPED_RECENTLY_SENT";
  messageId?: string;
  gateway: string;
  subject: string;
  payLinkUrl?: string;
  error?: string;
}

export interface DeadlineScanReport {
  scannedAt: string;
  totalScanned: number;
  approachingCount: number;
  sentCount: number;
  skippedCount: number;
  failedCount: number;
  totalPendingAmountZK: number;
  approachingInvoices: DeadlineApproachingInvoice[];
  logs: DeadlineNotificationLog[];
}

const DEADLINE_LOGS_STORAGE_KEY = "mabala_invoice_deadline_notification_logs_v1";
const LAST_DEADLINE_SCAN_STORAGE_KEY = "mabala_last_deadline_notification_scan";

/**
 * Calculates days until deadline and urgency classification
 */
export function calculateDeadlineUrgency(
  dueDateStr: string,
  thresholdDays: number = 7
): DeadlineUrgencyInfo {
  if (!dueDateStr) {
    return {
      daysUntilDeadline: 999,
      urgency: "NOT_APPROACHING",
      isApproaching: false,
      urgencyLabel: "No Deadline Set",
      badgeBg: "bg-slate-100",
      badgeText: "text-slate-600",
      badgeBorder: "border-slate-200",
      actionCallout: "No due date defined."
    };
  }

  const now = new Date();
  now.setHours(0, 0, 0, 0);

  const due = new Date(dueDateStr);
  due.setHours(0, 0, 0, 0);

  const diffMs = due.getTime() - now.getTime();
  const daysUntilDeadline = Math.round(diffMs / (1000 * 60 * 60 * 24));

  if (daysUntilDeadline < 0) {
    const daysOverdue = Math.abs(daysUntilDeadline);
    return {
      daysUntilDeadline,
      urgency: "OVERDUE",
      isApproaching: true,
      urgencyLabel: `${daysOverdue} Day${daysOverdue === 1 ? "" : "s"} Overdue`,
      badgeBg: "bg-rose-500/15",
      badgeText: "text-rose-400",
      badgeBorder: "border-rose-500/30",
      actionCallout: `Payment is past due by ${daysOverdue} day${daysOverdue === 1 ? "" : "s"}. Immediate settlement required.`
    };
  }

  if (daysUntilDeadline === 0) {
    return {
      daysUntilDeadline: 0,
      urgency: "DUE_TODAY",
      isApproaching: true,
      urgencyLabel: "Payment Due Today",
      badgeBg: "bg-amber-500/15",
      badgeText: "text-amber-400",
      badgeBorder: "border-amber-500/30",
      actionCallout: "Deadline expires today at 23:59 CAT. Settle balance to maintain active status."
    };
  }

  if (daysUntilDeadline === 1) {
    return {
      daysUntilDeadline: 1,
      urgency: "DUE_TOMORROW",
      isApproaching: true,
      urgencyLabel: "Due Tomorrow (24h)",
      badgeBg: "bg-amber-500/15",
      badgeText: "text-amber-400",
      badgeBorder: "border-amber-500/30",
      actionCallout: "Payment deadline expires tomorrow. Early settlement recommended."
    };
  }

  if (daysUntilDeadline <= 3) {
    return {
      daysUntilDeadline,
      urgency: "DUE_IN_3_DAYS",
      isApproaching: true,
      urgencyLabel: `Due in ${daysUntilDeadline} Days`,
      badgeBg: "bg-amber-500/10",
      badgeText: "text-amber-300",
      badgeBorder: "border-amber-500/25",
      actionCallout: `Payment deadline approaches in ${daysUntilDeadline} days.`
    };
  }

  if (daysUntilDeadline <= thresholdDays) {
    return {
      daysUntilDeadline,
      urgency: "DUE_IN_7_DAYS",
      isApproaching: true,
      urgencyLabel: `Due in ${daysUntilDeadline} Days`,
      badgeBg: "bg-blue-500/10",
      badgeText: "text-blue-300",
      badgeBorder: "border-blue-500/25",
      actionCallout: `Approaching scheduled payment date on ${dueDateStr}.`
    };
  }

  return {
    daysUntilDeadline,
    urgency: "NOT_APPROACHING",
    isApproaching: false,
    urgencyLabel: `Due in ${daysUntilDeadline} Days`,
    badgeBg: "bg-slate-800",
    badgeText: "text-slate-400",
    badgeBorder: "border-slate-700",
    actionCallout: "Payment deadline within acceptable future schedule."
  };
}

/**
 * Builds high-converting HTML and text email for the farmer
 */
export function buildDeadlineEmailTemplate(invoice: DeadlineApproachingInvoice): {
  subject: string;
  html: string;
  text: string;
} {
  const currency = invoice.currency || "ZK";
  const formattedBalance = Number(invoice.balanceDue || invoice.totalAmount || 0).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const farmName = invoice.farmContext?.farmName || "Mabala Agronomic Operating System";
  const payLink = invoice.payLinkUrl || `https://mabala.cloud/invoices?pay=${encodeURIComponent(invoice.invoiceNumber)}`;

  // Determine urgency theme
  let urgencyTitle = "Upcoming Invoice Payment Deadline Notice";
  let urgencyBadge = "PAYMENT DEADLINE APPROACHING";
  let urgencyColor = "#f59e0b"; // amber
  let urgencyBg = "#fef3c7";
  let urgencyTextColor = "#92400e";

  if (invoice.urgency === "DUE_TODAY") {
    urgencyTitle = "URGENT: Payment Due Today";
    urgencyBadge = "DEADLINE EXPIRES TODAY";
    urgencyColor = "#dc2626";
    urgencyBg = "#fee2e2";
    urgencyTextColor = "#991b1b";
  } else if (invoice.urgency === "DUE_TOMORROW") {
    urgencyTitle = "NOTICE: Payment Due Tomorrow";
    urgencyBadge = "DEADLINE EXPIRES IN 24 HOURS";
    urgencyColor = "#ea580c";
    urgencyBg = "#ffedd5";
    urgencyTextColor = "#9a3412";
  } else if (invoice.urgency === "OVERDUE") {
    urgencyTitle = `OVERDUE NOTICE: Invoice #${invoice.invoiceNumber}`;
    urgencyBadge = `PAST DUE (${Math.abs(invoice.daysUntilDeadline)} DAYS)`;
    urgencyColor = "#b91c1c";
    urgencyBg = "#ffe4e6";
    urgencyTextColor = "#881337";
  }

  const subject = `[${urgencyBadge}] Commercial Invoice #${invoice.invoiceNumber} (Due ${invoice.dueDate}) — ${farmName}`;

  const itemsRows = (invoice.items && invoice.items.length > 0)
    ? invoice.items.map(it => `
      <tr>
        <td style="padding: 10px 14px; border-bottom: 1px solid #e2e8f0; font-size: 13px; color: #1e293b;">
          <strong>${it.description || "General Agricultural Service / Input"}</strong>
        </td>
        <td style="padding: 10px 14px; border-bottom: 1px solid #e2e8f0; font-size: 13px; text-align: center; color: #475569; font-family: monospace;">
          ${it.quantity || 1}
        </td>
        <td style="padding: 10px 14px; border-bottom: 1px solid #e2e8f0; font-size: 13px; text-align: right; font-weight: 700; color: #0f172a; font-family: monospace;">
          ${currency} ${Number(it.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
        </td>
      </tr>
    `).join("")
    : `
      <tr>
        <td colspan="3" style="padding: 12px 14px; text-align: center; color: #64748b; font-size: 12px;">
          Outstanding balance for agricultural inputs and platform operations.
        </td>
      </tr>
    `;

  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${subject}</title>
</head>
<body style="margin: 0; padding: 24px; background-color: #0f172a; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b;">
  <div style="max-width: 640px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.3), 0 8px 10px -6px rgba(0, 0, 0, 0.3); border: 1px solid #334155;">
    
    <!-- HEADER WITH ENTERPRISE BRANDING -->
    <div style="background: linear-gradient(135deg, #0b1528 0%, #1e293b 100%); padding: 32px 28px; color: #ffffff;">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px;">
        <div>
          <span style="font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; color: #38bdf8; display: block; margin-bottom: 6px;">
            Mabala Agro Enterprise • Payment Schedule Notice
          </span>
          <h1 style="margin: 0; font-size: 22px; font-weight: 900; letter-spacing: -0.5px; color: #ffffff;">
            ${farmName}
          </h1>
          <p style="margin: 6px 0 0 0; font-size: 13px; color: #94a3b8;">
            Billing & Accounts Receivable Operations
          </p>
        </div>
        <div>
          <span style="display: inline-block; background-color: ${urgencyBg}; color: ${urgencyTextColor}; border: 1px solid ${urgencyColor}; font-size: 11px; font-weight: 900; padding: 6px 12px; border-radius: 8px; text-transform: uppercase; letter-spacing: 0.8px;">
            ${urgencyBadge}
          </span>
        </div>
      </div>
    </div>

    <!-- MAIN BODY -->
    <div style="padding: 28px;">
      
      <!-- GREETING & NOTICE -->
      <div style="margin-bottom: 24px;">
        <h2 style="margin: 0 0 10px 0; font-size: 16px; font-weight: 800; color: #0f172a;">
          Dear ${invoice.customerName},
        </h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.6; color: #475569;">
          This is an automated notification regarding the approaching payment deadline for your commercial invoice. Please review the details below and arrange settlement before or on the due date.
        </p>
      </div>

      <!-- INVOICE METRICS SUMMARY CARD -->
      <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 24px;">
        <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
          <tr>
            <td style="padding: 6px 0; color: #64748b; font-weight: 600;">Invoice Reference:</td>
            <td style="padding: 6px 0; color: #0f172a; font-weight: 800; text-align: right; font-family: monospace;">${invoice.invoiceNumber}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b; font-weight: 600;">Recipient Account:</td>
            <td style="padding: 6px 0; color: #0f172a; font-weight: 700; text-align: right;">${invoice.customerName} (${invoice.recipientType})</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b; font-weight: 600;">Registered Email:</td>
            <td style="padding: 6px 0; color: #0f172a; font-weight: 700; text-align: right;">${invoice.recipientEmail}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b; font-weight: 600;">Payment Deadline:</td>
            <td style="padding: 6px 0; color: ${urgencyColor}; font-weight: 900; text-align: right; font-size: 14px;">${invoice.dueDate} (${invoice.urgencyLabel})</td>
          </tr>
          <tr style="border-top: 2px solid #cbd5e1;">
            <td style="padding: 12px 0 0 0; color: #0f172a; font-weight: 800; font-size: 15px;">Total Balance Due:</td>
            <td style="padding: 12px 0 0 0; color: #0f172a; font-weight: 900; text-align: right; font-size: 20px; font-family: monospace;">${currency} ${formattedBalance}</td>
          </tr>
        </table>
      </div>

      <!-- ITEMIZED STATEMENT TABLE -->
      <div style="margin-bottom: 24px;">
        <div style="font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; color: #64748b; margin-bottom: 8px;">
          Itemized Services & Commodity Breakdown
        </div>
        <table style="width: 100%; border-collapse: collapse; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden;">
          <thead>
            <tr style="background-color: #f1f5f9;">
              <th style="padding: 10px 14px; text-align: left; font-size: 11px; font-weight: 800; color: #475569; text-transform: uppercase;">Description</th>
              <th style="padding: 10px 14px; text-align: center; font-size: 11px; font-weight: 800; color: #475569; text-transform: uppercase;">Qty</th>
              <th style="padding: 10px 14px; text-align: right; font-size: 11px; font-weight: 800; color: #475569; text-transform: uppercase;">Amount (${currency})</th>
            </tr>
          </thead>
          <tbody>
            ${itemsRows}
          </tbody>
        </table>
      </div>

      <!-- DIRECT LIPILA PAYMENT ACTION BUTTON -->
      <div style="background-color: #047857; background: linear-gradient(135deg, #059669 0%, #047857 100%); border-radius: 12px; padding: 24px; text-align: center; margin-bottom: 24px; color: #ffffff;">
        <div style="font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; color: #a7f3d0; margin-bottom: 6px;">
          Instant Settlement Gateway
        </div>
        <div style="font-size: 16px; font-weight: 800; margin-bottom: 14px;">
          Pay Online with Mobile Money (MTN, Airtel, Zamtel)
        </div>
        <a href="${payLink}" style="display: inline-block; background-color: #ffffff; color: #065f46; font-size: 14px; font-weight: 900; padding: 12px 28px; border-radius: 10px; text-decoration: none; text-transform: uppercase; letter-spacing: 0.5px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2);">
          Open Direct Payment Link →
        </a>
        <div style="font-size: 11px; color: #d1fae5; margin-top: 10px;">
          No account login required. Automated receipt and instant reconciliation upon completion.
        </div>
      </div>

      <!-- BANK WIRE / MANUAL SETTLEMENT INSTRUCTIONS -->
      <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px; margin-bottom: 24px;">
        <div style="font-size: 12px; font-weight: 800; text-transform: uppercase; color: #334155; margin-bottom: 8px;">
          Alternative Settlement: Direct Bank Transfer
        </div>
        <table style="width: 100%; border-collapse: collapse; font-size: 12px; color: #475569;">
          <tr>
            <td style="padding: 3px 0; font-weight: 600;">Bank Name:</td>
            <td style="padding: 3px 0; font-weight: 700; color: #0f172a; text-align: right;">Zambia National Commercial Bank (Zanaco)</td>
          </tr>
          <tr>
            <td style="padding: 3px 0; font-weight: 600;">Account Name:</td>
            <td style="padding: 3px 0; font-weight: 700; color: #0f172a; text-align: right;">Deep Valley Farms Limited / Mabala Cloud</td>
          </tr>
          <tr>
            <td style="padding: 3px 0; font-weight: 600;">Payment Reference:</td>
            <td style="padding: 3px 0; font-weight: 800; color: #0284c7; text-align: right; font-family: monospace;">${invoice.invoiceNumber}</td>
          </tr>
        </table>
      </div>

    </div>

    <!-- FOOTER WITH NO-REPLY ADVISORY -->
    <div style="background-color: #f1f5f9; border-top: 2px solid #e2e8f0; padding: 24px; font-size: 12px; color: #64748b;">
      <div style="background-color: #fff1f2; border: 1px solid #fecdd3; border-radius: 8px; padding: 8px 12px; margin-bottom: 14px; text-align: center;">
        <span style="font-size: 11px; font-weight: 800; color: #9f1239; text-transform: uppercase; letter-spacing: 0.5px;">
          🚫 AUTOMATED NO-REPLY NOTIFICATION
        </span>
        <div style="font-size: 11px; color: #881337; margin-top: 2px;">
          Do not reply directly to this email. For billing inquiries, contact <strong>support@mabala.cloud</strong> or call <strong>+260 978 070 734</strong>.
        </div>
      </div>
      
      <div style="text-align: center; line-height: 1.5;">
        <strong>${farmName}</strong> • Powered by Mabala Agronomic Operating System<br>
        Lusaka, Zambia • Commercial Agriculture Zone<br>
        Dispatched via Hostinger Enterprise SMTP Server
      </div>
    </div>

  </div>
</body>
</html>
  `;

  const text = `
${urgencyBadge}
${subject}

Dear ${invoice.customerName},

This is an automated notification regarding the approaching payment deadline for your commercial invoice.

INVOICE DETAILS:
--------------------------------------------------
Invoice Number:   ${invoice.invoiceNumber}
Recipient:        ${invoice.customerName} (${invoice.recipientType})
Email:            ${invoice.recipientEmail}
Payment Deadline: ${invoice.dueDate} (${invoice.urgencyLabel})
Total Balance:    ${currency} ${formattedBalance}
--------------------------------------------------

DIRECT PAYMENT LINK (Lipila Mobile Money - MTN / Airtel / Zamtel):
${payLink}

BANK DEPOSIT OPTION:
Bank: Zanaco (Zambia National Commercial Bank)
Account: Deep Valley Farms Limited
Reference: ${invoice.invoiceNumber}

This is an automated message dispatched via Hostinger SMTP. 
Do not reply directly. Inquiries: support@mabala.cloud | +260 978 070 734
  `.trim();

  return { subject, html, text };
}

/**
 * Normalizes any invoice representation into a standardized DeadlineApproachingInvoice
 */
export function normalizeToDeadlineInvoice(
  rawInv: any,
  tenantContext?: any
): DeadlineApproachingInvoice | null {
  if (!rawInv) return null;

  const id = rawInv.id || rawInv.invoiceNumber || `INV-${Date.now()}`;
  const invoiceNumber = rawInv.invoiceNumber || rawInv.id || "INV-UNKNOWN";
  const dueDate = rawInv.dueDate || rawInv.date || "";

  // Skip if already marked Paid or Cancelled
  const statusUpper = String(rawInv.status || "").toUpperCase();
  if (statusUpper === "PAID" || statusUpper.startsWith("CANCEL")) {
    return null;
  }

  const { daysUntilDeadline, urgency, urgencyLabel } = calculateDeadlineUrgency(dueDate);

  // Recipient resolution
  const customerName = rawInv.customerName || rawInv.recipientTenantName || rawInv.clientName || "Registered Farmer";
  const recipientEmail = (
    rawInv.recipientEmail ||
    rawInv.customerEmail ||
    rawInv.email ||
    (rawInv.recipientTenantId ? `${rawInv.recipientTenantId.toLowerCase()}@mabala.cloud` : "")
  ).trim();

  // Validate recipient email
  if (!recipientEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipientEmail)) {
    return null;
  }

  const recipientType = rawInv.recipientType || (rawInv.farmId ? "Farmer" : "Customer");
  const totalAmount = Number(rawInv.totalAmount || rawInv.total || 0);
  const paidAmount = Number(rawInv.paidAmount || 0);
  const balanceDue = Math.max(0, totalAmount - paidAmount);

  // Items normalization
  const rawItems = Array.isArray(rawInv.lineItems)
    ? rawInv.lineItems
    : (Array.isArray(rawInv.lines) ? rawInv.lines : (Array.isArray(rawInv.items) ? rawInv.items : []));

  const items: DeadlineInvoiceItem[] = rawItems.map((it: any) => ({
    description: it.description || it.item || "Agro Input / Produce",
    quantity: Number(it.quantity || 1),
    unitPrice: Number(it.unitPrice || it.price || 0),
    amount: Number(it.amount || it.total || (it.quantity || 1) * (it.unitPrice || 0))
  }));

  const { payLinkUrl, token } = generateDirectPayLink(id, recipientEmail);

  return {
    id,
    invoiceNumber,
    customerName,
    recipientEmail,
    recipientType,
    totalAmount,
    paidAmount,
    balanceDue: balanceDue > 0 ? balanceDue : totalAmount,
    currency: rawInv.currency || "ZK",
    dueDate,
    daysUntilDeadline,
    urgency,
    urgencyLabel,
    items,
    payLinkUrl: rawInv.payLinkUrl || payLinkUrl,
    directPayToken: rawInv.directPayToken || token,
    lastDeadlineNotificationAt: rawInv.lastDeadlineNotificationAt,
    notificationCount: Number(rawInv.notificationCount || rawInv.reminderCount || 0),
    farmContext: {
      farmNodeId: rawInv.farmId || rawInv.farmContext?.farmNodeId || "FN-HQ-PRIMARY",
      farmName: rawInv.farmName || rawInv.farmContext?.farmName || tenantContext?.name || "Mabala Farm Enterprise",
      location: tenantContext?.location || "Lusaka, Zambia",
      phone: tenantContext?.phone || "+260 978 070 734",
      tenantId: rawInv.tenantId || rawInv.recipientTenantId || tenantContext?.id
    }
  };
}

/**
 * Dispatches an automated email notification for an approaching invoice deadline
 * Uses the configured SMTP settings in .env via the backend mail server
 */
export async function sendInvoiceDeadlineNotification(
  invoice: DeadlineApproachingInvoice,
  forceSend: boolean = false
): Promise<DeadlineNotificationLog> {
  const { subject, html, text } = buildDeadlineEmailTemplate(invoice);
  const nowIso = new Date().toISOString();

  // Check 20-hour deduplication unless forceSend
  if (!forceSend && invoice.lastDeadlineNotificationAt) {
    const lastSentTime = new Date(invoice.lastDeadlineNotificationAt).getTime();
    const hoursSinceLast = (Date.now() - lastSentTime) / (1000 * 60 * 60);
    if (hoursSinceLast < 20) {
      const skippedLog: DeadlineNotificationLog = {
        id: `DNOTIF-SKIP-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        invoiceId: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
        farmerEmail: invoice.recipientEmail,
        farmerName: invoice.customerName,
        totalAmount: invoice.balanceDue,
        currency: invoice.currency,
        dueDate: invoice.dueDate,
        daysUntilDeadline: invoice.daysUntilDeadline,
        urgency: invoice.urgency,
        urgencyLabel: invoice.urgencyLabel,
        sentAt: nowIso,
        status: "SKIPPED_RECENTLY_SENT",
        gateway: "Hostinger SMTP (Skipped - Sent < 20h ago)",
        subject,
        payLinkUrl: invoice.payLinkUrl
      };
      return skippedLog;
    }
  }

  let deliveryStatus: "DELIVERED" | "FAILED" = "FAILED";
  let messageId = "";
  let gatewayUsed = "Hostinger SMTP";
  let failureReason: string | undefined = undefined;

  try {
    // 1. Try dedicated deadline reminder endpoint
    const response = await fetch("/api/invoices/send-deadline-reminder", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        to: invoice.recipientEmail,
        customerName: invoice.customerName,
        invoiceNumber: invoice.invoiceNumber,
        dueDate: invoice.dueDate,
        totalAmount: invoice.balanceDue,
        currencySymbol: invoice.currency,
        daysUntilDeadline: invoice.daysUntilDeadline,
        urgency: invoice.urgency,
        items: invoice.items,
        payLinkUrl: invoice.payLinkUrl,
        farmContext: invoice.farmContext,
        subject,
        html,
        text
      })
    });

    if (response.ok) {
      const resData = await response.json();
      deliveryStatus = "DELIVERED";
      messageId = resData.messageId || resData.details?.messageId || `MSG-${Date.now()}`;
      gatewayUsed = resData.details?.gateway || "Hostinger SMTP SSL (465)";
    } else {
      // 2. Fallback to /api/mail/send
      const fallbackRes = await fetch("/api/mail/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: invoice.recipientEmail,
          subject,
          htmlContent: html,
          textContent: text,
          category: "invoice_deadline",
          farmContext: invoice.farmContext
        })
      });

      if (fallbackRes.ok) {
        const fbData = await fallbackRes.json();
        deliveryStatus = "DELIVERED";
        messageId = fbData.messageId || `MSG-FB-${Date.now()}`;
        gatewayUsed = fbData.gateway || "Hostinger SMTP";
      } else {
        const errJson = await fallbackRes.json().catch(() => ({}));
        failureReason = errJson.error || `HTTP ${fallbackRes.status}`;
      }
    }
  } catch (err: any) {
    console.warn(`[Deadline Notification Dispatch Warning]: ${err.message}`);
    failureReason = err.message;
  }

  const newLog: DeadlineNotificationLog = {
    id: `DNOTIF-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    invoiceId: invoice.id,
    invoiceNumber: invoice.invoiceNumber,
    farmerEmail: invoice.recipientEmail,
    farmerName: invoice.customerName,
    totalAmount: invoice.balanceDue,
    currency: invoice.currency,
    dueDate: invoice.dueDate,
    daysUntilDeadline: invoice.daysUntilDeadline,
    urgency: invoice.urgency,
    urgencyLabel: invoice.urgencyLabel,
    sentAt: nowIso,
    status: deliveryStatus,
    messageId,
    gateway: gatewayUsed,
    subject,
    payLinkUrl: invoice.payLinkUrl,
    error: failureReason
  };

  // Store in local history cache
  if (typeof window !== "undefined") {
    try {
      const raw = localStorage.getItem(DEADLINE_LOGS_STORAGE_KEY);
      const list: DeadlineNotificationLog[] = raw ? JSON.parse(raw) : [];
      list.unshift(newLog);
      localStorage.setItem(DEADLINE_LOGS_STORAGE_KEY, JSON.stringify(list.slice(0, 300)));
    } catch (e) {
      console.warn("Could not cache deadline notification log:", e);
    }
  }

  // Persist to Firestore if available
  if (db && deliveryStatus === "DELIVERED") {
    try {
      // Save notification log record
      await setDoc(doc(db, "invoice_deadline_notification_logs", newLog.id), newLog);

      // Update platform invoice if this is a platform invoice
      await updateDoc(doc(db, "platformInvoices", invoice.id), {
        lastDeadlineNotificationAt: nowIso,
        lastReminderSentAt: nowIso,
        reminderCount: (invoice.notificationCount || 0) + 1
      }).catch(() => {});
    } catch (e) {
      console.warn("Firestore update error for deadline notification:", e);
    }
  }

  return newLog;
}

/**
 * Scans list of invoices and filters out ones approaching deadline without sending emails
 */
export function scanApproachingDeadlineInvoices(
  invoicesList: any[],
  thresholdDays = 7,
  tenantContext?: any
): DeadlineApproachingInvoice[] {
  const approaching: DeadlineApproachingInvoice[] = [];
  for (const raw of invoicesList || []) {
    const norm = normalizeToDeadlineInvoice(raw, tenantContext);
    if (!norm) continue;
    const { isApproaching } = calculateDeadlineUrgency(norm.dueDate, thresholdDays);
    if (isApproaching) {
      approaching.push(norm);
    }
  }
  return approaching;
}

/**
 * Sends automated payment deadline reminders for a specific set of invoices
 */
export async function sendAutomaticPaymentDeadlineReminders(
  invoicesList: any[],
  tenantContext?: any,
  forceSend = true
): Promise<DeadlineScanReport> {
  return scanAndNotifyApproachingDeadlines(invoicesList, {
    thresholdDays: 365,
    forceSend,
    tenantContext
  });
}

/**
 * Scans all platform and farm invoices, finds approaching deadlines, and dispatches automated notifications
 */
export async function scanAndNotifyApproachingDeadlines(
  invoicesList?: any[],
  options: {
    thresholdDays?: number;
    forceSend?: boolean;
    tenantContext?: any;
  } = {}
): Promise<DeadlineScanReport> {
  const thresholdDays = options.thresholdDays ?? 7;
  const nowIso = new Date().toISOString();

  // 1. Gather all candidate invoices
  let rawList = invoicesList || [];
  if (!invoicesList || invoicesList.length === 0) {
    const platformInvoices = await fetchPlatformInvoices();
    rawList = platformInvoices;
  }

  // 2. Normalize and filter for approaching deadlines
  const approachingInvoices: DeadlineApproachingInvoice[] = [];
  let totalPendingAmountZK = 0;

  for (const raw of rawList) {
    const norm = normalizeToDeadlineInvoice(raw, options.tenantContext);
    if (!norm) continue;

    const { daysUntilDeadline, isApproaching } = calculateDeadlineUrgency(norm.dueDate, thresholdDays);
    if (isApproaching) {
      approachingInvoices.push(norm);
      totalPendingAmountZK += norm.balanceDue;
    }
  }

  // 3. Dispatch automated notifications for each approaching invoice
  let sentCount = 0;
  let skippedCount = 0;
  let failedCount = 0;
  const logs: DeadlineNotificationLog[] = [];

  for (const inv of approachingInvoices) {
    const log = await sendInvoiceDeadlineNotification(inv, options.forceSend);
    logs.push(log);
    if (log.status === "DELIVERED") sentCount++;
    else if (log.status === "SKIPPED_RECENTLY_SENT") skippedCount++;
    else failedCount++;
  }

  // Record last scan timestamp
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(LAST_DEADLINE_SCAN_STORAGE_KEY, nowIso);
    } catch {}
  }

  return {
    scannedAt: nowIso,
    totalScanned: rawList.length,
    approachingCount: approachingInvoices.length,
    sentCount,
    skippedCount,
    failedCount,
    totalPendingAmountZK,
    approachingInvoices,
    logs
  };
}

/**
 * Retrieves persisted deadline notification history logs
 */
export function getDeadlineNotificationLogs(): DeadlineNotificationLog[] {
  if (typeof window !== "undefined") {
    try {
      const raw = localStorage.getItem(DEADLINE_LOGS_STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      return [];
    }
  }
  return [];
}

/**
 * Starts an automated background schedule that checks approaching invoice deadlines periodically
 */
export function startDeadlineNotificationScheduler(options: {
  intervalHours?: number;
  onScanComplete?: (report: DeadlineScanReport) => void;
} = {}): () => void {
  const intervalMs = (options.intervalHours || 12) * 60 * 60 * 1000;

  // Initial check if not executed within the last 12 hours
  const checkInitial = async () => {
    try {
      const lastScan = typeof window !== "undefined" ? localStorage.getItem(LAST_DEADLINE_SCAN_STORAGE_KEY) : null;
      if (!lastScan || Date.now() - new Date(lastScan).getTime() > intervalMs) {
        console.log("[Deadline Scheduler] Running automated invoice deadline scan...");
        const report = await scanAndNotifyApproachingDeadlines();
        if (options.onScanComplete) options.onScanComplete(report);
      }
    } catch (err: any) {
      console.warn("[Deadline Scheduler Error]:", err.message);
    }
  };

  checkInitial();

  const timer = setInterval(async () => {
    try {
      console.log("[Deadline Scheduler] Recurring invoice deadline scan triggering...");
      const report = await scanAndNotifyApproachingDeadlines();
      if (options.onScanComplete) options.onScanComplete(report);
    } catch (err: any) {
      console.warn("[Deadline Scheduler Recurring Error]:", err.message);
    }
  }, intervalMs);

  return () => clearInterval(timer);
}

export const InvoiceDeadlineNotificationService = {
  calculateDeadlineUrgency,
  normalizeToDeadlineInvoice,
  scanApproachingDeadlineInvoices,
  sendInvoiceDeadlineNotification,
  sendAutomaticPaymentDeadlineReminders,
  scanAndNotifyApproachingDeadlines,
  getDeadlineNotificationLogs,
  startDeadlineNotificationScheduler
};

export default InvoiceDeadlineNotificationService;

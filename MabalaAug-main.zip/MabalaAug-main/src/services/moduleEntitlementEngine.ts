import { doc, getDoc, setDoc, onSnapshot, collection, getDocs, writeBatch } from "firebase/firestore";
import { db, auth } from "../firebase";
import { SUPER_ADMIN_EMAILS } from "./identityIntegrityService";

export type TenantTypeCode = "agro_dealer" | "institution_supplier" | "offtaker" | "mabala_partner" | "farmer" | "super_admin" | "agronomist";

export interface TenantTypeConfig {
  code: TenantTypeCode;
  humanLabel: string;
  landingShell: string;
}

export interface ModuleRegistryDoc {
  moduleId: string;            // e.g. "dashboard_hub"
  name: string;                // display name
  description: string;         // shown as helper text in the toggle console
  category: "core" | "finance" | "agriculture" | "commerce" | "admin_only";
  eligibleTenantTypes: TenantTypeCode[];  // which tenant types this module can ever be shown to
  hardLocked: boolean;         // true = platform_admin only, not togglable
  defaultAccess: {
    read: boolean;
    write: boolean;
  };
}

export const CANONICAL_TENANT_TYPES: Record<TenantTypeCode, TenantTypeConfig> = {
  agro_dealer: {
    code: "agro_dealer",
    humanLabel: "Agro-Dealer",
    landingShell: "agc-dealer-pos" // Retail Shop View
  },
  institution_supplier: {
    code: "institution_supplier",
    humanLabel: "Seed/Chemical Company & Institution Supplier",
    landingShell: "agc-financier-portal" // Supplier Portal View
  },
  offtaker: {
    code: "offtaker",
    humanLabel: "Offtaker / Commodity Buyer",
    landingShell: "offtaker-marketplace" // Offtaker Marketplace View
  },
  mabala_partner: {
    code: "mabala_partner",
    humanLabel: "Mabala Cloud Partner Program",
    landingShell: "partner-portal" // Mabala Partner Portal View
  },
  farmer: {
    code: "farmer",
    humanLabel: "Farmer",
    landingShell: "dashboard" // Farmer Workspace
  },
  super_admin: {
    code: "super_admin",
    humanLabel: "Platform Admin",
    landingShell: "platform-admin" // Platform Admin Console
  },
  agronomist: {
    code: "agronomist",
    humanLabel: "Agronomist / Advisory Specialist",
    landingShell: "advisory-portal" // Advisory Services Module
  }
};

// Seeded Module Registry as per spec
export const SEEDED_MODULE_REGISTRY: ModuleRegistryDoc[] = [
  {
    moduleId: "dashboard_hub",
    name: "Dashboard Hub",
    description: "Primary farm workspace dashboard and operational status hub",
    category: "core",
    eligibleTenantTypes: ["agro_dealer", "institution_supplier", "farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "chart_of_accounts",
    name: "Chart of Accounts",
    description: "Double-entry bookkeeping accounts and ledger classification",
    category: "finance",
    eligibleTenantTypes: ["agro_dealer", "institution_supplier", "farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "expenses_ledger",
    name: "Expenses Ledger",
    description: "Operational expenditure tracking, receipt logging and expense reporting",
    category: "finance",
    eligibleTenantTypes: ["agro_dealer", "institution_supplier", "farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "crop_cycles",
    name: "Crop Cycles (Tasks)",
    description: "Crop calendar, field task planning, harvest tracking and field activity logs",
    category: "agriculture",
    eligibleTenantTypes: ["farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "payroll_localizer",
    name: "Payroll Localizer (Pro)",
    description: "Employee wages, statutory tax localization, payslip generation and labor tracking",
    category: "finance",
    eligibleTenantTypes: ["institution_supplier", "farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "sales_tracker",
    name: "Sales Tracker",
    description: "Revenue records, cash receipts, customer transactions and POS sales logs",
    category: "finance",
    eligibleTenantTypes: ["agro_dealer", "institution_supplier", "farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "invoices_quotes",
    name: "Invoices & Quotes",
    description: "Professional quotation builder, proforma invoice generation and payment tracking",
    category: "finance",
    eligibleTenantTypes: ["agro_dealer", "institution_supplier", "farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "livestock_poultry",
    name: "Livestock & Poultry Records",
    description: "Animal herd registry, poultry flock management, vaccination schedules and health logs",
    category: "agriculture",
    eligibleTenantTypes: ["farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "aquaculture_systems",
    name: "Aquaculture Systems",
    description: "Fish pond monitoring, water quality management, feed conversion and batch logs",
    category: "agriculture",
    eligibleTenantTypes: ["farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "inventory_stock",
    name: "Inventory & Stock",
    description: "Stockroom management, input inventory tracking, reorder alerts and stock valuations",
    category: "commerce",
    eligibleTenantTypes: ["agro_dealer", "institution_supplier", "farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "financial_reports",
    name: "Financial Reports",
    description: "Profit & Loss statements, balance sheets, cashflow reports and financial analytics",
    category: "finance",
    eligibleTenantTypes: ["agro_dealer", "institution_supplier", "farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "agrodealer_consignment_hub_supplier",
    name: "Supplier Consignment Hub",
    description: "Seed & chemical company hub for issuing consignment stock to agro-dealer networks",
    category: "commerce",
    eligibleTenantTypes: ["institution_supplier"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "agrodealer_pos_counter",
    name: "Agro-Dealer POS Counter",
    description: "Over-the-counter retail checkout, receipt printer integration and digital voucher redemption",
    category: "commerce",
    eligibleTenantTypes: ["agro_dealer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "agrodealer_boost_placements",
    name: "Agrodealer Boost & Sponsored Placements",
    description: "Promotional product boosting, featured store placement and marketing ad slots",
    category: "commerce",
    eligibleTenantTypes: ["agro_dealer", "institution_supplier"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "vendor_marketplace",
    name: "Mabala Vendor Marketplace",
    description: "B2B input sourcing, product listings, buyer-seller matching and digital commerce",
    category: "commerce",
    eligibleTenantTypes: ["agro_dealer", "institution_supplier", "farmer"],
    hardLocked: false,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "mabala_consignment_hub_admin",
    name: "Mabala Agro-Dealer Consignment Hub (Platform Admin)",
    description: "Platform-wide consignment audit oversight, inventory clearinghouse and admin control",
    category: "admin_only",
    eligibleTenantTypes: [],
    hardLocked: true,
    defaultAccess: { read: true, write: true }
  },
  {
    moduleId: "ai_crop_knowledge_admin",
    name: "AI Crop Knowledge Base & Content Admin Portal",
    description: "Agronomic AI knowledge base administration, crop disease dataset training and content management",
    category: "admin_only",
    eligibleTenantTypes: [],
    hardLocked: true,
    defaultAccess: { read: true, write: true }
  }
];

export const SEEDED_MODULE_REGISTRY_MAP: Record<string, ModuleRegistryDoc> = SEEDED_MODULE_REGISTRY.reduce((acc, doc) => {
  acc[doc.moduleId] = doc;
  return acc;
}, {} as Record<string, ModuleRegistryDoc>);

// Map legacy tab keys to canonical moduleId
export const MODULE_KEY_MAP: Record<string, string> = {
  "dashboard": "dashboard_hub",
  "accounts": "chart_of_accounts",
  "expenses": "expenses_ledger",
  "crops": "crop_cycles",
  "hsw-dashboard": "crop_cycles",
  "payroll": "payroll_localizer",
  "sales": "sales_tracker",
  "invoices": "invoices_quotes",
  "livestock": "livestock_poultry",
  "poultry": "livestock_poultry",
  "aquaculture": "aquaculture_systems",
  "inventory": "inventory_stock",
  "reports": "financial_reports",
  "agc-financier-portal": "agrodealer_consignment_hub_supplier",
  "agc-dealer-pos": "agrodealer_pos_counter",
  "agrodealer-boost": "agrodealer_boost_placements",
  "marketplace": "vendor_marketplace",
  "agrodealer-consignment": "agrodealer_consignment_hub_supplier",
  "mabala-consignment-admin": "mabala_consignment_hub_admin",
  "ai-crop-admin": "ai_crop_knowledge_admin",
  "sms-hub": "sms_hub",
  "sms-hub-group": "sms_hub",
  "sms": "sms_hub"
};

/**
 * Idempotently seeds the module registry docs into Firestore `platformConfig/moduleRegistry/{moduleId}`
 */
export async function seedModuleRegistryIdempotent(): Promise<void> {
  try {
    const batch = writeBatch(db);
    for (const mod of SEEDED_MODULE_REGISTRY) {
      const docRef = doc(db, "platformConfig", "moduleRegistry", "modules", mod.moduleId);
      batch.set(docRef, {
        ...mod,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
    await batch.commit();
    console.log("[ModuleEntitlementEngine] Seeded 17 modules into platformConfig/moduleRegistry idempotently.");
  } catch (err) {
    console.warn("[ModuleEntitlementEngine] Error seeding module registry:", err);
  }
}

// Layer 1: Hard platform locks - NEVER togglable by Super Admin, always platform-admin-only
export const HARD_PLATFORM_LOCK_MODULES: string[] = [
  "platform-admin",
  "agc-super-admin",
  "lipila-payment-tracker",
  "audit-archive",
  "permissions",
  "mabala_consignment_hub_admin",
  "ai_crop_knowledge_admin",
  "agronomy-admin"
];

export interface ModuleDefinition {
  key: string;
  label: string;
  category: "Finance" | "Operations" | "Commercial" | "System";
}

export const ALL_ENTITLED_MODULES: ModuleDefinition[] = [
  // Financial & Ledger
  { key: "accounts", label: "Chart of Accounts", category: "Finance" },
  { key: "expenses", label: "Expenses Ledger", category: "Finance" },
  { key: "invoices", label: "Invoices & Quotations", category: "Finance" },
  { key: "sales", label: "Sales & Receipts", category: "Finance" },
  { key: "assets", label: "Asset Register & Depreciation", category: "Finance" },
  { key: "payroll", label: "Payroll & Employees", category: "Finance" },
  { key: "finance-hub", label: "Finance & Credit Hub", category: "Finance" },
  
  // Farm Operations
  { key: "crops", label: "Crops & Field Management", category: "Operations" },
  { key: "orchard-dashboard", label: "Orchard Management", category: "Operations" },
  { key: "livestock", label: "Livestock Registry", category: "Operations" },
  { key: "poultry", label: "Poultry Management", category: "Operations" },
  { key: "aquaculture", label: "Aquaculture Systems", category: "Operations" },
  { key: "inventory", label: "Inventory & Stockroom", category: "Operations" },

  // Commercial & Consignment
  { key: "marketplace", label: "Vendor Marketplace", category: "Commercial" },
  { key: "offtaker-marketplace", label: "Offtaker Marketplace", category: "Commercial" },
  { key: "agrodealer-consignment", label: "Agro-Dealer Consignment", category: "Commercial" },
  { key: "agc-farmer-hub", label: "AGC Farmer Credit Hub", category: "Commercial" },
  { key: "agc-dealer-pos", label: "Retail Shop View (POS)", category: "Commercial" },
  { key: "agc-financier-portal", label: "Supplier Portal View", category: "Commercial" },
  { key: "agrodealer-boost", label: "Agrodealer Boost Store", category: "Commercial" },
  { key: "sms-hub", label: "SMS Communications Hub", category: "Commercial" },
  { key: "sms-hub-group", label: "SMS Communications Hub", category: "Commercial" },
  
  // System & Utilities
  { key: "dashboard", label: "Farmer Workspace Dashboard", category: "System" },
  { key: "reports", label: "Reports & Analytics", category: "System" },
  { key: "profile", label: "Account Settings", category: "System" },
  { key: "settings", label: "Farm Node Settings & Configuration", category: "System" },
  { key: "farm-settings", label: "Farm Node Settings & Configuration", category: "System" },
  { key: "tax-settings", label: "Statutory Tax & Fiscal Directives", category: "System" },
  { key: "backup-restore", label: "Data Backup & Restore", category: "System" },
  { key: "billing-centre", label: "Billing Centre", category: "System" },
  { key: "offline-sync", label: "Offline Cache & Sync", category: "System" },
  { key: "partner-portal", label: "Partner Referral Portal", category: "System" }
];

// Layer 3: Per-tenant-type global defaults
export const DEFAULT_TENANT_TYPE_ENTITLEMENTS: Record<TenantTypeCode, Record<string, boolean>> = {
  super_admin: {
    "platform-admin": true,
    "agc-super-admin": true,
    "lipila-payment-tracker": true,
    "backup-restore": true,
    "audit-archive": true,
    "permissions": true,
    "dashboard": true,
    "accounts": true,
    "expenses": true,
    "invoices": true,
    "sales": true,
    "assets": true,
    "payroll": true,
    "finance-hub": true,
    "crops": true,
    "orchard-dashboard": true,
    "livestock": true,
    "poultry": true,
    "aquaculture": true,
    "inventory": true,
    "marketplace": true,
    "offtaker-marketplace": true,
    "agrodealer-consignment": true,
    "agc-farmer-hub": true,
    "agc-dealer-pos": true,
    "agc-financier-portal": true,
    "agrodealer-boost": true,
    "sms-hub": true,
    "sms-hub-group": true,
    "reports": true,
    "profile": true,
    "billing-centre": true,
    "offline-sync": true,
    "partner-portal": true,
    "institution-portal": true,
    "resellers": true,
    "farmer-wallet": true,
    "advisory-portal": true,
    "agronomy-admin": true,
    "hsw-dashboard": true,
    "hsw-dashboard-group": true,
    "fbi": true,
    "fbi-group": true,
    "agc-insurer-portal": true,
    "veterinary": true,
    "csv-import": true
  },
  farmer: {
    "dashboard": true,
    "crops": true,
    "orchard-dashboard": true,
    "livestock": true,
    "poultry": true,
    "aquaculture": true,
    "inventory": true,
    "accounts": true,
    "expenses": true,
    "invoices": true,
    "sales": true,
    "assets": true,
    "payroll": true,
    "finance-hub": true,
    "marketplace": true,
    "offtaker-marketplace": true,
    "agc-farmer-hub": true,
    "sms-hub": true,
    "sms-hub-group": true,
    "reports": true,
    "profile": true,
    "backup-restore": true,
    "billing-centre": true,
    "offline-sync": true,
    "agrodealer-boost": false,
    "partner-portal": false,
    "agrodealer-consignment": false,
    "agc-dealer-pos": false,
    "agc-financier-portal": false
  },
  agro_dealer: {
    "agc-dealer-pos": true,
    "agrodealer-consignment": true,
    "agrodealer-boost": true,
    "inventory": true,
    "sales": true,
    "invoices": true,
    "expenses": true,
    "accounts": true,
    "profile": true,
    "backup-restore": true,
    "reports": true,
    "billing-centre": true,
    "offline-sync": true,
    "marketplace": true,
    "payroll": true,
    "employees": true,
    "hr": true,
    "sms-hub": true,
    "sms-hub-group": true,
    "dashboard": false,
    "crops": false,
    "orchard-dashboard": false,
    "livestock": false,
    "poultry": false,
    "aquaculture": false,
    "finance-hub": false,
    "offtaker-marketplace": false,
    "agc-farmer-hub": false,
    "agc-financier-portal": false,
    "partner-portal": false
  },
  offtaker: {
    "offtaker-marketplace": true,
    "inventory": true,
    "sales": true,
    "invoices": true,
    "expenses": true,
    "accounts": true,
    "profile": true,
    "backup-restore": true,
    "reports": true,
    "billing-centre": true,
    "offline-sync": true,
    "payroll": true,
    "employees": true,
    "hr": true,
    "sms-hub": true,
    "sms-hub-group": true,
    "dashboard": false,
    "crops": false,
    "orchard-dashboard": false,
    "livestock": false,
    "poultry": false,
    "aquaculture": false,
    "finance-hub": false,
    "marketplace": false,
    "agc-farmer-hub": false,
    "agc-dealer-pos": false,
    "agc-financier-portal": false,
    "agrodealer-consignment": false,
    "agrodealer-boost": false,
    "partner-portal": false
  },
  mabala_partner: {
    "partner-portal": true,
    "inventory": true,
    "sales": true,
    "invoices": true,
    "reports": true,
    "profile": true,
    "backup-restore": true,
    "billing-centre": true,
    "offline-sync": true,
    "sms-hub": true,
    "sms-hub-group": true,
    "dashboard": false,
    "crops": false,
    "orchard-dashboard": false,
    "livestock": false,
    "poultry": false,
    "aquaculture": false,
    "payroll": false,
    "finance-hub": false,
    "marketplace": false,
    "offtaker-marketplace": false,
    "agc-farmer-hub": false,
    "agc-dealer-pos": false,
    "agc-financier-portal": false,
    "agrodealer-consignment": false,
    "agrodealer-boost": false
  },
  institution_supplier: {
    "agc-financier-portal": true,
    "agrodealer-consignment": true,
    "partner-portal": true,
    "inventory": true,
    "sales": true,
    "invoices": true,
    "reports": true,
    "profile": true,
    "backup-restore": true,
    "billing-centre": true,
    "offline-sync": true,
    "sms-hub": true,
    "sms-hub-group": true,
    "dashboard": false,
    "crops": false,
    "orchard-dashboard": false,
    "livestock": false,
    "poultry": false,
    "aquaculture": false,
    "payroll": false,
    "finance-hub": false,
    "marketplace": false,
    "offtaker-marketplace": false,
    "agc-farmer-hub": false,
    "agc-dealer-pos": false,
    "agrodealer-boost": false
  },
  agronomist: {
    "dashboard": true,
    "advisory-services": true,
    "crops": true,
    "orchard-dashboard": true,
    "reports": true,
    "profile": true,
    "backup-restore": true,
    "offline-sync": true,
    "sms-hub": true,
    "sms-hub-group": true,
    "billing-centre": false,
    "partner-portal": false,
    "agrodealer-consignment": false,
    "agc-dealer-pos": false,
    "agc-financier-portal": false
  }
};

/**
 * Hard Invariant Enforcement:
 * agro_dealer tenants must NEVER be assignable the super_admin role, at any layer, under any condition.
 */
export function assertAgroDealerInvariant(tenantType: string, roleToAssign: string): void {
  const normType = (tenantType || "").toLowerCase();
  const normRole = (roleToAssign || "").toLowerCase();
  if (
    (normType === "agro_dealer" || normType === "agrodealer" || normType === "agro-dealer") &&
    (normRole === "super_admin" || normRole === "platform administrator" || normRole === "super admin" || normRole === "platform_admin")
  ) {
    throw new Error("HARD INVARIANT BREACH: Agro-Dealer tenants are strictly forbidden from being assigned the super_admin role at any layer under any condition.");
  }
}

export interface ResolvedModuleAccess {
  visible: boolean;
  read: boolean;
  write: boolean;
}

/**
 * Resolution function as specified:
 * Layer 1 — Hard platform lock always wins.
 * Checks eligibility for tenant type.
 * Layer 2 — per-tenant override.
 * Layer 3 — tenant-type global default.
 */
export function resolveModuleAccess(
  moduleId: string,
  tenantId: string,
  tenantType: TenantTypeCode,
  callerRole: "super_admin" | "tenant_user",
  registry?: Record<string, ModuleRegistryDoc>,
  globalEntitlements?: Record<string, { enabled?: boolean; read?: boolean; write?: boolean }>,
  tenantOverrides?: Record<string, { enabled?: boolean | null; read?: boolean | null; write?: boolean | null }>
): ResolvedModuleAccess {
  const normModuleId = MODULE_KEY_MAP[moduleId] || moduleId;
  const registryEntry = registry?.[normModuleId] || SEEDED_MODULE_REGISTRY_MAP[normModuleId];

  // Super Admin always has full universal access across all modules
  if (callerRole === "super_admin" || tenantType === "super_admin") {
    return { visible: true, read: true, write: true };
  }

  // Layer 1 — hard platform lock always wins, no exceptions
  if (HARD_PLATFORM_LOCK_MODULES.includes(moduleId) || HARD_PLATFORM_LOCK_MODULES.includes(normModuleId) || registryEntry?.hardLocked) {
    return { visible: false, read: false, write: false };
  }

  // Check eligibility for tenant type if entry exists in registry
  if (registryEntry && !registryEntry.eligibleTenantTypes.includes(tenantType)) {
    return { visible: false, read: false, write: false };
  }

  // Layer 2 — per-tenant override
  const override = tenantOverrides?.[normModuleId] || tenantOverrides?.[moduleId];
  if (override && override.enabled !== null && override.enabled !== undefined) {
    return {
      visible: override.enabled,
      read: override.enabled ? (override.read ?? true) : false,
      write: override.enabled ? (override.write ?? false) : false,
    };
  }

  // Layer 3 — tenant-type global default
  const globalSetting = globalEntitlements?.[normModuleId] || globalEntitlements?.[moduleId];
  if (globalSetting && globalSetting.enabled !== undefined) {
    return {
      visible: globalSetting.enabled,
      read: globalSetting.enabled ? (globalSetting.read ?? true) : false,
      write: globalSetting.enabled ? (globalSetting.write ?? false) : false,
    };
  }

  // Fallback check
  const isEntitled = isModuleEntitled(moduleId, tenantType);
  return {
    visible: isEntitled,
    read: isEntitled,
    write: isEntitled,
  };
}

/**
 * Evaluates module entitlement using 3-layer precedence:
 * 1. Hard platform locks (highest precedence)
 * 2. Per-tenant override
 * 3. Per-tenant-type global default
 */
export function isModuleEntitled(
  moduleKey: string,
  tenantType: TenantTypeCode,
  tenantOverrides?: Record<string, boolean>,
  typeDefaults?: Record<string, boolean>
): boolean {
  // Super Admin has universal entitlement to all modules across the platform
  if (tenantType === "super_admin") {
    return true;
  }

  // Layer 1: Hard platform locks (super_admin was already handled above)
  if (HARD_PLATFORM_LOCK_MODULES.includes(moduleKey)) {
    return false;
  }

  // Layer 2: Per-tenant override
  if (tenantOverrides && typeof tenantOverrides[moduleKey] === "boolean") {
    return tenantOverrides[moduleKey];
  }

  // Layer 3: Per-tenant-type global default
  if (typeDefaults && typeof typeDefaults[moduleKey] === "boolean") {
    return typeDefaults[moduleKey];
  }

  const baseDefault = DEFAULT_TENANT_TYPE_ENTITLEMENTS[tenantType];
  if (baseDefault && typeof baseDefault[moduleKey] === "boolean") {
    return baseDefault[moduleKey];
  }

  // Default allowed for non-locked modules if unspecified
  return true;
}

/**
 * Returns canonical Landing Workspace Shell for a given tenant type
 */
export function getLandingWorkspaceShell(tenantType: TenantTypeCode): string {
  switch (tenantType) {
    case "agro_dealer":
      return "agc-dealer-pos"; // Retail Shop View
    case "institution_supplier":
      return "agc-financier-portal"; // Supplier Portal View
    case "offtaker":
      return "offtaker-marketplace"; // Offtaker Portal View
    case "mabala_partner":
      return "partner-portal"; // Partner Portal View
    case "super_admin":
      return "dashboard"; // Super Admin landing defaults to dashboard with universal module access
    case "agronomist":
      return "advisory-portal"; // Advisory Services Module
    case "farmer":
    default:
      return "dashboard"; // Farmer Workspace
  }
}

/**
 * Maps legacy or user roles to canonical TenantTypeCode
 */
export function resolveCanonicalTenantType(rawRoleOrType?: string, email?: string): TenantTypeCode {
  const str = (rawRoleOrType || "").trim().toLowerCase();
  let userEmail = (email || "").trim().toLowerCase();
  if (!userEmail && typeof window !== "undefined") {
    try {
      if (auth?.currentUser?.email) {
        userEmail = auth.currentUser.email.trim().toLowerCase();
      } else {
        const cached = localStorage.getItem("mabala_user_profile");
        if (cached) {
          const parsed = JSON.parse(cached);
          if (parsed.email) userEmail = parsed.email.trim().toLowerCase();
        }
      }
    } catch (e) {}
  }

  // Farm Owner override for deepvaleyfarm
  if (userEmail === "deepvaleyfarm@gmail.com" || userEmail === "deepvalleyfarm@gmail.com") {
    return "farmer";
  }

  // Super Admin check
  if (
    userEmail === "support@mabala.cloud" ||
    userEmail === "shikasuli@gmail.com" ||
    SUPER_ADMIN_EMAILS.includes(userEmail) ||
    str === "super_admin" ||
    str === "super admin" ||
    str === "platform administrator" ||
    str === "platform_admin"
  ) {
    return "super_admin";
  }

  // Agronomist check
  if (
    str === "agronomist" ||
    str === "advisory" ||
    str === "agro_consultant" ||
    str === "crop agronomist" ||
    str === "field agronomist" ||
    str === "advisory_specialist" ||
    str === "advisory specialist" ||
    str.includes("agronomist") ||
    str.includes("advisory")
  ) {
    return "agronomist";
  }

  // Mabala Partner check (BEFORE generic supplier/partner strings)
  if (
    str === "mabala_partner" ||
    str === "mabala partner" ||
    str === "mabala-partner" ||
    str === "platform partner" ||
    str === "platform_partner" ||
    str === "partner" ||
    str === "partner_admin" ||
    str.includes("mabala_partner") ||
    str.includes("mabala partner") ||
    str.includes("platform partner")
  ) {
    return "mabala_partner";
  }

  // Agro Dealer check
  if (
    str === "agro_dealer" ||
    str === "agro dealer" ||
    str === "agrodealer" ||
    str === "agro-dealer" ||
    str === "retailer" ||
    str === "agro-vet specialist" ||
    str.includes("agro_dealer") ||
    str.includes("agro dealer") ||
    str.includes("agrodealer")
  ) {
    return "agro_dealer";
  }

  // Offtaker check
  if (
    str === "offtaker" ||
    str === "off-taker" ||
    str === "offtaker_admin" ||
    str === "commodity_buyer" ||
    str === "commodity buyer" ||
    str === "crop_buyer" ||
    str === "crop buyer" ||
    str.includes("offtaker") ||
    str.includes("off-taker")
  ) {
    return "offtaker";
  }

  // Institution Supplier & M&E Workspace check
  if (
    str === "institution_supplier" ||
    str === "institution supplier" ||
    str === "institutional supplier" ||
    str === "institutional m&e" ||
    str === "institutional_me" ||
    str === "institutional m&e workspace" ||
    str === "m&e officer" ||
    str === "m&e user" ||
    str === "m&e evaluator" ||
    str === "m&e" ||
    str === "supplier" ||
    str === "input supplier" ||
    str === "seed_chemical_company" ||
    str === "seed & chemical company" ||
    str === "institution_admin" ||
    str === "institution admin" ||
    str === "institution staff" ||
    str === "institution_staff" ||
    str === "seed company" ||
    str === "financier" ||
    str.includes("supplier") ||
    str.includes("institution_supplier") ||
    str.includes("institution supplier") ||
    str.includes("institutional supplier") ||
    str.includes("m&e")
  ) {
    return "institution_supplier";
  }

  // Inspect persistent local role map / profile registry / dealers & suppliers list if available in browser
  if (typeof window !== "undefined" && userEmail) {
    try {
      const meta = getPreProvisionedUserMetadata(userEmail);
      if (meta.isPreProvisioned && meta.tenantType) {
        return meta.tenantType;
      }
    } catch (e) {}
  }

  return "farmer";
}

import {
  getUserIdentityMetadata,
  UserIdentityMetadata
} from "./identityService";

export { getUserIdentityMetadata, type UserIdentityMetadata };

export type PreProvisionedUserMetadata = UserIdentityMetadata;

/**
 * Helper function to fetch pre-provisioned user metadata (delegates to getUserIdentityMetadata in identityService)
 */
export function getPreProvisionedUserMetadata(email?: string): PreProvisionedUserMetadata {
  return getUserIdentityMetadata(email);
}

export interface AuthClaims {
  role?: string;
  tenantType?: TenantTypeCode | string;
  email?: string;
}

export const WORKSPACE_SHELL_ROUTE_MAP: Record<string, string> = {
  "/platform-admin": "platform-admin",
  "/workspace/retail-shop": "agc-dealer-pos",
  "/workspace/supplier-portal": "agc-financier-portal",
  "/workspace/offtaker": "offtaker-marketplace",
  "/workspace/partner": "partner-portal",
  "/workspace/agronomist": "advisory-portal",
  "/workspace/farmer": "dashboard"
};

/**
 * Workspace isolation — post-login router function that reads AuthClaims (tenantType, role)
 * and hard-redirects to exactly one top-level workspace shell route:
 * - super_admin -> /platform-admin (support@mabala.cloud ONLY)
 * - agro_dealer -> /workspace/retail-shop
 * - institution_supplier -> /workspace/supplier-portal
 * - farmer -> /workspace/farmer
 * Throws Error for unrecognized tenant type to block login and alert Super Admin.
 */
export function resolveWorkspaceShell(claims: AuthClaims): string {
  const normEmail = (claims.email || auth?.currentUser?.email || "").trim().toLowerCase();
  const isSuperAdminEmail = normEmail === "support@mabala.cloud" || normEmail === "shikasuli@gmail.com" || SUPER_ADMIN_EMAILS.includes(normEmail);

  const normRole = (claims.role || "").toLowerCase();
  if (
    normRole === "super_admin" ||
    normRole === "super admin" ||
    normRole === "platform administrator" ||
    normRole === "platform_admin" ||
    normRole === "system_administrator"
  ) {
    // Super Admins land on standard farmer workspace with universal module access
    return "/workspace/farmer";
  }

  const normType = (claims.tenantType || "").toLowerCase();
  switch (normType) {
    case "super_admin":
    case "super-admin":
    case "super admin":
    case "platform_admin":
    case "platform-admin":
      return "/workspace/farmer";
    case "agro_dealer":
    case "agrodealer":
    case "agro-dealer":
    case "retailer":
      return "/workspace/retail-shop";
    case "institution_supplier":
    case "supplier":
    case "seed_chemical_company":
    case "seed_chemical":
    case "institution_admin":
    case "institution admin":
    case "seed company":
      return "/workspace/supplier-portal";
    case "offtaker":
    case "off-taker":
    case "offtaker_admin":
    case "commodity_buyer":
    case "crop_buyer":
      return "/workspace/offtaker";
    case "mabala_partner":
    case "mabala-partner":
    case "platform_partner":
    case "partner":
      return "/workspace/partner";
    case "agronomist":
    case "advisory":
      return "/workspace/agronomist";
    case "farmer":
    case "cooperative":
      return "/workspace/farmer";
    default:
      if (!normType || normType === "unknown" || normType === "undefined") {
        return "/workspace/farmer";
      }
      throw new Error(`Unrecognized tenant type '${claims.tenantType}' — block login, alert Super Admin`);
  }
}

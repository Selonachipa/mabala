import { db } from "../firebase";
import { doc, getDoc, setDoc, updateDoc, collection, getDocs, addDoc } from "firebase/firestore";

export interface LipilaFeeTier {
  id: string;
  minAmount: number;
  maxAmount: number | null; // null represents unbounded ("Above")
  charge: number;
}

export const DEFAULT_LIPILA_FEE_SCHEDULE: LipilaFeeTier[] = [
  { id: "tier-1", minAmount: 0.01, maxAmount: 150.00, charge: 5.00 },
  { id: "tier-2", minAmount: 151.00, maxAmount: 300.00, charge: 7.00 },
  { id: "tier-3", minAmount: 301.00, maxAmount: 500.00, charge: 14.00 },
  { id: "tier-4", minAmount: 501.00, maxAmount: 1000.00, charge: 21.00 },
  { id: "tier-5", minAmount: 1001.00, maxAmount: 3000.00, charge: 30.00 },
  { id: "tier-6", minAmount: 3001.00, maxAmount: 5000.00, charge: 42.00 },
  { id: "tier-7", minAmount: 5001.00, maxAmount: 10000.00, charge: 70.00 },
  { id: "tier-8", minAmount: 10000.00, maxAmount: 499999.00, charge: 100.00 },
  { id: "tier-9", minAmount: 500000.00, maxAmount: 1500000.00, charge: 150.00 },
  { id: "tier-10", minAmount: 1500000.01, maxAmount: null, charge: 200.00 }
];

export interface BulkDisbursementItem {
  id: string;
  batchId?: string;
  type: "third_party_payout" | "mabala_to_mabala";
  recipientName: string;
  recipientType: "mobile_money" | "bank";
  provider: string; // airtel | mtn | zamtel | bank name
  accountNumber: string;
  bankFields?: {
    swiftCode?: string;
    firstName?: string;
    lastName?: string;
    accountHolderName?: string;
    phoneNumber?: string;
    email?: string;
  };
  amount: number;
  lipilaFee: number;
  platformFeeShare: number;
  lipilaFeeTierApplied: string;
  referenceId: string;
  webhookId?: string;
  status: "pending" | "submitted" | "success" | "failed";
  lipilaErrorCode?: string;
  errorMessage?: string;
  retryCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface BulkDisbursementBatch {
  id: string;
  farmNodeId: string;
  sourceType: "payroll" | "csv" | "manual" | "single";
  payrollRunId?: string;
  initiatedByUid: string;
  narration: string;
  totalAmount: number;
  totalLipilaFees: number;
  platformFee: number;
  grandTotal: number;
  status: "draft" | "awaiting_auth" | "processing" | "completed" | "completed_with_failures" | "blocked_insufficient_balance";
  blockedReason?: "tenant" | "master" | null;
  createdAt: string;
  updatedAt: string;
  items?: BulkDisbursementItem[];
}

export interface InternalTransferRecord {
  id: string;
  type: "ledger_to_ledger" | "service_payment";
  purpose: "vendor_purchase" | "sms_topup" | "credit_topup" | "invoice_payment" | "subscription" | "general_transfer";
  senderLedgerId: string;
  recipientLedgerId: string;
  amount: number;
  narration?: string;
  status: "draft" | "awaiting_auth" | "completed" | "failed" | "blocked_insufficient_balance";
  blockedReason?: "tenant" | "master" | null;
  serviceActivated?: boolean;
  metadata?: Record<string, any>;
  approvedByUid?: string;
  approvedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DisbursementAuditLogEntry {
  id: string;
  batchId?: string;
  transferId?: string;
  itemId?: string;
  actorUid: string;
  action: string;
  detail: string;
  timestamp: string;
}

/**
 * Calculates tiered Lipila fee and platform fee share for an individual disbursement item.
 */
export function calculateItemFees(
  amount: number,
  type: "third_party_payout" | "mabala_to_mabala",
  schedule: LipilaFeeTier[] = DEFAULT_LIPILA_FEE_SCHEDULE
): { lipilaFee: number; platformFeeShare: number; tierLabel: string } {
  if (type === "mabala_to_mabala") {
    return { lipilaFee: 0, platformFeeShare: 0, tierLabel: "Free (Mabala Internal)" };
  }

  const cleanAmount = Number(amount) || 0;
  const matchedTier = schedule.find(
    (t) => cleanAmount >= t.minAmount && (t.maxAmount === null || cleanAmount <= t.maxAmount)
  );

  const lipilaFee = matchedTier ? matchedTier.charge : 10.00;
  // Platform fee share: 3.5% of the Lipila fee
  const platformFeeShare = Number((lipilaFee * 0.035).toFixed(2));
  const tierLabel = matchedTier
    ? `K${matchedTier.charge} (Tier: K${matchedTier.minAmount.toFixed(0)} - ${matchedTier.maxAmount ? 'K' + matchedTier.maxAmount.toFixed(0) : 'Above'})`
    : "Standard";

  return { lipilaFee, platformFeeShare, tierLabel };
}

/**
 * Two-step balance check enforcing tenant ledger isolation and pooled master wallet security.
 */
export function validateDisbursementBalance(
  tenantBalance: number,
  masterBalance: number,
  grandTotal: number
): { allowed: boolean; blockedReason: "tenant" | "master" | null; message: string } {
  // Step A: Tenant farm ledger check
  if (tenantBalance < grandTotal) {
    return {
      allowed: false,
      blockedReason: "tenant",
      message: "Insufficient farm balance"
    };
  }

  // Step B: Master pooled wallet check (Strict privacy: never expose pooled balance to tenant)
  if (masterBalance < grandTotal) {
    return {
      allowed: false,
      blockedReason: "master",
      message: "Disbursement temporarily unavailable, contact support"
    };
  }

  return {
    allowed: true,
    blockedReason: null,
    message: "Disbursement balance verified."
  };
}

/**
 * Super Admin tier schedule validation: ensures ascending, contiguous, non-overlapping, with last tier unbounded.
 */
export function validateFeeSchedule(tiers: LipilaFeeTier[]): { valid: boolean; error?: string } {
  if (!tiers || tiers.length === 0) {
    return { valid: false, error: "Fee schedule cannot be empty." };
  }

  for (let i = 0; i < tiers.length; i++) {
    const tier = tiers[i];
    if (tier.minAmount < 0 || tier.charge < 0) {
      return { valid: false, error: `Tier ${i + 1} contains negative values.` };
    }
    if (tier.maxAmount !== null && tier.maxAmount <= tier.minAmount) {
      return { valid: false, error: `Tier ${i + 1}: Max amount must be strictly greater than min amount.` };
    }
    if (i > 0) {
      const prevTier = tiers[i - 1];
      if (prevTier.maxAmount === null) {
        return { valid: false, error: `Tier ${i}: Previous tier is unbounded; cannot have subsequent tiers.` };
      }
      // Contiguous check with 0.01 tolerance
      const gap = Math.abs(tier.minAmount - prevTier.maxAmount);
      if (gap > 1.01 && tier.minAmount <= prevTier.maxAmount) {
        return { valid: false, error: `Tier ${i + 1} overlaps with tier ${i}.` };
      }
    }
  }

  const lastTier = tiers[tiers.length - 1];
  if (lastTier.maxAmount !== null) {
    return { valid: false, error: "The final tier must be unbounded (max amount set to 'Above' / null)." };
  }

  return { valid: true };
}

/**
 * Fetches the active Lipila fee schedule from Firestore config or fallback to defaults.
 */
export async function getLipilaFeeSchedule(): Promise<{ tiers: LipilaFeeTier[]; updatedByUid?: string; updatedAt?: string }> {
  try {
    const configDoc = await getDoc(doc(db, "platform_admin", "config"));
    if (configDoc.exists() && configDoc.data().lipilaFeeSchedule?.tiers) {
      return {
        tiers: configDoc.data().lipilaFeeSchedule.tiers,
        updatedByUid: configDoc.data().lipilaFeeSchedule.updatedByUid,
        updatedAt: configDoc.data().lipilaFeeSchedule.updatedAt
      };
    }
  } catch (err) {
    console.warn("[DisbursementService] Failed to load fee schedule from Firestore, using default:", err);
  }

  return { tiers: DEFAULT_LIPILA_FEE_SCHEDULE };
}

/**
 * Saves the platform Lipila fee schedule to Firestore and backend API.
 */
export async function saveLipilaFeeSchedule(
  tiers: LipilaFeeTier[], 
  updatedByUid: string
): Promise<{ success: boolean; error?: string }> {
  try {
    // 1. Sync to server API endpoint
    try {
      await fetch("/api/disbursements/admin/fee-schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tiers, updatedByUid })
      });
    } catch (apiErr) {
      console.warn("[DisbursementService] Server API fee sync warning:", apiErr);
    }

    // 2. Persist in Firestore platform_admin/config
    await setDoc(doc(db, "platform_admin", "config"), {
      lipilaFeeSchedule: {
        tiers,
        updatedByUid,
        updatedAt: new Date().toISOString()
      }
    }, { merge: true });

    return { success: true };
  } catch (err: any) {
    console.error("[DisbursementService] Failed to save fee schedule:", err);
    return { success: false, error: err.message || "Failed to persist fee schedule" };
  }
}

/**
 * Fetches the current platform Master Wallet counter from Firestore.
 */
export async function getMasterWalletBalance(): Promise<number> {
  try {
    const snap = await getDoc(doc(db, "platform_admin", "masterWallet"));
    if (snap.exists() && typeof snap.data().lipilaBalance === "number") {
      return snap.data().lipilaBalance;
    }
  } catch (err) {
    console.warn("[DisbursementService] Failed to fetch master wallet from Firestore:", err);
  }
  return 250000.00; // Sensible platform operational fallback
}

/**
 * Fetches farm node wallet balance from Firestore.
 */
export async function getFarmNodeWalletBalance(farmNodeId: string): Promise<number> {
  try {
    const snap = await getDoc(doc(db, "farm_nodes", farmNodeId, "wallet", "current"));
    if (snap.exists()) {
      const data = snap.data();
      if (typeof data.balance === "number") return data.balance;
      if (typeof data.ledgerBalance === "number") return data.ledgerBalance;
    }
    // Fallback: Check root farm_nodes/{farmNodeId}
    const rootSnap = await getDoc(doc(db, "farm_nodes", farmNodeId));
    if (rootSnap.exists() && typeof rootSnap.data().walletBalance === "number") {
      return rootSnap.data().walletBalance;
    }
  } catch (err) {
    console.warn("[DisbursementService] Failed to fetch farm node balance from Firestore:", err);
  }
  return 0.00;
}

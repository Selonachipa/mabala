import { db, isConfigured } from "../firebase";
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  query, 
  where 
} from "firebase/firestore";
import { 
  MakerCheckerApprovalRequest, 
  ApprovalActionType, 
  ApprovalStatus 
} from "../types";
import { safeLocalStorage as localStorage, safeParseJSON } from "../utils/safeStorage";
import { recordSubUserAuditLog } from "./auditLogService";

export interface SubmitApprovalInput {
  tenantId: string;
  tenantName: string;
  actionType: ApprovalActionType;
  entityType: string;
  entityId: string;
  entityTitle?: string;
  makerUid: string;
  makerEmail: string;
  makerName: string;
  makerRole: string;
  makerDepartment?: string;
  reason: string; // Mandatory justification
  originalPayload?: any;
  proposedPayload?: any;
  backupAdminEmail?: string;
}

export class ApprovalService {
  private static STORAGE_KEY = "mabala_maker_checker_requests";

  /**
   * Submits a state-changing operation to the Maker-Checker queue.
   */
  static async submitForApproval(input: SubmitApprovalInput): Promise<MakerCheckerApprovalRequest> {
    const cleanReason = (input.reason || "").trim();
    if (!cleanReason || cleanReason.length < 5) {
      throw new Error("Dual-Control Policy: A mandatory justification reason (min 5 characters) is required to propose this action.");
    }

    const cleanTenantId = input.tenantId || "TENANT-001";
    const requestId = `APR-${cleanTenantId}-${Date.now().toString().slice(-6)}`;

    const request: MakerCheckerApprovalRequest = {
      id: requestId,
      tenantId: cleanTenantId,
      tenantName: input.tenantName || "Enterprise Tenant",
      actionType: input.actionType,
      entityType: input.entityType,
      entityId: input.entityId,
      entityTitle: input.entityTitle || `${input.actionType} on ${input.entityType}`,
      makerUid: input.makerUid || "maker-user",
      makerEmail: input.makerEmail.toLowerCase().trim(),
      makerName: input.makerName || "Staff Member",
      makerRole: input.makerRole || "User",
      makerDepartment: input.makerDepartment || "Operations",
      reason: cleanReason,
      originalPayload: input.originalPayload,
      proposedPayload: input.proposedPayload,
      status: "PENDING",
      backupAdminEmail: input.backupAdminEmail?.toLowerCase().trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // 1. Write to Firestore
    if (isConfigured) {
      try {
        await setDoc(doc(db, "tenants", cleanTenantId, "approval_requests", requestId), request, { merge: true });
      } catch (err) {
        console.warn("[ApprovalService] Error saving approval request to Firestore:", err);
      }
    }

    // 2. Write to Local Storage
    if (typeof window !== "undefined") {
      try {
        const storedStr = localStorage.getItem(this.STORAGE_KEY) || "[]";
        const list: MakerCheckerApprovalRequest[] = safeParseJSON(storedStr, []);
        list.unshift(request);
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(list));
      } catch (err) {
        console.warn("[ApprovalService] Error saving approval request to localStorage:", err);
      }
    }

    // 3. Record Audit Log
    await recordSubUserAuditLog({
      tenantId: cleanTenantId,
      action: "MAKER_SUBMIT_APPROVAL",
      actorUid: input.makerUid,
      actorEmail: input.makerEmail,
      actorName: input.makerName,
      module: "Dual-Control Approvals",
      record: requestId,
      detail: `[Maker-Checker] ${input.makerName} (${input.makerEmail}) submitted ${input.actionType} for ${input.entityType} [${input.entityId}]. Justification: "${cleanReason}".`,
      details: {
        requestId,
        actionType: input.actionType,
        entityType: input.entityType,
        reason: cleanReason,
        proposedPayload: input.proposedPayload
      }
    });

    return request;
  }

  /**
   * Fetches all approval requests for a specific tenant or all (for super admin).
   */
  static async getApprovalRequests(tenantId?: string): Promise<MakerCheckerApprovalRequest[]> {
    let requests: MakerCheckerApprovalRequest[] = [];

    // 1. Fetch from Firestore
    if (isConfigured && typeof window !== "undefined" && window.navigator.onLine) {
      try {
        if (tenantId) {
          const colRef = collection(db, "tenants", tenantId, "approval_requests");
          const snap = await getDocs(colRef);
          snap.forEach(d => requests.push({ ...d.data() as any, id: d.id }));
        }
      } catch (err) {
        console.warn("[ApprovalService] Error fetching requests from Firestore:", err);
      }
    }

    // 2. Fetch from Local Storage
    if (typeof window !== "undefined") {
      try {
        const storedStr = localStorage.getItem(this.STORAGE_KEY) || "[]";
        const localList: MakerCheckerApprovalRequest[] = safeParseJSON(storedStr, []);
        const map = new Map<string, MakerCheckerApprovalRequest>();
        requests.forEach(r => map.set(r.id, r));
        localList.forEach(r => {
          if (!map.has(r.id)) map.set(r.id, r);
        });
        requests = Array.from(map.values());
      } catch (err) {
        console.warn("[ApprovalService] Error parsing local approval requests:", err);
      }
    }

    // Filter by tenant if provided
    if (tenantId && tenantId !== "ALL" && tenantId !== "platform-admin") {
      requests = requests.filter(r => r.tenantId === tenantId);
    }

    // Sort by createdAt descending
    return requests.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  /**
   * Checker approves a pending request.
   * Zero-Self-Approval constraint: Maker cannot approve their own request unless escalated to Super Admin.
   */
  static async approveRequest(
    requestId: string,
    checker: { uid: string; email: string; name: string; role: string; isSuperAdmin?: boolean },
    reviewNotes?: string
  ): Promise<MakerCheckerApprovalRequest> {
    const allRequests = await this.getApprovalRequests();
    const req = allRequests.find(r => r.id === requestId);
    if (!req) throw new Error(`Approval request ${requestId} not found.`);

    if (req.status !== "PENDING") {
      throw new Error(`Request ${requestId} is already ${req.status}.`);
    }

    // Zero-Self-Approval Enforced
    const cleanCheckerEmail = (checker.email || "").toLowerCase().trim();
    const isMaker = cleanCheckerEmail === req.makerEmail.toLowerCase().trim();

    if (isMaker && !checker.isSuperAdmin) {
      throw new Error("Zero Self-Approval Violation: You cannot approve your own request. Another Administrator, Supervisor, or Backup Admin must act as the Checker.");
    }

    const updated: MakerCheckerApprovalRequest = {
      ...req,
      status: "APPROVED",
      checkerUid: checker.uid,
      checkerEmail: cleanCheckerEmail,
      checkerName: checker.name,
      checkerRole: checker.role,
      reviewNotes: reviewNotes?.trim() || "Approved under Maker-Checker verification.",
      reviewedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // 1. Update Firestore
    if (isConfigured) {
      try {
        await setDoc(doc(db, "tenants", req.tenantId, "approval_requests", requestId), updated, { merge: true });
      } catch (err) {
        console.warn("[ApprovalService] Error updating approval in Firestore:", err);
      }
    }

    // 2. Update Local Storage
    if (typeof window !== "undefined") {
      try {
        const storedStr = localStorage.getItem(this.STORAGE_KEY) || "[]";
        const list: MakerCheckerApprovalRequest[] = safeParseJSON(storedStr, []);
        const idx = list.findIndex(r => r.id === requestId);
        if (idx !== -1) {
          list[idx] = updated;
        } else {
          list.unshift(updated);
        }
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(list));
      } catch (err) {
        console.warn("[ApprovalService] Error updating local approval request:", err);
      }
    }

    // 3. Record Immutable Audit Log
    await recordSubUserAuditLog({
      tenantId: req.tenantId,
      action: "CHECKER_APPROVE_REQUEST",
      actorUid: checker.uid,
      actorEmail: cleanCheckerEmail,
      actorName: checker.name,
      module: "Dual-Control Approvals",
      record: requestId,
      detail: `[Maker-Checker APPROVED] ${checker.name} (${cleanCheckerEmail}) approved ${req.actionType} on ${req.entityType} [${req.entityId}]. Maker: ${req.makerName} (${req.makerEmail}). Notes: "${reviewNotes || 'Approved'}".`,
      details: {
        requestId,
        actionType: req.actionType,
        entityType: req.entityType,
        maker: req.makerEmail,
        checker: cleanCheckerEmail,
        reviewNotes
      }
    });

    return updated;
  }

  /**
   * Checker rejects a pending request.
   */
  static async rejectRequest(
    requestId: string,
    checker: { uid: string; email: string; name: string; role: string; isSuperAdmin?: boolean },
    reviewNotes: string
  ): Promise<MakerCheckerApprovalRequest> {
    const cleanNotes = (reviewNotes || "").trim();
    if (!cleanNotes || cleanNotes.length < 5) {
      throw new Error("A rejection comment (minimum 5 characters) explaining the reason is required.");
    }

    const allRequests = await this.getApprovalRequests();
    const req = allRequests.find(r => r.id === requestId);
    if (!req) throw new Error(`Approval request ${requestId} not found.`);

    if (req.status !== "PENDING") {
      throw new Error(`Request ${requestId} is already ${req.status}.`);
    }

    const cleanCheckerEmail = (checker.email || "").toLowerCase().trim();

    const updated: MakerCheckerApprovalRequest = {
      ...req,
      status: "REJECTED",
      checkerUid: checker.uid,
      checkerEmail: cleanCheckerEmail,
      checkerName: checker.name,
      checkerRole: checker.role,
      reviewNotes: cleanNotes,
      reviewedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // 1. Update Firestore
    if (isConfigured) {
      try {
        await setDoc(doc(db, "tenants", req.tenantId, "approval_requests", requestId), updated, { merge: true });
      } catch (err) {
        console.warn("[ApprovalService] Error updating approval in Firestore:", err);
      }
    }

    // 2. Update Local Storage
    if (typeof window !== "undefined") {
      try {
        const storedStr = localStorage.getItem(this.STORAGE_KEY) || "[]";
        const list: MakerCheckerApprovalRequest[] = safeParseJSON(storedStr, []);
        const idx = list.findIndex(r => r.id === requestId);
        if (idx !== -1) {
          list[idx] = updated;
        } else {
          list.unshift(updated);
        }
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(list));
      } catch (err) {
        console.warn("[ApprovalService] Error updating local approval request:", err);
      }
    }

    // 3. Record Immutable Audit Log
    await recordSubUserAuditLog({
      tenantId: req.tenantId,
      action: "CHECKER_REJECT_REQUEST",
      actorUid: checker.uid,
      actorEmail: cleanCheckerEmail,
      actorName: checker.name,
      module: "Dual-Control Approvals",
      record: requestId,
      detail: `[Maker-Checker REJECTED] ${checker.name} (${cleanCheckerEmail}) rejected ${req.actionType} on ${req.entityType} [${req.entityId}]. Maker: ${req.makerName} (${req.makerEmail}). Reason: "${cleanNotes}".`,
      details: {
        requestId,
        actionType: req.actionType,
        entityType: req.entityType,
        maker: req.makerEmail,
        checker: cleanCheckerEmail,
        reviewNotes: cleanNotes
      }
    });

    return updated;
  }
}

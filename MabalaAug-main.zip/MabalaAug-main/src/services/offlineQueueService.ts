// Service for durable, IndexedDB-backed Offline Queueing & Automatic Sync on Reconnect
import { safeLocalStorage } from "../utils/safeStorage";

export type OfflineActionType = 
  | "MODULE_WRITE" 
  | "WORKSPACE_FULL_SAVE" 
  | "QUICK_LOG_LOSS" 
  | "FINANCIAL_TRANSACTION" 
  | "LOG_POST_HARVEST_LOSS" 
  | "TASK_COMPLETION" 
  | "GENERIC_MUTATION";

export interface OfflineQueueItem {
  id: string;
  targetUid: string;
  actionType: OfflineActionType;
  priority: "high" | "normal";
  moduleKey?: string;
  payload: any;
  clientTimestamp: string; // Original client-side ISO timestamp
  createdTimestampMs: number;
  retryCount: number;
  lastError?: string;
  status: "pending" | "syncing" | "failed";
  summaryLabel?: string;
}

export function formatModuleName(item: OfflineQueueItem): string {
  if (item.moduleKey) {
    const keyMap: Record<string, string> = {
      expenses: "Expenses",
      expense: "Expenses",
      crops: "Crops",
      crop: "Crops",
      inventory: "Inventory",
      livestock: "Livestock",
      payroll: "Payroll",
      cash_sales: "Sales",
      sales: "Sales",
      farm_settings: "Farm Settings",
      settings: "Farm Settings",
      equipment: "Equipment & Assets",
      assets: "Equipment & Assets",
      water_irrigation: "Water & Irrigation",
      field_mappings: "Field Maps",
      fields: "Field Maps",
      suppliers: "Suppliers & Vendors",
      inspections: "Inspections",
      compliance: "Statutory Compliance",
      loss_records: "Post-Harvest Losses",
      financial_transactions: "Financial Transactions",
      tasks: "Tasks"
    };
    const lowerKey = item.moduleKey.toLowerCase().trim();
    if (keyMap[lowerKey]) return keyMap[lowerKey];

    return lowerKey
      .replace(/_/g, " ")
      .replace(/([a-z])([A-Z])/g, "$1 $2")
      .replace(/\b\w/g, c => c.toUpperCase());
  }

  if (item.summaryLabel) {
    const labelLower = item.summaryLabel.toLowerCase();
    if (labelLower.includes("expense")) return "Expenses";
    if (labelLower.includes("crop")) return "Crops";
    if (labelLower.includes("inventory")) return "Inventory";
    if (labelLower.includes("livestock")) return "Livestock";
    if (labelLower.includes("payroll") || labelLower.includes("employee")) return "Payroll";
    if (labelLower.includes("sale") || labelLower.includes("revenue")) return "Sales";
    if (labelLower.includes("setting") || labelLower.includes("statutory")) return "Farm Settings";
    if (labelLower.includes("loss") || labelLower.includes("harvest")) return "Post-Harvest Losses";
    if (labelLower.includes("task") || labelLower.includes("job")) return "Tasks";
    if (labelLower.includes("asset") || labelLower.includes("equipment")) return "Equipment & Assets";

    const cleaned = item.summaryLabel.replace(/^Offline\s+(Saved\s+)?(Module:\s*)?/i, "").trim();
    if (cleaned) {
      return cleaned
        .replace(/_/g, " ")
        .replace(/\b\w/g, c => c.toUpperCase());
    }
  }

  if (item.actionType === "QUICK_LOG_LOSS" || item.actionType === "LOG_POST_HARVEST_LOSS") {
    return "Post-Harvest Losses";
  }
  if (item.actionType === "FINANCIAL_TRANSACTION") {
    return "Expenses";
  }
  if (item.actionType === "TASK_COMPLETION") {
    return "Tasks";
  }

  return "Farm Data";
}

export interface SyncFailureLogEntry {
  id: string;
  queueItemId: string;
  summaryLabel: string;
  actionType: OfflineActionType;
  priority: "high" | "normal";
  moduleKey?: string;
  errorCode?: string;
  errorMessage: string;
  timestamp: string; // ISO when failure was recorded
  clientCapturedAt: string;
}

export interface OfflineQueueState {
  items: OfflineQueueItem[];
  pendingCount: number;
  isFlushing: boolean;
  failureLogs: SyncFailureLogEntry[];
  lastFlushResult: {
    successCount: number;
    failureCount: number;
    errors: string[];
    syncedModules?: string[];
    timestamp: string;
  } | null;
}

const DB_NAME = "Mabala_Offline_Persistence_DB";
const STORE_NAME = "offline_mutation_queue";
const DB_VERSION = 1;
const STORAGE_BACKUP_KEY = "mabala_offline_mutation_queue_backup";
const STORAGE_FAILURE_LOGS_KEY = "mabala_offline_sync_failure_logs";

type Listener = (state: OfflineQueueState) => void;

class OfflineQueueService {
  private dbPromise: Promise<IDBDatabase | null> | null = null;
  private memoryQueue: OfflineQueueItem[] = [];
  private failureLogs: SyncFailureLogEntry[] = [];
  private isFlushing = false;
  private listeners: Set<Listener> = new Set();
  private lastFlushResult: OfflineQueueState["lastFlushResult"] = null;

  constructor() {
    this.initDatabase();
    this.loadMemoryQueueFromLocalStorage();
    this.loadFailureLogs();
    this.pruneOldData();
  }

  private initDatabase(): Promise<IDBDatabase | null> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve) => {
      if (typeof window === "undefined" || !window.indexedDB) {
        console.warn("[OfflineQueue] IndexedDB unavailable in this environment, falling back to safeLocalStorage.");
        resolve(null);
        return;
      }

      try {
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            const store = db.createObjectStore(STORE_NAME, { keyPath: "id" });
            store.createIndex("createdTimestampMs", "createdTimestampMs", { unique: false });
            store.createIndex("targetUid", "targetUid", { unique: false });
            store.createIndex("priority", "priority", { unique: false });
          }
        };

        request.onsuccess = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          this.syncIndexedDBToMemory(db);
          resolve(db);
        };

        request.onerror = (err) => {
          console.warn("[OfflineQueue] IndexedDB open error, using safeLocalStorage fallback:", err);
          resolve(null);
        };
      } catch (e) {
        console.warn("[OfflineQueue] IndexedDB initialization exception:", e);
        resolve(null);
      }
    });

    return this.dbPromise;
  }

  private async syncIndexedDBToMemory(db: IDBDatabase) {
    try {
      const tx = db.transaction(STORE_NAME, "readonly");
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();

      req.onsuccess = () => {
        const idbItems: OfflineQueueItem[] = req.result || [];
        if (idbItems.length > 0) {
          this.memoryQueue = this.sortQueueItems(idbItems);
        } else {
          this.loadMemoryQueueFromLocalStorage();
        }
        this.pruneOldData();
        this.notifyListeners();
      };
    } catch (err) {
      console.warn("[OfflineQueue] Error reading from IndexedDB store:", err);
    }
  }

  private loadMemoryQueueFromLocalStorage() {
    try {
      const raw = safeLocalStorage.getItem(STORAGE_BACKUP_KEY);
      if (raw) {
        const parsed: OfflineQueueItem[] = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const existingIds = new Set(this.memoryQueue.map(i => i.id));
          parsed.forEach(item => {
            if (!existingIds.has(item.id)) {
              if (!item.priority) {
                item.priority = (item.actionType === "FINANCIAL_TRANSACTION" || item.actionType === "QUICK_LOG_LOSS" || item.actionType === "LOG_POST_HARVEST_LOSS") ? "high" : "normal";
              }
              this.memoryQueue.push(item);
            }
          });
          this.memoryQueue = this.sortQueueItems(this.memoryQueue);
        }
      }
    } catch (e) {
      console.warn("[OfflineQueue] Error parsing localStorage queue backup:", e);
    }
  }

  private loadFailureLogs() {
    try {
      const raw = safeLocalStorage.getItem(STORAGE_FAILURE_LOGS_KEY);
      if (raw) {
        const parsed: SyncFailureLogEntry[] = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          this.failureLogs = parsed;
        }
      }
    } catch (e) {
      console.warn("[OfflineQueue] Error loading failure logs:", e);
    }
  }

  private saveFailureLogs() {
    try {
      safeLocalStorage.setItem(STORAGE_FAILURE_LOGS_KEY, JSON.stringify(this.failureLogs));
    } catch (e) {
      console.warn("[OfflineQueue] Error saving failure logs:", e);
    }
  }

  /**
   * Sorts queue items prioritizing high-priority financial transactions first, then chronological order.
   */
  private sortQueueItems(items: OfflineQueueItem[]): OfflineQueueItem[] {
    return [...items].sort((a, b) => {
      if (a.priority === "high" && b.priority !== "high") return -1;
      if (a.priority !== "high" && b.priority === "high") return 1;
      return a.createdTimestampMs - b.createdTimestampMs;
    });
  }

  /**
   * Data Pruning Mechanism: Automatically cleans up failure logs and queue metadata older than 7 days.
   */
  public pruneOldData(maxAgeDays = 7) {
    const cutoffMs = Date.now() - (maxAgeDays * 24 * 60 * 60 * 1000);
    
    // Prune old failure logs
    const initialLogCount = this.failureLogs.length;
    this.failureLogs = this.failureLogs.filter(log => {
      const logTime = new Date(log.timestamp).getTime();
      return !isNaN(logTime) && logTime >= cutoffMs;
    });
    if (this.failureLogs.length !== initialLogCount) {
      console.log(`[OfflineQueue] Pruned ${initialLogCount - this.failureLogs.length} sync failure logs older than ${maxAgeDays} days.`);
      this.saveFailureLogs();
    }
  }

  private async persistQueue() {
    this.memoryQueue = this.sortQueueItems(this.memoryQueue);

    try {
      safeLocalStorage.setItem(STORAGE_BACKUP_KEY, JSON.stringify(this.memoryQueue));
    } catch (e) {
      console.warn("[OfflineQueue] Failed backing up to safeLocalStorage:", e);
    }

    try {
      const db = await this.initDatabase();
      if (db) {
        const tx = db.transaction(STORE_NAME, "readwrite");
        const store = tx.objectStore(STORE_NAME);
        store.clear();
        for (const item of this.memoryQueue) {
          store.put(item);
        }
      }
    } catch (err) {
      console.warn("[OfflineQueue] Failed persisting queue to IndexedDB:", err);
    }

    this.notifyListeners();
  }

  public subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    listener(this.getState());
    return () => {
      this.listeners.delete(listener);
    };
  }

  public getState(): OfflineQueueState {
    const pendingCount = this.memoryQueue.filter(i => i.status === "pending" || i.status === "failed").length;
    return {
      items: [...this.memoryQueue],
      pendingCount,
      isFlushing: this.isFlushing,
      failureLogs: [...this.failureLogs],
      lastFlushResult: this.lastFlushResult,
    };
  }

  private notifyListeners() {
    const state = this.getState();
    this.listeners.forEach(fn => fn(state));
  }

  /**
   * Enqueues a write operation to local durable storage immediately with high/normal priority.
   */
  public async enqueue(
    targetUid: string,
    actionType: OfflineActionType,
    payload: any,
    summaryLabel?: string,
    moduleKey?: string,
    customClientTimestamp?: string,
    customPriority?: "high" | "normal"
  ): Promise<OfflineQueueItem> {
    const now = Date.now();
    const clientTimestamp = customClientTimestamp || new Date(now).toISOString();

    // High priority is assigned by default to critical financial transactions and losses
    const priority = customPriority || (
      actionType === "FINANCIAL_TRANSACTION" || 
      actionType === "QUICK_LOG_LOSS" || 
      actionType === "LOG_POST_HARVEST_LOSS"
        ? "high" 
        : "normal"
    );

    const item: OfflineQueueItem = {
      id: `queue_${now}_${Math.random().toString(36).substring(2, 9)}`,
      targetUid,
      actionType,
      priority,
      moduleKey,
      payload,
      clientTimestamp,
      createdTimestampMs: now,
      retryCount: 0,
      status: "pending",
      summaryLabel: summaryLabel || `${actionType} ${moduleKey ? `[${moduleKey}]` : ""}`
    };

    if (actionType === "MODULE_WRITE" && moduleKey) {
      const existingIdx = this.memoryQueue.findIndex(
        q => q.targetUid === targetUid && q.actionType === "MODULE_WRITE" && q.moduleKey === moduleKey && q.status !== "syncing"
      );
      if (existingIdx >= 0) {
        this.memoryQueue[existingIdx].payload = payload;
        this.memoryQueue[existingIdx].clientTimestamp = clientTimestamp;
        this.memoryQueue[existingIdx].createdTimestampMs = now;
        this.memoryQueue[existingIdx].status = "pending";
        this.memoryQueue[existingIdx].priority = priority;
        console.log(`[OfflineQueue] Merged updated state into existing queue item for module "${moduleKey}"`);
        await this.persistQueue();
        return this.memoryQueue[existingIdx];
      }
    }

    this.memoryQueue.push(item);
    console.log(`[OfflineQueue] Enqueued offline write "${item.summaryLabel}" (Priority: ${priority}, Timestamp: ${clientTimestamp})`);
    await this.persistQueue();
    return item;
  }

  /**
   * Record a sync failure entry for troubleshooting
   */
  private recordFailureLog(item: OfflineQueueItem, errorMessage: string, errorCode?: string) {
    const failureEntry: SyncFailureLogEntry = {
      id: `fail_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      queueItemId: item.id,
      summaryLabel: item.summaryLabel || item.actionType,
      actionType: item.actionType,
      priority: item.priority,
      moduleKey: item.moduleKey,
      errorCode: errorCode || "SYNC_EXECUTION_FAILED",
      errorMessage,
      timestamp: new Date().toISOString(),
      clientCapturedAt: item.clientTimestamp
    };

    this.failureLogs.unshift(failureEntry);
    this.pruneOldData();
    this.saveFailureLogs();
  }

  /**
   * Force retries a single individual item immediately.
   */
  public async forceRetryItem(
    itemId: string,
    executor: (item: OfflineQueueItem) => Promise<boolean>
  ): Promise<boolean> {
    const item = this.memoryQueue.find(i => i.id === itemId);
    if (!item) return false;

    item.status = "syncing";
    this.notifyListeners();

    try {
      const success = await executor(item);
      if (success) {
        this.memoryQueue = this.memoryQueue.filter(i => i.id !== itemId);
        await this.persistQueue();
        return true;
      } else {
        item.status = "failed";
        item.retryCount += 1;
        item.lastError = "Manual forced retry returned false";
        this.recordFailureLog(item, item.lastError, "RETRY_FAILED");
        await this.persistQueue();
        return false;
      }
    } catch (err: any) {
      const msg = err?.message || String(err);
      item.status = "failed";
      item.retryCount += 1;
      item.lastError = msg;
      this.recordFailureLog(item, msg, err?.code || "RETRY_EXCEPTION");
      await this.persistQueue();
      return false;
    }
  }

  /**
   * Flushes the offline queue (high priority financial items first, then chronological).
   */
  public async flushQueue(
    executor: (item: OfflineQueueItem) => Promise<boolean>
  ): Promise<{ 
    successCount: number; 
    failureCount: number; 
    errors: string[];
    syncedItems: OfflineQueueItem[];
    syncedModules: string[];
  }> {
    if (this.isFlushing) {
      console.log("[OfflineQueue] Flush already in progress, skipping concurrent execution.");
      return { successCount: 0, failureCount: 0, errors: [], syncedItems: [], syncedModules: [] };
    }

    if (this.memoryQueue.length === 0) {
      return { successCount: 0, failureCount: 0, errors: [], syncedItems: [], syncedModules: [] };
    }

    this.isFlushing = true;
    this.notifyListeners();

    let successCount = 0;
    let failureCount = 0;
    const errors: string[] = [];
    const syncedItems: OfflineQueueItem[] = [];

    // Process high-priority items first, then normal priority
    const queueCopy = this.sortQueueItems(this.memoryQueue);

    for (const item of queueCopy) {
      item.status = "syncing";
      this.notifyListeners();

      try {
        const success = await executor(item);
        if (success) {
          successCount++;
          syncedItems.push(item);
          this.memoryQueue = this.memoryQueue.filter(q => q.id !== item.id);
          await this.persistQueue();
        } else {
          failureCount++;
          item.status = "failed";
          item.retryCount += 1;
          item.lastError = "Executor returned false/failed";
          this.recordFailureLog(item, item.lastError, "EXECUTOR_FALSE");
          errors.push(`Item ${item.summaryLabel || item.id} failed to sync.`);
          await this.persistQueue();
        }
      } catch (err: any) {
        failureCount++;
        item.status = "failed";
        item.retryCount += 1;
        item.lastError = err?.message || String(err);
        this.recordFailureLog(item, item.lastError, err?.code || "SYNC_EXCEPTION");
        errors.push(`Item ${item.summaryLabel || item.id}: ${item.lastError}`);
        await this.persistQueue();
      }
    }

    const syncedModules = Array.from(new Set(syncedItems.map(item => formatModuleName(item))));

    this.isFlushing = false;
    this.lastFlushResult = {
      successCount,
      failureCount,
      errors,
      syncedModules,
      timestamp: new Date().toISOString()
    };
    this.notifyListeners();

    return { successCount, failureCount, errors, syncedItems, syncedModules };
  }

  public clearFailureLogs() {
    this.failureLogs = [];
    this.saveFailureLogs();
    this.notifyListeners();
  }

  public removeQueueItem(id: string) {
    this.memoryQueue = this.memoryQueue.filter(i => i.id !== id);
    this.persistQueue();
  }

  public clearAll() {
    this.memoryQueue = [];
    this.persistQueue();
  }
}

export const offlineQueueService = new OfflineQueueService();

import { getFeeConfig } from "./feeConfigService";
import { db } from "../firebase";
import { collection, doc, setDoc, getDoc } from "firebase/firestore";
import { LipilaTransaction } from "../data/mockLipilaTransactions";
import { safeFetchJsonClient } from "../App";
import { normalizeZambianMobileNumber, isValidZambianMobileNumber, formatZambianMobileDisplay } from "../utils/phoneUtils";
import { creditOperationsLedger } from "./operationsLedgerService";

export interface WalletBalances {
  lipilaBalance: number; // Mobile Money Lipila Wallet (Account Code 1020)
  cashBalance: number;   // Cash on Hand / Bank (Account Code 1010)
  totalBalance: number;  // Combined Liquid Asset Balance
}

export interface OutboundFeeBreakdown {
  principal: number;
  lipilaFeePercent: number;
  lipilaFee: number;
  flatFee: number;
  totalDeducted: number;
}

export type SpendCategory = "payroll" | "invoice" | "marketplace" | "loan_repayment" | "platform_credits" | "subscription" | "sms_topup" | "payout_withdrawal";

const STORAGE_KEY_LIPILA = "mabala_lipila_wallet_balance";
const STORAGE_KEY_CASH = "mabala_cash_wallet_balance";
const STORAGE_KEY_TXS = "mabala_lipila_user_transactions";
const STORAGE_KEY_FINALIZED_REFS = "mabala_finalized_topup_refs";
const STORAGE_KEY_SMS = "mabala_sms_credits";
const STORAGE_KEY_SMS_BAL = "mabala_sms_balance";

// In-flight locking map to prevent concurrent executions from double-crediting
const inFlightFinalizations = new Map<string, Promise<{ success: boolean; tx: LipilaTransaction; newBalances: WalletBalances }>>();

function getFinalizedRefs(): Set<string> {
  const set = new Set<string>();
  try {
    const raw = localStorage.getItem(STORAGE_KEY_FINALIZED_REFS);
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) {
        arr.forEach(r => set.add(String(r)));
      }
    }
  } catch (_) {}
  return set;
}

function recordFinalizedRef(refId: string): void {
  try {
    const set = getFinalizedRefs();
    set.add(refId);
    localStorage.setItem(STORAGE_KEY_FINALIZED_REFS, JSON.stringify(Array.from(set)));
  } catch (_) {}
}

// Deduplicated, tenant-isolated transactions getter
export function getTransactionsForTenant(tenantId: string = "TENANT-001"): LipilaTransaction[] {
  try {
    let list: LipilaTransaction[] = [];
    const tenantStored = localStorage.getItem(`${STORAGE_KEY_TXS}_${tenantId}`);
    if (tenantStored) {
      try {
        list = JSON.parse(tenantStored);
      } catch (_) {}
    }

    if (!list || list.length === 0) {
      const globalStored = localStorage.getItem(STORAGE_KEY_TXS);
      if (globalStored) {
        try {
          const parsed: LipilaTransaction[] = JSON.parse(globalStored);
          list = parsed.filter(t => t.tenantId === tenantId || (!t.tenantId && (tenantId === "TENANT-001" || tenantId === "farm-1")));
        } catch (_) {}
      }
    }

    const uniqueMap = new Map<string, LipilaTransaction>();
    list.forEach(t => {
      const key = t.id || t.referenceId || `${t.createdAt}-${t.amount}`;
      if (!uniqueMap.has(key)) {
        uniqueMap.set(key, t);
      }
    });

    return Array.from(uniqueMap.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  } catch (e) {
    console.warn("[WalletService] getTransactionsForTenant error:", e);
    return [];
  }
}

// Self-healing ledger reconciler: computes true Lipila balance directly from unique itemized ledger transactions for a specific farm node
export function reconcileWalletBalancesFromLedger(tenantId: string = "TENANT-001"): WalletBalances {
  let netLipilaBalance = 0.00;
  let hasTransactions = false;

  try {
    const rawList = getTransactionsForTenant(tenantId);
    if (Array.isArray(rawList) && rawList.length > 0) {
      hasTransactions = true;

      rawList.forEach((tx) => {
        const status = String(tx.status || "").toUpperCase();
        if (status === "FAILED" || status === "REJECTED" || status === "DECLINED" || status === "ERROR") {
          return;
        }

        const isTopUp = 
          tx.paymentType === "Top-Up" || 
          tx.type === "Mobile Money Collection" || 
          tx.module === "Farmer Wallet Top-Up" ||
          tx.module === "Mabala Ledger Top-Up" ||
          tx.type === "Deposit";

        const isSpend = 
          tx.paymentType === "Disbursement" ||
          tx.type === "Mobile Money Disbursement" ||
          tx.type === "DDACC Loan Clearing Deduction" ||
          tx.module === "Payroll Disbursement" ||
          tx.module === "Platform Invoice Settlement" ||
          tx.module === "Agro-Dealer Input Purchase" ||
          tx.module === "AGC Agro Loan Repayment" ||
          tx.module === "DDACC Auto Loan Deduction";

        if (isTopUp) {
          // Principal amount strictly added once
          const amt = Number(tx.principalAmount ?? tx.amount ?? 0);
          netLipilaBalance += amt;
        } else if (isSpend) {
          // Total deducted amount subtracted once
          const amt = Number(tx.amount ?? tx.principalAmount ?? 0);
          netLipilaBalance -= amt;
        }
      });
    }
  } catch (err) {
    console.warn("[WalletService] Ledger reconciliation note:", err);
  }

  netLipilaBalance = Math.max(0, Number(netLipilaBalance.toFixed(2)));

  // Read cash balance for this node
  let cash = 0.00;
  try {
    const storedCash = localStorage.getItem(`${STORAGE_KEY_CASH}_${tenantId}`);
    if (storedCash !== null) {
      cash = Math.max(0, parseFloat(storedCash) || 0);
    } else if (tenantId === "TENANT-001" || tenantId === "farm-1") {
      const defaultCash = localStorage.getItem(STORAGE_KEY_CASH);
      if (defaultCash !== null) {
        cash = Math.max(0, parseFloat(defaultCash) || 0);
      }
    }
  } catch (_) {}

  // Persist the reconciled balance for this tenant node
  try {
    localStorage.setItem(`${STORAGE_KEY_LIPILA}_${tenantId}`, netLipilaBalance.toString());
    localStorage.setItem(`mabala_wallet_lipila_${tenantId}`, netLipilaBalance.toString());
    if (tenantId === "TENANT-001" || tenantId === "farm-1") {
      localStorage.setItem(STORAGE_KEY_LIPILA, netLipilaBalance.toString());
      localStorage.setItem("mabala_wallet_lipila", netLipilaBalance.toString());
    }
  } catch (_) {}

  return {
    lipilaBalance: Number(netLipilaBalance.toFixed(2)),
    cashBalance: Number(cash.toFixed(2)),
    totalBalance: Number((netLipilaBalance + cash).toFixed(2))
  };
}

// Zero-rate all local storage wallets, SMS balances, and clear transaction history
export function zeroRateAllPlatformWallets(tenantId?: string): WalletBalances {
  try {
    localStorage.setItem(STORAGE_KEY_LIPILA, "0");
    localStorage.setItem(STORAGE_KEY_CASH, "0");
    localStorage.setItem("mabala_wallet_lipila", "0");
    localStorage.setItem(STORAGE_KEY_SMS, "0");
    localStorage.setItem(STORAGE_KEY_SMS_BAL, "0");
    localStorage.setItem(STORAGE_KEY_TXS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEY_FINALIZED_REFS, JSON.stringify([]));
    localStorage.setItem("mabala_lipila_txs", JSON.stringify([]));
    localStorage.setItem("mabala_wallet_txs", JSON.stringify([]));

    if (tenantId) {
      localStorage.setItem(`${STORAGE_KEY_LIPILA}_${tenantId}`, "0");
      localStorage.setItem(`${STORAGE_KEY_CASH}_${tenantId}`, "0");
      localStorage.setItem(`mabala_wallet_lipila_${tenantId}`, "0");
      localStorage.setItem(`${STORAGE_KEY_SMS}_${tenantId}`, "0");
      localStorage.setItem(`${STORAGE_KEY_SMS_BAL}_${tenantId}`, "0");
    }

    // Clean any tenant-specific keys in localStorage
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        if (
          key.startsWith("mabala_lipila_wallet_balance") ||
          key.startsWith("mabala_cash_wallet_balance") ||
          key.startsWith("mabala_wallet_lipila") ||
          key.startsWith("mabala_sms_credits") ||
          key.startsWith("mabala_sms_balance")
        ) {
          localStorage.setItem(key, "0");
        }
      }
    }
  } catch (e) {
    console.warn("[WalletService] Zero-rate localStorage note:", e);
  }

  // Update Firestore if available
  if (db && tenantId) {
    try {
      setDoc(doc(db, "tenants", tenantId, "wallet", "credits"), {
        currentBalance: 0,
        balance: 0,
        smsCredits: 0,
        smsCreditBalance: 0,
        updatedAt: new Date().toISOString()
      }, { merge: true }).catch(() => {});

      setDoc(doc(db, "tenants", tenantId, "wallet", "sms"), {
        currentBalance: 0,
        balance: 0,
        updatedAt: new Date().toISOString()
      }, { merge: true }).catch(() => {});

      setDoc(doc(db, "users_data", tenantId), {
        smsCredits: 0,
        updatedAt: new Date().toISOString()
      }, { merge: true }).catch(() => {});

      setDoc(doc(db, "tenants", tenantId, "credit_wallet", "default"), {
        currentBalance: 0,
        balance: 0,
        updatedAt: new Date().toISOString()
      }, { merge: true }).catch(() => {});
    } catch (_) {}
  }

  // Broadcast wallet & SMS update
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("mabala_wallet_update", { detail: { tenantId } }));
    window.dispatchEvent(new CustomEvent("mabala_sms_update", { detail: { smsCredits: 0, tenantId } }));
    window.dispatchEvent(new Event("storage"));
  }

  return {
    lipilaBalance: 0.00,
    cashBalance: 0.00,
    totalBalance: 0.00
  };
}

// Dedicated helper to zero-rate all SMS balances
export function zeroRateAllSmsBalances(tenantId?: string): void {
  try {
    localStorage.setItem(STORAGE_KEY_SMS, "0");
    localStorage.setItem(STORAGE_KEY_SMS_BAL, "0");
    if (tenantId) {
      localStorage.setItem(`${STORAGE_KEY_SMS}_${tenantId}`, "0");
      localStorage.setItem(`${STORAGE_KEY_SMS_BAL}_${tenantId}`, "0");
    }
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith("mabala_sms_credits") || key.startsWith("mabala_sms_balance"))) {
        localStorage.setItem(key, "0");
      }
    }
  } catch (_) {}

  if (db && tenantId) {
    try {
      setDoc(doc(db, "users_data", tenantId), {
        smsCredits: 0,
        updatedAt: new Date().toISOString()
      }, { merge: true }).catch(() => {});
      setDoc(doc(db, "tenants", tenantId, "wallet", "sms"), {
        currentBalance: 0,
        balance: 0,
        updatedAt: new Date().toISOString()
      }, { merge: true }).catch(() => {});
    } catch (_) {}
  }

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("mabala_sms_update", { detail: { smsCredits: 0, tenantId } }));
    window.dispatchEvent(new Event("storage"));
  }
}

// Automatically enforce zero-rated platform baseline on module execution
try {
  if (typeof window !== "undefined" && !localStorage.getItem("mabala_zero_rate_applied_v1")) {
    zeroRateAllPlatformWallets();
    localStorage.setItem("mabala_zero_rate_applied_v1", "true");
  }
} catch (_) {}

// Helper to get stored balances (reconciled from itemized ledger transactions)
export function getWalletBalances(tenantId: string = "TENANT-001"): WalletBalances {
  return reconcileWalletBalancesFromLedger(tenantId);
}

// Calculate outbound fees dynamically using Super Admin fee configuration
export function calculateOutboundFee(principalAmount: number): OutboundFeeBreakdown {
  const safePrincipal = Math.max(0, Number(principalAmount) || 0);
  
  // Retrieve active fee rates from FeeConfigService
  const lipilaFeeConfig = getFeeConfig("disbursement_platform_fee");
  const flatFeeConfig = getFeeConfig("farm_wallet_outbound_flat");

  const lipilaFeePercent = (lipilaFeeConfig && lipilaFeeConfig.active) ? lipilaFeeConfig.value : 3.5;
  const flatFee = (flatFeeConfig && flatFeeConfig.active) ? flatFeeConfig.value : 3.0;

  const lipilaFee = Number((safePrincipal * (lipilaFeePercent / 100)).toFixed(2));
  const totalDeducted = Number((safePrincipal + lipilaFee + flatFee).toFixed(2));

  return {
    principal: safePrincipal,
    lipilaFeePercent,
    lipilaFee,
    flatFee,
    totalDeducted
  };
}

// Subscribe to wallet balance updates across UI
export function subscribeWalletUpdates(callback: (balances: WalletBalances) => void, tenantId: string = "TENANT-001"): () => void {
  const handler = (e?: any) => {
    const eventTenant = e?.detail?.tenantId;
    if (!eventTenant || eventTenant === tenantId || eventTenant === "TENANT-001" || tenantId === "TENANT-001") {
      callback(getWalletBalances(tenantId));
    }
  };

  window.addEventListener("mabala_wallet_update", handler);
  window.addEventListener("storage", handler);
  // Emit initial state
  callback(getWalletBalances(tenantId));

  return () => {
    window.removeEventListener("mabala_wallet_update", handler);
    window.removeEventListener("storage", handler);
  };
}

// Record a transaction locally and in Firestore
async function saveLipilaTransactionRecord(tx: LipilaTransaction): Promise<void> {
  const tenantId = tx.tenantId || "TENANT-001";
  try {
    // 1. Save to tenant-specific list
    let tenantTxs: LipilaTransaction[] = [];
    const tenantStored = localStorage.getItem(`${STORAGE_KEY_TXS}_${tenantId}`);
    if (tenantStored) {
      try {
        tenantTxs = JSON.parse(tenantStored);
      } catch (_) {}
    }
    tenantTxs = tenantTxs.filter(t => (t.id || t.referenceId) !== (tx.id || tx.referenceId));
    tenantTxs.unshift(tx);
    localStorage.setItem(`${STORAGE_KEY_TXS}_${tenantId}`, JSON.stringify(tenantTxs));

    // 2. Save to global list
    let localTxs: LipilaTransaction[] = [];
    const stored = localStorage.getItem(STORAGE_KEY_TXS);
    if (stored) {
      try {
        localTxs = JSON.parse(stored);
      } catch (_) {}
    }
    localTxs = localTxs.filter(t => (t.id || t.referenceId) !== (tx.id || tx.referenceId));
    localTxs.unshift(tx);
    localStorage.setItem(STORAGE_KEY_TXS, JSON.stringify(localTxs));
  } catch (e) {
    console.warn("[WalletService] LocalStorage tx save note:", e);
  }

  if (db) {
    try {
      await setDoc(doc(db, "lipilaTransactions", tx.id), tx);
      await setDoc(doc(db, "superAdmin", "lipilaTransactions", "records", tx.id), tx);
      if (tenantId) {
        await setDoc(doc(db, "tenants", tenantId, "walletTransactions", tx.id), tx).catch(() => {});
      }
    } catch (err) {
      console.warn("[WalletService] Firestore tx save note:", err);
    }
  }
}

// Initiate Top Up (Step 1: Collection request via Airtel / MTN / Zamtel MoMo without crediting balance)
export async function initiateTopUpWallet(params: {
  tenantId?: string;
  amount: number;
  provider: "Airtel Money" | "MTN MoMo" | "Zamtel Kwacha" | "Airtel" | "MTN" | "Zamtel";
  phone: string;
  accountName?: string;
  reference?: string;
}): Promise<{ referenceId: string; status: string; cleanPhone: string; amount: number }> {
  const topUpAmt = Math.max(1, Number(params.amount) || 0);

  const cleanPhone = normalizeZambianMobileNumber(params.phone);
  if (!cleanPhone || !isValidZambianMobileNumber(cleanPhone)) {
    throw new Error(`Invalid mobile number format: "${params.phone}". Please provide a valid Zambian mobile number (e.g. 0977344556, 096..., 095..., 077...).`);
  }

  // 1. Pre-check balance endpoint
  let checkBalRes: any = null;
  try {
    checkBalRes = await safeFetchJsonClient("/api/payments/check-balance", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        accountNumber: cleanPhone,
        requiredAmount: topUpAmt
      })
    });
  } catch (_) {}

  if (checkBalRes && checkBalRes.hasBalance === false) {
    throw new Error(checkBalRes.message || `Insufficient Mobile Money balance on account ${formatZambianMobileDisplay(cleanPhone)}. Transaction terminated.`);
  }

  // 2. Collect via production Lipila API
  const refId = params.reference || `ref-topup-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
  
  const collectRes = await safeFetchJsonClient("/api/payments/collect", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      referenceId: refId,
      amount: topUpAmt,
      narration: `Farmer Wallet MoMo Top-Up (+ZMW ${topUpAmt.toFixed(2)})`,
      accountNumber: cleanPhone,
      currency: "ZMW",
      email: "owner@mabala.com",
      packageName: "Farmer Wallet Top-Up",
      packageType: "wallet_topup"
    })
  });

  if (!collectRes || collectRes.status === "Failed" || collectRes.status === "Error" || collectRes.success === false) {
    const rawMsg = collectRes?.message || collectRes?.error || "";
    const cleanMsg = rawMsg.toLowerCase().includes("failed to fetch")
      ? "Unable to reach Lipila Payment Gateway. Please check your internet connection and try again."
      : rawMsg || "Lipila Mobile Money collection request failed. Please check your mobile number and account balance.";
    throw new Error(cleanMsg);
  }

  return {
    referenceId: collectRes.referenceId || refId,
    status: collectRes.status || "Pending",
    cleanPhone,
    amount: topUpAmt
  };
}

// Check status of pending top-up
export async function checkTopUpStatus(referenceId: string): Promise<{ status: string; message?: string }> {
  try {
    const res = await safeFetchJsonClient(`/api/payments/check-status?referenceId=${referenceId}`);
    return {
      status: res?.status || "Pending",
      message: res?.message || res?.error
    };
  } catch (err: any) {
    console.warn(`[walletService] checkTopUpStatus transient note:`, err.message);
    return { status: "Pending", message: "Payment status check in progress." };
  }
}

// Finalize Top Up (Step 2: Add funds to wallet ONLY AFTER PIN AUTHORIZATION is confirmed as Successful)
export async function finalizeTopUpWallet(params: {
  tenantId?: string;
  referenceId: string;
  amount: number;
  phone: string;
  provider: string;
  accountName?: string;
}): Promise<{ success: boolean; tx: LipilaTransaction; newBalances: WalletBalances }> {
  const tenantId = params.tenantId || "TENANT-001";
  const topUpAmt = Math.max(0, Number(params.amount) || 0);
  const refId = String(params.referenceId || "").trim();

  if (!refId) {
    throw new Error("Transaction referenceId is required to finalize wallet top-up.");
  }

  // 1. If this exact referenceId is already being finalized in-flight, return the existing promise
  if (inFlightFinalizations.has(refId)) {
    return await inFlightFinalizations.get(refId)!;
  }

  const finalizationPromise = (async () => {
    // 2. Check if this referenceId was already finalized in previous poll or session
    const finalizedRefs = getFinalizedRefs();
    let existingTx: LipilaTransaction | null = null;
    try {
      const stored = localStorage.getItem(STORAGE_KEY_TXS);
      if (stored) {
        const parsed: LipilaTransaction[] = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          existingTx = parsed.find(t => (t.id === refId || t.referenceId === refId)) || null;
        }
      }
    } catch (_) {}

    if (finalizedRefs.has(refId) || existingTx) {
      console.log(`[WalletService] Top-up ref ${refId} has already been credited. Bypassing duplicate credit.`);
      return {
        success: true,
        tx: existingTx || {
          id: refId,
          referenceId: refId,
          tenantId,
          type: "Mobile Money Collection",
          paymentType: "Top-Up",
          module: "Farmer Wallet Top-Up",
          amount: topUpAmt,
          principalAmount: topUpAmt,
          lipilaFeeAmount: 0,
          flatFeeAmount: 0,
          status: "COMPLETED",
          accountNumber: params.phone,
          customerName: params.accountName || "Farmer Node Top-Up",
          createdAt: new Date().toISOString()
        },
        newBalances: getWalletBalances(tenantId)
      };
    }

    // 3. Mark referenceId as finalized immediately
    recordFinalizedRef(refId);

    const normalizedProvider = params.provider.includes("Airtel") 
      ? "Airtel Money" 
      : params.provider.includes("MTN") 
      ? "MTN MoMo" 
      : "Zamtel Kwacha";

    const txRecord: LipilaTransaction = {
      id: refId,
      referenceId: refId,
      tenantId,
      type: "Mobile Money Collection",
      paymentType: "Top-Up",
      module: "Farmer Wallet Top-Up",
      amount: topUpAmt,
      principalAmount: topUpAmt,
      lipilaFeeAmount: 0,
      flatFeeAmount: 0,
      status: "COMPLETED",
      accountNumber: params.phone,
      customerName: params.accountName || "Farmer Node Top-Up",
      accountInfo: {
        walletName: params.accountName || "Farmer Wallet",
        walletCode: params.phone,
        provider: normalizedProvider
      },
      description: `Wallet MoMo Top-Up (+ZMW ${topUpAmt.toFixed(2)}) via ${normalizedProvider}`,
      createdAt: new Date().toISOString()
    };

    // Save transaction record to itemized ledger
    await saveLipilaTransactionRecord(txRecord);

    // Reconcile and calculate exact balance from ledger (guaranteeing exact single principal addition)
    const reconciledBalances = reconcileWalletBalancesFromLedger(tenantId);

    if (db) {
      try {
        await setDoc(doc(db, "tenants", tenantId, "wallet", "credits"), {
          currentBalance: reconciledBalances.lipilaBalance,
          updatedAt: new Date().toISOString()
        }, { merge: true });
      } catch (err) {}
    }

    // Notify components
    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("mabala_wallet_update", { detail: { tenantId } }));
      window.dispatchEvent(new Event("storage"));
    }

    return {
      success: true,
      tx: txRecord,
      newBalances: reconciledBalances
    };
  })();

  inFlightFinalizations.set(refId, finalizationPromise);
  try {
    return await finalizationPromise;
  } finally {
    inFlightFinalizations.delete(refId);
  }
}

// Legacy wrapper
export async function topUpWallet(params: {
  tenantId?: string;
  amount: number;
  provider: "Airtel Money" | "MTN MoMo" | "Zamtel Kwacha" | "Airtel" | "MTN" | "Zamtel";
  phone: string;
  accountName?: string;
  reference?: string;
}): Promise<{ success: boolean; tx: LipilaTransaction; newBalances: WalletBalances }> {
  const init = await initiateTopUpWallet(params);
  let status = init.status;
  
  if (status === "Pending" || status === "Processing") {
    let pollAttempts = 0;
    while (pollAttempts < 10 && (status === "Pending" || status === "Processing")) {
      await new Promise(r => setTimeout(r, 2000));
      pollAttempts++;
      const check = await checkTopUpStatus(init.referenceId);
      status = check.status;
      if (status === "Failed" || status === "Rejected" || status === "Error") {
        throw new Error(check.message || "Mobile Money PIN prompt rejected or expired.");
      }
    }
  }

  if (status === "Successful" || status === "Success" || status === "Completed") {
    return await finalizeTopUpWallet({
      tenantId: params.tenantId,
      referenceId: init.referenceId,
      amount: init.amount,
      phone: init.cleanPhone,
      provider: params.provider,
      accountName: params.accountName
    });
  } else {
    throw new Error("Mobile Money PIN authorization incomplete. Funds were not added to wallet balance.");
  }
}

// Outbound Spend Wallet (Payroll, Invoices, Marketplace, AGC Agro Loans)
export async function spendWallet(params: {
  tenantId?: string;
  amount: number;
  category: SpendCategory;
  description: string;
  referenceId?: string;
  recipientName?: string;
  recipientPhone?: string;
}): Promise<{ success: boolean; tx: LipilaTransaction; newBalances: WalletBalances; breakdown: OutboundFeeBreakdown }> {
  const tenantId = params.tenantId || "TENANT-001";
  const feeBreakdown = calculateOutboundFee(params.amount);

  const current = getWalletBalances(tenantId);

  if (current.lipilaBalance < feeBreakdown.totalDeducted) {
    throw new Error(
      `Insufficient Wallet Balance! Required: ZMW ${feeBreakdown.totalDeducted.toFixed(2)} (Principal: ZMW ${feeBreakdown.principal.toFixed(2)} + Lipila Fee: ZMW ${feeBreakdown.lipilaFee.toFixed(2)} + Flat Fee: ZMW ${feeBreakdown.flatFee.toFixed(2)}). Available Lipila Wallet Balance: ZMW ${current.lipilaBalance.toFixed(2)}.`
    );
  }

  const newLipilaBal = Number((current.lipilaBalance - feeBreakdown.totalDeducted).toFixed(2));

  // Persist updated balance
  try {
    localStorage.setItem(`${STORAGE_KEY_LIPILA}_${tenantId}`, newLipilaBal.toString());
    localStorage.setItem(`mabala_wallet_lipila_${tenantId}`, newLipilaBal.toString());
    if (tenantId === "TENANT-001" || tenantId === "farm-1") {
      localStorage.setItem(STORAGE_KEY_LIPILA, newLipilaBal.toString());
      localStorage.setItem("mabala_wallet_lipila", newLipilaBal.toString());
    }
  } catch (e) {}

  if (db) {
    try {
      await setDoc(doc(db, "tenants", tenantId, "wallet", "credits"), {
        currentBalance: newLipilaBal,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {}
  }

  const categoryLabels: Record<SpendCategory, string> = {
    payroll: "Payroll Disbursement",
    invoice: "Platform Invoice Settlement",
    marketplace: "Agro-Dealer Input Purchase",
    loan_repayment: "AGC Agro Loan Repayment",
    platform_credits: "Platform Credits Purchase",
    subscription: "Farm Subscription / Tier Renewal",
    sms_topup: "SMS Credits Top-Up",
    payout_withdrawal: "Farm Wallet Payout Request"
  };

  const txRecord: LipilaTransaction = {
    id: params.referenceId || `TX-SPEND-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    tenantId,
    type: "Mobile Money Disbursement",
    paymentType: "Disbursement",
    module: categoryLabels[params.category] || "Mabala Ledger Spend",
    amount: feeBreakdown.totalDeducted,
    principalAmount: feeBreakdown.principal,
    lipilaFeeAmount: feeBreakdown.lipilaFee,
    flatFeeAmount: feeBreakdown.flatFee,
    status: "COMPLETED",
    accountNumber: params.recipientPhone || "1020-FARM-WALLET",
    customerName: params.recipientName || "Farmer Node Spend",
    accountInfo: {
      walletName: params.recipientName || categoryLabels[params.category] || "Farmer Node",
      walletCode: params.recipientPhone || "1020"
    },
    description: `${params.description} | Principal: ZMW ${feeBreakdown.principal.toFixed(2)}, Lipila Fee (${feeBreakdown.lipilaFeePercent}%): ZMW ${feeBreakdown.lipilaFee.toFixed(2)}, Outbound Flat Fee: ZMW ${feeBreakdown.flatFee.toFixed(2)}`,
    createdAt: new Date().toISOString()
  };

  await saveLipilaTransactionRecord(txRecord);

  // Credit Super Admin Operations Ledger for fee collections
  const totalPlatformCollectionFee = (feeBreakdown.flatFee || 0) + (feeBreakdown.lipilaFee || 0);
  if (totalPlatformCollectionFee > 0) {
    try {
      await creditOperationsLedger({
        sourceTenantId: tenantId,
        sourceFarmName: params.recipientName || "Farm Node",
        category: "platform_collection_fee",
        amount: totalPlatformCollectionFee,
        referenceId: `OP-FEE-${txRecord.id}`,
        narration: `Platform Fee Collection on Spend (${categoryLabels[params.category] || "Spend"})`,
        metadata: {
          txId: txRecord.id,
          category: params.category,
          principal: feeBreakdown.principal,
          lipilaFee: feeBreakdown.lipilaFee,
          flatFee: feeBreakdown.flatFee
        }
      });
    } catch (e) {
      console.warn("[WalletService] Platform collection fee credit note:", e);
    }
  }

  // If this spend is for platform subscriptions, platform credits, or SMS topups, credit the Super Admin Operations Ledger!
  if (params.category === "platform_credits" || params.category === "subscription" || params.category === "sms_topup" || params.category === "invoice") {
    try {
      await creditOperationsLedger({
        sourceTenantId: tenantId,
        sourceFarmName: params.recipientName || "Farm Node",
        category: params.category === "invoice" ? "invoice_settlement" : params.category,
        amount: feeBreakdown.principal,
        referenceId: txRecord.id,
        narration: params.description,
        metadata: {
          totalDeducted: feeBreakdown.totalDeducted,
          lipilaFee: feeBreakdown.lipilaFee,
          flatFee: feeBreakdown.flatFee
        }
      });
    } catch (e) {
      console.warn("[WalletService] Operations Ledger credit note:", e);
    }
  }

  // Notify components
  window.dispatchEvent(new CustomEvent("mabala_wallet_update", { detail: { tenantId } }));

  return {
    success: true,
    tx: txRecord,
    newBalances: getWalletBalances(tenantId),
    breakdown: feeBreakdown
  };
}

// Credit a farm node's Mabala Farm Ledger directly (e.g. from Vendor Portal sales, refunds, or manual credit)
export async function creditFarmLedger(params: {
  tenantId: string;
  amount: number;
  category?: string;
  description: string;
  referenceId?: string;
  senderName?: string;
  senderPhone?: string;
}): Promise<{ success: boolean; tx: LipilaTransaction; newBalances: WalletBalances }> {
  const tenantId = params.tenantId || "TENANT-001";
  const amount = Math.max(0, Number(params.amount) || 0);
  const refId = params.referenceId || `TX-CREDIT-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

  const txRecord: LipilaTransaction = {
    id: refId,
    referenceId: refId,
    tenantId,
    type: "Deposit",
    paymentType: "Top-Up",
    module: params.category || "Vendor Sales Credit",
    amount: amount,
    principalAmount: amount,
    lipilaFeeAmount: 0,
    flatFeeAmount: 0,
    status: "COMPLETED",
    accountNumber: params.senderPhone || "1020-MABALA-LEDGER",
    customerName: params.senderName || "Vendor Marketplace Sales",
    accountInfo: {
      walletName: params.senderName || "Mabala Marketplace Checkout",
      walletCode: params.senderPhone || "1020",
      provider: "Mabala Ledger"
    },
    description: params.description || `Mabala Farm Ledger Credit (+ZMW ${amount.toFixed(2)})`,
    createdAt: new Date().toISOString()
  };

  await saveLipilaTransactionRecord(txRecord);
  const newBalances = reconcileWalletBalancesFromLedger(tenantId);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("mabala_wallet_update", { detail: { tenantId } }));
    window.dispatchEvent(new Event("storage"));
  }

  return {
    success: true,
    tx: txRecord,
    newBalances
  };
}

// Direct Debit from Farm Ledger (e.g. for Payout Requests or Payroll Disbursement deductions)
export async function debitFarmLedger(params: {
  tenantId: string;
  amount: number;
  category?: string;
  description: string;
  referenceId?: string;
  recipientName?: string;
  recipientPhone?: string;
}): Promise<{ success: boolean; tx: LipilaTransaction; newBalances: WalletBalances }> {
  const tenantId = params.tenantId || "TENANT-001";
  const amount = Math.max(0, Number(params.amount) || 0);
  const current = getWalletBalances(tenantId);

  if (current.lipilaBalance < amount) {
    throw new Error(
      `Insufficient Mabala Farm Ledger Balance! Required: ZMW ${amount.toFixed(2)}, Available: ZMW ${current.lipilaBalance.toFixed(2)}.`
    );
  }

  const refId = params.referenceId || `TX-DEBIT-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

  const txRecord: LipilaTransaction = {
    id: refId,
    referenceId: refId,
    tenantId,
    type: "Mobile Money Disbursement",
    paymentType: "Disbursement",
    module: params.category || "Mabala Ledger Debit",
    amount: amount,
    principalAmount: amount,
    lipilaFeeAmount: 0,
    flatFeeAmount: 0,
    status: "COMPLETED",
    accountNumber: params.recipientPhone || "1020-FARM-LEDGER",
    customerName: params.recipientName || "Mabala Farm Node",
    accountInfo: {
      walletName: params.recipientName || "Mabala Farm Ledger",
      walletCode: params.recipientPhone || "1020"
    },
    description: params.description || `Mabala Farm Ledger Debit (-ZMW ${amount.toFixed(2)})`,
    createdAt: new Date().toISOString()
  };

  await saveLipilaTransactionRecord(txRecord);
  const newBalances = reconcileWalletBalancesFromLedger(tenantId);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("mabala_wallet_update", { detail: { tenantId } }));
    window.dispatchEvent(new Event("storage"));
  }

  return {
    success: true,
    tx: txRecord,
    newBalances
  };
}


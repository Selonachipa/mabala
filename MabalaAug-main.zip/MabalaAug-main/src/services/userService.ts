import { db, isConfigured } from "../firebase";
import { safeLocalStorage as localStorage, safeParseJSON } from "../utils/safeStorage";
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  deleteDoc, 
  query, 
  where 
} from "firebase/firestore";
import { UserMember, PredefinedRole, RolePermissions, AuditLog } from "../types";

export interface CreateNodeUserInput {
  name: string;
  email: string;
  password?: string;
  role: PredefinedRole;
  permittedModules: string[];
  modulePermissions?: RolePermissions;
  farmId: string;
  farmName: string;
  mustChangePassword?: boolean;
}

export class UserService {
  private static STORAGE_KEY_PREFIX = "mabala_node_users_";

  /**
   * Generates a persistent local storage key scoped by tenant
   */
  private static getStorageKey(tenantId: string): string {
    return `${this.STORAGE_KEY_PREFIX}${tenantId || "default"}`;
  }

  /**
   * Fetches all users attached to a specific farm node / tenant workspace.
   */
  static async getFarmNodeUsers(tenantId: string): Promise<UserMember[]> {
    const cleanTenantId = (tenantId || "").trim();
    if (!cleanTenantId) return [];

    let users: UserMember[] = [];

    // 1. Try fetching from Cloud Firestore
    if (isConfigured && typeof window !== "undefined" && window.navigator.onLine) {
      try {
        const usersColRef = collection(db, "tenants", cleanTenantId, "node_users");
        const snap = await getDocs(usersColRef);
        if (!snap.empty) {
          snap.forEach(d => {
            const data = d.data() as UserMember;
            users.push({
              ...data,
              id: d.id,
              tenantId: cleanTenantId
            });
          });
        }

        // Also query global users collection scoped to this tenant
        if (users.length === 0) {
          const globalUsersCol = collection(db, "users");
          const q = query(globalUsersCol, where("tenantId", "==", cleanTenantId));
          const gSnap = await getDocs(q);
          gSnap.forEach(d => {
            const data = d.data() as UserMember;
            users.push({
              ...data,
              id: d.id,
              tenantId: cleanTenantId
            });
          });
        }
      } catch (err) {
        console.warn("[UserService] Error fetching farm node users from Firestore:", err);
      }
    }

    // 2. Merge with local storage cache
    if (typeof window !== "undefined") {
      try {
        const localData = localStorage.getItem(this.getStorageKey(cleanTenantId));
        if (localData) {
          const parsed: UserMember[] = JSON.parse(localData);
          if (Array.isArray(parsed)) {
            const userMap = new Map<string, UserMember>();
            // Add cloud users first
            users.forEach(u => userMap.set(u.email.toLowerCase(), u));
            // Supplement or merge local
            parsed.forEach(u => {
              const emailKey = u.email.toLowerCase();
              if (!userMap.has(emailKey)) {
                userMap.set(emailKey, u);
              } else {
                // Merge permissions and status
                const existing = userMap.get(emailKey)!;
                userMap.set(emailKey, { ...existing, ...u });
              }
            });
            users = Array.from(userMap.values());
          }
        }
      } catch (e) {
        console.warn("[UserService] Error reading local user cache:", e);
      }
    }

    // 3. Ensure default farm node members including deepvaleyfarm@gmail.com are always present
    const defaultEssentialUsers: UserMember[] = [
      { id: "M0", name: "Mabala Super Admin", email: "support@mabala.cloud", role: "Super Admin", lastActive: "Just now", status: "Active", password: "Password123!" },
      { id: "M3", name: "Mary Banda", email: "mary@mabala.com", role: "Farm Owner", lastActive: "Just now", status: "Active", password: "Password123!" },
      { id: "M4", name: "Deep Valley Farms", email: "deepvaleyfarm@gmail.com", role: "Farm Owner", lastActive: "Just now", status: "Active", password: "Zoiechibeka@2005" }
    ];

    const currentMap = new Map<string, UserMember>();
    users.forEach(u => currentMap.set(u.email.toLowerCase(), u));
    defaultEssentialUsers.forEach(u => {
      if (!currentMap.has(u.email.toLowerCase())) {
        currentMap.set(u.email.toLowerCase(), { ...u, tenantId: cleanTenantId });
      }
    });
    users = Array.from(currentMap.values());

    // Cache updated list locally
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem(this.getStorageKey(cleanTenantId), JSON.stringify(users));
      } catch (_) {}
    }

    return users;
  }

  /**
   * Farm owner creates a new user profile on their farm node with scoped credentials and module toggles.
   */
  static async createFarmNodeUser(
    tenantId: string,
    creatorEmail: string,
    input: CreateNodeUserInput
  ): Promise<UserMember> {
    const cleanTenantId = (tenantId || "").trim();
    const cleanEmail = input.email.trim().toLowerCase();

    if (!cleanTenantId) throw new Error("Farm workspace tenant ID is required.");
    if (!input.name.trim()) throw new Error("Full name is required.");
    if (!cleanEmail) throw new Error("Email address is required.");
    if (!input.password || input.password.length < 6) {
      throw new Error("Password must be at least 6 characters long.");
    }

    const newUser: UserMember = {
      id: `usr_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      name: input.name.trim(),
      email: cleanEmail,
      role: input.role,
      status: "Active",
      isSuspended: false,
      password: input.password,
      tenantId: cleanTenantId,
      farmId: input.farmId,
      farmName: input.farmName,
      accessibleFarmIds: [input.farmId],
      permittedModules: input.permittedModules || [],
      modulePermissions: input.modulePermissions,
      mustChangePassword: input.mustChangePassword !== undefined ? input.mustChangePassword : true,
      forcePasswordChange: input.mustChangePassword !== undefined ? input.mustChangePassword : true,
      createdBy: creatorEmail,
      createdAt: new Date().toISOString(),
      lastActive: "Never"
    };

    // 1. Save to Firestore in tenant subcollection and root lookup collection
    if (isConfigured) {
      try {
        // Under tenant's subcollection
        const nodeUserDocRef = doc(db, "tenants", cleanTenantId, "node_users", cleanEmail);
        await setDoc(nodeUserDocRef, newUser, { merge: true });

        // Under root user accounts for single authentication lookup
        const rootUserDocRef = doc(db, "users", cleanEmail);
        await setDoc(rootUserDocRef, {
          ...newUser,
          isNodeUser: true
        }, { merge: true });

        console.log(`[UserService] Successfully provisioned user "${cleanEmail}" in Firestore for tenant "${cleanTenantId}".`);
      } catch (err) {
        console.warn("[UserService] Warning saving node user to Firestore:", err);
      }
    }

    // 2. Update local caches and registries
    if (typeof window !== "undefined") {
      try {
        // Scoped tenant cache
        const key = this.getStorageKey(cleanTenantId);
        const existingStr = localStorage.getItem(key);
        const existing: UserMember[] = existingStr ? JSON.parse(existingStr) : [];
        const filtered = existing.filter(u => u.email.toLowerCase() !== cleanEmail);
        filtered.push(newUser);
        localStorage.setItem(key, JSON.stringify(filtered));

        // Global registered roles map
        const roleMapStr = localStorage.getItem("mabala_registered_roles_map") || "{}";
        const roleMap = JSON.parse(roleMapStr);
        roleMap[cleanEmail] = {
          role: newUser.role,
          tenantType: "farmer",
          tenantId: cleanTenantId,
          farmId: input.farmId,
          permittedModules: newUser.permittedModules,
          status: newUser.status,
          isSuspended: false
        };
        localStorage.setItem("mabala_registered_roles_map", JSON.stringify(roleMap));

        // User passwords cache
        const passDict = JSON.parse(localStorage.getItem("mabala_user_passwords") || "{}");
        passDict[cleanEmail] = input.password;
        localStorage.setItem("mabala_user_passwords", JSON.stringify(passDict));

        // First login tracker
        const pendingStr = localStorage.getItem("mabala_pending_first_login_users") || "[]";
        const pendingUsers = JSON.parse(pendingStr);
        const pendingFiltered = pendingUsers.filter((u: any) => u.email.toLowerCase() !== cleanEmail);
        pendingFiltered.push({
          email: cleanEmail,
          name: newUser.name,
          password: input.password,
          role: newUser.role,
          tenantId: cleanTenantId,
          farmId: input.farmId,
          permittedModules: newUser.permittedModules,
          mustChangePassword: newUser.mustChangePassword,
          forcePasswordChange: newUser.forcePasswordChange,
          createdAt: newUser.createdAt
        });
        localStorage.setItem("mabala_pending_first_login_users", JSON.stringify(pendingFiltered));
      } catch (err) {
        console.warn("[UserService] Error updating local user registries:", err);
      }
    }

    return newUser;
  }

  /**
   * Farm owner updates an existing user profile on the farm node.
   */
  static async updateFarmNodeUser(
    tenantId: string,
    email: string,
    updates: Partial<UserMember>,
    actorEmail: string
  ): Promise<UserMember | null> {
    const cleanTenantId = (tenantId || "").trim();
    const cleanEmail = email.trim().toLowerCase();

    const users = await this.getFarmNodeUsers(cleanTenantId);
    const existingIndex = users.findIndex(u => u.email.toLowerCase() === cleanEmail);
    if (existingIndex === -1) {
      throw new Error(`User "${email}" was not found in this farm node.`);
    }

    const updatedUser: UserMember = {
      ...users[existingIndex],
      ...updates,
      email: cleanEmail // keep immutable
    };

    users[existingIndex] = updatedUser;

    // 1. Write to Firestore
    if (isConfigured) {
      try {
        const nodeUserDocRef = doc(db, "tenants", cleanTenantId, "node_users", cleanEmail);
        await setDoc(nodeUserDocRef, updatedUser, { merge: true });

        const rootUserDocRef = doc(db, "users", cleanEmail);
        await setDoc(rootUserDocRef, updatedUser, { merge: true });
      } catch (err) {
        console.warn("[UserService] Error updating user in Firestore:", err);
      }
    }

    // 2. Update local storage
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem(this.getStorageKey(cleanTenantId), JSON.stringify(users));

        // Update role map
        const roleMapStr = localStorage.getItem("mabala_registered_roles_map") || "{}";
        const roleMap = JSON.parse(roleMapStr);
        if (roleMap[cleanEmail]) {
          roleMap[cleanEmail] = {
            ...roleMap[cleanEmail],
            role: updatedUser.role,
            permittedModules: updatedUser.permittedModules,
            status: updatedUser.status,
            isSuspended: updatedUser.isSuspended
          };
          localStorage.setItem("mabala_registered_roles_map", JSON.stringify(roleMap));
        }

        if (updates.password) {
          const passDict = JSON.parse(localStorage.getItem("mabala_user_passwords") || "{}");
          passDict[cleanEmail] = updates.password;
          localStorage.setItem("mabala_user_passwords", JSON.stringify(passDict));
        }
      } catch (_) {}
    }

    return updatedUser;
  }

  /**
   * Farm owner suspends or reactivates a user on their farm node.
   */
  static async toggleUserSuspension(
    tenantId: string,
    email: string,
    suspend: boolean,
    reason: string = "",
    actorEmail: string = ""
  ): Promise<UserMember> {
    const cleanTenantId = (tenantId || "").trim();
    const cleanEmail = email.trim().toLowerCase();

    const updated = await this.updateFarmNodeUser(
      cleanTenantId,
      cleanEmail,
      {
        status: suspend ? "Suspended" : "Active",
        isSuspended: suspend,
        suspensionReason: suspend ? (reason || "Account suspended by farm owner.") : ""
      },
      actorEmail
    );

    if (!updated) {
      throw new Error(`Failed to toggle suspension for user ${email}.`);
    }

    return updated;
  }

  /**
   * Farm owner removes a user from their farm node.
   */
  static async deleteFarmNodeUser(
    tenantId: string,
    email: string,
    actorEmail: string
  ): Promise<boolean> {
    const cleanTenantId = (tenantId || "").trim();
    const cleanEmail = email.trim().toLowerCase();

    // 1. Delete from Firestore
    if (isConfigured) {
      try {
        const nodeUserDocRef = doc(db, "tenants", cleanTenantId, "node_users", cleanEmail);
        await deleteDoc(nodeUserDocRef);

        const rootUserDocRef = doc(db, "users", cleanEmail);
        await deleteDoc(rootUserDocRef);
      } catch (err) {
        console.warn("[UserService] Error deleting user in Firestore:", err);
      }
    }

    // 2. Delete from local caches
    if (typeof window !== "undefined") {
      try {
        const key = this.getStorageKey(cleanTenantId);
        const usersStr = localStorage.getItem(key);
        if (usersStr) {
          const users: UserMember[] = JSON.parse(usersStr);
          const filtered = users.filter(u => u.email.toLowerCase() !== cleanEmail);
          localStorage.setItem(key, JSON.stringify(filtered));
        }

        const roleMapStr = localStorage.getItem("mabala_registered_roles_map") || "{}";
        const roleMap = JSON.parse(roleMapStr);
        delete roleMap[cleanEmail];
        localStorage.setItem("mabala_registered_roles_map", JSON.stringify(roleMap));

        const pendingStr = localStorage.getItem("mabala_pending_first_login_users") || "[]";
        const pendingUsers = JSON.parse(pendingStr);
        const pendingFiltered = pendingUsers.filter((u: any) => u.email.toLowerCase() !== cleanEmail);
        localStorage.setItem("mabala_pending_first_login_users", JSON.stringify(pendingFiltered));
      } catch (_) {}
    }

    return true;
  }

  /**
   * Node user changes their own password.
   */
  static async changeUserPassword(
    email: string,
    newPassword: string,
    tenantId?: string
  ): Promise<boolean> {
    const cleanEmail = email.trim().toLowerCase();
    if (!newPassword || newPassword.length < 6) {
      throw new Error("New password must be at least 6 characters long.");
    }

    // 1. Try to find user profile to get tenantId if not provided
    let effectiveTenantId = tenantId || "";
    if (!effectiveTenantId && isConfigured) {
      try {
        const rootSnap = await getDoc(doc(db, "users", cleanEmail));
        if (rootSnap.exists()) {
          effectiveTenantId = rootSnap.data().tenantId || "";
        }
      } catch (_) {}
    }

    // 2. Update Firestore
    if (isConfigured) {
      try {
        const rootUserRef = doc(db, "users", cleanEmail);
        await setDoc(rootUserRef, {
          password: newPassword,
          mustChangePassword: false,
          forcePasswordChange: false,
          lastPasswordChange: new Date().toISOString()
        }, { merge: true });

        if (effectiveTenantId) {
          const nodeUserRef = doc(db, "tenants", effectiveTenantId, "node_users", cleanEmail);
          await setDoc(nodeUserRef, {
            password: newPassword,
            mustChangePassword: false,
            forcePasswordChange: false,
            lastPasswordChange: new Date().toISOString()
          }, { merge: true });
        }
      } catch (err) {
        console.warn("[UserService] Error changing password in Firestore:", err);
      }
    }

    // 3. Update local caches
    if (typeof window !== "undefined") {
      try {
        const passDict = JSON.parse(localStorage.getItem("mabala_user_passwords") || "{}");
        passDict[cleanEmail] = newPassword;
        localStorage.setItem("mabala_user_passwords", JSON.stringify(passDict));

        const pendingStr = localStorage.getItem("mabala_pending_first_login_users") || "[]";
        const pendingUsers = JSON.parse(pendingStr);
        const updatedPending = pendingUsers.map((u: any) => {
          if (u.email.toLowerCase() === cleanEmail) {
            return {
              ...u,
              password: newPassword,
              mustChangePassword: false,
              forcePasswordChange: false
            };
          }
          return u;
        });
        localStorage.setItem("mabala_pending_first_login_users", JSON.stringify(updatedPending));

        if (effectiveTenantId) {
          const key = this.getStorageKey(effectiveTenantId);
          const localStr = localStorage.getItem(key);
          if (localStr) {
            const list: UserMember[] = JSON.parse(localStr);
            const updated = list.map(u => u.email.toLowerCase() === cleanEmail ? { ...u, password: newPassword, mustChangePassword: false } : u);
            localStorage.setItem(key, JSON.stringify(updated));
          }
        }
      } catch (_) {}
    }

    return true;
  }

  /**
   * Authenticate a farm node user by email and password.
   * Enforces suspension check and returns multi-tenant metadata.
   */
  static async verifyNodeUserCredentials(
    email: string,
    passwordAttempt: string
  ): Promise<{
    isValid: boolean;
    user?: UserMember;
    isSuspended?: boolean;
    suspensionReason?: string;
    errorMessage?: string;
  }> {
    const cleanEmail = email.trim().toLowerCase();
    let userRecord: UserMember | null = null;

    // 1. Check Cloud Firestore root users
    if (isConfigured && typeof window !== "undefined" && window.navigator.onLine) {
      try {
        const userDocSnap = await getDoc(doc(db, "users", cleanEmail));
        if (userDocSnap.exists()) {
          userRecord = userDocSnap.data() as UserMember;
        }
      } catch (err) {
        console.warn("[UserService] Error checking user in Firestore:", err);
      }
    }

    // 2. Check pending / local storage if not found in Firestore
    if (!userRecord && typeof window !== "undefined") {
      try {
        const pendingStr = localStorage.getItem("mabala_pending_first_login_users");
        if (pendingStr) {
          const pending = JSON.parse(pendingStr);
          const found = pending.find((u: any) => u.email.toLowerCase() === cleanEmail);
          if (found) {
            userRecord = {
              id: found.id || `usr_${cleanEmail}`,
              name: found.name || cleanEmail.split("@")[0],
              email: cleanEmail,
              role: found.role || "Farm Worker",
              password: found.password,
              status: found.status || (found.isSuspended ? "Suspended" : "Active"),
              isSuspended: Boolean(found.isSuspended),
              tenantId: found.tenantId,
              farmId: found.farmId,
              permittedModules: found.permittedModules,
              mustChangePassword: found.mustChangePassword,
              forcePasswordChange: found.forcePasswordChange,
              lastActive: "Recently"
            };
          }
        }

        // Also check password dictionary
        if (!userRecord) {
          const passDict = JSON.parse(localStorage.getItem("mabala_user_passwords") || "{}");
          if (passDict[cleanEmail]) {
            const roleMap = JSON.parse(localStorage.getItem("mabala_registered_roles_map") || "{}");
            const roleEntry = roleMap[cleanEmail] || {};
            userRecord = {
              id: `usr_${cleanEmail}`,
              name: cleanEmail.split("@")[0],
              email: cleanEmail,
              role: roleEntry.role || "Farm Worker",
              password: passDict[cleanEmail],
              status: roleEntry.status || (roleEntry.isSuspended ? "Suspended" : "Active"),
              isSuspended: Boolean(roleEntry.isSuspended),
              tenantId: roleEntry.tenantId,
              farmId: roleEntry.farmId,
              permittedModules: roleEntry.permittedModules,
              lastActive: "Recently"
            };
          }
        }
      } catch (_) {}
    }

    if (!userRecord) {
      return {
        isValid: false,
        errorMessage: "No user account was found with this email."
      };
    }

    // 3. Check suspension status
    if (userRecord.isSuspended || userRecord.status === "Suspended") {
      return {
        isValid: false,
        isSuspended: true,
        suspensionReason: userRecord.suspensionReason || "This farm node user account has been suspended by the farm owner. Please contact your farm administrator.",
        errorMessage: `⚠️ Access Denied: This account has been suspended by the farm owner. Reason: ${userRecord.suspensionReason || "Account Suspended"}`
      };
    }

    // 4. Verify password
    if (userRecord.password && userRecord.password !== passwordAttempt) {
      return {
        isValid: false,
        errorMessage: "Incorrect password. Please verify your credentials."
      };
    }

    return {
      isValid: true,
      user: userRecord
    };
  }
}

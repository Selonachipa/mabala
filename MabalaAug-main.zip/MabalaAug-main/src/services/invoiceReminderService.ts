import { db } from "../firebase";
import { collection, doc, setDoc, getDocs, updateDoc } from "firebase/firestore";
import { PlatformInvoice, fetchPlatformInvoices, markPlatformInvoicePaid } from "./platformInvoiceService";

export interface InvoiceReminderLog {
  id: string;
  invoiceId: string;
  invoiceNumber: string;
  recipientTenantName: string;
  recipientEmail: string;
  recipientType: string;
  amountPending: number;
  dueDate: string;
  daysOverdue: number; // 0 if not yet due, >0 if past due date
  status: "PENDING" | "OVERDUE";
  payLinkUrl: string;
  directPayToken: string;
  sentAt: string;
  emailSubject: string;
  emailBody: string;
  deliveryStatus: "DELIVERED" | "SIMULATED_SENT";
}

const REMINDER_LOGS_STORAGE_KEY = "mabala_invoice_reminder_dispatch_logs_v1";

// Helper to calculate days overdue
export function calculateDaysOverdue(dueDateStr: string): { daysOverdue: number; isOverdue: boolean } {
  if (!dueDateStr) return { daysOverdue: 0, isOverdue: false };
  const due = new Date(dueDateStr);
  due.setHours(23, 59, 59, 999);
  const now = new Date();
  
  if (now <= due) {
    return { daysOverdue: 0, isOverdue: false };
  } else {
    const diffMs = now.getTime() - due.getTime();
    const days = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    return { daysOverdue: days, isOverdue: true };
  }
}

// Helper to construct direct Lipila payment link
export function generateDirectPayLink(invoiceId: string, recipientEmail?: string): { payLinkUrl: string; token: string } {
  const origin = typeof window !== "undefined" ? window.location.origin : "https://mabala.ag";
  const token = `PAY-${btoa(invoiceId).replace(/=/g, "")}-${Date.now().toString(36)}`;
  const payLinkUrl = `${origin}?payInvoice=${encodeURIComponent(invoiceId)}&token=${encodeURIComponent(token)}`;
  return { payLinkUrl, token };
}

// Generate rich email content
export function buildReminderEmailContent(
  invoice: PlatformInvoice,
  daysOverdue: number,
  payLinkUrl: string
): { subject: string; body: string } {
  const isOverdue = daysOverdue > 0;
  const subject = isOverdue
    ? `[OVERDUE REMINDER - ${daysOverdue} DAYS] Invoice ${invoice.invoiceNumber} for ZK ${invoice.totalAmount.toLocaleString()} - Mabala Agritech`
    : `[PAYMENT REMINDER] Upcoming Invoice ${invoice.invoiceNumber} (Due ${invoice.dueDate}) - Mabala Agritech`;

  const lineItemsList = invoice.lineItems
    .map(item => `  • ${item.description}: ZK ${item.amount.toLocaleString()}`)
    .join("\n");

  const body = `
Dear ${invoice.recipientTenantName} (${invoice.recipientType}),

This is an automated notification regarding your platform service invoice with Mabala Agritech.

--------------------------------------------------
INVOICE SUMMARY
--------------------------------------------------
Invoice Number: ${invoice.invoiceNumber}
Recipient Tenant: ${invoice.recipientTenantName}
Due Date: ${invoice.dueDate}
Days Overdue: ${daysOverdue > 0 ? `${daysOverdue} Day(s) Overdue` : "0 (Due Today / Upcoming)"}
Payment Status: ${isOverdue ? "OVERDUE" : "PENDING"}

ITEMIZED BREAKDOWN:
${lineItemsList}

TOTAL AMOUNT PENDING: ZK ${invoice.totalAmount.toLocaleString()}
--------------------------------------------------

DIRECT LIPILA PAYMENT LINK (NO LOGIN REQUIRED):
Click or open the link below to pay immediately via Lipila Mobile Money (MTN / Airtel / Zamtel):
${payLinkUrl}

Upon completion of Mobile Money approval, your payment will automatically reconcile back to Invoice #${invoice.invoiceNumber} and issue your instant receipt.

Thank you for your valued partnership.

Finance & Billing Operations
Mabala Agritech Platform
Support: finance@mabala.ag | Lusaka, Zambia
`;

  return { subject, body };
}

// Send or trigger an individual invoice email reminder
export async function dispatchInvoiceEmailReminder(
  invoice: PlatformInvoice,
  forceSend: boolean = false
): Promise<InvoiceReminderLog> {
  const { daysOverdue, isOverdue } = calculateDaysOverdue(invoice.dueDate);
  const { payLinkUrl, token } = generateDirectPayLink(invoice.id, invoice.recipientEmail);
  const { subject, body } = buildReminderEmailContent(invoice, daysOverdue, payLinkUrl);

  const recipientEmail = invoice.recipientEmail || `finance@${invoice.recipientTenantId.toLowerCase()}.zm`;

  const newLog: InvoiceReminderLog = {
    id: `REM-LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    invoiceId: invoice.id,
    invoiceNumber: invoice.invoiceNumber,
    recipientTenantName: invoice.recipientTenantName,
    recipientEmail: recipientEmail,
    recipientType: invoice.recipientType,
    amountPending: invoice.totalAmount,
    dueDate: invoice.dueDate,
    daysOverdue: daysOverdue,
    status: isOverdue ? "OVERDUE" : "PENDING",
    payLinkUrl: payLinkUrl,
    directPayToken: token,
    sentAt: new Date().toISOString(),
    emailSubject: subject,
    emailBody: body,
    deliveryStatus: "DELIVERED"
  };

  // Dispatch live email via Hostinger Enterprise SMTP Gateway
  try {
    const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipientEmail);
    if (isEmailValid) {
      await fetch("/api/mail/send-invoice", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: recipientEmail,
          invoiceNumber: invoice.invoiceNumber,
          customerName: invoice.recipientTenantName,
          dueDate: invoice.dueDate,
          totalAmount: invoice.totalAmount,
          currencySymbol: "ZK",
          lineItems: invoice.lineItems,
          payLinkUrl,
          daysOverdue,
          notes: isOverdue ? `Please attend to this overdue balance of ZK ${invoice.totalAmount.toLocaleString()} to avoid service disruption.` : undefined,
          farmContext: {
            farmNodeId: "FN-HQ-BILLING",
            farmName: "Mabala Agronomic Enterprise Cloud",
            tenantId: invoice.recipientTenantId,
            location: "Lusaka, Zambia",
            phone: "+260 978 070 734",
            tpin: "1002938475",
            operatorName: "Finance & Billing Operations"
          }
        })
      });
      console.log(`[Invoice Reminder] Successfully sent email to ${recipientEmail} via Hostinger SMTP`);
    }
  } catch (mailErr: any) {
    console.warn("[Invoice Reminder Mail Error]:", mailErr.message);
  }

  // Update local storage logs
  let existingLogs: InvoiceReminderLog[] = [];
  if (typeof window !== "undefined") {
    const rawLogs = localStorage.getItem(REMINDER_LOGS_STORAGE_KEY);
    if (rawLogs) existingLogs = JSON.parse(rawLogs);
    existingLogs.unshift(newLog);
    localStorage.setItem(REMINDER_LOGS_STORAGE_KEY, JSON.stringify(existingLogs.slice(0, 200)));
  }

  // Update invoice record with lastReminderSentAt and reminderCount
  const updatedInvoice: PlatformInvoice = {
    ...invoice,
    lastReminderSentAt: new Date().toISOString(),
    reminderCount: (invoice.reminderCount || 0) + 1,
    payLinkUrl: payLinkUrl,
    directPayToken: token
  };

  // Persist updated invoice in platform storage & Firestore
  if (typeof window !== "undefined") {
    const rawInvs = localStorage.getItem("mabala_platform_invoices_v1");
    if (rawInvs) {
      const list: PlatformInvoice[] = JSON.parse(rawInvs);
      const updatedList = list.map(i => i.id === invoice.id ? updatedInvoice : i);
      localStorage.setItem("mabala_platform_invoices_v1", JSON.stringify(updatedList));
    }
  }

  if (db) {
    try {
      await updateDoc(doc(db, "platformInvoices", invoice.id), {
        lastReminderSentAt: new Date().toISOString(),
        reminderCount: (invoice.reminderCount || 0) + 1,
        payLinkUrl: payLinkUrl,
        directPayToken: token
      });
      await setDoc(doc(db, "invoiceReminderLogs", newLog.id), newLog);
    } catch (e) {
      console.warn("Firestore update error during reminder dispatch:", e);
    }
  }

  return newLog;
}

// Scheduled / Daily scanner function
export async function runAutomatedDailyInvoiceScan(): Promise<{
  scannedCount: number;
  remindersSentCount: number;
  totalPendingAmountZK: number;
  totalOverdueAmountZK: number;
  dispatchedLogs: InvoiceReminderLog[];
}> {
  const invoices = await fetchPlatformInvoices();
  const pendingOrOverdue = invoices.filter(i => i.status === "PENDING");

  let remindersSentCount = 0;
  let totalPendingAmountZK = 0;
  let totalOverdueAmountZK = 0;
  const dispatchedLogs: InvoiceReminderLog[] = [];

  const now = new Date();

  for (const inv of pendingOrOverdue) {
    const { daysOverdue, isOverdue } = calculateDaysOverdue(inv.dueDate);
    totalPendingAmountZK += inv.totalAmount;
    if (isOverdue) {
      totalOverdueAmountZK += inv.totalAmount;
    }

    // Check cadence: send if no reminder sent yet OR if last reminder was > 24 hours ago
    let shouldSend = false;
    if (!inv.lastReminderSentAt) {
      shouldSend = true;
    } else {
      const lastSent = new Date(inv.lastReminderSentAt);
      const hoursSinceLast = (now.getTime() - lastSent.getTime()) / (1000 * 60 * 60);
      // Remind if >= 24 hours have passed or if newly overdue
      if (hoursSinceLast >= 24) {
        shouldSend = true;
      }
    }

    if (shouldSend) {
      const log = await dispatchInvoiceEmailReminder(inv, true);
      dispatchedLogs.push(log);
      remindersSentCount++;
    }
  }

  return {
    scannedCount: pendingOrOverdue.length,
    remindersSentCount,
    totalPendingAmountZK,
    totalOverdueAmountZK,
    dispatchedLogs
  };
}

export function fetchReminderLogs(): InvoiceReminderLog[] {
  if (typeof window !== "undefined") {
    const raw = localStorage.getItem(REMINDER_LOGS_STORAGE_KEY);
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch (e) {
        return [];
      }
    }
  }
  return [];
}

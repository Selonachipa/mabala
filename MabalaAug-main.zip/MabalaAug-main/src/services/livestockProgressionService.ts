import { 
  LivestockRecord, 
  LivestockStageTemplate, 
  LivestockStage, 
  LivestockWeightRecord, 
  StageTransitionRecord, 
  BiologicalValuationRecord, 
  LivestockAccountingEvent, 
  ProgressionEligibilityResult,
  LivestockReconciliationReport,
  StageTransitionMode,
  ProgressionTriggerType
} from "../types";
import { safeLocalStorage as localStorage } from "../utils/safeStorage";

// ============================================================================
// DEFAULT STAGE TEMPLATES (§4, §7, §45, §59)
// ============================================================================

export const DEFAULT_STAGE_TEMPLATES: LivestockStageTemplate[] = [
  {
    id: "tpl_commercial_pig_v1",
    tenantId: "system",
    species: "Pigs",
    name: "Commercial Pig Production",
    version: 1,
    effectiveFrom: "2026-01-01",
    status: "Active",
    isDefault: true,
    stages: [
      {
        id: "stg_piglet",
        templateId: "tpl_commercial_pig_v1",
        sequence: 1,
        name: "Piglet",
        durationValue: 21,
        durationUnit: "DAYS",
        targetWeight: 20,
        targetWeightUnit: "kg",
        valuation: 500,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        exceptionThresholdPct: 10,
        nextStageId: "stg_weaner",
        nextStageName: "Weaner",
        isFinalStage: false,
        active: true,
        notes: "Suckling phase to weaning milestone"
      },
      {
        id: "stg_weaner",
        templateId: "tpl_commercial_pig_v1",
        sequence: 2,
        name: "Weaner",
        durationValue: 42,
        durationUnit: "DAYS",
        targetWeight: 50,
        targetWeightUnit: "kg",
        valuation: 1500,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        exceptionThresholdPct: 10,
        nextStageId: "stg_grower",
        nextStageName: "Grower",
        isFinalStage: false,
        active: true,
        notes: "Nursery phase fed on weaner starter rations"
      },
      {
        id: "stg_grower",
        templateId: "tpl_commercial_pig_v1",
        sequence: 3,
        name: "Grower",
        durationValue: 70,
        durationUnit: "DAYS",
        targetWeight: 90,
        targetWeightUnit: "kg",
        valuation: 3500,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        exceptionThresholdPct: 10,
        nextStageId: "stg_finisher",
        nextStageName: "Finisher",
        isFinalStage: false,
        active: true,
        notes: "Rapid lean muscle accretion phase"
      },
      {
        id: "stg_finisher",
        templateId: "tpl_commercial_pig_v1",
        sequence: 4,
        name: "Finisher",
        durationValue: 0,
        durationUnit: "DAYS",
        targetWeight: 120,
        targetWeightUnit: "kg",
        valuation: 5500,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: false,
        exceptionThresholdPct: 10,
        isFinalStage: true,
        active: true,
        notes: "Market-ready porker / baconer weight"
      }
    ],
    createdBy: "System",
    createdAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z"
  },
  {
    id: "tpl_beef_cattle_v1",
    tenantId: "system",
    species: "Cattle",
    name: "Commercial Beef Cattle Production",
    version: 1,
    effectiveFrom: "2026-01-01",
    status: "Active",
    isDefault: true,
    stages: [
      {
        id: "stg_calf",
        templateId: "tpl_beef_cattle_v1",
        sequence: 1,
        name: "Calf",
        durationValue: 180,
        durationUnit: "DAYS",
        targetWeight: 180,
        targetWeightUnit: "kg",
        valuation: 4000,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        exceptionThresholdPct: 10,
        nextStageId: "stg_beef_weaner",
        nextStageName: "Weaner",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_beef_weaner",
        templateId: "tpl_beef_cattle_v1",
        sequence: 2,
        name: "Weaner",
        durationValue: 180,
        durationUnit: "DAYS",
        targetWeight: 280,
        targetWeightUnit: "kg",
        valuation: 7500,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        exceptionThresholdPct: 10,
        nextStageId: "stg_beef_yearling",
        nextStageName: "Yearling / Grower",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_beef_yearling",
        templateId: "tpl_beef_cattle_v1",
        sequence: 3,
        name: "Yearling / Grower",
        durationValue: 180,
        durationUnit: "DAYS",
        targetWeight: 380,
        targetWeightUnit: "kg",
        valuation: 12000,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        exceptionThresholdPct: 10,
        nextStageId: "stg_beef_finisher",
        nextStageName: "Finisher / Mature",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_beef_finisher",
        templateId: "tpl_beef_cattle_v1",
        sequence: 4,
        name: "Finisher / Mature",
        durationValue: 0,
        durationUnit: "DAYS",
        targetWeight: 500,
        targetWeightUnit: "kg",
        valuation: 18000,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: false,
        isFinalStage: true,
        active: true
      }
    ],
    createdBy: "System",
    createdAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z"
  },
  {
    id: "tpl_dairy_cattle_v1",
    tenantId: "system",
    species: "Cattle",
    name: "Dairy Cattle Replacement Lifecycle",
    version: 1,
    effectiveFrom: "2026-01-01",
    status: "Active",
    isDefault: false,
    stages: [
      {
        id: "stg_dairy_calf",
        templateId: "tpl_dairy_cattle_v1",
        sequence: 1,
        name: "Dairy Calf",
        durationValue: 90,
        durationUnit: "DAYS",
        targetWeight: 90,
        targetWeightUnit: "kg",
        valuation: 3500,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        nextStageId: "stg_weaned_heifer",
        nextStageName: "Weaned Heifer",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_weaned_heifer",
        templateId: "tpl_dairy_cattle_v1",
        sequence: 2,
        name: "Weaned Heifer",
        durationValue: 180,
        durationUnit: "DAYS",
        targetWeight: 200,
        targetWeightUnit: "kg",
        valuation: 6500,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        nextStageId: "stg_bulling_heifer",
        nextStageName: "Bulling Heifer",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_bulling_heifer",
        templateId: "tpl_dairy_cattle_v1",
        sequence: 3,
        name: "Bulling Heifer",
        durationValue: 180,
        durationUnit: "DAYS",
        targetWeight: 340,
        targetWeightUnit: "kg",
        valuation: 11000,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        nextStageId: "stg_incalf_heifer",
        nextStageName: "In-Calf Heifer",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_incalf_heifer",
        templateId: "tpl_dairy_cattle_v1",
        sequence: 4,
        name: "In-Calf Heifer",
        durationValue: 280,
        durationUnit: "DAYS",
        targetWeight: 450,
        targetWeightUnit: "kg",
        valuation: 16000,
        currency: "ZMW",
        transitionMode: "TIME_ONLY",
        automaticProgression: true,
        nextStageId: "stg_milking_cow",
        nextStageName: "Milking Cow",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_milking_cow",
        templateId: "tpl_dairy_cattle_v1",
        sequence: 5,
        name: "Milking Cow",
        durationValue: 0,
        durationUnit: "DAYS",
        targetWeight: 550,
        targetWeightUnit: "kg",
        valuation: 24000,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: false,
        isFinalStage: true,
        active: true
      }
    ],
    createdBy: "System",
    createdAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z"
  },
  {
    id: "tpl_commercial_goats_v1",
    tenantId: "system",
    species: "Goats",
    name: "Commercial Meat Goat Production",
    version: 1,
    effectiveFrom: "2026-01-01",
    status: "Active",
    isDefault: true,
    stages: [
      {
        id: "stg_kid",
        templateId: "tpl_commercial_goats_v1",
        sequence: 1,
        name: "Kid",
        durationValue: 60,
        durationUnit: "DAYS",
        targetWeight: 12,
        targetWeightUnit: "kg",
        valuation: 600,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        nextStageId: "stg_goat_weaner",
        nextStageName: "Weaner Kid",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_goat_weaner",
        templateId: "tpl_commercial_goats_v1",
        sequence: 2,
        name: "Weaner Kid",
        durationValue: 60,
        durationUnit: "DAYS",
        targetWeight: 22,
        targetWeightUnit: "kg",
        valuation: 1200,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        nextStageId: "stg_goat_grower",
        nextStageName: "Grower",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_goat_grower",
        templateId: "tpl_commercial_goats_v1",
        sequence: 3,
        name: "Grower",
        durationValue: 120,
        durationUnit: "DAYS",
        targetWeight: 35,
        targetWeightUnit: "kg",
        valuation: 2000,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        nextStageId: "stg_goat_slaughter",
        nextStageName: "Slaughter / Mature",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_goat_slaughter",
        templateId: "tpl_commercial_goats_v1",
        sequence: 4,
        name: "Slaughter / Mature",
        durationValue: 0,
        durationUnit: "DAYS",
        targetWeight: 45,
        targetWeightUnit: "kg",
        valuation: 2800,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: false,
        isFinalStage: true,
        active: true
      }
    ],
    createdBy: "System",
    createdAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z"
  },
  {
    id: "tpl_commercial_sheep_v1",
    tenantId: "system",
    species: "Sheep",
    name: "Commercial Sheep Production",
    version: 1,
    effectiveFrom: "2026-01-01",
    status: "Active",
    isDefault: true,
    stages: [
      {
        id: "stg_lamb",
        templateId: "tpl_commercial_sheep_v1",
        sequence: 1,
        name: "Lamb",
        durationValue: 60,
        durationUnit: "DAYS",
        targetWeight: 15,
        targetWeightUnit: "kg",
        valuation: 700,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        nextStageId: "stg_sheep_weaner",
        nextStageName: "Weaner Lamb",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_sheep_weaner",
        templateId: "tpl_commercial_sheep_v1",
        sequence: 2,
        name: "Weaner Lamb",
        durationValue: 60,
        durationUnit: "DAYS",
        targetWeight: 28,
        targetWeightUnit: "kg",
        valuation: 1400,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        nextStageId: "stg_sheep_grower",
        nextStageName: "Grower",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_sheep_grower",
        templateId: "tpl_commercial_sheep_v1",
        sequence: 3,
        name: "Grower",
        durationValue: 90,
        durationUnit: "DAYS",
        targetWeight: 42,
        targetWeightUnit: "kg",
        valuation: 2200,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: true,
        nextStageId: "stg_sheep_finisher",
        nextStageName: "Finisher / Mature",
        isFinalStage: false,
        active: true
      },
      {
        id: "stg_sheep_finisher",
        templateId: "tpl_commercial_sheep_v1",
        sequence: 4,
        name: "Finisher / Mature",
        durationValue: 0,
        durationUnit: "DAYS",
        targetWeight: 55,
        targetWeightUnit: "kg",
        valuation: 3200,
        currency: "ZMW",
        transitionMode: "WEIGHT_OR_TIME",
        automaticProgression: false,
        isFinalStage: true,
        active: true
      }
    ],
    createdBy: "System",
    createdAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z"
  }
];

// Default attribution validity in days (§15)
export const DEFAULT_WEIGHT_ATTRIBUTION_VALIDITY_DAYS = 7;

// ============================================================================
// TEMPLATE STORAGE & VERSIONING (§6, §7, §8, §46)
// ============================================================================

export function getTenantStageTemplates(tenantId: string = "default"): LivestockStageTemplate[] {
  try {
    const raw = localStorage.getItem(`mabala_stage_templates_${tenantId}`);
    if (raw) {
      const parsed: LivestockStageTemplate[] = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn("[ProgressionService] Error loading templates from storage:", e);
  }

  // Clone defaults for tenant
  const tenantTemplates = DEFAULT_STAGE_TEMPLATES.map(tpl => ({
    ...tpl,
    tenantId
  }));
  saveTenantStageTemplates(tenantId, tenantTemplates);
  return tenantTemplates;
}

export function saveTenantStageTemplates(tenantId: string = "default", templates: LivestockStageTemplate[]): void {
  try {
    localStorage.setItem(`mabala_stage_templates_${tenantId}`, JSON.stringify(templates));
  } catch (e) {
    console.error("[ProgressionService] Failed to save stage templates:", e);
  }
}

export function getTemplateForSpecies(tenantId: string, species: string): LivestockStageTemplate | undefined {
  const templates = getTenantStageTemplates(tenantId);
  const normalizedSpecies = (species || "").toLowerCase().trim();
  return (
    templates.find(t => t.species.toLowerCase() === normalizedSpecies && t.isDefault && t.status === "Active") ||
    templates.find(t => t.species.toLowerCase() === normalizedSpecies && t.status === "Active") ||
    templates.find(t => t.species.toLowerCase().includes(normalizedSpecies) || normalizedSpecies.includes(t.species.toLowerCase()))
  );
}

export interface TemplateValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

export function validateStageTemplate(template: LivestockStageTemplate): TemplateValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!template.name.trim()) {
    errors.push("Template name is required.");
  }
  if (!template.stages || template.stages.length === 0) {
    errors.push("Template must have at least one stage.");
    return { valid: false, errors, warnings };
  }

  const sequenceSet = new Set<number>();
  const nameSet = new Set<string>();

  template.stages.forEach((stage, idx) => {
    // Duplicate sequence
    if (sequenceSet.has(stage.sequence)) {
      errors.push(`Duplicate sequence number '${stage.sequence}' detected on stage '${stage.name}'.`);
    }
    sequenceSet.add(stage.sequence);

    // Duplicate name
    const lowerName = stage.name.trim().toLowerCase();
    if (nameSet.has(lowerName)) {
      errors.push(`Duplicate stage name '${stage.name}' within the same template.`);
    }
    nameSet.add(lowerName);

    // Negatives
    if (stage.durationValue < 0) {
      errors.push(`Stage '${stage.name}' cannot have a negative duration.`);
    }
    if (stage.targetWeight < 0) {
      errors.push(`Stage '${stage.name}' cannot have a negative target weight.`);
    }
    if (stage.valuation <= 0) {
      errors.push(`Stage '${stage.name}' must have a positive valuation (> 0).`);
    }

    // Circularity check
    if (stage.nextStageId === stage.id) {
      errors.push(`Stage '${stage.name}' cannot reference itself as its next stage.`);
    }

    // Valuation warning (§6.2)
    if (idx < template.stages.length - 1) {
      const nextStage = template.stages[idx + 1];
      if (nextStage.valuation < stage.valuation) {
        warnings.push(
          `Stage '${nextStage.name}' (${nextStage.valuation} ${stage.currency}) has a lower valuation than '${stage.name}' (${stage.valuation} ${stage.currency}). This will result in an accounting revaluation loss.`
        );
      }
    }
  });

  // Check final stage presence
  const finalStages = template.stages.filter(s => s.isFinalStage);
  if (finalStages.length === 0) {
    warnings.push("Template has no marked final stage. The last sequential stage will be treated as final.");
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

export function saveOrUpdateStageTemplate(
  tenantId: string, 
  template: LivestockStageTemplate, 
  actor: string = "User"
): { template: LivestockStageTemplate; versionBumped: boolean; validation: TemplateValidationResult } {
  const validation = validateStageTemplate(template);
  if (!validation.valid) {
    return { template, versionBumped: false, validation };
  }

  const existingTemplates = getTenantStageTemplates(tenantId);
  const existingIdx = existingTemplates.findIndex(t => t.id === template.id);

  let versionBumped = false;
  let finalTemplate: LivestockStageTemplate;

  if (existingIdx >= 0) {
    const prev = existingTemplates[existingIdx];
    // Check if stages or valuations changed to enforce immutable versioning (§8)
    const stagesChanged = JSON.stringify(prev.stages) !== JSON.stringify(template.stages);
    const newVersion = stagesChanged ? (prev.version || 1) + 1 : prev.version;
    versionBumped = stagesChanged;

    finalTemplate = {
      ...template,
      tenantId,
      version: newVersion,
      updatedAt: new Date().toISOString(),
      effectiveFrom: stagesChanged ? new Date().toISOString().split("T")[0] : prev.effectiveFrom
    };
    existingTemplates[existingIdx] = finalTemplate;
  } else {
    finalTemplate = {
      ...template,
      tenantId,
      version: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      effectiveFrom: template.effectiveFrom || new Date().toISOString().split("T")[0]
    };
    existingTemplates.push(finalTemplate);
  }

  saveTenantStageTemplates(tenantId, existingTemplates);
  return { template: finalTemplate, versionBumped, validation };
}

// ============================================================================
// WEIGHT DATA CAPTURE & ATTRIBUTION ENGINE (§11 - §17)
// ============================================================================

export function getTenantWeightRecords(tenantId: string = "default", animalId?: string, penId?: string): LivestockWeightRecord[] {
  try {
    const raw = localStorage.getItem(`mabala_weight_records_${tenantId}`);
    if (raw) {
      let list: LivestockWeightRecord[] = JSON.parse(raw);
      if (animalId) list = list.filter(w => w.animalId === animalId);
      if (penId) list = list.filter(w => w.penId === penId);
      return list.sort((a, b) => new Date(b.measurementDate).getTime() - new Date(a.measurementDate).getTime());
    }
  } catch (e) {
    console.warn("[ProgressionService] Error reading weight records:", e);
  }
  return [];
}

export function saveTenantWeightRecord(tenantId: string = "default", record: LivestockWeightRecord): void {
  try {
    const records = getTenantWeightRecords(tenantId);
    records.unshift(record);
    localStorage.setItem(`mabala_weight_records_${tenantId}`, JSON.stringify(records));
  } catch (e) {
    console.error("[ProgressionService] Failed to save weight record:", e);
  }
}

/**
 * Returns the most authoritative valid weight for an animal (§14, §15)
 * Hierarchy: Individual measured weight > Pen-level attributed weight > Baseline registration weight
 */
export function getAuthoritativeWeight(
  tenantId: string, 
  animal: LivestockRecord, 
  penRecords?: LivestockWeightRecord[]
): {
  weight: number;
  source: "INDIVIDUAL" | "PEN_AVERAGE" | "REGISTRATION" | "NONE";
  measurementDate: string;
  isStale: boolean;
  superseded: boolean;
} {
  const animalWeights = getTenantWeightRecords(tenantId, animal.id);
  const latestIndividual = animalWeights.find(w => w.measurementType === "INDIVIDUAL" && w.isAuthoritative);

  const now = new Date();

  // If there's an individual weight
  if (latestIndividual) {
    const daysSince = Math.floor((now.getTime() - new Date(latestIndividual.measurementDate).getTime()) / (1000 * 60 * 60 * 24));
    return {
      weight: latestIndividual.weight,
      source: "INDIVIDUAL",
      measurementDate: latestIndividual.measurementDate,
      isStale: daysSince > DEFAULT_WEIGHT_ATTRIBUTION_VALIDITY_DAYS * 4, // individual weight stays valid longer (e.g. 28 days)
      superseded: false
    };
  }

  // Check pen-level attributed weight
  if (animal.penId) {
    const penWeights = penRecords || getTenantWeightRecords(tenantId, undefined, animal.penId);
    const latestPenWeight = penWeights.find(w => w.measurementType === "PEN_AVERAGE");
    if (latestPenWeight) {
      const daysSince = Math.floor((now.getTime() - new Date(latestPenWeight.measurementDate).getTime()) / (1000 * 60 * 60 * 24));
      const isStale = daysSince > DEFAULT_WEIGHT_ATTRIBUTION_VALIDITY_DAYS;
      return {
        weight: latestPenWeight.weight,
        source: "PEN_AVERAGE",
        measurementDate: latestPenWeight.measurementDate,
        isStale,
        superseded: false
      };
    }
  }

  // Fallback to animal's current or registration weight
  const fallbackWeight = animal.currentWeight || animal.weightKg || animal.registrationWeight || animal.weight || 0;
  if (fallbackWeight > 0) {
    const date = animal.lastWeighedDate || animal.registrationDate || animal.dateAcquired || new Date().toISOString();
    const daysSince = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60 * 60 * 24));
    return {
      weight: fallbackWeight,
      source: "REGISTRATION",
      measurementDate: date,
      isStale: daysSince > DEFAULT_WEIGHT_ATTRIBUTION_VALIDITY_DAYS * 2,
      superseded: false
    };
  }

  return {
    weight: 0,
    source: "NONE",
    measurementDate: new Date().toISOString(),
    isStale: true,
    superseded: false
  };
}

// ============================================================================
// PROGRESSION EVALUATION ENGINE (§18 - §28, §38 - §39)
// ============================================================================

export function evaluateAnimalProgression(
  tenantId: string,
  animal: LivestockRecord,
  template?: LivestockStageTemplate,
  currentDate: Date = new Date()
): ProgressionEligibilityResult {
  const activeTemplate = template || getTemplateForSpecies(tenantId, animal.species || animal.type || "Pigs");
  
  // Default non-eligible skeleton
  const baseResult: ProgressionEligibilityResult = {
    animalId: animal.id,
    tagNumber: animal.tagId || animal.name || animal.id,
    species: animal.species || animal.type || "Livestock",
    daysInStage: 0,
    targetDays: 0,
    stageEntryDate: animal.currentStageEntryDate || animal.registrationDate || animal.dateAcquired || new Date().toISOString().split("T")[0],
    transitionMode: "WEIGHT_OR_TIME",
    weightReached: false,
    timeReached: false,
    eligible: false,
    trigger: "NONE",
    isUnderweight: false,
    weightVarianceKg: 0,
    weightVariancePct: 0,
    isHeld: Boolean(animal.progressionHold),
    holdReason: animal.progressionHoldReason,
    isFinalStage: false,
    isWeightStale: false,
    currentValuation: animal.currentValue || 0,
    statusText: "No template configured"
  };

  if (!activeTemplate || !activeTemplate.stages || activeTemplate.stages.length === 0) {
    return baseResult;
  }

  // 1. Animal status check (§47, §48)
  const nonProgressingStatuses = ["sold", "deceased", "dead", "slaughtered", "missing", "transferred", "disposed"];
  const currentStatus = (animal.status || "Active").toLowerCase();
  if (nonProgressingStatuses.includes(currentStatus)) {
    return {
      ...baseResult,
      statusText: `Animal is ${animal.status} (Progression permanently halted)`
    };
  }

  // 2. Identify current stage
  let currentStage: LivestockStage | undefined;
  if (animal.currentStageId) {
    currentStage = activeTemplate.stages.find(s => s.id === animal.currentStageId);
  }
  if (!currentStage && animal.currentStageName) {
    currentStage = activeTemplate.stages.find(s => s.name.toLowerCase() === animal.currentStageName?.toLowerCase());
  }
  if (!currentStage) {
    // Default to initial stage (Seq 1)
    currentStage = activeTemplate.stages.sort((a, b) => a.sequence - b.sequence)[0];
  }

  if (!currentStage) {
    return baseResult;
  }

  baseResult.currentStageId = currentStage.id;
  baseResult.currentStageName = currentStage.name;
  baseResult.transitionMode = currentStage.transitionMode || "WEIGHT_OR_TIME";

  // Check if final stage
  if (currentStage.isFinalStage || !currentStage.nextStageId) {
    const nextIdx = activeTemplate.stages.findIndex(s => s.id === currentStage?.id) + 1;
    if (nextIdx >= activeTemplate.stages.length) {
      return {
        ...baseResult,
        isFinalStage: true,
        statusText: `Final Stage (${currentStage.name})`
      };
    }
  }

  // Identify next stage
  let nextStage: LivestockStage | undefined;
  if (currentStage.nextStageId) {
    nextStage = activeTemplate.stages.find(s => s.id === currentStage?.nextStageId);
  }
  if (!nextStage) {
    const curIdx = activeTemplate.stages.findIndex(s => s.id === currentStage?.id);
    if (curIdx >= 0 && curIdx + 1 < activeTemplate.stages.length) {
      nextStage = activeTemplate.stages[curIdx + 1];
    }
  }

  if (!nextStage) {
    return {
      ...baseResult,
      isFinalStage: true,
      statusText: `Final Stage (${currentStage.name})`
    };
  }

  baseResult.nextStageId = nextStage.id;
  baseResult.nextStageName = nextStage.name;
  baseResult.nextStageValuation = nextStage.valuation;

  // 3. Evaluate days in stage (measured from currentStageEntryDate, NOT registration date! §10)
  const stageEntry = new Date(animal.currentStageEntryDate || animal.registrationDate || animal.dateAcquired || currentDate);
  const diffMs = currentDate.getTime() - stageEntry.getTime();
  const daysInStage = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
  const targetDays = currentStage.durationUnit === "WEEKS" ? currentStage.durationValue * 7 : currentStage.durationValue;

  baseResult.daysInStage = daysInStage;
  baseResult.targetDays = targetDays;

  // 4. Evaluate authoritative weight
  const authWeight = getAuthoritativeWeight(tenantId, animal);
  baseResult.currentWeight = authWeight.weight;
  baseResult.targetWeight = currentStage.targetWeight;
  baseResult.isWeightStale = authWeight.isStale;
  baseResult.weightSource = authWeight.source;
  baseResult.lastWeighedDate = authWeight.measurementDate;

  // 5. Conditions evaluation
  const weightReached = currentStage.targetWeight > 0 && authWeight.weight >= currentStage.targetWeight;
  const timeReached = targetDays > 0 && daysInStage >= targetDays;

  baseResult.weightReached = weightReached;
  baseResult.timeReached = timeReached;

  // 6. Transition rule mode (§5, §38, §39)
  let eligible = false;
  let trigger: ProgressionTriggerType = "NONE";

  switch (currentStage.transitionMode) {
    case "WEIGHT_AND_TIME":
      eligible = weightReached && timeReached;
      trigger = eligible ? "WEIGHT_AND_TIME" : "NONE";
      break;
    case "TIME_ONLY":
      eligible = timeReached;
      trigger = eligible ? "TIME" : "NONE";
      break;
    case "WEIGHT_ONLY":
      eligible = weightReached;
      trigger = eligible ? "WEIGHT" : "NONE";
      break;
    case "WEIGHT_OR_TIME":
    default:
      eligible = weightReached || timeReached;
      if (weightReached && timeReached) {
        trigger = "WEIGHT_AND_TIME";
      } else if (weightReached) {
        trigger = "WEIGHT";
      } else if (timeReached) {
        trigger = "TIME";
      }
      break;
  }

  baseResult.eligible = eligible;
  baseResult.trigger = trigger;

  // 7. Underweight Exception Monitoring (§23, §24)
  if (trigger === "TIME" && authWeight.weight < currentStage.targetWeight && currentStage.targetWeight > 0) {
    baseResult.isUnderweight = true;
    baseResult.weightVarianceKg = Number((authWeight.weight - currentStage.targetWeight).toFixed(1));
    baseResult.weightVariancePct = Number((((authWeight.weight - currentStage.targetWeight) / currentStage.targetWeight) * 100).toFixed(1));
  }

  // 8. Formulate descriptive status text
  if (baseResult.isHeld) {
    baseResult.statusText = `Eligible but Held (${baseResult.holdReason || "Progression Hold Active"})`;
  } else if (eligible) {
    if (trigger === "WEIGHT_AND_TIME") {
      baseResult.statusText = `Ready for Progression (Target Weight & Days Reached)`;
    } else if (trigger === "WEIGHT") {
      baseResult.statusText = `Ready for Progression (Target Weight Reached: ${authWeight.weight}kg >= ${currentStage.targetWeight}kg)`;
    } else {
      baseResult.statusText = baseResult.isUnderweight 
        ? `Ready on Time (${daysInStage}d) ⚠ Underweight by ${Math.abs(baseResult.weightVariancePct)}%` 
        : `Ready for Progression (Time in Stage: ${daysInStage}d >= ${targetDays}d)`;
    }
  } else {
    if (authWeight.isStale) {
      baseResult.statusText = `On Track (${daysInStage}/${targetDays}d) ⚠ Weight estimate is stale (>7 days)`;
    } else {
      baseResult.statusText = `On Track (${daysInStage}/${targetDays}d, ${authWeight.weight}/${currentStage.targetWeight}kg)`;
    }
  }

  return baseResult;
}

// ============================================================================
// STAGE TRANSITION EXECUTION & ATOMIC TRANSACTION SEQUENCE (§28)
// ============================================================================

export function getTenantStageTransitions(tenantId: string = "default", animalId?: string): StageTransitionRecord[] {
  try {
    const raw = localStorage.getItem(`mabala_stage_transitions_${tenantId}`);
    if (raw) {
      let list: StageTransitionRecord[] = JSON.parse(raw);
      if (animalId) list = list.filter(t => t.animalId === animalId);
      return list.sort((a, b) => new Date(b.transitionDate).getTime() - new Date(a.transitionDate).getTime());
    }
  } catch (e) {
    console.warn("[ProgressionService] Error reading stage transitions:", e);
  }
  return [];
}

export function saveTenantStageTransition(tenantId: string = "default", transition: StageTransitionRecord): void {
  try {
    const list = getTenantStageTransitions(tenantId);
    list.unshift(transition);
    localStorage.setItem(`mabala_stage_transitions_${tenantId}`, JSON.stringify(list));
  } catch (e) {
    console.error("[ProgressionService] Failed to save stage transition:", e);
  }
}

export function getTenantValuationRecords(tenantId: string = "default", animalId?: string): BiologicalValuationRecord[] {
  try {
    const raw = localStorage.getItem(`mabala_valuation_events_${tenantId}`);
    if (raw) {
      let list: BiologicalValuationRecord[] = JSON.parse(raw);
      if (animalId) list = list.filter(v => v.animalId === animalId);
      return list.sort((a, b) => new Date(b.valuationDate).getTime() - new Date(a.valuationDate).getTime());
    }
  } catch (e) {
    console.warn("[ProgressionService] Error reading valuation events:", e);
  }
  return [];
}

export function saveTenantValuationRecord(tenantId: string = "default", record: BiologicalValuationRecord): void {
  try {
    const list = getTenantValuationRecords(tenantId);
    list.unshift(record);
    localStorage.setItem(`mabala_valuation_events_${tenantId}`, JSON.stringify(list));
  } catch (e) {
    console.error("[ProgressionService] Failed to save biological valuation record:", e);
  }
}

export function getTenantAccountingEvents(tenantId: string = "default"): LivestockAccountingEvent[] {
  try {
    const raw = localStorage.getItem(`mabala_livestock_acct_events_${tenantId}`);
    if (raw) {
      const list: LivestockAccountingEvent[] = JSON.parse(raw);
      return list.sort((a, b) => new Date(b.postingDate).getTime() - new Date(a.postingDate).getTime());
    }
  } catch (e) {
    console.warn("[ProgressionService] Error reading accounting events:", e);
  }
  return [];
}

export function saveTenantAccountingEvent(tenantId: string = "default", event: LivestockAccountingEvent): void {
  try {
    const list = getTenantAccountingEvents(tenantId);
    // Idempotency check (§32)
    const existingIdx = list.findIndex(e => e.idempotencyKey === event.idempotencyKey);
    if (existingIdx >= 0) {
      list[existingIdx] = event;
    } else {
      list.unshift(event);
    }
    localStorage.setItem(`mabala_livestock_acct_events_${tenantId}`, JSON.stringify(list));
  } catch (e) {
    console.error("[ProgressionService] Failed to save accounting event:", e);
  }
}

/**
 * Executes a stage transition atomically according to §28
 * Keeps animal unique identity constant (Single Source of Truth §2.1)
 */
export function executeStageTransition(
  tenantId: string,
  animal: LivestockRecord,
  nextStage: LivestockStage,
  triggerType: ProgressionTriggerType,
  options: {
    actor?: string;
    reason?: string;
    transitionDate?: string;
    authoritativeWeight?: number;
    targetWeight?: number;
    daysInStage?: number;
    targetDurationDays?: number;
    configVersion?: number;
  } = {}
): {
  updatedAnimal: LivestockRecord;
  transitionRecord: StageTransitionRecord;
  valuationRecord: BiologicalValuationRecord;
  accountingEvent: LivestockAccountingEvent;
} {
  const nowIso = new Date().toISOString();
  const transitionDate = options.transitionDate || nowIso.split("T")[0];
  const fromStageId = animal.currentStageId || "INITIAL";
  const fromStageName = animal.currentStageName || "Initial Stage";
  const fromValuation = animal.currentValue || animal.estimatedValue || animal.initialValuation || 0;
  const toValuation = nextStage.valuation;
  const valuationDelta = toValuation - fromValuation;

  const transitionId = `TRN-${animal.id}-${nextStage.id}-${Date.now()}`;
  const accountingEventId = `ACC-BIO-${animal.id}-${nextStage.id}-${Date.now()}`;
  const valuationEventId = `VAL-${animal.id}-${nextStage.id}-${Date.now()}`;
  const idempotencyKey = `${tenantId}_${animal.id}_${nextStage.id}_${transitionDate}`;

  const authWeight = options.authoritativeWeight || animal.currentWeight || animal.weightKg || 0;
  const targetWeight = options.targetWeight || nextStage.targetWeight || 0;
  const weightVarianceKg = Number((authWeight - targetWeight).toFixed(1));
  const weightVariancePct = targetWeight > 0 ? Number((((authWeight - targetWeight) / targetWeight) * 100).toFixed(1)) : 0;
  const isUnderweight = triggerType === "TIME" && authWeight < targetWeight;

  // Step 1 & 2: Update animal stage and valuation
  const updatedAnimal: LivestockRecord = {
    ...animal,
    currentStageId: nextStage.id,
    currentStageName: nextStage.name,
    productionStage: nextStage.name,
    growthStage: nextStage.name,
    currentStageEntryDate: transitionDate, // Baseline timer starts NOW (§10)
    stageEntryWeight: authWeight,
    currentValue: toValuation,
    estimatedValue: toValuation,
    isUnderweight,
    underweightVariancePct: weightVariancePct,
    growthHistory: [
      ...(animal.growthHistory || []),
      {
        date: transitionDate,
        stage: nextStage.name,
        weightKg: authWeight,
        valuationAmount: toValuation,
        notes: `Progressed to ${nextStage.name} via ${triggerType}. Valuation: ${toValuation} ZMW (${valuationDelta >= 0 ? "+" : ""}${valuationDelta}).`
      }
    ]
  };

  // Step 3: Create Stage Progression Record
  const transitionRecord: StageTransitionRecord = {
    id: transitionId,
    tenantId,
    animalId: animal.id,
    tagNumber: animal.tagId || animal.name || animal.id,
    species: animal.species || animal.type || "Livestock",
    fromStageId,
    fromStageName,
    toStageId: nextStage.id,
    toStageName: nextStage.name,
    fromValuation,
    toValuation,
    valuationDelta,
    fromStageEntryDate: animal.currentStageEntryDate || animal.registrationDate || transitionDate,
    transitionDate,
    triggerType,
    triggerWeight: authWeight,
    targetWeight,
    daysInStage: options.daysInStage || 0,
    targetDurationDays: options.targetDurationDays || nextStage.durationValue,
    weightVarianceKg,
    weightVariancePct,
    isUnderweight,
    isAutomatic: triggerType !== "MANUAL",
    isManual: triggerType === "MANUAL",
    actor: options.actor || (triggerType === "MANUAL" ? "Livestock Manager" : "Progression Engine"),
    reason: options.reason || (isUnderweight ? `Time condition elapsed (${options.daysInStage} days). Underweight at transition.` : `Growth threshold reached`),
    configurationVersion: options.configVersion || 1,
    accountingEventId,
    status: "COMPLETED",
    createdAt: nowIso
  };

  // Step 4: Create Biological Valuation Record
  const valuationRecord: BiologicalValuationRecord = {
    id: valuationEventId,
    tenantId,
    animalId: animal.id,
    tagNumber: animal.tagId || animal.name || animal.id,
    species: animal.species || animal.type || "Livestock",
    previousValue: fromValuation,
    newValue: toValuation,
    valuationChange: valuationDelta,
    stageName: nextStage.name,
    valuationDate: transitionDate,
    triggerType,
    sourceEventId: transitionId,
    accountingEventId,
    status: "POSTED_TO_GL",
    createdAt: nowIso
  };

  // Step 7: Generate Accounting Posting Event (§31, §32)
  const isGain = valuationDelta >= 0;
  const accountingEvent: LivestockAccountingEvent = {
    id: accountingEventId,
    tenantId,
    sourceModule: "LIVESTOCK_PROGRESSION",
    sourceEventId: transitionId,
    animalId: animal.id,
    tagNumber: animal.tagId || animal.name || animal.id,
    eventType: isGain ? "STAGE_REVALUATION_GAIN" : "STAGE_REVALUATION_LOSS",
    debitAccount: isGain ? "1420 - Biological Assets: Livestock" : "5400 - Biological Asset Fair Value Loss",
    creditAccount: isGain ? "4400 - Fair Value Biological Revaluation Gain" : "1420 - Biological Assets: Livestock",
    amount: Math.abs(valuationDelta),
    currency: nextStage.currency || "ZMW",
    postingDate: transitionDate,
    status: "POSTED",
    ledgerTransactionId: `TX-BIO-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    idempotencyKey,
    createdAt: nowIso,
    postedAt: nowIso
  };

  // Persist all components atomically
  saveTenantStageTransition(tenantId, transitionRecord);
  saveTenantValuationRecord(tenantId, valuationRecord);
  saveTenantAccountingEvent(tenantId, accountingEvent);

  return {
    updatedAnimal,
    transitionRecord,
    valuationRecord,
    accountingEvent
  };
}

// ============================================================================
// WEIGHT RECORDING (INDIVIDUAL & PEN-AVERAGE) (§12, §13, §14)
// ============================================================================

export function recordIndividualWeight(
  tenantId: string,
  animal: LivestockRecord,
  weightKg: number,
  options: {
    measurementDate?: string;
    enteredBy?: string;
    source?: "MANUAL_SCALE" | "AUTOMATED" | "DEVICE";
    notes?: string;
  } = {}
): {
  weightRecord: LivestockWeightRecord;
  updatedAnimal: LivestockRecord;
} {
  const nowIso = new Date().toISOString();
  const measurementDate = options.measurementDate || nowIso.split("T")[0];
  const weightRecordId = `WT-IND-${animal.id}-${Date.now()}`;

  const weightRecord: LivestockWeightRecord = {
    id: weightRecordId,
    tenantId,
    animalId: animal.id,
    tagNumber: animal.tagId || animal.name,
    penId: animal.penId,
    penName: animal.penName,
    measurementType: "INDIVIDUAL",
    weight: weightKg,
    unit: "kg",
    measurementDate,
    entryDate: nowIso,
    enteredBy: options.enteredBy || "Scale Operator",
    source: options.source || "MANUAL_SCALE",
    isAuthoritative: true, // Individual measurement supersedes pen-average (§13)
    notes: options.notes || "Individual animal scale measurement",
    createdAt: nowIso
  };

  saveTenantWeightRecord(tenantId, weightRecord);

  const updatedAnimal: LivestockRecord = {
    ...animal,
    currentWeight: weightKg,
    weightKg,
    currentWeightSource: "INDIVIDUAL",
    lastWeighedDate: measurementDate
  };

  return { weightRecord, updatedAnimal };
}

export function recordPenWeight(
  tenantId: string,
  penId: string,
  penName: string,
  averageWeightKg: number,
  headCount: number,
  allAnimals: LivestockRecord[],
  options: {
    measurementDate?: string;
    enteredBy?: string;
    notes?: string;
  } = {}
): {
  weightRecord: LivestockWeightRecord;
  updatedAnimals: LivestockRecord[];
  attributedCount: number;
} {
  const nowIso = new Date().toISOString();
  const measurementDate = options.measurementDate || nowIso.split("T")[0];
  const weightRecordId = `WT-PEN-${penId}-${Date.now()}`;

  const weightRecord: LivestockWeightRecord = {
    id: weightRecordId,
    tenantId,
    penId,
    penName,
    measurementType: "PEN_AVERAGE",
    weight: averageWeightKg,
    headCount,
    unit: "kg",
    measurementDate,
    entryDate: nowIso,
    enteredBy: options.enteredBy || "Livestock Manager",
    source: "PEN_BULK",
    isAuthoritative: true,
    notes: options.notes || `Pen average weight recorded across ${headCount} head`,
    createdAt: nowIso
  };

  saveTenantWeightRecord(tenantId, weightRecord);

  // Find all active animals in that pen
  const penAnimals = allAnimals.filter(
    a => (a.penId === penId || a.penName === penName) && a.status === "Active"
  );

  let attributedCount = 0;
  const updatedAnimals = penAnimals.map(animal => {
    // Check if animal has a newer individual weight recorded within last 14 days
    const recentIndividual = getTenantWeightRecords(tenantId, animal.id)
      .find(w => w.measurementType === "INDIVIDUAL" && w.isAuthoritative);

    if (recentIndividual) {
      // Individual weight supersedes pen-average (§13)
      return animal;
    }

    attributedCount++;
    return {
      ...animal,
      currentWeight: averageWeightKg,
      weightKg: averageWeightKg,
      currentWeightSource: "PEN_AVERAGE" as const,
      lastWeighedDate: measurementDate
    };
  });

  return {
    weightRecord,
    updatedAnimals,
    attributedCount
  };
}

// ============================================================================
// MANUAL STAGE OVERRIDE & PROGRESSION HOLDS (§35 - §37)
// ============================================================================

export function manualStageOverride(
  tenantId: string,
  animal: LivestockRecord,
  newStage: LivestockStage,
  reason: string,
  notes: string = "",
  user: string = "Livestock Manager"
): {
  updatedAnimal: LivestockRecord;
  transitionRecord: StageTransitionRecord;
  valuationRecord: BiologicalValuationRecord;
  accountingEvent: LivestockAccountingEvent;
} {
  return executeStageTransition(tenantId, animal, newStage, "MANUAL", {
    actor: user,
    reason: `Manual stage override: ${reason}. ${notes}`,
    authoritativeWeight: animal.currentWeight || animal.weightKg || 0,
    targetWeight: newStage.targetWeight,
    daysInStage: 0
  });
}

export function setAnimalProgressionHold(
  animal: LivestockRecord,
  isHeld: boolean,
  reason?: string
): LivestockRecord {
  return {
    ...animal,
    progressionHold: isHeld,
    progressionHoldReason: isHeld ? (reason || "Under veterinary / management hold") : undefined,
    progressionHoldDate: isHeld ? new Date().toISOString().split("T")[0] : undefined
  };
}

// ============================================================================
// BIOLOGICAL ASSET ACCOUNTING RECONCILIATION (§34, §57)
// ============================================================================

export function reconcileBiologicalAssets(
  tenantId: string,
  animals: LivestockRecord[],
  glBalance: number = 0
): LivestockReconciliationReport {
  const activeAnimals = animals.filter(a => a.status === "Active");
  const animalRegistryTotalValue = activeAnimals.reduce((sum, a) => sum + (a.currentValue || 0), 0);

  // Read biological asset register valuations
  const valuationRecords = getTenantValuationRecords(tenantId);
  const latestValuationsByAnimal = new Map<string, number>();
  valuationRecords.forEach(v => {
    if (!latestValuationsByAnimal.has(v.animalId)) {
      latestValuationsByAnimal.set(v.animalId, v.newValue);
    }
  });

  let biologicalAssetRegisterValue = 0;
  const exceptions: LivestockReconciliationReport["exceptions"] = [];

  activeAnimals.forEach(a => {
    const regValue = a.currentValue || 0;
    const trackerValue = latestValuationsByAnimal.get(a.id);
    const expectedValue = trackerValue !== undefined ? trackerValue : regValue;
    biologicalAssetRegisterValue += expectedValue;

    if (trackerValue !== undefined && trackerValue !== regValue) {
      exceptions.push({
        animalId: a.id,
        tagNumber: a.tagId || a.name || a.id,
        issue: "Registry valuation does not match latest Valuation Tracker record.",
        registryValue: regValue,
        expectedValue: trackerValue,
        delta: regValue - trackerValue
      });
    }
  });

  const accountingEvents = getTenantAccountingEvents(tenantId);
  const unpostedEventsCount = accountingEvents.filter(e => e.status !== "POSTED").length;

  const discrepancyAmount = Math.abs(animalRegistryTotalValue - biologicalAssetRegisterValue);

  return {
    tenantId,
    generatedAt: new Date().toISOString(),
    totalActiveAnimals: activeAnimals.length,
    animalRegistryTotalValue,
    biologicalAssetRegisterValue,
    generalLedgerControlBalance: glBalance || animalRegistryTotalValue,
    discrepancyAmount,
    isBalanced: discrepancyAmount === 0 && exceptions.length === 0,
    unpostedEventsCount,
    exceptions
  };
}

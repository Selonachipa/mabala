import { 
  AnimalTypeConfig, 
  AnimalGrowthStage,
  FeedIngredient, 
  FeedFormulation, 
  DailyFeedLog, 
  AnimalFeedCostLedger,
  FormulationIngredient,
  PenRecord
} from "../types";
import { safeLocalStorage as localStorage } from "../utils/safeStorage";
import { getFarmOperationalConfig } from "../config/farmOperationalConfig";

// 1. Standard Animal Types & Default Growth Stage Configuration (§2)
export const DEFAULT_ANIMAL_TYPES: AnimalTypeConfig[] = [
  {
    id: "goat",
    name: "Goats",
    unitOfMeasure: "kg",
    countUnit: "head",
    stages: [
      { id: "kid", name: "Kid / Nursing", ageRangeDays: [0, 60], defaultDailyRationKg: 0.4 },
      { id: "weaner", name: "Weaner Kid", ageRangeDays: [61, 120], defaultDailyRationKg: 0.8 },
      { id: "grower", name: "Grower / Doeling / Buckling", ageRangeDays: [121, 240], defaultDailyRationKg: 1.5 },
      { id: "finisher", name: "Fattening / Meat Goat Finisher", ageRangeDays: [241, 365], defaultDailyRationKg: 2.0 },
      { id: "breeding_buck", name: "Breeding Buck / Stud", ageRangeDays: null, defaultDailyRationKg: 2.0 },
      { id: "breeding_doe", name: "Breeding Doe / Pregnant Doe", ageRangeDays: null, defaultDailyRationKg: 1.8 },
      { id: "lactating_doe", name: "Lactating / Milking Doe", ageRangeDays: null, defaultDailyRationKg: 2.2 },
      { id: "dry_doe", name: "Dry Doe / Castrate / Wether", ageRangeDays: null, defaultDailyRationKg: 1.2 }
    ]
  },
  {
    id: "pig",
    name: "Pigs",
    unitOfMeasure: "kg",
    countUnit: "head",
    stages: [
      { id: "creep", name: "Creep / Piglet", ageRangeDays: [0, 28], defaultDailyRationKg: 0.35 },
      { id: "weaner", name: "Weaner", ageRangeDays: [29, 56], defaultDailyRationKg: 1.0 },
      { id: "grower", name: "Grower", ageRangeDays: [57, 112], defaultDailyRationKg: 2.2 },
      { id: "finisher", name: "Finisher", ageRangeDays: [113, 168], defaultDailyRationKg: 3.0 },
      { id: "breeding", name: "Sow / Boar (Breeding)", ageRangeDays: null, defaultDailyRationKg: 2.5 },
      { id: "lactating", name: "Lactating Sow", ageRangeDays: null, defaultDailyRationKg: 4.5 }
    ]
  },
  {
    id: "cattle",
    name: "Cattle",
    unitOfMeasure: "kg",
    countUnit: "head",
    stages: [
      { id: "calf", name: "Calf", ageRangeDays: [0, 180], defaultDailyRationKg: 2.0 },
      { id: "weaner", name: "Weaner", ageRangeDays: [181, 365], defaultDailyRationKg: 4.5 },
      { id: "grower", name: "Grower / Heifer", ageRangeDays: [366, 730], defaultDailyRationKg: 8.0 },
      { id: "finisher", name: "Fattening / Finisher", ageRangeDays: [731, 1095], defaultDailyRationKg: 12.0 },
      { id: "breeding", name: "Breeding Bull / Brood Cow", ageRangeDays: null, defaultDailyRationKg: 10.0 },
      { id: "lactating", name: "Lactating / Milking Cow", ageRangeDays: null, defaultDailyRationKg: 12.5 },
      { id: "dry", name: "Dry Cow", ageRangeDays: null, defaultDailyRationKg: 8.5 }
    ]
  },
  {
    id: "sheep",
    name: "Sheep",
    unitOfMeasure: "kg",
    countUnit: "head",
    stages: [
      { id: "lamb", name: "Lamb / Nursing", ageRangeDays: [0, 60], defaultDailyRationKg: 0.4 },
      { id: "weaner", name: "Weaner", ageRangeDays: [61, 120], defaultDailyRationKg: 0.9 },
      { id: "grower", name: "Grower / Hogget", ageRangeDays: [121, 240], defaultDailyRationKg: 1.6 },
      { id: "finisher", name: "Fattening / Mutton Finisher", ageRangeDays: [241, 365], defaultDailyRationKg: 2.2 },
      { id: "breeding_ram", name: "Breeding Ram / Stud", ageRangeDays: null, defaultDailyRationKg: 2.2 },
      { id: "breeding_ewe", name: "Breeding Ewe / Pregnant Ewe", ageRangeDays: null, defaultDailyRationKg: 1.8 },
      { id: "lactating_ewe", name: "Lactating Ewe", ageRangeDays: null, defaultDailyRationKg: 2.4 },
      { id: "dry_ewe", name: "Dry Ewe / Wether", ageRangeDays: null, defaultDailyRationKg: 1.3 }
    ]
  },
  {
    id: "chicken",
    name: "Chickens / Poultry",
    unitOfMeasure: "kg",
    countUnit: "flock",
    stages: [
      { id: "starter", name: "Chick / Starter", ageRangeDays: [0, 21], defaultDailyRationKg: 0.04 },
      { id: "grower", name: "Grower / Pullet", ageRangeDays: [22, 42], defaultDailyRationKg: 0.09 },
      { id: "finisher_layer", name: "Layer Production / Broiler-Finisher", ageRangeDays: null, defaultDailyRationKg: 0.13 },
      { id: "breeder", name: "Breeder Flock", ageRangeDays: null, defaultDailyRationKg: 0.14 }
    ]
  },
  {
    id: "fish",
    name: "Fish / Aquaculture",
    unitOfMeasure: "kg",
    countUnit: "1000 fingerlings",
    stages: [
      { id: "fry", name: "Fry", ageRangeDays: [0, 30], defaultDailyRationKg: 0.2 },
      { id: "fingerling", name: "Fingerling", ageRangeDays: [31, 90], defaultDailyRationKg: 1.0 },
      { id: "growout", name: "Grow-out", ageRangeDays: [91, 240], defaultDailyRationKg: 3.5 },
      { id: "broodstock", name: "Broodstock", ageRangeDays: null, defaultDailyRationKg: 2.0 }
    ]
  }
];

// Helper: Local storage key helpers
const getAnimalTypeKey = (tenantId: string) => `mabala_${tenantId || "default"}_animal_types`;
const getIngKey = (tenantId: string) => `mabala_${tenantId || "default"}_feed_ingredients`;
const getFormKey = (tenantId: string) => `mabala_${tenantId || "default"}_feed_formulations`;
const getLogKey = (tenantId: string) => `mabala_${tenantId || "default"}_daily_feed_logs`;
const getLedgerKey = (tenantId: string) => `mabala_${tenantId || "default"}_animal_feed_ledgers`;
const getPenKey = (tenantId: string) => `mabala_${tenantId || "default"}_pens`;

// Animal Type & Growth Stage Services
export function getTenantAnimalTypes(tenantId: string = "default"): AnimalTypeConfig[] {
  const cached = localStorage.getItem(getAnimalTypeKey(tenantId));
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Merge missing default species and missing stages (e.g. goats, sheep) into cached
        const merged: AnimalTypeConfig[] = [...parsed];
        DEFAULT_ANIMAL_TYPES.forEach(defType => {
          const existingIdx = merged.findIndex(m => m.id === defType.id);
          if (existingIdx === -1) {
            merged.push(defType);
          } else {
            // Check if any default stages are missing in the existing species config
            const existingStages = merged[existingIdx].stages || [];
            const stageIds = new Set(existingStages.map(s => s.id));
            let addedStage = false;
            defType.stages.forEach(stg => {
              if (!stageIds.has(stg.id)) {
                existingStages.push(stg);
                addedStage = true;
              }
            });
            if (addedStage) {
              merged[existingIdx].stages = existingStages;
            }
          }
        });
        localStorage.setItem(getAnimalTypeKey(tenantId), JSON.stringify(merged));
        return merged;
      }
    } catch (e) {
      console.error("[feedEngineService] Error reading animal types", e);
    }
  }
  localStorage.setItem(getAnimalTypeKey(tenantId), JSON.stringify(DEFAULT_ANIMAL_TYPES));
  return DEFAULT_ANIMAL_TYPES;
}

export function saveTenantAnimalType(tenantId: string = "default", typeData: AnimalTypeConfig): AnimalTypeConfig[] {
  const current = getTenantAnimalTypes(tenantId);
  const idx = current.findIndex(t => t.id === typeData.id);
  if (idx >= 0) {
    current[idx] = typeData;
  } else {
    current.push(typeData);
  }
  localStorage.setItem(getAnimalTypeKey(tenantId), JSON.stringify(current));
  return current;
}

export function saveTenantGrowthStage(
  tenantId: string = "default", 
  animalTypeId: string, 
  stage: AnimalGrowthStage
): AnimalTypeConfig[] {
  const current = getTenantAnimalTypes(tenantId);
  const typeIdx = current.findIndex(t => t.id === animalTypeId);
  if (typeIdx >= 0) {
    const stgIdx = current[typeIdx].stages.findIndex(s => s.id === stage.id);
    if (stgIdx >= 0) {
      current[typeIdx].stages[stgIdx] = stage;
    } else {
      current[typeIdx].stages.push(stage);
    }
    localStorage.setItem(getAnimalTypeKey(tenantId), JSON.stringify(current));
  }
  return current;
}

export function deleteTenantGrowthStage(
  tenantId: string = "default", 
  animalTypeId: string, 
  stageId: string
): AnimalTypeConfig[] {
  const current = getTenantAnimalTypes(tenantId);
  const typeIdx = current.findIndex(t => t.id === animalTypeId);
  if (typeIdx >= 0) {
    current[typeIdx].stages = current[typeIdx].stages.filter(s => s.id !== stageId);
    localStorage.setItem(getAnimalTypeKey(tenantId), JSON.stringify(current));
  }
  return current;
}

export function deleteTenantAnimalType(tenantId: string = "default", animalTypeId: string): AnimalTypeConfig[] {
  const current = getTenantAnimalTypes(tenantId).filter(t => t.id !== animalTypeId);
  localStorage.setItem(getAnimalTypeKey(tenantId), JSON.stringify(current));
  return current;
}

export function resetTenantAnimalTypesToDefaults(tenantId: string = "default"): AnimalTypeConfig[] {
  localStorage.setItem(getAnimalTypeKey(tenantId), JSON.stringify(DEFAULT_ANIMAL_TYPES));
  return DEFAULT_ANIMAL_TYPES;
}

// 2. Starter Ingredient Template (§3)
export const STARTER_INGREDIENT_TEMPLATE: Omit<FeedIngredient, "id" | "tenantId" | "updatedAt">[] = [
  { name: "Meal No. 3 (Mea No.3)", category: "energy", unit: "kg", bagSizeKg: 1, currentCostPerUnit: 2.53, crudeProteinPercent: 11.0, crudeFiberPercent: 11.5, energyKcalPerKg: 2400, energyMjPerKg: 10.0, currentStockKg: 650, minThresholdKg: 100, active: true, costHistory: [] },
  { name: "Crushed Maize", category: "energy", unit: "kg", bagSizeKg: null, currentCostPerUnit: 3.50, crudeProteinPercent: 8.8, crudeFiberPercent: 2.2, energyKcalPerKg: 3350, energyMjPerKg: 14.0, currentStockKg: 1200, minThresholdKg: 200, active: true, costHistory: [] },
  { name: "Soya ME", category: "protein", unit: "kg", bagSizeKg: 50, pricePaid: 592, currentCostPerUnit: 11.84, crudeProteinPercent: 44.0, crudeFiberPercent: 5.5, energyKcalPerKg: 3200, energyMjPerKg: 13.4, currentStockKg: 140, minThresholdKg: 150, active: true, costHistory: [] },
  { name: "Soya SE", category: "protein", unit: "kg", bagSizeKg: 50, pricePaid: 450, currentCostPerUnit: 9.00, crudeProteinPercent: 42.0, crudeFiberPercent: 6.0, energyKcalPerKg: 3100, energyMjPerKg: 13.0, currentStockKg: 300, minThresholdKg: 80, active: true, costHistory: [] },
  { name: "Soya Full Fat", category: "protein", unit: "kg", bagSizeKg: 50, pricePaid: 903.5, currentCostPerUnit: 18.07, crudeProteinPercent: 38.0, crudeFiberPercent: 5.0, energyKcalPerKg: 3600, energyMjPerKg: 15.0, currentStockKg: 250, minThresholdKg: 50, active: true, costHistory: [] },
  { name: "Wheat Bran", category: "energy", unit: "kg", bagSizeKg: 25, pricePaid: 55, currentCostPerUnit: 2.20, crudeProteinPercent: 15.0, crudeFiberPercent: 9.5, energyKcalPerKg: 2200, energyMjPerKg: 9.2, currentStockKg: 450, minThresholdKg: 100, active: true, costHistory: [] },
  { name: "Fish Meal", category: "protein", unit: "kg", bagSizeKg: 50, pricePaid: 2265.5, currentCostPerUnit: 45.31, crudeProteinPercent: 65.0, crudeFiberPercent: 1.0, energyKcalPerKg: 2800, energyMjPerKg: 11.7, currentStockKg: 100, minThresholdKg: 30, active: true, costHistory: [] },
  { name: "Sunflower Cake", category: "protein", unit: "kg", bagSizeKg: null, currentCostPerUnit: 4.96, crudeProteinPercent: 30.0, crudeFiberPercent: 20.0, energyKcalPerKg: 2200, energyMjPerKg: 9.2, currentStockKg: 180, minThresholdKg: 40, active: true, costHistory: [] },
  { name: "Blood Meal", category: "protein", unit: "kg", bagSizeKg: null, currentCostPerUnit: 18.00, crudeProteinPercent: 80.0, crudeFiberPercent: 1.0, energyKcalPerKg: 2900, energyMjPerKg: 12.1, currentStockKg: 80, minThresholdKg: 20, active: true, costHistory: [] },
  { name: "Groundnut Cake", category: "protein", unit: "kg", bagSizeKg: null, currentCostPerUnit: 0.00, crudeProteinPercent: 44.0, crudeFiberPercent: 8.0, energyKcalPerKg: 3000, energyMjPerKg: 12.5, currentStockKg: 150, minThresholdKg: 30, active: true, costHistory: [] },
  { name: "Limestone / Lime", category: "mineral", unit: "kg", bagSizeKg: 50, pricePaid: 65, currentCostPerUnit: 1.30, crudeProteinPercent: 0, crudeFiberPercent: 0, energyKcalPerKg: 0, energyMjPerKg: 0, currentStockKg: 120, minThresholdKg: 40, active: true, costHistory: [] },
  { name: "DCP", category: "mineral", unit: "kg", bagSizeKg: null, currentCostPerUnit: 37.35, crudeProteinPercent: 0, crudeFiberPercent: 0, energyKcalPerKg: 0, energyMjPerKg: 0, currentStockKg: 45, minThresholdKg: 20, active: true, costHistory: [] },
  { name: "MCP", category: "mineral", unit: "kg", bagSizeKg: null, currentCostPerUnit: 38.60, crudeProteinPercent: 0, crudeFiberPercent: 0, energyKcalPerKg: 0, energyMjPerKg: 0, currentStockKg: 40, minThresholdKg: 15, active: true, costHistory: [] },
  { name: "Lysine", category: "additive", unit: "kg", bagSizeKg: null, currentCostPerUnit: 46.14, crudeProteinPercent: 0, crudeFiberPercent: 0, energyKcalPerKg: 0, energyMjPerKg: 0, currentStockKg: 25, minThresholdKg: 10, active: true, costHistory: [] },
  { name: "Methionine", category: "additive", unit: "kg", bagSizeKg: null, currentCostPerUnit: 98.77, crudeProteinPercent: 0, crudeFiberPercent: 0, energyKcalPerKg: 0, energyMjPerKg: 0, currentStockKg: 15, minThresholdKg: 8, active: true, costHistory: [] },
  { name: "Salt", category: "mineral", unit: "kg", bagSizeKg: null, currentCostPerUnit: 5.76, crudeProteinPercent: 0, crudeFiberPercent: 0, energyKcalPerKg: 0, energyMjPerKg: 0, currentStockKg: 50, minThresholdKg: 15, active: true, costHistory: [] },
  { name: "Pig Premix", category: "additive", unit: "kg", bagSizeKg: null, currentCostPerUnit: 388.38, crudeProteinPercent: 0, crudeFiberPercent: 0, energyKcalPerKg: 0, energyMjPerKg: 0, currentStockKg: 18, minThresholdKg: 25, active: true, costHistory: [] },
  { name: "Toxifin", category: "additive", unit: "kg", bagSizeKg: null, currentCostPerUnit: 0.00, crudeProteinPercent: 0, crudeFiberPercent: 0, energyKcalPerKg: 0, energyMjPerKg: 0, currentStockKg: 10, minThresholdKg: 5, active: true, costHistory: [] },
  { name: "Eskaline", category: "additive", unit: "kg", bagSizeKg: null, currentCostPerUnit: 99.16, crudeProteinPercent: 0, crudeFiberPercent: 0, energyKcalPerKg: 0, energyMjPerKg: 0, currentStockKg: 12, minThresholdKg: 5, active: true, costHistory: [] },
  { name: "Urban Feed (bought-in complete feed)", category: "complete-feed", unit: "kg", bagSizeKg: 15, pricePaid: 783.3, currentCostPerUnit: 52.22, crudeProteinPercent: 18.0, crudeFiberPercent: 4.5, energyKcalPerKg: 3100, energyMjPerKg: 13.0, currentStockKg: 90, minThresholdKg: 30, active: true, costHistory: [] },
  { name: "Farm Feed — Creep", category: "complete-feed", unit: "kg", bagSizeKg: 50, pricePaid: 825, currentCostPerUnit: 16.50, crudeProteinPercent: 20.0, crudeFiberPercent: 3.5, energyKcalPerKg: 3300, energyMjPerKg: 13.8, currentStockKg: 200, minThresholdKg: 50, active: true, costHistory: [] },
  { name: "Farm Feed — Weaner Pellet", category: "complete-feed", unit: "kg", bagSizeKg: 50, pricePaid: 675, currentCostPerUnit: 13.50, crudeProteinPercent: 18.0, crudeFiberPercent: 4.0, energyKcalPerKg: 3200, energyMjPerKg: 13.4, currentStockKg: 350, minThresholdKg: 60, active: true, costHistory: [] },
  { name: "Farm Feed — Weaner Concentrate", category: "complete-feed", unit: "kg", bagSizeKg: 50, pricePaid: 336, currentCostPerUnit: 6.72, crudeProteinPercent: 35.0, crudeFiberPercent: 5.0, energyKcalPerKg: 2800, energyMjPerKg: 11.7, currentStockKg: 280, minThresholdKg: 50, active: true, costHistory: [] },
  { name: "Farm Feed — Grower", category: "complete-feed", unit: "kg", bagSizeKg: 50, pricePaid: 276, currentCostPerUnit: 5.52, crudeProteinPercent: 16.0, crudeFiberPercent: 5.5, energyKcalPerKg: 3000, energyMjPerKg: 12.5, currentStockKg: 600, minThresholdKg: 100, active: true, costHistory: [] },
  { name: "Farm Feed — Finisher", category: "complete-feed", unit: "kg", bagSizeKg: 50, pricePaid: 234, currentCostPerUnit: 4.68, crudeProteinPercent: 14.0, crudeFiberPercent: 6.0, energyKcalPerKg: 2950, energyMjPerKg: 12.3, currentStockKg: 400, minThresholdKg: 100, active: true, costHistory: [] },
  { name: "Farm Feed — Sow&Boar", category: "complete-feed", unit: "kg", bagSizeKg: 50, pricePaid: 226, currentCostPerUnit: 4.52, crudeProteinPercent: 14.0, crudeFiberPercent: 7.0, energyKcalPerKg: 2850, energyMjPerKg: 11.9, currentStockKg: 300, minThresholdKg: 80, active: true, costHistory: [] },
  { name: "Farm Feed — Lactating", category: "complete-feed", unit: "kg", bagSizeKg: 50, pricePaid: 228, currentCostPerUnit: 4.56, crudeProteinPercent: 16.5, crudeFiberPercent: 5.0, energyKcalPerKg: 3100, energyMjPerKg: 13.0, currentStockKg: 250, minThresholdKg: 60, active: true, costHistory: [] }
];

// Pen Services
export const DEFAULT_PIG_PENS: { code: string; stageId: string; headcount: number }[] = [];

export function getTenantPens(tenantId: string = "default"): PenRecord[] {
  const primaryKey = getPenKey(tenantId);
  const cached = localStorage.getItem(primaryKey);
  let currentPens: PenRecord[] = [];

  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        currentPens = parsed;
      }
    } catch (e) {
      console.error("[feedEngineService] Error reading pens", e);
    }
  }

  // Pre-seed standard starter pens for tenant across species if none exist
  if (currentPens.length === 0) {
    const now = new Date().toISOString();
    currentPens = [
      { id: `pen_${tenantId}_p01`, tenantId, code: "PEN-P01", name: "Farrowing Pen Alpha", animalTypeId: "pig", stageId: "breeding", capacity: 15, headcount: 8, active: true, assignedFormulationId: null, notes: "Farrowing unit with heat lamps & creep area", createdAt: now, updatedAt: now },
      { id: `pen_${tenantId}_p02`, tenantId, code: "PEN-P02", name: "Pig Weaner Pen 1", animalTypeId: "pig", stageId: "weaner", capacity: 30, headcount: 18, active: true, assignedFormulationId: null, notes: "Weaner nursery pen with automatic drinkers", createdAt: now, updatedAt: now },
      { id: `pen_${tenantId}_p03`, tenantId, code: "PEN-P03", name: "Grower Finisher Yard A", animalTypeId: "pig", stageId: "grower", capacity: 35, headcount: 22, active: true, assignedFormulationId: null, notes: "Concrete slatted floor grower finisher pen", createdAt: now, updatedAt: now },
      { id: `pen_${tenantId}_c01`, tenantId, code: "PEN-C01", name: "Cattle Pasture Paddock A", animalTypeId: "cattle", stageId: "grower", capacity: 50, headcount: 32, active: true, assignedFormulationId: null, notes: "Fenced grazing paddock with fresh water trough", createdAt: now, updatedAt: now },
      { id: `pen_${tenantId}_c02`, tenantId, code: "PEN-C02", name: "Dairy Milking Pen & Stalls", animalTypeId: "cattle", stageId: "breeding", capacity: 20, headcount: 12, active: true, assignedFormulationId: null, notes: "Lactating dairy cow shed with milking stanchions", createdAt: now, updatedAt: now },
      { id: `pen_${tenantId}_g01`, tenantId, code: "PEN-G01", name: "Goat Breeding Enclosure", animalTypeId: "goat", stageId: "breeding", capacity: 40, headcount: 25, active: true, assignedFormulationId: null, notes: "Elevated slatted goat shed & maternity section", createdAt: now, updatedAt: now },
      { id: `pen_${tenantId}_g02`, tenantId, code: "PEN-G02", name: "Goat Maternity & Nursing Pen", animalTypeId: "goat", stageId: "kid", capacity: 25, headcount: 10, active: true, assignedFormulationId: null, notes: "Maternity pen for kidding does and nursing kids", createdAt: now, updatedAt: now }
    ];
    localStorage.setItem(primaryKey, JSON.stringify(currentPens));
  }

  // Also collect and merge any custom pens created across any other tenant key in localStorage
  try {
    const allPenKeys = Object.keys(localStorage).filter(k => k.startsWith("mabala_") && k.endsWith("_pens") && k !== primaryKey);
    const existingIds = new Set(currentPens.map(p => p.id || p.code.toUpperCase()));
    const existingNames = new Set(currentPens.map(p => p.name.toLowerCase()));

    allPenKeys.forEach(key => {
      try {
        const otherData = localStorage.getItem(key);
        if (otherData) {
          const parsedOther: PenRecord[] = JSON.parse(otherData);
          if (Array.isArray(parsedOther)) {
            parsedOther.forEach(otherPen => {
              if (
                otherPen &&
                otherPen.name &&
                !existingIds.has(otherPen.id || "") &&
                !existingIds.has((otherPen.code || "").toUpperCase()) &&
                !existingNames.has(otherPen.name.toLowerCase())
              ) {
                currentPens.push(otherPen);
                existingIds.add(otherPen.id || "");
                existingNames.add(otherPen.name.toLowerCase());
              }
            });
          }
        }
      } catch (_) {}
    });
  } catch (_) {}

  return currentPens;
}

export function saveTenantPen(
  tenantId: string = "default", 
  penData: Partial<PenRecord> & { code: string; animalTypeId: string; stageId: string }
): PenRecord {
  const pens = getTenantPens(tenantId);
  const idx = pens.findIndex(p => p.id === penData.id || p.code.toUpperCase() === penData.code.toUpperCase());
  let targetPen: PenRecord;

  if (idx >= 0) {
    targetPen = { ...pens[idx], ...penData, updatedAt: new Date().toISOString() };
    pens[idx] = targetPen;
  } else {
    targetPen = {
      id: penData.id || `pen_${penData.code}_${Date.now()}`,
      tenantId,
      farmNodeId: penData.farmNodeId,
      code: penData.code.toUpperCase(),
      name: penData.name || `Pen ${penData.code.toUpperCase()}`,
      animalTypeId: penData.animalTypeId,
      stageId: penData.stageId,
      assignedFormulationId: penData.assignedFormulationId || null,
      headcount: penData.headcount || 10,
      capacity: penData.capacity || 20,
      notes: penData.notes || "",
      active: penData.active ?? true,
      createdAt: penData.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    pens.push(targetPen);
  }

  localStorage.setItem(getPenKey(tenantId), JSON.stringify(pens));
  return targetPen;
}

export function deleteTenantPen(tenantId: string = "default", penId: string): boolean {
  const pens = getTenantPens(tenantId);
  const filtered = pens.filter(p => p.id !== penId && p.code !== penId);
  if (filtered.length === pens.length) return false;
  localStorage.setItem(getPenKey(tenantId), JSON.stringify(filtered));
  return true;
}

export function adjustTenantPenHeadcount(
  tenantId: string = "default", 
  penId: string, 
  countOrDelta: number,
  reason?: string
): PenRecord | null {
  const pens = getTenantPens(tenantId);
  const idx = pens.findIndex(p => p.id === penId || p.code === penId);
  if (idx >= 0) {
    let newCount = countOrDelta;
    if (countOrDelta < 0) {
      newCount = Math.max(0, (pens[idx].headcount || 0) + countOrDelta);
    }
    pens[idx] = {
      ...pens[idx],
      headcount: Math.max(0, newCount),
      notes: reason ? `${pens[idx].notes ? pens[idx].notes + " | " : ""}${reason}` : pens[idx].notes,
      updatedAt: new Date().toISOString()
    };
    localStorage.setItem(getPenKey(tenantId), JSON.stringify(pens));
    return pens[idx];
  }
  return null;
}

export function getPenDailyFeedMetrics(
  pen: PenRecord,
  formulations?: FeedFormulation[]
): {
  activeRecipe: FeedFormulation | undefined;
  dailyRationKg: number;
  costPerKg: number;
  totalDailyFeedKg: number;
  totalDailyCost: number;
} {
  const forms = formulations || [];
  let recipe: FeedFormulation | undefined;

  if (pen.assignedFormulationId) {
    recipe = forms.find(f => f.id === pen.assignedFormulationId);
  }
  if (!recipe) {
    recipe = forms.find(
      f => f.animalTypeId === pen.animalTypeId && 
           f.stageId.toLowerCase() === pen.stageId.toLowerCase() && 
           f.status === "active"
    ) || forms.find(f => f.animalTypeId === pen.animalTypeId && f.status === "active");
  }

  const headcount = pen.headcount || 0;
  const opConfig = getFarmOperationalConfig();
  const dailyRationKg = recipe ? (recipe.dailyQtyPerAnimal || opConfig.defaultDailyRationKg) : opConfig.defaultDailyRationKg;
  const costPerKg = recipe ? (recipe.costPerKgMix || opConfig.defaultFeedCostPerKg) : opConfig.defaultFeedCostPerKg;
  const totalDailyFeedKg = Number((headcount * dailyRationKg).toFixed(2));
  const totalDailyCost = Number((totalDailyFeedKg * costPerKg).toFixed(2));

  return {
    activeRecipe: recipe,
    dailyRationKg,
    costPerKg,
    totalDailyFeedKg,
    totalDailyCost
  };
}

// 3. Ingredient Services
export function getTenantIngredients(tenantId: string = "default"): FeedIngredient[] {
  const cached = localStorage.getItem(getIngKey(tenantId));
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    } catch (e) {
      console.error("[feedEngineService] Error reading ingredients", e);
    }
  }

  // Pre-load starter template for new tenant (§3)
  const initialized: FeedIngredient[] = STARTER_INGREDIENT_TEMPLATE.map((tmpl, idx) => ({
    ...tmpl,
    id: `ing_tmpl_${idx + 1}_${Date.now()}`,
    tenantId,
    updatedAt: new Date().toISOString()
  }));
  localStorage.setItem(getIngKey(tenantId), JSON.stringify(initialized));
  return initialized;
}

export function saveTenantIngredient(
  tenantId: string = "default", 
  ingredientData: Partial<FeedIngredient> & { name: string; unit: "kg" | "g" | "litre"; category: FeedIngredient["category"] },
  user: string = "System"
): FeedIngredient {
  const currentList = getTenantIngredients(tenantId);
  const existingIdx = currentList.findIndex(i => i.id === ingredientData.id);
  const now = new Date().toISOString();

  let targetIngredient: FeedIngredient;

  if (existingIdx >= 0) {
    const prev = currentList[existingIdx];
    const newCost = ingredientData.currentCostPerUnit ?? prev.currentCostPerUnit;
    const costHistory = [...(prev.costHistory || [])];

    if (newCost !== prev.currentCostPerUnit) {
      costHistory.push({
        costPerUnit: newCost,
        effectiveFrom: now,
        changedBy: user
      });
    }

    targetIngredient = {
      ...prev,
      ...ingredientData,
      currentCostPerUnit: newCost,
      costHistory,
      updatedAt: now,
      updatedBy: user
    };
    currentList[existingIdx] = targetIngredient;
  } else {
    const newCost = ingredientData.currentCostPerUnit ?? 0;
    targetIngredient = {
      id: `ing_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      tenantId,
      name: ingredientData.name,
      unit: ingredientData.unit,
      category: ingredientData.category,
      currentCostPerUnit: newCost,
      active: ingredientData.active ?? true,
      costHistory: newCost > 0 ? [{ costPerUnit: newCost, effectiveFrom: now, changedBy: user }] : [],
      updatedAt: now,
      updatedBy: user
    };
    currentList.push(targetIngredient);
  }

  localStorage.setItem(getIngKey(tenantId), JSON.stringify(currentList));

  // Recalculate cost on active formulations using this ingredient
  recalculateFormulationsForIngredient(tenantId, targetIngredient);

  return targetIngredient;
}

// 4. Formulation Services & Starters
export const STARTER_FORMULATION_TEMPLATES = [
  {
    animalTypeId: "pig",
    stageId: "grower",
    name: "Standard Pig Grower Mash (16% CP)",
    status: "active" as const,
    version: 1,
    batchSize: 100,
    dailyQtyPerAnimal: 1.8,
    ingredientRatios: [
      { name: "Crushed Maize", qty: 52 },
      { name: "Soya ME", qty: 22 },
      { name: "Wheat Bran", qty: 20 },
      { name: "Limestone / Lime", qty: 2.5 },
      { name: "DCP", qty: 1.5 },
      { name: "Salt", qty: 0.5 },
      { name: "Pig Premix", qty: 1.5 }
    ]
  },
  {
    animalTypeId: "pig",
    stageId: "weaner",
    name: "High-Digestibility Pig Weaner Ration (18% CP)",
    status: "active" as const,
    version: 1,
    batchSize: 100,
    dailyQtyPerAnimal: 1.0,
    ingredientRatios: [
      { name: "Crushed Maize", qty: 45 },
      { name: "Soya Full Fat", qty: 25 },
      { name: "Fish Meal", qty: 8 },
      { name: "Wheat Bran", qty: 16 },
      { name: "Limestone / Lime", qty: 2.5 },
      { name: "MCP", qty: 1.5 },
      { name: "Salt", qty: 0.5 },
      { name: "Pig Premix", qty: 1.5 }
    ]
  },
  {
    animalTypeId: "pig",
    stageId: "finisher",
    name: "Economic Pig Finisher Mash (14% CP)",
    status: "active" as const,
    version: 1,
    batchSize: 100,
    dailyQtyPerAnimal: 2.5,
    ingredientRatios: [
      { name: "Meal No. 3 (Mea No.3)", qty: 55 },
      { name: "Sunflower Cake", qty: 20 },
      { name: "Wheat Bran", qty: 20 },
      { name: "Limestone / Lime", qty: 2.5 },
      { name: "Salt", qty: 1.0 },
      { name: "Pig Premix", qty: 1.5 }
    ]
  },
  {
    animalTypeId: "pig",
    stageId: "creep",
    name: "Piglet Creep Starter Pellet Mix (20% CP)",
    status: "active" as const,
    version: 1,
    batchSize: 100,
    dailyQtyPerAnimal: 0.35,
    ingredientRatios: [
      { name: "Crushed Maize", qty: 40 },
      { name: "Soya ME", qty: 28 },
      { name: "Fish Meal", qty: 10 },
      { name: "Wheat Bran", qty: 15 },
      { name: "Limestone / Lime", qty: 2.5 },
      { name: "MCP", qty: 2.0 },
      { name: "Pig Premix", qty: 2.5 }
    ]
  },
  {
    animalTypeId: "chicken",
    stageId: "starter",
    name: "Broiler Starter Crumble (22% CP)",
    status: "active" as const,
    version: 1,
    batchSize: 100,
    dailyQtyPerAnimal: 0.05,
    ingredientRatios: [
      { name: "Crushed Maize", qty: 50 },
      { name: "Soya ME", qty: 32 },
      { name: "Fish Meal", qty: 8 },
      { name: "Wheat Bran", qty: 5 },
      { name: "Limestone / Lime", qty: 2.0 },
      { name: "MCP", qty: 1.5 },
      { name: "Salt", qty: 0.5 },
      { name: "Pig Premix", qty: 1.0 }
    ]
  },
  {
    animalTypeId: "chicken",
    stageId: "finisher_layer",
    name: "Layer Commercial Production Mash (16.5% CP + Calcium)",
    status: "active" as const,
    version: 1,
    batchSize: 100,
    dailyQtyPerAnimal: 0.12,
    ingredientRatios: [
      { name: "Crushed Maize", qty: 52 },
      { name: "Soya ME", qty: 20 },
      { name: "Sunflower Cake", qty: 12 },
      { name: "Wheat Bran", qty: 6 },
      { name: "Limestone / Lime", qty: 8.0 },
      { name: "MCP", qty: 1.0 },
      { name: "Salt", qty: 0.5 },
      { name: "Pig Premix", qty: 0.5 }
    ]
  },
  {
    animalTypeId: "cattle",
    stageId: "finisher",
    name: "Beef Feedlot Fattening Ration (13.5% CP)",
    status: "active" as const,
    version: 1,
    batchSize: 100,
    dailyQtyPerAnimal: 8.5,
    ingredientRatios: [
      { name: "Meal No. 3 (Mea No.3)", qty: 45 },
      { name: "Wheat Bran", qty: 25 },
      { name: "Sunflower Cake", qty: 22 },
      { name: "Limestone / Lime", qty: 3.5 },
      { name: "Salt", qty: 2.5 },
      { name: "Pig Premix", qty: 2.0 }
    ]
  },
  {
    animalTypeId: "goat",
    stageId: "grower",
    name: "Goat Intensive Growth Ration (15% CP)",
    status: "active" as const,
    version: 1,
    batchSize: 100,
    dailyQtyPerAnimal: 0.9,
    ingredientRatios: [
      { name: "Meal No. 3 (Mea No.3)", qty: 40 },
      { name: "Wheat Bran", qty: 30 },
      { name: "Sunflower Cake", qty: 22 },
      { name: "Limestone / Lime", qty: 3.0 },
      { name: "Salt", qty: 2.5 },
      { name: "Pig Premix", qty: 2.5 }
    ]
  }
];

export function getTenantFormulations(tenantId: string = "default"): FeedFormulation[] {
  const cached = localStorage.getItem(getFormKey(tenantId));
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    } catch (e) {
      console.error("[feedEngineService] Error reading formulations", e);
    }
  }

  // Pre-seed default formulations for tenant mapped to tenant master ingredients
  const masterIngredients = getTenantIngredients(tenantId);
  const now = new Date().toISOString();

  const initialized: FeedFormulation[] = STARTER_FORMULATION_TEMPLATES.map((tmpl, idx) => {
    const ingredients: FormulationIngredient[] = tmpl.ingredientRatios.map(r => {
      const master = masterIngredients.find(m => m.name.toLowerCase().includes(r.name.toLowerCase())) || masterIngredients[0];
      return {
        ingredientId: master.id,
        ingredientName: master.name,
        inclusionQtyPerUnit: r.qty,
        unit: master.unit,
        costPerKgOverride: master.currentCostPerUnit
      };
    });

    const { costPerKgMix, costPerAnimalPerDay } = computeFormulationCosts(
      ingredients,
      masterIngredients,
      tmpl.batchSize,
      tmpl.dailyQtyPerAnimal
    );

    return {
      id: `form_init_${tmpl.animalTypeId}_${tmpl.stageId}_${idx + 1}`,
      tenantId,
      animalTypeId: tmpl.animalTypeId,
      stageId: tmpl.stageId,
      name: tmpl.name,
      status: tmpl.status,
      version: tmpl.version,
      effectiveFrom: now,
      batchSize: tmpl.batchSize,
      dailyQtyPerAnimal: tmpl.dailyQtyPerAnimal,
      ingredients,
      costPerKgMix,
      costPerAnimalPerDay,
      createdBy: "Mabala Agronomic Master",
      createdAt: now,
      updatedAt: now
    };
  });

  localStorage.setItem(getFormKey(tenantId), JSON.stringify(initialized));
  return initialized;
}

// Compute formulation cost server/service side (§4)
export function computeFormulationCosts(
  ingredients: FormulationIngredient[],
  masterIngredients: FeedIngredient[],
  batchSize: number = 100,
  dailyQtyPerAnimal: number = 1.0
) {
  let totalBatchCost = 0;
  let totalInclusionQty = 0;
  let totalCrudeProteinKg = 0;
  let totalCrudeFiberKg = 0;
  let totalEnergyKcal = 0;

  const resolvedIngredients = ingredients.map(item => {
    const master = masterIngredients.find(m => m.id === item.ingredientId);
    const unitCost = item.costPerKgOverride !== undefined && item.costPerKgOverride !== null
      ? item.costPerKgOverride 
      : (master?.currentCostPerUnit || 0);
    
    const cpPct = item.crudeProteinOverride !== undefined && item.crudeProteinOverride !== null
      ? item.crudeProteinOverride
      : (master?.crudeProteinPercent || 0);

    const cfPct = item.crudeFiberOverride !== undefined && item.crudeFiberOverride !== null
      ? item.crudeFiberOverride
      : (master?.crudeFiberPercent || 0);

    const energyKcal = item.energyKcalOverride !== undefined && item.energyKcalOverride !== null
      ? item.energyKcalOverride
      : (master?.energyKcalPerKg || 0);

    const lineCost = item.inclusionQtyPerUnit * unitCost;
    const lineProteinKg = item.inclusionQtyPerUnit * (cpPct / 100);
    const lineFiberKg = item.inclusionQtyPerUnit * (cfPct / 100);
    const lineEnergyKcal = item.inclusionQtyPerUnit * energyKcal;

    totalBatchCost += lineCost;
    totalInclusionQty += item.inclusionQtyPerUnit;
    totalCrudeProteinKg += lineProteinKg;
    totalCrudeFiberKg += lineFiberKg;
    totalEnergyKcal += lineEnergyKcal;

    return {
      ...item,
      ingredientName: master?.name || item.ingredientName,
      unitCost,
      cpPct,
      cfPct,
      energyKcal,
      lineCost,
      lineProteinKg,
      lineFiberKg,
      lineEnergyKcal
    };
  });

  const qtyBasis = totalInclusionQty > 0 ? totalInclusionQty : (batchSize > 0 ? batchSize : 1);
  const costPerKgMix = qtyBasis > 0 ? totalBatchCost / qtyBasis : 0;
  const costPerAnimalPerDay = costPerKgMix * dailyQtyPerAnimal;

  const crudeProteinPercent = (totalCrudeProteinKg / qtyBasis) * 100;
  const crudeFiberPercent = (totalCrudeFiberKg / qtyBasis) * 100;
  const energyKcalPerKg = totalEnergyKcal / qtyBasis;
  const energyMjPerKg = (energyKcalPerKg * 0.004184); // 1 kcal = 0.004184 MJ

  return {
    resolvedIngredients,
    totalInclusionQty,
    totalBatchCost: Number(totalBatchCost.toFixed(2)),
    costPerKgMix: Number(costPerKgMix.toFixed(4)),
    costPerAnimalPerDay: Number(costPerAnimalPerDay.toFixed(2)),
    nutrients: {
      totalCrudeProteinKg: Number(totalCrudeProteinKg.toFixed(2)),
      crudeProteinPercent: Number(crudeProteinPercent.toFixed(2)),
      totalCrudeFiberKg: Number(totalCrudeFiberKg.toFixed(2)),
      crudeFiberPercent: Number(crudeFiberPercent.toFixed(2)),
      totalEnergyKcal: Number(totalEnergyKcal.toFixed(0)),
      energyKcalPerKg: Number(energyKcalPerKg.toFixed(0)),
      energyMjPerKg: Number(energyMjPerKg.toFixed(2))
    }
  };
}

export function saveTenantFormulation(
  tenantId: string = "default",
  formulationData: Omit<FeedFormulation, "id" | "tenantId" | "costPerKgMix" | "costPerAnimalPerDay" | "createdAt" | "updatedAt"> & { id?: string },
  user: string = "System",
  options: { bumpVersion?: boolean; setAsPrimaryActive?: boolean } = {}
): FeedFormulation {
  const formulations = getTenantFormulations(tenantId);
  const masterIngredients = getTenantIngredients(tenantId);
  const now = new Date().toISOString();

  const { costPerKgMix, costPerAnimalPerDay } = computeFormulationCosts(
    formulationData.ingredients,
    masterIngredients,
    formulationData.batchSize,
    formulationData.dailyQtyPerAnimal
  );

  const existingIdx = formulations.findIndex(f => f.id === formulationData.id);

  let resultFormulation: FeedFormulation;

  if (existingIdx >= 0) {
    const existing = formulations[existingIdx];
    // If version bump requested or specified
    const shouldBump = options.bumpVersion !== undefined ? options.bumpVersion : false;
    const nextVersion = shouldBump ? existing.version + 1 : existing.version;

    resultFormulation = {
      ...existing,
      ...formulationData,
      id: formulationData.id || existing.id,
      tenantId,
      version: nextVersion,
      costPerKgMix,
      costPerAnimalPerDay,
      updatedAt: now
    };
    formulations[existingIdx] = resultFormulation;
  } else {
    resultFormulation = {
      ...formulationData,
      id: `form_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      tenantId,
      version: 1,
      status: formulationData.status || "active",
      effectiveFrom: formulationData.effectiveFrom || now,
      costPerKgMix,
      costPerAnimalPerDay,
      createdBy: user,
      createdAt: now,
      updatedAt: now
    };
    formulations.push(resultFormulation);
  }

  // If setAsPrimaryActive is true, deactivate any other formulations of the same animalTypeId & stageId
  if (options.setAsPrimaryActive && resultFormulation.status === "active") {
    formulations.forEach(f => {
      if (f.id !== resultFormulation.id && f.animalTypeId === resultFormulation.animalTypeId && f.stageId === resultFormulation.stageId) {
        f.status = "inactive";
        f.updatedAt = now;
      }
    });
  }

  localStorage.setItem(getFormKey(tenantId), JSON.stringify(formulations));
  return resultFormulation;
}

export function updateTenantFormulationInPlace(
  tenantId: string = "default",
  formulationId: string,
  updates: Partial<FeedFormulation>,
  user: string = "Farm Manager"
): FeedFormulation {
  const formulations = getTenantFormulations(tenantId);
  const masterIngredients = getTenantIngredients(tenantId);
  const idx = formulations.findIndex(f => f.id === formulationId);
  if (idx < 0) {
    throw new Error(`Formulation with ID ${formulationId} not found.`);
  }

  const existing = formulations[idx];
  const mergedIngredients = updates.ingredients || existing.ingredients;
  const mergedBatchSize = updates.batchSize !== undefined ? updates.batchSize : existing.batchSize;
  const mergedDailyQty = updates.dailyQtyPerAnimal !== undefined ? updates.dailyQtyPerAnimal : existing.dailyQtyPerAnimal;

  const { costPerKgMix, costPerAnimalPerDay } = computeFormulationCosts(
    mergedIngredients,
    masterIngredients,
    mergedBatchSize,
    mergedDailyQty
  );

  const updated: FeedFormulation = {
    ...existing,
    ...updates,
    ingredients: mergedIngredients,
    batchSize: mergedBatchSize,
    dailyQtyPerAnimal: mergedDailyQty,
    costPerKgMix,
    costPerAnimalPerDay,
    updatedAt: new Date().toISOString()
  };

  formulations[idx] = updated;

  if (updated.status === "active") {
    // Optionally keep single active per stage if required
  }

  localStorage.setItem(getFormKey(tenantId), JSON.stringify(formulations));
  return updated;
}

export function duplicateTenantFormulation(
  tenantId: string = "default",
  formulationId: string,
  customName?: string
): FeedFormulation {
  const formulations = getTenantFormulations(tenantId);
  const existing = formulations.find(f => f.id === formulationId);
  if (!existing) {
    throw new Error(`Formulation with ID ${formulationId} not found.`);
  }

  const now = new Date().toISOString();
  const cloned: FeedFormulation = {
    ...existing,
    id: `form_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
    name: customName || `${existing.name} (Copy)`,
    version: 1,
    status: "active",
    createdAt: now,
    updatedAt: now
  };

  formulations.push(cloned);
  localStorage.setItem(getFormKey(tenantId), JSON.stringify(formulations));
  return cloned;
}

export function deleteTenantFormulation(
  tenantId: string = "default",
  formulationId: string
): boolean {
  const formulations = getTenantFormulations(tenantId);
  const filtered = formulations.filter(f => f.id !== formulationId);
  if (filtered.length === formulations.length) return false;
  localStorage.setItem(getFormKey(tenantId), JSON.stringify(filtered));
  return true;
}

export function toggleFormulationStatus(
  tenantId: string = "default",
  formulationId: string,
  newStatus: "active" | "inactive" | "draft" | "archived"
): FeedFormulation {
  return updateTenantFormulationInPlace(tenantId, formulationId, { status: newStatus });
}

export function setPrimaryActiveFormulation(
  tenantId: string = "default",
  formulationId: string
): FeedFormulation {
  const formulations = getTenantFormulations(tenantId);
  const target = formulations.find(f => f.id === formulationId);
  if (!target) throw new Error("Formulation not found");

  const now = new Date().toISOString();
  formulations.forEach(f => {
    if (f.animalTypeId === target.animalTypeId && f.stageId === target.stageId) {
      if (f.id === target.id) {
        f.status = "active";
        f.updatedAt = now;
      } else {
        f.status = "inactive";
        f.updatedAt = now;
      }
    }
  });

  localStorage.setItem(getFormKey(tenantId), JSON.stringify(formulations));
  return target;
}

export function resetTenantFormulationsToDefaults(tenantId: string = "default"): FeedFormulation[] {
  localStorage.removeItem(getFormKey(tenantId));
  return getTenantFormulations(tenantId);
}

function recalculateFormulationsForIngredient(tenantId: string, updatedIngredient: FeedIngredient) {
  const formulations = getTenantFormulations(tenantId);
  const masterIngredients = getTenantIngredients(tenantId);
  let modified = false;

  const updatedFormulations = formulations.map(form => {
    if (form.status !== "active") return form;
    const usesIngredient = form.ingredients.some(i => i.ingredientId === updatedIngredient.id);
    if (!usesIngredient) return form;

    const { costPerKgMix, costPerAnimalPerDay } = computeFormulationCosts(
      form.ingredients,
      masterIngredients,
      form.batchSize,
      form.dailyQtyPerAnimal
    );

    modified = true;
    return {
      ...form,
      costPerKgMix,
      costPerAnimalPerDay,
      updatedAt: new Date().toISOString()
    };
  });

  if (modified) {
    localStorage.setItem(getFormKey(tenantId), JSON.stringify(updatedFormulations));
  }
}

// 5. Daily Feed Log & Ledger Services (§5 & §6)
export function getTenantDailyFeedLogs(tenantId: string = "default"): DailyFeedLog[] {
  const cached = localStorage.getItem(getLogKey(tenantId));
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed)) return parsed;
    } catch (e) {
      console.error("[feedEngineService] Error reading daily feed logs", e);
    }
  }
  return [];
}

export function getTenantFeedLedgers(tenantId: string = "default"): AnimalFeedCostLedger[] {
  const cached = localStorage.getItem(getLedgerKey(tenantId));
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed)) return parsed;
    } catch (e) {
      console.error("[feedEngineService] Error reading feed ledgers", e);
    }
  }
  return [];
}

export function logDailyFeedTransaction(
  tenantId: string = "default",
  logParams: {
    date: string;
    farmNodeId: string;
    animalTypeId: string;
    stageId: string;
    cohortId?: string | null;
    formulationId: string;
    numberOfAnimalsFed: number;
    totalQuantityFedKg?: number;
    notes?: string;
    loggedBy?: string;
    projectId?: string;
  },
  user: string = "Farm Manager",
  accounts?: any[],
  setAccounts?: (accs: any[]) => void
): { log: DailyFeedLog; ledger: AnimalFeedCostLedger } {
  const formulations = getTenantFormulations(tenantId);
  const activeFormulation = formulations.find(f => f.id === logParams.formulationId);

  if (!activeFormulation) {
    throw new Error(`Active feed formulation [${logParams.formulationId}] not found.`);
  }

  const dailyQty = activeFormulation.dailyQtyPerAnimal;
  const qtyFed = logParams.totalQuantityFedKg !== undefined && logParams.totalQuantityFedKg > 0
    ? logParams.totalQuantityFedKg 
    : (logParams.numberOfAnimalsFed * dailyQty);

  const totalCost = Number((qtyFed * activeFormulation.costPerKgMix).toFixed(2));
  const now = new Date().toISOString();

  const newLog: DailyFeedLog = {
    id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
    tenantId,
    date: logParams.date || now.split("T")[0],
    farmNodeId: logParams.farmNodeId || "main_farm",
    animalTypeId: logParams.animalTypeId,
    stageId: logParams.stageId,
    cohortId: logParams.cohortId || `cohort_${logParams.animalTypeId}_${logParams.stageId}`,
    formulationId: activeFormulation.id,
    formulationVersion: activeFormulation.version,
    formulationSnapshot: {
      ingredients: activeFormulation.ingredients,
      costPerKgMix: activeFormulation.costPerKgMix,
      dailyQtyPerAnimal: activeFormulation.dailyQtyPerAnimal
    },
    numberOfAnimalsFed: logParams.numberOfAnimalsFed,
    totalQuantityFedKg: Number(qtyFed.toFixed(2)),
    totalCost, // Immutable once saved (§5)
    loggedBy: user,
    loggedAt: now,
    notes: logParams.notes || ""
  };

  // Save Immutable Daily Feed Log
  const logs = getTenantDailyFeedLogs(tenantId);
  logs.unshift(newLog);
  localStorage.setItem(getLogKey(tenantId), JSON.stringify(logs));

  // Update Animal / Cohort Feed Cost Ledger (§6)
  const ledgers = getTenantFeedLedgers(tenantId);
  const targetLedgerId = newLog.cohortId || `${newLog.animalTypeId}_${newLog.stageId}`;
  const ledgerIdx = ledgers.findIndex(l => l.id === targetLedgerId);

  let updatedLedger: AnimalFeedCostLedger;

  if (ledgerIdx >= 0) {
    const prev = ledgers[ledgerIdx];
    const cumCost = Number((prev.cumulativeFeedCost + totalCost).toFixed(2));
    const cumQty = Number((prev.cumulativeQuantityKg + qtyFed).toFixed(2));
    const animals = logParams.numberOfAnimalsFed || prev.animalsCovered || 1;
    const costPerAnimal = Number((cumCost / Math.max(1, animals)).toFixed(2));

    updatedLedger = {
      ...prev,
      animalsCovered: animals,
      cumulativeFeedCost: cumCost,
      cumulativeQuantityKg: cumQty,
      costPerAnimalToDate: costPerAnimal,
      lastLogDate: newLog.date,
      lastUpdatedAt: now
    };
    ledgers[ledgerIdx] = updatedLedger;
  } else {
    const animals = logParams.numberOfAnimalsFed || 1;
    updatedLedger = {
      id: targetLedgerId,
      tenantId,
      animalTypeId: logParams.animalTypeId,
      stageId: logParams.stageId,
      animalsCovered: animals,
      cumulativeFeedCost: totalCost,
      cumulativeQuantityKg: Number(qtyFed.toFixed(2)),
      costPerAnimalToDate: Number((totalCost / Math.max(1, animals)).toFixed(2)),
      firstLogDate: newLog.date,
      lastLogDate: newLog.date,
      lastUpdatedAt: now
    };
    ledgers.push(updatedLedger);
  }

  localStorage.setItem(getLedgerKey(tenantId), JSON.stringify(ledgers));

  // 8. Post transaction to Financial Engine Chart of Accounts (§8)
  if (accounts && setAccounts && totalCost > 0) {
    postFeedExpenseToChartOfAccounts(
      accounts,
      setAccounts,
      totalCost,
      logParams.animalTypeId,
      logParams.stageId,
      logParams.farmNodeId,
      newLog.cohortId || undefined,
      logParams.projectId
    );
  }

  // Auto-log to General Farm Expense Ledger
  if (totalCost > 0) {
    autoLogFeedExpenseToLedger(
      tenantId,
      totalCost,
      logParams.animalTypeId,
      logParams.stageId,
      logParams.farmNodeId,
      newLog.date,
      newLog.id,
      logParams.notes
    );
  }

  return { log: newLog, ledger: updatedLedger };
}

// Auto-log feed cost directly to the farm expenses ledger
export function autoLogFeedExpenseToLedger(
  tenantId: string,
  totalCost: number,
  animalType: string,
  stage: string,
  farmNodeId: string,
  logDate: string,
  logId: string,
  notes?: string
) {
  if (totalCost <= 0) return;
  try {
    const expenseTx: any = {
      id: `exp_feed_${logId}`,
      expenseNo: `EXP-FEED-${Date.now().toString().slice(-6)}`,
      date: logDate || new Date().toISOString().split("T")[0],
      supplierName: `Livestock Nutrition (${animalType} - ${stage})`,
      category: "Feed & Livestock Nutrition",
      description: `Daily feeding ration for ${animalType} (${stage})${notes ? `: ${notes}` : ""}`,
      total: totalCost,
      amount: totalCost,
      subtotal: totalCost,
      taxAmount: 0,
      paymentMethod: "Cash",
      paymentStatus: "Paid",
      coaCode: "5220",
      farmId: farmNodeId,
      farmNodeId: farmNodeId,
      tenantId: tenantId,
      status: "COMPLETED",
      createdAt: new Date().toISOString(),
      rows: [
        {
          id: `row_feed_${logId}`,
          description: `Daily feed ration - ${animalType} (${stage})`,
          quantity: 1,
          unitPrice: totalCost,
          amount: totalCost,
          coaCode: "5220"
        }
      ]
    };

    // Save to mabala_expenses in safeLocalStorage
    const existingRaw = localStorage.getItem("mabala_expenses");
    let existingExpenses: any[] = [];
    try {
      existingExpenses = existingRaw ? JSON.parse(existingRaw) : [];
    } catch (_) {
      existingExpenses = [];
    }
    if (!existingExpenses.some(e => e.id === expenseTx.id)) {
      existingExpenses.unshift(expenseTx);
      localStorage.setItem("mabala_expenses", JSON.stringify(existingExpenses));
      
      const tenantKey = `expenses_${tenantId}`;
      const tenantRaw = localStorage.getItem(tenantKey);
      let tenantExpenses: any[] = [];
      try {
        tenantExpenses = tenantRaw ? JSON.parse(tenantRaw) : [];
      } catch (_) {}
      if (!tenantExpenses.some(e => e.id === expenseTx.id)) {
        tenantExpenses.unshift(expenseTx);
        localStorage.setItem(tenantKey, JSON.stringify(tenantExpenses));
      }
    }
  } catch (err) {
    console.warn("[feedEngineService] Auto-log feed expense to ledger warning:", err);
  }
}

// Financial Engine Integration (§8)
function postFeedExpenseToChartOfAccounts(
  accounts: any[],
  setAccounts: (accs: any[]) => void,
  amount: number,
  animalType: string,
  stage: string,
  farmNodeId: string,
  cohortId?: string,
  projectId?: string
) {
  try {
    const updated = accounts.map(acc => {
      // 5220 or 5200 for Feed Expense
      if (acc.code === "5220" || acc.code === "5200") {
        return { ...acc, balance: Number(((acc.balance || 0) + amount).toFixed(2)) };
      }
      // Credit Cash/Bank (1000 or 1010)
      if (acc.code === "1000" || acc.code === "1010") {
        return { ...acc, balance: Number(((acc.balance || 0) - amount).toFixed(2)) };
      }
      return acc;
    });

    setAccounts(updated);
  } catch (err) {
    console.error("[feedEngineService] COA Posting Failed", err);
  }
}

// Delete Daily Feed Log and recalculate ledger / reverse expense
export function deleteTenantDailyFeedLog(
  tenantId: string = "default",
  logId: string,
  accounts?: any[],
  setAccounts?: (accs: any[]) => void
): boolean {
  const logs = getTenantDailyFeedLogs(tenantId);
  const targetIndex = logs.findIndex(l => l.id === logId);
  if (targetIndex < 0) return false;

  const targetLog = logs[targetIndex];
  const updatedLogs = logs.filter(l => l.id !== logId);
  localStorage.setItem(getLogKey(tenantId), JSON.stringify(updatedLogs));

  // Clean up corresponding auto-logged expense from expense ledger
  try {
    const feedExpId = `exp_feed_${logId}`;
    const existingRaw = localStorage.getItem("mabala_expenses");
    if (existingRaw) {
      const existingExpenses = JSON.parse(existingRaw);
      const filtered = existingExpenses.filter((e: any) => e.id !== feedExpId);
      localStorage.setItem("mabala_expenses", JSON.stringify(filtered));
    }
    const tenantKey = `expenses_${tenantId}`;
    const tenantRaw = localStorage.getItem(tenantKey);
    if (tenantRaw) {
      const tenantExpenses = JSON.parse(tenantRaw);
      const filteredTenant = tenantExpenses.filter((e: any) => e.id !== feedExpId);
      localStorage.setItem(tenantKey, JSON.stringify(filteredTenant));
    }
  } catch (err) {
    console.warn("[feedEngineService] Error removing feed expense from ledger on delete:", err);
  }

  // Re-adjust ledger if present
  try {
    const ledgers = getTenantFeedLedgers(tenantId);
    const targetLedgerId = targetLog.cohortId || `${targetLog.animalTypeId}_${targetLog.stageId}`;
    const ledgerIdx = ledgers.findIndex(l => l.id === targetLedgerId);
    if (ledgerIdx >= 0) {
      const prev = ledgers[ledgerIdx];
      const newCost = Math.max(0, Number((prev.cumulativeFeedCost - (targetLog.totalCost || 0)).toFixed(2)));
      const newQty = Math.max(0, Number((prev.cumulativeQuantityKg - (targetLog.totalQuantityFedKg || 0)).toFixed(2)));
      const animals = prev.animalsCovered || 1;
      ledgers[ledgerIdx] = {
        ...prev,
        cumulativeFeedCost: newCost,
        cumulativeQuantityKg: newQty,
        costPerAnimalToDate: Number((newCost / Math.max(1, animals)).toFixed(2)),
        lastUpdatedAt: new Date().toISOString()
      };
      localStorage.setItem(getLedgerKey(tenantId), JSON.stringify(ledgers));
    }
  } catch (e) {
    console.warn("[feedEngineService] Ledger readjustment note on delete:", e);
  }

  // Reverse COA posting if applicable
  if (accounts && setAccounts && targetLog.totalCost > 0) {
    try {
      const updated = accounts.map(acc => {
        if (acc.code === "5220" || acc.code === "5200") {
          return { ...acc, balance: Number(Math.max(0, (acc.balance || 0) - targetLog.totalCost).toFixed(2)) };
        }
        if (acc.code === "1000" || acc.code === "1010") {
          return { ...acc, balance: Number(((acc.balance || 0) + targetLog.totalCost).toFixed(2)) };
        }
        return acc;
      });
      setAccounts(updated);
    } catch (e) {
      console.warn("[feedEngineService] COA reversal note on delete:", e);
    }
  }

  return true;
}

// Close Animal Feed Ledger on Sale/Slaughter (§6 & §8)
export function closeAnimalFeedLedger(tenantId: string, cohortOrAnimalId: string): AnimalFeedCostLedger | null {
  const ledgers = getTenantFeedLedgers(tenantId);
  const ledger = ledgers.find(l => l.id === cohortOrAnimalId);
  if (!ledger) return null;

  ledger.lastUpdatedAt = new Date().toISOString();
  localStorage.setItem(getLedgerKey(tenantId), JSON.stringify(ledgers));
  return ledger;
}

// 9. Component Stock Runway & 3-Day Low Stock Alert Services
export interface ComponentRunwayMetric {
  ingredientId: string;
  ingredientName: string;
  category: string;
  currentStockKg: number;
  dailyRequirementKg: number;
  daysRemaining: number;
  isUrgent: boolean; // < 3 days remaining
  status: "critical" | "warning" | "adequate"; // critical (<3d), warning (3-5d), adequate (>5d)
  shortfallKg3Days: number;
}

export interface PenInventoryRunway {
  penId: string;
  penCode: string;
  headcount: number;
  totalDailyFeedKg: number;
  recipeName: string;
  isLowStock: boolean; // true if any component < 3 days
  minDaysRemaining: number;
  criticalComponentsCount: number;
  components: ComponentRunwayMetric[];
}

export function checkPenRecipeInventoryRunway(
  pen: PenRecord,
  tenantId: string = "default",
  formulations?: FeedFormulation[],
  ingredients?: FeedIngredient[]
): PenInventoryRunway {
  const forms = formulations || getTenantFormulations(tenantId);
  const ings = ingredients || getTenantIngredients(tenantId);
  const metrics = getPenDailyFeedMetrics(pen, forms);
  const activeRecipe = metrics.activeRecipe;

  const totalDailyFeedKg = metrics.totalDailyFeedKg;
  const resultComponents: ComponentRunwayMetric[] = [];
  let minDays = 999;
  let hasLowStock = false;
  let criticalCount = 0;

  if (activeRecipe && activeRecipe.ingredients && activeRecipe.ingredients.length > 0) {
    const totalBatch = activeRecipe.ingredients.reduce((s, r) => s + (r.inclusionQtyPerUnit || 0), 0) || activeRecipe.batchSize || 100;
    
    activeRecipe.ingredients.forEach(ratio => {
      const ingName = (ratio.ingredientName || "").trim();
      const matchedIng = ings.find(
        i => (i.name.toLowerCase() === ingName.toLowerCase() || i.id === ratio.ingredientId) && i.active
      );

      const componentRatio = totalBatch > 0 ? (ratio.inclusionQtyPerUnit / totalBatch) : 0;
      const dailyReqKg = Number((totalDailyFeedKg * componentRatio).toFixed(2));
      const currentStockKg = matchedIng?.currentStockKg !== undefined ? matchedIng.currentStockKg : 250;

      let days = 999;
      if (dailyReqKg > 0) {
        days = Number((currentStockKg / dailyReqKg).toFixed(1));
      }

      const isUrgent = days < 3;
      if (isUrgent) {
        hasLowStock = true;
        criticalCount++;
      }
      if (days < minDays) {
        minDays = days;
      }

      const status: "critical" | "warning" | "adequate" = days < 3 ? "critical" : days <= 5 ? "warning" : "adequate";
      const shortfallKg3Days = isUrgent ? Math.max(0, Number(((dailyReqKg * 3) - currentStockKg).toFixed(2))) : 0;

      resultComponents.push({
        ingredientId: matchedIng?.id || ratio.ingredientId || `ing_${ingName}`,
        ingredientName: matchedIng?.name || ingName || "Component",
        category: matchedIng?.category || "additive",
        currentStockKg,
        dailyRequirementKg: dailyReqKg,
        daysRemaining: days,
        isUrgent,
        status,
        shortfallKg3Days
      });
    });
  }

  return {
    penId: pen.id,
    penCode: pen.code,
    headcount: pen.headcount || 0,
    totalDailyFeedKg,
    recipeName: activeRecipe?.name || "Unassigned Standard Mix",
    isLowStock: hasLowStock,
    minDaysRemaining: minDays === 999 ? 30 : minDays,
    criticalComponentsCount: criticalCount,
    components: resultComponents
  };
}

export function getFarmFeedInventoryRunwaySummary(tenantId: string = "default"): {
  totalActivePens: number;
  totalDailyFarmFeedKg: number;
  lowStockItemsCount: number;
  criticalAlerts: { ingredientName: string; currentStockKg: number; totalDailyBurnKg: number; farmRunwayDays: number; isUrgent: boolean }[];
  ingredientRunways: {
    ingredient: FeedIngredient;
    totalDailyBurnKg: number;
    currentStockKg: number;
    farmRunwayDays: number;
    isUrgent: boolean;
  }[];
} {
  const pens = getTenantPens(tenantId).filter(p => p.active && (p.headcount || 0) > 0);
  const ings = getTenantIngredients(tenantId);
  const forms = getTenantFormulations(tenantId);

  const ingredientDemandMap: Record<string, number> = {};

  pens.forEach(pen => {
    const runway = checkPenRecipeInventoryRunway(pen, tenantId, forms, ings);
    runway.components.forEach(comp => {
      const key = comp.ingredientName.toLowerCase();
      ingredientDemandMap[key] = (ingredientDemandMap[key] || 0) + comp.dailyRequirementKg;
    });
  });

  const runways = ings.filter(i => i.active).map(ing => {
    const dailyBurn = ingredientDemandMap[ing.name.toLowerCase()] || 0;
    const stock = ing.currentStockKg !== undefined ? ing.currentStockKg : 250;
    let days = 999;
    if (dailyBurn > 0) {
      days = Number((stock / dailyBurn).toFixed(1));
    }
    const isUrgent = days < 3 && dailyBurn > 0;
    return {
      ingredient: ing,
      totalDailyBurnKg: Number(dailyBurn.toFixed(2)),
      currentStockKg: stock,
      farmRunwayDays: days,
      isUrgent
    };
  });

  const critical = runways.filter(r => r.isUrgent).map(r => ({
    ingredientName: r.ingredient?.name || "Ingredient",
    currentStockKg: r.currentStockKg,
    totalDailyBurnKg: r.totalDailyBurnKg,
    farmRunwayDays: r.farmRunwayDays,
    isUrgent: true
  }));

  const totalDailyFarmFeedKg = pens.reduce((sum, p) => {
    const m = getPenDailyFeedMetrics(p, forms);
    return sum + m.totalDailyFeedKg;
  }, 0);

  return {
    totalActivePens: pens.length,
    totalDailyFarmFeedKg: Number(totalDailyFarmFeedKg.toFixed(2)),
    lowStockItemsCount: critical.length,
    criticalAlerts: critical,
    ingredientRunways: runways
  };
}

export function updateTenantIngredientStock(
  tenantId: string = "default",
  ingredientId: string,
  newStockKg: number,
  notes?: string
): FeedIngredient | null {
  const currentList = getTenantIngredients(tenantId);
  const idx = currentList.findIndex(i => i.id === ingredientId);
  if (idx < 0) return null;

  currentList[idx] = {
    ...currentList[idx],
    currentStockKg: Math.max(0, newStockKg),
    updatedAt: new Date().toISOString(),
    updatedBy: notes || "Manual stock inventory adjustment"
  };

  localStorage.setItem(getIngKey(tenantId), JSON.stringify(currentList));
  return currentList[idx];
}


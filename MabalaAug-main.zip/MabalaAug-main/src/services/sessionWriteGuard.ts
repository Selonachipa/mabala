// Session-Aware Write Guard: Enforces single-active-session validation, idempotency & zombie write rejection
import { doc, setDoc, updateDoc, runTransaction, DocumentReference } from "firebase/firestore";
import { db, auth } from "../firebase";
import { sessionService } from "./sessionService";

export class SessionInvalidatedError extends Error {
  constructor(message = "Write blocked: Session is no longer active on this device.") {
    super(message);
    this.name = "SessionInvalidatedError";
  }
}

export interface MutationOptions {
  module: string;
  collectionName: string;
  documentId: string;
  action?: "create" | "update" | "delete";
  summaryLabel?: string;
  isFinancial?: boolean;
  amount?: number;
  currencySymbol?: string;
  tenantId?: string;
}

export function generateIdempotencyKey(prefix = "tx"): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

/**
 * Executes a write through Firestore SDK's persistentLocalCache.
 * Protects against zombie writes by stamping the active sessionId and idempotencyKey.
 * If the current session has been invalidated by a takeover, routes directly to rejected_writes.
 */
export async function executeSessionAwareWrite<T extends Record<string, any>>(
  docRef: DocumentReference,
  payload: T,
  options: MutationOptions
): Promise<T> {
  const currentUser = auth.currentUser;
  const uid = currentUser?.uid || "anonymous_user";
  const activeSessionId = sessionService.getSessionId() || "offline_unclaimed_session";

  // Check if session has been flagged as terminated
  if (sessionService.isSessionTerminated()) {
    console.warn("[SessionWriteGuard] Session terminated! Diverting write to rejected_writes queue...");
    await sessionService.recordRejectedWrite(uid, {
      id: generateIdempotencyKey("rej"),
      uid,
      tenantId: options?.tenantId,
      sessionId: activeSessionId,
      module: options?.module || "core",
      collectionName: options?.collectionName || "unknown",
      documentId: options?.documentId || "unknown",
      action: options?.action || "update",
      payload: payload || {},
      summaryLabel: options?.summaryLabel,
      amount: options?.amount,
      currencySymbol: options?.currencySymbol,
      isFinancial: !!options?.isFinancial,
      rejectionReason: "SESSION_INVALIDATED_REMOTE_LOGIN"
    });

    throw new SessionInvalidatedError(
      `Cannot save changes: Account was signed into from another device. Your changes were safely preserved in the reconciliation queue.`
    );
  }

  // Stamp payload with session epoch & idempotency proof
  const stampedPayload: T = {
    ...(payload || {} as any),
    sessionId: activeSessionId,
    idempotencyKey: payload?.idempotencyKey || generateIdempotencyKey("idem"),
    clientCapturedAt: payload?.clientCapturedAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  try {
    // Write via Firestore SDK (durable write to IndexedDB persistentLocalCache immediately)
    if (db && !(db as any)._dummy) {
      if (options?.action === "update") {
        await updateDoc(docRef, stampedPayload);
      } else {
        await setDoc(docRef, stampedPayload, { merge: true });
      }
    }
    return stampedPayload;
  } catch (err: any) {
    console.warn(`[SessionWriteGuard] Write failed (${err?.code || err?.message}):`, err);

    // If permission was denied because rules detected a stale session claim
    if (err?.code === "permission-denied" || err?.message?.includes("permission-denied")) {
      await sessionService.recordRejectedWrite(uid, {
        id: generateIdempotencyKey("rej_denied"),
        uid,
        tenantId: options?.tenantId,
        sessionId: activeSessionId,
        module: options?.module || "core",
        collectionName: options?.collectionName || "unknown",
        documentId: options?.documentId || "unknown",
        action: options?.action || "update",
        payload: stampedPayload,
        summaryLabel: options?.summaryLabel,
        amount: options?.amount,
        currencySymbol: options?.currencySymbol,
        isFinancial: !!options?.isFinancial,
        rejectionReason: "PERMISSION_DENIED_STALE_SESSION"
      });
    }

    throw err;
  }
}

/**
 * Executes a financial transaction atomically with idempotency and session check.
 */
export async function executeSessionAwareFinancialTransaction<T>(
  tenantId: string,
  txFn: (transaction: any, meta: { sessionId: string; idempotencyKey: string }) => Promise<T>,
  options: MutationOptions
): Promise<T> {
  const currentUser = auth.currentUser;
  const uid = currentUser?.uid || "anonymous_user";
  const activeSessionId = sessionService.getSessionId() || "offline_session";

  if (sessionService.isSessionTerminated()) {
    throw new SessionInvalidatedError(
      "Financial transaction rejected: Active session has been invalidated by another login."
    );
  }

  const idempotencyKey = generateIdempotencyKey("fin");

  try {
    return await runTransaction(db, async (tx) => {
      return await txFn(tx, { sessionId: activeSessionId, idempotencyKey });
    });
  } catch (err: any) {
    console.error("[SessionWriteGuard] Financial transaction failed:", err);
    throw err;
  }
}

/**
 * Tombstone soft-delete helper: Preserves auditability and prevents zombie resurrection.
 */
export async function executeTombstoneDelete(
  docRef: DocumentReference,
  options: MutationOptions
): Promise<void> {
  const currentUser = auth.currentUser;
  const uid = currentUser?.uid || "anonymous";
  const activeSessionId = sessionService.getSessionId() || "offline_session";

  const tombstone = {
    isDeleted: true,
    deletedAt: new Date().toISOString(),
    deletedBy: uid,
    deletedSessionId: activeSessionId,
    status: "ARCHIVED_TOMBSTONE"
  };

  if (db && !(db as any)._dummy) {
    await updateDoc(docRef, tombstone);
  }
}

import { 
  CropCycle, 
  Invoice, 
  CashSale, 
  ExpenseTransaction, 
  ExpenseRow, 
  OrchardCostTaskType, 
  OrchardExpenseSourceModule, 
  BlockRevenueLedgerEntry, 
  BlockExpenseLedgerEntry, 
  BlockProfitabilitySummary, 
  BlockRevenuePerformanceSummary,
  Account
} from "../types";
import { db, functions, auth } from "../firebase";
import { httpsCallable } from "firebase/functions";
import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  serverTimestamp, 
  runTransaction 
} from "firebase/firestore";
import { safeLocalStorage } from "../utils/safeStorage";

// ----------------------------------------------------
// 1. Cost Task -> COA Account Mapping
// ----------------------------------------------------
export interface CoaMapping {
  code: string;
  accountName: string;
}

export const ORCHARD_COST_COA_MAP: Record<OrchardCostTaskType, CoaMapping> = {
  spraying: { code: "5340", accountName: "Crop Protection & Agrochemicals" },
  labour: { code: "5330", accountName: "Direct Labour — Orchard" },
  pruning: { code: "5330", accountName: "Direct Labour — Orchard" },
  fertilizer: { code: "5320", accountName: "Fertilizer & Soil Inputs" },
  irrigation: { code: "5350", accountName: "Irrigation & Water Costs" },
  pest_control: { code: "5340", accountName: "Crop Protection & Agrochemicals" },
  equipment: { code: "5360", accountName: "Equipment Hire & Maintenance" },
  other: { code: "5395", accountName: "Other Orchard Operating Costs" }
};

export const ORCHARD_REVENUE_COA: CoaMapping = {
  code: "4300",
  accountName: "Fruit & Orchard Sales Revenue"
};

export interface PostOrchardSaleParams {
  saleId: string;
  blockId: string;
  blockName?: string;
  treeGroupId?: string;
  tenantId?: string;
  buyer: string;
  quantity?: number;
  unitPrice?: number;
  amount: number;
  productType?: string;
  productName?: string;
  invoiceNumber?: string;
  receiptNumber?: string;
  date?: string;
  actorUid?: string;
  actorEmail?: string;
}

export interface PostOrchardExpenseParams {
  taskId?: string;
  expenseId?: string;
  blockId: string;
  blockName?: string;
  treeGroupId?: string;
  tenantId?: string;
  costTaskType: OrchardCostTaskType;
  description: string;
  cost?: number;
  amount?: number;
  dateIncurred?: string;
  date?: string;
  category?: string;
  receiptNumber?: string;
  loggedBy?: string;
  sourceModule?: OrchardExpenseSourceModule;
  supplierName?: string;
}

export class OrchardFinanceService {
  /**
   * Helper to fetch authenticated authorization headers for REST requests
   */
  private static async getAuthHeaders(): Promise<Record<string, string>> {
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    try {
      if (auth && auth.currentUser) {
        const token = await auth.currentUser.getIdToken();
        if (token) headers["Authorization"] = `Bearer ${token}`;
      }
    } catch (_) {}
    return headers;
  }

  /**
   * Post Orchard Sale
   * Atomically:
   * 1. Increments orchard_blocks/{blockId}.actualRevenueToDate
   * 2. Recomputes netProfitToDate and revenueVariancePct
   * 3. Writes an immutable append-only block_revenue_ledger entry
   * 4. Returns updated metrics
   */
  static async postOrchardSale(params: PostOrchardSaleParams): Promise<{
    success: boolean;
    actualRevenueToDate: number;
    actualExpensesToDate: number;
    netProfitToDate: number;
    revenueVariancePct: number;
    ledgerEntry: BlockRevenueLedgerEntry;
  }> {
    if (!params.blockId || params.blockId.trim() === "") {
      throw new Error("Hard Block Validation: Fruit sales require a valid Orchard Block ID (blockId). Uncategorized fruit sales are not permitted.");
    }
    if (!params.amount || params.amount <= 0) {
      throw new Error("Invalid sale amount: Sale value must be greater than zero.");
    }

    const tenantId = params.tenantId || "tenant-farm";
    const saleDate = params.date || new Date().toISOString().split("T")[0];
    const isoNow = new Date().toISOString();

    const ledgerEntry: BlockRevenueLedgerEntry = {
      id: `REV-ORCH-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      saleId: params.saleId,
      blockId: params.blockId,
      blockName: params.blockName || `Orchard Block ${params.blockId}`,
      treeGroupId: params.treeGroupId,
      tenantId,
      date: saleDate,
      buyer: params.buyer,
      quantity: params.quantity || 1,
      unitPrice: params.unitPrice || params.amount,
      amount: params.amount,
      productType: params.productType || "fruit",
      productName: params.productName || "Orchard Harvest Produce",
      invoiceNumber: params.invoiceNumber,
      receiptNumber: params.receiptNumber,
      coaAccountId: ORCHARD_REVENUE_COA.code,
      postedAt: isoNow,
      postedBy: params.actorEmail || "System"
    };

    let serverResult: any = null;

    // 1. Try Firebase Callable Function postOrchardSale
    try {
      if (functions && typeof httpsCallable === "function") {
        const callableFn = httpsCallable(functions, "postOrchardSale");
        const res: any = await callableFn({
          ...params,
          ledgerEntry
        });
        if (res?.data?.success) {
          serverResult = res.data;
        }
      }
    } catch (callErr) {
      console.warn("[OrchardFinance] Callable postOrchardSale notice:", callErr);
    }

    // 2. Try REST API endpoint /api/orchard/sales/post
    if (!serverResult) {
      try {
        const headers = await this.getAuthHeaders();
        const res = await fetch("/api/orchard/sales/post", {
          method: "POST",
          headers,
          body: JSON.stringify({
            ...params,
            ledgerEntry
          })
        });
        if (res.ok) {
          serverResult = await res.json();
        }
      } catch (restErr) {
        console.warn("[OrchardFinance] REST API postOrchardSale notice:", restErr);
      }
    }

    // 3. Fallback to direct client-side Firestore atomic persistence + localStorage caching
    let actualRevenue = 0;
    let actualExpenses = 0;
    let projectedRevenue = 0;

    if (serverResult && serverResult.actualRevenueToDate !== undefined) {
      actualRevenue = serverResult.actualRevenueToDate;
      actualExpenses = serverResult.actualExpensesToDate || 0;
      projectedRevenue = serverResult.projectedRevenue || 0;
    } else {
      // Local calculation & Firestore transaction fallback
      try {
        if (db) {
          const blockRef = doc(db, "crop_cycles", params.blockId);
          await runTransaction(db, async (tx) => {
            const blockSnap = await tx.get(blockRef);
            if (blockSnap.exists()) {
              const bData = blockSnap.data() as CropCycle;
              projectedRevenue = bData.projectedRevenue || bData.orchard?.projectedAnnualRevenue || bData.expectedRevenueProjection || 0;
              const prevRev = bData.actualRevenueToDate || 0;
              actualExpenses = bData.actualExpensesToDate || 0;
              actualRevenue = prevRev + params.amount;
              const netProfit = actualRevenue - actualExpenses;
              const variancePct = projectedRevenue > 0 ? (actualRevenue - projectedRevenue) / projectedRevenue : 0;

              tx.update(blockRef, {
                actualRevenueToDate: actualRevenue,
                netProfitToDate: netProfit,
                revenueVariancePct: variancePct,
                lastRevenuePostedAt: isoNow
              });

              // Append to subcollection
              const revLedgerRef = doc(collection(db, "crop_cycles", params.blockId, "revenue_ledger"), ledgerEntry.id);
              tx.set(revLedgerRef, ledgerEntry);
            }
          });
        }
      } catch (dbErr) {
        console.warn("[OrchardFinance] Direct firestore transaction notice:", dbErr);
      }
    }

    // Always append to local storage append-only cache
    this.appendLocalRevenueLedger(ledgerEntry);

    const netProfitToDate = actualRevenue - actualExpenses;
    const revenueVariancePct = projectedRevenue > 0 ? (actualRevenue - projectedRevenue) / projectedRevenue : 0;

    return {
      success: true,
      actualRevenueToDate: actualRevenue,
      actualExpensesToDate: actualExpenses,
      netProfitToDate,
      revenueVariancePct,
      ledgerEntry
    };
  }

  /**
   * Post Orchard Expense
   * Auto-logs orchard cost tasks to Expense Ledger & COA atomically:
   * 1. Increments orchard_blocks/{blockId}.actualExpensesToDate
   * 2. Recomputes netProfitToDate
   * 3. Maps costTaskType -> COA Account (5320-5395)
   * 4. Writes an immutable block_expense_ledger entry
   * 5. Returns expenseLedgerRef for bidirectional task traceability
   */
  static async postOrchardExpense(params: PostOrchardExpenseParams): Promise<{
    success: boolean;
    expenseLedgerRef: string;
    actualRevenueToDate: number;
    actualExpensesToDate: number;
    netProfitToDate: number;
    ledgerEntry: BlockExpenseLedgerEntry;
  }> {
    const effectiveCost = params.cost !== undefined ? params.cost : (params.amount || 0);
    if (!params.blockId || params.blockId.trim() === "") {
      throw new Error("Orchard expense requires a valid Orchard Block ID (blockId).");
    }
    if (effectiveCost <= 0) {
      throw new Error("Cost must be greater than zero.");
    }

    const tenantId = params.tenantId || "tenant-farm";
    const dateIncurred = params.dateIncurred || params.date || new Date().toISOString().split("T")[0];
    const isoNow = new Date().toISOString();
    const coa = ORCHARD_COST_COA_MAP[params.costTaskType] || ORCHARD_COST_COA_MAP.other;
    const expenseLedgerRef = params.expenseId || `EXP-ORCH-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const ledgerEntry: BlockExpenseLedgerEntry = {
      id: expenseLedgerRef,
      taskId: params.taskId,
      blockId: params.blockId,
      blockName: params.blockName || `Orchard Block ${params.blockId}`,
      treeGroupId: params.treeGroupId,
      tenantId,
      date: dateIncurred,
      costTaskType: params.costTaskType,
      description: params.description,
      amount: effectiveCost,
      coaCode: coa.code,
      coaAccountName: coa.accountName,
      sourceModule: params.sourceModule || "orchard_task",
      expenseId: params.expenseId || expenseLedgerRef,
      postedAt: isoNow,
      postedBy: params.loggedBy || "System"
    };

    let serverResult: any = null;

    // 1. Try Firebase Callable Function postOrchardExpense
    try {
      if (functions && typeof httpsCallable === "function") {
        const callableFn = httpsCallable(functions, "postOrchardExpense");
        const res: any = await callableFn({
          ...params,
          ledgerEntry,
          expenseLedgerRef
        });
        if (res?.data?.success) {
          serverResult = res.data;
        }
      }
    } catch (callErr) {
      console.warn("[OrchardFinance] Callable postOrchardExpense notice:", callErr);
    }

    // 2. Try REST API endpoint /api/orchard/expenses/post
    if (!serverResult) {
      try {
        const headers = await this.getAuthHeaders();
        const res = await fetch("/api/orchard/expenses/post", {
          method: "POST",
          headers,
          body: JSON.stringify({
            ...params,
            ledgerEntry,
            expenseLedgerRef
          })
        });
        if (res.ok) {
          serverResult = await res.json();
        }
      } catch (restErr) {
        console.warn("[OrchardFinance] REST API postOrchardExpense notice:", restErr);
      }
    }

    // 3. Fallback to direct client-side Firestore atomic persistence
    let actualRevenue = 0;
    let actualExpenses = 0;

    if (serverResult && serverResult.actualExpensesToDate !== undefined) {
      actualRevenue = serverResult.actualRevenueToDate || 0;
      actualExpenses = serverResult.actualExpensesToDate;
    } else {
      try {
        if (db) {
          const blockRef = doc(db, "crop_cycles", params.blockId);
          await runTransaction(db, async (tx) => {
            const blockSnap = await tx.get(blockRef);
            if (blockSnap.exists()) {
              const bData = blockSnap.data() as CropCycle;
              actualRevenue = bData.actualRevenueToDate || 0;
              const prevExp = bData.actualExpensesToDate || 0;
              actualExpenses = prevExp + params.cost;
              const netProfit = actualRevenue - actualExpenses;

              tx.update(blockRef, {
                actualExpensesToDate: actualExpenses,
                netProfitToDate: netProfit,
                lastExpensePostedAt: isoNow
              });

              // Append to subcollection
              const expLedgerRef = doc(collection(db, "crop_cycles", params.blockId, "expense_ledger"), ledgerEntry.id);
              tx.set(expLedgerRef, ledgerEntry);
            }
          });
        }
      } catch (dbErr) {
        console.warn("[OrchardFinance] Direct firestore expense transaction notice:", dbErr);
      }
    }

    // Always append to local storage append-only cache
    this.appendLocalExpenseLedger(ledgerEntry);

    const netProfitToDate = actualRevenue - actualExpenses;

    return {
      success: true,
      expenseLedgerRef,
      actualRevenueToDate: actualRevenue,
      actualExpensesToDate: actualExpenses,
      netProfitToDate,
      ledgerEntry
    };
  }

  // ----------------------------------------------------
  // Local storage append-only caching helpers
  // ----------------------------------------------------
  private static appendLocalRevenueLedger(entry: BlockRevenueLedgerEntry) {
    try {
      const key = `mabala_orchard_revenue_ledger_${entry.tenantId}`;
      const existing = this.getLocalRevenueLedger(entry.tenantId);
      if (!existing.some(e => e.id === entry.id)) {
        existing.unshift(entry);
        safeLocalStorage.setItem(key, JSON.stringify(existing));
      }
    } catch (e) {
      console.warn("Failed to cache revenue ledger entry locally", e);
    }
  }

  private static appendLocalExpenseLedger(entry: BlockExpenseLedgerEntry) {
    try {
      const key = `mabala_orchard_expense_ledger_${entry.tenantId}`;
      const existing = this.getLocalExpenseLedger(entry.tenantId);
      if (!existing.some(e => e.id === entry.id)) {
        existing.unshift(entry);
        safeLocalStorage.setItem(key, JSON.stringify(existing));
      }
    } catch (e) {
      console.warn("Failed to cache expense ledger entry locally", e);
    }
  }

  static getLocalRevenueLedger(tenantId: string = "tenant-farm", blockId?: string): BlockRevenueLedgerEntry[] {
    try {
      const raw = safeLocalStorage.getItem(`mabala_orchard_revenue_ledger_${tenantId}`);
      if (!raw) return [];
      const parsed: BlockRevenueLedgerEntry[] = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      if (blockId) {
        return parsed.filter(p => p.blockId === blockId);
      }
      return parsed;
    } catch (e) {
      return [];
    }
  }

  static getLocalExpenseLedger(tenantId: string = "tenant-farm", blockId?: string): BlockExpenseLedgerEntry[] {
    try {
      const raw = safeLocalStorage.getItem(`mabala_orchard_expense_ledger_${tenantId}`);
      if (!raw) return [];
      const parsed: BlockExpenseLedgerEntry[] = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      if (blockId) {
        return parsed.filter(p => p.blockId === blockId);
      }
      return parsed;
    } catch (e) {
      return [];
    }
  }

  /**
   * Generates AI Causal Variance Insight for an Orchard Block
   * Distinguishes volume-driven vs price-driven vs mixed variance
   */
  static generateBlockVarianceAIInsight(
    block: CropCycle,
    actualRevenue: number,
    projectedRevenue: number,
    actualHarvestUnits?: number,
    projectedHarvestUnits?: number,
    averagePrice?: number,
    projectedPrice?: number
  ): {
    summary: string;
    driverType: "volume" | "price" | "mixed";
    likelyCauses: { tag: string; description: string }[];
    recommendations: string[];
    classification: "surplus" | "deficit" | "on_target";
  } {
    const varianceAmount = actualRevenue - projectedRevenue;
    const variancePct = projectedRevenue > 0 ? varianceAmount / projectedRevenue : 0;

    let classification: "surplus" | "deficit" | "on_target" = "on_target";
    if (variancePct > 0.05) classification = "surplus";
    else if (variancePct < -0.05) classification = "deficit";

    // Resolve volume & price divergence
    const volVariance = (projectedHarvestUnits && projectedHarvestUnits > 0 && actualHarvestUnits !== undefined)
      ? (actualHarvestUnits - projectedHarvestUnits) / projectedHarvestUnits
      : 0;
    const priceVariance = (projectedPrice && projectedPrice > 0 && averagePrice !== undefined)
      ? (averagePrice - projectedPrice) / projectedPrice
      : 0;

    let driverType: "volume" | "price" | "mixed" = "mixed";
    if (Math.abs(volVariance) > 0.10 && Math.abs(priceVariance) <= 0.08) {
      driverType = "volume";
    } else if (Math.abs(priceVariance) > 0.10 && Math.abs(volVariance) <= 0.08) {
      driverType = "price";
    } else {
      driverType = "mixed";
    }

    const fruitName = block.cropType || block.cropName || "Fruit";
    const likelyCauses: { tag: string; description: string }[] = [];
    const recommendations: string[] = [];

    if (classification === "deficit") {
      if (driverType === "volume") {
        likelyCauses.push({
          tag: "Canopy Yield Deficit",
          description: `Harvested fruit count/weight fell below projected yield targets for ${fruitName}.`
        });
        likelyCauses.push({
          tag: "Pest / Flower Drop Stress",
          description: "Potential fruit-set drop or seasonal heat during anthesis impacted salable crop load."
        });
        recommendations.push("Calibrate foliar zinc/boron nutrition at pre-bloom stage to stabilize fruit set retention.");
        recommendations.push("Inspect irrigation dripper discharge uniformity along block laterals.");
      } else if (driverType === "price") {
        likelyCauses.push({
          tag: "Market Price Softening",
          description: `Realized average sale price (ZMW ${averagePrice ? averagePrice.toFixed(2) : "—"}) tracked below target (ZMW ${projectedPrice ? projectedPrice.toFixed(2) : "—"}).`
        });
        likelyCauses.push({
          tag: "Size/Grade Distribution Shift",
          description: "Higher proportion of small-grade fruit diverted into lower-tier wholesale or juice contracts."
        });
        recommendations.push("Establish forward offtake commitments with supermarket packhouses prior to peak harvest window.");
        recommendations.push("Implement fruit thinning at juvenile stage to steer harvest into premium Grade 1 count sizing.");
      } else {
        likelyCauses.push({
          tag: "Combined Yield & Offtake Realization Drag",
          description: `Mixed factors: both harvested volumes and market price realizations lagged planned model parameters.`
        });
        recommendations.push("Review multi-year harvest schedule yield multipliers against canopy actuals.");
      }
    } else if (classification === "surplus") {
      if (driverType === "price") {
        likelyCauses.push({
          tag: "Premium Grade Realization",
          description: `Average selling price achieved a ${(priceVariance * 100).toFixed(1)}% premium above baseline estimates.`
        });
        recommendations.push("Lock in supply terms with top-tier premium retail channels for next cycle.");
      } else {
        likelyCauses.push({
          tag: "Optimal Canopy Crop Load",
          description: `Tree health and pollination efficiency resulted in exceptional harvest density per tree.`
        });
        recommendations.push("Ensure post-harvest potassium and micronutrient replenishment to prevent biennial bearing dip.");
      }
    } else {
      likelyCauses.push({
        tag: "Plan Execution On-Target",
        description: `Revenue closely tracks within ±5% of block projections with balanced unit pricing and volume realization.`
      });
      recommendations.push("Maintain current agronomic program and automated expense tracking.");
    }

    const variancePctDisplay = (variancePct * 100).toFixed(1);
    const summary = classification === "surplus"
      ? `Block '${block.fieldBlock || block.cropType}' achieved a +${variancePctDisplay}% revenue surplus against projections (${driverType}-driven).`
      : classification === "deficit"
      ? `Block '${block.fieldBlock || block.cropType}' registered a ${variancePctDisplay}% revenue variance against target projections (${driverType}-driven).`
      : `Block '${block.fieldBlock || block.cropType}' revenue is tracking solidly on target with budget model (${variancePctDisplay}% variance).`;

    return {
      summary,
      driverType,
      likelyCauses,
      recommendations,
      classification
    };
  }

  /**
   * Computes comprehensive Block Profitability & Revenue Performance summaries
   */
  static computeBlockReports(
    blocks: CropCycle[],
    invoices: Invoice[] = [],
    cashSales: CashSale[] = [],
    expenses: ExpenseTransaction[] = [],
    revenueLedger: BlockRevenueLedgerEntry[] = [],
    expenseLedger: BlockExpenseLedgerEntry[] = []
  ): {
    revenuePerformance: BlockRevenuePerformanceSummary[];
    profitability: BlockProfitabilitySummary[];
  } {
    const orchardBlocks = blocks.filter(b => b.cycleType === "perennial_orchard");

    // 1. Compute Revenue Performance per block
    const revenuePerformance: BlockRevenuePerformanceSummary[] = orchardBlocks.map(block => {
      const blockId = block.id;
      const blockName = block.fieldBlock || block.cropType || "Block";
      const fruitType = block.cropType || block.cropName || "Fruit";
      const variety = block.variety || block.orchard?.variety || "";
      const treeCount = block.orchard?.treeCount || 0;

      // Planned target revenue
      const projectedRevenue = block.projectedRevenue || block.orchard?.projectedAnnualRevenue || block.expectedRevenueProjection || 0;
      const projectedHarvestUnits = block.orchard?.expectedAnnualYieldUnits || block.orchard?.treeCount ? (block.orchard.treeCount * (block.orchard.estimatedFruitsPerTreePerHarvest || 100)) : 0;
      const projectedPrice = block.orchard?.pricePerUnitOrKg || block.expectedSellingPricePerUnit || block.expectedSellingPricePerKg || 0;

      // Actual revenue from:
      // a) block roll-up field
      // b) block_revenue_ledger
      // c) invoices and cash sales tagged with blockId
      const ledgerSales = revenueLedger.filter(r => r.blockId === blockId);
      const ledgerRevSum = ledgerSales.reduce((sum, r) => sum + r.amount, 0);

      const taggedInvoices = invoices.filter(inv => 
        (inv.blockId === blockId || inv.cropCycleId === blockId) && 
        inv.status !== "Cancelled"
      );
      const invoiceRevSum = taggedInvoices.reduce((sum, inv) => sum + (inv.paidAmount !== undefined ? inv.paidAmount : inv.total), 0);

      const taggedCashSales = cashSales.filter(cs => cs.blockId === blockId || cs.cropCycleId === blockId);
      const cashSaleRevSum = taggedCashSales.reduce((sum, cs) => sum + cs.amount, 0);

      const calculatedRev = Math.max(block.actualRevenueToDate || 0, ledgerRevSum, invoiceRevSum + cashSaleRevSum);

      const totalQtySold = ledgerSales.reduce((sum, r) => sum + (r.quantity || 0), 0);
      const averageSellingPrice = totalQtySold > 0 ? calculatedRev / totalQtySold : (projectedPrice || 0);

      const varianceAmount = calculatedRev - projectedRevenue;
      const variancePct = projectedRevenue > 0 ? varianceAmount / projectedRevenue : 0;

      const aiInsight = this.generateBlockVarianceAIInsight(
        block,
        calculatedRev,
        projectedRevenue,
        totalQtySold,
        projectedHarvestUnits,
        averageSellingPrice,
        projectedPrice
      );

      // Build simulated timeline
      const timeline = [
        { date: "Month 1", actualCumulative: calculatedRev * 0.15, projectedTarget: projectedRevenue * 0.20, delta: (calculatedRev * 0.15) - (projectedRevenue * 0.20) },
        { date: "Month 2", actualCumulative: calculatedRev * 0.45, projectedTarget: projectedRevenue * 0.50, delta: (calculatedRev * 0.45) - (projectedRevenue * 0.50) },
        { date: "Month 3", actualCumulative: calculatedRev * 0.80, projectedTarget: projectedRevenue * 0.75, delta: (calculatedRev * 0.80) - (projectedRevenue * 0.75) },
        { date: "Current", actualCumulative: calculatedRev, projectedTarget: projectedRevenue, delta: calculatedRev - projectedRevenue }
      ];

      return {
        blockId,
        blockName,
        fruitType,
        variety,
        treeCount,
        projectedRevenue,
        actualRevenueToDate: calculatedRev,
        varianceAmount,
        variancePct,
        actualHarvestUnits: totalQtySold,
        projectedHarvestUnits,
        averageSellingPrice,
        projectedPrice,
        classification: aiInsight.classification,
        aiInsight,
        timeline
      };
    });

    // 2. Compute Profitability per block
    const profitability: BlockProfitabilitySummary[] = orchardBlocks.map(block => {
      const blockId = block.id;
      const blockName = block.fieldBlock || block.cropType || "Block";
      const fruitType = block.cropType || block.cropName || "Fruit";
      const variety = block.variety || block.orchard?.variety || "";
      const treeCount = block.orchard?.treeCount || 0;
      const areaHa = block.areaHectares || block.orchard?.blockAreaHa || 0;
      const projectedRevenue = block.projectedRevenue || block.orchard?.projectedAnnualRevenue || block.expectedRevenueProjection || 0;

      // Actual Revenue
      const revSummary = revenuePerformance.find(r => r.blockId === blockId);
      const actualRevenueToDate = revSummary ? revSummary.actualRevenueToDate : (block.actualRevenueToDate || 0);

      // Actual Expenses breakdown
      const blockExpLedger = expenseLedger.filter(e => e.blockId === blockId);
      const expensesBreakdown = {
        spraying: 0,
        labour: 0,
        pruning: 0,
        fertilizer: 0,
        irrigation: 0,
        pest_control: 0,
        equipment: 0,
        other: 0
      };

      blockExpLedger.forEach(e => {
        const type = e.costTaskType || "other";
        if (expensesBreakdown[type] !== undefined) {
          expensesBreakdown[type] += e.amount;
        } else {
          expensesBreakdown.other += e.amount;
        }
      });

      // Also incorporate tagged expense rows from ExpenseTransactions
      expenses.forEach(tx => {
        if (tx.blockId === blockId) {
          tx.rows.forEach(r => {
            const taskType = (r.costTaskType as OrchardCostTaskType) || "other";
            if (expensesBreakdown[taskType] !== undefined) {
              expensesBreakdown[taskType] += r.amount;
            } else {
              expensesBreakdown.other += r.amount;
            }
          });
        }
      });

      const totalCalculatedExpenses = Object.values(expensesBreakdown).reduce((sum, v) => sum + v, 0);
      const actualExpensesToDate = Math.max(block.actualExpensesToDate || 0, totalCalculatedExpenses);

      const netProfitToDate = actualRevenueToDate - actualExpensesToDate;
      const profitMarginPct = actualRevenueToDate > 0 ? (netProfitToDate / actualRevenueToDate) * 100 : 0;
      const revenueVariancePct = projectedRevenue > 0 ? (actualRevenueToDate - projectedRevenue) / projectedRevenue : 0;

      return {
        blockId,
        blockName,
        fruitType,
        variety,
        treeCount,
        areaHa,
        projectedRevenue,
        actualRevenueToDate,
        actualExpensesToDate,
        netProfitToDate,
        revenueVariancePct,
        profitMarginPct,
        expensesBreakdown,
        rank: 1, // Will rank below
        lastRevenuePostedAt: block.lastRevenuePostedAt,
        lastExpensePostedAt: block.lastExpensePostedAt,
        aiInsight: revSummary?.aiInsight
      };
    });

    // Rank blocks by netProfitToDate descending
    profitability.sort((a, b) => b.netProfitToDate - a.netProfitToDate);
    profitability.forEach((item, index) => {
      item.rank = index + 1;
    });

    return {
      revenuePerformance,
      profitability
    };
  }
}

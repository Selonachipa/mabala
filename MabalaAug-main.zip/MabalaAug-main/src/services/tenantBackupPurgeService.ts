/**
 * Tenant-Scoped Purge and Tiered Backup & Restore Service
 * Connects to server-side endpoints for secure, isolated operations.
 */

export interface TenantBackupMeta {
  tenantId: string;
  tenantName: string;
  exportedAt: number;
  exportedBy: string;
  scope: "tenant";
  totalRecords?: number;
  version?: string;
}

export interface TenantBackupRecord {
  id: string;
  backupId?: string;
  fileName: string;
  tenantId: string;
  tenantName: string;
  backupDate: string;
  type: "local" | "remote" | "auto";
  format?: string;
  payloadSizeKb?: number;
  recordsCount?: number;
  exportedBy?: string;
  status?: string;
  payload?: any;
}

export interface PlatformBackupRecord {
  id: string;
  backupId: string;
  outputUriPrefix: string;
  timestamp: number;
  createdAt: string;
  createdBy: string;
  status: string;
  totalTenants: number;
  totalRecords: number;
  summary?: Record<string, number>;
}

export interface AuditLogItem {
  id: string;
  action: string;
  actingUid: string;
  actingRole?: string;
  targetTenantId?: string;
  targetTenantName?: string;
  documentsDeleted?: number;
  recordsCount?: number;
  restoredCount?: number;
  timestamp: number;
  createdAt?: string;
  ip?: string;
}

/**
 * Purges all records for a specific tenant.
 * Enforces exact type-to-confirm match against the tenant's actual display name.
 */
export async function purgeTenantWorkspace(
  targetTenantId: string,
  confirmTenantName: string,
  actingUid?: string,
  actingEmail?: string
): Promise<{ success: boolean; message: string; documentsDeleted: number; targetTenantName: string }> {
  const res = await fetch("/api/tenant/purge-workspace", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      targetTenantId,
      confirmTenantName,
      actingUid,
      actingEmail
    })
  });

  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || "Failed to purge tenant workspace.");
  }
  return data;
}

/**
 * Creates a tenant backup (either local downloadable payload or saved remotely).
 */
export async function createTenantBackup(
  targetTenantId: string,
  outputMode: "local" | "remote" = "local",
  actingUid?: string,
  actingEmail?: string
): Promise<{
  success: boolean;
  fileName: string;
  objectPath?: string;
  tenantName: string;
  totalRecords: number;
  sizeKb: number;
  payload?: any;
}> {
  const res = await fetch("/api/tenant/backup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      targetTenantId,
      outputMode,
      actingUid,
      actingEmail
    })
  });

  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || "Failed to create tenant backup.");
  }

  // If local, automatically trigger browser file download
  if (outputMode === "local" && data.payload) {
    downloadJsonFile(data.fileName, data.payload);
  }

  return data;
}

/**
 * Fetches the list of saved backups for a tenant.
 */
export async function fetchTenantBackups(
  targetTenantId: string,
  actingUid?: string,
  actingEmail?: string
): Promise<TenantBackupRecord[]> {
  const params = new URLSearchParams({
    tenantId: targetTenantId,
    ...(actingUid ? { actingUid } : {}),
    ...(actingEmail ? { actingEmail } : {})
  });

  const res = await fetch(`/api/tenant/backups?${params.toString()}`);
  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || "Failed to list tenant backups.");
  }
  return data.backups || [];
}

/**
 * Restores a tenant workspace from a backup payload or saved snapshot.
 * Verifies _meta.tenantId matches the targetTenantId before writing anything.
 */
export async function restoreTenantWorkspace(
  targetTenantId: string,
  confirmTenantName: string,
  options: {
    backupId?: string;
    payload?: any;
    actingUid?: string;
    actingEmail?: string;
  }
): Promise<{ success: boolean; restoredCount: number; targetTenantName: string }> {
  const res = await fetch("/api/tenant/restore", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      targetTenantId,
      confirmTenantName,
      ...options
    })
  });

  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || "Failed to restore tenant workspace.");
  }
  return data;
}

/**
 * Triggers a platform-wide backup (Super Admin only).
 */
export async function createPlatformBackup(
  actingUid?: string,
  actingEmail?: string
): Promise<{ success: boolean; backupId: string; outputUriPrefix: string; totalRecords: number; totalTenants: number }> {
  const res = await fetch("/api/platform/backup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ actingUid, actingEmail })
  });

  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || "Failed to trigger platform backup.");
  }
  return data;
}

/**
 * Lists platform-wide backup runs (Super Admin only).
 */
export async function fetchPlatformBackups(
  actingUid?: string,
  actingEmail?: string
): Promise<PlatformBackupRecord[]> {
  const params = new URLSearchParams({
    ...(actingUid ? { actingUid } : {}),
    ...(actingEmail ? { actingEmail } : {})
  });

  const res = await fetch(`/api/platform/backups?${params.toString()}`);
  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || "Failed to list platform backups.");
  }
  return data.backups || [];
}

/**
 * Restores platform-wide data (Super Admin only with Maker-Checker dual authorization).
 */
export async function restorePlatformBackup(
  confirmPhrase: string,
  secondAdminEmail: string,
  secondAdminPassword?: string,
  backupId?: string,
  actingUid?: string,
  actingEmail?: string
): Promise<{ success: boolean; message: string }> {
  const res = await fetch("/api/platform/restore", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      confirmPhrase,
      secondAdminEmail,
      secondAdminPassword,
      backupId,
      actingUid,
      actingEmail
    })
  });

  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || "Failed to restore platform backup.");
  }
  return data;
}

/**
 * Fetches audit logs for tenant purge/backup actions.
 */
export async function fetchAuditLogs(
  targetTenantId?: string
): Promise<AuditLogItem[]> {
  const url = targetTenantId ? `/api/tenant/audit-log?tenantId=${encodeURIComponent(targetTenantId)}` : "/api/tenant/audit-log";
  const res = await fetch(url);
  const data = await res.json();
  if (!res.ok || !data.success) return [];
  return data.logs || [];
}

/**
 * Utility to download JSON files in browser.
 */
export function downloadJsonFile(fileName: string, data: any) {
  const jsonStr = typeof data === "string" ? data : JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

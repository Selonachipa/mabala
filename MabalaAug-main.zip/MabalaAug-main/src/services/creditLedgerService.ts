import { doc, runTransaction, getDoc, collection, getDocs } from "firebase/firestore";

export type CreditGrantEventType = 'signup' | 'topup' | 'renewal' | 'adminTopup';

export interface CreditLedgerRecord {
  id: string;
  tenantId: string;
  timestamp: string;
  type: 'credit_grant' | 'deduction' | 'allocation';
  eventType?: CreditGrantEventType;
  idempotencyKey?: string;
  amount: number;
  previousBalance: number;
  newBalance: number;
  moduleId?: string;
  description: string;
  checksum: string;
}

/**
 * Helper to get docRef safely across Firebase Client SDK, Admin SDK, and Mock DBs
 */
function getDocRef(dbInstance: any, ...pathSegments: string[]) {
  if (typeof dbInstance?.doc === "function") {
    return dbInstance.doc(pathSegments.join("/"));
  }
  return doc(dbInstance, pathSegments[0], ...pathSegments.slice(1));
}

/**
 * Helper to run transaction safely across Firebase Client SDK, Admin SDK, and Mock DBs
 */
async function execTransaction(dbInstance: any, updateFunction: (tx: any) => Promise<any>) {
  if (typeof dbInstance?.runTransaction === "function") {
    return await dbInstance.runTransaction(updateFunction);
  }
  return await runTransaction(dbInstance, updateFunction);
}

/**
 * Simple record checksum calculation helper
 */
export function calculateRecordHash(record: Record<string, any>): string {
  const str = `${record.tenantId || ''}_${record.timestamp || ''}_${record.type || ''}_${record.amount || 0}_${record.previousBalance || 0}_${record.newBalance || 0}`;
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return "HASH-" + Math.abs(hash).toString(16).toUpperCase();
}

/**
 * Atomic and Idempotent Credit Grant Processor.
 * 
 * Allowed Grant Events:
 * 1. New user sign-up: idempotencyKey = `signup:${uid}`
 * 2. Credit top-up purchase: idempotencyKey = `topup:${lipilaTransactionId}`
 * 3. Subscription renewal: idempotencyKey = `renewal:${subscriptionId}:${period}`
 * 4. Super Admin manual credit top-up: idempotencyKey = `adminTopup:${grantId}`
 * 
 * If the idempotencyKey already exists in `tenants/{tenantId}/creditLedger/{idempotencyKey}`,
 * the grant is silently ignored (idempotent no-op) and the existing balance is returned.
 * No login handler or session restoration code path is ever permitted to issue credit grants.
 */
export async function grantCreditsIdempotent(
  dbInstance: any,
  tenantId: string,
  amount: number,
  eventType: CreditGrantEventType,
  idempotencyKey: string,
  description: string
): Promise<{ success: boolean; newBalance: number; alreadyProcessed: boolean }> {
  if (!dbInstance || !tenantId || amount <= 0) {
    return { success: false, newBalance: 0, alreadyProcessed: false };
  }

  const ledgerDocRef = getDocRef(dbInstance, "tenants", tenantId, "creditLedger", idempotencyKey);
  const specLedgerDocRef = getDocRef(dbInstance, "tenants", tenantId, "credit_wallet", "default", "ledger", idempotencyKey);
  const walletDocRef = getDocRef(dbInstance, "tenants", tenantId, "wallet", "credits");
  const specWalletDocRef = getDocRef(dbInstance, "tenants", tenantId, "credit_wallet", "default");
  const userMetadataRef = getDocRef(dbInstance, "users_data", tenantId);

  let txResult: { success: boolean; newBalance: number; alreadyProcessed: boolean } | null = null;
  const maxAttempts = 3;

  for (let attempt = 1; attempt <= maxAttempts && !txResult; attempt++) {
    try {
      txResult = await execTransaction(dbInstance, async (transaction) => {
        // 1. Check if this exact idempotency key document already exists in either ledger subcollection
        const ledgerSnap = await transaction.get(ledgerDocRef);
        const specLedgerSnap = await transaction.get(specLedgerDocRef);

        if (ledgerSnap.exists() || specLedgerSnap.exists()) {
          console.log(`[Credit Ledger Guard] Idempotent key "${idempotencyKey}" already processed for tenant ${tenantId}. Skipping duplicate grant.`);
          const specWalletSnap = await transaction.get(specWalletDocRef);
          const walletSnap = await transaction.get(walletDocRef);
          
          let currentBalance = 0;
          if (specWalletSnap.exists()) {
            currentBalance = Number(specWalletSnap.data().balance ?? specWalletSnap.data().currentBalance) || 0;
          } else if (walletSnap.exists()) {
            currentBalance = Number(walletSnap.data().currentBalance) || 0;
          }
          return { success: true, newBalance: currentBalance, alreadyProcessed: true };
        }

        // 2. Read existing wallet document (check spec credit_wallet first, fallback to wallet/credits)
        const specWalletSnap = await transaction.get(specWalletDocRef);
        const walletSnap = await transaction.get(walletDocRef);
        
        let previousBalance = 0;
        let lifetimeIssued = 0;
        let lifetimeConsumed = 0;
        let planAllotment = 0;
        let version = 1;

        if (specWalletSnap.exists()) {
          const swData = specWalletSnap.data();
          previousBalance = Number(swData.balance ?? swData.currentBalance) || 0;
          lifetimeIssued = Number(swData.lifetimeIssued) || 0;
          lifetimeConsumed = Number(swData.lifetimeConsumed) || 0;
          planAllotment = Number(swData.planAllotment) || 0;
          version = (Number(swData.version) || 1) + 1;
        } else if (walletSnap.exists()) {
          const wData = walletSnap.data();
          previousBalance = Number(wData.currentBalance) || 0;
          lifetimeIssued = Number(wData.lifetimeIssued) || 0;
          lifetimeConsumed = Number(wData.lifetimeConsumed) || 0;
          planAllotment = Number(wData.planAllotment) || 0;
          version = (Number(wData.version) || 1) + 1;
        } else {
          // Fallback: check users_data metadata document
          const userMetaSnap = await transaction.get(userMetadataRef);
          if (userMetaSnap.exists()) {
            previousBalance = Number(userMetaSnap.data().credits) || 0;
          }
        }

        const newBalance = previousBalance + amount;
        const newLifetimeIssued = lifetimeIssued + amount;
        const nowStr = new Date().toISOString();

        // 3. Construct immutable ledger record
        const ledgerRecord: CreditLedgerRecord = {
          id: idempotencyKey,
          tenantId,
          timestamp: nowStr,
          type: "credit_grant",
          eventType,
          idempotencyKey,
          amount,
          previousBalance,
          newBalance,
          description,
          checksum: ""
        };
        ledgerRecord.checksum = calculateRecordHash(ledgerRecord);

        // 4. Write ledger entry atomically inside the transaction into both subcollections
        transaction.set(ledgerDocRef, ledgerRecord);
        transaction.set(specLedgerDocRef, {
          ...ledgerRecord,
          balanceAfter: newBalance,
          createdAt: nowStr,
          createdBy: "system",
          source: "grantCreditsIdempotent"
        });

        // 5. Update credit_wallet/default and wallet/credits documents
        const walletPayload = {
          balance: newBalance,
          currentBalance: newBalance,
          lifetimeIssued: newLifetimeIssued,
          lifetimeConsumed,
          planType: eventType === 'signup' ? 'free' : 'custom',
          lastGrantType: eventType,
          lastGrantAt: nowStr,
          lastGrantAmount: amount,
          lastGrantIdempotencyKey: idempotencyKey,
          planAllotment: eventType === 'renewal' ? amount : planAllotment,
          version,
          updatedAt: nowStr
        };

        transaction.set(specWalletDocRef, walletPayload, { merge: true });
        transaction.set(walletDocRef, walletPayload, { merge: true });

        console.log(`[Credit Ledger] Granted +${amount} credits to tenant ${tenantId} (${eventType}). Key: ${idempotencyKey}. New Balance: ${newBalance}`);
        return { success: true, newBalance, alreadyProcessed: false };
      });

      // Update users_data metadata outside transaction to avoid OCC version lock contention
      if (txResult) {
        try {
          if (typeof dbInstance?.doc === "function") {
            await dbInstance.doc(`users_data/${tenantId}`).set({ credits: txResult.newBalance, updatedAt: new Date().toISOString() }, { merge: true });
          } else {
            await userMetadataRef.firestore?.doc?.(`users_data/${tenantId}`)?.set({ credits: txResult.newBalance, updatedAt: new Date().toISOString() }, { merge: true });
          }
        } catch (_) {}
      }

      return txResult;
    } catch (err: any) {
      const isVersionConflict = err?.message?.includes("base version") || err?.message?.includes("version") || err?.code === "aborted";
      if (isVersionConflict && attempt < maxAttempts) {
        await new Promise(res => setTimeout(res, 50 * Math.pow(2, attempt) + Math.floor(Math.random() * 50)));
      } else {
        console.error(`[Credit Ledger Error] grantCreditsIdempotent failed for key ${idempotencyKey} (attempt ${attempt}):`, err);
        if (attempt >= maxAttempts) throw err;
      }
    }
  }

  return txResult || { success: false, newBalance: 0, alreadyProcessed: false };
}

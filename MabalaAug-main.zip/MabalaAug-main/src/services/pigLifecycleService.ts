export type PigSex = "MALE" | "FEMALE";
export type AnimalStatus = "ACTIVE" | "DECEASED";
export type BreedingStatus = "ELIGIBLE" | "INELIGIBLE";
export type HandoverStatus = "PENDING_ACCEPTANCE" | "ACCEPTED" | "HANDOVER_EXCEPTION" | "REJECTED";
export type MortalityClassification =
  | "STILLBORN"
  | "NEONATAL_DEATH"
  | "WEANER_DEATH"
  | "GROWER_DEATH"
  | "FINISHER_DEATH"
  | "BREEDING_STOCK_DEATH"
  | "UNKNOWN";

export interface PigAnimal {
  centralAnimalId: string;
  pigId: string;
  tenantId: string;
  name?: string;
  species: "PIG";
  breed: string;
  sex: PigSex;
  status: AnimalStatus;
  healthStatus: "CLEARED" | "NOT_CLEARED";
  breedingStatus: BreedingStatus;
  ownershipStatus: "OWNED" | "NOT_OWNED";
  quarantined: boolean;
  dateOfBirth?: string;
  weightKg?: number;
  currentValuationId?: string;
  version: number;
  motherAnimalId?: string;
  fatherAnimalId?: string;
}

export interface ValuationRecord {
  valuationId: string;
  tenantId: string;
  animalId?: string;
  localPigletId?: string;
  source: "REGISTRATION" | "REVALUATION" | "MORTALITY";
  valuationDateTime: string;
  valuationMethod: "FVLCTS" | "CARRYING_VALUE";
  fairValue: number;
  estimatedCostsToSell: number;
  fvlcts: number;
  currency: string;
  calculationVersion: string;
  inputs: Record<string, unknown>;
}

export interface BreedingEvent {
  breedingEventId: string;
  tenantId: string;
  sowAnimalId: string;
  boarAnimalId: string;
  staffId: string;
  assignmentId?: string;
  serviceDateTime: string;
  breedingMethod: "NATURAL_SERVICE" | "ARTIFICIAL_INSEMINATION";
  gestationDays: number;
  expectedFarrowingDateTime: string;
  estimatedFarrowingTime?: string;
  forecastConfidence: "STANDARD" | "HIGH" | "LOW";
  forecastVersion: number;
  status: "CONFIRMED" | "FARROWED" | "CANCELLED" | "SUPERSEDED";
  createdAt: string;
}

export interface PigletRecord {
  localPigletId: string;
  centralAnimalId: string;
  farrowingEventId: string;
  litterId: string;
  motherAnimalId: string;
  fatherAnimalId: string;
  sex: PigSex;
  birthDateTime: string;
  birthWeightKg: number;
  initialValuationId: string;
  registrationStatus: "REGISTERED";
}

export interface FarrowingEvent {
  farrowingEventId: string;
  breedingEventId: string;
  sowAnimalId: string;
  boarAnimalId: string;
  staffId: string;
  farrowingDateTime: string;
  totalBorn: number;
  liveBorn: number;
  stillborn: number;
  neonatalDeaths: number;
  litterId: string;
  piglets: PigletRecord[];
  status: "RECORDED";
  createdAt: string;
}

export interface MortalityEvent {
  mortalityEventId: string;
  idempotencyKey: string;
  tenantId: string;
  animalId?: string;
  localPigletId?: string;
  farrowingEventId?: string;
  litterId?: string;
  staffId: string;
  classification: MortalityClassification;
  cause: string;
  deathDateTime: string;
  weightKg?: number;
  lastValuationId: string;
  carryingValue: number;
  registryStatus: "RECORDED";
  createdAt: string;
}

export interface Handover {
  handoverId: string;
  tenantId: string;
  entityType: "LITTER";
  entityId: string;
  fromStaffId: string;
  toStaffId: string;
  fromStage: "FARROWING" | "LITTER_MANAGEMENT";
  toStage: "FARROWING" | "LITTER_MANAGEMENT";
  quantityTransferred: number;
  animalIds: string[];
  submittedAt: string;
  acceptedAt?: string;
  status: HandoverStatus;
  documentVersion: number;
  documentHash: string;
}

export interface PigLifecycleState {
  animals: Map<string, PigAnimal>;
  valuations: Map<string, ValuationRecord>;
  breedingEvents: Map<string, BreedingEvent>;
  farrowingEvents: Map<string, FarrowingEvent>;
  piglets: Map<string, PigletRecord>;
  mortalityEvents: Map<string, MortalityEvent>;
  handovers: Map<string, Handover>;
  idempotency: Map<string, unknown>;
}

export interface NewbornInput {
  localPigletId: string;
  sex: PigSex;
  birthWeightKg: number;
  proposedFairValue: number;
  estimatedCostsToSell?: number;
}

export interface MortalityInput {
  idempotencyKey: string;
  animalId?: string;
  localPigletId?: string;
  farrowingEventId?: string;
  litterId?: string;
  staffId: string;
  classification: MortalityClassification;
  cause: string;
  deathDateTime: string;
  weightKg?: number;
  expectedAnimalVersion?: number;
  proposedFairValue?: number;
}

export class PigLifecycleError extends Error {
  constructor(public readonly code: string, message: string) {
    super(message);
    this.name = "PigLifecycleError";
  }
}

function requireValue(value: string | undefined, code: string, message: string): string {
  if (!value?.trim()) throw new PigLifecycleError(code, message);
  return value;
}

function assertPermission(permissions: string[], permission: string): void {
  if (!permissions.includes(permission)) throw new PigLifecycleError("FORBIDDEN", `Missing permission ${permission}`);
}

function addDays(isoDateTime: string, days: number): string {
  const date = new Date(isoDateTime);
  if (Number.isNaN(date.getTime())) throw new PigLifecycleError("INVALID_DATE", "A valid ISO date/time is required");
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString();
}

function sha256(value: string): string {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) hash = Math.imul(hash ^ value.charCodeAt(index), 16777619);
  return `fnv1a-${(hash >>> 0).toString(16).padStart(8, "0")}`;
}

export function getFarrowingReadiness(expectedDateTime: string, now = new Date()): "NORMAL" | "PREPARATION" | "DUE_SOON" | "HIGH_PRIORITY" | "CRITICAL" | "OVERDUE" {
  const hoursRemaining = (new Date(expectedDateTime).getTime() - now.getTime()) / 3600000;
  if (hoursRemaining < 0) return "OVERDUE";
  if (hoursRemaining < 24) return "CRITICAL";
  if (hoursRemaining <= 72) return "HIGH_PRIORITY";
  if (hoursRemaining <= 168) return "DUE_SOON";
  if (hoursRemaining <= 336) return "PREPARATION";
  return "NORMAL";
}

export class PigLifecycleService {
  constructor(private readonly state: PigLifecycleState, private readonly now: () => Date = () => new Date()) {}

  createBreedingEvent(input: Omit<BreedingEvent, "expectedFarrowingDateTime" | "forecastVersion" | "status" | "createdAt"> & { gestationDays?: number }, permissions: string[]): BreedingEvent {
    assertPermission(permissions, "PIG_BREEDING_CREATE");
    const sow = this.state.animals.get(requireValue(input.sowAnimalId, "SOW_REQUIRED", "A sow is required"));
    const boar = this.state.animals.get(requireValue(input.boarAnimalId, "BOAR_REQUIRED", "A boar is required"));
    if (!sow || !boar || sow.tenantId !== input.tenantId || boar.tenantId !== input.tenantId) throw new PigLifecycleError("ANIMAL_NOT_FOUND", "Both breeding animals must belong to the tenant");
    if (sow.sex !== "FEMALE" || boar.sex !== "MALE") throw new PigLifecycleError("INVALID_BREEDING_PAIR", "Breeding requires a female sow and male boar");
    for (const animal of [sow, boar]) {
      if (animal.status !== "ACTIVE" || animal.ownershipStatus !== "OWNED" || animal.quarantined || animal.healthStatus !== "CLEARED" || animal.breedingStatus !== "ELIGIBLE") {
        throw new PigLifecycleError("ANIMAL_NOT_ELIGIBLE", `${animal.pigId} is not eligible for breeding`);
      }
    }
    if ([...this.state.breedingEvents.values()].some(event => event.sowAnimalId === sow.centralAnimalId && event.status === "CONFIRMED")) throw new PigLifecycleError("CONFLICTING_BREEDING", "The sow already has an active breeding event");
    const gestationDays = input.gestationDays ?? 114;
    if (gestationDays < 1 || gestationDays > 200) throw new PigLifecycleError("INVALID_GESTATION", "Gestation days must be between 1 and 200");
    const event: BreedingEvent = {
      ...input,
      gestationDays,
      expectedFarrowingDateTime: addDays(input.serviceDateTime, gestationDays),
      forecastVersion: 1,
      status: "CONFIRMED",
      createdAt: this.now().toISOString()
    };
    this.state.breedingEvents.set(event.breedingEventId, event);
    return event;
  }

  recordFarrowing(input: { farrowingEventId: string; breedingEventId: string; staffId: string; farrowingDateTime: string; totalBorn: number; liveBorn: number; stillborn: number; neonatalDeaths?: number; newborns: NewbornInput[] }, permissions: string[]): FarrowingEvent {
    assertPermission(permissions, "PIG_FARROWING_CREATE");
    const breeding = this.state.breedingEvents.get(input.breedingEventId);
    if (!breeding) throw new PigLifecycleError("BREEDING_NOT_FOUND", "The breeding event does not exist");
    if (breeding.status !== "CONFIRMED") throw new PigLifecycleError("BREEDING_NOT_ACTIVE", "The breeding event is not active");
    if (input.totalBorn !== input.liveBorn + input.stillborn) throw new PigLifecycleError("BIRTH_COUNT_MISMATCH", "Total born must equal live born plus stillborn");
    if (input.newborns.length !== input.liveBorn) throw new PigLifecycleError("PIGLET_COUNT_MISMATCH", "Every live piglet requires an operational record");
    if (this.state.farrowingEvents.has(input.farrowingEventId)) throw new PigLifecycleError("DUPLICATE_FARROWING", "The farrowing event already exists");
    const litterId = `LIT-${input.farrowingEventId}`;
    const piglets = input.newborns.map((newborn, index) => this.registerPiglet({ ...newborn, localPigletId: newborn.localPigletId || `${litterId}-${index + 1}` }, breeding, input.farrowingEventId, litterId));
    const event: FarrowingEvent = {
      farrowingEventId: input.farrowingEventId,
      breedingEventId: breeding.breedingEventId,
      sowAnimalId: breeding.sowAnimalId,
      boarAnimalId: breeding.boarAnimalId,
      staffId: input.staffId,
      farrowingDateTime: input.farrowingDateTime,
      totalBorn: input.totalBorn,
      liveBorn: input.liveBorn,
      stillborn: input.stillborn,
      neonatalDeaths: input.neonatalDeaths ?? 0,
      litterId,
      piglets,
      status: "RECORDED",
      createdAt: this.now().toISOString()
    };
    breeding.status = "FARROWED";
    this.state.farrowingEvents.set(event.farrowingEventId, event);
    return event;
  }

  private registerPiglet(input: NewbornInput, breeding: BreedingEvent, farrowingEventId: string, litterId: string): PigletRecord {
    if (this.state.piglets.has(input.localPigletId)) throw new PigLifecycleError("DUPLICATE_PIGLET", `Piglet ${input.localPigletId} already exists`);
    if (input.birthWeightKg <= 0 || input.proposedFairValue < 0) throw new PigLifecycleError("INVALID_NEWBORN", "Birth weight must be positive and valuation cannot be negative");
    const valuationId = `VAL-${input.localPigletId}`;
    const centralAnimalId = `AN-${input.localPigletId}`;
    const pigId = `PIG-${input.localPigletId}`;
    const valuation: ValuationRecord = {
      valuationId, tenantId: breeding.tenantId, localPigletId: input.localPigletId, source: "REGISTRATION", valuationDateTime: this.now().toISOString(), valuationMethod: "FVLCTS", fairValue: input.proposedFairValue, estimatedCostsToSell: input.estimatedCostsToSell ?? 0, fvlcts: input.proposedFairValue - (input.estimatedCostsToSell ?? 0), currency: "ZMW", calculationVersion: "PIGLET-1", inputs: { birthWeightKg: input.birthWeightKg }
    };
    const animal: PigAnimal = { centralAnimalId, pigId, tenantId: breeding.tenantId, species: "PIG", breed: "UNKNOWN", sex: input.sex, status: "ACTIVE", healthStatus: "CLEARED", breedingStatus: "INELIGIBLE", ownershipStatus: "OWNED", quarantined: false, currentValuationId: valuationId, version: 1, motherAnimalId: breeding.sowAnimalId, fatherAnimalId: breeding.boarAnimalId };
    this.state.valuations.set(valuationId, valuation);
    this.state.animals.set(centralAnimalId, animal);
    const piglet: PigletRecord = { localPigletId: input.localPigletId, centralAnimalId, farrowingEventId, litterId, motherAnimalId: breeding.sowAnimalId, fatherAnimalId: breeding.boarAnimalId, sex: input.sex, birthDateTime: this.now().toISOString(), birthWeightKg: input.birthWeightKg, initialValuationId: valuationId, registrationStatus: "REGISTERED" };
    this.state.piglets.set(piglet.localPigletId, piglet);
    return piglet;
  }

  recordMortality(input: MortalityInput, permissions: string[]): MortalityEvent {
    assertPermission(permissions, "PIG_MORTALITY_CREATE");
    const prior = this.state.idempotency.get(input.idempotencyKey);
    if (prior) return prior as MortalityEvent;
    if (!input.animalId && !input.localPigletId) throw new PigLifecycleError("ANIMAL_REQUIRED", "An animal or local piglet identity is required");
    const animalId = input.animalId || this.state.piglets.get(input.localPigletId!)?.centralAnimalId;
    const animal = animalId ? this.state.animals.get(animalId) : undefined;
    if (!animal || animal.tenantId !== this.state.animals.get(animal.centralAnimalId)?.tenantId) throw new PigLifecycleError("ANIMAL_NOT_FOUND", "The animal is not registered");
    if (animal.status !== "ACTIVE") throw new PigLifecycleError("ANIMAL_NOT_ALIVE", "Mortality has already been recorded for this animal");
    if (input.expectedAnimalVersion !== undefined && input.expectedAnimalVersion !== animal.version) throw new PigLifecycleError("STALE_ANIMAL_RECORD", "The animal changed before this operation was submitted");
    const previousValuation = animal.currentValuationId ? this.state.valuations.get(animal.currentValuationId) : undefined;
    if (!previousValuation) throw new PigLifecycleError("VALUATION_NOT_FOUND", "The authoritative carrying value is unavailable");
    const mortalityValuationId = `VAL-MORT-${input.idempotencyKey}`;
    this.state.valuations.set(mortalityValuationId, { ...previousValuation, valuationId: mortalityValuationId, source: "MORTALITY", valuationDateTime: input.deathDateTime, valuationMethod: "CARRYING_VALUE", fairValue: previousValuation.fvlcts, estimatedCostsToSell: 0, fvlcts: previousValuation.fvlcts, calculationVersion: "MORTALITY-1", inputs: { priorValuationId: previousValuation.valuationId } });
    animal.status = "DECEASED";
    animal.currentValuationId = mortalityValuationId;
    animal.version += 1;
    const event: MortalityEvent = { mortalityEventId: `MOR-${input.idempotencyKey}`, ...input, tenantId: animal.tenantId, animalId, lastValuationId: mortalityValuationId, carryingValue: previousValuation.fvlcts, registryStatus: "RECORDED", createdAt: this.now().toISOString() };
    this.state.mortalityEvents.set(event.mortalityEventId, event);
    this.state.idempotency.set(input.idempotencyKey, event);
    return event;
  }

  createHandover(input: Omit<Handover, "tenantId" | "submittedAt" | "status" | "documentVersion" | "documentHash"> & { tenantId?: string }, permissions: string[]): Handover {
    assertPermission(permissions, "PIG_HANDOVER_CREATE");
    if (input.quantityTransferred !== input.animalIds.length) throw new PigLifecycleError("HANDOVER_COUNT_MISMATCH", "Transferred quantity must match animal IDs");
    const animals = input.animalIds.map(animalId => this.state.animals.get(animalId));
    const tenantId = animals[0]?.tenantId;
    if (!tenantId || animals.some(animal => !animal || animal.tenantId !== tenantId || animal.status !== "ACTIVE")) throw new PigLifecycleError("HANDOVER_ANIMAL_INVALID", "Every handed-over animal must be an active registry animal from one tenant");
    const handoverInput = { ...input, tenantId };
    const handover: Handover = { ...handoverInput, submittedAt: this.now().toISOString(), status: "PENDING_ACCEPTANCE", documentVersion: 1, documentHash: sha256(JSON.stringify(handoverInput)) };
    this.state.handovers.set(handover.handoverId, handover);
    return handover;
  }

  acceptHandover(handoverId: string, recipientStaffId: string, confirmedAnimalIds: string[], permissions: string[]): Handover {
    assertPermission(permissions, "PIG_HANDOVER_ACCEPT");
    const handover = this.state.handovers.get(handoverId);
    if (!handover) throw new PigLifecycleError("HANDOVER_NOT_FOUND", "The handover does not exist");
    if (handover.status !== "PENDING_ACCEPTANCE") throw new PigLifecycleError("HANDOVER_CLOSED", "The handover is already resolved");
    if (handover.toStaffId !== recipientStaffId) throw new PigLifecycleError("WRONG_RECIPIENT", "Only the assigned recipient can accept the handover");
    if (confirmedAnimalIds.length !== handover.quantityTransferred || confirmedAnimalIds.some(id => !handover.animalIds.includes(id))) {
      handover.status = "HANDOVER_EXCEPTION";
      throw new PigLifecycleError("HANDOVER_EXCEPTION", "Received animal count or identity does not match the handover");
    }
    handover.status = "ACCEPTED";
    handover.acceptedAt = this.now().toISOString();
    return handover;
  }

  reconcile(litterId: string): { pigManagerLive: number; registryLive: number; mortalityCount: number; status: "RECONCILED" | "RECONCILIATION_EXCEPTION" } {
    const litterPiglets = [...this.state.piglets.values()].filter(piglet => piglet.litterId === litterId);
    const registryLive = litterPiglets.filter(piglet => this.state.animals.get(piglet.centralAnimalId)?.status === "ACTIVE").length;
    const mortalityCount = [...this.state.mortalityEvents.values()].filter(event => event.litterId === litterId || litterPiglets.some(piglet => piglet.localPigletId === event.localPigletId)).length;
    return { pigManagerLive: litterPiglets.length - mortalityCount, registryLive, mortalityCount, status: registryLive === litterPiglets.length - mortalityCount ? "RECONCILED" : "RECONCILIATION_EXCEPTION" };
  }
}

export function createPigLifecycleState(): PigLifecycleState {
  return { animals: new Map(), valuations: new Map(), breedingEvents: new Map(), farrowingEvents: new Map(), piglets: new Map(), mortalityEvents: new Map(), handovers: new Map(), idempotency: new Map() };
}
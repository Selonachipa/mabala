import { db, isConfigured } from "../firebase";
import { collection, getDocs } from "firebase/firestore";
import { safeLocalStorage as localStorage, safeParseJSON } from "../utils/safeStorage";
import { getDeletedFarmNodesTracker } from "./nodeDeletionService";
import { NETWORK_ACTIVE_TENANTS_66 } from "../data/networkTenantsData";

export interface TenantNodeRecord {
  id: string;
  uid: string;
  tenantUid: string;
  tenantId: string;
  name: string;
  displayName: string;
  ownerName: string;
  farmName: string;
  farm?: any;
  farms?: any[];
  email: string;
  tenantEmail: string;
  ownerEmail: string;
  phone: string;
  tenantPhone: string;
  ownerPhone: string;
  role: string;
  accountType: string;
  type?: "Farmer" | "Agro-Dealer" | "Supplier" | "Super Admin" | string;
  province?: string;
  district?: string;
  town?: string;
  location?: string;
  tier?: string;
  subscriptionTier?: string;
  subscriptionPackage?: string;
  subscriptionStatus?: string;
  credits?: number;
  smsCredits?: number;
  status: string;
  createdAt?: string | null;
  lastActiveAt?: string | null;
  lastLoginAt?: string | null;
  cropsCount?: number;
  livestockCount?: number;
  invoicesCount?: number;
  backupsCount?: number;
  lastBackupDate?: string | null;
  lastBackupType?: string | null;
  lastRestoredAt?: string | null;
  [key: string]: any;
}

export const PRESET_BASE_TENANTS: TenantNodeRecord[] = [...NETWORK_ACTIVE_TENANTS_66];

let cachedTenantNodes: TenantNodeRecord[] | null = null;
let lastCacheTimestamp = 0;
const CACHE_TTL_MS = 20000; // 20s TTL for sub-second UI responsiveness

export function invalidateTenantNodesCache(): void {
  cachedTenantNodes = null;
  lastCacheTimestamp = 0;
}

function withTimeout<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((resolve) => setTimeout(() => resolve(fallback), ms))
  ]);
}

export async function fetchAllActiveTenantNodes(options?: {
  adminEmail?: string;
  adminUid?: string;
  authToken?: string;
  extraTenants?: any[];
  forceRefresh?: boolean;
  timeoutMs?: number;
}): Promise<TenantNodeRecord[]> {
  if (!options?.forceRefresh && cachedTenantNodes && (Date.now() - lastCacheTimestamp < CACHE_TTL_MS)) {
    return cachedTenantNodes;
  }

  const combinedMap = new Map<string, TenantNodeRecord>();

  // Helper to normalize role
  const resolveRole = (r?: any): string => {
    const str = (r || "Farmer").toString();
    if (/admin/i.test(str)) return "Super Admin";
    if (/dealer|merchant/i.test(str)) return "Agro-Dealer";
    if (/offtaker|buyer/i.test(str)) return "Offtaker";
    if (/agronomist/i.test(str)) return "Agronomist";
    if (/vet/i.test(str)) return "Veterinary";
    if (/supplier|partner/i.test(str)) return "Supplier";
    return "Farmer";
  };

  const resolveType = (r?: any): "Farmer" | "Agro-Dealer" | "Supplier" => {
    const role = resolveRole(r);
    if (role === "Agro-Dealer") return "Agro-Dealer";
    if (role === "Supplier" || role === "Offtaker") return "Supplier";
    return "Farmer";
  };

  // 1. Seed with base presets
  PRESET_BASE_TENANTS.forEach(preset => {
    combinedMap.set(preset.uid, { ...preset });
    if (preset.email) {
      combinedMap.set(preset.email.toLowerCase(), { ...preset });
    }
  });

  // 2. Load from props / extraTenants
  if (Array.isArray(options?.extraTenants)) {
    options.extraTenants.forEach((u: any) => {
      if (!u) return;
      const uid = u.uid || u.tenantUid || u.id || u.tenantId;
      const email = u.email || u.tenantEmail || u.ownerEmail || "";
      if (!uid && !email) return;

      const farmName = u.farms?.[0]?.name || u.farm?.name || u.farmName || u.displayName || u.name || `Farm Node (${email})`;
      const role = resolveRole(u.role || u.accountType || u.type);
      const type = resolveType(role);
      const effectiveId = uid || `NODE-${email}`;

      const rec: TenantNodeRecord = {
        id: effectiveId,
        uid: effectiveId,
        tenantUid: effectiveId,
        tenantId: effectiveId,
        name: u.displayName || u.name || farmName,
        displayName: u.displayName || u.name || farmName,
        ownerName: u.ownerName || u.name || u.displayName || "Farm Owner",
        farmName,
        farm: u.farm || { name: farmName, province: u.province, district: u.district },
        farms: Array.isArray(u.farms) ? u.farms : [u.farm || { name: farmName }],
        type,
        role,
        accountType: role,
        email,
        tenantEmail: email,
        ownerEmail: email,
        phone: u.phone || u.phoneNumber || u.tenantPhone || u.ownerPhone || "+260978000000",
        tenantPhone: u.phone || u.phoneNumber || u.tenantPhone || u.ownerPhone || "+260978000000",
        ownerPhone: u.phone || u.phoneNumber || u.tenantPhone || u.ownerPhone || "+260978000000",
        province: u.province || u.farm?.province || "Central Province",
        district: u.district || u.farm?.district || "Kabwe",
        town: u.town || u.district || "Kabwe",
        location: typeof u.location === "string" ? u.location : (u.district ? `${u.district}, ${u.province || ""}` : "Zambia"),
        tier: u.subscriptionTier || u.subscriptionPackage || "Standard",
        subscriptionTier: u.subscriptionTier || u.subscriptionPackage || "Standard",
        subscriptionPackage: u.subscriptionTier || u.subscriptionPackage || "Standard",
        subscriptionStatus: u.subscriptionStatus || u.status || "ACTIVE",
        credits: Number(u.credits ?? 60),
        smsCredits: Number(u.smsCredits ?? 0),
        status: u.status || "ACTIVE",
        createdAt: u.createdAt || null,
        lastActiveAt: u.lastActiveAt || u.lastLoginAt || null
      };

      combinedMap.set(effectiveId, rec);
      if (email) combinedMap.set(email.toLowerCase(), rec);
    });
  }

  // 3. Load from local storage
  try {
    const localUsers = safeParseJSON(localStorage.getItem("mabala_registered_users") || "[]", []);
    if (Array.isArray(localUsers)) {
      localUsers.forEach((u: any) => {
        if (!u) return;
        const uid = u.uid || u.tenantUid || u.id;
        const email = u.email || u.tenantEmail || "";
        if (!uid && !email) return;

        const effectiveId = uid || `LOCAL-${email}`;
        const farmName = u.farms?.[0]?.name || u.farm?.name || u.farmName || u.name || `Farm Node (${email})`;
        const role = resolveRole(u.role || u.accountType);
        const type = resolveType(role);

        const rec: TenantNodeRecord = {
          id: effectiveId,
          uid: effectiveId,
          tenantUid: effectiveId,
          tenantId: effectiveId,
          name: u.displayName || u.name || farmName,
          displayName: u.displayName || u.name || farmName,
          ownerName: u.name || u.displayName || "Farm Owner",
          farmName,
          farm: u.farm || { name: farmName, province: u.province, district: u.district },
          farms: Array.isArray(u.farms) ? u.farms : [u.farm || { name: farmName }],
          type,
          role,
          accountType: role,
          email,
          tenantEmail: email,
          ownerEmail: email,
          phone: u.phone || u.phoneNumber || u.tenantPhone || "",
          tenantPhone: u.phone || u.phoneNumber || u.tenantPhone || "",
          ownerPhone: u.phone || u.phoneNumber || u.tenantPhone || "",
          province: u.province || "Lusaka Province",
          district: u.district || "Lusaka",
          town: u.town || "Lusaka",
          location: u.location || "Zambia",
          tier: u.subscriptionTier || u.subscriptionPackage || "Standard",
          subscriptionTier: u.subscriptionTier || u.subscriptionPackage || "Standard",
          subscriptionPackage: u.subscriptionTier || u.subscriptionPackage || "Standard",
          subscriptionStatus: "ACTIVE",
          credits: Number(u.credits ?? 60),
          smsCredits: Number(u.smsCredits ?? 0),
          status: "ACTIVE",
          createdAt: u.createdAt || null,
          lastActiveAt: u.lastActiveAt || u.lastLoginAt || null
        };

        combinedMap.set(effectiveId, rec);
        if (email) combinedMap.set(email.toLowerCase(), rec);
      });
    }
  } catch (_) {}

  // 4. Retrieve from Firestore users_data collection (which holds the full network workspace nodes)
  const fsTimeout = Math.min(options?.timeoutMs || 4000, 4000);
  if (isConfigured && db) {
    try {
      const snap = await withTimeout(getDocs(collection(db, "users_data")), fsTimeout, null);
      if (snap) {
        snap.forEach(docSnap => {
          const data = docSnap.data();
          const uid = docSnap.id;
          const email = (data.userProfile?.email || data.email || data.ownerEmail || "").toLowerCase();
          
          const farmsList = Array.isArray(data.farms) ? data.farms : [];
          const primaryFarm = (farmsList[0] && typeof farmsList[0] === "object") ? farmsList[0] : (data.farm && typeof data.farm === "object" ? data.farm : {});
          const farmName = primaryFarm?.name || data.farmName || data.workspaceName || data.companyName || data.name || (email ? `Farm Node (${email})` : `Farm Node ${uid.slice(0, 6)}`);
          const ownerName = data.userProfile?.name || data.name || data.displayName || "Farm Owner";
          const phone = data.userProfile?.phone || data.phone || data.phoneNumber || data.contactPhone || "";
          const role = resolveRole(data.role || data.accountType || data.userProfile?.role);
          const type = resolveType(role);

          const rec: TenantNodeRecord = {
            id: uid,
            uid,
            tenantUid: uid,
            tenantId: uid,
            name: ownerName,
            displayName: ownerName,
            ownerName,
            farmName,
            farm: primaryFarm?.name ? primaryFarm : { name: farmName, province: data.province, district: data.district },
            farms: farmsList.length > 0 ? farmsList : [{ name: farmName }],
            type,
            role,
            accountType: role,
            email,
            tenantEmail: email,
            ownerEmail: email,
            phone,
            tenantPhone: phone,
            ownerPhone: phone,
            province: primaryFarm.province || data.province || "Central Province",
            district: primaryFarm.district || data.district || "Kabwe",
            town: primaryFarm.town || data.town || "Kabwe",
            location: typeof data.location === "string" ? data.location : (data.district ? `${data.district}, ${data.province || ""}` : "Zambia"),
            tier: data.subscriptionPackage || data.subscriptionTier || "Standard",
            subscriptionTier: data.subscriptionPackage || data.subscriptionTier || "Standard",
            subscriptionPackage: data.subscriptionPackage || data.subscriptionTier || "Standard",
            subscriptionStatus: data.status || data.subscriptionStatus || "ACTIVE",
            credits: Number(data.credits ?? 60),
            smsCredits: Number(data.smsCredits ?? 0),
            status: data.status || "ACTIVE",
            createdAt: data.createdAt || null,
            sortKey: data.sortKey || data.createdAt || "2024-01-01T00:00:00.000Z",
            lastActiveAt: data.lastActiveAt || data.lastLoginAt || null,
            cropsCount: Array.isArray(data.crops) ? data.crops.length : 0,
            livestockCount: (Array.isArray(data.livestock) ? data.livestock.length : 0) + (Array.isArray(data.poultry) ? data.poultry.length : 0) + (Array.isArray(data.fish) ? data.fish.length : 0),
            invoicesCount: Array.isArray(data.invoices) ? data.invoices.length : 0
          };

          combinedMap.set(uid, rec);
          if (email) combinedMap.set(email, rec);
        });
      }
    } catch (fsErr) {
      console.warn("[tenantRegistryService] Firestore users_data scan notice:", fsErr);
    }

    // Also scan Firestore users collection
    try {
      const authSnap = await withTimeout(getDocs(collection(db, "users")), 2000, null);
      if (authSnap) {
        authSnap.forEach(d => {
          const data = d.data();
          const uid = d.id;
          const email = (data.email || "").toLowerCase();

          if (combinedMap.has(uid) || (email && combinedMap.has(email))) {
            const existing = combinedMap.get(uid) || (email ? combinedMap.get(email) : null);
            if (existing) {
              if (data.phone && !existing.phone) existing.phone = data.phone;
              if (data.name && !existing.name) existing.name = data.name;
              return;
            }
          }

          const role = resolveRole(data.role || data.accountType);
          const type = resolveType(role);
          const farmName = data.farmName || data.farm?.name || data.displayName || `${data.name || "User"}'s Farm Node`;

          const rec: TenantNodeRecord = {
            id: uid,
            uid,
            tenantUid: uid,
            tenantId: uid,
            name: data.name || data.displayName || "User",
            displayName: data.name || data.displayName || "User",
            ownerName: data.name || data.displayName || "User",
            farmName,
            farm: data.farm || { name: farmName },
            farms: [{ name: farmName }],
            type,
            role,
            accountType: role,
            email,
            tenantEmail: email,
            ownerEmail: email,
            phone: data.phone || data.phoneNumber || "",
            tenantPhone: data.phone || data.phoneNumber || "",
            ownerPhone: data.phone || data.phoneNumber || "",
            province: data.province || "Lusaka Province",
            district: data.district || "Lusaka",
            town: data.town || "Lusaka",
            location: "Zambia",
            tier: data.subscriptionPackage || data.subscriptionTier || "Standard",
            subscriptionTier: data.subscriptionPackage || data.subscriptionTier || "Standard",
            subscriptionPackage: data.subscriptionPackage || data.subscriptionTier || "Standard",
            subscriptionStatus: "ACTIVE",
            credits: Number(data.credits ?? 60),
            smsCredits: Number(data.smsCredits ?? 0),
            status: "ACTIVE",
            createdAt: data.createdAt || null,
            sortKey: data.sortKey || data.createdAt || "2024-01-01T00:00:00.000Z",
            lastActiveAt: data.lastActiveAt || data.lastLoginAt || null
          };

          combinedMap.set(uid, rec);
          if (email) combinedMap.set(email, rec);
        });
      }
    } catch (_) {}
  }

  // 5. Try Backend API /api/admin/farm-nodes
  try {
    const adminEmail = options?.adminEmail || "support@mabala.cloud";
    const adminUid = options?.adminUid || "icIoBG4eN5VOw2BvhNiFUnUqmsX2";
    const apiRes = await withTimeout(
      fetch("/api/admin/farm-nodes", {
        headers: {
          "Content-Type": "application/json",
          "x-mabala-super-email": adminEmail,
          "x-mabala-super-uid": adminUid,
          ...(options?.authToken ? { "Authorization": `Bearer ${options.authToken}` } : {})
        }
      }),
      3500,
      null
    );

    if (apiRes && apiRes.ok) {
      const data = await apiRes.json();
      const backendNodes = data.allNodes || data.nodes || [];
      if (Array.isArray(backendNodes)) {
        backendNodes.forEach((n: any) => {
          if (!n) return;
          const uid = n.tenantUid || n.tenantId || n.uid || n.id;
          const email = (n.email || n.ownerEmail || n.tenantEmail || "").toLowerCase();
          if (!uid && !email) return;

          const key = uid || email;
          const existing = combinedMap.get(key) || (email ? combinedMap.get(email) : null);
          const role = resolveRole(n.role || n.accountType || existing?.role);
          const type = resolveType(role);
          const farmName = n.farmName || n.farm?.name || n.displayName || existing?.farmName || "Mabala Farm Node";

          const rec: TenantNodeRecord = {
            id: uid || existing?.id || key,
            uid: uid || existing?.uid || key,
            tenantUid: uid || existing?.tenantUid || key,
            tenantId: uid || existing?.tenantId || key,
            name: n.displayName || n.name || n.ownerName || existing?.name || "Farm Owner",
            displayName: n.displayName || n.name || n.ownerName || existing?.displayName || "Farm Owner",
            ownerName: n.ownerName || n.name || n.displayName || existing?.ownerName || "Farm Owner",
            farmName,
            farm: n.farm || existing?.farm || { name: farmName, province: n.province, district: n.district },
            farms: Array.isArray(n.farms) && n.farms.length > 0 ? n.farms : (existing?.farms || [{ name: farmName }]),
            type,
            role,
            accountType: role,
            email: email || existing?.email || "",
            tenantEmail: email || existing?.tenantEmail || "",
            ownerEmail: email || existing?.ownerEmail || "",
            phone: n.phone || n.ownerPhone || n.tenantPhone || existing?.phone || "",
            tenantPhone: n.tenantPhone || n.phone || n.ownerPhone || existing?.tenantPhone || "",
            ownerPhone: n.ownerPhone || n.phone || n.tenantPhone || existing?.ownerPhone || "",
            province: n.province || existing?.province || "Central Province",
            district: n.district || existing?.district || "Kabwe",
            town: n.town || existing?.town || "Kabwe",
            location: typeof n.location === "string" ? n.location : (existing?.location || "Zambia"),
            tier: n.subscriptionPackage || n.subscriptionTier || existing?.tier || "Standard",
            subscriptionTier: n.subscriptionPackage || n.subscriptionTier || existing?.subscriptionTier || "Standard",
            subscriptionPackage: n.subscriptionPackage || n.subscriptionTier || existing?.subscriptionPackage || "Standard",
            subscriptionStatus: n.status || n.subscriptionStatus || existing?.subscriptionStatus || "ACTIVE",
            credits: Number(n.credits ?? existing?.credits ?? 60),
            smsCredits: Number(n.smsCredits ?? existing?.smsCredits ?? 0),
            status: n.status || existing?.status || "ACTIVE",
            createdAt: n.createdAt || existing?.createdAt || null,
            sortKey: n.sortKey || n.createdAt || existing?.sortKey || "2024-01-01T00:00:00.000Z",
            lastActiveAt: n.lastActiveAt || n.lastLoginAt || existing?.lastActiveAt || null,
            cropsCount: n.cropsCount ?? existing?.cropsCount ?? 0,
            livestockCount: n.livestockCount ?? existing?.livestockCount ?? 0,
            invoicesCount: n.invoicesCount ?? existing?.invoicesCount ?? 0,
            backupsCount: n.backupsCount ?? existing?.backupsCount ?? 0,
            lastBackupDate: n.lastBackupDate || existing?.lastBackupDate || null,
            lastBackupType: n.lastBackupType || existing?.lastBackupType || null
          };

          combinedMap.set(rec.uid, rec);
          if (email) combinedMap.set(email, rec);
        });
      }
    }
  } catch (_) {}

  // 6. Exclude deleted farm nodes with timeout protection
  const deletedTracker = await withTimeout(getDeletedFarmNodesTracker(), 1500, []);
  const deletedEmails = new Set(deletedTracker.map(d => (d.email || "").toLowerCase()));
  const deletedUids = new Set(deletedTracker.map(d => d.tenantId || d.id));

  // HARD GUARANTEE: Never exclude Super Admin or canonical seeds from deleted tracker
  deletedEmails.delete("support@mabala.cloud");
  deletedUids.delete("icIoBG4eN5VOw2BvhNiFUnUqmsX2");
  deletedEmails.delete("deepvaleyfarm@gmail.com");
  deletedUids.delete("TENANT_DEEP_VALLEY_FARM");

  // Deduplicate and filter
  const uniqueRecordsMap = new Map<string, TenantNodeRecord>();
  for (const node of combinedMap.values()) {
    const email = (node.tenantEmail || node.email || "").toLowerCase();
    const uid = node.tenantUid || node.uid || node.id;

    // Preserve support@mabala.cloud unconditionally
    if (email === "support@mabala.cloud" || uid === "icIoBG4eN5VOw2BvhNiFUnUqmsX2") {
      uniqueRecordsMap.set("icIoBG4eN5VOw2BvhNiFUnUqmsX2", node);
      continue;
    }

    if (deletedEmails.has(email) || deletedUids.has(uid) || node.status === "deleted" || node.status === "purged" || node.isDeleted) {
      continue;
    }

    // Key primarily on UID or email
    const dedupKey = uid || email;
    if (!uniqueRecordsMap.has(dedupKey)) {
      uniqueRecordsMap.set(dedupKey, node);
    }
  }

  // Unconditionally guarantee support@mabala.cloud is present in active farm nodes and directory
  const saEmail = "support@mabala.cloud";
  const hasSuperAdmin = Array.from(uniqueRecordsMap.values()).some(n => (n.email || n.tenantEmail || "").toLowerCase() === saEmail);
  if (!hasSuperAdmin) {
    uniqueRecordsMap.set("icIoBG4eN5VOw2BvhNiFUnUqmsX2", {
      id: "icIoBG4eN5VOw2BvhNiFUnUqmsX2",
      uid: "icIoBG4eN5VOw2BvhNiFUnUqmsX2",
      tenantUid: "icIoBG4eN5VOw2BvhNiFUnUqmsX2",
      tenantId: "icIoBG4eN5VOw2BvhNiFUnUqmsX2",
      name: "Mabala Super Admin",
      displayName: "Mabala Super Admin",
      ownerName: "Mabala Cloud Operations",
      farmName: "Mabala Cloud Platform Hub",
      farm: { name: "Mabala Cloud Platform Hub", province: "Lusaka Province", district: "Lusaka Central" },
      farms: [{ name: "Mabala Cloud Platform Hub", province: "Lusaka Province", district: "Lusaka Central" }],
      type: "Super Admin",
      role: "Super Admin",
      accountType: "Super Admin",
      email: saEmail,
      tenantEmail: saEmail,
      ownerEmail: saEmail,
      phone: "+260978070734",
      tenantPhone: "+260978070734",
      ownerPhone: "+260978070734",
      province: "Lusaka Province",
      district: "Lusaka Central",
      town: "Lusaka",
      location: "Lusaka, Zambia",
      tier: "Super Admin Core",
      subscriptionTier: "Super Admin Core",
      subscriptionPackage: "Super Admin Core",
      subscriptionStatus: "ACTIVE",
      credits: 10000,
      smsCredits: 5000,
      status: "ACTIVE",
      createdAt: "2024-01-01T00:00:00.000Z",
      sortKey: "2024-01-01T00:00:00.000Z",
      lastActiveAt: new Date().toISOString(),
      cropsCount: 5,
      livestockCount: 5,
      invoicesCount: 10
    });
  }

  // Unconditionally guarantee Deep Valley Farm is present in active farm nodes
  const dvEmail = "deepvaleyfarm@gmail.com";
  const hasDeepValley = Array.from(uniqueRecordsMap.values()).some(n => (n.email || n.tenantEmail || "").toLowerCase() === dvEmail);
  if (!hasDeepValley && !deletedEmails.has(dvEmail) && !deletedUids.has("TENANT_DEEP_VALLEY_FARM")) {
    uniqueRecordsMap.set("TENANT_DEEP_VALLEY_FARM", {
      id: "TENANT_DEEP_VALLEY_FARM",
      uid: "TENANT_DEEP_VALLEY_FARM",
      tenantUid: "TENANT_DEEP_VALLEY_FARM",
      tenantId: "TENANT_DEEP_VALLEY_FARM",
      name: "Deep Valley Farm Operations",
      displayName: "Deep Valley Farm Operations",
      ownerName: "Deep Valley Farm Operations",
      farmName: "Deep Valley Farms",
      farm: { name: "Deep Valley Farms", province: "Central Province", district: "Chibombo" },
      farms: [{ name: "Deep Valley Farms", province: "Central Province", district: "Chibombo" }],
      type: "Farmer",
      role: "Farm Owner",
      accountType: "Farm Owner",
      email: dvEmail,
      tenantEmail: dvEmail,
      ownerEmail: dvEmail,
      phone: "+260 97 7000000",
      tenantPhone: "+260 97 7000000",
      ownerPhone: "+260 97 7000000",
      province: "Central Province",
      district: "Chibombo",
      town: "Chibombo",
      location: "Chibombo, Central Province",
      tier: "Commercial Growth Layer",
      subscriptionTier: "Commercial Growth Layer",
      subscriptionPackage: "Commercial Growth Layer",
      subscriptionStatus: "ACTIVE",
      credits: 100,
      smsCredits: 100,
      status: "ACTIVE",
      createdAt: "2024-01-15T08:00:00.000Z",
      sortKey: "2024-01-15T08:00:00.000Z",
      lastActiveAt: new Date().toISOString(),
      cropsCount: 4,
      livestockCount: 85,
      invoicesCount: 12,
      backupsCount: 1,
      lastBackupDate: new Date().toISOString(),
      lastBackupType: "auto"
    });
  }

  const finalResult = Array.from(uniqueRecordsMap.values());
  cachedTenantNodes = finalResult;
  lastCacheTimestamp = Date.now();
  return finalResult;
}

/**
 * Searches farm nodes and users with debounced real-time auto-fetch support across Active and Inactive nodes.
 */
export async function searchFarmNodesAndUsers(query: string, options?: {
  status?: string;
  limit?: number;
  adminEmail?: string;
  adminUid?: string;
  authToken?: string;
}): Promise<TenantNodeRecord[]> {
  const q = (query || "").trim().toLowerCase();
  const status = options?.status || "ALL";
  const limit = options?.limit || 50;

  // 1. Try server-side real-time auto-fetch endpoint
  try {
    const adminEmail = options?.adminEmail || "support@mabala.cloud";
    const adminUid = options?.adminUid || "icIoBG4eN5VOw2BvhNiFUnUqmsX2";
    const params = new URLSearchParams({
      q,
      status,
      limit: String(limit)
    });

    const res = await fetch(`/api/admin/farm-nodes/search?${params.toString()}`, {
      headers: {
        "Content-Type": "application/json",
        "x-mabala-super-email": adminEmail,
        "x-mabala-super-uid": adminUid,
        ...(options?.authToken ? { Authorization: `Bearer ${options.authToken}` } : {})
      }
    });

    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.nodes) && data.nodes.length > 0) {
        return data.nodes;
      }
    }
  } catch (err) {
    console.warn("[tenantRegistryService] Search endpoint fallback:", err);
  }

  // 2. Client-side fallback: fetch all nodes and filter across active and inactive
  const allNodes = await fetchAllActiveTenantNodes();
  if (!q) return allNodes.slice(0, limit);

  return allNodes.filter(n => {
    const fn = (n.farmName || "").toLowerCase();
    const dn = (n.displayName || n.name || "").toLowerCase();
    const em = (n.email || n.tenantEmail || "").toLowerCase();
    const ph = (n.phone || n.tenantPhone || "").toLowerCase();
    const uid = (n.tenantUid || n.uid || n.id || "").toLowerCase();
    const prov = (n.province || "").toLowerCase();
    const dist = (n.district || "").toLowerCase();
    const rol = (n.role || n.accountType || "").toLowerCase();

    const matchesStatus = status === "ALL" || (n.status || "ACTIVE").toUpperCase() === status.toUpperCase();

    return matchesStatus && (
      fn.includes(q) ||
      dn.includes(q) ||
      em.includes(q) ||
      ph.includes(q) ||
      uid.includes(q) ||
      prov.includes(q) ||
      dist.includes(q) ||
      rol.includes(q)
    );
  }).slice(0, limit);
}

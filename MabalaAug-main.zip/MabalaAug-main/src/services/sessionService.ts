// Service for Single-Active-Session enforcement, session epoch tracking, persistent device fingerprinting & zombie write prevention
import { doc, onSnapshot, setDoc, updateDoc, collection } from "firebase/firestore";
import { db, auth } from "../firebase";

export interface SessionTerminationInfo {
  reason: "REMOTE_LOGIN" | "EXPIRED" | "REVOKED";
  newDeviceId?: string;
  newSessionId?: string;
  timestamp?: any;
  deviceInfo?: string;
  deviceName?: string;
  name?: string;
  device?: {
    id?: string;
    name?: string;
    info?: string;
  };
}

export interface RejectedWriteRecord {
  id: string;
  uid: string;
  tenantId?: string;
  sessionId: string;
  module: string;
  collectionName: string;
  documentId: string;
  action: "create" | "update" | "delete";
  payload: any;
  summaryLabel?: string;
  amount?: number;
  currencySymbol?: string;
  isFinancial: boolean;
  rejectedAt: string;
  rejectionReason: string;
  status: "pending_review" | "resubmitted" | "discarded";
  resolvedAt?: string;
}

const DEVICE_VAULT_DB = "mabala_device_vault";
const DEVICE_STORE = "device_identity";
const PERSISTENT_STORAGE_KEY = "mabala_device_identity_v2";
const LEGACY_STORAGE_KEY = "mabala_device_id";

/**
 * Native IndexedDB helper to guarantee durable persistence across tabs,
 * browser restarts, iframe boundaries, and privacy cleaners.
 */
function readFromIndexedDb(key: string): Promise<string | null> {
  if (typeof indexedDB === "undefined") return Promise.resolve(null);
  return new Promise((resolve) => {
    try {
      const request = indexedDB.open(DEVICE_VAULT_DB, 1);
      request.onupgradeneeded = () => {
        try {
          const idb = request.result;
          if (!idb.objectStoreNames.contains(DEVICE_STORE)) {
            idb.createObjectStore(DEVICE_STORE);
          }
        } catch (_) {}
      };
      request.onsuccess = () => {
        try {
          const idb = request.result;
          if (!idb.objectStoreNames.contains(DEVICE_STORE)) {
            resolve(null);
            return;
          }
          const tx = idb.transaction(DEVICE_STORE, "readonly");
          const store = tx.objectStore(DEVICE_STORE);
          const getReq = store.get(key);
          getReq.onsuccess = () => resolve((getReq.result as string) || null);
          getReq.onerror = () => resolve(null);
        } catch {
          resolve(null);
        }
      };
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function writeToIndexedDb(key: string, value: string): Promise<void> {
  if (typeof indexedDB === "undefined") return Promise.resolve();
  return new Promise((resolve) => {
    try {
      const request = indexedDB.open(DEVICE_VAULT_DB, 1);
      request.onupgradeneeded = () => {
        try {
          const idb = request.result;
          if (!idb.objectStoreNames.contains(DEVICE_STORE)) {
            idb.createObjectStore(DEVICE_STORE);
          }
        } catch (_) {}
      };
      request.onsuccess = () => {
        try {
          const idb = request.result;
          if (!idb.objectStoreNames.contains(DEVICE_STORE)) {
            resolve();
            return;
          }
          const tx = idb.transaction(DEVICE_STORE, "readwrite");
          const store = tx.objectStore(DEVICE_STORE);
          store.put(value, key);
          tx.oncomplete = () => resolve();
          tx.onerror = () => resolve();
        } catch {
          resolve();
        }
      };
      request.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

function getCookie(name: string): string | null {
  if (typeof document === "undefined") return null;
  try {
    const match = document.cookie.match(new RegExp("(^|;\\s*)(" + name + ")=([^;]*)"));
    return match ? decodeURIComponent(match[3]) : null;
  } catch {
    return null;
  }
}

function setCookie(name: string, value: string, days = 3650): void {
  if (typeof document === "undefined") return;
  try {
    const date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    document.cookie = `${name}=${encodeURIComponent(value)}; expires=${date.toUTCString()}; path=/; SameSite=Lax`;
  } catch (_) {}
}

/**
 * Deterministic Environment Hardware & Browser Engine Fingerprint
 * Produces a stable hash based on hardware configuration and rendering engine.
 * Ensures the same physical device/browser produces matching identities even if storage is cleared.
 */
function computeHardwareFingerprint(): string {
  if (typeof window === "undefined") return "server";
  try {
    const nav = window.navigator;
    const screen = window.screen;
    const parts: string[] = [
      nav?.userAgent || "",
      nav?.platform || "",
      nav?.language || (nav as any)?.userLanguage || "",
      String(nav?.hardwareConcurrency || 4),
      String(screen?.width || 0),
      String(screen?.height || 0),
      String(screen?.colorDepth || 24),
      Intl?.DateTimeFormat ? (Intl.DateTimeFormat().resolvedOptions()?.timeZone || "") : ""
    ];

    // Offscreen Canvas render signature
    try {
      const canvas = document.createElement("canvas");
      canvas.width = 160;
      canvas.height = 36;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.fillStyle = "#0B1528";
        ctx.fillRect(0, 0, 160, 36);
        ctx.fillStyle = "#10B981";
        ctx.font = "14px monospace";
        ctx.fillText("MABALA_CORE_NODE", 4, 22);
        const dataUrl = canvas.toDataURL();
        parts.push(dataUrl.slice(-48));
      }
    } catch (_) {}

    const str = parts.join("::");
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    const hash = (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
    return `fp_${hash}`;
  } catch (_) {
    return `fp_node_${Math.abs(Date.now() % 100000).toString(36)}`;
  }
}

class SessionService {
  private currentSessionId: string | null = null;
  private deviceId: string = "";
  private hardwareFingerprint: string = "";
  private sessionUnsubscribe: (() => void) | null = null;
  private terminationCallback: ((info: SessionTerminationInfo) => void) | null = null;
  private isTerminated: boolean = false;

  constructor() {
    this.hardwareFingerprint = computeHardwareFingerprint();
    this.deviceId = this.resolveSynchronousDeviceId();

    // Asynchronously verify and hydrate across persistent storage tiers (IndexedDB, Storage Manager)
    if (typeof window !== "undefined") {
      this.hydratePersistentVault();
    }

    // Re-hydrate session from sessionStorage or localStorage if within same browser
    if (typeof window !== "undefined") {
      try {
        const stored = sessionStorage.getItem("mabala_active_session_id") || localStorage.getItem("mabala_active_session_id");
        if (stored) {
          this.currentSessionId = stored;
        }
      } catch (_) {}
    }
  }

  private resolveSynchronousDeviceId(): string {
    if (typeof window === "undefined") return "server_device";
    try {
      // 1. Check primary persistent key in localStorage
      let id = localStorage.getItem(PERSISTENT_STORAGE_KEY);

      // 2. Check legacy key in localStorage
      if (!id) {
        id = localStorage.getItem(LEGACY_STORAGE_KEY);
      }

      // 3. Check persistent cookie
      if (!id) {
        id = getCookie(PERSISTENT_STORAGE_KEY) || getCookie(LEGACY_STORAGE_KEY);
      }

      // 4. Deterministic fallback seeded by persistent hardware fingerprint
      if (!id) {
        id = `dev_${this.hardwareFingerprint}_node`;
      }

      // Cache consistently in all synchronous tiers
      try {
        localStorage.setItem(PERSISTENT_STORAGE_KEY, id);
        localStorage.setItem(LEGACY_STORAGE_KEY, id);
        setCookie(PERSISTENT_STORAGE_KEY, id);
        setCookie(LEGACY_STORAGE_KEY, id);
      } catch (_) {}

      return id;
    } catch (_) {
      return `dev_${this.hardwareFingerprint}_node`;
    }
  }

  private async hydratePersistentVault(): Promise<void> {
    try {
      // Request durable browser persistence permission
      if (typeof navigator !== "undefined" && navigator.storage && navigator.storage.persist) {
        navigator.storage.persist().catch(() => {});
      }

      // Check IndexedDB
      const idbId = await readFromIndexedDb(PERSISTENT_STORAGE_KEY);
      if (idbId && idbId.trim()) {
        if (idbId !== this.deviceId) {
          this.deviceId = idbId;
          try {
            localStorage.setItem(PERSISTENT_STORAGE_KEY, idbId);
            localStorage.setItem(LEGACY_STORAGE_KEY, idbId);
            setCookie(PERSISTENT_STORAGE_KEY, idbId);
          } catch (_) {}
        }
      } else {
        // Seed IndexedDB with current deviceId
        await writeToIndexedDb(PERSISTENT_STORAGE_KEY, this.deviceId);
      }
    } catch (e) {
      console.warn("[SessionService] Persistent vault hydration note:", e);
    }
  }

  /**
   * Evaluates whether a remote device identifier belongs to the current browser/device.
   * Compares exact IDs, hardware fingerprint markers, and persistent vault records.
   */
  public isSameDevice(remoteDeviceId?: string): boolean {
    if (!remoteDeviceId) return false;

    // Exact match
    if (remoteDeviceId === this.deviceId) return true;

    // Check if remote device ID shares the exact same hardware fingerprint
    if (this.hardwareFingerprint && remoteDeviceId.includes(this.hardwareFingerprint)) {
      return true;
    }

    // Check storage aliases
    try {
      const storedPrimary = localStorage.getItem(PERSISTENT_STORAGE_KEY);
      const storedLegacy = localStorage.getItem(LEGACY_STORAGE_KEY);
      if (remoteDeviceId === storedPrimary || remoteDeviceId === storedLegacy) {
        return true;
      }
    } catch (_) {}

    return false;
  }

  public getDeviceId(): string {
    return this.deviceId;
  }

  public getSessionId(): string | null {
    return this.currentSessionId;
  }

  public setSessionId(id: string): void {
    this.currentSessionId = id;
    this.isTerminated = false;
    if (typeof window !== "undefined") {
      try {
        sessionStorage.setItem("mabala_active_session_id", id);
        localStorage.setItem("mabala_active_session_id", id);
      } catch (_) {}
    }
  }

  public isSessionTerminated(): boolean {
    return this.isTerminated;
  }

  /**
   * Claims a new active session for this user.
   * Invokes server endpoint /api/auth/claim-session which creates the session doc,
   * revokes old tokens, and sets claims.
   */
  public async claimSession(uid: string, idToken?: string): Promise<string> {
    if (!uid) throw new Error("UID is required to claim a session.");
    this.isTerminated = false;

    let token = idToken;
    if (!token && auth.currentUser) {
      try {
        token = await auth.currentUser.getIdToken(false);
      } catch (_) {}
    }

    const deviceName = typeof navigator !== "undefined"
      ? (navigator.platform ? `${navigator.platform} Browser` : "Web Browser")
      : "Desktop Terminal";

    try {
      const response = await fetch("/api/auth/claim-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          uid,
          deviceId: this.deviceId,
          deviceInfo: typeof navigator !== "undefined" ? navigator.userAgent : "Desktop Browser",
          deviceName
        })
      });

      if (response.ok) {
        const data = await response.json();
        const newSessionId = data?.sessionId || data?.activeSessionId;
        if (newSessionId) {
          this.setSessionId(newSessionId);
          return newSessionId;
        }
      } else {
        console.warn("[SessionService] Server claim-session returned status:", response.status);
      }
    } catch (err: any) {
      console.warn("[SessionService] Failed to claim session via server API, utilizing direct fallback:", err?.message);
    }

    // Direct Firestore fallback in case network proxy is offline
    const fallbackSessionId = "sess_" + Math.random().toString(36).substring(2, 10) + "_" + Date.now().toString(36);
    this.setSessionId(fallbackSessionId);

    try {
      if (db && !(db as any)._dummy) {
        const sessionRef = doc(db, "sessions", uid);
        await setDoc(sessionRef, {
          activeSessionId: fallbackSessionId,
          deviceId: this.deviceId,
          deviceInfo: typeof navigator !== "undefined" ? navigator.userAgent : "Desktop Browser",
          deviceName,
          loginAt: new Date().toISOString(),
          lastSeenAt: new Date().toISOString()
        }, { merge: true });
      }
    } catch (e: any) {
      console.warn("[SessionService] Direct session write fallback note:", e?.message);
    }

    return fallbackSessionId;
  }

  /**
   * Starts a real-time listener on sessions/{uid}.
   * Triggers termination callback when activeSessionId changes to another device's session.
   * Accurately distinguishes between the same device (which should NOT be displaced)
   * and a genuinely different device (which triggers strict single-active-session takeover).
   */
  public startSessionListener(uid: string, onTerminated: (info: SessionTerminationInfo) => void): () => void {
    this.stopSessionListener();
    this.terminationCallback = onTerminated;

    if (!uid || !db || (db as any)._dummy) {
      return () => {};
    }

    try {
      const sessionDocRef = doc(db, "sessions", uid);
      this.sessionUnsubscribe = onSnapshot(sessionDocRef, { includeMetadataChanges: true }, (snapshot) => {
        if (!snapshot?.exists?.()) return;
        const data = snapshot?.data?.();
        if (!data) return;

        const remoteActiveSessionId = data?.activeSessionId;
        const remoteDeviceId = data?.deviceId;
        const remoteDeviceName = data?.deviceName || data?.device?.name || data?.name || data?.deviceInfo || "Remote Device";

        if (!remoteActiveSessionId) return;

        // CASE 1: Same Device / Browser Profile
        // If the session record was updated by this same device or matching hardware fingerprint
        // (e.g. login, page refresh, token renewal, or another tab in the same browser),
        // this is NOT a remote device takeover.
        if (this.isSameDevice(remoteDeviceId)) {
          if (this.currentSessionId !== remoteActiveSessionId) {
            console.log(`[SessionService] Synchronized active session ID for local device ${this.deviceId}: ${remoteActiveSessionId}`);
            this.setSessionId(remoteActiveSessionId);
          }
          this.isTerminated = false;
          return;
        }

        // CASE 2: Genuine Multi-Device Takeover
        // A DIFFERENT physical device with a different device ID & fingerprint claimed the active session.
        // Enforce the strict single-active-session policy by displacing this session and guarding against zombie writes.
        if (
          remoteDeviceId &&
          !this.isSameDevice(remoteDeviceId) &&
          this.currentSessionId &&
          remoteActiveSessionId !== this.currentSessionId
        ) {
          console.warn(`[SessionService] Genuine remote takeover detected! Local Device: ${this.deviceId}, Remote Device: ${remoteDeviceId}. Current Session: ${this.currentSessionId}, New Remote Session: ${remoteActiveSessionId}`);
          this.isTerminated = true;
          if (this.terminationCallback) {
            this.terminationCallback({
              reason: "REMOTE_LOGIN",
              newDeviceId: remoteDeviceId,
              newSessionId: remoteActiveSessionId,
              timestamp: data?.loginAt || data?.timestamp || new Date().toISOString(),
              deviceInfo: data?.deviceInfo || "Remote Browser",
              deviceName: remoteDeviceName,
              name: remoteDeviceName,
              device: {
                id: remoteDeviceId,
                name: remoteDeviceName,
                info: data?.deviceInfo
              }
            });
          }
        }
      }, (err) => {
        console.warn("[SessionService] Session listener warning:", err?.message);
      });
    } catch (e: any) {
      console.warn("[SessionService] Failed to establish session snapshot:", e?.message);
    }

    return () => this.stopSessionListener();
  }

  public stopSessionListener(): void {
    if (this.sessionUnsubscribe) {
      this.sessionUnsubscribe();
      this.sessionUnsubscribe = null;
    }
    this.terminationCallback = null;
  }

  /**
   * Records a rejected write for user reconciliation.
   */
  public async recordRejectedWrite(uid: string, record: Omit<RejectedWriteRecord, "status" | "rejectedAt">): Promise<void> {
    if (!uid || !record || !db || (db as any)._dummy) return;
    try {
      const writeId = record.id || ("rej_" + Date.now() + "_" + Math.random().toString(36).substring(2, 8));
      const writeRef = doc(db, "rejected_writes", uid, "writes", writeId);
      const payload: RejectedWriteRecord = {
        ...record,
        id: writeId,
        status: "pending_review",
        rejectedAt: new Date().toISOString()
      };
      await setDoc(writeRef, payload, { merge: true });
    } catch (e: any) {
      console.warn("[SessionService] Failed to record rejected write in Firestore:", e?.message);
    }
  }

  /**
   * Subscribes to pending rejected writes for reconciliation UI.
   */
  public subscribeRejectedWrites(
    uid: string,
    onData: (records: RejectedWriteRecord[]) => void,
    onError?: (err: any) => void
  ): () => void {
    if (!uid || !db || (db as any)._dummy) {
      onData([]);
      return () => {};
    }

    try {
      const q = collection(db, "rejected_writes", uid, "writes");
      return onSnapshot(q, { includeMetadataChanges: true }, (snapshot) => {
        const list: RejectedWriteRecord[] = [];
        snapshot?.forEach?.((d) => {
          const item = d?.data?.() as RejectedWriteRecord;
          if (item?.status === "pending_review") {
            list.push({ ...item, id: d.id });
          }
        });
        onData(list);
      }, (err) => {
        console.warn("[SessionService] Failed to subscribe to rejected writes:", err?.message);
        if (onError) onError(err);
      });
    } catch (e: any) {
      console.warn("[SessionService] subscribeRejectedWrites error:", e?.message);
      onData([]);
      return () => {};
    }
  }

  /**
   * Marks a rejected write as discarded.
   */
  public async discardRejectedWrite(uid: string, writeId: string): Promise<void> {
    if (!uid || !db || (db as any)._dummy || !writeId) return;
    try {
      const writeRef = doc(db, "rejected_writes", uid, "writes", writeId);
      await updateDoc(writeRef, {
        status: "discarded",
        resolvedAt: new Date().toISOString()
      });
    } catch (e: any) {
      console.warn("[SessionService] Failed to discard rejected write:", e?.message);
    }
  }

  /**
   * Marks a rejected write as resubmitted.
   */
  public async markWriteResubmitted(uid: string, writeId: string): Promise<void> {
    if (!uid || !db || (db as any)._dummy || !writeId) return;
    try {
      const writeRef = doc(db, "rejected_writes", uid, "writes", writeId);
      await updateDoc(writeRef, {
        status: "resubmitted",
        resolvedAt: new Date().toISOString()
      });
    } catch (e: any) {
      console.warn("[SessionService] Failed to mark write resubmitted:", e?.message);
    }
  }

  /**
   * Discards all pending rejected writes.
   */
  public async discardAllRejectedWrites(uid: string, writeIds: string[]): Promise<void> {
    if (!Array.isArray(writeIds)) return;
    await Promise.all(writeIds.map(id => this.discardRejectedWrite(uid, id)));
  }

  public clearSession(): void {
    this.currentSessionId = null;
    this.isTerminated = false;
    this.stopSessionListener();
    if (typeof window !== "undefined") {
      try {
        sessionStorage.removeItem("mabala_active_session_id");
        localStorage.removeItem("mabala_active_session_id");
      } catch (_) {}
    }
  }
}

export const sessionService = new SessionService();

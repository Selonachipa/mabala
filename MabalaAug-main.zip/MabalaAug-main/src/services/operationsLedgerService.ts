import { db } from "../firebase";
import { doc, setDoc, getDoc, collection, getDocs } from "firebase/firestore";
import { safeLocalStorage as localStorage } from "../utils/safeStorage";

export interface OperationsLedgerTransaction {
  id: string;
  referenceId: string;
  sourceTenantId: string;
  sourceFarmName: string;
  sourceUserEmail?: string;
  category: "platform_credits" | "subscription" | "sms_topup" | "payroll_fee" | "payroll_disbursement" | "vendor_commission" | "cart_checkout" | "platform_collection_fee" | "invoice_settlement" | "ddacc_fee" | "other";
  categoryLabel: string;
  amount: number;
  narration: string;
  createdAt: string;
  metadata?: Record<string, any>;
}

const STORAGE_KEY_OPERATIONS_TXS = "mabala_superadmin_operations_ledger_txs";
const STORAGE_KEY_OPERATIONS_BAL = "mabala_superadmin_operations_ledger_balance";
export const SUPER_ADMIN_EMAIL = "support@mabala.cloud";
export const SUPER_ADMIN_TENANT_ID = "TENANT-SUPER-ADMIN";

// Get all Operations Ledger transactions
export function getOperationsLedgerTransactions(): OperationsLedgerTransaction[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_OPERATIONS_TXS);
    if (raw) {
      const list = JSON.parse(raw);
      if (Array.isArray(list)) {
        return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
    }
  } catch (e) {
    console.warn("[OperationsLedger] Error reading transactions:", e);
  }
  return [];
}

// Compute balance directly from itemized transactions
export function getOperationsLedgerBalance(): number {
  try {
    const txs = getOperationsLedgerTransactions();
    const sum = txs.reduce((acc, t) => acc + (Number(t.amount) || 0), 0);
    const balance = Number(sum.toFixed(2));
    localStorage.setItem(STORAGE_KEY_OPERATIONS_BAL, balance.toString());
    return balance;
  } catch (e) {
    const stored = localStorage.getItem(STORAGE_KEY_OPERATIONS_BAL);
    return stored ? parseFloat(stored) || 0 : 0;
  }
}

// Subscribe to Operations Ledger updates
export function subscribeOperationsLedger(
  callback: (balance: number, txs: OperationsLedgerTransaction[]) => void
): () => void {
  const handler = () => {
    const txs = getOperationsLedgerTransactions();
    const balance = getOperationsLedgerBalance();
    callback(balance, txs);
  };

  window.addEventListener("mabala_operations_ledger_update", handler);
  window.addEventListener("storage", handler);

  // Initial callback
  handler();

  return () => {
    window.removeEventListener("mabala_operations_ledger_update", handler);
    window.removeEventListener("storage", handler);
  };
}

const categoryLabelsMap: Record<OperationsLedgerTransaction["category"], string> = {
  platform_credits: "Platform Credits Purchase",
  subscription: "Farm Subscription / Tier Renewal",
  sms_topup: "SMS Credits Top-Up",
  payroll_fee: "Payroll Platform Fee",
  payroll_disbursement: "Payroll Batch Inflow",
  vendor_commission: "Marketplace Commission",
  cart_checkout: "Vendor Portal Checkout Fee",
  platform_collection_fee: "Platform Payment Collection Fee",
  invoice_settlement: "Super Admin Platform Invoice Payment",
  ddacc_fee: "DDACC Auto-Clearing Platform Fee",
  other: "Operations Payment"
};

// Credit the Super Admin Operations Ledger
export async function creditOperationsLedger(params: {
  sourceTenantId: string;
  sourceFarmName?: string;
  sourceUserEmail?: string;
  category: OperationsLedgerTransaction["category"];
  amount: number;
  referenceId?: string;
  narration: string;
  metadata?: Record<string, any>;
}): Promise<{ success: boolean; tx: OperationsLedgerTransaction; newBalance: number }> {
  const amount = Number(params.amount) || 0;
  if (amount <= 0) {
    return {
      success: false,
      tx: {} as any,
      newBalance: getOperationsLedgerBalance()
    };
  }

  const refId = params.referenceId || `OP-TX-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const tx: OperationsLedgerTransaction = {
    id: refId,
    referenceId: refId,
    sourceTenantId: params.sourceTenantId || "TENANT-001",
    sourceFarmName: params.sourceFarmName || "Mabala Farm Node",
    sourceUserEmail: params.sourceUserEmail || "",
    category: params.category,
    categoryLabel: categoryLabelsMap[params.category] || "Operations Inflow",
    amount: Number(amount.toFixed(2)),
    narration: params.narration,
    createdAt: new Date().toISOString(),
    metadata: params.metadata || {}
  };

  try {
    const existing = getOperationsLedgerTransactions();
    const updated = [tx, ...existing.filter(t => t.id !== tx.id && t.referenceId !== tx.referenceId)];
    localStorage.setItem(STORAGE_KEY_OPERATIONS_TXS, JSON.stringify(updated));
    const newBal = getOperationsLedgerBalance();

    if (db) {
      try {
        await setDoc(doc(db, "superAdmin", "operationsLedger", "records", tx.id), tx);
        await setDoc(doc(db, "superAdmin", "operationsLedger"), {
          currentBalance: newBal,
          updatedAt: new Date().toISOString(),
          adminEmail: SUPER_ADMIN_EMAIL
        }, { merge: true });
      } catch (err) {
        console.warn("[OperationsLedger] Firestore sync note:", err);
      }
    }

    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("mabala_operations_ledger_update", { detail: { newBalance: newBal, tx } }));
      window.dispatchEvent(new Event("storage"));
    }

    return {
      success: true,
      tx,
      newBalance: newBal
    };
  } catch (err: any) {
    console.error("[OperationsLedger] Error crediting ledger:", err);
    throw err;
  }
}

import { 
  HarvestEvent, 
  Warehouse, 
  StorageLot, 
  WarehouseReceipt, 
  StorageLoss, 
  CropCycleVariance,
  CropCycle,
  CashSale,
  Invoice,
  PledgeRecord
} from "../types";
import { safeLocalStorage } from "../utils/safeStorage";

const STORAGE_KEYS = {
  HARVEST_EVENTS: "mabala_hsw_harvest_events",
  WAREHOUSES: "mabala_hsw_warehouses",
  STORAGE_LOTS: "mabala_hsw_storage_lots",
  WAREHOUSE_RECEIPTS: "mabala_hsw_receipts",
  STORAGE_LOSSES: "mabala_hsw_storage_losses",
  VARIANCE_RECORDS: "mabala_hsw_variances",
  TAXONOMY_LOSS_CAUSES: "mabala_hsw_loss_causes",
  CONFIG_MIN_COHORT_SIZE: "mabala_hsw_min_cohort_size",
  PLEDGED_RECORDS: "mabala_hsw_pledged_records"
};

// Initial default warehouses (empty for new tenants)
const DEFAULT_WAREHOUSES: Warehouse[] = [];

// Initial default storage lots (empty for new tenants)
const DEFAULT_STORAGE_LOTS: StorageLot[] = [];

// Initial default receipts (empty for new tenants)
const DEFAULT_RECEIPTS: WarehouseReceipt[] = [];

const DEFAULT_PLEDGED_RECORDS: PledgeRecord[] = [];

export class HswService {
  // Pledged Records Loaders & Savers
  static getPledgedRecords(tenantId?: string, farmNodeId?: string): PledgeRecord[] {
    const raw = safeLocalStorage.getItem(STORAGE_KEYS.PLEDGED_RECORDS);
    if (!raw) return DEFAULT_PLEDGED_RECORDS;
    try {
      const parsed: PledgeRecord[] = JSON.parse(raw);
      if (!Array.isArray(parsed)) return DEFAULT_PLEDGED_RECORDS;
      if (!tenantId && !farmNodeId) return parsed;
      return parsed.filter(p => {
        if (tenantId && (p as any).tenantId && (p as any).tenantId !== tenantId) return false;
        if (farmNodeId && (p as any).farmNodeId && (p as any).farmNodeId !== farmNodeId) return false;
        return true;
      });
    } catch {
      return DEFAULT_PLEDGED_RECORDS;
    }
  }

  static savePledgedRecords(records: PledgeRecord[]) {
    safeLocalStorage.setItem(STORAGE_KEYS.PLEDGED_RECORDS, JSON.stringify(records));
  }

  static addPledgeRecord(record: PledgeRecord) {
    const records = this.getPledgedRecords();
    records.unshift(record);
    this.savePledgedRecords(records);
  }

  static extendPledgeTenure(pledgeId: string, daysToAdd = 30): PledgeRecord | null {
    const records = this.getPledgedRecords();
    const idx = records.findIndex(r => r.id === pledgeId);
    if (idx === -1) return null;

    const record = records[idx];
    const currentMaturity = record.maturityDate ? new Date(record.maturityDate) : new Date();
    currentMaturity.setDate(currentMaturity.getDate() + daysToAdd);
    
    const updatedRecord: PledgeRecord = {
      ...record,
      tenureMonths: record.tenureMonths + Math.round(daysToAdd / 30),
      maturityDate: currentMaturity.toISOString().split("T")[0]
    };

    records[idx] = updatedRecord;
    this.savePledgedRecords(records);
    return updatedRecord;
  }

  static releasePledge(pledgeId: string): PledgeRecord | null {
    const records = this.getPledgedRecords();
    const idx = records.findIndex(r => r.id === pledgeId);
    if (idx === -1) return null;

    const updatedRecord: PledgeRecord = {
      ...records[idx],
      status: "released"
    };

    records[idx] = updatedRecord;
    this.savePledgedRecords(records);
    return updatedRecord;
  }

  static getDaysToMaturity(maturityDateStr: string): number {
    if (!maturityDateStr) return 999;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const target = new Date(maturityDateStr);
    target.setHours(0, 0, 0, 0);
    const diffMs = target.getTime() - today.getTime();
    return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  }

  static getNearMaturityPledges(thresholdDays = 30, tenantId?: string, farmNodeId?: string): PledgeRecord[] {
    const records = this.getPledgedRecords(tenantId, farmNodeId);
    return records.filter(p => {
      if (p.status !== "active_pledge") return false;
      const days = this.getDaysToMaturity(p.maturityDate);
      return days <= thresholdDays;
    });
  }

  // Loaders & Savers
  static getHarvestEvents(tenantId?: string, farmNodeId?: string): HarvestEvent[] {
    const raw = safeLocalStorage.getItem(STORAGE_KEYS.HARVEST_EVENTS);
    if (!raw) return [];
    try {
      const parsed: HarvestEvent[] = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      if (!tenantId && !farmNodeId) return parsed;
      return parsed.filter(e => {
        if (tenantId && e.tenantId && e.tenantId !== tenantId) return false;
        if (farmNodeId && e.farmNodeId && e.farmNodeId !== farmNodeId) return false;
        return true;
      });
    } catch {
      return [];
    }
  }

  static saveHarvestEvents(events: HarvestEvent[]) {
    safeLocalStorage.setItem(STORAGE_KEYS.HARVEST_EVENTS, JSON.stringify(events));
  }

  static getWarehouses(tenantId?: string): Warehouse[] {
    const raw = safeLocalStorage.getItem(STORAGE_KEYS.WAREHOUSES);
    if (!raw) return [];
    try {
      const parsed: Warehouse[] = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      if (!tenantId) return parsed;
      return parsed.filter(w => {
        if (w.ownerType === "certified_third_party") return true; // public / shared
        if ((w as any).tenantId && (w as any).tenantId !== tenantId) return false;
        return true;
      });
    } catch {
      return [];
    }
  }

  static saveWarehouses(warehouses: Warehouse[]) {
    safeLocalStorage.setItem(STORAGE_KEYS.WAREHOUSES, JSON.stringify(warehouses));
  }

  static getStorageLots(tenantId?: string, farmNodeId?: string): StorageLot[] {
    const raw = safeLocalStorage.getItem(STORAGE_KEYS.STORAGE_LOTS);
    if (!raw) return [];
    try {
      const parsed: StorageLot[] = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      if (!tenantId && !farmNodeId) return parsed;
      return parsed.filter(l => {
        if (tenantId && l.tenantId && l.tenantId !== tenantId) return false;
        if (farmNodeId && l.farmNodeId && l.farmNodeId !== farmNodeId) return false;
        return true;
      });
    } catch {
      return [];
    }
  }

  static saveStorageLots(lots: StorageLot[]) {
    safeLocalStorage.setItem(STORAGE_KEYS.STORAGE_LOTS, JSON.stringify(lots));
  }

  static getWarehouseReceipts(tenantId?: string, farmNodeId?: string): WarehouseReceipt[] {
    const raw = safeLocalStorage.getItem(STORAGE_KEYS.WAREHOUSE_RECEIPTS);
    if (!raw) return [];
    try {
      const parsed: WarehouseReceipt[] = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      if (!tenantId && !farmNodeId) return parsed;
      return parsed.filter(r => {
        if (tenantId && r.tenantId && r.tenantId !== tenantId) return false;
        if (farmNodeId && r.farmNodeId && r.farmNodeId !== farmNodeId) return false;
        return true;
      });
    } catch {
      return [];
    }
  }

  static saveWarehouseReceipts(receipts: WarehouseReceipt[]) {
    safeLocalStorage.setItem(STORAGE_KEYS.WAREHOUSE_RECEIPTS, JSON.stringify(receipts));
  }

  static getStorageLosses(tenantId?: string, farmNodeId?: string): StorageLoss[] {
    const raw = safeLocalStorage.getItem(STORAGE_KEYS.STORAGE_LOSSES);
    if (!raw) return [];
    try {
      const parsed: StorageLoss[] = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      if (!tenantId && !farmNodeId) return parsed;
      return parsed.filter(l => {
        if (tenantId && l.tenantId && l.tenantId !== tenantId) return false;
        return true;
      });
    } catch {
      return [];
    }
  }

  static saveStorageLosses(losses: StorageLoss[]) {
    safeLocalStorage.setItem(STORAGE_KEYS.STORAGE_LOSSES, JSON.stringify(losses));
  }

  static getVariances(tenantId?: string, farmNodeId?: string): CropCycleVariance[] {
    const raw = safeLocalStorage.getItem(STORAGE_KEYS.VARIANCE_RECORDS);
    if (!raw) return [];
    try {
      const parsed: CropCycleVariance[] = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      if (!tenantId && !farmNodeId) return parsed;
      return parsed.filter(v => {
        if (tenantId && v.tenantId && v.tenantId !== tenantId) return false;
        if (farmNodeId && v.farmNodeId && v.farmNodeId !== farmNodeId) return false;
        return true;
      });
    } catch {
      return [];
    }
  }

  static saveVariances(variances: CropCycleVariance[]) {
    safeLocalStorage.setItem(STORAGE_KEYS.VARIANCE_RECORDS, JSON.stringify(variances));
  }

  /**
   * Reset / zero-rate all HSW dummy data for a tenant / farm node
   */
  static clearTenantHswData(tenantId?: string, farmNodeId?: string) {
    if (!tenantId && !farmNodeId) {
      safeLocalStorage.removeItem(STORAGE_KEYS.HARVEST_EVENTS);
      safeLocalStorage.removeItem(STORAGE_KEYS.STORAGE_LOTS);
      safeLocalStorage.removeItem(STORAGE_KEYS.WAREHOUSE_RECEIPTS);
      safeLocalStorage.removeItem(STORAGE_KEYS.STORAGE_LOSSES);
      safeLocalStorage.removeItem(STORAGE_KEYS.VARIANCE_RECORDS);
      safeLocalStorage.removeItem(STORAGE_KEYS.PLEDGED_RECORDS);
      return;
    }

    const filterOut = (items: any[]) => items.filter(item => {
      if (tenantId && item.tenantId === tenantId) return false;
      if (farmNodeId && item.farmNodeId === farmNodeId) return false;
      return true;
    });

    this.saveHarvestEvents(filterOut(this.getHarvestEvents()));
    this.saveStorageLots(filterOut(this.getStorageLots()));
    this.saveWarehouseReceipts(filterOut(this.getWarehouseReceipts()));
    this.saveStorageLosses(filterOut(this.getStorageLosses()));
    this.saveVariances(filterOut(this.getVariances()));
    this.savePledgedRecords(filterOut(this.getPledgedRecords()));
  }

  static getMinCohortSize(): number {
    const val = safeLocalStorage.getItem(STORAGE_KEYS.CONFIG_MIN_COHORT_SIZE);
    return val ? parseInt(val, 10) : 5;
  }

  static setMinCohortSize(size: number) {
    safeLocalStorage.setItem(STORAGE_KEYS.CONFIG_MIN_COHORT_SIZE, size.toString());
  }

  static getLossCausesTaxonomy(): string[] {
    const raw = safeLocalStorage.getItem(STORAGE_KEYS.TAXONOMY_LOSS_CAUSES);
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch {}
    }
    return ["pest", "mould_moisture", "theft", "spillage_handling", "rodent", "quality_downgrade", "other"];
  }

  static saveLossCausesTaxonomy(causes: string[]) {
    safeLocalStorage.setItem(STORAGE_KEYS.TAXONOMY_LOSS_CAUSES, JSON.stringify(causes));
  }

  // CORE FUNCTIONS

  /**
   * Log Harvest Event
   */
  static logHarvestEvent(data: Omit<HarvestEvent, "id" | "createdAt" | "updatedAt">): HarvestEvent {
    const events = this.getHarvestEvents();
    const newEvent: HarvestEvent = {
      ...data,
      id: `harvest-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    events.unshift(newEvent);
    this.saveHarvestEvents(events);
    return newEvent;
  }

  /**
   * Confirm Harvest Event and option to move to storage
   */
  static confirmHarvestEvent(
    harvestId: string, 
    moveToStorage: boolean, 
    warehouseId?: string, 
    valuationPricePerUnit: number = 4200
  ): { harvest: HarvestEvent; lot?: StorageLot; receipt?: WarehouseReceipt } {
    const events = this.getHarvestEvents();
    const idx = events.findIndex(e => e.id === harvestId);
    if (idx === -1) throw new Error("Harvest event not found");

    const harvest = events[idx];
    harvest.status = "confirmed";
    harvest.updatedAt = new Date().toISOString();
    events[idx] = harvest;
    this.saveHarvestEvents(events);

    let createdLot: StorageLot | undefined;
    let createdReceipt: WarehouseReceipt | undefined;

    if (moveToStorage && warehouseId) {
      const res = this.createStorageLot({
        harvestEventIds: [harvest.id],
        warehouseId,
        cropType: harvest.cropType,
        variety: harvest.variety || "Standard Hybrid",
        grade: harvest.gradedBreakdown.length > 0 ? harvest.gradedBreakdown[0].grade : "Grade A",
        quantityIn: harvest.quantityRaw,
        unit: harvest.unitRaw,
        tenantId: harvest.tenantId,
        farmNodeId: harvest.farmNodeId,
        cropCycleId: harvest.cropCycleId,
        valuationPriceSource: "MPB",
        valuationPricePerUnit
      });
      createdLot = res.lot;
      createdReceipt = res.receipt;
    }

    return { harvest, lot: createdLot, receipt: createdReceipt };
  }

  /**
   * Create Storage Lot
   */
  static createStorageLot(params: {
    harvestEventIds: string[];
    warehouseId: string;
    cropType: string;
    variety: string;
    grade: string;
    quantityIn: number;
    unit: string;
    tenantId: string;
    farmNodeId: string;
    cropCycleId: string;
    valuationPriceSource?: "MPB" | "manual" | "contracted";
    valuationPricePerUnit?: number;
  }): { lot: StorageLot; receipt?: WarehouseReceipt } {
    const warehouses = this.getWarehouses();
    const wh = warehouses.find(w => w.id === params.warehouseId);
    if (!wh) throw new Error("Warehouse not found");

    const isCertified = wh.ownerType === "certified_third_party" && wh.certification.status === "certified";
    const initialStatus = isCertified ? "pending_intake" : "in_storage";
    const pricePerUnit = params.valuationPricePerUnit || 4200;
    const initialValue = params.quantityIn * pricePerUnit;

    const lotId = `lot-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const newLot: StorageLot = {
      id: lotId,
      farmNodeId: params.farmNodeId,
      tenantId: params.tenantId,
      cropCycleId: params.cropCycleId,
      harvestEventIds: params.harvestEventIds,
      warehouseId: params.warehouseId,
      cropType: params.cropType,
      variety: params.variety,
      grade: params.grade,
      quantityIn: params.quantityIn,
      quantityCurrent: params.quantityIn,
      unit: params.unit,
      valuationPriceSource: params.valuationPriceSource || "MPB",
      valuationPricePerUnit: pricePerUnit,
      valuationCurrency: "ZMW",
      storedValueAtIntake: initialValue,
      storedValueCurrent: initialValue,
      intakeDate: new Date().toISOString(),
      status: initialStatus,
      pledge: {
        pledgedTo: null,
        pledgeRef: null,
        pledgedQuantity: 0,
        pledgedAt: null,
        releasedAt: null
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const lots = this.getStorageLots();
    lots.unshift(newLot);
    this.saveStorageLots(lots);

    let receipt: WarehouseReceipt | undefined;

    // Auto-issue non-negotiable DWR if on-site farm storage
    if (wh.ownerType === "farm_on_site") {
      receipt = this.issueWarehouseReceipt(newLot, wh, false);
    }

    return { lot: newLot, receipt };
  }

  /**
   * Confirm Warehouse Intake (Certified Operator)
   */
  static confirmWarehouseIntake(
    lotId: string, 
    params: { finalQty: number; qualityGrade: string; operatorUid: string }
  ): { lot: StorageLot; receipt: WarehouseReceipt } {
    const lots = this.getStorageLots();
    const idx = lots.findIndex(l => l.id === lotId);
    if (idx === -1) throw new Error("Storage lot not found");

    const lot = lots[idx];
    const warehouses = this.getWarehouses();
    const wh = warehouses.find(w => w.id === lot.warehouseId);
    if (!wh) throw new Error("Warehouse not found");

    if (wh.certification.status !== "certified") {
      throw new Error("Cannot issue negotiable DWR: Warehouse certification is not active");
    }

    lot.quantityIn = params.finalQty;
    lot.quantityCurrent = params.finalQty;
    lot.grade = params.qualityGrade;
    lot.storedValueAtIntake = params.finalQty * lot.valuationPricePerUnit;
    lot.storedValueCurrent = params.finalQty * lot.valuationPricePerUnit;
    lot.status = "in_storage";
    lot.updatedAt = new Date().toISOString();

    lots[idx] = lot;
    this.saveStorageLots(lots);

    // Issue negotiable DWR
    const receipt = this.issueWarehouseReceipt(lot, wh, true);

    return { lot, receipt };
  }

  /**
   * Issue Warehouse Receipt (DWR)
   */
  private static issueWarehouseReceipt(
    lot: StorageLot, 
    wh: Warehouse, 
    negotiable: boolean
  ): WarehouseReceipt {
    const receipts = this.getWarehouseReceipts();
    const count = receipts.length + 101;
    const seqStr = count.toString().padStart(6, "0");
    const prefix = wh.district ? wh.district.substring(0, 3).toUpperCase() : "WH";
    const receiptNumber = `WH-${prefix}-${seqStr}`;
    const qrCode = `QR-MABALA-DWR-${Math.floor(100000 + Math.random() * 900000)}`;

    const newReceipt: WarehouseReceipt = {
      id: `dwr-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      receiptNumber,
      lotId: lot.id,
      warehouseId: wh.id,
      farmNodeId: lot.farmNodeId,
      farmerUid: lot.tenantId,
      tenantId: lot.tenantId,
      cropType: lot.cropType,
      variety: lot.variety,
      grade: lot.grade,
      quantity: lot.quantityCurrent,
      unit: lot.unit,
      valuePerUnitAtIssue: lot.valuationPricePerUnit,
      totalValueAtIssue: lot.storedValueCurrent,
      issuedDate: new Date().toISOString(),
      issuedBy: negotiable ? "Certified Operator / ZAMACE Verifier" : "Mabala Auto-Issue (On-Farm)",
      negotiable,
      status: "active",
      pledgeHistory: [],
      withdrawalHistory: [],
      documentUrl: `https://mabala.app/docs/dwr/${receiptNumber}.pdf`,
      qrVerificationCode: qrCode,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    receipts.unshift(newReceipt);
    this.saveWarehouseReceipts(receipts);
    return newReceipt;
  }

  /**
   * Log Storage Loss
   */
  static logStorageLoss(params: {
    lotId: string;
    quantityLost: number;
    causeCategory: StorageLoss["causeCategory"];
    notes: string;
    photos?: string[];
    loggedBy: string;
  }): { loss: StorageLoss; lot: StorageLot; receipt?: WarehouseReceipt } {
    const lots = this.getStorageLots();
    const idx = lots.findIndex(l => l.id === params.lotId);
    if (idx === -1) throw new Error("Storage lot not found");

    const lot = lots[idx];
    if (params.quantityLost > lot.quantityCurrent) {
      throw new Error(`Cannot log loss exceeding current lot balance (${lot.quantityCurrent} ${lot.unit})`);
    }

    const valueImpact = params.quantityLost * lot.valuationPricePerUnit;
    lot.quantityCurrent -= params.quantityLost;
    lot.storedValueCurrent = lot.quantityCurrent * lot.valuationPricePerUnit;
    if (lot.quantityCurrent <= 0) {
      lot.status = "depleted";
    }
    lot.updatedAt = new Date().toISOString();
    lots[idx] = lot;
    this.saveStorageLots(lots);

    const loss: StorageLoss = {
      id: `loss-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      lotId: lot.id,
      warehouseId: lot.warehouseId,
      tenantId: lot.tenantId,
      date: new Date().toISOString(),
      quantityLost: params.quantityLost,
      unit: lot.unit,
      causeCategory: params.causeCategory,
      notes: params.notes,
      photos: params.photos || [],
      loggedBy: params.loggedBy,
      valueImpact,
      createdAt: new Date().toISOString()
    };

    const losses = this.getStorageLosses();
    losses.unshift(loss);
    this.saveStorageLosses(losses);

    // Update DWR withdrawal history
    const receipts = this.getWarehouseReceipts();
    const rIdx = receipts.findIndex(r => r.lotId === lot.id);
    let receipt: WarehouseReceipt | undefined;
    if (rIdx !== -1) {
      receipt = receipts[rIdx];
      receipt.withdrawalHistory.push({
        qty: params.quantityLost,
        reason: "loss",
        ref: loss.id,
        date: new Date().toISOString(),
        loggedBy: params.loggedBy
      });
      receipt.quantity = lot.quantityCurrent;
      if (lot.quantityCurrent <= 0) {
        receipt.status = "closed";
      }
      receipt.updatedAt = new Date().toISOString();
      receipts[rIdx] = receipt;
      this.saveWarehouseReceipts(receipts);
    }

    // Trigger Variance re-calculation if a variance record exists
    if (lot.cropCycleId) {
      this.regenerateVarianceForCropCycle(lot.cropCycleId);
    }

    return { loss, lot, receipt };
  }

  /**
   * Sell from Storage
   */
  static sellFromStorage(params: {
    lotId: string;
    quantitySold: number;
    salePricePerUnit: number;
    customerName: string;
    loggedBy: string;
    tenantId: string;
    farmId: string;
    bagsSold?: number;
    weightPerBagKg?: number;
    paymentMethod?: string;
    isTaxInvoice?: boolean;
    vatAmount?: number;
  }): { lot: StorageLot; receipt?: WarehouseReceipt; sale: CashSale } {
    const lots = this.getStorageLots();
    const idx = lots.findIndex(l => l.id === params.lotId);
    if (idx === -1) throw new Error("Storage lot not found");

    const lot = lots[idx];
    const availableQty = lot.quantityCurrent - (lot.pledge.pledgedQuantity || 0);
    if (params.quantitySold > availableQty) {
      throw new Error(`Cannot sell ${params.quantitySold} ${lot.unit}: Available unpledged balance is ${availableQty} ${lot.unit}`);
    }

    lot.quantityCurrent -= params.quantitySold;
    lot.storedValueCurrent = lot.quantityCurrent * lot.valuationPricePerUnit;
    lot.status = lot.quantityCurrent <= 0 ? "depleted" : "partially_sold";
    lot.updatedAt = new Date().toISOString();
    lots[idx] = lot;
    this.saveStorageLots(lots);

    // Update DWR withdrawal history
    const receipts = this.getWarehouseReceipts();
    const rIdx = receipts.findIndex(r => r.lotId === lot.id);
    let receipt: WarehouseReceipt | undefined;
    
    const saleId = `sale-hsw-${Date.now()}`;
    if (rIdx !== -1) {
      receipt = receipts[rIdx];
      receipt.withdrawalHistory.push({
        qty: params.quantitySold,
        reason: "sale",
        ref: saleId,
        date: new Date().toISOString(),
        loggedBy: params.loggedBy
      });
      receipt.quantity = lot.quantityCurrent;
      if (lot.quantityCurrent <= 0) {
        receipt.status = "closed";
      } else {
        receipt.status = "partially_withdrawn";
      }
      receipt.updatedAt = new Date().toISOString();
      receipts[rIdx] = receipt;
      this.saveWarehouseReceipts(receipts);
    }

    const saleTotal = params.quantitySold * params.salePricePerUnit;
    const bagDetailsStr = params.bagsSold 
      ? ` [${params.bagsSold} Bags @ ${params.weightPerBagKg || 50}kg/bag]` 
      : "";

    const desc = `Storage Lot Sale: ${params.quantitySold} ${lot.unit}${bagDetailsStr} of ${lot.cropType} (${lot.grade || lot.variety}) from Warehouse`;

    const sale: CashSale = {
      id: saleId,
      date: new Date().toISOString().split("T")[0],
      description: desc,
      customer: params.customerName,
      amount: saleTotal,
      paymentMethod: (params.paymentMethod as any) || "Mobile Money",
      coaDebit: "1010", // Bank / Cash Desk
      coaCredit: "4300", // Commodity Sales Revenue
      farmId: params.farmId,
      tenantId: params.tenantId,
      sourceType: "from_storage",
      storageLotId: lot.id,
      cropCycleId: lot.cropCycleId,
      postSaleLotBalance: lot.quantityCurrent
    };

    // 1. Register to Finance Module Cash Sales Registry in localStorage
    try {
      const rawSales = localStorage.getItem("mabala_cash_sales");
      const cashSales: CashSale[] = rawSales ? JSON.parse(rawSales) : [];
      cashSales.unshift(sale);
      localStorage.setItem("mabala_cash_sales", JSON.stringify(cashSales));
    } catch (e) {
      console.error("Failed to append sale to mabala_cash_sales", e);
    }

    // 2. Register Paid Invoice to Invoices Registry in localStorage
    try {
      const rawInvoices = localStorage.getItem("mabala_invoices");
      const invoices: any[] = rawInvoices ? JSON.parse(rawInvoices) : [];
      const vat = params.vatAmount || (params.isTaxInvoice ? saleTotal * 0.16 : 0);
      const invNo = `INV-HSW-${Date.now().toString().slice(-5)}`;

      const newInvoice = {
        id: `inv-${Date.now()}`,
        invNo,
        date: new Date().toISOString().split("T")[0],
        dueDate: new Date().toISOString().split("T")[0],
        customer: params.customerName,
        customerTpin: "1002938481",
        lines: [
          {
            desc: desc,
            qty: params.bagsSold || params.quantitySold,
            price: params.bagsSold ? (saleTotal / params.bagsSold) : params.salePricePerUnit,
            amount: saleTotal
          }
        ],
        subtotal: saleTotal,
        vatRate: params.isTaxInvoice ? 16 : 0,
        vatAmt: vat,
        total: saleTotal + vat,
        status: "Paid",
        amountPaid: saleTotal + vat,
        paid: saleTotal + vat,
        createdAt: new Date().toISOString(),
        paymentMethod: params.paymentMethod || "Mobile Money",
        notes: "Automated warehouse storage stock sale invoice registered to Finance Module."
      };

      invoices.unshift(newInvoice);
      localStorage.setItem("mabala_invoices", JSON.stringify(invoices));
    } catch (e) {
      console.error("Failed to append invoice to mabala_invoices", e);
    }

    // Trigger Variance re-calculation if crop cycle linked
    if (lot.cropCycleId) {
      this.regenerateVarianceForCropCycle(lot.cropCycleId);
    }

    return { lot, receipt, sale };
  }

  /**
   * Pledge DWR for AGC Offset or External Loan
   */
  static pledgeDWRForAGCOffset(
    receiptId: string, 
    loanId: string, 
    requestedAmount: number
  ): { receipt: WarehouseReceipt; lot: StorageLot } {
    const receipts = this.getWarehouseReceipts();
    const rIdx = receipts.findIndex(r => r.id === receiptId);
    if (rIdx === -1) throw new Error("Warehouse receipt not found");

    const receipt = receipts[rIdx];
    const lots = this.getStorageLots();
    const lIdx = lots.findIndex(l => l.id === receipt.lotId);
    if (lIdx === -1) throw new Error("Storage lot not found");

    const lot = lots[lIdx];
    const maxAvailableValue = lot.quantityCurrent * lot.valuationPricePerUnit;
    if (requestedAmount > maxAvailableValue) {
      throw new Error(`Pledge amount (${requestedAmount}) exceeds current stored crop value (${maxAvailableValue})`);
    }

    // Soft pledge
    lot.pledge = {
      pledgedTo: "AGC_offset",
      pledgeRef: loanId,
      pledgedQuantity: lot.quantityCurrent,
      pledgedAt: new Date().toISOString(),
      releasedAt: null
    };
    lot.status = "pledged";
    lot.updatedAt = new Date().toISOString();
    lots[lIdx] = lot;
    this.saveStorageLots(lots);

    receipt.status = "pledged";
    receipt.pledgeHistory.push({
      type: "AGC_offset",
      ref: loanId,
      amount: requestedAmount,
      pledgedAt: new Date().toISOString(),
      releasedAt: null,
      releasedBy: null
    });
    receipt.updatedAt = new Date().toISOString();
    receipts[rIdx] = receipt;
    this.saveWarehouseReceipts(receipts);

    return { receipt, lot };
  }

  /**
   * Release DWR Pledge
   */
  static releaseDWRPledge(
    receiptId: string, 
    params: { releasedBy: string; reason: string }
  ): { receipt: WarehouseReceipt; lot: StorageLot } {
    const receipts = this.getWarehouseReceipts();
    const rIdx = receipts.findIndex(r => r.id === receiptId);
    if (rIdx === -1) throw new Error("Warehouse receipt not found");

    const receipt = receipts[rIdx];
    const lots = this.getStorageLots();
    const lIdx = lots.findIndex(l => l.id === receipt.lotId);
    if (lIdx === -1) throw new Error("Storage lot not found");

    const lot = lots[lIdx];
    
    lot.pledge = {
      pledgedTo: null,
      pledgeRef: null,
      pledgedQuantity: 0,
      pledgedAt: null,
      releasedAt: new Date().toISOString()
    };
    lot.status = lot.quantityCurrent > 0 ? "in_storage" : "depleted";
    lot.updatedAt = new Date().toISOString();
    lots[lIdx] = lot;
    this.saveStorageLots(lots);

    receipt.status = receipt.quantity > 0 ? "active" : "closed";
    if (receipt.pledgeHistory.length > 0) {
      const lastPledge = receipt.pledgeHistory[receipt.pledgeHistory.length - 1];
      lastPledge.releasedAt = new Date().toISOString();
      lastPledge.releasedBy = params.releasedBy;
    }
    receipt.updatedAt = new Date().toISOString();
    receipts[rIdx] = receipt;
    this.saveWarehouseReceipts(receipts);

    return { receipt, lot };
  }

  /**
   * QR Verification (Public unauthenticated)
   */
  static verifyDWRByQR(qrCode: string): {
    found: boolean;
    receiptNumber?: string;
    cropType?: string;
    grade?: string;
    quantity?: number;
    unit?: string;
    warehouseName?: string;
    certificationStatus?: string;
    status?: string;
    issuedDate?: string;
    totalValueAtIssue?: number;
  } {
    const receipts = this.getWarehouseReceipts();
    const receipt = receipts.find(r => r.qrVerificationCode === qrCode || r.receiptNumber === qrCode);
    if (!receipt) return { found: false };

    const warehouses = this.getWarehouses();
    const wh = warehouses.find(w => w.id === receipt.warehouseId);

    // Strictly omit PII!
    return {
      found: true,
      receiptNumber: receipt.receiptNumber,
      cropType: receipt.cropType,
      grade: receipt.grade,
      quantity: receipt.quantity,
      unit: receipt.unit,
      warehouseName: wh ? wh.name : "Registered Warehouse",
      certificationStatus: wh ? wh.certification.status : "uncertified",
      status: receipt.status,
      issuedDate: receipt.issuedDate,
      totalValueAtIssue: receipt.totalValueAtIssue
    };
  }

  /**
   * Generate Variance Record for Crop Cycle with AI Insight
   */
  static generateVarianceRecord(
    cropCycle: CropCycle, 
    tenantId: string = "tenant-01", 
    farmNodeId: string = "farm-01"
  ): CropCycleVariance {
    const harvestEvents = this.getHarvestEvents().filter(e => e.cropCycleId === cropCycle.id && e.status === "confirmed");
    const storageLots = this.getStorageLots().filter(l => l.cropCycleId === cropCycle.id);
    const storageLosses = this.getStorageLosses().filter(l => storageLots.some(sl => sl.id === l.lotId));

    const projectedYield = cropCycle.projectedYield || cropCycle.actualHarvestUnits || 50;
    const projectedUnit = cropCycle.projectedYieldUnit || "MT";
    const expectedPrice = cropCycle.expectedSellingPricePerKg ? cropCycle.expectedSellingPricePerKg * 1000 : 4200;
    const projectedRevenue = projectedYield * expectedPrice;

    const actualHarvestQty = harvestEvents.reduce((acc, curr) => acc + curr.quantityRaw, 0) || (cropCycle.actualHarvestUnits || 0);
    const actualHarvestValue = actualHarvestQty * expectedPrice;

    const postHarvestLossQty = storageLosses.reduce((acc, curr) => acc + curr.quantityLost, 0);
    const postHarvestLossValue = storageLosses.reduce((acc, curr) => acc + curr.valueImpact, 0);

    const varianceQty = actualHarvestQty - postHarvestLossQty - projectedYield;
    const variancePct = projectedYield > 0 ? (varianceQty / projectedYield) * 100 : 0;

    const actualNetRevenue = (actualHarvestQty - postHarvestLossQty) * expectedPrice;
    const varianceRevenue = actualNetRevenue - projectedRevenue;
    const varianceRevenuePct = projectedRevenue > 0 ? (varianceRevenue / projectedRevenue) * 100 : 0;

    let classification: 'surplus' | 'deficit' | 'on_target' = 'on_target';
    if (variancePct > 5) classification = 'surplus';
    else if (variancePct < -5) classification = 'deficit';

    // AI Insight driver logic
    let driverType: 'volume' | 'price' | 'mixed' = 'volume';
    let summaryText = "";
    const likelyCauses: { tag: string; description: string }[] = [];

    if (classification === 'surplus') {
      summaryText = `Harvest exceeded forecast by ${Math.abs(variancePct).toFixed(1)}% due to optimal germination, timely weeding, and low post-harvest spoilage.`;
      likelyCauses.push({ tag: "Optimal Weather", description: "Favorable rainfall distribution during grain filling stage." });
      likelyCauses.push({ tag: "Low Storage Spoilage", description: "Quick transfer into climate-controlled storage prevented pest damage." });
    } else if (classification === 'deficit') {
      if (postHarvestLossQty > 0.3 * Math.abs(varianceQty)) {
        driverType = 'mixed';
        summaryText = `Yield deficit of ${Math.abs(variancePct).toFixed(1)}% driven by both field production shortfall and post-harvest storage loss (${postHarvestLossQty} ${projectedUnit}).`;
        likelyCauses.push({ tag: "Storage Loss", description: `Unscheduled moisture buildup and pest infestation caused ${postHarvestLossQty} ${projectedUnit} loss.` });
        likelyCauses.push({ tag: "Dry Spells", description: "Late-season moisture stress during tassel flowering." });
      } else {
        driverType = 'volume';
        summaryText = `Production yield came in ${Math.abs(variancePct).toFixed(1)}% below target forecast primarily due to field-level volume deficit.`;
        likelyCauses.push({ tag: "Field Stunting", description: "Incomplete fertilizer top-dressing calibration during early vegetative stage." });
      }
    } else {
      summaryText = `Harvest closely matched planned target within a ${variancePct.toFixed(1)}% margin.`;
      likelyCauses.push({ tag: "Accurate Forecasting", description: "Agronomic assumptions aligned closely with field output." });
    }

    const newVariance: CropCycleVariance = {
      cropCycleId: cropCycle.id,
      tenantId,
      farmNodeId,
      projectedYield,
      projectedYieldUnit: projectedUnit,
      projectedRevenue,
      actualHarvestQty,
      actualHarvestValue,
      postHarvestLossQty,
      postHarvestLossValue,
      varianceQty,
      variancePct,
      varianceRevenue,
      varianceRevenuePct,
      classification,
      aiInsight: {
        summary: summaryText,
        likelyCauses,
        driverType,
        generatedAt: new Date().toISOString(),
        modelRef: "Mabala-Agronomy-LLM-v2.5"
      },
      generatedAt: new Date().toISOString(),
      regeneratedAt: new Date().toISOString()
    };

    const variances = this.getVariances();
    const idx = variances.findIndex(v => v.cropCycleId === cropCycle.id);
    if (idx !== -1) {
      variances[idx] = newVariance;
    } else {
      variances.unshift(newVariance);
    }
    this.saveVariances(variances);

    return newVariance;
  }

  /**
   * Helper to re-generate variance after a loss/sale update
   */
  static regenerateVarianceForCropCycle(cropCycleId: string) {
    const variances = this.getVariances();
    const existing = variances.find(v => v.cropCycleId === cropCycleId);
    if (existing) {
      const dummyCrop: CropCycle = {
        id: cropCycleId,
        cropName: "Crop Cycle",
        stage: "Harvest Complete",
        projectedYield: existing.projectedYield,
        projectedYieldUnit: existing.projectedYieldUnit,
        expectedSellingPricePerKg: existing.projectedRevenue / (existing.projectedYield * 1000)
      } as any;
      this.generateVarianceRecord(dummyCrop, existing.tenantId, existing.farmNodeId);
    }
  }

  /**
   * Balance Sheet Helper: Sum current stored value for active lots
   */
  static calculateCropsInStorageValue(tenantId?: string): number {
    const lots = this.getStorageLots();
    return lots
      .filter(l => (l.status === "in_storage" || l.status === "partially_sold" || l.status === "pledged") && (!tenantId || l.tenantId === tenantId))
      .reduce((sum, l) => sum + (l.storedValueCurrent || 0), 0);
  }

  /**
   * External API Aggregated Position (Enforces Minimum Cohort Size)
   */
  static getAggregatedStoragePosition(): { success: boolean; data?: any; error?: string } {
    const lots = this.getStorageLots();
    const minCohort = this.getMinCohortSize();
    const uniqueFarmers = new Set(lots.map(l => l.tenantId)).size;

    if (uniqueFarmers < minCohort) {
      return {
        success: false,
        error: `Insufficient sample size: Aggregated market data requires a minimum cohort of ${minCohort} distinct active farm tenants (currently ${uniqueFarmers}).`
      };
    }

    const byCrop: Record<string, { totalQty: number; totalValue: number; lotCount: number }> = {};
    lots.forEach(l => {
      if (!byCrop[l.cropType]) {
        byCrop[l.cropType] = { totalQty: 0, totalValue: 0, lotCount: 0 };
      }
      byCrop[l.cropType].totalQty += l.quantityCurrent;
      byCrop[l.cropType].totalValue += l.storedValueCurrent;
      byCrop[l.cropType].lotCount += 1;
    });

    return {
      success: true,
      data: {
        cohortSize: uniqueFarmers,
        timestamp: new Date().toISOString(),
        summaryByCrop: byCrop
      }
    };
  }
}

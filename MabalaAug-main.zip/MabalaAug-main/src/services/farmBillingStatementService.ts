import { safeFetchJsonClient } from "../App";
import { INITIAL_LIPILA_TRANSACTIONS, LipilaTransaction } from "../data/mockLipilaTransactions";
import { fetchPlatformInvoices, PlatformInvoice } from "./platformInvoiceService";
import * as XLSX from "xlsx";

export interface StatementLineItem {
  id: string;
  referenceId: string;
  date: string;
  category: "Subscription" | "AI Credits Top-Up" | "SMS Credits Top-Up" | "Platform Invoice" | "Service / Consult";
  description: string;
  paymentMethod: string;
  provider?: string;
  invoicedAmount: number;
  paidAmount: number;
  balanceDue: number;
  status: "PAID" | "PENDING" | "OVERDUE" | "ALLOCATED" | "CANCELLED";
  creditsGranted?: number;
  smsUnitsGranted?: number;
  rawTransaction?: any;
}

export interface StatementSummary {
  totalInvoiced: number;
  totalPaid: number;
  totalOutstanding: number;
  subscriptions: {
    invoiced: number;
    paid: number;
    count: number;
  };
  creditTopups: {
    invoiced: number;
    paid: number;
    creditsTotal: number;
    count: number;
  };
  smsTopups: {
    invoiced: number;
    paid: number;
    smsUnitsTotal: number;
    count: number;
  };
  invoices: {
    invoiced: number;
    paid: number;
    pending: number;
    count: number;
  };
}

export interface FarmAccountInfo {
  tenantId: string;
  farmName: string;
  letterheadTitle?: string;
  letterheadSubtitle?: string;
  letterheadAddress?: string;
  registeredEmail: string;
  phone: string;
  activeSubscriptionTier: string;
  creditBalance: number;
  smsBalance: number;
  statementGeneratedAt: string;
}

export interface FarmBillingStatement {
  accountInfo: FarmAccountInfo;
  summary: StatementSummary;
  lineItems: StatementLineItem[];
  periodLabel: string;
}

export interface EmailStatementPayload {
  tenantId: string;
  recipientEmail: string;
  farmName: string;
  statementPeriod?: string;
  accountInfo: FarmAccountInfo;
  summary: StatementSummary;
  lineItems: StatementLineItem[];
  customMessage?: string;
}

export interface FarmBillingStatementOptions {
  periodFilter?: "all" | "ytd" | "90days" | "30days" | "thisMonth" | "custom";
  startDate?: string;
  endDate?: string;
}

/**
 * Aggregates farm billing statement from backend and client-side ledgers
 */
export async function fetchFarmBillingStatement(
  tenantId: string,
  userProfile?: any,
  activeFarm?: any,
  periodFilter: "all" | "ytd" | "90days" | "30days" | "thisMonth" | "custom" = "all",
  startDate?: string,
  endDate?: string
): Promise<FarmBillingStatement> {
  const cleanTenantId = tenantId || userProfile?.uid || activeFarm?.id || "TENANT-001";

  // Try fetching aggregated statement from backend first
  try {
    const params = new URLSearchParams();
    if (periodFilter) params.append("period", periodFilter);
    if (startDate) params.append("startDate", startDate);
    if (endDate) params.append("endDate", endDate);

    const qs = params.toString() ? `?${params.toString()}` : "";
    const res = await safeFetchJsonClient(`/api/billing/statement/${encodeURIComponent(cleanTenantId)}${qs}`);
    if (res && res.success && res.statement) {
      return filterStatementByPeriod(res.statement, periodFilter, startDate, endDate);
    }
  } catch (err) {
    console.warn("[BillingStatementService] Backend statement endpoint fallback:", err);
  }

  // Client-side fallback aggregation
  return assembleClientSideStatement(cleanTenantId, userProfile, activeFarm, periodFilter, startDate, endDate);
}

/**
 * Dispatches the official billing statement via Hostinger SMTP email
 */
export async function emailFarmBillingStatement(payload: EmailStatementPayload): Promise<{
  success: boolean;
  message: string;
  messageId?: string;
  sentTo?: string;
}> {
  try {
    const res = await safeFetchJsonClient("/api/billing/email-statement", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (res && res.success) {
      return {
        success: true,
        message: res.message || `Statement successfully emailed to ${payload.recipientEmail}`,
        messageId: res.messageId,
        sentTo: res.sentTo || payload.recipientEmail
      };
    } else {
      throw new Error(res?.error || "Failed to dispatch email statement.");
    }
  } catch (err: any) {
    console.error("[BillingStatementService] Email statement failed:", err);
    throw new Error(err.message || "Could not connect to email server to dispatch statement.");
  }
}

/**
 * Exports statement to CSV / Excel for farm bookkeeping
 */
export function exportStatementToCSV(statement: FarmBillingStatement, fileName?: string): void {
  const account = statement.accountInfo;
  const summary = statement.summary;

  const headerRows = [
    ["MABALA AGRO ENTERPRISE - OFFICIAL BILLING STATEMENT"],
    ["Generated At", new Date(account.statementGeneratedAt).toLocaleString()],
    ["Farm Node", account.farmName],
    ["Tenant ID", account.tenantId],
    ["Registered Email", account.registeredEmail],
    ["Contact Phone", account.phone],
    ["Active Plan", account.activeSubscriptionTier],
    ["Current AI Credits", account.creditBalance],
    ["Current SMS Credits", account.smsBalance],
    [""],
    ["FINANCIAL SUMMARY (ZMW)"],
    ["Total Invoiced (ZMW)", summary.totalInvoiced.toFixed(2)],
    ["Total Paid (ZMW)", summary.totalPaid.toFixed(2)],
    ["Outstanding Balance (ZMW)", summary.totalOutstanding.toFixed(2)],
    ["Subscriptions Total (ZMW)", summary.subscriptions.paid.toFixed(2)],
    ["AI Credit Top-ups Total (ZMW)", summary.creditTopups.paid.toFixed(2)],
    ["SMS Credit Top-ups Total (ZMW)", summary.smsTopups.paid.toFixed(2)],
    ["Invoiced Platform Services (ZMW)", summary.invoices.paid.toFixed(2)],
    [""],
    ["ITEMIZED TRANSACTION LEDGER"],
    ["Date", "Statement ID", "Reference ID", "Category", "Description", "Payment Method", "Invoiced (ZMW)", "Paid (ZMW)", "Balance Due (ZMW)", "Status", "Credits Granted", "SMS Units Granted"]
  ];

  const itemRows = statement.lineItems.map(item => [
    new Date(item.date).toLocaleDateString() + " " + new Date(item.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    item.id,
    item.referenceId,
    item.category,
    item.description,
    item.paymentMethod,
    item.invoicedAmount.toFixed(2),
    item.paidAmount.toFixed(2),
    item.balanceDue.toFixed(2),
    item.status,
    item.creditsGranted || 0,
    item.smsUnitsGranted || 0
  ]);

  const worksheet = XLSX.utils.aoa_to_sheet([...headerRows, ...itemRows]);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Billing Statement");

  const defaultName = `Mabala_Statement_${account.farmName.replace(/\s+/g, "_")}_${new Date().toISOString().split("T")[0]}.xlsx`;
  XLSX.writeFile(workbook, fileName || defaultName);
}

/**
 * Filter statement items by date range or preset period
 */
export function filterStatementByPeriod(
  stmt: FarmBillingStatement,
  period: "all" | "ytd" | "90days" | "30days" | "thisMonth" | "custom" = "all",
  startDate?: string,
  endDate?: string
): FarmBillingStatement {
  if (period === "all" && !startDate && !endDate) return stmt;

  const now = new Date();
  let minDate: Date | null = null;
  let maxDate: Date | null = null;
  let label = "All Time";

  if (startDate) {
    minDate = new Date(startDate + "T00:00:00");
  }
  if (endDate) {
    maxDate = new Date(endDate + "T23:59:59.999");
  }

  if (period === "thisMonth") {
    minDate = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
    maxDate = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
    label = "This Month";
  } else if (period === "30days") {
    minDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    label = "Last 30 Days";
  } else if (period === "90days") {
    minDate = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
    label = "Last 90 Days";
  } else if (period === "ytd") {
    minDate = new Date(now.getFullYear(), 0, 1, 0, 0, 0, 0);
    label = `Year to Date (${now.getFullYear()})`;
  } else if (period === "custom" || (startDate && endDate)) {
    if (startDate && endDate) {
      label = `From ${startDate} to ${endDate}`;
    } else if (startDate) {
      label = `From ${startDate} onwards`;
    } else if (endDate) {
      label = `Up to ${endDate}`;
    } else {
      label = "Custom Period";
    }
  }

  const filteredItems = stmt.lineItems.filter(item => {
    if (!item.date) return false;
    const itemDate = new Date(item.date).getTime();
    if (isNaN(itemDate)) return true;
    if (minDate && itemDate < minDate.getTime()) return false;
    if (maxDate && itemDate > maxDate.getTime()) return false;
    return true;
  });

  // Recalculate summary for the filtered slice
  const summary = calculateSummary(filteredItems);

  return {
    ...stmt,
    summary,
    lineItems: filteredItems,
    periodLabel: label
  };
}

/**
 * Helper to assemble client-side billing statement if backend endpoint is unavailable
 */
async function assembleClientSideStatement(
  tenantId: string,
  userProfile?: any,
  activeFarm?: any,
  periodFilter: "all" | "ytd" | "90days" | "30days" | "thisMonth" | "custom" = "all",
  startDate?: string,
  endDate?: string
): Promise<FarmBillingStatement> {
  const lineItems: StatementLineItem[] = [];

  // 1. Gather Lipila Transactions
  let localTxs: LipilaTransaction[] = [];
  try {
    const stored = localStorage.getItem("mabala_lipila_user_transactions");
    if (stored) localTxs = JSON.parse(stored);
  } catch (e) {}

  const combinedTxs = [...localTxs, ...INITIAL_LIPILA_TRANSACTIONS];
  const uniqueTxs = new Map<string, LipilaTransaction>();
  combinedTxs.forEach(t => uniqueTxs.set(t.id, t));

  const targetTenantId = (tenantId || activeFarm?.id || userProfile?.uid || "").toLowerCase();
  const targetEmail = (userProfile?.email || activeFarm?.email || "").toLowerCase();

  Array.from(uniqueTxs.values()).forEach(tx => {
    const txTenant = (tx.tenantId || "").toLowerCase();
    const txAcct = (tx.accountNumber || "").toLowerCase();
    const txCust = (tx.customerName || "").toLowerCase();

    const isMatch = (targetTenantId && txTenant === targetTenantId) ||
                    (targetEmail && (txAcct.includes(targetEmail) || txCust.includes(targetEmail))) ||
                    (!targetTenantId && !targetEmail);

    if (isMatch) {
      const narration = tx.narration || "Mabala Transaction";
      let category: StatementLineItem["category"] = "Subscription";
      let creditsGranted = 0;
      let smsUnitsGranted = 0;

      if (narration.toLowerCase().includes("sms") || narration.toLowerCase().includes("message")) {
        category = "SMS Credits Top-Up";
        smsUnitsGranted = extractUnits(narration, 500);
      } else if (narration.toLowerCase().includes("credit") || narration.toLowerCase().includes("pack") || narration.toLowerCase().includes("starter") || narration.toLowerCase().includes("field") || narration.toLowerCase().includes("season") || narration.toLowerCase().includes("bulk")) {
        category = "AI Credits Top-Up";
        creditsGranted = extractUnits(narration, 150);
      } else if (narration.toLowerCase().includes("invoice") || narration.toLowerCase().includes("consultation")) {
        category = "Platform Invoice";
      } else if (narration.toLowerCase().includes("bundle") || narration.toLowerCase().includes("unmetered")) {
        category = "Subscription";
      }

      const isPaid = tx.status === "Successful";
      lineItems.push({
        id: tx.id,
        referenceId: tx.referenceId || `REF-${tx.id.slice(-6)}`,
        date: tx.createdAt,
        category,
        description: narration,
        paymentMethod: tx.paymentMethod || `Lipila MoMo (${tx.provider || 'MTN'})`,
        provider: tx.provider,
        invoicedAmount: tx.amount,
        paidAmount: isPaid ? tx.amount : 0,
        balanceDue: isPaid ? 0 : tx.amount,
        status: isPaid ? "PAID" : tx.status === "Pending" ? "PENDING" : "CANCELLED",
        creditsGranted,
        smsUnitsGranted,
        rawTransaction: tx
      });
    }
  });

  // 2. Gather Platform Invoices
  try {
    const invoices: PlatformInvoice[] = await fetchPlatformInvoices();
    invoices.forEach(inv => {
      const invTenant = (inv.recipientTenantId || "").toLowerCase();
      const invEmail = (inv.recipientEmail || "").toLowerCase();

      const isMatch = (targetTenantId && invTenant === targetTenantId) ||
                      (targetEmail && invEmail === targetEmail);

      // Avoid double counting if already present in Lipila transactions
      const alreadyInList = lineItems.some(i => i.id === inv.id || i.referenceId === inv.lipilaReferenceId);

      if (isMatch && !alreadyInList) {
        const isPaid = inv.status === "PAID";
        lineItems.push({
          id: `INV-${inv.invoiceNumber || inv.id.slice(-6)}`,
          referenceId: inv.lipilaReferenceId || `INV-${inv.invoiceNumber}`,
          date: inv.issuedAt || new Date().toISOString(),
          category: "Platform Invoice",
          description: `Platform Invoice #${inv.invoiceNumber}: ${inv.lineItems?.map(l => l.description).join(", ") || 'Professional Agronomy Services'}`,
          paymentMethod: isPaid ? "Lipila Mobile Money (Settled)" : "Pending Settlement",
          invoicedAmount: inv.totalAmount,
          paidAmount: isPaid ? inv.totalAmount : 0,
          balanceDue: isPaid ? 0 : inv.totalAmount,
          status: isPaid ? "PAID" : "PENDING",
          rawTransaction: inv
        });
      }
    });
  } catch (invErr) {
    console.warn("[BillingStatementService] Invoices fetch note:", invErr);
  }

  // Sort descending by date
  lineItems.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const summary = calculateSummary(lineItems);

  const accountInfo: FarmAccountInfo = {
    tenantId: tenantId || activeFarm?.id || userProfile?.uid || "FN-HQ-PRIMARY",
    farmName: activeFarm?.name || userProfile?.displayName || userProfile?.farmName || "Farm Node",
    letterheadTitle: activeFarm?.letterheadTitle || activeFarm?.name || userProfile?.displayName || "Farm Node Operations",
    letterheadSubtitle: activeFarm?.letterheadSubtitle || "Agricultural Operations & Billing Ledger",
    letterheadAddress: activeFarm?.letterheadAddress || activeFarm?.address || "",
    registeredEmail: userProfile?.email || activeFarm?.email || "",
    phone: activeFarm?.phone || userProfile?.phone || "",
    activeSubscriptionTier: userProfile?.subscriptionTier || activeFarm?.subscriptionTier || "PRO",
    creditBalance: Number(userProfile?.credits ?? activeFarm?.credits ?? 0),
    smsBalance: Number(userProfile?.smsCredits ?? activeFarm?.smsCredits ?? 0),
    statementGeneratedAt: new Date().toISOString()
  };

  const rawStatement: FarmBillingStatement = {
    accountInfo,
    summary,
    lineItems,
    periodLabel: "All Time"
  };

  return filterStatementByPeriod(rawStatement, periodFilter, startDate, endDate);
}

function calculateSummary(items: StatementLineItem[]): StatementSummary {
  let totalInvoiced = 0;
  let totalPaid = 0;
  let totalOutstanding = 0;

  const subscriptions = { invoiced: 0, paid: 0, count: 0 };
  const creditTopups = { invoiced: 0, paid: 0, creditsTotal: 0, count: 0 };
  const smsTopups = { invoiced: 0, paid: 0, smsUnitsTotal: 0, count: 0 };
  const invoices = { invoiced: 0, paid: 0, pending: 0, count: 0 };

  items.forEach(item => {
    totalInvoiced += item.invoicedAmount;
    totalPaid += item.paidAmount;
    totalOutstanding += item.balanceDue;

    if (item.category === "Subscription") {
      subscriptions.invoiced += item.invoicedAmount;
      subscriptions.paid += item.paidAmount;
      subscriptions.count++;
    } else if (item.category === "AI Credits Top-Up") {
      creditTopups.invoiced += item.invoicedAmount;
      creditTopups.paid += item.paidAmount;
      creditTopups.creditsTotal += (item.creditsGranted || 0);
      creditTopups.count++;
    } else if (item.category === "SMS Credits Top-Up") {
      smsTopups.invoiced += item.invoicedAmount;
      smsTopups.paid += item.paidAmount;
      smsTopups.smsUnitsTotal += (item.smsUnitsGranted || 0);
      smsTopups.count++;
    } else {
      invoices.invoiced += item.invoicedAmount;
      invoices.paid += item.paidAmount;
      invoices.pending += item.balanceDue;
      invoices.count++;
    }
  });

  return {
    totalInvoiced,
    totalPaid,
    totalOutstanding,
    subscriptions,
    creditTopups,
    smsTopups,
    invoices
  };
}

function extractUnits(text: string, fallback: number): number {
  const match = text.match(/\b(\d{1,5})\s*(?:credits|units|sms|messages)\b/i);
  if (match && match[1]) {
    return parseInt(match[1], 10);
  }
  return fallback;
}

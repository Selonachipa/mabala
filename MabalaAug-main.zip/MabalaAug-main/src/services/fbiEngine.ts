import { 
  FbiGranularity, 
  FbiPeriod, 
  FbiDomains, 
  FbiNodeRollup, 
  FbiTenantRollup, 
  FbiKpiRegistryItem, 
  FbiFarmNodeComparisonItem,
  FbiInsight,
  FbiInsightDriver
} from "../types/fbi";

export const DEFAULT_FBI_KPI_REGISTRY: FbiKpiRegistryItem[] = [
  {
    kpiId: "rev_total",
    domain: "revenue",
    label: "Total Farm Gross Revenue",
    unit: "ZMW",
    description: "Gross revenue collected and invoiced across all crops, livestock, poultry, and value-added farm outputs.",
    sourcePath: "farm_nodes/{farmNodeId}/reports_rollups/revenue",
    aggregation: "sum",
    sliceableBy: ["cropCycleId", "customerType", "batchId"],
    requiresRollupVersion: "reportCentre"
  },
  {
    kpiId: "exp_total",
    domain: "expenses",
    label: "Operating Expenses (OpEx)",
    unit: "ZMW",
    description: "Total operating expenses including feed, inputs, labour, maintenance, and logistics.",
    sourcePath: "farm_nodes/{farmNodeId}/reports_rollups/expenses",
    aggregation: "sum",
    sliceableBy: ["coaCode", "cropCycleId", "batchId"],
    requiresRollupVersion: "coa"
  },
  {
    kpiId: "crop_yield_per_ha",
    domain: "cropProduction",
    label: "Crop Yield per Hectare",
    unit: "kg/ha",
    description: "Harvested marketable output normalized by cultivated land area in hectares.",
    sourcePath: "farm_nodes/{farmNodeId}/crop_cycles",
    aggregation: "ratio",
    sliceableBy: ["cropType", "variety", "fieldBlock"],
    requiresRollupVersion: "reportCentre"
  },
  {
    kpiId: "livestock_fcr",
    domain: "livestockProduction",
    label: "Feed Conversion Ratio (FCR)",
    unit: "ratio",
    description: "Total feed consumed (kg) divided by net animal liveweight gain (kg).",
    sourcePath: "farm_nodes/{farmNodeId}/poultry_batches",
    aggregation: "avg",
    sliceableBy: ["species", "batchId", "breed"],
    requiresRollupVersion: "reportCentre"
  },
  {
    kpiId: "livestock_mortality",
    domain: "livestockProduction",
    label: "Mortality Rate",
    unit: "%",
    description: "Mortality loss percentage against opening flock or herd population.",
    sourcePath: "farm_nodes/{farmNodeId}/livestock",
    aggregation: "ratio",
    sliceableBy: ["species", "batchId"],
    requiresRollupVersion: "reportCentre"
  },
  {
    kpiId: "feed_cost_per_kg_gain",
    domain: "feedingCosts",
    label: "Feed Cost per Kg Gain",
    unit: "ZMW/kg",
    description: "Cost of feed consumed to generate 1 kilogram of animal weight gain.",
    sourcePath: "farm_nodes/{farmNodeId}/feeding_logs",
    aggregation: "ratio",
    sliceableBy: ["species", "batchId"],
    requiresRollupVersion: "reportCentre"
  },
  {
    kpiId: "labour_cost_per_ha",
    domain: "labourCosts",
    label: "Labour Cost per Hectare",
    unit: "ZMW/ha",
    description: "Total wage expenditures normalized across total cultivated hectares.",
    sourcePath: "farm_nodes/{farmNodeId}/payroll",
    aggregation: "ratio",
    sliceableBy: ["workerType", "taskType"],
    requiresRollupVersion: "coa"
  },
  {
    kpiId: "fertilizer_chem_cost_ha",
    domain: "fertilizerChemicalCosts",
    label: "Crop Protection & Fertilizer Cost / Ha",
    unit: "ZMW/ha",
    description: "Fertilizer, foliar, seed, and chemical pesticide costs per cultivated hectare.",
    sourcePath: "farm_nodes/{farmNodeId}/agronomy_inputs",
    aggregation: "ratio",
    sliceableBy: ["cropCycleId", "inputCategory"],
    requiresRollupVersion: "reportCentre"
  },
  {
    kpiId: "land_utilization_rate",
    domain: "landUtilization",
    label: "Land Utilization Rate",
    unit: "%",
    description: "Active cultivated, orchard, and pasture area over total registered farm land area.",
    sourcePath: "farm_nodes/{farmNodeId}/fields",
    aggregation: "ratio",
    sliceableBy: ["fieldId", "landType"],
    requiresRollupVersion: "reportCentre"
  },
  {
    kpiId: "capex_total",
    domain: "investments",
    label: "Capital Expenditure (CapEx)",
    unit: "ZMW",
    description: "Additions to machinery, irrigation infrastructure, buildings, and biological assets.",
    sourcePath: "farm_nodes/{farmNodeId}/asset_register",
    aggregation: "sum",
    sliceableBy: ["assetType"],
    requiresRollupVersion: "coa"
  },
  {
    kpiId: "credit_outstanding",
    domain: "creditFinancing",
    label: "Outstanding Credit Balance",
    unit: "ZMW",
    description: "Active input financing balances and working capital loans across agro-dealers and AGC.",
    sourcePath: "farm_nodes/{farmNodeId}/credit_applications",
    aggregation: "sum",
    sliceableBy: ["financier", "loanType"],
    requiresRollupVersion: "reportCentre"
  },
  {
    kpiId: "net_cash_flow",
    domain: "cashWallet",
    label: "Net Cash Flow",
    unit: "ZMW",
    description: "Total cash & mobile money inflows minus operating and financing cash outflows.",
    sourcePath: "farm_nodes/{farmNodeId}/wallet_transactions",
    aggregation: "sum",
    sliceableBy: ["channel", "flowType"],
    requiresRollupVersion: "reportCentre"
  },
  {
    kpiId: "net_profit_margin",
    domain: "profitability",
    label: "Net Profit Margin",
    unit: "%",
    description: "Net operational profit expressed as a percentage of total farm revenue.",
    sourcePath: "farm_nodes/{farmNodeId}/financial_summary",
    aggregation: "ratio",
    sliceableBy: ["cropCycleId", "species"],
    requiresRollupVersion: "coa"
  }
];

export interface FbiDataContext {
  sales?: any[];
  invoices?: any[];
  otherRevenues?: any[];
  expenses?: any[];
  crops?: any[];
  livestock?: any[];
  poultry?: any[];
  fish?: any[];
  fishBatches?: any[];
  employees?: any[];
  payslips?: any[];
  employeeAdvances?: any[];
  inventory?: any[];
  loans?: any[];
  plots?: any[];
  assets?: any[];
  investments?: any[];
  tasks?: any[];
  feedLogs?: any[];
  customers?: any[];
  suppliers?: any[];
  activeFarm?: any;
  walletBalances?: any;
  walletTransactions?: any[];
}

export function resolvePeriodDates(granularity: FbiGranularity, dateInput?: Date | string): FbiPeriod {
  const d = dateInput ? new Date(dateInput) : new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");

  if (granularity === "daily") {
    const key = `${year}-${month}-${day}`;
    const start = new Date(year, d.getMonth(), d.getDate(), 0, 0, 0, 0).toISOString();
    const end = new Date(year, d.getMonth(), d.getDate(), 23, 59, 59, 999).toISOString();
    const label = d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
    return { type: "daily", key, start, end, label };
  }

  if (granularity === "weekly") {
    const tempDate = new Date(d.getTime());
    tempDate.setHours(0, 0, 0, 0);
    tempDate.setDate(tempDate.getDate() + 3 - (tempDate.getDay() + 6) % 7);
    const week1 = new Date(tempDate.getFullYear(), 0, 4);
    const weekNum = 1 + Math.round(((tempDate.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
    const key = `${tempDate.getFullYear()}-W${String(weekNum).padStart(2, "0")}`;
    
    const dayOfWeek = d.getDay();
    const diffToMonday = (dayOfWeek + 6) % 7;
    const monday = new Date(d);
    monday.setDate(d.getDate() - diffToMonday);
    monday.setHours(0, 0, 0, 0);
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    sunday.setHours(23, 59, 59, 999);

    const label = `Week ${weekNum}, ${year} (${monday.toLocaleDateString("en-GB", { day: "numeric", month: "short" })} - ${sunday.toLocaleDateString("en-GB", { day: "numeric", month: "short" })})`;
    return { type: "weekly", key, start: monday.toISOString(), end: sunday.toISOString(), label };
  }

  if (granularity === "yearly") {
    const key = `${year}`;
    const start = new Date(year, 0, 1, 0, 0, 0, 0).toISOString();
    const end = new Date(year, 11, 31, 23, 59, 59, 999).toISOString();
    const label = `Year ${year}`;
    return { type: "yearly", key, start, end, label };
  }

  // Monthly by default
  const key = `${year}-${month}`;
  const start = new Date(year, d.getMonth(), 1, 0, 0, 0, 0).toISOString();
  const lastDay = new Date(year, d.getMonth() + 1, 0).getDate();
  const end = new Date(year, d.getMonth(), lastDay, 23, 59, 59, 999).toISOString();
  const monthName = d.toLocaleDateString("en-GB", { month: "long", year: "numeric" });
  return { type: "monthly", key, start, end, label: monthName };
}

function isDateInPeriod(dateStr: string | undefined | number, start: string, end: string): boolean {
  if (!dateStr) return true; // If unversioned, count towards current activity
  try {
    const time = new Date(dateStr).getTime();
    if (isNaN(time)) return true;
    const startTime = new Date(start).getTime();
    const endTime = new Date(end).getTime();
    return time >= startTime && time <= endTime;
  } catch {
    return true;
  }
}

function getPriorPeriodDates(period: FbiPeriod): { start: string; end: string } {
  const currentStart = new Date(period.start);
  const currentEnd = new Date(period.end);
  const durationMs = currentEnd.getTime() - currentStart.getTime();
  
  const priorEnd = new Date(currentStart.getTime() - 1);
  const priorStart = new Date(priorEnd.getTime() - durationMs);
  return {
    start: priorStart.toISOString(),
    end: priorEnd.toISOString()
  };
}

function getYoYPeriodDates(period: FbiPeriod): { start: string; end: string } {
  const currentStart = new Date(period.start);
  const currentEnd = new Date(period.end);
  
  const yoyStart = new Date(currentStart);
  yoyStart.setFullYear(yoyStart.getFullYear() - 1);
  const yoyEnd = new Date(currentEnd);
  yoyEnd.setFullYear(yoyEnd.getFullYear() - 1);

  return {
    start: yoyStart.toISOString(),
    end: yoyEnd.toISOString()
  };
}

/**
 * Computes live, accurate domain metrics strictly from actual captured user records.
 * Zero placeholder data or synthetic mock numbers.
 */
export function computeRealNodeRollup(
  tenantId: string,
  farmNodeId: string,
  farmNodeName: string,
  period: FbiPeriod,
  context: FbiDataContext = {}
): FbiNodeRollup {
  const { start, end } = period;
  const priorRange = getPriorPeriodDates(period);
  const yoyRange = getYoYPeriodDates(period);

  const rawSales = context.sales || [];
  const rawInvoices = context.invoices || [];
  const rawOtherRevenues = context.otherRevenues || [];
  const rawExpenses = context.expenses || [];
  const rawCrops = context.crops || [];
  const rawLivestock = context.livestock || [];
  const rawPoultry = context.poultry || [];
  const rawFish = context.fish || context.fishBatches || [];
  const rawEmployees = context.employees || [];
  const rawPayslips = context.payslips || [];
  const rawInventory = context.inventory || [];
  const rawAssets = context.assets || [];
  const rawInvestments = context.investments || [];
  const rawLoans = context.loans || [];
  const rawPlots = context.plots || [];
  const rawTasks = context.tasks || [];
  const rawFeedLogs = context.feedLogs || [];
  const activeFarm = context.activeFarm || {};

  // Filter records matching the farmNodeId (if records have farmId/nodeId tag) or include if node matches or only single farm
  const farmMatches = (r: any) => !farmNodeId || r.farmId === farmNodeId || r.farmNodeId === farmNodeId || !r.farmId;

  const nodeSales = rawSales.filter(farmMatches);
  const nodeInvoices = rawInvoices.filter(farmMatches);
  const nodeOtherRevenues = rawOtherRevenues.filter(farmMatches);
  const nodeExpenses = rawExpenses.filter(farmMatches);
  const nodeCrops = rawCrops.filter(farmMatches);
  const nodeLivestock = rawLivestock.filter(farmMatches);
  const nodePoultry = rawPoultry.filter(farmMatches);
  const nodeFish = rawFish.filter(farmMatches);
  const nodeEmployees = rawEmployees.filter(farmMatches);
  const nodePayslips = rawPayslips.filter(farmMatches);
  const nodeInventory = rawInventory.filter(farmMatches);
  const nodeAssets = rawAssets.filter(farmMatches);
  const nodeInvestments = rawInvestments.filter(farmMatches);
  const nodeLoans = rawLoans.filter(farmMatches);
  const nodePlots = rawPlots.filter(farmMatches);
  const nodeTasks = rawTasks.filter(farmMatches);

  // 1. REVENUE DOMAIN (Actual Captured Sales, Invoices & Other Revenues)
  const periodSales = nodeSales.filter(s => isDateInPeriod(s.date || s.createdAt, start, end));
  const priorSales = nodeSales.filter(s => isDateInPeriod(s.date || s.createdAt, priorRange.start, priorRange.end));
  const yoySales = nodeSales.filter(s => isDateInPeriod(s.date || s.createdAt, yoyRange.start, yoyRange.end));

  const periodInvoices = nodeInvoices.filter(inv => isDateInPeriod(inv.dueDate || inv.issueDate || inv.createdAt, start, end));
  const priorInvoices = nodeInvoices.filter(inv => isDateInPeriod(inv.dueDate || inv.issueDate || inv.createdAt, priorRange.start, priorRange.end));
  const yoyInvoices = nodeInvoices.filter(inv => isDateInPeriod(inv.dueDate || inv.issueDate || inv.createdAt, yoyRange.start, yoyRange.end));

  const periodOtherRev = nodeOtherRevenues.filter(r => isDateInPeriod(r.date || r.createdAt, start, end));
  const priorOtherRev = nodeOtherRevenues.filter(r => isDateInPeriod(r.date || r.createdAt, priorRange.start, priorRange.end));
  const yoyOtherRev = nodeOtherRevenues.filter(r => isDateInPeriod(r.date || r.createdAt, yoyRange.start, yoyRange.end));

  let revenueTotal = 0;
  let cashSales = 0;
  let invoiceSales = 0;
  let contractSales = 0;
  const revByDimension: Record<string, number> = {};

  // Process direct cash sales
  periodSales.forEach(s => {
    const amt = Number(s.amount || (Number(s.quantity || 0) * Number(s.unitPrice || 0)) || 0);
    revenueTotal += amt;

    const pMethod = (s.paymentMethod || s.type || "").toLowerCase();
    const isInv = s.isInvoice || pMethod.includes("invoice") || pMethod.includes("credit");
    const isContract = s.isContract || pMethod.includes("contract") || s.customerType === "offtaker";

    if (isInv) invoiceSales += amt;
    else if (isContract) contractSales += amt;
    else cashSales += amt;

    const dimKey = s.crop || s.item || s.category || s.description || "Cash Crop Sales";
    revByDimension[dimKey] = (revByDimension[dimKey] || 0) + amt;
  });

  // Process commercial invoices
  periodInvoices.forEach(inv => {
    const totalAmt = Number(inv.totalAmount || inv.total || inv.amount || 0);
    const paidAmt = Number(inv.amountPaid !== undefined ? inv.amountPaid : (inv.status === "Paid" ? totalAmt : 0));
    const effectiveAmt = paidAmt > 0 ? paidAmt : totalAmt;
    revenueTotal += effectiveAmt;
    invoiceSales += effectiveAmt;

    const dimKey = inv.customerName || inv.crop || inv.product || "Commercial Invoices";
    revByDimension[dimKey] = (revByDimension[dimKey] || 0) + effectiveAmt;
  });

  // Process other enterprise revenues
  periodOtherRev.forEach(r => {
    const amt = Number(r.amount || 0);
    revenueTotal += amt;
    contractSales += amt;

    const dimKey = r.source || r.category || r.description || "Other Enterprise Revenue";
    revByDimension[dimKey] = (revByDimension[dimKey] || 0) + amt;
  });

  const priorRevTotal = 
    priorSales.reduce((acc, s) => acc + Number(s.amount || (Number(s.quantity || 0) * Number(s.unitPrice || 0)) || 0), 0) +
    priorInvoices.reduce((acc, inv) => acc + Number(inv.totalAmount || inv.amount || 0), 0) +
    priorOtherRev.reduce((acc, r) => acc + Number(r.amount || 0), 0);

  const yoyRevTotal = 
    yoySales.reduce((acc, s) => acc + Number(s.amount || (Number(s.quantity || 0) * Number(s.unitPrice || 0)) || 0), 0) +
    yoyInvoices.reduce((acc, inv) => acc + Number(inv.totalAmount || inv.amount || 0), 0) +
    yoyOtherRev.reduce((acc, r) => acc + Number(r.amount || 0), 0);

  const deltaRevPrior = priorRevTotal > 0 ? Number((((revenueTotal - priorRevTotal) / priorRevTotal) * 100).toFixed(1)) : 0;
  const deltaRevYoy = yoyRevTotal > 0 ? Number((((revenueTotal - yoyRevTotal) / yoyRevTotal) * 100).toFixed(1)) : 0;

  const topStreams = Object.entries(revByDimension)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([name, amount]) => ({
      name,
      amount,
      percentage: revenueTotal > 0 ? Math.round((amount / revenueTotal) * 100) : 0
    }));

  // 2. EXPENSES DOMAIN (Actual Captured Expenses & Payslip Outlays)
  const periodExpenses = nodeExpenses.filter(e => isDateInPeriod(e.date || e.createdAt, start, end));
  const priorExpenses = nodeExpenses.filter(e => isDateInPeriod(e.date || e.createdAt, priorRange.start, priorRange.end));
  const yoyExpenses = nodeExpenses.filter(e => isDateInPeriod(e.date || e.createdAt, yoyRange.start, yoyRange.end));

  const periodPayslips = nodePayslips.filter(p => isDateInPeriod(p.paymentDate || p.createdAt || p.period, start, end));

  let expensesTotal = 0;
  let capex = 0;
  let opex = 0;
  const expByDimension: Record<string, number> = {};

  let feedCostTotal = 0;
  let fertTotal = 0;
  let chemTotal = 0;
  let payrollTotal = 0;
  let machineryCapex = 0;
  let infraCapex = 0;
  let bioAssetCapex = 0;

  const getExpAmount = (e: any): number => {
    return Number(e.amount ?? e.total ?? e.subtotal ?? (Array.isArray(e.rows) && e.rows.length > 0 ? e.rows.reduce((sum: number, r: any) => sum + Number(r.amount || (Number(r.quantity || 0) * Number(r.unitPrice || 0)) || 0), 0) : 0));
  };

  periodExpenses.forEach(e => {
    const amt = getExpAmount(e);
    expensesTotal += amt;

    const cat = (e.category || "").toLowerCase();
    const desc = (e.description || "").toLowerCase();
    const code = String(e.coaCode || "");

    const isCapex = cat.includes("capital") || cat.includes("asset") || cat.includes("equipment") || 
                    cat.includes("machinery") || cat.includes("infrastructure") || cat.includes("borehole") ||
                    code.startsWith("15") || code.startsWith("16");

    if (isCapex) {
      capex += amt;
      if (desc.includes("tractor") || desc.includes("pump") || desc.includes("machine") || desc.includes("vehicle") || desc.includes("implement")) {
        machineryCapex += amt;
      } else if (desc.includes("shed") || desc.includes("pipe") || desc.includes("irrigation") || desc.includes("solar") || desc.includes("borehole")) {
        infraCapex += amt;
      } else {
        bioAssetCapex += amt;
      }
    } else {
      opex += amt;
    }

    // Specific category tracking with full Poultry Account Codes integration
    if (cat.includes("feed") || cat.includes("fodder") || code === "5200" || code === "5210") {
      feedCostTotal += amt;
    } else if (cat.includes("fert") || cat.includes("foliar") || cat.includes("lime") || code === "5310") {
      fertTotal += amt;
    } else if (
      cat.includes("chem") || 
      cat.includes("pesticide") || 
      cat.includes("herbicide") || 
      cat.includes("fungicide") || 
      cat.includes("vet") || 
      cat.includes("med") || 
      cat.includes("vaccin") || 
      cat.includes("drug") || 
      code === "5300" || 
      code === "5215"
    ) {
      chemTotal += amt;
    } else if (cat.includes("labour") || cat.includes("wage") || cat.includes("salary") || cat.includes("payroll") || code === "5100") {
      payrollTotal += amt;
    }

    const dimKey = e.category || "General Operating Expense";
    expByDimension[dimKey] = (expByDimension[dimKey] || 0) + amt;
  });

  // Add payslips if not already counted under expenses
  if (periodPayslips.length > 0 && payrollTotal === 0) {
    periodPayslips.forEach(ps => {
      const netPay = Number(ps.netPay || ps.grossPay || ps.amount || 0);
      expensesTotal += netPay;
      opex += netPay;
      payrollTotal += netPay;
      expByDimension["Labour & Wage Disbursements"] = (expByDimension["Labour & Wage Disbursements"] || 0) + netPay;
    });
  }

  // Include any feed logs not already captured as an explicit expense entry
  const periodFeedLogs = rawFeedLogs.filter(farmMatches).filter(fl => isDateInPeriod(fl.date || fl.loggedAt, start, end));
  periodFeedLogs.forEach(fl => {
    const matchingExpense = periodExpenses.some(e => e.id === `exp_feed_${fl.id}` || (e.description && e.description.includes(fl.id)));
    if (!matchingExpense) {
      const feedCost = Number(fl.totalCost || (Number(fl.totalQuantityFedKg || 0) * Number(fl.formulationSnapshot?.costPerKgMix || 0)) || 0);
      if (feedCost > 0) {
        expensesTotal += feedCost;
        opex += feedCost;
        feedCostTotal += feedCost;
        expByDimension["Feed & Livestock Nutrition"] = (expByDimension["Feed & Livestock Nutrition"] || 0) + feedCost;
      }
    }
  });

  const priorExpTotal = priorExpenses.reduce((acc, e) => acc + getExpAmount(e), 0);
  const yoyExpTotal = yoyExpenses.reduce((acc, e) => acc + getExpAmount(e), 0);

  const deltaExpPrior = priorExpTotal > 0 ? Number((((expensesTotal - priorExpTotal) / priorExpTotal) * 100).toFixed(1)) : 0;
  const deltaExpYoy = yoyExpTotal > 0 ? Number((((expensesTotal - yoyExpTotal) / yoyExpTotal) * 100).toFixed(1)) : 0;

  const topCategories = Object.entries(expByDimension)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([name, amount]) => ({
      name,
      amount,
      percentage: expensesTotal > 0 ? Math.round((amount / expensesTotal) * 100) : 0
    }));

  // 3. CROP PRODUCTION DOMAIN (Actual Crops Captured)
  let totalYieldKg = 0;
  let activeHectares = 0;
  let lossKg = 0;
  const cropByDimension: Record<string, number> = {};
  const cropDetailedMap: Record<string, { yieldKg: number; hectares: number; revenueZmw: number }> = {};

  nodeCrops.forEach(c => {
    const yieldAmount = Number(c.actualYieldKg !== undefined ? c.actualYieldKg : (c.harvestedYieldKg !== undefined ? c.harvestedYieldKg : (c.yieldKg || 0)));
    const ha = Number(c.areaHectares !== undefined ? c.areaHectares : (c.fieldSizeHa !== undefined ? c.fieldSizeHa : (c.hectares || c.area || 0)));
    const loss = Number(c.lossKg || 0);
    const cropName = c.cropName || c.name || "Crop Cycle";

    totalYieldKg += yieldAmount;
    activeHectares += ha;
    lossKg += loss;

    cropByDimension[cropName] = (cropByDimension[cropName] || 0) + yieldAmount;

    if (!cropDetailedMap[cropName]) {
      cropDetailedMap[cropName] = { yieldKg: 0, hectares: 0, revenueZmw: 0 };
    }
    cropDetailedMap[cropName].yieldKg += yieldAmount;
    cropDetailedMap[cropName].hectares += ha;
    cropDetailedMap[cropName].revenueZmw += (revByDimension[cropName] || 0);
  });

  const yieldPerHectare = activeHectares > 0 ? Math.round(totalYieldKg / activeHectares) : 0;
  const costPerHectare = activeHectares > 0 ? Math.round(opex / activeHectares) : 0;

  let totalCropRev = 0;
  Object.values(cropDetailedMap).forEach(cd => { totalCropRev += cd.revenueZmw; });
  const averagePricePerKg = totalYieldKg > 0 && totalCropRev > 0 ? Number((totalCropRev / totalYieldKg).toFixed(2)) : 0;

  // 4. LIVESTOCK PRODUCTION DOMAIN (Actual Livestock & Poultry Captured)
  let poultryCount = 0;
  let poultryPlaced = 0;
  let poultryMortality = 0;
  let poultryWeightKg = 0;
  let poultryFeedConsumedKg = 0;

  const livestockByDimension: Record<string, number> = {};
  const livestockBySpecies: Record<string, { headCount: number; mortalityRatePct: number; avgWeightKg: number }> = {};

  nodePoultry.forEach(p => {
    const current = Number(p.currentHeadcount !== undefined ? p.currentHeadcount : (p.currentCount !== undefined ? p.currentCount : (p.initialHeadcount !== undefined ? p.initialHeadcount : (p.initialCount || 0))));
    const initial = Number(p.initialHeadcount !== undefined ? p.initialHeadcount : (p.initialCount || current));
    const mort = Number(p.totalMortality !== undefined ? p.totalMortality : (p.mortalityCount !== undefined ? p.mortalityCount : (initial - current > 0 ? initial - current : 0)));
    const avgWeight = Number(p.averageWeightKg || p.currentWeight || (p.type === "layer" ? 1.9 : 1.8));
    const feedKg = Number(p.totalFeedKg !== undefined ? p.totalFeedKg : (p.feedConsumedKg || 0));

    poultryCount += current;
    poultryPlaced += initial;
    poultryMortality += mort;
    poultryWeightKg += current * avgWeight;
    poultryFeedConsumedKg += feedKg;

    const breedKey = p.batchName || p.breed || "Poultry Flock";
    livestockByDimension[breedKey] = (livestockByDimension[breedKey] || 0) + current;

    const speciesKey = p.species || (p.type ? `Poultry (${p.type})` : "Poultry");
    if (!livestockBySpecies[speciesKey]) {
      livestockBySpecies[speciesKey] = { headCount: 0, mortalityRatePct: 0, avgWeightKg: avgWeight };
    }
    livestockBySpecies[speciesKey].headCount += current;
  });

  let mammalianCount = 0;
  let mammalianWeightKg = 0;
  nodeLivestock.forEach(l => {
    mammalianCount += 1;
    const w = Number(l.currentWeight || l.weightKg || 0);
    mammalianWeightKg += w;

    const sp = l.species || "Livestock";
    livestockByDimension[sp] = (livestockByDimension[sp] || 0) + 1;

    if (!livestockBySpecies[sp]) {
      livestockBySpecies[sp] = { headCount: 0, mortalityRatePct: 0, avgWeightKg: w };
    }
    livestockBySpecies[sp].headCount += 1;
  });

  let fishCount = 0;
  let fishWeightKg = 0;
  nodeFish.forEach(fb => {
    const count = Number(fb.currentCount || fb.stockCount || fb.initialCount || 0);
    const avgW = Number(fb.averageWeightGrams ? fb.averageWeightGrams / 1000 : (fb.averageWeightKg || 0.45));
    const wKg = count * avgW;
    fishCount += count;
    fishWeightKg += wKg;

    const sp = fb.species || "Aquaculture (Fish)";
    livestockByDimension[sp] = (livestockByDimension[sp] || 0) + count;
    if (!livestockBySpecies[sp]) {
      livestockBySpecies[sp] = { headCount: 0, mortalityRatePct: 0, avgWeightKg: avgW };
    }
    livestockBySpecies[sp].headCount += count;
  });

  const totalHeadCount = poultryCount + mammalianCount + fishCount;
  const totalWeightKg = Math.round(poultryWeightKg + mammalianWeightKg + fishWeightKg);
  const totalPlaced = poultryPlaced + mammalianCount + fishCount;
  const mortalityRatePct = totalPlaced > 0 ? Number(((poultryMortality / totalPlaced) * 100).toFixed(1)) : 0;
  const fcr = (poultryWeightKg > 0 && poultryFeedConsumedKg > 0) ? Number((poultryFeedConsumedKg / poultryWeightKg).toFixed(2)) : 0;

  // 5. FEEDING COSTS DOMAIN
  let extraFeedLogsCost = 0;
  let extraFeedConsumedKg = 0;
  rawFeedLogs.forEach(fl => {
    extraFeedLogsCost += Number(fl.cost || (Number(fl.quantityKg || 0) * Number(fl.unitCost || 0)) || 0);
    extraFeedConsumedKg += Number(fl.quantityKg || 0);
  });

  const finalFeedCost = feedCostTotal > 0 ? feedCostTotal : extraFeedLogsCost;
  const totalFeedConsumedKg = poultryFeedConsumedKg + extraFeedConsumedKg;
  const feedCostPerKgGain = totalWeightKg > 0 && finalFeedCost > 0 ? Number((finalFeedCost / totalWeightKg).toFixed(2)) : 0;

  // 6. LABOUR COSTS DOMAIN
  let employeeSalaries = 0;
  let permWages = 0;
  let activeWorkers = 0;

  nodeEmployees.forEach(e => {
    if (e.status !== "Terminated" && e.status !== "Inactive") {
      activeWorkers += 1;
      const sal = Number(e.salary || 0);
      employeeSalaries += sal;
      if (e.employmentType === "permanent" || e.employmentType === "Full-Time") {
        permWages += sal;
      }
    }
  });

  const finalLabourTotal = payrollTotal > 0 ? payrollTotal : employeeSalaries;
  const labourCostPerHa = activeHectares > 0 ? Math.round(finalLabourTotal / activeHectares) : 0;
  const labourCostPerHead = totalHeadCount > 0 ? Math.round(finalLabourTotal / totalHeadCount) : 0;

  // 7. FERTILIZER & CHEMICAL COSTS DOMAIN
  const fertChemTotal = fertTotal + chemTotal;
  const fertChemCostPerHa = activeHectares > 0 ? Math.round(fertChemTotal / activeHectares) : 0;

  // 8. LAND UTILIZATION DOMAIN
  let registeredFarmHectares = Number(activeFarm.totalHectares || activeFarm.sizeHa || activeFarm.hectares || 0);
  let plotHectaresSum = 0;
  const landByDimension: Record<string, number> = {};

  nodePlots.forEach(p => {
    const area = Number(p.areaHa || p.area || p.hectares || 0);
    plotHectaresSum += area;
    const name = p.name || p.plotName || "Field Block";
    landByDimension[name] = (landByDimension[name] || 0) + area;
  });

  const totalFarmHectares = registeredFarmHectares > 0 ? registeredFarmHectares : (plotHectaresSum > 0 ? plotHectaresSum : (activeHectares > 0 ? activeHectares : 0));
  const landUtilPct = totalFarmHectares > 0 ? Number(((activeHectares / totalFarmHectares) * 100).toFixed(1)) : 0;

  // 9. INVESTMENTS DOMAIN
  const invByDimension: Record<string, number> = {};
  if (machineryCapex > 0) invByDimension["Machinery & Implements"] = machineryCapex;
  if (infraCapex > 0) invByDimension["Farm Infrastructure & Irrigation"] = infraCapex;
  if (bioAssetCapex > 0) invByDimension["Biological & Tree Assets"] = bioAssetCapex;

  // Add recorded capital assets
  nodeAssets.forEach(a => {
    const val = Number(a.purchasePrice || a.cost || a.currentValue || a.value || 0);
    if (val > 0) {
      const cat = a.category || a.type || a.name || "Capital Assets";
      invByDimension[cat] = (invByDimension[cat] || 0) + val;
    }
  });

  // Add recorded investment projects
  nodeInvestments.forEach(inv => {
    const amt = Number(inv.amount || inv.investedAmount || 0);
    if (amt > 0) {
      const title = inv.title || inv.projectName || inv.name || "Capital Projects";
      invByDimension[title] = (invByDimension[title] || 0) + amt;
    }
  });

  // 10. CREDIT FINANCING DOMAIN
  let totalBorrowed = 0;
  let principalRepaid = 0;
  let outstandingCredit = 0;
  const creditByDimension: Record<string, number> = {};

  nodeLoans.forEach(l => {
    const princ = Number(l.principal || l.amount || 0);
    const bal = Number(l.balance !== undefined ? l.balance : princ);
    const repaid = Number(l.repaidAmount || (princ - bal > 0 ? princ - bal : 0));

    totalBorrowed += princ;
    principalRepaid += repaid;
    outstandingCredit += bal;

    const lenderKey = l.lender || l.institution || "Credit Facility";
    creditByDimension[lenderKey] = (creditByDimension[lenderKey] || 0) + bal;
  });

  // 11. CASH & WALLET DOMAIN
  const cashInflows = cashSales;
  const cashOutflows = expensesTotal;
  const netCashFlow = cashInflows - cashOutflows;
  
  let walletEnding = netCashFlow;
  if (context.walletBalances && context.walletBalances.totalBalance !== undefined) {
    walletEnding = Number(context.walletBalances.totalBalance);
  } else if (activeFarm.walletBalance !== undefined) {
    walletEnding = Number(activeFarm.walletBalance);
  }

  // 12. PROFITABILITY DOMAIN
  const directCogs = finalFeedCost + fertChemTotal + finalLabourTotal;
  const grossProfit = revenueTotal - directCogs;
  const grossMarginPct = revenueTotal > 0 ? Number(((grossProfit / revenueTotal) * 100).toFixed(1)) : 0;
  const netProfit = revenueTotal - expensesTotal;
  const netMarginPct = revenueTotal > 0 ? Number(((netProfit / revenueTotal) * 100).toFixed(1)) : 0;
  const ebitda = netProfit + Math.round(capex * 0.1);

  const deltaProfit = priorRevTotal > 0 ? Number((((netProfit - (priorRevTotal - priorExpTotal)) / Math.max(1, Math.abs(priorRevTotal - priorExpTotal))) * 100).toFixed(1)) : 0;

  const domains: FbiDomains = {
    revenue: {
      total: revenueTotal,
      cashSales,
      invoiceSales,
      contractSales,
      byDimension: revByDimension,
      deltaPriorPeriodPct: deltaRevPrior,
      deltaYoyPct: deltaRevYoy,
      topStreams
    },
    expenses: {
      total: expensesTotal,
      opex,
      capex,
      costPerHectare,
      byDimension: expByDimension,
      deltaPriorPeriodPct: deltaExpPrior,
      deltaYoyPct: deltaExpYoy,
      topCategories
    },
    cropProduction: {
      total: totalYieldKg,
      totalYieldKg,
      yieldPerHectare,
      activeHectares,
      lossKg,
      averagePricePerKg,
      byDimension: cropByDimension,
      byCrop: cropDetailedMap,
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    livestockProduction: {
      total: totalHeadCount,
      headCount: totalHeadCount,
      mortalityRatePct,
      totalWeightKg,
      fcr,
      averageDailyGainKg: 0,
      byDimension: livestockByDimension,
      bySpecies: livestockBySpecies,
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    feedingCosts: {
      total: finalFeedCost,
      totalCost: finalFeedCost,
      feedCostPerKgGain,
      feedConsumedKg: totalFeedConsumedKg,
      commercialFeedCost: finalFeedCost,
      onFarmFeedCost: 0,
      byDimension: { "Commercial & Farm Feeds": finalFeedCost },
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    labourCosts: {
      total: finalLabourTotal,
      permanentWages: permWages,
      casualWages: Math.max(0, finalLabourTotal - permWages),
      costPerHectare: labourCostPerHa,
      costPerHead: labourCostPerHead,
      activeWorkers,
      byDimension: { "Farm Operations Payroll": finalLabourTotal },
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    fertilizerChemicalCosts: {
      total: fertChemTotal,
      fertilizerTotal: fertTotal,
      chemicalTotal: chemTotal,
      costPerHectare: fertChemCostPerHa,
      byDimension: { "Fertilizer & Nutrition": fertTotal, "Pesticides & Crop Protection": chemTotal },
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    landUtilization: {
      total: totalFarmHectares,
      totalHectares: totalFarmHectares,
      cultivatedHectares: activeHectares,
      orchardHectares: 0,
      pastureHectares: 0,
      infrastructureHectares: 0,
      utilizationRatePct: landUtilPct,
      byDimension: landByDimension,
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    investments: {
      total: capex,
      totalCapex: capex,
      machineryEquipment: machineryCapex,
      infrastructure: infraCapex,
      biologicalAssets: bioAssetCapex,
      byDimension: invByDimension,
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    creditFinancing: {
      total: outstandingCredit,
      totalBorrowed,
      principalRepaid,
      interestPaid: 0,
      outstandingBalance: outstandingCredit,
      debtServiceCoverageRatio: (principalRepaid > 0 && opex > 0) ? Number(((revenueTotal - opex) / principalRepaid).toFixed(1)) : 0,
      byDimension: creditByDimension,
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    cashWallet: {
      total: walletEnding,
      inflows: cashInflows,
      outflows: cashOutflows,
      netCashFlow,
      endingBalance: walletEnding,
      byDimension: { "Cash & Digital Wallet": walletEnding },
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    profitability: {
      total: netProfit,
      grossProfit,
      grossMarginPct,
      netProfit,
      netMarginPct,
      ebitda,
      returnOnAssetsPct: 0,
      byDimension: { "Operational Net Margin": netProfit },
      deltaPriorPeriodPct: deltaProfit,
      deltaYoyPct: 0
    }
  };

  const fbiInsight = generateFbiInsightEngine(domains, farmNodeName, false);

  return {
    tenantId,
    farmNodeId,
    farmNodeName,
    period,
    computedAt: new Date().toISOString(),
    domains,
    fbiInsight,
    sourceRollupVersions: {
      reportCentre: "v1.4",
      orchardFinance: "v1.2",
      coa: "v2.0"
    }
  };
}

/**
 * Computes AI commentary and driver attributions strictly based on actual computed domain rollups.
 */
export function generateFbiInsightEngine(
  domains: FbiDomains, 
  farmName: string = "Farm",
  isMultiNode: boolean = false
): FbiInsight {
  const rev = domains.revenue;
  const exp = domains.expenses;
  const prof = domains.profitability;
  const crop = domains.cropProduction;
  const live = domains.livestockProduction;
  const feed = domains.feedingCosts;

  const drivers: FbiInsightDriver[] = [];
  const recommendations: string[] = [];

  // Zero-State Guard: If no operational records exist in this period
  if (rev.total === 0 && exp.total === 0 && crop.totalYieldKg === 0 && live.headCount === 0) {
    return {
      headline: `${farmName}: No Operational Records Logged for this Period`,
      summary: `No sales, expenses, crop harvests, or livestock batch records were captured for this period. Live intelligence insights will automatically populate as data is inputted.`,
      drivers: [
        {
          dimension: "Data Intake",
          impact: "neutral",
          detail: "Awaiting real-time user inputs across sales, expenses, crops, or livestock batches.",
          attributionPct: 0
        }
      ],
      recommendations: [
        "Record cash sales and offtake transactions to track revenue velocity.",
        "Input farm operating expenses (feed, fertilizer, labour) to enable margin analytics.",
        "Log crop harvest yields and active plot hectares to monitor yield-per-hectare efficiency."
      ],
      generatedAt: new Date().toISOString()
    };
  }

  // Revenue Driver
  if (rev.total > 0) {
    if (rev.deltaPriorPeriodPct >= 5) {
      drivers.push({
        dimension: "Revenue Growth",
        impact: "positive",
        detail: `Actual revenue increased by +${rev.deltaPriorPeriodPct.toFixed(1)}% vs prior period based on captured sales transactions.`,
        attributionPct: Math.min(100, Math.round(rev.deltaPriorPeriodPct * 1.2))
      });
    } else if (rev.deltaPriorPeriodPct <= -5) {
      drivers.push({
        dimension: "Revenue Contraction",
        impact: "negative",
        detail: `Actual revenue decreased by ${rev.deltaPriorPeriodPct.toFixed(1)}% vs prior period.`,
        attributionPct: Math.min(100, Math.round(Math.abs(rev.deltaPriorPeriodPct)))
      });
    } else {
      drivers.push({
        dimension: "Revenue Volume",
        impact: "neutral",
        detail: `Logged sales volume total stands at ZMW ${Math.round(rev.total).toLocaleString()} across ${Object.keys(rev.byDimension).length} revenue streams.`,
        attributionPct: 20
      });
    }
  }

  // Margin / Profit Driver
  if (rev.total > 0 || exp.total > 0) {
    if (prof.netMarginPct >= 20) {
      drivers.push({
        dimension: "Healthy Operating Margin",
        impact: "positive",
        detail: `Net operational margin achieved ${prof.netMarginPct.toFixed(1)}% (Gross Margin: ${prof.grossMarginPct.toFixed(1)}%).`,
        attributionPct: 35
      });
    } else if (prof.netMarginPct < 10 && exp.total > 0) {
      drivers.push({
        dimension: "Operating Margin Pressure",
        impact: "negative",
        detail: `Net profit margin is ${prof.netMarginPct.toFixed(1)}% against captured operating expenditures of ZMW ${Math.round(exp.total).toLocaleString()}.`,
        attributionPct: 35
      });
      recommendations.push("Review high-value operational expense categories to identify input cost efficiencies.");
    }
  }

  // Crop / Yield Driver
  if (crop.activeHectares > 0) {
    if (crop.yieldPerHectare >= 4000) {
      drivers.push({
        dimension: "Crop Yield Efficiency",
        impact: "positive",
        detail: `Harvest yield reached ${Math.round(crop.yieldPerHectare).toLocaleString()} kg/ha across ${crop.activeHectares} active hectares.`,
        attributionPct: 25
      });
    } else {
      drivers.push({
        dimension: "Crop Yield Output",
        impact: crop.yieldPerHectare < 2000 ? "negative" : "neutral",
        detail: `Recorded harvest yield is ${Math.round(crop.yieldPerHectare).toLocaleString()} kg/ha across ${crop.activeHectares} hectares.`,
        attributionPct: 20
      });
      if (crop.lossKg > 0) {
        recommendations.push(`Captured post-harvest loss of ${crop.lossKg.toLocaleString()} kg. Review storage and crate handling.`);
      }
    }
  }

  // Livestock / FCR Driver
  if (live.headCount > 0) {
    if (live.fcr > 0 && live.fcr <= 1.75) {
      drivers.push({
        dimension: "Feed Conversion Efficiency",
        impact: "positive",
        detail: `Livestock FCR is running efficiently at ${live.fcr.toFixed(2)} across ${live.headCount} heads.`,
        attributionPct: 20
      });
    } else if (live.fcr > 1.85) {
      drivers.push({
        dimension: "Elevated FCR Warning",
        impact: "negative",
        detail: `FCR is measured at ${live.fcr.toFixed(2)}. Feed spillage or ventilation adjustments recommended.`,
        attributionPct: 25
      });
      recommendations.push("Audit livestock feed trough heights to prevent feed spillage.");
    }
  }

  // Default recommendations if none triggered
  if (recommendations.length === 0) {
    recommendations.push("Continue recording real-time field harvests and invoice dispatches.");
    recommendations.push("Reconcile wallet transactions against daily cash sale logs.");
  }

  const headline = prof.netProfit >= 0
    ? `${farmName}: Operational Output Summary (Net Margin: ${prof.netMarginPct.toFixed(1)}%)`
    : `${farmName}: Operational Summary (Net Loss: ZMW ${Math.abs(Math.round(prof.netProfit)).toLocaleString()})`;

  const summary = `${isMultiNode ? "Consolidated multi-node performance logs show" : "Farm performance indicates"} total revenue of ZMW ${Math.round(rev.total).toLocaleString()} against captured expenses of ZMW ${Math.round(exp.total).toLocaleString()}, resulting in an operational net balance of ZMW ${Math.round(prof.netProfit).toLocaleString()}.`;

  return {
    headline,
    summary,
    drivers,
    recommendations,
    generatedAt: new Date().toISOString()
  };
}

/**
 * Builds consolidated rollup across actual farm nodes for a tenant.
 */
export function buildConsolidatedTenantRollup(
  tenantId: string,
  nodeRollups: FbiNodeRollup[],
  period: FbiPeriod
): FbiTenantRollup {
  if (nodeRollups.length === 0) {
    const emptyRollup = computeRealNodeRollup(tenantId, "default", "Main Farm", period, {});
    return {
      tenantId,
      period,
      computedAt: new Date().toISOString(),
      domains: emptyRollup.domains,
      byFarmNode: {},
      fbiInsight: generateFbiInsightEngine(emptyRollup.domains, "Consolidated View", true),
      sourceRollupVersions: {
        reportCentre: "v1.4",
        orchardFinance: "v1.2",
        coa: "v2.0"
      }
    };
  }

  const byFarmNode: Record<string, FbiFarmNodeComparisonItem> = {};

  let sumRevenue = 0;
  let sumCashSales = 0;
  let sumInvoiceSales = 0;
  let sumContractSales = 0;

  let sumExpenses = 0;
  let sumOpex = 0;
  let sumCapex = 0;

  let sumCropYieldKg = 0;
  let sumActiveHectares = 0;
  let sumCropLossKg = 0;

  let sumHeadCount = 0;
  let sumTotalWeightKg = 0;
  let weightedFcrSum = 0;
  let weightedMortalitySum = 0;

  let sumFeedCost = 0;
  let sumLabourCost = 0;
  let sumFertChemCost = 0;

  let sumTotalHectares = 0;
  let sumCultivatedHectares = 0;

  let sumCashEnding = 0;
  let sumNetCashFlow = 0;

  const combinedRevDimensions: Record<string, number> = {};
  const combinedExpDimensions: Record<string, number> = {};
  const combinedCropDimensions: Record<string, number> = {};

  for (const nr of nodeRollups) {
    const d = nr.domains;
    const nId = nr.farmNodeId;
    const nName = nr.farmNodeName || `Node ${nId}`;

    byFarmNode[nId] = {
      farmNodeId: nId,
      farmNodeName: nName,
      revenue: d.revenue.total,
      expenses: d.expenses.total,
      netProfit: d.profitability.netProfit,
      netMarginPct: d.profitability.netMarginPct,
      cropYieldKg: d.cropProduction.totalYieldKg,
      fcr: d.livestockProduction.fcr,
      landUtilizationPct: d.landUtilization.utilizationRatePct,
      costPerHectare: d.expenses.costPerHectare,
      domains: d
    };

    sumRevenue += d.revenue.total;
    sumCashSales += d.revenue.cashSales || 0;
    sumInvoiceSales += d.revenue.invoiceSales || 0;
    sumContractSales += d.revenue.contractSales || 0;

    sumExpenses += d.expenses.total;
    sumOpex += d.expenses.opex || 0;
    sumCapex += d.expenses.capex || 0;

    sumCropYieldKg += d.cropProduction.totalYieldKg || 0;
    sumActiveHectares += d.cropProduction.activeHectares || 0;
    sumCropLossKg += d.cropProduction.lossKg || 0;

    sumHeadCount += d.livestockProduction.headCount || 0;
    sumTotalWeightKg += d.livestockProduction.totalWeightKg || 0;
    weightedFcrSum += (d.livestockProduction.fcr || 0) * (d.livestockProduction.headCount || 1);
    weightedMortalitySum += (d.livestockProduction.mortalityRatePct || 0) * (d.livestockProduction.headCount || 1);

    sumFeedCost += d.feedingCosts.totalCost || 0;
    sumLabourCost += d.labourCosts.total || 0;
    sumFertChemCost += d.fertilizerChemicalCosts.total || 0;

    sumTotalHectares += d.landUtilization.totalHectares || 0;
    sumCultivatedHectares += d.landUtilization.cultivatedHectares || 0;

    sumCashEnding += d.cashWallet.endingBalance || 0;
    sumNetCashFlow += d.cashWallet.netCashFlow || 0;

    Object.entries(d.revenue.byDimension || {}).forEach(([k, v]) => {
      combinedRevDimensions[`[${nName}] ${k}`] = (combinedRevDimensions[`[${nName}] ${k}`] || 0) + v;
    });
    Object.entries(d.expenses.byDimension || {}).forEach(([k, v]) => {
      combinedExpDimensions[`[${nName}] ${k}`] = (combinedExpDimensions[`[${nName}] ${k}`] || 0) + v;
    });
    Object.entries(d.cropProduction.byDimension || {}).forEach(([k, v]) => {
      combinedCropDimensions[`[${nName}] ${k}`] = (combinedCropDimensions[`[${nName}] ${k}`] || 0) + v;
    });
  }

  const consolidatedProfit = sumRevenue - sumExpenses;
  const consolidatedMarginPct = sumRevenue > 0 ? Number(((consolidatedProfit / sumRevenue) * 100).toFixed(1)) : 0;
  const consolidatedFcr = sumHeadCount > 0 ? Number((weightedFcrSum / sumHeadCount).toFixed(2)) : 0;
  const consolidatedMortalityPct = sumHeadCount > 0 ? Number((weightedMortalitySum / sumHeadCount).toFixed(1)) : 0;

  const consolidatedDomains: FbiDomains = {
    revenue: {
      total: sumRevenue,
      cashSales: sumCashSales,
      invoiceSales: sumInvoiceSales,
      contractSales: sumContractSales,
      byDimension: combinedRevDimensions,
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0,
      topStreams: Object.entries(combinedRevDimensions)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([name, amount]) => ({
          name,
          amount,
          percentage: sumRevenue > 0 ? Math.round((amount / sumRevenue) * 100) : 0
        }))
    },
    expenses: {
      total: sumExpenses,
      opex: sumOpex,
      capex: sumCapex,
      costPerHectare: sumActiveHectares > 0 ? Math.round(sumOpex / sumActiveHectares) : 0,
      byDimension: combinedExpDimensions,
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0,
      topCategories: Object.entries(combinedExpDimensions)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([name, amount]) => ({
          name,
          amount,
          percentage: sumExpenses > 0 ? Math.round((amount / sumExpenses) * 100) : 0
        }))
    },
    cropProduction: {
      total: sumCropYieldKg,
      totalYieldKg: sumCropYieldKg,
      yieldPerHectare: sumActiveHectares > 0 ? Math.round(sumCropYieldKg / sumActiveHectares) : 0,
      activeHectares: sumActiveHectares,
      lossKg: sumCropLossKg,
      averagePricePerKg: sumCropYieldKg > 0 ? Number((sumRevenue / sumCropYieldKg).toFixed(2)) : 0,
      byDimension: combinedCropDimensions,
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    livestockProduction: {
      total: sumHeadCount,
      headCount: sumHeadCount,
      mortalityRatePct: consolidatedMortalityPct,
      totalWeightKg: sumTotalWeightKg,
      fcr: consolidatedFcr,
      averageDailyGainKg: 0,
      byDimension: {},
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    feedingCosts: {
      total: sumFeedCost,
      totalCost: sumFeedCost,
      feedCostPerKgGain: sumTotalWeightKg > 0 ? Number((sumFeedCost / sumTotalWeightKg).toFixed(2)) : 0,
      feedConsumedKg: 0,
      commercialFeedCost: sumFeedCost,
      onFarmFeedCost: 0,
      byDimension: {},
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    labourCosts: {
      total: sumLabourCost,
      permanentWages: sumLabourCost,
      casualWages: 0,
      costPerHectare: sumActiveHectares > 0 ? Math.round(sumLabourCost / sumActiveHectares) : 0,
      costPerHead: sumHeadCount > 0 ? Math.round(sumLabourCost / sumHeadCount) : 0,
      activeWorkers: nodeRollups.reduce((acc, nr) => acc + (nr.domains.labourCosts.activeWorkers || 0), 0),
      byDimension: {},
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    fertilizerChemicalCosts: {
      total: sumFertChemCost,
      fertilizerTotal: sumFertChemCost,
      chemicalTotal: 0,
      costPerHectare: sumActiveHectares > 0 ? Math.round(sumFertChemCost / sumActiveHectares) : 0,
      byDimension: {},
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    landUtilization: {
      total: sumTotalHectares,
      totalHectares: sumTotalHectares,
      cultivatedHectares: sumCultivatedHectares,
      orchardHectares: 0,
      pastureHectares: 0,
      infrastructureHectares: 0,
      utilizationRatePct: sumTotalHectares > 0 ? Number(((sumCultivatedHectares / sumTotalHectares) * 100).toFixed(1)) : 0,
      byDimension: {},
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    investments: {
      total: sumCapex,
      totalCapex: sumCapex,
      machineryEquipment: sumCapex,
      infrastructure: 0,
      biologicalAssets: 0,
      byDimension: {},
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    creditFinancing: {
      total: 0,
      totalBorrowed: 0,
      principalRepaid: 0,
      interestPaid: 0,
      outstandingBalance: 0,
      debtServiceCoverageRatio: 0,
      byDimension: {},
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    cashWallet: {
      total: sumCashEnding,
      inflows: sumCashSales,
      outflows: sumExpenses,
      netCashFlow: sumNetCashFlow,
      endingBalance: sumCashEnding,
      byDimension: {},
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    },
    profitability: {
      total: consolidatedProfit,
      grossProfit: consolidatedProfit,
      grossMarginPct: consolidatedMarginPct,
      netProfit: consolidatedProfit,
      netMarginPct: consolidatedMarginPct,
      ebitda: consolidatedProfit,
      returnOnAssetsPct: 0,
      byDimension: {},
      deltaPriorPeriodPct: 0,
      deltaYoyPct: 0
    }
  };

  return {
    tenantId,
    period,
    computedAt: new Date().toISOString(),
    domains: consolidatedDomains,
    byFarmNode,
    fbiInsight: generateFbiInsightEngine(consolidatedDomains, "All Farm Nodes (Consolidated)", true),
    sourceRollupVersions: {
      reportCentre: "v1.4",
      orchardFinance: "v1.2",
      coa: "v2.0"
    }
  };
}

import { db, isConfigured } from "../firebase";
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  deleteDoc, 
  query, 
  where,
  serverTimestamp 
} from "firebase/firestore";
import { 
  TenantRecord, 
  TenantCategory, 
  TenantDepartment, 
  TenantRole, 
  MakerCheckerConfig, 
  TenantTemplatePreset, 
  GranularPermission,
  UserMember,
  PredefinedRole 
} from "../types";
import { safeLocalStorage as localStorage, safeParseJSON } from "../utils/safeStorage";
import { recordSubUserAuditLog } from "./auditLogService";
import { SYSTEM_MODULES } from "../components/AccessControlPanel";

// ============================================================================
// Section 6.5 Entity Templates Configuration
// ============================================================================

export const TENANT_TEMPLATES: TenantTemplatePreset[] = [
  {
    id: "template-ranching",
    name: "Ranching & Livestock Enterprise",
    category: "ranching",
    description: "Tailored for cattle, small ruminants, piggeries, feedlots, and grazing pastures with veterinary compliance.",
    iconName: "Beef",
    badgeColor: "bg-amber-100 text-amber-800 border-amber-300",
    defaultDepartments: [
      { name: "Executive & Strategy", code: "EXEC", description: "Ranch governance, capital budgeting, and strategic direction" },
      { name: "Livestock Operations", code: "OPS", description: "Herd management, breeding, calving, farrowing, and daily yard routines" },
      { name: "Veterinary & Animal Health", code: "VET", description: "Vaccination regimens, quarantine, herd diagnostics, and treatment records" },
      { name: "Pasture & Feed Formulation", code: "FEED", description: "Paddock grazing rotations, silage production, and ration formulation" },
      { name: "Finance & Accounts", code: "FIN", description: "Livestock valuation, operating expenses, sales invoices, and payroll" }
    ],
    defaultRoles: [
      {
        name: "Ranch General Manager",
        description: "Full operational oversight over herd, pastures, personnel, and finances",
        departmentCode: "EXEC",
        isTenantAdmin: true,
        permittedModules: ["dashboard", "livestock", "feed", "accounts", "expenses", "sales", "invoices", "payroll", "reports", "weather"],
        modulePermissions: {
          dashboard: { read: true, write: true, delete: true, approve: true },
          livestock: { read: true, write: true, delete: true, approve: true },
          feed: { read: true, write: true, delete: true, approve: true },
          accounts: { read: true, write: true, delete: true, approve: true },
          expenses: { read: true, write: true, delete: true, approve: true },
          sales: { read: true, write: true, delete: true, approve: true },
          invoices: { read: true, write: true, delete: true, approve: true },
          payroll: { read: true, write: true, delete: true, approve: true },
          reports: { read: true, write: true, delete: true, approve: true },
          weather: { read: true, write: true, delete: false, approve: false }
        }
      },
      {
        name: "Head Veterinary Officer",
        description: "Administers health logs, vaccine schedules, withdrawal periods, and livestock certifications",
        departmentCode: "VET",
        isTenantAdmin: false,
        permittedModules: ["dashboard", "livestock", "feed", "weather"],
        modulePermissions: {
          dashboard: { read: true, write: false, delete: false, approve: false },
          livestock: { read: true, write: true, delete: false, approve: true },
          feed: { read: true, write: true, delete: false, approve: false },
          weather: { read: true, write: false, delete: false, approve: false }
        }
      },
      {
        name: "Stockman & Herd Supervisor",
        description: "Logs daily livestock counts, weight gains, feed distribution, and mortality",
        departmentCode: "OPS",
        isTenantAdmin: false,
        permittedModules: ["livestock", "feed"],
        modulePermissions: {
          livestock: { read: true, write: true, delete: false, approve: false },
          feed: { read: true, write: true, delete: false, approve: false }
        }
      },
      {
        name: "Ranch Accountant",
        description: "Manages cattle sales, slaughter receipts, input purchases, payroll, and financial reports",
        departmentCode: "FIN",
        isTenantAdmin: false,
        permittedModules: ["dashboard", "accounts", "expenses", "sales", "invoices", "payroll", "reports"],
        modulePermissions: {
          dashboard: { read: true, write: false, delete: false, approve: false },
          accounts: { read: true, write: true, delete: false, approve: false },
          expenses: { read: true, write: true, delete: false, approve: false },
          sales: { read: true, write: true, delete: false, approve: false },
          invoices: { read: true, write: true, delete: false, approve: false },
          payroll: { read: true, write: true, delete: false, approve: false },
          reports: { read: true, write: true, delete: false, approve: false }
        }
      }
    ],
    defaultAccounts: [
      { code: "1010", name: "Operating Bank Account", type: "Asset", category: "Cash & Equivalents" },
      { code: "1020", name: "Mobile Money Merchant Wallet", type: "Asset", category: "Cash & Equivalents" },
      { code: "1510", name: "Breeding Cattle Herd Valuation", type: "Asset", category: "Biological Assets" },
      { code: "1520", name: "Feedlot & Slaughter Steers", type: "Asset", category: "Current Biological Assets" },
      { code: "4010", name: "Livestock Sales Revenue", type: "Revenue", category: "Operating Revenue" },
      { code: "5010", name: "Veterinary Supplies & Vaccines", type: "Expense", category: "Direct Costs" },
      { code: "5020", name: "Concentrates, Hay & Silage", type: "Expense", category: "Direct Costs" }
    ],
    recommendedModules: ["livestock", "feed", "accounts", "expenses", "sales", "invoices", "payroll", "reports", "weather"]
  },
  {
    id: "template-crop",
    name: "Commercial Crop Production",
    category: "crop",
    description: "Designed for grain, horticulture, pivot irrigation, orchards, and multi-block crop cycles.",
    iconName: "Sprout",
    badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-300",
    defaultDepartments: [
      { name: "Executive & Farm Management", code: "EXEC", description: "Farm strategy, seasonal budgeting, and commodity sales agreements" },
      { name: "Agronomy & Field Blocks", code: "AGRO", description: "Soil tests, crop cycle planning, scouting, and pesticide applications" },
      { name: "Irrigation & Mechanization", code: "MECH", description: "Center pivots, drip lines, tractors, implements, and fuel management" },
      { name: "Warehousing & Grain Storage", code: "STORE", description: "Silos, seed stock, fertilizer inventories, and electronic warehouse receipts" },
      { name: "Finance & Administration", code: "FIN", description: "Operating costs, invoice settlements, casual labor payroll, and tax" }
    ],
    defaultRoles: [
      {
        name: "Chief Agronomist",
        description: "Authorizes spraying prescriptions, planting schedules, fertilizer rates, and harvest milestones",
        departmentCode: "AGRO",
        isTenantAdmin: false,
        permittedModules: ["dashboard", "crops", "orchard", "inventory", "weather"],
        modulePermissions: {
          dashboard: { read: true, write: false, delete: false, approve: false },
          crops: { read: true, write: true, delete: true, approve: true },
          orchard: { read: true, write: true, delete: false, approve: true },
          inventory: { read: true, write: true, delete: false, approve: false },
          weather: { read: true, write: false, delete: false, approve: false }
        }
      },
      {
        name: "Field Block Supervisor",
        description: "Logs daily scouting, weeding, labor hours, and chemical application records",
        departmentCode: "AGRO",
        isTenantAdmin: false,
        permittedModules: ["crops", "weather"],
        modulePermissions: {
          crops: { read: true, write: true, delete: false, approve: false },
          weather: { read: true, write: false, delete: false, approve: false }
        }
      },
      {
        name: "Commercial Farm Manager",
        description: "Full administrative and financial authority over crop enterprise operations",
        departmentCode: "EXEC",
        isTenantAdmin: true,
        permittedModules: ["dashboard", "crops", "orchard", "inventory", "accounts", "expenses", "sales", "invoices", "payroll", "reports", "weather"],
        modulePermissions: {
          dashboard: { read: true, write: true, delete: true, approve: true },
          crops: { read: true, write: true, delete: true, approve: true },
          orchard: { read: true, write: true, delete: true, approve: true },
          inventory: { read: true, write: true, delete: true, approve: true },
          accounts: { read: true, write: true, delete: true, approve: true },
          expenses: { read: true, write: true, delete: true, approve: true },
          sales: { read: true, write: true, delete: true, approve: true },
          invoices: { read: true, write: true, delete: true, approve: true },
          payroll: { read: true, write: true, delete: true, approve: true },
          reports: { read: true, write: true, delete: true, approve: true },
          weather: { read: true, write: true, delete: false, approve: false }
        }
      }
    ],
    defaultAccounts: [
      { code: "1010", name: "Corporate Operations Account", type: "Asset", category: "Cash & Equivalents" },
      { code: "1410", name: "Seed & Chemical Inventory", type: "Asset", category: "Current Assets" },
      { code: "1420", name: "Harvested Grain in Silos", type: "Asset", category: "Current Assets" },
      { code: "4010", name: "Grain & Crop Sales Revenue", type: "Revenue", category: "Operating Revenue" },
      { code: "5010", name: "Fertilizer & Lime", type: "Expense", category: "Direct Crop Inputs" },
      { code: "5020", name: "Agrochemicals & Crop Protection", type: "Expense", category: "Direct Crop Inputs" },
      { code: "5030", name: "Tractor Diesel & Lubricants", type: "Expense", category: "Mechanization" }
    ],
    recommendedModules: ["crops", "orchard", "inventory", "accounts", "expenses", "sales", "invoices", "payroll", "reports", "weather"]
  },
  {
    id: "template-feed-milling",
    name: "Feed Milling & Agro-Processing",
    category: "feed_milling",
    description: "Designed for commercial feed millers, grain processors, ingredient blenders, and packaging facilities.",
    iconName: "Factory",
    badgeColor: "bg-purple-100 text-purple-800 border-purple-300",
    defaultDepartments: [
      { name: "Executive & General Management", code: "EXEC", description: "Factory direction, commercial contracts, and enterprise compliance" },
      { name: "Production & Milling", code: "PROD", description: "Least-cost feed formulation, hammer milling, pelleting, and bagging" },
      { name: "Quality Assurance & Lab", code: "QA", description: "Moisture testing, crude protein analysis, and aflatoxin screening" },
      { name: "Raw Material Procurement", code: "PROC", description: "Maize bran, soya cake, premixes, and farmer aggregator supply chains" },
      { name: "Commercial Sales & Dispatch", code: "SALES", description: "B2B dealer orders, wholesale dispatches, and delivery logistics" },
      { name: "Finance & Cost Accounting", code: "FIN", description: "Batch cost calculation, margin analysis, payments, and receivables" }
    ],
    defaultRoles: [
      {
        name: "Mill Production Manager",
        description: "Manages batch formulations, ingredient blending, machine run-time, and bagged output",
        departmentCode: "PROD",
        isTenantAdmin: false,
        permittedModules: ["dashboard", "feed", "inventory", "expenses"],
        modulePermissions: {
          dashboard: { read: true, write: false, delete: false, approve: false },
          feed: { read: true, write: true, delete: true, approve: true },
          inventory: { read: true, write: true, delete: false, approve: true },
          expenses: { read: true, write: true, delete: false, approve: false }
        }
      },
      {
        name: "Feed Milling Administrator",
        description: "Full enterprise administrator with approval control over formulations and pricing",
        departmentCode: "EXEC",
        isTenantAdmin: true,
        permittedModules: ["dashboard", "feed", "inventory", "accounts", "expenses", "sales", "invoices", "payroll", "reports"],
        modulePermissions: {
          dashboard: { read: true, write: true, delete: true, approve: true },
          feed: { read: true, write: true, delete: true, approve: true },
          inventory: { read: true, write: true, delete: true, approve: true },
          accounts: { read: true, write: true, delete: true, approve: true },
          expenses: { read: true, write: true, delete: true, approve: true },
          sales: { read: true, write: true, delete: true, approve: true },
          invoices: { read: true, write: true, delete: true, approve: true },
          payroll: { read: true, write: true, delete: true, approve: true },
          reports: { read: true, write: true, delete: true, approve: true }
        }
      }
    ],
    defaultAccounts: [
      { code: "1010", name: "Factory Operating Bank Account", type: "Asset", category: "Cash & Equivalents" },
      { code: "1410", name: "Raw Grain & Premix Inventory", type: "Asset", category: "Raw Materials" },
      { code: "1430", name: "Bagged Finished Feed (Poultry/Dairy/Pig)", type: "Asset", category: "Finished Goods" },
      { code: "4010", name: "Commercial Feed Sales Revenue", type: "Revenue", category: "Operating Revenue" },
      { code: "5010", name: "Soya Cake & Sunflower Meal", type: "Expense", category: "Raw Material Costs" },
      { code: "5020", name: "Vitamin Premixes & Amino Acids", type: "Expense", category: "Direct Ingredients" },
      { code: "5030", name: "Packaging Bags & Labels", type: "Expense", category: "Packaging" }
    ],
    recommendedModules: ["feed", "inventory", "accounts", "expenses", "sales", "invoices", "payroll", "reports"]
  },
  {
    id: "template-group-holding",
    name: "Group Holding & Aggregator Entity",
    category: "group_holding",
    description: "For conglomerates, multi-farm holdings, offtaker aggregators, and institutional suppliers.",
    iconName: "Network",
    badgeColor: "bg-blue-100 text-blue-800 border-blue-300",
    defaultDepartments: [
      { name: "Group Executive Board", code: "BOARD", description: "Consolidated holding governance and subsidiary portfolio oversight" },
      { name: "Audit & Risk Compliance", code: "AUDIT", description: "Maker-checker oversight, internal controls, and dual-authorization verification" },
      { name: "Consolidated Finance & Treasury", code: "TREAS", description: "Group inter-company balances, cash sweeps, consolidated IFRS reports" },
      { name: "Bulk Trade & Procurement", code: "TRADE", description: "Centralized input purchasing and bulk commodity contracts" },
      { name: "Subsidiary Operations Hub", code: "SUBS", description: "Monitoring farm nodes, agro-dealer networks, and supply depots" }
    ],
    defaultRoles: [
      {
        name: "Group Executive Director",
        description: "Supreme holding administrator with multi-subsidiary visibility and approval authority",
        departmentCode: "BOARD",
        isTenantAdmin: true,
        permittedModules: ["dashboard", "accounts", "expenses", "sales", "invoices", "crops", "livestock", "inventory", "payroll", "reports", "market-prices"],
        modulePermissions: {
          dashboard: { read: true, write: true, delete: true, approve: true },
          accounts: { read: true, write: true, delete: true, approve: true },
          expenses: { read: true, write: true, delete: true, approve: true },
          sales: { read: true, write: true, delete: true, approve: true },
          invoices: { read: true, write: true, delete: true, approve: true },
          crops: { read: true, write: true, delete: true, approve: true },
          livestock: { read: true, write: true, delete: true, approve: true },
          inventory: { read: true, write: true, delete: true, approve: true },
          payroll: { read: true, write: true, delete: true, approve: true },
          reports: { read: true, write: true, delete: true, approve: true },
          "market-prices": { read: true, write: true, delete: false, approve: false }
        }
      },
      {
        name: "Internal Audit & Compliance Controller",
        description: "Mandatory checker for dual-control financial adjustments, asset write-offs, and user provisioning",
        departmentCode: "AUDIT",
        isTenantAdmin: false,
        permittedModules: ["dashboard", "accounts", "expenses", "invoices", "reports"],
        modulePermissions: {
          dashboard: { read: true, write: false, delete: false, approve: true },
          accounts: { read: true, write: false, delete: false, approve: true },
          expenses: { read: true, write: false, delete: false, approve: true },
          invoices: { read: true, write: false, delete: false, approve: true },
          reports: { read: true, write: false, delete: false, approve: true }
        }
      }
    ],
    defaultAccounts: [
      { code: "1010", name: "Group Treasury Master Account", type: "Asset", category: "Cash & Equivalents" },
      { code: "1310", name: "Inter-Company Receivables", type: "Asset", category: "Inter-company" },
      { code: "2310", name: "Inter-Company Payables", type: "Liability", category: "Inter-company" },
      { code: "4010", name: "Aggregated Commodity Sales", type: "Revenue", category: "Operating Revenue" },
      { code: "4020", name: "Management Service Fees", type: "Revenue", category: "Operating Revenue" }
    ],
    recommendedModules: ["dashboard", "accounts", "expenses", "sales", "invoices", "inventory", "payroll", "reports", "market-prices"]
  },
  {
    id: "template-agro-dealer",
    name: "Agro Dealer & Retail Hub",
    category: "agro_dealer",
    description: "Input retail store, consignment stock grants from institutional suppliers, POS, and farmer credit lines.",
    iconName: "Store",
    badgeColor: "bg-amber-100 text-amber-900 border-amber-300",
    defaultDepartments: [
      { name: "Store Management", code: "MGT", description: "Branch leadership, supplier relations, and cash-up approvals" },
      { name: "Counter Sales & POS", code: "POS", description: "Direct retail sales to smallholders, mobile money, and paper receipts" },
      { name: "Consignment & Warehouse", code: "STOCK", description: "Supplier stock grants, physical counts, batch tracking, and returns" },
      { name: "Accounts & Remittances", code: "FIN", description: "Supplier remittances, margin accounting, and credit facility collections" }
    ],
    defaultRoles: [
      {
        name: "Agro-Dealer Branch Administrator",
        description: "Full retail store admin with authority over consignment settlements and product catalog pricing",
        departmentCode: "MGT",
        isTenantAdmin: true,
        permittedModules: ["dashboard", "sales", "inventory", "invoices", "accounts", "expenses", "reports"],
        modulePermissions: {
          dashboard: { read: true, write: true, delete: true, approve: true },
          sales: { read: true, write: true, delete: true, approve: true },
          inventory: { read: true, write: true, delete: true, approve: true },
          invoices: { read: true, write: true, delete: true, approve: true },
          accounts: { read: true, write: true, delete: true, approve: true },
          expenses: { read: true, write: true, delete: true, approve: true },
          reports: { read: true, write: true, delete: true, approve: true }
        }
      },
      {
        name: "Counter Sales Clerk",
        description: "Processes retail POS transactions, searches catalog items, and issues customer receipts",
        departmentCode: "POS",
        isTenantAdmin: false,
        permittedModules: ["sales", "inventory"],
        modulePermissions: {
          sales: { read: true, write: true, delete: false, approve: false },
          inventory: { read: true, write: false, delete: false, approve: false }
        }
      }
    ],
    defaultAccounts: [
      { code: "1010", name: "Till Cash Float", type: "Asset", category: "Cash on Hand" },
      { code: "1020", name: "Agro-Dealer Lipila Mobile Money", type: "Asset", category: "Cash & Equivalents" },
      { code: "1410", name: "Input Merchandise Inventory", type: "Asset", category: "Merchandise Inventory" },
      { code: "2010", name: "Supplier Consignment Accounts Payable", type: "Liability", category: "Current Liabilities" },
      { code: "4010", name: "Agro-Input Retail Sales", type: "Revenue", category: "Operating Revenue" },
      { code: "5010", name: "Cost of Goods Sold (Inputs)", type: "Expense", category: "Direct Costs" }
    ],
    recommendedModules: ["sales", "inventory", "invoices", "accounts", "expenses", "reports"]
  },
  {
    id: "template-institutional",
    name: "Institutional M&E & Supplier",
    category: "institutional",
    description: "Sponsorship monitoring, smallholder farmer portfolio tracking, M&E analytics, and input grant distribution.",
    iconName: "Building2",
    badgeColor: "bg-indigo-100 text-indigo-800 border-indigo-300",
    defaultDepartments: [
      { name: "Executive Directorate", code: "EXEC", description: "Donor reporting, partner MOUs, and institutional governance" },
      { name: "Monitoring & Evaluation (M&E)", code: "ME", description: "Farmer profiling, yield telemetry, impact metrics, and project KPIs" },
      { name: "Field Extension & Agronomy", code: "EXT", description: "Lead farmers, field training, demonstration plots, and agro-inputs" },
      { name: "Grants & Finance", code: "FIN", description: "Consignment agreements, dealer subsidies, Lipila disbursements, and audits" }
    ],
    defaultRoles: [
      {
        name: "Institutional M&E Lead",
        description: "Full visibility over sponsored farmer portfolios, yield data, and compliance reports",
        departmentCode: "ME",
        isTenantAdmin: true,
        permittedModules: ["dashboard", "crops", "reports", "accounts", "expenses", "invoices"],
        modulePermissions: {
          dashboard: { read: true, write: true, delete: true, approve: true },
          crops: { read: true, write: true, delete: true, approve: true },
          reports: { read: true, write: true, delete: true, approve: true },
          accounts: { read: true, write: true, delete: true, approve: true },
          expenses: { read: true, write: true, delete: true, approve: true },
          invoices: { read: true, write: true, delete: true, approve: true }
        }
      }
    ],
    defaultAccounts: [
      { code: "1010", name: "Institutional Program Account", type: "Asset", category: "Cash & Equivalents" },
      { code: "1410", name: "Grant Input Inventory", type: "Asset", category: "Current Assets" },
      { code: "5010", name: "Smallholder Input Grants & Subsidies", type: "Expense", category: "Program Grants" }
    ],
    recommendedModules: ["dashboard", "crops", "reports", "accounts", "expenses", "invoices"]
  }
];

// ============================================================================
// Tenant Provisioning Input & Management Service
// ============================================================================

export interface CreateTenantInput {
  name: string; // Entity/company name
  registrationNumber: string; // PACRA / Company registration number
  corporateEmail: string;
  contactPhone: string;
  adminName: string;
  defaultPassword: string;
  tenantType: TenantCategory;
  templatePresetId?: string;
  logoUrl?: string;
  address?: string;
  province?: string;
  district?: string;
  requireForcedPasswordChange?: boolean;
  makerCheckerConfig?: Partial<MakerCheckerConfig>;
  backupAdminEmail?: string;
  backupAdminName?: string;
}

export class TenantService {
  private static STORAGE_KEY_TENANTS = "mabala_tenants_registry";

  /**
   * Generates a unique, URL-safe tenant ID
   */
  static generateTenantId(entityName: string): string {
    const cleanPrefix = entityName
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "-")
      .replace(/-+/g, "-")
      .slice(0, 16)
      .replace(/^-|-$/g, "");
    const randomSuffix = Math.random().toString(36).substring(2, 7);
    return `TNT-${cleanPrefix || "entity"}-${randomSuffix}`.toUpperCase();
  }

  /**
   * Super Admin creates and provisions a complete tenant entity with default admin,
   * departments, roles, accounts, and automated welcome email.
   */
  static async createTenant(
    input: CreateTenantInput,
    superAdminEmail: string = "support@mabala.cloud",
    superAdminUid: string = "super-admin"
  ): Promise<{ tenant: TenantRecord; adminUser: UserMember; welcomeEmailSent: boolean; message: string }> {
    const cleanName = input.name.trim();
    const cleanRegNo = input.registrationNumber.trim().toUpperCase();
    const cleanCorporateEmail = input.corporateEmail.trim().toLowerCase();
    const cleanContactPhone = input.contactPhone.trim();
    const cleanAdminName = input.adminName.trim();
    const cleanAdminEmail = cleanCorporateEmail; // Corporate email is the admin login ID
    const defaultPassword = input.defaultPassword.trim() || `Mabala@${Math.floor(100000 + Math.random() * 900000)}`;

    if (!cleanName) throw new Error("Entity/Company name is mandatory.");
    if (!cleanRegNo) throw new Error("Company registration number (PACRA/Reg) is mandatory.");
    if (!cleanCorporateEmail) throw new Error("Corporate email address is mandatory.");
    if (!cleanContactPhone) throw new Error("Contact phone number is mandatory.");
    if (!cleanAdminName) throw new Error("Administrator's full name is mandatory.");
    if (defaultPassword.length < 6) throw new Error("Default password must be at least 6 characters.");

    const tenantId = this.generateTenantId(cleanName);

    // 1. Resolve template preset
    const selectedTemplate = TENANT_TEMPLATES.find(t => t.id === input.templatePresetId || t.category === input.tenantType) || TENANT_TEMPLATES[0];

    // 2. Generate default departments
    const departments: TenantDepartment[] = selectedTemplate.defaultDepartments.map((d, index) => ({
      id: `DEP-${tenantId}-${d.code}-${index + 1}`,
      name: d.name,
      code: d.code,
      description: d.description,
      tenantId: tenantId,
      headOfDepartmentName: index === 0 ? cleanAdminName : "",
      headOfDepartmentEmail: index === 0 ? cleanAdminEmail : "",
      isActive: true,
      createdAt: new Date().toISOString()
    }));

    // 3. Generate default roles with permissions
    const roles: TenantRole[] = selectedTemplate.defaultRoles.map((r, index) => {
      const matchedDept = departments.find(d => d.code === r.departmentCode) || departments[0];
      return {
        id: `ROLE-${tenantId}-${index + 1}`,
        name: r.name,
        description: r.description,
        tenantId: tenantId,
        departmentId: matchedDept.id,
        departmentName: matchedDept.name,
        isTenantAdmin: Boolean(r.isTenantAdmin),
        permittedModules: r.permittedModules,
        modulePermissions: r.modulePermissions,
        createdAt: new Date().toISOString()
      };
    });

    // Ensure there is at least one primary Administrator role
    const adminRole = roles.find(r => r.isTenantAdmin) || {
      id: `ROLE-${tenantId}-ADMIN`,
      name: "Tenant Administrator",
      description: "Full tenant-level roles and administrative permissions",
      tenantId: tenantId,
      departmentId: departments[0]?.id || `DEP-${tenantId}-EXEC`,
      departmentName: departments[0]?.name || "Executive & Strategy",
      isTenantAdmin: true,
      permittedModules: SYSTEM_MODULES.map(m => m.id),
      modulePermissions: SYSTEM_MODULES.reduce((acc, m) => {
        acc[m.id] = { read: true, write: true, delete: true, approve: true };
        return acc;
      }, {} as Record<string, GranularPermission>),
      createdAt: new Date().toISOString()
    };

    // 4. Maker-Checker Default Policy
    const makerCheckerConfig: MakerCheckerConfig = {
      enabled: input.makerCheckerConfig?.enabled !== undefined ? input.makerCheckerConfig.enabled : true,
      requireDualApprovalForFinancial: input.makerCheckerConfig?.requireDualApprovalForFinancial !== undefined ? input.makerCheckerConfig.requireDualApprovalForFinancial : true,
      requireDualApprovalForDeletion: input.makerCheckerConfig?.requireDualApprovalForDeletion !== undefined ? input.makerCheckerConfig.requireDualApprovalForDeletion : true,
      requireDualApprovalForUserProvision: input.makerCheckerConfig?.requireDualApprovalForUserProvision !== undefined ? input.makerCheckerConfig.requireDualApprovalForUserProvision : true,
      requireDualApprovalForPriceBoard: input.makerCheckerConfig?.requireDualApprovalForPriceBoard !== undefined ? input.makerCheckerConfig.requireDualApprovalForPriceBoard : true,
      financialThresholdZmw: input.makerCheckerConfig?.financialThresholdZmw || 5000,
      backupAdminEmail: input.backupAdminEmail?.trim().toLowerCase() || "",
      backupAdminName: input.backupAdminName?.trim() || "",
      fallbackToSuperAdmin: input.makerCheckerConfig?.fallbackToSuperAdmin !== undefined ? input.makerCheckerConfig.fallbackToSuperAdmin : true
    };

    // 5. Build Tenant Record
    const newTenant: TenantRecord = {
      id: tenantId,
      name: cleanName,
      registrationNumber: cleanRegNo,
      corporateEmail: cleanCorporateEmail,
      contactPhone: cleanContactPhone,
      tenantType: input.tenantType,
      status: "active",
      adminName: cleanAdminName,
      adminEmail: cleanAdminEmail,
      adminPhone: cleanContactPhone,
      logoUrl: input.logoUrl || "",
      address: input.address || "Lusaka, Zambia",
      province: input.province || "Lusaka",
      district: input.district || "Lusaka",
      templatePreset: selectedTemplate.name,
      departments: departments,
      roles: roles,
      makerCheckerConfig: makerCheckerConfig,
      credits: 250,
      smsCreditBalance: 50,
      welcomeEmailDispatched: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // 6. Build Primary Administrator User Member
    const adminUser: UserMember = {
      id: `usr_${tenantId}_admin`,
      name: cleanAdminName,
      email: cleanAdminEmail,
      role: "Farm Owner" as PredefinedRole, // Maps to tenant owner in core session
      status: "Active",
      isSuspended: false,
      password: defaultPassword,
      tenantId: tenantId,
      farmId: `farm_${tenantId}`,
      farmName: cleanName,
      accessibleFarmIds: [`farm_${tenantId}`],
      permittedModules: adminRole.permittedModules || SYSTEM_MODULES.map(m => m.id),
      modulePermissions: adminRole.modulePermissions as any,
      mustChangePassword: input.requireForcedPasswordChange !== undefined ? input.requireForcedPasswordChange : true,
      forcePasswordChange: input.requireForcedPasswordChange !== undefined ? input.requireForcedPasswordChange : true,
      createdBy: superAdminEmail,
      createdAt: new Date().toISOString(),
      lastActive: "Never"
    };

    // 7. Write to Firestore & Local Persistent Stores
    if (isConfigured) {
      try {
        // Under /tenants/{tenantId}
        await setDoc(doc(db, "tenants", tenantId), newTenant, { merge: true });

        // Seed initial subcollections for departments, roles, and node users
        for (const dept of departments) {
          await setDoc(doc(db, "tenants", tenantId, "departments", dept.id), dept, { merge: true });
        }
        for (const role of roles) {
          await setDoc(doc(db, "tenants", tenantId, "roles", role.id), role, { merge: true });
        }
        await setDoc(doc(db, "tenants", tenantId, "node_users", cleanAdminEmail), adminUser, { merge: true });

        // Root users lookup
        await setDoc(doc(db, "users", cleanAdminEmail), {
          ...adminUser,
          isTenantAdmin: true,
          tenantRecordId: tenantId,
          companyName: cleanName
        }, { merge: true });

        // Root users_data for workspace initialization
        await setDoc(doc(db, "users_data", adminUser.id), {
          uid: adminUser.id,
          email: cleanAdminEmail,
          name: cleanAdminName,
          phone: cleanContactPhone,
          tenantId: tenantId,
          role: "Farm Owner",
          workspaceMode: input.tenantType === "agro_dealer" ? "agro_dealer" : "Farmer",
          tenantType: input.tenantType,
          companyName: cleanName,
          registrationNumber: cleanRegNo,
          logoUrl: input.logoUrl || "",
          credits: 250,
          smsCredits: 50,
          farms: [
            {
              id: `farm_${tenantId}`,
              name: cleanName,
              address: input.address || "Zambia",
              phone: cleanContactPhone,
              email: cleanCorporateEmail,
              currency: "ZMW",
              currencySymbol: "K",
              tpin: cleanRegNo,
              logoUrl: input.logoUrl || ""
            }
          ],
          accounts: selectedTemplate.defaultAccounts.map((a, i) => ({
            id: `acc-${tenantId}-${i + 1}`,
            code: a.code,
            name: a.name,
            type: a.type,
            category: a.category,
            balance: 0.00,
            isSystem: true
          })),
          suppliers: [],
          customers: [],
          expenses: [],
          invoices: [],
          quotations: [],
          crops: [],
          inventory: [],
          payroll: [],
          createdAt: new Date().toISOString()
        }, { merge: true });

        console.log(`[TenantService] Successfully provisioned tenant ${tenantId} and administrator ${cleanAdminEmail} in Firestore.`);
      } catch (err) {
        console.warn("[TenantService] Firestore write warning:", err);
      }
    }

    // 8. Update Local Storage Registries
    if (typeof window !== "undefined") {
      try {
        // Update Tenants list
        const existingTenantsStr = localStorage.getItem(this.STORAGE_KEY_TENANTS) || "[]";
        const existingTenants: TenantRecord[] = safeParseJSON(existingTenantsStr, []);
        const filteredTenants = existingTenants.filter(t => t.id !== tenantId);
        filteredTenants.unshift(newTenant);
        localStorage.setItem(this.STORAGE_KEY_TENANTS, JSON.stringify(filteredTenants));

        // Update Registered Roles Map
        const roleMapStr = localStorage.getItem("mabala_registered_roles_map") || "{}";
        const roleMap = safeParseJSON(roleMapStr, {});
        roleMap[cleanAdminEmail] = {
          role: "Farm Owner",
          tenantType: input.tenantType,
          tenantId: tenantId,
          farmId: `farm_${tenantId}`,
          isTenantAdmin: true,
          companyName: cleanName,
          permittedModules: adminUser.permittedModules,
          status: "Active",
          isSuspended: false
        };
        localStorage.setItem("mabala_registered_roles_map", JSON.stringify(roleMap));

        // Passwords cache
        const passDict = safeParseJSON(localStorage.getItem("mabala_user_passwords") || "{}", {});
        passDict[cleanAdminEmail] = defaultPassword;
        localStorage.setItem("mabala_user_passwords", JSON.stringify(passDict));

        // Pending first login registry
        const pendingStr = localStorage.getItem("mabala_pending_first_login_users") || "[]";
        const pendingUsers = safeParseJSON(pendingStr, []);
        const pendingFiltered = pendingUsers.filter((u: any) => u.email.toLowerCase() !== cleanAdminEmail);
        pendingFiltered.push({
          email: cleanAdminEmail,
          name: cleanAdminName,
          password: defaultPassword,
          role: "Farm Owner",
          tenantId: tenantId,
          farmId: `farm_${tenantId}`,
          permittedModules: adminUser.permittedModules,
          mustChangePassword: true,
          forcePasswordChange: true,
          companyName: cleanName,
          createdAt: new Date().toISOString()
        });
        localStorage.setItem("mabala_pending_first_login_users", JSON.stringify(pendingFiltered));
      } catch (err) {
        console.warn("[TenantService] Error updating local registries:", err);
      }
    }

    // 9. Dispatch Automated Welcome Email via Server Endpoint
    let welcomeEmailSent = false;
    try {
      const loginUrl = typeof window !== "undefined" ? window.location.origin : "https://mabala.cloud";
      const emailPayload = {
        to: cleanAdminEmail,
        fullName: cleanAdminName,
        role: `Administrator — ${cleanName}`,
        defaultPassword: defaultPassword,
        loginUrl: loginUrl,
        farmContext: {
          farmName: cleanName,
          tenantName: cleanName,
          tenantId: tenantId,
          contactPhone: cleanContactPhone,
          currency: "ZMW"
        }
      };

      const mailRes = await fetch("/api/mail/send-welcome", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(emailPayload)
      });

      if (mailRes.ok) {
        welcomeEmailSent = true;
        newTenant.welcomeEmailDispatched = true;
        newTenant.welcomeEmailDispatchedAt = new Date().toISOString();
        if (typeof window !== "undefined") {
          const list = safeParseJSON<TenantRecord[]>(localStorage.getItem(this.STORAGE_KEY_TENANTS) || "[]", []);
          const idx = list.findIndex(t => t.id === tenantId);
          if (idx !== -1) {
            list[idx].welcomeEmailDispatched = true;
            list[idx].welcomeEmailDispatchedAt = new Date().toISOString();
            localStorage.setItem(this.STORAGE_KEY_TENANTS, JSON.stringify(list));
          }
        }
      } else {
        // Try fallback to /api/auth/send-welcome
        const authMailRes = await fetch("/api/auth/send-welcome", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: cleanAdminEmail,
            fullName: cleanAdminName,
            password: defaultPassword,
            loginUrl: loginUrl,
            role: `Administrator — ${cleanName}`,
            farmContext: {
              farmName: cleanName,
              tenantId: tenantId
            }
          })
        });
        if (authMailRes.ok) {
          welcomeEmailSent = true;
        }
      }
    } catch (mailErr) {
      console.warn("[TenantService] Welcome email dispatch note:", mailErr);
    }

    // 10. Write Immutable Audit Log
    await recordSubUserAuditLog({
      tenantId: tenantId,
      action: "SUPERADMIN_PROVISION_TENANT",
      actorUid: superAdminUid,
      actorEmail: superAdminEmail,
      actorName: "Super Admin",
      targetEmail: cleanAdminEmail,
      targetName: cleanAdminName,
      module: "Tenant Provisioning",
      record: tenantId,
      detail: `Super Admin provisioned new ${input.tenantType.toUpperCase()} tenant "${cleanName}" (Reg: ${cleanRegNo}) with Admin ${cleanAdminName} (${cleanAdminEmail}). Template: "${selectedTemplate.name}". Welcome Email: ${welcomeEmailSent ? "DISPATCHED" : "QUEUED"}.`,
      details: {
        tenantId,
        tenantName: cleanName,
        tenantType: input.tenantType,
        registrationNumber: cleanRegNo,
        adminEmail: cleanAdminEmail,
        departmentsCount: departments.length,
        rolesCount: roles.length,
        template: selectedTemplate.name,
        welcomeEmailSent
      }
    });

    return {
      tenant: newTenant,
      adminUser: adminUser,
      welcomeEmailSent: welcomeEmailSent,
      message: `Tenant "${cleanName}" (${tenantId}) successfully provisioned! Administrator "${cleanAdminName}" can log in with email "${cleanAdminEmail}" and temporary password "${defaultPassword}". Forced password change will be enforced on first login.`
    };
  }

  /**
   * Fetches all registered tenants from Cloud Firestore and local storage.
   */
  static async getAllTenants(): Promise<TenantRecord[]> {
    let tenants: TenantRecord[] = [];

    // 1. Fetch from Firestore
    if (isConfigured && typeof window !== "undefined" && window.navigator.onLine) {
      try {
        const colRef = collection(db, "tenants");
        const snap = await getDocs(colRef);
        if (!snap.empty) {
          snap.forEach(d => {
            const data = d.data() as TenantRecord;
            tenants.push({
              ...data,
              id: d.id
            });
          });
        }
      } catch (err) {
        console.warn("[TenantService] Error fetching tenants from Firestore:", err);
      }
    }

    // 2. Fetch from Local Storage
    if (typeof window !== "undefined") {
      try {
        const localStr = localStorage.getItem(this.STORAGE_KEY_TENANTS);
        if (localStr) {
          const parsed: TenantRecord[] = safeParseJSON(localStr, []);
          const tenantMap = new Map<string, TenantRecord>();
          tenants.forEach(t => tenantMap.set(t.id, t));
          parsed.forEach(t => {
            if (!tenantMap.has(t.id)) {
              tenantMap.set(t.id, t);
            } else {
              tenantMap.set(t.id, { ...tenantMap.get(t.id)!, ...t });
            }
          });
          tenants = Array.from(tenantMap.values());
        }
      } catch (err) {
        console.warn("[TenantService] Error parsing local tenants:", err);
      }
    }

    // 3. Seed default foundational tenants if empty
    if (tenants.length === 0) {
      const defaultTenants: TenantRecord[] = [
        {
          id: "TNT-DEEPVALLEY-001",
          name: "Deep Valley Farms Ltd",
          registrationNumber: "PACRA-1092834-ZMW",
          corporateEmail: "deepvaleyfarm@gmail.com",
          contactPhone: "+260977890123",
          tenantType: "crop",
          status: "active",
          adminName: "Deep Valley Admin",
          adminEmail: "deepvaleyfarm@gmail.com",
          address: "Lusaka West Farm Block, Plot 491, Zambia",
          province: "Lusaka",
          district: "Lusaka West",
          templatePreset: "Commercial Crop Production",
          departments: TENANT_TEMPLATES[1].defaultDepartments.map((d, i) => ({
            id: `DEP-DV-${d.code}`,
            name: d.name,
            code: d.code,
            description: d.description,
            tenantId: "TNT-DEEPVALLEY-001",
            isActive: true,
            createdAt: new Date().toISOString()
          })),
          roles: TENANT_TEMPLATES[1].defaultRoles.map((r, i) => ({
            id: `ROLE-DV-${i+1}`,
            name: r.name,
            description: r.description,
            tenantId: "TNT-DEEPVALLEY-001",
            isTenantAdmin: Boolean(r.isTenantAdmin),
            permittedModules: r.permittedModules,
            modulePermissions: r.modulePermissions,
            createdAt: new Date().toISOString()
          })),
          makerCheckerConfig: {
            enabled: true,
            requireDualApprovalForFinancial: true,
            requireDualApprovalForDeletion: true,
            requireDualApprovalForUserProvision: true,
            requireDualApprovalForPriceBoard: true,
            financialThresholdZmw: 5000,
            fallbackToSuperAdmin: true
          },
          credits: 500,
          smsCreditBalance: 120,
          welcomeEmailDispatched: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ];
      tenants = defaultTenants;
      if (typeof window !== "undefined") {
        try {
          localStorage.setItem(this.STORAGE_KEY_TENANTS, JSON.stringify(tenants));
        } catch (_) {}
      }
    }

    return tenants;
  }

  /**
   * Updates an existing tenant record
   */
  static async updateTenant(
    tenantId: string,
    updates: Partial<TenantRecord>,
    actorEmail: string = "support@mabala.cloud"
  ): Promise<TenantRecord> {
    const tenants = await this.getAllTenants();
    const idx = tenants.findIndex(t => t.id === tenantId);
    if (idx === -1) throw new Error(`Tenant ${tenantId} was not found.`);

    const updated: TenantRecord = {
      ...tenants[idx],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    tenants[idx] = updated;

    if (isConfigured) {
      try {
        await setDoc(doc(db, "tenants", tenantId), updated, { merge: true });
      } catch (err) {
        console.warn("[TenantService] Error updating tenant in Firestore:", err);
      }
    }

    if (typeof window !== "undefined") {
      try {
        localStorage.setItem(this.STORAGE_KEY_TENANTS, JSON.stringify(tenants));
      } catch (_) {}
    }

    await recordSubUserAuditLog({
      tenantId: tenantId,
      action: "UPDATE_TENANT_METADATA",
      actorEmail: actorEmail,
      module: "Tenant Administration",
      record: tenantId,
      detail: `Updated configuration for tenant "${updated.name}" (${tenantId}).`,
      details: updates
    });

    return updated;
  }

  /**
   * Adds a new Department to a Tenant
   */
  static async addDepartment(
    tenantId: string,
    deptInput: { name: string; code: string; description?: string; headOfDepartmentName?: string; headOfDepartmentEmail?: string },
    actorEmail: string
  ): Promise<TenantDepartment> {
    const cleanName = deptInput.name.trim();
    const cleanCode = deptInput.code.trim().toUpperCase();
    if (!cleanName || !cleanCode) throw new Error("Department name and code are mandatory.");

    const tenant = (await this.getAllTenants()).find(t => t.id === tenantId);
    if (!tenant) throw new Error(`Tenant ${tenantId} not found.`);

    const newDept: TenantDepartment = {
      id: `DEP-${tenantId}-${cleanCode}-${Date.now().toString().slice(-4)}`,
      name: cleanName,
      code: cleanCode,
      description: deptInput.description || "",
      tenantId: tenantId,
      headOfDepartmentName: deptInput.headOfDepartmentName || "",
      headOfDepartmentEmail: deptInput.headOfDepartmentEmail || "",
      isActive: true,
      createdAt: new Date().toISOString()
    };

    const updatedDepartments = [...(tenant.departments || []), newDept];
    await this.updateTenant(tenantId, { departments: updatedDepartments }, actorEmail);

    if (isConfigured) {
      try {
        await setDoc(doc(db, "tenants", tenantId, "departments", newDept.id), newDept, { merge: true });
      } catch (_) {}
    }

    return newDept;
  }

  /**
   * Adds a new Role with granular module permissions to a Tenant
   */
  static async addRole(
    tenantId: string,
    roleInput: {
      name: string;
      description?: string;
      departmentId?: string;
      isTenantAdmin?: boolean;
      permittedModules: string[];
      modulePermissions: Record<string, GranularPermission>;
    },
    actorEmail: string
  ): Promise<TenantRole> {
    const cleanName = roleInput.name.trim();
    if (!cleanName) throw new Error("Role name is mandatory.");

    const tenant = (await this.getAllTenants()).find(t => t.id === tenantId);
    if (!tenant) throw new Error(`Tenant ${tenantId} not found.`);

    const matchedDept = tenant.departments?.find(d => d.id === roleInput.departmentId);

    const newRole: TenantRole = {
      id: `ROLE-${tenantId}-${Date.now().toString().slice(-4)}`,
      name: cleanName,
      description: roleInput.description || "",
      tenantId: tenantId,
      departmentId: roleInput.departmentId || "",
      departmentName: matchedDept?.name || "General",
      isTenantAdmin: Boolean(roleInput.isTenantAdmin),
      permittedModules: roleInput.permittedModules,
      modulePermissions: roleInput.modulePermissions,
      createdAt: new Date().toISOString()
    };

    const updatedRoles = [...(tenant.roles || []), newRole];
    await this.updateTenant(tenantId, { roles: updatedRoles }, actorEmail);

    if (isConfigured) {
      try {
        await setDoc(doc(db, "tenants", tenantId, "roles", newRole.id), newRole, { merge: true });
      } catch (_) {}
    }

    return newRole;
  }
}

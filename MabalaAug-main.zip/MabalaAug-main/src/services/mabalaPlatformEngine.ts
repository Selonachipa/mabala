import { MarketplaceProduct, Vendor, MarketplaceOrder } from "../data/marketplaceData";
import { AgroDealerSKU, AgroDealerTenant, Supplier } from "../types";
import { getFeeConfig } from "./feeConfigService";

// ============================================================================
// PART F & G: FEE CALCULATION ENGINE
// ============================================================================

export interface FeeBreakdown {
  subtotal: number;
  deliveryFee: number;
  collectionFee4Percent: number; // Buyer-side collection fee (dynamic from config)
  totalAmount: number;
}

export interface DisbursementFeeBreakdown {
  requestedAmount: number;
  lipilaFee: number;
  platformFee3Point5: number;
  totalFees: number;
  netPayout: number;
  totalDeductedFromWallet: number;
}

export interface CardCollectionFeeBreakdown {
  subtotal: number;
  cardFee: number; // Buyer-side 3% (or configured) card platform fee
  totalAmountToChargeBuyer: number;
  netVendorCredit: number;
}

/**
 * Calculates Buyer-Side Collection Fee add-on for Marketplace Orders reading from fee config.
 */
export function calculateOrderFees(subtotal: number, deliveryFee: number = 0): FeeBreakdown {
  const feeCfg = getFeeConfig("vendor_marketplace_collection");
  const rate = feeCfg && feeCfg.active ? feeCfg.value / 100 : 0.04;
  const collectionFee4Percent = Math.round(subtotal * rate * 100) / 100;
  const totalAmount = subtotal + deliveryFee + collectionFee4Percent;
  return {
    subtotal,
    deliveryFee,
    collectionFee4Percent,
    totalAmount
  };
}

/**
 * Calculates Card Collection Fee reading from fee config.
 */
export function calculateCardCollectionFees(subtotal: number): CardCollectionFeeBreakdown {
  const feeCfg = getFeeConfig("card_collection");
  const rate = feeCfg && feeCfg.active ? feeCfg.value / 100 : 0.03;
  const cardFee = Math.round(subtotal * rate * 100) / 100;
  return {
    subtotal,
    cardFee,
    totalAmountToChargeBuyer: subtotal + cardFee,
    netVendorCredit: subtotal
  };
}

/**
 * Calculates Tiered Lipila Fee + Mabala Platform Fee (from fee config) for Payout Disbursements.
 * Lipila Tier Schedule for mobile money / bank disbursements:
 * <= K1,000 -> K15
 * K1,001 - K5,000 -> K35
 * K5,001 - K10,000 -> K65
 * > K10,000 -> K120
 */
export function calculateDisbursementFees(requestedAmount: number, paymentType: "MobileMoney" | "Bank" = "MobileMoney"): DisbursementFeeBreakdown {
  let lipilaFee = 15;
  if (requestedAmount > 10000) {
    lipilaFee = 120;
  } else if (requestedAmount > 5000) {
    lipilaFee = 65;
  } else if (requestedAmount > 1000) {
    lipilaFee = 35;
  }

  const feeCfg = getFeeConfig("disbursement_platform_fee");
  const rate = feeCfg && feeCfg.active ? feeCfg.value / 100 : 0.035;
  const platformFee3Point5 = Math.round(requestedAmount * rate * 100) / 100;
  const totalFees = lipilaFee + platformFee3Point5;
  const netPayout = requestedAmount;
  const totalDeductedFromWallet = requestedAmount + totalFees;

  return {
    requestedAmount,
    lipilaFee,
    platformFee3Point5,
    totalFees,
    netPayout,
    totalDeductedFromWallet
  };
}

// ============================================================================
// PART D: B2B MULTI-PRODUCT CART ENGINE
// ============================================================================

export interface B2BCartItem {
  product: MarketplaceProduct;
  quantity: number;
  vendorId: string;
  vendorName: string;
  unitPrice: number;
  distanceKm: number;
}

export interface B2BCartSummary {
  items: B2BCartItem[];
  subtotal: number;
  deliveryFeeTotal: number;
  collectionFeeTotal: number;
  grandTotal: number;
  vendorBreakdown: Array<{
    vendorId: string;
    vendorName: string;
    itemCount: number;
    subtotal: number;
    deliveryFee: number;
  }>;
}

export function calculateCartSummary(cartItems: B2BCartItem[], deliveryFeePerKm: number = 5.0): B2BCartSummary {
  const subtotal = cartItems.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);

  // Group by vendor to determine delivery fees per vendor
  const vendorMap = new Map<string, { vendorId: string; vendorName: string; itemCount: number; subtotal: number; maxDistance: number }>();
  cartItems.forEach(item => {
    const existing = vendorMap.get(item.vendorId) || {
      vendorId: item.vendorId,
      vendorName: item.vendorName,
      itemCount: 0,
      subtotal: 0,
      maxDistance: item.distanceKm || 0
    };
    existing.itemCount += item.quantity;
    existing.subtotal += item.unitPrice * item.quantity;
    existing.maxDistance = Math.max(existing.maxDistance, item.distanceKm || 0);
    vendorMap.set(item.vendorId, existing);
  });

  const vendorBreakdown = Array.from(vendorMap.values()).map(v => ({
    vendorId: v.vendorId,
    vendorName: v.vendorName,
    itemCount: v.itemCount,
    subtotal: v.subtotal,
    deliveryFee: Math.round(v.maxDistance * deliveryFeePerKm * 100) / 100
  }));

  const deliveryFeeTotal = vendorBreakdown.reduce((acc, v) => acc + v.deliveryFee, 0);
  const collectionFeeTotal = Math.round(subtotal * 0.04 * 100) / 100;
  const grandTotal = subtotal + deliveryFeeTotal + collectionFeeTotal;

  return {
    items: cartItems,
    subtotal,
    deliveryFeeTotal,
    collectionFeeTotal,
    grandTotal,
    vendorBreakdown
  };
}

// ============================================================================
// PART H: DIGITISE CASH VOUCHER ENGINE
// ============================================================================

export interface DigitiseCashVoucher {
  voucherId: string;
  farmerUid: string;
  farmerName: string;
  farmerPhone: string;
  amount: number;
  agentLocation: string;
  status: "Pending Deposit" | "Verified & Credited" | "Cancelled";
  createdAt: string;
  verifiedAt?: string;
  referenceCode: string;
}

export function generateDigitiseCashVoucher(
  farmerUid: string,
  farmerName: string,
  farmerPhone: string,
  amount: number,
  agentLocation: string
): DigitiseCashVoucher {
  const timestamp = Date.now();
  const ref = `DIG-${Math.floor(100000 + Math.random() * 900000)}`;
  return {
    voucherId: `vch-${timestamp}`,
    farmerUid,
    farmerName,
    farmerPhone,
    amount,
    agentLocation,
    status: "Pending Deposit",
    createdAt: new Date().toISOString(),
    referenceCode: ref
  };
}

// ============================================================================
// PART I & J: REPORTING & ANALYTICS ENGINE
// ============================================================================

export interface ConsignmentSettlementRow {
  skuId: string;
  skuName: string;
  supplierName: string;
  qtyConsigned: number;
  qtySold: number;
  unitPrice: number;
  grossSales: number;
  collectionFee4Percent: number;
  supplierPayoutOwed: number;
  agroDealerMargin: number;
}

export interface POSReconciliationData {
  totalSales: number;
  cashSales: number;
  mobileMoneySales: number;
  cardSales: number;
  cashOnHand: number;
  digitalLipilaBalance: number;
  reconciliationStatus: "Balanced" | "Discrepancy";
  discrepancyAmount: number;
}

export interface SupplierSalesVelocityRow {
  skuId: string;
  skuName: string;
  agroDealerName: string;
  consignedStock: number;
  unitsSold7Days: number;
  dailyVelocity: number;
  projectedStockoutDays: number;
}

export interface DealerReceivableAgingRow {
  dealerId: string;
  dealerName: string;
  totalOwed: number;
  current0to30: number;
  days31to60: number;
  days60Plus: number;
  status: "Current" | "Overdue" | "Critical";
}

export function generateConsignmentSettlementReport(skus: AgroDealerSKU[]): ConsignmentSettlementRow[] {
  return skus.map(sku => {
    const qtyConsigned = (sku.qtyOnHand || 0) + 50; // simulated batch
    const qtySold = Math.floor(qtyConsigned * 0.4);
    const grossSales = qtySold * (sku.sellingPrice || 100);
    const collectionFee4Percent = Math.round(grossSales * 0.04 * 100) / 100;
    const supplierPayoutOwed = Math.round(grossSales * 0.85 * 100) / 100; // 85% payout term
    const agroDealerMargin = Math.round((grossSales - supplierPayoutOwed) * 100) / 100;

    return {
      skuId: sku.id,
      skuName: sku.productName,
      supplierName: sku.supplierName || "Universal Inputs Ltd",
      qtyConsigned,
      qtySold,
      unitPrice: sku.sellingPrice || 100,
      grossSales,
      collectionFee4Percent,
      supplierPayoutOwed,
      agroDealerMargin
    };
  });
}

export function generatePOSReconciliation(orders: MarketplaceOrder[]): POSReconciliationData {
  let cashSales = 0;
  let mobileMoneySales = 0;
  let cardSales = 0;

  orders.forEach(o => {
    const prov = (o.paymentProvider || "").toLowerCase();
    if (prov.includes("cash")) {
      cashSales += o.totalAmount;
    } else if (prov.includes("card") || prov.includes("visa")) {
      cardSales += o.totalAmount;
    } else {
      mobileMoneySales += o.totalAmount;
    }
  });

  const totalSales = cashSales + mobileMoneySales + cardSales;
  const cashOnHand = cashSales;
  const digitalLipilaBalance = mobileMoneySales + cardSales;

  return {
    totalSales,
    cashSales,
    mobileMoneySales,
    cardSales,
    cashOnHand,
    digitalLipilaBalance,
    reconciliationStatus: "Balanced",
    discrepancyAmount: 0
  };
}

export function generateSupplierSalesVelocity(skus: AgroDealerSKU[], dealers: AgroDealerTenant[]): SupplierSalesVelocityRow[] {
  return skus.map(sku => {
    const dealer = dealers.find(d => d.id === sku.tenantId) || dealers[0];
    const unitsSold7Days = Math.floor(15 + Math.random() * 30);
    const dailyVelocity = Math.round((unitsSold7Days / 7) * 10) / 10;
    const consignedStock = sku.qtyOnHand || 20;
    const projectedStockoutDays = dailyVelocity > 0 ? Math.round(consignedStock / dailyVelocity) : 99;

    return {
      skuId: sku.id,
      skuName: sku.productName,
      agroDealerName: dealer ? dealer.businessName : "Choma Central Agro",
      consignedStock,
      unitsSold7Days,
      dailyVelocity,
      projectedStockoutDays
    };
  });
}

export function generateDealerReceivablesAging(dealers: AgroDealerTenant[]): DealerReceivableAgingRow[] {
  return dealers.map(dealer => {
    const totalOwed = Math.floor(12000 + Math.random() * 35000);
    const current0to30 = Math.round(totalOwed * 0.7);
    const days31to60 = Math.round(totalOwed * 0.2);
    const days60Plus = totalOwed - current0to30 - days31to60;

    return {
      dealerId: dealer.id,
      dealerName: dealer.businessName,
      totalOwed,
      current0to30,
      days31to60,
      days60Plus,
      status: days60Plus > 5000 ? "Critical" : days31to60 > 2000 ? "Overdue" : "Current"
    };
  });
}

// ============================================================================
// PART L: BULK INVENTORY IMPORT & ALLOCATION PARSER
// ============================================================================

export interface BulkSKUImportRow {
  name: string;
  category: string;
  unitPrice: number;
  qtyOnHand: number;
  reorderPoint: number;
  supplierName: string;
}

export function parseBulkSKUCSV(csvContent: string): BulkSKUImportRow[] {
  const lines = csvContent.split("\n").map(l => l.trim()).filter(l => l.length > 0);
  if (lines.length < 2) return [];

  const headers = lines[0].toLowerCase().split(",").map(h => h.trim());
  const rows: BulkSKUImportRow[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(",").map(v => v.trim());
    if (values.length >= 4) {
      rows.push({
        name: values[0] || `Bulk Item ${i}`,
        category: values[1] || "Seed",
        unitPrice: parseFloat(values[2]) || 100,
        qtyOnHand: parseInt(values[3], 10) || 50,
        reorderPoint: parseInt(values[4], 10) || 10,
        supplierName: values[5] || "Universal Inputs Ltd"
      });
    }
  }
  return rows;
}

/**
 * Farm Node & User Account Deletion Service
 * Handles data export backups, confirmation verification, Firestore and Auth purges,
 * phone/email release for re-registration, and Super Admin deletion tracking.
 */

import { auth, db } from "../firebase";
import { doc, getDoc, getDocs, collection, deleteDoc, setDoc, query, where } from "firebase/firestore";
import { invalidateTenantNodesCache } from "./tenantRegistryService";

export interface DeletedFarmNodeRecord {
  id: string;
  tenantId: string;
  farmName: string;
  ownerName: string;
  email: string;
  phone: string;
  ownerEmail?: string;
  ownerPhone?: string;
  role: string;
  tenantType: string;
  deletedBy: "Self (User)" | "Super Admin" | string;
  deletedByEmail: string;
  deletedAt: string;
  reason: string;
  backupDownloaded: boolean;
  backupDownloadedAt?: string;
  emailPhoneReleased: boolean;
  credentialsReleased?: boolean;
  recordsSummary: {
    cropsCount?: number;
    livestockCount?: number;
    salesCount?: number;
    expensesCount?: number;
    invoicesCount?: number;
    employeesCount?: number;
    feedLogsCount?: number;
    inventoryCount?: number;
    totalRecords?: number;
  };
  details?: Record<string, any>;
}

const STORAGE_KEYS = {
  DELETED_NODES: "mabala_deleted_farm_nodes",
  REGISTERED_USERS: "mabala_registered_users",
  CUSTOMERS: "mabala_customers",
  PASSWORDS: "mabala_user_passwords"
};

/**
 * Gather complete farm node data across all local storage keys and Firestore collections
 */
export function compileFarmNodeData(tenantId: string, userProfile?: any): Record<string, any> {
  const farmData: Record<string, any> = {
    metadata: {
      tenantId,
      exportedAt: new Date().toISOString(),
      exportType: "Full Farm Node Pre-Deletion Archive",
      platform: "Mabala Digital Farm Platform",
      userProfile: userProfile || null
    },
    collections: {}
  };

  // 1. Gather all tenant-specific local storage items
  const tenantPrefix = `mabala_${tenantId}_`;
  const generalKeys = [
    "mabala_crops",
    "mabala_livestock",
    "mabala_sales",
    "mabala_expenses",
    "mabala_invoices",
    "mabala_employees",
    "mabala_inventory",
    "mabala_customers",
    "mabala_feed_ingredients",
    "mabala_feed_formulations",
    "mabala_daily_feed_logs",
    "mabala_poultry_batches",
    "mabala_poultry_daily_logs",
    "mabala_aquaculture_ponds",
    "mabala_farm_assets",
    "mabala_farm_tasks",
    "mabala_farm_plots",
    "mabala_audit_logs",
    "mabala_settings",
    "mabala_agc_profiles",
    "mabala_agc_applications",
    "mabala_agc_loans"
  ];

  // Scan localStorage
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key) continue;

      if (key.startsWith(tenantPrefix)) {
        const subKey = key.replace(tenantPrefix, "");
        const raw = localStorage.getItem(key);
        if (raw) {
          try {
            farmData.collections[subKey] = JSON.parse(raw);
          } catch {
            farmData.collections[subKey] = raw;
          }
        }
      } else if (generalKeys.includes(key)) {
        const raw = localStorage.getItem(key);
        if (raw) {
          try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
              // Filter by tenantId or farmId if items have tenant metadata
              const tenantItems = parsed.filter(item => 
                item?.tenantId === tenantId || 
                item?.farmId === tenantId || 
                item?.farmNodeId === tenantId ||
                item?.uid === tenantId
              );
              farmData.collections[key.replace("mabala_", "")] = tenantItems.length > 0 ? tenantItems : parsed;
            } else {
              farmData.collections[key.replace("mabala_", "")] = parsed;
            }
          } catch {
            farmData.collections[key.replace("mabala_", "")] = raw;
          }
        }
      }
    }
  } catch (err) {
    console.warn("[NodeDeletionService] Warning compiling localStorage:", err);
  }

  return farmData;
}

/**
 * Trigger an instant browser JSON file download of the compiled farm node data
 */
export function downloadFarmNodeBackupArchive(
  tenantId: string,
  farmName: string,
  userProfile?: any
): { success: boolean; fileName: string; timestamp: string; totalRecords: number } {
  const data = compileFarmNodeData(tenantId, userProfile);
  
  // Calculate total record count
  let totalRecords = 0;
  Object.values(data.collections).forEach((col: any) => {
    if (Array.isArray(col)) totalRecords += col.length;
    else if (col && typeof col === "object") totalRecords += Object.keys(col).length;
    else if (col) totalRecords += 1;
  });

  const timestamp = new Date().toISOString();
  const safeFarmName = (farmName || "Farm_Node").replace(/[^a-zA-Z0-9_-]/g, "_");
  const dateStr = timestamp.split("T")[0];
  const timeStr = timestamp.split("T")[1].replace(/[:.]/g, "-").substring(0, 8);
  const fileName = `mabala_backup_${safeFarmName}_${tenantId}_${dateStr}_${timeStr}.json`;

  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  return {
    success: true,
    fileName,
    timestamp,
    totalRecords
  };
}

/**
 * Record a deleted farm node event in localStorage and Firestore for Super Admin tracking
 */
export async function trackDeletedFarmNode(record: DeletedFarmNodeRecord): Promise<void> {
  // 1. Save to Local Storage
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DELETED_NODES);
    const list: DeletedFarmNodeRecord[] = raw ? JSON.parse(raw) : [];
    // Remove if already exists with same id or tenantId
    const updated = [record, ...list.filter(item => item.id !== record.id && item.tenantId !== record.tenantId)];
    localStorage.setItem(STORAGE_KEYS.DELETED_NODES, JSON.stringify(updated));
  } catch (err) {
    console.error("[NodeDeletionService] Error saving to localStorage:", err);
  }

  // 2. Save to Firestore (deleted_farm_nodes collection)
  if (db) {
    try {
      const docRef = doc(db, "deleted_farm_nodes", record.id);
      await setDoc(docRef, record, { merge: true });
    } catch (err) {
      console.warn("[NodeDeletionService] Firestore tracking warning (continuing):", err);
    }
  }
}

/**
 * Retrieve all tracked deleted farm nodes from Firestore and LocalStorage
 */
export async function getDeletedFarmNodesTracker(): Promise<DeletedFarmNodeRecord[]> {
  const map = new Map<string, DeletedFarmNodeRecord>();

  // 1. LocalStorage source
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DELETED_NODES);
    if (raw) {
      const localList: DeletedFarmNodeRecord[] = JSON.parse(raw);
      localList.forEach(item => map.set(item.id, item));
    }
  } catch (e) {
    console.warn("[NodeDeletionService] Error reading local deleted nodes:", e);
  }

  // 2. Firestore source
  if (db) {
    try {
      const snap = await getDocs(collection(db, "deleted_farm_nodes"));
      snap.forEach(docSnap => {
        const item = docSnap.data() as DeletedFarmNodeRecord;
        if (item && item.id) {
          map.set(item.id, item);
        }
      });
    } catch (e) {
      console.warn("[NodeDeletionService] Firestore fetch skipped/failed:", e);
    }
  }

  return Array.from(map.values()).sort((a, b) => 
    new Date(b.deletedAt).getTime() - new Date(a.deletedAt).getTime()
  );
}

/**
 * Clean up local storage keys for the deleted tenant
 */
export function purgeLocalTenantData(tenantId: string, email?: string, phone?: string): void {
  try {
    const prefix = `mabala_${tenantId}_`;
    const keysToRemove: string[] = [];

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith(prefix) || key.includes(tenantId))) {
        keysToRemove.push(key);
      }
    }

    keysToRemove.forEach(k => localStorage.removeItem(k));

    // Also remove from user password dict if exists
    if (email) {
      const passDictStr = localStorage.getItem(STORAGE_KEYS.PASSWORDS);
      if (passDictStr) {
        try {
          const passDict = JSON.parse(passDictStr);
          delete passDict[email.toLowerCase()];
          localStorage.setItem(STORAGE_KEYS.PASSWORDS, JSON.stringify(passDict));
        } catch {}
      }
    }

    // Also purge credit wallet, credit ledger, and user directory entries
    const creditKeys = [
      `mabala_credit_wallet_${tenantId}`,
      `mabala_credit_ledger_${tenantId}`,
      `mabala_credits_${tenantId}`,
      `mabala_wallet_${tenantId}`,
      `mabala_${tenantId}_credit_wallet`,
      `mabala_${tenantId}_creditLedger`
    ];
    creditKeys.forEach(k => localStorage.removeItem(k));

    // Purge from global user directory cache if stored locally
    const regUsersRaw = localStorage.getItem(STORAGE_KEYS.REGISTERED_USERS);
    if (regUsersRaw) {
      try {
        const regUsers = JSON.parse(regUsersRaw);
        if (Array.isArray(regUsers)) {
          const filtered = regUsers.filter((u: any) => u.uid !== tenantId && u.tenantId !== tenantId && (!email || u.email?.toLowerCase() !== email.toLowerCase()));
          localStorage.setItem(STORAGE_KEYS.REGISTERED_USERS, JSON.stringify(filtered));
        }
      } catch {}
    }

    // Purge from credit transactions cache if stored locally
    const creditTxRaw = localStorage.getItem("mabala_credit_transactions");
    if (creditTxRaw) {
      try {
        const creditTxs = JSON.parse(creditTxRaw);
        if (Array.isArray(creditTxs)) {
          const filtered = creditTxs.filter((tx: any) => tx.tenantId !== tenantId && (!email || tx.tenantEmail?.toLowerCase() !== email.toLowerCase()));
          localStorage.setItem("mabala_credit_transactions", JSON.stringify(filtered));
        }
      } catch {}
    }

    // Clean up customer directory of this tenant's items
    const custRaw = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
    if (custRaw) {
      try {
        const custs = JSON.parse(custRaw);
        if (Array.isArray(custs)) {
          const filtered = custs.filter(c => c.tenantId !== tenantId && c.id !== tenantId);
          localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(filtered));
        }
      } catch {}
    }
  } catch (err) {
    console.warn("[NodeDeletionService] Error purging local storage:", err);
  }
}

/**
 * Execute Self-Service Farm Node Deletion (For Farmer, Agro Dealer, Supplier, Agronomist, Offtaker, Partner)
 */
export async function executeSelfFarmNodeDeletion(params: {
  tenantId: string;
  userEmail: string;
  userName: string;
  farmName: string;
  userPhone: string;
  role: string;
  tenantType: string;
  reason: string;
  backupDownloaded: boolean;
  backupDownloadedAt?: string;
}): Promise<{ success: boolean; message: string }> {
  const {
    tenantId,
    userEmail,
    userName,
    farmName,
    userPhone,
    role,
    tenantType,
    reason,
    backupDownloaded,
    backupDownloadedAt
  } = params;

  const deletedAt = new Date().toISOString();
  const deletionAuditId = `del_${tenantId}_${Date.now()}`;

  // 1. Gather record counts before deletion
  const compiledData = compileFarmNodeData(tenantId);
  const crops = compiledData.collections.crops || [];
  const livestock = compiledData.collections.livestock || [];
  const sales = compiledData.collections.sales || [];
  const expenses = compiledData.collections.expenses || [];
  const invoices = compiledData.collections.invoices || [];
  const employees = compiledData.collections.employees || [];
  const feedLogs = compiledData.collections.daily_feed_logs || [];
  const inventory = compiledData.collections.inventory || [];

  const auditRecord: DeletedFarmNodeRecord = {
    id: deletionAuditId,
    tenantId,
    farmName: farmName || `${userName}'s Farm Node`,
    ownerName: userName || userEmail.split("@")[0],
    email: userEmail,
    phone: userPhone || "Not Provided",
    role: role || "Farmer",
    tenantType: tenantType || "farmer",
    deletedBy: "Self (User)",
    deletedByEmail: userEmail,
    deletedAt,
    reason: reason || "User initiated permanent account & farm node deletion.",
    backupDownloaded,
    backupDownloadedAt: backupDownloadedAt || deletedAt,
    emailPhoneReleased: true,
    recordsSummary: {
      cropsCount: Array.isArray(crops) ? crops.length : 0,
      livestockCount: Array.isArray(livestock) ? livestock.length : 0,
      salesCount: Array.isArray(sales) ? sales.length : 0,
      expensesCount: Array.isArray(expenses) ? expenses.length : 0,
      invoicesCount: Array.isArray(invoices) ? invoices.length : 0,
      employeesCount: Array.isArray(employees) ? employees.length : 0,
      feedLogsCount: Array.isArray(feedLogs) ? feedLogs.length : 0,
      inventoryCount: Array.isArray(inventory) ? inventory.length : 0,
      totalRecords: Object.values(compiledData.collections).reduce<number>((sum: number, col: any) => {
        return sum + (Array.isArray(col) ? col.length : 1);
      }, 0)
    }
  };

  // 2. Track deletion in Super Admin tracker
  await trackDeletedFarmNode(auditRecord);

  // 3. Purge Firestore documents
  if (db) {
    try {
      // Hard delete user profile & modules
      const userRef = doc(db, "users_data", tenantId);
      await deleteDoc(userRef);

      // Clean up active_sessions
      if (userEmail) {
        try {
          await deleteDoc(doc(db, "active_sessions", userEmail.toLowerCase()));
        } catch {}
      }

      // Clean up partners or offtakers if present
      try {
        await deleteDoc(doc(db, "partners", tenantId));
        await deleteDoc(doc(db, "offtakers", tenantId));
        await deleteDoc(doc(db, "tenants", tenantId, "wallet", "credits"));
        await deleteDoc(doc(db, "tenants", tenantId, "credit_wallet", "default"));
      } catch {}
    } catch (dbErr) {
      console.warn("[NodeDeletionService] Warning during Firestore deletion:", dbErr);
    }
  }

  // 4. Request backend cascade delete & Auth user removal to free email & phone
  try {
    const idToken = await auth.currentUser?.getIdToken();
    await fetch("/api/account/delete-node", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(idToken ? { Authorization: `Bearer ${idToken}` } : {})
      },
      body: JSON.stringify({
        tenantId,
        userEmail,
        userPhone,
        reason,
        auditRecord
      })
    });
  } catch (apiErr) {
    console.warn("[NodeDeletionService] Server delete API note:", apiErr);
  }

  // 5. Purge local tenant storage
  purgeLocalTenantData(tenantId, userEmail, userPhone);

  return {
    success: true,
    message: `Farm node "${farmName}" and your user account have been permanently deleted. Your email (${userEmail}) and phone number are now released and can be used to create a new farm node anytime.`
  };
}

/**
 * Execute Super Admin Farm Node Deletion for any tenant on the platform
 */
export async function executeSuperAdminFarmNodeDeletion(params: {
  tenantId: string;
  farmName?: string;
  tenantName?: string;
  ownerEmail?: string;
  tenantEmail?: string;
  ownerPhone?: string;
  tenantPhone?: string;
  role?: string;
  tenantType?: string;
  reason: string;
  adminEmail?: string;
  superAdminEmail?: string;
  adminUid?: string;
  confirmationName?: string;
  backupDownloaded?: boolean;
}): Promise<{ success: boolean; message: string; error?: string }> {
  const {
    tenantId,
    farmName = "Farm Node",
    tenantName,
    ownerEmail,
    tenantEmail = ownerEmail || "",
    ownerPhone,
    tenantPhone = ownerPhone || "Not Provided",
    role = "farmer",
    tenantType = "farmer",
    reason,
    adminEmail = "support@mabala.cloud",
    superAdminEmail = adminEmail,
    adminUid = "icIoBG4eN5VOw2BvhNiFUnUqmsX2",
    confirmationName,
    backupDownloaded = true
  } = params;

  const deletedAt = new Date().toISOString();
  const deletionAuditId = `del_admin_${tenantId}_${Date.now()}`;

  // 1. Gather record counts
  const compiledData = compileFarmNodeData(tenantId);
  const auditRecord: DeletedFarmNodeRecord = {
    id: deletionAuditId,
    tenantId,
    farmName: farmName || tenantName || "Farm Node",
    ownerName: tenantName || tenantEmail.split("@")[0],
    email: tenantEmail,
    phone: tenantPhone || "Not Provided",
    ownerEmail: tenantEmail,
    ownerPhone: tenantPhone,
    role: role || "Farmer",
    tenantType: tenantType || "farmer",
    deletedBy: "Super Admin",
    deletedByEmail: superAdminEmail || adminEmail || "support@mabala.cloud",
    deletedAt,
    reason: reason || "Super Admin administrative farm node purge.",
    backupDownloaded,
    backupDownloadedAt: backupDownloaded ? deletedAt : undefined,
    emailPhoneReleased: true,
    recordsSummary: {
      cropsCount: Array.isArray(compiledData.collections.crops) ? compiledData.collections.crops.length : 0,
      livestockCount: Array.isArray(compiledData.collections.livestock) ? compiledData.collections.livestock.length : 0,
      salesCount: Array.isArray(compiledData.collections.sales) ? compiledData.collections.sales.length : 0,
      expensesCount: Array.isArray(compiledData.collections.expenses) ? compiledData.collections.expenses.length : 0,
      invoicesCount: Array.isArray(compiledData.collections.invoices) ? compiledData.collections.invoices.length : 0,
      employeesCount: Array.isArray(compiledData.collections.employees) ? compiledData.collections.employees.length : 0,
      feedLogsCount: Array.isArray(compiledData.collections.daily_feed_logs) ? compiledData.collections.daily_feed_logs.length : 0,
      inventoryCount: Array.isArray(compiledData.collections.inventory) ? compiledData.collections.inventory.length : 0,
      totalRecords: Object.values(compiledData.collections).reduce<number>((sum: number, col: any) => {
        return sum + (Array.isArray(col) ? col.length : 1);
      }, 0)
    }
  };

  // 2. Track deletion in Super Admin Tracker
  await trackDeletedFarmNode(auditRecord);

  // 3. Call backend endpoint to delete from Firebase Auth, Firestore, and release credentials
  try {
    const idToken = await auth.currentUser?.getIdToken();
    const effectiveAdminEmail = superAdminEmail || adminEmail || "support@mabala.cloud";
    const effectiveAdminUid = adminUid || "icIoBG4eN5VOw2BvhNiFUnUqmsX2";
    const confirmedText = confirmationName || farmName || tenantName || tenantEmail || tenantId;

    const response = await fetch("/api/admin/tenant/delete", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-mabala-super-email": effectiveAdminEmail,
        "x-mabala-super-uid": effectiveAdminUid,
        ...(idToken ? { Authorization: `Bearer ${idToken}` } : {})
      },
      body: JSON.stringify({
        tenantId,
        superAdminEmail: effectiveAdminEmail,
        superAdminUid: effectiveAdminUid,
        reason,
        confirmationName: confirmedText,
        confirmationText: confirmedText,
        auditRecord
      })
    });

    const resData = await response.json();
    if (!response.ok) {
      return {
        success: false,
        message: resData.error || "Failed to purge node on server.",
        error: resData.error
      };
    }
  } catch (err: any) {
    console.warn("[NodeDeletionService] Super Admin server delete note:", err);
  }

  // 4. Firestore direct cleanup
  if (db) {
    try {
      await deleteDoc(doc(db, "users_data", tenantId));
      if (tenantEmail) {
        await deleteDoc(doc(db, "active_sessions", tenantEmail.toLowerCase()));
      }
      await deleteDoc(doc(db, "partners", tenantId));
      await deleteDoc(doc(db, "offtakers", tenantId));
      // Delete credit wallet and ledger references
      await deleteDoc(doc(db, "tenants", tenantId, "wallet", "credits"));
      await deleteDoc(doc(db, "tenants", tenantId, "credit_wallet", "default"));
    } catch {}
  }

  // 5. Purge local storage
  purgeLocalTenantData(tenantId, tenantEmail, tenantPhone);

  return {
    success: true,
    message: `Farm node "${farmName || tenantName}" has been successfully deleted by Super Admin. Email (${tenantEmail}) and phone number are released for new registration.`
  };
}

export interface BulkNodeDeletionOptions {
  nodes: Array<{
    tenantId?: string;
    uid?: string;
    id?: string;
    farmName?: string;
    displayName?: string;
    email?: string;
    tenantEmail?: string;
    ownerEmail?: string;
    phone?: string;
    tenantPhone?: string;
    role?: string;
  }>;
  reason: string;
  superAdminEmail: string;
  superAdminUid?: string;
}

/**
 * Executes high-performance bulk deletion of multiple farm nodes for Super Admins.
 * Cascades across server, database, and local caches in a single operation while logging reasons.
 */
export async function executeBulkFarmNodeDeletion(options: BulkNodeDeletionOptions): Promise<{
  success: boolean;
  message: string;
  deletedCount: number;
  errors?: any[];
}> {
  const { nodes, reason, superAdminEmail, superAdminUid } = options;
  if (!nodes || nodes.length === 0) {
    return { success: false, message: "No farm nodes selected for deletion.", deletedCount: 0 };
  }

  const trimmedReason = reason.trim();
  if (!trimmedReason) {
    return { success: false, message: "A reason is strictly required for audit purposes.", deletedCount: 0 };
  }

  const nodeIds = nodes.map(n => n.tenantId || n.uid || n.id || "").filter(Boolean);
  if (nodeIds.length === 0) {
    return { success: false, message: "Selected nodes do not contain valid IDs.", deletedCount: 0 };
  }

  let idToken = "";
  try {
    const currentUser = auth.currentUser;
    if (currentUser) {
      idToken = await currentUser.getIdToken();
    }
  } catch (_) {}

  const effectiveAdminEmail = superAdminEmail || "support@mabala.cloud";
  const effectiveAdminUid = superAdminUid || "icIoBG4eN5VOw2BvhNiFUnUqmsX2";

  // 1. Send bulk delete request to backend endpoint
  let backendResult: any = null;
  try {
    const response = await fetch("/api/admin/nodes/bulk-delete", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-mabala-super-email": effectiveAdminEmail,
        "x-mabala-super-uid": effectiveAdminUid,
        ...(idToken ? { Authorization: `Bearer ${idToken}` } : {})
      },
      body: JSON.stringify({
        nodeIds,
        reason: trimmedReason,
        superAdminEmail: effectiveAdminEmail,
        superAdminUid: effectiveAdminUid
      })
    });

    backendResult = await response.json();
    if (!response.ok) {
      return {
        success: false,
        message: backendResult.error || "Failed to execute bulk deletion on server.",
        deletedCount: 0
      };
    }
  } catch (err: any) {
    console.warn("[NodeDeletionService] Bulk delete backend note:", err);
  }

  // 2. Direct Firestore cleanup & local purge for each node
  for (const node of nodes) {
    const tid = node.tenantId || node.uid || node.id || "";
    const email = (node.email || node.tenantEmail || node.ownerEmail || "").toLowerCase();
    const phone = node.phone || node.tenantPhone || "";
    const name = node.farmName || node.displayName || tid;

    if (db && tid) {
      try {
        await deleteDoc(doc(db, "users_data", tid));
        if (email) {
          await deleteDoc(doc(db, "active_sessions", email));
        }
        await deleteDoc(doc(db, "partners", tid));
        await deleteDoc(doc(db, "offtakers", tid));
        await deleteDoc(doc(db, "tenants", tid, "wallet", "credits"));
        await deleteDoc(doc(db, "tenants", tid, "credit_wallet", "default"));

        // Audit entry in deleted_farm_nodes
        const auditId = "del_" + tid + "_" + Date.now();
        await setDoc(doc(db, "deleted_farm_nodes", auditId), {
          id: auditId,
          tenantId: tid,
          farmName: name,
          email,
          phone,
          deletedBy: "Super Admin",
          deletedByEmail: effectiveAdminEmail,
          deletedAt: new Date().toISOString(),
          reason: trimmedReason,
          emailPhoneReleased: true
        }, { merge: true });
      } catch (_) {}
    }

    purgeLocalTenantData(tid, email, phone);
  }

  // Invalidate in-memory tenant registry cache so lists refresh immediately
  invalidateTenantNodesCache();

  return {
    success: true,
    message: `Successfully deleted ${nodes.length} farm node(s). Audit records have been logged and all associated credentials released.`,
    deletedCount: nodes.length
  };
}

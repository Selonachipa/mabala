import { getStatutoryTaxConfig, StatutoryTaxConfig } from "./taxConfigService";

export interface FinancialRecord {
  id: string;
  amount?: number;
  revenue?: number;
  salary?: number;
  taxAmount?: number;
  netPay?: number;
  subtotal?: number;
  total?: number;
  status?: string;
  isPosted?: boolean;
  isReversal?: boolean;
  linkedOriginalId?: string;
  correctedFromId?: string;
  timestamp?: string;
  date?: string;
  category?: string;
  description?: string;
  taxConfigApplied?: {
    rateName: string;
    ratePercent: number;
    jurisdiction: string;
    appliedAt: string;
  };
  [key: string]: any;
}

export interface ReconciliationReport {
  timestamp: string;
  tenantId: string;
  totalSourceRecords: number;
  sourceSalesTotal: number;
  sourceExpensesTotal: number;
  sourcePayrollTotal: number;
  sourceTaxTotal: number;
  rollupSalesTotal: number;
  rollupExpensesTotal: number;
  varianceSales: number;
  varianceExpenses: number;
  status: "BALANCED" | "VARIANCE_DETECTED";
  reconciledBy: string;
  details: string[];
}

/**
 * Financial Guard: Ensures posted financial records cannot have their source amounts mutated in-place.
 * Throws an error if amount fields are altered on a posted record.
 */
export function validateFinancialMutationGuard(
  originalRecord: FinancialRecord,
  updatedRecord: FinancialRecord
): void {
  const isPosted = originalRecord.status === "POSTED" || originalRecord.status === "posted" || originalRecord.isPosted === true;
  if (!isPosted) return; // Drafts or unposted records can be edited directly

  const fieldsToCheck = ["amount", "revenue", "salary", "taxAmount", "netPay", "subtotal", "total"];
  for (const field of fieldsToCheck) {
    if (originalRecord[field] !== undefined && updatedRecord[field] !== undefined) {
      if (Number(originalRecord[field]) !== Number(updatedRecord[field])) {
        throw new Error(
          `FINANCIAL DATA INTEGRITY VIOLATION: Cannot mutate posted amount field '${field}' on record ${originalRecord.id}. Posted financial entries are append-only. Use linked reversal + new entry correction.`
        );
      }
    }
  }
}

/**
 * Creates a linked reversal + new entry pair for correcting a posted financial transaction.
 * Never overwrites original record amount.
 */
export function createLinkedFinancialCorrection(
  originalRecord: FinancialRecord,
  newFigures: Partial<FinancialRecord>,
  userEmail: string = "system@mabala.cloud"
): {
  updatedOriginal: FinancialRecord;
  reversalEntry: FinancialRecord;
  correctedEntry: FinancialRecord;
} {
  const nowIso = new Date().toISOString();
  const origAmount = Number(originalRecord.amount || originalRecord.revenue || originalRecord.salary || originalRecord.total || 0);

  // 1. Updated Original (marked REVERSED_LINKED)
  const updatedOriginal: FinancialRecord = {
    ...originalRecord,
    status: "REVERSED_LINKED",
    isPosted: false,
    reversedAt: nowIso,
    reversedBy: userEmail
  };

  // 2. Reversal Entry (Mirror entry with negative amounts)
  const reversalEntry: FinancialRecord = {
    ...originalRecord,
    id: `REV-${originalRecord.id}-${Date.now().toString().slice(-4)}`,
    amount: -origAmount,
    revenue: originalRecord.revenue !== undefined ? -Number(originalRecord.revenue) : undefined,
    salary: originalRecord.salary !== undefined ? -Number(originalRecord.salary) : undefined,
    total: originalRecord.total !== undefined ? -Number(originalRecord.total) : undefined,
    status: "REVERSED",
    isPosted: true,
    isReversal: true,
    linkedOriginalId: originalRecord.id,
    timestamp: nowIso,
    description: `[Reversal] Linked reversal for entry #${originalRecord.id}`
  };

  // 3. New Corrected Entry
  const newAmount = Number(newFigures.amount || newFigures.revenue || newFigures.salary || newFigures.total || 0);
  const correctedEntry: FinancialRecord = {
    ...originalRecord,
    ...newFigures,
    id: `CORR-${originalRecord.id}-${Date.now().toString().slice(-4)}`,
    amount: newAmount,
    status: "POSTED",
    isPosted: true,
    isReversal: false,
    correctedFromId: originalRecord.id,
    timestamp: nowIso,
    description: newFigures.description || `[Correction] Corrected entry linked from #${originalRecord.id}`
  };

  return { updatedOriginal, reversalEntry, correctedEntry };
}

/**
 * Statutory Tax Single Source of Truth Lookup
 * Guarantees that any tax calculation references the same rate config from getStatutoryTaxConfig().
 */
export function getStatutoryTaxRateForCalculation(
  taxType: "VAT" | "TOT" | "PAYE" | "SALES_TAX" | "CUSTOM" = "VAT"
): { ratePercent: number; taxName: string; configRef: StatutoryTaxConfig } {
  const config = getStatutoryTaxConfig();
  let ratePercent = 0;
  let taxName = "Statutory Tax";

  switch (taxType) {
    case "VAT":
      ratePercent = config.vatRate;
      taxName = `VAT (${config.vatRate}%)`;
      break;
    case "TOT":
      ratePercent = config.totRate;
      taxName = `Turnover Tax (${config.totRate}%)`;
      break;
    case "PAYE":
      ratePercent = config.payeFlatRate;
      taxName = `PAYE Statutory (${config.payeFlatRate}%)`;
      break;
    case "SALES_TAX":
      ratePercent = config.salesTaxRate;
      taxName = `Sales Tax (${config.salesTaxRate}%)`;
      break;
    case "CUSTOM":
      ratePercent = config.customTaxRate;
      taxName = `${config.customTaxName} (${config.customTaxRate}%)`;
      break;
  }

  return { ratePercent, taxName, configRef: config };
}

/**
 * Reconcile Rollups Vs Source
 * Computes deterministic sums directly from posted source records, diffs against rollups,
 * and produces a verifiably reconcilable audit report.
 */
export function reconcileRollupsVsSource(
  tenantId: string,
  sourceSales: FinancialRecord[] = [],
  sourceExpenses: FinancialRecord[] = [],
  sourcePayroll: FinancialRecord[] = [],
  sourceTaxes: FinancialRecord[] = [],
  cachedSalesRollupTotal: number = 0,
  cachedExpensesRollupTotal: number = 0,
  reconciledBy: string = "Super Admin"
): ReconciliationReport {
  // Sum only posted records (ignoring reversed entries or taking reversals into account)
  const postedSales = sourceSales.filter(s => s.status !== "REVERSED_LINKED" && s.status !== "DRAFT");
  const sourceSalesTotal = postedSales.reduce((acc, s) => acc + Number(s.revenue || s.amount || s.total || 0), 0);

  const postedExpenses = sourceExpenses.filter(e => e.status !== "REVERSED_LINKED" && e.status !== "DRAFT");
  const sourceExpensesTotal = postedExpenses.reduce((acc, e) => acc + Number(e.amount || e.total || 0), 0);

  const postedPayroll = sourcePayroll.filter(p => p.status !== "REVERSED_LINKED" && p.status !== "DRAFT");
  const sourcePayrollTotal = postedPayroll.reduce((acc, p) => acc + Number(p.netPay || p.salary || p.amount || 0), 0);

  const postedTaxes = sourceTaxes.filter(t => t.status !== "REVERSED_LINKED" && t.status !== "DRAFT");
  const sourceTaxTotal = postedTaxes.reduce((acc, t) => acc + Number(t.taxAmount || t.amount || 0), 0);

  const varianceSales = Math.abs(sourceSalesTotal - cachedSalesRollupTotal);
  const varianceExpenses = Math.abs(sourceExpensesTotal - cachedExpensesRollupTotal);

  const hasVariance = varianceSales > 0.01 || varianceExpenses > 0.01;

  const details: string[] = [
    `Processed ${postedSales.length} posted sales lines. Source Revenue = ZMW ${sourceSalesTotal.toFixed(2)}. Rollup = ZMW ${cachedSalesRollupTotal.toFixed(2)}. Variance = ZMW ${varianceSales.toFixed(2)}.`,
    `Processed ${postedExpenses.length} posted expense lines. Source Expenses = ZMW ${sourceExpensesTotal.toFixed(2)}. Rollup = ZMW ${cachedExpensesRollupTotal.toFixed(2)}. Variance = ZMW ${varianceExpenses.toFixed(2)}.`,
    `Processed ${postedPayroll.length} posted payroll runs. Total Net Pay = ZMW ${sourcePayrollTotal.toFixed(2)}.`,
    `Processed ${postedTaxes.length} statutory tax entries. Total Tax = ZMW ${sourceTaxTotal.toFixed(2)}.`
  ];

  if (hasVariance) {
    details.push(`⚠️ VARIANCE DETECTED: Rollup cache drifted by ZMW ${(varianceSales + varianceExpenses).toFixed(2)}. Rollups should be regenerated deterministically.`);
  } else {
    details.push(`✅ ZERO DRIFT: All rollup summaries match raw source transaction lines with 100% mathematical precision.`);
  }

  return {
    timestamp: new Date().toISOString(),
    tenantId,
    totalSourceRecords: postedSales.length + postedExpenses.length + postedPayroll.length + postedTaxes.length,
    sourceSalesTotal,
    sourceExpensesTotal,
    sourcePayrollTotal,
    sourceTaxTotal,
    rollupSalesTotal: cachedSalesRollupTotal,
    rollupExpensesTotal: cachedExpensesRollupTotal,
    varianceSales,
    varianceExpenses,
    status: hasVariance ? "VARIANCE_DETECTED" : "BALANCED",
    reconciledBy,
    details
  };
}

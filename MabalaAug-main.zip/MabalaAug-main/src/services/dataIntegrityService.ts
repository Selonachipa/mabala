import { doc, runTransaction, setDoc, getDoc, collection, getDocs } from "firebase/firestore";

/**
 * Helper to construct a DocumentReference compatible with Client SDK, Admin SDK, and Mock DBs
 */
function resolveDocRef(dbInstance: any, collectionPath: string, docId?: string, ...subPaths: string[]) {
  if (typeof dbInstance?.doc === "function") {
    const fullPath = [collectionPath, docId, ...subPaths].filter(Boolean).join("/");
    return dbInstance.doc(fullPath);
  }
  if (docId) {
    if (subPaths.length > 0) {
      return doc(dbInstance, collectionPath, docId, ...subPaths);
    }
    return doc(dbInstance, collectionPath, docId);
  }
  return doc(dbInstance, collectionPath);
}

/**
 * Helper to get document data from a docRef compatible with Client, Admin, or Mock DBs
 */
async function resolveGetDoc(dbInstance: any, docRef: any) {
  if (typeof dbInstance?.getDoc === "function") {
    return await dbInstance.getDoc(docRef);
  }
  if (typeof docRef?.get === "function") {
    const snap = await docRef.get();
    return {
      exists: () => (typeof snap.exists === "function" ? snap.exists() : !!snap.exists),
      data: () => (typeof snap.data === "function" ? snap.data() : snap)
    };
  }
  const snap = await getDoc(docRef);
  return {
    exists: () => snap.exists(),
    data: () => snap.data()
  };
}

/**
 * Helper to set document data compatible with Client, Admin, or Mock DBs
 */
async function resolveSetDoc(dbInstance: any, docRef: any, data: any, options: any = { merge: true }) {
  if (typeof dbInstance?.setDoc === "function") {
    return await dbInstance.setDoc(docRef, data, options);
  }
  if (typeof docRef?.set === "function") {
    return await docRef.set(data, options);
  }
  return await setDoc(docRef, data, options);
}

/**
 * Helper to get collection docs compatible with Client, Admin, or Mock DBs
 */
async function resolveGetDocs(dbInstance: any, collectionPath: string) {
  if (typeof dbInstance?.getDocs === "function") {
    const colRef = resolveDocRef(dbInstance, collectionPath);
    return await dbInstance.getDocs(colRef);
  }
  if (typeof dbInstance?.collection === "function") {
    const snap = await dbInstance.collection(collectionPath).get();
    const docs: any[] = [];
    if (snap && snap.forEach) {
      snap.forEach((d: any) => {
        docs.push({
          id: d.id,
          data: () => (typeof d.data === "function" ? d.data() : d)
        });
      });
    } else if (snap && snap.docs) {
      return snap;
    }
    return { docs };
  }
  const colRef = collection(dbInstance, collectionPath);
  return await getDocs(colRef);
}

/**
 * Interface for soft-deleted audit fields
 */
export interface SoftDeleteMetadata {
  isDeleted: boolean;
  status: "deleted";
  deletedAt: string;
  deletedBy: string;
  previousStatus?: string;
}

/**
 * Interface for Reconciliation Alert
 */
export interface ReconciliationAlert {
  alertId: string;
  tenantId: string;
  tenantName?: string;
  walletBalance: number;
  ledgerSum: number;
  discrepancy: number;
  flaggedAt: string;
  status: "UNRESOLVED" | "RESOLVED";
  notes?: string;
}

/**
 * 1. Shared softDelete helper function:
 * Converts any hard-delete into a soft delete by marking:
 * isDeleted: true, status: 'deleted', deletedAt: ISO string, deletedBy: operator ID.
 * Document remains permanently in Firestore.
 */
export async function softDelete(
  dbInstance: any,
  collectionPath: string,
  docId: string,
  deletedBy: string = "system_operator"
): Promise<{ success: boolean; docId: string; deletedAt: string }> {
  if (!dbInstance || !collectionPath || !docId) {
    throw new Error("softDelete requires dbInstance, collectionPath, and docId");
  }

  const docRef = resolveDocRef(dbInstance, collectionPath, docId);
  const docSnap = await resolveGetDoc(dbInstance, docRef);

  if (!docSnap.exists()) {
    throw new Error(`Document ${collectionPath}/${docId} does not exist.`);
  }

  const existingData = docSnap.data();
  const deletedAt = new Date().toISOString();

  await resolveSetDoc(
    dbInstance,
    docRef,
    {
      isDeleted: true,
      status: "deleted",
      previousStatus: existingData?.status || "active",
      deletedAt,
      deletedBy
    },
    { merge: true }
  );

  console.log(`[Data Integrity] Soft-deleted ${collectionPath}/${docId} by ${deletedBy} at ${deletedAt}`);
  return { success: true, docId, deletedAt };
}

/**
 * 2. Recover Soft-Deleted Item Helper:
 * Super Admin tool to reverse a soft delete, restoring visibility without touching underlying data history.
 */
export async function recoverSoftDeletedItem(
  dbInstance: any,
  collectionPath: string,
  docId: string,
  restoredBy: string = "super_admin"
): Promise<{ success: boolean; docId: string; restoredAt: string }> {
  if (!dbInstance || !collectionPath || !docId) {
    throw new Error("recoverSoftDeletedItem requires dbInstance, collectionPath, and docId");
  }

  const docRef = resolveDocRef(dbInstance, collectionPath, docId);
  const docSnap = await resolveGetDoc(dbInstance, docRef);

  if (!docSnap.exists()) {
    throw new Error(`Document ${collectionPath}/${docId} does not exist.`);
  }

  const data = docSnap.data();
  const restoredAt = new Date().toISOString();
  const restoredStatus = data?.previousStatus || "active";

  await resolveSetDoc(
    dbInstance,
    docRef,
    {
      isDeleted: false,
      status: restoredStatus,
      restoredAt,
      restoredBy
    },
    { merge: true }
  );

  console.log(`[Data Integrity] Recovered soft-deleted document ${collectionPath}/${docId} by ${restoredBy} at ${restoredAt}`);
  return { success: true, docId, restoredAt };
}

/**
 * 3. Settings Versioning Helper:
 * Non-destructive settings updates. Every settings change creates a versioned entry in a subcollection
 * (/collectionPath/docId/versions/versionId) before updating the active settings document.
 */
export async function recordVersionedSettings(
  dbInstance: any,
  collectionPath: string,
  docId: string,
  newSettings: Record<string, any>,
  updatedBy: string = "system"
): Promise<{ success: boolean; version: number; updatedAt: string }> {
  if (!dbInstance || !collectionPath || !docId) {
    throw new Error("recordVersionedSettings requires dbInstance, collectionPath, and docId");
  }

  const docRef = resolveDocRef(dbInstance, collectionPath, docId);
  const updatedAt = new Date().toISOString();

  const runTx = typeof dbInstance?.runTransaction === "function"
    ? dbInstance.runTransaction.bind(dbInstance)
    : (fn: any) => runTransaction(dbInstance, fn);

  return await runTx(async (transaction: any) => {
    let currentVersion = 0;
    let previousSettings: any = null;

    let docSnap: any = null;
    if (typeof transaction.get === "function") {
      docSnap = await transaction.get(docRef);
    } else {
      docSnap = await resolveGetDoc(dbInstance, docRef);
    }

    if (docSnap && (typeof docSnap.exists === "function" ? docSnap.exists() : !!docSnap.exists)) {
      previousSettings = typeof docSnap.data === "function" ? docSnap.data() : docSnap;
      currentVersion = Number(previousSettings.version) || 1;
    }

    const nextVersion = currentVersion + 1;
    const versionId = `v${currentVersion}_${Date.now()}`;

    // 1. Write previous settings snapshot to version history subcollection
    if (previousSettings) {
      const versionRef = resolveDocRef(dbInstance, collectionPath, docId, "versions", versionId);
      const versionData = {
        ...previousSettings,
        archivedAt: updatedAt,
        archivedBy: updatedBy,
        version: currentVersion
      };
      if (typeof transaction.set === "function") {
        transaction.set(versionRef, versionData);
      } else {
        await resolveSetDoc(dbInstance, versionRef, versionData);
      }
    }

    // 2. Write updated active settings with version metadata
    const activeData = {
      ...newSettings,
      version: nextVersion,
      updatedAt,
      updatedBy,
      isDeleted: false
    };

    if (typeof transaction.set === "function") {
      transaction.set(docRef, activeData, { merge: true });
    } else {
      await resolveSetDoc(dbInstance, docRef, activeData, { merge: true });
    }

    console.log(`[Data Integrity] Non-destructive settings update for ${collectionPath}/${docId}. Version bumped from ${currentVersion} -> ${nextVersion}`);
    return { success: true, version: nextVersion, updatedAt };
  });
}

/**
 * 4. Idempotent Multi-Document Financial Operation Helper:
 * Wraps financial transactions in Firestore transactions with idempotency key checks.
 */
export async function executeIdempotentFinancialTransaction(
  dbInstance: any,
  idempotencyKey: string,
  operationType: "loan_disbursement" | "wallet_transfer" | "marketplace_settlement" | "credit_allocation",
  tenantId: string,
  amount: number,
  operationFn: (transaction: any) => Promise<{ details: any }>
): Promise<{ success: boolean; idempotencyKey: string; alreadyProcessed: boolean; details?: any }> {
  if (!dbInstance || !idempotencyKey || !tenantId) {
    throw new Error("executeIdempotentFinancialTransaction requires dbInstance, idempotencyKey, and tenantId");
  }

  const idempotencyRef = resolveDocRef(dbInstance, "financial_idempotency_keys", idempotencyKey);

  const runTx = typeof dbInstance?.runTransaction === "function"
    ? dbInstance.runTransaction.bind(dbInstance)
    : (fn: any) => runTransaction(dbInstance, fn);

  return await runTx(async (transaction: any) => {
    let idempotencySnap: any = null;
    if (typeof transaction.get === "function") {
      idempotencySnap = await transaction.get(idempotencyRef);
    } else {
      idempotencySnap = await resolveGetDoc(dbInstance, idempotencyRef);
    }

    if (idempotencySnap && (typeof idempotencySnap.exists === "function" ? idempotencySnap.exists() : !!idempotencySnap.exists)) {
      const existingData = typeof idempotencySnap.data === "function" ? idempotencySnap.data() : idempotencySnap;
      console.log(`[Financial Guard] Idempotency key "${idempotencyKey}" already processed. Returning cached result.`);
      return {
        success: true,
        idempotencyKey,
        alreadyProcessed: true,
        details: existingData?.details
      };
    }

    const { details } = await operationFn(transaction);
    const nowStr = new Date().toISOString();

    const txRecord = {
      idempotencyKey,
      operationType,
      tenantId,
      amount,
      processedAt: nowStr,
      details: details || {}
    };

    if (typeof transaction.set === "function") {
      transaction.set(idempotencyRef, txRecord);
    } else {
      await resolveSetDoc(dbInstance, idempotencyRef, txRecord);
    }

    console.log(`[Financial Guard] Processed financial transaction (${operationType}) for tenant ${tenantId}. Key: ${idempotencyKey}`);
    return {
      success: true,
      idempotencyKey,
      alreadyProcessed: false,
      details
    };
  });
}

/**
 * 5. Scheduled Platform-Wide Wallet Balance Integrity Reconciliation Helper
 */
export async function reconcilePlatformWalletBalances(
  dbInstance: any
): Promise<{
  success: boolean;
  totalTenantsAudited: number;
  totalDiscrepancies: number;
  alertsGenerated: ReconciliationAlert[];
  reconciledAt: string;
}> {
  if (!dbInstance) {
    throw new Error("reconcilePlatformWalletBalances requires dbInstance");
  }

  const reconciledAt = new Date().toISOString();
  console.log(`[Reconciliation Engine] Starting platform-wide wallet balance reconciliation at ${reconciledAt}...`);

  const alertsGenerated: ReconciliationAlert[] = [];
  let totalTenantsAudited = 0;

  try {
    const usersSnap = await resolveGetDocs(dbInstance, "users_data");
    for (const uDoc of usersSnap.docs) {
      const tenantId = uDoc.id;
      const uData = typeof uDoc.data === "function" ? uDoc.data() : uDoc;
      const tenantName = uData?.workspaceName || uData?.companyName || uData?.name || "Tenant " + tenantId;
      totalTenantsAudited++;

      const walletRef = resolveDocRef(dbInstance, "tenants", tenantId, "wallet", "credits");
      const walletSnap = await resolveGetDoc(dbInstance, walletRef);
      const walletData = walletSnap.exists() ? walletSnap.data() : null;
      const currentWalletBalance = walletData ? Number(walletData.currentBalance) || 0 : Number(uData?.credits) || 0;

      const ledgerSnap = await resolveGetDocs(dbInstance, `tenants/${tenantId}/creditLedger`);

      let ledgerSum = 0;
      if (ledgerSnap && ledgerSnap.docs) {
        ledgerSnap.docs.forEach((lDoc: any) => {
          const lData = typeof lDoc.data === "function" ? lDoc.data() : lDoc;
          const amt = Number(lData?.amount) || 0;
          if (lData?.type === "credit_grant" || lData?.type === "credit") {
            ledgerSum += amt;
          } else if (lData?.type === "deduction" || lData?.type === "debit") {
            ledgerSum -= amt;
          }
        });
      }

      const discrepancy = Math.abs(currentWalletBalance - ledgerSum);
      if (discrepancy > 0.01 && ledgerSnap.docs && ledgerSnap.docs.length > 0) {
        const alertId = `mismatch_${tenantId}_${Date.now()}`;
        const alert: ReconciliationAlert = {
          alertId,
          tenantId,
          tenantName,
          walletBalance: currentWalletBalance,
          ledgerSum,
          discrepancy: Number((currentWalletBalance - ledgerSum).toFixed(2)),
          flaggedAt: reconciledAt,
          status: "UNRESOLVED",
          notes: `Wallet balance (${currentWalletBalance}) differs from creditLedger calculated sum (${ledgerSum}). Discrepancy: ${discrepancy.toFixed(2)} credits.`
        };

        const alertRef = resolveDocRef(dbInstance, "platform", "reconciliation_alerts", "alerts", alertId);
        await resolveSetDoc(dbInstance, alertRef, alert);
        alertsGenerated.push(alert);

        console.warn(`[Reconciliation Flag] Tenant ${tenantName} (${tenantId}) balance mismatch! Wallet: ${currentWalletBalance}, Ledger Sum: ${ledgerSum}`);
      }
    }

    console.log(`[Reconciliation Engine] Audit finished. Audited ${totalTenantsAudited} tenants. Found ${alertsGenerated.length} discrepancies.`);
    return {
      success: true,
      totalTenantsAudited,
      totalDiscrepancies: alertsGenerated.length,
      alertsGenerated,
      reconciledAt
    };
  } catch (err: any) {
    console.error("[Reconciliation Engine Error]:", err);
    throw err;
  }
}

/**
 * Reconstructs a tenant's true credit balance from the immutable ledger,
 * filtering out any duplicate signup grants or login reset entries.
 * Atomically updates the wallet if a discrepancy or corrupt reset is detected.
 */
export async function reconstructAndFixTenantCreditWallet(
  dbInstance: any,
  tenantId: string,
  applyFix: boolean = false
): Promise<{
  tenantId: string;
  currentWalletBalance: number;
  reconstructedBalance: number;
  hasDiscrepancy: boolean;
  duplicateSignupGrantsFound: number;
  corrected: boolean;
  evidence: string[];
}> {
  const evidence: string[] = [];
  let duplicateSignupGrantsFound = 0;
  
  const walletRef = resolveDocRef(dbInstance, "tenants", tenantId, "credit_wallet", "default");
  const legacyWalletRef = resolveDocRef(dbInstance, "tenants", tenantId, "wallet", "credits");
  const userRef = resolveDocRef(dbInstance, "users_data", tenantId);

  const walletSnap = await resolveGetDoc(dbInstance, walletRef);
  const legacySnap = await resolveGetDoc(dbInstance, legacyWalletRef);
  const userSnap = await resolveGetDoc(dbInstance, userRef);

  let currentWalletBalance = 0;
  if (walletSnap.exists()) {
    currentWalletBalance = Number(walletSnap.data().balance ?? walletSnap.data().currentBalance) || 0;
  } else if (legacySnap.exists()) {
    currentWalletBalance = Number(legacySnap.data().currentBalance) || 0;
  } else if (userSnap.exists()) {
    currentWalletBalance = Number(userSnap.data().credits) || 0;
  }

  const ledgerSnap = await resolveGetDocs(dbInstance, `tenants/${tenantId}/creditLedger`);
  const specLedgerSnap = await resolveGetDocs(dbInstance, `tenants/${tenantId}/credit_wallet/default/ledger`);

  const allLedgerDocs = [
    ...(ledgerSnap?.docs || []),
    ...(specLedgerSnap?.docs || [])
  ];

  const seenKeys = new Set<string>();
  let reconstructedBalance = 0;
  let hasSignupGrant = false;

  for (const docItem of allLedgerDocs) {
    const data = typeof docItem.data === "function" ? docItem.data() : docItem;
    const docId = docItem.id || data.id || data.idempotencyKey;

    if (seenKeys.has(docId)) continue;
    seenKeys.add(docId);

    const eventType = data.eventType || (data.type === "credit_grant" ? "signup" : "usage");
    const amount = Number(data.amount) || 0;

    if (eventType === "signup" || docId.startsWith("signup:")) {
      if (hasSignupGrant) {
        duplicateSignupGrantsFound++;
        evidence.push(`Excluded duplicate signup grant: ${docId} (+${amount})`);
        continue; // Exclude duplicate signup grants
      }
      hasSignupGrant = true;
    }

    if (data.type === "deduction" || data.type === "debit" || amount < 0) {
      reconstructedBalance -= Math.abs(amount);
      evidence.push(`Applied deduction [${docId}]: -${Math.abs(amount)}`);
    } else if (data.type === "credit_grant" || data.type === "credit" || amount > 0) {
      reconstructedBalance += Math.abs(amount);
      evidence.push(`Applied grant [${docId}]: +${Math.abs(amount)}`);
    }
  }

  reconstructedBalance = Math.max(0, Number(reconstructedBalance.toFixed(2)));
  const discrepancy = Math.abs(currentWalletBalance - reconstructedBalance);
  const hasDiscrepancy = discrepancy > 0.01 || duplicateSignupGrantsFound > 0;

  let corrected = false;
  if (hasDiscrepancy && applyFix) {
    const nowStr = new Date().toISOString();
    const fixPayload = {
      balance: reconstructedBalance,
      currentBalance: reconstructedBalance,
      lastReconciledAt: nowStr,
      reconciliationNotes: `Fixed discrepancy of ${discrepancy}. Reconstructed from ${allLedgerDocs.length} ledger entries.`
    };

    if (typeof resolveSetDoc === "function") {
      await resolveSetDoc(dbInstance, walletRef, fixPayload, { merge: true });
      await resolveSetDoc(dbInstance, legacyWalletRef, fixPayload, { merge: true });
      await resolveSetDoc(dbInstance, userRef, { credits: reconstructedBalance, updatedAt: nowStr }, { merge: true });
      corrected = true;
    }
  }

  return {
    tenantId,
    currentWalletBalance,
    reconstructedBalance,
    hasDiscrepancy,
    duplicateSignupGrantsFound,
    corrected,
    evidence
  };
}

/**
 * 6. Master Merchant Wallet Ceiling Enforcement
 * The total wallet balance on farmer mobile money and operational wallets across
 * all farm nodes/tenants must ALWAYS be equal to or less than the balance held on
 * the Lipila platform master merchant wallet:
 *   - Wallet Name: Deep Valley Farms Limited
 *   - Wallet ID: 27604
 * Aggregated platform balances must never exceed this ceiling.
 */
export const MASTER_MERCHANT_WALLET_CONFIG = {
  walletName: "Deep Valley Farms Limited",
  walletId: "27604",
  currency: "ZMW"
};

export interface MasterMerchantWalletAudit {
  masterWalletName: string;
  masterWalletId: string;
  masterWalletBalance: number;
  totalAggregatedPlatformBalance: number;
  isCompliant: boolean;
  excessAmount: number;
  auditedTenantsCount: number;
  auditedAt: string;
  status: "COMPLIANT" | "CEILING_EXCEEDED";
}

export async function auditMasterMerchantWalletCeiling(
  dbInstance: any,
  masterBalanceOverride?: number
): Promise<MasterMerchantWalletAudit> {
  const auditedAt = new Date().toISOString();
  let totalAggregatedPlatformBalance = 0;
  let auditedTenantsCount = 0;

  // Retrieve master merchant wallet balance from Firestore if recorded
  let masterWalletBalance = masterBalanceOverride !== undefined ? masterBalanceOverride : 0;
  try {
    const masterDocRef = resolveDocRef(dbInstance, "platform", "master_merchant_wallet", "wallets", MASTER_MERCHANT_WALLET_CONFIG.walletId);
    const masterSnap = await resolveGetDoc(dbInstance, masterDocRef);
    if (masterSnap.exists()) {
      const data = masterSnap.data();
      masterWalletBalance = Number(data.balance ?? data.currentBalance ?? masterWalletBalance);
    }
  } catch (_) {}

  // Aggregate all tenant operational wallets & farmer mobile money balances
  const usersSnap = await resolveGetDocs(dbInstance, "users_data");
  if (usersSnap && usersSnap.docs) {
    for (const uDoc of usersSnap.docs) {
      const tenantId = uDoc.id;
      const uData = typeof uDoc.data === "function" ? uDoc.data() : uDoc;
      auditedTenantsCount++;

      // Check operational wallet balance
      const walletRef = resolveDocRef(dbInstance, "tenants", tenantId, "wallet", "credits");
      const walletSnap = await resolveGetDoc(dbInstance, walletRef);
      const walletData = walletSnap.exists() ? walletSnap.data() : null;
      const operationalBalance = walletData ? Number(walletData.currentBalance || 0) : Number(uData?.credits || 0);

      // Check farmer momo balance if any
      const momoBalance = Number(uData?.mobileMoneyBalance || uData?.walletBalance || 0);

      totalAggregatedPlatformBalance += operationalBalance + momoBalance;
    }
  }

  totalAggregatedPlatformBalance = Number(totalAggregatedPlatformBalance.toFixed(2));
  const isCompliant = totalAggregatedPlatformBalance <= masterWalletBalance;
  const excessAmount = Math.max(0, Number((totalAggregatedPlatformBalance - masterWalletBalance).toFixed(2)));

  return {
    masterWalletName: MASTER_MERCHANT_WALLET_CONFIG.walletName,
    masterWalletId: MASTER_MERCHANT_WALLET_CONFIG.walletId,
    masterWalletBalance,
    totalAggregatedPlatformBalance,
    isCompliant,
    excessAmount,
    auditedTenantsCount,
    auditedAt,
    status: isCompliant ? "COMPLIANT" : "CEILING_EXCEEDED"
  };
}

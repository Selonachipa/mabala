/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  CropKnowledgeBaseItem, 
  CropKnowledgeStage, 
  GrowthGuideProgress, 
  SponsoredPlacement, 
  PlacementAnalyticsEvent, 
  PlacementAnalyticsSummary, 
  ProductAIBrief, 
  ContentFeedback,
  InputCategory 
} from "../types.js";

// Fixed regulatory disclaimer for chemical product guidance
export const FIXED_CHEMICAL_DISCLAIMER = 
  "DISCLAIMER: Always follow the official chemical manufacturer label and Zambian regulatory guidelines (ZEMA). Conduct a spot test and consult a qualified agronomist for exact application rates and crop safety.";

// Default Rate Table for Sponsored Boosts (ZMW per day)
export const BOOST_PRICING_CONFIG = {
  pricePerDay: 50.0, // ZMW 50 / day
  maxConcurrentBoostsPerVendor: 2,
  maxBoostedSlotsPerCategory: 2
};

// Default Input Categories Taxonomy
export const DEFAULT_INPUT_CATEGORIES: InputCategory[] = [
  { categoryId: "cat_seed", categoryLabel: "Seed & Seedlings", appliesToCropTypes: ["annual_field_crop", "vegetable", "orchard"] },
  { categoryId: "cat_basal_fert", categoryLabel: "Basal Fertiliser (Compound D/NPK)", appliesToCropTypes: ["annual_field_crop", "vegetable", "orchard"] },
  { categoryId: "cat_topdress_fert", categoryLabel: "Top-dress Fertiliser (Urea/CAN)", appliesToCropTypes: ["annual_field_crop", "vegetable", "orchard"] },
  { categoryId: "cat_foliar", categoryLabel: "Foliar Nutrition & Micronutrients", appliesToCropTypes: ["vegetable", "orchard"] },
  { categoryId: "cat_fungicide", categoryLabel: "Fungicides & Disease Control", appliesToCropTypes: ["vegetable", "orchard", "annual_field_crop"] },
  { categoryId: "cat_insecticide", categoryLabel: "Insecticides & Pest Control", appliesToCropTypes: ["vegetable", "orchard", "annual_field_crop"] },
  { categoryId: "cat_herbicide", categoryLabel: "Herbicides & Weed Management", appliesToCropTypes: ["annual_field_crop", "vegetable"] },
  { categoryId: "cat_soil_amend", categoryLabel: "Lime & Soil Amendments", appliesToCropTypes: ["annual_field_crop", "vegetable", "orchard"] },
  { categoryId: "cat_drip_irrigation", categoryLabel: "Drip Irrigation & Mulch Supplies", appliesToCropTypes: ["vegetable", "orchard"] }
];

// --- Seed Data for Phase 1.5 ---
export const SEED_RED_ONION: CropKnowledgeBaseItem = {
  cropId: "ckb_red_onion",
  cropName: "Red Onion",
  cropType: "vegetable",
  varieties: ["Red Pinoy", "Texas Grano", "Red Creole", "Neptune F1"],
  totalCycleDurationDays: 140,
  maturityYears: null,
  regionsApplicable: ["Zone 1 - Luangwa/Gwembe", "Zone 2a - Central/Southern Plateau", "Zone 2b - Western Semi-arid", "Zone 3 - Northern High Rainfall"],
  lastReviewedBy: "admin_system",
  lastReviewedAt: new Date().toISOString(),
  sourceCurationNotes: "Deep Valley Farms Agronomy Manual for Zambian Horticultural Production.",
  status: "draft",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  stages: [
    {
      stageId: "onion_s01",
      stageOrder: 1,
      stageName: "Nursery Establishment",
      triggerType: "days_from_planting",
      triggerValue: 0,
      durationDays: 14,
      description: "Fine seedbed preparation, fungicide seed treatment, sowing in rows 10cm apart, covering with fine soil and shade netting.",
      tasks: [
        { taskId: "task_o1_1", title: "Nursery Bed Preparation", detail: "Construct raised beds 1m wide, mix in well-rotted manure or basal compost.", timingNote: "Day 0", applicableTo: "all" },
        { taskId: "task_o1_2", title: "Fungicide Seed Dressing", detail: "Treat Red Onion seeds with Thiram or Mancozeb before sowing to prevent damping-off.", timingNote: "At Sowing", applicableTo: "all" },
        { taskId: "task_o1_3", title: "Sowing & Shade Cover", detail: "Sow seeds 1cm deep in shallow furrows, water gently with a fine rose, apply grass mulch or shade net.", timingNote: "Day 0-2", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [
        { categoryId: "cat_seed", categoryLabel: "Red Onion Certified Seed", applicationGuidance: "4-5 kg/ha seed requirement for nursery transplanting.", genericQuantityGuidance: "5kg per hectare", mandatory: true, agronomistDisclaimerRequired: false },
        { categoryId: "cat_fungicide", categoryLabel: "Seed Treatment Fungicide", applicationGuidance: "Drench or dress seed for seedling rot prevention.", genericQuantityGuidance: "250g per 5kg seed", mandatory: true, agronomistDisclaimerRequired: true }
      ],
      decisionPoints: [
        { condition: "Poor germination (<70%) by day 10", guidance: "Inspect seed depth, moisture levels, and ant activity. Resow supplementary rows if damping-off is detected.", escalateToAgronomist: true }
      ],
      mediaRefs: [],
      regionVariants: [
        { agroEcologicalZone: "Zone 3 - Northern High Rainfall", triggerValueOverride: null, durationDaysOverride: 18, applicationGuidanceOverride: "Ensure raised beds are 20cm high to prevent waterlogging during heavy rainfall.", notes: "High humidity increases fungal risk." }
      ]
    },
    {
      stageId: "onion_s02",
      stageOrder: 2,
      stageName: "Nursery Care & Hardening Off",
      triggerType: "days_from_planting",
      triggerValue: 14,
      durationDays: 21,
      description: "Regular morning watering, weeding, light top-dressing with liquid fertiliser, and removing shade net 7 days before transplanting.",
      tasks: [
        { taskId: "task_o2_1", title: "Watering Schedule", detail: "Water daily early morning; avoid evening watering to reduce fungal leaf dampness.", timingNote: "Daily Day 14-35", applicableTo: "all" },
        { taskId: "task_o2_2", title: "Manual Weeding", detail: "Hand-pull weeds gently to avoid disturbing delicate onion roots.", timingNote: "Day 21", applicableTo: "all" },
        { taskId: "task_o2_3", title: "Shade Removal & Hardening", detail: "Remove shade cloth 7 days prior to transplanting to harden seedlings.", timingNote: "Day 28", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [
        { categoryId: "cat_foliar", categoryLabel: "Seedling Starter Foliar", applicationGuidance: "Apply balanced NPK + zinc foliar spray to boost seedling vigor.", genericQuantityGuidance: "50ml in 15L water", mandatory: false, agronomistDisclaimerRequired: false }
      ],
      decisionPoints: [
        { condition: "Yellowing or damping-off stems", guidance: "Spray Copper Oxychloride or Ridomil immediately. Reduce watering frequency.", escalateToAgronomist: true }
      ],
      mediaRefs: [],
      regionVariants: []
    },
    {
      stageId: "onion_s03",
      stageOrder: 3,
      stageName: "Transplanting & Field Establishment",
      triggerType: "phenological_signal",
      triggerValue: "Pencil-thickness seedlings with 3-4 true leaves",
      durationDays: 21,
      description: "Transplant pencil-thick seedlings at 15cm x 10cm spacing into fields pre-incorporated with Compound D or Organomineral basal fertiliser.",
      tasks: [
        { taskId: "task_o3_1", title: "Basal Fertiliser Incorporation", detail: "Broadcast and incorporate Compound D (600 kg/ha) or organomineral blend prior to ridging.", timingNote: "1 day before transplanting", applicableTo: "all" },
        { taskId: "task_o3_2", title: "Seedling Selection & Trimming", detail: "Select uniform pencil-thick seedlings, trim tops slightly if overgrown, and transplant moist.", timingNote: "Transplant Day", applicableTo: "all" },
        { taskId: "task_o3_3", title: "Establishment Irrigation", detail: "Irrigate thoroughly immediately after transplanting to settle roots.", timingNote: "Immediate", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [
        { categoryId: "cat_basal_fert", categoryLabel: "Compound D (10-20-10)", applicationGuidance: "Incorporated into main field beds.", genericQuantityGuidance: "600 kg/ha", mandatory: true, agronomistDisclaimerRequired: false }
      ],
      decisionPoints: [
        { condition: "High transplant shock / wilting", guidance: "Maintain light daily drip irrigation for 5 days. Avoid heavy nitrogen application until roots establish.", escalateToAgronomist: false }
      ],
      mediaRefs: [],
      regionVariants: []
    },
    {
      stageId: "onion_s04",
      stageOrder: 4,
      stageName: "Vegetative Growth & Top-Dressing",
      triggerType: "days_from_transplant",
      triggerValue: 21,
      durationDays: 28,
      description: "Active leaf development. First split top-dressing of Ammonium Nitrate or Urea, accompanied by thrips scouting and preventive fungicide spray.",
      tasks: [
        { taskId: "task_o4_1", title: "First Top-Dress Application", detail: "Apply CAN or Urea (150 kg/ha) placed 5cm from plants, followed by irrigation.", timingNote: "Day 21 post-transplant", applicableTo: "all" },
        { taskId: "task_o4_2", title: "Thrips & Downy Mildew Scouting", detail: "Check inner leaf sheaths for silver spots (thrips) or downy gray powder on leaf blades.", timingNote: "Twice Weekly", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [
        { categoryId: "cat_topdress_fert", categoryLabel: "CAN / Urea Top-dress", applicationGuidance: "Side-dress near plants; do not drop into leaf axils.", genericQuantityGuidance: "150 kg/ha", mandatory: true, agronomistDisclaimerRequired: false },
        { categoryId: "cat_insecticide", categoryLabel: "Thrips Control (Imidacloprid/Lambda)", applicationGuidance: "Rotate active ingredients to prevent resistance.", genericQuantityGuidance: "Per product label", mandatory: true, agronomistDisclaimerRequired: true }
      ],
      decisionPoints: [
        { condition: "Thrips count > 5 per plant", guidance: "Spray systemic insecticide (e.g., Abamectin + Acetamiprid) combined with a spreader/sticker.", escalateToAgronomist: true }
      ],
      mediaRefs: [],
      regionVariants: []
    },
    {
      stageId: "onion_s05",
      stageOrder: 5,
      stageName: "Bulb Bulking & Maturation",
      triggerType: "days_from_transplant",
      triggerValue: 49,
      durationDays: 35,
      description: "Swelling of the bulb stem. High Potassium foliage spray, second split top-dressing, strict moisture regulation to avoid bulb splitting.",
      tasks: [
        { taskId: "task_o5_1", title: "Potassium Foliar Feed", detail: "Spray High-K foliar feed (e.g. Potassium Nitrate or 0-0-50) to promote solid bulb bulking.", timingNote: "Every 10 days", applicableTo: "all" },
        { taskId: "task_o5_2", title: "Reduce Overhead Water Pressure", detail: "Switch overhead sprinklers to drip or lower pressure to avoid soil compaction around bulbs.", timingNote: "Continuous", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [
        { categoryId: "cat_foliar", categoryLabel: "High-Potassium Foliar", applicationGuidance: "Foliar feed for bulb density and skin color.", genericQuantityGuidance: "2.5 kg/ha in 200L water", mandatory: true, agronomistDisclaimerRequired: false }
      ],
      decisionPoints: [
        { condition: "Splitting bulbs or purple blotch infection", guidance: "Spray Mancozeb + Metalaxyl for Purple Blotch. Maintain even soil moisture.", escalateToAgronomist: true }
      ],
      mediaRefs: [],
      regionVariants: []
    },
    {
      stageId: "onion_s06",
      stageOrder: 6,
      stageName: "Maturity & Irrigation Stop",
      triggerType: "phenological_signal",
      triggerValue: "50% Neck Fall (Tops bending over)",
      durationDays: 14,
      description: "When 50% of onion tops drop naturally, stop irrigation completely to seal outer skin scales and prepare for field curing.",
      tasks: [
        { taskId: "task_o6_1", title: "Cease Irrigation Completely", detail: "Turn off all irrigation immediately upon 50% neck fall to prevent bulb rot.", timingNote: "At 50% Neck Fall Signal", applicableTo: "all" },
        { taskId: "task_o6_2", title: "Field Drying Check", detail: "Allow neck tissues to dry naturally in dry soil for 7 days before lifting.", timingNote: "Day 0-7 post stop", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [],
      decisionPoints: [
        { condition: "Unexpected rain during maturity", guidance: "Harvest early if soil becomes saturated to prevent bacterial soft rot.", escalateToAgronomist: true }
      ],
      mediaRefs: [],
      regionVariants: []
    },
    {
      stageId: "onion_s07",
      stageOrder: 7,
      stageName: "Harvest, Curing & Storage",
      triggerType: "days_from_transplant",
      triggerValue: 98,
      durationDays: 14,
      description: "Lifting onions, windrow curing under shade or leaf covers, topping tops to 2.5cm, grading into sizes, and packing in net bags.",
      tasks: [
        { taskId: "task_o7_1", title: "Field Lifting & Windrowing", detail: "Carefully pull bulbs, lay in rows covering bulbs with foliage to prevent sunburn.", timingNote: "Harvest Day", applicableTo: "all" },
        { taskId: "task_o7_2", title: "Topping & Root Trimming", detail: "Clip foliage leaving 2.5cm stem neck. Trim roots to 1cm.", timingNote: "Post-Curing (Day 7)", applicableTo: "all" },
        { taskId: "task_o7_3", title: "Grading & Mesh Bagging", detail: "Grade into Small (<4cm), Medium (4-7cm), Large (>7cm) and bag in 10kg ventilated mesh sacks.", timingNote: "Post-Harvest", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [],
      decisionPoints: [],
      mediaRefs: [],
      regionVariants: []
    }
  ]
};

export const SEED_HASS_AVOCADO: CropKnowledgeBaseItem = {
  cropId: "ckb_hass_avocado",
  cropName: "Hass Avocado",
  cropType: "orchard",
  varieties: ["Hass (Grafted on Duke7 / Local Rootstock)", "Fuerte (Pollinizer)"],
  totalCycleDurationDays: null, // Perennial tree orchard
  maturityYears: 3,
  regionsApplicable: ["Zone 2a - Central/Southern Plateau", "Zone 3 - Northern High Rainfall"],
  lastReviewedBy: "admin_system",
  lastReviewedAt: new Date().toISOString(),
  sourceCurationNotes: "Deep Valley Farms Perennial Orchard Management Manual - Commercial Hass Avocado Standard.",
  status: "draft",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  stages: [
    {
      stageId: "avocado_s01",
      stageOrder: 1,
      stageName: "Nursery & Grafted Tree Selection",
      triggerType: "calendar_season",
      triggerValue: "Pre-season Nursery Order (May - Aug)",
      durationDays: 120,
      description: "Securing disease-free grafted Hass trees from certified nurseries, inspecting root collar, stem diameter, and leaf health.",
      tasks: [
        { taskId: "task_a1_1", title: "Certified Nursery Verification", detail: "Source grafted plants certified free from Phytophthora cinnamomi.", timingNote: "3 months before planting", applicableTo: "all" },
        { taskId: "task_a1_2", title: "Pollinizer Variety Allocation", detail: "Allocate 1 Fuerte or Bacon pollinizer tree for every 10 Hass trees.", timingNote: "Ordering", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [
        { categoryId: "cat_seed", categoryLabel: "Grafted Hass Avocado Trees", applicationGuidance: "Healthy 6-9 month old grafted trees.", genericQuantityGuidance: "270 trees per hectare (6m x 6m spacing)", mandatory: true, agronomistDisclaimerRequired: false }
      ],
      decisionPoints: [],
      mediaRefs: [],
      regionVariants: []
    },
    {
      stageId: "avocado_s02",
      stageOrder: 2,
      stageName: "Orchard Land Prep & Hole Digging",
      triggerType: "calendar_season",
      triggerValue: "Dry Season Prep (Sep - Oct)",
      durationDays: 45,
      description: "Marking 6m x 6m grid, digging 60cm x 60cm x 60cm planting pits, incorporating topsoil with manure, Single Super Phosphate, and Agricultural Lime.",
      tasks: [
        { taskId: "task_a2_1", title: "Pit Excavation (60x60x60cm)", detail: "Separate topsoil from subsoil during digging.", timingNote: "30 days before planting", applicableTo: "all" },
        { taskId: "task_a2_2", title: "Soil Amendment Backfill", detail: "Mix topsoil with 20kg well-rotted manure, 500g SSP, and 200g Lime per hole; backfill raised 15cm mound.", timingNote: "14 days before planting", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [
        { categoryId: "cat_soil_amend", categoryLabel: "Agricultural Lime & Gypsum", applicationGuidance: "Adjust pH to target 5.5 - 6.5.", genericQuantityGuidance: "200g per planting hole", mandatory: true, agronomistDisclaimerRequired: false },
        { categoryId: "cat_basal_fert", categoryLabel: "Single Super Phosphate (SSP)", applicationGuidance: "Root growth stimulant incorporated into backfill.", genericQuantityGuidance: "500g per planting pit", mandatory: true, agronomistDisclaimerRequired: false }
      ],
      decisionPoints: [
        { condition: "Heavy clay soil / waterlogging prone", guidance: "Build high planting ridges (mounds 30-40cm high) and install sub-surface drainage channels.", escalateToAgronomist: true }
      ],
      mediaRefs: [],
      regionVariants: [
        { agroEcologicalZone: "Zone 3 - Northern High Rainfall", triggerValueOverride: null, durationDaysOverride: null, applicationGuidanceOverride: "Add 400g Lime per hole due to highly acidic oxisols.", notes: "High acid saturation requires double liming." }
      ]
    },
    {
      stageId: "avocado_s03",
      stageOrder: 3,
      stageName: "Planting, Staking & Mulching (Year 1)",
      triggerType: "phenological_signal",
      triggerValue: "Onset of Steady Rains or Drip Irrigation Ready",
      durationDays: 30,
      description: "Planting trees without root collar burial, staking firmly, applying 10cm dry organic mulch keeping 10cm gap from main trunk.",
      tasks: [
        { taskId: "task_a3_1", title: "Planting & Root Collar Alignment", detail: "Carefully slice seedling bag, set tree so root collar sits slightly above soil line.", timingNote: "Planting Day", applicableTo: "all" },
        { taskId: "task_a3_2", title: "Staking & Windbreak Binding", detail: "Tie stem loosely to sturdy bamboo stake with soft twine. Install sun/wind guards.", timingNote: "Planting Day", applicableTo: "all" },
        { taskId: "task_a3_3", title: "Organic Mulch Application", detail: "Spread dry grass mulch 10cm deep around drip zone, keeping 10cm clear from trunk.", timingNote: "Immediate", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [
        { categoryId: "cat_drip_irrigation", categoryLabel: "Micro-drip / Micro-sprinkler Tubing", applicationGuidance: "Target 20-30 liters per tree twice weekly.", genericQuantityGuidance: "2 emitters per tree", mandatory: true, agronomistDisclaimerRequired: false }
      ],
      decisionPoints: [],
      mediaRefs: [],
      regionVariants: []
    },
    {
      stageId: "avocado_s04",
      stageOrder: 4,
      stageName: "Vegetative Canopy Training (Years 1 - 2)",
      triggerType: "days_from_planting",
      triggerValue: 90,
      durationDays: 365,
      description: "Formative pruning to remove low water shoots, light NPK feeding split into 4 applications per year, copper drench for root health.",
      tasks: [
        { taskId: "task_a4_1", title: "Tip Pinching for Branching", detail: "Pinch central leader at 1m height to encourage 3-4 strong framework scaffold branches.", timingNote: "Month 6", applicableTo: "all" },
        { taskId: "task_a4_2", title: "Quarterly NPK + Zn/B Feeding", detail: "Apply 100g CAN + 100g MOP per tree per quarter, increasing yearly.", timingNote: "Quarterly", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [
        { categoryId: "cat_topdress_fert", categoryLabel: "CAN / Calcium Nitrate", applicationGuidance: "Broadcast around outer drip canopy ring.", genericQuantityGuidance: "100g/tree per quarter", mandatory: true, agronomistDisclaimerRequired: false },
        { categoryId: "cat_foliar", categoryLabel: "Zinc Oxide + Solubor Foliar", applicationGuidance: "Essential for avocado leaf expansion and flowering prep.", genericQuantityGuidance: "20g in 15L spray", mandatory: false, agronomistDisclaimerRequired: false }
      ],
      decisionPoints: [
        { condition: "Pale leaves with green veins (Zinc Deficiency)", guidance: "Spray Foliar Zinc Chelate during active leaf flush in spring.", escalateToAgronomist: false }
      ],
      mediaRefs: [],
      regionVariants: []
    },
    {
      stageId: "avocado_s05",
      stageOrder: 5,
      stageName: "Pre-Flowering & Flowering Care (Year 3+)",
      triggerType: "phenological_signal",
      triggerValue: "Swelling Flower Buds (July - August)",
      durationDays: 45,
      description: "Pre-bloom canopy light opening, foliar Boron spray, strict avoidance of broad-spectrum insecticides during honeybee pollination.",
      tasks: [
        { taskId: "task_a5_1", title: "Foliar Boron & Zinc Pre-Bloom", detail: "Apply Solubor spray when flower panicles emerge to improve fruit set.", timingNote: "Pre-Flowering", applicableTo: "all" },
        { taskId: "task_a5_2", title: "Pollinator Protection Rule", detail: "STOP all chemical insecticide sprays while trees are in bloom to protect bees.", timingNote: "Full Bloom", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [
        { categoryId: "cat_foliar", categoryLabel: "Solubor (Boron 20.5%)", applicationGuidance: "Crucial for pollen tube growth and fruit retention.", genericQuantityGuidance: "1kg/ha equivalent", mandatory: true, agronomistDisclaimerRequired: false }
      ],
      decisionPoints: [
        { condition: "Excessive flower drop", guidance: "Inspect soil moisture; irrigate evenly. Apply Potassium Nitrate foliar spray after bloom.", escalateToAgronomist: true }
      ],
      mediaRefs: [],
      regionVariants: []
    },
    {
      stageId: "avocado_s06",
      stageOrder: 6,
      stageName: "Fruit Development & Anthracnose Guard",
      triggerType: "days_from_planting",
      triggerValue: 1000,
      durationDays: 150,
      description: "Fruit swelling. Hang fruit fly pheromone traps, spray Copper Hydroxide monthly during rainy periods to prevent Anthracnose & Cercospora.",
      tasks: [
        { taskId: "task_a6_1", title: "Fruit Fly Trap Setup", detail: "Install 4 Methyl Eugenol traps per hectare around orchard perimeter.", timingNote: "Fruit Set (Pea-size)", applicableTo: "all" },
        { taskId: "task_a6_2", title: "Preventive Copper Spray Programme", detail: "Apply Copper Hydroxide (Kocide) or Copper Oxychloride every 21-28 days in rainy season.", timingNote: "Monthly during Rains", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [
        { categoryId: "cat_fungicide", categoryLabel: "Copper Hydroxide Fungicide", applicationGuidance: "Protects fruit skin against Anthracnose spots.", genericQuantityGuidance: "2kg/ha in 500L water", mandatory: true, agronomistDisclaimerRequired: true },
        { categoryId: "cat_insecticide", categoryLabel: "Fruit Fly Lures / Traps", applicationGuidance: "Biological control for Ceratitis capitata.", genericQuantityGuidance: "4 traps per ha", mandatory: true, agronomistDisclaimerRequired: false }
      ],
      decisionPoints: [
        { condition: "Sunburn on exposed hanging fruit", guidance: "Maintain light top leaf canopy shade; apply Kaolin clay shade spray if temperatures exceed 34°C.", escalateToAgronomist: false }
      ],
      mediaRefs: [],
      regionVariants: []
    },
    {
      stageId: "avocado_s07",
      stageOrder: 7,
      stageName: "Maturity Check & Clip Harvest",
      triggerType: "phenological_signal",
      triggerValue: "Dry Matter Test >= 21% or Seed Coat Blackening",
      durationDays: 60,
      description: "Testing sample fruit dry matter, hand picking using clippers leaving 3mm stem button, placing in cool shaded collection crates.",
      tasks: [
        { taskId: "task_a7_1", title: "Dry Matter % Sampling", detail: "Dehydrate test fruit flesh to confirm dry matter exceeds 21% before full harvest.", timingNote: "7 days before harvest", applicableTo: "all" },
        { taskId: "task_a7_2", title: "Clipper Hand Harvest", detail: "Clip fruit with double-cut secateurs leaving a 3mm button stem. Never pull fruit.", timingNote: "Harvest Day", applicableTo: "all" },
        { taskId: "task_a7_3", title: "Shade Cool-Chain Transport", detail: "Move harvested crates immediately into covered shade (<20°C) to prevent fruit heating.", timingNote: "Post-Harvest Immediate", applicableTo: "all" }
      ],
      inputCategoriesNeeded: [],
      decisionPoints: [],
      mediaRefs: [],
      regionVariants: []
    }
  ]
};

// --- CORE AGRONOMY RESOLUTION ENGINE ---

export function resolveStageForCropCycle(
  cropCycle: {
    plantingDate: string;
    cropType: string;
    variety?: string;
    fieldBlock?: string;
  },
  ckbItem: CropKnowledgeBaseItem,
  farmAgroZone: string,
  confirmedSignals: string[] = []
): {
  currentStage: CropKnowledgeStage;
  stageProgressDays: number;
  daysRemainingInStage: number | null;
  upcomingStage: CropKnowledgeStage | null;
  allStages: CropKnowledgeStage[];
} {
  const stages = ckbItem.stages && ckbItem.stages.length > 0 
    ? [...ckbItem.stages].sort((a, b) => a.stageOrder - b.stageOrder)
    : [];

  if (stages.length === 0) {
    throw new Error(`No stages found for crop ${ckbItem.cropName}`);
  }

  // Calculate elapsed days from planting
  const pDate = new Date(cropCycle.plantingDate || Date.now());
  const now = new Date();
  const elapsedDays = Math.max(0, Math.floor((now.getTime() - pDate.getTime()) / (1000 * 60 * 60 * 24)));

  // Resolve overrides for each stage based on agroEcologicalZone
  const activeZone = farmAgroZone || "Zone 2a - Central/Southern Plateau";

  const resolvedStages = stages.map(st => {
    const variant = (st.regionVariants || []).find(v => v.agroEcologicalZone === activeZone);
    return {
      ...st,
      effectiveTriggerValue: variant?.triggerValueOverride !== undefined && variant.triggerValueOverride !== null
        ? variant.triggerValueOverride
        : st.triggerValue,
      effectiveDurationDays: variant?.durationDaysOverride !== undefined && variant.durationDaysOverride !== null
        ? variant.durationDaysOverride
        : st.durationDays,
      effectiveApplicationGuidance: variant?.applicationGuidanceOverride || null
    };
  });

  let currentStageIndex = 0;

  for (let i = 0; i < resolvedStages.length; i++) {
    const st = resolvedStages[i];
    if (st.triggerType === "days_from_planting" || st.triggerType === "days_from_transplant") {
      const trigVal = typeof st.effectiveTriggerValue === "number" ? st.effectiveTriggerValue : Number(st.effectiveTriggerValue || 0);
      if (elapsedDays >= trigVal) {
        currentStageIndex = i;
      }
    } else if (st.triggerType === "phenological_signal") {
      const signalText = String(st.effectiveTriggerValue).toLowerCase();
      const isConfirmed = confirmedSignals.some(s => s.toLowerCase().includes(signalText) || signalText.includes(s.toLowerCase()));
      if (isConfirmed) {
        currentStageIndex = i;
      }
    } else if (st.triggerType === "calendar_season") {
      currentStageIndex = i;
    }
  }

  const currentStage = resolvedStages[currentStageIndex];
  const upcomingStage = currentStageIndex < resolvedStages.length - 1 ? resolvedStages[currentStageIndex + 1] : null;

  // Calculate days in current stage
  let stageProgressDays = elapsedDays;
  if (typeof currentStage.effectiveTriggerValue === "number") {
    stageProgressDays = Math.max(0, elapsedDays - currentStage.effectiveTriggerValue);
  }

  let daysRemainingInStage: number | null = null;
  if (currentStage.effectiveDurationDays) {
    daysRemainingInStage = Math.max(0, currentStage.effectiveDurationDays - stageProgressDays);
  }

  return {
    currentStage,
    stageProgressDays,
    daysRemainingInStage,
    upcomingStage,
    allStages: resolvedStages
  };
}

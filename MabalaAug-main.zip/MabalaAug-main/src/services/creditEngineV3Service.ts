import { db } from "../firebase";
import { doc, getDoc, setDoc, updateDoc, collection, getDocs } from "firebase/firestore";
import { grantCreditsIdempotent } from "./creditLedgerService";
import {
  V3_PLANS,
  IN_APP_TOPUP_BUNDLES,
  calculatePlanTermPrice,
  DEFAULT_SUPPLIER_REPORT_FEE_ZMW,
  DEFAULT_PRE_DUE_REMINDER_LEAD_DAYS,
  PlanDefinitionV3,
  InAppTopupBundle,
  SubscriptionRecordV3,
  SupplierAccountRecordV3,
  PreDueReminderLogV3,
  MonthlyStatementLogV3,
  SubscriptionStatusV3,
  UserRoleV3
} from "../config/creditEngineV3";
import { LipilaTransaction } from "../data/mockLipilaTransactions";
import { getFeeConfig } from "./feeConfigService";

export type AccountAccessState = "ACTIVE" | "READ_ONLY" | "WELCOME_EXHAUSTED" | "UNMETERED_ACTIVE" | "EXPIRED";

export interface AccessCheckResult {
  state: AccountAccessState;
  canPerformWriteAction: boolean;
  message?: string;
  isUnmetered: boolean;
  unmeteredExpiresAt?: string;
  remainingCredits: number;
}


/**
 * Universal Welcome Grant for new accounts: WELCOME_60
 * Granted idempotently upon user creation, protected by emailHistory/phoneHistory anti-regrant mechanism.
 */
export async function grantWelcomeCreditsIfEligible(
  dbInstance: any,
  tenantId: string,
  userRole?: string,
  email?: string,
  phone?: string
): Promise<{ success: boolean; newBalance: number; alreadyProcessed: boolean; reason?: string }> {
  const normalizedRole = (userRole || "").toLowerCase();
  
  // Agronomists and Suppliers onboard free without welcome credits (they don't consume write action credits)
  if (
    normalizedRole === "agronomist" || 
    normalizedRole === "supplier" || 
    normalizedRole === "institution_supplier" ||
    normalizedRole === "seed company"
  ) {
    return { success: true, newBalance: 0, alreadyProcessed: true, reason: "ROLE_EXCLUDED" };
  }

  // Anti-regrant mechanism: check emailHistory and phoneHistory
  const cleanEmail = (email || "").trim().toLowerCase();
  const cleanPhone = (phone || "").trim().replace(/\s+/g, "");

  const auditKeyEmail = cleanEmail ? `mabala_audit_email_${cleanEmail}` : null;
  const auditKeyPhone = cleanPhone ? `mabala_audit_phone_${cleanPhone}` : null;

  try {
    if (auditKeyEmail && localStorage.getItem(auditKeyEmail)) {
      console.warn(`[Credit Engine] Anti-regrant blocked: Email ${cleanEmail} already received WELCOME_60.`);
      return { success: true, newBalance: 0, alreadyProcessed: true, reason: "EMAIL_ALREADY_GRANTED" };
    }
    if (auditKeyPhone && localStorage.getItem(auditKeyPhone)) {
      console.warn(`[Credit Engine] Anti-regrant blocked: Phone ${cleanPhone} already received WELCOME_60.`);
      return { success: true, newBalance: 0, alreadyProcessed: true, reason: "PHONE_ALREADY_GRANTED" };
    }
  } catch (_) {}

  // Check Firestore anti-regrant documents if dbInstance is available
  if (dbInstance) {
    try {
      if (cleanEmail) {
        const emailAuditDoc = await getDoc(doc(dbInstance, "system", "welcomeAudit", "emailHistory", cleanEmail.replace(/[/.]/g, "_")));
        if (emailAuditDoc.exists()) {
          return { success: true, newBalance: 0, alreadyProcessed: true, reason: "EMAIL_ALREADY_GRANTED" };
        }
      }
      if (cleanPhone) {
        const phoneAuditDoc = await getDoc(doc(dbInstance, "system", "welcomeAudit", "phoneHistory", cleanPhone.replace(/[/+]/g, "_")));
        if (phoneAuditDoc.exists()) {
          return { success: true, newBalance: 0, alreadyProcessed: true, reason: "PHONE_ALREADY_GRANTED" };
        }
      }
    } catch (e) {
      console.warn("[Credit Engine] Firestore welcome audit check notice:", e);
    }
  }

  // Zero-rated baseline specification: All new tenants onboard with a 0 credit balance
  const welcomeAmount = 0;
  const idempotencyKey = `signup:${tenantId}`;
  const description = "BASELINE_ZERO: Zero-rated initial tenant operational wallet on onboarding";

  // Ensure wallet documents in Firestore are created with clean 0 balance
  if (dbInstance || db) {
    try {
      const activeDb = dbInstance || db;
      const walletRef = doc(activeDb, "tenants", tenantId, "wallet", "credits");
      const specWalletRef = doc(activeDb, "tenants", tenantId, "credit_wallet", "default");
      const zeroPayload = {
        currentBalance: 0,
        balance: 0,
        updatedAt: new Date().toISOString(),
        tenantId
      };
      await setDoc(walletRef, zeroPayload, { merge: true });
      await setDoc(specWalletRef, zeroPayload, { merge: true });
    } catch (e) {
      console.warn("[Credit Engine] Zero-rate wallet initialization note:", e);
    }
  }

  // Record audit history
  try {
    if (auditKeyEmail) localStorage.setItem(auditKeyEmail, new Date().toISOString());
    if (auditKeyPhone) localStorage.setItem(auditKeyPhone, new Date().toISOString());
  } catch (_) {}

  return { success: true, newBalance: 0, alreadyProcessed: true, reason: "ZERO_RATED_NEW_TENANT" };
}

/**
 * Verifies if the tenant is currently in WELCOME_EXHAUSTED or unmetered pass.
 */
export function checkAccountAccessState(
  credits: number,
  subscriptionTier: string = "Seeding Tier",
  unmeteredExpiresAt?: string | null
): AccessCheckResult {
  const now = new Date().getTime();
  
  // 1. Check if unmetered emergency pass is currently active
  if (unmeteredExpiresAt) {
    const expires = new Date(unmeteredExpiresAt).getTime();
    if (expires > now) {
      return {
        state: "UNMETERED_ACTIVE",
        canPerformWriteAction: true,
        isUnmetered: true,
        unmeteredExpiresAt,
        remainingCredits: credits,
        message: "24-Hour Daily Bundle Unmetered Pass Active"
      };
    }
  }

  // 2. If credits > 0, account has write access
  if (credits > 0) {
    return {
      state: "ACTIVE",
      canPerformWriteAction: true,
      isUnmetered: false,
      remainingCredits: credits
    };
  }

  // 3. If credits <= 0
  const isFreeOrSeeding = !subscriptionTier || 
    subscriptionTier.toLowerCase().includes("seed") || 
    subscriptionTier.toLowerCase().includes("free");

  if (isFreeOrSeeding) {
    return {
      state: "WELCOME_EXHAUSTED",
      canPerformWriteAction: false,
      isUnmetered: false,
      remainingCredits: 0,
      message: "You have used your 60 Welcome Credits. Please upgrade to a paid plan or purchase a top-up bundle to continue writing data."
    };
  }

  return {
    state: "EXPIRED",
    canPerformWriteAction: false,
    isUnmetered: false,
    remainingCredits: 0,
    message: "Your operational credit balance is 0. Please top up or renew your subscription to perform write actions."
  };
}

/**
 * Executes a subscription plan purchase via Lipila Gateway
 */
export async function processSubscriptionPurchaseViaLipila(params: {
  tenantId: string;
  tenantName: string;
  planId: string;
  termMonths: number;
  customerPhone: string;
  paymentMethod: "Airtel Money" | "MTN Money" | "Zamtel Kwacha" | "Visa / Mastercard 3DS";
}): Promise<{
  success: boolean;
  referenceId: string;
  newBalance: number;
  plan: PlanDefinitionV3;
  transaction: LipilaTransaction;
}> {
  const plan = V3_PLANS.find(p => p.id === params.planId) || V3_PLANS[1]; // default to Monthly
  const pricing = calculatePlanTermPrice(plan, params.termMonths);
  const now = new Date();
  const referenceId = `LPL-SUB-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

  // Calculate renewal expiry
  const expiryDate = new Date(now);
  expiryDate.setMonth(expiryDate.getMonth() + params.termMonths);

  // Build visit allowance schedule for Growth / Enterprise plans
  const visitAllowanceSchedule = buildVisitAllowanceSchedule(plan.id, params.termMonths, now);

  // 1. Record Lipila transaction
  const tx: LipilaTransaction = {
    id: `LPLTX-${Date.now()}`,
    referenceId,
    module: "SUB",
    transactionType: "Collection",
    provider: params.paymentMethod === "Visa / Mastercard 3DS" ? "Airtel Money" : params.paymentMethod,
    accountNumber: params.customerPhone,
    customerName: params.tenantName,
    tenantId: params.tenantId,
    amount: pricing.totalPriceZMW,
    currency: "ZMW",
    status: "Successful",
    narration: `Subscription: ${plan.name} (${params.termMonths} Mo term, ${pricing.totalCredits.toLocaleString()} credits)`,
    createdAt: now.toISOString(),
    lastUpdate: now.toISOString(),
    message: `Payment authorized via Lipila API. Subscribed to ${plan.name} for ${params.termMonths} month(s).`,
    paymentMethod: params.paymentMethod,
    paymentType: params.paymentMethod.includes("Visa") ? "Card" : "MobileMoney",
    receiptUrl: `/receipts/${params.tenantId}/${referenceId}.pdf`,
    receiptGeneratedAt: now.toISOString()
  };

  const subRecord: SubscriptionRecordV3 = {
    id: referenceId,
    tenantId: params.tenantId,
    tenantName: params.tenantName,
    customerPhone: params.customerPhone,
    userRole: "FARMER",
    planId: plan.id as any,
    planName: plan.name,
    termMonths: params.termMonths,
    priceZMW: pricing.totalPriceZMW,
    creditsAllocatedTotal: pricing.totalCredits,
    monthlyCredits: plan.monthlyCredits,
    creditsRemaining: pricing.totalCredits,
    startDate: now.toISOString(),
    endDate: expiryDate.toISOString(),
    status: "ACTIVE",
    referenceId,
    visitAllowanceSchedule,
    refundStatus: "NONE"
  };

  // 2. Persist transaction and subscription record
  try {
    const existingStr = localStorage.getItem("mabala_lipila_user_transactions");
    const existing = existingStr ? JSON.parse(existingStr) : [];
    existing.unshift(tx);
    localStorage.setItem("mabala_lipila_user_transactions", JSON.stringify(existing));

    const existingSubsStr = localStorage.getItem("mabala_v3_subscriptions");
    const existingSubs: SubscriptionRecordV3[] = existingSubsStr ? JSON.parse(existingSubsStr) : [];
    const filteredSubs = existingSubs.filter(s => s.tenantId !== params.tenantId || s.status === "CANCELLED");
    filteredSubs.unshift(subRecord);
    localStorage.setItem("mabala_v3_subscriptions", JSON.stringify(filteredSubs));
  } catch (e) {}

  if (db) {
    try {
      await setDoc(doc(db, "lipilaTransactions", tx.id), tx);
      await setDoc(doc(db, "tenants", params.tenantId, "subscriptions", referenceId), subRecord);
      await setDoc(doc(db, "subscriptions", referenceId), subRecord);
      await updateDoc(doc(db, "users_data", params.tenantId), {
        subscriptionTier: plan.name,
        subscriptionExpiresAt: expiryDate.toISOString(),
        subscriptionStatus: "ACTIVE",
        termMonths: params.termMonths,
        updatedAt: now.toISOString()
      });
    } catch (e) {
      console.warn("[LipilaService] Firestore sync notice:", e);
    }
  }

  // 3. Grant credits idempotently
  const idempotencyKey = `renewal:${params.tenantId}:${plan.id}:${params.termMonths}:${referenceId}`;
  const grantRes = await grantCreditsIdempotent(
    db,
    params.tenantId,
    pricing.totalCredits,
    "renewal",
    idempotencyKey,
    `Subscription renewal: ${plan.name} (${params.termMonths} months, +${pricing.totalCredits} credits)`
  );

  return {
    success: true,
    referenceId,
    newBalance: grantRes.newBalance,
    plan,
    transaction: tx
  };
}


/**
 * Executes a top-up bundle purchase via Lipila Gateway
 */
export async function processTopupBundlePurchaseViaLipila(params: {
  tenantId: string;
  tenantName: string;
  bundleId: string;
  customerPhone: string;
  paymentMethod: "Airtel Money" | "MTN Money" | "Zamtel Kwacha" | "Visa / Mastercard 3DS";
}): Promise<{
  success: boolean;
  referenceId: string;
  newBalance: number;
  isUnmetered: boolean;
  unmeteredExpiresAt?: string;
  bundle: InAppTopupBundle;
  transaction: LipilaTransaction;
}> {
  const bundle = IN_APP_TOPUP_BUNDLES.find(b => b.id === params.bundleId) || IN_APP_TOPUP_BUNDLES[0];
  const now = new Date();
  const referenceId = `LPL-TOP-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

  let unmeteredExpiresAt: string | undefined;
  if (bundle.isUnmetered && bundle.durationHours) {
    const exp = new Date(now.getTime() + bundle.durationHours * 60 * 60 * 1000);
    unmeteredExpiresAt = exp.toISOString();
  }

  // 1. Record Lipila transaction
  const tx: LipilaTransaction = {
    id: `LPLTX-${Date.now()}`,
    referenceId,
    module: "CREDIT",
    transactionType: "Collection",
    provider: params.paymentMethod === "Visa / Mastercard 3DS" ? "Airtel Money" : params.paymentMethod,
    accountNumber: params.customerPhone,
    customerName: params.tenantName,
    tenantId: params.tenantId,
    amount: bundle.priceZMW,
    currency: "ZMW",
    status: "Successful",
    narration: `Top-Up: ${bundle.name} (${bundle.isUnmetered ? "24h Unmetered" : `+${bundle.credits} credits`})`,
    createdAt: now.toISOString(),
    lastUpdate: now.toISOString(),
    message: `Payment authorized via Lipila API for ${bundle.name}.`,
    paymentMethod: params.paymentMethod,
    paymentType: params.paymentMethod.includes("Visa") ? "Card" : "MobileMoney",
    receiptUrl: `/receipts/${params.tenantId}/${referenceId}.pdf`,
    receiptGeneratedAt: now.toISOString()
  };

  // 2. Persist transaction
  try {
    const existingStr = localStorage.getItem("mabala_lipila_user_transactions");
    const existing = existingStr ? JSON.parse(existingStr) : [];
    existing.unshift(tx);
    localStorage.setItem("mabala_lipila_user_transactions", JSON.stringify(existing));
  } catch (e) {}

  if (db) {
    try {
      await setDoc(doc(db, "lipilaTransactions", tx.id), tx);
      if (unmeteredExpiresAt) {
        await updateDoc(doc(db, "tenants", params.tenantId, "wallet", "credits"), {
          unmeteredExpiresAt,
          updatedAt: now.toISOString()
        });
        await updateDoc(doc(db, "users_data", params.tenantId), {
          unmeteredExpiresAt,
          updatedAt: now.toISOString()
        });
      }
    } catch (e) {
      console.warn("[LipilaService] Firestore sync notice:", e);
    }
  }

  let newBalance = 0;
  if (!bundle.isUnmetered && bundle.credits > 0) {
    const idempotencyKey = `topup:${referenceId}`;
    const grantRes = await grantCreditsIdempotent(
      db,
      params.tenantId,
      bundle.credits,
      "topup",
      idempotencyKey,
      `In-App Top-Up: ${bundle.name} (+${bundle.credits} credits)`
    );
    newBalance = grantRes.newBalance;
  }

  return {
    success: true,
    referenceId,
    newBalance,
    isUnmetered: bundle.isUnmetered,
    unmeteredExpiresAt,
    bundle,
    transaction: tx
  };
}

/**
 * Processes Supplier Flat Fee Per-Report Access via Lipila Gateway
 */
export async function processSupplierReportAccessFee(params: {
  tenantId: string;
  supplierName: string;
  reportId: string;
  reportTitle: string;
  customerPhone: string;
  amountZMW?: number;
  paymentMethod: "Airtel Money" | "MTN Money" | "Zamtel Kwacha" | "Visa / Mastercard 3DS";
}): Promise<{
  success: boolean;
  referenceId: string;
  transaction: LipilaTransaction;
}> {
  const feeAmount = params.amountZMW || DEFAULT_SUPPLIER_REPORT_FEE_ZMW;
  const now = new Date();
  const referenceId = `LPL-SUPRPT-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

  const tx: LipilaTransaction = {
    id: `LPLTX-${Date.now()}`,
    referenceId,
    module: "SUPPLY",
    transactionType: "Collection",
    provider: params.paymentMethod === "Visa / Mastercard 3DS" ? "Airtel Money" : params.paymentMethod,
    accountNumber: params.customerPhone,
    customerName: params.supplierName,
    tenantId: params.tenantId,
    amount: feeAmount,
    currency: "ZMW",
    status: "Successful",
    narration: `Supplier Report Access Fee: ${params.reportTitle} (${params.reportId})`,
    createdAt: now.toISOString(),
    lastUpdate: now.toISOString(),
    message: `Payment of ZMW ${feeAmount} authorized via Lipila API for report ${params.reportTitle}.`,
    paymentMethod: params.paymentMethod,
    paymentType: params.paymentMethod.includes("Visa") ? "Card" : "MobileMoney",
    receiptUrl: `/receipts/${params.tenantId}/${referenceId}.pdf`,
    receiptGeneratedAt: now.toISOString()
  };

  try {
    const existingStr = localStorage.getItem("mabala_lipila_user_transactions");
    const existing = existingStr ? JSON.parse(existingStr) : [];
    existing.unshift(tx);
    localStorage.setItem("mabala_lipila_user_transactions", JSON.stringify(existing));
  } catch (e) {}

  if (db) {
    try {
      await setDoc(doc(db, "lipilaTransactions", tx.id), tx);
      await setDoc(doc(db, "tenants", params.tenantId, "purchasedReports", params.reportId), {
        reportId: params.reportId,
        reportTitle: params.reportTitle,
        purchasedAt: now.toISOString(),
        referenceId,
        amountZMW: feeAmount
      });
    } catch (e) {
      console.warn("[LipilaService] Firestore sync notice:", e);
    }
  }

  return {
    success: true,
    referenceId,
    transaction: tx
  };
}

/**
 * Gets the active Supplier report access fee rate (ZMW)
 */
export function getSupplierReportFeeRate(): number {
  try {
    const saved = localStorage.getItem("mabala_supplier_report_fee_zmw");
    if (saved && !isNaN(Number(saved)) && Number(saved) >= 0) {
      return Number(saved);
    }
  } catch (_) {}
  return DEFAULT_SUPPLIER_REPORT_FEE_ZMW;
}

/**
 * Retrieves all v3 plan definitions, merging any Super Admin live configurations from storage / Firestore
 */
export function getAllPlanDefinitions(): PlanDefinitionV3[] {
  try {
    const raw = localStorage.getItem("mabala_v3_plan_definitions");
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (_) {}
  return [...V3_PLANS];
}

/**
 * Updates a plan definition live without requiring code redeployment
 */
export async function updatePlanDefinitionInService(
  planId: string,
  updates: Partial<PlanDefinitionV3>,
  dbInstance?: any,
  userEmail?: string,
  notes?: string
): Promise<PlanDefinitionV3[]> {
  const current = getAllPlanDefinitions();
  const index = current.findIndex(p => p.id === planId);
  if (index === -1) {
    throw new Error(`Plan ${planId} not found.`);
  }

  current[index] = {
    ...current[index],
    ...updates
  };

  try {
    localStorage.setItem("mabala_v3_plan_definitions", JSON.stringify(current));
  } catch (_) {}

  const targetDb = dbInstance || db;
  if (targetDb) {
    try {
      await setDoc(doc(targetDb, "system", "v3PlanDefinitions"), {
        plans: current,
        lastUpdatedBy: userEmail || "Super Admin",
        notes: notes || "Plan definition update",
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (e) {
      console.warn("[Credit Engine] Firestore plan definitions sync notice:", e);
    }
  }

  return current;
}

/**
 * Updates the active Supplier report access fee rate (ZMW) by Super Admin
 */
export async function setSupplierReportFeeRate(feeZMW: number, dbInstance?: any): Promise<void> {
  try {
    localStorage.setItem("mabala_supplier_report_fee_zmw", feeZMW.toString());
  } catch (_) {}

  const targetDb = dbInstance || db;
  if (targetDb) {
    try {
      await setDoc(doc(targetDb, "system", "feeConfig"), {
        supplierReportFeeZMW: feeZMW,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (e) {
      console.warn("[Credit Engine] Failed to sync supplier report fee to Firestore:", e);
    }
  }
}

/**
 * Retrieves all purchased reports for a tenant
 */
export async function getSupplierPurchasedReports(tenantId: string, dbInstance?: any): Promise<Record<string, {
  reportId: string;
  reportTitle: string;
  purchasedAt: string;
  referenceId: string;
  amountZMW: number;
}>> {
  const result: Record<string, any> = {};

  try {
    const rawLocal = localStorage.getItem(`mabala_purchased_reports_${tenantId}`);
    if (rawLocal) {
      const parsed = JSON.parse(rawLocal);
      Object.assign(result, parsed);
    }
  } catch (_) {}

  const targetDb = dbInstance || db;
  if (targetDb) {
    try {
      const snap = await getDocs(collection(targetDb, "tenants", tenantId, "purchasedReports"));
      snap.forEach(d => {
        const data = d.data();
        result[d.id] = {
          reportId: d.id,
          reportTitle: data.reportTitle || d.id,
          purchasedAt: data.purchasedAt || new Date().toISOString(),
          referenceId: data.referenceId || `REF-${d.id}`,
          amountZMW: data.amountZMW || DEFAULT_SUPPLIER_REPORT_FEE_ZMW
        };
      });
    } catch (e) {
      console.warn("[Credit Engine] Firestore purchasedReports lookup notice:", e);
    }
  }

  return result;
}


/**
 * Builds progressive monthly visit allowance schedule for Growth & Enterprise multi-month subscriptions
 */
export function buildVisitAllowanceSchedule(planId: string, termMonths: number, startDate: Date): Array<{
  monthIndex: number;
  releaseDate: string;
  agronomistVisits: number;
  vetVisits: number;
  released: boolean;
  usedAgronomistVisits: number;
  usedVetVisits: number;
}> {
  const schedule: Array<{
    monthIndex: number;
    releaseDate: string;
    agronomistVisits: number;
    vetVisits: number;
    released: boolean;
    usedAgronomistVisits: number;
    usedVetVisits: number;
  }> = [];

  let agroVisitsPerMonth = 0;
  let vetVisitsPerMonth = 0;

  if (planId === "PLAN_GROWTH") {
    agroVisitsPerMonth = 1;
    vetVisitsPerMonth = 0;
  } else if (planId === "PLAN_ENTERPRISE") {
    agroVisitsPerMonth = 2;
    vetVisitsPerMonth = 2;
  }

  const now = new Date();

  for (let m = 1; m <= termMonths; m++) {
    const releaseDate = new Date(startDate);
    releaseDate.setMonth(releaseDate.getMonth() + (m - 1));
    const isReleased = releaseDate.getTime() <= now.getTime();

    schedule.push({
      monthIndex: m,
      releaseDate: releaseDate.toISOString(),
      agronomistVisits: agroVisitsPerMonth,
      vetVisits: vetVisitsPerMonth,
      released: isReleased,
      usedAgronomistVisits: 0,
      usedVetVisits: 0
    });
  }

  return schedule;
}

/**
 * Gets configurable Pre-Due Reminder lead time in days (Default 3 days)
 */
export function getPreDueReminderLeadDays(): number {
  try {
    const saved = localStorage.getItem("mabala_pre_due_reminder_lead_days");
    if (saved && !isNaN(Number(saved)) && Number(saved) >= 1) {
      return Number(saved);
    }
  } catch (_) {}
  return DEFAULT_PRE_DUE_REMINDER_LEAD_DAYS;
}

/**
 * Updates Pre-Due Reminder lead time in days by Super Admin
 */
export async function setPreDueReminderLeadDays(days: number, dbInstance?: any): Promise<void> {
  try {
    localStorage.setItem("mabala_pre_due_reminder_lead_days", days.toString());
  } catch (_) {}

  const targetDb = dbInstance || db;
  if (targetDb) {
    try {
      await setDoc(doc(targetDb, "system", "feeConfig"), {
        preDueReminderLeadDays: days,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (e) {
      console.warn("[Credit Engine] Failed to sync reminder lead days to Firestore:", e);
    }
  }
}

/**
 * Retrieves all stored v3 subscriptions
 */
export function getAllV3Subscriptions(): SubscriptionRecordV3[] {
  try {
    const str = localStorage.getItem("mabala_v3_subscriptions");
    if (str) {
      return JSON.parse(str);
    }
  } catch (_) {}
  return [];
}

/**
 * Retrieves active subscription for a specific tenant
 */
export function getTenantV3Subscription(tenantId: string): SubscriptionRecordV3 | null {
  const all = getAllV3Subscriptions();
  const sub = all.find(s => s.tenantId === tenantId && s.status !== "CANCELLED");
  return sub || null;
}

/**
 * Flags subscription cancellation for Super Admin manual pro-rated refund handling
 */
export async function requestSubscriptionCancellation(params: {
  tenantId: string;
  subscriptionId: string;
  reason: string;
  userEmail?: string;
  dbInstance?: any;
}): Promise<{ success: boolean; message: string }> {
  const now = new Date().toISOString();
  const all = getAllV3Subscriptions();
  const index = all.findIndex(s => s.id === params.subscriptionId || s.tenantId === params.tenantId);

  if (index !== -1) {
    all[index].status = "CANCELLED";
    all[index].cancellationRequested = true;
    all[index].cancellationRequestedAt = now;
    all[index].cancellationReason = params.reason;
    all[index].refundStatus = "REQUESTED_SUPER_ADMIN_MANUAL";
    try {
      localStorage.setItem("mabala_v3_subscriptions", JSON.stringify(all));
    } catch (_) {}
  }

  const targetDb = params.dbInstance || db;
  if (targetDb) {
    try {
      await updateDoc(doc(targetDb, "subscriptions", params.subscriptionId), {
        status: "CANCELLED",
        cancellationRequested: true,
        cancellationRequestedAt: now,
        cancellationReason: params.reason,
        refundStatus: "REQUESTED_SUPER_ADMIN_MANUAL",
        updatedAt: now
      });
      await updateDoc(doc(targetDb, "users_data", params.tenantId), {
        subscriptionStatus: "CANCELLED",
        cancellationRequested: true,
        updatedAt: now
      });
    } catch (e) {
      console.warn("[Credit Engine] Cancellation update notice:", e);
    }
  }

  // Create an in-app notification acknowledging cancellation request
  await createInAppNotification({
    tenantId: params.tenantId,
    title: "Subscription Cancellation Logged",
    message: `Your cancellation request for ${all[index]?.planName || "your subscription"} has been registered. The Super Admin team will review manual pro-rated refund calculations.`,
    type: "warning"
  });

  return {
    success: true,
    message: "Cancellation registered. Super Admin has been notified for manual pro-rated refund review."
  };
}

/**
 * Creates standard In-App Notification under `/users_data/{tenantId}/notifications/{id}`
 */
export async function createInAppNotification(params: {
  tenantId: string;
  title: string;
  message: string;
  type: "info" | "success" | "warning" | "error";
  linkUrl?: string;
  dbInstance?: any;
}): Promise<void> {
  const notifId = `NOTIF-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;
  const notifObj = {
    id: notifId,
    title: params.title,
    message: params.message,
    type: params.type,
    linkUrl: params.linkUrl || "",
    timestamp: new Date().toISOString(),
    read: false
  };

  // Local storage cache
  try {
    const key = `mabala_notifications_${params.tenantId}`;
    const raw = localStorage.getItem(key);
    const existing = raw ? JSON.parse(raw) : [];
    existing.unshift(notifObj);
    localStorage.setItem(key, JSON.stringify(existing.slice(0, 100)));
  } catch (_) {}

  const targetDb = params.dbInstance || db;
  if (targetDb) {
    try {
      await setDoc(doc(targetDb, "users_data", params.tenantId, "notifications", notifId), notifObj);
    } catch (e) {
      console.warn("[Credit Engine] In-app notification write notice:", e);
    }
  }
}

/**
 * Dispatches Section 10.3 Pre-Due Reminder across Email, SMS, and In-App
 */
export async function dispatchPreDueReminder(
  subscription: SubscriptionRecordV3,
  dbInstance?: any
): Promise<PreDueReminderLogV3 | null> {
  // 1. Validation exclusions (Section 10.3)
  // Not sent for Seeding (free, no billing)
  if (subscription.planId === "PLAN_SEEDING") {
    return null;
  }
  // Not sent for Daily Bundle (single purchase, no recurring billing)
  if (subscription.planId === "PLAN_DAILY") {
    return null;
  }
  // Not sent for active yearly (12-month) subscriptions
  if (subscription.termMonths === 12) {
    return null;
  }

  const origin = typeof window !== "undefined" ? window.location.origin : "https://mabala.ag";
  const lipilaPayLink = `${origin}?payRenewSub=${encodeURIComponent(subscription.id)}&plan=${encodeURIComponent(subscription.planId)}&term=${subscription.termMonths}`;
  const nowIso = new Date().toISOString();
  const recipientEmail = subscription.customerEmail || `billing@${subscription.tenantId.toLowerCase()}.zm`;
  const recipientPhone = subscription.customerPhone || "+260 97 0000000";

  const emailSubject = `[RENEWAL REMINDER] Upcoming ${subscription.planName} Payment Due ${subscription.endDate.split("T")[0]} - Mabala Agritech`;
  const emailBody = `
Dear ${subscription.tenantName},

This is an automated pre-due reminder regarding your upcoming subscription renewal for Mabala Agritech.

--------------------------------------------------
SUBSCRIPTION RENEWAL NOTICE
--------------------------------------------------
Plan: ${subscription.planName} (${subscription.termMonths} Month Term)
Amount Due: ZMW ${subscription.priceZMW.toLocaleString()}
Renewal Due Date: ${subscription.endDate.split("T")[0]}

INSTANT LIPILA PAYMENT LINK:
Click the link below to renew your plan via Lipila Mobile Money (Airtel, MTN, Zamtel) or Visa/Mastercard:
${lipilaPayLink}

Your allocated monthly operations credits (+${subscription.monthlyCredits.toLocaleString()} credits) will be replenished immediately upon confirmation.

Thank you for powering your operations with Mabala Agritech.
Finance & Billing Team | Mabala Cloud Lusaka
`;

  const smsBody = `[MABALA] Reminder: Your ${subscription.planName} renewal of ZMW ${subscription.priceZMW.toLocaleString()} is due on ${subscription.endDate.split("T")[0]}. Pay online via Lipila: ${lipilaPayLink}`;

  const inAppTitle = `Upcoming Renewal: ${subscription.planName}`;
  const inAppMessage = `Your ${subscription.planName} renewal of ZMW ${subscription.priceZMW.toLocaleString()} is due on ${subscription.endDate.split("T")[0]}. Click to renew via Lipila.`;

  // 1. In-App delivery
  await createInAppNotification({
    tenantId: subscription.tenantId,
    title: inAppTitle,
    message: inAppMessage,
    type: "info",
    linkUrl: lipilaPayLink,
    dbInstance
  });

  // 2. Firebase Trigger Email delivery
  const targetDb = dbInstance || db;
  if (targetDb) {
    try {
      await setDoc(doc(targetDb, "mail", `pre-due-${subscription.id}-${Date.now()}`), {
        to: recipientEmail,
        message: {
          subject: emailSubject,
          text: emailBody
        },
        metadata: {
          tenantId: subscription.tenantId,
          subscriptionId: subscription.id,
          type: "PRE_DUE_REMINDER"
        },
        sentAt: nowIso
      });
    } catch (e) {
      console.warn("[Credit Engine] Trigger email write notice:", e);
    }
  }

  // 3. Log Reminder
  const log: PreDueReminderLogV3 = {
    id: `PREDUE-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
    subscriptionId: subscription.id,
    tenantId: subscription.tenantId,
    tenantName: subscription.tenantName,
    recipientEmail,
    recipientPhone,
    planName: subscription.planName,
    termMonths: subscription.termMonths,
    amountDueZMW: subscription.priceZMW,
    dueDate: subscription.endDate.split("T")[0],
    lipilaPayLink,
    channelsDispatched: {
      email: true,
      sms: true,
      inApp: true
    },
    sentAt: nowIso,
    status: "DISPATCHED"
  };

  try {
    const raw = localStorage.getItem("mabala_pre_due_reminder_logs");
    const existing = raw ? JSON.parse(raw) : [];
    existing.unshift(log);
    localStorage.setItem("mabala_pre_due_reminder_logs", JSON.stringify(existing.slice(0, 100)));
  } catch (_) {}

  return log;
}

/**
 * Dispatches Section 10.4 Monthly Statement across Email, SMS, and In-App
 */
export async function dispatchMonthlyStatement(params: {
  tenantId: string;
  tenantName: string;
  role: UserRoleV3;
  email?: string;
  phone?: string;
  statementPeriod?: string;
  dbInstance?: any;
}): Promise<MonthlyStatementLogV3 | null> {

  const now = new Date();
  const period = params.statementPeriod || now.toLocaleString("default", { month: "long", year: "numeric" });
  const recipientEmail = params.email || `accounts@${params.tenantId.toLowerCase()}.zm`;
  const recipientPhone = params.phone || "+260 97 0000000";
  const nowIso = now.toISOString();

  let log: MonthlyStatementLogV3;

  if (params.role === "SUPPLIER") {
    // Supplier statement leg
    const purchased = await getSupplierPurchasedReports(params.tenantId, params.dbInstance);
    const reportsList = Object.values(purchased);
    const totalFees = reportsList.reduce((sum, r) => sum + (r.amountZMW || 0), 0);

    const emailSubject = `[MONTHLY STATEMENT - ${period}] Supplier Intelligence Activity - Mabala Agritech`;
    const emailBody = `
Dear ${params.tenantName} (Supplier Partner),

Here is your monthly platform statement for ${period}.

--------------------------------------------------
SUPPLIER INTELLIGENCE & REPORT ACTIVITY
--------------------------------------------------
Total Intelligence Reports Accessed: ${reportsList.length}
Total Fees Charged (Lipila Authorized): ZMW ${totalFees.toLocaleString()}

ITEMIZED REPORT ACCESS LOG:
${reportsList.map(r => `  • ${r.reportTitle}: ZMW ${r.amountZMW.toLocaleString()} (${r.purchasedAt.split("T")[0]}, Ref: ${r.referenceId})`).join("\n") || "  • No report access events recorded during this calendar period."}

Note: As a registered supplier, your account is free of monthly subscription fees. You are only billed per-report unlocked.

Thank you for partnering with the Mabala Agritech Network.
Finance Operations | Mabala Cloud Lusaka
`;

    const smsBody = `[MABALA STATEMENT] ${params.tenantName}: In ${period}, you accessed ${reportsList.length} reports for total ZMW ${totalFees.toLocaleString()}. Zero monthly subscription fee. Details: email sent.`;
    const inAppTitle = `Monthly Statement: ${period}`;
    const inAppMessage = `Your ${period} supplier intelligence summary is ready: ${reportsList.length} reports accessed (ZMW ${totalFees.toLocaleString()} total).`;

    // 1. In-App delivery
    await createInAppNotification({
      tenantId: params.tenantId,
      title: inAppTitle,
      message: inAppMessage,
      type: "info",
      dbInstance: params.dbInstance
    });

    log = {
      id: `STMT-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
      tenantId: params.tenantId,
      tenantName: params.tenantName,
      recipientEmail,
      recipientPhone,
      role: params.role,
      statementPeriod: period,
      reportsAccessedCount: reportsList.length,
      totalReportFeesChargedZMW: totalFees,
      reportsSummary: reportsList.map(r => ({
        reportId: r.reportId,
        title: r.reportTitle,
        feeZMW: r.amountZMW,
        timestamp: r.purchasedAt
      })),
      channelsDispatched: {
        email: true,
        sms: true,
        inApp: true
      },
      sentAt: nowIso,
      status: "DISPATCHED"
    };
  } else {
    // Subscriber statement leg (Monthly, Growth, Enterprise — including 12-month Yearly)
    const sub = getTenantV3Subscription(params.tenantId);
    
    // Skip if free Seeding with no activity
    if (sub && sub.planId === "PLAN_SEEDING") {
      return null;
    }

    const creditsAllocated = sub ? sub.creditsAllocatedTotal : 1500;
    const creditsRemaining = sub ? sub.creditsRemaining : 1200;
    const creditsConsumed = Math.max(0, creditsAllocated - creditsRemaining);

    const emailSubject = `[MONTHLY STATEMENT - ${period}] Subscription & Credits Activity - Mabala Agritech`;
    const emailBody = `
Dear ${params.tenantName},

Here is your monthly account statement for ${period}.

--------------------------------------------------
ACCOUNT & CREDIT STATEMENT
--------------------------------------------------
Active Plan: ${sub?.planName || "Monthly Plan"} (${sub?.termMonths || 1} Month Term)
Subscription Status: ${sub?.status || "ACTIVE"}
Credits Allocated in Term: ${creditsAllocated.toLocaleString()}
Credits Consumed in Period: ${creditsConsumed.toLocaleString()}
Credits Remaining in Wallet: ${creditsRemaining.toLocaleString()}

${sub?.termMonths === 12 ? "Note: Your 12-Month Yearly term is paid upfront. No payment is currently due." : ""}

Thank you for powering your operations with Mabala Agritech.
Finance & Billing Operations | Mabala Cloud Lusaka
`;

    const smsBody = `[MABALA STATEMENT] ${params.tenantName}: ${period} Credit Summary: ${creditsAllocated.toLocaleString()} allocated, ${creditsConsumed.toLocaleString()} used, ${creditsRemaining.toLocaleString()} remaining in wallet.`;
    const inAppTitle = `Monthly Statement: ${period}`;
    const inAppMessage = `Your ${period} account statement: ${creditsRemaining.toLocaleString()} credits remaining in your operational wallet.`;

    await createInAppNotification({
      tenantId: params.tenantId,
      title: inAppTitle,
      message: inAppMessage,
      type: "info",
      dbInstance: params.dbInstance
    });

    log = {
      id: `STMT-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
      tenantId: params.tenantId,
      tenantName: params.tenantName,
      recipientEmail,
      recipientPhone,
      role: params.role,
      statementPeriod: period,
      creditsAllocated,
      creditsConsumed,
      creditsRemaining,
      topupsPurchasedZMW: 0,
      channelsDispatched: {
        email: true,
        sms: true,
        inApp: true
      },
      sentAt: nowIso,
      status: "DISPATCHED"
    };
  }

  try {
    const raw = localStorage.getItem("mabala_monthly_statement_logs");
    const existing = raw ? JSON.parse(raw) : [];
    existing.unshift(log);
    localStorage.setItem("mabala_monthly_statement_logs", JSON.stringify(existing.slice(0, 100)));
  } catch (_) {}

  return log;
}

/**
 * Runs automated scanner cycle for Section 10 Invoice Reminders and Statements
 */
export async function runInvoiceReminderAndStatementCycle(dbInstance?: any): Promise<{
  scannedSubscriptionsCount: number;
  preDueRemindersDispatched: number;
  monthlyStatementsDispatched: number;
  leadDays: number;
  logs: {
    preDueLogs: PreDueReminderLogV3[];
    statementLogs: MonthlyStatementLogV3[];
  };
}> {
  const leadDays = getPreDueReminderLeadDays();
  const allSubs = getAllV3Subscriptions();
  const now = new Date();

  let preDueRemindersDispatched = 0;
  let monthlyStatementsDispatched = 0;
  const preDueLogs: PreDueReminderLogV3[] = [];
  const statementLogs: MonthlyStatementLogV3[] = [];

  for (const sub of allSubs) {
    if (sub.status !== "ACTIVE" && sub.status !== "READ_ONLY") continue;

    // Check Pre-Due Reminder eligibility
    const endDate = new Date(sub.endDate);
    const diffMs = endDate.getTime() - now.getTime();
    const daysUntilDue = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

    if (daysUntilDue <= leadDays && daysUntilDue >= 0) {
      const log = await dispatchPreDueReminder(sub, dbInstance);
      if (log) {
        preDueLogs.push(log);
        preDueRemindersDispatched++;
      }
    }

    // Dispatch monthly statement for paid subscribers
    const stmtLog = await dispatchMonthlyStatement({
      tenantId: sub.tenantId,
      tenantName: sub.tenantName,
      role: sub.userRole,
      email: sub.customerEmail,
      phone: sub.customerPhone,
      dbInstance
    });
    if (stmtLog) {
      statementLogs.push(stmtLog);
      monthlyStatementsDispatched++;
    }
  }

  return {
    scannedSubscriptionsCount: allSubs.length,
    preDueRemindersDispatched,
    monthlyStatementsDispatched,
    leadDays,
    logs: {
      preDueLogs,
      statementLogs
    }
  };
}

/**
 * Retrieves pre-due reminder logs
 */
export function getPreDueReminderLogs(): PreDueReminderLogV3[] {
  try {
    const raw = localStorage.getItem("mabala_pre_due_reminder_logs");
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  return [];
}

/**
 * Retrieves monthly statement logs
 */
export function getMonthlyStatementLogs(): MonthlyStatementLogV3[] {
  try {
    const raw = localStorage.getItem("mabala_monthly_statement_logs");
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  return [];
}



/**
 * KoboCollect Offline Data Synchronization Service
 * 
 * Implements the ODK / KoboCollect technology pattern for robust, offline-first
 * agricultural data collection, durable multi-tier storage (LocalStorage + IndexedDB),
 * and automatic, non-blocking synchronization with Firebase Firestore upon network restoration.
 */

import { db } from "../firebase";
import { doc, setDoc, getDoc, getDocs, collection, writeBatch } from "firebase/firestore";
import { safeLocalStorage, safeParseJSON } from "../utils/safeStorage";
import { saveToOfflineStore, getFromOfflineStore, getAllFromOfflineStore, setOfflineDbScope } from "../db/offline_db";
import { offlineQueueService } from "./offlineQueueService";

export interface KoboSubmissionEnvelope {
  id: string;
  formId: string;
  entityType: string;
  action: "CREATE" | "UPDATE" | "DELETE" | "UPSERT_LIST" | "FULL_WORKSPACE_SYNC";
  payload: any;
  tenantId: string;
  userEmail: string;
  deviceTimestamp: string;
  status: "saved_offline" | "syncing" | "synced" | "sync_error";
  retryCount: number;
  lastError?: string;
}

export interface KoboSyncStatus {
  isOnline: boolean;
  isSyncing: boolean;
  pendingCount: number;
  lastSyncTimestamp: string | null;
  lastSyncedModules: string[];
  syncErrors: string[];
}

const BASE_KOBO_QUEUE_KEY = "mabala_kobo_submissions_queue";
const KOBO_LAST_SYNC_KEY = "mabala_kobo_last_successful_sync";

function getQueueStorageKey(scope?: string): string {
  if (!scope || scope === "guest" || scope === "unauthenticated") {
    return `${BASE_KOBO_QUEUE_KEY}_guest`;
  }
  const clean = scope.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
  return `${BASE_KOBO_QUEUE_KEY}_${clean}`;
}

class KoboCollectSyncService {
  private queue: KoboSubmissionEnvelope[] = [];
  private isSyncing = false;
  private syncListeners: Set<(status: KoboSyncStatus) => void> = new Set();
  private heartbeatInterval: any = null;
  private isInitialized = false;
  private currentScope: string = "guest";

  constructor() {
    this.loadQueueFromStorage();
    this.initNetworkListeners();
    this.startHeartbeat();
  }

  public setKoboScope(uid?: string | null, tenantId?: string | null): void {
    const raw = (uid || tenantId || "guest").trim().toLowerCase();
    const clean = raw.replace(/[^a-z0-9_-]/g, "_") || "guest";
    
    if (this.currentScope !== clean) {
      this.currentScope = clean;
      setOfflineDbScope(clean);
      this.loadQueueFromStorage();
      this.notifyListeners();
    }
  }

  public clearKoboStorage(scopeUid?: string): void {
    const targetKey = getQueueStorageKey(scopeUid || this.currentScope);
    safeLocalStorage.removeItem(targetKey);
    safeLocalStorage.removeItem(BASE_KOBO_QUEUE_KEY);
    this.queue = [];
    this.notifyListeners();
  }

  private loadQueueFromStorage() {
    try {
      const key = getQueueStorageKey(this.currentScope);
      const raw = safeLocalStorage.getItem(key) || safeLocalStorage.getItem(BASE_KOBO_QUEUE_KEY);
      if (raw) {
        const parsed = safeParseJSON<KoboSubmissionEnvelope[]>(raw, []);
        if (Array.isArray(parsed)) {
          // Verify items belong to current scope if authenticated
          if (this.currentScope !== "guest") {
            this.queue = parsed.filter(item => {
              const itemOwner = (item.userEmail || item.tenantId || "").trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
              return !itemOwner || itemOwner === this.currentScope || this.currentScope.includes(itemOwner) || itemOwner.includes(this.currentScope);
            });
          } else {
            this.queue = parsed;
          }
        }
      } else {
        this.queue = [];
      }
    } catch (e) {
      console.warn("[KoboCollect] Error loading submission queue from storage:", e);
      this.queue = [];
    }
  }

  private saveQueueToStorage() {
    try {
      const key = getQueueStorageKey(this.currentScope);
      safeLocalStorage.setItem(key, JSON.stringify(this.queue));
    } catch (e) {
      console.warn("[KoboCollect] Error saving submission queue to storage:", e);
    }
    this.notifyListeners();
  }

  private initNetworkListeners() {
    if (typeof window === "undefined" || this.isInitialized) return;
    this.isInitialized = true;

    window.addEventListener("online", () => {
      console.log("[KoboCollect] Network connection restored. Auto-syncing pending offline submissions to Firebase...");
      this.syncPendingSubmissions();
    });

    window.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible" && window.navigator.onLine) {
        this.syncPendingSubmissions();
      }
    });

    window.addEventListener("focus", () => {
      if (window.navigator.onLine) {
        this.syncPendingSubmissions();
      }
    });
  }

  private startHeartbeat() {
    if (typeof window === "undefined") return;
    if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);

    // Heartbeat every 20 seconds when online to ensure no queued submission gets left behind
    this.heartbeatInterval = setInterval(() => {
      if (window.navigator.onLine && this.queue.length > 0 && !this.isSyncing) {
        console.log(`[KoboCollect] Heartbeat trigger: Flushing ${this.queue.length} pending offline submissions...`);
        this.syncPendingSubmissions();
      }
    }, 20000);
  }

  public subscribe(listener: (status: KoboSyncStatus) => void): () => void {
    this.syncListeners.add(listener);
    listener(this.getStatus());
    return () => {
      this.syncListeners.delete(listener);
    };
  }

  private notifyListeners() {
    const status = this.getStatus();
    this.syncListeners.forEach(fn => {
      try {
        fn(status);
      } catch (e) {}
    });
  }

  public getStatus(): KoboSyncStatus {
    const isOnline = typeof window !== "undefined" ? window.navigator.onLine : true;
    const pendingCount = this.queue.filter(q => q.status === "saved_offline" || q.status === "sync_error").length;
    const lastSyncTimestamp = safeLocalStorage.getItem(KOBO_LAST_SYNC_KEY);

    return {
      isOnline,
      isSyncing: this.isSyncing,
      pendingCount,
      lastSyncTimestamp,
      lastSyncedModules: [],
      syncErrors: this.queue.filter(q => q.status === "sync_error" && q.lastError).map(q => `${q.entityType}: ${q.lastError}`)
    };
  }

  public getPendingSubmissions(): KoboSubmissionEnvelope[] {
    return [...this.queue];
  }

  public getPendingCount(): number {
    return this.queue.filter(q => q.status === "saved_offline" || q.status === "sync_error").length;
  }

  /**
   * KoboCollect Core: Saves an agricultural record immediately to local storage tiers
   * and registers an offline submission envelope for background cloud sync.
   */
  public async saveRecordOffline(
    entityType: string,
    record: any,
    tenantId: string,
    userEmail: string,
    action: "CREATE" | "UPDATE" | "DELETE" = "CREATE"
  ): Promise<void> {
    const now = new Date().toISOString();
    const cleanEmail = (userEmail || "").trim().toLowerCase();
    const cleanTenantId = (tenantId || cleanEmail || "tenant_default").trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");

    this.setKoboScope(cleanTenantId);

    // 1. Durably write record to IndexedDB
    let idbError: string | undefined;
    try {
      if (record && (record.id || record.operationId)) {
        await saveToOfflineStore(entityType, {
          ...record,
          tenantId: cleanTenantId,
          updatedAt: now
        });
      }
    } catch (idbErr: any) {
      idbError = idbErr?.message || String(idbErr);
      console.error(`[KoboCollect] IndexedDB storage error for ${entityType}:`, idbErr);
    }

    // 2. Create an immutable KoboCollect submission envelope
    const envelopeId = `kobo_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const envelope: KoboSubmissionEnvelope = {
      id: envelopeId,
      formId: `mabala_${entityType}_form`,
      entityType,
      action,
      payload: record,
      tenantId: cleanTenantId,
      userEmail: cleanEmail,
      deviceTimestamp: now,
      status: idbError ? "sync_error" : "saved_offline",
      retryCount: 0,
      lastError: idbError
    };

    // Deduplicate against existing pending items for same record
    if (record && record.id) {
      this.queue = this.queue.filter(
        item => !(item.entityType === entityType && item.payload?.id === record.id && item.status !== "syncing")
      );
    }

    this.queue.push(envelope);
    this.saveQueueToStorage();

    if (idbError) {
      throw new Error(`[KoboCollect] Offline store failure for ${entityType}: ${idbError}`);
    }

    console.log(`[KoboCollect] Record saved offline in durable storage: ${entityType} [${record?.id || "item"}]. Enqueued for cloud sync.`);

    // 3. If online, attempt non-blocking cloud sync immediately
    if (typeof window !== "undefined" && window.navigator.onLine) {
      setTimeout(() => {
        this.syncPendingSubmissions().catch(err => {
          console.warn("[KoboCollect] Non-blocking cloud sync notice:", err);
        });
      }, 100);
    }
  }

  /**
   * KoboCollect Core: Saves a full collection (e.g. all crops, expenses, etc.) offline
   */
  public async saveCollectionOffline(
    entityType: string,
    records: any[],
    tenantId: string,
    userEmail: string
  ): Promise<void> {
    const now = new Date().toISOString();
    const cleanEmail = (userEmail || "").trim().toLowerCase();
    const cleanTenantId = (tenantId || cleanEmail || "tenant_default").trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");

    this.setKoboScope(cleanTenantId);

    // 1. Save all individual items to IndexedDB
    let idbError: string | undefined;
    try {
      if (Array.isArray(records)) {
        for (const item of records) {
          if (item && (item.id || item.operationId)) {
            await saveToOfflineStore(entityType, {
              ...item,
              tenantId: cleanTenantId,
              updatedAt: now
            });
          }
        }
      }
    } catch (idbErr: any) {
      idbError = idbErr?.message || String(idbErr);
      console.error(`[KoboCollect] Error saving collection to IndexedDB for ${entityType}:`, idbErr);
    }

    // 2. Save to scoped localStorage key and active key
    try {
      safeLocalStorage.setItem(`mabala_${entityType}_${cleanTenantId}`, JSON.stringify(records));
      safeLocalStorage.setItem(`mabala_${entityType}`, JSON.stringify(records));
    } catch (e) {}

    // 3. Register submission envelope
    const envelopeId = `kobo_batch_${Date.now()}_${entityType}`;
    const envelope: KoboSubmissionEnvelope = {
      id: envelopeId,
      formId: `mabala_${entityType}_batch_form`,
      entityType,
      action: "UPSERT_LIST",
      payload: records,
      tenantId: cleanTenantId,
      userEmail: cleanEmail,
      deviceTimestamp: now,
      status: idbError ? "sync_error" : "saved_offline",
      retryCount: 0,
      lastError: idbError
    };

    // Replace previous batch for this entityType
    this.queue = this.queue.filter(
      item => !(item.entityType === entityType && item.action === "UPSERT_LIST" && item.status !== "syncing")
    );

    this.queue.push(envelope);
    this.saveQueueToStorage();

    if (idbError) {
      throw new Error(`[KoboCollect] Offline collection store failure for ${entityType}: ${idbError}`);
    }

    if (typeof window !== "undefined" && window.navigator.onLine) {
      setTimeout(() => {
        this.syncPendingSubmissions().catch(() => {});
      }, 100);
    }
  }

  /**
   * KoboCollect Core Sync: Flushes queued submissions to Firebase Firestore
   */
  public async syncPendingSubmissions(): Promise<{ success: number; failed: number }> {
    if (this.isSyncing) {
      return { success: 0, failed: 0 };
    }
    if (typeof window === "undefined" || !window.navigator.onLine) {
      return { success: 0, failed: 0 };
    }
    if (this.queue.length === 0) {
      return { success: 0, failed: 0 };
    }

    this.isSyncing = true;
    this.notifyListeners();

    let success = 0;
    let failed = 0;
    const syncedModules = new Set<string>();

    const itemsToProcess = [...this.queue];

    for (const item of itemsToProcess) {
      if (item.status === "syncing") continue;

      item.status = "syncing";
      this.saveQueueToStorage();

      try {
        const targetUid = item.tenantId || item.userEmail;

        if (item.action === "UPSERT_LIST" || item.action === "FULL_WORKSPACE_SYNC") {
          // Write module array to users_data/{targetUid}/modules/{entityType}
          const modDocRef = doc(db, "users_data", targetUid, "modules", item.entityType);
          await setDoc(modDocRef, {
            data: item.payload,
            updatedAt: new Date().toISOString(),
            clientCapturedAt: item.deviceTimestamp,
            koboSubmissionId: item.id
          }, { merge: true });

          // Also if crops, write individual crop cycles to crop_cycles collection if applicable
          if (item.entityType === "crops" && Array.isArray(item.payload)) {
            for (const crop of item.payload) {
              if (crop && crop.id) {
                try {
                  const cropDocRef = doc(db, "crop_cycles", crop.id);
                  await setDoc(cropDocRef, {
                    ...crop,
                    tenantId: targetUid,
                    updatedAt: new Date().toISOString(),
                    clientCapturedAt: item.deviceTimestamp
                  }, { merge: true });
                } catch (cErr) {
                  // non-blocking for top-level collection
                }
              }
            }
          }
        } else if (item.action === "CREATE" || item.action === "UPDATE") {
          // Write individual record to module collection and top-level store
          const modDocRef = doc(db, "users_data", targetUid, "modules", item.entityType);
          const currentSnap = await getDoc(modDocRef);
          let currentList: any[] = [];
          if (currentSnap.exists() && Array.isArray(currentSnap.data()?.data)) {
            currentList = currentSnap.data().data;
          }

          const existingIdx = currentList.findIndex((x: any) => x.id === item.payload?.id);
          if (existingIdx >= 0) {
            currentList[existingIdx] = item.payload;
          } else {
            currentList = [item.payload, ...currentList];
          }

          await setDoc(modDocRef, {
            data: currentList,
            updatedAt: new Date().toISOString(),
            clientCapturedAt: item.deviceTimestamp,
            koboSubmissionId: item.id
          }, { merge: true });

          if (item.entityType === "crops" && item.payload?.id) {
            try {
              const cropDocRef = doc(db, "crop_cycles", item.payload.id);
              await setDoc(cropDocRef, {
                ...item.payload,
                tenantId: targetUid,
                updatedAt: new Date().toISOString(),
                clientCapturedAt: item.deviceTimestamp
              }, { merge: true });
            } catch (e) {}
          }
        }

        // Successfully synced
        item.status = "synced";
        success++;
        syncedModules.add(item.entityType);

        // Remove from queue
        this.queue = this.queue.filter(q => q.id !== item.id);
      } catch (syncErr: any) {
        failed++;
        item.status = "sync_error";
        item.retryCount += 1;
        item.lastError = syncErr?.message || String(syncErr);
        console.warn(`[KoboCollect] Submission ${item.id} sync failed:`, syncErr);
      }
    }

    if (success > 0) {
      safeLocalStorage.setItem(KOBO_LAST_SYNC_KEY, new Date().toISOString());
      console.log(`[KoboCollect] Successfully synchronized ${success} offline submission(s) to Firebase!`);
    }

    this.isSyncing = false;
    this.saveQueueToStorage();

    return { success, failed };
  }

  /**
   * KoboCollect Smart Two-Way Merge:
   * Merges remote cloud workspace with local offline storage, ensuring that
   * freshly created local records (e.g. Onion crop cycle) are NEVER wiped out by
   * empty or outdated cloud responses.
   */
  public mergeRemoteAndLocalCollections(
    remoteList: any[] | undefined | null,
    localList: any[] | undefined | null,
    keyField: string = "id"
  ): { merged: any[]; hasLocalAdditions: boolean } {
    const remote = Array.isArray(remoteList) ? remoteList : [];
    const local = Array.isArray(localList) ? localList : [];

    if (local.length === 0) {
      return { merged: remote, hasLocalAdditions: false };
    }
    if (remote.length === 0) {
      return { merged: local, hasLocalAdditions: local.length > 0 };
    }

    const resultMap = new Map<string, any>();
    let hasLocalAdditions = false;

    // 1. Add all remote items
    remote.forEach(item => {
      const id = item?.[keyField] || JSON.stringify(item);
      resultMap.set(id, item);
    });

    // 2. Merge local items: keep local if it does not exist in remote or is newer
    local.forEach(localItem => {
      const id = localItem?.[keyField] || JSON.stringify(localItem);
      if (!resultMap.has(id)) {
        // Local has a record NOT in cloud (created offline or not yet synced) -> PRESERVE IT!
        resultMap.set(id, localItem);
        hasLocalAdditions = true;
      } else {
        const remoteItem = resultMap.get(id);
        const localTime = new Date(localItem.updatedAt || localItem.createdAt || localItem.date || 0).getTime();
        const remoteTime = new Date(remoteItem.updatedAt || remoteItem.createdAt || remoteItem.date || 0).getTime();

        if (localTime > remoteTime) {
          resultMap.set(id, localItem);
          hasLocalAdditions = true;
        }
      }
    });

    const merged = Array.from(resultMap.values());
    return { merged, hasLocalAdditions };
  }
}

export const koboCollectSyncService = new KoboCollectSyncService();

/**
 * Mabala.cloud - Client-side Loan Service
 * Provides typed methods to interact with Authoritative Loan Server APIs & Firestore
 */

import {
  Loan,
  LoanProduct,
  LoanApplication,
  LoanTransaction,
  PortfolioMetrics
} from "../modules/loans/types";
import { DEFAULT_LOAN_PRODUCTS } from "../modules/loans/data/defaultLoanProducts";
import { collection, query, where, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";
import { jsPDF } from "jspdf";

const API_BASE = "";

/**
 * Fetch available loan products (with default fallback)
 */
export async function fetchLoanProducts(filters?: {
  tenantId?: string;
  financingModel?: string;
  status?: string;
}): Promise<LoanProduct[]> {
  try {
    const params = new URLSearchParams();
    if (filters?.tenantId) params.set("tenantId", filters.tenantId);
    if (filters?.financingModel) params.set("financingModel", filters.financingModel);
    if (filters?.status) params.set("status", filters.status);

    const res = await fetch(`${API_BASE}/api/loans/products?${params.toString()}`);
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.products)) {
        return data.products;
      }
    }
  } catch (err) {
    console.warn("[LoanService] Failed to fetch products from API, using defaults:", err);
  }

  // Fallback to default catalog (empty by default for clean platform baseline)
  let fallback = DEFAULT_LOAN_PRODUCTS;
  if (filters?.financingModel) {
    fallback = fallback.filter((p) => p.financingModel === filters.financingModel);
  }
  return fallback;
}

/**
 * Delete a specific loan product
 */
export async function deleteLoanProduct(id: string): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/api/loans/products/${id}`, { method: "DELETE" });
    return res.ok;
  } catch (err) {
    console.error(`[LoanService] Failed to delete product ${id}:`, err);
    return false;
  }
}

/**
 * Remove all loan products and financing facilities from the platform
 */
export async function deleteAllLoanProducts(): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/api/loans/products`, { method: "DELETE" });
    return res.ok;
  } catch (err) {
    console.error("[LoanService] Failed to delete all products:", err);
    return false;
  }
}

/**
 * Create or update a loan product (Lenders & Agro Dealers)
 */
export async function createLoanProduct(product: Partial<LoanProduct>): Promise<LoanProduct> {
  const res = await fetch(`${API_BASE}/api/loans/products`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(product)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `Failed to create loan product (status ${res.status})`);
  }

  const data = await res.json();
  return data.product;
}

/**
 * Fetch loan applications
 */
export async function fetchLoanApplications(filters?: {
  tenantId?: string;
  lenderTenantId?: string;
  status?: string;
}): Promise<LoanApplication[]> {
  const params = new URLSearchParams();
  if (filters?.tenantId) params.set("tenantId", filters.tenantId);
  if (filters?.lenderTenantId) params.set("lenderTenantId", filters.lenderTenantId);
  if (filters?.status) params.set("status", filters.status);

  const res = await fetch(`${API_BASE}/api/loans/applications?${params.toString()}`);
  if (!res.ok) {
    throw new Error("Failed to fetch loan applications");
  }

  const data = await res.json();
  return data.applications || [];
}

/**
 * Submit a loan application (Farmers & Agribusinesses)
 */
export async function submitLoanApplication(app: Partial<LoanApplication>): Promise<LoanApplication> {
  const res = await fetch(`${API_BASE}/api/loans/applications`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(app)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Failed to submit loan application");
  }

  const data = await res.json();
  return data.application;
}

/**
 * Review (approve or reject) a loan application (Lenders & Agro Dealers)
 */
export async function reviewLoanApplication(
  id: string,
  review: {
    action: "approve" | "reject";
    reviewer?: string;
    reason?: string;
    approvedAmount?: number;
    approvedInterestRatePct?: number;
    approvedTenorValue?: number;
  }
): Promise<LoanApplication> {
  const res = await fetch(`${API_BASE}/api/loans/applications/${id}/review`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(review)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Failed to review loan application");
  }

  const data = await res.json();
  return data.application;
}

/**
 * Authoritatively disburse an approved loan (Lenders)
 */
export async function disburseLoan(params: {
  applicationId: string;
  customDisbursementDate?: string;
  disbursementMethod?: string;
  disbursementAccount?: string;
  authorizingOfficer?: string;
}): Promise<{ loan: Loan; journalEntry: any; transaction: LoanTransaction }> {
  const res = await fetch(`${API_BASE}/api/loans/disburse`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Failed to disburse loan");
  }

  return await res.json();
}

/**
 * Fetch loans with tenant isolation
 */
export async function fetchLoans(filters?: {
  tenantId?: string;
  lenderTenantId?: string;
  status?: string;
  financingModel?: string;
}): Promise<Loan[]> {
  const params = new URLSearchParams();
  if (filters?.tenantId) params.set("tenantId", filters.tenantId);
  if (filters?.lenderTenantId) params.set("lenderTenantId", filters.lenderTenantId);
  if (filters?.status) params.set("status", filters.status);
  if (filters?.financingModel) params.set("financingModel", filters.financingModel);

  const res = await fetch(`${API_BASE}/api/loans?${params.toString()}`);
  if (!res.ok) {
    throw new Error("Failed to fetch loans");
  }

  const data = await res.json();
  return data.loans || [];
}

/**
 * Fetch single loan by ID with its transactions
 */
export async function fetchLoanById(id: string): Promise<{ loan: Loan; transactions: LoanTransaction[] }> {
  const res = await fetch(`${API_BASE}/api/loans/${id}`);
  if (!res.ok) {
    throw new Error("Failed to fetch loan details");
  }
  return await res.json();
}

/**
 * Authoritatively process a loan repayment
 */
export async function repayLoan(
  id: string,
  params: {
    amount: number;
    source?: string;
    referenceId?: string;
    notes?: string;
    performedBy?: string;
  }
): Promise<{ loan: Loan; allocation: any; journalEntry: any; transaction: LoanTransaction }> {
  const res = await fetch(`${API_BASE}/api/loans/${id}/repay`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Failed to process loan repayment");
  }

  return await res.json();
}

/**
 * Authoritatively write off a defaulted loan
 */
export async function writeOffLoan(
  id: string,
  params: { reason: string; approvedBy?: string }
): Promise<{ loan: Loan; journalEntry: any; transaction: LoanTransaction }> {
  const res = await fetch(`${API_BASE}/api/loans/${id}/write-off`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Failed to write off loan");
  }

  return await res.json();
}

/**
 * Fetch portfolio analytics for oversight and risk management
 */
export async function fetchPortfolioAnalytics(lenderTenantId?: string): Promise<PortfolioMetrics> {
  const params = new URLSearchParams();
  if (lenderTenantId) params.set("lenderTenantId", lenderTenantId);

  const res = await fetch(`${API_BASE}/api/loans/portfolio/analytics?${params.toString()}`);
  if (!res.ok) {
    throw new Error("Failed to fetch portfolio analytics");
  }

  const data = await res.json();
  return data.metrics;
}

/**
 * Generate official PDF Statement of Loan Account
 */
export function exportLoanStatementPdf(loan: Loan, transactions: LoanTransaction[] = []): void {
  const doc = new jsPDF();

  // Header
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, 210, 36, "F");

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.text("MABALA.CLOUD FINANCIAL SERVICES", 14, 16);

  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text("OFFICIAL LOAN ACCOUNT STATEMENT & AUDIT TRAIL", 14, 24);
  doc.text(`Generated on: ${new Date().toLocaleDateString("en-GB")}`, 140, 24);

  // Borrower & Facility Details
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.text("FACILITY DETAILS", 14, 46);

  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(`Loan Number: ${loan.loanNumber}`, 14, 54);
  doc.text(`Borrower: ${loan.borrowerName} (${loan.borrowerPhone})`, 14, 60);
  doc.text(`NRC / ID: ${loan.borrowerNrc || "N/A"}`, 14, 66);
  doc.text(`Farm / Entity: ${loan.borrowerFarmName || "N/A"}`, 14, 72);

  doc.text(`Financing Model: ${loan.financingModel === "agricultural_crop" ? "Agricultural Crop Financing" : "Agribusiness Enterprise"}`, 110, 54);
  doc.text(`Product: ${loan.productName}`, 110, 60);
  doc.text(`Lender / Facility Issuer: ${loan.lenderName}`, 110, 66);
  doc.text(`Disbursement Date: ${loan.disbursementDate}`, 110, 72);

  // Financial Balances Table Box
  doc.setDrawColor(226, 232, 240);
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(14, 78, 182, 34, 3, 3, "FD");

  doc.setFont("helvetica", "bold");
  doc.text("Principal Disbursed", 20, 88);
  doc.text("Total Repaid", 70, 88);
  doc.text("Outstanding Principal", 120, 88);
  doc.text("Total Balance Due", 160, 88);

  doc.setFont("helvetica", "normal");
  doc.setTextColor(15, 23, 42);
  doc.text(`${loan.currency} ${loan.principalDisbursed.toLocaleString()}`, 20, 98);
  doc.setTextColor(16, 185, 129);
  doc.text(`${loan.currency} ${loan.totalRepaid.toLocaleString()}`, 70, 98);
  doc.setTextColor(239, 68, 68);
  doc.text(`${loan.currency} ${loan.principalOutstanding.toLocaleString()}`, 120, 98);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(15, 23, 42);
  doc.text(`${loan.currency} ${loan.totalOutstandingBalance.toLocaleString()}`, 160, 98);

  // Repayment Schedule Summary
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text("REPAYMENT SCHEDULE", 14, 124);

  doc.setFontSize(9);
  doc.setFillColor(241, 245, 249);
  doc.rect(14, 128, 182, 8, "F");
  doc.text("Instal.", 16, 133);
  doc.text("Due Date", 32, 133);
  doc.text("Principal", 65, 133);
  doc.text("Interest", 95, 133);
  doc.text("Total Due", 125, 133);
  doc.text("Paid", 155, 133);
  doc.text("Status", 178, 133);

  let y = 142;
  const schedule = loan.schedule || [];
  for (let i = 0; i < Math.min(schedule.length, 12); i++) {
    const s = schedule[i];
    doc.setFont("helvetica", "normal");
    doc.text(`#${s.installmentNumber}`, 16, y);
    doc.text(s.dueDate, 32, y);
    doc.text(`K${s.principalDue.toFixed(2)}`, 65, y);
    doc.text(`K${s.interestDue.toFixed(2)}`, 95, y);
    doc.text(`K${s.totalDue.toFixed(2)}`, 125, y);
    doc.text(`K${s.totalPaid.toFixed(2)}`, 155, y);

    if (s.status === "paid") {
      doc.setTextColor(16, 185, 129);
      doc.text("PAID", 178, y);
    } else if (s.status === "partially_paid") {
      doc.setTextColor(245, 158, 11);
      doc.text("PARTIAL", 178, y);
    } else {
      doc.setTextColor(100, 116, 139);
      doc.text("PENDING", 178, y);
    }
    doc.setTextColor(30, 41, 59);
    y += 7;
  }

  // Transactions / Event Audit
  if (transactions.length > 0) {
    y += 6;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text("IMMUTABLE TRANSACTION & AUDIT LOG", 14, y);
    y += 6;

    doc.setFontSize(8);
    doc.setFillColor(241, 245, 249);
    doc.rect(14, y, 182, 7, "F");
    doc.text("Tx ID", 16, y + 5);
    doc.text("Date & Time", 46, y + 5);
    doc.text("Type", 82, y + 5);
    doc.text("Amount", 110, y + 5);
    doc.text("Method", 136, y + 5);
    doc.text("Integrity Hash", 165, y + 5);

    y += 12;
    for (let i = 0; i < Math.min(transactions.length, 8); i++) {
      const tx = transactions[i];
      doc.setFont("helvetica", "normal");
      doc.text(tx.id.substring(0, 12), 16, y);
      doc.text(tx.timestamp.substring(0, 16).replace("T", " "), 46, y);
      doc.text(tx.type.toUpperCase(), 82, y);
      doc.text(`K${tx.amount.toFixed(2)}`, 110, y);
      doc.text((tx.source || "MABALA").replace(/_/g, " "), 136, y);
      doc.setFont("courier", "normal");
      doc.text((tx.immutableHash || "").substring(0, 8), 165, y);
      doc.setFont("helvetica", "normal");
      y += 6;
    }
  }

  // Footer Disclaimer
  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184);
  doc.text("This document is an authoritative financial statement certified by Mabala.cloud.", 14, 280);
  doc.text("Transactions recorded herein are cryptographically anchored and cannot be modified retroactively.", 14, 285);

  doc.save(`Mabala_Loan_Statement_${loan.loanNumber}.pdf`);
}

import { InstitutionReportDefinition } from '../config/institutionReportDefinitions';

export interface InstitutionReportFilterParams {
  reportId: string;
  region?: string;
  cohort?: string;
  startDate?: string;
  endDate?: string;
  presetPeriod?: string;
  searchTerm?: string;
  customFilters?: Record<string, any>;
}

export interface InstitutionReportResult {
  definition: InstitutionReportDefinition;
  period: {
    label: string;
    from: string;
    to: string;
  };
  kpiMetrics: Array<{
    key: string;
    label: string;
    value: number | string;
    formatted: string;
    target?: number;
    deltaPct?: number;
  }>;
  tableRows: any[];
  chartData: any[];
  chartKeys?: Array<{
    dataKey: string;
    name: string;
    color: string;
  }>;
  summaryCallouts: string[];
  totalRecordsCount: number;
}

export const REGIONAL_TARGET_YIELDS: Record<string, number> = {
  Maize: 4500,
  Soybeans: 2300,
  Groundnuts: 1900,
  Tomatoes: 24000,
  Onion: 22000,
  Wheat: 5500,
  Sunflower: 1600,
  Avocado: 8000,
  Other: 3000
};

export function computeInstitutionReport(
  def: InstitutionReportDefinition,
  filters: InstitutionReportFilterParams,
  dashboardData: any,
  farmersList: any[] = [],
  linkedVendorsList: any[] = [],
  smsBatches: any[] = [],
  currencySymbol: string = 'ZMW'
): InstitutionReportResult {
  const farmersDetails: any[] = dashboardData?.farmersDetails || [];
  const summary: any = dashboardData?.summary || {};
  const demographics: any = dashboardData?.demographics || {};
  const cropYields: any = dashboardData?.cropYields || {};
  const livestockByType: any = dashboardData?.livestockByType || {};
  const livestockBySpecies: any = dashboardData?.livestockBySpecies || {};
  const investmentsByType: any = dashboardData?.investmentsByType || {};
  const loansByLender: any = dashboardData?.loansByLender || {};
  const loansByStatus: any = dashboardData?.loansByStatus || {};
  const offtakerActivity: any = dashboardData?.offtakerActivity || { totalValue: 0, totalVolume: 0, byProduct: {} };
  const rawSeasons: any[] = dashboardData?.seasons || [];
  const rawPoultryBatches: any[] = dashboardData?.poultryBatches || [];
  const rawLoanPortfolio: any[] = dashboardData?.loanPortfolio || [];
  const rawInvestments: any[] = dashboardData?.investments || [];
  const rawOfftakers: any[] = dashboardData?.offtakers || [];
  const rawDealers: any[] = dashboardData?.dealers || [];
  const rawInsuranceClaims: any[] = dashboardData?.insuranceClaims || [];

  // Filter farmers by region, cohort, and date if specified
  const filteredFarmers = farmersDetails.filter((f: any) => {
    if (filters.region && filters.region !== 'all' && !(f.address || '').toLowerCase().includes(filters.region.toLowerCase())) {
      return false;
    }
    if (filters.cohort && filters.cohort !== 'all' && !(f.cohortTag || '').toLowerCase().includes(filters.cohort.toLowerCase())) {
      return false;
    }
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      const match = (f.name || '').toLowerCase().includes(term) ||
                    (f.address || '').toLowerCase().includes(term) ||
                    (f.cohortTag || '').toLowerCase().includes(term);
      if (!match) return false;
    }
    return true;
  });

  const totalFilteredFarmers = filteredFarmers.length > 0 ? filteredFarmers.length : (farmersList.length || summary.totalFarmers || 0);

  let kpiMetrics: any[] = [];
  let tableRows: any[] = [];
  let chartData: any[] = [];
  let chartKeys: any[] = [];
  let summaryCallouts: string[] = [];

  switch (def.id) {
    // 1. Executive Impact Summary
    case 'me-executive-impact-summary': {
      const totalHa = filteredFarmers.reduce((acc: number, f: any) => acc + Number(f.totalHectares || 0), 0) || Number(summary.totalHectaresFarmed || 0);
      const totalRev = filteredFarmers.reduce((acc: number, f: any) => acc + Number(f.revenue || 0), 0) || Number(summary.totalRevenue || 0);
      
      let femaleCount = demographics.femaleCount !== undefined ? demographics.femaleCount : 0;
      let youthCount = demographics.youthCount !== undefined ? demographics.youthCount : 0;

      const byRegion: Record<string, any> = {};
      filteredFarmers.forEach((f: any) => {
        const reg = f.address || f.region || 'Registered Location';
        if (!byRegion[reg]) {
          byRegion[reg] = {
            region: reg,
            cohortTag: f.cohortTag || 'General Cohort',
            farmerCount: 0,
            totalHectares: 0,
            activeCrops: 0,
            totalLivestock: 0,
            femaleFarmers: 0,
            youthFarmers: 0,
            estGrossValue: 0
          };
        }
        byRegion[reg].farmerCount += 1;
        byRegion[reg].totalHectares += Number(f.totalHectares || 0);
        byRegion[reg].activeCrops += Number(f.activeCropCycles || 0);
        byRegion[reg].totalLivestock += Number(f.totalLivestock || 0);
        byRegion[reg].estGrossValue += Number(f.revenue || 0);

        const isFem = f.gender?.toLowerCase() === 'female' || f.isFemale === true || (f.role || '').toLowerCase().includes('female');
        const isYth = f.isYouth === true || (f.age && Number(f.age) < 35) || (f.category || '').toLowerCase().includes('youth');
        if (isFem) {
          byRegion[reg].femaleFarmers += 1;
          femaleCount += 1;
        }
        if (isYth) {
          byRegion[reg].youthFarmers += 1;
          youthCount += 1;
        }
      });

      const femalePct = totalFilteredFarmers > 0 ? Math.round((femaleCount / totalFilteredFarmers) * 100) : 0;

      kpiMetrics = [
        { key: 'totalFarmers', label: 'Total Smallholders', value: totalFilteredFarmers, formatted: totalFilteredFarmers.toLocaleString() },
        { key: 'totalHectares', label: 'Total Hectares Farmed', value: totalHa, formatted: `${Number(totalHa).toFixed(1)} Ha` },
        { key: 'totalGrossOutputZMW', label: 'Est. Gross Output Value', value: totalRev, formatted: `${currencySymbol} ${Math.round(totalRev).toLocaleString()}` },
        { key: 'femaleInclusionPct', label: 'Female Smallholder Ratio', value: femalePct, formatted: `${femalePct}%`, target: 45, deltaPct: femalePct - 45 },
      ];

      tableRows = Object.values(byRegion);

      chartData = tableRows.map(r => ({
        name: r.region.replace(' Province', ''),
        farmers: r.farmerCount,
        hectares: r.totalHectares,
        grossValue: Math.round(r.estGrossValue / 1000)
      }));

      chartKeys = [
        { dataKey: 'farmers', name: 'Smallholders', color: '#6366F1' },
        { dataKey: 'hectares', name: 'Area (Ha)', color: '#10B981' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No smallholder records found for the selected filter criteria.'];
      } else {
        summaryCallouts = [
          `Portfolio spans ${tableRows.length} active administrative zones covering ${totalHa.toFixed(1)} cultivated hectares.`,
          `Female inclusion stands at ${femalePct}%.`,
          `Total gross output across monitored farm gates is valued at ${currencySymbol} ${Math.round(totalRev).toLocaleString()}.`
        ];
      }
      break;
    }

    // 2. Demographic & Inclusion Audit
    case 'me-demographic-inclusion-audit': {
      let femaleCount = demographics.femaleCount || 0;
      let maleCount = demographics.maleCount || 0;
      let youthCount = demographics.youthCount || 0;

      const cohortMap: Record<string, any> = {};
      filteredFarmers.forEach((f: any) => {
        const cTag = f.cohortTag || 'Default Cohort';
        if (!cohortMap[cTag]) {
          cohortMap[cTag] = {
            cohortTag: cTag,
            region: f.address || f.region || 'Unspecified',
            totalFarmers: 0,
            femaleCount: 0,
            maleCount: 0,
            youthCount: 0,
            femalePct: 0,
            youthPct: 0,
            avgFarmSizeHa: 0,
            _totalHa: 0
          };
        }
        cohortMap[cTag].totalFarmers += 1;
        cohortMap[cTag]._totalHa += Number(f.totalHectares || 0);

        const isFem = f.gender?.toLowerCase() === 'female' || f.isFemale === true || (f.role || '').toLowerCase().includes('female');
        const isYth = f.isYouth === true || (f.age && Number(f.age) < 35) || (f.category || '').toLowerCase().includes('youth');
        if (isFem) {
          cohortMap[cTag].femaleCount += 1;
          femaleCount += 1;
        } else {
          cohortMap[cTag].maleCount += 1;
          maleCount += 1;
        }
        if (isYth) {
          cohortMap[cTag].youthCount += 1;
          youthCount += 1;
        }
      });

      tableRows = Object.values(cohortMap).map(c => ({
        ...c,
        femalePct: c.totalFarmers > 0 ? Math.round((c.femaleCount / c.totalFarmers) * 100) : 0,
        youthPct: c.totalFarmers > 0 ? Math.round((c.youthCount / c.totalFarmers) * 100) : 0,
        avgFarmSizeHa: c.totalFarmers > 0 ? Number((c._totalHa / c.totalFarmers).toFixed(1)) : 0
      }));

      const complianceRate = demographics.currentPercentage !== undefined ? demographics.currentPercentage : (totalFilteredFarmers > 0 ? 100 : 0);

      kpiMetrics = [
        { key: 'femaleSmallholders', label: 'Female Beneficiaries', value: femaleCount, formatted: femaleCount.toLocaleString() },
        { key: 'youthSmallholders', label: 'Youth Beneficiaries (<35)', value: youthCount, formatted: youthCount.toLocaleString() },
        { key: 'totalCohorts', label: 'Active Cohorts', value: tableRows.length, formatted: `${tableRows.length} Groups` },
        { key: 'complianceRate', label: 'Profile Compliance Rate', value: complianceRate, formatted: `${complianceRate}%`, target: 90, deltaPct: complianceRate - 90 },
      ];

      chartData = [
        { name: 'Female Smallholders', value: femaleCount, color: '#EC4899' },
        { name: 'Male Smallholders', value: maleCount, color: '#3B82F6' },
        { name: 'Youth Smallholders (<35)', value: youthCount, color: '#F59E0B' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No demographic cohort records found.'];
      } else {
        summaryCallouts = [
          `Female smallholders represent ${totalFilteredFarmers > 0 ? Math.round((femaleCount / totalFilteredFarmers) * 100) : 0}% of active program participants.`,
          `Youth participation stands at ${totalFilteredFarmers > 0 ? Math.round((youthCount / totalFilteredFarmers) * 100) : 0}%.`,
          `KYC profile compliance across recorded cohorts is verified at ${complianceRate}%.`
        ];
      }
      break;
    }

    // 3. Agronomic Yield Performance
    case 'agronomy-yield-performance': {
      const entries = Object.entries(cropYields);
      let totalHa = 0;
      let totalOutputKg = 0;
      let totalCycles = summary.totalActiveCropCycles || 0;

      tableRows = entries.map(([crop, data]: [string, any]) => {
        const ha = Number(data.totalHectares || data.hectares || 0);
        const kg = Number(data.totalYield || data.yieldKg || 0);
        const actualYield = ha > 0 ? Math.round(kg / ha) : 0;
        const targetYield = REGIONAL_TARGET_YIELDS[crop] || REGIONAL_TARGET_YIELDS.Other;
        const variance = targetYield > 0 ? Math.round(((actualYield - targetYield) / targetYield) * 100) : 0;
        const pricePerKg = Number(data.pricePerKg || (crop === 'Soybeans' ? 14 : crop === 'Maize' ? 6.5 : crop === 'Groundnuts' ? 18 : 20));

        totalHa += ha;
        totalOutputKg += kg;

        return {
          cropType: crop,
          cultivatedHa: Number(ha.toFixed(1)),
          farmerCount: Number(data.count || data.farmerCount || 0),
          totalHarvestKg: Math.round(kg),
          actualYieldPerHa: actualYield,
          benchmarkYieldPerHa: targetYield,
          variancePct: variance,
          estMarketValue: Math.round(kg * pricePerKg)
        };
      });

      const avgYield = totalHa > 0 ? Math.round(totalOutputKg / totalHa) : 0;

      kpiMetrics = [
        { key: 'totalCropCycles', label: 'Total Crop Cycles', value: totalCycles, formatted: totalCycles.toLocaleString() },
        { key: 'totalCultivatedHa', label: 'Total Land Cultivated', value: totalHa, formatted: `${Number(totalHa).toFixed(1)} Ha` },
        { key: 'totalHarvestKg', label: 'Total Harvest Output', value: totalOutputKg, formatted: `${(totalOutputKg / 1000).toFixed(1)} MT` },
        { key: 'avgYieldPerHa', label: 'Network Avg Yield', value: avgYield, formatted: `${avgYield.toLocaleString()} kg/ha` },
      ];

      chartData = tableRows.map(r => ({
        name: r.cropType,
        actual: r.actualYieldPerHa,
        target: r.benchmarkYieldPerHa,
        outputMT: Math.round(r.totalHarvestKg / 1000)
      }));

      chartKeys = [
        { dataKey: 'actual', name: 'Actual Yield (kg/ha)', color: '#10B981' },
        { dataKey: 'target', name: 'Regional Target (kg/ha)', color: '#94A3B8' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No crop harvest cycles recorded for this period.'];
      } else {
        summaryCallouts = [
          `Harvest aggregated ${(totalOutputKg / 1000).toFixed(1)} Metric Tonnes across ${totalHa.toFixed(1)} hectares.`,
          `Average yield per hectare reached ${avgYield.toLocaleString()} kg/ha.`
        ];
      }
      break;
    }

    // 4. Seasonal Crop Dynamics
    case 'agronomy-seasonal-dynamics': {
      tableRows = rawSeasons.map((s: any) => {
        const ha = Number(s.ha || s.hectares || 0);
        const kg = Number(s.kg || s.harvestedKg || 0);
        const inputCost = Number(s.inputCost || s.expenses || 0);
        const rev = Number(s.rev || s.revenue || 0);
        return {
          season: s.season || s.name || 'Season Cycle',
          cropType: s.crop || s.cropType || 'Crop',
          hectaresPlanted: ha,
          harvestedKg: kg,
          inputExpenditure: inputCost,
          revenueGenerated: rev,
          grossMarginPerHa: ha > 0 ? Math.round((rev - inputCost) / ha) : 0
        };
      });

      const totalWetHa = tableRows.filter(r => r.season.toLowerCase().includes('wet')).reduce((a, b) => a + b.hectaresPlanted, 0);
      const totalDryHa = tableRows.filter(r => r.season.toLowerCase().includes('dry') || r.season.toLowerCase().includes('irrigated')).reduce((a, b) => a + b.hectaresPlanted, 0);
      const totalAllHa = tableRows.reduce((a, b) => a + b.hectaresPlanted, 0);
      const totalInput = tableRows.reduce((a, b) => a + b.inputExpenditure, 0);
      const avgInputHa = totalAllHa > 0 ? Math.round(totalInput / totalAllHa) : 0;

      kpiMetrics = [
        { key: 'wetSeasonHa', label: 'Wet Season Area', value: totalWetHa, formatted: `${totalWetHa.toFixed(1)} Ha` },
        { key: 'drySeasonHa', label: 'Irrigated / Dry Area', value: totalDryHa, formatted: `${totalDryHa.toFixed(1)} Ha` },
        { key: 'inputCostPerHa', label: 'Avg Input Cost / Ha', value: avgInputHa, formatted: `${currencySymbol} ${avgInputHa.toLocaleString()}` },
        { key: 'cropDiversityScore', label: 'Crop Cycles Tracked', value: tableRows.length, formatted: `${tableRows.length} Cycles` },
      ];

      chartData = tableRows.map(r => ({
        name: r.season,
        inputCost: Math.round(r.inputExpenditure / 1000),
        revenue: Math.round(r.revenueGenerated / 1000),
        margin: Math.round((r.revenueGenerated - r.inputExpenditure) / 1000)
      }));

      chartKeys = [
        { dataKey: 'revenue', name: 'Revenue (k ZMW)', color: '#10B981' },
        { dataKey: 'inputCost', name: 'Inputs (k ZMW)', color: '#EF4444' },
        { dataKey: 'margin', name: 'Margin (k ZMW)', color: '#6366F1' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No seasonal crop dynamics records found.'];
      } else {
        summaryCallouts = [
          `Total seasonal crop cycles tracked across ${totalAllHa.toFixed(1)} hectares.`,
          `Average input cost is ${currencySymbol} ${avgInputHa.toLocaleString()} per hectare.`
        ];
      }
      break;
    }

    // 5. Livestock & Dairy Productivity
    case 'livestock-dairy-productivity': {
      const entries = Object.entries(livestockBySpecies.length !== undefined ? {} : livestockBySpecies);
      let totalHeads = Number(summary.totalLivestockRegistered || 0);
      let totalMilk = Number(summary.totalMilkVolumeLiters || 0);

      tableRows = entries.map(([sp, data]: [string, any]) => {
        const count = Number(data.count || data.headCount || 0);
        const milk = Number(data.milkLiters || 0);
        return {
          speciesName: sp,
          totalHeadCount: count,
          producersCount: Number(data.producersCount || Math.round(count * 0.2)),
          totalMilkOutputLiters: milk,
          avgYieldPerCow: count > 0 && milk > 0 ? Number((milk / count).toFixed(1)) : 0,
          estAssetValuation: Number(data.valuation || count * 4500),
          vaccinationRatePct: Number(data.vaccinationRate || 100)
        };
      });

      const avgMilk = totalHeads > 0 && totalMilk > 0 ? Number((totalMilk / totalHeads).toFixed(1)) : 0;

      kpiMetrics = [
        { key: 'totalLivestockHead', label: 'Total Livestock Head', value: totalHeads, formatted: totalHeads.toLocaleString() },
        { key: 'totalMilkVolumeL', label: 'Total Milk Output', value: totalMilk, formatted: `${totalMilk.toLocaleString()} L` },
        { key: 'avgMilkPerFarm', label: 'Avg Milk / Producer', value: avgMilk, formatted: `${avgMilk} L` },
        { key: 'herdHealthCompliance', label: 'Vaccination Rate', value: 100, formatted: '100%', target: 95, deltaPct: 5 },
      ];

      chartData = tableRows.map(r => ({
        name: r.speciesName,
        heads: r.totalHeadCount,
        valuation: Math.round(r.estAssetValuation / 1000)
      }));

      chartKeys = [
        { dataKey: 'heads', name: 'Head Count', color: '#6366F1' },
        { dataKey: 'valuation', name: 'Valuation (k ZMW)', color: '#10B981' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No livestock holdings recorded.'];
      } else {
        summaryCallouts = [
          `Livestock inventory records ${totalHeads.toLocaleString()} head across registered farms.`,
          `Total recorded milk production stands at ${totalMilk.toLocaleString()} Litres.`
        ];
      }
      break;
    }

    // 6. Poultry & Commercial Egg Report
    case 'poultry-commercial-performance': {
      const eggsCol = Number(summary.totalEggsCollected || 0);
      const eggsSold = Number(summary.totalEggsSold || 0);
      const batches = Number(summary.totalActivePoultryBatches || rawPoultryBatches.length || 0);
      const poultryRev = Number(summary.poultryRevenue || Math.round(eggsSold * 2.8));

      kpiMetrics = [
        { key: 'totalPoultryBatches', label: 'Active Poultry Batches', value: batches, formatted: `${batches} Batches` },
        { key: 'totalEggsCollected', label: 'Eggs Collected', value: eggsCol, formatted: eggsCol.toLocaleString() },
        { key: 'totalEggsSold', label: 'Eggs Sold (Commercial)', value: eggsSold, formatted: eggsSold.toLocaleString() },
        { key: 'poultryRevenueZMW', label: 'Poultry & Egg Revenue', value: poultryRev, formatted: `${currencySymbol} ${poultryRev.toLocaleString()}` },
      ];

      tableRows = rawPoultryBatches.map((c: any) => {
        const col = Number(c.eggsCol || c.eggsCollected || 0);
        const sold = Number(c.eggsSold || 0);
        const feed = Number(c.feedCost || 0);
        const rev = Number(c.rev || c.revenue || 0);
        return {
          cohortTag: c.cohort || c.batchName || 'Flock Batch',
          batchCount: Number(c.batches || 1),
          birdsCount: Number(c.birds || c.currentCount || 0),
          eggsCollected: col,
          eggsSold: sold,
          commercializationRate: col > 0 ? Math.round((sold / col) * 100) : 0,
          totalFeedCost: feed,
          totalSalesRevenue: rev,
          netPoultryMargin: rev - feed
        };
      });

      chartData = tableRows.map(r => ({
        name: r.cohortTag.split(' ')[0],
        revenue: r.totalSalesRevenue,
        feedCost: r.totalFeedCost,
        netMargin: r.netPoultryMargin
      }));

      chartKeys = [
        { dataKey: 'revenue', name: 'Revenue', color: '#10B981' },
        { dataKey: 'feedCost', name: 'Feed Costs', color: '#F43F5E' },
        { dataKey: 'netMargin', name: 'Net Margin', color: '#6366F1' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No active poultry batches logged for this period.'];
      } else {
        summaryCallouts = [
          `Total eggs collected stands at ${eggsCol.toLocaleString()} with ${eggsSold.toLocaleString()} sold commercially.`,
          `Recorded poultry revenue stands at ${currencySymbol} ${poultryRev.toLocaleString()}.`
        ];
      }
      break;
    }

    // 7. Credit Portfolio & PAR Report
    case 'credit-portfolio-par-report': {
      const totalDisbursed = Number(summary.totalLoansValue || 0);
      const totalOut = Number(summary.totalLoansOutstanding || 0);
      const repaid = Math.max(0, totalDisbursed - totalOut);
      const repRate = totalDisbursed > 0 ? Math.round((repaid / totalDisbursed) * 100) : 0;

      tableRows = rawLoanPortfolio.map((l: any) => {
        const princ = Number(l.principal || l.amount || 0);
        const out = Number(l.out || l.balance || 0);
        const repaidAmt = Math.max(0, princ - out);
        return {
          lenderPartner: l.lender || l.institution || 'Credit Facility',
          borrowerCount: Number(l.borrowers || l.borrowerCount || 1),
          totalPrincipal: princ,
          totalOutstanding: out,
          repaidAmount: repaidAmt,
          repaymentPct: princ > 0 ? Math.round((repaidAmt / princ) * 100) : 0,
          par30Amount: Number(l.p30 || l.par30 || 0),
          par60Amount: Number(l.p60 || l.par60 || 0),
          par90Amount: Number(l.p90 || l.par90 || 0)
        };
      });

      kpiMetrics = [
        { key: 'totalLoansDisbursed', label: 'Total Loans Disbursed', value: totalDisbursed, formatted: `${currencySymbol} ${totalDisbursed.toLocaleString()}` },
        { key: 'totalOutstandingExposure', label: 'Current Outstanding Portfolio', value: totalOut, formatted: `${currencySymbol} ${totalOut.toLocaleString()}` },
        { key: 'overallRepaymentRate', label: 'Repayment Rate', value: repRate, formatted: `${repRate}%`, target: 95, deltaPct: repRate - 95 },
        { key: 'par30Rate', label: 'PAR > 30 Days', value: 0, formatted: '0%', target: 5, deltaPct: 5 },
      ];

      chartData = tableRows.map(r => ({
        name: r.lenderPartner.split(' ')[0],
        repaid: r.repaidAmount,
        outstanding: r.totalOutstanding,
        par: r.par30Amount + r.par60Amount + r.par90Amount
      }));

      chartKeys = [
        { dataKey: 'repaid', name: 'Repaid Capital (ZMW)', color: '#10B981' },
        { dataKey: 'outstanding', name: 'Current Balance (ZMW)', color: '#3B82F6' },
        { dataKey: 'par', name: 'Portfolio at Risk (ZMW)', color: '#EF4444' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No active loan facilities logged for this period.'];
      } else {
        summaryCallouts = [
          `Cumulative credit disbursements recorded at ${currencySymbol} ${totalDisbursed.toLocaleString()}.`,
          `Current outstanding balance across lenders is ${currencySymbol} ${totalOut.toLocaleString()}.`
        ];
      }
      break;
    }

    // 8. Farm Capital Investments
    case 'farm-capital-investments-report': {
      const totalInv = Number(summary.totalInvestments || 0);

      tableRows = rawInvestments.map((it: any) => {
        const tot = Number(it.total || it.amount || 0);
        const fCount = Number(it.farms || it.farmCount || 1);
        return {
          investmentType: it.type || it.assetType || 'Capital Asset',
          farmCount: fCount,
          totalInvestedZMW: tot,
          pctOfTotalInvestments: totalInv > 0 ? Math.round((tot / totalInv) * 100) : 0,
          avgCostPerAsset: fCount > 0 ? Math.round(tot / fCount) : 0,
          primaryFundingSource: it.source || 'Equity / Loan'
        };
      });

      kpiMetrics = [
        { key: 'totalInvestmentsZMW', label: 'Total Capital Invested', value: totalInv, formatted: `${currencySymbol} ${totalInv.toLocaleString()}` },
        { key: 'investingFarmsCount', label: 'Farms Investing in Assets', value: tableRows.length, formatted: `${tableRows.length} Assets` },
        { key: 'avgInvestmentPerFarm', label: 'Avg Capital / Record', value: tableRows.length > 0 ? Math.round(totalInv / tableRows.length) : 0, formatted: `${currencySymbol} ${(tableRows.length > 0 ? Math.round(totalInv / tableRows.length) : 0).toLocaleString()}` },
        { key: 'topAssetCategory', label: 'Leading Asset Category', value: tableRows[0]?.investmentType || 'None', formatted: tableRows[0]?.investmentType || 'None' },
      ];

      chartData = tableRows.map(r => ({
        name: r.investmentType.split(' ')[0],
        value: r.totalInvestedZMW
      }));

      chartKeys = [{ dataKey: 'value', name: 'Invested (ZMW)', color: '#10B981' }];

      if (tableRows.length === 0) {
        summaryCallouts = ['No capital investment records logged for this period.'];
      } else {
        summaryCallouts = [
          `Total logged capital expenditure is ${currencySymbol} ${totalInv.toLocaleString()}.`
        ];
      }
      break;
    }

    // Consolidated Tenant Multi-Node Financial Report
    case 'consolidated-tenant-report': {
      let totalRev = 0;
      let totalExp = 0;
      let totalHa = 0;
      let totalAssets = 0;

      tableRows = filteredFarmers.map((f: any) => {
        const rev = Number(f.revenue || f.totalRevenue || 0);
        const exp = Number(f.expenses || f.totalExpenses || 0);
        const net = rev - exp;
        const margin = rev > 0 ? (net / rev) * 100 : 0;
        const ha = Number(f.totalHectares || f.hectares || f.farmSize || 10);
        const assets = (ha * 15000) + rev + 30000;

        totalRev += rev;
        totalExp += exp;
        totalHa += ha;
        totalAssets += assets;

        let band = 'B';
        if (margin >= 20) band = 'A';
        else if (margin >= 10) band = 'B';
        else if (margin >= 0) band = 'C';
        else band = 'D';

        return {
          farmName: f.name || f.farmName || 'Farm Node',
          ownerName: f.phone || f.ownerName || 'Farmer Operator',
          province: f.address || f.province || 'Southern Province',
          hectarage: ha,
          revenue: rev,
          expenses: exp,
          netIncome: net,
          netMarginPct: Number(margin.toFixed(1)),
          healthBand: band
        };
      });

      const totalNet = totalRev - totalExp;
      const netPct = totalRev > 0 ? (totalNet / totalRev) * 100 : 0;

      kpiMetrics = [
        { key: 'consolidatedGrossRevenue', label: 'Consolidated Gross Revenue', value: totalRev, formatted: `${currencySymbol} ${totalRev.toLocaleString()}` },
        { key: 'consolidatedNetOperatingIncome', label: 'Consolidated Net Income', value: totalNet, formatted: `${currencySymbol} ${totalNet.toLocaleString()}` },
        { key: 'consolidatedNetProfitMarginPct', label: 'Net Operating Margin', value: Number(netPct.toFixed(1)), formatted: `${netPct.toFixed(1)}%` },
        { key: 'consolidatedTotalAssets', label: 'Total Biological & Capital Assets', value: totalAssets, formatted: `${currencySymbol} ${totalAssets.toLocaleString()}` }
      ];

      chartData = tableRows.slice(0, 8).map(r => ({
        name: r.farmName.split(' ')[0],
        revenue: r.revenue,
        expenses: r.expenses,
        netIncome: r.netIncome
      }));

      chartKeys = [
        { dataKey: 'revenue', name: 'Revenue (ZMW)', color: '#10B981' },
        { dataKey: 'expenses', name: 'Expenses (ZMW)', color: '#EF4444' },
        { dataKey: 'netIncome', name: 'Net Income (ZMW)', color: '#3B82F6' }
      ];

      summaryCallouts = [
        `Portfolio-wide gross revenue across all farm nodes is ${currencySymbol} ${totalRev.toLocaleString()} with a net profit margin of ${netPct.toFixed(1)}%.`,
        `Aggregated balance sheet assets total ${currencySymbol} ${totalAssets.toLocaleString()} across ${totalHa} cultivated hectares.`
      ];
      break;
    }

    // 9. Market Offtaker & Commercial Report
    case 'market-offtaker-commercial-report': {
      const offtakeVal = Number(offtakerActivity.totalValue || summary.totalOfftakerRevenue || 0);
      const offtakeVol = Number(offtakerActivity.totalVolume || 0);

      tableRows = rawOfftakers.map((c: any) => {
        const val = Number(c.val || c.salesValue || 0);
        const vol = Number(c.vol || c.volumeKg || 0);
        return {
          buyerName: c.name || c.buyer || 'Offtaker Partner',
          commodity: c.commodity || c.crop || 'Agricultural Produce',
          totalVolumeDelivered: vol,
          totalSalesValue: val,
          contractComplianceRate: Number(c.comp || 100),
          avgPricePerUnit: vol > 0 ? Number((val / vol).toFixed(2)) : 0,
          paymentStatus: c.status || 'SETTLED'
        };
      });

      kpiMetrics = [
        { key: 'totalOfftakeValueZMW', label: 'Total Offtake Revenue', value: offtakeVal, formatted: `${currencySymbol} ${offtakeVal.toLocaleString()}` },
        { key: 'totalVolumeDeliveredMT', label: 'Total Volume Delivered', value: offtakeVol / 1000, formatted: `${(offtakeVol / 1000).toFixed(1)} MT` },
        { key: 'activeBuyerContracts', label: 'Offtaker Partners', value: tableRows.length, formatted: `${tableRows.length} Buyers` },
        { key: 'avgContractCompliance', label: 'Contract Fulfillment', value: 100, formatted: '100%', target: 95, deltaPct: 5 },
      ];

      chartData = tableRows.map(r => ({
        name: r.buyerName.split(' ')[0],
        salesValue: Math.round(r.totalSalesValue / 1000),
        volume: Math.round(r.totalVolumeDelivered / 1000)
      }));

      chartKeys = [
        { dataKey: 'salesValue', name: 'Sales Value (k ZMW)', color: '#10B981' },
        { dataKey: 'volume', name: 'Volume (MT)', color: '#3B82F6' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No commercial offtake contract deliveries recorded for this period.'];
      } else {
        summaryCallouts = [
          `Total offtake volume reached ${(offtakeVol / 1000).toFixed(1)} MT with gross sales of ${currencySymbol} ${offtakeVal.toLocaleString()}.`
        ];
      }
      break;
    }

    // 10. Labor & Social Impact
    case 'labor-employment-social-impact': {
      const totalWorkers = Number(summary.totalEmployeesRegistered || filteredFarmers.length || 0);
      const totalWage = Number(summary.totalPayrollExpenditure || 0);

      tableRows = filteredFarmers.map((f: any) => ({
        region: f.address || f.region || 'Registered Farm',
        totalSmallholderJobs: 1,
        permanentWorkers: 1,
        seasonalWorkers: 0,
        estMonthlyPayrollZMW: Number(f.revenue ? f.revenue * 0.2 : 0),
        youthWorkerPct: f.isYouth ? 100 : 0,
        femaleWorkerPct: f.isFemale ? 100 : 0
      }));

      kpiMetrics = [
        { key: 'totalAgriculturalJobs', label: 'Registered Farm Personnel', value: totalWorkers, formatted: totalWorkers.toLocaleString() },
        { key: 'totalPayrollDisbursed', label: 'Estimated Payroll Injected', value: totalWage, formatted: `${currencySymbol} ${totalWage.toLocaleString()}` },
        { key: 'femaleWorkerRatio', label: 'Female Labor Force', value: demographics.femalePercentage || 0, formatted: `${demographics.femalePercentage || 0}%`, target: 45, deltaPct: (demographics.femalePercentage || 0) - 45 },
        { key: 'youthEmploymentRatio', label: 'Youth Workforce (<35)', value: demographics.youthPercentage || 0, formatted: `${demographics.youthPercentage || 0}%`, target: 35, deltaPct: (demographics.youthPercentage || 0) - 35 },
      ];

      chartData = tableRows.map(r => ({
        name: r.region.split(' ')[0],
        jobs: r.totalSmallholderJobs,
        payroll: Math.round(r.estMonthlyPayrollZMW / 1000)
      }));

      chartKeys = [
        { dataKey: 'jobs', name: 'Personnel', color: '#6366F1' },
        { dataKey: 'payroll', name: 'Payroll (k ZMW)', color: '#10B981' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No farm personnel or labor records found.'];
      } else {
        summaryCallouts = [
          `Agricultural workforce metrics track ${totalWorkers.toLocaleString()} registered personnel.`
        ];
      }
      break;
    }

    // 11. Weather & DWR Resilience Audit
    case 'weather-dwr-resilience-audit': {
      tableRows = rawInsuranceClaims.map((z: any) => ({
        region: z.zone || z.region || 'Agro Zone',
        coveredHectares: Number(z.ha || 0),
        enrolledFarmers: Number(z.farmers || 0),
        totalPledgeZMW: Number(z.pledge || 0),
        rainfallTriggerStatus: z.rainStatus || 'Monitored',
        payoutStatus: z.payout || 'Active',
        disbursedAmountZMW: Number(z.dis || 0)
      }));

      const totalPledged = tableRows.reduce((a, b) => a + b.totalPledgeZMW, 0);
      const totalDisbursed = tableRows.reduce((a, b) => a + b.disbursedAmountZMW, 0);

      kpiMetrics = [
        { key: 'totalInsuredHectares', label: 'DWR Insured Hectares', value: tableRows.reduce((a, b) => a + b.coveredHectares, 0), formatted: `${tableRows.reduce((a, b) => a + b.coveredHectares, 0)} Ha` },
        { key: 'totalProtectedFarmers', label: 'Protected Smallholders', value: tableRows.reduce((a, b) => a + b.enrolledFarmers, 0), formatted: `${tableRows.reduce((a, b) => a + b.enrolledFarmers, 0)} Farmers` },
        { key: 'totalRiskPoolPledge', label: 'Risk Coverage Value', value: totalPledged, formatted: `${currencySymbol} ${totalPledged.toLocaleString()}` },
        { key: 'totalClaimsDisbursed', label: 'Index Payouts Disbursed', value: totalDisbursed, formatted: `${currencySymbol} ${totalDisbursed.toLocaleString()}` },
      ];

      chartData = tableRows.map(r => ({
        name: r.region.split(' ')[0],
        pledged: r.totalPledgeZMW,
        disbursed: r.disbursedAmountZMW
      }));

      chartKeys = [
        { dataKey: 'pledged', name: 'Total Pledged (ZMW)', color: '#3B82F6' },
        { dataKey: 'disbursed', name: 'Disbursed Indemnity (ZMW)', color: '#10B981' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No weather index insurance policies or claims registered for this period.'];
      } else {
        summaryCallouts = [
          `DWR protection active across ${tableRows.length} agro-zones with ${currencySymbol} ${totalDisbursed.toLocaleString()} disbursed.`
        ];
      }
      break;
    }

    // 12. Consignments & Agro-Dealers
    case 'consignments-agro-dealer-audit': {
      tableRows = (rawDealers.length > 0 ? rawDealers : linkedVendorsList).map((d: any) => {
        const val = Number(d.val || d.consignedValue || 0);
        const set = Number(d.set || d.settledValue || 0);
        return {
          dealerName: d.name || d.vendorName || 'Agro-Dealer Hub',
          region: d.region || d.address || 'Unspecified',
          activeOrders: Number(d.orders || d.activeOrders || 0),
          consignedValueZMW: val,
          settledValueZMW: set,
          clearanceRatePct: val > 0 ? Math.round((set / val) * 100) : 0,
          complianceStatus: d.status || 'Active Partner'
        };
      });

      const totalConsigned = tableRows.reduce((a, b) => a + b.consignedValueZMW, 0);
      const totalSettled = tableRows.reduce((a, b) => a + b.settledValueZMW, 0);

      kpiMetrics = [
        { key: 'linkedDealersCount', label: 'Linked Agro-Dealers', value: tableRows.length, formatted: `${tableRows.length} Stores` },
        { key: 'totalConsignedValueZMW', label: 'Total Consigned Inventory', value: totalConsigned, formatted: `${currencySymbol} ${totalConsigned.toLocaleString()}` },
        { key: 'clearedConsignmentsZMW', label: 'Cleared / Sold Inventory', value: totalSettled, formatted: `${currencySymbol} ${totalSettled.toLocaleString()}` },
        { key: 'avgDealerComplianceScore', label: 'Avg Clearance Rate', value: totalConsigned > 0 ? Math.round((totalSettled / totalConsigned) * 100) : 0, formatted: `${totalConsigned > 0 ? Math.round((totalSettled / totalConsigned) * 100) : 0}%` },
      ];

      chartData = tableRows.map(r => ({
        name: r.dealerName.split(' ')[0],
        consigned: r.consignedValueZMW,
        settled: r.settledValueZMW
      }));

      chartKeys = [
        { dataKey: 'consigned', name: 'Consigned (ZMW)', color: '#6366F1' },
        { dataKey: 'settled', name: 'Settled / Sold (ZMW)', color: '#10B981' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No consigned inventory or dealer store records found.'];
      } else {
        summaryCallouts = [
          `Consignment audit covers ${tableRows.length} agro-dealer partners with ${currencySymbol} ${totalSettled.toLocaleString()} settled.`
        ];
      }
      break;
    }

    // 13. Bulk SMS Outreach Report
    case 'sms-outreach-engagement-report': {
      tableRows = smsBatches.map((b: any, idx: number) => ({
        batchId: b.id || `BATCH-00${idx + 1}`,
        date: (b.timestamp || b.createdAt || new Date().toISOString()).slice(0, 10),
        templatePreview: (b.template || b.message_template || b.message || 'Advisory broadcast').slice(0, 48) + '...',
        recipientsCount: Number(b.total_recipients || b.recipientsCount || 0),
        partsCount: Number(b.total_parts || b.partsCount || 1),
        deliveryRate: Number(b.deliveryRate || 100),
        gatewayUsed: b.gateway || b.processed_gateway || 'Gateway',
        status: (b.status || 'SENT').toUpperCase()
      }));

      const totalDispatched = tableRows.length;
      const totalRecipients = tableRows.reduce((acc, b) => acc + (b.recipientsCount || 0), 0);
      const totalParts = tableRows.reduce((acc, b) => acc + (b.partsCount || 0), 0);

      kpiMetrics = [
        { key: 'totalBatchesDispatched', label: 'Campaign Batches Sent', value: totalDispatched, formatted: `${totalDispatched} Batches` },
        { key: 'totalMessagesDelivered', label: 'Messages Delivered', value: totalRecipients, formatted: totalRecipients.toLocaleString() },
        { key: 'overallDeliveryRate', label: 'Delivery Success Rate', value: totalDispatched > 0 ? 100 : 0, formatted: `${totalDispatched > 0 ? 100 : 0}%`, target: 98, deltaPct: 2 },
        { key: 'totalCreditsConsumed', label: 'SMS Credits Consumed', value: totalParts, formatted: `${totalParts} Credits` },
      ];

      chartData = tableRows.map(r => ({
        name: r.batchId,
        recipients: r.recipientsCount,
        parts: r.partsCount
      }));

      chartKeys = [
        { dataKey: 'recipients', name: 'Recipients Count', color: '#6366F1' },
        { dataKey: 'parts', name: 'SMS Parts Consumed', color: '#F59E0B' }
      ];

      if (tableRows.length === 0) {
        summaryCallouts = ['No bulk SMS outreach broadcasts recorded for this period.'];
      } else {
        summaryCallouts = [
          `Direct SMS broadcast channel dispatched ${totalDispatched} batches to ${totalRecipients.toLocaleString()} recipients.`
        ];
      }
      break;
    }

    default: {
      kpiMetrics = [];
      tableRows = [];
      chartData = [];
      summaryCallouts = ['Select an institutional report to view metrics and export documentation.'];
      break;
    }
  }

  return {
    definition: def,
    period: {
      label: filters.presetPeriod || 'Custom Range',
      from: filters.startDate || '2025-01-01',
      to: filters.endDate || new Date().toISOString().split('T')[0]
    },
    kpiMetrics,
    tableRows,
    chartData,
    chartKeys,
    summaryCallouts,
    totalRecordsCount: tableRows.length
  };
}

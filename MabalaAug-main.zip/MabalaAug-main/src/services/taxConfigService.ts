import { doc, getDoc, setDoc } from "firebase/firestore";
import { db } from "../firebase";
import { safeLocalStorage as localStorage } from "../utils/safeStorage";

export interface TaxAuditLogEntry {
  id: string;
  updatedAt: string;
  updatedBy: string;
  previousRateCardSummary: string;
  newRateCardSummary: string;
  notes?: string;
}

export interface StatutoryTaxConfig {
  vatRate: number;              // Standard VAT % (e.g. 16.0 for ZRA VAT)
  totRate: number;              // Turnover Tax % (e.g. 5.0 for small business)
  payeFlatRate: number;         // Statutory PAYE flat rate % (e.g. 10.0)
  payeThreshold: number;        // Tax-free PAYE threshold (e.g. ZMW 5100.00)
  salesTaxRate: number;         // Sales Tax % (e.g. 5.0)
  customTaxName: string;        // e.g. "Custom Statutory Tax"
  customTaxRate: number;        // e.g. 16.0
  activeTaxSystem: "VAT" | "TOT" | "CUSTOM" | "EXEMPT";
  napsaEmployeeRate?: number;     // NAPSA Pension Employee % (default 5.0)
  napsaEmployerRate?: number;     // NAPSA Pension Employer % (default 5.0)
  nhimaEmployeeRate?: number;     // NHIMA Health Scheme Employee % (default 1.0)
  nhimaEmployerRate?: number;     // NHIMA Health Scheme Employer % (default 1.0)
  wcfEmployerRate?: number;       // Workers Compensation Fund Employer % (default 1.0)
  skillsLevyEmployerRate?: number; // Skills Development Levy Employer % (default 0.5)
  countryIso2: string;          // Default jurisdiction ISO code (e.g. "ZM")
  jurisdictionRates: Record<string, { vatRate: number; totRate: number; payeFlatRate: number; salesTaxRate: number }>;
  updatedAt: string;
  updatedBy: string;
  previousValue?: string;
  auditTrail: TaxAuditLogEntry[];
}

export const DEFAULT_TAX_CONFIG: StatutoryTaxConfig = {
  vatRate: 16.0,
  totRate: 5.0,
  payeFlatRate: 10.0,
  payeThreshold: 5100,
  salesTaxRate: 5.0,
  customTaxName: "Custom Statutory Tax",
  customTaxRate: 16.0,
  activeTaxSystem: "VAT",
  napsaEmployeeRate: 5.0,
  napsaEmployerRate: 5.0,
  nhimaEmployeeRate: 1.0,
  nhimaEmployerRate: 1.0,
  wcfEmployerRate: 1.0,
  skillsLevyEmployerRate: 0.5,
  countryIso2: "ZM",
  jurisdictionRates: {
    ZM: { vatRate: 16.0, totRate: 5.0, payeFlatRate: 10.0, salesTaxRate: 5.0 },
    KE: { vatRate: 16.0, totRate: 3.0, payeFlatRate: 10.0, salesTaxRate: 5.0 },
    TZ: { vatRate: 18.0, totRate: 3.0, payeFlatRate: 10.0, salesTaxRate: 5.0 },
    UG: { vatRate: 18.0, totRate: 3.0, payeFlatRate: 10.0, salesTaxRate: 5.0 }
  },
  updatedAt: "2026-07-31T12:00:00.000Z",
  updatedBy: "superadmin@mabala.zm",
  previousValue: "Platform Initial Seed",
  auditTrail: [
    {
      id: "TAX-AUDIT-001",
      updatedAt: "2026-07-31T12:00:00.000Z",
      updatedBy: "superadmin@mabala.zm",
      previousRateCardSummary: "None (System Initialization)",
      newRateCardSummary: "VAT: 16.0%, TOT: 5.0%, PAYE: 10.0%, Sales Tax: 5.0%",
      notes: "Seeded initial single source of truth statutory tax rate document at superAdmin/platformConfig/tax."
    }
  ]
};

const LOCAL_STORAGE_KEY = "mabala_statutory_tax_config";

// In-memory cache
let currentTaxConfig: StatutoryTaxConfig = loadLocalConfig();
const subscribers: Set<(config: StatutoryTaxConfig) => void> = new Set();

function loadLocalConfig(): StatutoryTaxConfig {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_TAX_CONFIG,
        ...parsed,
        auditTrail: parsed.auditTrail || DEFAULT_TAX_CONFIG.auditTrail
      };
    }
  } catch (err) {
    console.warn("[taxConfigService] Local load error:", err);
  }
  return DEFAULT_TAX_CONFIG;
}

export function getStatutoryTaxConfig(): StatutoryTaxConfig {
  return currentTaxConfig;
}

export function subscribeTaxConfig(callback: (config: StatutoryTaxConfig) => void): () => void {
  subscribers.add(callback);
  callback(currentTaxConfig);
  return () => {
    subscribers.delete(callback);
  };
}

function notifySubscribers() {
  subscribers.forEach((cb) => cb(currentTaxConfig));
}

/**
 * Async initialization: fetches statutory tax config from Firestore superAdmin/platformConfig/tax
 * and updates local memory cache & subscribers.
 */
export async function fetchStatutoryTaxConfig(): Promise<StatutoryTaxConfig> {
  try {
    if (db) {
      const docRef = doc(db, "superAdmin", "platformConfig");
      const snap = await getDoc(docRef);
      if (snap.exists() && snap.data()?.taxSettings) {
        const remote = snap.data().taxSettings as StatutoryTaxConfig;
        currentTaxConfig = {
          ...DEFAULT_TAX_CONFIG,
          ...remote,
          auditTrail: remote.auditTrail || DEFAULT_TAX_CONFIG.auditTrail
        };
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(currentTaxConfig));
        notifySubscribers();
        return currentTaxConfig;
      }

      // Also try doc(db, "platformConfig", "tax") fallback
      const altRef = doc(db, "platformConfig", "tax");
      const altSnap = await getDoc(altRef);
      if (altSnap.exists()) {
        const remote = altSnap.data() as StatutoryTaxConfig;
        currentTaxConfig = {
          ...DEFAULT_TAX_CONFIG,
          ...remote,
          auditTrail: remote.auditTrail || DEFAULT_TAX_CONFIG.auditTrail
        };
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(currentTaxConfig));
        notifySubscribers();
        return currentTaxConfig;
      }
    }
  } catch (err) {
    console.warn("[taxConfigService] Firestore fetch error:", err);
  }
  return currentTaxConfig;
}

/**
 * Saves updated Statutory Tax configuration with mandatory Super Admin audit trail.
 */
export async function saveStatutoryTaxConfig(
  newConfig: Partial<StatutoryTaxConfig>,
  updatedBy: string = "superadmin@mabala.zm",
  notes: string = "Statutory tax rate card updated by Super Admin"
): Promise<StatutoryTaxConfig> {
  const previousSummary = `VAT: ${currentTaxConfig.vatRate}%, TOT: ${currentTaxConfig.totRate}%, PAYE: ${currentTaxConfig.payeFlatRate}%, Sales Tax: ${currentTaxConfig.salesTaxRate}%`;
  
  const merged: StatutoryTaxConfig = {
    ...currentTaxConfig,
    ...newConfig,
    updatedAt: new Date().toISOString(),
    updatedBy,
    previousValue: previousSummary
  };

  const newSummary = `VAT: ${merged.vatRate}%, TOT: ${merged.totRate}%, PAYE: ${merged.payeFlatRate}%, Sales Tax: ${merged.salesTaxRate}%`;

  const newAuditEntry: TaxAuditLogEntry = {
    id: "TAX-AUDIT-" + Date.now(),
    updatedAt: merged.updatedAt,
    updatedBy,
    previousRateCardSummary: previousSummary,
    newRateCardSummary: newSummary,
    notes
  };

  merged.auditTrail = [newAuditEntry, ...(currentTaxConfig.auditTrail || [])].slice(0, 50); // Keep last 50 entries

  currentTaxConfig = merged;
  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(merged));
  notifySubscribers();

  // Save to Firestore
  try {
    if (db) {
      // Primary location: superAdmin/platformConfig under taxSettings
      await setDoc(
        doc(db, "superAdmin", "platformConfig"),
        {
          taxSettings: merged
        },
        { merge: true }
      );

      // Secondary location: platformConfig/tax for root reads
      await setDoc(doc(db, "platformConfig", "tax"), merged, { merge: true });
    }
  } catch (err) {
    console.error("[taxConfigService] Firestore save error:", err);
  }

  return currentTaxConfig;
}

/**
 * PROSPECTIVE TAX RATE CALCULATOR & IMMUTABILITY HELPER
 * If historical document has an applied tax rate, use docRate (immutable financial record).
 * Otherwise, return the current statutory rate.
 */
export function getAppliedVatRate(docRate?: number): number {
  if (docRate !== undefined && docRate !== null && !isNaN(docRate)) {
    return docRate;
  }
  return currentTaxConfig.vatRate;
}

export function getAppliedTotRate(docRate?: number): number {
  if (docRate !== undefined && docRate !== null && !isNaN(docRate)) {
    return docRate;
  }
  return currentTaxConfig.totRate;
}

export function getAppliedPayeRate(docRate?: number): number {
  if (docRate !== undefined && docRate !== null && !isNaN(docRate)) {
    return docRate;
  }
  return currentTaxConfig.payeFlatRate;
}

export function getAppliedSalesTaxRate(docRate?: number): number {
  if (docRate !== undefined && docRate !== null && !isNaN(docRate)) {
    return docRate;
  }
  return currentTaxConfig.salesTaxRate;
}

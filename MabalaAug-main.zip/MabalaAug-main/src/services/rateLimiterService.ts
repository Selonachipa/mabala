/**
 * Server & Client Rate Limiter Service backed by Firestore for Mabala Platform
 * Prevents cost-drain abuse and brute-force attempts per tenant for critical operations like
 * initiateCardCollection and initiateBankDisbursement.
 */

import { db } from "../firebase";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";

export interface RateLimitResult {
  allowed: boolean;
  tenantId: string;
  actionType: string;
  currentCount: number;
  maxLimit: number;
  remaining: number;
  resetTimeMs: number;
  message?: string;
}

// Fallback in-memory rate limiter cache for offline or transient store
const inMemoryStore: Record<string, { count: number; windowStart: number }> = {};

/**
 * Checks and increments the rate limit counter for a specific tenant and action.
 * @param tenantId The tenant ID initiating the transaction
 * @param actionType Operation type, e.g., "card_collection" | "bank_disbursement"
 * @param maxLimit Maximum allowed attempts within window (default: 5 attempts)
 * @param windowSeconds Window duration in seconds (default: 60s)
 */
export async function checkRateLimit(
  tenantId: string,
  actionType: "card_collection" | "bank_disbursement" | string,
  maxLimit: number = 5,
  windowSeconds: number = 60
): Promise<RateLimitResult> {
  const safeTenant = tenantId || "TENANT-DEFAULT";
  const docKey = `${safeTenant}_${actionType}`;
  const now = Date.now();
  const windowMs = windowSeconds * 1000;

  // 1. Try Firestore backed rate limiting
  if (db && !(db as any)._dummy) {
    try {
      const docRef = doc(db, "rate_limits", docKey);
      const snap = await getDoc(docRef);

      let currentCount = 0;
      let windowStart = now;

      if (snap.exists()) {
        const data = snap.data();
        const storedStart = typeof data.windowStart === "number" ? data.windowStart : new Date(data.windowStart || now).getTime();

        if (now - storedStart < windowMs) {
          currentCount = data.count || 0;
          windowStart = storedStart;
        } else {
          // Window expired, reset
          currentCount = 0;
          windowStart = now;
        }
      }

      if (currentCount >= maxLimit) {
        const resetTimeMs = windowStart + windowMs - now;
        const resetSec = Math.ceil(resetTimeMs / 1000);
        return {
          allowed: false,
          tenantId: safeTenant,
          actionType,
          currentCount,
          maxLimit,
          remaining: 0,
          resetTimeMs,
          message: `Rate limit exceeded for tenant "${safeTenant}". Maximum ${maxLimit} ${actionType.replace("_", " ")} attempts allowed per ${windowSeconds}s. Please wait ${resetSec} seconds before retrying.`
        };
      }

      // Increment counter
      const newCount = currentCount + 1;
      await setDoc(
        docRef,
        {
          tenantId: safeTenant,
          actionType,
          count: newCount,
          windowStart,
          lastAttemptAt: new Date().toISOString(),
          updatedAt: serverTimestamp()
        },
        { merge: true }
      );

      return {
        allowed: true,
        tenantId: safeTenant,
        actionType,
        currentCount: newCount,
        maxLimit,
        remaining: maxLimit - newCount,
        resetTimeMs: windowStart + windowMs - now
      };
    } catch (err) {
      console.warn("[RateLimiter] Firestore rate limit check fallback to in-memory:", err);
    }
  }

  // 2. Fallback to in-memory rate limiting if Firestore unavailable
  const entry = inMemoryStore[docKey] || { count: 0, windowStart: now };

  if (now - entry.windowStart >= windowMs) {
    entry.count = 0;
    entry.windowStart = now;
  }

  if (entry.count >= maxLimit) {
    const resetTimeMs = entry.windowStart + windowMs - now;
    const resetSec = Math.ceil(resetTimeMs / 1000);
    return {
      allowed: false,
      tenantId: safeTenant,
      actionType,
      currentCount: entry.count,
      maxLimit,
      remaining: 0,
      resetTimeMs,
      message: `Rate limit exceeded for tenant "${safeTenant}". Maximum ${maxLimit} ${actionType.replace("_", " ")} attempts allowed per ${windowSeconds}s. Please wait ${resetSec} seconds.`
    };
  }

  entry.count += 1;
  inMemoryStore[docKey] = entry;

  return {
    allowed: true,
    tenantId: safeTenant,
    actionType,
    currentCount: entry.count,
    maxLimit,
    remaining: maxLimit - entry.count,
    resetTimeMs: entry.windowStart + windowMs - now
  };
}

/**
 * Enforces rate limiting by throwing an Error if the tenant exceeds maxLimit attempts.
 */
export async function enforceRateLimit(
  tenantId: string,
  actionType: "card_collection" | "bank_disbursement" | string,
  maxLimit: number = 5,
  windowSeconds: number = 60
): Promise<RateLimitResult> {
  const result = await checkRateLimit(tenantId, actionType, maxLimit, windowSeconds);
  if (!result.allowed) {
    throw new Error(result.message || `Rate limit exceeded for tenant ${tenantId}.`);
  }
  return result;
}

import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  orderBy, 
  limit, 
  serverTimestamp,
  doc,
  setDoc
} from "firebase/firestore";
import { db, auth } from "../firebase";
import { AuditLog } from "../types";
import { safeLocalStorage as localStorage, safeParseJSON } from "../utils/safeStorage";

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.warn("Firestore Audit Error:", JSON.stringify(errInfo));
}

export interface RecordAuditParams {
  tenantId: string;
  action: string;
  actorUid?: string;
  actorEmail?: string;
  actorName?: string;
  targetUid?: string;
  targetEmail?: string;
  targetName?: string;
  module?: string;
  record?: string;
  detail?: string;
  details?: Record<string, any>;
  accessLevel?: "read_write" | "read_only" | "admin" | string;
  status?: "active" | "suspended" | "pending" | string;
  ip?: string;
}

/**
 * Records a sub-user activity log entry into Firestore:
 * platform/institutions/institutions/{tenantId}/auditLogs
 */
export async function recordSubUserAuditLog(params: RecordAuditParams): Promise<string> {
  const tenantId = params.tenantId || "TENANT-001";
  const path = `platform/institutions/institutions/${tenantId}/auditLogs`;
  const isoNow = new Date().toISOString();

  const auditEntry = {
    action: params.action,
    actorUid: params.actorUid || auth.currentUser?.uid || "system-sub-user",
    actorEmail: params.actorEmail || auth.currentUser?.email || "subuser@farm.local",
    actorName: params.actorName || "Farm Sub-User",
    user: params.actorName || params.actorEmail || "Sub-User",
    targetUid: params.targetUid || "",
    targetEmail: params.targetEmail || "",
    targetName: params.targetName || "",
    module: params.module || "Access Control",
    record: params.record || params.action,
    detail: params.detail || `Activity executed: ${params.action}`,
    details: params.details || {},
    accessLevel: params.accessLevel || "read_write",
    status: params.status || "active",
    tenantId: tenantId,
    timestamp: isoNow,
    createdAt: isoNow,
    clientTimestamp: isoNow,
    ip: params.ip || "127.0.0.1"
  };

  try {
    if (db) {
      const colRef = collection(db, "platform", "institutions", "institutions", tenantId, "auditLogs");
      const docRef = await addDoc(colRef, {
        ...auditEntry,
        serverTimestamp: serverTimestamp()
      });
      return docRef.id;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    console.warn("[auditLogService] Falling back to REST API for audit log creation:", error);
  }

  // API Fallback
  try {
    let token = localStorage.getItem("mabala_id_token");
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    const res = await fetch(`/api/tenant/audit-logs`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        tenantId,
        ...auditEntry
      })
    });
    if (res.ok) {
      const data = await res.json();
      return data.id || `LOG-${Date.now()}`;
    }
  } catch (apiErr) {
    console.warn("[auditLogService] REST API log error:", apiErr);
  }

  // Local storage fallback
  const localKey = `mabala_audit_logs_${tenantId}`;
  try {
    const existing = JSON.parse(localStorage.getItem(localKey) || "[]");
    const newEntry = { id: `local-${Date.now()}`, ...auditEntry };
    existing.unshift(newEntry);
    localStorage.setItem(localKey, JSON.stringify(existing.slice(0, 200)));
    return newEntry.id;
  } catch (_) {
    return `log-${Date.now()}`;
  }
}

/**
 * Returns empty array - all dummy sample data removed per production clean state
 */
export function getSampleSubUserAuditLogs(_tenantId?: string, _farmName?: string): AuditLog[] {
  return [];
}

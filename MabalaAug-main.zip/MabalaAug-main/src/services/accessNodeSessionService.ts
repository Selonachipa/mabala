import { serverTimestamp } from "firebase/firestore";

export type AccessNodeListenerScope = "admin" | "impersonation";

export interface ImpersonationSession {
  adminUid: string;
  adminEmail: string;
  targetTenantId: string;
  targetUid: string;
  targetFarmNodeId: string;
  startedAt: string;
  sessionEpoch: string;
}

export interface ListenerSet {
  scope: AccessNodeListenerScope;
  sessionEpoch: string;
  unsubscribers: Array<() => void>;
}

export interface SessionProfile {
  uid?: string;
  id?: string;
  tenantId?: string;
  email?: string;
  [key: string]: any;
}

export function createSessionEpoch(prefix = "session"): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

export function createImpersonationSession(params: Omit<ImpersonationSession, "startedAt" | "sessionEpoch">): Readonly<ImpersonationSession> {
  return Object.freeze({
    ...params,
    startedAt: new Date().toISOString(),
    sessionEpoch: createSessionEpoch("impersonation")
  });
}

export function getSessionNamespace(uid: string, tenantId: string, sessionEpoch: string): string {
  return `${uid}__${tenantId}__${sessionEpoch}`;
}

export function isProfileIntegrityValid(profile: SessionProfile | null | undefined, expectedUid: string, expectedTenantId: string): boolean {
  if (!profile) return false;
  const actualUid = String(profile.uid || profile.id || profile.tenantUid || "");
  const actualTenantId = String(profile.tenantId || "");
  return actualUid === expectedUid && actualTenantId === expectedTenantId;
}

export class AccessNodeListenerRegistry {
  private sets = new Map<AccessNodeListenerScope, ListenerSet>();

  stop(scope: AccessNodeListenerScope): void {
    const listenerSet = this.sets.get(scope);
    listenerSet?.unsubscribers.splice(0).forEach(unsubscribe => {
      try { unsubscribe(); } catch (_) {}
    });
    this.sets.delete(scope);
  }

  stopAll(): void {
    this.stop("admin");
    this.stop("impersonation");
  }

  start(scope: AccessNodeListenerScope, sessionEpoch: string, unsubscribers: Array<() => void>): void {
    this.stop(scope);
    this.sets.set(scope, { scope, sessionEpoch, unsubscribers });
    this.assertSingleScope();
  }

  activeScope(): AccessNodeListenerScope | null {
    const scopes = Array.from(this.sets.keys());
    if (scopes.length > 1) {
      throw new Error(`Multiple identity listener scopes are active: ${scopes.join(", ")}`);
    }
    return scopes[0] || null;
  }

  count(scope: AccessNodeListenerScope): number {
    return this.sets.get(scope)?.unsubscribers.length || 0;
  }

  private assertSingleScope(): void {
    if (import.meta.env?.MODE !== "production") this.activeScope();
  }
}

export const accessNodeListenerRegistry = new AccessNodeListenerRegistry();

export { serverTimestamp };
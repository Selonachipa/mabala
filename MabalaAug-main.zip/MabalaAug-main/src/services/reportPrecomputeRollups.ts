import { db } from '../firebase';
import { collection, doc, setDoc, getDocs, query, where } from 'firebase/firestore';

export interface DailyStockRollupDoc {
  skuId: string;
  skuName: string;
  category: string;
  date: string; // YYYY-MM-DD
  openingQty: number;
  received: number;
  sold: number;
  adjusted: number;
  closingQty: number;
  unitCost: number;
  closingValue: number;
  updatedAt: string;
}

export interface DailySalesRollupDoc {
  category: string;
  date: string; // YYYY-MM-DD
  revenue: number;
  qtySold: number;
  transactionCount: number;
  updatedAt: string;
}

/**
 * Precomputes daily stock and sales rollups for a tenant for a given date.
 */
export async function precomputeDailyRollupForTenant(
  tenantId: string,
  targetDateStr: string = new Date().toISOString().split('T')[0],
  contextData?: { movements?: any[]; sales?: any[]; inventory?: any[] }
): Promise<{ stockRollupsCount: number; salesRollupsCount: number }> {
  const stockRollups: Record<string, DailyStockRollupDoc> = {};
  const salesRollups: Record<string, DailySalesRollupDoc> = {};

  const inventory = contextData?.inventory || [];
  const movements = contextData?.movements || [];
  const sales = contextData?.sales || [];

  // 1. Compute Daily Stock Rollups per SKU
  inventory.forEach((inv: any) => {
    const skuId = inv.id || inv.skuName || inv.name;
    const qty = Number(inv.qtyOnHand || inv.quantity || 0);
    const unitCost = Number(inv.unitCost || 0);

    stockRollups[skuId] = {
      skuId,
      skuName: inv.skuName || inv.name,
      category: inv.category || 'General',
      date: targetDateStr,
      openingQty: qty,
      received: 0,
      sold: 0,
      adjusted: 0,
      closingQty: qty,
      unitCost,
      closingValue: qty * unitCost,
      updatedAt: new Date().toISOString()
    };
  });

  movements.forEach((m: any) => {
    const mDate = m.date ? m.date.split('T')[0] : '';
    if (mDate === targetDateStr) {
      const skuId = m.skuId || m.skuName;
      if (stockRollups[skuId]) {
        const qty = Number(m.qty || m.quantity || 0);
        const mType = (m.movementType || m.type || '').toLowerCase();
        if (mType.includes('grant') || mType.includes('in')) {
          stockRollups[skuId].received += qty;
        } else if (mType.includes('sale') || mType.includes('out')) {
          stockRollups[skuId].sold += qty;
        } else {
          stockRollups[skuId].adjusted += qty;
        }

        const netChange = stockRollups[skuId].received - stockRollups[skuId].sold + stockRollups[skuId].adjusted;
        stockRollups[skuId].closingQty = Math.max(0, stockRollups[skuId].openingQty + netChange);
        stockRollups[skuId].closingValue = stockRollups[skuId].closingQty * stockRollups[skuId].unitCost;
      }
    }
  });

  // 2. Compute Daily Sales Rollups per Category
  sales.forEach((s: any) => {
    const sDate = s.date ? s.date.split('T')[0] : '';
    if (sDate === targetDateStr) {
      const category = s.category || 'Inputs';
      if (!salesRollups[category]) {
        salesRollups[category] = {
          category,
          date: targetDateStr,
          revenue: 0,
          qtySold: 0,
          transactionCount: 0,
          updatedAt: new Date().toISOString()
        };
      }
      salesRollups[category].revenue += Number(s.revenue || s.amount || 0);
      salesRollups[category].qtySold += Number(s.qty || s.quantity || 1);
      salesRollups[category].transactionCount += 1;
    }
  });

  // Write to Firestore if connected
  try {
    const stockBatch = Object.values(stockRollups);
    for (const item of stockBatch) {
      const docRef = doc(db, 'dailyStockRollups', tenantId, targetDateStr, item.skuId);
      await setDoc(docRef, item, { merge: true });
    }

    const salesBatch = Object.values(salesRollups);
    for (const item of salesBatch) {
      const docRef = doc(db, 'dailySalesRollups', tenantId, targetDateStr, item.category);
      await setDoc(docRef, item, { merge: true });
    }
  } catch (err) {
    console.warn('Daily rollups fallback execution (offline or local storage mode):', err);
  }

  return {
    stockRollupsCount: Object.keys(stockRollups).length,
    salesRollupsCount: Object.keys(salesRollups).length
  };
}

import { db } from "../firebase";
import { doc, setDoc, getDoc, collection, getDocs, updateDoc } from "firebase/firestore";
import { safeLocalStorage as localStorage } from "../utils/safeStorage";

export interface PayoutEmployeeLine {
  employeeId: string;
  employeeName: string;
  netPay: number;
  mobileMoneyNumber: string;
  mobileMoneyProvider: string;
  hrRecordPhone?: string;
  status: "pending" | "paid" | "failed";
  disbursedAt?: string;
  transactionRef?: string;
}

export interface PayoutRequest {
  id: string;
  tenantId: string;
  farmName: string;
  requestedBy: string;
  type: "FARM_USER_WITHDRAWAL" | "PAYROLL_DISBURSEMENT";
  categoryLabel: string;
  amount: number;
  platformFee?: number;
  grandTotal: number;
  
  // Destination Details for Farm User Withdrawal
  destinationType?: "MOBILE_MONEY" | "BANK_ACCOUNT";
  mobileMoneyDetails?: {
    provider: string;
    mobileNumber: string;
    accountName: string;
  };
  bankDetails?: {
    bankName: string;
    accountNumber: string;
    accountName: string;
    branchName?: string;
    branchCode?: string;
    swiftCode?: string;
  };

  // Payroll specific fields
  payrollPeriod?: string;
  payrollRunId?: string;
  employees?: PayoutEmployeeLine[];

  // Processing Status
  status: "PENDING" | "PAID" | "REJECTED";
  requestedAt: string;
  processedAt?: string;
  processedBy?: string;
  paymentReference?: string;
  payoutMethodUsed?: string;
  adminNotes?: string;
}

const STORAGE_KEY_PAYOUT_REQUESTS = "mabala_payout_requests_master";

// Get all payout requests
export function getPayoutRequests(): PayoutRequest[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PAYOUT_REQUESTS);
    if (raw) {
      const list = JSON.parse(raw);
      if (Array.isArray(list)) {
        return list.sort((a, b) => new Date(b.requestedAt).getTime() - new Date(a.requestedAt).getTime());
      }
    }
  } catch (e) {
    console.warn("[PayoutService] Error reading payout requests:", e);
  }
  return [];
}

// Get pending payouts summary
export function getPayoutMetrics() {
  const all = getPayoutRequests();
  const pendingRequests = all.filter(r => r.status === "PENDING");
  const paidRequests = all.filter(r => r.status === "PAID");

  const pendingAmount = pendingRequests.reduce((sum, r) => sum + (Number(r.amount) || Number(r.grandTotal) || 0), 0);
  const paidAmount = paidRequests.reduce((sum, r) => sum + (Number(r.amount) || Number(r.grandTotal) || 0), 0);

  return {
    totalRequests: all.length,
    pendingCount: pendingRequests.length,
    paidCount: paidRequests.length,
    pendingAmount: Number(pendingAmount.toFixed(2)),
    paidAmount: Number(paidAmount.toFixed(2))
  };
}

// Subscribe to Payout Request updates
export function subscribePayoutRequests(
  callback: (requests: PayoutRequest[]) => void
): () => void {
  const handler = () => {
    callback(getPayoutRequests());
  };

  window.addEventListener("mabala_payout_requests_update", handler);
  window.addEventListener("storage", handler);

  // Initial call
  handler();

  return () => {
    window.removeEventListener("mabala_payout_requests_update", handler);
    window.removeEventListener("storage", handler);
  };
}

// Create Farm User Payout Request (Withdrawal)
export async function createFarmUserPayoutRequest(params: {
  tenantId: string;
  farmName: string;
  requestedBy: string;
  amount: number;
  destinationType: "MOBILE_MONEY" | "BANK_ACCOUNT";
  mobileMoneyDetails?: {
    provider: string;
    mobileNumber: string;
    accountName: string;
  };
  bankDetails?: {
    bankName: string;
    accountNumber: string;
    accountName: string;
    branchName?: string;
    branchCode?: string;
    swiftCode?: string;
  };
  notes?: string;
}): Promise<PayoutRequest> {
  const id = `PAYOUT-REQ-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const request: PayoutRequest = {
    id,
    tenantId: params.tenantId,
    farmName: params.farmName,
    requestedBy: params.requestedBy,
    type: "FARM_USER_WITHDRAWAL",
    categoryLabel: `Farm Wallet Payout (${params.destinationType === "MOBILE_MONEY" ? "Mobile Money" : "Bank Transfer"})`,
    amount: Number(params.amount.toFixed(2)),
    grandTotal: Number(params.amount.toFixed(2)),
    destinationType: params.destinationType,
    mobileMoneyDetails: params.mobileMoneyDetails,
    bankDetails: params.bankDetails,
    status: "PENDING",
    requestedAt: new Date().toISOString(),
    adminNotes: params.notes || ""
  };

  await savePayoutRequest(request);
  return request;
}

// Create Payroll Payout Request
export async function createPayrollPayoutRequest(params: {
  tenantId: string;
  farmName: string;
  requestedBy: string;
  payrollPeriod: string;
  payrollRunId: string;
  totalNetPay: number;
  platformFee: number;
  grandTotal: number;
  employees: PayoutEmployeeLine[];
  notes?: string;
}): Promise<PayoutRequest> {
  const id = `PAYROLL-PAYOUT-${params.payrollRunId || Date.now()}`;
  const request: PayoutRequest = {
    id,
    tenantId: params.tenantId,
    farmName: params.farmName,
    requestedBy: params.requestedBy,
    type: "PAYROLL_DISBURSEMENT",
    categoryLabel: `Staff Payroll Disbursement (${params.payrollPeriod})`,
    amount: Number(params.totalNetPay.toFixed(2)),
    platformFee: Number(params.platformFee.toFixed(2)),
    grandTotal: Number(params.grandTotal.toFixed(2)),
    payrollPeriod: params.payrollPeriod,
    payrollRunId: params.payrollRunId,
    employees: params.employees,
    status: "PENDING",
    requestedAt: new Date().toISOString(),
    adminNotes: params.notes || `Payroll batch disbursement request for ${params.employees.length} employees.`
  };

  await savePayoutRequest(request);
  return request;
}

// Mark a Payout Request as Paid & Processed
export async function markPayoutRequestAsPaid(params: {
  payoutId: string;
  processedBy: string;
  paymentReference?: string;
  payoutMethodUsed?: string;
  adminNotes?: string;
}): Promise<{ success: boolean; request: PayoutRequest }> {
  const all = getPayoutRequests();
  const index = all.findIndex(r => r.id === params.payoutId);
  if (index === -1) {
    throw new Error(`Payout request ${params.payoutId} not found.`);
  }

  const existing = all[index];
  const updatedEmployees = existing.employees?.map(emp => ({
    ...emp,
    status: "paid" as const,
    disbursedAt: new Date().toISOString(),
    transactionRef: params.paymentReference || `DISB-${Date.now()}`
  }));

  const updated: PayoutRequest = {
    ...existing,
    status: "PAID",
    processedAt: new Date().toISOString(),
    processedBy: params.processedBy || "support@mabala.cloud",
    paymentReference: params.paymentReference || `MANUAL-PAYOUT-${Date.now()}`,
    payoutMethodUsed: params.payoutMethodUsed || "Manual Mobile Money / Bank Disbursement",
    adminNotes: params.adminNotes || existing.adminNotes,
    employees: updatedEmployees || existing.employees
  };

  all[index] = updated;
  localStorage.setItem(STORAGE_KEY_PAYOUT_REQUESTS, JSON.stringify(all));

  // Sync to Firestore
  if (db) {
    try {
      await setDoc(doc(db, "payout_requests", updated.id), updated, { merge: true });
    } catch (e) {
      console.warn("[PayoutService] Firestore update note:", e);
    }
  }

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("mabala_payout_requests_update", { detail: { request: updated } }));
    window.dispatchEvent(new Event("storage"));
  }

  return { success: true, request: updated };
}

// Internal helper to save request
async function savePayoutRequest(request: PayoutRequest) {
  const existing = getPayoutRequests();
  const updated = [request, ...existing.filter(r => r.id !== request.id)];
  localStorage.setItem(STORAGE_KEY_PAYOUT_REQUESTS, JSON.stringify(updated));

  if (db) {
    try {
      await setDoc(doc(db, "payout_requests", request.id), request);
    } catch (e) {
      console.warn("[PayoutService] Firestore save note:", e);
    }
  }

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("mabala_payout_requests_update", { detail: { request } }));
    window.dispatchEvent(new Event("storage"));
  }
}

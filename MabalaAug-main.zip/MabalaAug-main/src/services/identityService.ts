import { TenantTypeCode, resolveCanonicalTenantType } from "./moduleEntitlementEngine";


export interface UserIdentityMetadata {
 role?: string;
 tenantType?: TenantTypeCode;
 name?: string;
 phone?: string;
 isPreProvisioned: boolean;
 source?: "registered_roles_map" | "pending_first_login_users" | "dealers" | "suppliers" | "user_profile";
}


function sanitizeIdentity(userEmail: string, data: UserIdentityMetadata): UserIdentityMetadata {
  if (userEmail !== "support@mabala.cloud") {
    const rLower = (data.role || "").toLowerCase();
    if (
      rLower === "super admin" ||
      rLower === "super_admin" ||
      rLower === "platform administrator" ||
      rLower === "platform_admin" ||
      data.tenantType === "super_admin"
    ) {
      return {
        ...data,
        role: "Farm Owner",
        tenantType: "farmer"
      };
    }
  }
  return data;
}

/**
* Unified helper function to fetch pre-provisioned user metadata from local storage and caches.
* Consolidates lookups from mabala_registered_roles_map, mabala_pending_first_login_users,
* dealer/supplier registries, and user profile caches.
*/
function getRawUserIdentityMetadata(email?: string): UserIdentityMetadata {
 const userEmail = (email || "").trim().toLowerCase();
 if (!userEmail || typeof window === "undefined") {
   return { isPreProvisioned: false };
 }

 // Explicit override: support@mabala.cloud is the ONLY Super Admin on the platform
 if (userEmail === "support@mabala.cloud") {
   return {
     role: "Super Admin",
     tenantType: "super_admin",
     name: "Mabala Super Admin",
     phone: "+260 978 070734",
     isPreProvisioned: true,
     source: "registered_roles_map"
   };
 }

 // Explicit override: deepvaleyfarm@gmail.com is a standard Farm Owner node
 if (userEmail === "deepvaleyfarm@gmail.com" || userEmail === "deepvalleyfarm@gmail.com") {
   return {
     role: "Farm Owner",
     tenantType: "farmer",
     name: "Deep Valley Farms",
     phone: "+260978070734",
     isPreProvisioned: true,
     source: "registered_roles_map"
   };
 }


 try {
   // 1. Check registered roles map (mabala_registered_roles_map)
   const storedMapStr = localStorage.getItem("mabala_registered_roles_map");
   if (storedMapStr) {
     const storedMap = JSON.parse(storedMapStr);
     const entry = storedMap[userEmail];
     if (entry) {
       if (typeof entry === "string") {
         const canonical = resolveCanonicalTenantType(entry, userEmail);
         return {
           role: entry,
           tenantType: canonical,
           isPreProvisioned: true,
           source: "registered_roles_map"
         };
       } else if (typeof entry === "object" && entry !== null) {
         const rawRole = entry.role || entry.tenantType || "";
         const canonical = (entry.tenantType as TenantTypeCode) || resolveCanonicalTenantType(rawRole, userEmail);
         return {
           role: rawRole || (canonical === "agro_dealer" ? "Agro Dealer" : canonical === "institution_supplier" ? "Institutional Supplier" : canonical === "offtaker" ? "Offtaker" : canonical === "mabala_partner" ? "Platform Partner" : "Farm Owner"),
           tenantType: canonical,
           name: entry.name,
           phone: entry.phone,
           isPreProvisioned: true,
           source: "registered_roles_map"
         };
       }
     }
   }


   // 2. Check pending first login users (mabala_pending_first_login_users)
   const pendingStr = localStorage.getItem("mabala_pending_first_login_users");
   if (pendingStr) {
     const pendingUsers = JSON.parse(pendingStr);
     if (Array.isArray(pendingUsers)) {
       const match = pendingUsers.find((u: any) => u.email && u.email.toLowerCase() === userEmail);
       if (match) {
         const rawRole = match.role || match.tenantType || "";
         const canonical = (match.tenantType as TenantTypeCode) || resolveCanonicalTenantType(rawRole, userEmail);
         return {
           role: rawRole || (canonical === "agro_dealer" ? "Agro Dealer" : canonical === "institution_supplier" ? "Institutional Supplier" : canonical === "offtaker" ? "Offtaker" : canonical === "mabala_partner" ? "Platform Partner" : "Farm Owner"),
           tenantType: canonical,
           name: match.name,
           phone: match.phone,
           isPreProvisioned: true,
           source: "pending_first_login_users"
         };
       }
     }
   }


   // 3. Check dealers list (mabala_agd_dealers)
   const dealersStr = localStorage.getItem("mabala_agd_dealers");
   if (dealersStr) {
     const dealers = JSON.parse(dealersStr);
     if (Array.isArray(dealers)) {
       const match = dealers.find((d: any) => (d.ownerEmail && d.ownerEmail.toLowerCase() === userEmail) || (d.email && d.email.toLowerCase() === userEmail));
       if (match) {
         return {
           role: "Agro Dealer",
           tenantType: "agro_dealer",
           name: match.businessName || match.name || match.ownerName,
           phone: match.phone || match.contactPhone,
           isPreProvisioned: true,
           source: "dealers"
         };
       }
     }
   }


   // 4. Check suppliers list (mabala_agd_suppliers)
   const suppliersStr = localStorage.getItem("mabala_agd_suppliers");
   if (suppliersStr) {
     const suppliers = JSON.parse(suppliersStr);
     if (Array.isArray(suppliers)) {
       const match = suppliers.find((s: any) => (s.ownerEmail && s.ownerEmail.toLowerCase() === userEmail) || (s.email && s.email.toLowerCase() === userEmail));
       if (match) {
         return {
           role: "Institutional Supplier",
           tenantType: "institution_supplier",
           name: match.companyName || match.name || match.ownerName,
           phone: match.phone || match.contactPhone,
           isPreProvisioned: true,
           source: "suppliers"
         };
       }
     }
   }


   // 4b. Check offtakers list (mabala_offtakers)
   const offtakersStr = localStorage.getItem("mabala_offtakers");
   if (offtakersStr) {
     const offtakers = JSON.parse(offtakersStr);
     if (Array.isArray(offtakers)) {
       const match = offtakers.find((o: any) => (o.email && o.email.toLowerCase() === userEmail) || (o.offtaker_profile?.email && o.offtaker_profile.email.toLowerCase() === userEmail) || (o.contactEmail && o.contactEmail.toLowerCase() === userEmail));
       if (match) {
         return {
           role: "Offtaker",
           tenantType: "offtaker",
           name: match.legalName || match.name || match.offtaker_profile?.legalName,
           phone: match.contactPhone || match.phone,
           isPreProvisioned: true,
           source: "registered_roles_map"
         };
       }
     }
   }


   // 5. Check user profile (mabala_user_profile)
   const profileStr = localStorage.getItem("mabala_user_profile");
   if (profileStr) {
     const p = JSON.parse(profileStr);
     if (p.email && p.email.toLowerCase() === userEmail) {
       const rawRole = p.role || p.tenantType || "";
       const canonical = (p.tenantType as TenantTypeCode) || resolveCanonicalTenantType(rawRole, userEmail);
       return {
         role: rawRole,
         tenantType: canonical,
         name: p.name,
         phone: p.phone,
         isPreProvisioned: true,
         source: "user_profile"
       };
     }
   }
 } catch (e) {
   console.warn("[UserIdentityMetadata] Error retrieving pre-provisioned user metadata:", e);
 }


 return { isPreProvisioned: false };
}

export function getUserIdentityMetadata(email?: string): UserIdentityMetadata {
  const normEmail = (email || "").trim().toLowerCase();
  const raw = getRawUserIdentityMetadata(email);
  return sanitizeIdentity(normEmail, raw);
}




import { User } from "firebase/auth";
import { auth } from "../firebase";
import { recordSubUserAuditLog } from "./auditLogService";
import { purgeAllOfflineDatabases, setOfflineDbScope } from "../db/offline_db";
import { koboCollectSyncService } from "./koboCollectSyncService";
import { FarmPersistenceService, setPersistenceScope } from "./farmPersistenceService";

export const SUPER_ADMIN_EMAILS = [
  "support@mabala.cloud",
  "shikasuli@gmail.com"
];

export interface ProfileValidationResult {
  valid: boolean;
  profile: any | null;
  reason?: string;
  isSuperAdminEscalationAttempt?: boolean;
}

export class IdentityIntegrityService {
  /**
   * Validates that a cached profile strictly matches the currently authenticated Firebase user.
   * If any mismatch (UID, email, or unearned Super Admin elevation) is found, returns valid: false.
   */
  public static validateCachedProfile(
    cachedProfile: any,
    authUser: { uid?: string | null; email?: string | null } | null
  ): ProfileValidationResult {
    if (!authUser || !authUser.email) {
      return { valid: false, profile: null, reason: "No authenticated user session" };
    }

    if (!cachedProfile || typeof cachedProfile !== "object") {
      return { valid: false, profile: null, reason: "No cached profile data" };
    }

    const authEmail = (authUser.email || "").trim().toLowerCase();
    const cachedEmail = (cachedProfile.email || "").trim().toLowerCase();

    // 1. Email integrity check
    if (cachedEmail && cachedEmail !== authEmail) {
      return {
        valid: false,
        profile: null,
        reason: `Profile email mismatch: cached='${cachedEmail}', auth='${authEmail}'`
      };
    }

    // 2. UID integrity check
    const authUid = (authUser.uid || "").trim();
    const cachedUid = (cachedProfile.uid || cachedProfile.id || cachedProfile._ownerUid || "").trim();
    if (authUid && cachedUid && authUid !== cachedUid) {
      return {
        valid: false,
        profile: null,
        reason: `Profile UID mismatch: cached='${cachedUid}', auth='${authUid}'`
      };
    }

    // 3. Super Admin role escalation check
    const role = String(cachedProfile.role || "").trim().toLowerCase();
    const tenantType = String(cachedProfile.tenantType || "").trim().toLowerCase();
    const isSuperAdminClaimed =
      role === "super admin" ||
      role === "super_admin" ||
      role === "platform administrator" ||
      role === "platform_admin" ||
      tenantType === "super_admin";

    if (isSuperAdminClaimed && !SUPER_ADMIN_EMAILS.includes(authEmail)) {
      return {
        valid: false,
        profile: null,
        reason: `Cross-session Super Admin leak prevented: '${authEmail}' attempted with cached role '${cachedProfile.role}'`,
        isSuperAdminEscalationAttempt: true
      };
    }

    return {
      valid: true,
      profile: cachedProfile
    };
  }

  /**
   * Records an audit log in production when a cached profile mismatch or potential leak is intercepted.
   */
  public static async reportIdentityMismatchAudit(params: {
    authUid?: string;
    authEmail?: string;
    cachedUid?: string;
    cachedEmail?: string;
    leakedRole?: string;
    reason?: string;
    context?: string;
  }): Promise<void> {
    console.error(
      "[IdentityIntegrity] PREVENTED CROSS-SESSION PROFILE LEAK! Cached profile mismatch detected:",
      params
    );

    try {
      await recordSubUserAuditLog({
        tenantId: params.authEmail || params.cachedEmail || "MABALA_PLATFORM_SECURITY",
        action: "IDENTITY_LEAK_PREVENTED",
        actorUid: params.authUid || "client_integrity_guard",
        actorEmail: params.authEmail || "security@mabala.cloud",
        actorName: "Mabala Client Integrity Guard",
        module: "Security & Auth",
        record: "Client Storage Profile Validation",
        detail: `Prevented local cache profile leak: ${params.reason || "Mismatched session profile discarded"}`,
        details: {
          authEmail: params.authEmail,
          authUid: params.authUid,
          cachedEmail: params.cachedEmail,
          cachedUid: params.cachedUid,
          leakedRole: params.leakedRole,
          context: params.context || "session_hydration",
          clientTimestamp: new Date().toISOString()
        },
        accessLevel: "admin",
        status: "active"
      });
    } catch (auditErr) {
      console.warn("[IdentityIntegrity] Audit logging failed (falling back):", auditErr);
    }
  }

  /**
   * Reads and verifies the user profile from local storage.
   * If invalid, stale, or mismatched, discards it immediately, purges corrupted keys, and returns null.
   */
  public static getVerifiedCachedProfile(authUser: { uid?: string | null; email?: string | null } | null): any | null {
    if (!authUser || !authUser.email) {
      return null;
    }

    const cleanUid = (authUser.uid || "").trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
    const scopedKey = `mabala_user_profile_${cleanUid}`;

    // 1. Try reading scoped profile first
    let raw = localStorage.getItem(scopedKey);
    // 2. Fall back to generic key if scoped is not found
    if (!raw) {
      raw = localStorage.getItem("mabala_user_profile");
    }

    if (!raw) return null;

    try {
      const parsed = JSON.parse(raw);
      const validation = this.validateCachedProfile(parsed, authUser);

      if (!validation.valid) {
        // Discard immediately!
        this.reportIdentityMismatchAudit({
          authUid: authUser.uid || undefined,
          authEmail: authUser.email || undefined,
          cachedUid: parsed.uid || parsed._ownerUid,
          cachedEmail: parsed.email,
          leakedRole: parsed.role,
          reason: validation.reason,
          context: "getVerifiedCachedProfile"
        }).catch(() => {});

        this.purgeStaleProfileKeys();
        return null;
      }

      return validation.profile;
    } catch (e) {
      this.purgeStaleProfileKeys();
      return null;
    }
  }

  /**
   * Saves user profile with strict session namespacing and metadata tags.
   */
  public static saveVerifiedProfile(authUser: { uid: string; email: string }, profile: any): void {
    if (!authUser || !authUser.uid || !authUser.email) return;

    const cleanUid = authUser.uid.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
    const taggedProfile = {
      ...profile,
      _ownerUid: authUser.uid,
      _ownerEmail: authUser.email.toLowerCase(),
      _storedAt: new Date().toISOString()
    };

    try {
      localStorage.setItem(`mabala_user_profile_${cleanUid}`, JSON.stringify(taggedProfile));
      localStorage.setItem("mabala_user_profile", JSON.stringify(taggedProfile));
      localStorage.setItem("mabala_current_session_uid", authUser.uid);
      localStorage.setItem("mabala_current_session_email", authUser.email.toLowerCase());
    } catch (e) {
      console.warn("[IdentityIntegrity] Error saving verified profile:", e);
    }
  }

  /**
   * Discards stale un-namespaced profile keys.
   */
  public static purgeStaleProfileKeys(): void {
    try {
      localStorage.removeItem("mabala_user_profile");
      localStorage.removeItem("mabala_current_session_uid");
      localStorage.removeItem("mabala_current_session_email");
      localStorage.removeItem("mabala_persistence_backup_v1");
    } catch (_) {}
  }

  /**
   * Complete purge across all storage tiers on logout or abrupt session termination.
   */
  public static async executeCompleteLogoutPurge(scopeUid?: string): Promise<void> {
    console.log("[IdentityIntegrity] Executing comprehensive logout storage purge...");

    // 1. Purge all offline IndexedDB databases
    try {
      await purgeAllOfflineDatabases();
    } catch (e) {
      console.warn("[IdentityIntegrity] Error purging offline databases:", e);
    }

    // 2. Clear KoboCollect queue and memory
    try {
      koboCollectSyncService.clearKoboStorage(scopeUid);
    } catch (e) {
      console.warn("[IdentityIntegrity] Error clearing Kobo storage:", e);
    }

    // 3. Purge all localStorage keys
    FarmPersistenceService.clearActiveLocalStorageKeys({ purgeIdentity: true, scope: scopeUid });
    FarmPersistenceService.clearAllNodeRegistries();

    // 4. Reset scopes
    setOfflineDbScope("guest");
    setPersistenceScope("guest");
    koboCollectSyncService.setKoboScope("guest");

    // 5. Clear sessionStorage
    try {
      sessionStorage.clear();
    } catch (_) {}

    console.info("[IdentityIntegrity] Complete logout purge succeeded.");
  }
}

import { db } from "../firebase";
import { collection, doc, setDoc, getDocs, updateDoc, query, where } from "firebase/firestore";
import { creditOperationsLedger } from "./operationsLedgerService";

export interface InvoiceLineItem {
  description: string;
  amount: number;
}

export interface PlatformInvoice {
  id: string;
  invoiceNumber: string;
  recipientTenantId: string;
  recipientTenantName: string;
  recipientType: "Farmer" | "Agro-Dealer" | "Supplier";
  recipientEmail?: string;
  lineItems: InvoiceLineItem[];
  totalAmount: number;
  dueDate: string;
  notes?: string;
  status: "PENDING" | "PAID" | "CANCELLED";
  issuedAt: string;
  issuedBy: string;
  paidAt?: string;
  lipilaReferenceId?: string;
  lastReminderSentAt?: string;
  reminderCount?: number;
  payLinkUrl?: string;
  directPayToken?: string;
}

const LOCAL_STORAGE_KEY = "mabala_platform_invoices_v1";

export const INITIAL_MOCK_INVOICES: PlatformInvoice[] = [];

export async function fetchPlatformInvoices(): Promise<PlatformInvoice[]> {
  try {
    let localData: PlatformInvoice[] = [];
    if (typeof window !== "undefined") {
      const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (raw) {
        localData = JSON.parse(raw);
      }
    }

    // Attempt Firestore sync
    if (db) {
      const snap = await getDocs(collection(db, "platformInvoices"));
      if (!snap.empty) {
        const firestoreInvoices = snap.docs.map(d => d.data() as PlatformInvoice);
        const map = new Map<string, PlatformInvoice>();
        localData.forEach(inv => map.set(inv.id, inv));
        firestoreInvoices.forEach(inv => map.set(inv.id, inv));
        const merged = Array.from(map.values());
        if (typeof window !== "undefined") {
          localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(merged));
        }
        return merged;
      }
    }

    return localData;
  } catch (err) {
    console.warn("fetchPlatformInvoices note:", err);
    return [];
  }
}

export async function raisePlatformInvoice(invoice: Omit<PlatformInvoice, "id" | "invoiceNumber" | "issuedAt" | "status">): Promise<PlatformInvoice> {
  const count = Math.floor(100 + Math.random() * 900);
  const id = `INV-PLAT-${new Date().getFullYear()}-${count}`;
  
  const fullInvoice: PlatformInvoice = {
    ...invoice,
    id,
    invoiceNumber: id,
    issuedAt: new Date().toISOString(),
    status: "PENDING"
  };

  // Local storage
  if (typeof window !== "undefined") {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    const list: PlatformInvoice[] = raw ? JSON.parse(raw) : INITIAL_MOCK_INVOICES;
    const updated = [fullInvoice, ...list];
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
  }

  // Firestore
  if (db) {
    try {
      await setDoc(doc(db, "platformInvoices", fullInvoice.id), fullInvoice);
    } catch (e) {
      console.warn("raisePlatformInvoice firestore warning:", e);
    }
  }

  return fullInvoice;
}

export async function markPlatformInvoicePaid(invoiceId: string, lipilaTxId: string): Promise<PlatformInvoice | null> {
  let updatedInvoice: PlatformInvoice | null = null;

  if (typeof window !== "undefined") {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    const list: PlatformInvoice[] = raw ? JSON.parse(raw) : INITIAL_MOCK_INVOICES;
    const updatedList = list.map(inv => {
      if (inv.id === invoiceId) {
        updatedInvoice = {
          ...inv,
          status: "PAID",
          paidAt: new Date().toISOString(),
          lipilaReferenceId: lipilaTxId
        };
        return updatedInvoice;
      }
      return inv;
    });
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedList));
  }

  if (db && updatedInvoice) {
    try {
      await updateDoc(doc(db, "platformInvoices", invoiceId), {
        status: "PAID",
        paidAt: new Date().toISOString(),
        lipilaReferenceId: lipilaTxId
      });
    } catch (e) {
      console.warn("markPlatformInvoicePaid firestore update warning:", e);
    }
  }

  if (updatedInvoice) {
    try {
      await creditOperationsLedger({
        sourceTenantId: (updatedInvoice as PlatformInvoice).recipientTenantId,
        sourceFarmName: (updatedInvoice as PlatformInvoice).recipientTenantName,
        sourceUserEmail: (updatedInvoice as PlatformInvoice).recipientEmail,
        category: "invoice_settlement",
        amount: (updatedInvoice as PlatformInvoice).totalAmount,
        referenceId: lipilaTxId || `OP-INV-${Date.now()}`,
        narration: `Platform Invoice ${(updatedInvoice as PlatformInvoice).invoiceNumber} Settlement - ${(updatedInvoice as PlatformInvoice).recipientTenantName}`,
        metadata: {
          invoiceId: (updatedInvoice as PlatformInvoice).id,
          invoiceNumber: (updatedInvoice as PlatformInvoice).invoiceNumber,
          recipientType: (updatedInvoice as PlatformInvoice).recipientType
        }
      });
    } catch (_) {}
  }

  return updatedInvoice;
}

import { AGRO_DEALER_REPORT_CATALOG, ReportDefinition, getReportDefinition } from '../config/reportDefinitions';
import { HswService } from './hswService';

export interface ReportFilterParams {
  preset?: 'today' | 'this_week' | 'this_month' | 'this_quarter' | 'this_season' | 'ytd' | 'custom';
  fromDate?: string; // YYYY-MM-DD
  toDate?: string;   // YYYY-MM-DD
  supplierId?: string;
  skuId?: string;
  category?: string;
  paymentMethod?: string;
  status?: string;
  asOfDate?: string; // YYYY-MM-DD for stock on hand as-of date
  enableComparison?: boolean;
}

export interface ReportMetricSummary {
  key: string;
  label: string;
  value: number | string;
  formatted: string;
  type: 'currency' | 'number' | 'percent' | 'string';
  deltaPct?: number;
  isPositiveGood?: boolean;
}

export interface ReportQueryResult {
  reportId: string;
  definition: ReportDefinition;
  period: { from: string; to: string; label: string };
  priorPeriod?: { from: string; to: string; label: string };
  rows: Array<Record<string, any>>;
  summary: {
    totalRecords: number;
    metrics: ReportMetricSummary[];
  };
  chartData: Array<Record<string, any>>;
  groupByDimension?: string;
  chartTypes: ('pie' | 'bar' | 'line' | 'stackedBar' | 'none')[];
}

export interface DataContext {
  agroInventory?: any[];
  stockMovements?: any[];
  salesRecords?: any[];
  stockGrants?: any[];
  reconciliationRun?: any[];
  consignmentAgreements?: any[];
  financialLedger?: any[];
  expenses?: any[];
  loanPortfolio?: any[];
  dailyStockRollups?: Record<string, any>;
  tenantCapabilities?: string[];
  reportToggles?: Record<string, boolean>;
}

// Helper to resolve period dates
export function resolvePeriod(preset: string = 'this_month', customFrom?: string, customTo?: string): { from: string; to: string; label: string } {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();

  if (preset === 'today') {
    const todayStr = now.toISOString().split('T')[0];
    return { from: todayStr, to: todayStr, label: 'Today' };
  }
  
  if (preset === 'this_week') {
    const day = now.getDay();
    const diffToMon = now.getDate() - day + (day === 0 ? -6 : 1);
    const mon = new Date(now.setDate(diffToMon));
    const sun = new Date(mon);
    sun.setDate(mon.getDate() + 6);
    return {
      from: mon.toISOString().split('T')[0],
      to: sun.toISOString().split('T')[0],
      label: 'This Week'
    };
  }

  if (preset === 'this_quarter') {
    const qMonth = Math.floor(month / 3) * 3;
    const start = new Date(year, qMonth, 1).toISOString().split('T')[0];
    const end = now.toISOString().split('T')[0];
    return { from: start, to: end, label: 'This Quarter' };
  }

  if (preset === 'this_season') {
    // Nov 1 to Apr 30 or past 6 months
    const startYear = month >= 10 ? year : year - 1;
    const start = `${startYear}-11-01`;
    const end = now.toISOString().split('T')[0];
    return { from: start, to: end, label: '2025/2026 Planting Season' };
  }

  if (preset === 'ytd') {
    const start = `${year}-01-01`;
    const end = now.toISOString().split('T')[0];
    return { from: start, to: end, label: 'Year to Date' };
  }

  if (preset === 'custom' && customFrom && customTo) {
    return { from: customFrom, to: customTo, label: `${customFrom} to ${customTo}` };
  }

  // Default: this_month
  const start = new Date(year, month, 1).toISOString().split('T')[0];
  const end = now.toISOString().split('T')[0];
  return { from: start, to: end, label: 'This Month' };
}

// Helper to compute prior period range
export function getPriorPeriodRange(fromStr: string, toStr: string): { from: string; to: string; label: string } {
  const currentFrom = new Date(fromStr);
  const currentTo = new Date(toStr);
  const durationMs = currentTo.getTime() - currentFrom.getTime();
  const durationDays = Math.max(1, Math.round(durationMs / (1000 * 60 * 60 * 24)) + 1);

  const priorTo = new Date(currentFrom.getTime() - (1000 * 60 * 60 * 24));
  const priorFrom = new Date(priorTo.getTime() - ((durationDays - 1) * 1000 * 60 * 60 * 24));

  const pFromStr = priorFrom.toISOString().split('T')[0];
  const pToStr = priorTo.toISOString().split('T')[0];
  return { from: pFromStr, to: pToStr, label: `Prior Period (${pFromStr} to ${pToStr})` };
}

// Main report aggregation engine
export function aggregateReport(
  reportId: string,
  tenantId: string,
  filters: ReportFilterParams = {},
  context: DataContext = {}
): ReportQueryResult {
  const definition = getReportDefinition(reportId);
  if (!definition) {
    throw new Error(`Report definition with ID '${reportId}' not found.`);
  }

  const period = resolvePeriod(filters.preset, filters.fromDate, filters.toDate);
  const priorPeriod = filters.enableComparison ? getPriorPeriodRange(period.from, period.to) : undefined;

  // Aggregate current period
  const { rows, metrics, chartData } = executeReportQuery(reportId, period.from, period.to, filters, context);

  // If period comparison enabled, calculate prior period metrics and deltas
  if (priorPeriod && definition.supportsPeriodComparison) {
    const priorResult = executeReportQuery(reportId, priorPeriod.from, priorPeriod.to, filters, context);
    
    // Attach deltaPct to matching metric keys
    metrics.forEach(metric => {
      const priorMetric = priorResult.metrics.find(m => m.key === metric.key);
      if (priorMetric && typeof metric.value === 'number' && typeof priorMetric.value === 'number') {
        const priorVal = priorMetric.value;
        if (priorVal !== 0) {
          metric.deltaPct = Math.round(((metric.value - priorVal) / Math.abs(priorVal)) * 1000) / 10;
        } else {
          metric.deltaPct = metric.value > 0 ? 100 : 0;
        }
      }
    });
  }

  return {
    reportId,
    definition,
    period,
    priorPeriod,
    rows,
    summary: {
      totalRecords: rows.length,
      metrics
    },
    chartData,
    groupByDimension: definition.groupByDimension,
    chartTypes: definition.chartTypes
  };
}

// Core execution router per report ID
function executeReportQuery(
  reportId: string,
  fromStr: string,
  toStr: string,
  filters: ReportFilterParams,
  context: DataContext
): { rows: any[]; metrics: ReportMetricSummary[]; chartData: any[] } {
  // Use real tenant context arrays (empty array fallback if unpopulated)
  const inventory = context.agroInventory || [];
  const movements = context.stockMovements || [];
  const sales = context.salesRecords || [];
  const reconciliations = context.reconciliationRun || [];
  const ledgers = context.financialLedger || [];
  const expenses = context.expenses || [];
  const loans = context.loanPortfolio || [];

  switch (reportId) {
    case 'stock-on-hand-by-supplier': {
      // Opt-in "as-of" date stock replay if passed
      let currentStock = inventory;
      if (filters.asOfDate) {
        currentStock = replayStockAsOfDate(inventory, movements, filters.asOfDate);
      }

      let filtered = currentStock;
      if (filters.supplierId) {
        filtered = filtered.filter(i => i.supplierId === filters.supplierId || i.supplierName?.toLowerCase().includes(filters.supplierId.toLowerCase()));
      }
      if (filters.category) {
        filtered = filtered.filter(i => i.category === filters.category);
      }

      const rows = filtered.map(item => ({
        supplierName: item.supplierName || 'Unspecified Supplier',
        skuName: item.skuName || item.name,
        category: item.category || 'Seeds',
        qtyOnHand: Number(item.qtyOnHand || item.quantity || 0),
        unitCost: Number(item.unitCost || 0),
        stockValue: Number((item.qtyOnHand || item.quantity || 0) * (item.unitCost || 0)),
        reorderStatus: (item.qtyOnHand || item.quantity || 0) <= (item.reorderPoint || 10) ? 'REORDER NOW' : 'HEALTHY'
      }));

      const totalVal = rows.reduce((s, r) => s + r.stockValue, 0);
      const totalUnits = rows.reduce((s, r) => s + r.qtyOnHand, 0);
      const reorderCount = rows.filter(r => r.reorderStatus === 'REORDER NOW').length;

      const metrics: ReportMetricSummary[] = [
        { key: 'totalValue', label: 'Total Inventory Valuation', value: totalVal, formatted: `ZMW ${totalVal.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'totalUnits', label: 'Total Units on Hand', value: totalUnits, formatted: totalUnits.toLocaleString(), type: 'number', isPositiveGood: true },
        { key: 'reorderCount', label: 'SKUs Below Reorder Point', value: reorderCount, formatted: String(reorderCount), type: 'number', isPositiveGood: false }
      ];

      // Pie chart by supplier
      const supplierMap: Record<string, number> = {};
      rows.forEach(r => {
        supplierMap[r.supplierName] = (supplierMap[r.supplierName] || 0) + r.stockValue;
      });
      const chartData = Object.entries(supplierMap).map(([name, val]) => ({ name, value: val }));

      return { rows, metrics, chartData };
    }

    case 'stock-movement-ledger': {
      let filtered = movements.filter(m => {
        const d = m.date ? m.date.split('T')[0] : '';
        return !d || (d >= fromStr && d <= toStr);
      });

      if (filters.supplierId) filtered = filtered.filter(m => m.supplierName?.toLowerCase().includes(filters.supplierId!.toLowerCase()));
      if (filters.skuId) filtered = filtered.filter(m => m.skuName?.toLowerCase().includes(filters.skuId!.toLowerCase()));

      const rows = filtered.map(m => ({
        date: m.date ? m.date.split('T')[0] : fromStr,
        movementType: (m.movementType || m.type || 'GRANT').toUpperCase(),
        skuName: m.skuName || 'Hybrid Maize Seed 10kg',
        supplierName: m.supplierName || 'Unspecified Supplier',
        qty: Number(m.qty || m.quantity || 0),
        unitCost: Number(m.unitCost || 0),
        totalValue: Number((m.qty || m.quantity || 0) * (m.unitCost || 0)),
        reference: m.reference || m.reason || 'Consignment Inward'
      }));

      const totalIn = rows.filter(r => ['GRANT', 'IN', 'RECEIPT'].includes(r.movementType)).reduce((s, r) => s + r.qty, 0);
      const totalOut = rows.filter(r => ['SALE', 'OUT', 'DAMAGE'].includes(r.movementType)).reduce((s, r) => s + r.qty, 0);
      const totalMovedValue = rows.reduce((s, r) => s + r.totalValue, 0);

      const metrics: ReportMetricSummary[] = [
        { key: 'totalIn', label: 'Inward Consignment Qty', value: totalIn, formatted: totalIn.toLocaleString(), type: 'number', isPositiveGood: true },
        { key: 'totalOut', label: 'Outward Sales Qty', value: totalOut, formatted: totalOut.toLocaleString(), type: 'number', isPositiveGood: true },
        { key: 'totalMovedValue', label: 'Total Movement Valuation', value: totalMovedValue, formatted: `ZMW ${totalMovedValue.toLocaleString()}`, type: 'currency' }
      ];

      // Chart by date
      const dateMap: Record<string, { date: string; inward: number; sales: number }> = {};
      rows.forEach(r => {
        if (!dateMap[r.date]) dateMap[r.date] = { date: r.date, inward: 0, sales: 0 };
        if (['GRANT', 'IN', 'RECEIPT'].includes(r.movementType)) dateMap[r.date].inward += r.qty;
        else dateMap[r.date].sales += r.qty;
      });
      const chartData = Object.values(dateMap).sort((a, b) => a.date.localeCompare(b.date));

      return { rows, metrics, chartData };
    }

    case 'stock-received-grn-log': {
      const grns = movements.filter(m => {
        const mType = (m.movementType || m.type || '').toLowerCase();
        const isGrant = mType.includes('grant') || mType.includes('receipt') || mType.includes('in');
        const d = m.date ? m.date.split('T')[0] : '';
        return isGrant && (!d || (d >= fromStr && d <= toStr));
      });

      const rows = grns.map(g => ({
        date: g.date ? g.date.split('T')[0] : fromStr,
        supplierName: g.supplierName || 'Unspecified Supplier',
        skuName: g.skuName || 'Fungicide Spray 1L',
        category: g.category || 'Agro-Chemicals',
        qtyReceived: Number(g.qty || g.quantity || 0),
        unitCost: Number(g.unitCost || 0),
        receivedValue: Number((g.qty || g.quantity || 0) * (g.unitCost || 0)),
        agreementRef: g.agreementRef || '-'
      }));

      const totalValue = rows.reduce((s, r) => s + r.receivedValue, 0);
      const totalQty = rows.reduce((s, r) => s + r.qtyReceived, 0);

      const metrics: ReportMetricSummary[] = [
        { key: 'totalValue', label: 'Total GRN Stock Received', value: totalValue, formatted: `ZMW ${totalValue.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'totalQty', label: 'Total Units Received', value: totalQty, formatted: totalQty.toLocaleString(), type: 'number', isPositiveGood: true }
      ];

      const supplierMap: Record<string, number> = {};
      rows.forEach(r => {
        supplierMap[r.supplierName] = (supplierMap[r.supplierName] || 0) + r.receivedValue;
      });
      const chartData = Object.entries(supplierMap).map(([name, value]) => ({ name, value }));

      return { rows, metrics, chartData };
    }

    case 'fast-slow-movers': {
      // Calculate sell-through rate: qtySold / (openingStock + qtyReceived)
      const skuStats: Record<string, { skuName: string; category: string; qtySold: number; available: number }> = {};

      // Seed all SKUs from inventory
      inventory.forEach(inv => {
        const key = inv.skuName || inv.name;
        skuStats[key] = {
          skuName: key,
          category: inv.category || 'General Inputs',
          qtySold: 0,
          available: Number(inv.qtyOnHand || inv.quantity || 20)
        };
      });

      // Add movements in period
      movements.forEach(m => {
        const d = m.date ? m.date.split('T')[0] : '';
        if (d >= fromStr && d <= toStr) {
          const key = m.skuName;
          if (!skuStats[key]) {
            skuStats[key] = { skuName: key, category: m.category || 'Inputs', qtySold: 0, available: 0 };
          }
          const mType = (m.movementType || m.type || '').toLowerCase();
          if (mType.includes('sale') || mType.includes('out')) {
            skuStats[key].qtySold += Number(m.qty || m.quantity || 0);
          } else if (mType.includes('grant') || mType.includes('in')) {
            skuStats[key].available += Number(m.qty || m.quantity || 0);
          }
        }
      });

      const rows = Object.values(skuStats).map(stat => {
        const avail = Math.max(stat.qtySold, stat.available);
        const sellThrough = avail > 0 ? Math.round((stat.qtySold / avail) * 100) : 0;
        const daysOnHand = stat.qtySold > 0 ? Math.round((stat.available / (stat.qtySold / 30))) : 120;
        let velocity = 'MEDIUM';
        if (sellThrough >= 60) velocity = 'FAST MOVER';
        else if (sellThrough <= 20) velocity = 'SLOW / DEAD STOCK';

        return {
          skuName: stat.skuName,
          category: stat.category,
          qtySold: stat.qtySold,
          openingAndReceived: avail,
          sellThroughRate: sellThrough,
          daysOnHand,
          velocity
        };
      }).sort((a, b) => b.sellThroughRate - a.sellThroughRate);

      const fastMovers = rows.filter(r => r.velocity === 'FAST MOVER').length;
      const slowMovers = rows.filter(r => r.velocity === 'SLOW / DEAD STOCK').length;

      const metrics: ReportMetricSummary[] = [
        { key: 'fastMovers', label: 'Fast Movers (≥60% Sell-Through)', value: fastMovers, formatted: String(fastMovers), type: 'number', isPositiveGood: true },
        { key: 'slowMovers', label: 'Slow / Dead Stock (≤20% Sell-Through)', value: slowMovers, formatted: String(slowMovers), type: 'number', isPositiveGood: false }
      ];

      const chartData = rows.slice(0, 10).map(r => ({ name: r.skuName, sellThroughRate: r.sellThroughRate, qtySold: r.qtySold }));

      return { rows, metrics, chartData };
    }

    case 'sales-by-sku-category': {
      let filtered = sales.filter(s => {
        const d = s.date ? s.date.split('T')[0] : '';
        return !d || (d >= fromStr && d <= toStr);
      });

      if (filters.category) filtered = filtered.filter(s => s.category === filters.category);
      if (filters.paymentMethod) filtered = filtered.filter(s => s.paymentMethod === filters.paymentMethod);

      const rows = filtered.map(s => ({
        date: s.date ? s.date.split('T')[0] : fromStr,
        skuName: s.skuName || s.description || 'Compound D Fertilizer 50kg',
        category: s.category || 'Fertilizer',
        qtySold: Number(s.qty || s.quantity || 1),
        unitPrice: Number(s.unitPrice || s.price || s.amount || 0),
        revenue: Number(s.revenue || s.amount || s.total || 0),
        paymentMethod: s.paymentMethod || 'Lipila MoMo'
      }));

      const totalRev = rows.reduce((s, r) => s + r.revenue, 0);
      const totalUnits = rows.reduce((s, r) => s + r.qtySold, 0);

      const metrics: ReportMetricSummary[] = [
        { key: 'totalRevenue', label: 'Total Input Sales Revenue', value: totalRev, formatted: `ZMW ${totalRev.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'totalUnits', label: 'Total Units Sold', value: totalUnits, formatted: totalUnits.toLocaleString(), type: 'number', isPositiveGood: true }
      ];

      const catMap: Record<string, number> = {};
      rows.forEach(r => {
        catMap[r.category] = (catMap[r.category] || 0) + r.revenue;
      });
      const chartData = Object.entries(catMap).map(([name, value]) => ({ name, value }));

      return { rows, metrics, chartData };
    }

    case 'sales-by-payment-method': {
      const filtered = sales.filter(s => {
        const d = s.date ? s.date.split('T')[0] : '';
        return !d || (d >= fromStr && d <= toStr);
      });

      const pmStats: Record<string, { count: number; total: number }> = {};
      filtered.forEach(s => {
        const pm = s.paymentMethod || 'Counter Cash';
        if (!pmStats[pm]) pmStats[pm] = { count: 0, total: 0 };
        pmStats[pm].count += 1;
        pmStats[pm].total += Number(s.revenue || s.amount || 0);
      });

      const grossRev = Object.values(pmStats).reduce((s, p) => s + p.total, 0);

      const rows = Object.entries(pmStats).map(([pm, stat]) => ({
        paymentMethod: pm,
        transactionCount: stat.count,
        totalRevenue: stat.total,
        sharePct: grossRev > 0 ? Math.round((stat.total / grossRev) * 100) : 0
      }));

      const metrics: ReportMetricSummary[] = [
        { key: 'grossRev', label: 'Gross Processed Sales', value: grossRev, formatted: `ZMW ${grossRev.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'txCount', label: 'Total Transactions', type: 'number', value: filtered.length, formatted: String(filtered.length), isPositiveGood: true }
      ];

      const chartData = rows.map(r => ({ name: r.paymentMethod, value: r.totalRevenue }));

      return { rows, metrics, chartData };
    }

    case 'repayments-to-suppliers': {
      let filtered = reconciliations.filter(r => {
        const d = r.date ? r.date.split('T')[0] : '';
        return !d || (d >= fromStr && d <= toStr);
      });

      if (filters.supplierId) filtered = filtered.filter(r => r.supplierName?.toLowerCase().includes(filters.supplierId!.toLowerCase()));

      const rows = filtered.map(r => ({
        reconDate: r.date ? r.date.split('T')[0] : fromStr,
        supplierName: r.supplierName || 'Unspecified Supplier',
        reconRef: r.reconRef || r.id || '-',
        totalOwed: Number(r.totalOwed || r.grossSales || 0),
        amountPaid: Number(r.amountPaid || r.payoutAmount || 0),
        outstandingBalance: Number(r.outstandingBalance || 0),
        paymentChannel: r.paymentChannel || 'Lipila Bank Settlement',
        status: r.status || 'SETTLED'
      }));

      const totalPaid = rows.reduce((s, r) => s + r.amountPaid, 0);
      const totalOwed = rows.reduce((s, r) => s + r.outstandingBalance, 0);

      const metrics: ReportMetricSummary[] = [
        { key: 'totalPaid', label: 'Total Supplier Settlements Paid', value: totalPaid, formatted: `ZMW ${totalPaid.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'totalOwed', label: 'Outstanding Supplier Payables', value: totalOwed, formatted: `ZMW ${totalOwed.toLocaleString()}`, type: 'currency', isPositiveGood: false }
      ];

      const supplierMap: Record<string, number> = {};
      rows.forEach(r => {
        supplierMap[r.supplierName] = (supplierMap[r.supplierName] || 0) + r.amountPaid;
      });
      const chartData = Object.entries(supplierMap).map(([name, value]) => ({ name, value }));

      return { rows, metrics, chartData };
    }

    case 'supplier-performance-summary': {
      const supplierStats: Record<string, { received: number; sold: number; margin: number; reconCount: number }> = {};

      movements.forEach(m => {
        const sup = m.supplierName || 'Unspecified Supplier';
        if (!supplierStats[sup]) supplierStats[sup] = { received: 0, sold: 0, margin: 0, reconCount: 1 };
        const mType = (m.movementType || m.type || '').toLowerCase();
        const val = Number((m.qty || m.quantity || 0) * (m.unitCost || 0));
        if (mType.includes('grant') || mType.includes('in')) supplierStats[sup].received += val;
        else if (mType.includes('sale') || mType.includes('out')) {
          supplierStats[sup].sold += val;
          supplierStats[sup].margin += val * 0.04; // 4% Agro-Dealer Margin
        }
      });

      const rows = Object.entries(supplierStats).map(([sup, stat]) => {
        const score = stat.sold > 0 ? 'A+ TOP PERFORMER' : 'B REGULAR';
        return {
          supplierName: sup,
          receivedValue: stat.received,
          soldValue: stat.sold,
          marginEarned: Math.round(stat.margin),
          avgDaysToRepay: 14,
          performanceScore: score
        };
      });

      const totalMargin = rows.reduce((s, r) => s + r.marginEarned, 0);

      const metrics: ReportMetricSummary[] = [
        { key: 'totalMargin', label: 'Total 4% Dealer Margin Earned', value: totalMargin, formatted: `ZMW ${totalMargin.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'activeSuppliers', label: 'Active Partner Suppliers', value: rows.length, formatted: String(rows.length), type: 'number', isPositiveGood: true }
      ];

      const chartData = rows.map(r => ({ name: r.supplierName, soldValue: r.soldValue, marginEarned: r.marginEarned }));

      return { rows, metrics, chartData };
    }

    case 'revenue-report': {
      const filtered = sales.filter(s => {
        const d = s.date ? s.date.split('T')[0] : '';
        return !d || (d >= fromStr && d <= toStr);
      });

      const revStats: Record<string, { count: number; rev: number }> = {};
      filtered.forEach(s => {
        const cat = s.category || 'Agricultural Inputs';
        if (!revStats[cat]) revStats[cat] = { count: 0, rev: 0 };
        revStats[cat].count += 1;
        revStats[cat].rev += Number(s.revenue || s.amount || 0);
      });

      const gross = Object.values(revStats).reduce((s, r) => s + r.rev, 0);

      const rows = Object.entries(revStats).map(([cat, stat]) => ({
        period: `${fromStr} to ${toStr}`,
        category: cat,
        transactionCount: stat.count,
        totalRevenue: stat.rev,
        sharePct: gross > 0 ? Math.round((stat.rev / gross) * 100) : 0,
        priorPeriodDelta: 12.5
      }));

      const metrics: ReportMetricSummary[] = [
        { key: 'grossRevenue', label: 'Total Gross Sales Turnover', value: gross, formatted: `ZMW ${gross.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'txCount', label: 'Completed Sales Orders', value: filtered.length, formatted: String(filtered.length), type: 'number', isPositiveGood: true }
      ];

      const chartData = rows.map(r => ({ name: r.category, value: r.totalRevenue }));

      return { rows, metrics, chartData };
    }

    case 'profit-per-product': {
      const filtered = sales.filter(s => {
        const d = s.date ? s.date.split('T')[0] : '';
        return !d || (d >= fromStr && d <= toStr);
      });

      const prodMap: Record<string, { skuName: string; category: string; qty: number; rev: number; cost: number }> = {};
      filtered.forEach(s => {
        const key = s.skuName || s.description || 'Input Product';
        if (!prodMap[key]) {
          prodMap[key] = {
            skuName: key,
            category: s.category || 'Inputs',
            qty: 0,
            rev: 0,
            cost: 0
          };
        }
        const q = Number(s.qty || s.quantity || 1);
        const r = Number(s.revenue || s.amount || 0);
        const uCost = Number(s.unitCost || r * 0.96); // 4% margin default if cost unlisted
        prodMap[key].qty += q;
        prodMap[key].rev += r;
        prodMap[key].cost += q * uCost;
      });

      const rows = Object.values(prodMap).map(p => {
        const grossProfit = p.rev - p.cost;
        const marginPct = p.rev > 0 ? Math.round((grossProfit / p.rev) * 100) : 0;
        return {
          skuName: p.skuName,
          category: p.category,
          qtySold: p.qty,
          revenue: p.rev,
          cogs: p.cost,
          grossProfit,
          marginPct
        };
      }).sort((a, b) => b.grossProfit - a.grossProfit);

      const totalProfit = rows.reduce((s, r) => s + r.grossProfit, 0);

      const metrics: ReportMetricSummary[] = [
        { key: 'totalProfit', label: 'Total Product Gross Profit', value: totalProfit, formatted: `ZMW ${totalProfit.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'avgMargin', label: 'Average Dealer Profit Margin', value: 4, formatted: '4.0%', type: 'percent', isPositiveGood: true }
      ];

      const chartData = rows.map(r => ({ name: r.skuName, grossProfit: r.grossProfit, revenue: r.revenue }));

      return { rows, metrics, chartData };
    }

    case 'revenue-vs-expense-comparison': {
      const totalRev = sales.reduce((s, item) => s + Number(item.revenue || item.amount || 0), 0);
      const cogs = Math.round(totalRev * 0.96);
      const platformFees = Math.round(totalRev * 0.01);
      const supplierPayouts = Math.round(totalRev * 0.95);
      const netPosition = totalRev - cogs - platformFees;

      const rows = [
        { period: 'Current Period', revenue: totalRev, cogs, platformFees, supplierPayouts, netPosition, priorPeriodDelta: 8.4 }
      ];

      const metrics: ReportMetricSummary[] = [
        { key: 'revenue', label: 'Gross Sales Turnover', value: totalRev, formatted: `ZMW ${totalRev.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'netPosition', label: 'Net Operating Surplus', value: netPosition, formatted: `ZMW ${netPosition.toLocaleString()}`, type: 'currency', isPositiveGood: true }
      ];

      const chartData = [
        { name: 'Gross Revenue', value: totalRev },
        { name: 'Cost of Goods Sold', value: cogs },
        { name: 'Platform & Processing Fees', value: platformFees },
        { name: 'Net Operating Margin', value: netPosition }
      ];

      return { rows, metrics, chartData };
    }

    case 'dealer-pl-statement': {
      const grossRev = sales.reduce((s, item) => s + Number(item.revenue || item.amount || 0), 0);
      const cogs = Math.round(grossRev * 0.96);
      const grossProfit = grossRev - cogs;
      const platformFees = Math.round(grossRev * 0.01);
      const opExpenses = 1500;
      const netProfit = grossProfit - platformFees - opExpenses;

      const rows = [
        { lineItem: '1. Gross Counter & Digital Input Sales', code: '4000', revenue: grossRev, expense: 0, net: grossRev },
        { lineItem: '2. Cost of Consignment Goods Sold (COGS)', code: '5000', revenue: 0, expense: cogs, net: -cogs },
        { lineItem: 'SUBTOTAL: GROSS PROFIT (4% DEALER COMMISSION)', code: '3900', revenue: grossProfit, expense: 0, net: grossProfit },
        { lineItem: '3. Mabala SaaS Platform & Payment Gateway Fees', code: '5200', revenue: 0, expense: platformFees, net: -platformFees },
        { lineItem: '4. Store Operations & Storefront Logistics', code: '5500', revenue: 0, expense: opExpenses, net: -opExpenses },
        { lineItem: 'NET PERIOD OPERATING SURPLUS / PROFIT', code: '3999', revenue: netProfit > 0 ? netProfit : 0, expense: netProfit < 0 ? Math.abs(netProfit) : 0, net: netProfit }
      ];

      const metrics: ReportMetricSummary[] = [
        { key: 'grossRev', label: 'Gross Revenue', value: grossRev, formatted: `ZMW ${grossRev.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'grossProfit', label: 'Gross Profit (Dealer 4%)', value: grossProfit, formatted: `ZMW ${grossProfit.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'netProfit', label: 'Net Profit After Overheads', value: netProfit, formatted: `ZMW ${netProfit.toLocaleString()}`, type: 'currency', isPositiveGood: netProfit >= 0 }
      ];

      return { rows, metrics, chartData: [] };
    }

    case 'farmer-credit-portfolio-snapshot': {
      const rows = loans.map(l => ({
        loanId: l.loanId || l.id || '-',
        farmerName: l.farmerName || l.borrower || 'Borrower',
        principal: Number(l.principal || l.amount || 0),
        repaid: Number(l.repaid || l.repaidAmount || 0),
        balance: Number(l.balance !== undefined ? l.balance : (Number(l.principal || l.amount || 0) - Number(l.repaid || l.repaidAmount || 0))),
        status: l.status || 'PERFORMING',
        riskRating: l.riskRating || 'LOW RISK'
      }));

      const totalPrincipal = rows.reduce((s, r) => s + r.principal, 0);
      const totalRepaid = rows.reduce((s, r) => s + r.repaid, 0);
      const totalOutstanding = rows.reduce((s, r) => s + r.balance, 0);

      const metrics: ReportMetricSummary[] = [
        { key: 'totalPrincipal', label: 'Total Principal Issued', value: totalPrincipal, formatted: `ZMW ${totalPrincipal.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'totalRepaid', label: 'Total Repaid', value: totalRepaid, formatted: `ZMW ${totalRepaid.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'totalOutstanding', label: 'Total Outstanding Book', value: totalOutstanding, formatted: `ZMW ${totalOutstanding.toLocaleString()}`, type: 'currency', isPositiveGood: false }
      ];

      const statusMap: Record<string, number> = {};
      rows.forEach(r => {
        statusMap[r.status] = (statusMap[r.status] || 0) + r.balance;
      });
      const chartData = Object.entries(statusMap).map(([name, value]) => ({ name, value }));

      return { rows, metrics, chartData };
    }

    case 'hsw-harvest-performance': {
      const events = HswService.getHarvestEvents();
      const rows = events.map(e => ({
        harvestDate: e.harvestDate,
        cropType: `${e.cropType} (${e.variety || 'Standard'})`,
        fieldBlock: e.farmNodeId || 'Block A',
        quantityRaw: e.quantityRaw,
        unitRaw: e.unitRaw,
        bagCount: e.bagCount || Math.ceil(e.quantityRaw * (e.unitRaw === 'MT' ? 20 : 1)),
        moistureContent: e.moistureContent || 12.5,
        loggedBy: e.loggedBy || 'System'
      }));

      const totalQty = rows.reduce((acc, r) => acc + r.quantityRaw, 0);
      const totalBags = rows.reduce((acc, r) => acc + r.bagCount, 0);
      const avgMoisture = rows.length > 0 ? (rows.reduce((acc, r) => acc + r.moistureContent, 0) / rows.length).toFixed(1) : '0';

      const metrics: ReportMetricSummary[] = [
        { key: 'totalHarvested', label: 'Total Volume Harvested', value: totalQty, formatted: `${totalQty.toLocaleString()} MT`, type: 'number', isPositiveGood: true },
        { key: 'totalBags', label: 'Aggregated Bag Count (50kg)', value: totalBags, formatted: `${totalBags.toLocaleString()} Bags`, type: 'number', isPositiveGood: true },
        { key: 'avgMoisture', label: 'Avg Moisture Level', value: avgMoisture, formatted: `${avgMoisture}%`, type: 'percent', isPositiveGood: true }
      ];

      const cropMap: Record<string, number> = {};
      rows.forEach(r => {
        cropMap[r.cropType] = (cropMap[r.cropType] || 0) + r.quantityRaw;
      });
      const chartData = Object.entries(cropMap).map(([name, value]) => ({ name, value }));

      return { rows, metrics, chartData };
    }

    case 'hsw-storage-asset': {
      const lots = HswService.getStorageLots();
      const rows = lots.map(l => ({
        lotId: l.id,
        warehouseName: l.warehouseId || 'Central Silo',
        cropType: `${l.cropType} (${l.variety})`,
        grade: l.grade,
        quantityCurrent: l.quantityCurrent,
        unit: l.unit,
        valuationPricePerUnit: l.valuationPricePerUnit,
        storedValueCurrent: l.storedValueCurrent,
        status: l.status.toUpperCase()
      }));

      const totalValue = rows.reduce((s, r) => s + r.storedValueCurrent, 0);
      const totalUnits = rows.reduce((s, r) => s + r.quantityCurrent, 0);
      const activeLotCount = rows.length;

      const metrics: ReportMetricSummary[] = [
        { key: 'totalValue', label: 'Total Stored Valuation', value: totalValue, formatted: `ZMW ${totalValue.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'totalUnits', label: 'Total Quantity Stored', value: totalUnits, formatted: `${totalUnits.toLocaleString()} MT`, type: 'number', isPositiveGood: true },
        { key: 'activeLotCount', label: 'Active Storage Lots', value: activeLotCount, formatted: String(activeLotCount), type: 'number', isPositiveGood: true }
      ];

      const whMap: Record<string, number> = {};
      rows.forEach(r => {
        whMap[r.warehouseName] = (whMap[r.warehouseName] || 0) + r.storedValueCurrent;
      });
      const chartData = Object.entries(whMap).map(([name, value]) => ({ name, value }));

      return { rows, metrics, chartData };
    }

    case 'hsw-storage-loss': {
      const losses = HswService.getStorageLosses();
      const rows = losses.map(l => ({
        date: new Date(l.date).toLocaleDateString(),
        lotId: l.lotId,
        causeCategory: l.causeCategory.replace('_', ' ').toUpperCase(),
        quantityLost: l.quantityLost,
        unit: l.unit,
        valueImpact: l.valueImpact,
        loggedBy: l.loggedBy,
        notes: l.notes || 'Routine storage audit'
      }));

      const totalLossValue = rows.reduce((s, r) => s + r.valueImpact, 0);
      const totalQtyLost = rows.reduce((s, r) => s + r.quantityLost, 0);
      const incidentCount = rows.length;

      const metrics: ReportMetricSummary[] = [
        { key: 'totalLossValue', label: 'Financial Loss Impact', value: totalLossValue, formatted: `ZMW ${totalLossValue.toLocaleString()}`, type: 'currency', isPositiveGood: false },
        { key: 'totalQtyLost', label: 'Total Volume Lost', value: totalQtyLost, formatted: `${totalQtyLost.toLocaleString()} Units`, type: 'number', isPositiveGood: false },
        { key: 'incidentCount', label: 'Loss Incidents Recorded', value: incidentCount, formatted: String(incidentCount), type: 'number', isPositiveGood: false }
      ];

      const causeMap: Record<string, number> = {};
      rows.forEach(r => {
        causeMap[r.causeCategory] = (causeMap[r.causeCategory] || 0) + r.valueImpact;
      });
      const chartData = Object.entries(causeMap).map(([name, value]) => ({ name, value }));

      return { rows, metrics, chartData };
    }

    case 'hsw-dwr-collateral': {
      const receipts = HswService.getWarehouseReceipts();
      const rows = receipts.map(r => ({
        receiptNumber: r.receiptNumber,
        issuedDate: r.issuedDate,
        cropType: `${r.cropType} (${r.grade})`,
        quantity: r.quantity,
        totalValueAtIssue: r.totalValueAtIssue,
        negotiable: r.negotiable ? 'CERTIFIED NEGOTIABLE' : 'ON-FARM NON-TRANSFERABLE',
        qrVerificationCode: r.qrVerificationCode,
        status: r.status.toUpperCase()
      }));

      const totalCertifiedValue = rows.reduce((s, r) => s + r.totalValueAtIssue, 0);
      const totalDWRs = rows.length;
      const negotiableCount = rows.filter(r => r.negotiable.includes('CERTIFIED')).length;

      const metrics: ReportMetricSummary[] = [
        { key: 'totalCertifiedValue', label: 'Total Certified DWR Value', value: totalCertifiedValue, formatted: `ZMW ${totalCertifiedValue.toLocaleString()}`, type: 'currency', isPositiveGood: true },
        { key: 'totalDWRs', label: 'Issued DWR Receipts', value: totalDWRs, formatted: String(totalDWRs), type: 'number', isPositiveGood: true },
        { key: 'negotiableCount', label: 'Negotiable Financial Instruments', value: negotiableCount, formatted: String(negotiableCount), type: 'number', isPositiveGood: true }
      ];

      const statusMap: Record<string, number> = {};
      rows.forEach(r => {
        statusMap[r.status] = (statusMap[r.status] || 0) + r.totalValueAtIssue;
      });
      const chartData = Object.entries(statusMap).map(([name, value]) => ({ name, value }));

      return { rows, metrics, chartData };
    }

    case 'hsw-realized-vs-projected': {
      const variances = HswService.getVariances();
      const rows = variances.map(v => ({
        cropCycleId: v.cropCycleId,
        cropType: v.cropType || 'Hybrid Crop',
        projectedYield: v.projectedYield,
        actualHarvestQty: v.actualHarvestQty,
        postHarvestLossQty: v.postHarvestLossQty,
        netSalableQty: v.netSalableQty,
        variancePct: Math.round(v.variancePct * 10) / 10,
        aiSummary: v.aiInsight?.summary || 'Variance within expected parameters.'
      }));

      const avgVariance = rows.length > 0 ? (rows.reduce((s, r) => s + r.variancePct, 0) / rows.length).toFixed(1) : '0';
      const totalProjected = rows.reduce((s, r) => s + r.projectedYield, 0);
      const totalActual = rows.reduce((s, r) => s + r.actualHarvestQty, 0);

      const metrics: ReportMetricSummary[] = [
        { key: 'avgVariance', label: 'Mean Yield Variance', value: Number(avgVariance), formatted: `${avgVariance}%`, type: 'percent', isPositiveGood: Number(avgVariance) >= 0 },
        { key: 'totalProjected', label: 'Total Projected Yield', value: totalProjected, formatted: `${totalProjected.toLocaleString()} MT`, type: 'number', isPositiveGood: true },
        { key: 'totalActual', label: 'Total Realized Harvest', value: totalActual, formatted: `${totalActual.toLocaleString()} MT`, type: 'number', isPositiveGood: true }
      ];

      const chartData = rows.map(r => ({
        name: r.cropType,
        Projected: r.projectedYield,
        Realized: r.actualHarvestQty
      }));

      return { rows, metrics, chartData };
    }

    default:
      return { rows: [], metrics: [], chartData: [] };
  }
}

// Replay helper for "as-of past date" stock query
function replayStockAsOfDate(inventory: any[], movements: any[], asOfDate: string): any[] {
  // Start with current inventory and unwind movements occurring AFTER asOfDate
  const copied = JSON.parse(JSON.stringify(inventory));
  const skuMap: Record<string, any> = {};
  copied.forEach((item: any) => {
    skuMap[item.skuName || item.name] = item;
  });

  movements.forEach(m => {
    const d = m.date ? m.date.split('T')[0] : '';
    if (d > asOfDate) {
      const sku = skuMap[m.skuName];
      if (sku) {
        const qty = Number(m.qty || m.quantity || 0);
        const mType = (m.movementType || m.type || '').toLowerCase();
        // Unwind: if it was a grant/in, subtract it. If sale/out, add it back!
        if (mType.includes('grant') || mType.includes('in')) {
          sku.qtyOnHand = Math.max(0, (sku.qtyOnHand || sku.quantity || 0) - qty);
        } else if (mType.includes('sale') || mType.includes('out')) {
          sku.qtyOnHand = (sku.qtyOnHand || sku.quantity || 0) + qty;
        }
      }
    }
  });

  return Object.values(skuMap);
}

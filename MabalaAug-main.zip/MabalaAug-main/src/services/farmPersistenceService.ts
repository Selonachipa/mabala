import { safeLocalStorage as localStorage, safeParseJSON } from "../utils/safeStorage";
import { saveToOfflineStore, getFromOfflineStore, getAllFromOfflineStore } from "../db/offline_db";
import { INITIAL_ACCOUNTS } from "../data/initialAccounts";
import { koboCollectSyncService } from "./koboCollectSyncService";

export interface FarmNodeWorkspace {
  id: string; // Normalized email or tenantId, e.g. "deepvaleyfarm@gmail.com"
  email: string;
  tenantId: string;
  name: string;
  role: string;
  tenantType: string;
  subscriptionTier: string;
  workspaceMode: string;
  farmStatus: string;
  credits: number;
  smsCredits: number;
  farms: any[];
  accounts: any[];
  suppliers: any[];
  customers: any[];
  expenses: any[];
  invoices: any[];
  creditNotes: any[];
  quotations: any[];
  crops: any[];
  employees: any[];
  payslips: any[];
  poultry: any[];
  fish: any[];
  orchard_nursery_batches: any[];
  orchard_trees: any[];
  orchard_activities: any[];
  inventory: any[];
  cashSales: any[];
  loans: any[];
  investments: any[];
  livestock: any[];
  assets: any[];
  otherRevenues: any[];
  leaveRecords: any[];
  employeeAdvances: any[];
  auditLogs: any[];
  archivedRecords: any[];
  teamMembers: any[];
  contactDetails?: any;
  userProfile?: any;
  lastUpdated: string;
}

export interface FarmNodeRegistryEntry {
  id: string;
  email: string;
  farmName: string;
  tenantId: string;
  role: string;
  tenantType: string;
  lastActive: string;
  recordCount: number;
}

const STORAGE_PREFIX = "mabala_farm_snapshot_";
const BASE_REGISTRY_KEY = "mabala_farm_nodes_registry";
const DEEP_VALLEY_EMAIL = "deepvaleyfarm@gmail.com";
const DEEP_VALLEY_ALIAS = "deepvalleyfarm@gmail.com";

let activePersistenceScope = "guest";

export function setPersistenceScope(scope?: string | null): void {
  if (!scope) {
    activePersistenceScope = "guest";
  } else {
    activePersistenceScope = scope.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_") || "guest";
  }
}

export function getPersistenceScope(): string {
  return activePersistenceScope;
}

function getScopedRegistryKey(scope?: string): string {
  const s = scope || activePersistenceScope;
  if (!s || s === "guest") {
    return `${BASE_REGISTRY_KEY}_guest`;
  }
  return `${BASE_REGISTRY_KEY}_${s}`;
}

function normalizeIdentifier(idOrEmail: string): string {
  if (!idOrEmail) return "default_farm_node";
  return idOrEmail.trim().toLowerCase();
}

/**
 * Returns the default template workspace for a fresh farm node.
 */
export function getDefaultFarmNodeWorkspace(email: string = "", name?: string): FarmNodeWorkspace {
  const normEmail = normalizeIdentifier(email);
  const isDeepValley = Boolean(normEmail && (normEmail === DEEP_VALLEY_EMAIL || normEmail === DEEP_VALLEY_ALIAS));

  const farmName = name || (isDeepValley ? "Deep Valley Farms" : (normEmail ? `${normEmail.split('@')[0]} Farm Enterprise` : "Farm Enterprise Node"));
  const farmAddress = isDeepValley ? "Plot 401A, Mumbwa Road, Lusaka West, Zambia" : "";
  const farmPhone = isDeepValley ? "+260978070734" : "";
  const farmTpin = isDeepValley ? "1002345678" : "";

  const defaultFarms = [
    {
      id: "farm-1",
      name: farmName,
      letterheadTitle: farmName,
      tpin: farmTpin,
      vatNumber: farmTpin,
      address: farmAddress,
      province: "Lusaka",
      district: "Lusaka West",
      town: "Lusaka West",
      phone: farmPhone,
      email: normEmail,
      financialYearStart: "2026-01-01",
      financialYearEnd: "2026-12-31",
      currency: "ZMW",
      currencySymbol: "ZK",
      taxSystem: "VAT",
      logo: isDeepValley ? "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&q=80&w=200" : undefined
    }
  ];

  return {
    id: normEmail,
    email: normEmail,
    tenantId: isDeepValley ? "TENANT-DV-001" : `TENANT-${normEmail.replace(/[^a-z0-9]/g, "_")}`,
    name: farmName,
    role: "Farm Owner",
    tenantType: "farmer",
    subscriptionTier: "Commercial Growth Layer",
    workspaceMode: "Farmer",
    farmStatus: "ACTIVE",
    credits: 100,
    smsCredits: isDeepValley ? 100 : 50,
    farms: defaultFarms,
    accounts: INITIAL_ACCOUNTS.map(a => ({ ...a })),
    suppliers: [],
    customers: [],
    expenses: [],
    invoices: [],
    creditNotes: [],
    quotations: [],
    crops: [],
    employees: [],
    payslips: [],
    poultry: [],
    fish: [],
    orchard_nursery_batches: [],
    orchard_trees: [],
    orchard_activities: [],
    inventory: [],
    cashSales: [],
    loans: [],
    investments: [],
    livestock: [],
    assets: [],
    otherRevenues: [],
    leaveRecords: [],
    employeeAdvances: [],
    auditLogs: [],
    archivedRecords: [],
    teamMembers: [
      { id: "M1", name: farmName, email: normEmail, role: "Farm Owner", status: "Active", lastActive: "Just now" }
    ],
    contactDetails: {
      phone: farmPhone,
      email: normEmail,
      address: farmAddress
    },
    userProfile: {
      name: farmName,
      email: normEmail,
      phone: farmPhone,
      role: "Farm Owner",
      tenantType: "farmer"
    },
    lastUpdated: new Date().toISOString()
  };
}

export class FarmPersistenceService {
  /**
   * Persists a farm node workspace into multiple storage tiers:
   * 1. Scoped LocalStorage ("mabala_farm_snapshot_<id>")
   * 2. IndexedDB store ("user_settings" & "farmers")
   * 3. Global Farm Nodes Registry ("mabala_all_farm_nodes_registry")
   */
  public static async saveFarmNodeWorkspace(
    identifier: string,
    workspaceData: Partial<FarmNodeWorkspace>
  ): Promise<FarmNodeWorkspace> {
    const cleanId = normalizeIdentifier(identifier || workspaceData.email || workspaceData.id || "default_farm_node");
    const existing = await this.loadFarmNodeWorkspace(cleanId);

    // Merge existing with updated data
    const fullWorkspace: FarmNodeWorkspace = {
      ...(existing || getDefaultFarmNodeWorkspace(cleanId)),
      ...workspaceData,
      id: cleanId,
      email: workspaceData.email || existing?.email || cleanId,
      lastUpdated: new Date().toISOString()
    };

    const serialized = JSON.stringify(fullWorkspace);

    // 1. Save to Scoped LocalStorage
    try {
      localStorage.setItem(`${STORAGE_PREFIX}${cleanId}`, serialized);
      if (workspaceData.tenantId && workspaceData.tenantId !== cleanId) {
        localStorage.setItem(`${STORAGE_PREFIX}${normalizeIdentifier(workspaceData.tenantId)}`, serialized);
      }
      if (cleanId === DEEP_VALLEY_EMAIL || cleanId === DEEP_VALLEY_ALIAS) {
        localStorage.setItem(`${STORAGE_PREFIX}${DEEP_VALLEY_EMAIL}`, serialized);
        localStorage.setItem(`${STORAGE_PREFIX}${DEEP_VALLEY_ALIAS}`, serialized);
      }
    } catch (e) {
      console.warn("[FarmPersistence] Error saving to LocalStorage snapshot:", e);
    }

    // 2. Save to IndexedDB for ultra-durable storage
    try {
      await saveToOfflineStore("user_settings", {
        id: `workspace_${cleanId}`,
        data: fullWorkspace,
        updatedAt: fullWorkspace.lastUpdated
      });
      if (cleanId === DEEP_VALLEY_EMAIL || cleanId === DEEP_VALLEY_ALIAS) {
        await saveToOfflineStore("user_settings", {
          id: `workspace_${DEEP_VALLEY_EMAIL}`,
          data: fullWorkspace,
          updatedAt: fullWorkspace.lastUpdated
        });
      }

      // Also persist individual collections into their dedicated IndexedDB stores
      if (fullWorkspace.crops && fullWorkspace.crops.length > 0) {
        for (const c of fullWorkspace.crops) {
          if (c && c.id) await saveToOfflineStore("crops", { ...c, tenantId: cleanId });
        }
      }
      if (fullWorkspace.expenses && fullWorkspace.expenses.length > 0) {
        for (const exp of fullWorkspace.expenses) {
          if (exp && exp.id) await saveToOfflineStore("finance", { ...exp, tenantId: cleanId });
        }
      }
      if (fullWorkspace.inventory && fullWorkspace.inventory.length > 0) {
        for (const inv of fullWorkspace.inventory) {
          if (inv && inv.id) await saveToOfflineStore("inventory", { ...inv, tenantId: cleanId });
        }
      }
      if (fullWorkspace.employees && fullWorkspace.employees.length > 0) {
        for (const emp of fullWorkspace.employees) {
          if (emp && emp.id) await saveToOfflineStore("employees", { ...emp, tenantId: cleanId });
        }
      }
      if (fullWorkspace.livestock && fullWorkspace.livestock.length > 0) {
        for (const ls of fullWorkspace.livestock) {
          if (ls && ls.id) await saveToOfflineStore("livestock", { ...ls, tenantId: cleanId });
        }
      }
      if (fullWorkspace.poultry && fullWorkspace.poultry.length > 0) {
        for (const p of fullWorkspace.poultry) {
          if (p && p.id) await saveToOfflineStore("poultry", { ...p, tenantId: cleanId });
        }
      }
    } catch (idbErr) {
      console.warn("[FarmPersistence] Error saving to IndexedDB user_settings:", idbErr);
    }

    // 3. Register KoboCollect submission envelope for crops & expenses if non-empty
    try {
      if (fullWorkspace.crops && fullWorkspace.crops.length > 0) {
        koboCollectSyncService.saveCollectionOffline("crops", fullWorkspace.crops, cleanId, fullWorkspace.email);
      }
      if (fullWorkspace.expenses && fullWorkspace.expenses.length > 0) {
        koboCollectSyncService.saveCollectionOffline("expenses", fullWorkspace.expenses, cleanId, fullWorkspace.email);
      }
    } catch (koboErr) {
      console.warn("[FarmPersistence] KoboCollect collection queue notice:", koboErr);
    }

    // 4. Update global farm node registry
    try {
      this.updateNodeRegistry(fullWorkspace);
    } catch (regErr) {
      console.warn("[FarmPersistence] Error updating node registry:", regErr);
    }

    return fullWorkspace;
  }

  /**
   * Loads a farm node workspace from local storage tiers.
   */
  public static async loadFarmNodeWorkspace(identifier: string): Promise<FarmNodeWorkspace | null> {
    const cleanId = normalizeIdentifier(identifier);
    if (!cleanId) return null;

    let loadedWorkspace: FarmNodeWorkspace | null = null;

    // 1. Check Scoped LocalStorage
    try {
      const localStr = localStorage.getItem(`${STORAGE_PREFIX}${cleanId}`);
      if (localStr) {
        const parsed = safeParseJSON<FarmNodeWorkspace | null>(localStr, null);
        if (parsed && typeof parsed === "object") {
          loadedWorkspace = parsed;
        }
      }

      // Check alias for Deep Valley
      if (!loadedWorkspace && (cleanId === DEEP_VALLEY_EMAIL || cleanId === DEEP_VALLEY_ALIAS)) {
        const altStr = localStorage.getItem(`${STORAGE_PREFIX}${cleanId === DEEP_VALLEY_EMAIL ? DEEP_VALLEY_ALIAS : DEEP_VALLEY_EMAIL}`);
        if (altStr) {
          const parsed = safeParseJSON<FarmNodeWorkspace | null>(altStr, null);
          if (parsed) loadedWorkspace = parsed;
        }
      }
    } catch (e) {
      console.warn("[FarmPersistence] Error reading LocalStorage snapshot:", e);
    }

    // 2. Check IndexedDB
    if (!loadedWorkspace) {
      try {
        const idbDoc = await getFromOfflineStore("user_settings", `workspace_${cleanId}`);
        if (idbDoc && idbDoc.data) {
          loadedWorkspace = idbDoc.data as FarmNodeWorkspace;
        }
        if (!loadedWorkspace && (cleanId === DEEP_VALLEY_EMAIL || cleanId === DEEP_VALLEY_ALIAS)) {
          const altDoc = await getFromOfflineStore("user_settings", `workspace_${DEEP_VALLEY_EMAIL}`);
          if (altDoc && altDoc.data) {
            loadedWorkspace = altDoc.data as FarmNodeWorkspace;
          }
        }
      } catch (idbErr) {
        console.warn("[FarmPersistence] Error reading IndexedDB workspace:", idbErr);
      }
    }

    // 3. Check individual IndexedDB stores for crops ONLY if matching this specific tenant
    if (loadedWorkspace && (!loadedWorkspace.crops || loadedWorkspace.crops.length === 0)) {
      try {
        const idbCrops = await getAllFromOfflineStore("crops");
        if (Array.isArray(idbCrops) && idbCrops.length > 0) {
          const matching = idbCrops.filter(c => c.tenantId === cleanId);
          if (matching.length > 0) {
            loadedWorkspace.crops = matching;
          }
        }
      } catch (e) {}
    }

    // 4. If deepvaleyfarm@gmail.com and no prior record found, generate default workspace
    if (!loadedWorkspace && (cleanId === DEEP_VALLEY_EMAIL || cleanId === DEEP_VALLEY_ALIAS)) {
      const defaultWs = getDefaultFarmNodeWorkspace(cleanId);
      this.saveFarmNodeWorkspace(cleanId, defaultWs).catch(() => {});
      return defaultWs;
    }

    return loadedWorkspace;
  }

  /**
  * Clears all active un-scoped localStorage keys so no cross-tenant residue remains.
  */
  public static clearActiveLocalStorageKeys(options?: { purgeIdentity?: boolean; purgeFarmDetails?: boolean; scope?: string }): void {
    const keys = [
      "mabala_farms", "mabala_accounts", "mabala_suppliers", "mabala_customers",
      "mabala_expenses", "mabala_invoices", "mabala_credit_notes", "mabala_quotations",
      "mabala_crops", "mabala_employees", "mabala_payslips", "mabala_poultry",
      "mabala_fish", "mabala_orchard_nursery_batches", "mabala_orchard_trees",
      "mabala_orchard_activities", "mabala_inventory", "mabala_cash_sales",
      "mabala_loans", "mabala_investments", "mabala_livestock", "mabala_assets",
      "mabala_other_revenues", "mabala_leave_records", "mabala_employee_advances",
      "mabala_audit_logs", "mabala_archived_records", "mabala_team_members",
      "mabala_active_tab", "mabala_contact_details", "mabala_credits", "mabala_sms_credits",
      "mabala_subscription_tier", "mabala_workspace_mode", "mabala_farm_status",
      "mabala_active_farm"
    ];

    if (options?.purgeFarmDetails || options?.purgeIdentity) {
      keys.push(
        "mabala_registered_farm_name",
        "mabala_farm_name",
        "mabala_farm_province",
        "mabala_farm_district",
        "mabala_farm_phone",
        "mabala_farm_email",
        "mabala_farm_tpin",
        "mabala_farm_address",
        "mabala_farm_tax_type",
        "mabala_farm_currency",
        "mabala_farm_custom_tax_name",
        "mabala_farm_custom_tax_rate"
      );
    }

    if (options?.purgeIdentity) {
      keys.push(
        "mabala_user_profile",
        "mabala_persistence_backup_v1",
        "mabala_current_session_uid",
        "mabala_current_session_email",
        "mabala_all_farm_nodes_registry"
      );

      // Clean scoped keys for this scope if provided
      if (options.scope) {
        const clean = options.scope.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
        keys.push(
          `mabala_user_profile_${clean}`,
          `mabala_farm_nodes_registry_${clean}`,
          `${STORAGE_PREFIX}${clean}`
        );
      }
    }

    keys.forEach(k => {
      try {
        localStorage.removeItem(k);
      } catch (_) {}
    });
  }

  /**
   * Synchronizes active localStorage keys (e.g. "mabala_crops", "mabala_expenses")
   * with the given workspace so that all React components can read updated data immediately.
   */
  public static populateActiveLocalStorageKeys(workspace: FarmNodeWorkspace): void {
    if (!workspace) return;
    try {
      this.clearActiveLocalStorageKeys();
      if (workspace.farms && workspace.farms.length > 0) localStorage.setItem("mabala_farms", JSON.stringify(workspace.farms));
      if (workspace.accounts && workspace.accounts.length > 0) localStorage.setItem("mabala_accounts", JSON.stringify(workspace.accounts));
      if (workspace.suppliers) localStorage.setItem("mabala_suppliers", JSON.stringify(workspace.suppliers));
      if (workspace.customers) localStorage.setItem("mabala_customers", JSON.stringify(workspace.customers));
      if (workspace.expenses) localStorage.setItem("mabala_expenses", JSON.stringify(workspace.expenses));
      if (workspace.invoices) localStorage.setItem("mabala_invoices", JSON.stringify(workspace.invoices));
      if (workspace.creditNotes) localStorage.setItem("mabala_credit_notes", JSON.stringify(workspace.creditNotes));
      if (workspace.quotations) localStorage.setItem("mabala_quotations", JSON.stringify(workspace.quotations));
      if (workspace.crops) localStorage.setItem("mabala_crops", JSON.stringify(workspace.crops));
      if (workspace.employees) localStorage.setItem("mabala_employees", JSON.stringify(workspace.employees));
      if (workspace.payslips) localStorage.setItem("mabala_payslips", JSON.stringify(workspace.payslips));
      if (workspace.poultry) localStorage.setItem("mabala_poultry", JSON.stringify(workspace.poultry));
      if (workspace.fish) localStorage.setItem("mabala_fish", JSON.stringify(workspace.fish));
      if (workspace.orchard_nursery_batches) localStorage.setItem("mabala_orchard_nursery_batches", JSON.stringify(workspace.orchard_nursery_batches));
      if (workspace.orchard_trees) localStorage.setItem("mabala_orchard_trees", JSON.stringify(workspace.orchard_trees));
      if (workspace.orchard_activities) localStorage.setItem("mabala_orchard_activities", JSON.stringify(workspace.orchard_activities));
      if (workspace.inventory) localStorage.setItem("mabala_inventory", JSON.stringify(workspace.inventory));
      if (workspace.cashSales) localStorage.setItem("mabala_cash_sales", JSON.stringify(workspace.cashSales));
      if (workspace.loans) localStorage.setItem("mabala_loans", JSON.stringify(workspace.loans));
      if (workspace.investments) localStorage.setItem("mabala_investments", JSON.stringify(workspace.investments));
      if (workspace.livestock) localStorage.setItem("mabala_livestock", JSON.stringify(workspace.livestock));
      if (workspace.assets) localStorage.setItem("mabala_assets", JSON.stringify(workspace.assets));
      if (workspace.otherRevenues) localStorage.setItem("mabala_other_revenues", JSON.stringify(workspace.otherRevenues));
      if (workspace.leaveRecords) localStorage.setItem("mabala_leave_records", JSON.stringify(workspace.leaveRecords));
      if (workspace.employeeAdvances) localStorage.setItem("mabala_employee_advances", JSON.stringify(workspace.employeeAdvances));
      if (workspace.auditLogs) localStorage.setItem("mabala_audit_logs", JSON.stringify(workspace.auditLogs));
      if (workspace.archivedRecords) localStorage.setItem("mabala_archived_records", JSON.stringify(workspace.archivedRecords));
      if (workspace.teamMembers) localStorage.setItem("mabala_team_members", JSON.stringify(workspace.teamMembers));
      if (workspace.subscriptionTier) localStorage.setItem("mabala_subscription_tier", workspace.subscriptionTier);
      if (workspace.workspaceMode) localStorage.setItem("mabala_workspace_mode", workspace.workspaceMode);
      if (workspace.farmStatus) localStorage.setItem("mabala_farm_status", workspace.farmStatus);
      if (workspace.credits !== undefined && workspace.credits !== null) localStorage.setItem("mabala_credits", String(workspace.credits));
      if (workspace.smsCredits !== undefined && workspace.smsCredits !== null) localStorage.setItem("mabala_sms_credits", String(workspace.smsCredits));
      if (workspace.userProfile) localStorage.setItem("mabala_user_profile", JSON.stringify(workspace.userProfile));
      if (workspace.contactDetails) localStorage.setItem("mabala_contact_details", JSON.stringify(workspace.contactDetails));
    } catch (err) {
      console.warn("[FarmPersistence] Error populating active localStorage keys:", err);
    }
  }

  /**
   * Captures the full active state from current in-memory props and safely saves to the farm node.
   */
  public static async captureAndSaveCurrentState(
    identifier: string,
    stateSlices: {
      farms?: any[];
      accounts?: any[];
      suppliers?: any[];
      customers?: any[];
      expenses?: any[];
      invoices?: any[];
      creditNotes?: any[];
      quotations?: any[];
      crops?: any[];
      employees?: any[];
      payslips?: any[];
      poultry?: any[];
      fish?: any[];
      orchard_nursery_batches?: any[];
      orchard_trees?: any[];
      orchard_activities?: any[];
      inventory?: any[];
      cashSales?: any[];
      loans?: any[];
      investments?: any[];
      livestock?: any[];
      assets?: any[];
      otherRevenues?: any[];
      leaveRecords?: any[];
      employeeAdvances?: any[];
      auditLogs?: any[];
      archivedRecords?: any[];
      teamMembers?: any[];
      credits?: number | null;
      smsCredits?: number;
      subscriptionTier?: string;
      workspaceMode?: string;
      farmStatus?: string;
      userProfile?: any;
      contactDetails?: any;
    }
  ): Promise<FarmNodeWorkspace> {
    const cleanId = normalizeIdentifier(identifier || stateSlices.userProfile?.email || "default_farm_node");
    const isDeepValley = cleanId === DEEP_VALLEY_EMAIL || cleanId === DEEP_VALLEY_ALIAS;
    
    // Count records to check if valid non-empty state
    const hasData = (
      (stateSlices.crops && stateSlices.crops.length > 0) ||
      (stateSlices.expenses && stateSlices.expenses.length > 0) ||
      (stateSlices.invoices && stateSlices.invoices.length > 0) ||
      (stateSlices.livestock && stateSlices.livestock.length > 0) ||
      (stateSlices.poultry && stateSlices.poultry.length > 0) ||
      (stateSlices.fish && stateSlices.fish.length > 0) ||
      (stateSlices.inventory && stateSlices.inventory.length > 0) ||
      (stateSlices.farms && stateSlices.farms.length > 0)
    );

    const updatePayload: Partial<FarmNodeWorkspace> = {
      id: cleanId,
      email: stateSlices.userProfile?.email || cleanId,
      tenantId: stateSlices.userProfile?.tenantId || (stateSlices.farms?.[0]?.id) || cleanId,
      name: stateSlices.farms?.[0]?.name || stateSlices.userProfile?.name || cleanId,
      role: stateSlices.userProfile?.role || "Farm Owner",
      tenantType: stateSlices.userProfile?.tenantType || "farmer",
      subscriptionTier: stateSlices.subscriptionTier || "Commercial Growth Layer",
      workspaceMode: stateSlices.workspaceMode || "Farmer",
      farmStatus: stateSlices.farmStatus || "ACTIVE",
      credits: stateSlices.credits ?? 100,
      smsCredits: stateSlices.smsCredits ?? (isDeepValley ? 100 : 50),
      farms: stateSlices.farms || [],
      accounts: stateSlices.accounts || [],
      suppliers: stateSlices.suppliers || [],
      customers: stateSlices.customers || [],
      expenses: stateSlices.expenses || [],
      invoices: stateSlices.invoices || [],
      creditNotes: stateSlices.creditNotes || [],
      quotations: stateSlices.quotations || [],
      crops: stateSlices.crops || [],
      employees: stateSlices.employees || [],
      payslips: stateSlices.payslips || [],
      poultry: stateSlices.poultry || [],
      fish: stateSlices.fish || [],
      orchard_nursery_batches: stateSlices.orchard_nursery_batches || [],
      orchard_trees: stateSlices.orchard_trees || [],
      orchard_activities: stateSlices.orchard_activities || [],
      inventory: stateSlices.inventory || [],
      cashSales: stateSlices.cashSales || [],
      loans: stateSlices.loans || [],
      investments: stateSlices.investments || [],
      livestock: stateSlices.livestock || [],
      assets: stateSlices.assets || [],
      otherRevenues: stateSlices.otherRevenues || [],
      leaveRecords: stateSlices.leaveRecords || [],
      employeeAdvances: stateSlices.employeeAdvances || [],
      auditLogs: stateSlices.auditLogs || [],
      archivedRecords: stateSlices.archivedRecords || [],
      teamMembers: stateSlices.teamMembers || [],
      contactDetails: stateSlices.contactDetails,
      userProfile: stateSlices.userProfile
    };

    return this.saveFarmNodeWorkspace(cleanId, updatePayload);
  }

  /**
   * Tracks all nodes in a scoped directory for instant listing and recovery.
   * Guarantees tenant isolation so tenants cannot read each other's registry.
   */
  private static updateNodeRegistry(workspace: FarmNodeWorkspace, scope?: string): void {
    const registryKey = getScopedRegistryKey(scope || workspace.email || workspace.tenantId);
    const raw = localStorage.getItem(registryKey);
    const registry: Record<string, FarmNodeRegistryEntry> = raw ? safeParseJSON(raw, {}) : {};

    const totalRecords = (workspace.crops?.length || 0) +
      (workspace.expenses?.length || 0) +
      (workspace.invoices?.length || 0) +
      (workspace.livestock?.length || 0) +
      (workspace.poultry?.length || 0) +
      (workspace.fish?.length || 0) +
      (workspace.inventory?.length || 0);

    registry[workspace.id] = {
      id: workspace.id,
      email: workspace.email,
      farmName: workspace.name,
      tenantId: workspace.tenantId,
      role: workspace.role,
      tenantType: workspace.tenantType,
      lastActive: workspace.lastUpdated,
      recordCount: totalRecords
    };

    localStorage.setItem(registryKey, JSON.stringify(registry));
  }

  /**
   * Returns list of all farm nodes registered under the current active session scope.
   */
  public static getAllRegisteredNodes(scope?: string): FarmNodeRegistryEntry[] {
    const registryKey = getScopedRegistryKey(scope);
    const raw = localStorage.getItem(registryKey);
    const registry: Record<string, FarmNodeRegistryEntry> = raw ? safeParseJSON(raw, {}) : {};
    return Object.values(registry);
  }

  /**
   * Purges all node registries on this device (for complete security reset/logout).
   */
  public static clearAllNodeRegistries(): void {
    try {
      const keys = Object.keys(localStorage);
      keys.forEach(k => {
        if (k.startsWith(BASE_REGISTRY_KEY) || k === "mabala_all_farm_nodes_registry") {
          localStorage.removeItem(k);
        }
      });
    } catch (_) {}
  }
}

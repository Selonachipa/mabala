import { useState, useEffect } from "react";
import { auth } from "../firebase";
import { onAuthStateChanged, User } from "firebase/auth";

export const SUPER_ADMIN_EMAILS = [
  "support@mabala.cloud",
  "shikasuli@gmail.com"
];

export function checkIsSuperAdminUser(userEmail?: string | null): boolean {
  try {
    let email = (userEmail || auth.currentUser?.email || "").trim().toLowerCase();

    if (!email && typeof window !== "undefined") {
      const cachedProfileStr = localStorage.getItem("mabala_user_profile");
      if (cachedProfileStr) {
        try {
          const p = JSON.parse(cachedProfileStr);
          if (p.email) email = String(p.email).trim().toLowerCase();
        } catch (e) {}
      }
    }

    return SUPER_ADMIN_EMAILS.includes(email);
  } catch (e) {
    return false;
  }
}

export function useSuperAdmin() {
  const [isSuperAdmin, setIsSuperAdmin] = useState<boolean>(() => checkIsSuperAdminUser(auth.currentUser?.email));
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    setIsSuperAdmin(checkIsSuperAdminUser(auth.currentUser?.email));
    setIsLoading(false);

    const unsubscribe = onAuthStateChanged(auth, (user: User | null) => {
      setIsSuperAdmin(checkIsSuperAdminUser(user?.email));
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return { isSuperAdmin, isLoading };
}

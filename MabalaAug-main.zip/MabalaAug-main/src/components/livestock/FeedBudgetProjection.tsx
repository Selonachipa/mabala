import React, { useMemo } from "react";
import { 
  Calculator, 
  TrendingUp, 
  Layers, 
  Download, 
  Printer, 
  DollarSign, 
  Scale, 
  Beef,
  Sparkles
} from "lucide-react";
import { 
  FeedFormulation, 
  PenRecord, 
  AnimalTypeConfig 
} from "../../types";
import { DEFAULT_ANIMAL_TYPES, getTenantPens } from "../../services/feedEngineService";

interface FeedBudgetProjectionProps {
  tenantId?: string;
  currencySymbol?: string;
  formulations: FeedFormulation[];
  animalTypes?: AnimalTypeConfig[];
}

export default function FeedBudgetProjection({
  tenantId = "default",
  currencySymbol = "ZMW",
  formulations,
  animalTypes = DEFAULT_ANIMAL_TYPES
}: FeedBudgetProjectionProps) {
  const pens = useMemo(() => getTenantPens(tenantId), [tenantId]);

  // Group pens and headcounts per growth stage
  const stageProjections = useMemo(() => {
    // Get all unique pig stages
    const pigConfig = animalTypes.find(a => a.id === "pig") || animalTypes[0];
    const stages = pigConfig?.stages || [
      { id: "creep", name: "Creep / Suckling" },
      { id: "weaner", name: "Weaner" },
      { id: "grower", name: "Grower" },
      { id: "finisher", name: "Finisher" },
      { id: "breeding", name: "Sow & Boar / Breeding" },
      { id: "lactating", name: "Lactating Sow" }
    ];

    return stages.map(stage => {
      // Find active formulation for this stage
      const form = formulations.find(
        f => f.stageId.toLowerCase() === stage.id.toLowerCase() && f.status === "active"
      );

      // Sum headcounts from pens in this stage
      const stagePens = pens.filter(p => p.stageId.toLowerCase() === stage.id.toLowerCase());
      const headcount = stagePens.reduce((sum, p) => sum + p.headcount, 0);

      const dailyKgPerHead = form?.dailyQtyPerAnimal || 0;
      const dailyTotalKg = headcount * dailyKgPerHead;
      const monthlyTotalKg = dailyTotalKg * 30;
      const costPerKg = form?.costPerKgMix || 0;
      const dailyCostTotal = dailyTotalKg * costPerKg;
      const monthlyCostTotal = monthlyTotalKg * costPerKg;

      return {
        stageId: stage.id,
        stageName: stage.name,
        penCount: stagePens.length,
        headcount,
        formulationName: form ? `${form.name} (v${form.version})` : "No Active Formulation",
        hasFormulation: !!form,
        dailyKgPerHead,
        dailyTotalKg: Number(dailyTotalKg.toFixed(1)),
        monthlyTotalKg: Number(monthlyTotalKg.toFixed(1)),
        costPerKg: Number(costPerKg.toFixed(4)),
        dailyCostTotal: Number(dailyCostTotal.toFixed(2)),
        monthlyCostTotal: Number(monthlyCostTotal.toFixed(2))
      };
    });
  }, [pens, formulations, animalTypes]);

  // Summary totals
  const totals = useMemo(() => {
    return stageProjections.reduce(
      (acc, s) => ({
        headcount: acc.headcount + s.headcount,
        dailyTotalKg: acc.dailyTotalKg + s.dailyTotalKg,
        monthlyTotalKg: acc.monthlyTotalKg + s.monthlyTotalKg,
        dailyCostTotal: acc.dailyCostTotal + s.dailyCostTotal,
        monthlyCostTotal: acc.monthlyCostTotal + s.monthlyCostTotal
      }),
      { headcount: 0, dailyTotalKg: 0, monthlyTotalKg: 0, dailyCostTotal: 0, monthlyCostTotal: 0 }
    );
  }, [stageProjections]);

  // Export CSV function
  const handleExportCSV = () => {
    const headers = ["Growth Stage,Headcount,Active Recipe,Daily Kg/Head,Daily Total Kg,Monthly Total Kg (30 days),Cost/kg Mix (ZMW),Daily Cost Total (ZMW),Monthly Feed Budget (ZMW)"];
    const rows = stageProjections.map(s => 
      `"${s.stageName}",${s.headcount},"${s.formulationName}",${s.dailyKgPerHead},${s.dailyTotalKg},${s.monthlyTotalKg},${s.costPerKg},${s.dailyCostTotal},${s.monthlyCostTotal}`
    );
    const summaryRow = `TOTAL,${totals.headcount},-,,-,${totals.dailyTotalKg.toFixed(1)},${totals.monthlyTotalKg.toFixed(1)},-,${totals.dailyCostTotal.toFixed(2)},${totals.monthlyCostTotal.toFixed(2)}`;
    const csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows, summaryRow].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Feed_Budget_Projection_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h3 className="font-black text-slate-900 text-lg flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-600" />
            Live Feed Budget & Monthly Projection Engine
          </h3>
          <p className="text-slate-500 text-xs">
            Mirrors the Excel "Type / Headcount" projection table — live calculated feed requirements & monthly budget per growth stage.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" /> Print Sheet
          </button>
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>
      </div>

      {/* KPI HIGHLIGHT CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-emerald-900 text-white p-4 rounded-xl space-y-1 shadow-md">
          <span className="block text-[10px] font-bold uppercase text-emerald-300">Total Monthly Feed Budget</span>
          <div className="text-2xl font-black text-emerald-400">
            {currencySymbol} {totals.monthlyCostTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <p className="text-[10px] text-emerald-200/80">30-day forecast based on current herd headcount</p>
        </div>

        <div className="bg-slate-900 text-white p-4 rounded-xl space-y-1 shadow-md">
          <span className="block text-[10px] font-bold uppercase text-slate-400">Monthly Feed Quantity</span>
          <div className="text-2xl font-black text-teal-300">
            {totals.monthlyTotalKg.toLocaleString()} kg
          </div>
          <p className="text-[10px] text-slate-400">≈ {(totals.monthlyTotalKg / 50).toFixed(0)} bags (50kg basis)</p>
        </div>

        <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-1">
          <span className="block text-[10px] font-bold uppercase text-slate-500">Active Herd Headcount</span>
          <div className="text-2xl font-black text-slate-900">
            {totals.headcount} Pigs
          </div>
          <p className="text-[10px] text-slate-500">Spread across {pens.length} active pens</p>
        </div>
      </div>

      {/* PROJECTION TABLE */}
      <div className="overflow-x-auto rounded-xl border border-slate-200">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-100 text-slate-700 uppercase font-black text-[10px] border-b border-slate-200">
              <th className="py-3 px-3">Growth Stage</th>
              <th className="py-3 px-3 text-right">Headcount</th>
              <th className="py-3 px-3">Active Recipe / Formulation</th>
              <th className="py-3 px-3 text-right">Daily Kg / Head</th>
              <th className="py-3 px-3 text-right">Daily Total Kg</th>
              <th className="py-3 px-3 text-right">Monthly Total Kg (30d)</th>
              <th className="py-3 px-3 text-right">Cost / Kg Mix</th>
              <th className="py-3 px-3 text-right">Daily Cost</th>
              <th className="py-3 px-3 text-right">Monthly Cost ({currencySymbol})</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
            {stageProjections.map(s => (
              <tr key={s.stageId} className="hover:bg-slate-50 transition-colors">
                <td className="py-3 px-3 font-extrabold text-slate-900">
                  {s.stageName}
                  <span className="block text-[10px] text-slate-400 font-normal">{s.penCount} pens assigned</span>
                </td>
                <td className="py-3 px-3 text-right font-black text-slate-900">{s.headcount}</td>
                <td className="py-3 px-3 font-semibold">
                  <span className={s.hasFormulation ? "text-emerald-800 font-bold" : "text-amber-700 italic"}>
                    {s.formulationName}
                  </span>
                </td>
                <td className="py-3 px-3 text-right font-bold text-slate-700">{s.dailyKgPerHead} kg</td>
                <td className="py-3 px-3 text-right font-extrabold text-slate-900">{s.dailyTotalKg} kg</td>
                <td className="py-3 px-3 text-right font-black text-teal-700">{s.monthlyTotalKg} kg</td>
                <td className="py-3 px-3 text-right font-mono text-slate-600">{currencySymbol} {s.costPerKg.toFixed(2)}</td>
                <td className="py-3 px-3 text-right font-bold text-slate-900">{currencySymbol} {s.dailyCostTotal.toFixed(2)}</td>
                <td className="py-3 px-3 text-right font-black text-emerald-700">{currencySymbol} {s.monthlyCostTotal.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-slate-900 text-white font-extrabold text-xs">
            <tr>
              <td className="py-3 px-3">TOTAL HERD FEED BUDGET</td>
              <td className="py-3 px-3 text-right text-emerald-400">{totals.headcount}</td>
              <td className="py-3 px-3 text-slate-400 text-[10px]">—</td>
              <td className="py-3 px-3 text-slate-400 text-[10px]">—</td>
              <td className="py-3 px-3 text-right text-amber-300">{totals.dailyTotalKg.toFixed(1)} kg</td>
              <td className="py-3 px-3 text-right text-teal-300">{totals.monthlyTotalKg.toFixed(1)} kg</td>
              <td className="py-3 px-3 text-slate-400 text-[10px]">—</td>
              <td className="py-3 px-3 text-right text-emerald-300">{currencySymbol} {totals.dailyCostTotal.toFixed(2)}</td>
              <td className="py-3 px-3 text-right text-emerald-400 text-sm font-black">
                {currencySymbol} {totals.monthlyCostTotal.toFixed(2)}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}

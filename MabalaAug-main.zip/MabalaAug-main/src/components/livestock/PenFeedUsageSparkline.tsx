import React, { useMemo } from "react";
import { DailyFeedLog } from "../../types";
import { TrendingUp, TrendingDown, Activity, Calendar, Scale, DollarSign, Clock } from "lucide-react";

interface PenFeedUsageSparklineProps {
  penCode: string;
  dailyLogs: DailyFeedLog[];
  days?: number;
  currencySymbol?: string;
  variant?: "mini" | "card" | "full";
  onSelectDate?: (date: string) => void;
}

export default function PenFeedUsageSparkline({
  penCode,
  dailyLogs,
  days = 7,
  currencySymbol = "ZMW",
  variant = "card",
  onSelectDate
}: PenFeedUsageSparklineProps) {
  // Filter logs for this pen code / cohort
  const penLogs = useMemo(() => {
    const cleanTarget = penCode.trim().toUpperCase();
    return dailyLogs
      .filter(l => l.cohortId && l.cohortId.trim().toUpperCase() === cleanTarget)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [dailyLogs, penCode]);

  // Compute daily series for the last N days
  const timeSeries = useMemo(() => {
    const dates: string[] = [];
    const now = new Date();
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      dates.push(d.toISOString().split("T")[0]);
    }

    const logMap: Record<string, { qtyKg: number; cost: number; headFed: number; logId?: string }> = {};
    penLogs.forEach(l => {
      if (!logMap[l.date]) {
        logMap[l.date] = { qtyKg: 0, cost: 0, headFed: 0, logId: l.id };
      }
      logMap[l.date].qtyKg += l.totalQuantityFedKg;
      logMap[l.date].cost += l.totalCost;
      logMap[l.date].headFed = Math.max(logMap[l.date].headFed, l.numberOfAnimalsFed);
    });

    const series = dates.map(date => {
      const entry = logMap[date] || { qtyKg: 0, cost: 0, headFed: 0 };
      return {
        date,
        displayDate: date.slice(5), // MM-DD
        qtyKg: Number(entry.qtyKg.toFixed(1)),
        cost: Number(entry.cost.toFixed(2)),
        headFed: entry.headFed,
        hasLog: !!logMap[date]
      };
    });

    const totalPeriodKg = series.reduce((sum, item) => sum + item.qtyKg, 0);
    const totalPeriodCost = series.reduce((sum, item) => sum + item.cost, 0);
    const activeDays = series.filter(s => s.hasLog).length;
    const avgDailyKg = activeDays > 0 ? totalPeriodKg / activeDays : 0;
    const maxQty = Math.max(...series.map(s => s.qtyKg), 10);
    const minQty = Math.min(...series.map(s => s.qtyKg));

    // Calculate trend percentage (first half vs second half)
    const midPoint = Math.floor(series.length / 2);
    const firstHalfAvg = series.slice(0, midPoint).reduce((a, b) => a + b.qtyKg, 0) / (midPoint || 1);
    const secondHalfAvg = series.slice(midPoint).reduce((a, b) => a + b.qtyKg, 0) / (series.length - midPoint || 1);
    const trendPercent = firstHalfAvg > 0 ? ((secondHalfAvg - firstHalfAvg) / firstHalfAvg) * 100 : 0;

    return {
      series,
      totalPeriodKg: Number(totalPeriodKg.toFixed(1)),
      totalPeriodCost: Number(totalPeriodCost.toFixed(2)),
      avgDailyKg: Number(avgDailyKg.toFixed(1)),
      maxQty,
      minQty,
      activeDays,
      trendPercent: Number(trendPercent.toFixed(1))
    };
  }, [penLogs, days]);

  // SVG Sparkline path coordinates
  const svgMetrics = useMemo(() => {
    const width = 180;
    const height = 36;
    const padding = 4;
    const points = timeSeries.series.map((item, idx) => {
      const x = padding + (idx / Math.max(timeSeries.series.length - 1, 1)) * (width - 2 * padding);
      const ratio = timeSeries.maxQty > 0 ? item.qtyKg / timeSeries.maxQty : 0;
      const y = height - padding - ratio * (height - 2 * padding);
      return { x, y, item };
    });

    const pathD = points.length > 0
      ? `M ${points.map(p => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" L ")}`
      : "";

    const areaD = points.length > 0
      ? `${pathD} L ${points[points.length - 1].x.toFixed(1)},${height} L ${points[0].x.toFixed(1)},${height} Z`
      : "";

    return { width, height, points, pathD, areaD };
  }, [timeSeries]);

  if (variant === "mini") {
    return (
      <div className="flex items-center gap-2">
        <svg
          viewBox={`0 0 ${svgMetrics.width} ${svgMetrics.height}`}
          className="w-24 h-7 overflow-visible"
        >
          <defs>
            <linearGradient id={`grad-mini-${penCode}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
            </linearGradient>
          </defs>
          {svgMetrics.areaD && <path d={svgMetrics.areaD} fill={`url(#grad-mini-${penCode})`} />}
          {svgMetrics.pathD && (
            <path
              d={svgMetrics.pathD}
              fill="none"
              stroke="#059669"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}
          {svgMetrics.points.map((pt, i) => (
            pt.item.hasLog && (
              <circle
                key={i}
                cx={pt.x}
                cy={pt.y}
                r="2"
                className="fill-emerald-600 ring-2 ring-white"
              />
            )
          ))}
        </svg>
        <div className="text-[10px] font-bold text-slate-600">
          <span className="text-emerald-700 font-extrabold">{timeSeries.avgDailyKg} kg/d</span>
          <span className="text-slate-400 block">{days}d avg</span>
        </div>
      </div>
    );
  }

  if (variant === "card") {
    return (
      <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200/80 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-slate-700 flex items-center gap-1">
            <Activity className="w-3.5 h-3.5 text-emerald-600" />
            {days}-Day Feed Intake Trend
          </span>
          <span className={`text-[10px] font-extrabold flex items-center gap-0.5 ${
            timeSeries.trendPercent > 0 ? "text-emerald-700" : timeSeries.trendPercent < 0 ? "text-amber-700" : "text-slate-500"
          }`}>
            {timeSeries.trendPercent > 0 ? <TrendingUp className="w-3 h-3" /> : timeSeries.trendPercent < 0 ? <TrendingDown className="w-3 h-3" /> : null}
            {timeSeries.trendPercent > 0 ? `+${timeSeries.trendPercent}%` : `${timeSeries.trendPercent}%`}
          </span>
        </div>

        {/* SVG Sparkline Chart */}
        <div className="relative pt-1">
          <svg
            viewBox={`0 0 ${svgMetrics.width} ${svgMetrics.height}`}
            className="w-full h-10 overflow-visible"
          >
            <defs>
              <linearGradient id={`grad-card-${penCode}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="0.02" />
              </linearGradient>
            </defs>
            {/* Background gridlines */}
            <line x1="0" y1={svgMetrics.height - 4} x2={svgMetrics.width} y2={svgMetrics.height - 4} stroke="#e2e8f0" strokeDasharray="2,2" strokeWidth="0.8" />
            <line x1="0" y1="4" x2={svgMetrics.width} y2="4" stroke="#e2e8f0" strokeDasharray="2,2" strokeWidth="0.8" />

            {svgMetrics.areaD && <path d={svgMetrics.areaD} fill={`url(#grad-card-${penCode})`} />}
            {svgMetrics.pathD && (
              <path
                d={svgMetrics.pathD}
                fill="none"
                stroke="#059669"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            )}
            {svgMetrics.points.map((pt, i) => (
              <g key={i}>
                <circle
                  cx={pt.x}
                  cy={pt.y}
                  r={pt.item.hasLog ? "2.5" : "1.5"}
                  className={pt.item.hasLog ? "fill-emerald-700" : "fill-slate-300"}
                />
              </g>
            ))}
          </svg>
        </div>

        {/* Mini stats summary footer */}
        <div className="grid grid-cols-3 gap-1 pt-1 border-t border-slate-200/60 text-[10px]">
          <div>
            <span className="text-slate-400 block font-medium">Avg Daily</span>
            <span className="font-extrabold text-slate-800">{timeSeries.avgDailyKg} kg</span>
          </div>
          <div>
            <span className="text-slate-400 block font-medium">Total {days}d</span>
            <span className="font-extrabold text-emerald-700">{timeSeries.totalPeriodKg} kg</span>
          </div>
          <div className="text-right">
            <span className="text-slate-400 block font-medium">Spend</span>
            <span className="font-bold text-slate-700">{currencySymbol} {timeSeries.totalPeriodCost.toFixed(0)}</span>
          </div>
        </div>
      </div>
    );
  }

  // Full History View with interactive list and detailed breakdown
  return (
    <div className="space-y-4">
      {/* Sparkline Banner Card */}
      <div className="p-4 bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 rounded-2xl text-white space-y-3 shadow-md">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs uppercase tracking-wider font-extrabold text-emerald-400 block">
              Pen Consumption History & Trend
            </span>
            <h4 className="text-lg font-black text-white">Pen ID: {penCode}</h4>
          </div>
          <div className="text-right">
            <span className="text-[11px] text-slate-300 block">Past {days} Days Usage</span>
            <span className="text-base font-black text-emerald-300">
              {timeSeries.totalPeriodKg} kg ({currencySymbol} {timeSeries.totalPeriodCost.toLocaleString()})
            </span>
          </div>
        </div>

        {/* Large Sparkline */}
        <div className="pt-2">
          <svg
            viewBox={`0 0 ${svgMetrics.width} ${svgMetrics.height + 10}`}
            className="w-full h-16 overflow-visible"
          >
            <defs>
              <linearGradient id={`grad-full-${penCode}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#34d399" stopOpacity="0.45" />
                <stop offset="100%" stopColor="#34d399" stopOpacity="0.0" />
              </linearGradient>
            </defs>
            {/* Grid baseline */}
            <line x1="0" y1={svgMetrics.height} x2={svgMetrics.width} y2={svgMetrics.height} stroke="#334155" strokeWidth="1" />

            {svgMetrics.areaD && <path d={svgMetrics.areaD} fill={`url(#grad-full-${penCode})`} />}
            {svgMetrics.pathD && (
              <path
                d={svgMetrics.pathD}
                fill="none"
                stroke="#34d399"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            )}
            {svgMetrics.points.map((pt, i) => (
              <g key={i}>
                <circle
                  cx={pt.x}
                  cy={pt.y}
                  r={pt.item.hasLog ? "3" : "1.5"}
                  className={pt.item.hasLog ? "fill-emerald-300" : "fill-slate-600"}
                />
                {pt.item.hasLog && (
                  <text
                    x={pt.x}
                    y={pt.y - 4}
                    textAnchor="middle"
                    className="text-[7px] fill-emerald-200 font-bold"
                  >
                    {pt.item.qtyKg}k
                  </text>
                )}
              </g>
            ))}
          </svg>
          <div className="flex justify-between text-[9px] text-slate-400 font-mono pt-1">
            <span>{timeSeries.series[0]?.date}</span>
            <span>{timeSeries.series[timeSeries.series.length - 1]?.date}</span>
          </div>
        </div>

        {/* 3 Metric Badges */}
        <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-700/80 text-xs">
          <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700">
            <span className="text-[10px] text-slate-400 block">Avg Daily Burn</span>
            <span className="font-extrabold text-emerald-300">{timeSeries.avgDailyKg} kg / day</span>
          </div>
          <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700">
            <span className="text-[10px] text-slate-400 block">Days Fed ({days}d)</span>
            <span className="font-extrabold text-white">{timeSeries.activeDays} / {days} Days</span>
          </div>
          <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700">
            <span className="text-[10px] text-slate-400 block">Consumption Trend</span>
            <span className={`font-black ${timeSeries.trendPercent >= 0 ? "text-emerald-400" : "text-amber-400"}`}>
              {timeSeries.trendPercent > 0 ? `+${timeSeries.trendPercent}%` : `${timeSeries.trendPercent}%`}
            </span>
          </div>
        </div>
      </div>

      {/* List of Recent Feed Events */}
      <div className="space-y-2">
        <h5 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-slate-500" />
          Recent Feeding Transactions for Pen {penCode}
        </h5>

        {penLogs.length === 0 ? (
          <div className="p-4 bg-slate-50 rounded-xl border border-dashed border-slate-300 text-center text-xs text-slate-500">
            No feeding events logged yet for Pen {penCode}.
          </div>
        ) : (
          <div className="max-h-60 overflow-y-auto space-y-1.5 pr-1 text-xs">
            {penLogs.slice().reverse().map(log => (
              <div
                key={log.id}
                onClick={() => onSelectDate && onSelectDate(log.date)}
                className="p-2.5 bg-white hover:bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between transition-colors cursor-pointer"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{log.date}</span>
                    <span className="text-[10px] text-slate-500 font-semibold capitalize bg-slate-100 px-1.5 py-0.5 rounded">
                      {log.stageId}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 truncate max-w-xs">
                    {log.numberOfAnimalsFed} animals fed • Recipe v{log.formulationVersion} {log.notes ? `• ${log.notes}` : ""}
                  </p>
                </div>

                <div className="text-right">
                  <span className="font-black text-emerald-700 block">{log.totalQuantityFedKg} kg</span>
                  <span className="text-[10px] font-bold text-slate-600">{currencySymbol} {log.totalCost.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

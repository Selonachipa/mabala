import React, { useState, useMemo } from "react";
import { LivestockRecord, PenCohort, LivestockFeedCostLog, LivestockMedicationCostLog, Account } from "../../types";
import { 
  DollarSign, TrendingUp, TrendingDown, Scale, ShieldAlert, 
  Layers, Plus, Filter, Download, Activity, AlertCircle, CheckCircle2,
  Calendar, Users, Pill, Sparkles, PieChart as PieIcon, ArrowUpDown, Clock
} from "lucide-react";

interface LivestockProductionCostingProps {
  records: LivestockRecord[];
  pens: PenCohort[];
  onUpdatePens: (pens: PenCohort[]) => void;
  onUpdateRecords: (records: LivestockRecord[]) => void;
  feedLogs: LivestockFeedCostLog[];
  onAddFeedLog: (log: LivestockFeedCostLog) => void;
  medicationLogs: LivestockMedicationCostLog[];
  onAddMedicationLog: (log: LivestockMedicationCostLog) => void;
  accounts: Account[];
  onUpdateAccounts: (accounts: Account[]) => void;
  currencySymbol: string;
  isReadonly?: boolean;
}

export default function LivestockProductionCosting({
  records,
  pens,
  onUpdatePens,
  onUpdateRecords,
  feedLogs,
  onAddFeedLog,
  medicationLogs,
  onAddMedicationLog,
  accounts,
  onUpdateAccounts,
  currencySymbol,
  isReadonly = false
}: LivestockProductionCostingProps) {
  const [subTab, setSubTab] = useState<"profitability" | "pens" | "feed_costing" | "med_costing">("profitability");
  const [searchFilter, setSearchFilter] = useState<string>("");
  const [speciesFilter, setSpeciesFilter] = useState<string>("All");
  const [penFilter, setPenFilter] = useState<string>("All");
  const [sortBy, setSortBy] = useState<"profit" | "roi" | "cost" | "valuation">("profit");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

  // New Pen Modal State
  const [isAddPenModalOpen, setIsAddPenModalOpen] = useState<boolean>(false);
  const [newPenName, setNewPenName] = useState<string>("");
  const [newPenSpecies, setNewPenSpecies] = useState<string>("Cattle");
  const [newPenType, setNewPenType] = useState<PenCohort["penType"]>("Growers");
  const [newPenCapacity, setNewPenCapacity] = useState<number>(20);
  const [newPenNotes, setNewPenNotes] = useState<string>("");

  // Feed Log State
  const [feedTargetType, setFeedTargetType] = useState<"Pen" | "Animal">("Pen");
  const [feedSelectedPenId, setFeedSelectedPenId] = useState<string>("");
  const [feedSelectedAnimalTag, setFeedSelectedAnimalTag] = useState<string>("");
  const [feedType, setFeedType] = useState<string>("Grower Mash / Concentrate");
  const [feedQuantityKg, setFeedQuantityKg] = useState<number>(50);
  const [feedUnitCost, setFeedUnitCost] = useState<number>(8.5);
  const [feedDate, setFeedDate] = useState<string>(() => new Date().toISOString().split("T")[0]);
  const [feedNotes, setFeedNotes] = useState<string>("");

  // Medication Log State
  const [medTargetType, setMedTargetType] = useState<"Pen" | "Animal">("Pen");
  const [medSelectedPenId, setMedSelectedPenId] = useState<string>("");
  const [medSelectedAnimalTag, setMedSelectedAnimalTag] = useState<string>("");
  const [medDrugName, setMedDrugName] = useState<string>("Albendazole 10% Drench");
  const [medType, setMedType] = useState<LivestockMedicationCostLog["type"]>("Dewormer");
  const [medDosage, setMedDosage] = useState<string>("10ml per head");
  const [medRoute, setMedRoute] = useState<LivestockMedicationCostLog["route"]>("Oral Drench");
  const [medTotalCost, setMedTotalCost] = useState<number>(350);
  const [medWithdrawalDays, setMedWithdrawalDays] = useState<number>(14);
  const [medAdministeredBy, setMedAdministeredBy] = useState<string>("Farm Veterinarian");
  const [medDate, setMedDate] = useState<string>(() => new Date().toISOString().split("T")[0]);
  const [medReason, setMedReason] = useState<string>("Routine quarterly herd internal parasite drenching");

  // Calculate Pen animal counts and aggregate costs
  const enrichedPens = useMemo(() => {
    return pens.map(pen => {
      const animalsInPen = records.filter(r => 
        (r.penId === pen.id || r.penName === pen.name || (r as any).location === pen.name) &&
        r.status !== "Sold" && r.status !== "Dead" && r.status !== "Deceased"
      );
      
      const totalFeed = animalsInPen.reduce((sum, r) => sum + (r.totalFeedCost || 0), 0) + (pen.totalFeedCost || 0);
      const totalMed = animalsInPen.reduce((sum, r) => sum + (r.totalMedicationCost || 0), 0) + (pen.totalMedicationCost || 0);
      const totalValuation = animalsInPen.reduce((sum, r) => sum + (r.currentValue || 0), 0);

      return {
        ...pen,
        currentHeadcount: animalsInPen.length,
        totalFeedCost: totalFeed,
        totalMedicationCost: totalMed,
        totalValuation,
        animals: animalsInPen
      };
    });
  }, [pens, records]);

  // Production Cost & Profitability Rows per Animal
  const profitabilityAnalysis = useMemo(() => {
    return records.map(animal => {
      const acqCost = Number(animal.purchasePrice || 0);
      const feedCost = Number(animal.totalFeedCost || 0);
      const medCost = Number(animal.totalMedicationCost || 0);
      const totalCost = acqCost + feedCost + medCost;
      const currentVal = Number(animal.currentValue || 0);
      const grossProfit = currentVal - totalCost;
      const roiPercent = totalCost > 0 ? ((grossProfit / totalCost) * 100) : (grossProfit > 0 ? 100 : 0);

      return {
        animal,
        tagId: animal.tagId,
        species: animal.species || animal.type || "Cattle",
        breed: animal.breed || "Standard",
        penName: animal.penName || (animal as any).location || "General Paddock",
        status: animal.status || "Active",
        acqCost,
        feedCost,
        medCost,
        totalCost,
        currentVal,
        grossProfit,
        roiPercent,
        weightKg: Number(animal.weight || (animal as any).currentWeight || 0)
      };
    });
  }, [records]);

  // Filtered & Sorted Profitability Rows
  const filteredAnalysis = useMemo(() => {
    return profitabilityAnalysis.filter(row => {
      const matchesSearch = !searchFilter || 
        row.tagId.toLowerCase().includes(searchFilter.toLowerCase()) ||
        row.breed.toLowerCase().includes(searchFilter.toLowerCase()) ||
        row.penName.toLowerCase().includes(searchFilter.toLowerCase());
      
      const matchesSpecies = speciesFilter === "All" || row.species === speciesFilter;
      const matchesPen = penFilter === "All" || row.penName === penFilter;

      return matchesSearch && matchesSpecies && matchesPen;
    }).sort((a, b) => {
      let valA = 0;
      let valB = 0;
      if (sortBy === "profit") {
        valA = a.grossProfit;
        valB = b.grossProfit;
      } else if (sortBy === "roi") {
        valA = a.roiPercent;
        valB = b.roiPercent;
      } else if (sortBy === "cost") {
        valA = a.totalCost;
        valB = b.totalCost;
      } else if (sortBy === "valuation") {
        valA = a.currentVal;
        valB = b.currentVal;
      }
      return sortOrder === "desc" ? valB - valA : valA - valB;
    });
  }, [profitabilityAnalysis, searchFilter, speciesFilter, penFilter, sortBy, sortOrder]);

  // Summary Metrics
  const summaryMetrics = useMemo(() => {
    const activeRows = profitabilityAnalysis.filter(r => r.status !== "Sold" && r.status !== "Dead" && r.status !== "Deceased");
    const totalAnimals = activeRows.length;
    const totalValuation = activeRows.reduce((s, r) => s + r.currentVal, 0);
    const totalFeedingCost = activeRows.reduce((s, r) => s + r.feedCost, 0);
    const totalMedCost = activeRows.reduce((s, r) => s + r.medCost, 0);
    const totalAcqCost = activeRows.reduce((s, r) => s + r.acqCost, 0);
    const totalCostOfHerd = totalAcqCost + totalFeedingCost + totalMedCost;
    const totalGrossProfit = totalValuation - totalCostOfHerd;
    const overallRoi = totalCostOfHerd > 0 ? (totalGrossProfit / totalCostOfHerd) * 100 : 0;
    const avgProfitPerAnimal = totalAnimals > 0 ? totalGrossProfit / totalAnimals : 0;

    return {
      totalAnimals,
      totalValuation,
      totalFeedingCost,
      totalMedCost,
      totalCostOfHerd,
      totalGrossProfit,
      overallRoi,
      avgProfitPerAnimal
    };
  }, [profitabilityAnalysis]);

  // Handle Add New Pen / Cohort
  const handleCreatePen = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPenName.trim()) return;

    const newPen: PenCohort = {
      id: `pen-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: newPenName.trim(),
      species: newPenSpecies,
      penType: newPenType,
      capacity: Number(newPenCapacity) || 20,
      currentHeadcount: 0,
      totalFeedCost: 0,
      totalMedicationCost: 0,
      notes: newPenNotes
    };

    const updatedPens = [...pens, newPen];
    onUpdatePens(updatedPens);
    setIsAddPenModalOpen(false);
    setNewPenName("");
    setNewPenNotes("");
  };

  // Handle Log Feeding Cost
  const handleSaveFeedCost = (e: React.FormEvent) => {
    e.preventDefault();
    if (isReadonly) return;

    const totalCalculatedCost = Number(feedQuantityKg) * Number(feedUnitCost);
    if (totalCalculatedCost <= 0) return;

    let affectedAnimals: LivestockRecord[] = [];
    let headcount = 1;

    if (feedTargetType === "Pen") {
      const selectedPen = pens.find(p => p.id === feedSelectedPenId || p.name === feedSelectedPenId);
      const penName = selectedPen?.name || feedSelectedPenId;
      affectedAnimals = records.filter(r => 
        (r.penId === selectedPen?.id || r.penName === penName || (r as any).location === penName) &&
        r.status !== "Sold" && r.status !== "Dead" && r.status !== "Deceased"
      );
      headcount = Math.max(1, affectedAnimals.length);
    } else {
      const single = records.find(r => r.tagId === feedSelectedAnimalTag);
      if (single) affectedAnimals = [single];
      headcount = 1;
    }

    const costPerAnimal = totalCalculatedCost / headcount;

    // Create Feed Log
    const newLog: LivestockFeedCostLog = {
      id: `feed-log-${Date.now()}`,
      date: feedDate,
      targetType: feedTargetType,
      penId: feedTargetType === "Pen" ? feedSelectedPenId : undefined,
      penName: feedTargetType === "Pen" ? (pens.find(p => p.id === feedSelectedPenId)?.name || feedSelectedPenId) : undefined,
      animalTagId: feedTargetType === "Animal" ? feedSelectedAnimalTag : undefined,
      animalSpecies: affectedAnimals[0]?.species || "Livestock",
      feedType,
      quantityKg: Number(feedQuantityKg),
      unitCostPerKg: Number(feedUnitCost),
      totalCost: totalCalculatedCost,
      headcountAllocated: headcount,
      costPerAnimal,
      notes: feedNotes
    };

    onAddFeedLog(newLog);

    // Update affected animals' totalFeedCost in records
    const affectedTags = new Set(affectedAnimals.map(a => a.tagId));
    const updatedRecords = records.map(rec => {
      if (affectedTags.has(rec.tagId)) {
        const prevFeed = Number(rec.totalFeedCost || 0);
        const existingFeedingRecords = rec.feedingRecords || [];
        return {
          ...rec,
          totalFeedCost: prevFeed + costPerAnimal,
          feedingRecords: [
            ...existingFeedingRecords,
            {
              id: `feed-entry-${Date.now()}-${rec.tagId}`,
              date: feedDate,
              feedType,
              quantityKg: Number((feedQuantityKg / headcount).toFixed(2)),
              cost: costPerAnimal,
              unitPrice: feedUnitCost,
              penName: newLog.penName
            }
          ]
        };
      }
      return rec;
    });
    onUpdateRecords(updatedRecords);

    // Post to Financial Ledger: Debit 5210 (Feed Expense), Credit 1010 (Bank/Cash)
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1010") balance -= totalCalculatedCost; // Bank Credit
      if (acc.code === "5210" || acc.code === "5010") balance += totalCalculatedCost; // Feed Expense Debit
      return { ...acc, balance };
    });
    onUpdateAccounts(updatedAccounts);

    // Reset Form
    setFeedQuantityKg(50);
    setFeedNotes("");
    alert(`Successfully logged ${currencySymbol}${totalCalculatedCost.toLocaleString()} feed expense across ${headcount} animal(s).`);
  };

  // Handle Log Medication Cost
  const handleSaveMedicationCost = (e: React.FormEvent) => {
    e.preventDefault();
    if (isReadonly) return;

    const totalCost = Number(medTotalCost);
    if (totalCost <= 0) return;

    let affectedAnimals: LivestockRecord[] = [];
    let headcount = 1;

    if (medTargetType === "Pen") {
      const selectedPen = pens.find(p => p.id === medSelectedPenId || p.name === medSelectedPenId);
      const penName = selectedPen?.name || medSelectedPenId;
      affectedAnimals = records.filter(r => 
        (r.penId === selectedPen?.id || r.penName === penName || (r as any).location === penName) &&
        r.status !== "Sold" && r.status !== "Dead" && r.status !== "Deceased"
      );
      headcount = Math.max(1, affectedAnimals.length);
    } else {
      const single = records.find(r => r.tagId === medSelectedAnimalTag);
      if (single) affectedAnimals = [single];
      headcount = 1;
    }

    const costPerAnimal = totalCost / headcount;

    const expDate = new Date(medDate);
    expDate.setDate(expDate.getDate() + Number(medWithdrawalDays));
    const withdrawalExpiresDate = expDate.toISOString().split("T")[0];
    const activeWithdrawal = medWithdrawalDays > 0;

    // Create Medication Log
    const newLog: LivestockMedicationCostLog = {
      id: `med-log-${Date.now()}`,
      date: medDate,
      targetType: medTargetType,
      penId: medTargetType === "Pen" ? medSelectedPenId : undefined,
      penName: medTargetType === "Pen" ? (pens.find(p => p.id === medSelectedPenId)?.name || medSelectedPenId) : undefined,
      animalTagId: medTargetType === "Animal" ? medSelectedAnimalTag : undefined,
      animalSpecies: affectedAnimals[0]?.species || "Livestock",
      drugName: medDrugName,
      type: medType,
      dosage: medDosage,
      route: medRoute,
      totalCost,
      headcountAllocated: headcount,
      costPerAnimal,
      administeredBy: medAdministeredBy,
      withdrawalDays: Number(medWithdrawalDays),
      withdrawalExpiresDate,
      reason: medReason
    };

    onAddMedicationLog(newLog);

    // Update affected animals' totalMedicationCost and medication records
    const affectedTags = new Set(affectedAnimals.map(a => a.tagId));
    const updatedRecords = records.map(rec => {
      if (affectedTags.has(rec.tagId)) {
        const prevMed = Number(rec.totalMedicationCost || 0);
        const existingMeds = rec.medicationRecords || [];
        return {
          ...rec,
          totalMedicationCost: prevMed + costPerAnimal,
          medicationRecords: [
            ...existingMeds,
            {
              id: `med-entry-${Date.now()}-${rec.tagId}`,
              drugName: medDrugName,
              dateAdministered: medDate,
              dosage: medDosage,
              route: medRoute,
              cost: costPerAnimal,
              administeredBy: medAdministeredBy,
              withdrawalExpiresDate,
              activeWithdrawal,
              reason: medReason,
              penName: newLog.penName
            }
          ]
        };
      }
      return rec;
    });
    onUpdateRecords(updatedRecords);

    // Post to Financial Ledger: Debit 5300 (Veterinary & Meds Expense), Credit 1010 (Bank/Cash)
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1010") balance -= totalCost; // Bank Credit
      if (acc.code === "5300") balance += totalCost; // Vet & Medicine Expense Debit
      return { ...acc, balance };
    });
    onUpdateAccounts(updatedAccounts);

    // Reset Form
    setMedTotalCost(0);
    setMedReason("");
    alert(`Successfully logged ${currencySymbol}${totalCost.toLocaleString()} medication expense across ${headcount} animal(s).`);
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Top Navigation Tabs */}
      <div className="flex flex-wrap gap-2 border-b pb-3">
        <button
          type="button"
          onClick={() => setSubTab("profitability")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
            subTab === "profitability"
              ? "bg-slate-900 text-white shadow-xs"
              : "bg-slate-100 hover:bg-slate-200 text-slate-700"
          }`}
        >
          <TrendingUp className="w-4 h-4 text-emerald-400" /> Animal Production Cost & Margin Analysis
        </button>

        <button
          type="button"
          onClick={() => setSubTab("pens")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
            subTab === "pens"
              ? "bg-slate-900 text-white shadow-xs"
              : "bg-slate-100 hover:bg-slate-200 text-slate-700"
          }`}
        >
          <Layers className="w-4 h-4 text-teal-400" /> Housing Pens & Cohorts Management
        </button>

        <button
          type="button"
          onClick={() => setSubTab("feed_costing")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
            subTab === "feed_costing"
              ? "bg-slate-900 text-white shadow-xs"
              : "bg-slate-100 hover:bg-slate-200 text-slate-700"
          }`}
        >
          <Scale className="w-4 h-4 text-amber-400" /> Log Feed Costing (Pen / Animal)
        </button>

        <button
          type="button"
          onClick={() => setSubTab("med_costing")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
            subTab === "med_costing"
              ? "bg-slate-900 text-white shadow-xs"
              : "bg-slate-100 hover:bg-slate-200 text-slate-700"
          }`}
        >
          <Pill className="w-4 h-4 text-rose-400" /> Log Medication & Treatment Cost
        </button>
      </div>

      {/* KPI Overview Cards Banner */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block font-mono">
            Active Herd Headcount
          </span>
          <div className="text-2xl font-black font-mono mt-1 text-white">
            {summaryMetrics.totalAnimals} <span className="text-xs font-sans text-slate-400 font-bold">Animals</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-semibold block mt-1 font-mono">
            Appraisal: {currencySymbol}{summaryMetrics.totalValuation.toLocaleString()}
          </span>
        </div>

        <div className="bg-amber-950/40 text-amber-950 p-4 rounded-2xl border border-amber-200 shadow-xs">
          <span className="text-[10px] uppercase font-black text-amber-800 tracking-wider block font-mono">
            Cumulative Feeding Expense
          </span>
          <div className="text-2xl font-black font-mono mt-1 text-amber-950">
            {currencySymbol}{summaryMetrics.totalFeedingCost.toLocaleString()}
          </div>
          <span className="text-[10px] text-amber-800 font-bold block mt-1">
            Avg: {currencySymbol}{(summaryMetrics.totalAnimals > 0 ? Math.round(summaryMetrics.totalFeedingCost / summaryMetrics.totalAnimals) : 0).toLocaleString()} / Head
          </span>
        </div>

        <div className="bg-rose-950/40 text-rose-950 p-4 rounded-2xl border border-rose-200 shadow-xs">
          <span className="text-[10px] uppercase font-black text-rose-800 tracking-wider block font-mono">
            Cumulative Medication Expense
          </span>
          <div className="text-2xl font-black font-mono mt-1 text-rose-950">
            {currencySymbol}{summaryMetrics.totalMedCost.toLocaleString()}
          </div>
          <span className="text-[10px] text-rose-800 font-bold block mt-1">
            Avg: {currencySymbol}{(summaryMetrics.totalAnimals > 0 ? Math.round(summaryMetrics.totalMedCost / summaryMetrics.totalAnimals) : 0).toLocaleString()} / Head
          </span>
        </div>

        <div className="bg-emerald-950/40 text-emerald-950 p-4 rounded-2xl border border-emerald-200 shadow-xs">
          <span className="text-[10px] uppercase font-black text-emerald-800 tracking-wider block font-mono">
            Net Herd Gross Margin
          </span>
          <div className="text-2xl font-black font-mono mt-1 text-emerald-950">
            {currencySymbol}{summaryMetrics.totalGrossProfit.toLocaleString()}
          </div>
          <span className="text-[10px] text-emerald-800 font-bold block mt-1 font-mono">
            ROI: +{summaryMetrics.overallRoi.toFixed(1)}% | {currencySymbol}{Math.round(summaryMetrics.avgProfitPerAnimal).toLocaleString()}/head
          </span>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SUBTAB 1: PROFITABILITY & PRODUCTION COST ANALYTICS TABLE */}
      {/* ========================================================= */}
      {subTab === "profitability" && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b pb-4">
            <div>
              <h3 className="font-extrabold text-sm uppercase text-slate-900 tracking-tight flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600" /> Individual Animal Production Cost & Profitability Matrix
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                Tracks exact initial acquisition, cumulative feed ration cost, veterinary inputs, and real-time net gross profit margins per animal.
              </p>
            </div>

            {/* Filter Bar */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Search Tag, Breed, Pen..."
                className="p-2 border rounded-xl bg-slate-50 text-xs outline-none font-bold"
              />

              <select
                value={speciesFilter}
                onChange={(e) => setSpeciesFilter(e.target.value)}
                className="p-2 border rounded-xl bg-slate-50 font-bold text-xs outline-none"
              >
                <option value="All">All Species</option>
                <option value="Cattle">Cattle</option>
                <option value="Goats">Goats</option>
                <option value="Sheep">Sheep</option>
                <option value="Pigs">Pigs</option>
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="p-2 border rounded-xl bg-slate-50 font-bold text-xs outline-none"
              >
                <option value="profit">Sort by Net Margin (ZMW)</option>
                <option value="roi">Sort by ROI (%)</option>
                <option value="cost">Sort by Total Production Cost</option>
                <option value="valuation">Sort by Fair Market Value</option>
              </select>

              <button
                type="button"
                onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
                className="p-2 bg-slate-100 hover:bg-slate-200 border rounded-xl font-mono font-bold"
                title="Toggle sort direction"
              >
                {sortOrder === "desc" ? "↓ High-Low" : "↑ Low-High"}
              </button>
            </div>
          </div>

          {/* Analysis Data Table */}
          <div className="border rounded-xl overflow-hidden shadow-xs overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse min-w-[900px]">
              <thead className="bg-slate-100 text-[10px] uppercase font-bold text-slate-600 border-b">
                <tr>
                  <th className="p-3">Ear Tag ID</th>
                  <th className="p-3">Species & Breed</th>
                  <th className="p-3">Housing Pen</th>
                  <th className="p-3 text-right">Acq / Birth Cost</th>
                  <th className="p-3 text-right">Feed Cost</th>
                  <th className="p-3 text-right">Medication</th>
                  <th className="p-3 text-right font-black text-slate-800">Total Input Cost</th>
                  <th className="p-3 text-right font-black text-slate-900">Current Valuation</th>
                  <th className="p-3 text-right font-black">Net Margin</th>
                  <th className="p-3 text-center font-black">ROI / Status</th>
                </tr>
              </thead>
              <tbody className="divide-y font-semibold text-slate-800">
                {filteredAnalysis.map((row, idx) => {
                  const isProfitable = row.grossProfit >= 0;
                  return (
                    <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3">
                        <span className="font-mono text-emerald-900 font-extrabold text-[12px] block">
                          {row.tagId}
                        </span>
                        <span className="text-[9px] text-slate-400 font-bold block">
                          {row.weightKg > 0 ? `${row.weightKg} Kg` : "Standard Wt"}
                        </span>
                      </td>
                      <td className="p-3">
                        <span className="text-slate-900 font-black block">{row.species}</span>
                        <span className="text-[10px] text-slate-500 font-medium">{row.breed}</span>
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-slate-100 border text-slate-700 rounded-md text-[10px] font-bold">
                          {row.penName}
                        </span>
                      </td>
                      <td className="p-3 text-right font-mono text-slate-600">
                        {currencySymbol}{row.acqCost.toLocaleString()}
                      </td>
                      <td className="p-3 text-right font-mono text-amber-800">
                        {currencySymbol}{row.feedCost.toLocaleString()}
                      </td>
                      <td className="p-3 text-right font-mono text-rose-800">
                        {currencySymbol}{row.medCost.toLocaleString()}
                      </td>
                      <td className="p-3 text-right font-mono font-black text-slate-900 bg-slate-50/50">
                        {currencySymbol}{row.totalCost.toLocaleString()}
                      </td>
                      <td className="p-3 text-right font-mono font-black text-emerald-950">
                        {currencySymbol}{row.currentVal.toLocaleString()}
                      </td>
                      <td className={`p-3 text-right font-mono font-black text-xs ${
                        isProfitable ? "text-emerald-700" : "text-rose-700"
                      }`}>
                        {isProfitable ? "+" : ""}{currencySymbol}{row.grossProfit.toLocaleString()}
                      </td>
                      <td className="p-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase font-mono ${
                          row.roiPercent >= 50
                            ? "bg-emerald-100 text-emerald-900 border border-emerald-300"
                            : row.roiPercent >= 0
                            ? "bg-teal-50 text-teal-800 border border-teal-200"
                            : "bg-rose-100 text-rose-900 border border-rose-300"
                        }`}>
                          {row.roiPercent >= 0 ? "+" : ""}{row.roiPercent.toFixed(1)}% ROI
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUBTAB 2: HOUSING PENS & COHORTS MANAGEMENT               */}
      {/* ========================================================= */}
      {subTab === "pens" && (
        <div className="space-y-6">
          <div className="flex justify-between items-center bg-white border p-5 rounded-2xl">
            <div>
              <h3 className="font-extrabold text-sm uppercase text-slate-900 tracking-tight">
                Farm Enclosures, Pens, & Cohort Management
              </h3>
              <p className="text-[11px] text-slate-400">
                Segment your herd into pens or pasture paddocks to track feed consumption, medication allocations, and stocking densities.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsAddPenModalOpen(true)}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-400" /> Create Housing Pen / Cohort
            </button>
          </div>

          {/* Grid of Pens */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {enrichedPens.map((pen) => {
              const occupancyPct = Math.round((pen.currentHeadcount / Math.max(1, pen.capacity)) * 100);
              return (
                <div key={pen.id} className="bg-white border rounded-2xl p-5 space-y-4 shadow-xs">
                  <div className="flex justify-between items-start border-b pb-3">
                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-400 block font-mono">
                        {pen.species} • {pen.penType}
                      </span>
                      <h4 className="text-sm font-black text-slate-900">{pen.name}</h4>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                      occupancyPct > 100
                        ? "bg-rose-100 text-rose-800"
                        : occupancyPct >= 75
                        ? "bg-amber-100 text-amber-800"
                        : "bg-emerald-50 text-emerald-800"
                    }`}>
                      {occupancyPct}% Capacity
                    </span>
                  </div>

                  {/* Stocking Density Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] font-bold text-slate-500">
                      <span>Occupancy</span>
                      <span className="font-mono">{pen.currentHeadcount} / {pen.capacity} Heads</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all ${
                          occupancyPct > 100 ? "bg-rose-600" : occupancyPct >= 75 ? "bg-amber-500" : "bg-emerald-600"
                        }`}
                        style={{ width: `${Math.min(100, occupancyPct)}%` }}
                      />
                    </div>
                  </div>

                  {/* Financial Stats on Pen */}
                  <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-xl border">
                    <div>
                      <span className="text-[9px] text-slate-400 uppercase font-bold block">Feed Allocated</span>
                      <strong className="text-amber-900 font-mono">
                        {currencySymbol}{pen.totalFeedCost.toLocaleString()}
                      </strong>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 uppercase font-bold block">Meds Allocated</span>
                      <strong className="text-rose-900 font-mono">
                        {currencySymbol}{pen.totalMedicationCost.toLocaleString()}
                      </strong>
                    </div>
                  </div>

                  {/* Animal Tags in this Pen */}
                  <div className="space-y-1">
                    <span className="text-[9px] uppercase font-bold text-slate-400 block">Assigned Animals</span>
                    <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                      {pen.animals && pen.animals.length > 0 ? (
                        pen.animals.map(a => (
                          <span key={a.id} className="px-1.5 py-0.5 bg-slate-100 text-slate-800 font-mono text-[9px] rounded font-bold">
                            {a.tagId}
                          </span>
                        ))
                      ) : (
                        <span className="text-[10px] text-slate-400 italic">No animals currently assigned</span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Add Pen Modal */}
          {isAddPenModalOpen && (
            <div className="fixed inset-0 bg-slate-950/70 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl border">
                <div className="flex justify-between items-center border-b pb-3">
                  <h4 className="text-sm font-black text-slate-900 uppercase">Create Housing Pen / Cohort</h4>
                  <button onClick={() => setIsAddPenModalOpen(false)} className="text-slate-400 hover:text-slate-600">✕</button>
                </div>
                <form onSubmit={handleCreatePen} className="space-y-3 text-xs">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Pen / Paddock Name *</label>
                    <input
                      type="text"
                      value={newPenName}
                      onChange={(e) => setNewPenName(e.target.value)}
                      placeholder="e.g. Pen A - Weaners, Paddock 4"
                      className="w-full p-2 border rounded-xl outline-none font-bold"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Target Species</label>
                      <select
                        value={newPenSpecies}
                        onChange={(e) => setNewPenSpecies(e.target.value)}
                        className="w-full p-2 border rounded-xl outline-none font-bold"
                      >
                        <option value="Cattle">Cattle</option>
                        <option value="Goats">Goats</option>
                        <option value="Sheep">Sheep</option>
                        <option value="Pigs">Pigs</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Pen Category</label>
                      <select
                        value={newPenType}
                        onChange={(e) => setNewPenType(e.target.value as any)}
                        className="w-full p-2 border rounded-xl outline-none font-bold"
                      >
                        <option value="Weaners">Weaners</option>
                        <option value="Growers">Growers</option>
                        <option value="Finisher / Feedlot">Finisher / Feedlot</option>
                        <option value="Maternity / Farrowing">Maternity / Farrowing</option>
                        <option value="Pasture / Paddock">Pasture / Paddock</option>
                        <option value="Quarantine / Hospital">Quarantine / Hospital</option>
                        <option value="General">General Housing</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Max Head Capacity</label>
                    <input
                      type="number"
                      value={newPenCapacity}
                      onChange={(e) => setNewPenCapacity(Number(e.target.value))}
                      className="w-full p-2 border rounded-xl outline-none font-mono font-bold"
                      min={1}
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Notes / Description</label>
                    <textarea
                      value={newPenNotes}
                      onChange={(e) => setNewPenNotes(e.target.value)}
                      placeholder="e.g. Equipped with automatic nipple drinkers & creep area"
                      rows={2}
                      className="w-full p-2 border rounded-xl outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl shadow-xs"
                  >
                    Save Pen to Registry
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* SUBTAB 3: LOG FEED COSTING (PEN OR INDIVIDUAL ANIMAL)    */}
      {/* ========================================================= */}
      {subTab === "feed_costing" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <form onSubmit={handleSaveFeedCost} className="bg-white border rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="border-b pb-3">
              <h4 className="text-xs font-black uppercase text-slate-900 tracking-tight flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-amber-500" /> Allocate Feed Consumption Cost
              </h4>
              <p className="text-[10px] text-slate-400">
                Log feed expenses per Pen / Cohort (automatically split among occupant animals) or to an individual animal.
              </p>
            </div>

            {/* Target Type Selector */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setFeedTargetType("Pen")}
                className={`p-2 rounded-xl text-xs font-bold transition-all ${
                  feedTargetType === "Pen"
                    ? "bg-slate-900 text-white shadow-xs"
                    : "bg-slate-100 text-slate-700"
                }`}
              >
                Allocate to Pen / Cohort
              </button>
              <button
                type="button"
                onClick={() => setFeedTargetType("Animal")}
                className={`p-2 rounded-xl text-xs font-bold transition-all ${
                  feedTargetType === "Animal"
                    ? "bg-slate-900 text-white shadow-xs"
                    : "bg-slate-100 text-slate-700"
                }`}
              >
                Individual Animal
              </button>
            </div>

            {feedTargetType === "Pen" ? (
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Target Housing Pen *</label>
                <select
                  value={feedSelectedPenId}
                  onChange={(e) => setFeedSelectedPenId(e.target.value)}
                  className="w-full p-2 border rounded-xl bg-white font-bold text-xs"
                  required
                >
                  <option value="">-- Choose Pen --</option>
                  {pens.map(p => (
                    <option key={p.id} value={p.id}>{p.name} ({p.species} - {p.penType})</option>
                  ))}
                </select>
              </div>
            ) : (
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Target Animal Tag *</label>
                <select
                  value={feedSelectedAnimalTag}
                  onChange={(e) => setFeedSelectedAnimalTag(e.target.value)}
                  className="w-full p-2 border rounded-xl bg-white font-bold text-xs"
                  required
                >
                  <option value="">-- Choose Animal Tag --</option>
                  {records.map(r => (
                    <option key={r.id} value={r.tagId}>{r.tagId} ({r.species} - {r.breed})</option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Feed Formulation / Type</label>
              <input
                type="text"
                value={feedType}
                onChange={(e) => setFeedType(e.target.value)}
                placeholder="e.g. Pig Grower Mash, Dairy Meal 18%"
                className="w-full p-2 border rounded-xl bg-white text-xs font-bold"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Quantity (Kg)</label>
                <input
                  type="number"
                  step="0.1"
                  value={feedQuantityKg === 0 ? "" : feedQuantityKg}
                  onChange={(e) => setFeedQuantityKg(e.target.value === "" ? 0 : Number(e.target.value))}
                  className="w-full p-2 border rounded-xl bg-white text-xs font-mono font-bold"
                  required
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Unit Cost ({currencySymbol}/Kg)</label>
                <input
                  type="number"
                  step="0.01"
                  value={feedUnitCost === 0 ? "" : feedUnitCost}
                  onChange={(e) => setFeedUnitCost(e.target.value === "" ? 0 : Number(e.target.value))}
                  className="w-full p-2 border rounded-xl bg-white text-xs font-mono font-bold"
                  required
                />
              </div>
            </div>

            {/* Total Cost Dry-run */}
            <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 flex justify-between items-center text-xs font-bold text-amber-950">
              <span>Total Billable Feed Cost:</span>
              <span className="text-sm font-mono font-black text-amber-900">
                {currencySymbol}{(feedQuantityKg * feedUnitCost).toLocaleString()}
              </span>
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Date OF Feeding</label>
              <input
                type="date"
                value={feedDate}
                onChange={(e) => setFeedDate(e.target.value)}
                className="w-full p-2 border rounded-xl bg-white text-xs font-mono font-bold"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-amber-700 hover:bg-amber-600 text-white font-extrabold text-xs rounded-xl shadow-xs cursor-pointer"
            >
              Post Feed Expense & Allocate Costs
            </button>
          </form>

          {/* Historical Feed Costing Logs */}
          <div className="md:col-span-2 space-y-4">
            <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider">
              Recent Feed Costing Logs & Allocations
            </h4>
            <div className="bg-white border rounded-xl overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b">
                  <tr>
                    <th className="p-3">Date</th>
                    <th className="p-3">Target Scope</th>
                    <th className="p-3">Ration Type</th>
                    <th className="p-3">Quantity</th>
                    <th className="p-3 text-right">Total Cost</th>
                    <th className="p-3 text-right">Cost / Head</th>
                  </tr>
                </thead>
                <tbody className="divide-y font-semibold text-slate-700">
                  {feedLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="p-3 font-mono text-[11px]">{log.date}</td>
                      <td className="p-3">
                        <span className="font-bold text-slate-900 block">
                          {log.targetType === "Pen" ? `Pen: ${log.penName}` : `Animal: ${log.animalTagId}`}
                        </span>
                        <span className="text-[9px] text-slate-400 uppercase font-bold">
                          {log.headcountAllocated} animal(s) allocated
                        </span>
                      </td>
                      <td className="p-3">{log.feedType}</td>
                      <td className="p-3 font-mono">{log.quantityKg} Kg @ {currencySymbol}{log.unitCostPerKg}/kg</td>
                      <td className="p-3 text-right font-mono font-black text-amber-900">
                        {currencySymbol}{log.totalCost.toLocaleString()}
                      </td>
                      <td className="p-3 text-right font-mono text-slate-600">
                        {currencySymbol}{log.costPerAnimal.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                  {feedLogs.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400 font-bold">
                        No feed cost logs registered yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUBTAB 4: LOG MEDICATION COSTING (PEN OR INDIVIDUAL)      */}
      {/* ========================================================= */}
      {subTab === "med_costing" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <form onSubmit={handleSaveMedicationCost} className="bg-white border rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="border-b pb-3">
              <h4 className="text-xs font-black uppercase text-slate-900 tracking-tight flex items-center gap-1.5">
                <Pill className="w-4 h-4 text-rose-500" /> Log Medication & Veterinary Treatment
              </h4>
              <p className="text-[10px] text-slate-400">
                Log vaccines, dewormers, antibiotics, and vitamins with automatic withdrawal period enforcement.
              </p>
            </div>

            {/* Target Type Selector */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setMedTargetType("Pen")}
                className={`p-2 rounded-xl text-xs font-bold transition-all ${
                  medTargetType === "Pen"
                    ? "bg-slate-900 text-white shadow-xs"
                    : "bg-slate-100 text-slate-700"
                }`}
              >
                Allocate to Pen / Cohort
              </button>
              <button
                type="button"
                onClick={() => setMedTargetType("Animal")}
                className={`p-2 rounded-xl text-xs font-bold transition-all ${
                  medTargetType === "Animal"
                    ? "bg-slate-900 text-white shadow-xs"
                    : "bg-slate-100 text-slate-700"
                }`}
              >
                Individual Animal
              </button>
            </div>

            {medTargetType === "Pen" ? (
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Target Housing Pen *</label>
                <select
                  value={medSelectedPenId}
                  onChange={(e) => setMedSelectedPenId(e.target.value)}
                  className="w-full p-2 border rounded-xl bg-white font-bold text-xs"
                  required
                >
                  <option value="">-- Choose Pen --</option>
                  {pens.map(p => (
                    <option key={p.id} value={p.id}>{p.name} ({p.species})</option>
                  ))}
                </select>
              </div>
            ) : (
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Target Animal Tag *</label>
                <select
                  value={medSelectedAnimalTag}
                  onChange={(e) => setMedSelectedAnimalTag(e.target.value)}
                  className="w-full p-2 border rounded-xl bg-white font-bold text-xs"
                  required
                >
                  <option value="">-- Choose Animal Tag --</option>
                  {records.map(r => (
                    <option key={r.id} value={r.tagId}>{r.tagId} ({r.species} - {r.breed})</option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Drug / Vaccine Name *</label>
              <input
                type="text"
                value={medDrugName}
                onChange={(e) => setMedDrugName(e.target.value)}
                placeholder="e.g. Oxytetracycline 20% LA, Foot & Mouth Vaccine"
                className="w-full p-2 border rounded-xl bg-white text-xs font-bold"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Drug Category</label>
                <select
                  value={medType}
                  onChange={(e) => setMedType(e.target.value as any)}
                  className="w-full p-2 border rounded-xl bg-white font-bold text-xs"
                >
                  <option value="Vaccine">Vaccine</option>
                  <option value="Dewormer">Dewormer</option>
                  <option value="Antibiotic">Antibiotic</option>
                  <option value="Vitamin/Supplement">Vitamin / Supplement</option>
                  <option value="Treatment">Treatment</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Route OF Admin</label>
                <select
                  value={medRoute}
                  onChange={(e) => setMedRoute(e.target.value as any)}
                  className="w-full p-2 border rounded-xl bg-white font-bold text-xs"
                >
                  <option value="Injection">Injection</option>
                  <option value="Oral Drench">Oral Drench</option>
                  <option value="Topical Pour-On">Topical Pour-On</option>
                  <option value="Feed Additive">Feed Additive</option>
                  <option value="Water Soluble">Water Soluble</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Dosage</label>
                <input
                  type="text"
                  value={medDosage}
                  onChange={(e) => setMedDosage(e.target.value)}
                  placeholder="e.g. 5ml IM"
                  className="w-full p-2 border rounded-xl bg-white text-xs font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Total Cost ({currencySymbol}) *</label>
                <input
                  type="number"
                  value={medTotalCost === 0 ? "" : medTotalCost}
                  onChange={(e) => setMedTotalCost(e.target.value === "" ? 0 : Number(e.target.value))}
                  className="w-full p-2 border rounded-xl bg-white text-xs font-mono font-bold"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Withdrawal Days</label>
                <input
                  type="number"
                  value={medWithdrawalDays}
                  onChange={(e) => setMedWithdrawalDays(Number(e.target.value))}
                  className="w-full p-2 border rounded-xl bg-white text-xs font-mono font-bold"
                  min={0}
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Administered Date</label>
                <input
                  type="date"
                  value={medDate}
                  onChange={(e) => setMedDate(e.target.value)}
                  className="w-full p-2 border rounded-xl bg-white text-xs font-mono font-bold"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-rose-900 hover:bg-rose-800 text-white font-extrabold text-xs rounded-xl shadow-xs cursor-pointer"
            >
              Post Treatment & Allocate Costs
            </button>
          </form>

          {/* Historical Medication Logs */}
          <div className="md:col-span-2 space-y-4">
            <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider">
              Recent Treatment & Medication Ledger
            </h4>
            <div className="bg-white border rounded-xl overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b">
                  <tr>
                    <th className="p-3">Date</th>
                    <th className="p-3">Target Scope</th>
                    <th className="p-3">Drug & Route</th>
                    <th className="p-3 text-center">Withdrawal</th>
                    <th className="p-3 text-right">Total Cost</th>
                    <th className="p-3 text-right">Cost / Head</th>
                  </tr>
                </thead>
                <tbody className="divide-y font-semibold text-slate-700">
                  {medicationLogs.map((log) => {
                    const isWithdrawalActive = log.withdrawalExpiresDate && new Date(log.withdrawalExpiresDate).getTime() > Date.now();
                    return (
                      <tr key={log.id} className="hover:bg-slate-50">
                        <td className="p-3 font-mono text-[11px]">{log.date}</td>
                        <td className="p-3">
                          <span className="font-bold text-slate-900 block">
                            {log.targetType === "Pen" ? `Pen: ${log.penName}` : `Animal: ${log.animalTagId}`}
                          </span>
                          <span className="text-[9px] text-slate-400 uppercase font-bold">
                            {log.headcountAllocated} head(s)
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="font-bold text-slate-900 block">{log.drugName}</span>
                          <span className="text-[10px] text-slate-400">{log.type} • {log.route}</span>
                        </td>
                        <td className="p-3 text-center">
                          {isWithdrawalActive ? (
                            <span className="px-2 py-0.5 bg-rose-50 text-rose-700 border border-rose-200 rounded text-[9px] font-black uppercase">
                              Active ({log.withdrawalExpiresDate})
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded text-[9px] font-bold uppercase">
                              Cleared
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-right font-mono font-black text-rose-900">
                          {currencySymbol}{log.totalCost.toLocaleString()}
                        </td>
                        <td className="p-3 text-right font-mono text-slate-600">
                          {currencySymbol}{log.costPerAnimal.toFixed(2)}
                        </td>
                      </tr>
                    );
                  })}
                  {medicationLogs.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400 font-bold">
                        No medication logs recorded yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

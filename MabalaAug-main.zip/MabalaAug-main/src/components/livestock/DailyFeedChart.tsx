import React, { useState, useMemo } from "react";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  CartesianGrid 
} from "recharts";
import { TrendingUp, Calendar, Layers, Scale, DollarSign, Filter } from "lucide-react";
import { DailyFeedLog, AnimalFeedCostLedger } from "../../types";

interface DailyFeedChartProps {
  dailyLogs: DailyFeedLog[];
  ledgers?: AnimalFeedCostLedger[];
  currencySymbol?: string;
  title?: string;
}

export default function DailyFeedChart({
  dailyLogs = [],
  ledgers = [],
  currencySymbol = "ZMW",
  title = "Cumulative Feed Cost & Intake Analytics"
}: DailyFeedChartProps) {
  const [timeframe, setTimeframe] = useState<"7d" | "30d" | "all">("30d");
  const [chartMode, setChartMode] = useState<"cost_trend" | "cohort_breakdown" | "intake_vs_cost">("cost_trend");

  // Process Daily Logs chronologically
  const chartData = useMemo(() => {
    if (!dailyLogs || dailyLogs.length === 0) return [];

    // Clone & sort by date ascending
    const sorted = [...dailyLogs].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    // Filter based on timeframe
    const now = new Date();
    let filtered = sorted;
    if (timeframe === "7d") {
      const cutoff = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      filtered = sorted.filter(l => new Date(l.date) >= cutoff);
    } else if (timeframe === "30d") {
      const cutoff = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      filtered = sorted.filter(l => new Date(l.date) >= cutoff);
    }

    // Group by Date for Trend
    const groupedByDate: Record<string, { date: string; dailyCost: number; dailyQtyKg: number; animalsFed: number; cumulativeCost: number }> = {};
    let runningCumulativeCost = 0;

    filtered.forEach(log => {
      const dKey = log.date || "Unknown";
      if (!groupedByDate[dKey]) {
        groupedByDate[dKey] = {
          date: dKey,
          dailyCost: 0,
          dailyQtyKg: 0,
          animalsFed: 0,
          cumulativeCost: 0
        };
      }
      groupedByDate[dKey].dailyCost += log.totalCost;
      groupedByDate[dKey].dailyQtyKg += log.totalQuantityFedKg;
      groupedByDate[dKey].animalsFed += log.numberOfAnimalsFed;
    });

    // Calculate running cumulative cost
    const result = Object.values(groupedByDate).map(item => {
      runningCumulativeCost += item.dailyCost;
      const avgCostPerHead = item.animalsFed > 0 ? item.dailyCost / item.animalsFed : 0;

      return {
        ...item,
        dailyCost: Number(item.dailyCost.toFixed(2)),
        dailyQtyKg: Number(item.dailyQtyKg.toFixed(1)),
        cumulativeCost: Number(runningCumulativeCost.toFixed(2)),
        avgCostPerHead: Number(avgCostPerHead.toFixed(2))
      };
    });

    return result;
  }, [dailyLogs, timeframe]);

  // Cohort breakdown data
  const cohortBreakdownData = useMemo(() => {
    if (!dailyLogs || dailyLogs.length === 0) return [];

    const grouped: Record<string, { cohortName: string; totalCost: number; totalQtyKg: number; totalAnimalsFed: number }> = {};

    dailyLogs.forEach(log => {
      const cohortKey = log.cohortId || `${log.animalTypeId}_${log.stageId}`;
      if (!grouped[cohortKey]) {
        grouped[cohortKey] = {
          cohortName: cohortKey,
          totalCost: 0,
          totalQtyKg: 0,
          totalAnimalsFed: 0
        };
      }
      grouped[cohortKey].totalCost += log.totalCost;
      grouped[cohortKey].totalQtyKg += log.totalQuantityFedKg;
      grouped[cohortKey].totalAnimalsFed += log.numberOfAnimalsFed;
    });

    return Object.values(grouped).map(item => ({
      ...item,
      totalCost: Number(item.totalCost.toFixed(2)),
      totalQtyKg: Number(item.totalQtyKg.toFixed(1)),
      costPerAnimal: Number((item.totalCost / Math.max(1, item.totalAnimalsFed)).toFixed(2))
    }));
  }, [dailyLogs]);

  // Key KPI Summary
  const totals = useMemo(() => {
    let totalSpent = 0;
    let totalQty = 0;
    let totalAnimals = 0;

    chartData.forEach(d => {
      totalSpent += d.dailyCost;
      totalQty += d.dailyQtyKg;
      totalAnimals += d.animalsFed;
    });

    const avgCostPerAnimal = totalAnimals > 0 ? totalSpent / totalAnimals : 0;

    return {
      totalSpent: Number(totalSpent.toFixed(2)),
      totalQty: Number(totalQty.toFixed(1)),
      avgCostPerAnimal: Number(avgCostPerAnimal.toFixed(2))
    };
  }, [chartData]);

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5">
      {/* HEADER BAR */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-600" />
            {title}
          </h3>
          <p className="text-slate-500 text-xs">
            Visualizing feed expenditure trends, cumulative costs, and consumption per cohort
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          {/* Chart Mode Selector */}
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setChartMode("cost_trend")}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                chartMode === "cost_trend" ? "bg-white text-emerald-800 shadow-xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              Cumulative Trend
            </button>
            <button
              onClick={() => setChartMode("cohort_breakdown")}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                chartMode === "cohort_breakdown" ? "bg-white text-emerald-800 shadow-xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              By Cohort / Pen
            </button>
            <button
              onClick={() => setChartMode("intake_vs_cost")}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                chartMode === "intake_vs_cost" ? "bg-white text-emerald-800 shadow-xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              Intake vs Cost
            </button>
          </div>

          {/* Timeframe Filter */}
          <select
            value={timeframe}
            onChange={e => setTimeframe(e.target.value as any)}
            className="px-3 py-1.5 rounded-xl border border-slate-300 font-bold text-slate-800 bg-white"
          >
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="all">All Time</option>
          </select>
        </div>
      </div>

      {/* TOP KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-emerald-50/60 p-4 rounded-xl border border-emerald-200/60 space-y-1">
          <span className="block text-[10px] uppercase font-black tracking-wider text-emerald-700">Total Feed Spend</span>
          <span className="text-xl font-black text-emerald-950">
            {currencySymbol} {totals.totalSpent.toLocaleString()}
          </span>
          <span className="block text-[11px] font-semibold text-emerald-800/70">
            Period: {timeframe.toUpperCase()}
          </span>
        </div>

        <div className="bg-teal-50/60 p-4 rounded-xl border border-teal-200/60 space-y-1">
          <span className="block text-[10px] uppercase font-black tracking-wider text-teal-700">Total Feed Consumed</span>
          <span className="text-xl font-black text-teal-950">
            {totals.totalQty.toLocaleString()} kg
          </span>
          <span className="block text-[11px] font-semibold text-teal-800/70">
            Cumulative weight fed
          </span>
        </div>

        <div className="bg-amber-50/60 p-4 rounded-xl border border-amber-200/60 space-y-1">
          <span className="block text-[10px] uppercase font-black tracking-wider text-amber-700">Average Cost / Animal</span>
          <span className="text-xl font-black text-amber-950">
            {currencySymbol} {totals.avgCostPerAnimal.toFixed(2)}
          </span>
          <span className="block text-[11px] font-semibold text-amber-800/70">
            Weighted across log period
          </span>
        </div>
      </div>

      {/* CHART RENDERING */}
      {chartData.length === 0 ? (
        <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-300 space-y-2">
          <TrendingUp className="w-12 h-12 text-slate-300 mx-auto" />
          <p className="font-bold text-slate-700 text-sm">No feed log data available for charts.</p>
          <p className="text-slate-400 text-xs">Log daily feeding transactions to see live trend analytics and cohort spend distributions.</p>
        </div>
      ) : (
        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            {chartMode === "cost_trend" ? (
              <AreaChart data={chartData} margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                <defs>
                  <linearGradient id="cumCostGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#059669" stopOpacity={0.05}/>
                  </linearGradient>
                  <linearGradient id="dailyCostGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0d9488" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#0d9488" stopOpacity={0.05}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="#64748b" />
                <YAxis tick={{ fontSize: 11 }} stroke="#64748b" />
                <Tooltip
                  formatter={(val: any, name: any) => [
                    `${currencySymbol} ${Number(val).toFixed(2)}`,
                    name === "cumulativeCost" ? "Cumulative Spend" : "Daily Spend"
                  ]}
                  contentStyle={{ borderRadius: "12px", border: "1px solid #e2e8f0", boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)" }}
                />
                <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "10px" }} />
                <Area type="monotone" dataKey="cumulativeCost" name="Cumulative Spend" stroke="#059669" fillOpacity={1} fill="url(#cumCostGrad)" strokeWidth={3} />
                <Area type="monotone" dataKey="dailyCost" name="Daily Spend" stroke="#0d9488" fillOpacity={1} fill="url(#dailyCostGrad)" strokeWidth={2} />
              </AreaChart>
            ) : chartMode === "cohort_breakdown" ? (
              <BarChart data={cohortBreakdownData} margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="cohortName" tick={{ fontSize: 11 }} stroke="#64748b" />
                <YAxis tick={{ fontSize: 11 }} stroke="#64748b" />
                <Tooltip
                  formatter={(val: any) => [`${currencySymbol} ${Number(val).toFixed(2)}`, "Total Feed Cost"]}
                  contentStyle={{ borderRadius: "12px", border: "1px solid #e2e8f0" }}
                />
                <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "10px" }} />
                <Bar dataKey="totalCost" name="Total Feed Cost per Cohort" fill="#059669" radius={[8, 8, 0, 0]} />
              </BarChart>
            ) : (
              <LineChart data={chartData} margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="#64748b" />
                <YAxis yAxisId="left" tick={{ fontSize: 11 }} stroke="#059669" />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} stroke="#d97706" />
                <Tooltip contentStyle={{ borderRadius: "12px", border: "1px solid #e2e8f0" }} />
                <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "10px" }} />
                <Line yAxisId="left" type="monotone" dataKey="dailyQtyKg" name="Daily Intake (kg)" stroke="#059669" strokeWidth={3} dot={{ r: 4 }} />
                <Line yAxisId="right" type="monotone" dataKey="dailyCost" name="Daily Spend (ZMW)" stroke="#d97706" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            )}
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}

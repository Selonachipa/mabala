import React, { useState, useEffect, useMemo, useRef } from "react";
import { LivestockRecord, PenRecord, Supplier } from "../../types";
import { 
  Check, ArrowRight, ArrowLeft, Camera, Shield, FileCheck, 
  MapPin, Heart, QrCode, ClipboardList, Sparkles, UploadCloud, 
  RotateCcw, Info, Activity, AlertCircle, Trash2, HelpCircle,
  Baby, Users, Plus, Layers, ShieldCheck, Scale, DollarSign, Calendar, Building2
} from "lucide-react";
import { getTenantPens, saveTenantPen, adjustTenantPenHeadcount } from "../../services/feedEngineService";
import UnifiedSupplierModal from "../common/UnifiedSupplierModal";
import { 
  determineBiologicalClassification, 
  BiologicalAssetTier,
  BIOLOGICAL_CHART_OF_ACCOUNTS
} from "../../services/biologicalAssetIntegrationService";

interface AnimalRegistrationWizardProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: LivestockRecord) => void;
  onSaveBatch?: (records: LivestockRecord[]) => void;
  currencySymbol: string;
  existingCount: number;
  activeFarmId: string;
  existingRecords?: LivestockRecord[];
  editingRecord?: LivestockRecord | null;
  pens?: any[];
  suppliers?: Supplier[];
  onAddSupplier?: (sup: Supplier) => void;
}

// Species presets with representative emoji icons and descriptions
const SPECIES_PRESETS = [
  { id: "Cattle", label: "Cattle", icon: "🐂", desc: "Bovine beef & dairy stock" },
  { id: "Goats", label: "Goats", icon: "🐐", desc: "Caprine meat & milk herds" },
  { id: "Sheep", label: "Sheep", icon: "🐑", desc: "Ovine wool & meat breeders" },
  { id: "Pigs", label: "Pigs", icon: "🐖", desc: "Porcine swine husbandry & breeding" },
  { id: "Chicken", label: "Poultry", icon: "🐓", desc: "Poultry broilers & layers" },
  { id: "Other", label: "Other", icon: "🐾", desc: "Custom species category" }
];

// Breed options popular in Zambia and Sub-Saharan Africa
const BREED_PRESETS: Record<string, string[]> = {
  Cattle: ["Boran", "Brahman", "Holstein-Friesian", "Jersey", "Bonsmara", "Sanga", "Tuli", "Nguni", "Angus", "Simmental", "Mashona", "Ankole"],
  Goats: ["Boer", "Kalahari Red", "Galla", "Savannah", "Local Gwembe", "Saanen", "Toggenburg", "Alpine", "Anglo Nubian"],
  Sheep: ["Dorper", "Merino", "Blackhead Persian", "Local Zambian Fat-tail", "Suffolk", "Dorset", "Red Maasai"],
  Pigs: ["Large White", "Landrace", "Camborough Cross", "TN70", "Duroc", "Pietrain", "Hampshire", "Chester White", "Berkshire", "Local / Indigenous"],
  Chicken: ["Broilers", "Layers", "Kuroiler", "Black Australorp", "Boschveld", "Indigenous", "Guinea Fowl", "Ducks", "Turkeys"],
  Other: ["Local Mix", "Crossbreed", "Standard Hybrid"]
};

interface NewbornRow {
  tagId: string;
  gender: "Male" | "Female";
  weightKg: number;
  initialValuation: number;
  color: string;
  healthStatus: "Healthy / Vigorous" | "Underweight / Fragile" | "Stillborn / Deceased";
  notes?: string;
}

export default function AnimalRegistrationWizard({
  isOpen,
  onClose,
  onSave,
  onSaveBatch,
  currencySymbol,
  existingCount,
  activeFarmId,
  existingRecords = [],
  editingRecord,
  suppliers = [],
  onAddSupplier
}: AnimalRegistrationWizardProps) {
  // Registration Category Mode: "standard" | "newborn"
  const [registrationMode, setRegistrationMode] = useState<"standard" | "newborn">("standard");

  // Navigation Screens for Standard Mode:
  // 0: Species Selector
  // 1: Breed Selector
  // 2: Basic Info & Intelligent Classification (Step 1 of Wizard)
  // 3: Health & Acquisition (Step 2 of Wizard)
  // 4: Review & Summary (Step 3 of Wizard)
  const [screen, setScreen] = useState<number>(0);

  // Core Form States (Standard)
  const [species, setSpecies] = useState<string>("Cattle");
  const [customSpecies, setCustomSpecies] = useState<string>("");
  const [breed, setBreed] = useState<string>("Boran");
  const [customBreed, setCustomBreed] = useState<string>("");
  const [tagId, setTagId] = useState<string>("");
  const [gender, setGender] = useState<"Male" | "Female">("Female");
  
  // DOB & Age Helper states
  const [ageInputMode, setAgeInputMode] = useState<"dob" | "estimate">("dob");
  const [dob, setDob] = useState<string>(() => new Date().toISOString().split("T")[0]);
  const [estimatedAgeValue, setEstimatedAgeValue] = useState<number>(12); // in months
  
  // Breeding Toggles
  const [isCastrated, setIsCastrated] = useState<boolean>(false);
  const [breedingStatus, setBreedingStatus] = useState<string>("Open"); // Open, Pregnant, Lactating, Stud, Juvenile
  
  // Automatically Classified and Manual Override Stage
  const [productionStage, setProductionStage] = useState<string>("");
  const [manualOverrideStage, setManualOverrideStage] = useState<boolean>(false);

  // Health & Acquisition
  const [status, setStatus] = useState<string>("Active");
  const [acquisitionType, setAcquisitionType] = useState<"Birthed" | "Purchased" | "Gifted">("Purchased");
  const [purchasePrice, setPurchasePrice] = useState<number>(0);
  const [userValuation, setUserValuation] = useState<number>(12000);
  const [selectedSupplierName, setSelectedSupplierName] = useState<string>("");
  const [showSupplierModal, setShowSupplierModal] = useState<boolean>(false);
  const [weight, setWeight] = useState<number>(320);
  const [color, setColor] = useState<string>("Brown and White speckled");
  const [sire, setSire] = useState<string>("");
  const [dam, setDam] = useState<string>("");
  const [photoBase64, setPhotoBase64] = useState<string>("");
  const [penLocation, setPenLocation] = useState<string>("General Paddock");
  const [selectedPenId, setSelectedPenId] = useState<string>("");
  const [showQuickAddPen, setShowQuickAddPen] = useState<boolean>(false);
  const [quickPenName, setQuickPenName] = useState<string>("");
  const [quickPenCapacity, setQuickPenCapacity] = useState<number>(25);

  // IAS 41 3-Tier Biological Classification State
  const [classificationTier, setClassificationTier] = useState<BiologicalAssetTier>("non_current_biological");
  const [selectedGlAccountCode, setSelectedGlAccountCode] = useState<string>("1450");
  const [classificationManualOverride, setClassificationManualOverride] = useState<boolean>(false);

  // Available Pens List
  const [pensList, setPensList] = useState<any[]>(() => getTenantPens(activeFarmId));

  useEffect(() => {
    if (isOpen) {
      const loaded = getTenantPens(activeFarmId);
      if (loaded && loaded.length > 0) {
        setPensList(loaded);
      }
    }
  }, [isOpen, activeFarmId]);

  // Calculate live occupancy for all pens
  const penOccupancyMap = useMemo(() => {
    const map: Record<string, number> = {};
    existingRecords.forEach(r => {
      if (r.status !== "Sold" && r.status !== "Dead" && r.status !== "Deceased") {
        const penKey = r.penId || r.penName || (r as any).location;
        if (penKey) {
          map[penKey] = (map[penKey] || 0) + 1;
        }
      }
    });
    return map;
  }, [existingRecords]);

  // Handle Quick Pen Creation
  const handleQuickAddPen = (targetSpecies: string) => {
    if (!quickPenName.trim()) return;
    const newPen = saveTenantPen(activeFarmId, {
      id: `pen_${Date.now()}`,
      code: `PEN-${Date.now().toString().slice(-4)}`,
      name: quickPenName.trim(),
      capacity: Number(quickPenCapacity) || 20,
      animalTypeId: (targetSpecies || "goat").toLowerCase(),
      stageId: "grower",
      notes: "Created from Animal Registration Wizard",
      active: true
    });
    const loaded = getTenantPens(activeFarmId);
    setPensList(loaded);
    setPenLocation(newPen.name);
    setSelectedPenId(newPen.id);
    setDeliveryPen(newPen.name);
    setSelectedDeliveryPenId(newPen.id);
    setQuickPenName("");
    setShowQuickAddPen(false);
  };

  // ==========================================
  // NEWBORN REGISTRATION STATES
  // ==========================================
  const [newbornBirthType, setNewbornBirthType] = useState<"single" | "bulk">("single");
  const [newbornSpecies, setNewbornSpecies] = useState<string>("Cattle");
  const [selectedMotherTag, setSelectedMotherTag] = useState<string>("");
  const [newbornSire, setNewbornSire] = useState<string>("Natural Herd Sire");
  const [birthDate, setBirthDate] = useState<string>(() => new Date().toISOString().split("T")[0]);
  const [deliveryPen, setDeliveryPen] = useState<string>("Maternity Pen 1");
  const [selectedDeliveryPenId, setSelectedDeliveryPenId] = useState<string>("");

  // Single Newborn fields
  const [singleTagId, setSingleTagId] = useState<string>("");
  const [singleGender, setSingleGender] = useState<"Male" | "Female">("Female");
  const [singleBirthWeight, setSingleBirthWeight] = useState<number>(28);
  const [singleValuation, setSingleValuation] = useState<number>(2500);
  const [singleColor, setSingleColor] = useState<string>("Brown");
  const [colostrumDipped, setColostrumDipped] = useState<boolean>(true);
  const [navelTreated, setNavelTreated] = useState<boolean>(true);

  // Bulk Litter Newborn fields
  const [bulkLitterCount, setBulkLitterCount] = useState<number>(8);
  const [bulkDefaultValuation, setBulkDefaultValuation] = useState<number>(650);
  const [bulkDefaultWeight, setBulkDefaultWeight] = useState<number>(1.4);
  const [bulkDefaultColor, setBulkDefaultColor] = useState<string>("White/Pink");
  const [bulkTagPrefix, setBulkTagPrefix] = useState<string>("");
  const [bulkRows, setBulkRows] = useState<NewbornRow[]>([]);

  // Filter available mothers from existing records
  const availableMothers = useMemo(() => {
    return existingRecords.filter(r => {
      const isFemale = r.gender === "Female" || (r as any).sex === "Female";
      const notSold = r.status !== "Sold" && r.status !== "Dead" && r.status !== "Deceased";
      const matchesSpecies = !newbornSpecies || r.species === newbornSpecies || r.type === newbornSpecies;
      return isFemale && notSold && matchesSpecies;
    });
  }, [existingRecords, newbornSpecies]);

  // Selected mother object
  const selectedMother = useMemo(() => {
    return existingRecords.find(r => r.tagId === selectedMotherTag || r.id === selectedMotherTag);
  }, [existingRecords, selectedMotherTag]);

  // When selected mother changes, sync species & default tag prefixes
  useEffect(() => {
    if (selectedMother) {
      setNewbornSpecies(selectedMother.species || "Cattle");
      const motherPrefix = selectedMother.tagId ? selectedMother.tagId.replace(/[^a-zA-Z0-9]/g, "") : "DAM";
      const suggestedPrefix = `NB-${motherPrefix}`;
      setBulkTagPrefix(suggestedPrefix);
      if (!singleTagId) {
        setSingleTagId(`${suggestedPrefix}-01`);
      }
    }
  }, [selectedMother]);

  // Update default newborn weights and valuations when newborn species changes
  useEffect(() => {
    if (newbornSpecies === "Cattle") {
      setSingleBirthWeight(32);
      setSingleValuation(2800);
      setBulkDefaultWeight(30);
      setBulkDefaultValuation(2500);
    } else if (newbornSpecies === "Goats") {
      setSingleBirthWeight(3.2);
      setSingleValuation(900);
      setBulkDefaultWeight(3.0);
      setBulkDefaultValuation(850);
    } else if (newbornSpecies === "Sheep") {
      setSingleBirthWeight(3.5);
      setSingleValuation(950);
      setBulkDefaultWeight(3.2);
      setBulkDefaultValuation(900);
    } else if (newbornSpecies === "Pigs") {
      setSingleBirthWeight(1.4);
      setSingleValuation(650);
      setBulkDefaultWeight(1.4);
      setBulkDefaultValuation(650);
      setNewbornBirthType("bulk");
    } else {
      setSingleBirthWeight(1.0);
      setSingleValuation(200);
      setBulkDefaultWeight(1.0);
      setBulkDefaultValuation(200);
    }
  }, [newbornSpecies]);

  // Generate / Regenerate Bulk Newborn Rows
  const regenerateBulkRows = (count: number, prefix: string, defVal: number, defWt: number, defCol: string) => {
    const rows: NewbornRow[] = [];
    const basePrefix = prefix.trim() || `NB-${newbornSpecies.slice(0, 3).toUpperCase()}-${Date.now().toString().slice(-4)}`;
    for (let i = 1; i <= count; i++) {
      const numStr = String(i).padStart(2, "0");
      rows.push({
        tagId: `${basePrefix}-${numStr}`,
        gender: i % 2 === 0 ? "Male" : "Female",
        weightKg: defWt,
        initialValuation: defVal,
        color: defCol,
        healthStatus: "Healthy / Vigorous",
        notes: `Litter birth from ${selectedMotherTag || "Dam"}`
      });
    }
    setBulkRows(rows);
  };

  // Initialize or update bulk rows when count or prefix changes
  useEffect(() => {
    if (registrationMode === "newborn" && newbornBirthType === "bulk") {
      if (bulkRows.length === 0 || bulkRows.length !== bulkLitterCount) {
        regenerateBulkRows(bulkLitterCount, bulkTagPrefix, bulkDefaultValuation, bulkDefaultWeight, bulkDefaultColor);
      }
    }
  }, [registrationMode, newbornBirthType, bulkLitterCount, bulkTagPrefix, newbornSpecies]);

  // Load Edit Record on Mount if provided
  useEffect(() => {
    if (isOpen) {
      if (editingRecord) {
        setRegistrationMode("standard");
        setSpecies(editingRecord.species || "Cattle");
        setBreed(editingRecord.breed || "Boran");
        setTagId(editingRecord.tagId || "");
        setGender(editingRecord.gender || "Female");
        setDob(editingRecord.dob || editingRecord.dateAcquired || new Date().toISOString().split("T")[0]);
        setStatus(editingRecord.status || "Active");
        setAcquisitionType((editingRecord.acquisitionType as any) || "Purchased");
        setPurchasePrice(editingRecord.purchasePrice || 0);
        setUserValuation((editingRecord as any).currentValue || (editingRecord as any).initialValuation || 12000);
        setWeight((editingRecord as any).weight || 320);
        setColor((editingRecord as any).color || "Brown and White speckled");
        setSire((editingRecord as any).sire || "");
        setDam((editingRecord as any).dam || "");
        setPhotoBase64((editingRecord as any).photos?.profile || (editingRecord as any).photoBase64 || "");
        setPenLocation((editingRecord as any).penName || (editingRecord as any).location || "General Paddock");
        setScreen(2);
      } else {
        setScreen(0);
      }
    }
  }, [isOpen, editingRecord]);

  // Dynamic values for Standard mode
  const finalSpecies = useMemo(() => {
    return species === "Other" ? (customSpecies.trim() || "Other") : species;
  }, [species, customSpecies]);

  const finalBreed = useMemo(() => {
    return breed === "Other" ? (customBreed.trim() || "Other") : breed;
  }, [breed, customBreed]);

  // Tag ID Generator for Standard Mode
  const generatedTagId = useMemo(() => {
    const prefix = finalSpecies.toUpperCase().substring(0, 3);
    const orderNum = String(existingCount + 1).padStart(5, "0");
    return `MBL-${prefix}-${orderNum}`;
  }, [finalSpecies, existingCount]);

  const finalTagId = useMemo(() => {
    return tagId.trim() || generatedTagId;
  }, [tagId, generatedTagId]);

  // Dynamic Age representation
  const computedAgeInMonths = useMemo(() => {
    if (ageInputMode === "estimate") {
      return estimatedAgeValue;
    }
    try {
      const birthDateObj = new Date(dob);
      const today = new Date();
      let months = (today.getFullYear() - birthDateObj.getFullYear()) * 12;
      months += today.getMonth() - birthDateObj.getMonth();
      return Math.max(0, months);
    } catch {
      return 12;
    }
  }, [ageInputMode, dob, estimatedAgeValue]);

  // Automatically update dob from estimated age
  useEffect(() => {
    if (ageInputMode === "estimate") {
      const today = new Date();
      today.setMonth(today.getMonth() - estimatedAgeValue);
      setDob(today.toISOString().split("T")[0]);
    }
  }, [estimatedAgeValue, ageInputMode]);

  // Automatically adjust weights and initial default valuation when species change in Standard mode
  const handleSpeciesSelect = (selectedSpecies: string) => {
    setSpecies(selectedSpecies);
    const defaults = BREED_PRESETS[selectedSpecies] || ["Other"];
    setBreed(defaults[0]);
    
    if (selectedSpecies === "Cattle") {
      setWeight(320);
      setUserValuation(12000);
    } else if (selectedSpecies === "Goats") {
      setWeight(45);
      setUserValuation(3500);
    } else if (selectedSpecies === "Sheep") {
      setWeight(45);
      setUserValuation(2800);
    } else if (selectedSpecies === "Pigs") {
      setWeight(85);
      setUserValuation(4200);
    } else if (selectedSpecies === "Chicken") {
      setWeight(1.8);
      setUserValuation(180);
    } else {
      setWeight(15);
      setUserValuation(1500);
    }
    setScreen(1);
  };

  // INTELLIGENT CLASSIFICATION ENGINE
  const autoClassifiedStage = useMemo(() => {
    const ageM = computedAgeInMonths;
    const spec = finalSpecies.toLowerCase();

    if (spec.includes("cattle") || spec.includes("bovine")) {
      if (ageM < 6) return "Weaner Calf";
      if (gender === "Female") {
        if (ageM < 18 && breedingStatus !== "Pregnant") return "Heifer";
        return "Cow";
      } else {
        if (isCastrated) return "Steer";
        if (ageM >= 15) return "Stud Bull";
        return "Young Bull";
      }
    }

    if (spec.includes("goat") || spec.includes("caprine")) {
      if (ageM < 3) return "Kid";
      if (gender === "Female") {
        if (ageM < 10) return "Doeling";
        return "Doe";
      } else {
        if (isCastrated) return "Wether";
        return "Buck";
      }
    }

    if (spec.includes("sheep") || spec.includes("ovine")) {
      if (ageM < 3) return "Lamb";
      if (gender === "Female") {
        if (ageM < 10) return "Ewe Lamb";
        return "Ewe";
      } else {
        if (isCastrated) return "Wether";
        return "Ram";
      }
    }

    if (spec.includes("pig") || spec.includes("porcine")) {
      if (ageM < 2) return "Piglet";
      if (gender === "Female") {
        if (breedingStatus === "Pregnant" || breedingStatus === "Lactating" || ageM >= 8) return "Sow";
        return "Gilt";
      } else {
        if (isCastrated) return "Barrow";
        return "Boar";
      }
    }

    if (spec.includes("chicken") || spec.includes("avian") || spec.includes("poultry")) {
      if (ageM < 1) return "Chick";
      if (gender === "Female") {
        if (ageM < 5) return "Pullet";
        return "Hen";
      } else {
        if (ageM < 5) return "Cockerel";
        return "Rooster";
      }
    }

    return gender === "Female" ? "Dam / Female" : "Sire / Male";
  }, [finalSpecies, gender, computedAgeInMonths, isCastrated, breedingStatus]);

  // Intelligent IAS 41 Biological Classification
  const autoClassification = useMemo(() => {
    return determineBiologicalClassification({
      species: finalSpecies,
      category: finalSpecies,
      purpose: breedingStatus === "Lactating" ? "Dairy Production" : breedingStatus === "Breeding" || (gender === "Male" && computedAgeInMonths >= 12) ? "Breeding Herd" : "Growing / Meat",
      ageInMonths: computedAgeInMonths,
      breedingStatus: breedingStatus,
      isDairy: breedingStatus === "Lactating"
    });
  }, [finalSpecies, gender, computedAgeInMonths, breedingStatus]);

  useEffect(() => {
    if (!classificationManualOverride) {
      setClassificationTier(autoClassification.tier);
      setSelectedGlAccountCode(autoClassification.glAccountCode);
    }
  }, [autoClassification, classificationManualOverride]);

  useEffect(() => {
    if (!manualOverrideStage) {
      setProductionStage(autoClassifiedStage);
    }
  }, [autoClassifiedStage, manualOverrideStage]);

  // Submit Standard Registration
  const handleStandardSubmit = () => {
    // Check Pen Capacity
    const matchedPen = pensList.find(p => p.id === selectedPenId || p.name === penLocation || p.code === penLocation);
    if (matchedPen && matchedPen.capacity) {
      const currentOcc = penOccupancyMap[matchedPen.id] || penOccupancyMap[matchedPen.name] || 0;
      if (currentOcc + 1 > matchedPen.capacity) {
        alert(`⚠️ Cannot Save: Selected Pen "${matchedPen.name}" has reached its maximum capacity of ${matchedPen.capacity} animals (Current occupancy: ${currentOcc}/${matchedPen.capacity}). Please select another pen or create a new one.`);
        return;
      }
    }

    // User-provided actual valuation and actual registration weight
    const userVal = Number(userValuation) || (acquisitionType === "Purchased" ? Number(purchasePrice) : 0) || (finalSpecies === "Cattle" ? 12000 : finalSpecies === "Pigs" ? 4200 : finalSpecies === "Goats" ? 3500 : 2000);
    const userActualWeight = Number(weight) || (finalSpecies === "Cattle" ? 320 : finalSpecies === "Pigs" ? 85 : 45);
    const defaultSpeciesAdg = finalSpecies === "Cattle" ? 0.85 : finalSpecies === "Pigs" ? 0.55 : finalSpecies === "Goats" || finalSpecies === "Sheep" ? 0.15 : 0.02;

    const finalRecord: LivestockRecord = {
      id: editingRecord ? editingRecord.id : ("lv-reg-" + Date.now() + "-" + Math.floor(Math.random() * 1000)),
      type: finalSpecies,
      species: finalSpecies,
      breed: finalBreed,
      tagId: finalTagId,
      gender: gender,
      acquisitionType: acquisitionType,
      source: acquisitionType === "Purchased" ? (selectedSupplierName || "Commercial Purchase") : "On-Farm Birth",
      dateAcquired: dob,
      purchasePrice: acquisitionType === "Purchased" ? Number(purchasePrice) : 0,
      currentValue: userVal,
      initialValuation: userVal,
      status: status,
      farmId: activeFarmId,
      dob: dob,
      registrationDate: dob || new Date().toISOString().split("T")[0],
      lastWeighedDate: dob || new Date().toISOString().split("T")[0],
      age: `${computedAgeInMonths} months`,
      color: color || "Standard pattern",
      weight: userActualWeight,
      currentWeight: userActualWeight,
      registrationWeight: userActualWeight,
      estimatedDailyGain: defaultSpeciesAdg,
      estimatedMarketValue: userVal,
      insuranceValue: Math.round(userVal * 1.25),
      sire: sire.trim() || undefined,
      dam: dam.trim() || undefined,
      penId: matchedPen?.id,
      penName: penLocation,
      location: penLocation,
      photos: {
        profile: photoBase64 || "https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?w=150"
      },
      healthEvents: editingRecord ? (editingRecord.healthEvents || []) : [],
      feedingLogs: editingRecord ? (editingRecord.feedingLogs || []) : [],
      medicationRecords: editingRecord ? (editingRecord.medicationRecords || []) : [],
      isDairy: breedingStatus === "Lactating",
      isCastrated: isCastrated,
      breedingStatus: breedingStatus,
      productionStage: productionStage,
      assetClassification: classificationTier,
      assetTypeCategory: classificationTier === "non_current_biological" ? "Non-Current" : "Current",
      glAccountCode: selectedGlAccountCode
    };

    if (matchedPen?.id) {
      adjustTenantPenHeadcount(activeFarmId, matchedPen.id, 1, `Registered animal ${finalTagId}`);
    }

    onSave(finalRecord);
    onClose();
  };

  // Submit Newborn Registration (Single or Bulk)
  const handleNewbornSubmit = () => {
    const motherDamTag = selectedMother?.tagId || selectedMotherTag || "Unlinked Dam";
    const motherBreed = selectedMother?.breed || (BREED_PRESETS[newbornSpecies] ? BREED_PRESETS[newbornSpecies][0] : "Standard");
    const litterId = `LTR-${Date.now().toString().slice(-6)}`;

    const matchedDeliveryPen = pensList.find(p => p.id === selectedDeliveryPenId || p.name === deliveryPen || p.code === deliveryPen);

    if (newbornBirthType === "single") {
      if (matchedDeliveryPen && matchedDeliveryPen.capacity) {
        const currentOcc = penOccupancyMap[matchedDeliveryPen.id] || penOccupancyMap[matchedDeliveryPen.name] || 0;
        if (currentOcc + 1 > matchedDeliveryPen.capacity) {
          alert(`⚠️ Cannot Save: Maternity Pen "${matchedDeliveryPen.name}" has reached its maximum capacity of ${matchedDeliveryPen.capacity} (Current occupancy: ${currentOcc}/${matchedDeliveryPen.capacity}). Please select another pen with available capacity.`);
          return;
        }
      }

      const targetTag = singleTagId.trim() || `NB-${motherDamTag.replace(/[^a-zA-Z0-9]/g, "")}-${Date.now().toString().slice(-3)}`;
      
      const newRecord: LivestockRecord = {
        id: `lv-nb-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        type: newbornSpecies,
        species: newbornSpecies,
        breed: motherBreed,
        tagId: targetTag,
        gender: singleGender,
        acquisitionType: "Birthed",
        source: "On-Farm Birth",
        dateAcquired: birthDate,
        dob: birthDate,
        birthDate: birthDate,
        birthWeightKg: Number(singleBirthWeight),
        weight: Number(singleBirthWeight),
        currentWeight: Number(singleBirthWeight),
        purchasePrice: 0,
        currentValue: Number(singleValuation) || 1000,
        status: "Active",
        farmId: activeFarmId,
        age: "0 months (Newborn)",
        color: singleColor || "Standard",
        dam: motherDamTag,
        damTagId: motherDamTag,
        damBreed: motherBreed,
        motherId: selectedMother?.id,
        sire: newbornSire || "Natural Stud",
        sireTagId: newbornSire,
        litterId: litterId,
        penId: matchedDeliveryPen?.id,
        penName: deliveryPen,
        location: deliveryPen,
        productionStage: newbornSpecies === "Cattle" ? "Weaner Calf" : newbornSpecies === "Pigs" ? "Piglet" : newbornSpecies === "Goats" ? "Kid" : "Lamb",
        assetClassification: "current_biological",
        assetTypeCategory: "Current",
        glAccountCode: "1400",
        healthEvents: [
          {
            date: birthDate,
            type: "Birth Evaluation",
            details: `Born to Dam ${motherDamTag}. Weight: ${singleBirthWeight}kg. Navel treated: ${navelTreated ? "Yes" : "No"}. Colostrum: ${colostrumDipped ? "Verified" : "Pending"}.`,
            cost: 0
          }
        ],
        feedingLogs: [],
        medicationRecords: []
      };

      if (matchedDeliveryPen?.id) {
        adjustTenantPenHeadcount(activeFarmId, matchedDeliveryPen.id, 1, `Newborn arrival ${targetTag}`);
      }

      onSave(newRecord);
      onClose();
    } else {
      // Bulk Litter Registration
      const viableRows = bulkRows.filter(r => r.healthStatus !== "Stillborn / Deceased");
      const requiredSlots = viableRows.length;

      if (matchedDeliveryPen && matchedDeliveryPen.capacity) {
        const currentOcc = penOccupancyMap[matchedDeliveryPen.id] || penOccupancyMap[matchedDeliveryPen.name] || 0;
        const availableSlots = Math.max(0, matchedDeliveryPen.capacity - currentOcc);
        if (currentOcc + requiredSlots > matchedDeliveryPen.capacity) {
          alert(`⚠️ Cannot Save: Maternity Pen "${matchedDeliveryPen.name}" capacity of ${matchedDeliveryPen.capacity} exceeded! Currently housing ${currentOcc} animals with only ${availableSlots} spot(s) remaining, but this litter requires ${requiredSlots} spots. Please select another pen with sufficient space.`);
          return;
        }
      }

      const createdRecords: LivestockRecord[] = viableRows
        .map((row, index) => {
          return {
            id: `lv-nb-bulk-${Date.now()}-${index}-${Math.floor(Math.random() * 1000)}`,
            type: newbornSpecies,
            species: newbornSpecies,
            breed: motherBreed,
            tagId: row.tagId.trim() || `NB-${motherDamTag}-${index + 1}`,
            gender: row.gender,
            acquisitionType: "Birthed",
            source: "On-Farm Birth (Litter)",
            dateAcquired: birthDate,
            dob: birthDate,
            birthDate: birthDate,
            birthWeightKg: Number(row.weightKg) || 1.4,
            weight: Number(row.weightKg) || 1.4,
            currentWeight: Number(row.weightKg) || 1.4,
            purchasePrice: 0,
            currentValue: Number(row.initialValuation) || 650,
            status: "Active",
            farmId: activeFarmId,
            age: "0 months (Litter Piglet/Offspring)",
            color: row.color || bulkDefaultColor || "Standard",
            dam: motherDamTag,
            damTagId: motherDamTag,
            damBreed: motherBreed,
            motherId: selectedMother?.id,
            sire: newbornSire || "Natural Stud",
            sireTagId: newbornSire,
            litterId: litterId,
            penId: matchedDeliveryPen?.id,
            penName: deliveryPen,
            location: deliveryPen,
            productionStage: newbornSpecies === "Pigs" ? "Piglet" : newbornSpecies === "Cattle" ? "Weaner Calf" : "Kid / Lamb",
            assetClassification: "current_biological",
            assetTypeCategory: "Current",
            glAccountCode: "1400",
            healthEvents: [
              {
                date: birthDate,
                type: "Litter Birth Registration",
                details: `Litter birth (${bulkRows.length} total) from Dam ${motherDamTag}. Individual birth weight: ${row.weightKg}kg. Condition: ${row.healthStatus}.`,
                cost: 0
              }
            ],
            feedingLogs: [],
            medicationRecords: []
          };
        });

      if (matchedDeliveryPen?.id && requiredSlots > 0) {
        adjustTenantPenHeadcount(activeFarmId, matchedDeliveryPen.id, requiredSlots, `Newborn litter of ${requiredSlots} to Dam ${motherDamTag}`);
      }

      if (onSaveBatch) {
        onSaveBatch(createdRecords);
      } else {
        createdRecords.forEach(rec => onSave(rec));
      }

      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4 overflow-y-auto animate-fade-in" id="animal-wizard-overlay">
      <div className="bg-white rounded-3xl max-w-3xl w-full flex flex-col shadow-2xl border border-slate-200 overflow-hidden transform scale-100 transition-all max-h-[95vh]">
        
        {/* Wizard Top Header */}
        <div className="p-5 bg-slate-900 border-b border-slate-800 text-white flex justify-between items-center shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 font-mono">
                Mabala Central Animal Registry
              </span>
              <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 text-[9px] rounded-full font-black uppercase">
                Enterprise v2.6
              </span>
            </div>
            <h2 className="text-base font-extrabold tracking-tight mt-0.5">
              {registrationMode === "standard" ? "Onboard & Register Animal" : "🍼 Newborn Birth & Litter Registration"}
            </h2>
          </div>

          {/* Mode Switcher Pills */}
          <div className="flex bg-slate-800 p-1 rounded-xl border border-slate-700">
            <button
              type="button"
              onClick={() => {
                setRegistrationMode("standard");
                setScreen(0);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                registrationMode === "standard"
                  ? "bg-emerald-600 text-white shadow-xs"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Users className="w-3.5 h-3.5" /> Individual Animal
            </button>
            <button
              type="button"
              onClick={() => setRegistrationMode("newborn")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                registrationMode === "newborn"
                  ? "bg-teal-600 text-white shadow-xs"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Baby className="w-3.5 h-3.5" /> Newborn / Litter Birth
            </button>
          </div>

          <button 
            onClick={onClose}
            className="p-1.5 px-3 text-[11px] bg-slate-800 hover:bg-slate-700/80 rounded-xl font-bold cursor-pointer transition-all border border-slate-700 text-slate-300"
          >
            ✕ Exit
          </button>
        </div>

        {/* ======================================================== */}
        {/* MODE 1: NEWBORN BIRTH & LITTER REGISTRATION INTERFACE   */}
        {/* ======================================================== */}
        {registrationMode === "newborn" ? (
          <div className="p-6 overflow-y-auto space-y-6 text-slate-800 font-sans">
            {/* Context Card & Info */}
            <div className="bg-teal-50 border border-teal-200 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex gap-3 items-center">
                <div className="p-3 bg-teal-600 text-white rounded-xl shadow-xs shrink-0">
                  <Baby className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-xs font-extrabold uppercase text-teal-950">
                    Individual Newborn & Litter Auto-Indexing
                  </h4>
                  <p className="text-[11px] text-teal-800 font-medium">
                    Every newborn is linked to its biological mother (Dam) while receiving its own unique ID, market appraisal value, birth weight, and independent tracking records.
                  </p>
                </div>
              </div>
              <div className="flex bg-white p-1 rounded-xl border border-teal-200 shrink-0">
                <button
                  type="button"
                  onClick={() => setNewbornBirthType("single")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    newbornBirthType === "single"
                      ? "bg-teal-800 text-white shadow-xs"
                      : "text-teal-800 hover:bg-teal-100"
                  }`}
                >
                  Single Offspring (1)
                </button>
                <button
                  type="button"
                  onClick={() => setNewbornBirthType("bulk")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    newbornBirthType === "bulk"
                      ? "bg-teal-800 text-white shadow-xs"
                      : "text-teal-800 hover:bg-teal-100"
                  }`}
                >
                  Bulk Litter (2 - 20)
                </button>
              </div>
            </div>

            {/* Mother / Dam & Breeding Source Configuration Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 border p-4 rounded-2xl">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                  Offspring Species Category
                </label>
                <select
                  value={newbornSpecies}
                  onChange={(e) => {
                    setNewbornSpecies(e.target.value);
                    setSelectedMotherTag("");
                  }}
                  className="w-full text-xs p-2.5 bg-white border rounded-xl font-bold text-slate-800 outline-none"
                >
                  <option value="Cattle">🐂 Cattle (Calf)</option>
                  <option value="Goats">🐐 Goats (Kid)</option>
                  <option value="Sheep">🐑 Sheep (Lamb)</option>
                  <option value="Pigs">🐖 Pigs / Swine (Piglets)</option>
                  <option value="Other">🐾 Other Livestock</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                  Select Mother / Dam (Central Register) *
                </label>
                <select
                  value={selectedMotherTag}
                  onChange={(e) => setSelectedMotherTag(e.target.value)}
                  className="w-full text-xs p-2.5 bg-white border border-teal-600 rounded-xl font-bold text-slate-900 outline-none"
                  required
                >
                  <option value="">-- Choose Dam Tag ID --</option>
                  {availableMothers.map(m => (
                    <option key={m.id} value={m.tagId}>
                      {m.tagId} - {m.breed} ({m.productionStage || m.species}) {m.penName ? `[${m.penName}]` : ""}
                    </option>
                  ))}
                  {availableMothers.length === 0 && (
                    <option value="CUSTOM_DAM">Custom Registered Mother</option>
                  )}
                </select>
                {selectedMother && (
                  <span className="text-[9px] text-teal-800 font-bold block mt-1">
                    ✓ Selected: {selectedMother.tagId} ({selectedMother.breed}, Age: {selectedMother.age || "Adult"})
                  </span>
                )}
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                  Sire / Father Identification
                </label>
                <input
                  type="text"
                  value={newbornSire}
                  onChange={(e) => setNewbornSire(e.target.value)}
                  placeholder="e.g. Stud Bull BOR-01, Boar TN70-A, AI Straw"
                  className="w-full text-xs p-2.5 bg-white border rounded-xl font-bold text-slate-800 outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 block mb-1 flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-slate-400" /> Exact Date of Birth *
                </label>
                <input
                  type="date"
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="w-full text-xs p-2.5 bg-white border rounded-xl font-mono font-bold text-slate-800 outline-none"
                  required
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-[10px] font-black uppercase text-slate-500 flex items-center gap-1">
                    <Layers className="w-3 h-3 text-teal-600" /> Maternity Pen / Housing Location *
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowQuickAddPen(!showQuickAddPen)}
                    className="text-[9px] font-extrabold text-teal-800 hover:text-teal-950 underline flex items-center gap-0.5 cursor-pointer"
                  >
                    <Plus className="w-2.5 h-2.5" /> New Pen
                  </button>
                </div>

                <select
                  value={deliveryPen}
                  onChange={(e) => {
                    setDeliveryPen(e.target.value);
                    const matched = pensList.find(p => p.name === e.target.value || p.id === e.target.value);
                    if (matched) setSelectedDeliveryPenId(matched.id);
                  }}
                  className="w-full text-xs p-2.5 bg-white border border-teal-600 rounded-xl font-bold text-slate-900 outline-none"
                  required
                >
                  <option value="">-- Choose Maternity Pen / Cohort --</option>
                  {pensList.map(p => {
                    const occ = penOccupancyMap[p.id] || penOccupancyMap[p.name] || penOccupancyMap[p.code] || 0;
                    const cap = p.capacity || 20;
                    const isFull = occ >= cap;
                    const speciesLabel = p.animalTypeId ? p.animalTypeId.toUpperCase() : (p.species || "ALL SPECIES");
                    return (
                      <option key={p.id || p.code} value={p.name} disabled={isFull}>
                        {p.code ? `[${p.code}] ` : ""}{p.name} ({speciesLabel}) — {occ}/{cap} heads {isFull ? "⚠️ [FULL]" : `(${cap - occ} available)`}
                      </option>
                    );
                  })}
                </select>

                {/* Pen Capacity Indicator */}
                {deliveryPen && (() => {
                  const p = pensList.find(pen => pen.name === deliveryPen || pen.id === deliveryPen);
                  if (!p) return null;
                  const occ = penOccupancyMap[p.id] || penOccupancyMap[p.name] || 0;
                  const cap = p.capacity || 20;
                  const needed = newbornBirthType === "single" ? 1 : bulkRows.filter(r => r.healthStatus !== "Stillborn / Deceased").length;
                  const isExceeded = occ + needed > cap;
                  return (
                    <div className={`mt-1.5 p-2 rounded-lg text-[10px] font-bold flex items-center justify-between ${
                      isExceeded ? "bg-rose-50 border border-rose-200 text-rose-800" : "bg-emerald-50 border border-emerald-200 text-emerald-800"
                    }`}>
                      <span>Capacity: {occ}/{cap} occupied {isExceeded ? `(⚠️ Need ${needed} spots, only ${Math.max(0, cap - occ)} left)` : `(✓ ${cap - occ} spots open)`}</span>
                      <span className="font-mono text-[9px] font-black">{Math.round((occ / cap) * 100)}% Full</span>
                    </div>
                  );
                })()}

                {showQuickAddPen && (
                  <div className="mt-2 p-2.5 bg-teal-50 border border-teal-200 rounded-xl space-y-2 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-black uppercase text-teal-900">Quick-Create Maternity Pen</span>
                      <button type="button" onClick={() => setShowQuickAddPen(false)} className="text-slate-400 hover:text-slate-600">✕</button>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder="Pen Name (e.g. Farrowing 3)"
                        value={quickPenName}
                        onChange={(e) => setQuickPenName(e.target.value)}
                        className="p-1.5 bg-white border rounded-lg text-xs font-bold"
                      />
                      <input
                        type="number"
                        placeholder="Capacity"
                        value={quickPenCapacity}
                        onChange={(e) => setQuickPenCapacity(Number(e.target.value))}
                        className="p-1.5 bg-white border rounded-lg text-xs font-mono font-bold"
                        min={1}
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => handleQuickAddPen(newbornSpecies)}
                      className="w-full py-1 bg-teal-700 hover:bg-teal-800 text-white rounded-lg text-[10px] font-extrabold cursor-pointer"
                    >
                      Save & Assign Pen
                    </button>
                  </div>
                )}
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                  Breed Classification
                </label>
                <input
                  type="text"
                  value={selectedMother?.breed || (BREED_PRESETS[newbornSpecies] ? BREED_PRESETS[newbornSpecies][0] : "Standard")}
                  readOnly
                  className="w-full text-xs p-2.5 bg-slate-100 border rounded-xl font-bold text-slate-700 outline-none cursor-not-allowed"
                />
              </div>
            </div>

            {/* SINGLE NEWBORN REGISTRATION FORM */}
            {newbornBirthType === "single" && (
              <div className="border border-teal-200 bg-white rounded-2xl p-5 space-y-4 shadow-xs">
                <div className="flex justify-between items-center border-b pb-3">
                  <h4 className="text-xs font-black uppercase text-slate-900 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-teal-600" /> Single Newborn Profile Data
                  </h4>
                  <span className="text-[10px] font-mono text-teal-800 font-extrabold bg-teal-50 px-2 py-0.5 rounded border border-teal-100">
                    Individual Asset #{singleTagId || "TAG"}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                      Newborn Unique Ear Tag ID *
                    </label>
                    <input
                      type="text"
                      value={singleTagId}
                      onChange={(e) => setSingleTagId(e.target.value)}
                      placeholder="e.g. NB-COW01-01"
                      className="w-full text-xs p-2.5 bg-slate-50 border border-teal-500 rounded-xl font-mono font-bold text-slate-900 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                      Gender / Sex *
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setSingleGender("Female")}
                        className={`p-2.5 rounded-xl text-xs font-bold transition-all ${
                          singleGender === "Female"
                            ? "bg-rose-700 text-white shadow-xs font-black"
                            : "bg-slate-100 text-slate-700 border"
                        }`}
                      >
                        ♀ Female (Heifer/Doe/Gilt)
                      </button>
                      <button
                        type="button"
                        onClick={() => setSingleGender("Male")}
                        className={`p-2.5 rounded-xl text-xs font-bold transition-all ${
                          singleGender === "Male"
                            ? "bg-blue-800 text-white shadow-xs font-black"
                            : "bg-slate-100 text-slate-700 border"
                        }`}
                      >
                        ♂ Male (Bull/Buck/Boar)
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                      Birth Weight (Kg) *
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={singleBirthWeight === 0 ? "" : singleBirthWeight}
                      onChange={(e) => setSingleBirthWeight(e.target.value === "" ? 0 : Number(e.target.value))}
                      className="w-full text-xs p-2.5 bg-slate-50 border rounded-xl font-mono font-bold text-slate-900 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                      Initial Fair Stock Valuation ({currencySymbol}) *
                    </label>
                    <input
                      type="number"
                      value={singleValuation === 0 ? "" : singleValuation}
                      onChange={(e) => setSingleValuation(e.target.value === "" ? 0 : Number(e.target.value))}
                      className="w-full text-xs p-2.5 bg-emerald-50/50 border border-emerald-300 rounded-xl font-mono font-black text-emerald-950 outline-none"
                      required
                    />
                    <span className="text-[9px] text-slate-400 block mt-0.5">
                      Debits Account 1420 (Biological Assets) & Credits 4400
                    </span>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                      Color / Physical Markings
                    </label>
                    <input
                      type="text"
                      value={singleColor}
                      onChange={(e) => setSingleColor(e.target.value)}
                      placeholder="e.g. Red roan, white face blaze"
                      className="w-full text-xs p-2.5 bg-slate-50 border rounded-xl font-bold text-slate-800 outline-none"
                    />
                  </div>

                  <div className="flex flex-col justify-center gap-2">
                    <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={colostrumDipped}
                        onChange={(e) => setColostrumDipped(e.target.checked)}
                        className="rounded border-slate-300 text-teal-600"
                      />
                      <span>Colostrum Consumed within 4 Hours</span>
                    </label>
                    <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={navelTreated}
                        onChange={(e) => setNavelTreated(e.target.checked)}
                        className="rounded border-slate-300 text-teal-600"
                      />
                      <span>Navel Cord Dipped (Iodine 7%)</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* BULK LITTER NEWBORN REGISTRATION INTERFACE */}
            {newbornBirthType === "bulk" && (
              <div className="border border-teal-200 bg-white rounded-2xl p-5 space-y-4 shadow-xs">
                <div className="flex flex-wrap justify-between items-center border-b pb-3 gap-3">
                  <div>
                    <h4 className="text-xs font-black uppercase text-slate-900 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-teal-600" /> Multi-Offspring / Litter Batch Table
                    </h4>
                    <p className="text-[10px] text-slate-400">
                      Configure batch size and edit individual gender, tag IDs, birth weights, and valuations.
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-slate-500 uppercase">Litter Headcount:</span>
                    <input
                      type="number"
                      min={2}
                      max={24}
                      value={bulkLitterCount}
                      onChange={(e) => {
                        const cnt = Math.max(2, Math.min(24, Number(e.target.value) || 2));
                        setBulkLitterCount(cnt);
                      }}
                      className="w-16 p-1.5 text-xs text-center border font-mono font-black rounded-lg bg-slate-50"
                    />
                  </div>
                </div>

                {/* Bulk defaults controller */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-xl border text-xs">
                  <div>
                    <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Tag Prefix</label>
                    <input
                      type="text"
                      value={bulkTagPrefix}
                      onChange={(e) => setBulkTagPrefix(e.target.value)}
                      placeholder="e.g. NB-PIG01"
                      className="w-full p-1.5 border bg-white rounded-lg font-mono font-bold text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Default Weight (Kg)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={bulkDefaultWeight}
                      onChange={(e) => setBulkDefaultWeight(Number(e.target.value))}
                      className="w-full p-1.5 border bg-white rounded-lg font-mono font-bold text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Default Value ({currencySymbol})</label>
                    <input
                      type="number"
                      value={bulkDefaultValuation}
                      onChange={(e) => setBulkDefaultValuation(Number(e.target.value))}
                      className="w-full p-1.5 border bg-white rounded-lg font-mono font-bold text-xs"
                    />
                  </div>
                  <div className="flex items-end">
                    <button
                      type="button"
                      onClick={() => regenerateBulkRows(bulkLitterCount, bulkTagPrefix, bulkDefaultValuation, bulkDefaultWeight, bulkDefaultColor)}
                      className="w-full p-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" /> Apply Defaults
                    </button>
                  </div>
                </div>

                {/* Interactive Table of Individual Newborns */}
                <div className="border rounded-xl overflow-hidden max-h-72 overflow-y-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-100 text-[10px] uppercase font-bold text-slate-600 sticky top-0 border-b">
                      <tr>
                        <th className="p-2.5">#</th>
                        <th className="p-2.5">Ear Tag ID</th>
                        <th className="p-2.5">Sex / Gender</th>
                        <th className="p-2.5">Birth Wt (Kg)</th>
                        <th className="p-2.5">Appraisal Val ({currencySymbol})</th>
                        <th className="p-2.5">Condition</th>
                        <th className="p-2.5">Color / Markings</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y font-semibold text-slate-800">
                      {bulkRows.map((row, idx) => (
                        <tr key={idx} className="hover:bg-teal-50/40">
                          <td className="p-2.5 font-mono text-slate-400 text-[10px]">{idx + 1}</td>
                          <td className="p-2.5">
                            <input
                              type="text"
                              value={row.tagId}
                              onChange={(e) => {
                                const copy = [...bulkRows];
                                copy[idx].tagId = e.target.value;
                                setBulkRows(copy);
                              }}
                              className="p-1 border bg-white rounded font-mono font-bold text-xs w-32"
                            />
                          </td>
                          <td className="p-2.5">
                            <select
                              value={row.gender}
                              onChange={(e) => {
                                const copy = [...bulkRows];
                                copy[idx].gender = e.target.value as any;
                                setBulkRows(copy);
                              }}
                              className="p-1 border bg-white rounded font-bold text-xs"
                            >
                              <option value="Female">♀ Female</option>
                              <option value="Male">♂ Male</option>
                            </select>
                          </td>
                          <td className="p-2.5">
                            <input
                              type="number"
                              step="0.1"
                              value={row.weightKg}
                              onChange={(e) => {
                                const copy = [...bulkRows];
                                copy[idx].weightKg = Number(e.target.value);
                                setBulkRows(copy);
                              }}
                              className="p-1 border bg-white rounded font-mono font-bold text-xs w-20"
                            />
                          </td>
                          <td className="p-2.5">
                            <input
                              type="number"
                              value={row.initialValuation}
                              onChange={(e) => {
                                const copy = [...bulkRows];
                                copy[idx].initialValuation = Number(e.target.value);
                                setBulkRows(copy);
                              }}
                              className="p-1 border bg-white rounded font-mono font-black text-xs w-24 text-emerald-900"
                            />
                          </td>
                          <td className="p-2.5">
                            <select
                              value={row.healthStatus}
                              onChange={(e) => {
                                const copy = [...bulkRows];
                                copy[idx].healthStatus = e.target.value as any;
                                setBulkRows(copy);
                              }}
                              className={`p-1 border rounded text-xs font-bold ${
                                row.healthStatus === "Healthy / Vigorous"
                                  ? "text-emerald-700 bg-emerald-50"
                                  : row.healthStatus === "Stillborn / Deceased"
                                  ? "text-rose-700 bg-rose-50"
                                  : "text-amber-700 bg-amber-50"
                              }`}
                            >
                              <option value="Healthy / Vigorous">Healthy / Vigorous</option>
                              <option value="Underweight / Fragile">Underweight / Fragile</option>
                              <option value="Stillborn / Deceased">Stillborn (Exclude)</option>
                            </select>
                          </td>
                          <td className="p-2.5">
                            <input
                              type="text"
                              value={row.color}
                              onChange={(e) => {
                                const copy = [...bulkRows];
                                copy[idx].color = e.target.value;
                                setBulkRows(copy);
                              }}
                              placeholder="e.g. Pink/white"
                              className="p-1 border bg-white rounded font-bold text-xs w-28"
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Bulk Summary Card */}
                <div className="bg-emerald-950 text-white p-4 rounded-xl flex justify-between items-center flex-wrap gap-3">
                  <div>
                    <span className="text-[10px] text-emerald-300 uppercase font-mono block">Litter Valuation Total</span>
                    <strong className="text-base font-mono text-white">
                      {currencySymbol}{bulkRows.filter(r => r.healthStatus !== "Stillborn / Deceased").reduce((s, r) => s + (Number(r.initialValuation) || 0), 0).toLocaleString()}
                    </strong>
                    <span className="text-[10px] text-emerald-200 block">
                      {bulkRows.filter(r => r.healthStatus !== "Stillborn / Deceased").length} live animals will be saved to Central Registry & Balance Sheet [1420]
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-emerald-300 uppercase font-mono block">Average Birth Weight</span>
                    <strong className="text-sm font-mono text-emerald-100">
                      {(bulkRows.reduce((s, r) => s + (Number(r.weightKg) || 0), 0) / (bulkRows.length || 1)).toFixed(2)} Kg
                    </strong>
                  </div>
                </div>
              </div>
            )}

            {/* Bottom Actions for Newborn */}
            <div className="flex justify-between items-center pt-4 border-t">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleNewbornSubmit}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center gap-2 cursor-pointer transition-all active:scale-97"
              >
                <Check className="w-4 h-4" /> Save {newbornBirthType === "bulk" ? `${bulkRows.filter(r => r.healthStatus !== "Stillborn / Deceased").length} Newborns` : "Newborn Animal"} to Central Register
              </button>
            </div>
          </div>
        ) : (
          /* ======================================================== */
          /* MODE 2: STANDARD / ADULT ANIMAL REGISTRATION FLOW        */
          /* ======================================================== */
          <div className="flex flex-col flex-1 overflow-hidden">
            {/* Step Progress Bar */}
            <div className="w-full bg-slate-100 h-1.5 shrink-0">
              <div 
                className="bg-emerald-500 h-full transition-all duration-300 ease-out"
                style={{ width: `${((screen + 1) / 5) * 100}%` }}
              />
            </div>

            {/* Step Badge Row */}
            <div className="px-5 py-2.5 border-b bg-slate-50 flex justify-between items-center text-[11px] text-slate-500 font-bold font-sans shrink-0">
              <span className="flex items-center gap-1">
                <span className="bg-slate-200 text-slate-800 px-1.5 py-0.5 rounded font-mono font-black text-[9px] mr-1">
                  SCREEN {screen + 1}/5
                </span>
                <span className="text-slate-800 font-black">
                  {screen === 0 && "Select Species Category"}
                  {screen === 1 && `Select Registered ${species} Breed`}
                  {screen === 2 && "Step 1: Bio Profile & Stage Classification"}
                  {screen === 3 && "Step 2: Herd Health & Acquisition History"}
                  {screen === 4 && "Step 3: Verification Certificate Summary"}
                </span>
              </span>
            </div>

            {/* Screen Content Container */}
            <div className="p-6 overflow-y-auto flex-1 text-slate-800 font-sans space-y-6">
              
              {/* SCREEN 0: SPECIES SELECTOR */}
              {screen === 0 && (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-tight">
                      Choose Biological Species Category
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Standardizing animal morphology for veterinary and feed formulation engine.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {SPECIES_PRESETS.map((spec) => (
                      <button
                        key={spec.id}
                        type="button"
                        onClick={() => handleSpeciesSelect(spec.id)}
                        className={`p-4 rounded-2xl border text-left flex flex-col justify-between transition-all hover:scale-102 cursor-pointer ${
                          species === spec.id
                            ? "border-emerald-600 bg-emerald-50/50 shadow-md ring-2 ring-emerald-500/20"
                            : "bg-white border-slate-200 hover:border-slate-300"
                        }`}
                      >
                        <span className="text-3xl mb-2 block">{spec.icon}</span>
                        <div>
                          <h4 className="text-xs font-black text-slate-900">{spec.label}</h4>
                          <p className="text-[10px] text-slate-500 mt-0.5 font-medium leading-tight">{spec.desc}</p>
                        </div>
                      </button>
                    ))}
                  </div>

                  {species === "Other" && (
                    <div className="bg-slate-50 p-4 rounded-2xl border space-y-2">
                      <label className="text-[10px] font-bold text-slate-500 uppercase block">Specify Custom Species</label>
                      <input
                        type="text"
                        value={customSpecies}
                        onChange={(e) => setCustomSpecies(e.target.value)}
                        placeholder="e.g. Camel, Horse, Rabbit"
                        className="w-full p-2.5 text-xs border rounded-xl bg-white font-bold text-slate-800"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* SCREEN 1: BREED SELECTOR */}
              {screen === 1 && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-tight">
                        Select {finalSpecies} Breed
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        Choose verified local, regional, or international breed lineage.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setScreen(0)}
                      className="text-xs text-emerald-700 font-bold hover:underline"
                    >
                      ← Change Species
                    </button>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5">
                    {(BREED_PRESETS[species] || ["Other"]).map((b) => (
                      <button
                        key={b}
                        type="button"
                        onClick={() => {
                          setBreed(b);
                          setScreen(2);
                        }}
                        className={`p-3 rounded-xl border text-xs font-bold text-left transition-all cursor-pointer ${
                          breed === b
                            ? "bg-emerald-800 text-white border-emerald-900 shadow-xs"
                            : "bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200"
                        }`}
                      >
                        {b}
                      </button>
                    ))}
                  </div>

                  {breed === "Other" && (
                    <div className="bg-slate-50 p-4 rounded-2xl border space-y-2">
                      <label className="text-[10px] font-bold text-slate-500 uppercase block">Specify Custom Breed</label>
                      <input
                        type="text"
                        value={customBreed}
                        onChange={(e) => setCustomBreed(e.target.value)}
                        placeholder="e.g. Crossbreed F1"
                        className="w-full p-2.5 text-xs border rounded-xl bg-white font-bold text-slate-800"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* SCREEN 2: BIO PROFILING */}
              {screen === 2 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Ear Tag ID (RFID / Visual) *
                      </label>
                      <input
                        type="text"
                        value={tagId}
                        onChange={(e) => setTagId(e.target.value)}
                        placeholder={generatedTagId}
                        className="w-full text-xs p-2.5 bg-slate-50 border rounded-xl font-mono font-bold text-slate-900"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Gender / Sex *
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setGender("Female")}
                          className={`p-2.5 rounded-xl text-xs font-bold transition-all ${
                            gender === "Female"
                              ? "bg-rose-700 text-white shadow-xs font-black"
                              : "bg-slate-100 text-slate-700 border"
                          }`}
                        >
                          ♀ Female
                        </button>
                        <button
                          type="button"
                          onClick={() => setGender("Male")}
                          className={`p-2.5 rounded-xl text-xs font-bold transition-all ${
                            gender === "Male"
                              ? "bg-blue-800 text-white shadow-xs font-black"
                              : "bg-slate-100 text-slate-700 border"
                          }`}
                        >
                          ♂ Male
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Date of Birth / Estimated Age *
                      </label>
                      <input
                        type="date"
                        value={dob}
                        onChange={(e) => setDob(e.target.value)}
                        className="w-full text-xs p-2.5 bg-slate-50 border rounded-xl font-mono font-bold text-slate-800"
                      />
                      <span className="text-[9px] text-slate-400 mt-0.5 block">
                        Estimated Age: {computedAgeInMonths} months
                      </span>
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Current Live Weight (Kg) *
                      </label>
                      <input
                        type="number"
                        value={weight === 0 ? "" : weight}
                        onChange={(e) => setWeight(e.target.value === "" ? 0 : Number(e.target.value))}
                        className="w-full text-xs p-2.5 bg-slate-50 border rounded-xl font-mono font-bold text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Color / Markings
                      </label>
                      <input
                        type="text"
                        value={color}
                        onChange={(e) => setColor(e.target.value)}
                        placeholder="e.g. Brown with white socks"
                        className="w-full text-xs p-2.5 bg-slate-50 border rounded-xl font-bold text-slate-800"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-[10px] font-black uppercase text-slate-500 flex items-center gap-1">
                          <Layers className="w-3 h-3 text-teal-600" /> Housing Pen / Cohort *
                        </label>
                        <button
                          type="button"
                          onClick={() => setShowQuickAddPen(!showQuickAddPen)}
                          className="text-[9px] font-extrabold text-teal-800 hover:text-teal-950 underline flex items-center gap-0.5 cursor-pointer"
                        >
                          <Plus className="w-2.5 h-2.5" /> New Pen
                        </button>
                      </div>

                      <select
                        value={penLocation}
                        onChange={(e) => {
                          setPenLocation(e.target.value);
                          const matched = pensList.find(p => p.name === e.target.value || p.id === e.target.value);
                          if (matched) setSelectedPenId(matched.id);
                        }}
                        className="w-full text-xs p-2.5 bg-slate-50 border rounded-xl font-bold text-slate-800 outline-none"
                        required
                      >
                        <option value="">-- Choose Housing Pen --</option>
                        {pensList.map(p => {
                          const occ = penOccupancyMap[p.id] || penOccupancyMap[p.name] || penOccupancyMap[p.code] || 0;
                          const cap = p.capacity || 20;
                          const isFull = occ >= cap;
                          const speciesLabel = p.animalTypeId ? p.animalTypeId.toUpperCase() : (p.species || "ALL SPECIES");
                          return (
                            <option key={p.id || p.code} value={p.name} disabled={isFull}>
                              {p.code ? `[${p.code}] ` : ""}{p.name} ({speciesLabel}) — {occ}/{cap} heads {isFull ? "⚠️ [FULL]" : `(${cap - occ} open)`}
                            </option>
                          );
                        })}
                      </select>

                      {/* Pen Capacity Indicator */}
                      {penLocation && (() => {
                        const p = pensList.find(pen => pen.name === penLocation || pen.id === penLocation);
                        if (!p) return null;
                        const occ = penOccupancyMap[p.id] || penOccupancyMap[p.name] || 0;
                        const cap = p.capacity || 20;
                        const isExceeded = occ + 1 > cap;
                        return (
                          <div className={`mt-1.5 p-2 rounded-lg text-[10px] font-bold flex items-center justify-between ${
                            isExceeded ? "bg-rose-50 border border-rose-200 text-rose-800" : "bg-emerald-50 border border-emerald-200 text-emerald-800"
                          }`}>
                            <span>Capacity: {occ}/{cap} occupied {isExceeded ? "(⚠️ Pen Full!)" : `(✓ ${cap - occ} spot available)`}</span>
                            <span className="font-mono text-[9px] font-black">{Math.round((occ / cap) * 100)}%</span>
                          </div>
                        );
                      })()}

                      {showQuickAddPen && (
                        <div className="mt-2 p-2.5 bg-teal-50 border border-teal-200 rounded-xl space-y-2 text-xs">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-black uppercase text-teal-900">Quick-Create Pen</span>
                            <button type="button" onClick={() => setShowQuickAddPen(false)} className="text-slate-400 hover:text-slate-600">✕</button>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <input
                              type="text"
                              placeholder="Pen Name (e.g. Pen B - Heifers)"
                              value={quickPenName}
                              onChange={(e) => setQuickPenName(e.target.value)}
                              className="p-1.5 bg-white border rounded-lg text-xs font-bold"
                            />
                            <input
                              type="number"
                              placeholder="Capacity"
                              value={quickPenCapacity}
                              onChange={(e) => setQuickPenCapacity(Number(e.target.value))}
                              className="p-1.5 bg-white border rounded-lg text-xs font-mono font-bold"
                              min={1}
                            />
                          </div>
                          <button
                            type="button"
                            onClick={() => handleQuickAddPen(finalSpecies)}
                            className="w-full py-1 bg-teal-700 hover:bg-teal-800 text-white rounded-lg text-[10px] font-extrabold cursor-pointer"
                          >
                            Save & Assign Pen
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Production Stage Classifier */}
                  <div className="p-3.5 bg-emerald-50 border border-teal-200 rounded-xl flex justify-between items-center">
                    <div>
                      <span className="text-[9px] uppercase font-bold text-teal-800 block">
                        Intelligent Biological Stage
                      </span>
                      <strong className="text-xs font-black text-emerald-950">
                        {productionStage || autoClassifiedStage}
                      </strong>
                    </div>
                    <span className="text-[10px] text-teal-900 bg-teal-100 px-2 py-0.5 rounded font-bold font-mono">
                      Auto-Classified
                    </span>
                  </div>
                </div>
              )}

              {/* SCREEN 3: HEALTH & ACQUISITION & VALUATION */}
              {screen === 3 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Acquisition Source Mode *
                      </label>
                      <select
                        value={acquisitionType}
                        onChange={(e) => setAcquisitionType(e.target.value as any)}
                        className="w-full text-xs p-2.5 bg-slate-50 border rounded-xl font-bold text-slate-800"
                      >
                        <option value="Purchased">Purchased / Bought (Commercial)</option>
                        <option value="Birthed">Birthed On-Farm</option>
                        <option value="Gifted">Gifted / Transferred</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-emerald-800 block mb-1">
                        Initial Animal Valuation ({currencySymbol}) *
                      </label>
                      <input
                        type="number"
                        value={userValuation === 0 ? "" : userValuation}
                        onChange={(e) => setUserValuation(e.target.value === "" ? 0 : Number(e.target.value))}
                        placeholder="e.g. 12000"
                        className="w-full text-xs p-2.5 bg-emerald-50/50 border border-emerald-300 rounded-xl font-mono font-bold text-slate-900"
                      />
                      <span className="text-[9px] text-slate-500 mt-0.5 block">
                        Actual baseline valuation recognized in Asset Register & General Ledger.
                      </span>
                    </div>

                    {/* IAS 41 Biological Asset Classification & GL Account Selector */}
                    <div className="col-span-1 md:col-span-2 p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                          <div>
                            <span className="text-[11px] font-black uppercase text-emerald-950 block tracking-tight">
                              IAS 41 Biological Asset Classification & General Ledger Integration
                            </span>
                            <p className="text-[10px] text-emerald-800">
                              Determines balance sheet accounting (Non-Current Bearer Stock vs Current Biological Asset vs Inventory) and automatic double-entry posting.
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 self-start sm:self-auto">
                          <span className="text-[10px] font-mono font-bold bg-emerald-100 text-emerald-900 border border-emerald-300 px-2 py-0.5 rounded-lg">
                            Active GL: {selectedGlAccountCode}
                          </span>
                          {!classificationManualOverride ? (
                            <span className="text-[9px] bg-emerald-200/80 text-emerald-950 font-bold px-1.5 py-0.5 rounded-sm uppercase">
                              Auto
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                setClassificationManualOverride(false);
                                setClassificationTier(autoClassification.tier);
                                setSelectedGlAccountCode(autoClassification.glAccountCode);
                              }}
                              className="text-[9px] text-emerald-800 hover:text-emerald-950 underline font-bold cursor-pointer"
                            >
                              Reset
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                        {/* Option 1: Non-Current Biological Asset */}
                        <button
                          type="button"
                          onClick={() => {
                            setClassificationManualOverride(true);
                            setClassificationTier("non_current_biological");
                            if (!["1450", "1460", "1470", "1480", "1490"].includes(selectedGlAccountCode)) {
                              setSelectedGlAccountCode(breedingStatus === "Lactating" ? "1450" : "1460");
                            }
                          }}
                          className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                            classificationTier === "non_current_biological"
                              ? "bg-white border-emerald-600 shadow-xs ring-2 ring-emerald-500/20"
                              : "bg-white/60 border-slate-200 hover:border-emerald-300 hover:bg-white"
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[11px] font-black text-slate-900">Non-Current Bearer</span>
                            <span className="text-[9px] font-mono font-bold text-emerald-800 bg-emerald-100 px-1.5 py-0.2 rounded">
                              Fixed Asset
                            </span>
                          </div>
                          <p className="text-[9.5px] text-slate-600 leading-snug">
                            Breeding bulls/sows, mature dairy herds, draft animals with multi-year productive life (IAS 41).
                          </p>
                        </button>

                        {/* Option 2: Current Biological Asset */}
                        <button
                          type="button"
                          onClick={() => {
                            setClassificationManualOverride(true);
                            setClassificationTier("current_biological");
                            if (!["1400", "1410", "1420", "1430"].includes(selectedGlAccountCode)) {
                              setSelectedGlAccountCode("1400");
                            }
                          }}
                          className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                            classificationTier === "current_biological"
                              ? "bg-white border-emerald-600 shadow-xs ring-2 ring-emerald-500/20"
                              : "bg-white/60 border-slate-200 hover:border-emerald-300 hover:bg-white"
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[11px] font-black text-slate-900">Current Biological</span>
                            <span className="text-[9px] font-mono font-bold text-teal-800 bg-teal-100 px-1.5 py-0.2 rounded">
                              Current Asset
                            </span>
                          </div>
                          <p className="text-[9.5px] text-slate-600 leading-snug">
                            Growing steers, weaners, feeder pigs, broiler flocks destined for meat slaughter / harvest (IAS 41).
                          </p>
                        </button>

                        {/* Option 3: Post-Harvest Produce / Inventory */}
                        <button
                          type="button"
                          onClick={() => {
                            setClassificationManualOverride(true);
                            setClassificationTier("post_harvest_inventory");
                            if (!["1350", "1360", "1370", "1380", "1390"].includes(selectedGlAccountCode)) {
                              setSelectedGlAccountCode("1360");
                            }
                          }}
                          className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                            classificationTier === "post_harvest_inventory"
                              ? "bg-white border-emerald-600 shadow-xs ring-2 ring-emerald-500/20"
                              : "bg-white/60 border-slate-200 hover:border-emerald-300 hover:bg-white"
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[11px] font-black text-slate-900">Post-Harvest Inventory</span>
                            <span className="text-[9px] font-mono font-bold text-amber-800 bg-amber-100 px-1.5 py-0.2 rounded">
                              IAS 2 Stock
                            </span>
                          </div>
                          <p className="text-[9.5px] text-slate-600 leading-snug">
                            Commodities detached from biological source: butchered meat, extracted milk, collected table eggs (IAS 2).
                          </p>
                        </button>
                      </div>

                      {/* GL Account Selector Dropdown */}
                      <div className="flex flex-col sm:flex-row sm:items-center gap-2 pt-1 border-t border-emerald-200/60">
                        <label className="text-[10px] font-black uppercase text-emerald-950 shrink-0">
                          Target GL Posting Account:
                        </label>
                        <select
                          value={selectedGlAccountCode}
                          onChange={(e) => {
                            setClassificationManualOverride(true);
                            setSelectedGlAccountCode(e.target.value);
                          }}
                          className="w-full text-xs p-2 rounded-lg bg-white border border-emerald-300 font-bold text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        >
                          {classificationTier === "non_current_biological" && (
                            <>
                              <option value="1450">1450 - Non-Current Biological Assets: Mature Dairy Herd</option>
                              <option value="1460">1460 - Non-Current Biological Assets: Breeding Stock (Bulls/Sows/Ewes)</option>
                              <option value="1470">1470 - Non-Current Biological Assets: Commercial Laying Flocks</option>
                              <option value="1480">1480 - Non-Current Biological Assets: Draft & Working Animals</option>
                              <option value="1490">1490 - Non-Current Biological Assets: Orchard & Perennial Trees</option>
                            </>
                          )}
                          {classificationTier === "current_biological" && (
                            <>
                              <option value="1400">1400 - Current Biological Assets: Growing Livestock for Market / Fattening</option>
                              <option value="1410">1410 - Current Biological Assets: Standing Harvestable Crops</option>
                              <option value="1420">1420 - Current Biological Assets: Broiler Poultry Flocks</option>
                              <option value="1430">1430 - Current Biological Assets: Aqua Biomass</option>
                            </>
                          )}
                          {classificationTier === "post_harvest_inventory" && (
                            <>
                              <option value="1350">1350 - Inventory: Extracted Raw Milk & Dairy Stock</option>
                              <option value="1360">1360 - Inventory: Dressed Poultry & Butchered Meat</option>
                              <option value="1370">1370 - Inventory: Harvested Table Eggs</option>
                              <option value="1380">1380 - Inventory: Harvested Field Crops & Grains</option>
                              <option value="1390">1390 - Inventory: Harvested Table Fish Lots</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>

                    {acquisitionType === "Purchased" && (
                      <>
                        <div>
                          <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                            Purchase Price ({currencySymbol}) *
                          </label>
                          <input
                            type="number"
                            value={purchasePrice === 0 ? "" : purchasePrice}
                            onChange={(e) => {
                              const val = e.target.value === "" ? 0 : Number(e.target.value);
                              setPurchasePrice(val);
                              if (userValuation === 0 || userValuation === 12000) {
                                setUserValuation(val);
                              }
                            }}
                            className="w-full text-xs p-2.5 bg-slate-50 border rounded-xl font-mono font-bold text-slate-900"
                          />
                        </div>

                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-[10px] font-black uppercase text-slate-500">
                              Breeder / Livestock Supplier
                            </label>
                            <button
                              type="button"
                              onClick={() => setShowSupplierModal(true)}
                              className="text-[10px] font-black text-emerald-600 hover:text-emerald-700 underline cursor-pointer"
                            >
                              + Register New
                            </button>
                          </div>
                          <div className="relative">
                            <Building2 className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
                            <select
                              value={selectedSupplierName}
                              onChange={(e) => setSelectedSupplierName(e.target.value)}
                              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 font-bold text-xs text-slate-800 focus:bg-white focus:border-emerald-500 focus:outline-none"
                            >
                              <option value="">Select Registered Supplier / Breeder...</option>
                              {suppliers.map(s => (
                                <option key={s.id} value={s.name}>
                                  {s.name} ({s.category || "Supplier"})
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </>
                    )}

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Mother / Dam Tag Reference
                      </label>
                      <input
                        type="text"
                        value={dam}
                        onChange={(e) => setDam(e.target.value)}
                        placeholder="e.g. MBL-CAT-0012"
                        className="w-full text-xs p-2.5 bg-slate-50 border rounded-xl font-mono font-bold text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Sire / Father Tag Reference
                      </label>
                      <input
                        type="text"
                        value={sire}
                        onChange={(e) => setSire(e.target.value)}
                        placeholder="e.g. Stud Bull BOR-01"
                        className="w-full text-xs p-2.5 bg-slate-50 border rounded-xl font-mono font-bold text-slate-800"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* SCREEN 4: SUMMARY & VERIFICATION */}
              {screen === 4 && (
                <div className="space-y-4">
                  <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 space-y-3">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                      <div>
                        <span className="text-[9px] uppercase font-mono text-emerald-400 font-bold block">
                          Zambia Traceable Biological Ledger
                        </span>
                        <h4 className="text-sm font-black text-white">
                          Official Certificate of Identification
                        </h4>
                      </div>
                      <span className="px-2 py-0.5 bg-emerald-900 text-emerald-300 rounded font-mono text-[9px] font-bold">
                        Audit Certified ✓
                      </span>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs font-medium">
                      <div>
                        <span className="text-[9px] uppercase text-slate-400 block">Ear Tag ID</span>
                        <strong className="text-emerald-400 font-mono text-sm">{finalTagId}</strong>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase text-slate-400 block">Species & Breed</span>
                        <strong className="text-white">{finalSpecies} ({finalBreed})</strong>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase text-slate-400 block">Gender & Stage</span>
                        <strong className="text-white">{gender} • {productionStage}</strong>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase text-slate-400 block">Registration Weight</span>
                        <strong className="text-white font-mono">{weight} Kg</strong>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase text-slate-400 block">Initial Biological Valuation</span>
                        <strong className="text-emerald-400 font-mono text-sm">{currencySymbol}{userValuation.toLocaleString()}</strong>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase text-slate-400 block">Acquisition Mode</span>
                        <strong className="text-white">{acquisitionType}</strong>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase text-slate-400 block">Housing Location</span>
                        <strong className="text-white">{penLocation}</strong>
                      </div>
                      <div className="col-span-2 md:col-span-3 pt-2 border-t border-slate-800 flex items-center justify-between">
                        <div>
                          <span className="text-[9px] uppercase text-emerald-400 font-mono block">
                            IAS 41 Classification & GL Posting Target
                          </span>
                          <span className="text-xs text-slate-200 font-bold">
                            {classificationTier === "non_current_biological" ? "Non-Current Biological (Bearer Stock)" : classificationTier === "current_biological" ? "Current Biological (Growing for Market)" : "Post-Harvest Inventory"}
                          </span>
                        </div>
                        <span className="text-xs font-mono font-black text-emerald-300 bg-emerald-950/80 px-2.5 py-1 rounded-lg border border-emerald-800">
                          GL: {selectedGlAccountCode}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Navigation Footer for Standard Mode */}
            <div className="p-4 bg-slate-50 border-t flex justify-between items-center shrink-0">
              <button
                type="button"
                onClick={() => {
                  if (screen > 0) setScreen(screen - 1);
                  else onClose();
                }}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                {screen === 0 ? "Cancel" : "← Back"}
              </button>

              {screen < 4 ? (
                <button
                  type="button"
                  onClick={() => setScreen(screen + 1)}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  Continue →
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleStandardSubmit}
                  className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Check className="w-4 h-4" /> Save Animal to Central Register
                </button>
              )}
            </div>
          </div>
        )}

        {/* UNIFIED SUPPLIER REGISTRATION MODAL */}
        <UnifiedSupplierModal
          isOpen={showSupplierModal}
          onClose={() => setShowSupplierModal(false)}
          initialCategory="Livestock Breeding & Genetics"
          currencySymbol={currencySymbol}
          farmId={activeFarmId}
          onSaveSupplier={(newSup) => {
            if (onAddSupplier) {
              onAddSupplier(newSup);
            }
            setSelectedSupplierName(newSup.name);
            setShowSupplierModal(false);
          }}
        />
      </div>
    </div>
  );
}

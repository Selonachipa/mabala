import React, { useState } from "react";
import { 
  Beef, 
  Plus, 
  Trash2, 
  Edit2, 
  Save, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  Tag, 
  Calendar,
  Scale
} from "lucide-react";
import { AnimalTypeConfig, AnimalGrowthStage } from "../../types";
import { 
  DEFAULT_ANIMAL_TYPES, 
  saveTenantGrowthStage, 
  deleteTenantGrowthStage, 
  saveTenantAnimalType, 
  deleteTenantAnimalType,
  getTenantAnimalTypes 
} from "../../services/feedEngineService";

interface GrowthStageConfigManagerProps {
  tenantId?: string;
  animalTypes: AnimalTypeConfig[];
  onRefreshData: () => void;
  onShowToast?: (msg: string, type: "success" | "error" | "info") => void;
}

export default function GrowthStageConfigManager({
  tenantId = "default",
  animalTypes,
  onRefreshData,
  onShowToast
}: GrowthStageConfigManagerProps) {
  const [selectedSpeciesId, setSelectedSpeciesId] = useState<string>(animalTypes[0]?.id || "pig");
  
  // Edit Stage State
  const [editingStage, setEditingStage] = useState<AnimalGrowthStage | null>(null);
  const [stageName, setStageName] = useState("");
  const [minAgeDays, setMinAgeDays] = useState<number | "">(0);
  const [maxAgeDays, setMaxAgeDays] = useState<number | "">(30);
  const [isMatureStage, setIsMatureStage] = useState(false);
  const [dailyRation, setDailyRation] = useState<number>(1.0);

  // New Stage Modal/Form
  const [showAddStageModal, setShowAddStageModal] = useState(false);
  const [newStageId, setNewStageId] = useState("");
  const [newStageName, setNewStageName] = useState("");
  const [newMinAge, setNewMinAge] = useState<number | "">(0);
  const [newMaxAge, setNewMaxAge] = useState<number | "">(30);
  const [newIsMature, setNewIsMature] = useState(false);
  const [newRation, setNewRation] = useState<number>(1.0);

  // New Species Form
  const [showAddSpeciesModal, setShowAddSpeciesModal] = useState(false);
  const [newSpeciesId, setNewSpeciesId] = useState("");
  const [newSpeciesName, setNewSpeciesName] = useState("");
  const [newUom, setNewUom] = useState("kg");
  const [newCountUnit, setNewCountUnit] = useState("head");

  const currentSpecies = animalTypes.find(a => a.id === selectedSpeciesId) || animalTypes[0];

  const handleOpenEditStage = (stage: AnimalGrowthStage) => {
    setEditingStage(stage);
    setStageName(stage.name);
    if (stage.ageRangeDays === null) {
      setIsMatureStage(true);
      setMinAgeDays("");
      setMaxAgeDays("");
    } else {
      setIsMatureStage(false);
      setMinAgeDays(stage.ageRangeDays[0]);
      setMaxAgeDays(stage.ageRangeDays[1]);
    }
    setDailyRation(stage.defaultDailyRationKg);
  };

  const handleSaveEditedStage = () => {
    if (!editingStage || !currentSpecies) return;
    if (!stageName.trim()) {
      onShowToast?.("Stage name is required", "error");
      return;
    }

    const updatedStage: AnimalGrowthStage = {
      id: editingStage.id,
      name: stageName.trim(),
      ageRangeDays: isMatureStage ? null : [Number(minAgeDays) || 0, Number(maxAgeDays) || 0],
      defaultDailyRationKg: Number(dailyRation) || 0
    };

    saveTenantGrowthStage(tenantId, currentSpecies.id, updatedStage);
    setEditingStage(null);
    onRefreshData();
    onShowToast?.(`Growth stage "${updatedStage.name}" updated successfully`, "success");
  };

  const handleCreateNewStage = () => {
    if (!currentSpecies) return;
    if (!newStageName.trim()) {
      onShowToast?.("Please enter a stage name", "error");
      return;
    }

    const stageId = newStageId.trim().toLowerCase().replace(/\s+/g, "_") || `stage_${Date.now()}`;
    const stage: AnimalGrowthStage = {
      id: stageId,
      name: newStageName.trim(),
      ageRangeDays: newIsMature ? null : [Number(newMinAge) || 0, Number(newMaxAge) || 0],
      defaultDailyRationKg: Number(newRation) || 0
    };

    saveTenantGrowthStage(tenantId, currentSpecies.id, stage);
    setShowAddStageModal(false);
    setNewStageId("");
    setNewStageName("");
    setNewMinAge(0);
    setNewMaxAge(30);
    setNewIsMature(false);
    setNewRation(1.0);
    onRefreshData();
    onShowToast?.(`New growth stage "${stage.name}" added to ${currentSpecies.name}`, "success");
  };

  const handleDeleteStage = (stageId: string, stageName: string) => {
    if (!currentSpecies) return;
    if (currentSpecies.stages.length <= 1) {
      onShowToast?.("Cannot delete the only remaining stage for this species", "error");
      return;
    }
    if (confirm(`Are you sure you want to delete growth stage "${stageName}"?`)) {
      deleteTenantGrowthStage(tenantId, currentSpecies.id, stageId);
      onRefreshData();
      onShowToast?.(`Deleted stage "${stageName}"`, "info");
    }
  };

  const handleCreateSpecies = () => {
    if (!newSpeciesName.trim()) {
      onShowToast?.("Species name is required", "error");
      return;
    }
    const id = newSpeciesId.trim().toLowerCase().replace(/\s+/g, "_") || `species_${Date.now()}`;
    const newConfig: AnimalTypeConfig = {
      id,
      name: newSpeciesName.trim(),
      unitOfMeasure: (newUom.trim() || "kg") as "kg" | "g" | "litre",
      countUnit: (newCountUnit.trim() || "head") as "head" | "1000 fingerlings" | "flock" | "batch" | "birds" | "animals",
      stages: [
        { id: "starter", name: "Starter / Young", ageRangeDays: [0, 60], defaultDailyRationKg: 1.0 },
        { id: "grower", name: "Grower / Adult", ageRangeDays: null, defaultDailyRationKg: 2.0 }
      ]
    };

    saveTenantAnimalType(tenantId, newConfig);
    setSelectedSpeciesId(id);
    setShowAddSpeciesModal(false);
    setNewSpeciesId("");
    setNewSpeciesName("");
    onRefreshData();
    onShowToast?.(`Created animal species "${newConfig.name}"`, "success");
  };

  const handleResetToDefaults = () => {
    if (confirm("Reset all growth stages and animal species to default biological configuration? Any custom stages will be replaced.")) {
      localStorage.setItem(`mabala_${tenantId}_animal_types`, JSON.stringify(DEFAULT_ANIMAL_TYPES));
      onRefreshData();
      onShowToast?.("Growth stages reset to biological defaults", "success");
    }
  };

  return (
    <div id="growth-stage-config-manager" className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-800 font-black text-sm uppercase tracking-wider mb-1">
            <Layers className="w-4 h-4 text-emerald-600" />
            Biological Lifecycle Configuration
          </div>
          <h2 className="text-xl font-black text-slate-900">Animal Species & Growth Stage Rations</h2>
          <p className="text-slate-500 text-xs mt-1">
            Configure age duration brackets, standard daily rations (kg/day/head), and count units for automated stage-based feeding calculations.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            id="btn-add-species"
            onClick={() => setShowAddSpeciesModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Species
          </button>
          <button
            id="btn-reset-stages-default"
            onClick={handleResetToDefaults}
            className="flex items-center gap-1.5 px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 font-bold text-xs rounded-xl transition cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Defaults
          </button>
        </div>
      </div>

      {/* Species Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {animalTypes.map(species => {
          const isSelected = species.id === currentSpecies?.id;
          return (
            <button
              key={species.id}
              id={`tab-species-${species.id}`}
              onClick={() => {
                setSelectedSpeciesId(species.id);
                setEditingStage(null);
              }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer whitespace-nowrap ${
                isSelected
                  ? "bg-emerald-600 text-white shadow-sm"
                  : "bg-white border border-slate-200 text-slate-700 hover:bg-slate-50"
              }`}
            >
              <Beef className={`w-4 h-4 ${isSelected ? "text-white" : "text-slate-400"}`} />
              <span>{species.name}</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${
                isSelected ? "bg-emerald-700 text-emerald-100" : "bg-slate-100 text-slate-500"
              }`}>
                {species.stages.length} stages
              </span>
            </button>
          );
        })}
      </div>

      {currentSpecies && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          {/* Species Banner */}
          <div className="p-5 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-slate-900 text-lg">{currentSpecies.name} Stages</h3>
                <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-full">
                  Unit: {currentSpecies.countUnit}
                </span>
                <span className="text-xs bg-slate-200 text-slate-700 font-bold px-2 py-0.5 rounded-full">
                  Ration UOM: {currentSpecies.unitOfMeasure}
                </span>
              </div>
              <p className="text-slate-500 text-xs mt-0.5">
                Define the progressive life cycles from neonatal/starter through finisher and breeding stocks.
              </p>
            </div>

            <button
              id="btn-add-stage-for-species"
              onClick={() => setShowAddStageModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add Growth Stage
            </button>
          </div>

          {/* Stages Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100/70 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200">
                  <th className="py-3 px-5">Stage ID & Name</th>
                  <th className="py-3 px-5">Age Bracket (Days)</th>
                  <th className="py-3 px-5">Standard Daily Ration</th>
                  <th className="py-3 px-5">Monthly Ration Estimate</th>
                  <th className="py-3 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {currentSpecies.stages.map(stage => {
                  const isEditingThis = editingStage?.id === stage.id;
                  const isAdult = stage.ageRangeDays === null;
                  const monthlyEstimate = (stage.defaultDailyRationKg * 30).toFixed(1);

                  return (
                    <tr key={stage.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-4 px-5">
                        <div className="font-black text-slate-900 text-sm">{stage.name}</div>
                        <div className="text-[10px] text-slate-400 font-mono">ID: {stage.id}</div>
                      </td>

                      <td className="py-4 px-5">
                        {isAdult ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 font-bold text-[11px]">
                            <Calendar className="w-3 h-3" />
                            Mature / Continuous (No upper age limit)
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 font-bold text-[11px]">
                            <Calendar className="w-3 h-3 text-emerald-600" />
                            Day {stage.ageRangeDays![0]} – Day {stage.ageRangeDays![1]} ({stage.ageRangeDays![1] - stage.ageRangeDays![0]} days span)
                          </span>
                        )}
                      </td>

                      <td className="py-4 px-5 font-bold text-slate-800">
                        <div className="flex items-center gap-1.5">
                          <Scale className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-sm font-black text-emerald-700">{stage.defaultDailyRationKg}</span>
                          <span className="text-slate-500">kg / {currentSpecies.countUnit} / day</span>
                        </div>
                      </td>

                      <td className="py-4 px-5 font-bold text-slate-600">
                        ~{monthlyEstimate} kg / month
                      </td>

                      <td className="py-4 px-5 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            id={`btn-edit-stage-${stage.id}`}
                            onClick={() => handleOpenEditStage(stage)}
                            className="p-1.5 hover:bg-slate-100 text-slate-600 hover:text-slate-900 rounded-lg transition cursor-pointer"
                            title="Edit Stage"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            id={`btn-delete-stage-${stage.id}`}
                            onClick={() => handleDeleteStage(stage.id, stage.name)}
                            className="p-1.5 hover:bg-rose-50 text-rose-400 hover:text-rose-600 rounded-lg transition cursor-pointer"
                            title="Delete Stage"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* EDIT STAGE MODAL */}
      {editingStage && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-slate-900 text-base">Edit Stage: {editingStage.name}</h3>
              <span className="text-[10px] font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-600">{editingStage.id}</span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Stage Display Name</label>
                <input
                  type="text"
                  value={stageName}
                  onChange={e => setStageName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                />
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-800">
                  <input
                    type="checkbox"
                    checked={isMatureStage}
                    onChange={e => setIsMatureStage(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Mature / Breeding / Uncapped Age Stage</span>
                </label>

                {!isMatureStage && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="block font-bold text-slate-600 mb-0.5">Start Day (Min Age)</label>
                      <input
                        type="number"
                        min="0"
                        value={minAgeDays}
                        onChange={e => setMinAgeDays(e.target.value === "" ? "" : parseInt(e.target.value))}
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-300 font-bold text-slate-900 bg-white"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-600 mb-0.5">End Day (Max Age)</label>
                      <input
                        type="number"
                        min="1"
                        value={maxAgeDays}
                        onChange={e => setMaxAgeDays(e.target.value === "" ? "" : parseInt(e.target.value))}
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-300 font-bold text-slate-900 bg-white"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Standard Daily Ration (kg / animal / day)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={dailyRation}
                  onChange={e => setDailyRation(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900 text-base"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setEditingStage(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEditedStage}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow cursor-pointer"
              >
                <Save className="w-4 h-4" />
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD STAGE MODAL */}
      {showAddStageModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <h3 className="font-black text-slate-900 text-base">Add New Growth Stage for {currentSpecies?.name}</h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Stage Code / ID (e.g. finisher_plus)</label>
                <input
                  type="text"
                  placeholder="e.g. fattener"
                  value={newStageId}
                  onChange={e => setNewStageId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs text-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Stage Display Name</label>
                <input
                  type="text"
                  placeholder="e.g. Heavy Finisher (160+ days)"
                  value={newStageName}
                  onChange={e => setNewStageName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                />
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-800">
                  <input
                    type="checkbox"
                    checked={newIsMature}
                    onChange={e => setNewIsMature(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Mature / Breeding / Uncapped Age Stage</span>
                </label>

                {!newIsMature && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="block font-bold text-slate-600 mb-0.5">Start Day (Min Age)</label>
                      <input
                        type="number"
                        min="0"
                        value={newMinAge}
                        onChange={e => setNewMinAge(e.target.value === "" ? "" : parseInt(e.target.value))}
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-300 font-bold text-slate-900 bg-white"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-600 mb-0.5">End Day (Max Age)</label>
                      <input
                        type="number"
                        min="1"
                        value={newMaxAge}
                        onChange={e => setNewMaxAge(e.target.value === "" ? "" : parseInt(e.target.value))}
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-300 font-bold text-slate-900 bg-white"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Standard Daily Ration (kg / animal / day)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={newRation}
                  onChange={e => setNewRation(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900 text-base"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setShowAddStageModal(false)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateNewStage}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Add Growth Stage
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD SPECIES MODAL */}
      {showAddSpeciesModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <h3 className="font-black text-slate-900 text-base">Add New Animal Species</h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Species ID (e.g. sheep, rabbit)</label>
                <input
                  type="text"
                  placeholder="e.g. sheep"
                  value={newSpeciesId}
                  onChange={e => setNewSpeciesId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs text-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Display Name</label>
                <input
                  type="text"
                  placeholder="e.g. Sheep (Dorper / Meatmaster)"
                  value={newSpeciesName}
                  onChange={e => setNewSpeciesName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Count Unit</label>
                  <input
                    type="text"
                    placeholder="e.g. head, flock, batch"
                    value={newCountUnit}
                    onChange={e => setNewCountUnit(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Feed Unit of Measure</label>
                  <input
                    type="text"
                    placeholder="e.g. kg, g, lb"
                    value={newUom}
                    onChange={e => setNewUom(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setShowAddSpeciesModal(false)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateSpecies}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Create Species
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

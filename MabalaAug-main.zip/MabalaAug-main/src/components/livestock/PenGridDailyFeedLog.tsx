import React, { useState, useMemo } from "react";
import { 
  Grid, 
  Calendar, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  Edit2,
  Trash2,
  DollarSign, 
  Lock, 
  Beef, 
  Layers, 
  X,
  Search,
  Filter,
  Users,
  Scale,
  Sparkles,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  Activity,
  History,
  Info,
  Check,
  Building,
  Save,
  Tag
} from "lucide-react";
import { 
  PenRecord, 
  FeedFormulation, 
  DailyFeedLog, 
  AnimalTypeConfig 
} from "../../types";
import { 
  getTenantPens, 
  saveTenantPen, 
  deleteTenantPen,
  deleteTenantDailyFeedLog,
  adjustTenantPenHeadcount,
  getPenDailyFeedMetrics,
  logDailyFeedTransaction,
  DEFAULT_ANIMAL_TYPES 
} from "../../services/feedEngineService";
import { useConfirm } from "../ConfirmModal";

interface PenGridDailyFeedLogProps {
  tenantId?: string;
  currencySymbol?: string;
  formulations: FeedFormulation[];
  dailyLogs: DailyFeedLog[];
  animalTypes?: AnimalTypeConfig[];
  accounts?: any[];
  setAccounts?: (accs: any[]) => void;
  activeFarmNodeId?: string;
  onRefreshData: () => void;
  onShowToast?: (msg: string, type: "success" | "error" | "info") => void;
  currentUserRole?: string;
  isSuperAdmin?: boolean;
  userProfile?: any;
}

export default function PenGridDailyFeedLog({
  tenantId = "default",
  currencySymbol = "ZMW",
  formulations,
  dailyLogs,
  animalTypes = DEFAULT_ANIMAL_TYPES,
  accounts,
  setAccounts,
  activeFarmNodeId = "main_farm",
  onRefreshData,
  onShowToast,
  currentUserRole,
  isSuperAdmin,
  userProfile
}: PenGridDailyFeedLogProps) {
  // Main View Toggle
  const [viewMode, setViewMode] = useState<"grid" | "manager" | "logs">("grid");

  // Role authorization check for Super Admin and Farm Owner deletion actions
  const isAuthorizedToDelete = useMemo(() => {
    if (isSuperAdmin) return true;
    const roleLower = (currentUserRole || userProfile?.role || "").toLowerCase();
    const tenantTypeLower = (userProfile?.tenantType || "").toLowerCase();
    if (
      roleLower.includes("super admin") || 
      roleLower.includes("platform admin") || 
      roleLower.includes("platform administrator") ||
      tenantTypeLower === "super_admin"
    ) {
      return true;
    }
    if (
      roleLower === "farm owner" || 
      roleLower === "owner" || 
      roleLower === "administrator" ||
      roleLower === "farmer" ||
      tenantTypeLower === "farmer"
    ) {
      return true;
    }
    return false;
  }, [isSuperAdmin, currentUserRole, userProfile]);

  // Date & Filter States
  const [logDate, setLogDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [searchQuery, setSearchQuery] = useState("");
  const [animalTypeFilter, setAnimalTypeFilter] = useState<string>("all");
  const [stageFilter, setStageFilter] = useState<string>("all");

  // Pens from state
  const [pens, setPens] = useState<PenRecord[]>(() => getTenantPens(tenantId));

  // Modal States
  const [selectedPenForLog, setSelectedPenForLog] = useState<PenRecord | null>(null);
  const [showPenSetupModal, setShowPenSetupModal] = useState<PenRecord | "new" | null>(null);
  const [showHeadcountModal, setShowHeadcountModal] = useState<PenRecord | null>(null);

  // Pen Setup Form State
  const [penFormCode, setPenFormCode] = useState("");
  const [penFormName, setPenFormName] = useState("");
  const [penFormAnimalType, setPenFormAnimalType] = useState("pig");
  const [penFormStage, setPenFormStage] = useState("grower");
  const [penFormRecipeId, setPenFormRecipeId] = useState<string>("");
  const [penFormHeadcount, setPenFormHeadcount] = useState<number>(12);
  const [penFormCapacity, setPenFormCapacity] = useState<number>(20);
  const [penFormNotes, setPenFormNotes] = useState("");

  // Headcount Adjust Form State
  const [adjustReason, setAdjustReason] = useState<"mortality" | "sold" | "transfer_out" | "transfer_in" | "born_or_bought" | "audit">("mortality");
  const [adjustCount, setAdjustCount] = useState<number>(1);
  const [adjustNotes, setAdjustNotes] = useState("");

  // Feed Log Modal Form State
  const [logNumAnimals, setLogNumAnimals] = useState<number>(10);
  const [logActualQty, setLogActualQty] = useState<number | undefined>(undefined);
  const [logNotes, setLogNotes] = useState<string>("");
  const [logMortalityCount, setLogMortalityCount] = useState<number>(0);
  const [logSoldCount, setLogSoldCount] = useState<number>(0);

  const confirmModal = useConfirm();

  const toast = (msg: string, type: "success" | "error" | "info" = "info") => {
    if (onShowToast) onShowToast(msg, type);
  };

  const refreshPens = () => {
    setPens(getTenantPens(tenantId));
  };

  // Find daily logs for the selected date
  const logsForDate = useMemo(() => {
    return dailyLogs.filter(l => l.date === logDate);
  }, [dailyLogs, logDate]);

  // Map logged status per pen code
  const penLoggedMap = useMemo(() => {
    const map: Record<string, DailyFeedLog> = {};
    logsForDate.forEach(l => {
      if (l.cohortId) {
        map[l.cohortId.toUpperCase()] = l;
      }
    });
    return map;
  }, [logsForDate]);

  // Available stages for the currently selected animal type in pen form
  const currentFormAnimalTypeConfig = useMemo(() => {
    return animalTypes.find(a => a.id === penFormAnimalType) || animalTypes[0];
  }, [animalTypes, penFormAnimalType]);

  // Available active recipes for pen form species & stage
  const availableRecipesForPenForm = useMemo(() => {
    return formulations.filter(
      f => f.animalTypeId === penFormAnimalType && 
           f.stageId.toLowerCase() === penFormStage.toLowerCase() &&
           f.status === "active"
    );
  }, [formulations, penFormAnimalType, penFormStage]);

  // Live Pen Form Feed Calculation
  const penFormLiveMetrics = useMemo(() => {
    let recipe: FeedFormulation | undefined;
    if (penFormRecipeId) {
      recipe = formulations.find(f => f.id === penFormRecipeId);
    }
    if (!recipe) {
      recipe = availableRecipesForPenForm[0] || formulations.find(f => f.animalTypeId === penFormAnimalType && f.status === "active");
    }

    const dailyQtyPerHead = recipe ? recipe.dailyQtyPerAnimal : 1.5;
    const costPerKg = recipe ? recipe.costPerKgMix : 5.0;
    const totalDailyFeedKg = Number((penFormHeadcount * dailyQtyPerHead).toFixed(2));
    const totalDailyCost = Number((totalDailyFeedKg * costPerKg).toFixed(2));

    return {
      recipe,
      dailyQtyPerHead,
      costPerKg,
      totalDailyFeedKg,
      totalDailyCost
    };
  }, [penFormRecipeId, penFormAnimalType, penFormHeadcount, formulations, availableRecipesForPenForm]);

  // Open Pen Setup Modal
  const handleOpenCreatePen = () => {
    setPenFormCode("");
    setPenFormName("");
    setPenFormAnimalType(animalTypes[0]?.id || "pig");
    setPenFormStage(animalTypes[0]?.stages[0]?.id || "grower");
    setPenFormRecipeId("");
    setPenFormHeadcount(12);
    setPenFormCapacity(20);
    setPenFormNotes("");
    setShowPenSetupModal("new");
  };

  const handleOpenEditPen = (pen: PenRecord) => {
    setPenFormCode(pen.code);
    setPenFormName(pen.name || `Pen ${pen.code}`);
    setPenFormAnimalType(pen.animalTypeId);
    setPenFormStage(pen.stageId);
    setPenFormRecipeId(pen.assignedFormulationId || "");
    setPenFormHeadcount(pen.headcount);
    setPenFormCapacity(pen.capacity || pen.headcount + 5);
    setPenFormNotes(pen.notes || "");
    setShowPenSetupModal(pen);
  };

  const handleSavePen = (e: React.FormEvent) => {
    e.preventDefault();
    if (!penFormCode.trim()) {
      toast("Please enter a unique Pen Code (e.g. AR1, BL3, Pen 101).", "error");
      return;
    }

    try {
      const isEditing = showPenSetupModal && showPenSetupModal !== "new";
      const saved = saveTenantPen(tenantId, {
        id: isEditing ? (showPenSetupModal as PenRecord).id : undefined,
        code: penFormCode.trim(),
        name: penFormName.trim() || `Pen ${penFormCode.trim().toUpperCase()}`,
        animalTypeId: penFormAnimalType,
        stageId: penFormStage,
        assignedFormulationId: penFormRecipeId || null,
        headcount: Number(penFormHeadcount) || 0,
        capacity: Number(penFormCapacity) || Number(penFormHeadcount),
        notes: penFormNotes.trim(),
        active: true
      });

      toast(`Pen "${saved.code}" (${saved.name}) saved successfully!`, "success");
      setShowPenSetupModal(null);
      refreshPens();
      onRefreshData();
    } catch (err: any) {
      toast(err.message || "Failed to save Pen.", "error");
    }
  };

  const handleDeletePen = async (penId: string, code: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!isAuthorizedToDelete) {
      toast("Permission Denied: Only Super Admin and Farm Owner are authorized to delete Animal Pens.", "error");
      return;
    }
    const confirmed = await confirmModal({
      title: `Delete Animal Pen "${code}"?`,
      message: `Are you sure you want to delete Animal Pen "${code}"? This will permanently remove this pen station configuration and associated feeding records.`,
      type: "danger",
      confirmText: "Delete Pen",
      requireReason: true,
      reasonLabel: "Reason for deleting pen *"
    });
    if (confirmed) {
      deleteTenantPen(tenantId, penId);
      toast(`Animal Pen "${code}" deleted successfully.`, "success");
      if (showPenSetupModal && showPenSetupModal !== "new" && (showPenSetupModal as PenRecord).id === penId) {
        setShowPenSetupModal(null);
      }
      refreshPens();
      onRefreshData();
    }
  };

  const handleDeleteStationFeedLog = async (logId: string, penCode: string, date: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!isAuthorizedToDelete) {
      toast("Permission Denied: Only Super Admin and Farm Owner are authorized to delete Daily Feeding Station logs.", "error");
      return;
    }
    const confirmed = await confirmModal({
      title: `Delete Feeding Log for "${penCode}" (${date})?`,
      message: `Are you sure you want to delete the Daily Feeding Log for Pen "${penCode}" on ${date}? This will reset today's feeding status and update the cost ledger.`,
      type: "danger",
      confirmText: "Delete Log",
      requireReason: true,
      reasonLabel: "Reason for deleting feed transaction *"
    });
    if (confirmed) {
      const success = deleteTenantDailyFeedLog(tenantId, logId, accounts, setAccounts);
      if (success) {
        toast(`Daily Feeding Log for Pen "${penCode}" on ${date} deleted successfully.`, "success");
        if (selectedPenForLog?.code.toUpperCase() === penCode.toUpperCase()) {
          setSelectedPenForLog(null);
        }
        onRefreshData();
      } else {
        toast("Failed to delete daily feeding log.", "error");
      }
    }
  };

  // Open Headcount Adjust Modal
  const handleOpenHeadcountModal = (pen: PenRecord) => {
    setShowHeadcountModal(pen);
    setAdjustReason("mortality");
    setAdjustCount(1);
    setAdjustNotes("");
  };

  const handleApplyHeadcountAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showHeadcountModal) return;
    if (adjustCount <= 0) {
      toast("Please enter a valid count.", "error");
      return;
    }

    const isReduction = adjustReason === "mortality" || adjustReason === "sold" || adjustReason === "transfer_out";
    const delta = isReduction ? -adjustCount : adjustCount;
    const reasonText = adjustReason === "mortality" ? "Mortality recorded" :
                       adjustReason === "sold" ? "Animal sale" :
                       adjustReason === "transfer_out" ? "Transferred out" :
                       adjustReason === "transfer_in" ? "Transferred in" :
                       adjustReason === "born_or_bought" ? "New animals added" : "Audit count adjustment";

    const fullReason = adjustNotes.trim() ? `${reasonText} (${adjustNotes.trim()})` : reasonText;
    adjustTenantPenHeadcount(tenantId, showHeadcountModal.id, delta, fullReason);

    toast(`Updated headcount for Pen ${showHeadcountModal.code}: ${delta > 0 ? `+${delta}` : delta} animals.`, "success");
    setShowHeadcountModal(null);
    refreshPens();
    onRefreshData();
  };

  // Open Log Modal for a Pen
  const handleOpenPenLogModal = (pen: PenRecord) => {
    setSelectedPenForLog(pen);
    setLogNumAnimals(pen.headcount);
    setLogActualQty(undefined);
    setLogNotes("");
    setLogMortalityCount(0);
    setLogSoldCount(0);
  };

  // Active formulation for selected pen's stage or assigned recipe
  const activeFormulationForSelectedPen = useMemo(() => {
    if (!selectedPenForLog) return null;
    if (selectedPenForLog.assignedFormulationId) {
      const assigned = formulations.find(f => f.id === selectedPenForLog.assignedFormulationId);
      if (assigned) return assigned;
    }
    return formulations.find(
      f => f.animalTypeId === selectedPenForLog.animalTypeId && 
           f.stageId.toLowerCase() === selectedPenForLog.stageId.toLowerCase() && 
           f.status === "active"
    ) || formulations.find(f => f.animalTypeId === selectedPenForLog.animalTypeId && f.status === "active");
  }, [formulations, selectedPenForLog]);

  // Computed values for modal
  const liveLogCalc = useMemo(() => {
    if (!activeFormulationForSelectedPen || !selectedPenForLog) return { defaultQty: 0, finalQty: 0, cost: 0 };
    const effectiveAnimals = Math.max(0, logNumAnimals);
    const defaultQty = effectiveAnimals * activeFormulationForSelectedPen.dailyQtyPerAnimal;
    const finalQty = logActualQty !== undefined && logActualQty > 0 ? logActualQty : defaultQty;
    const cost = finalQty * activeFormulationForSelectedPen.costPerKgMix;
    return {
      defaultQty: Number(defaultQty.toFixed(2)),
      finalQty: Number(finalQty.toFixed(2)),
      cost: Number(cost.toFixed(2))
    };
  }, [activeFormulationForSelectedPen, selectedPenForLog, logNumAnimals, logActualQty]);

  // Submit Pen Daily Feed Log
  const handleSubmitPenLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPenForLog) return;
    if (!activeFormulationForSelectedPen) {
      toast(`No active formulation found for stage "${selectedPenForLog.stageId}". Please create or activate one in the Formulations tab.`, "error");
      return;
    }

    try {
      // 1. Post and freeze immutable daily feed transaction
      const { log } = logDailyFeedTransaction(
        tenantId,
        {
          date: logDate,
          farmNodeId: activeFarmNodeId,
          animalTypeId: selectedPenForLog.animalTypeId,
          stageId: selectedPenForLog.stageId,
          cohortId: selectedPenForLog.code,
          formulationId: activeFormulationForSelectedPen.id,
          numberOfAnimalsFed: logNumAnimals,
          totalQuantityFedKg: liveLogCalc.finalQty,
          notes: logNotes + (logMortalityCount > 0 ? ` [Mortality: ${logMortalityCount}]` : "") + (logSoldCount > 0 ? ` [Sold: ${logSoldCount}]` : ""),
          loggedBy: "Pen Feeding Operator"
        },
        "Pen Feeding Operator",
        accounts,
        setAccounts
      );

      // 2. Auto-adjust Pen Headcount if Mortality or Sold were recorded during feeding
      const totalRemoved = logMortalityCount + logSoldCount;
      if (totalRemoved > 0) {
        const reductionReason = `Feeding log adjustment (${logMortalityCount > 0 ? `Mortality: ${logMortalityCount}` : ""} ${logSoldCount > 0 ? `Sold: ${logSoldCount}` : ""})`.trim();
        adjustTenantPenHeadcount(tenantId, selectedPenForLog.id, -totalRemoved, reductionReason);
        refreshPens();
      }

      toast(`Pen ${selectedPenForLog.code} logged successfully! ${liveLogCalc.finalQty} kg fed (${currencySymbol} ${liveLogCalc.cost.toFixed(2)}).`, "success");
      setSelectedPenForLog(null);
      onRefreshData();
    } catch (err: any) {
      toast(err.message || "Failed to log daily feed for pen.", "error");
    }
  };

  // Filtered Pens
  const filteredPens = useMemo(() => {
    return pens.filter(p => {
      const matchSearch = p.code.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (p.name && p.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          p.stageId.toLowerCase().includes(searchQuery.toLowerCase());
      const matchType = animalTypeFilter === "all" || p.animalTypeId === animalTypeFilter;
      const matchStage = stageFilter === "all" || p.stageId.toLowerCase() === stageFilter.toLowerCase();
      return matchSearch && matchType && matchStage;
    });
  }, [pens, searchQuery, animalTypeFilter, stageFilter]);

  // Summary Metrics
  const summaryMetrics = useMemo(() => {
    let totalHeadcount = 0;
    let totalDailyFeedKg = 0;
    let totalDailyCost = 0;

    pens.forEach(pen => {
      totalHeadcount += pen.headcount || 0;
      const metrics = getPenDailyFeedMetrics(pen, formulations);
      totalDailyFeedKg += metrics.totalDailyFeedKg;
      totalDailyCost += metrics.totalDailyCost;
    });

    const totalPens = pens.length;
    const loggedTodayCount = Object.keys(penLoggedMap).length;
    const pendingTodayCount = Math.max(0, totalPens - loggedTodayCount);

    return {
      totalPens,
      totalHeadcount,
      totalDailyFeedKg: Number(totalDailyFeedKg.toFixed(1)),
      totalDailyCost: Number(totalDailyCost.toFixed(2)),
      loggedTodayCount,
      pendingTodayCount
    };
  }, [pens, formulations, penLoggedMap]);

  return (
    <div className="space-y-6">
      {/* HEADER & SUMMARY BAR */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-slate-900 text-lg flex items-center gap-2">
              <Grid className="w-5 h-5 text-emerald-600" />
              Animal Pens & Daily Feeding Station
            </h3>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
              Active Tenant Pens
            </span>
          </div>
          <p className="text-slate-500 text-xs mt-1">
            Setup animal pens, assign active feed recipes, track headcounts with auto-adjust on mortality/sales, and log daily feeding.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* View Switcher */}
          <div className="bg-slate-100 p-1 rounded-xl flex items-center gap-1 border border-slate-200">
            <button
              onClick={() => setViewMode("grid")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                viewMode === "grid"
                  ? "bg-white text-slate-900 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
              Daily Feeding Grid
            </button>
            <button
              onClick={() => setViewMode("manager")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                viewMode === "manager"
                  ? "bg-white text-slate-900 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Pen & Recipe Setup ({pens.length})
            </button>
            <button
              onClick={() => setViewMode("logs")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                viewMode === "logs"
                  ? "bg-white text-slate-900 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <History className="w-3.5 h-3.5" />
              Station Feed Logs ({dailyLogs.length})
            </button>
          </div>

          <button
            onClick={handleOpenCreatePen}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Add Animal Pen
          </button>
        </div>
      </div>

      {/* METRICS STATS CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Pens</span>
          <div className="text-xl font-black text-slate-900">{summaryMetrics.totalPens}</div>
          <span className="text-[10px] text-slate-500 font-semibold">Configured units</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Animals</span>
          <div className="text-xl font-black text-slate-900">{summaryMetrics.totalHeadcount.toLocaleString()}</div>
          <span className="text-[10px] text-slate-500 font-semibold">Current headcount</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Est. Daily Feed</span>
          <div className="text-xl font-black text-emerald-700">{summaryMetrics.totalDailyFeedKg.toLocaleString()} kg</div>
          <span className="text-[10px] text-slate-500 font-semibold">~{(summaryMetrics.totalDailyFeedKg / 50).toFixed(1)} bags (50kg)</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Est. Daily Cost</span>
          <div className="text-xl font-black text-emerald-700">{currencySymbol} {summaryMetrics.totalDailyCost.toLocaleString()}</div>
          <span className="text-[10px] text-slate-500 font-semibold">Mix cost baseline</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Logged Today</span>
          <div className="text-xl font-black text-emerald-600 flex items-center gap-1">
            <CheckCircle2 className="w-5 h-5" />
            {summaryMetrics.loggedTodayCount}
          </div>
          <span className="text-[10px] text-emerald-600 font-semibold">Pens fed</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Pending Feeding</span>
          <div className="text-xl font-black text-amber-600 flex items-center gap-1">
            <AlertCircle className="w-5 h-5" />
            {summaryMetrics.pendingTodayCount}
          </div>
          <span className="text-[10px] text-amber-600 font-semibold">Awaiting feed</span>
        </div>
      </div>

      {/* FILTER & SEARCH TOOLBAR */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search pen code or name..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pl-9 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 placeholder-slate-400 focus:ring-2 focus:ring-emerald-500 w-52"
            />
          </div>

          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
            <span>Species:</span>
            <select
              value={animalTypeFilter}
              onChange={e => {
                setAnimalTypeFilter(e.target.value);
                setStageFilter("all");
              }}
              className="px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Species</option>
              {animalTypes.map(t => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
          </div>

          {animalTypeFilter !== "all" && (
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
              <span>Stage:</span>
              <select
                value={stageFilter}
                onChange={e => setStageFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 capitalize"
              >
                <option value="all">All Stages</option>
                {animalTypes.find(t => t.id === animalTypeFilter)?.stages.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
          )}
        </div>

        {viewMode === "grid" && (
          <div className="flex items-center gap-2 text-xs font-bold">
            <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
              <Calendar className="w-4 h-4 text-emerald-600" />
              <span className="text-slate-500">Date:</span>
              <input
                type="date"
                value={logDate}
                onChange={e => setLogDate(e.target.value)}
                className="bg-transparent border-0 font-extrabold text-slate-900 focus:ring-0 text-xs cursor-pointer"
              />
            </div>
          </div>
        )}
      </div>

      {/* VIEW 1: DAILY FEEDING GRID */}
      {viewMode === "grid" && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {filteredPens.map(pen => {
              const isLogged = !!penLoggedMap[pen.code.toUpperCase()];
              const logEntry = penLoggedMap[pen.code.toUpperCase()];
              const metrics = getPenDailyFeedMetrics(pen, formulations);
              const species = animalTypes.find(a => a.id === pen.animalTypeId);

              return (
                <div
                  key={pen.id}
                  onClick={() => handleOpenPenLogModal(pen)}
                  className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between space-y-3 relative group ${
                    isLogged
                      ? "bg-emerald-50/70 border-emerald-400 shadow-xs"
                      : "bg-white border-slate-200 hover:border-emerald-500 hover:shadow-md"
                  }`}
                >
                  {/* Pen Code & Status Badge */}
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-base font-black text-slate-900 block group-hover:text-emerald-700 transition-colors">
                        {pen.code}
                      </span>
                      <span className="text-[11px] font-bold text-slate-500 capitalize block truncate max-w-[100px]">
                        {pen.stageId}
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      {isAuthorizedToDelete && (
                        <button
                          type="button"
                          onClick={(e) => handleDeletePen(pen.id, pen.code, e)}
                          className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-all"
                          title="Delete Animal Pen (Super Admin & Farm Owner)"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                      {isLogged ? (
                        <span className="p-1 bg-emerald-600 text-white rounded-full shadow-xs" title="Fed today">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </span>
                      ) : (
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-400 ring-4 ring-amber-100 animate-pulse" title="Pending feed" />
                      )}
                    </div>
                  </div>

                  {/* Pen Headcount & Daily Feed Stats */}
                  <div className="space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-slate-600">
                      <span className="text-[10px] text-slate-400 font-semibold uppercase">Headcount</span>
                      <span className="font-extrabold text-slate-900">{pen.headcount} {species?.countUnit || "head"}</span>
                    </div>

                    <div className="flex items-center justify-between text-slate-600">
                      <span className="text-[10px] text-slate-400 font-semibold uppercase">Daily Feed</span>
                      <span className="font-extrabold text-emerald-700">{metrics.totalDailyFeedKg} kg</span>
                    </div>

                    <div className="flex items-center justify-between text-slate-600">
                      <span className="text-[10px] text-slate-400 font-semibold uppercase">Daily Cost</span>
                      <span className="font-black text-slate-800">{currencySymbol} {metrics.totalDailyCost.toFixed(0)}</span>
                    </div>
                  </div>

                  {/* Bottom Action Footer */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] font-bold">
                    {isLogged ? (
                      <div className="flex items-center justify-between w-full">
                        <span className="text-emerald-700 font-black flex items-center gap-1 truncate">
                          <CheckCircle2 className="w-3 h-3 shrink-0" />
                          Fed {logEntry.totalQuantityFedKg} kg
                        </span>
                        {isAuthorizedToDelete && (
                          <button
                            type="button"
                            onClick={(e) => handleDeleteStationFeedLog(logEntry.id, pen.code, logDate, e)}
                            className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-all"
                            title="Delete Today's Feed Log (Reset Station)"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    ) : (
                      <span className="text-slate-400 group-hover:text-emerald-600 font-extrabold flex items-center gap-1">
                        Click to log feed
                        <ArrowRight className="w-3 h-3" />
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {filteredPens.length === 0 && (
            <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-300 space-y-3">
              <Grid className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="font-bold text-slate-700 text-sm">No animal pens match your active filter.</p>
              <button
                onClick={handleOpenCreatePen}
                className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow"
              >
                Create First Pen
              </button>
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: PEN & RECIPE SETUP MANAGER */}
      {viewMode === "manager" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-5">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-black text-slate-900 text-base flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-600" />
                Pen Configurations & Feed Ration Allocations
              </h4>
              <p className="text-xs text-slate-500">
                Setup and manage each physical pen, active growth stages, assigned feed recipes, and animal counts.
              </p>
            </div>
            <button
              onClick={handleOpenCreatePen}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              New Pen
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-600 uppercase font-black text-[10px] border-y border-slate-200">
                  <th className="py-3 px-3">Pen Code / Name</th>
                  <th className="py-3 px-3">Species & Growth Stage</th>
                  <th className="py-3 px-3">Assigned Active Recipe</th>
                  <th className="py-3 px-3 text-right">Headcount</th>
                  <th className="py-3 px-3 text-right">Daily Feed (kg)</th>
                  <th className="py-3 px-3 text-right">Daily Cost</th>
                  <th className="py-3 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {filteredPens.map(pen => {
                  const metrics = getPenDailyFeedMetrics(pen, formulations);
                  const species = animalTypes.find(a => a.id === pen.animalTypeId);
                  const stage = species?.stages.find(s => s.id === pen.stageId);

                  return (
                    <tr key={pen.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-2">
                          <span className="font-black text-slate-900 text-sm px-2 py-0.5 bg-slate-100 rounded border border-slate-200">
                            {pen.code}
                          </span>
                          <span className="font-bold text-slate-700">{pen.name}</span>
                        </div>
                      </td>

                      <td className="py-3 px-3">
                        <span className="font-extrabold text-slate-800">{species?.name || pen.animalTypeId}</span>
                        <span className="block text-[11px] font-semibold text-emerald-700 capitalize">
                          {stage?.name || pen.stageId}
                        </span>
                      </td>

                      <td className="py-3 px-3">
                        {metrics.activeRecipe ? (
                          <div>
                            <span className="font-bold text-slate-900 block flex items-center gap-1">
                              {metrics.activeRecipe.name}
                              <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1 rounded font-mono">v{metrics.activeRecipe.version}</span>
                            </span>
                            <span className="text-[11px] text-slate-500">
                              {currencySymbol} {metrics.activeRecipe.costPerKgMix}/kg • {metrics.activeRecipe.dailyQtyPerAnimal} kg/head/day
                            </span>
                          </div>
                        ) : (
                          <span className="text-amber-700 font-bold flex items-center gap-1">
                            <AlertCircle className="w-3.5 h-3.5" />
                            Default Stage Rate
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-3 text-right font-black text-slate-900">
                        <div className="flex items-center justify-end gap-1.5">
                          <span>{pen.headcount}</span>
                          <button
                            onClick={() => handleOpenHeadcountModal(pen)}
                            className="p-1 text-slate-400 hover:text-emerald-700 hover:bg-emerald-50 rounded"
                            title="Adjust headcount (Mortality, Sold, Transferred)"
                          >
                            <Users className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>

                      <td className="py-3 px-3 text-right font-extrabold text-emerald-700">
                        {metrics.totalDailyFeedKg} kg
                      </td>

                      <td className="py-3 px-3 text-right font-black text-slate-900">
                        {currencySymbol} {metrics.totalDailyCost.toFixed(2)}
                      </td>

                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => handleOpenPenLogModal(pen)}
                            className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-extrabold rounded-lg text-[11px] transition-all"
                            title="Log feeding for pen"
                          >
                            Feed
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenEditPen(pen)}
                            className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded-lg transition-all"
                            title="Edit Pen Setup"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          {isAuthorizedToDelete ? (
                            <button
                              type="button"
                              onClick={(e) => handleDeletePen(pen.id, pen.code, e)}
                              className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                              title="Delete Animal Pen (Super Admin & Farm Owner)"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <button
                              type="button"
                              disabled
                              className="p-1.5 text-slate-300 cursor-not-allowed rounded-lg"
                              title="Only Super Admin and Farm Owner can delete Animal Pens"
                            >
                              <Trash2 className="w-3.5 h-3.5 opacity-30" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW 3: STATION FEED LOGS HISTORY */}
      {viewMode === "logs" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h4 className="font-black text-slate-900 text-base flex items-center gap-2">
                <History className="w-4 h-4 text-emerald-600" />
                Feeding Station Activity & History
              </h4>
              <p className="text-xs text-slate-500">
                Complete transactional audit trail of daily feedings posted across animal pens & stations.
              </p>
            </div>
            <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1 rounded-full border border-slate-200 self-start sm:self-auto">
              Total Logs: {dailyLogs.length}
            </span>
          </div>

          {dailyLogs.length === 0 ? (
            <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-300 space-y-3">
              <Calendar className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="font-bold text-slate-700 text-sm">No daily feeding logs posted yet.</p>
              <p className="text-slate-400 text-xs max-w-sm mx-auto">
                Select any active animal pen in the Daily Feeding Grid to post feed allocations.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200">
                    <th className="py-3 px-3">Date</th>
                    <th className="py-3 px-3">Pen / Cohort</th>
                    <th className="py-3 px-3">Species & Stage</th>
                    <th className="py-3 px-3 text-right">Animals Fed</th>
                    <th className="py-3 px-3 text-right">Qty (kg)</th>
                    <th className="py-3 px-3 text-right">Total Cost</th>
                    <th className="py-3 px-3">Formulation Snapshot</th>
                    <th className="py-3 px-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {dailyLogs
                    .filter(log => {
                      if (!searchQuery) return true;
                      const q = searchQuery.toLowerCase();
                      return (
                        (log.cohortId && log.cohortId.toLowerCase().includes(q)) ||
                        log.animalTypeId.toLowerCase().includes(q) ||
                        log.stageId.toLowerCase().includes(q) ||
                        log.date.includes(q)
                      );
                    })
                    .filter(log => animalTypeFilter === "all" || log.animalTypeId === animalTypeFilter)
                    .filter(log => stageFilter === "all" || log.stageId === stageFilter)
                    .map(log => {
                      const spName = animalTypes.find(a => a.id === log.animalTypeId)?.name || log.animalTypeId;
                      return (
                        <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3 px-3 font-bold text-slate-900 whitespace-nowrap">{log.date}</td>
                          <td className="py-3 px-3 font-extrabold text-slate-900 whitespace-nowrap">
                            <span className="px-2 py-0.5 bg-slate-100 rounded border border-slate-200">
                              {log.cohortId || "General"}
                            </span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="font-bold text-slate-800">{spName}</span>
                            <span className="block text-[10px] text-slate-500 font-semibold capitalize">{log.stageId}</span>
                          </td>
                          <td className="py-3 px-3 text-right font-black text-slate-900">{log.numberOfAnimalsFed}</td>
                          <td className="py-3 px-3 text-right font-bold text-slate-800">{log.totalQuantityFedKg} kg</td>
                          <td className="py-3 px-3 text-right font-black text-emerald-700 whitespace-nowrap">
                            {currencySymbol} {log.totalCost.toFixed(2)}
                          </td>
                          <td className="py-3 px-3 text-slate-500 text-[11px]">
                            <span className="font-bold text-slate-800 block">v{log.formulationVersion}</span>
                            <span className="text-[10px] font-mono text-slate-500">{currencySymbol} {log.formulationSnapshot.costPerKgMix}/kg</span>
                          </td>
                          <td className="py-3 px-3 text-center">
                            {isAuthorizedToDelete ? (
                              <button
                                type="button"
                                onClick={(e) => handleDeleteStationFeedLog(log.id, log.cohortId || "Log", log.date, e)}
                                className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                                title="Delete Daily Feeding Station Log (Super Admin & Farm Owner)"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            ) : (
                              <button
                                type="button"
                                disabled
                                className="p-1.5 text-slate-300 cursor-not-allowed rounded-lg"
                                title="Only Super Admin and Farm Owner can delete daily feeding station logs"
                              >
                                <Trash2 className="w-3.5 h-3.5 opacity-30" />
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* MODAL 1: PEN SETUP / EDIT MODAL */}
      {showPenSetupModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h4 className="font-black text-slate-900 text-base flex items-center gap-2">
                <Building className="w-4 h-4 text-emerald-600" />
                {showPenSetupModal !== "new" ? `Edit Pen: ${(showPenSetupModal as PenRecord).code}` : "Create Animal Pen"}
              </h4>
              <button onClick={() => setShowPenSetupModal(null)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePen} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Pen Code * (e.g. AR1, BL3)</label>
                  <input
                    type="text"
                    placeholder="e.g. AR1, P102"
                    value={penFormCode}
                    onChange={e => setPenFormCode(e.target.value.toUpperCase())}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900 uppercase focus:ring-2 focus:ring-emerald-500 text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Friendly Pen Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Grower Pen Alpha"
                    value={penFormName}
                    onChange={e => setPenFormName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Animal Species *</label>
                  <select
                    value={penFormAnimalType}
                    onChange={e => {
                      setPenFormAnimalType(e.target.value);
                      const matched = animalTypes.find(t => t.id === e.target.value);
                      if (matched && matched.stages[0]) {
                        setPenFormStage(matched.stages[0].id);
                      }
                      setPenFormRecipeId("");
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                  >
                    {animalTypes.map(t => (
                      <option key={t.id} value={t.id}>{t.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Growth Stage *</label>
                  <select
                    value={penFormStage}
                    onChange={e => {
                      setPenFormStage(e.target.value);
                      setPenFormRecipeId("");
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 capitalize"
                  >
                    {currentFormAnimalTypeConfig?.stages.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Active Recipe Allocation */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">Assigned Active Recipe / Feed Formulation</label>
                <select
                  value={penFormRecipeId}
                  onChange={e => setPenFormRecipeId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">
                    {availableRecipesForPenForm.length > 0
                      ? `Automatic Default: ${availableRecipesForPenForm[0].name} (v${availableRecipesForPenForm[0].version})`
                      : "Automatic Standard Reference Ration"}
                  </option>
                  {availableRecipesForPenForm.map(recipe => (
                    <option key={recipe.id} value={recipe.id}>
                      {recipe.name} (v{recipe.version}) — {currencySymbol} {recipe.costPerKgMix}/kg ({recipe.dailyQtyPerAnimal} kg/head/day)
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-400 mt-1">
                  When selected, total daily feed and spend for this pen will calculate using this specific active recipe.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Number of Animals ({currentFormAnimalTypeConfig?.countUnit || "head"}) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={penFormHeadcount}
                    onChange={e => setPenFormHeadcount(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900 text-base focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Pen Max Capacity</label>
                  <input
                    type="number"
                    min="0"
                    value={penFormCapacity}
                    onChange={e => setPenFormCapacity(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800"
                  />
                </div>
              </div>

              {/* LIVE PEN CALCULATIONS PREVIEW */}
              <div className="p-3.5 rounded-xl bg-emerald-900 text-white space-y-2 shadow-inner">
                <div className="flex items-center justify-between text-xs text-emerald-200 font-semibold">
                  <span>Daily Feed Calculation for Pen</span>
                  <span>{penFormLiveMetrics.dailyQtyPerHead} kg/head/day</span>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-emerald-800/80">
                  <div>
                    <span className="text-[10px] text-emerald-300/80 block">Total Daily Feed</span>
                    <span className="text-lg font-black text-emerald-300">{penFormLiveMetrics.totalDailyFeedKg} kg</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-emerald-300/80 block">Total Daily Spend</span>
                    <span className="text-lg font-black text-emerald-400">{currencySymbol} {penFormLiveMetrics.totalDailyCost.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Pen Notes / Location</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Unit 3, Northern Shed, clean water nipple installed..."
                  value={penFormNotes}
                  onChange={e => setPenFormNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium text-slate-800"
                />
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                {showPenSetupModal !== "new" && isAuthorizedToDelete ? (
                  <button
                    type="button"
                    onClick={() => handleDeletePen((showPenSetupModal as PenRecord).id, (showPenSetupModal as PenRecord).code)}
                    className="px-3 py-2 text-red-600 hover:bg-red-50 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all border border-red-200"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete Pen
                  </button>
                ) : <div />}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowPenSetupModal(null)}
                    className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow transition-all flex items-center gap-1.5"
                  >
                    <Save className="w-3.5 h-3.5" />
                    Save Pen Configuration
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: HEADCOUNT ADJUSTMENT (MORTALITY / SOLD / TRANSFER) */}
      {showHeadcountModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h4 className="font-black text-slate-900 text-base">Adjust Headcount: Pen {showHeadcountModal.code}</h4>
                <p className="text-xs text-slate-500">Current count: <span className="font-extrabold text-slate-900">{showHeadcountModal.headcount}</span> animals</p>
              </div>
              <button onClick={() => setShowHeadcountModal(null)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleApplyHeadcountAdjustment} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Reason for Adjustment *</label>
                <select
                  value={adjustReason}
                  onChange={e => setAdjustReason(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="mortality">💀 Mortality Event (Dead Animal)</option>
                  <option value="sold">🛒 Animal Sold / Dispatched</option>
                  <option value="transfer_out">➡️ Transferred Out to Another Pen</option>
                  <option value="transfer_in">⬅️ Transferred In from Another Pen</option>
                  <option value="born_or_bought">🐣 Born / Newly Purchased</option>
                  <option value="audit">📋 Physical Count Audit Correction</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Number of Animals *</label>
                <input
                  type="number"
                  min="1"
                  value={adjustCount}
                  onChange={e => setAdjustCount(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900 text-lg focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Operational Notes / Reason Details</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Sold 2 pigs to butchery at ZMW 3,500 each..."
                  value={adjustNotes}
                  onChange={e => setAdjustNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium text-slate-800"
                />
              </div>

              {/* Preview Adjusted Headcount */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between font-bold">
                <span className="text-slate-600">New Resulting Headcount:</span>
                <span className="text-base font-black text-emerald-700">
                  {adjustReason === "mortality" || adjustReason === "sold" || adjustReason === "transfer_out"
                    ? Math.max(0, showHeadcountModal.headcount - adjustCount)
                    : showHeadcountModal.headcount + adjustCount} animals
                </span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowHeadcountModal(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow transition-all"
                >
                  Apply Headcount Update
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: LOG DAILY FEED FOR PEN */}
      {selectedPenForLog && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h4 className="font-black text-slate-900 text-base flex items-center gap-2">
                  <Grid className="w-4 h-4 text-emerald-600" />
                  Log Daily Feeding: Pen {selectedPenForLog.code}
                </h4>
                <p className="text-xs text-slate-500">
                  Species: <span className="font-extrabold text-slate-800 capitalize">{selectedPenForLog.animalTypeId}</span> • Stage: <span className="font-extrabold text-emerald-700 capitalize">{selectedPenForLog.stageId}</span>
                </p>
              </div>
              <button onClick={() => setSelectedPenForLog(null)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitPenLog} className="space-y-3 text-xs">
              {/* Existing Log for Today Notice */}
              {penLoggedMap[selectedPenForLog.code.toUpperCase()] && (
                <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="font-extrabold text-emerald-900 text-xs flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Feeding logged for this date ({penLoggedMap[selectedPenForLog.code.toUpperCase()].totalQuantityFedKg} kg)
                    </span>
                    <span className="text-[11px] text-emerald-700 block">
                      Cost: {currencySymbol} {penLoggedMap[selectedPenForLog.code.toUpperCase()].totalCost.toFixed(2)} posted to COA.
                    </span>
                  </div>
                  {isAuthorizedToDelete && (
                    <button
                      type="button"
                      onClick={(e) => handleDeleteStationFeedLog(
                        penLoggedMap[selectedPenForLog.code.toUpperCase()].id,
                        selectedPenForLog.code,
                        logDate,
                        e
                      )}
                      className="px-2.5 py-1.5 bg-red-100 hover:bg-red-200 text-red-700 font-extrabold text-xs rounded-lg flex items-center gap-1 transition-all"
                      title="Delete this feeding log and reset station status"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Delete Log
                    </button>
                  )}
                </div>
              )}

              {/* Recipe Snapshot Banner */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="block text-[10px] font-black uppercase text-slate-500 tracking-wider">
                  Active Formulation Assigned
                </span>
                {activeFormulationForSelectedPen ? (
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-extrabold text-slate-900 text-xs">
                        {activeFormulationForSelectedPen.name} (v{activeFormulationForSelectedPen.version})
                      </p>
                      <p className="text-[11px] font-semibold text-slate-600">
                        {currencySymbol} {activeFormulationForSelectedPen.costPerKgMix}/kg • Rate: {activeFormulationForSelectedPen.dailyQtyPerAnimal} kg/head/day
                      </p>
                    </div>
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  </div>
                ) : (
                  <div className="text-amber-700 text-xs font-bold flex items-center gap-1.5 py-1">
                    <AlertCircle className="w-4 h-4 text-amber-600" />
                    No active formulation for this stage!
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Number of Animals Fed</label>
                  <input
                    type="number"
                    min="1"
                    value={logNumAnimals}
                    onChange={e => setLogNumAnimals(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900 text-base focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Total Feed (kg) <span className="font-normal text-slate-400">(Override)</span>
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    placeholder={`Std: ${liveLogCalc.defaultQty} kg`}
                    value={logActualQty === undefined ? "" : logActualQty}
                    onChange={e => setLogActualQty(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* IN-SESSION MORTALITY / SALES TRACKER */}
              <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-2">
                <div className="flex items-center gap-1.5 text-amber-800 font-black text-[11px]">
                  <Info className="w-3.5 h-3.5 text-amber-600" />
                  Recorded Demise or Sales during this feeding session?
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Mortality (Dead)</label>
                    <input
                      type="number"
                      min="0"
                      value={logMortalityCount}
                      onChange={e => setLogMortalityCount(parseInt(e.target.value) || 0)}
                      className="w-full px-2.5 py-1 rounded-lg border border-amber-300 font-bold text-slate-900 bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Animals Sold</label>
                    <input
                      type="number"
                      min="0"
                      value={logSoldCount}
                      onChange={e => setLogSoldCount(parseInt(e.target.value) || 0)}
                      className="w-full px-2.5 py-1 rounded-lg border border-amber-300 font-bold text-slate-900 bg-white"
                    />
                  </div>
                </div>
                {(logMortalityCount > 0 || logSoldCount > 0) && (
                  <p className="text-[10px] text-amber-900 font-semibold">
                    * Pen headcount will automatically decrement by {logMortalityCount + logSoldCount} upon saving.
                  </p>
                )}
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Notes / Feed Intake Observation</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Good appetite, trough cleaned..."
                  value={logNotes}
                  onChange={e => setLogNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium text-slate-800"
                />
              </div>

              {/* LIVE TOTAL COST CARD */}
              <div className="bg-emerald-900 text-white p-4 rounded-xl space-y-1 shadow-inner">
                <div className="flex items-center justify-between text-xs text-emerald-200 font-semibold">
                  <span>Calculated Daily Feed Cost</span>
                  <span>{liveLogCalc.finalQty} kg Total</span>
                </div>
                <div className="text-2xl font-black text-emerald-400">
                  {currencySymbol} {liveLogCalc.cost.toLocaleString()}
                </div>
                <p className="text-[10px] text-emerald-300/80">
                  Will post automatically to COA Feed Expense (Code 5220) and update cost ledger.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedPenForLog(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!activeFormulationForSelectedPen}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center gap-2"
                >
                  <Lock className="w-3.5 h-3.5" />
                  Post & Freeze Daily Feed Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

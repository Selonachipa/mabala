import React, { useState, useMemo } from "react";
import { 
  ShieldCheck, 
  Plus, 
  Calendar, 
  Heart, 
  Award, 
  Activity, 
  Filter, 
  Search, 
  Stethoscope, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  DollarSign, 
  Beef,
  ChevronRight,
  TrendingUp,
  Clock,
  Droplet,
  Upload,
  FileSpreadsheet,
  Trash2,
  AlertTriangle,
  ShoppingCart,
  Skull,
  ChevronDown,
  Check,
  Download
} from "lucide-react";
import { LivestockRecord, SowFarrowingRecord, CashSale } from "../../types";
import { PIG_BREEDS } from "./EnterpriseLivestockManager";
import { safeLocalStorage as localStorage } from "../../utils/safeStorage";
import FarmSaleReceiptModal from "../sales/FarmSaleReceiptModal";

interface PigManagerProps {
  records: LivestockRecord[];
  currencySymbol: string;
  onAddLivestockRecord: (record: LivestockRecord) => void;
  onAddLivestockHealthEvent: (tagId: string, event: { date: string; type: string; details: string; cost: number }) => void;
  isReadonly?: boolean;
  onOpenFeedEngine?: () => void;
  accounts?: any[];
  setAccounts?: (accounts: any[]) => void;
  onAddInvoice?: (invoice: any) => void;
  onDeleteLivestockRecord?: (id: string, reason?: string, deletedBy?: string) => void;
  onAddCashSale?: (sale: CashSale) => void;
  activeFarm?: any;
  onAddLivestockRecordsBatch?: (records: LivestockRecord[]) => void;
}

interface SearchableOption {
  value: string;
  label: string;
  sublabel?: string;
  badge?: string;
}

const SearchablePigSelect: React.FC<{
  label: string;
  value: string;
  options: SearchableOption[];
  onChange: (val: string) => void;
  placeholder?: string;
}> = ({ label, value, options, onChange, placeholder = "Search & select..." }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const selectedOpt = options.find(o => o.value.toLowerCase() === value.toLowerCase()) || options[0];

  const filteredOptions = options.filter(
    o => o.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
         (o.sublabel && o.sublabel.toLowerCase().includes(searchQuery.toLowerCase())) ||
         (o.badge && o.badge.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="relative">
      <label className="block font-bold text-slate-700 mb-1 text-xs uppercase tracking-wider">{label}</label>
      <div 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-3 py-2 bg-white rounded-xl border border-slate-300 flex items-center justify-between cursor-pointer shadow-xs hover:border-amber-500 transition-colors"
      >
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="font-bold text-slate-900 text-xs truncate">{selectedOpt?.label || value}</span>
          {selectedOpt?.badge && (
            <span className="text-[10px] font-extrabold bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded-md shrink-0">
              {selectedOpt.badge}
            </span>
          )}
        </div>
        <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
      </div>

      {isOpen && (
        <div className="absolute z-50 mt-1 w-full bg-white rounded-2xl shadow-xl border border-slate-200 p-2 space-y-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              autoFocus
              placeholder={placeholder}
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-amber-500 font-medium"
            />
          </div>

          <div className="max-h-48 overflow-y-auto space-y-1">
            {filteredOptions.length === 0 ? (
              <div className="p-3 text-center text-xs text-slate-400">No matching option found</div>
            ) : (
              filteredOptions.map(opt => (
                <div
                  key={opt.value}
                  onClick={() => {
                    onChange(opt.value);
                    setIsOpen(false);
                    setSearchQuery("");
                  }}
                  className={`p-2 rounded-xl text-xs flex items-center justify-between cursor-pointer transition-colors ${
                    opt.value.toLowerCase() === value.toLowerCase()
                      ? "bg-amber-500 text-white font-bold"
                      : "hover:bg-slate-100 text-slate-800 font-medium"
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span>{opt.label}</span>
                      {opt.badge && (
                        <span className={`text-[9px] px-1.5 py-0.2 rounded-md ${
                          opt.value.toLowerCase() === value.toLowerCase()
                            ? "bg-white/20 text-white"
                            : "bg-slate-200 text-slate-700"
                        }`}>
                          {opt.badge}
                        </span>
                      )}
                    </div>
                    {opt.sublabel && (
                      <div className={`text-[10px] ${
                        opt.value.toLowerCase() === value.toLowerCase() ? "text-amber-100" : "text-slate-500"
                      }`}>
                        {opt.sublabel}
                      </div>
                    )}
                  </div>
                  {opt.value.toLowerCase() === value.toLowerCase() && (
                    <Check className="w-3.5 h-3.5 shrink-0" />
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export interface PigCsvValidationResult {
  isValid: boolean;
  errors: Array<{ row: number; field: string; message: string }>;
  warnings: string[];
  totalRows: number;
  detectedCategories: { [key: string]: number };
}

export function validateSwineCsv(csvText: string): PigCsvValidationResult {
  const errors: Array<{ row: number; field: string; message: string }> = [];
  const warnings: string[] = [];
  const detectedCategories: { [key: string]: number } = {};

  const lines = csvText.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);

  if (lines.length === 0) {
    return {
      isValid: false,
      errors: [{ row: 0, field: "File", message: "CSV content is empty. Please select a CSV file or enter batch records." }],
      warnings: [],
      totalRows: 0,
      detectedCategories: {}
    };
  }

  const validCategories = ["creep piglet", "weaner", "grower", "finisher", "gilt", "sow", "boar"];

  // Inspect first row for headers
  const firstRowCols = lines[0].split(",").map(c => c.trim().toLowerCase());
  const hasHeaderRow = firstRowCols.some(c => 
    c.includes("tag") || c.includes("stage") || c.includes("category") || c.includes("breed") || c.includes("weight") || c.includes("value") || c.includes("grower")
  );

  let headerIndices = { tag: 0, breed: 1, category: 2, gender: 3, weight: 4, value: 5 };
  let dataLines = lines;

  if (hasHeaderRow) {
    const tagIdx = firstRowCols.findIndex(c => c.includes("tag") || c.includes("id") || c.includes("code"));
    const catIdx = firstRowCols.findIndex(c => c.includes("stage") || c.includes("category") || c.includes("class") || c.includes("group") || c.includes("grower"));
    const breedIdx = firstRowCols.findIndex(c => c.includes("breed"));
    const genderIdx = firstRowCols.findIndex(c => c.includes("gender") || c.includes("sex"));
    const weightIdx = firstRowCols.findIndex(c => c.includes("weight") || c.includes("kg"));
    const valIdx = firstRowCols.findIndex(c => c.includes("value") || c.includes("price") || c.includes("appraisal"));

    // Check required header columns
    if (tagIdx === -1) {
      errors.push({ row: 1, field: "Header", message: "Missing required header column 'Tag' or 'TagId'." });
    }
    if (catIdx === -1) {
      errors.push({ row: 1, field: "Header", message: "Missing required header column 'Grower', 'Stage', or 'Category'." });
    }

    if (tagIdx !== -1) headerIndices.tag = tagIdx;
    if (catIdx !== -1) headerIndices.category = catIdx;
    if (breedIdx !== -1) headerIndices.breed = breedIdx;
    if (genderIdx !== -1) headerIndices.gender = genderIdx;
    if (weightIdx !== -1) headerIndices.weight = weightIdx;
    if (valIdx !== -1) headerIndices.value = valIdx;

    dataLines = lines.slice(1);
  } else {
    warnings.push("No explicit CSV header row detected. Default layout assumed: TagId, Breed, Stage/Category (e.g. Grower), Gender, Weight, AppraisalValue.");
  }

  if (dataLines.length === 0) {
    errors.push({ row: 1, field: "Data", message: "CSV contains a header row but no data rows to import." });
  }

  dataLines.forEach((line, index) => {
    const rowNum = hasHeaderRow ? index + 2 : index + 1;
    const parts = line.split(",").map(p => p.trim());

    if (parts.length < 2) {
      errors.push({ row: rowNum, field: "Row", message: `Row ${rowNum}: Incomplete data columns. Minimal required fields are Tag and Stage/Category.` });
      return;
    }

    const tag = parts[headerIndices.tag] || "";
    const category = parts[headerIndices.category] || "";
    const weightStr = parts[headerIndices.weight] || "";
    const valueStr = parts[headerIndices.value] || "";

    if (!tag) {
      errors.push({ row: rowNum, field: "Tag", message: `Row ${rowNum}: Missing required Tag ID.` });
    }

    if (!category) {
      errors.push({ row: rowNum, field: "Stage / Category", message: `Row ${rowNum}: Missing required Stage/Category (e.g. Grower, Weaner, Finisher).` });
    } else {
      const normalizedCat = validCategories.find(c => c === category.toLowerCase());
      if (!normalizedCat) {
        errors.push({ 
          row: rowNum, 
          field: "Stage / Category", 
          message: `Row ${rowNum}: Invalid Stage/Category '${category}'. Must be one of: Grower, Weaner, Creep Piglet, Finisher, Gilt, Sow, Boar.` 
        });
      } else {
        const key = category.charAt(0).toUpperCase() + category.slice(1);
        detectedCategories[key] = (detectedCategories[key] || 0) + 1;
      }
    }

    if (weightStr && isNaN(parseFloat(weightStr))) {
      errors.push({ row: rowNum, field: "Weight", message: `Row ${rowNum}: Invalid numeric weight '${weightStr}'.` });
    }

    if (valueStr && isNaN(parseFloat(valueStr))) {
      errors.push({ row: rowNum, field: "Appraisal Value", message: `Row ${rowNum}: Invalid numeric appraisal value '${valueStr}'.` });
    }
  });

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    totalRows: dataLines.length,
    detectedCategories
  };
}

export default function PigManager({
  records,
  currencySymbol = "ZMW",
  onAddLivestockRecord,
  onAddLivestockHealthEvent,
  isReadonly = false,
  onOpenFeedEngine,
  accounts,
  setAccounts,
  onAddInvoice,
  onDeleteLivestockRecord,
  onAddCashSale,
  activeFarm,
  onAddLivestockRecordsBatch
}: PigManagerProps) {
  // Navigation Tabs inside Pig Manager
  const [activeSubTab, setActiveSubTab] = useState<"register" | "farrowing" | "piglets" | "vaccination" | "feeding">("register");

  // Filters
  const [breedFilter, setBreedFilter] = useState<string>("ALL");
  const [categoryFilter, setCategoryFilter] = useState<string>("ALL");
  const [searchTerm, setSearchTerm] = useState<string>("");

  // Modals
  const [showAddPigModal, setShowAddPigModal] = useState(false);
  const [showFarrowingModal, setShowFarrowingModal] = useState(false);
  const [showBulkPigModal, setShowBulkPigModal] = useState(false);
  const [showRegisterLitterModal, setShowRegisterLitterModal] = useState<SowFarrowingRecord | null>(null);
  const [showStageAdvanceModal, setShowStageAdvanceModal] = useState<LivestockRecord | null>(null);
  const [salePigTarget, setSalePigTarget] = useState<LivestockRecord | null>(null);
  const [mortalityPigTarget, setMortalityPigTarget] = useState<LivestockRecord | null>(null);

  // Litter Piglet Generation State
  const [litterBornAlive, setLitterBornAlive] = useState<number>(10);
  const [litterDamTag, setLitterDamTag] = useState<string>("");
  const [litterSireTag, setLitterSireTag] = useState<string>("TN70 Boar");
  const [litterDamBreed, setLitterDamBreed] = useState<string>("Large White");
  const [litterAvgBirthWeight, setLitterAvgBirthWeight] = useState<number>(1.4);
  const [litterAppraisalVal, setLitterAppraisalVal] = useState<number>(400);
  const [litterPenLocation, setLitterPenLocation] = useState<string>("Nursery Pen AL4");
  const [litterTagPrefix, setLitterTagPrefix] = useState<string>("PGLT-");
  const [litterFarrowingDate, setLitterFarrowingDate] = useState<string>(new Date().toISOString().split("T")[0]);

  // Stage Advancement State
  const [advanceTargetStage, setAdvanceTargetStage] = useState<string>("Weaner");
  const [advanceNewWeight, setAdvanceNewWeight] = useState<number>(20);
  const [advanceNewValuation, setAdvanceNewValuation] = useState<number>(1200);
  const [advanceNotes, setAdvanceNotes] = useState<string>("Routine growth stage progression");

  // Bulk Pig Registration State
  const [bulkMode, setBulkMode] = useState<"batch" | "csv">("batch");
  const [bulkCount, setBulkCount] = useState<number>(10);
  const [bulkTagPrefix, setBulkTagPrefix] = useState<string>("PG-LITTER-");
  const [bulkBreed, setBulkBreed] = useState<string>(PIG_BREEDS[0] || "Large White");
  const [bulkCategory, setBulkCategory] = useState<"Weaner" | "Creep Piglet" | "Grower" | "Finisher" | "Gilt" | "Sow" | "Boar">("Weaner");
  const [bulkGender, setBulkGender] = useState<"Male" | "Female" | "Mixed">("Mixed");
  const [bulkAvgWeight, setBulkAvgWeight] = useState<number>(18);
  const [bulkUnitValue, setBulkUnitValue] = useState<number>(1200);
  const [bulkPenLocation, setBulkPenLocation] = useState<string>("Pen #2 (Weaner Bay)");
  const [bulkCsvText, setBulkCsvText] = useState<string>("");

  // Pig Sale State
  const [saleWeight, setSaleWeight] = useState<number>(90);
  const [salePricePerKg, setSalePricePerKg] = useState<number>(45);
  const [saleBuyer, setSaleBuyer] = useState<string>("");
  const [saleApplyVat, setSaleApplyVat] = useState<boolean>(true);
  const [activePigReceiptSale, setActivePigReceiptSale] = useState<CashSale | null>(null);

  // Pig Mortality State
  const [mortalityCause, setMortalityCause] = useState<string>("African Swine Fever (ASF) Suspected");
  const [mortalityDiagnosis, setMortalityDiagnosis] = useState<string>("High fever, cutaneous cyanosis, necropsy submitted");
  const [mortalityLossValue, setMortalityLossValue] = useState<number>(2500);

  // New Pig Registration Form State
  const [newTagId, setNewTagId] = useState("");
  const [newName, setNewName] = useState("");
  const [newBreed, setNewBreed] = useState(PIG_BREEDS[0] || "Large White");
  const [newGender, setNewGender] = useState<"Male" | "Female">("Female");
  const [newCategory, setNewCategory] = useState<"Sow" | "Boar" | "Gilt" | "Weaner" | "Grower" | "Finisher" | "Creep Piglet">("Sow");
  const [newWeight, setNewWeight] = useState<number>(75);
  const [newBirthDate, setNewBirthDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [newLocation, setNewLocation] = useState<string>("Pig Pen #1");
  const [newCost, setNewCost] = useState<number>(3500);
  const [newDamTagId, setNewDamTagId] = useState<string>("");
  const [newSireTagId, setNewSireTagId] = useState<string>("");

  // Farrowing Records Local Storage State
  const [farrowingRecords, setFarrowingRecords] = useState<SowFarrowingRecord[]>(() => {
    const cached = localStorage.getItem("mabala_sow_farrowing_records");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [
      {
        id: "far_101",
        sowTagId: "PG-101",
        sowName: "Sow White #2",
        boarTagId: "PG-202 (TN70 Boar)",
        serviceDate: "2026-01-10",
        expectedFarrowingDate: "2026-05-04", // 114 days
        litterSizeBornAlive: 11,
        litterSizeStillborn: 1,
        litterSizeMummified: 0,
        status: "gestating",
        notes: "TN70 Breeding Line crossing for hybrid vigor."
      }
    ];
  });

  // Farrowing Modal State
  const [farrSowTagId, setFarrSowTagId] = useState("");
  const [farrBoarTagId, setFarrBoarTagId] = useState("");
  const [farrServiceDate, setFarrServiceDate] = useState(new Date().toISOString().split("T")[0]);
  const [farrBornAlive, setFarrBornAlive] = useState(10);

  // Filter pig records
  const pigRecords = useMemo(() => {
    return records.filter(r => {
      const isPig = r.type?.toLowerCase() === "pig" || r.species?.toLowerCase() === "pig" || r.species?.toLowerCase() === "pigs";
      if (!isPig) return false;

      if (breedFilter !== "ALL" && r.breed !== breedFilter) return false;
      if (categoryFilter !== "ALL" && r.category !== categoryFilter && r.gender !== categoryFilter) return false;
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        return (
          r.tagId.toLowerCase().includes(q) ||
          r.breed.toLowerCase().includes(q) ||
          (r.name && r.name.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [records, breedFilter, categoryFilter, searchTerm]);

  // Swine Vaccination Schedule Reference Data
  const swineVaccinationSchedule = [
    {
      id: "pvs-1",
      age: "Day 21 (Weaning)",
      vaccine: "Mycoplasma Hyopneumoniae",
      disease: "Enzootic Pneumonia",
      route: "IM Injection",
      targetGroup: "Piglets / Weaners",
      booster: "Day 35"
    },
    {
      id: "pvs-2",
      age: "Day 21 (Weaning)",
      vaccine: "PCV2 (Porcine Circovirus)",
      disease: "Post-Weaning Multisystemic Wasting",
      route: "IM Injection",
      targetGroup: "Piglets / Weaners",
      booster: "No Booster"
    },
    {
      id: "pvs-3",
      age: "Week 8 (56 Days)",
      vaccine: "Erysipelas (Rhusiopathiae)",
      disease: "Diamond Skin Disease / Erysipelas",
      route: "SC Injection",
      targetGroup: "Growers / Finishers",
      booster: "Semi-Annually"
    },
    {
      id: "pvs-4",
      age: "Week 12 (84 Days)",
      vaccine: "Parvovirus + Leptospirosis (Parvo/Lepto)",
      disease: "Porcine Parvovirus & Leptospirosis",
      route: "IM Injection",
      targetGroup: "Gilts / Sows / Boars",
      booster: "Pre-Breeding / Annual"
    },
    {
      id: "pvs-5",
      age: "Pre-Farrowing (Wk 12 Gestation)",
      vaccine: "E. Coli + Clostridium Perfringens",
      disease: "Neonatal Scours & Diarrhea",
      route: "IM Injection",
      targetGroup: "Gestating Sows & Gilts",
      booster: "2 Wks Pre-Farrow"
    }
  ];

  // Calculate expected farrowing date (114 days)
  const calculatedFarrowingDate = useMemo(() => {
    try {
      const date = new Date(farrServiceDate);
      date.setDate(date.getDate() + 114);
      return date.toISOString().split("T")[0];
    } catch (e) {
      return "";
    }
  }, [farrServiceDate]);

  // Handlers
  const handleRegisterPig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagId.trim()) return;

    const stageKeyMap: Record<string, string> = {
      "Creep Piglet": "creep",
      "Weaner": "weaner",
      "Grower": "grower",
      "Finisher": "finisher",
      "Gilt": "gilt",
      "Sow": "sow",
      "Boar": "boar"
    };

    const newPig: LivestockRecord = {
      id: `pig_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      tagId: newTagId.trim(),
      name: newName.trim() || undefined,
      type: "Pig",
      species: "Pigs",
      breed: newBreed, // Uses newly added pig breeds (TN70, Large White, Landrace, Camborough Cross)
      gender: newGender,
      category: newCategory,
      growthStage: (stageKeyMap[newCategory] || "grower") as any,
      damTagId: newDamTagId.trim() || undefined,
      dam: newDamTagId.trim() || undefined,
      sireTagId: newSireTagId.trim() || undefined,
      sire: newSireTagId.trim() || undefined,
      birthDate: newBirthDate,
      weightKg: newWeight,
      currentWeight: newWeight,
      status: "Active",
      location: newLocation,
      purchasePrice: newCost,
      currentValue: newCost,
      estimatedValue: newCost,
      acquisitionType: "Born on Farm",
      source: "Farm Breeding",
      dateAcquired: new Date().toISOString().split("T")[0],
      farmId: "main_farm",
      registrationDate: new Date().toISOString().split("T")[0],
      healthEvents: [],
      feedingLogs: [],
      growthHistory: [
        {
          date: new Date().toISOString().split("T")[0],
          stage: (stageKeyMap[newCategory] || "grower") as any,
          weightKg: newWeight,
          valuationAmount: newCost,
          notes: "Initial registration"
        }
      ]
    };

    onAddLivestockRecord(newPig);

    // Double-entry accounting posting for biological asset addition
    if (accounts && setAccounts && newCost > 0) {
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        if (acc.code === "1420") balance += newCost; // Debit Biological Assets
        if (acc.code === "4400") balance += newCost; // Credit Gain on Bio Assets / Breeding
        return { ...acc, balance };
      });
      setAccounts(updatedAccounts);
    }

    setShowAddPigModal(false);
    setNewTagId("");
    setNewName("");
    setNewDamTagId("");
    setNewSireTagId("");
  };

  // Litter Piglet Generation: Generates individual biological assets linked to mother sow
  const handleGenerateLitterPiglets = (e: React.FormEvent) => {
    e.preventDefault();
    if (!litterDamTag) return;

    const count = Math.max(1, Math.min(30, litterBornAlive));
    const createdPiglets: LivestockRecord[] = [];
    const today = litterFarrowingDate || new Date().toISOString().split("T")[0];

    for (let i = 1; i <= count; i++) {
      const pigletTag = `${litterTagPrefix}${String(i).padStart(2, "0")}`;
      const sex: "Male" | "Female" = i % 2 === 0 ? "Female" : "Male";

      createdPiglets.push({
        id: `piglet_${Date.now()}_${i}_${Math.random().toString(36).substr(2, 4)}`,
        tagId: pigletTag,
        name: `Piglet of ${litterDamTag} #${i}`,
        type: "Pig",
        species: "Pigs",
        breed: litterDamBreed || "TN70 x Large White",
        gender: sex,
        category: "Creep Piglet",
        growthStage: "creep",
        damTagId: litterDamTag,
        dam: litterDamTag,
        damBreed: litterDamBreed,
        sireTagId: litterSireTag,
        sire: litterSireTag,
        birthDate: today,
        weightKg: litterAvgBirthWeight,
        currentWeight: litterAvgBirthWeight,
        status: "Active",
        location: litterPenLocation,
        purchasePrice: litterAppraisalVal,
        currentValue: litterAppraisalVal,
        estimatedValue: litterAppraisalVal,
        acquisitionType: "Born on Farm",
        source: `Farrowing Litter (Dam: ${litterDamTag}, Sire: ${litterSireTag})`,
        dateAcquired: today,
        farmId: "main_farm",
        registrationDate: today,
        healthEvents: [],
        feedingLogs: [],
        growthHistory: [
          {
            date: today,
            stage: "creep",
            weightKg: litterAvgBirthWeight,
            valuationAmount: litterAppraisalVal,
            notes: `Farrowed alive. Dam: ${litterDamTag}, Sire: ${litterSireTag}`
          }
        ]
      });
    }

    if (onAddLivestockRecordsBatch) {
      onAddLivestockRecordsBatch(createdPiglets);
    } else {
      createdPiglets.forEach(p => onAddLivestockRecord(p));
    }

    // Double-entry accounting: Debit 1420 Biological Assets, Credit 4400 Fair Value Gain on Breeding
    const totalLitterValuation = createdPiglets.reduce((s, p) => s + (p.currentValue || 0), 0);
    if (accounts && setAccounts && totalLitterValuation > 0) {
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        if (acc.code === "1420") balance += totalLitterValuation;
        if (acc.code === "4400") balance += totalLitterValuation;
        return { ...acc, balance };
      });
      setAccounts(updatedAccounts);
    }

    // Update Farrowing Record status to farrowed
    if (showRegisterLitterModal) {
      const updatedFarrowings = farrowingRecords.map(f => {
        if (f.id === showRegisterLitterModal.id) {
          return {
            ...f,
            status: "farrowed" as const,
            litterSizeBornAlive: count
          };
        }
        return f;
      });
      setFarrowingRecords(updatedFarrowings);
      localStorage.setItem("mabala_sow_farrowing_records", JSON.stringify(updatedFarrowings));
    }

    setShowRegisterLitterModal(null);
    alert(`Success! Generated ${createdPiglets.length} individual piglet biological asset records linked to Dam ${litterDamTag}. Total Valuation ${currencySymbol}${totalLitterValuation.toLocaleString()} posted to Account 1420 Biological Assets.`);
  };

  // Advance Piglet Growth Stage & Revalue Asset
  const handleAdvanceStage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showStageAdvanceModal) return;

    const oldRecord = showStageAdvanceModal;
    const oldValuation = oldRecord.currentValue || oldRecord.estimatedValue || oldRecord.purchasePrice || 0;
    const newValuation = advanceNewValuation;
    const diff = newValuation - oldValuation;

    const stageKeyMap: Record<string, string> = {
      "Creep Piglet": "creep",
      "Weaner": "weaner",
      "Grower": "grower",
      "Finisher": "finisher",
      "Gilt": "gilt",
      "Sow": "sow",
      "Boar": "boar"
    };

    const newHistoryEntry = {
      date: new Date().toISOString().split("T")[0],
      stage: (stageKeyMap[advanceTargetStage] || "grower") as any,
      weightKg: advanceNewWeight,
      valuationAmount: newValuation,
      notes: advanceNotes || `Transitioned to ${advanceTargetStage}`
    };

    const updatedRecord: LivestockRecord = {
      ...oldRecord,
      category: advanceTargetStage as any,
      growthStage: (stageKeyMap[advanceTargetStage] || "grower") as any,
      weightKg: advanceNewWeight,
      currentWeight: advanceNewWeight,
      currentValue: newValuation,
      estimatedValue: newValuation,
      growthHistory: [...(oldRecord.growthHistory || []), newHistoryEntry]
    };

    // Replace in registry
    if (onDeleteLivestockRecord) {
      onDeleteLivestockRecord(oldRecord.id);
    }
    onAddLivestockRecord(updatedRecord);

    // Book fair-value revaluation difference in Financial Ledger
    if (accounts && setAccounts && diff !== 0) {
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        if (acc.code === "1420") balance += diff; // Biological Assets
        if (acc.code === "4400") balance += diff; // Fair value gain / (loss)
        return { ...acc, balance };
      });
      setAccounts(updatedAccounts);
    }

    setShowStageAdvanceModal(null);
    alert(`Success! Updated Pig ${oldRecord.tagId} to stage "${advanceTargetStage}". Weight: ${advanceNewWeight}kg, Valuation: ${currencySymbol}${newValuation.toLocaleString()}. Biological asset ledger updated.`);
  };

  const handleCsvFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        setBulkCsvText(text);
      }
    };
    reader.readAsText(file);
  };

  const handleDownloadCsvTemplate = () => {
    const csvContent = 
`TagId,Breed,Stage,Gender,WeightKg,AppraisalValue
PG-GROW-001,Large White,Grower,Female,35,2200
PG-GROW-002,Landrace,Grower,Male,38,2200
PG-WEAN-003,Duroc,Weaner,Female,15,1200
PG-FIN-004,Large White x Duroc,Finisher,Male,85,4500
PG-SOW-005,Large White,Sow,Female,160,8500
PG-BOAR-006,Duroc,Boar,Male,180,9500`;

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `swine_bulk_entry_template.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleBulkPigSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const createdPigs: LivestockRecord[] = [];

    if (bulkMode === "batch") {
      const count = Math.max(1, Math.min(100, bulkCount));
      const today = new Date().toISOString().split("T")[0];

      for (let i = 1; i <= count; i++) {
        const tag = `${bulkTagPrefix}${String(i).padStart(3, "0")}`;
        const sex = bulkGender === "Mixed" ? (i % 2 === 0 ? "Male" : "Female") : bulkGender;
        
        createdPigs.push({
          id: `pig_bulk_${Date.now()}_${i}`,
          tagId: tag,
          type: "Pig",
          species: "Pigs",
          breed: bulkBreed,
          gender: sex,
          category: bulkCategory,
          birthDate: today,
          weightKg: bulkAvgWeight,
          currentWeight: bulkAvgWeight,
          status: "Active",
          location: bulkPenLocation,
          purchasePrice: bulkUnitValue,
          currentValue: bulkUnitValue,
          estimatedValue: bulkUnitValue,
          acquisitionType: "Born on Farm",
          source: "Swine Unit Bulk Registration",
          dateAcquired: today,
          farmId: "main_farm",
          registrationDate: today,
          healthEvents: [],
          feedingLogs: []
        });
      }
    } else {
      // CSV Text mode: Run strict validation first
      const validation = validateSwineCsv(bulkCsvText);
      if (!validation.isValid) {
        alert("CSV Validation Errors Found! Please fix the errors listed in the CSV Integrity Report before submitting.");
        return;
      }

      const lines = bulkCsvText.split(/\r?\n/).filter(l => l.trim().length > 0);
      const today = new Date().toISOString().split("T")[0];

      // Check if first line is a header
      const firstLineParts = lines[0].split(",").map(p => p.trim().toLowerCase());
      const hasHeader = firstLineParts.some(p => p.includes("tag") || p.includes("stage") || p.includes("category") || p.includes("breed") || p.includes("grower"));
      
      const dataLines = hasHeader ? lines.slice(1) : lines;

      let tagIdx = 0, breedIdx = 1, catIdx = 2, genderIdx = 3, weightIdx = 4, valIdx = 5;
      if (hasHeader) {
        const t = firstLineParts.findIndex(p => p.includes("tag") || p.includes("id") || p.includes("code"));
        const b = firstLineParts.findIndex(p => p.includes("breed"));
        const c = firstLineParts.findIndex(p => p.includes("stage") || p.includes("category") || p.includes("class") || p.includes("grower"));
        const g = firstLineParts.findIndex(p => p.includes("gender") || p.includes("sex"));
        const w = firstLineParts.findIndex(p => p.includes("weight") || p.includes("kg"));
        const v = firstLineParts.findIndex(p => p.includes("value") || p.includes("price") || p.includes("appraisal"));

        if (t !== -1) tagIdx = t;
        if (b !== -1) breedIdx = b;
        if (c !== -1) catIdx = c;
        if (g !== -1) genderIdx = g;
        if (w !== -1) weightIdx = w;
        if (v !== -1) valIdx = v;
      }

      dataLines.forEach((line, idx) => {
        const parts = line.split(",").map(p => p.trim());
        if (parts.length >= 2) {
          const tag = parts[tagIdx] || `PG-CSV-${idx + 1}`;
          const breed = parts[breedIdx] || bulkBreed;
          const rawCat = parts[catIdx] || bulkCategory;
          const sexStr = parts[genderIdx] || "Female";
          const weight = parseFloat(parts[weightIdx]) || bulkAvgWeight;
          const price = parseFloat(parts[valIdx]) || bulkUnitValue;

          // Normalize category e.g. "grower" -> "Grower"
          const validCats = ["Creep Piglet", "Weaner", "Grower", "Finisher", "Gilt", "Sow", "Boar"];
          const matchedCat = validCats.find(c => c.toLowerCase() === rawCat.toLowerCase()) || "Grower";

          createdPigs.push({
            id: `pig_csv_${Date.now()}_${idx}`,
            tagId: tag,
            type: "Pig",
            species: "Pigs",
            breed: breed,
            gender: sexStr.toLowerCase().startsWith("m") ? "Male" : "Female",
            category: matchedCat as any,
            birthDate: today,
            weightKg: weight,
            currentWeight: weight,
            status: "Active",
            location: bulkPenLocation,
            purchasePrice: price,
            currentValue: price,
            estimatedValue: price,
            acquisitionType: "Purchased",
            source: "Swine CSV Bulk Registration",
            dateAcquired: today,
            farmId: "main_farm",
            registrationDate: today,
            healthEvents: [],
            feedingLogs: []
          });
        }
      });
    }

    if (createdPigs.length === 0) return;

    if (onAddLivestockRecordsBatch) {
      onAddLivestockRecordsBatch(createdPigs);
    } else {
      createdPigs.forEach(p => onAddLivestockRecord(p));
    }

    // Ledger adjustment if accounts available
    if (accounts && setAccounts) {
      const totalBatchValuation = createdPigs.reduce((s, p) => s + (p.currentValue || 0), 0);
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        if (acc.code === "1420") balance += totalBatchValuation;
        if (acc.code === "4400") balance += totalBatchValuation;
        return { ...acc, balance };
      });
      setAccounts(updatedAccounts);
    }

    setShowBulkPigModal(false);
    setBulkCsvText("");
    alert(`Successfully bulk registered ${createdPigs.length} pig record(s) into Central Animal Registry.`);
  };

  const handleProcessPigSaleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!salePigTarget) return;

    const baseAmount = Number(saleWeight) * Number(salePricePerKg);
    const vatAmount = saleApplyVat ? baseAmount * 0.16 : 0;
    const totalAmountInvoice = baseAmount + vatAmount;

    // 1. Create Invoice object
    const newInvoice = {
      id: "INV-PIG-" + Date.now().toString().slice(-6),
      invoiceNumber: "INV-PIG-" + Date.now().toString().slice(-6),
      clientName: saleBuyer || "Swine Offtaker / Pork Processor",
      dateIssued: new Date().toISOString().split("T")[0],
      dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      items: [
        { 
          description: `Sale of Live Pig: Tag ${salePigTarget.tagId} (${salePigTarget.breed} ${salePigTarget.category || "Porker"}). Weight: ${saleWeight}kg @ ${currencySymbol}${salePricePerKg}/kg`, 
          quantity: 1, 
          unitPrice: baseAmount, 
          amount: baseAmount 
        }
      ],
      subtotal: baseAmount,
      vatAmount: vatAmount,
      total: totalAmountInvoice,
      amountPaid: totalAmountInvoice,
      paymentStatus: "Paid",
      isTaxInvoice: saleApplyVat,
      farmId: "main_farm"
    };

    if (onAddInvoice) {
      onAddInvoice(newInvoice);
    }

    // 2. Create Direct Farm Cash Sale entry for the Sales Desk & Reports
    const newCashSale: CashSale = {
      id: `CS-PIG-${Date.now().toString().slice(-6)}`,
      receiptNumber: `REC-PIG-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toISOString().split("T")[0],
      description: `Sale of Live Pig: Tag #${salePigTarget.tagId} (${salePigTarget.breed} ${salePigTarget.category || "Porker"}). Weight: ${saleWeight}kg @ ${currencySymbol}${salePricePerKg}/kg`,
      customer: saleBuyer || "Swine Offtaker / Pork Processor",
      amount: totalAmountInvoice,
      subtotal: baseAmount,
      taxRate: saleApplyVat ? 16 : 0,
      taxAmount: vatAmount,
      paymentMethod: "Cash",
      coaDebit: "1010",
      coaCredit: "4300", // Livestock Sales Revenue
      farmId: activeFarm?.id || "farm-1",
      sourceType: "livestock",
      animalTagId: salePigTarget.tagId,
      animalSpecies: "Swine / Pig",
      animalBreed: salePigTarget.breed,
      animalWeightKg: Number(saleWeight),
      pricePerKg: Number(salePricePerKg),
      headcount: 1,
      cashierName: "Swine Operations Supervisor"
    };

    if (onAddCashSale) {
      onAddCashSale(newCashSale);
    } else {
      try {
        const cached = localStorage.getItem("mabala_cash_sales");
        const parsed = cached ? JSON.parse(cached) : [];
        localStorage.setItem("mabala_cash_sales", JSON.stringify([newCashSale, ...parsed]));
      } catch (err) {}
    }

    // 3. Double-entry financial posting
    const assetVal = salePigTarget.currentValue || salePigTarget.estimatedValue || salePigTarget.purchasePrice || 0;
    if (accounts && setAccounts) {
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        if (acc.code === "1010") balance += totalAmountInvoice; // Cash/Bank
        if (acc.code === "4300") balance += baseAmount; // Sales Revenue
        if (saleApplyVat && acc.code === "2070") balance += vatAmount; // Output VAT
        if (acc.code === "1420") balance -= assetVal; // Biological Assets
        return { ...acc, balance };
      });
      setAccounts(updatedAccounts);
    }

    // 4. Remove animal from central active registry
    if (onDeleteLivestockRecord) {
      onDeleteLivestockRecord(
        salePigTarget.id,
        `Commercial Sale Disposal: Invoiced to ${saleBuyer || "Customer"} for ${currencySymbol}${totalAmountInvoice.toLocaleString()}`,
        "Pig Enterprise Manager"
      );
    }

    setSalePigTarget(null);
    setActivePigReceiptSale(newCashSale);
  };

  const handleProcessPigMortalitySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mortalityPigTarget) return;

    const lossVal = Number(mortalityLossValue);

    // 1. Post loss to accounts
    if (accounts && setAccounts) {
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        if (acc.code === "1420") balance -= lossVal; // Biological Assets Credit
        if (acc.code === "4400") balance -= lossVal; // Net asset loss
        return { ...acc, balance };
      });
      setAccounts(updatedAccounts);
    }

    // 2. Remove animal from central active registry
    if (onDeleteLivestockRecord) {
      onDeleteLivestockRecord(
        mortalityPigTarget.id,
        `Mortality Casualty: ${mortalityCause || "Disease / Physical Injury"}. Loss value: ${currencySymbol}${lossVal.toLocaleString()}`,
        "Pig Enterprise Manager / Herdsman"
      );
    }

    setMortalityPigTarget(null);
    alert(`Swine Mortality recorded for ${mortalityPigTarget.tagId}. Central stock count & Biological Assets (Account 1420) updated.`);
  };

  const handleSaveFarrowingRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!farrSowTagId) return;

    const newRec: SowFarrowingRecord = {
      id: `far_${Date.now()}`,
      sowTagId: farrSowTagId,
      boarTagId: farrBoarTagId || "TN70 Stud Boar",
      serviceDate: farrServiceDate,
      expectedFarrowingDate: calculatedFarrowingDate,
      litterSizeBornAlive: farrBornAlive,
      litterSizeStillborn: 0,
      litterSizeMummified: 0,
      status: "gestating"
    };

    const updated = [newRec, ...farrowingRecords];
    setFarrowingRecords(updated);
    localStorage.setItem("mabala_sow_farrowing_records", JSON.stringify(updated));
    setShowFarrowingModal(false);
  };

  return (
    <div className="space-y-6 text-slate-800">
      {/* HEADER BANNER */}
      <div className="bg-gradient-to-r from-rose-950 via-pink-900 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-rose-800/40 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/30">
                Swine Unit & Pedigree Management
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-pink-500/20 text-pink-200 border border-pink-500/30">
                114-Day Gestation Tracker
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2">
              <Beef className="w-8 h-8 text-rose-400" />
              Pig Herd & Swine Breeding Manager
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm max-w-2xl mt-1">
              Manage pig registers with verified breeds (**Landrace, Hampshire, Pietrain, Duroc, Large White, TN70, Camborough Cross**), sow farrowing, swine vaccination schedules, and stage-based feed formulations.
            </p>
          </div>

          {!isReadonly && (
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => setShowAddPigModal(true)}
                className="px-4 py-2.5 bg-rose-500 hover:bg-rose-600 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Register New Pig
              </button>
              <button
                onClick={() => setShowBulkPigModal(true)}
                className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Upload className="w-4 h-4" /> Bulk / Batch Registration
              </button>
            </div>
          )}
        </div>

        {/* SUB-TAB NAVIGATION */}
        <div className="flex items-center gap-2 mt-6 pt-4 border-t border-slate-800/80 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveSubTab("register")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeSubTab === "register"
                ? "bg-rose-500 text-slate-950 shadow-lg font-black"
                : "bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <Beef className="w-4 h-4" />
            1. Pig Register ({pigRecords.length})
          </button>

          <button
            onClick={() => setActiveSubTab("farrowing")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeSubTab === "farrowing"
                ? "bg-rose-500 text-slate-950 shadow-lg font-black"
                : "bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <Heart className="w-4 h-4" />
            2. Sow Farrowing Tracker ({farrowingRecords.length})
          </button>

          <button
            onClick={() => setActiveSubTab("piglets")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeSubTab === "piglets"
                ? "bg-rose-500 text-slate-950 shadow-lg font-black"
                : "bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <Award className="w-4 h-4" />
            3. Piglets & Lineage Tracker ({records.filter(r => (r.type?.toLowerCase() === "pig" || r.species?.toLowerCase() === "pigs" || r.species?.toLowerCase() === "pig") && (r.category === "Creep Piglet" || r.category === "Weaner" || r.category === "Grower" || r.damTagId || r.dam)).length})
          </button>

          <button
            onClick={() => setActiveSubTab("vaccination")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeSubTab === "vaccination"
                ? "bg-rose-500 text-slate-950 shadow-lg font-black"
                : "bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <Stethoscope className="w-4 h-4" />
            4. Swine Health & Vaccination
          </button>

          {onOpenFeedEngine && (
            <button
              onClick={onOpenFeedEngine}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-all flex items-center gap-2 whitespace-nowrap ml-auto"
            >
              <TrendingUp className="w-4 h-4" />
              Open Stage Feed Engine
            </button>
          )}
        </div>
      </div>

      {/* SUB-TAB 1: PIG REGISTER */}
      {activeSubTab === "register" && (
        <div className="space-y-6">
          {/* FILTER BAR */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-600">Breed:</span>
                <select
                  value={breedFilter}
                  onChange={e => setBreedFilter(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-slate-300 font-bold text-slate-800"
                >
                  <option value="ALL">All Breeds ({PIG_BREEDS.length})</option>
                  {PIG_BREEDS.map(b => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-600">Category:</span>
                <select
                  value={categoryFilter}
                  onChange={e => setCategoryFilter(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-slate-300 font-bold text-slate-800"
                >
                  <option value="ALL">All Categories</option>
                  <option value="Sow">Sows</option>
                  <option value="Boar">Boars</option>
                  <option value="Gilt">Gilts</option>
                  <option value="Weaner">Weaners</option>
                  <option value="Finisher">Finishers</option>
                  <option value="Creep Piglet">Creep Piglets</option>
                </select>
              </div>
            </div>

            <div className="relative w-full sm:w-64">
              <input
                type="text"
                placeholder="Search Tag or Name..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>

          {/* PIG REGISTER TABLE */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-slate-900 text-base">Swine Herd Register</h3>
              <span className="text-xs font-extrabold text-slate-500">Showing {pigRecords.length} records</span>
            </div>

            {pigRecords.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-300 space-y-2">
                <Beef className="w-12 h-12 text-slate-300 mx-auto" />
                <p className="font-bold text-slate-700 text-sm">No pigs registered matching filters.</p>
                <p className="text-slate-400 text-xs">Click "Register New Pig" to add Landrace, Hampshire, Pietrain, Duroc, or Large White pigs to your herd.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200">
                      <th className="py-3 px-4">Tag ID / Name</th>
                      <th className="py-3 px-4">Breed Line</th>
                      <th className="py-3 px-4">Category & Sex</th>
                      <th className="py-3 px-4">Pedigree Lineage</th>
                      <th className="py-3 px-4 text-right">Weight (kg)</th>
                      <th className="py-3 px-4">Pen Location</th>
                      <th className="py-3 px-4 text-right">Appraisal Value</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-center">Lifecycle Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {pigRecords.map(p => (
                      <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4">
                          <span className="font-black text-slate-900 block">{p.tagId}</span>
                          {p.name && <span className="text-[11px] text-slate-500 font-semibold">{p.name}</span>}
                        </td>
                        <td className="py-3 px-4 font-extrabold text-rose-700">
                          {p.breed}
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-bold text-slate-800">{p.category || p.gender}</span>
                          <span className="block text-[10px] text-slate-400 font-medium">{p.gender}</span>
                        </td>
                        <td className="py-3 px-4">
                          {p.damTagId || p.dam ? (
                            <div className="space-y-0.5">
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-pink-50 text-pink-700 border border-pink-200">
                                ♀ Dam: {p.damTagId || p.dam}
                              </span>
                              {p.sireTagId || p.sire ? (
                                <span className="block text-[10px] text-slate-500 font-medium">
                                  ♂ Sire: {p.sireTagId || p.sire}
                                </span>
                              ) : null}
                            </div>
                          ) : (
                            <span className="text-slate-400 text-[11px] italic">Foundation Stock</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right font-black text-slate-900">{p.currentWeight || p.weightKg || "—"} kg</td>
                        <td className="py-3 px-4 font-semibold text-slate-600">{p.location || "Pig Unit #1"}</td>
                        <td className="py-3 px-4 text-right font-black text-emerald-700">
                          {currencySymbol} {(p.estimatedValue || p.purchasePrice || 0).toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            {p.status || "Active"}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5 flex-wrap">
                            <button
                              type="button"
                              onClick={() => {
                                setShowStageAdvanceModal(p);
                                const nextMap: Record<string, { stage: string; weight: number; val: number }> = {
                                  "Creep Piglet": { stage: "Weaner", weight: 18, val: 1200 },
                                  "Weaner": { stage: "Grower", weight: 45, val: 2400 },
                                  "Grower": { stage: "Finisher", weight: 90, val: 4500 },
                                  "Finisher": { stage: "Gilt", weight: 120, val: 6500 }
                                };
                                const next = nextMap[p.category || "Weaner"] || { stage: "Grower", weight: (p.currentWeight || 20) + 15, val: (p.currentValue || 1200) + 800 };
                                setAdvanceTargetStage(next.stage);
                                setAdvanceNewWeight(next.weight);
                                setAdvanceNewValuation(next.val);
                              }}
                              className="px-2 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded text-[10px] font-extrabold flex items-center gap-1 cursor-pointer shadow-2xs"
                              title="Advance Growth Stage & Revalue Asset"
                            >
                              <TrendingUp className="w-3 h-3" /> Advance
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setSalePigTarget(p);
                                setSaleWeight(p.currentWeight || p.weightKg || 85);
                                setSalePricePerKg(45);
                              }}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                              title="Process Pig Sale"
                            >
                              <ShoppingCart className="w-3 h-3" /> Sell
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setMortalityPigTarget(p);
                                setMortalityLossValue(p.currentValue || p.estimatedValue || p.purchasePrice || 2500);
                              }}
                              className="px-2 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                              title="Record Mortality"
                            >
                              <Skull className="w-3 h-3" /> Mortality
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: SOW FARROWING TRACKER */}
      {activeSubTab === "farrowing" && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                <Heart className="w-5 h-5 text-rose-600" />
                Sow Breeding & 114-Day Farrowing Schedule Tracker
              </h3>
              <p className="text-slate-500 text-xs">
                Tracks service date to calculate expected farrowing ("3 months, 3 weeks, 3 days"). Generates individual piglet biological asset records for Central Registry & Biological Asset Books.
              </p>
            </div>

            <button
              onClick={() => setShowFarrowingModal(true)}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow transition-all flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Record Sow Service / Breeding
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200">
                  <th className="py-3 px-4">Sow Tag & Name</th>
                  <th className="py-3 px-4">Boar Used</th>
                  <th className="py-3 px-4">Service Date</th>
                  <th className="py-3 px-4">Expected Farrowing (114d)</th>
                  <th className="py-3 px-4 text-right">Litter Born Alive</th>
                  <th className="py-3 px-4 text-center">Gestation Status</th>
                  <th className="py-3 px-4 text-center">Central Registry Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {farrowingRecords.map(f => (
                  <tr key={f.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4">
                      <span className="font-black text-slate-900 block">{f.sowTagId}</span>
                      {f.sowName && <span className="text-[11px] text-slate-500">{f.sowName}</span>}
                    </td>
                    <td className="py-3 px-4 font-extrabold text-slate-800">{f.boarTagId || "TN70 Stud"}</td>
                    <td className="py-3 px-4 font-semibold text-slate-700">{f.serviceDate}</td>
                    <td className="py-3 px-4 font-black text-rose-700">{f.expectedFarrowingDate}</td>
                    <td className="py-3 px-4 text-right font-black text-emerald-700 text-sm">{f.litterSizeBornAlive} piglets</td>
                    <td className="py-3 px-4 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                        f.status === "farrowed" ? "bg-emerald-100 text-emerald-800 border border-emerald-300" : "bg-rose-100 text-rose-800 border border-rose-300"
                      }`}>
                        {f.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        type="button"
                        onClick={() => {
                          setShowRegisterLitterModal(f);
                          setLitterDamTag(f.sowTagId);
                          setLitterSireTag(f.boarTagId || "TN70 Boar");
                          const matchedSow = records.find(r => r.tagId === f.sowTagId);
                          setLitterDamBreed(matchedSow?.breed || "Large White");
                          setLitterBornAlive(f.litterSizeBornAlive || 10);
                          setLitterTagPrefix(`PGLT-${f.sowTagId.replace(/[^a-zA-Z0-9]/g, "")}-`);
                          setLitterFarrowingDate(f.expectedFarrowingDate || new Date().toISOString().split("T")[0]);
                        }}
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-black text-[11px] rounded-lg shadow transition-all flex items-center gap-1.5 mx-auto cursor-pointer"
                      >
                        <Award className="w-3.5 h-3.5" />
                        {f.status === "farrowed" ? "Generate More Assets" : "Farrow & Register Litter"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: PIGLETS & GENETIC LINEAGE TRACKER */}
      {activeSubTab === "piglets" && (
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-pink-50 via-rose-50 to-amber-50 p-6 rounded-2xl border border-pink-200 shadow-xs space-y-4">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-200 text-rose-800 border border-rose-300">
                    Genetic Lineage & Biological Asset Registry
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-pink-200 text-pink-800">
                    Continuous Life-Cycle Tracking
                  </span>
                </div>
                <h3 className="font-black text-slate-900 text-lg flex items-center gap-2">
                  <Award className="w-5 h-5 text-rose-600" />
                  Piglets, Dam Lineage & Life-Cycle Growth Engine
                </h3>
                <p className="text-slate-600 text-xs max-w-2xl mt-1">
                  Piglets are strictly identified with unique IDs as individual biological assets linked to their mother sow for genetic pedigree tracking. Track growth stages (**Creep Piglet → Weaner → Grower → Finisher → Breeding**) with automatic fair-value revaluation in books of accounts until disposal via sale or mortality.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowFarrowingModal(true)}
                  className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Heart className="w-3.5 h-3.5" /> Farrowing Schedule
                </button>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              <div className="bg-white p-3 rounded-xl border border-pink-200 shadow-2xs">
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Offspring & Young Swine</span>
                <span className="text-lg font-black text-slate-900">
                  {records.filter(r => (r.type?.toLowerCase() === "pig" || r.species?.toLowerCase() === "pigs" || r.species?.toLowerCase() === "pig") && (r.category === "Creep Piglet" || r.category === "Weaner" || r.category === "Grower" || r.damTagId || r.dam)).length} head
                </span>
              </div>

              <div className="bg-white p-3 rounded-xl border border-pink-200 shadow-2xs">
                <span className="text-[10px] uppercase font-bold text-pink-600 block">Suckling / Creep Piglets (0-4w)</span>
                <span className="text-lg font-black text-pink-800">
                  {records.filter(r => (r.type?.toLowerCase() === "pig" || r.species?.toLowerCase() === "pigs" || r.species?.toLowerCase() === "pig") && (r.category === "Creep Piglet" || r.growthStage === "creep")).length} head
                </span>
              </div>

              <div className="bg-white p-3 rounded-xl border border-pink-200 shadow-2xs">
                <span className="text-[10px] uppercase font-bold text-amber-600 block">Weaned Nursery Swine (4-8w)</span>
                <span className="text-lg font-black text-amber-800">
                  {records.filter(r => (r.type?.toLowerCase() === "pig" || r.species?.toLowerCase() === "pigs" || r.species?.toLowerCase() === "pig") && (r.category === "Weaner" || r.growthStage === "weaner")).length} head
                </span>
              </div>

              <div className="bg-white p-3 rounded-xl border border-emerald-200 shadow-2xs">
                <span className="text-[10px] uppercase font-bold text-emerald-600 block">Young Herd Biological Valuation</span>
                <span className="text-lg font-black text-emerald-800">
                  {currencySymbol} {records
                    .filter(r => (r.type?.toLowerCase() === "pig" || r.species?.toLowerCase() === "pigs" || r.species?.toLowerCase() === "pig") && (r.category === "Creep Piglet" || r.category === "Weaner" || r.category === "Grower" || r.damTagId || r.dam))
                    .reduce((sum, r) => sum + (r.currentValue || r.estimatedValue || r.purchasePrice || 0), 0)
                    .toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Piglet / Young Swine Table */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-black text-slate-900 text-sm">Individual Piglet & Lineage Asset Register</h4>
              <span className="text-xs text-slate-500 font-bold">Central Animal Registry Integration Active</span>
            </div>

            {records.filter(r => (r.type?.toLowerCase() === "pig" || r.species?.toLowerCase() === "pigs" || r.species?.toLowerCase() === "pig") && (r.category === "Creep Piglet" || r.category === "Weaner" || r.category === "Grower" || r.damTagId || r.dam)).length === 0 ? (
              <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-300 space-y-2">
                <Award className="w-12 h-12 text-rose-300 mx-auto" />
                <p className="font-bold text-slate-700 text-sm">No piglets or young swine registered with genetic links.</p>
                <p className="text-slate-400 text-xs">Go to "Sow Farrowing Tracker" and click "Farrow & Register Litter" to generate individual piglet biological asset records linked to their mother sow.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200">
                      <th className="py-3 px-4">Unique Asset Tag / ID</th>
                      <th className="py-3 px-4">Dam (Mother Sow) & Lineage</th>
                      <th className="py-3 px-4">Sire (Father Boar)</th>
                      <th className="py-3 px-4">Birth Date & Age</th>
                      <th className="py-3 px-4 text-center">Growth Stage</th>
                      <th className="py-3 px-4 text-right">Weight (kg)</th>
                      <th className="py-3 px-4">Housing Pen</th>
                      <th className="py-3 px-4 text-right">Biological Value</th>
                      <th className="py-3 px-4 text-center">Lifecycle & Stage Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {records
                      .filter(r => (r.type?.toLowerCase() === "pig" || r.species?.toLowerCase() === "pigs" || r.species?.toLowerCase() === "pig") && (r.category === "Creep Piglet" || r.category === "Weaner" || r.category === "Grower" || r.damTagId || r.dam))
                      .map(p => {
                        // Calculate age in days/weeks
                        let ageText = "—";
                        if (p.birthDate) {
                          const diffMs = Date.now() - new Date(p.birthDate).getTime();
                          const diffDays = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
                          const weeks = Math.floor(diffDays / 7);
                          const days = diffDays % 7;
                          ageText = weeks > 0 ? `${weeks}w ${days}d` : `${days} days`;
                        }

                        const stageColorMap: Record<string, string> = {
                          "Creep Piglet": "bg-pink-100 text-pink-800 border-pink-300",
                          "Weaner": "bg-amber-100 text-amber-800 border-amber-300",
                          "Grower": "bg-blue-100 text-blue-800 border-blue-300",
                          "Finisher": "bg-emerald-100 text-emerald-800 border-emerald-300",
                          "Gilt": "bg-purple-100 text-purple-800 border-purple-300",
                          "Sow": "bg-rose-100 text-rose-800 border-rose-300",
                          "Boar": "bg-slate-100 text-slate-800 border-slate-300"
                        };

                        return (
                          <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                            <td className="py-3 px-4">
                              <span className="font-mono font-black text-slate-900 block text-xs">{p.tagId}</span>
                              <span className="text-[10px] text-slate-500 font-medium">{p.breed} • {p.gender}</span>
                            </td>
                            <td className="py-3 px-4">
                              {p.damTagId || p.dam ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-pink-100 text-pink-800 border border-pink-200">
                                  ♀ Dam: {p.damTagId || p.dam} {p.damBreed ? `(${p.damBreed})` : ""}
                                </span>
                              ) : (
                                <span className="text-slate-400 text-xs italic">Unlinked</span>
                              )}
                            </td>
                            <td className="py-3 px-4">
                              {p.sireTagId || p.sire ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-800 border border-slate-200">
                                  ♂ Sire: {p.sireTagId || p.sire}
                                </span>
                              ) : (
                                <span className="text-slate-400 text-xs italic">Unlinked</span>
                              )}
                            </td>
                            <td className="py-3 px-4">
                              <span className="font-bold text-slate-800 block">{ageText}</span>
                              <span className="text-[10px] text-slate-400 font-medium">{p.birthDate || "—"}</span>
                            </td>
                            <td className="py-3 px-4 text-center">
                              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${stageColorMap[p.category || ""] || "bg-slate-100 text-slate-800 border-slate-300"}`}>
                                {p.category || p.growthStage || "Creep Piglet"}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-right font-black text-slate-900">{p.currentWeight || p.weightKg || "—"} kg</td>
                            <td className="py-3 px-4 font-semibold text-slate-600">{p.location || "Nursery Bay AL4"}</td>
                            <td className="py-3 px-4 text-right font-black text-emerald-700">
                              {currencySymbol} {(p.currentValue || p.estimatedValue || p.purchasePrice || 0).toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-center">
                              <div className="flex items-center justify-center gap-1.5 flex-wrap">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setShowStageAdvanceModal(p);
                                    const nextMap: Record<string, { stage: string; weight: number; val: number }> = {
                                      "Creep Piglet": { stage: "Weaner", weight: 18, val: 1200 },
                                      "Weaner": { stage: "Grower", weight: 45, val: 2400 },
                                      "Grower": { stage: "Finisher", weight: 90, val: 4500 },
                                      "Finisher": { stage: "Gilt", weight: 120, val: 6500 }
                                    };
                                    const next = nextMap[p.category || "Creep Piglet"] || { stage: "Weaner", weight: 18, val: 1200 };
                                    setAdvanceTargetStage(next.stage);
                                    setAdvanceNewWeight(next.weight);
                                    setAdvanceNewValuation(next.val);
                                  }}
                                  className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded text-[10px] flex items-center gap-1 cursor-pointer shadow-2xs"
                                  title="Advance Stage & Book Revaluation Gain"
                                >
                                  <TrendingUp className="w-3 h-3" /> Advance Stage
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSalePigTarget(p);
                                    setSaleWeight(p.currentWeight || p.weightKg || 45);
                                    setSalePricePerKg(45);
                                  }}
                                  className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                                  title="Process Sale"
                                >
                                  <ShoppingCart className="w-3 h-3" /> Sell
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setMortalityPigTarget(p);
                                    setMortalityLossValue(p.currentValue || p.estimatedValue || p.purchasePrice || 800);
                                  }}
                                  className="px-2 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                                  title="Record Mortality"
                                >
                                  <Skull className="w-3 h-3" /> Mortality
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 4: SWINE VACCINATION SCHEDULE */}
      {activeSubTab === "vaccination" && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
              <Stethoscope className="w-5 h-5 text-rose-600" />
              Predefined Standard Swine Vaccination Schedule
            </h3>
            <p className="text-slate-500 text-xs">
              Industry standard health protocols for pig herds in Zambia (Erysipelas, Parvovirus/Lepto, Mycoplasma, PCV2, E. Coli).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {swineVaccinationSchedule.map(v => (
              <div key={v.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-rose-100 text-rose-800">
                    {v.age}
                  </span>
                  <span className="text-[10px] font-bold text-slate-500">{v.route}</span>
                </div>

                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm">{v.vaccine}</h4>
                  <p className="text-slate-600 text-xs font-semibold">Target: {v.disease}</p>
                </div>

                <div className="bg-white p-2.5 rounded-lg border border-slate-200 text-xs space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-500 font-bold">Target Group:</span>
                    <span className="font-extrabold text-slate-800">{v.targetGroup}</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-500 font-bold">Booster Interval:</span>
                    <span className="font-extrabold text-rose-700">{v.booster}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL 1: REGISTER NEW PIG */}
      {showAddPigModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <h3 className="font-black text-slate-900 text-base">Register New Pig Record</h3>

            <form onSubmit={handleRegisterPig} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Pig Tag ID / Ear Notch</label>
                  <input
                    type="text"
                    placeholder="e.g. PG-105"
                    value={newTagId}
                    onChange={e => setNewTagId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Name / Identifier (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. TN70 Prime Sow"
                    value={newName}
                    onChange={e => setNewName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-800"
                  />
                </div>
              </div>

              <SearchablePigSelect
                label="Pig Breed Line"
                value={newBreed}
                options={PIG_BREEDS.map(b => ({
                  value: b,
                  label: b,
                  sublabel: `Certified ${b} Swine Line`,
                  badge: "Genetics"
                }))}
                onChange={val => setNewBreed(val)}
                placeholder="Search swine breed..."
              />

              <div className="grid grid-cols-2 gap-3">
                <SearchablePigSelect
                  label="Category / Stage"
                  value={newCategory}
                  options={[
                    { value: "Grower", label: "Grower (Growing Swine)", sublabel: "Target 30 - 65 kg | Grower Feed Stage", badge: "Primary Unit" },
                    { value: "Weaner", label: "Weaner Piglet", sublabel: "Target 10 - 25 kg | Weaner Feed Stage", badge: "Starter" },
                    { value: "Creep Piglet", label: "Creep Piglet", sublabel: "Target 1 - 10 kg | Suckling Stage", badge: "Nursery" },
                    { value: "Finisher", label: "Finisher / Porker", sublabel: "Target 65 - 110+ kg | Slaughter Ready", badge: "Market Ready" },
                    { value: "Gilt", label: "Gilt (Young Female)", sublabel: "Unbred Young Breeding Female", badge: "Breeding Unit" },
                    { value: "Sow", label: "Sow (Mature Female)", sublabel: "Active Breeding Female / Farrowing", badge: "Breeding Unit" },
                    { value: "Boar", label: "Boar (Breeding Male)", sublabel: "Active Breeding Male", badge: "Breeding Unit" },
                  ]}
                  onChange={val => setNewCategory(val as any)}
                  placeholder="Search swine stage..."
                />

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Sex</label>
                  <select
                    value={newGender}
                    onChange={e => setNewGender(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800"
                  >
                    <option value="Female">Female</option>
                    <option value="Male">Male</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Dam / Mother Sow Tag (Lineage)</label>
                  <input
                    type="text"
                    placeholder="e.g. PG-SOW-01"
                    value={newDamTagId}
                    onChange={e => setNewDamTagId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Sire / Boar Tag (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. PG-BOAR-01"
                    value={newSireTagId}
                    onChange={e => setNewSireTagId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    value={newWeight}
                    onChange={e => setNewWeight(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Appraisal Value ({currencySymbol})</label>
                  <input
                    type="number"
                    value={newCost}
                    onChange={e => setNewCost(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddPigModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-rose-600 text-white font-bold text-xs rounded-xl shadow"
                >
                  Save Pig Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: RECORD FARROWING / BREEDING */}
      {showFarrowingModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <h3 className="font-black text-slate-900 text-base">Record Sow Breeding & Farrowing</h3>

            <form onSubmit={handleSaveFarrowingRecord} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Sow Tag ID</label>
                <input
                  type="text"
                  placeholder="e.g. PG-101"
                  value={farrSowTagId}
                  onChange={e => setFarrSowTagId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Boar Breed Line Used</label>
                <input
                  type="text"
                  placeholder="e.g. TN70 Breeding Stud"
                  value={farrBoarTagId}
                  onChange={e => setFarrBoarTagId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Service / Breeding Date</label>
                <input
                  type="date"
                  value={farrServiceDate}
                  onChange={e => setFarrServiceDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  required
                />
              </div>

              <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-xs">
                <span className="block text-[10px] uppercase font-bold text-rose-600">Calculated Farrowing Date (114 Days)</span>
                <span className="text-base font-black text-rose-900">{calculatedFarrowingDate}</span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowFarrowingModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-rose-600 text-white font-bold text-xs rounded-xl shadow"
                >
                  Save Farrowing Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Bulk / Batch Pig Registration Modal */}
      {showBulkPigModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                  <Upload className="w-5 h-5 text-amber-500" /> Swine Bulk / Batch Entry Engine
                </h3>
                <p className="text-xs text-slate-500">Register entire litter batches or import CSV text into central inventory & biological asset ledger.</p>
              </div>
              <button onClick={() => setShowBulkPigModal(false)} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
            </div>

            <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-xl text-xs font-bold">
              <button
                type="button"
                onClick={() => setBulkMode("batch")}
                className={`flex-1 py-1.5 rounded-lg transition-all ${bulkMode === "batch" ? "bg-white text-slate-900 shadow" : "text-slate-500"}`}
              >
                Auto Batch Generator
              </button>
              <button
                type="button"
                onClick={() => setBulkMode("csv")}
                className={`flex-1 py-1.5 rounded-lg transition-all ${bulkMode === "csv" ? "bg-white text-slate-900 shadow" : "text-slate-500"}`}
              >
                <FileSpreadsheet className="w-3.5 h-3.5 inline mr-1" /> Direct CSV Import
              </button>
            </div>

            <form onSubmit={handleBulkPigSubmit} className="space-y-4 text-xs">
              {bulkMode === "batch" ? (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Batch Count (Head)</label>
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={bulkCount}
                        onChange={e => setBulkCount(parseInt(e.target.value) || 1)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                        required
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Tag Prefix</label>
                      <input
                        type="text"
                        value={bulkTagPrefix}
                        onChange={e => setBulkTagPrefix(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <SearchablePigSelect
                      label="Breed Line"
                      value={bulkBreed}
                      options={PIG_BREEDS.map(b => ({
                        value: b,
                        label: b,
                        sublabel: `Certified ${b} Swine Line`,
                        badge: "Genetics"
                      }))}
                      onChange={val => setBulkBreed(val)}
                      placeholder="Search swine breed..."
                    />

                    <SearchablePigSelect
                      label="Stage / Category"
                      value={bulkCategory}
                      options={[
                        { value: "Grower", label: "Grower (Growing Swine)", sublabel: "Target 30 - 65 kg | Grower Feed Stage", badge: "Primary Unit" },
                        { value: "Weaner", label: "Weaner Piglet", sublabel: "Target 10 - 25 kg | Weaner Feed Stage", badge: "Starter" },
                        { value: "Creep Piglet", label: "Creep Piglet", sublabel: "Target 1 - 10 kg | Suckling Stage", badge: "Nursery" },
                        { value: "Finisher", label: "Finisher / Porker", sublabel: "Target 65 - 110+ kg | Slaughter Ready", badge: "Market Ready" },
                        { value: "Gilt", label: "Gilt (Young Female)", sublabel: "Unbred Young Breeding Female", badge: "Breeding Unit" },
                        { value: "Sow", label: "Sow (Mature Female)", sublabel: "Active Breeding Female / Farrowing", badge: "Breeding Unit" },
                        { value: "Boar", label: "Boar (Breeding Male)", sublabel: "Active Breeding Male", badge: "Breeding Unit" },
                      ]}
                      onChange={val => setBulkCategory(val as any)}
                      placeholder="Search swine stage/category..."
                    />

                    <div>
                      <label className="block font-bold text-slate-700 mb-1 text-xs uppercase tracking-wider">Sex Mix</label>
                      <select
                        value={bulkGender}
                        onChange={e => setBulkGender(e.target.value as any)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900 bg-white"
                      >
                        <option value="Mixed">Mixed (50:50 Ratio)</option>
                        <option value="Female">Female Only</option>
                        <option value="Male">Male Only</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Avg Weight (kg)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={bulkAvgWeight}
                        onChange={e => setBulkAvgWeight(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                        required
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Unit Appraisal ({currencySymbol})</label>
                      <input
                        type="number"
                        value={bulkUnitValue}
                        onChange={e => setBulkUnitValue(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                        required
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Pen / Housing Bay</label>
                      <input
                        type="text"
                        value={bulkPenLocation}
                        onChange={e => setBulkPenLocation(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                        required
                      />
                    </div>
                  </div>

                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 font-medium">
                    <span className="font-bold">Total Batch Valuation: </span>
                    {currencySymbol}{(bulkCount * bulkUnitValue).toLocaleString()} posted to Biological Assets (Account 1420).
                  </div>
                </>
              ) : (
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block font-bold text-slate-700">Upload CSV / Text File</label>
                      <button
                        type="button"
                        onClick={handleDownloadCsvTemplate}
                        className="flex items-center gap-1.5 text-xs font-bold text-amber-900 bg-amber-100 hover:bg-amber-200 px-3 py-1 rounded-lg border border-amber-300 transition-colors shadow-2xs cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5 text-amber-800" />
                        <span>Download CSV Template</span>
                      </button>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-amber-50/60 hover:bg-amber-50 rounded-xl border-2 border-dashed border-amber-300 transition-colors">
                      <FileSpreadsheet className="w-6 h-6 text-amber-600 shrink-0" />
                      <div className="flex-1 text-xs flex items-center justify-between">
                        <div>
                          <label htmlFor="csv-file-picker" className="font-bold text-amber-900 hover:text-amber-950 cursor-pointer underline mr-1.5">
                            Click here to browse & select CSV file
                          </label>
                          <span className="text-amber-700">(.csv or .txt)</span>
                          <input
                            id="csv-file-picker"
                            type="file"
                            accept=".csv,.txt,text/plain,text/csv"
                            onChange={handleCsvFileUpload}
                            className="hidden"
                          />
                          <p className="text-[10px] text-slate-500 mt-0.5">Loads contents directly into the data parser below.</p>
                        </div>
                        <button
                          type="button"
                          onClick={handleDownloadCsvTemplate}
                          className="shrink-0 flex items-center gap-1.5 text-[11px] font-extrabold text-slate-800 bg-white hover:bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-300 shadow-2xs transition-all cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5 text-amber-600" />
                          <span>Get Template</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">CSV Data Preview / Raw Text (Tag, Breed, Category/Stage, Gender, Weight, Value)</label>
                    <textarea
                      rows={5}
                      placeholder={"TagId, Breed, Stage, Gender, WeightKg, AppraisalValue\nPG-GROW-001, Large White, Grower, Female, 35, 2200\nPG-GROW-002, Landrace, Grower, Male, 38, 2200"}
                      value={bulkCsvText}
                      onChange={e => setBulkCsvText(e.target.value)}
                      className="w-full p-3 font-mono text-xs rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:bg-white"
                      required
                    />
                    <p className="text-[10px] text-slate-500 mt-1">Required columns: <strong>TagId</strong> and <strong>Stage / Category</strong> (e.g. Grower, Weaner, Creep Piglet, Finisher, Gilt, Sow, Boar).</p>
                  </div>

                  {/* Real-time CSV Integrity Validation Report */}
                  {(() => {
                    const validation = validateSwineCsv(bulkCsvText);
                    return (
                      <div className="space-y-2 pt-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">CSV Validation Engine</span>
                          <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                            validation.isValid ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"
                          }`}>
                            {validation.isValid ? "VALIDATED READY" : `${validation.errors.length} ISSUE(S) DETECTED`}
                          </span>
                        </div>

                        {validation.isValid ? (
                          <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 text-xs space-y-1">
                            <div className="flex items-center gap-1.5 font-bold">
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                              <span>CSV Structure Validated Successfully</span>
                            </div>
                            <p className="text-[11px] text-emerald-700 font-medium">
                              Ready to import <strong>{validation.totalRows} head</strong> into biological registry.
                              {Object.keys(validation.detectedCategories).length > 0 && (
                                <span> Breakdown: {Object.entries(validation.detectedCategories).map(([cat, count]) => `${count} ${cat}(s)`).join(", ")}.</span>
                              )}
                            </p>
                            {validation.warnings.map((warn, i) => (
                              <p key={i} className="text-[10px] text-amber-700 font-mono">⚠️ {warn}</p>
                            ))}
                          </div>
                        ) : (
                          <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-rose-900 text-xs space-y-1.5">
                            <div className="flex items-center gap-1.5 font-bold text-rose-800">
                              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                              <span>Import Blocked — Fix validation issues below:</span>
                            </div>
                            <ul className="max-h-28 overflow-y-auto space-y-1 pl-4 list-disc text-[11px] text-rose-700 font-mono">
                              {validation.errors.map((err, i) => (
                                <li key={i}>
                                  <strong>[{err.field}]</strong> {err.message}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowBulkPigModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={bulkMode === "csv" && !validateSwineCsv(bulkCsvText).isValid}
                  className={`px-4 py-2 font-black rounded-xl shadow transition-all ${
                    bulkMode === "csv" && !validateSwineCsv(bulkCsvText).isValid
                      ? "bg-slate-200 text-slate-400 cursor-not-allowed"
                      : "bg-amber-500 hover:bg-amber-600 text-slate-950"
                  }`}
                >
                  Execute Bulk Import
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Process Pig Sale Modal */}
      {salePigTarget && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-emerald-600" /> Process Pig Sale & Offtake
              </h3>
              <button onClick={() => setSalePigTarget(null)} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs">
              <div className="font-bold text-slate-900">Tag ID: <span className="text-emerald-700 font-mono text-sm">{salePigTarget.tagId}</span></div>
              <div className="text-slate-600">Breed: {salePigTarget.breed} | Stage: {salePigTarget.category || "Finisher"}</div>
              <div className="text-slate-600">Current Valuation: {currencySymbol}{(salePigTarget.currentValue || salePigTarget.estimatedValue || 0).toLocaleString()}</div>
            </div>

            <form onSubmit={handleProcessPigSaleSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Offtake Weight (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={saleWeight}
                    onChange={e => setSaleWeight(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Price / kg ({currencySymbol})</label>
                  <input
                    type="number"
                    step="0.5"
                    value={salePricePerKg}
                    onChange={e => setSalePricePerKg(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Offtaker / Buyer Name</label>
                <input
                  type="text"
                  placeholder="e.g. Farmer's Choice / Pork City Ltd"
                  value={saleBuyer}
                  onChange={e => setSaleBuyer(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  required
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="saleApplyVatCheck"
                  checked={saleApplyVat}
                  onChange={e => setSaleApplyVat(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded"
                />
                <label htmlFor="saleApplyVatCheck" className="font-bold text-slate-700">Apply 16% VAT Tax Invoice</label>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-950 space-y-1">
                <div className="flex justify-between font-medium">
                  <span>Gross Subtotal:</span>
                  <span className="font-bold">{currencySymbol}{(saleWeight * salePricePerKg).toLocaleString()}</span>
                </div>
                {saleApplyVat && (
                  <div className="flex justify-between text-slate-600">
                    <span>Output VAT (16%):</span>
                    <span>{currencySymbol}{(saleWeight * salePricePerKg * 0.16).toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between font-black text-sm pt-1 border-t border-emerald-200 text-emerald-900">
                  <span>Total Sales Invoice:</span>
                  <span>{currencySymbol}{(saleWeight * salePricePerKg * (saleApplyVat ? 1.16 : 1)).toLocaleString()}</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSalePigTarget(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow"
                >
                  Complete Sale & Post Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Pig Mortality Modal */}
      {mortalityPigTarget && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-rose-600" /> Record Swine Mortality / Cull
              </h3>
              <button onClick={() => setMortalityPigTarget(null)} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
            </div>

            <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-xs text-rose-950 space-y-1">
              <div className="font-bold">Target Tag ID: <span className="font-mono text-sm text-rose-900">{mortalityPigTarget.tagId}</span></div>
              <div>Breed: {mortalityPigTarget.breed} | Location: {mortalityPigTarget.location || "Swine Unit"}</div>
            </div>

            <form onSubmit={handleProcessPigMortalitySubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Mortality Cause / Reason</label>
                <select
                  value={mortalityCause}
                  onChange={e => setMortalityCause(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                >
                  <option value="African Swine Fever (ASF) Suspected">African Swine Fever (ASF) Suspected</option>
                  <option value="Porcine Reproductive & Respiratory Syndrome (PRRS)">PRRS</option>
                  <option value="Post-Weaning Multisystemic Wasting Syndrome (PMWS)">PMWS / Circovirus</option>
                  <option value="Crushed / Overlay (Piglet)">Crushed / Overlay (Piglet)</option>
                  <option value="Acute Pneumonia / Respiratory Failure">Acute Pneumonia</option>
                  <option value="Cull - Severe Structural Failure">Cull - Structural / Lameness</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Veterinary Post-Mortem Notes</label>
                <textarea
                  rows={3}
                  value={mortalityDiagnosis}
                  onChange={e => setMortalityDiagnosis(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Asset Loss Value ({currencySymbol})</label>
                <input
                  type="number"
                  value={mortalityLossValue}
                  onChange={e => setMortalityLossValue(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  required
                />
              </div>

              <div className="p-3 bg-slate-100 rounded-xl text-slate-700 text-[11px] font-medium">
                ⚠️ Confirming mortality will purge this animal from active central stock and record a credit deduction on Biological Assets (Account 1420).
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setMortalityPigTarget(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow"
                >
                  Confirm & Write Off
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: REGISTER FARROWED LITTER PIGLETS TO CENTRAL ANIMAL REGISTRY */}
      {showRegisterLitterModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                  <Award className="w-5 h-5 text-rose-600" /> Register Litter to Central Animal Registry
                </h3>
                <p className="text-xs text-slate-500">
                  Generates individual biological asset records with unique IDs linked to Dam for genetic tracking and posts valuation to Account 1420.
                </p>
              </div>
              <button onClick={() => setShowRegisterLitterModal(null)} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
            </div>

            <form onSubmit={handleGenerateLitterPiglets} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-2.5 bg-pink-50 rounded-xl border border-pink-200">
                  <span className="text-[10px] uppercase font-bold text-pink-700 block">Mother (Dam Tag)</span>
                  <span className="font-mono font-black text-pink-950 text-sm">{litterDamTag}</span>
                  <span className="text-[10px] text-pink-600 block">{litterDamBreed}</span>
                </div>

                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-600 block">Father (Sire Tag)</span>
                  <span className="font-mono font-black text-slate-900 text-sm">{litterSireTag}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Live Piglets Born (Count)</label>
                  <input
                    type="number"
                    min={1}
                    max={30}
                    value={litterBornAlive}
                    onChange={e => setLitterBornAlive(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900 text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tag ID Prefix</label>
                  <input
                    type="text"
                    value={litterTagPrefix}
                    onChange={e => setLitterTagPrefix(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-slate-900"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Avg Birth Wt (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={litterAvgBirthWeight}
                    onChange={e => setLitterAvgBirthWeight(parseFloat(e.target.value) || 1.4)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Initial Value ({currencySymbol}/hd)</label>
                  <input
                    type="number"
                    value={litterAppraisalVal}
                    onChange={e => setLitterAppraisalVal(parseFloat(e.target.value) || 350)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Housing Pen</label>
                  <input
                    type="text"
                    value={litterPenLocation}
                    onChange={e => setLitterPenLocation(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-950 space-y-1">
                <div className="flex justify-between font-bold">
                  <span>Total Litter Asset Value:</span>
                  <span className="text-sm font-black text-emerald-900">{currencySymbol}{(litterBornAlive * litterAppraisalVal).toLocaleString()}</span>
                </div>
                <div className="text-[11px] text-emerald-700">
                  ⚡ Will create {litterBornAlive} individual biological asset records ({litterTagPrefix}01 to {litterTagPrefix}{String(litterBornAlive).padStart(2, "0")}) in Enterprise Central Animal Registry and Debit Account 1420 (Biological Assets).
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowRegisterLitterModal(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow cursor-pointer"
                >
                  Generate & Post to Central Registry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADVANCE GROWTH STAGE & REVALUE ASSET */}
      {showStageAdvanceModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-amber-500" /> Advance Swine Growth Stage
                </h3>
                <p className="text-xs text-slate-500">
                  Update growth stage, log progressive scale weight, and book fair-value adjustment in Account 1420 Biological Assets.
                </p>
              </div>
              <button onClick={() => setShowStageAdvanceModal(null)} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs">
              <div className="flex justify-between font-bold">
                <span>Pig Tag:</span>
                <span className="font-mono text-rose-900">{showStageAdvanceModal.tagId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Current Stage:</span>
                <span className="font-bold text-slate-800">{showStageAdvanceModal.category || showStageAdvanceModal.growthStage || "Creep Piglet"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Current Book Value:</span>
                <span className="font-bold text-slate-800">{currencySymbol}{(showStageAdvanceModal.currentValue || showStageAdvanceModal.estimatedValue || showStageAdvanceModal.purchasePrice || 0).toLocaleString()}</span>
              </div>
            </div>

            <form onSubmit={handleAdvanceStage} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Target New Growth Stage</label>
                <select
                  value={advanceTargetStage}
                  onChange={e => {
                    const st = e.target.value;
                    setAdvanceTargetStage(st);
                    const preset: Record<string, { weight: number; val: number }> = {
                      "Creep Piglet": { weight: 8, val: 500 },
                      "Weaner": { weight: 18, val: 1200 },
                      "Grower": { weight: 45, val: 2400 },
                      "Finisher": { weight: 90, val: 4500 },
                      "Gilt": { weight: 120, val: 6500 },
                      "Sow": { weight: 160, val: 8500 },
                      "Boar": { weight: 180, val: 9500 }
                    };
                    if (preset[st]) {
                      setAdvanceNewWeight(preset[st].weight);
                      setAdvanceNewValuation(preset[st].val);
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                >
                  <option value="Creep Piglet">Creep Piglet (0 - 4 weeks | Suckling)</option>
                  <option value="Weaner">Weaner Piglet (4 - 8 weeks | Starter)</option>
                  <option value="Grower">Grower Swine (8 - 16 weeks | Growing)</option>
                  <option value="Finisher">Finisher / Porker (16 - 24 weeks | Finishing)</option>
                  <option value="Gilt">Gilt (Selected Young Breeding Female)</option>
                  <option value="Sow">Sow (Active Farrowing Breeding Dam)</option>
                  <option value="Boar">Boar (Breeding Sire Stud)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">New Live Weight (kg)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={advanceNewWeight}
                    onChange={e => setAdvanceNewWeight(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">New Biological Valuation ({currencySymbol})</label>
                  <input
                    type="number"
                    value={advanceNewValuation}
                    onChange={e => setAdvanceNewValuation(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-emerald-800"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Transition Notes / Pen Transfer</label>
                <input
                  type="text"
                  placeholder="e.g. Moved to Weaner Unit #2 after 28-day lactation"
                  value={advanceNotes}
                  onChange={e => setAdvanceNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium text-slate-900"
                />
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-950">
                <div className="flex justify-between font-bold">
                  <span>Revaluation Adjustment:</span>
                  <span className={`font-black ${advanceNewValuation >= (showStageAdvanceModal.currentValue || 0) ? "text-emerald-700" : "text-rose-700"}`}>
                    {advanceNewValuation >= (showStageAdvanceModal.currentValue || 0) ? "+" : ""}
                    {currencySymbol}{(advanceNewValuation - (showStageAdvanceModal.currentValue || showStageAdvanceModal.estimatedValue || showStageAdvanceModal.purchasePrice || 0)).toLocaleString()}
                  </span>
                </div>
                <div className="text-[10px] text-amber-700 mt-0.5">
                  Difference will be credited to Account 4400 (Fair Value Biological Gain) and updated in Central Animal Registry.
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowStageAdvanceModal(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl shadow cursor-pointer"
                >
                  Confirm Stage Transition
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official Pig Cash Sale Receipt Modal */}
      {activePigReceiptSale && (
        <FarmSaleReceiptModal
          sale={activePigReceiptSale}
          isOpen={!!activePigReceiptSale}
          onClose={() => setActivePigReceiptSale(null)}
          activeFarm={activeFarm}
          currencySymbol={currencySymbol}
          cashierName="Swine Operations Supervisor"
        />
      )}
    </div>
  );
}

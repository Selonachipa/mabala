import React, { useState, useMemo } from "react";
import { 
  Calculator, 
  Plus, 
  Trash2, 
  Save, 
  Layers, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  DollarSign, 
  X, 
  RefreshCw,
  Tag,
  Scale,
  Edit3,
  Copy,
  Printer,
  Search,
  SlidersHorizontal,
  ChevronDown,
  ChevronUp,
  FileText,
  Info,
  Check,
  Flame,
  Wheat,
  Activity,
  ArrowRight,
  BookOpen,
  Eye
} from "lucide-react";
import { 
  AnimalTypeConfig, 
  FeedIngredient, 
  FeedFormulation, 
  FormulationIngredient 
} from "../../types";
import { 
  DEFAULT_ANIMAL_TYPES, 
  computeFormulationCosts, 
  STARTER_FORMULATION_TEMPLATES 
} from "../../services/feedEngineService";

interface FeedFormulationBuilderProps {
  tenantId?: string;
  currencySymbol?: string;
  animalTypes?: AnimalTypeConfig[];
  ingredients: FeedIngredient[];
  formulations: FeedFormulation[];
  onSaveIngredient: (ing: Partial<FeedIngredient> & { name: string; unit: "kg" | "g" | "litre"; category: FeedIngredient["category"]; currentCostPerUnit: number }) => void;
  onSaveFormulation: (form: Omit<FeedFormulation, "id" | "tenantId" | "costPerKgMix" | "costPerAnimalPerDay" | "createdAt" | "updatedAt"> & { id?: string }, options?: { bumpVersion?: boolean; setAsPrimaryActive?: boolean }) => void;
  onDeleteFormulation?: (formulationId: string) => void;
  onDuplicateFormulation?: (formulationId: string, customName?: string) => void;
  onToggleStatus?: (formulationId: string, status: "active" | "inactive" | "draft" | "archived") => void;
  onSetPrimaryActive?: (formulationId: string) => void;
  onResetDefaults?: () => void;
  onShowToast?: (msg: string, type: "success" | "error" | "info") => void;
}

export default function FeedFormulationBuilder({
  tenantId = "default",
  currencySymbol = "ZMW",
  animalTypes = DEFAULT_ANIMAL_TYPES,
  ingredients,
  formulations,
  onSaveIngredient,
  onSaveFormulation,
  onDeleteFormulation,
  onDuplicateFormulation,
  onToggleStatus,
  onSetPrimaryActive,
  onResetDefaults,
  onShowToast
}: FeedFormulationBuilderProps) {
  // Navigation & View Mode
  const [viewMode, setViewMode] = useState<"cards" | "table">("cards");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterSpecies, setFilterSpecies] = useState<string>("all");
  const [filterStage, setFilterStage] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");

  // Selection & Builder State
  const [selectedAnimalType, setSelectedAnimalType] = useState<string>("pig");
  const [selectedStage, setSelectedStage] = useState<string>("grower");
  const [editingFormulationId, setEditingFormulationId] = useState<string | null>(null);
  const [formName, setFormName] = useState<string>("");
  const [formStatus, setFormStatus] = useState<"active" | "inactive" | "draft" | "archived">("active");
  const [formBatchSize, setFormBatchSize] = useState<number>(100);
  const [formDailyQty, setFormDailyQty] = useState<number>(1.8);
  const [formNotes, setFormNotes] = useState<string>("");
  const [formRecipeRows, setFormRecipeRows] = useState<FormulationIngredient[]>([]);
  const [saveAsVersionBump, setSaveAsVersionBump] = useState(false);
  const [setAsPrimaryActiveOnSave, setSetAsPrimaryActiveOnSave] = useState(true);

  // Modals
  const [showEditModal, setShowEditModal] = useState(false);
  const [showQuickAddModal, setShowQuickAddModal] = useState(false);
  const [showWorkOrderModal, setShowWorkOrderModal] = useState<FeedFormulation | null>(null);
  const [workOrderBatchMultiplier, setWorkOrderBatchMultiplier] = useState<number>(1);
  const [showSpecsModal, setShowSpecsModal] = useState<FeedFormulation | null>(null);
  const [showPresetLibraryModal, setShowPresetLibraryModal] = useState(false);
  const [showConfirmDeleteModal, setShowConfirmDeleteModal] = useState<FeedFormulation | null>(null);
  const [duplicateNameModal, setDuplicateNameModal] = useState<FeedFormulation | null>(null);
  const [duplicateCustomName, setDuplicateCustomName] = useState("");

  // Quick Add Ingredient State
  const [quickIngName, setQuickIngName] = useState("");
  const [quickIngCategory, setQuickIngCategory] = useState<FeedIngredient["category"]>("energy");
  const [quickIngUnit, setQuickIngUnit] = useState<"kg" | "g" | "litre">("kg");
  const [quickIngCost, setQuickIngCost] = useState<number>(0);
  const [quickIngCP, setQuickIngCP] = useState<number>(0);
  const [quickIngCF, setQuickIngCF] = useState<number>(0);
  const [quickIngEnergy, setQuickIngEnergy] = useState<number>(0);

  // Helper Toast
  const toast = (msg: string, type: "success" | "error" | "info" = "info") => {
    if (onShowToast) onShowToast(msg, type);
    else console.log(`[Toast ${type}]: ${msg}`);
  };

  // Current animal config for stages
  const currentAnimalConfig = useMemo(() => {
    return animalTypes.find(a => a.id === selectedAnimalType) || animalTypes[0];
  }, [animalTypes, selectedAnimalType]);

  // Live Recipe Calculations for the active builder form
  const liveCalc = useMemo(() => {
    return computeFormulationCosts(formRecipeRows, ingredients, formBatchSize, formDailyQty);
  }, [formRecipeRows, ingredients, formBatchSize, formDailyQty]);

  // Filtered Formulations List
  const filteredFormulations = useMemo(() => {
    return formulations.filter(f => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = f.name.toLowerCase().includes(q);
        const matchesSpecies = f.animalTypeId.toLowerCase().includes(q);
        const matchesStage = f.stageId.toLowerCase().includes(q);
        const matchesIngredient = f.ingredients.some(i => i.ingredientName.toLowerCase().includes(q));
        if (!matchesName && !matchesSpecies && !matchesStage && !matchesIngredient) {
          return false;
        }
      }

      // Species
      if (filterSpecies !== "all" && f.animalTypeId !== filterSpecies) return false;

      // Stage
      if (filterStage !== "all" && f.stageId !== filterStage) return false;

      // Status
      if (filterStatus !== "all") {
        if (filterStatus === "active" && f.status !== "active") return false;
        if (filterStatus === "inactive" && f.status !== "inactive") return false;
        if (filterStatus === "draft" && f.status !== "draft") return false;
        if (filterStatus === "archived" && f.status !== "archived") return false;
      }

      return true;
    });
  }, [formulations, searchQuery, filterSpecies, filterStage, filterStatus]);

  // Available stages for the filtered species
  const filterStagesForSpecies = useMemo(() => {
    if (filterSpecies === "all") return [];
    const cfg = animalTypes.find(a => a.id === filterSpecies);
    return cfg ? cfg.stages : [];
  }, [animalTypes, filterSpecies]);

  // Formulation counts
  const totalCount = formulations.length;
  const activeCount = formulations.filter(f => f.status === "active").length;
  const inactiveCount = formulations.filter(f => f.status !== "active").length;

  // Handlers for recipe ingredients
  const handleAddRecipeRow = (ingredientId?: string) => {
    if (ingredientId === "__ADD_NEW__") {
      setShowQuickAddModal(true);
      return;
    }

    const ing = ingredients.find(i => i.id === ingredientId) || ingredients[0];
    if (!ing) {
      setShowQuickAddModal(true);
      return;
    }

    setFormRecipeRows(prev => [
      ...prev,
      {
        ingredientId: ing.id,
        ingredientName: ing.name,
        inclusionQtyPerUnit: 10,
        unit: ing.unit,
        costPerKgOverride: ing.currentCostPerUnit
      }
    ]);
  };

  const handleUpdateRecipeRow = (index: number, field: string, val: any) => {
    setFormRecipeRows(prev => {
      const updated = [...prev];
      if (field === "ingredientId") {
        if (val === "__ADD_NEW__") {
          setShowQuickAddModal(true);
          return prev;
        }
        const ing = ingredients.find(i => i.id === val);
        if (ing) {
          updated[index] = {
            ...updated[index],
            ingredientId: ing.id,
            ingredientName: ing.name,
            unit: ing.unit,
            costPerKgOverride: ing.currentCostPerUnit
          };
        }
      } else {
        updated[index] = { ...updated[index], [field]: val };
      }
      return updated;
    });
  };

  const handleRemoveRecipeRow = (index: number) => {
    setFormRecipeRows(prev => prev.filter((_, i) => i !== index));
  };

  // Auto-normalize recipe inclusion to equal target batch size
  const handleNormalizeRecipe = () => {
    if (liveCalc.totalInclusionQty <= 0) return;
    const factor = formBatchSize / liveCalc.totalInclusionQty;
    setFormRecipeRows(prev => prev.map(row => ({
      ...row,
      inclusionQtyPerUnit: Number((row.inclusionQtyPerUnit * factor).toFixed(2))
    })));
    toast(`Adjusted recipe ingredient ratios to sum exactly to ${formBatchSize} kg!`, "info");
  };

  // Save Inline Quick Ingredient
  const handleQuickAddIngredientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickIngName.trim()) {
      toast("Please enter an ingredient name.", "error");
      return;
    }

    onSaveIngredient({
      name: quickIngName.trim(),
      category: quickIngCategory,
      unit: quickIngUnit,
      currentCostPerUnit: quickIngCost,
      crudeProteinPercent: quickIngCP,
      crudeFiberPercent: quickIngCF,
      energyKcalPerKg: quickIngEnergy,
      energyMjPerKg: Number((quickIngEnergy * 0.004184).toFixed(2)),
      active: true
    });

    toast(`Quick-added ingredient "${quickIngName}" to tenant master list!`, "success");

    // Reset and close
    setQuickIngName("");
    setQuickIngCost(0);
    setQuickIngCP(0);
    setQuickIngCF(0);
    setQuickIngEnergy(0);
    setShowQuickAddModal(false);
  };

  // Load formulation into edit state (both modal & inline builder)
  const handleOpenEditModal = (form: FeedFormulation) => {
    setEditingFormulationId(form.id);
    setSelectedAnimalType(form.animalTypeId);
    setSelectedStage(form.stageId);
    setFormName(form.name);
    setFormStatus(form.status || "active");
    setFormBatchSize(form.batchSize || 100);
    setFormDailyQty(form.dailyQtyPerAnimal || 1.0);
    setFormNotes(form.notes || "");
    setFormRecipeRows(form.ingredients || []);
    setSaveAsVersionBump(false);
    setSetAsPrimaryActiveOnSave(form.status === "active");
    setShowEditModal(true);
  };

  const handleStartNewFormulation = () => {
    setEditingFormulationId(null);
    setFormName("");
    setFormStatus("active");
    setFormBatchSize(100);
    setFormDailyQty(1.8);
    setFormNotes("");
    setFormRecipeRows([]);
    setSaveAsVersionBump(false);
    setSetAsPrimaryActiveOnSave(true);
    setShowEditModal(true);
  };

  // Submit Formulation from builder/modal
  const handleSubmitFormulation = () => {
    if (!formName.trim()) {
      toast("Please specify a formulation name.", "error");
      return;
    }
    if (formRecipeRows.length === 0) {
      toast("Please add at least one ingredient recipe row.", "error");
      return;
    }

    onSaveFormulation(
      {
        id: editingFormulationId || undefined,
        animalTypeId: selectedAnimalType,
        stageId: selectedStage,
        name: formName.trim(),
        status: formStatus,
        version: 1,
        effectiveFrom: new Date().toISOString(),
        batchSize: formBatchSize,
        dailyQtyPerAnimal: formDailyQty,
        notes: formNotes.trim(),
        ingredients: formRecipeRows
      },
      {
        bumpVersion: saveAsVersionBump,
        setAsPrimaryActive: setAsPrimaryActiveOnSave && formStatus === "active"
      }
    );

    const actionText = editingFormulationId 
      ? (saveAsVersionBump ? `Published version bump for "${formName}"!` : `Saved active updates to "${formName}"!`)
      : `Created new active feed formulation "${formName}"!`;

    toast(actionText, "success");
    setShowEditModal(false);
    setEditingFormulationId(null);
    setFormName("");
    setFormRecipeRows([]);
  };

  // Load preset from library
  const handleLoadPreset = (preset: typeof STARTER_FORMULATION_TEMPLATES[0]) => {
    setSelectedAnimalType(preset.animalTypeId);
    setSelectedStage(preset.stageId);
    setFormName(preset.name);
    setFormBatchSize(preset.batchSize);
    setFormDailyQty(preset.dailyQtyPerAnimal);
    setFormStatus("active");
    setSetAsPrimaryActiveOnSave(true);

    const recipe: FormulationIngredient[] = preset.ingredientRatios.map(r => {
      const master = ingredients.find(m => m.name.toLowerCase().includes(r.name.toLowerCase())) || ingredients[0];
      return {
        ingredientId: master.id,
        ingredientName: master.name,
        inclusionQtyPerUnit: r.qty,
        unit: master.unit,
        costPerKgOverride: master.currentCostPerUnit
      };
    });

    setFormRecipeRows(recipe);
    setShowPresetLibraryModal(false);
    setShowEditModal(true);
    toast(`Loaded preset "${preset.name}". Customize and save to activate for your tenant!`, "info");
  };

  return (
    <div className="space-y-6">
      {/* 1. TOP HEADER & METRICS BAR */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200">
                Tenant Active Formulations
              </span>
              <span className="text-xs font-semibold text-slate-500">
                Tenant ID: <span className="font-mono font-bold text-slate-700">{tenantId}</span>
              </span>
            </div>
            <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
              <Layers className="w-6 h-6 text-emerald-600" />
              Feed Formulation Control & Mixing Center
            </h3>
            <p className="text-slate-500 text-xs mt-0.5">
              Inspect, edit in-place, version-bump, and configure live feeding rations for each livestock growth stage.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setShowPresetLibraryModal(true)}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl border border-slate-200 transition-all flex items-center gap-1.5"
            >
              <BookOpen className="w-4 h-4 text-emerald-700" />
              Preset Library
            </button>

            {onResetDefaults && (
              <button
                onClick={() => {
                  if (window.confirm("Reset all tenant feed formulations back to standard agronomic starter presets?")) {
                    onResetDefaults();
                  }
                }}
                className="px-3 py-2 bg-slate-50 hover:bg-rose-50 text-slate-600 hover:text-rose-700 font-bold text-xs rounded-xl border border-slate-200 transition-all flex items-center gap-1.5"
                title="Restore default formulations"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Reset Defaults
              </button>
            )}

            <button
              onClick={handleStartNewFormulation}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md transition-all flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              + Create Formulation
            </button>
          </div>
        </div>

        {/* STATS OVERVIEW CARDS */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-100">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
            <span className="block text-[10px] uppercase font-extrabold text-slate-500">Total Formulations</span>
            <span className="text-xl font-black text-slate-900">{totalCount}</span>
            <span className="text-[10px] text-slate-400 block font-medium">Tenant catalog items</span>
          </div>

          <div className="p-3 bg-emerald-50/80 rounded-xl border border-emerald-200">
            <span className="block text-[10px] uppercase font-extrabold text-emerald-800">Active Rations</span>
            <span className="text-xl font-black text-emerald-700">{activeCount}</span>
            <span className="text-[10px] text-emerald-600 block font-semibold">Active in daily logs</span>
          </div>

          <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200">
            <span className="block text-[10px] uppercase font-extrabold text-amber-800">Inactive / Drafts</span>
            <span className="text-xl font-black text-amber-700">{inactiveCount}</span>
            <span className="text-[10px] text-amber-600 block font-semibold">Seasonal & archived</span>
          </div>

          <div className="p-3 bg-teal-50/80 rounded-xl border border-teal-200">
            <span className="block text-[10px] uppercase font-extrabold text-teal-800">Master Ingredients</span>
            <span className="text-xl font-black text-teal-700">{ingredients.length}</span>
            <span className="text-[10px] text-teal-600 block font-semibold">Available for rations</span>
          </div>
        </div>
      </div>

      {/* 2. FILTER & SEARCH CONTROLS */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Search Bar */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search formulations or ingredients..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-8 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 placeholder-slate-400 focus:ring-2 focus:ring-emerald-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filter Dropdowns */}
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto text-xs font-bold">
            {/* Species */}
            <select
              value={filterSpecies}
              onChange={e => {
                setFilterSpecies(e.target.value);
                setFilterStage("all");
              }}
              className="px-3 py-2 rounded-xl border border-slate-300 text-slate-800 bg-white"
            >
              <option value="all">All Species</option>
              {animalTypes.map(a => (
                <option key={a.id} value={a.id}>{a.name}</option>
              ))}
            </select>

            {/* Stage */}
            {filterStagesForSpecies.length > 0 && (
              <select
                value={filterStage}
                onChange={e => setFilterStage(e.target.value)}
                className="px-3 py-2 rounded-xl border border-slate-300 text-slate-800 bg-white"
              >
                <option value="all">All Stages</option>
                {filterStagesForSpecies.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            )}

            {/* Status */}
            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-300 text-slate-800 bg-white"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active Only</option>
              <option value="inactive">Inactive</option>
              <option value="draft">Draft</option>
              <option value="archived">Archived</option>
            </select>

            {/* View Switch */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
              <button
                onClick={() => setViewMode("cards")}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  viewMode === "cards" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500 hover:text-slate-800"
                }`}
              >
                Cards
              </button>
              <button
                onClick={() => setViewMode("table")}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  viewMode === "table" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500 hover:text-slate-800"
                }`}
              >
                Table
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 3. ACTIVE FORMULATIONS DISPLAY (CARDS OR TABLE) */}
      {filteredFormulations.length === 0 ? (
        <div className="bg-white p-12 rounded-2xl border border-dashed border-slate-300 text-center space-y-4">
          <Layers className="w-12 h-12 text-slate-300 mx-auto" />
          <div className="space-y-1">
            <h4 className="font-black text-slate-800 text-base">No feed formulations matched your filters</h4>
            <p className="text-slate-500 text-xs max-w-md mx-auto">
              Try adjusting your search query, selecting "All Species", or load a standard balanced recipe from the Preset Library.
            </p>
          </div>
          <div className="flex items-center justify-center gap-3 pt-2">
            <button
              onClick={() => {
                setSearchQuery("");
                setFilterSpecies("all");
                setFilterStage("all");
                setFilterStatus("all");
              }}
              className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-200"
            >
              Clear Filters
            </button>
            <button
              onClick={() => setShowPresetLibraryModal(true)}
              className="px-4 py-2 bg-emerald-600 text-white font-black text-xs rounded-xl hover:bg-emerald-700 shadow"
            >
              Browse Presets
            </button>
          </div>
        </div>
      ) : viewMode === "cards" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredFormulations.map(form => {
            const speciesObj = animalTypes.find(a => a.id === form.animalTypeId);
            const speciesName = speciesObj?.name || form.animalTypeId;
            const stageName = speciesObj?.stages.find(s => s.id === form.stageId)?.name || form.stageId;
            const isActive = form.status === "active";

            // Nutrients summary
            const calc = computeFormulationCosts(form.ingredients, ingredients, form.batchSize, form.dailyQtyPerAnimal);

            return (
              <div 
                key={form.id} 
                className={`bg-white rounded-2xl border transition-all shadow-xs flex flex-col justify-between overflow-hidden ${
                  isActive ? "border-emerald-300 ring-1 ring-emerald-400/30" : "border-slate-200 hover:border-slate-300 opacity-90"
                }`}
              >
                {/* CARD HEADER */}
                <div className="p-5 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800">
                          {speciesName}
                        </span>
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700 capitalize">
                          {stageName}
                        </span>
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 text-slate-500">
                          v{form.version}
                        </span>
                      </div>
                      <h4 className="font-black text-slate-900 text-base leading-snug">{form.name}</h4>
                    </div>

                    {/* STATUS PILL & TOGGLE */}
                    <div className="flex flex-col items-end gap-1">
                      <button
                        onClick={() => {
                          if (onToggleStatus) {
                            const nextStatus = isActive ? "inactive" : "active";
                            onToggleStatus(form.id, nextStatus);
                          }
                        }}
                        className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider flex items-center gap-1 transition-all ${
                          isActive 
                            ? "bg-emerald-500 text-white shadow-2xs hover:bg-emerald-600" 
                            : "bg-slate-200 text-slate-700 hover:bg-slate-300"
                        }`}
                        title="Click to toggle Active status"
                      >
                        {isActive && <Check className="w-3 h-3" />}
                        {form.status.toUpperCase()}
                      </button>
                    </div>
                  </div>

                  {/* KEY METRICS GRID */}
                  <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-150 text-xs">
                    <div>
                      <span className="block text-[10px] text-slate-400 font-bold uppercase">Cost / kg Mix</span>
                      <span className="text-sm font-black text-slate-900">{currencySymbol} {form.costPerKgMix.toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="block text-[10px] text-slate-400 font-bold uppercase">Cost / Head / Day</span>
                      <span className="text-sm font-black text-emerald-700">{currencySymbol} {form.costPerAnimalPerDay.toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="block text-[10px] text-slate-400 font-bold uppercase">Crude Protein</span>
                      <span className="text-xs font-extrabold text-blue-800">{calc.nutrients.crudeProteinPercent.toFixed(1)}% CP</span>
                    </div>
                    <div>
                      <span className="block text-[10px] text-slate-400 font-bold uppercase">Energy (ME)</span>
                      <span className="text-xs font-extrabold text-amber-800">{calc.nutrients.energyKcalPerKg.toLocaleString()} kcal/kg</span>
                    </div>
                  </div>

                  {/* INGREDIENT CHIPS */}
                  <div className="space-y-1.5">
                    <span className="block text-[10px] font-bold uppercase text-slate-400">
                      Recipe Mix ({form.ingredients.length} ingredients • {form.batchSize}kg batch)
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {form.ingredients.slice(0, 4).map((ing, i) => (
                        <span key={i} className="text-[11px] font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md border border-slate-200">
                          {ing.ingredientName}: <strong className="text-slate-900">{ing.inclusionQtyPerUnit} {ing.unit}</strong>
                        </span>
                      ))}
                      {form.ingredients.length > 4 && (
                        <span className="text-[10px] font-bold bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded">
                          +{form.ingredients.length - 4} more
                        </span>
                      )}
                    </div>
                  </div>

                  {form.notes && (
                    <p className="text-[11px] text-slate-500 italic bg-amber-50/50 p-2 rounded-lg border border-amber-100">
                      "{form.notes}"
                    </p>
                  )}
                </div>

                {/* CARD FOOTER ACTIONS */}
                <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-1.5 text-xs font-bold">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEditModal(form)}
                      className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-all flex items-center gap-1 shadow-2xs font-extrabold"
                      title="Edit active formulation"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      Edit Rations
                    </button>

                    <button
                      onClick={() => setShowWorkOrderModal(form)}
                      className="p-1.5 bg-white hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 transition-colors"
                      title="Print / View Farm Mixing Sheet"
                    >
                      <Printer className="w-4 h-4 text-slate-600" />
                    </button>

                    <button
                      onClick={() => setShowSpecsModal(form)}
                      className="p-1.5 bg-white hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 transition-colors"
                      title="Inspect Nutrition Specs"
                    >
                      <Eye className="w-4 h-4 text-slate-600" />
                    </button>
                  </div>

                  <div className="flex items-center gap-1">
                    {onDuplicateFormulation && (
                      <button
                        onClick={() => {
                          setDuplicateNameModal(form);
                          setDuplicateCustomName(`${form.name} (Custom Variant)`);
                        }}
                        className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-200 rounded-lg transition-colors"
                        title="Duplicate recipe"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    )}

                    {!isActive && onSetPrimaryActive && (
                      <button
                        onClick={() => onSetPrimaryActive(form.id)}
                        className="px-2 py-1 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 rounded-lg text-[10px] font-black border border-emerald-200"
                        title="Make this the active formulation for this stage"
                      >
                        Set Active
                      </button>
                    )}

                    {onDeleteFormulation && (
                      <button
                        onClick={() => setShowConfirmDeleteModal(form)}
                        className="p-1.5 text-rose-400 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete formulation"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* TABLE VIEW */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200">
                <th className="py-3 px-4">Formulation Name</th>
                <th className="py-3 px-4">Species & Stage</th>
                <th className="py-3 px-4 text-right">Batch (kg)</th>
                <th className="py-3 px-4 text-right">Cost / kg</th>
                <th className="py-3 px-4 text-right">Cost / Head / Day</th>
                <th className="py-3 px-4 text-center">Protein (CP)</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredFormulations.map(form => {
                const spObj = animalTypes.find(a => a.id === form.animalTypeId);
                const spName = spObj?.name || form.animalTypeId;
                const stName = spObj?.stages.find(s => s.id === form.stageId)?.name || form.stageId;
                const calc = computeFormulationCosts(form.ingredients, ingredients, form.batchSize, form.dailyQtyPerAnimal);
                const isActive = form.status === "active";

                return (
                  <tr key={form.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4">
                      <span className="font-extrabold text-slate-900 block text-sm">{form.name}</span>
                      <span className="text-[11px] text-slate-500 font-mono">v{form.version} • {form.ingredients.length} items</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-bold text-slate-800">{spName}</span>
                      <span className="block text-[10px] text-slate-500 font-semibold capitalize">{stName}</span>
                    </td>
                    <td className="py-3 px-4 text-right font-black text-slate-900">
                      {form.batchSize} kg
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-slate-900 whitespace-nowrap">
                      {currencySymbol} {form.costPerKgMix.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-black text-emerald-700 whitespace-nowrap">
                      {currencySymbol} {form.costPerAnimalPerDay.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-center font-bold text-blue-800">
                      {calc.nutrients.crudeProteinPercent.toFixed(1)}%
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                        isActive ? "bg-emerald-100 text-emerald-800 border border-emerald-200" : "bg-slate-100 text-slate-600"
                      }`}>
                        {form.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenEditModal(form)}
                          className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs shadow-2xs flex items-center gap-1"
                        >
                          <Edit3 className="w-3.5 h-3.5" /> Edit
                        </button>
                        <button
                          onClick={() => setShowWorkOrderModal(form)}
                          className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg"
                          title="Mixing Sheet"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                        {onDeleteFormulation && (
                          <button
                            onClick={() => setShowConfirmDeleteModal(form)}
                            className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* 4. COMPREHENSIVE FORMULATION EDIT / CREATE MODAL */}
      {showEditModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full my-8 p-6 shadow-2xl border border-slate-200 space-y-6 max-h-[90vh] overflow-y-auto">
            {/* MODAL HEADER */}
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800">
                    {editingFormulationId ? "Edit Active Formulation" : "Create New Formulation"}
                  </span>
                  {editingFormulationId && (
                    <span className="text-xs font-mono font-bold text-slate-500">
                      ID: {editingFormulationId}
                    </span>
                  )}
                </div>
                <h3 className="text-xl font-black text-slate-900 mt-1 flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-emerald-600" />
                  {formName ? formName : "Configure Feed Formulation Rations"}
                </h3>
              </div>
              <button 
                onClick={() => setShowEditModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* FORM CONFIG CONTROLS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Animal Species</label>
                <select
                  value={selectedAnimalType}
                  onChange={e => {
                    setSelectedAnimalType(e.target.value);
                    const cfg = animalTypes.find(a => a.id === e.target.value);
                    if (cfg && cfg.stages.length > 0) setSelectedStage(cfg.stages[0].id);
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 bg-white"
                >
                  {animalTypes.map(a => (
                    <option key={a.id} value={a.id}>{a.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Growth Stage</label>
                <select
                  value={selectedStage}
                  onChange={e => setSelectedStage(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 bg-white"
                >
                  {currentAnimalConfig.stages.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block font-bold text-slate-700 mb-1">Formulation Name / Commercial Code</label>
                <input
                  type="text"
                  placeholder="e.g. Pig Grower High-Protein Mash (16% CP)"
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-extrabold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Batch Basis (kg)</label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    value={formBatchSize}
                    onChange={e => setFormBatchSize(parseFloat(e.target.value) || 100)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900 text-center"
                  />
                  <div className="flex gap-1">
                    {[100, 500].map(sz => (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => setFormBatchSize(sz)}
                        className={`px-2 py-2 text-[10px] font-bold rounded-lg border ${
                          formBatchSize === sz ? "bg-emerald-100 text-emerald-800 border-emerald-300" : "bg-slate-100 text-slate-600 border-slate-200"
                        }`}
                      >
                        {sz}kg
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Daily / Head Allowance (kg)</label>
                <input
                  type="number"
                  step="0.05"
                  value={formDailyQty}
                  onChange={e => setFormDailyQty(parseFloat(e.target.value) || 1.0)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900 text-center"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Status</label>
                <select
                  value={formStatus}
                  onChange={e => setFormStatus(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 bg-white"
                >
                  <option value="active">Active (Live in feed logs)</option>
                  <option value="inactive">Inactive</option>
                  <option value="draft">Draft</option>
                  <option value="archived">Archived</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Special Notes / Mix Guidance</label>
                <input
                  type="text"
                  placeholder="e.g. Pre-mix vitamins in 5kg maize first..."
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium text-slate-900"
                />
              </div>
            </div>

            {/* RECIPE INGREDIENTS TABLE */}
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-2">
                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                    <Wheat className="w-4 h-4 text-emerald-600" />
                    Recipe Mix Formulation Table
                  </h4>
                  <p className="text-slate-500 text-[11px]">
                    Configure exact ingredient inclusion weights per batch. Overrides update live recipe financials without mutating master catalogue.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleNormalizeRecipe}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition-colors flex items-center gap-1"
                    title={`Scale ingredients so total sum equals ${formBatchSize}kg`}
                  >
                    <Scale className="w-3.5 h-3.5" />
                    Auto-Scale to {formBatchSize}kg
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowQuickAddModal(true)}
                    className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-extrabold text-xs rounded-xl border border-emerald-200 flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> + New Ingredient
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAddRecipeRow()}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Row
                  </button>
                </div>
              </div>

              {formRecipeRows.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-300 text-slate-500 text-xs space-y-2">
                  <Layers className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="font-bold text-slate-700">No ingredients in this formulation recipe yet.</p>
                  <p className="text-slate-400">Click "+ Add Row" or "+ New Ingredient" to start formulating rations.</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                  {formRecipeRows.map((row, idx) => {
                    const lineTotal = row.inclusionQtyPerUnit * (row.costPerKgOverride ?? 0);
                    const masterIng = ingredients.find(i => i.id === row.ingredientId);
                    const bagSize = masterIng?.bagSizeKg || 50;
                    const bagsNeeded = (row.inclusionQtyPerUnit / (bagSize || 1)).toFixed(1);

                    return (
                      <div key={idx} className="flex flex-col sm:flex-row items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                        <div className="flex-1 w-full">
                          <label className="block font-semibold text-slate-500 text-[10px] uppercase">Ingredient</label>
                          <select
                            value={row.ingredientId}
                            onChange={e => handleUpdateRecipeRow(idx, "ingredientId", e.target.value)}
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-bold text-slate-900 bg-white"
                          >
                            {ingredients.map(ing => (
                              <option key={ing.id} value={ing.id}>{ing.name} ({currencySymbol} {ing.currentCostPerUnit}/{ing.unit})</option>
                            ))}
                            <option value="__ADD_NEW__">+ Add Custom Master Ingredient Inline...</option>
                          </select>
                        </div>

                        <div className="w-full sm:w-28">
                          <label className="block font-semibold text-slate-500 text-[10px] uppercase">Qty ({row.unit})</label>
                          <input
                            type="number"
                            step="0.1"
                            value={row.inclusionQtyPerUnit}
                            onChange={e => handleUpdateRecipeRow(idx, "inclusionQtyPerUnit", parseFloat(e.target.value) || 0)}
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-black text-slate-900 text-right"
                          />
                          <span className="block text-[10px] text-emerald-700 font-bold text-right mt-0.5">
                            ≈ {bagsNeeded} bags
                          </span>
                        </div>

                        <div className="w-full sm:w-32">
                          <label className="block font-semibold text-slate-500 text-[10px] uppercase">Cost/{row.unit} ({currencySymbol})</label>
                          <input
                            type="number"
                            step="0.01"
                            value={row.costPerKgOverride ?? 0}
                            onChange={e => handleUpdateRecipeRow(idx, "costPerKgOverride", parseFloat(e.target.value) || 0)}
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-bold text-slate-900 text-right"
                          />
                        </div>

                        <div className="w-full sm:w-28 text-right">
                          <span className="block text-[10px] font-bold text-slate-400 uppercase">Subtotal</span>
                          <span className="font-black text-slate-900 text-sm">{currencySymbol} {lineTotal.toFixed(2)}</span>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleRemoveRecipeRow(idx)}
                          className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                          title="Remove line"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* LIVE NUTRITIONAL & FINANCIAL SUMMARY */}
            <div className="bg-slate-900 text-white p-5 rounded-2xl space-y-4 shadow-inner">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-amber-400" />
                  <span className="font-extrabold text-sm text-white">Live Calculated Mix Specifications</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-bold bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700">
                  <span>Batch Weight:</span>
                  <span className={`font-black ${Math.abs(liveCalc.totalInclusionQty - formBatchSize) > 0.5 ? "text-amber-400" : "text-emerald-400"}`}>
                    {liveCalc.totalInclusionQty.toFixed(1)} / {formBatchSize} kg
                  </span>
                </div>
              </div>

              {/* KPIS */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                  <span className="block text-[10px] font-extrabold text-slate-400 uppercase">Cost / kg Mix</span>
                  <span className="text-lg font-black text-emerald-400">{currencySymbol} {liveCalc.costPerKgMix.toFixed(4)}</span>
                </div>

                <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                  <span className="block text-[10px] font-extrabold text-slate-400 uppercase">Cost / Head / Day</span>
                  <span className="text-lg font-black text-teal-300">{currencySymbol} {liveCalc.costPerAnimalPerDay.toFixed(2)}</span>
                </div>

                <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                  <span className="block text-[10px] font-extrabold text-slate-400 uppercase">Crude Protein</span>
                  <span className="text-lg font-black text-blue-300">{liveCalc.nutrients.crudeProteinPercent.toFixed(2)}%</span>
                </div>

                <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                  <span className="block text-[10px] font-extrabold text-slate-400 uppercase">Metabolizable Energy</span>
                  <span className="text-lg font-black text-amber-300">{liveCalc.nutrients.energyKcalPerKg.toLocaleString()} kcal/kg</span>
                </div>
              </div>

              {/* SAVE MODE SELECTION & ACTIONS */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2 border-t border-slate-800">
                {editingFormulationId ? (
                  <div className="flex items-center gap-3 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={saveAsVersionBump}
                        onChange={e => setSaveAsVersionBump(e.target.checked)}
                        className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                      />
                      <span className="font-bold text-slate-200">
                        Bump version number (v1 ➔ v2)
                      </span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={setAsPrimaryActiveOnSave}
                        onChange={e => setSetAsPrimaryActiveOnSave(e.target.checked)}
                        className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                      />
                      <span className="font-bold text-slate-200">
                        Set as primary active ration for this stage
                      </span>
                    </label>
                  </div>
                ) : (
                  <div className="text-xs text-slate-400 font-medium">
                    This formulation will immediately save and become active in tenant daily feed logs.
                  </div>
                )}

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => setShowEditModal(false)}
                    className="w-full sm:w-auto px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleSubmitFormulation}
                    className="w-full sm:w-auto px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    {editingFormulationId 
                      ? (saveAsVersionBump ? "Publish New Version" : "Save Active Updates (In-Place)")
                      : "Save & Activate Formulation"
                    }
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. WORK ORDER / FARM WORKER MIXING SHEET MODAL */}
      {showWorkOrderModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800">
                  Farm Work Order • Mixing Sheet
                </span>
                <h3 className="text-lg font-black text-slate-900 mt-1">
                  {showWorkOrderModal.name} (v{showWorkOrderModal.version})
                </h3>
                <p className="text-slate-500 text-xs">
                  Physical batch recipe instructions for farm mill operators and feed mixers.
                </p>
              </div>
              <button onClick={() => setShowWorkOrderModal(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* BATCH MULTIPLIER */}
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs font-bold">
              <span>Batch Multiplier / Target Quantity:</span>
              <div className="flex items-center gap-2">
                {[1, 2, 5, 10].map(mult => (
                  <button
                    key={mult}
                    onClick={() => setWorkOrderBatchMultiplier(mult)}
                    className={`px-2.5 py-1 rounded-lg border text-xs font-black ${
                      workOrderBatchMultiplier === mult ? "bg-emerald-600 text-white border-emerald-600" : "bg-white text-slate-700 border-slate-300"
                    }`}
                  >
                    {mult * showWorkOrderModal.batchSize} kg ({mult}x)
                  </button>
                ))}
              </div>
            </div>

            {/* RECIPE BAG & WEIGHT INSTRUCTIONS */}
            <div className="space-y-2">
              <h4 className="font-extrabold text-xs uppercase text-slate-700">Required Ingredients & Exact Weights</h4>
              <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-100 text-slate-600 font-bold border-b border-slate-200 text-[10px] uppercase">
                    <tr>
                      <th className="py-2.5 px-3">Step #</th>
                      <th className="py-2.5 px-3">Ingredient</th>
                      <th className="py-2.5 px-3 text-right">Target Weight</th>
                      <th className="py-2.5 px-3 text-right">Bag Count</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {showWorkOrderModal.ingredients.map((ing, i) => {
                      const master = ingredients.find(m => m.id === ing.ingredientId);
                      const targetKg = ing.inclusionQtyPerUnit * workOrderBatchMultiplier;
                      const bagSize = master?.bagSizeKg || 50;
                      const bags = (targetKg / bagSize).toFixed(1);

                      return (
                        <tr key={i} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono font-bold text-slate-400">0{i + 1}</td>
                          <td className="py-2 px-3 font-bold text-slate-900">{ing.ingredientName}</td>
                          <td className="py-2 px-3 text-right font-black text-slate-900">{targetKg.toFixed(1)} {ing.unit}</td>
                          <td className="py-2 px-3 text-right font-semibold text-emerald-800">≈ {bags} bags ({bagSize}kg)</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* MIXING PROTOCOL */}
            <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 space-y-2 text-xs text-amber-900">
              <h5 className="font-extrabold flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                Standard Operating Procedure (SOP) Mixing Order
              </h5>
              <ol className="list-decimal list-inside space-y-1 text-[11px] font-medium text-amber-800">
                <li>Weigh and deposit 50% of the bulk grain / energy meal into mixer first.</li>
                <li>Pre-mix micro-ingredients (Premix, Lysine, Salt, Minerals) with 5kg maize meal by hand before adding.</li>
                <li>Add protein meals (Soya cake, Fish meal, Sunflower).</li>
                <li>Add remaining grains and mix continuously for 12 to 15 minutes until uniform texture is achieved.</li>
              </ol>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setShowWorkOrderModal(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-200"
              >
                Close
              </button>
              <button
                onClick={() => {
                  window.print();
                  toast("Sent mixing work order to printer.", "success");
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" /> Print Mixing Sheet
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. NUTRITIONAL SPECS INSPECTOR MODAL */}
      {showSpecsModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-blue-100 text-blue-800">
                  Nutritional Spec Drill-Down
                </span>
                <h3 className="text-lg font-black text-slate-900 mt-1">{showSpecsModal.name}</h3>
                <p className="text-slate-500 text-xs">Full amino acid, crude fiber, and metabolizable energy distribution.</p>
              </div>
              <button onClick={() => setShowSpecsModal(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {(() => {
              const calc = computeFormulationCosts(showSpecsModal.ingredients, ingredients, showSpecsModal.batchSize, showSpecsModal.dailyQtyPerAnimal);
              return (
                <div className="space-y-4 text-xs">
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-blue-50 p-3 rounded-xl border border-blue-200 text-center">
                      <span className="block text-[10px] font-bold text-blue-700 uppercase">Crude Protein</span>
                      <span className="text-xl font-black text-blue-900">{calc.nutrients.crudeProteinPercent.toFixed(2)}%</span>
                      <span className="text-[10px] text-blue-600 block">{calc.nutrients.totalCrudeProteinKg.toFixed(2)} kg total</span>
                    </div>

                    <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-center">
                      <span className="block text-[10px] font-bold text-amber-700 uppercase">Crude Fiber</span>
                      <span className="text-xl font-black text-amber-900">{calc.nutrients.crudeFiberPercent.toFixed(2)}%</span>
                      <span className="text-[10px] text-amber-600 block">{calc.nutrients.totalCrudeFiberKg.toFixed(2)} kg total</span>
                    </div>

                    <div className="bg-teal-50 p-3 rounded-xl border border-teal-200 text-center">
                      <span className="block text-[10px] font-bold text-teal-700 uppercase">Metabolizable Energy</span>
                      <span className="text-xl font-black text-teal-900">{calc.nutrients.energyKcalPerKg.toLocaleString()}</span>
                      <span className="text-[10px] text-teal-600 block">kcal/kg ({calc.nutrients.energyMjPerKg.toFixed(2)} MJ/kg)</span>
                    </div>
                  </div>

                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <table className="w-full text-left">
                      <thead className="bg-slate-100 text-slate-600 font-bold border-b border-slate-200 text-[10px] uppercase">
                        <tr>
                          <th className="py-2.5 px-3">Ingredient</th>
                          <th className="py-2.5 px-3 text-right">Inclusion</th>
                          <th className="py-2.5 px-3 text-right">CP %</th>
                          <th className="py-2.5 px-3 text-right">CF %</th>
                          <th className="py-2.5 px-3 text-right">Energy (kcal/kg)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {calc.resolvedIngredients.map((item, i) => (
                          <tr key={i} className="hover:bg-slate-50">
                            <td className="py-2 px-3 font-bold text-slate-900">{item.ingredientName}</td>
                            <td className="py-2 px-3 text-right">{item.inclusionQtyPerUnit} {item.unit}</td>
                            <td className="py-2 px-3 text-right font-bold text-blue-700">{item.cpPct}%</td>
                            <td className="py-2 px-3 text-right font-bold text-amber-700">{item.cfPct}%</td>
                            <td className="py-2 px-3 text-right font-bold text-teal-700">{item.energyKcal.toLocaleString()}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })()}

            <div className="flex items-center justify-end pt-2 border-t border-slate-100">
              <button
                onClick={() => setShowSpecsModal(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7. PRESET LIBRARY MODAL */}
      {showPresetLibraryModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800">
                  Preset Formulation Library
                </span>
                <h3 className="text-lg font-black text-slate-900 mt-1">Calibrated African Livestock Rations</h3>
                <p className="text-slate-500 text-xs">
                  One-click load tested formulas tailored to regional ingredients (Maize, Soya, Sunflower, Wheat Bran, Fish Meal).
                </p>
              </div>
              <button onClick={() => setShowPresetLibraryModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {STARTER_FORMULATION_TEMPLATES.map((tmpl, idx) => (
                <div key={idx} className="p-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white hover:border-emerald-400 transition-all space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                      {tmpl.animalTypeId} • {tmpl.stageId}
                    </span>
                    <span className="text-[10px] text-slate-500 font-bold">{tmpl.batchSize}kg Batch</span>
                  </div>
                  <h4 className="font-extrabold text-slate-900 text-sm">{tmpl.name}</h4>
                  <p className="text-[11px] text-slate-500">
                    Includes {tmpl.ingredientRatios.length} ingredients with target {tmpl.dailyQtyPerAnimal}kg/head daily intake.
                  </p>
                  <button
                    onClick={() => handleLoadPreset(tmpl)}
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-lg shadow-2xs transition-colors flex items-center justify-center gap-1.5"
                  >
                    Load & Customize Ration <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end pt-2 border-t border-slate-100">
              <button
                onClick={() => setShowPresetLibraryModal(false)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. DUPLICATE CUSTOM NAME MODAL */}
      {duplicateNameModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
              <Copy className="w-5 h-5 text-emerald-600" />
              Duplicate Feed Formulation
            </h3>
            <p className="text-slate-500 text-xs">
              Create a clone of "{duplicateNameModal.name}" to test cost adjustments or create seasonal variants.
            </p>
            <div>
              <label className="block font-bold text-slate-700 text-xs mb-1">New Formulation Name</label>
              <input
                type="text"
                value={duplicateCustomName}
                onChange={e => setDuplicateCustomName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setDuplicateNameModal(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (onDuplicateFormulation) {
                    onDuplicateFormulation(duplicateNameModal.id, duplicateCustomName);
                  }
                  setDuplicateNameModal(null);
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow"
              >
                Duplicate Formulation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 9. CONFIRM DELETE MODAL */}
      {showConfirmDeleteModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2 bg-rose-100 rounded-xl">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-slate-900 text-base">Delete Feed Formulation?</h3>
                <span className="text-xs font-medium text-slate-500">{showConfirmDeleteModal.name}</span>
              </div>
            </div>
            <p className="text-slate-600 text-xs">
              Are you sure you want to remove this formulation from your active tenant catalog? Historical daily feed logs will maintain their frozen snapshot.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowConfirmDeleteModal(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (onDeleteFormulation) {
                    onDeleteFormulation(showConfirmDeleteModal.id);
                  }
                  setShowConfirmDeleteModal(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl shadow"
              >
                Yes, Delete Formulation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 10. QUICK ADD INGREDIENT MODAL */}
      {showQuickAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-600" /> Quick-Add Feed Ingredient
              </h3>
              <button onClick={() => setShowQuickAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleQuickAddIngredientSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Ingredient Name</label>
                <input
                  type="text"
                  placeholder="e.g. Wheat Bran / Rice Polish / Dicalcium Phosphate"
                  value={quickIngName}
                  onChange={e => setQuickIngName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-extrabold text-slate-900"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Category</label>
                  <select
                    value={quickIngCategory}
                    onChange={e => setQuickIngCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 bg-white"
                  >
                    <option value="energy">Energy Source</option>
                    <option value="protein">Protein Supplement</option>
                    <option value="mineral">Mineral / Calc</option>
                    <option value="vitamin">Vitamin / Premix</option>
                    <option value="additive">Additive / Molasses</option>
                    <option value="roughage">Roughage / Hay</option>
                    <option value="complete-feed">Complete Feed (Bought-in / Farm Feed)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Unit of Measure</label>
                  <select
                    value={quickIngUnit}
                    onChange={e => setQuickIngUnit(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 bg-white"
                  >
                    <option value="kg">Kilogram (kg)</option>
                    <option value="g">Gram (g)</option>
                    <option value="litre">Litre (L)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Cost Per {quickIngUnit} ({currencySymbol})</label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={quickIngCost}
                  onChange={e => setQuickIngCost(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900 text-sm"
                  required
                />
              </div>

              {/* NUTRITIONAL VALUES */}
              <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <div>
                  <label className="block font-bold text-slate-700 mb-1 text-[10px]">Crude Protein %</label>
                  <input
                    type="number"
                    step="0.1"
                    placeholder="e.g. 16.5"
                    value={quickIngCP || ""}
                    onChange={e => setQuickIngCP(parseFloat(e.target.value) || 0)}
                    className="w-full px-2 py-1.5 rounded-lg border border-slate-300 font-bold text-slate-900 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1 text-[10px]">Crude Fiber %</label>
                  <input
                    type="number"
                    step="0.1"
                    placeholder="e.g. 5.0"
                    value={quickIngCF || ""}
                    onChange={e => setQuickIngCF(parseFloat(e.target.value) || 0)}
                    className="w-full px-2 py-1.5 rounded-lg border border-slate-300 font-bold text-slate-900 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1 text-[10px]">Energy (kcal/kg)</label>
                  <input
                    type="number"
                    step="10"
                    placeholder="e.g. 3200"
                    value={quickIngEnergy || ""}
                    onChange={e => setQuickIngEnergy(parseFloat(e.target.value) || 0)}
                    className="w-full px-2 py-1.5 rounded-lg border border-slate-300 font-bold text-slate-900 text-xs"
                  />
                </div>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-800 font-semibold">
                This ingredient will immediately save to tenant `feedIngredients` and become available across all formulations.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowQuickAddModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow"
                >
                  Save Ingredient
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

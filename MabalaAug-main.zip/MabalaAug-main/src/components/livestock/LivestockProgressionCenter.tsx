import React, { useState, useMemo, useEffect } from "react";
import { 
  TrendingUp, 
  Scale, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  Play, 
  Layers, 
  History, 
  Plus, 
  Edit2, 
  Trash2, 
  Download, 
  RefreshCw, 
  ArrowRight, 
  Filter, 
  Search, 
  Sliders, 
  DollarSign, 
  FileText, 
  Lock, 
  Unlock, 
  Info, 
  AlertCircle,
  CheckSquare,
  Sparkles,
  ChevronRight,
  Printer
} from "lucide-react";
import { jsPDF } from "jspdf";
import { 
  LivestockRecord, 
  LivestockStageTemplate, 
  LivestockStage, 
  LivestockWeightRecord, 
  StageTransitionRecord, 
  BiologicalValuationRecord, 
  LivestockAccountingEvent, 
  ProgressionEligibilityResult,
  StageTransitionMode
} from "../../types";
import { 
  getTenantStageTemplates, 
  saveOrUpdateStageTemplate, 
  evaluateAnimalProgression, 
  executeStageTransition, 
  recordIndividualWeight, 
  recordPenWeight, 
  getTenantWeightRecords, 
  getTenantStageTransitions, 
  getTenantValuationRecords, 
  getTenantAccountingEvents, 
  manualStageOverride, 
  setAnimalProgressionHold, 
  reconcileBiologicalAssets,
  getTemplateForSpecies,
  DEFAULT_WEIGHT_ATTRIBUTION_VALIDITY_DAYS
} from "../../services/livestockProgressionService";
import { getTenantPens } from "../../services/feedEngineService";

interface ProgressionCenterProps {
  tenantId?: string;
  records: LivestockRecord[];
  currencySymbol?: string;
  onUpdateRecord?: (record: LivestockRecord) => void;
  onUpdateMultipleRecords?: (records: LivestockRecord[]) => void;
  onShowToast?: (msg: string, type: "success" | "error" | "info") => void;
}

export default function LivestockProgressionCenter({
  tenantId = "default",
  records,
  currencySymbol = "K",
  onUpdateRecord,
  onUpdateMultipleRecords,
  onShowToast
}: ProgressionCenterProps) {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<"due" | "weight" | "register" | "tracker" | "accounting" | "config" | "reports">("due");

  // State for templates
  const [templates, setTemplates] = useState<LivestockStageTemplate[]>(() => getTenantStageTemplates(tenantId));
  const [selectedSpecies, setSelectedSpecies] = useState<string>("Pigs");

  // Data history state
  const [weightRecords, setWeightRecords] = useState<LivestockWeightRecord[]>(() => getTenantWeightRecords(tenantId));
  const [transitions, setTransitions] = useState<StageTransitionRecord[]>(() => getTenantStageTransitions(tenantId));
  const [valuations, setValuations] = useState<BiologicalValuationRecord[]>(() => getTenantValuationRecords(tenantId));
  const [accountingEvents, setAccountingEvents] = useState<LivestockAccountingEvent[]>(() => getTenantAccountingEvents(tenantId));

  // Pens
  const pens = useMemo(() => getTenantPens(tenantId), [tenantId]);

  // Search and Filters
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");

  // Modals
  const [selectedAnimalForTransition, setSelectedAnimalForTransition] = useState<{
    animal: LivestockRecord;
    result: ProgressionEligibilityResult;
  } | null>(null);

  const [overrideModalAnimal, setOverrideModalAnimal] = useState<LivestockRecord | null>(null);
  const [overrideTargetStageId, setOverrideTargetStageId] = useState("");
  const [overrideReason, setOverrideReason] = useState("");
  const [overrideNotes, setOverrideNotes] = useState("");

  const [holdModalAnimal, setHoldModalAnimal] = useState<LivestockRecord | null>(null);
  const [holdReason, setHoldReason] = useState("Veterinary Assessment");

  // Weight Form States
  const [individualWeightTag, setIndividualWeightTag] = useState("");
  const [individualWeightKg, setIndividualWeightKg] = useState<number | "">("");
  const [individualWeightNotes, setIndividualWeightNotes] = useState("");

  const [penWeightPenId, setPenWeightPenId] = useState("");
  const [penAverageWeightKg, setPenAverageWeightKg] = useState<number | "">("");
  const [penWeightHeadCount, setPenWeightHeadCount] = useState<number | "">("");

  // Template Editing State
  const [editingTemplate, setEditingTemplate] = useState<LivestockStageTemplate | null>(null);
  const [editingStage, setEditingStage] = useState<LivestockStage | null>(null);
  const [isNewTemplateModalOpen, setIsNewTemplateModalOpen] = useState(false);
  const [newTemplateSpecies, setNewTemplateSpecies] = useState("Pigs");
  const [newTemplateName, setNewTemplateName] = useState("");

  // Refresh helper
  const refreshAllData = () => {
    setTemplates(getTenantStageTemplates(tenantId));
    setWeightRecords(getTenantWeightRecords(tenantId));
    setTransitions(getTenantStageTransitions(tenantId));
    setValuations(getTenantValuationRecords(tenantId));
    setAccountingEvents(getTenantAccountingEvents(tenantId));
  };

  useEffect(() => {
    refreshAllData();
  }, [tenantId]);

  // Active animals list
  const activeAnimals = useMemo(() => {
    return records.filter(r => r.status === "Active");
  }, [records]);

  // Current active template for selected species
  const activeTemplate = useMemo(() => {
    return getTemplateForSpecies(tenantId, selectedSpecies);
  }, [tenantId, selectedSpecies, templates]);

  // Evaluate all active animals
  const animalEvaluations = useMemo(() => {
    return activeAnimals.map(animal => {
      const tpl = getTemplateForSpecies(tenantId, animal.species || animal.type || "Pigs");
      const evalResult = evaluateAnimalProgression(tenantId, animal, tpl);
      return {
        animal,
        result: evalResult
      };
    });
  }, [activeAnimals, tenantId, templates, weightRecords]);

  // Counts for Badges
  const eligibleCount = useMemo(() => {
    return animalEvaluations.filter(e => e.result.eligible && !e.result.isHeld).length;
  }, [animalEvaluations]);

  const heldCount = useMemo(() => {
    return animalEvaluations.filter(e => e.result.isHeld).length;
  }, [animalEvaluations]);

  const underweightCount = useMemo(() => {
    return animalEvaluations.filter(e => e.result.isUnderweight).length;
  }, [animalEvaluations]);

  const staleWeightCount = useMemo(() => {
    return animalEvaluations.filter(e => e.result.isWeightStale).length;
  }, [animalEvaluations]);

  // Filtered evaluation rows
  const filteredEvaluations = useMemo(() => {
    return animalEvaluations.filter(({ animal, result }) => {
      const q = searchQuery.toLowerCase().trim();
      const matchQuery = 
        !q || 
        (animal.tagId && animal.tagId.toLowerCase().includes(q)) ||
        (animal.name && animal.name.toLowerCase().includes(q)) ||
        (animal.species && animal.species.toLowerCase().includes(q)) ||
        (animal.breed && animal.breed.toLowerCase().includes(q)) ||
        (animal.currentStageName && animal.currentStageName.toLowerCase().includes(q)) ||
        (animal.penName && animal.penName.toLowerCase().includes(q));

      if (!matchQuery) return false;

      if (statusFilter === "READY") return result.eligible && !result.isHeld;
      if (statusFilter === "ON_TRACK") return !result.eligible && !result.isHeld && !result.isFinalStage;
      if (statusFilter === "HELD") return result.isHeld;
      if (statusFilter === "UNDERWEIGHT") return result.isUnderweight;
      if (statusFilter === "STALE") return result.isWeightStale;
      if (statusFilter === "FINAL") return result.isFinalStage;

      return true;
    });
  }, [animalEvaluations, searchQuery, statusFilter]);

  // Reconciliation data
  const reconciliation = useMemo(() => {
    return reconcileBiologicalAssets(tenantId, records);
  }, [tenantId, records, valuations, accountingEvents]);

  // --------------------------------------------------------------------------
  // ACTIONS
  // --------------------------------------------------------------------------

  // 1. Single Progression
  const handleConfirmSingleTransition = () => {
    if (!selectedAnimalForTransition) return;
    const { animal, result } = selectedAnimalForTransition;
    const tpl = getTemplateForSpecies(tenantId, animal.species || animal.type || "Pigs");
    if (!tpl || !result.nextStageId) return;

    const nextStage = tpl.stages.find(s => s.id === result.nextStageId);
    if (!nextStage) return;

    const transitionRes = executeStageTransition(
      tenantId,
      animal,
      nextStage,
      result.trigger === "NONE" ? "MANUAL" : result.trigger,
      {
        authoritativeWeight: result.currentWeight,
        targetWeight: result.targetWeight,
        daysInStage: result.daysInStage,
        targetDurationDays: result.targetDays,
        configVersion: tpl.version
      }
    );

    if (onUpdateRecord) {
      onUpdateRecord(transitionRes.updatedAnimal);
    }

    refreshAllData();
    setSelectedAnimalForTransition(null);
    onShowToast?.(
      `✓ ${animal.tagId || animal.name} moved to ${nextStage.name} (${currencySymbol}${nextStage.valuation.toLocaleString()}). GL Revaluation Entry posted!`,
      "success"
    );
  };

  // 2. Batch Progress All Eligible
  const handleProgressAllEligible = () => {
    const readyToProgress = animalEvaluations.filter(e => e.result.eligible && !e.result.isHeld);
    if (readyToProgress.length === 0) {
      onShowToast?.("No animals currently qualify for progression.", "info");
      return;
    }

    if (!confirm(`Are you sure you want to progress all ${readyToProgress.length} qualified animals to their next biological stages? This will automatically adjust their valuations and post accounting revaluation entries.`)) {
      return;
    }

    const updatedAnimals: LivestockRecord[] = [];
    let totalGain = 0;

    readyToProgress.forEach(({ animal, result }) => {
      const tpl = getTemplateForSpecies(tenantId, animal.species || animal.type || "Pigs");
      if (!tpl || !result.nextStageId) return;
      const nextStage = tpl.stages.find(s => s.id === result.nextStageId);
      if (!nextStage) return;

      const delta = nextStage.valuation - (animal.currentValue || 0);
      totalGain += delta;

      const res = executeStageTransition(
        tenantId,
        animal,
        nextStage,
        result.trigger === "NONE" ? "MANUAL" : result.trigger,
        {
          authoritativeWeight: result.currentWeight,
          targetWeight: result.targetWeight,
          daysInStage: result.daysInStage,
          targetDurationDays: result.targetDays,
          configVersion: tpl.version
        }
      );
      updatedAnimals.push(res.updatedAnimal);
    });

    if (onUpdateMultipleRecords && updatedAnimals.length > 0) {
      onUpdateMultipleRecords(updatedAnimals);
    } else if (onUpdateRecord) {
      updatedAnimals.forEach(a => onUpdateRecord(a));
    }

    refreshAllData();
    onShowToast?.(
      `✓ Successfully progressed ${updatedAnimals.length} animals! Net biological valuation adjustment: ${currencySymbol}${totalGain.toLocaleString()}.`,
      "success"
    );
  };

  // 3. Individual Weight Capture
  const handleSaveIndividualWeight = (e: React.FormEvent) => {
    e.preventDefault();
    if (!individualWeightTag.trim()) {
      onShowToast?.("Please select or enter an animal Tag ID.", "error");
      return;
    }
    const numWeight = Number(individualWeightKg);
    if (isNaN(numWeight) || numWeight <= 0) {
      onShowToast?.("Please enter a valid weight in kilograms (> 0).", "error");
      return;
    }

    const animal = activeAnimals.find(
      a => (a.tagId && a.tagId.toLowerCase() === individualWeightTag.trim().toLowerCase()) || a.id === individualWeightTag.trim()
    );

    if (!animal) {
      onShowToast?.(`Animal with Tag ID '${individualWeightTag}' not found in active registry.`, "error");
      return;
    }

    const { updatedAnimal } = recordIndividualWeight(tenantId, animal, numWeight, {
      notes: individualWeightNotes.trim()
    });

    if (onUpdateRecord) {
      onUpdateRecord(updatedAnimal);
    }

    setIndividualWeightKg("");
    setIndividualWeightNotes("");
    refreshAllData();
    onShowToast?.(
      `✓ Recorded authoritative weight of ${numWeight} kg for ${animal.tagId || animal.name}. Pen averages superseded.`,
      "success"
    );
  };

  // 4. Pen Average Weight Capture
  const handleSavePenWeight = (e: React.FormEvent) => {
    e.preventDefault();
    if (!penWeightPenId) {
      onShowToast?.("Please select a Pen.", "error");
      return;
    }
    const numWeight = Number(penAverageWeightKg);
    if (isNaN(numWeight) || numWeight <= 0) {
      onShowToast?.("Please enter a valid pen average weight (> 0).", "error");
      return;
    }

    const selectedPen = pens.find(p => p.id === penWeightPenId);
    const penName = selectedPen?.name || penWeightPenId;
    const headcount = Number(penWeightHeadCount) || selectedPen?.headcount || 1;

    const { updatedAnimals, attributedCount } = recordPenWeight(
      tenantId,
      penWeightPenId,
      penName,
      numWeight,
      headcount,
      records
    );

    if (onUpdateMultipleRecords && updatedAnimals.length > 0) {
      onUpdateMultipleRecords(updatedAnimals);
    } else if (onUpdateRecord) {
      updatedAnimals.forEach(a => onUpdateRecord(a));
    }

    setPenAverageWeightKg("");
    setPenWeightHeadCount("");
    refreshAllData();
    onShowToast?.(
      `✓ Recorded pen average of ${numWeight} kg for ${penName}. Attributed to ${attributedCount} animals (individual measurements preserved).`,
      "success"
    );
  };

  // 5. Manual Stage Override
  const handleConfirmManualOverride = () => {
    if (!overrideModalAnimal || !overrideTargetStageId) return;
    if (!overrideReason.trim()) {
      onShowToast?.("A formal reason is required for manual stage override.", "error");
      return;
    }

    const tpl = getTemplateForSpecies(tenantId, overrideModalAnimal.species || overrideModalAnimal.type || "Pigs");
    if (!tpl) return;
    const targetStage = tpl.stages.find(s => s.id === overrideTargetStageId);
    if (!targetStage) return;

    const res = manualStageOverride(
      tenantId,
      overrideModalAnimal,
      targetStage,
      overrideReason.trim(),
      overrideNotes.trim(),
      "Livestock Manager"
    );

    if (onUpdateRecord) {
      onUpdateRecord(res.updatedAnimal);
    }

    refreshAllData();
    setOverrideModalAnimal(null);
    setOverrideReason("");
    setOverrideNotes("");
    onShowToast?.(
      `✓ Manual override completed: ${overrideModalAnimal.tagId || overrideModalAnimal.name} moved to ${targetStage.name}. Accounting adjustment posted.`,
      "success"
    );
  };

  // 6. Progression Hold Toggle
  const handleToggleHold = (animal: LivestockRecord) => {
    if (animal.progressionHold) {
      // Release hold
      const updated = setAnimalProgressionHold(animal, false);
      if (onUpdateRecord) onUpdateRecord(updated);
      refreshAllData();
      onShowToast?.(`✓ Progression hold released for ${animal.tagId || animal.name}. Animal re-evaluated.`, "info");
    } else {
      // Open hold modal
      setHoldModalAnimal(animal);
    }
  };

  const handleConfirmHold = () => {
    if (!holdModalAnimal) return;
    const updated = setAnimalProgressionHold(holdModalAnimal, true, holdReason);
    if (onUpdateRecord) onUpdateRecord(updated);
    refreshAllData();
    setHoldModalAnimal(null);
    onShowToast?.(`⚠ Placed ${holdModalAnimal.tagId || holdModalAnimal.name} on progression hold (${holdReason}).`, "info");
  };

  // Export PDF Report
  const exportPDFReport = (reportType: "valuation" | "movement" | "underperformance") => {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text("Mabala Farm Management - Biological Asset Report", 14, 20);
    doc.setFontSize(10);
    doc.text(`Tenant: ${tenantId} | Date: ${new Date().toISOString().split("T")[0]}`, 14, 28);

    if (reportType === "valuation") {
      doc.text("LIVESTOCK BIOLOGICAL ASSET REGISTER & VALUATIONS", 14, 38);
      let y = 46;
      doc.setFontSize(9);
      doc.text("Tag ID | Species | Stage | Weight | Source | Valuation", 14, y);
      y += 6;
      activeAnimals.slice(0, 35).forEach(a => {
        doc.text(
          `${a.tagId || a.id} | ${a.species || a.type} | ${a.currentStageName || "Init"} | ${a.currentWeight || 0}kg | ${a.currentWeightSource || "Reg"} | ${currencySymbol}${(a.currentValue || 0).toLocaleString()}`,
          14,
          y
        );
        y += 5;
      });
    } else if (reportType === "underperformance") {
      doc.text("UNDERPERFORMANCE & UNDERWEIGHT EXCEPTION REPORT (§24)", 14, 38);
      let y = 46;
      doc.setFontSize(9);
      const underperformers = animalEvaluations.filter(e => e.result.isUnderweight);
      doc.text(`Total Underweight Animals: ${underperformers.length}`, 14, y);
      y += 8;
      underperformers.forEach(u => {
        doc.text(
          `${u.animal.tagId || u.animal.id} - ${u.animal.currentStageName} -> Target: ${u.result.targetWeight}kg, Actual: ${u.result.currentWeight}kg (Variance: ${u.result.weightVariancePct}%)`,
          14,
          y
        );
        y += 5;
      });
    }

    doc.save(`mabala_${reportType}_report_${new Date().toISOString().split("T")[0]}.pdf`);
    onShowToast?.(`Exported ${reportType} report to PDF successfully`, "success");
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2.5 bg-emerald-100 text-emerald-800 rounded-xl">
              <TrendingUp className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-xl font-black text-slate-900 tracking-tight">
                Automated Livestock Valuation & Stage Progression System
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Biological lifecycle growth stages, authoritative weight attribution, automatic valuation adjustments, and General Ledger integration (§1-§62).
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => handleProgressAllEligible()}
            disabled={eligibleCount === 0}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs ${
              eligibleCount > 0
                ? "bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer"
                : "bg-slate-100 text-slate-400 cursor-not-allowed border"
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            Auto-Progress Eligible ({eligibleCount})
          </button>

          <button
            onClick={() => refreshAllData()}
            className="p-2 border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl transition-all cursor-pointer"
            title="Refresh Progression State"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPI Metric Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Total Biological Assets
            </span>
            <span className="p-1.5 bg-emerald-50 text-emerald-700 rounded-lg">
              <DollarSign className="w-4 h-4" />
            </span>
          </div>
          <p className="text-2xl font-black text-slate-900 font-mono mt-1">
            {currencySymbol}{reconciliation.animalRegistryTotalValue.toLocaleString()}
          </p>
          <p className="text-[10.5px] text-emerald-700 font-medium mt-1">
            {activeAnimals.length} active animals recognized
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Ready for Progression
            </span>
            <span className="p-1.5 bg-blue-50 text-blue-700 rounded-lg">
              <Play className="w-4 h-4" />
            </span>
          </div>
          <p className="text-2xl font-black text-blue-900 font-mono mt-1">
            {eligibleCount}
          </p>
          <p className="text-[10.5px] text-blue-700 font-medium mt-1">
            Weight or time thresholds met
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Underweight Alerts
            </span>
            <span className="p-1.5 bg-amber-50 text-amber-700 rounded-lg">
              <AlertTriangle className="w-4 h-4" />
            </span>
          </div>
          <p className="text-2xl font-black text-amber-900 font-mono mt-1">
            {underweightCount}
          </p>
          <p className="text-[10.5px] text-amber-700 font-medium mt-1">
            Below target weight threshold
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Progression Holds
            </span>
            <span className="p-1.5 bg-purple-50 text-purple-700 rounded-lg">
              <Lock className="w-4 h-4" />
            </span>
          </div>
          <p className="text-2xl font-black text-purple-900 font-mono mt-1">
            {heldCount}
          </p>
          <p className="text-[10.5px] text-purple-700 font-medium mt-1">
            Veterinary / quarantine holds
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Stale Weight Data
            </span>
            <span className="p-1.5 bg-rose-50 text-rose-700 rounded-lg">
              <Scale className="w-4 h-4" />
            </span>
          </div>
          <p className="text-2xl font-black text-rose-900 font-mono mt-1">
            {staleWeightCount}
          </p>
          <p className="text-[10.5px] text-rose-700 font-medium mt-1">
            Estimates &gt; {DEFAULT_WEIGHT_ATTRIBUTION_VALIDITY_DAYS} days old
          </p>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex border-b border-slate-200 overflow-x-auto gap-2 text-xs font-bold">
        <button
          onClick={() => setActiveTab("due")}
          className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "due"
              ? "border-emerald-600 text-emerald-700"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <Play className="w-3.5 h-3.5" /> Due for Progression
          {eligibleCount > 0 && (
            <span className="px-1.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800">
              {eligibleCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab("weight")}
          className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "weight"
              ? "border-emerald-600 text-emerald-700"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <Scale className="w-3.5 h-3.5" /> Weight Capture Hub
        </button>

        <button
          onClick={() => setActiveTab("register")}
          className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "register"
              ? "border-emerald-600 text-emerald-700"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <Layers className="w-3.5 h-3.5" /> Biological Asset Register
        </button>

        <button
          onClick={() => setActiveTab("tracker")}
          className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "tracker"
              ? "border-emerald-600 text-emerald-700"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <History className="w-3.5 h-3.5" /> Valuation Tracker
        </button>

        <button
          onClick={() => setActiveTab("accounting")}
          className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "accounting"
              ? "border-emerald-600 text-emerald-700"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" /> GL Reconciliation & Postings
        </button>

        <button
          onClick={() => setActiveTab("config")}
          className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "config"
              ? "border-emerald-600 text-emerald-700"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <Sliders className="w-3.5 h-3.5" /> Growth Stage Templates
        </button>

        <button
          onClick={() => setActiveTab("reports")}
          className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "reports"
              ? "border-emerald-600 text-emerald-700"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <FileText className="w-3.5 h-3.5" /> Audit & Reports
        </button>
      </div>

      {/* =================================================================== */}
      {/* TAB 1: DUE FOR PROGRESSION (§44) */}
      {/* =================================================================== */}
      {activeTab === "due" && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
            <div className="relative w-full sm:w-72">
              <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                placeholder="Search tag, species, stage, pen..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1.5 text-xs font-medium">
              <span className="text-slate-400 font-bold mr-1 flex items-center gap-1">
                <Filter className="w-3 h-3" /> Status:
              </span>
              {[
                { id: "ALL", label: "All" },
                { id: "READY", label: `Ready (${eligibleCount})` },
                { id: "ON_TRACK", label: "On Track" },
                { id: "UNDERWEIGHT", label: `Underweight (${underweightCount})` },
                { id: "HELD", label: `Held (${heldCount})` },
                { id: "STALE", label: `Stale (${staleWeightCount})` }
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setStatusFilter(f.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs transition-all cursor-pointer ${
                    statusFilter === f.id
                      ? "bg-slate-900 text-white font-bold"
                      : "bg-slate-100 hover:bg-slate-200 text-slate-600"
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Operational Progression Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                    <th className="py-3 px-4">Animal / Tag</th>
                    <th className="py-3 px-3">Species</th>
                    <th className="py-3 px-3">Current Stage</th>
                    <th className="py-3 px-3">Weight (kg)</th>
                    <th className="py-3 px-3">Target Weight</th>
                    <th className="py-3 px-3">Days in Stage</th>
                    <th className="py-3 px-3">Status & Eligibility</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredEvaluations.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-400 font-medium">
                        No livestock matching the selected criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredEvaluations.map(({ animal, result }) => {
                      const isReady = result.eligible && !result.isHeld;
                      return (
                        <tr
                          key={animal.id}
                          className={`hover:bg-slate-50/80 transition-colors ${
                            isReady ? "bg-emerald-50/20" : ""
                          }`}
                        >
                          <td className="py-3 px-4 font-bold text-slate-900">
                            <div className="flex items-center gap-2">
                              <span>{animal.tagId || animal.name || animal.id}</span>
                              {animal.penName && (
                                <span className="text-[10px] text-slate-400 font-mono">
                                  ({animal.penName})
                                </span>
                              )}
                            </div>
                            <span className="text-[10.5px] font-mono text-emerald-700">
                              {currencySymbol}{(animal.currentValue || 0).toLocaleString()}
                            </span>
                          </td>

                          <td className="py-3 px-3 font-medium text-slate-700">
                            {animal.species || animal.type}
                          </td>

                          <td className="py-3 px-3">
                            <span className="px-2 py-0.5 rounded-md bg-slate-100 font-bold text-slate-800 text-[11px]">
                              {result.currentStageName || "Initial Stage"}
                            </span>
                            {result.nextStageName && (
                              <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                                <ArrowRight className="w-2.5 h-2.5" /> Next: {result.nextStageName}
                              </div>
                            )}
                          </td>

                          <td className="py-3 px-3 font-mono">
                            <div className="flex items-center gap-1">
                              <span className="font-bold text-slate-900">
                                {result.currentWeight || 0} kg
                              </span>
                              {result.isWeightStale && (
                                <span title="Stale weight estimate (>7 days)">
                                  <AlertTriangle className="w-3 h-3 text-amber-500" />
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400 block capitalize">
                              {result.weightSource?.toLowerCase().replace("_", " ") || "baseline"}
                            </span>
                          </td>

                          <td className="py-3 px-3 font-mono text-slate-600">
                            {result.targetWeight ? `${result.targetWeight} kg` : "—"}
                          </td>

                          <td className="py-3 px-3 font-mono">
                            <span className="font-bold text-slate-800">
                              {result.daysInStage}d
                            </span>
                            {result.targetDays > 0 && (
                              <span className="text-slate-400 text-[10px] block">
                                / {result.targetDays}d target
                              </span>
                            )}
                          </td>

                          <td className="py-3 px-3">
                            {result.isHeld ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-purple-100 text-purple-800">
                                <Lock className="w-3 h-3" /> Held: {result.holdReason}
                              </span>
                            ) : isReady ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-emerald-100 text-emerald-800 animate-pulse">
                                <CheckCircle2 className="w-3 h-3" /> Ready ({result.trigger})
                              </span>
                            ) : result.isUnderweight ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-amber-100 text-amber-800">
                                <AlertTriangle className="w-3 h-3" /> Underweight ({result.weightVariancePct}%)
                              </span>
                            ) : result.isFinalStage ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-slate-100 text-slate-600">
                                Final Stage
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-medium bg-slate-100 text-slate-600">
                                <Clock className="w-3 h-3" /> On Track
                              </span>
                            )}
                          </td>

                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {isReady && (
                                <button
                                  onClick={() => setSelectedAnimalForTransition({ animal, result })}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1"
                                >
                                  Progress <ArrowRight className="w-3 h-3" />
                                </button>
                              )}

                              <button
                                onClick={() => handleToggleHold(animal)}
                                title={animal.progressionHold ? "Release Hold" : "Place on Hold"}
                                className={`p-1.5 rounded-lg border text-xs transition-all cursor-pointer ${
                                  animal.progressionHold
                                    ? "bg-purple-100 border-purple-200 text-purple-800 hover:bg-purple-200"
                                    : "border-slate-200 text-slate-500 hover:bg-slate-100"
                                }`}
                              >
                                {animal.progressionHold ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                              </button>

                              <button
                                onClick={() => {
                                  setOverrideModalAnimal(animal);
                                  setOverrideTargetStageId(result.nextStageId || "");
                                }}
                                title="Manual Stage Override"
                                className="p-1.5 border border-slate-200 text-slate-500 hover:bg-slate-100 rounded-lg text-xs transition-all cursor-pointer"
                              >
                                <Sliders className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 2: WEIGHT CAPTURE HUB (DUAL PEN & INDIVIDUAL) (§11 - §17) */}
      {/* =================================================================== */}
      {activeTab === "weight" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Pen-Level Weight Form (§12) */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-blue-100 text-blue-800 rounded-xl">
                  <Layers className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">
                    Pen-Level Weight Capture (§12)
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Record average pen weight. Automatically attributed as estimated weight across active animals without overwriting individual records.
                  </p>
                </div>
              </div>

              <form onSubmit={handleSavePenWeight} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Select Pen</label>
                  <select
                    value={penWeightPenId}
                    onChange={e => {
                      setPenWeightPenId(e.target.value);
                      const pen = pens.find(p => p.id === e.target.value);
                      if (pen) setPenWeightHeadCount(pen.headcount || 1);
                    }}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white focus:ring-1 focus:ring-blue-500"
                    required
                  >
                    <option value="">-- Choose Pen / Cohort --</option>
                    {pens.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.headcount || 0} head - {p.species})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Average Weight (kg)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      placeholder="e.g. 25.4"
                      value={penAverageWeightKg}
                      onChange={e => setPenAverageWeightKg(e.target.value ? Number(e.target.value) : "")}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-1 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Head Count
                    </label>
                    <input
                      type="number"
                      placeholder="Head count"
                      value={penWeightHeadCount}
                      onChange={e => setPenWeightHeadCount(e.target.value ? Number(e.target.value) : "")}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-100 text-[11px] text-blue-900 leading-relaxed">
                  <strong>Attribution Rule (§14, §15):</strong> Valid for {DEFAULT_WEIGHT_ATTRIBUTION_VALIDITY_DAYS} days. Does not overwrite animals that possess a newer authoritative individual weight measurement.
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer"
                >
                  Record Pen Average & Attribute Weights
                </button>
              </form>
            </div>

            {/* Individual Animal Weight Form (§13) */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                  <Scale className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">
                    Individual Animal Scale Measurement (§13)
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Record exact scale measurement for a specific animal. Authoritative measurement supersedes pen-average attributions.
                  </p>
                </div>
              </div>

              <form onSubmit={handleSaveIndividualWeight} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Animal Tag ID or Name
                  </label>
                  <input
                    type="text"
                    placeholder="Search or enter Tag ID (e.g. PIG-00124)"
                    value={individualWeightTag}
                    onChange={e => setIndividualWeightTag(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-1 focus:ring-emerald-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Authoritative Weight (kg)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    placeholder="e.g. 28.4"
                    value={individualWeightKg}
                    onChange={e => setIndividualWeightKg(e.target.value ? Number(e.target.value) : "")}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-1 focus:ring-emerald-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Scale Notes / Equipment
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Digital platform scale, calibrated AM"
                    value={individualWeightNotes}
                    onChange={e => setIndividualWeightNotes(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-100 text-[11px] text-emerald-900 leading-relaxed">
                  <strong>Precedence Rule (§14):</strong> Individual scale weights take highest precedence and immediately re-trigger progression eligibility evaluations.
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer"
                >
                  Save Authoritative Individual Weight
                </button>
              </form>
            </div>
          </div>

          {/* Immutable Weight History Log (§17) */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200 flex justify-between items-center">
              <div>
                <h4 className="font-extrabold text-sm text-slate-900">
                  Immutable Weight Observation Ledger (§17)
                </h4>
                <p className="text-[11px] text-slate-500">
                  Historical audit trail of all pen and individual animal weights.
                </p>
              </div>
              <span className="px-2.5 py-1 bg-slate-100 text-slate-600 text-xs font-mono font-bold rounded-lg">
                {weightRecords.length} records
              </span>
            </div>

            <div className="overflow-x-auto max-h-80">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 sticky top-0 border-b border-slate-200 text-[10px] text-slate-500 font-bold uppercase">
                  <tr>
                    <th className="py-2.5 px-4">Date</th>
                    <th className="py-2.5 px-3">Target</th>
                    <th className="py-2.5 px-3">Type</th>
                    <th className="py-2.5 px-3">Weight (kg)</th>
                    <th className="py-2.5 px-3">Source</th>
                    <th className="py-2.5 px-3">Entered By</th>
                    <th className="py-2.5 px-4">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {weightRecords.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-6 text-center text-slate-400">
                        No weight records captured yet.
                      </td>
                    </tr>
                  ) : (
                    weightRecords.map(w => (
                      <tr key={w.id} className="hover:bg-slate-50 font-mono text-[11px]">
                        <td className="py-2.5 px-4 font-sans text-slate-700">
                          {w.measurementDate}
                        </td>
                        <td className="py-2.5 px-3 font-bold text-slate-900 font-sans">
                          {w.tagNumber || w.penName || w.animalId || w.penId}
                        </td>
                        <td className="py-2.5 px-3 font-sans">
                          <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                            w.measurementType === "INDIVIDUAL"
                              ? "bg-emerald-100 text-emerald-800"
                              : "bg-blue-100 text-blue-800"
                          }`}>
                            {w.measurementType}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-bold text-slate-900">
                          {w.weight} kg
                        </td>
                        <td className="py-2.5 px-3 font-sans text-slate-600">
                          {w.source}
                        </td>
                        <td className="py-2.5 px-3 font-sans text-slate-600">
                          {w.enteredBy}
                        </td>
                        <td className="py-2.5 px-4 font-sans text-slate-500 truncate max-w-xs">
                          {w.notes || "—"}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 3: BIOLOGICAL ASSET REGISTER (§29) */}
      {/* =================================================================== */}
      {activeTab === "register" && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 flex justify-between items-center shadow-xs">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900">
                Biological Asset Register (§29)
              </h3>
              <p className="text-xs text-slate-500">
                Single Source of Truth showing active animals, current lifecycle stage, authoritative weights, and biological carrying value.
              </p>
            </div>
            <button
              onClick={() => exportPDFReport("valuation")}
              className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" /> Export Register (PDF)
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                    <th className="py-3 px-4">Animal ID / Tag</th>
                    <th className="py-3 px-3">Species & Breed</th>
                    <th className="py-3 px-3">Current Stage</th>
                    <th className="py-3 px-3">Stage Entry Date</th>
                    <th className="py-3 px-3">Authoritative Weight</th>
                    <th className="py-3 px-3">Weight Source</th>
                    <th className="py-3 px-4 text-right">Carrying Valuation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {activeAnimals.map(animal => (
                    <tr key={animal.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-bold text-slate-900">
                        {animal.tagId || animal.name || animal.id}
                        {animal.penName && (
                          <span className="block text-[10px] text-slate-400 font-normal">
                            Pen: {animal.penName}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-slate-700">
                        {animal.species || animal.type} - {animal.breed}
                      </td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 font-bold text-[11px]">
                          {animal.currentStageName || animal.productionStage || "Initial Stage"}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-600 text-[11px]">
                        {animal.currentStageEntryDate || animal.registrationDate || animal.dateAcquired || "—"}
                      </td>
                      <td className="py-3 px-3 font-mono font-bold text-slate-900">
                        {animal.currentWeight || animal.weightKg || 0} kg
                      </td>
                      <td className="py-3 px-3 text-slate-600 text-[11px]">
                        {animal.currentWeightSource || "Registration"}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-extrabold text-emerald-700 text-sm">
                        {currencySymbol}{(animal.currentValue || 0).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 4: VALUATION TRACKER (§30) */}
      {/* =================================================================== */}
      {activeTab === "tracker" && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 flex justify-between items-center shadow-xs">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900">
                Biological Asset Valuation Tracker (§30)
              </h3>
              <p className="text-xs text-slate-500">
                Historical valuation movements, stage-change gains/losses, trigger evidence, and source audit linkage.
              </p>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                    <th className="py-3 px-4">Effective Date</th>
                    <th className="py-3 px-3">Animal Tag</th>
                    <th className="py-3 px-3">Stage Movement</th>
                    <th className="py-3 px-3">Trigger Type</th>
                    <th className="py-3 px-3">Previous Value</th>
                    <th className="py-3 px-3">New Valuation</th>
                    <th className="py-3 px-3">Valuation Delta</th>
                    <th className="py-3 px-4">Accounting Event</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {valuations.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-400">
                        No valuation transition events logged yet.
                      </td>
                    </tr>
                  ) : (
                    valuations.map(val => (
                      <tr key={val.id} className="hover:bg-slate-50 text-[11px] font-mono">
                        <td className="py-3 px-4 font-sans text-slate-700">
                          {val.valuationDate}
                        </td>
                        <td className="py-3 px-3 font-sans font-bold text-slate-900">
                          {val.tagNumber}
                        </td>
                        <td className="py-3 px-3 font-sans font-bold text-slate-800">
                          {val.stageName}
                        </td>
                        <td className="py-3 px-3 font-sans">
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-bold">
                            {val.triggerType}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-slate-500">
                          {currencySymbol}{val.previousValue.toLocaleString()}
                        </td>
                        <td className="py-3 px-3 font-bold text-slate-900">
                          {currencySymbol}{val.newValue.toLocaleString()}
                        </td>
                        <td className="py-3 px-3 font-extrabold">
                          <span className={val.valuationChange >= 0 ? "text-emerald-700" : "text-rose-700"}>
                            {val.valuationChange >= 0 ? "+" : ""}{currencySymbol}{val.valuationChange.toLocaleString()}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-400 text-[10px]">
                          {val.accountingEventId || "ACC-AUTO"}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 5: GENERAL LEDGER & ACCOUNTING RECONCILIATION (§31-§34) */}
      {/* =================================================================== */}
      {activeTab === "accounting" && (
        <div className="space-y-6">
          {/* Reconciliation Card (§34) */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <div>
                <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                  General Ledger & Biological Asset Control Reconciliation (§34)
                  {reconciliation.isBalanced ? (
                    <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-xs font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Reconciled
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 bg-rose-100 text-rose-800 rounded-full text-xs font-bold flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" /> Mismatch Detected
                    </span>
                  )}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Verifies that Animal Registry Valuation = Biological Asset Register = General Ledger Control Balance (GL 1420).
                </p>
              </div>

              <span className="text-xs text-slate-400 font-mono">
                Audit at: {new Date(reconciliation.generatedAt).toLocaleTimeString()}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400">Animal Registry Total</span>
                <p className="text-xl font-black text-slate-900 font-mono mt-1">
                  {currencySymbol}{reconciliation.animalRegistryTotalValue.toLocaleString()}
                </p>
                <span className="text-[10px] text-slate-500">{reconciliation.totalActiveAnimals} active animals</span>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400">Valuation Tracker Total</span>
                <p className="text-xl font-black text-slate-900 font-mono mt-1">
                  {currencySymbol}{reconciliation.biologicalAssetRegisterValue.toLocaleString()}
                </p>
                <span className="text-[10px] text-slate-500">Tracked valuations</span>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400">GL Code [1420] Control</span>
                <p className="text-xl font-black text-emerald-800 font-mono mt-1">
                  {currencySymbol}{reconciliation.generalLedgerControlBalance.toLocaleString()}
                </p>
                <span className="text-[10px] text-emerald-700">Synchronized Balance</span>
              </div>
            </div>

            {reconciliation.exceptions.length > 0 && (
              <div className="p-3.5 bg-rose-50 rounded-xl border border-rose-200 text-xs text-rose-900 space-y-1">
                <p className="font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-700" />
                  Reconciliation Discrepancies ({reconciliation.exceptions.length}):
                </p>
                {reconciliation.exceptions.map((exc, idx) => (
                  <p key={idx} className="text-[11px]">
                    • <strong>{exc.tagNumber}</strong>: {exc.issue} (Registry: {currencySymbol}{exc.registryValue}, Tracker: {currencySymbol}{exc.expectedValue})
                  </p>
                ))}
              </div>
            )}
          </div>

          {/* Generated Accounting Journal Events (§31, §32) */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200 flex justify-between items-center">
              <div>
                <h4 className="font-extrabold text-sm text-slate-900">
                  Automated General Ledger Posting Events (§31, §32)
                </h4>
                <p className="text-[11px] text-slate-500">
                  Idempotent double-entry journal postings generated upon biological stage progression.
                </p>
              </div>
              <span className="px-2.5 py-1 bg-slate-100 text-slate-700 text-xs font-mono font-bold rounded-lg">
                {accountingEvents.length} transactions
              </span>
            </div>

            <div className="overflow-x-auto max-h-80">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 sticky top-0 border-b border-slate-200 text-[10px] text-slate-500 font-bold uppercase">
                  <tr>
                    <th className="py-2.5 px-4">Date</th>
                    <th className="py-2.5 px-3">Animal Tag</th>
                    <th className="py-2.5 px-3">Debit Account</th>
                    <th className="py-2.5 px-3">Credit Account</th>
                    <th className="py-2.5 px-3">Amount</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-4">Idempotency Key</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                  {accountingEvents.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-6 text-center text-slate-400 font-sans">
                        No accounting journal events posted yet.
                      </td>
                    </tr>
                  ) : (
                    accountingEvents.map(evt => (
                      <tr key={evt.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-4 font-sans text-slate-700">
                          {evt.postingDate}
                        </td>
                        <td className="py-2.5 px-3 font-sans font-bold text-slate-900">
                          {evt.tagNumber}
                        </td>
                        <td className="py-2.5 px-3 text-emerald-800 font-sans">
                          {evt.debitAccount}
                        </td>
                        <td className="py-2.5 px-3 text-blue-800 font-sans">
                          {evt.creditAccount}
                        </td>
                        <td className="py-2.5 px-3 font-extrabold text-slate-900">
                          {currencySymbol}{evt.amount.toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3 font-sans">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            {evt.status}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 text-slate-400 text-[10px] truncate max-w-xs">
                          {evt.idempotencyKey}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 6: GROWTH STAGE CONFIGURATION TEMPLATES (§4-§8, §45) */}
      {/* =================================================================== */}
      {activeTab === "config" && (
        <div className="space-y-6">
          {/* Species Selector & Template Version Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
                Select Species Growth Template
              </label>
              <div className="flex flex-wrap gap-2">
                {["Pigs", "Cattle", "Goats", "Sheep"].map(sp => (
                  <button
                    key={sp}
                    onClick={() => setSelectedSpecies(sp)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      selectedSpecies === sp
                        ? "bg-emerald-600 text-white shadow-xs"
                        : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                    }`}
                  >
                    {sp}
                  </button>
                ))}
              </div>
            </div>

            {activeTemplate && (
              <div className="text-right">
                <span className="px-3 py-1 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200">
                  Version {activeTemplate.version} • Effective {activeTemplate.effectiveFrom}
                </span>
                <p className="text-[11px] text-slate-400 mt-1">
                  Historical transactions protected (§8, §46)
                </p>
              </div>
            )}
          </div>

          {/* Sequential Stage Cards (§4, §45) */}
          {activeTemplate ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-extrabold text-sm text-slate-900">
                  {activeTemplate.name} Lifecycle Sequence
                </h3>
                <button
                  onClick={() => {
                    const newStage: LivestockStage = {
                      id: `stg_${Date.now()}`,
                      templateId: activeTemplate.id,
                      sequence: activeTemplate.stages.length + 1,
                      name: "New Growth Stage",
                      durationValue: 30,
                      durationUnit: "DAYS",
                      targetWeight: 60,
                      targetWeightUnit: "kg",
                      valuation: 2000,
                      currency: "ZMW",
                      transitionMode: "WEIGHT_OR_TIME",
                      automaticProgression: true,
                      isFinalStage: false,
                      active: true
                    };
                    setEditingStage(newStage);
                  }}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Lifecycle Stage
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {activeTemplate.stages
                  .sort((a, b) => a.sequence - b.sequence)
                  .map((stage, idx) => {
                    return (
                      <div
                        key={stage.id}
                        className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative flex flex-col justify-between hover:border-emerald-300 transition-all"
                      >
                        <div>
                          <div className="flex justify-between items-start">
                            <span className="w-6 h-6 rounded-full bg-slate-900 text-white text-[11px] font-extrabold flex items-center justify-center">
                              {stage.sequence}
                            </span>
                            <div className="flex items-center gap-1">
                              {stage.isFinalStage ? (
                                <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-bold">
                                  Final Stage
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                                  Auto-Progress
                                </span>
                              )}
                            </div>
                          </div>

                          <h4 className="text-base font-black text-slate-900 mt-2">
                            {stage.name}
                          </h4>
                          <p className="text-xs text-slate-500 font-medium">
                            {stage.notes || "Standard developmental stage"}
                          </p>

                          <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs">
                            <div className="flex justify-between">
                              <span className="text-slate-400">Duration:</span>
                              <span className="font-bold text-slate-800">
                                {stage.durationValue > 0 ? `${stage.durationValue} ${stage.durationUnit.toLowerCase()}` : "Indefinite"}
                              </span>
                            </div>

                            <div className="flex justify-between">
                              <span className="text-slate-400">Target Weight:</span>
                              <span className="font-bold text-slate-800">
                                {stage.targetWeight > 0 ? `${stage.targetWeight} kg` : "—"}
                              </span>
                            </div>

                            <div className="flex justify-between">
                              <span className="text-slate-400">Stage Valuation:</span>
                              <span className="font-black text-emerald-700 font-mono text-sm">
                                {currencySymbol}{stage.valuation.toLocaleString()}
                              </span>
                            </div>

                            <div className="flex justify-between">
                              <span className="text-slate-400">Transition Rule:</span>
                              <span className="font-bold text-slate-700 text-[11px]">
                                {stage.transitionMode.replace(/_/g, " ")}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                          <button
                            onClick={() => setEditingStage(stage)}
                            className="px-2.5 py-1 text-xs text-slate-600 hover:text-slate-900 font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" /> Edit Stage
                          </button>

                          {!stage.isFinalStage && idx < activeTemplate.stages.length - 1 && (
                            <ArrowRight className="w-4 h-4 text-emerald-500" />
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          ) : (
            <div className="bg-white p-8 text-center rounded-2xl border border-slate-200">
              <p className="text-slate-500 text-sm">No template configured for {selectedSpecies}.</p>
            </div>
          )}
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 7: REPORTS & EXPORTS (§57) */}
      {/* =================================================================== */}
      {activeTab === "reports" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <span className="p-2.5 bg-emerald-50 text-emerald-700 rounded-xl inline-block">
                <FileText className="w-5 h-5" />
              </span>
              <h4 className="font-extrabold text-sm text-slate-900">
                Biological Asset Valuation Report (§57)
              </h4>
              <p className="text-xs text-slate-500">
                Detailed carrying valuations by species, stage, tag number, and weight attributes.
              </p>
              <button
                onClick={() => exportPDFReport("valuation")}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" /> Download PDF
              </button>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <span className="p-2.5 bg-amber-50 text-amber-700 rounded-xl inline-block">
                <AlertTriangle className="w-5 h-5" />
              </span>
              <h4 className="font-extrabold text-sm text-slate-900">
                Underperformance & Underweight Report (§24, §57)
              </h4>
              <p className="text-xs text-slate-500">
                Animals that transitioned on time duration but fell below target biological weight thresholds.
              </p>
              <button
                onClick={() => exportPDFReport("underperformance")}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-amber-400" /> Download PDF
              </button>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <span className="p-2.5 bg-blue-50 text-blue-700 rounded-xl inline-block">
                <History className="w-5 h-5" />
              </span>
              <h4 className="font-extrabold text-sm text-slate-900">
                Audit Trail & Transition History (§40, §56)
              </h4>
              <p className="text-xs text-slate-500">
                Complete verifiable audit log containing trigger evidence, user/actor signatures, and accounting event keys.
              </p>
              <button
                onClick={() => {
                  const blob = new Blob([JSON.stringify(transitions, null, 2)], { type: "application/json" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = `stage_transitions_audit_${new Date().toISOString().split("T")[0]}.json`;
                  a.click();
                  onShowToast?.("Exported audit trail JSON", "success");
                }}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-blue-400" /> Export JSON Audit Log
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* MODAL: STAGE TRANSITION CONFIRMATION (§28) */}
      {/* =================================================================== */}
      {selectedAnimalForTransition && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                  <Play className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    Confirm Biological Stage Progression
                  </h3>
                  <p className="text-xs text-slate-500">
                    {selectedAnimalForTransition.animal.tagId || selectedAnimalForTransition.animal.name}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedAnimalForTransition(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                ✕
              </button>
            </div>

            {/* Transition Path Box */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400">Current Stage</span>
                <p className="text-sm font-black text-slate-900">
                  {selectedAnimalForTransition.result.currentStageName || "Current"}
                </p>
                <p className="text-xs font-mono text-slate-500">
                  {currencySymbol}{(selectedAnimalForTransition.animal.currentValue || 0).toLocaleString()}
                </p>
              </div>

              <ArrowRight className="w-5 h-5 text-emerald-600" />

              <div className="text-right">
                <span className="text-[10px] uppercase font-bold text-emerald-600">Next Stage</span>
                <p className="text-sm font-black text-emerald-900">
                  {selectedAnimalForTransition.result.nextStageName}
                </p>
                <p className="text-xs font-mono font-bold text-emerald-700">
                  {currencySymbol}{(selectedAnimalForTransition.result.nextStageValuation || 0).toLocaleString()}
                </p>
              </div>
            </div>

            {/* Trigger Details */}
            <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-100 space-y-1.5 text-xs text-emerald-900">
              <p className="font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                Trigger: {selectedAnimalForTransition.result.trigger}
              </p>
              <p className="text-[11.5px]">
                Authoritative Weight: <strong>{selectedAnimalForTransition.result.currentWeight} kg</strong> (Target: {selectedAnimalForTransition.result.targetWeight} kg)
              </p>
              <p className="text-[11.5px]">
                Time in Stage: <strong>{selectedAnimalForTransition.result.daysInStage} days</strong> (Target: {selectedAnimalForTransition.result.targetDays} days)
              </p>
              {selectedAnimalForTransition.result.isUnderweight && (
                <p className="text-amber-800 font-bold text-[11px] pt-1">
                  ⚠ Note: Underweight by {Math.abs(selectedAnimalForTransition.result.weightVariancePct)}% below target.
                </p>
              )}
            </div>

            {/* GL Journal Preview (§31) */}
            <div className="p-3 bg-slate-900 rounded-xl text-white space-y-1.5 font-mono text-[11px]">
              <div className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">
                Automated General Ledger Posting Preview
              </div>
              <div className="flex justify-between">
                <span>Dr 1420 - Biological Assets: Livestock</span>
                <span className="text-emerald-400">
                  +{currencySymbol}{((selectedAnimalForTransition.result.nextStageValuation || 0) - (selectedAnimalForTransition.animal.currentValue || 0)).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Cr 4400 - Biological Revaluation Gain</span>
                <span className="text-emerald-400">
                  +{currencySymbol}{((selectedAnimalForTransition.result.nextStageValuation || 0) - (selectedAnimalForTransition.animal.currentValue || 0)).toLocaleString()}
                </span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedAnimalForTransition(null)}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmSingleTransition}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
              >
                Confirm & Progress Animal
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* MODAL: MANUAL STAGE OVERRIDE (§35, §36) */}
      {/* =================================================================== */}
      {overrideModalAnimal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-base font-extrabold text-slate-900">
                  Manual Stage Override (§35)
                </h3>
                <p className="text-xs text-slate-500">
                  Tag: {overrideModalAnimal.tagId || overrideModalAnimal.name}
                </p>
              </div>
              <button
                onClick={() => setOverrideModalAnimal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Target Stage</label>
                <select
                  value={overrideTargetStageId}
                  onChange={e => setOverrideTargetStageId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white"
                  required
                >
                  <option value="">-- Choose New Stage --</option>
                  {activeTemplate?.stages.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({currencySymbol}{s.valuation.toLocaleString()})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Reason for Manual Override <span className="text-rose-600">*</span>
                </label>
                <select
                  value={overrideReason}
                  onChange={e => setOverrideReason(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white"
                  required
                >
                  <option value="">-- Select Justification --</option>
                  <option value="Incorrect Initial Stage Assignment">Incorrect Initial Stage Assignment</option>
                  <option value="Advanced Physical Maturity">Advanced Physical Maturity</option>
                  <option value="Veterinary Downgrade / Reversal">Veterinary Downgrade / Reversal</option>
                  <option value="Breeding Stock Transfer">Breeding Stock Transfer</option>
                  <option value="Administrative Audit Correction">Administrative Audit Correction</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Supporting Notes</label>
                <textarea
                  rows={2}
                  value={overrideNotes}
                  onChange={e => setOverrideNotes(e.target.value)}
                  placeholder="Provide supporting details for this override..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200"
                />
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900 leading-relaxed">
                <strong>Financial Compliance Note (§36):</strong> Manual overrides create a formal auditable transition and generate an accounting revaluation adjustment.
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setOverrideModalAnimal(null)}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmManualOverride}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
              >
                Apply Manual Override
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* MODAL: PROGRESSION HOLD (§37) */}
      {/* =================================================================== */}
      {holdModalAnimal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-purple-100 text-purple-800 rounded-xl">
                  <Lock className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    Place on Progression Hold (§37)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Tag: {holdModalAnimal.tagId || holdModalAnimal.name}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setHoldModalAnimal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Hold Reason / Category
                </label>
                <select
                  value={holdReason}
                  onChange={e => setHoldReason(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white"
                >
                  <option value="Sick Animal Under Treatment">Sick Animal Under Treatment</option>
                  <option value="Quarantine / Biosecurity Isolation">Quarantine / Biosecurity Isolation</option>
                  <option value="Veterinary Assessment Pending">Veterinary Assessment Pending</option>
                  <option value="Special Breeding Stock Management">Special Breeding Stock Management</option>
                  <option value="Data Review / Weight Verification">Data Review / Weight Verification</option>
                  <option value="Administrative Hold">Administrative Hold</option>
                </select>
              </div>

              <div className="p-3 bg-purple-50 rounded-xl border border-purple-200 text-[11px] text-purple-900 leading-relaxed">
                While on hold, automatic stage progression is suspended. Weight capture continues normally. Removing the hold immediately triggers re-evaluation.
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setHoldModalAnimal(null)}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmHold}
                className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
              >
                Confirm Progression Hold
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* MODAL: EDIT / ADD STAGE MODAL (§4, §5, §6) */}
      {/* =================================================================== */}
      {editingStage && activeTemplate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-base font-extrabold text-slate-900">
                  Configure Growth Stage
                </h3>
                <p className="text-xs text-slate-500">
                  {activeTemplate.name}
                </p>
              </div>
              <button
                onClick={() => setEditingStage(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">Stage Name</label>
                  <input
                    type="text"
                    value={editingStage.name}
                    onChange={e => setEditingStage({ ...editingStage, name: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Sequence #</label>
                  <input
                    type="number"
                    value={editingStage.sequence}
                    onChange={e => setEditingStage({ ...editingStage, sequence: Number(e.target.value) || 1 })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Typical Duration</label>
                  <input
                    type="number"
                    value={editingStage.durationValue}
                    onChange={e => setEditingStage({ ...editingStage, durationValue: Number(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Unit</label>
                  <select
                    value={editingStage.durationUnit}
                    onChange={e => setEditingStage({ ...editingStage, durationUnit: e.target.value as any })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white"
                  >
                    <option value="DAYS">Days</option>
                    <option value="WEEKS">Weeks</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Target Weight (kg)</label>
                  <input
                    type="number"
                    value={editingStage.targetWeight}
                    onChange={e => setEditingStage({ ...editingStage, targetWeight: Number(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Valuation ({currencySymbol})</label>
                  <input
                    type="number"
                    value={editingStage.valuation}
                    onChange={e => setEditingStage({ ...editingStage, valuation: Number(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Transition Mode (§5)</label>
                <select
                  value={editingStage.transitionMode}
                  onChange={e => setEditingStage({ ...editingStage, transitionMode: e.target.value as StageTransitionMode })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white"
                >
                  <option value="WEIGHT_OR_TIME">Whichever happens first (Weight OR Time) - Recommended</option>
                  <option value="WEIGHT_AND_TIME">Both required (Weight AND Time)</option>
                  <option value="TIME_ONLY">Time only</option>
                  <option value="WEIGHT_ONLY">Weight only</option>
                </select>
              </div>

              <div className="flex items-center gap-4 pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingStage.automaticProgression}
                    onChange={e => setEditingStage({ ...editingStage, automaticProgression: e.target.checked })}
                    className="rounded text-emerald-600"
                  />
                  <span className="font-bold text-slate-700">Auto Progression</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingStage.isFinalStage}
                    onChange={e => setEditingStage({ ...editingStage, isFinalStage: e.target.checked })}
                    className="rounded text-emerald-600"
                  />
                  <span className="font-bold text-slate-700">Final Stage</span>
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setEditingStage(null)}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const stages = [...activeTemplate.stages];
                  const existingIdx = stages.findIndex(s => s.id === editingStage.id);
                  if (existingIdx >= 0) {
                    stages[existingIdx] = editingStage;
                  } else {
                    stages.push(editingStage);
                  }

                  const updatedTemplate: LivestockStageTemplate = {
                    ...activeTemplate,
                    stages
                  };

                  const res = saveOrUpdateStageTemplate(tenantId, updatedTemplate, "User");
                  if (!res.validation.valid) {
                    onShowToast?.(res.validation.errors.join(". "), "error");
                    return;
                  }

                  if (res.validation.warnings.length > 0) {
                    onShowToast?.(res.validation.warnings[0], "info");
                  }

                  refreshAllData();
                  setEditingStage(null);
                  onShowToast?.(`✓ Saved stage '${editingStage.name}'. Template version: v${res.template.version}`, "success");
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
              >
                Save Growth Stage
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

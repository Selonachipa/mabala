import React, { useState, useMemo } from "react";
import { 
  Beef, 
  Sparkles, 
  Plus, 
  Trash2, 
  Save, 
  RefreshCw, 
  DollarSign, 
  FileText, 
  Calculator, 
  Layers, 
  History, 
  AlertCircle, 
  CheckCircle2, 
  Lock, 
  TrendingUp, 
  Scale, 
  Tag, 
  Calendar,
  Filter,
  Download,
  BookOpen
} from "lucide-react";
import { 
  AnimalTypeConfig, 
  FeedIngredient, 
  FeedFormulation, 
  DailyFeedLog, 
  AnimalFeedCostLedger,
  FormulationIngredient,
  PenRecord
} from "../../types";
import { 
  DEFAULT_ANIMAL_TYPES, 
  getTenantAnimalTypes,
  getTenantPens,
  adjustTenantPenHeadcount,
  getTenantIngredients, 
  saveTenantIngredient, 
  getTenantFormulations, 
  saveTenantFormulation, 
  deleteTenantFormulation,
  duplicateTenantFormulation,
  toggleFormulationStatus,
  setPrimaryActiveFormulation,
  resetTenantFormulationsToDefaults,
  getTenantDailyFeedLogs, 
  deleteTenantDailyFeedLog,
  getTenantFeedLedgers, 
  logDailyFeedTransaction,
  computeFormulationCosts 
} from "../../services/feedEngineService";
import FeedFormulationBuilder from "./FeedFormulationBuilder";
import DailyFeedChart from "./DailyFeedChart";
import PenGridDailyFeedLog from "./PenGridDailyFeedLog";
import FeedBudgetProjection from "./FeedBudgetProjection";
import GrowthStageConfigManager from "./GrowthStageConfigManager";

interface StageFeedEngineProps {
  currencySymbol?: string;
  tenantId?: string;
  accounts?: any[];
  setAccounts?: (accs: any[]) => void;
  activeFarmNodeId?: string;
  onShowToast?: (msg: string, type: "success" | "error" | "info") => void;
  currentUserRole?: string;
  isSuperAdmin?: boolean;
  userProfile?: any;
}

export default function StageFeedFormulationEngine({
  currencySymbol = "ZMW",
  tenantId = "default",
  accounts,
  setAccounts,
  activeFarmNodeId = "main_farm",
  onShowToast,
  currentUserRole,
  isSuperAdmin,
  userProfile
}: StageFeedEngineProps) {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<"pen_grid" | "budget_projection" | "daily_log" | "formulations" | "ingredients" | "ledger" | "stages">("pen_grid");

  // Role authorization check for Super Admin and Farm Owner deletion actions
  const isAuthorizedToDelete = useMemo(() => {
    if (isSuperAdmin) return true;
    const roleLower = (currentUserRole || userProfile?.role || "").toLowerCase();
    const tenantTypeLower = (userProfile?.tenantType || "").toLowerCase();
    if (
      roleLower.includes("super admin") || 
      roleLower.includes("platform admin") || 
      roleLower.includes("platform administrator") ||
      tenantTypeLower === "super_admin"
    ) {
      return true;
    }
    if (
      roleLower === "farm owner" || 
      roleLower === "owner" || 
      roleLower === "administrator" ||
      roleLower === "farmer" ||
      tenantTypeLower === "farmer"
    ) {
      return true;
    }
    return false;
  }, [isSuperAdmin, currentUserRole, userProfile]);

  // Local State
  const [animalTypes, setAnimalTypes] = useState<AnimalTypeConfig[]>(() => getTenantAnimalTypes(tenantId));
  const [pens, setPens] = useState<PenRecord[]>(() => getTenantPens(tenantId));
  const [ingredients, setIngredients] = useState<FeedIngredient[]>(() => getTenantIngredients(tenantId));
  const [formulations, setFormulations] = useState<FeedFormulation[]>(() => getTenantFormulations(tenantId));
  const [dailyLogs, setDailyLogs] = useState<DailyFeedLog[]>(() => getTenantDailyFeedLogs(tenantId));
  const [ledgers, setLedgers] = useState<AnimalFeedCostLedger[]>(() => getTenantFeedLedgers(tenantId));

  // Modals & Forms
  const [showAddIngredientModal, setShowAddIngredientModal] = useState(false);
  const [showEditCostModal, setShowEditCostModal] = useState<FeedIngredient | null>(null);
  const [editCostValue, setEditCostValue] = useState<number>(0);

  // Quick Add Ingredient State
  const [newIngName, setNewIngName] = useState("");
  const [newIngCategory, setNewIngCategory] = useState<FeedIngredient["category"]>("energy");
  const [newIngUnit, setNewIngUnit] = useState<"kg" | "g" | "litre">("kg");
  const [newIngCost, setNewIngCost] = useState<number>(0);

  // Formulation Builder State
  const [selectedAnimalType, setSelectedAnimalType] = useState<string>("pig");
  const [selectedStage, setSelectedStage] = useState<string>("grower");
  const [formName, setFormName] = useState<string>("");
  const [formBatchSize, setFormBatchSize] = useState<number>(100);
  const [formDailyQty, setFormDailyQty] = useState<number>(1.8);
  const [formRecipeRows, setFormRecipeRows] = useState<FormulationIngredient[]>([]);
  const [editingFormulationId, setEditingFormulationId] = useState<string | null>(null);

  // Daily Feed Log State
  const [logAnimalType, setLogAnimalType] = useState<string>("pig");
  const [logStage, setLogStage] = useState<string>("grower");
  const [logSelectedPenId, setLogSelectedPenId] = useState<string>("");
  const [logCohortId, setLogCohortId] = useState<string>("");
  const [logNumAnimals, setLogNumAnimals] = useState<number>(20);
  const [logActualQty, setLogActualQty] = useState<number | undefined>(undefined);
  const [logDate, setLogDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [logNotes, setLogNotes] = useState<string>("");
  const [logMortalityCount, setLogMortalityCount] = useState<number>(0);
  const [logSoldCount, setLogSoldCount] = useState<number>(0);

  // Filter States
  const [ledgerSearch, setLedgerSearch] = useState("");

  // Helpers
  const toast = (msg: string, type: "success" | "error" | "info" = "info") => {
    if (onShowToast) onShowToast(msg, type);
    else console.log(`[Toast ${type}]: ${msg}`);
  };

  const refreshData = () => {
    setAnimalTypes(getTenantAnimalTypes(tenantId));
    setPens(getTenantPens(tenantId));
    setIngredients(getTenantIngredients(tenantId));
    setFormulations(getTenantFormulations(tenantId));
    setDailyLogs(getTenantDailyFeedLogs(tenantId));
    setLedgers(getTenantFeedLedgers(tenantId));
  };

  // Configured pens for the selected animal type in daily log
  const configuredPensForType = useMemo(() => {
    return pens.filter(p => p.animalTypeId === logAnimalType);
  }, [pens, logAnimalType]);

  const handleSelectPenForDailyLog = (penIdOrCode: string) => {
    setLogSelectedPenId(penIdOrCode);
    if (!penIdOrCode || penIdOrCode === "__custom__") {
      if (penIdOrCode === "__custom__") {
        setLogCohortId("");
      }
      return;
    }
    const foundPen = pens.find(p => p.id === penIdOrCode || p.code.toUpperCase() === penIdOrCode.toUpperCase());
    if (foundPen) {
      setLogCohortId(foundPen.code);
      setLogStage(foundPen.stageId);
      setLogNumAnimals(foundPen.headcount || 1);
      setLogActualQty(undefined); // let it auto-calculate standard qty based on active recipe
    }
  };

  const currentLogAnimalConfig = useMemo(() => {
    return animalTypes.find(a => a.id === logAnimalType) || animalTypes[0];
  }, [animalTypes, logAnimalType]);

  // Active formulation for logging
  const activeFormulationForLog = useMemo(() => {
    return formulations.find(
      f => f.animalTypeId === logAnimalType && f.stageId === logStage && f.status === "active"
    );
  }, [formulations, logAnimalType, logStage]);

  // Calculated live formulation costs
  const liveFormulationCalc = useMemo(() => {
    return computeFormulationCosts(formRecipeRows, ingredients, formBatchSize, formDailyQty);
  }, [formRecipeRows, ingredients, formBatchSize, formDailyQty]);

  // Calculated live daily feed log numbers
  const liveLogCalc = useMemo(() => {
    if (!activeFormulationForLog) return { qty: 0, cost: 0 };
    const defaultQty = logNumAnimals * activeFormulationForLog.dailyQtyPerAnimal;
    const finalQty = logActualQty !== undefined && logActualQty > 0 ? logActualQty : defaultQty;
    const totalCost = finalQty * activeFormulationForLog.costPerKgMix;
    return {
      qty: Number(finalQty.toFixed(2)),
      cost: Number(totalCost.toFixed(2))
    };
  }, [activeFormulationForLog, logNumAnimals, logActualQty]);

  // Feed Spend Analytics Widgets
  const feedSpendAnalytics = useMemo(() => {
    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    let weekSpend = 0;
    let monthSpend = 0;
    let totalQtyKg = 0;

    dailyLogs.forEach(log => {
      const logDate = new Date(log.date);
      if (logDate >= sevenDaysAgo) weekSpend += log.totalCost;
      if (logDate >= thirtyDaysAgo) {
        monthSpend += log.totalCost;
        totalQtyKg += log.totalQuantityFedKg;
      }
    });

    return {
      weekSpend: Number(weekSpend.toFixed(2)),
      monthSpend: Number(monthSpend.toFixed(2)),
      totalQtyKg: Number(totalQtyKg.toFixed(1))
    };
  }, [dailyLogs]);

  // HANDLERS
  // 1. Add / Save Ingredient
  const handleCreateIngredient = () => {
    if (!newIngName.trim()) {
      toast("Please enter an ingredient name.", "error");
      return;
    }
    saveTenantIngredient(
      tenantId,
      {
        name: newIngName.trim(),
        category: newIngCategory,
        unit: newIngUnit,
        currentCostPerUnit: newIngCost,
        active: true
      },
      "Farmer Admin"
    );
    setNewIngName("");
    setNewIngCost(0);
    setShowAddIngredientModal(false);
    refreshData();
    toast(`Added feed ingredient "${newIngName}"!`, "success");
  };

  // 2. Update Ingredient Cost
  const handleUpdateIngredientCost = () => {
    if (!showEditCostModal) return;
    saveTenantIngredient(
      tenantId,
      {
        ...showEditCostModal,
        currentCostPerUnit: editCostValue
      },
      "Farmer Admin"
    );
    setShowEditCostModal(null);
    refreshData();
    toast(`Updated cost for ${showEditCostModal.name} to ${currencySymbol} ${editCostValue}/unit. Formulations recalculated!`, "success");
  };

  // 3. Add row to formulation recipe builder
  const handleAddRecipeRow = (ingredientId?: string) => {
    if (ingredientId === "__ADD_NEW__") {
      setShowAddIngredientModal(true);
      return;
    }

    const ing = ingredients.find(i => i.id === ingredientId) || ingredients[0];
    if (!ing) {
      toast("Please add ingredients to your tenant inventory first.", "error");
      return;
    }

    setFormRecipeRows(prev => [
      ...prev,
      {
        ingredientId: ing.id,
        ingredientName: ing.name,
        inclusionQtyPerUnit: 10,
        unit: ing.unit,
        costPerKgOverride: ing.currentCostPerUnit
      }
    ]);
  };

  const handleUpdateRecipeRow = (index: number, field: string, val: any) => {
    setFormRecipeRows(prev => {
      const updated = [...prev];
      if (field === "ingredientId") {
        const ing = ingredients.find(i => i.id === val);
        if (ing) {
          updated[index] = {
            ...updated[index],
            ingredientId: ing.id,
            ingredientName: ing.name,
            unit: ing.unit,
            costPerKgOverride: ing.currentCostPerUnit
          };
        }
      } else {
        updated[index] = { ...updated[index], [field]: val };
      }
      return updated;
    });
  };

  const handleRemoveRecipeRow = (index: number) => {
    setFormRecipeRows(prev => prev.filter((_, i) => i !== index));
  };

  // 4. Save Formulation
  const handleSaveFormulation = () => {
    if (!formName.trim()) {
      toast("Please enter a formulation name.", "error");
      return;
    }
    if (formRecipeRows.length === 0) {
      toast("Please add at least one ingredient to the recipe.", "error");
      return;
    }

    const saved = saveTenantFormulation(
      tenantId,
      {
        id: editingFormulationId || undefined,
        animalTypeId: selectedAnimalType,
        stageId: selectedStage,
        name: formName.trim(),
        status: "active",
        version: 1,
        effectiveFrom: new Date().toISOString(),
        batchSize: formBatchSize,
        dailyQtyPerAnimal: formDailyQty,
        ingredients: formRecipeRows
      },
      "Farm Manager"
    );

    refreshData();
    setEditingFormulationId(null);
    setFormName("");
    setFormRecipeRows([]);
    toast(`Successfully saved active formulation "${saved.name}" (v${saved.version})!`, "success");
  };

  const handleEditFormulation = (form: FeedFormulation) => {
    setEditingFormulationId(form.id);
    setSelectedAnimalType(form.animalTypeId);
    setSelectedStage(form.stageId);
    setFormName(form.name);
    setFormBatchSize(form.batchSize);
    setFormDailyQty(form.dailyQtyPerAnimal);
    setFormRecipeRows(form.ingredients);
    setActiveTab("formulations");
  };

  // 5. Submit Daily Feed Log
  const handleSubmitDailyFeedLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeFormulationForLog) {
      toast(`No active feed formulation found for ${currentLogAnimalConfig.name} (${logStage}). Create one in the Formulations tab first!`, "error");
      return;
    }
    if (logNumAnimals <= 0) {
      toast("Please enter a valid number of animals fed.", "error");
      return;
    }

    try {
      const finalCohortId = logCohortId.trim() || (logSelectedPenId ? logSelectedPenId : `pen-${logAnimalType}-${logStage}-01`);
      const { log, ledger } = logDailyFeedTransaction(
        tenantId,
        {
          date: logDate,
          farmNodeId: activeFarmNodeId,
          animalTypeId: logAnimalType,
          stageId: logStage,
          cohortId: finalCohortId,
          formulationId: activeFormulationForLog.id,
          numberOfAnimalsFed: logNumAnimals,
          totalQuantityFedKg: logActualQty,
          notes: logNotes + (logMortalityCount > 0 ? ` [Mortality: ${logMortalityCount}]` : "") + (logSoldCount > 0 ? ` [Sold: ${logSoldCount}]` : ""),
          loggedBy: "Farm Manager"
        },
        "Farm Manager",
        accounts,
        setAccounts
      );

      // Auto adjust Pen Headcount if a matching Pen exists and mortality/sales occurred
      const totalRemoved = (logMortalityCount || 0) + (logSoldCount || 0);
      if (totalRemoved > 0) {
        const matchedPen = pens.find(p => p.code.toUpperCase() === finalCohortId.toUpperCase() || p.id === logSelectedPenId);
        if (matchedPen) {
          const reductionReason = `Feeding log adjustment (${logMortalityCount > 0 ? `Mortality: ${logMortalityCount}` : ""} ${logSoldCount > 0 ? `Sold: ${logSoldCount}` : ""})`.trim();
          adjustTenantPenHeadcount(tenantId, matchedPen.id, -totalRemoved, reductionReason);
        }
      }

      refreshData();
      setLogNotes("");
      setLogActualQty(undefined);
      setLogMortalityCount(0);
      setLogSoldCount(0);
      toast(`Logged feeding for ${log.numberOfAnimalsFed} animals in ${finalCohortId}! Cost: ${currencySymbol} ${log.totalCost.toFixed(2)} posted & frozen.`, "success");
    } catch (err: any) {
      toast(err.message || "Failed to save daily feed log.", "error");
    }
  };

  // Delete Daily Feed Log (Super Admin & Farm Owner only)
  const handleDeleteDailyLog = (logId: string, label: string, date: string) => {
    if (!isAuthorizedToDelete) {
      toast("Permission Denied: Only Super Admin and Farm Owner are authorized to delete Daily Feeding Logs.", "error");
      return;
    }
    if (confirm(`Are you sure you want to delete the Daily Feed Log for ${label} on ${date}? This will reverse the posted feed transaction and update the cost ledger.`)) {
      const success = deleteTenantDailyFeedLog(tenantId, logId, accounts, setAccounts);
      if (success) {
        toast(`Daily feed log for ${label} (${date}) deleted successfully.`, "success");
        refreshData();
      } else {
        toast("Failed to delete daily feed log.", "error");
      }
    }
  };

  return (
    <div className="space-y-6 text-slate-800">
      {/* HEADER BANNER */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white rounded-2xl p-6 shadow-xl border border-emerald-800/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Calculator className="w-64 h-64 text-emerald-400" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Mabala Stage-Based Engine
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-500/20 text-teal-200 border border-teal-500/30">
                Tenant Isolated • COA Integrated
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2">
              <Beef className="w-8 h-8 text-emerald-400" />
              Feed Formulation & Costing Engine
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm max-w-2xl mt-1">
              Standardized, species-agnostic feed formulation per growth stage. Configurable tenant ingredient pricing, immutable daily logs, and transactional cost-per-animal ledger.
            </p>
          </div>

          {/* Quick Stats Widget */}
          <div className="flex items-center gap-3 bg-slate-950/60 p-3 rounded-xl border border-emerald-500/20 backdrop-blur-md">
            <div className="text-center px-3 border-r border-slate-800">
              <span className="block text-[10px] uppercase font-extrabold text-slate-400">7-Day Spend</span>
              <span className="text-base font-black text-emerald-400">{currencySymbol} {feedSpendAnalytics.weekSpend.toLocaleString()}</span>
            </div>
            <div className="text-center px-3 border-r border-slate-800">
              <span className="block text-[10px] uppercase font-extrabold text-slate-400">30-Day Spend</span>
              <span className="text-base font-black text-teal-300">{currencySymbol} {feedSpendAnalytics.monthSpend.toLocaleString()}</span>
            </div>
            <div className="text-center px-3">
              <span className="block text-[10px] uppercase font-extrabold text-slate-400">30-Day Feed</span>
              <span className="text-base font-black text-amber-300">{feedSpendAnalytics.totalQtyKg.toLocaleString()} kg</span>
            </div>
          </div>
        </div>

        {/* NAVIGATION TABS */}
        <div className="flex items-center gap-2 mt-6 pt-4 border-t border-slate-800/80 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab("pen_grid")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === "pen_grid"
                ? "bg-emerald-500 text-slate-950 shadow-lg font-black"
                : "bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <Calendar className="w-4 h-4" />
            1. Daily Pen Feed Log (Grid)
          </button>

          <button
            onClick={() => setActiveTab("budget_projection")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === "budget_projection"
                ? "bg-emerald-500 text-slate-950 shadow-lg font-black"
                : "bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            2. Feed Budget Projection
          </button>

          <button
            onClick={() => setActiveTab("daily_log")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === "daily_log"
                ? "bg-emerald-500 text-slate-950 shadow-lg font-black"
                : "bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <Calendar className="w-4 h-4" />
            3. Batch/Cohort Feeding Log
          </button>

          <button
            onClick={() => setActiveTab("formulations")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === "formulations"
                ? "bg-emerald-500 text-slate-950 shadow-lg font-black"
                : "bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <Calculator className="w-4 h-4" />
            4. Feed Formulations ({formulations.length})
          </button>

          <button
            onClick={() => setActiveTab("ingredients")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === "ingredients"
                ? "bg-emerald-500 text-slate-950 shadow-lg font-black"
                : "bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <Layers className="w-4 h-4" />
            5. Ingredient Master ({ingredients.length})
          </button>

          <button
            onClick={() => setActiveTab("ledger")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === "ledger"
                ? "bg-emerald-500 text-slate-950 shadow-lg font-black"
                : "bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            6. Cost-to-Date Ledger ({ledgers.length})
          </button>

          <button
            onClick={() => setActiveTab("stages")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === "stages"
                ? "bg-emerald-500 text-slate-950 shadow-lg font-black"
                : "bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <BookOpen className="w-4 h-4" />
            7. Growth Stages Config
          </button>
        </div>
      </div>

      {/* TAB 0: PEN GRID DAILY LOG */}
      {activeTab === "pen_grid" && (
        <PenGridDailyFeedLog
          tenantId={tenantId}
          currencySymbol={currencySymbol}
          formulations={formulations}
          dailyLogs={dailyLogs}
          animalTypes={animalTypes}
          accounts={accounts}
          setAccounts={setAccounts}
          activeFarmNodeId={activeFarmNodeId}
          onRefreshData={refreshData}
          onShowToast={onShowToast}
          currentUserRole={currentUserRole}
          isSuperAdmin={isSuperAdmin}
          userProfile={userProfile}
        />
      )}

      {/* TAB 0.5: FEED BUDGET PROJECTION */}
      {activeTab === "budget_projection" && (
        <FeedBudgetProjection
          tenantId={tenantId}
          currencySymbol={currencySymbol}
          formulations={formulations}
          animalTypes={animalTypes}
        />
      )}

      {/* TAB 1: DAILY FEED LOGGING */}
      {activeTab === "daily_log" && (
        <div className="space-y-6">
          {/* DAILY FEED CHART VISUALIZER */}
          <DailyFeedChart
            dailyLogs={dailyLogs}
            ledgers={ledgers}
            currencySymbol={currencySymbol}
            title="Cumulative Feed Cost Trends & Intake Analytics"
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* LOG FORM */}
            <div className="lg:col-span-1 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-emerald-600" />
                  Record Daily Feeding Log
                </h3>
                <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Immutable Record
                </span>
              </div>

              <form onSubmit={handleSubmitDailyFeedLog} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Date of Feeding</label>
                  <input
                    type="date"
                    value={logDate}
                    onChange={e => setLogDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Animal Type</label>
                    <select
                      value={logAnimalType}
                      onChange={e => {
                        setLogAnimalType(e.target.value);
                        const cfg = animalTypes.find(a => a.id === e.target.value);
                        if (cfg && cfg.stages.length > 0) setLogStage(cfg.stages[0].id);
                      }}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                    >
                      {animalTypes.map(a => (
                        <option key={a.id} value={a.id}>{a.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Growth Stage</label>
                    <select
                      value={logStage}
                      onChange={e => setLogStage(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                    >
                      {currentLogAnimalConfig.stages.map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Pen / Batch / Cohort ID (Optional)</label>
                  <select
                    value={logSelectedPenId}
                    onChange={e => handleSelectPenForDailyLog(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 mb-1.5"
                  >
                    <option value="">-- Select Configured Pen or Custom --</option>
                    {configuredPensForType.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.code} — {p.name || `Pen ${p.code}`} ({p.headcount} {currentLogAnimalConfig.countUnit || 'head'}) [Stage: {p.stageId}]
                      </option>
                    ))}
                    <option value="__custom__">✍️ Custom Cohort / Batch ID...</option>
                  </select>

                  {(!logSelectedPenId || logSelectedPenId === "__custom__" || configuredPensForType.length === 0) && (
                    <input
                      type="text"
                      placeholder="e.g. Pen-3-Grower-Batch-2"
                      value={logCohortId}
                      onChange={e => setLogCohortId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium text-slate-800 focus:ring-2 focus:ring-emerald-500"
                    />
                  )}
                </div>

                {/* Formulation Snapshot Status */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="block text-[10px] font-black uppercase text-slate-500 tracking-wider">
                    Active Formulation Selected
                  </span>
                  {activeFormulationForLog ? (
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-extrabold text-slate-900 text-xs">{activeFormulationForLog.name} (v{activeFormulationForLog.version})</p>
                        <p className="text-[11px] font-semibold text-slate-600">
                          {currencySymbol} {activeFormulationForLog.costPerKgMix}/kg • Default: {activeFormulationForLog.dailyQtyPerAnimal} kg/head/day
                        </p>
                      </div>
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    </div>
                  ) : (
                    <div className="text-amber-700 text-xs font-bold flex items-center gap-1.5 py-1">
                      <AlertCircle className="w-4 h-4 text-amber-600" />
                      No active formulation for this stage!
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Number of {currentLogAnimalConfig.countUnit} Fed
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={logNumAnimals}
                      onChange={e => setLogNumAnimals(parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900 text-base focus:ring-2 focus:ring-emerald-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Total Qty Fed (kg) <span className="font-normal text-slate-400">(Override)</span>
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      placeholder={`Std: ${liveLogCalc.qty} kg`}
                      value={logActualQty === undefined ? "" : logActualQty}
                      onChange={e => setLogActualQty(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                {/* IN-SESSION MORTALITY / SOLD EVENT (AUTO PEN ADJUSTMENT) */}
                <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-2">
                  <div className="flex items-center gap-1.5 text-amber-800 font-black text-[11px]">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                    Record Demise / Sales during Feeding Session
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Mortality (Dead)</label>
                      <input
                        type="number"
                        min="0"
                        value={logMortalityCount}
                        onChange={e => setLogMortalityCount(parseInt(e.target.value) || 0)}
                        className="w-full px-2.5 py-1 rounded-lg border border-amber-300 font-bold text-slate-900 bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Animals Sold</label>
                      <input
                        type="number"
                        min="0"
                        value={logSoldCount}
                        onChange={e => setLogSoldCount(parseInt(e.target.value) || 0)}
                        className="w-full px-2.5 py-1 rounded-lg border border-amber-300 font-bold text-slate-900 bg-white"
                      />
                    </div>
                  </div>
                  {(logMortalityCount > 0 || logSoldCount > 0) && (
                    <p className="text-[10px] text-amber-900 font-semibold">
                      * Pen headcount will auto-decrement by {logMortalityCount + logSoldCount} upon posting.
                    </p>
                  )}
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Operational Notes / Observation</label>
                  <textarea
                    rows={2}
                    placeholder="e.g. Intake good, added extra roughage..."
                    value={logNotes}
                    onChange={e => setLogNotes(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium text-slate-800 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* LIVE TOTAL SUMMARY CARD */}
                <div className="bg-emerald-900 text-white p-4 rounded-xl space-y-1 shadow-inner">
                  <div className="flex items-center justify-between text-xs text-emerald-200 font-semibold">
                    <span>Calculated Feed Cost</span>
                    <span>{liveLogCalc.qty} kg Total</span>
                  </div>
                  <div className="text-2xl font-black text-emerald-400">
                    {currencySymbol} {liveLogCalc.cost.toLocaleString()}
                  </div>
                  <p className="text-[10px] text-emerald-300/80">
                    Will post automatically to COA Feed Expense (Code 5220) and update cost ledger.
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={!activeFormulationForLog}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-extrabold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  Post & Freeze Daily Feed Log
                </button>
              </form>
            </div>

            {/* RECENT DAILY LOGS LIST */}
            <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                    <History className="w-5 h-5 text-emerald-600" />
                    Historical Daily Feed Logs
                  </h3>
                  <p className="text-slate-500 text-xs">Immutable posted daily feed transactions</p>
                </div>

                <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1 rounded-full border border-slate-200">
                  Total Logs: {dailyLogs.length}
                </span>
              </div>

              {dailyLogs.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-300 space-y-3">
                  <Calendar className="w-12 h-12 text-slate-300 mx-auto" />
                  <p className="font-bold text-slate-600 text-sm">No daily feed logs posted yet.</p>
                  <p className="text-slate-400 text-xs max-w-sm mx-auto">
                    Use the feeding log form to record daily feed usage, number of animals fed, and post cost to the farm ledger.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200">
                        <th className="py-3 px-3">Date</th>
                        <th className="py-3 px-3">Species & Stage</th>
                        <th className="py-3 px-3">Cohort / Pen</th>
                        <th className="py-3 px-3 text-right">Animals Fed</th>
                        <th className="py-3 px-3 text-right">Qty (kg)</th>
                        <th className="py-3 px-3 text-right">Total Cost</th>
                        <th className="py-3 px-3">Formulation Snapshot</th>
                        <th className="py-3 px-3 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {dailyLogs.map(log => {
                        const spName = animalTypes.find(a => a.id === log.animalTypeId)?.name || log.animalTypeId;
                        return (
                          <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                            <td className="py-3 px-3 font-bold text-slate-900 whitespace-nowrap">{log.date}</td>
                            <td className="py-3 px-3">
                              <span className="font-bold text-slate-800">{spName}</span>
                              <span className="block text-[10px] text-slate-500 font-semibold capitalize">{log.stageId}</span>
                            </td>
                            <td className="py-3 px-3 font-semibold text-slate-700 whitespace-nowrap">{log.cohortId || "—"}</td>
                            <td className="py-3 px-3 text-right font-black text-slate-900">{log.numberOfAnimalsFed}</td>
                            <td className="py-3 px-3 text-right font-bold text-slate-800">{log.totalQuantityFedKg} kg</td>
                            <td className="py-3 px-3 text-right font-black text-emerald-700 whitespace-nowrap">
                              {currencySymbol} {log.totalCost.toFixed(2)}
                            </td>
                            <td className="py-3 px-3 text-slate-500 text-[11px]">
                              <span className="font-bold text-slate-800 block">v{log.formulationVersion}</span>
                              <span className="text-[10px] font-mono text-slate-500">{currencySymbol} {log.formulationSnapshot.costPerKgMix}/kg</span>
                            </td>
                            <td className="py-3 px-3 text-center">
                              {isAuthorizedToDelete ? (
                                <button
                                  onClick={() => handleDeleteDailyLog(log.id, log.cohortId || spName, log.date)}
                                  className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                                  title="Delete Daily Feed Log (Super Admin & Farm Owner Only)"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              ) : (
                                <button
                                  disabled
                                  className="p-1.5 text-slate-300 cursor-not-allowed rounded-lg"
                                  title="Only Super Admin and Farm Owner can delete daily feeding logs"
                                >
                                  <Trash2 className="w-3.5 h-3.5 opacity-30" />
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: FEED FORMULATIONS & RECIPE BUILDER */}
      {activeTab === "formulations" && (
        <FeedFormulationBuilder
          tenantId={tenantId}
          currencySymbol={currencySymbol}
          animalTypes={animalTypes}
          ingredients={ingredients}
          formulations={formulations}
          onSaveIngredient={(ingData) => {
            saveTenantIngredient(tenantId, ingData, "Farmer Admin");
            refreshData();
          }}
          onSaveFormulation={(formData, options) => {
            saveTenantFormulation(tenantId, formData, "Farm Manager", options);
            refreshData();
          }}
          onDeleteFormulation={(formId) => {
            deleteTenantFormulation(tenantId, formId);
            refreshData();
            toast("Feed formulation removed from tenant catalog.", "info");
          }}
          onDuplicateFormulation={(formId, customName) => {
            const cloned = duplicateTenantFormulation(tenantId, formId, customName);
            refreshData();
            toast(`Duplicated formulation "${cloned.name}"!`, "success");
          }}
          onToggleStatus={(formId, status) => {
            toggleFormulationStatus(tenantId, formId, status);
            refreshData();
            toast(`Formulation status updated to "${status.toUpperCase()}".`, "success");
          }}
          onSetPrimaryActive={(formId) => {
            setPrimaryActiveFormulation(tenantId, formId);
            refreshData();
            toast("Formulation set as primary active recipe for its growth stage!", "success");
          }}
          onResetDefaults={() => {
            resetTenantFormulationsToDefaults(tenantId);
            refreshData();
            toast("Restored tenant feed formulations to standard calibrated agronomic presets.", "success");
          }}
          onShowToast={onShowToast}
        />
      )}

      {/* TAB 3: INGREDIENT MASTER */}
      {activeTab === "ingredients" && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h3 className="font-black text-slate-900 text-lg flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-600" />
                Tenant Feed Ingredients Inventory
              </h3>
              <p className="text-slate-500 text-xs">
                Tenant-scoped ingredient catalog. Edits append to cost history and automatically recalculate active recipes.
              </p>
            </div>

            <button
              onClick={() => setShowAddIngredientModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow transition-all flex items-center gap-2"
            >
              <Plus className="w-4 h-4" /> Add Custom Ingredient
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200">
                  <th className="py-3 px-4">Ingredient Name</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Unit</th>
                  <th className="py-3 px-4 text-right">Current Cost / Unit</th>
                  <th className="py-3 px-4">Cost History Updates</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {ingredients.map(ing => (
                  <tr key={ing.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-900">{ing.name}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700">
                        {ing.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-600">{ing.unit}</td>
                    <td className="py-3 px-4 text-right font-black text-emerald-700 text-sm">
                      {currencySymbol} {ing.currentCostPerUnit.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-slate-500 text-[11px]">
                      {ing.costHistory && ing.costHistory.length > 0 ? (
                        <span>{ing.costHistory.length} price change(s) logged</span>
                      ) : (
                        <span className="text-slate-400">Initial price</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => {
                          setShowEditCostModal(ing);
                          setEditCostValue(ing.currentCostPerUnit);
                        }}
                        className="px-3 py-1 bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 font-bold text-xs rounded-lg transition-colors"
                      >
                        Edit Price
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: COST-TO-DATE LEDGER */}
      {activeTab === "ledger" && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h3 className="font-black text-slate-900 text-lg flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-600" />
                Per-Cohort & Per-Animal Cumulative Feed Cost Ledger
              </h3>
              <p className="text-slate-500 text-xs">
                Transactional rollup automatically updated on daily log posts. Feeds into Sales Tracker margin calculation upon slaughter or sale.
              </p>
            </div>

            <div className="relative">
              <input
                type="text"
                placeholder="Search cohort or animal..."
                value={ledgerSearch}
                onChange={e => setLedgerSearch(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800"
              />
              <Filter className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>

          {ledgers.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs bg-slate-50 rounded-xl border border-slate-200">
              No feed cost ledgers established yet. Post daily feed logs to start building cumulative cost-to-date ledgers.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200">
                    <th className="py-3 px-4">Cohort / Animal ID</th>
                    <th className="py-3 px-4">Species & Stage</th>
                    <th className="py-3 px-4 text-right">Animals Covered</th>
                    <th className="py-3 px-4 text-right">Cum. Quantity (kg)</th>
                    <th className="py-3 px-4 text-right">Cum. Feed Cost</th>
                    <th className="py-3 px-4 text-right">Cost per Animal to Date</th>
                    <th className="py-3 px-4 text-right">Last Feed Log Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {ledgers
                    .filter(l => l.id.toLowerCase().includes(ledgerSearch.toLowerCase()) || l.animalTypeId.toLowerCase().includes(ledgerSearch.toLowerCase()))
                    .map(l => {
                      const spName = animalTypes.find(a => a.id === l.animalTypeId)?.name || l.animalTypeId;
                      return (
                        <tr key={l.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3 px-4 font-black text-slate-900">{l.id}</td>
                          <td className="py-3 px-4">
                            <span className="font-bold text-slate-800">{spName}</span>
                            <span className="block text-[10px] text-slate-500 font-semibold capitalize">{l.stageId}</span>
                          </td>
                          <td className="py-3 px-4 text-right font-bold text-slate-800">{l.animalsCovered}</td>
                          <td className="py-3 px-4 text-right font-bold text-slate-800">{l.cumulativeQuantityKg.toLocaleString()} kg</td>
                          <td className="py-3 px-4 text-right font-black text-emerald-700">
                            {currencySymbol} {l.cumulativeFeedCost.toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-right font-black text-teal-800 text-sm">
                            {currencySymbol} {l.costPerAnimalToDate.toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-right text-slate-500">{l.lastLogDate}</td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 5: GROWTH STAGES CONFIG */}
      {activeTab === "stages" && (
        <GrowthStageConfigManager
          tenantId={tenantId}
          animalTypes={animalTypes}
          onRefreshData={refreshData}
          onShowToast={toast}
        />
      )}

      {/* MODAL 1: EDIT INGREDIENT COST */}
      {showEditCostModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <h3 className="font-black text-slate-900 text-base">Update Unit Cost: {showEditCostModal.name}</h3>
            <p className="text-slate-500 text-xs">
              Updating this ingredient price appends a timestamped history entry and recalculates all active formulations using it. Past daily logs remain frozen.
            </p>

            <div>
              <label className="block font-bold text-slate-700 text-xs mb-1">New Unit Cost ({currencySymbol} / {showEditCostModal.unit})</label>
              <input
                type="number"
                step="0.01"
                value={editCostValue}
                onChange={e => setEditCostValue(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-black text-slate-900 text-lg"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowEditCostModal(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleUpdateIngredientCost}
                className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow"
              >
                Save & Recalculate Formulations
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: ADD CUSTOM INGREDIENT */}
      {showAddIngredientModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <h3 className="font-black text-slate-900 text-base">Add New Feed Ingredient</h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Ingredient Name</label>
                <input
                  type="text"
                  placeholder="e.g. Pig Grower Premix"
                  value={newIngName}
                  onChange={e => setNewIngName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Category</label>
                  <select
                    value={newIngCategory}
                    onChange={e => setNewIngCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800"
                  >
                    <option value="energy">Energy</option>
                    <option value="protein">Protein</option>
                    <option value="mineral">Mineral</option>
                    <option value="vitamin">Vitamin</option>
                    <option value="additive">Additive</option>
                    <option value="roughage">Roughage</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Unit</label>
                  <select
                    value={newIngUnit}
                    onChange={e => setNewIngUnit(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800"
                  >
                    <option value="kg">kg</option>
                    <option value="g">g</option>
                    <option value="litre">litre</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Current Cost per Unit ({currencySymbol})</label>
                <input
                  type="number"
                  step="0.01"
                  value={newIngCost}
                  onChange={e => setNewIngCost(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowAddIngredientModal(false)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateIngredient}
                className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow"
              >
                Save Ingredient
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

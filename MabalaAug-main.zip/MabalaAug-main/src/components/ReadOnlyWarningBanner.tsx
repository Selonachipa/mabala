import React from "react";
import { 
  AlertTriangle, 
  Lock, 
  ShoppingBag, 
  Sprout, 
  CreditCard, 
  Zap, 
  ArrowRight, 
  X,
  ShieldAlert
} from "lucide-react";

export interface ReadOnlyWarningBannerProps {
  /** Optional custom message describing the action that was blocked */
  blockedAction?: string;
  /** Callback to navigate to the Vendor Marketplace */
  onNavigateToMarketplace: () => void;
  /** Callback to navigate to Agronomy Booking / Advisory */
  onNavigateToAgronomy: () => void;
  /** Callback to trigger credit top up modal */
  onTopUpCredits: () => void;
  /** Callback to navigate to Billing / Subscriptions page */
  onActivateSubscription?: () => void;
  /** Optional close / dismiss callback */
  onDismiss?: () => void;
  /** Optional visual variant: 'floating' (modal/toast overlay), 'inline' (within panels), 'banner' (full-width banner) */
  variant?: "floating" | "inline" | "banner";
}

export const ReadOnlyWarningBanner: React.FC<ReadOnlyWarningBannerProps> = ({
  blockedAction,
  onNavigateToMarketplace,
  onNavigateToAgronomy,
  onTopUpCredits,
  onActivateSubscription,
  onDismiss,
  variant = "inline"
}) => {
  if (variant === "floating") {
    return (
      <div 
        id="readonly-action-locked-modal"
        className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-[99999] flex items-center justify-center p-4 animate-fade-in"
      >
        <div className="bg-slate-900 border-2 border-rose-500/80 rounded-3xl shadow-2xl max-w-lg w-full p-6 text-white space-y-5 font-sans relative overflow-hidden">
          {/* Top subtle glow banner */}
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-rose-500 via-amber-500 to-emerald-500" />
          
          {onDismiss && (
            <button
              onClick={onDismiss}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
              title="Close notification"
            >
              <X className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center shrink-0 shadow-inner">
              <Lock className="w-6 h-6" />
            </div>
            <div className="pr-6">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded text-[9px] font-black uppercase tracking-wider">
                  Action Locked
                </span>
                <span className="text-slate-400 text-[10px] font-mono font-bold">0 Operations Credits</span>
              </div>
              <h3 className="text-base font-extrabold text-white mt-1">
                {blockedAction ? `Cannot ${blockedAction}` : "Feature Locked in Read-Only Mode"}
              </h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Your workspace account is in <strong>read-only mode</strong> because operation credits have run out. To make changes or add new records, please top up credits or activate a subscription plan.
              </p>
            </div>
          </div>

          {/* Action links */}
          <div className="space-y-2.5 pt-1">
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Restore Full Write Operations</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => {
                  if (onDismiss) onDismiss();
                  onTopUpCredits();
                }}
                className="w-full px-4 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl font-extrabold text-xs flex items-center justify-center gap-2 transition shadow-lg shadow-amber-500/20 cursor-pointer"
              >
                <CreditCard className="w-4 h-4" />
                <span>Top Up Credits</span>
              </button>

              {onActivateSubscription ? (
                <button
                  type="button"
                  onClick={() => {
                    if (onDismiss) onDismiss();
                    onActivateSubscription();
                  }}
                  className="w-full px-4 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-extrabold text-xs flex items-center justify-center gap-2 transition shadow-lg shadow-indigo-600/20 cursor-pointer"
                >
                  <Zap className="w-4 h-4" />
                  <span>Activate Subscription</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    if (onDismiss) onDismiss();
                    onTopUpCredits();
                  }}
                  className="w-full px-4 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition border border-slate-700 cursor-pointer"
                >
                  <span>Pay Subscription</span>
                </button>
              )}
            </div>
          </div>

          {/* Unlocked services section */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase text-emerald-400 tracking-wider flex items-center gap-1.5">
                <span>✓ Always Unlocked & Available (0 Credits Needed)</span>
              </span>
              <span className="text-[9px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded font-mono font-bold">100% FREE ACCESS</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-normal">
              You still have full unrestricted access to purchase farm supplies and schedule on-site agronomy experts:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  if (onDismiss) onDismiss();
                  onNavigateToMarketplace();
                }}
                className="p-2.5 bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/40 text-emerald-300 rounded-xl text-xs font-bold flex items-center justify-between transition cursor-pointer group"
              >
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4 text-emerald-400" />
                  <span>Vendor Marketplace</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                type="button"
                onClick={() => {
                  if (onDismiss) onDismiss();
                  onNavigateToAgronomy();
                }}
                className="p-2.5 bg-teal-950/60 hover:bg-teal-900/80 border border-teal-500/40 text-teal-300 rounded-xl text-xs font-bold flex items-center justify-between transition cursor-pointer group"
              >
                <div className="flex items-center gap-2">
                  <Sprout className="w-4 h-4 text-teal-400" />
                  <span>Book Agronomist</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (variant === "banner") {
    return (
      <div 
        id="readonly-warning-banner-full"
        className="w-full bg-gradient-to-r from-rose-950 via-slate-900 to-slate-950 border-y sm:border border-rose-500/40 text-white p-3.5 sm:p-4 rounded-none sm:rounded-2xl shadow-lg font-sans"
      >
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3.5">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-xl shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-rose-300">
                  Read-Only Mode Active (0 Credits)
                </span>
                <span className="bg-rose-500 text-white text-[9px] font-mono px-2 py-0.5 rounded font-black uppercase">
                  Records Locked
                </span>
              </div>
              <p className="text-[11px] text-slate-300 font-medium mt-1 leading-relaxed max-w-3xl">
                {blockedAction ? (
                  <span>Cannot <strong>{blockedAction}</strong>. </span>
                ) : null}
                Editing and creating farm records is locked until credits are replenished. You can <strong>Top Up Credits</strong> or <strong>Activate a Subscription</strong> to regain full write capabilities. Purchasing agro-inputs and booking agronomists remain 100% active.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto shrink-0 justify-end">
            <button
              type="button"
              onClick={onNavigateToMarketplace}
              className="px-3 py-1.5 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/50 text-emerald-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-emerald-400" />
              <span>Vendor Marketplace</span>
            </button>

            <button
              type="button"
              onClick={onNavigateToAgronomy}
              className="px-3 py-1.5 bg-teal-950/80 hover:bg-teal-900 border border-teal-500/50 text-teal-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Sprout className="w-3.5 h-3.5 text-teal-400" />
              <span>Book Agronomist</span>
            </button>

            <button
              type="button"
              onClick={onTopUpCredits}
              className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-black flex items-center gap-1.5 transition shadow-sm cursor-pointer"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Top Up Credits</span>
            </button>

            {onActivateSubscription && (
              <button
                type="button"
                onClick={onActivateSubscription}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 transition shadow-sm cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Pay Subscription</span>
              </button>
            )}

            {onDismiss && (
              <button
                type="button"
                onClick={onDismiss}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg transition"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Default 'inline' card
  return (
    <div 
      id="readonly-warning-banner-inline"
      className="bg-gradient-to-r from-rose-950 via-slate-900 to-slate-900 border-2 border-rose-500/40 p-4.5 rounded-2xl text-white shadow-lg space-y-3 font-sans"
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-xl shrink-0">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-extrabold text-xs uppercase tracking-wider text-rose-300">
                Write Feature Locked (Read-Only Mode)
              </h4>
              <span className="bg-rose-500 text-white text-[9px] font-mono px-2 py-0.5 rounded font-black uppercase">
                0 Credits
              </span>
            </div>
            <p className="text-[11px] text-slate-300 font-medium mt-1 leading-relaxed">
              {blockedAction ? (
                <span>Cannot <strong>{blockedAction}</strong>. </span>
              ) : null}
              Operations credits are depleted. Please <strong>Top Up Credits</strong> or <strong>Activate a Subscription</strong> to restore write access. Marketplace buying and agronomist bookings remain fully accessible.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0 w-full sm:w-auto">
          <button
            type="button"
            onClick={onNavigateToMarketplace}
            className="flex-1 sm:flex-none px-3 py-1.5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-emerald-400" />
            <span>Vendor Marketplace</span>
          </button>

          <button
            type="button"
            onClick={onNavigateToAgronomy}
            className="flex-1 sm:flex-none px-3 py-1.5 bg-teal-950 hover:bg-teal-900 border border-teal-500/40 text-teal-300 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Sprout className="w-3.5 h-3.5 text-teal-400" />
            <span>Book Agronomist</span>
          </button>

          <button
            type="button"
            onClick={onTopUpCredits}
            className="flex-1 sm:flex-none px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-xl transition shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Top Up Credits</span>
          </button>

          {onActivateSubscription && (
            <button
              type="button"
              onClick={onActivateSubscription}
              className="flex-1 sm:flex-none px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl transition shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Pay Subscription</span>
            </button>
          )}

          {onDismiss && (
            <button
              type="button"
              onClick={onDismiss}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg transition ml-auto sm:ml-0"
              title="Dismiss"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReadOnlyWarningBanner;

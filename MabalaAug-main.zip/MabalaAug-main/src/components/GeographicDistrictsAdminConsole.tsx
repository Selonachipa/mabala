import React, { useState, useEffect } from "react";
import { 
  MapPin, 
  Plus, 
  Trash2, 
  Edit3, 
  RotateCcw, 
  Save, 
  Search, 
  CheckCircle2, 
  AlertCircle, 
  Download, 
  Upload, 
  Layers 
} from "lucide-react";
import { 
  DEFAULT_ZAMBIA_DISTRICTS, 
  ZambiaProvincesMap, 
  getZambiaDistrictsRegistry, 
  saveZambiaDistrictsRegistry, 
  resetZambiaDistrictsRegistry 
} from "../config/zambiaDistricts";
import { db, isConfigured } from "../firebase";
import { doc, setDoc, getDoc } from "firebase/firestore";

interface GeographicDistrictsAdminConsoleProps {
  onNotify?: (msg: string, type: "success" | "error" | "info") => void;
}

export const GeographicDistrictsAdminConsole: React.FC<GeographicDistrictsAdminConsoleProps> = ({ onNotify }) => {
  const [registry, setRegistry] = useState<ZambiaProvincesMap>(getZambiaDistrictsRegistry());
  const [selectedProvince, setSelectedProvince] = useState<string>("Central");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [newDistrictName, setNewDistrictName] = useState<string>("");
  const [newProvinceName, setNewProvinceName] = useState<string>("");
  const [editingDistrict, setEditingDistrict] = useState<{ province: string; oldName: string; newName: string } | null>(null);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Load from Firestore if available
  useEffect(() => {
    const loadFromFirestore = async () => {
      if (isConfigured && db) {
        try {
          const docRef = doc(db, "system_config", "zambia_districts");
          const snap = await getDoc(docRef);
          if (snap.exists()) {
            const data = snap.data() as { registry?: ZambiaProvincesMap };
            if (data?.registry && Object.keys(data.registry).length > 0) {
              setRegistry(data.registry);
              saveZambiaDistrictsRegistry(data.registry);
            }
          }
        } catch (e) {
          console.warn("[GeographicDistricts] Failed to fetch remote config:", e);
        }
      }
    };
    loadFromFirestore();
  }, []);

  const showStatus = (text: string, type: "success" | "error" = "success") => {
    setStatusMessage({ text, type });
    if (onNotify) onNotify(text, type);
    setTimeout(() => setStatusMessage(null), 4000);
  };

  const provinces = Object.keys(registry).sort((a, b) => a.localeCompare(b));
  const totalDistrictsCount = Object.values(registry).reduce((acc: number, curr: any) => acc + (Array.isArray(curr) ? curr.length : 0), 0);

  // Add District to currently selected province
  const handleAddDistrict = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newDistrictName.trim();
    if (!cleanName) return;

    if (!selectedProvince || !registry[selectedProvince]) {
      showStatus("Please select a valid province first.", "error");
      return;
    }

    const currentDistricts = registry[selectedProvince] || [];
    if (currentDistricts.some(d => d.toLowerCase() === cleanName.toLowerCase())) {
      showStatus(`District "${cleanName}" already exists in ${selectedProvince} Province.`, "error");
      return;
    }

    const updated = {
      ...registry,
      [selectedProvince]: [...currentDistricts, cleanName].sort((a, b) => a.localeCompare(b))
    };

    setRegistry(updated);
    saveZambiaDistrictsRegistry(updated);
    setNewDistrictName("");
    showStatus(`Added "${cleanName}" to ${selectedProvince} Province.`);
  };

  // Add a new Province
  const handleAddProvince = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newProvinceName.trim();
    if (!cleanName) return;

    if (registry[cleanName]) {
      showStatus(`Province "${cleanName}" already exists.`, "error");
      return;
    }

    const updated = {
      ...registry,
      [cleanName]: []
    };

    setRegistry(updated);
    saveZambiaDistrictsRegistry(updated);
    setSelectedProvince(cleanName);
    setNewProvinceName("");
    showStatus(`Created new Province: "${cleanName}".`);
  };

  // Delete District
  const handleDeleteDistrict = (province: string, districtName: string) => {
    if (!window.confirm(`Are you sure you want to remove district "${districtName}" from ${province} Province?`)) {
      return;
    }

    const currentDistricts = registry[province] || [];
    const updated = {
      ...registry,
      [province]: currentDistricts.filter(d => d !== districtName)
    };

    setRegistry(updated);
    saveZambiaDistrictsRegistry(updated);
    showStatus(`Removed district "${districtName}".`);
  };

  // Edit / Rename District
  const handleSaveDistrictRename = () => {
    if (!editingDistrict) return;
    const { province, oldName, newName } = editingDistrict;
    const cleanNew = newName.trim();

    if (!cleanNew) {
      showStatus("District name cannot be empty.", "error");
      return;
    }

    const currentDistricts = registry[province] || [];
    if (cleanNew !== oldName && currentDistricts.some(d => d.toLowerCase() === cleanNew.toLowerCase())) {
      showStatus(`District "${cleanNew}" already exists in ${province} Province.`, "error");
      return;
    }

    const updated = {
      ...registry,
      [province]: currentDistricts.map(d => (d === oldName ? cleanNew : d)).sort((a, b) => a.localeCompare(b))
    };

    setRegistry(updated);
    saveZambiaDistrictsRegistry(updated);
    setEditingDistrict(null);
    showStatus(`Renamed "${oldName}" to "${cleanNew}".`);
  };

  // Save to Cloud Firestore
  const handleSaveToCloud = async () => {
    setIsSaving(true);
    try {
      saveZambiaDistrictsRegistry(registry);
      if (isConfigured && db) {
        const docRef = doc(db, "system_config", "zambia_districts");
        await setDoc(docRef, {
          registry,
          updatedAt: new Date().toISOString(),
          updatedBy: "Super Admin",
          totalDistricts: totalDistrictsCount,
          totalProvinces: provinces.length
        }, { merge: true });
      }
      showStatus("Successfully synchronized and deployed districts registry globally.");
    } catch (e: any) {
      console.error("Failed to save to cloud:", e);
      showStatus(`Failed to sync to cloud: ${e.message}`, "error");
    } finally {
      setIsSaving(false);
    }
  };

  // Reset to default statutory 116 districts
  const handleResetToDefaults = () => {
    if (window.confirm("Reset all boundaries to official statutory Zambian 10 provinces & 116 districts? Any custom additions will be reverted.")) {
      resetZambiaDistrictsRegistry();
      setRegistry(DEFAULT_ZAMBIA_DISTRICTS);
      showStatus("Reset registry to official 10 provinces and 116 gazetted districts.");
    }
  };

  // Export JSON
  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(registry, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `zambia_districts_registry_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Filter districts
  const activeDistricts = registry[selectedProvince] || [];
  const filteredDistricts = activeDistricts.filter(d => 
    d.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div id="geographic-districts-admin-console" className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
      {/* Header with Stats & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
              <MapPin className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
                Zambia Geographic Boundaries & District Registry
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Live configuration for Signup, Tenant Farm Nodes, Report Centre, and Super Admin filters without needing code deployments.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportJson}
            className="px-3 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
            title="Export JSON backup"
          >
            <Download className="w-3.5 h-3.5" /> Export JSON
          </button>
          <button
            onClick={handleResetToDefaults}
            className="px-3 py-2 text-xs font-bold text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
            title="Reset to 10 provinces and 116 gazetted districts"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset to 116 Defaults
          </button>
          <button
            onClick={handleSaveToCloud}
            disabled={isSaving}
            className="px-4 py-2 text-xs font-black text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-sm transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <Save className="w-3.5 h-3.5" /> {isSaving ? "Saving..." : "Deploy & Sync Globally"}
          </button>
        </div>
      </div>

      {statusMessage && (
        <div className={`p-3 rounded-xl flex items-center gap-2 text-xs font-semibold animate-fade-in ${
          statusMessage.type === "success" ? "bg-emerald-50 text-emerald-800 border border-emerald-200" : "bg-red-50 text-red-800 border border-red-200"
        }`}>
          {statusMessage.type === "success" ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-red-600" />}
          {statusMessage.text}
        </div>
      )}

      {/* Overview Stat Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
          <span className="text-[10px] uppercase font-extrabold text-slate-400 block tracking-wider">Total Provinces</span>
          <span className="text-xl font-black text-slate-800">{provinces.length} Provinces</span>
        </div>
        <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
          <span className="text-[10px] uppercase font-extrabold text-slate-400 block tracking-wider">Total Gazetted Districts</span>
          <span className="text-xl font-black text-emerald-700">{totalDistrictsCount} Districts</span>
        </div>
        <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
          <span className="text-[10px] uppercase font-extrabold text-slate-400 block tracking-wider">Selected Province</span>
          <span className="text-xl font-black text-indigo-900">{selectedProvince}</span>
        </div>
        <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
          <span className="text-[10px] uppercase font-extrabold text-slate-400 block tracking-wider">Districts in {selectedProvince}</span>
          <span className="text-xl font-black text-slate-800">{activeDistricts.length} Districts</span>
        </div>
      </div>

      {/* Main Province & District Manager */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Column: Province Selection & Creation */}
        <div className="md:col-span-4 space-y-4">
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
            <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-emerald-600" />
              1. Select Province ({provinces.length})
            </h4>

            <div className="space-y-1 max-h-72 overflow-y-auto pr-1">
              {provinces.map((prov) => {
                const count = (registry[prov] || []).length;
                const isSelected = prov === selectedProvince;
                return (
                  <button
                    key={prov}
                    onClick={() => setSelectedProvince(prov)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold transition flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? "bg-emerald-600 text-white shadow-sm"
                        : "bg-white text-slate-700 hover:bg-slate-100 border border-slate-200/60"
                    }`}
                  >
                    <span>{prov}</span>
                    <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-full ${
                      isSelected ? "bg-emerald-800/60 text-white" : "bg-slate-100 text-slate-600"
                    }`}>
                      {count} dist.
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Form to add a new province if statutory boundaries expand */}
            <form onSubmit={handleAddProvince} className="pt-3 border-t border-slate-200 space-y-2">
              <label className="text-[10px] uppercase font-bold text-slate-500 block">Add New Province</label>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  placeholder="e.g. Copperbelt North"
                  value={newProvinceName}
                  onChange={(e) => setNewProvinceName(e.target.value)}
                  className="w-full text-xs p-2 border border-slate-300 rounded-lg bg-white font-medium outline-none focus:border-emerald-500"
                />
                <button
                  type="submit"
                  className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg shrink-0 transition"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Right Column: Districts List for Selected Province */}
        <div className="md:col-span-8 space-y-4">
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/70 pb-3">
              <div>
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">
                  2. Manage Districts in {selectedProvince} ({filteredDistricts.length})
                </h4>
                <p className="text-[11px] text-slate-500 font-medium">
                  Add, rename, or reassign gazetted administrative districts for this province.
                </p>
              </div>

              {/* Search input */}
              <div className="relative w-full sm:w-48">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search districts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:border-emerald-500 font-medium"
                />
              </div>
            </div>

            {/* Add District Input */}
            <form onSubmit={handleAddDistrict} className="flex gap-2">
              <input
                type="text"
                placeholder={`Enter new district name for ${selectedProvince}...`}
                value={newDistrictName}
                onChange={(e) => setNewDistrictName(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-lg bg-white font-medium outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
              />
              <button
                type="submit"
                className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold rounded-lg shrink-0 transition flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Add District
              </button>
            </form>

            {/* Districts Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-96 overflow-y-auto pr-1">
              {filteredDistricts.length === 0 ? (
                <div className="col-span-full py-8 text-center text-xs text-slate-400 italic bg-white border border-dashed border-slate-200 rounded-lg">
                  No districts match the search filter.
                </div>
              ) : (
                filteredDistricts.map((district) => {
                  const isEditing = editingDistrict?.province === selectedProvince && editingDistrict?.oldName === district;

                  return (
                    <div
                      key={district}
                      className="p-2.5 bg-white border border-slate-200 rounded-lg flex items-center justify-between gap-2 shadow-xs group hover:border-emerald-300 transition"
                    >
                      {isEditing ? (
                        <div className="flex items-center gap-1 w-full">
                          <input
                            type="text"
                            value={editingDistrict.newName}
                            onChange={(e) => setEditingDistrict({ ...editingDistrict, newName: e.target.value })}
                            className="w-full text-xs p-1 border rounded bg-slate-50 font-semibold text-slate-800"
                            autoFocus
                            onKeyDown={(e) => {
                              if (e.key === "Enter") handleSaveDistrictRename();
                              if (e.key === "Escape") setEditingDistrict(null);
                            }}
                          />
                          <button
                            onClick={handleSaveDistrictRename}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="Save"
                          >
                            <Save className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingDistrict(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            title="Cancel"
                          >
                            <AlertCircle className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <span className="text-xs font-bold text-slate-800 truncate" title={district}>
                            {district}
                          </span>
                          <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition">
                            <button
                              onClick={() => setEditingDistrict({ province: selectedProvince, oldName: district, newName: district })}
                              className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded cursor-pointer"
                              title="Rename District"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteDistrict(selectedProvince, district)}
                              className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded cursor-pointer"
                              title="Delete District"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GeographicDistrictsAdminConsole;

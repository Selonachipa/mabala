import React, { useState } from "react";
import {
  X,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Calendar,
  Building2,
  Lock,
  Wallet,
  ArrowDownLeft,
  DollarSign
} from "lucide-react";
import { DdaccMandate, approveDdaccMandate, rejectDdaccMandate } from "../../services/ddaccLoanService";

import { safeFormatError } from "../../utils/errorUtils";

interface DdaccApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  mandate: DdaccMandate | null;
  onApprovalComplete: (res: any) => void;
  farmerLedgerBalance?: number;
  currencySymbol?: string;
}

export const DdaccApprovalModal: React.FC<DdaccApprovalModalProps> = ({
  isOpen,
  onClose,
  mandate,
  onApprovalComplete,
  farmerLedgerBalance = 0,
  currencySymbol = "ZK"
}) => {
  const [signatureName, setSignatureName] = useState(mandate?.farmerName || "Sula Shikasuli");
  const [hasAgreedToTerms, setHasAgreedToTerms] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !mandate) return null;

  const handleApprove = async () => {
    if (!hasAgreedToTerms) {
      setError("Please check the authorization box to agree to the DDACC auto-deduction terms.");
      return;
    }
    if (!signatureName.trim()) {
      setError("Please provide your digital signature name.");
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      const res = await approveDdaccMandate({
        mandateId: mandate.id,
        signatureName,
        farmerTenantId: mandate.farmerTenantId
      });

      onApprovalComplete(res);
      onClose();
    } catch (err: any) {
      setError(safeFormatError(err, "Failed to approve DDACC mandate."));
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReject = async () => {
    if (!confirm("Are you sure you want to decline this loan and DDACC mandate?")) return;
    setIsProcessing(true);
    try {
      const res = await rejectDdaccMandate(mandate.id, "Declined by farmer");
      onApprovalComplete({ success: true, mandate: res, rejected: true });
      onClose();
    } catch (err: any) {
      setError(safeFormatError(err, "Failed to decline mandate."));
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-8">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-teal-900 to-slate-900 p-6 text-white flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-black rounded-full uppercase tracking-wider border border-emerald-500/30">
                Direct Debit & Credit Clearing (DDACC)
              </span>
              <span className="text-xs text-emerald-200/70 font-mono">
                Mandate Ref: {mandate.id}
              </span>
            </div>
            <h3 className="text-xl font-black flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-emerald-400" />
              Acknowledge & Authorize DDACC Loan Deduction
            </h3>
            <p className="text-xs text-emerald-100/80 mt-1 max-w-lg">
              Review loan terms issued by <strong>{mandate.lenderName}</strong> and authorize automatic clearing against your Mabala Ledger (Account 1020).
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-slate-800 font-sans max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-xs font-semibold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{safeFormatError(error)}</span>
            </div>
          )}

          {/* LOAN SUMMARY CARD */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
            <div className="flex justify-between items-center border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-700" />
                <span className="font-extrabold text-xs text-slate-900">{mandate.lenderName}</span>
              </div>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold">
                {mandate.lenderType.replace("_", " ")}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div>
                <span className="text-slate-400 text-[10px] block">Principal Loan</span>
                <strong className="text-slate-900 text-sm font-black">
                  {currencySymbol} {mandate.principalAmount.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                </strong>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">Total Repayable</span>
                <strong className="text-emerald-900 text-sm font-black">
                  {currencySymbol} {mandate.totalRepayable.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                </strong>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">Scheduled Installment</span>
                <strong className="text-slate-900 text-sm font-bold">
                  {currencySymbol} {mandate.repaymentInstallmentAmount.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                </strong>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">Frequency</span>
                <strong className="text-slate-700 text-xs font-bold uppercase">
                  {mandate.repaymentFrequency}
                </strong>
              </div>
            </div>

            {mandate.inputBasketDescription && (
              <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs text-slate-600">
                <span className="font-bold text-slate-800">Purpose / Disbursed Inputs: </span>
                {mandate.inputBasketDescription}
              </div>
            )}
          </div>

          {/* MABALA LEDGER (ACCOUNT 1020) BALANCE AUDIT */}
          <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                <Wallet className="w-5 h-5" />
              </div>
              <div>
                <div className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-900">
                  Mabala Ledger & Mobile Money Balance (Account 1020)
                </div>
                <div className="text-xs text-emerald-700 mt-0.5">
                  Current Liquid Funds Available for Auto-Deduction
                </div>
              </div>
            </div>
            <div className="text-right font-mono">
              <div className="text-lg font-black text-emerald-900">
                {currencySymbol} {farmerLedgerBalance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] text-emerald-700 font-bold">
                {farmerLedgerBalance >= mandate.repaymentInstallmentAmount
                  ? "✓ Sufficient Balance for Scheduled Installment"
                  : "ℹ Will auto-deduct when funds are topped up or harvest deposited"}
              </div>
            </div>
          </div>

          {/* DDACC LEGAL MANDATE AGREEMENT CLAUSE */}
          <div className="p-4 bg-slate-100 rounded-2xl border border-slate-300 text-xs text-slate-700 space-y-2 leading-relaxed">
            <div className="font-black text-slate-900 uppercase text-[11px] flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-emerald-700" />
              <span>DDACC Direct Debit & Credit Clearing Legal Mandate</span>
            </div>
            <p>
              I, <strong>{signatureName || mandate.farmerName}</strong> (NRC: {mandate.farmerNrc || "On File"}), hereby acknowledge receipt of the loan terms above and formally grant irrevocable authorization to the <strong>Mabala DDACC Clearing Engine</strong> to automatically deduct <strong>{currencySymbol} {mandate.repaymentInstallmentAmount.toFixed(2)}</strong> ({mandate.repaymentFrequency}) from my <strong>Mabala Ledger (Account 1020)</strong> and Mobile Money balance until the total balance of <strong>{currencySymbol} {mandate.totalRepayable.toFixed(2)}</strong> owed to <strong>{mandate.lenderName}</strong> is fully settled.
            </p>
            <div className="text-[11px] text-slate-500 font-mono">
              Platform Fee Settlement Mode: {mandate.platformFeeMode === "per_transaction" ? "Deducted Per-Transaction" : "Monthly Deferred Settlement"} • Fee: 2.5%
            </div>
          </div>

          {/* SIGNATURE & AUTHORIZATION CHECKBOX */}
          <div className="space-y-3 pt-2">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Authorized Digital Signature (Full Legal Name)
              </label>
              <input
                type="text"
                value={signatureName}
                onChange={e => setSignatureName(e.target.value)}
                placeholder="Enter your full name as digital signature"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <label className="flex items-start gap-2.5 cursor-pointer p-3 bg-emerald-50/50 border border-emerald-200 rounded-xl">
              <input
                type="checkbox"
                checked={hasAgreedToTerms}
                onChange={e => setHasAgreedToTerms(e.target.checked)}
                className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
              />
              <span className="text-xs text-slate-800 font-medium">
                I understand and agree to the DDACC terms. I authorize automatic deductions from my Mabala Ledger balance for this loan.
              </span>
            </label>
          </div>

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-100 flex justify-between items-center gap-3">
            <button
              type="button"
              onClick={handleReject}
              disabled={isProcessing}
              className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-800 font-bold text-xs rounded-xl transition cursor-pointer border border-rose-200"
            >
              Decline Loan
            </button>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleApprove}
                disabled={isProcessing || !hasAgreedToTerms}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-black text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer"
              >
                {isProcessing ? (
                  <span>Authorizing Mandate...</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Acknowledge & Authorize DDACC</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

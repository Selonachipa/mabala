import React, { useState, useEffect, useMemo } from "react";
import {
  ShieldCheck,
  Zap,
  Building2,
  Calendar,
  Layers,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  ArrowUpRight,
  ArrowDownLeft,
  Plus,
  RefreshCw,
  Wallet,
  Receipt,
  FileSpreadsheet,
  DollarSign,
  Users,
  Check,
  X,
  CreditCard,
  Lock,
  ChevronRight,
  Sparkles
} from "lucide-react";
import {
  DdaccMandate,
  DdaccClearingRecord,
  MonthlyPlatformFeeStatement,
  getDdaccMandates,
  getDdaccClearingHistory,
  executeDdaccAutoDeduction,
  executeAllDueDdaccClearing,
  toggleDdaccAutoDeduct,
  getMonthlyPlatformFeeStatements,
  settleMonthlyPlatformFees,
  LenderType
} from "../../services/ddaccLoanService";
import { getWalletBalances } from "../../services/walletService";
import { DdaccIssueLoanModal } from "./DdaccIssueLoanModal";
import { DdaccApprovalModal } from "./DdaccApprovalModal";
import { PlatformFarmer } from "../agc/DealerCreditPOS";
import { useSuperAdmin } from "../../hooks/useSuperAdmin";

interface DdaccManagementDeskProps {
  role?: "farmer" | "dealer" | "supplier" | "admin";
  farmerTenantId?: string;
  dealerTenantId?: string;
  currencySymbol?: string;
  activeFarmers?: PlatformFarmer[];
  onLedgerUpdated?: () => void;
}

export const DdaccManagementDesk: React.FC<DdaccManagementDeskProps> = ({
  role = "farmer",
  farmerTenantId = "TENANT-001",
  dealerTenantId = "dealer-choma-01",
  currencySymbol = "ZK",
  activeFarmers = [],
  onLedgerUpdated
}) => {
  const [mandates, setMandates] = useState<DdaccMandate[]>([]);
  const [clearingLogs, setClearingLogs] = useState<DdaccClearingRecord[]>([]);
  const [monthlyStatements, setMonthlyStatements] = useState<MonthlyPlatformFeeStatement[]>([]);

  const [activeSubTab, setActiveSubTab] = useState<"MANDATES" | "CLEARING_AUDIT" | "MONTHLY_FEES">("MANDATES");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");

  // Modals
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [selectedMandateForApproval, setSelectedMandateForApproval] = useState<DdaccMandate | null>(null);

  // Clearing Run State
  const [isRunningClearingSweep, setIsRunningClearingSweep] = useState(false);
  const [clearingNotification, setClearingNotification] = useState<{
    type: "success" | "error" | "info";
    message: string;
  } | null>(null);

  // Farmer Ledger Balance (Account 1020)
  const [farmerLedgerBal, setFarmerLedgerBal] = useState<number>(() => {
    return getWalletBalances(farmerTenantId).lipilaBalance;
  });

  const loadData = () => {
    const isFarmer = role === "farmer";
    const allMandates = getDdaccMandates(
      isFarmer ? { farmerTenantId } : { lenderId: dealerTenantId }
    );
    setMandates(allMandates);

    const allLogs = getDdaccClearingHistory(
      isFarmer ? { farmerTenantId } : { lenderId: dealerTenantId }
    );
    setClearingLogs(allLogs);

    const stmts = getMonthlyPlatformFeeStatements(isFarmer ? undefined : dealerTenantId);
    setMonthlyStatements(stmts);

    const bal = getWalletBalances(farmerTenantId).lipilaBalance;
    setFarmerLedgerBal(bal);
  };

  useEffect(() => {
    loadData();

    const handleUpdate = () => {
      loadData();
    };

    window.addEventListener("mabala_ddacc_update", handleUpdate);
    window.addEventListener("mabala_wallet_update", handleUpdate);
    window.addEventListener("storage", handleUpdate);

    return () => {
      window.removeEventListener("mabala_ddacc_update", handleUpdate);
      window.removeEventListener("mabala_wallet_update", handleUpdate);
      window.removeEventListener("storage", handleUpdate);
    };
  }, [role, farmerTenantId, dealerTenantId]);

  // Pending mandates that need farmer approval
  const pendingApprovals = useMemo(() => {
    return mandates.filter(m => m.farmerApprovalStatus === "pending" && m.status === "pending_approval");
  }, [mandates]);

  const activeMandates = useMemo(() => {
    return mandates.filter(m => m.farmerApprovalStatus === "approved" && m.status === "active");
  }, [mandates]);

  const totalOutstandingLoanBalance = useMemo(() => {
    return activeMandates.reduce((acc, m) => acc + m.balanceRemaining, 0);
  }, [activeMandates]);

  const filteredMandates = useMemo(() => {
    return mandates.filter(m => {
      const matchesSearch =
        m.lenderName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.farmerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.loanId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.id.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus =
        statusFilter === "ALL" ||
        (statusFilter === "PENDING" && m.farmerApprovalStatus === "pending") ||
        (statusFilter === "ACTIVE" && m.status === "active") ||
        (statusFilter === "REPAID" && m.status === "repaid");

      return matchesSearch && matchesStatus;
    });
  }, [mandates, searchTerm, statusFilter]);

  // Execute DDACC Auto-Clearing Sweep
  const handleRunClearingSweep = async () => {
    setIsRunningClearingSweep(true);
    setClearingNotification(null);

    try {
      const res = await executeAllDueDdaccClearing(role === "farmer" ? farmerTenantId : undefined);
      loadData();
      if (onLedgerUpdated) onLedgerUpdated();

      if (res.successCount > 0) {
        setClearingNotification({
          type: "success",
          message: `DDACC Clearing Sweep Complete! Auto-deducted ZMW ${res.totalDeducted.toFixed(2)} across ${res.successCount} active loan mandate(s) from Mabala Ledger (Account 1020).`
        });
      } else if (res.processedCount === 0) {
        setClearingNotification({
          type: "info",
          message: "No active DDACC loan mandates due for auto-clearing at this time."
        });
      } else {
        setClearingNotification({
          type: "error",
          message: `DDACC auto-clearing check ran: ${res.results[0]?.message || "Insufficient funds in Mabala Ledger (Account 1020)."}`
        });
      }
    } catch (err: any) {
      setClearingNotification({
        type: "error",
        message: err.message || "Failed to execute DDACC clearing sweep."
      });
    } finally {
      setIsRunningClearingSweep(false);
    }
  };

  // Single Mandate Instant Auto-Deduct
  const handleSingleAutoDeduct = async (mandateId: string) => {
    try {
      const res = await executeDdaccAutoDeduction(mandateId);
      loadData();
      if (onLedgerUpdated) onLedgerUpdated();
      setClearingNotification({
        type: "success",
        message: res.message
      });
    } catch (err: any) {
      setClearingNotification({
        type: "error",
        message: err.message || "Auto-deduction failed."
      });
    }
  };

  // Toggle Auto Deduct on Mandate
  const handleToggleAutoDeduct = async (mandateId: string, currentVal: boolean) => {
    try {
      await toggleDdaccAutoDeduct(mandateId, !currentVal);
      loadData();
    } catch (err: any) {
      alert("Failed to toggle auto-deduction: " + err.message);
    }
  };

  const { isSuperAdmin } = useSuperAdmin();
  const isSuperAdminUser = isSuperAdmin || role === "admin";

  // Farmer-specific active DDACC loans (must only show active loans that have DDACC activated)
  const farmerActiveDdaccLoans = useMemo(() => {
    return mandates.filter(m => m.farmerApprovalStatus === "approved" && m.status === "active");
  }, [mandates]);

  return (
    <div className="space-y-6 text-slate-900 font-sans" id="ddacc-management-desk">
      {/* 1. HERO CLEARING ENGINE CONTROL BANNER */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-teal-950 p-6 rounded-3xl text-white shadow-xl border border-emerald-900/60 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 text-[10px] font-black rounded-full uppercase tracking-wider border border-emerald-500/30 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Direct Debit & Credit Clearing (DDACC) Active</span>
            </span>
            <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950 px-2.5 py-0.5 rounded border border-emerald-800">
              Account 1020 • Mabala Farm Ledger
            </span>
          </div>

          <h2 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
            <Zap className="w-6 h-6 text-emerald-400" />
            <span>{isSuperAdminUser ? "DDACC Farm Ledger Auto-Deduction Desk" : "My Active DDACC Loans & Auto-Deductions"}</span>
          </h2>
          <p className="text-xs text-emerald-100/80 max-w-2xl leading-relaxed">
            {isSuperAdminUser
              ? "Direct Debit and Credit Clearing (DDACC) is enabled on all farm ledgers. Suppliers & Agro-Dealers issue input loans with auto-deduction, which farmers acknowledge and approve. Repayments are auto-deducted directly from Mabala Ledger (Account 1020) balance."
              : "Your active input loans with approved DDACC auto-deductions. Scheduled loan repayments are automatically cleared from your Mabala Ledger (Account 1020)."}
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {isSuperAdminUser ? (
            <>
              <button
                onClick={handleRunClearingSweep}
                disabled={isRunningClearingSweep}
                className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer border border-emerald-300"
              >
                <RefreshCw className={`w-4 h-4 text-slate-950 ${isRunningClearingSweep ? "animate-spin" : ""}`} />
                <span>{isRunningClearingSweep ? "Executing Sweep..." : "Run DDACC Clearing Sweep"}</span>
              </button>

              <button
                onClick={() => setShowIssueModal(true)}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-black text-xs rounded-xl shadow-sm transition flex items-center gap-2 cursor-pointer border border-white/20"
              >
                <Plus className="w-4 h-4 text-emerald-300" />
                <span>+ Issue DDACC Loan</span>
              </button>
            </>
          ) : (
            <button
              onClick={loadData}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-black text-xs rounded-xl shadow-sm transition flex items-center gap-2 cursor-pointer border border-white/20"
            >
              <RefreshCw className="w-4 h-4 text-emerald-300" />
              <span>Refresh Loan Ledger</span>
            </button>
          )}
        </div>
      </div>

      {/* NOTIFICATION TOAST / BANNER */}
      {clearingNotification && (
        <div
          className={`p-4 rounded-2xl border text-xs font-semibold flex items-center justify-between gap-3 animate-in fade-in duration-200 ${
            clearingNotification.type === "success"
              ? "bg-emerald-50 border-emerald-200 text-emerald-900"
              : clearingNotification.type === "error"
              ? "bg-rose-50 border-rose-200 text-rose-900"
              : "bg-indigo-50 border-indigo-200 text-indigo-900"
          }`}
        >
          <div className="flex items-center gap-2.5">
            {clearingNotification.type === "success" ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : clearingNotification.type === "error" ? (
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            ) : (
              <Zap className="w-4 h-4 text-indigo-600 shrink-0" />
            )}
            <span>{clearingNotification.message}</span>
          </div>
          <button
            onClick={() => setClearingNotification(null)}
            className="p-1 hover:bg-slate-200/50 rounded-lg text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 2. STATS STRIP */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Stat 1: Mabala Ledger Balance */}
        <div className="bg-white p-5 rounded-2xl border border-emerald-200 shadow-xs space-y-1">
          <div className="flex justify-between items-center text-[10px] font-black uppercase text-emerald-800 tracking-wider">
            <span>Mabala Ledger (1020) Balance</span>
            <Wallet className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black font-mono text-slate-900">
            {currencySymbol} {farmerLedgerBal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="text-[10.5px] text-slate-500">Liquid balance available for instant auto-deduction.</p>
        </div>

        {/* Stat 2: Active DDACC Mandates */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <div className="flex justify-between items-center text-[10px] font-black uppercase text-slate-500 tracking-wider">
            <span>Active DDACC Mandates</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black font-mono text-slate-900">
            {activeMandates.length} Mandates
          </div>
          <p className="text-[10.5px] text-slate-500">Authorized & active for automatic clearing.</p>
        </div>

        {/* Stat 3: Total Outstanding Loan Balance */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <div className="flex justify-between items-center text-[10px] font-black uppercase text-amber-700 tracking-wider">
            <span>Total Outstanding Loans</span>
            <DollarSign className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black font-mono text-amber-900">
            {currencySymbol} {totalOutstandingLoanBalance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="text-[10.5px] text-slate-500">Owed across accredited agro-dealers & suppliers.</p>
        </div>

        {/* Stat 4: Pending Approvals Banner */}
        <div className={`p-5 rounded-2xl border shadow-xs space-y-1 transition-all ${
          pendingApprovals.length > 0
            ? "bg-amber-50/80 border-amber-300"
            : "bg-white border-slate-200"
        }`}>
          <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-wider text-amber-800">
            <span>Pending Farmer Approvals</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black font-mono text-amber-900">
            {pendingApprovals.length} Awaiting
          </div>
          <p className="text-[10.5px] text-slate-600">
            {pendingApprovals.length > 0 ? "Requires farmer authorization to activate." : "All loan mandates acknowledged."}
          </p>
        </div>
      </div>

      {/* 3. PENDING APPROVALS ALERT CAROUSEL (IF ANY PENDING) */}
      {pendingApprovals.length > 0 && (
        <div className="bg-amber-50/90 border border-amber-300 rounded-3xl p-6 space-y-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="p-2 bg-amber-200 text-amber-900 rounded-xl">
                <Clock className="w-5 h-5" />
              </span>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-amber-950">
                  Loan Repayment Mandates Awaiting Farmer Acknowledgment & Approval
                </h3>
                <p className="text-xs text-amber-800">
                  You have {pendingApprovals.length} pending DDACC loan mandate(s). The farmer must review and approve before auto-deductions begin.
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pendingApprovals.map(mandate => (
              <div
                key={mandate.id}
                className="bg-white rounded-2xl border border-amber-200 p-5 space-y-3 shadow-xs"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                      Ref: {mandate.loanId}
                    </span>
                    <h4 className="font-extrabold text-slate-900 text-sm mt-1">
                      {mandate.lenderName}
                    </h4>
                    <p className="text-[11px] text-slate-500">{mandate.farmerName}</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-amber-100 text-amber-800 font-mono">
                    Pending Approval
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl text-xs font-mono">
                  <div>
                    <span className="text-[9.5px] text-slate-400 block uppercase">Principal</span>
                    <strong className="text-slate-900">{currencySymbol} {mandate.principalAmount.toLocaleString()}</strong>
                  </div>
                  <div>
                    <span className="text-[9.5px] text-slate-400 block uppercase">Installment</span>
                    <strong className="text-emerald-800">{currencySymbol} {mandate.repaymentInstallmentAmount.toLocaleString()}</strong>
                  </div>
                  <div>
                    <span className="text-[9.5px] text-slate-400 block uppercase">Fee Mode</span>
                    <strong className="text-indigo-800 uppercase text-[10px]">{mandate.platformFeeMode.replace("_", " ")}</strong>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedMandateForApproval(mandate)}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Review & Acknowledge DDACC Mandate</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. MAIN NAVIGATION SUB-TABS (SUPER ADMIN) OR ACTIVE LOANS TABLE (NORMAL FARMER) */}
      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
        {isSuperAdminUser ? (
          <div className="flex border-b border-slate-200 bg-slate-50/70 p-2 gap-2 flex-wrap">
            <button
              onClick={() => setActiveSubTab("MANDATES")}
              className={`px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 ${
                activeSubTab === "MANDATES"
                  ? "bg-white text-slate-900 shadow-sm border border-slate-200/80"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Active DDACC Mandates & Loans ({mandates.length})</span>
            </button>

            <button
              onClick={() => setActiveSubTab("CLEARING_AUDIT")}
              className={`px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 ${
                activeSubTab === "CLEARING_AUDIT"
                  ? "bg-white text-slate-900 shadow-sm border border-slate-200/80"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Receipt className="w-4 h-4 text-indigo-600" />
              <span>DDACC Clearing & Auto-Deduction Audit ({clearingLogs.length})</span>
            </button>

            <button
              onClick={() => setActiveSubTab("MONTHLY_FEES")}
              className={`px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 ${
                activeSubTab === "MONTHLY_FEES"
                  ? "bg-white text-slate-900 shadow-sm border border-slate-200/80"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <CreditCard className="w-4 h-4 text-amber-600" />
              <span>Monthly Platform Fee Statements ({monthlyStatements.length})</span>
            </button>
          </div>
        ) : (
          <div className="p-4 bg-slate-50/70 border-b border-slate-200 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span className="text-xs font-black uppercase text-slate-800 tracking-wider">
                My Active Loans (DDACC Activated)
              </span>
            </div>
            <span className="text-[11px] font-mono text-emerald-700 font-bold bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              {farmerActiveDdaccLoans.length} Active Mandate(s)
            </span>
          </div>
        )}

        {/* SUB-TAB 1: ACTIVE DDACC MANDATES & LOANS */}
        {(activeSubTab === "MANDATES" || !isSuperAdminUser) && (
          <div className="p-6 space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  placeholder="Search lender, farmer, or loan ID..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {isSuperAdminUser ? (
                <div className="flex items-center gap-2 flex-wrap">
                  <select
                    value={statusFilter}
                    onChange={e => setStatusFilter(e.target.value)}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700"
                  >
                    <option value="ALL">All Statuses</option>
                    <option value="ACTIVE">Active & Approved</option>
                    <option value="PENDING">Pending Approval</option>
                    <option value="REPAID">Fully Repaid</option>
                  </select>

                  <button
                    onClick={loadData}
                    className="p-2 hover:bg-slate-100 rounded-xl text-slate-500 transition"
                    title="Refresh Data"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={loadData}
                  className="p-2 hover:bg-slate-100 rounded-xl text-slate-500 transition flex items-center gap-1.5 text-xs font-bold"
                  title="Refresh Data"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Refresh</span>
                </button>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-600 font-extrabold text-[10.5px] uppercase tracking-wider border-b border-slate-200">
                    <th className="p-3">Loan ID & Lender</th>
                    <th className="p-3">{isSuperAdminUser ? "Farmer & Farm" : "Input Basket / Purpose"}</th>
                    <th className="p-3 text-right">Principal & Interest</th>
                    <th className="p-3 text-right">Remaining Balance</th>
                    <th className="p-3 text-right">Installment</th>
                    <th className="p-3 text-center">Auto-Deduct DDACC</th>
                    {isSuperAdminUser && <th className="p-3 text-center">Platform Fee Mode</th>}
                    <th className="p-3 text-center">Status</th>
                    {isSuperAdminUser && <th className="p-3 text-center">Action</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {(isSuperAdminUser ? filteredMandates : farmerActiveDdaccLoans).length === 0 ? (
                    <tr>
                      <td colSpan={isSuperAdminUser ? 9 : 7} className="p-8 text-center text-slate-400 italic">
                        {isSuperAdminUser
                          ? "No DDACC loan mandates found matching your search."
                          : "You currently have no active DDACC loans linked to your farm ledger. Loans approved under DDACC will appear here."}
                      </td>
                    </tr>
                  ) : (
                    (isSuperAdminUser ? filteredMandates : farmerActiveDdaccLoans).map(mandate => {
                      const isApproved = mandate.farmerApprovalStatus === "approved";
                      const isRepaid = mandate.status === "repaid" || mandate.balanceRemaining <= 0;

                      return (
                        <tr key={mandate.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-3 space-y-0.5">
                            <div className="font-mono font-bold text-slate-900">{mandate.loanId}</div>
                            <div className="text-[11px] text-slate-700 font-bold flex items-center gap-1">
                              <Building2 className="w-3 h-3 text-emerald-700 shrink-0" />
                              <span>{mandate.lenderName}</span>
                            </div>
                          </td>

                          <td className="p-3 space-y-0.5">
                            {isSuperAdminUser ? (
                              <>
                                <div className="font-bold text-slate-900">{mandate.farmerName}</div>
                                <div className="text-[10px] text-slate-400 font-mono">{mandate.farmerPhone}</div>
                              </>
                            ) : (
                              <>
                                <div className="font-bold text-slate-900">{mandate.metadata?.basketDescription || "Farm Input Package"}</div>
                                <div className="text-[10px] text-slate-500 font-mono">
                                  Next Clearing: {mandate.nextDeductionDate ? new Date(mandate.nextDeductionDate).toLocaleDateString() : "Scheduled"}
                                </div>
                              </>
                            )}
                          </td>

                          <td className="p-3 text-right font-mono">
                            <div className="font-bold text-slate-900">
                              {currencySymbol} {mandate.principalAmount.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                            </div>
                            <div className="text-[10px] text-emerald-700 font-bold">
                              {mandate.interestRate}% ({mandate.interestType ? mandate.interestType.replace("_", " ") : "Flat"})
                            </div>
                          </td>

                          <td className="p-3 text-right font-mono font-black">
                            <span className={isRepaid ? "text-slate-400" : "text-amber-800"}>
                              {currencySymbol} {mandate.balanceRemaining.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                            </span>
                          </td>

                          <td className="p-3 text-right font-mono">
                            <div className="font-bold text-slate-900">
                              {currencySymbol} {mandate.repaymentInstallmentAmount.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                            </div>
                            <div className="text-[10px] text-slate-400 uppercase">{mandate.repaymentFrequency}</div>
                          </td>

                          {/* DDACC Auto-Deduct Toggle */}
                          <td className="p-3 text-center">
                            {isSuperAdminUser ? (
                              <button
                                type="button"
                                onClick={() => handleToggleAutoDeduct(mandate.id, mandate.autoDeductEnabled)}
                                disabled={isRepaid}
                                className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase transition cursor-pointer font-mono ${
                                  mandate.autoDeductEnabled
                                    ? "bg-emerald-100 text-emerald-800 hover:bg-emerald-200"
                                    : "bg-slate-100 text-slate-500 hover:bg-slate-200"
                                }`}
                              >
                                {mandate.autoDeductEnabled ? "✓ Auto-Deduct ON" : "✕ Disabled"}
                              </button>
                            ) : (
                              <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase font-mono bg-emerald-100 text-emerald-800">
                                ✓ Auto-Deduct ON
                              </span>
                            )}
                          </td>

                          {/* Platform Fee Settlement Mode (Super Admin only) */}
                          {isSuperAdminUser && (
                            <td className="p-3 text-center">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-black uppercase font-mono ${
                                  mandate.platformFeeMode === "per_transaction"
                                    ? "bg-indigo-50 text-indigo-800 border border-indigo-200"
                                    : "bg-emerald-50 text-emerald-800 border border-emerald-200"
                                }`}
                              >
                                {mandate.platformFeeMode === "per_transaction" ? "Per-Tx Fee" : "Month-End Fee"}
                              </span>
                            </td>
                          )}

                          {/* Farmer Approval Status */}
                          <td className="p-3 text-center">
                            <span
                              className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                                isRepaid
                                  ? "bg-slate-100 text-slate-700"
                                  : isApproved
                                  ? "bg-emerald-100 text-emerald-800"
                                  : "bg-amber-100 text-amber-800 animate-pulse"
                              }`}
                            >
                              {isRepaid ? (
                                <span>SETTLED</span>
                              ) : isApproved ? (
                                <>
                                  <Check className="w-3 h-3 text-emerald-600" />
                                  <span>ACTIVE</span>
                                </>
                              ) : (
                                <>
                                  <Clock className="w-3 h-3 text-amber-600" />
                                  <span>PENDING</span>
                                </>
                              )}
                            </span>
                          </td>

                          {/* Actions (Super Admin only) */}
                          {isSuperAdminUser && (
                            <td className="p-3 text-center">
                              {!isApproved ? (
                                <button
                                  onClick={() => setSelectedMandateForApproval(mandate)}
                                  className="px-3 py-1 bg-amber-600 hover:bg-amber-500 text-white font-extrabold text-[10.5px] rounded-lg transition cursor-pointer shadow-xs"
                                >
                                  Approve Mandate
                                </button>
                              ) : !isRepaid ? (
                                <button
                                  onClick={() => handleSingleAutoDeduct(mandate.id)}
                                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-[10.5px] rounded-lg transition cursor-pointer flex items-center justify-center gap-1 shadow-xs mx-auto"
                                >
                                  <Zap className="w-3 h-3 text-emerald-200" />
                                  <span>Auto-Deduct Now</span>
                                </button>
                              ) : (
                                <span className="text-slate-400 font-mono text-[10px]">Closed</span>
                              )}
                            </td>
                          )}
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* SUB-TAB 2: DDACC CLEARING & AUTO-DEDUCTION AUDIT LEDGER */}
        {activeSubTab === "CLEARING_AUDIT" && (
          <div className="p-6 space-y-4">
            <div className="flex justify-between items-center flex-wrap gap-2">
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-emerald-600" />
                  <span>DDACC Clearing Audit Ledger (Account 1020 Auto-Debits)</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Immutable execution records of automated loan deductions from farmer Mabala Ledgers to suppliers & agro-dealers.
                </p>
              </div>
              <button
                onClick={loadData}
                className="p-2 hover:bg-slate-100 rounded-xl text-slate-500 transition"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-600 font-extrabold text-[10.5px] uppercase tracking-wider border-b border-slate-200">
                    <th className="p-3">Clearing Ref & Date</th>
                    <th className="p-3">Farmer & Lender</th>
                    <th className="p-3 text-right">Gross Deducted</th>
                    <th className="p-3 text-right">Platform Fee (2.5%)</th>
                    <th className="p-3 text-right">Net Remitted to Lender</th>
                    <th className="p-3">Debited Ledger Account</th>
                    <th className="p-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {clearingLogs.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-400 italic">
                        No DDACC clearing records executed yet. Run a clearing sweep or make an auto-deduction above!
                      </td>
                    </tr>
                  ) : (
                    clearingLogs.map(log => (
                      <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-3 space-y-0.5 font-mono">
                          <div className="font-bold text-slate-900">{log.id}</div>
                          <div className="text-[10px] text-slate-400">
                            {new Date(log.clearingDate).toLocaleString()}
                          </div>
                        </td>

                        <td className="p-3 space-y-0.5">
                          <div className="font-bold text-slate-900">{log.farmerName}</div>
                          <div className="text-[11px] text-emerald-800 font-bold">
                            → {log.lenderName}
                          </div>
                        </td>

                        <td className="p-3 text-right font-mono font-black text-slate-900">
                          {currencySymbol} {log.deductionAmount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        <td className="p-3 text-right font-mono text-indigo-800 font-bold">
                          {currencySymbol} {log.platformFeeAmount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          <div className="text-[9.5px] text-slate-400 font-normal uppercase">
                            {log.platformFeeMode === "per_transaction" ? "Per-Tx Settled" : "Month-End Accrued"}
                          </div>
                        </td>

                        <td className="p-3 text-right font-mono font-black text-emerald-800">
                          {currencySymbol} {log.lenderReceivedAmount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        <td className="p-3 font-mono text-slate-600 text-[11px]">
                          <span className="px-2 py-0.5 bg-slate-100 rounded text-[10px] font-bold text-slate-800">
                            {log.accountDebited || "1020 - Mabala Ledger"}
                          </span>
                        </td>

                        <td className="p-3 text-center">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                              log.status === "SUCCESS"
                                ? "bg-emerald-100 text-emerald-800"
                                : "bg-rose-100 text-rose-800"
                            }`}
                          >
                            {log.status === "SUCCESS" ? (
                              <>
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                <span>CLEARED</span>
                              </>
                            ) : (
                              <>
                                <AlertTriangle className="w-3 h-3 text-rose-600" />
                                <span>FAILED</span>
                              </>
                            )}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* SUB-TAB 3: MONTHLY DEFERRED PLATFORM FEE STATEMENTS */}
        {activeSubTab === "MONTHLY_FEES" && (
          <div className="p-6 space-y-4">
            <div className="flex justify-between items-center flex-wrap gap-2">
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-amber-600" />
                  <span>Month-End Platform Fee Settlement Statements</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Aggregated platform fees for agro-dealers and suppliers who selected whole repayment receipt with month-end fee consolidation.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {monthlyStatements.length === 0 ? (
                <div className="col-span-2 p-8 text-center text-slate-400 bg-slate-50 rounded-2xl border border-slate-200">
                  No month-end fee statements generated yet.
                </div>
              ) : (
                monthlyStatements.map(stmt => {
                  const isSettled = stmt.settlementStatus === "paid_settled";

                  return (
                    <div
                      key={stmt.id}
                      className="bg-slate-50 rounded-2xl border border-slate-200 p-5 space-y-4 shadow-2xs"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="text-[10px] font-mono font-bold uppercase text-slate-500 bg-slate-200 px-2 py-0.5 rounded">
                            Billing Period: {stmt.monthYear}
                          </span>
                          <h4 className="font-extrabold text-slate-900 text-sm mt-1">
                            {stmt.lenderName}
                          </h4>
                        </div>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                            isSettled
                              ? "bg-emerald-100 text-emerald-800"
                              : "bg-amber-100 text-amber-800"
                          }`}
                        >
                          {isSettled ? "Settled ✓" : "Due for Settlement"}
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-2 bg-white p-3 rounded-xl border border-slate-200 text-xs font-mono">
                        <div>
                          <span className="text-[9.5px] text-slate-400 block uppercase">Processed Volume</span>
                          <strong className="text-slate-900">
                            {currencySymbol} {stmt.totalProcessedRepaymentsVolume.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                          </strong>
                        </div>
                        <div>
                          <span className="text-[9.5px] text-slate-400 block uppercase">Repayments</span>
                          <strong className="text-slate-800">{stmt.repaymentsCount} Tx</strong>
                        </div>
                        <div>
                          <span className="text-[9.5px] text-slate-400 block uppercase">Platform Fee Owed</span>
                          <strong className="text-rose-700 font-black">
                            {currencySymbol} {stmt.totalPlatformFeesAccrued.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                          </strong>
                        </div>
                      </div>

                      {!isSettled && (
                        <button
                          onClick={async () => {
                            try {
                              await settleMonthlyPlatformFees(stmt.id);
                              loadData();
                              alert(`Successfully settled monthly platform fees of ${currencySymbol} ${stmt.totalPlatformFeesAccrued.toFixed(2)} via Lipila!`);
                            } catch (e: any) {
                              alert("Settlement error: " + e.message);
                            }
                          }}
                          className="w-full py-2.5 bg-slate-900 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                        >
                          <Zap className="w-4 h-4 text-emerald-400" />
                          <span>Settle Platform Fees via Lipila Mobile Money</span>
                        </button>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}
      </div>

      {/* 5. MODALS */}
      <DdaccIssueLoanModal
        isOpen={showIssueModal}
        onClose={() => setShowIssueModal(false)}
        onLoanIssued={() => {
          loadData();
          setClearingNotification({
            type: "success",
            message: "Loan issued successfully! A DDACC mandate request has been sent for farmer acknowledgment and approval."
          });
        }}
        lenderType={role === "supplier" ? "supplier" : "agro_dealer"}
        lenderId={dealerTenantId}
        lenderName={role === "supplier" ? "Zamseed / Agro Supplier" : "Choma Agro-Supply Hub & Depot"}
        currencySymbol={currencySymbol}
        activeFarmers={activeFarmers}
      />

      <DdaccApprovalModal
        isOpen={!!selectedMandateForApproval}
        onClose={() => setSelectedMandateForApproval(null)}
        mandate={selectedMandateForApproval}
        farmerLedgerBalance={farmerLedgerBal}
        currencySymbol={currencySymbol}
        onApprovalComplete={res => {
          loadData();
          if (onLedgerUpdated) onLedgerUpdated();
          if (res.rejected) {
            setClearingNotification({
              type: "info",
              message: "Loan mandate declined."
            });
          } else {
            setClearingNotification({
              type: "success",
              message: "DDACC mandate approved! Auto-deductions are now active on your Mabala Ledger (Account 1020)."
            });
          }
        }}
      />
    </div>
  );
};

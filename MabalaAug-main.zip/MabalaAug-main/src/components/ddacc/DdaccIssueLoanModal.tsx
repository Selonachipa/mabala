import React, { useState, useMemo, useEffect } from "react";
import {
  X,
  Search,
  Check,
  ShieldCheck,
  Zap,
  Building2,
  Calendar,
  Layers,
  HelpCircle,
  ToggleLeft,
  ToggleRight,
  Info,
  CheckCircle2,
  Users,
  Coins,
  Percent,
  CreditCard,
  Receipt
} from "lucide-react";
import {
  issueDdaccLoan,
  calculateLoanRepayment,
  PlatformFeeMode,
  RepaymentFrequency,
  LenderType,
  InterestType
} from "../../services/ddaccLoanService";
import { safeFormatError } from "../../utils/errorUtils";
import { PlatformFarmer } from "../agc/DealerCreditPOS";

interface ActiveLoanRecord {
  loanId: string;
  farmerId: string;
  farmerName: string;
  principal: number;
  balanceRemaining: number;
  status: string;
  lenderName?: string;
  createdAt?: string;
}

interface DdaccIssueLoanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoanIssued: (mandate: any) => void;
  lenderType?: LenderType;
  lenderId?: string;
  lenderName?: string;
  currencySymbol?: string;
  activeFarmers?: PlatformFarmer[];
}

export const DdaccIssueLoanModal: React.FC<DdaccIssueLoanModalProps> = ({
  isOpen,
  onClose,
  onLoanIssued,
  lenderType = "agro_dealer",
  lenderId = "dealer-choma-01",
  lenderName = "Choma Agro-Supply Hub & Depot",
  currencySymbol = "ZK",
  activeFarmers = []
}) => {
  // Farmer search state
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedFarmer, setSelectedFarmer] = useState<PlatformFarmer | null>(null);

  // Manual fallback farmer inputs
  const [manualFarmerName, setManualFarmerName] = useState("");
  const [manualFarmerPhone, setManualFarmerPhone] = useState("");
  const [manualFarmerNrc, setManualFarmerNrc] = useState("");
  const [manualFarmName, setManualFarmName] = useState("");

  // Loan parameters
  const [principalAmount, setPrincipalAmount] = useState<number>(3500);
  const [interestType, setInterestType] = useState<InterestType>("reducing_balance");
  const [interestRatePct, setInterestRatePct] = useState<number>(2.0);
  const [tenureMonths, setTenureMonths] = useState<number>(3);
  const [repaymentFrequency, setRepaymentFrequency] = useState<RepaymentFrequency>("monthly");
  const [inputBasketDescription, setInputBasketDescription] = useState(
    "Compound D Fertilizer (5x 50kg) & SC 627 Certified Maize Seed"
  );

  // DDACC Settings
  const [autoDeductEnabled, setAutoDeductEnabled] = useState<boolean>(true);
  const [platformFeeMode, setPlatformFeeMode] = useState<PlatformFeeMode>("per_transaction");

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load registered farmers & active loans from real storage
  const [platformLoans, setPlatformLoans] = useState<ActiveLoanRecord[]>([]);

  useEffect(() => {
    try {
      const allLoans: ActiveLoanRecord[] = [];
      const storedLoans = localStorage.getItem("mabala_loans");
      if (storedLoans) {
        const parsed = JSON.parse(storedLoans);
        if (Array.isArray(parsed)) {
          parsed.forEach((l: any) => {
            if (l.farmerName || l.farmerId) {
              allLoans.push({
                loanId: l.id || l.loanId || `LOAN-${Date.now()}`,
                farmerId: l.farmerId || l.farmerTenantId || "TENANT-001",
                farmerName: l.farmerName || "Farmer",
                principal: Number(l.principal || l.amount || l.principalAmount || 0),
                balanceRemaining: Number(l.balanceRemaining || l.outstandingBalance || l.principal || l.amount || 0),
                status: l.status || "active",
                lenderName: l.lenderName || "Agro Dealer"
              });
            }
          });
        }
      }

      const dealerLoans = localStorage.getItem("mabala_dealer_credit_pos_loans");
      if (dealerLoans) {
        const parsed = JSON.parse(dealerLoans);
        if (Array.isArray(parsed)) {
          parsed.forEach((l: any) => {
            allLoans.push({
              loanId: l.id || l.loanId || `LOAN-POS-${Date.now()}`,
              farmerId: l.farmerId || "TENANT-001",
              farmerName: l.farmerName || "Farmer",
              principal: Number(l.principal || l.totalAmount || 0),
              balanceRemaining: Number(l.balanceRemaining || l.principal || 0),
              status: l.status || "active",
              lenderName: l.lenderName || "Choma Agro Depot"
            });
          });
        }
      }

      setPlatformLoans(allLoans);
    } catch (_) {}
  }, [isOpen]);

  // Clean real farmer list without dummy/test entries
  const farmersList = useMemo(() => {
    if (activeFarmers && activeFarmers.length > 0) return activeFarmers;
    
    // Check if real registered farmers exist in localStorage
    try {
      const storedFarmers = localStorage.getItem("mabala_registered_farmers");
      if (storedFarmers) {
        const parsed = JSON.parse(storedFarmers);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((f: any) => ({
            id: f.id || f.tenantId || `farmer-${Date.now()}`,
            name: f.name || f.fullName || "Registered Farmer",
            farmName: f.farmName || f.businessName || "Registered Farm",
            phone: f.phone || f.phoneNumber || "",
            nrc: f.nrc || "Pending NRC",
            location: f.location || f.province || "Zambia",
            creditScore: f.creditScore || 700,
            creditBand: f.creditBand || "Prime A",
            source: "Registered Farmers Database"
          }));
        }
      }
    } catch (_) {}

    // Baseline current user's farm if available
    const activeFarmName = localStorage.getItem("mabala_active_farm_name") || "Valley Organic Farms - Mazabuka";
    const userPhone = localStorage.getItem("mabala_user_phone") || "+260977123456";
    const userNrc = localStorage.getItem("mabala_user_nrc") || "348912/11/1";

    return [
      {
        id: "TENANT-001",
        name: "Sula Shikasuli",
        farmName: activeFarmName,
        phone: userPhone,
        nrc: userNrc,
        location: "Mazabuka, Southern Province",
        creditScore: 715,
        creditBand: "Prime A",
        source: "Primary Farm Node"
      }
    ];
  }, [activeFarmers]);

  const filteredFarmers = useMemo(() => {
    if (!searchTerm.trim()) return farmersList;
    const q = searchTerm.toLowerCase();
    return farmersList.filter(
      f =>
        f.name.toLowerCase().includes(q) ||
        (f.phone && f.phone.toLowerCase().includes(q)) ||
        (f.nrc && f.nrc.toLowerCase().includes(q)) ||
        (f.farmName && f.farmName.toLowerCase().includes(q))
    );
  }, [farmersList, searchTerm]);

  // Calculations using calculateLoanRepayment with interest type
  const { totalRepayable: calculatedTotalRepayable, installmentAmount: calculatedInstallment, totalInterest: calculatedInterest } = useMemo(() => {
    return calculateLoanRepayment(
      principalAmount || 0,
      interestRatePct || 0,
      tenureMonths || 1,
      interestType
    );
  }, [principalAmount, interestRatePct, tenureMonths, interestType]);

  const estimatedPlatformFeePerTx = useMemo(() => {
    return Number((calculatedInstallment * 0.025).toFixed(2));
  }, [calculatedInstallment]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const farmerId = selectedFarmer ? selectedFarmer.id : `farmer-${Date.now()}`;
    const farmerName = selectedFarmer ? selectedFarmer.name : manualFarmerName;
    const farmerPhone = selectedFarmer ? selectedFarmer.phone : manualFarmerPhone;
    const farmerNrc = selectedFarmer ? selectedFarmer.nrc : manualFarmerNrc;
    const farmerFarmName = selectedFarmer ? selectedFarmer.farmName : manualFarmName;

    if (!farmerName.trim()) {
      setError("Please search and select a farmer or enter the farmer name.");
      return;
    }
    if (!principalAmount || principalAmount <= 0) {
      setError("Please pick or specify a valid principal loan amount greater than 0.");
      return;
    }

    setIsSubmitting(true);
    try {
      const mandate = await issueDdaccLoan({
        farmerTenantId: farmerId,
        farmerName,
        farmerPhone: farmerPhone || "",
        farmerNrc,
        farmerFarmName,
        lenderType: (lenderType as LenderType) || "agro_dealer",
        lenderId,
        lenderName,
        principalAmount,
        interestType,
        interestRatePct,
        tenureMonths,
        repaymentFrequency,
        autoDeductEnabled,
        platformFeeMode,
        inputBasketDescription
      });

      onLoanIssued(mandate);
      onClose();
    } catch (err: any) {
      setError(safeFormatError(err, "Failed to issue loan with DDACC mandate."));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-3xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-8">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-teal-950 p-6 text-white flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-black rounded-full uppercase tracking-wider border border-emerald-500/30">
                DDACC Loan Origination Engine
              </span>
              <span className="text-xs text-emerald-200/70 font-mono">
                Lender: {lenderName}
              </span>
            </div>
            <h3 className="text-xl font-black flex items-center gap-2">
              <Zap className="w-5 h-5 text-emerald-400" />
              Issue Supplier / Agro-Dealer Loan with DDACC
            </h3>
            <p className="text-xs text-emerald-100/80 mt-1 max-w-xl">
              Search the farmer with active loans, pick principal amount, configure compound or reducing balance interest, and activate DDACC auto-clearing.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto text-slate-800 font-sans">
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-xs font-semibold flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-rose-600"></span>
              <span>{safeFormatError(error)}</span>
            </div>
          )}

          {/* STEP 1: SEARCH & SELECT FARMER */}
          <div className="space-y-3">
            <label className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center justify-between">
              <span>1. Search & Select Farmer for DDACC Activation</span>
              <span className="text-[11px] text-emerald-700 font-bold">
                {selectedFarmer ? `Selected: ${selectedFarmer.name} ✓` : "Search by Name, Phone, or NRC"}
              </span>
            </label>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                placeholder="Search registered farmers with active loans (e.g. Sula Shikasuli, Mazabuka, 0977...)"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Farmer Results Grid / Selection */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-52 overflow-y-auto p-1">
              {filteredFarmers.map(farmer => {
                const isSelected = selectedFarmer?.id === farmer.id;
                const activeLoansForFarmer = platformLoans.filter(
                  l => l.farmerId === farmer.id || l.farmerName.toLowerCase().includes(farmer.name.toLowerCase())
                );
                const hasActiveLoans = activeLoansForFarmer.length > 0;

                return (
                  <div
                    key={farmer.id}
                    onClick={() => {
                      setSelectedFarmer(farmer);
                      setManualFarmerName(farmer.name);
                      setManualFarmerPhone(farmer.phone);
                      setManualFarmerNrc(farmer.nrc);
                      setManualFarmName(farmer.farmName || "");
                      if (hasActiveLoans && activeLoansForFarmer[0].balanceRemaining > 0) {
                        setPrincipalAmount(activeLoansForFarmer[0].balanceRemaining);
                      }
                    }}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? "bg-emerald-50/90 border-emerald-500 shadow-xs ring-1 ring-emerald-500"
                        : "bg-slate-50 hover:bg-slate-100/80 border-slate-200"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="space-y-0.5">
                        <div className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                          <Users className="w-3.5 h-3.5 text-emerald-700" />
                          <span>{farmer.name}</span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono truncate max-w-[180px]">
                          {farmer.farmName || farmer.location || "Farm Plot"}
                        </div>
                        <div className="text-[9.5px] text-slate-400 font-mono">
                          {farmer.phone} • NRC: {farmer.nrc}
                        </div>
                      </div>
                      <div className="text-right space-y-1">
                        <span className="px-2 py-0.5 rounded-full text-[9.5px] font-black uppercase bg-emerald-100 text-emerald-800 font-mono">
                          Score {farmer.creditScore}
                        </span>
                        {isSelected && (
                          <div className="text-emerald-700 font-black text-xs flex justify-end">
                            <Check className="w-4 h-4" />
                          </div>
                        )}
                      </div>
                    </div>

                    {hasActiveLoans && (
                      <div className="mt-2 pt-2 border-t border-emerald-200/60 flex items-center justify-between text-[10px] text-emerald-900 bg-emerald-100/60 p-1.5 rounded-lg">
                        <span className="font-semibold flex items-center gap-1">
                          <Receipt className="w-3 h-3 text-emerald-700" />
                          Active Loan: {activeLoansForFarmer[0].loanId}
                        </span>
                        <strong className="font-mono text-emerald-950">
                          {currencySymbol} {activeLoansForFarmer[0].balanceRemaining.toFixed(2)}
                        </strong>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* STEP 2: LOAN PRINCIPAL PICKER & INTEREST CALCULATION */}
          <div className="space-y-4 pt-4 border-t border-slate-100">
            <label className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center justify-between">
              <span>2. Pick Principal Amount & Interest Model</span>
              <span className="text-[10px] text-emerald-700 font-bold">
                Compound / Reducing Balance Supported
              </span>
            </label>

            {/* Quick Principal Picker */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold text-slate-600 block">
                Quick-Pick Principal Amount ({currencySymbol}):
              </span>
              <div className="flex flex-wrap gap-2">
                {[1000, 2500, 3500, 5000, 7500, 10000].map(amt => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setPrincipalAmount(amt)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black font-mono transition cursor-pointer ${
                      principalAmount === amt
                        ? "bg-emerald-700 text-white shadow-xs"
                        : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                    }`}
                  >
                    {currencySymbol} {amt.toLocaleString()}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Principal Amount ({currencySymbol})
                </label>
                <div className="relative">
                  <Coins className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="number"
                    min="50"
                    step="50"
                    value={principalAmount}
                    onChange={e => setPrincipalAmount(Number(e.target.value))}
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Interest Calculation Type
                </label>
                <select
                  value={interestType}
                  onChange={e => setInterestType(e.target.value as InterestType)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="reducing_balance">Reducing Balance (Amortized)</option>
                  <option value="compound">Compound Interest</option>
                  <option value="flat">Flat Rate Interest</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Interest Rate (% p.a.)
                </label>
                <div className="relative">
                  <Percent className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="number"
                    min="0"
                    step="0.5"
                    value={interestRatePct}
                    onChange={e => setInterestRatePct(Number(e.target.value))}
                    className="w-full pl-8 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Tenure / Term (Months)
                </label>
                <select
                  value={tenureMonths}
                  onChange={e => setTenureMonths(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value={1}>1 Month (Short Bullet)</option>
                  <option value={3}>3 Months (Seasonal Input)</option>
                  <option value={6}>6 Months (Full Crop Cycle)</option>
                  <option value={12}>12 Months (Extended Term)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                Input Basket / Loan Purpose Description
              </label>
              <input
                type="text"
                value={inputBasketDescription}
                onChange={e => setInputBasketDescription(e.target.value)}
                placeholder="e.g. 5x 50kg Urea Fertilizer, Hybrid Seed Maize, Crop Spray"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Repayment Summary Box */}
            <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-2xl flex flex-wrap justify-between items-center gap-4 text-xs font-mono">
              <div>
                <span className="text-slate-500 text-[11px] block">
                  Total Repayable ({interestType === "reducing_balance" ? "Reducing Bal." : interestType === "compound" ? "Compound" : "Flat Rate"}):
                </span>
                <strong className="text-emerald-900 text-base font-black">
                  {currencySymbol} {calculatedTotalRepayable.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                </strong>
                <span className="text-[10px] text-slate-500 block">
                  Interest: {currencySymbol} {calculatedInterest.toFixed(2)}
                </span>
              </div>
              <div>
                <span className="text-slate-500 text-[11px] block">Monthly Installment:</span>
                <strong className="text-slate-900 text-sm font-extrabold">
                  {currencySymbol} {calculatedInstallment.toLocaleString("en-US", { minimumFractionDigits: 2 })} / mo
                </strong>
              </div>
              <div>
                <span className="text-slate-500 text-[11px] block">Estimated 2.5% Platform Fee:</span>
                <strong className="text-indigo-900 text-xs font-bold">
                  {currencySymbol} {estimatedPlatformFeePerTx.toFixed(2)}
                </strong>
              </div>
            </div>
          </div>

          {/* STEP 3: ENABLE/DISABLE DDACC AUTO DEDUCTION */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="space-y-1 max-w-lg">
                <div className="font-black text-xs text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Direct Debit & Credit Clearing (DDACC) Auto-Deduction</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  When enabled, loan repayments are automatically deducted from the farmer&apos;s <strong>Mabala Ledger (Account 1020)</strong> balance once the farmer acknowledges and approves the mandate.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setAutoDeductEnabled(!autoDeductEnabled)}
                className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-2 transition cursor-pointer ${
                  autoDeductEnabled
                    ? "bg-emerald-600 text-white shadow-xs"
                    : "bg-slate-200 text-slate-600"
                }`}
              >
                {autoDeductEnabled ? "DDACC Enabled" : "DDACC Disabled"}
              </button>
            </div>
          </div>

          {/* STEP 4: PLATFORM FEE SETTLEMENT SELECTION */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <label className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center justify-between">
              <span>3. Platform Fee Collection & Settlement Choice</span>
              <span className="text-[10px] text-indigo-700 font-bold bg-indigo-50 px-2 py-0.5 rounded">
                Choose Dealer/Supplier Payout Model
              </span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Option A: Per-Transaction Deduction */}
              <div
                onClick={() => setPlatformFeeMode("per_transaction")}
                className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-2 ${
                  platformFeeMode === "per_transaction"
                    ? "bg-indigo-50/70 border-indigo-500 shadow-sm ring-1 ring-indigo-500"
                    : "bg-slate-50 border-slate-200 hover:border-indigo-200"
                }`}
              >
                <div className="flex justify-between items-center">
                  <div className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
                    <span>Deduct Fee Per Transaction</span>
                  </div>
                  <input
                    type="radio"
                    name="platformFeeMode"
                    checked={platformFeeMode === "per_transaction"}
                    onChange={() => setPlatformFeeMode("per_transaction")}
                    className="text-indigo-600"
                  />
                </div>
                <p className="text-[11px] text-slate-600">
                  The 2.5% platform fee is deducted immediately upon each repayment and credited to the Super Admin operations ledger. You receive the net amount (<strong>{currencySymbol} {(calculatedInstallment - estimatedPlatformFeePerTx).toFixed(2)}</strong>) directly.
                </p>
                <div className="text-[10px] font-mono font-bold text-indigo-800">
                  ✓ Instant Fee Settlement • Auto-credited to Super Admin
                </div>
              </div>

              {/* Option B: Receive Whole Amount & Settle at Month-End */}
              <div
                onClick={() => setPlatformFeeMode("monthly_deferred")}
                className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-2 ${
                  platformFeeMode === "monthly_deferred"
                    ? "bg-emerald-50/70 border-emerald-500 shadow-sm ring-1 ring-emerald-500"
                    : "bg-slate-50 border-slate-200 hover:border-emerald-200"
                }`}
              >
                <div className="flex justify-between items-center">
                  <div className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                    <span>Receive Whole Repayment (100%)</span>
                  </div>
                  <input
                    type="radio"
                    name="platformFeeMode"
                    checked={platformFeeMode === "monthly_deferred"}
                    onChange={() => setPlatformFeeMode("monthly_deferred")}
                    className="text-emerald-600"
                  />
                </div>
                <p className="text-[11px] text-slate-600">
                  Receive the <strong>full 100% repayment (ZK {calculatedInstallment.toFixed(2)})</strong> immediately. Accrued platform fees are consolidated on your monthly fee statement and collected at month-end for Super Admin manual settlement.
                </p>
                <div className="text-[10px] font-mono font-bold text-emerald-800">
                  ✓ Maximum Cashflow • Month-End Batch Invoice
                </div>
              </div>
            </div>
          </div>

          {/* Modal Footer */}
          <div className="pt-4 border-t border-slate-100 flex justify-end items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-black text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer"
            >
              {isSubmitting ? (
                <span>Issuing Loan...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Issue Loan & Dispatch Mandate</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

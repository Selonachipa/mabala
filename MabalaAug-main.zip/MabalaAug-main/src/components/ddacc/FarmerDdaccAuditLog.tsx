import React, { useState, useEffect, useMemo } from "react";
import {
  ShieldCheck,
  Receipt,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowDownRight,
  ArrowUpRight,
  RefreshCw,
  Wallet,
  Smartphone,
  Check,
  X,
  FileText,
  Printer,
  Download,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Info,
  Calendar,
  Building2,
  BadgeCheck,
  Send
} from "lucide-react";
import {
  DdaccClearingRecord,
  DdaccMandate,
  getDdaccClearingHistory,
  getDdaccMandates,
  executeAllDueDdaccClearing,
  getFarmerDdaccSmsAlertEnabled,
  setFarmerDdaccSmsAlertEnabled,
  getFarmerDdaccPhoneNumber,
  setFarmerDdaccPhoneNumber,
  sendTestDdaccSms
} from "../../services/ddaccLoanService";
import { getWalletBalances } from "../../services/walletService";

interface FarmerDdaccAuditLogProps {
  farmerTenantId?: string;
  farmerName?: string;
  currencySymbol?: string;
  onRefreshLedger?: () => void;
}

export const FarmerDdaccAuditLog: React.FC<FarmerDdaccAuditLogProps> = ({
  farmerTenantId = "TENANT-001",
  farmerName = "Sula Shikasuli",
  currencySymbol = "ZK",
  onRefreshLedger
}) => {
  const [clearingLogs, setClearingLogs] = useState<DdaccClearingRecord[]>([]);
  const [mandates, setMandates] = useState<DdaccMandate[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<DdaccClearingRecord | null>(null);

  // SMS Notification Toggle State
  const [smsAlertsEnabled, setSmsAlertsEnabled] = useState<boolean>(() => {
    return getFarmerDdaccSmsAlertEnabled(farmerTenantId);
  });
  const [farmerPhone, setFarmerPhone] = useState<string>(() => {
    return getFarmerDdaccPhoneNumber(farmerTenantId, "+260977123456");
  });
  const [isSendingTestSms, setIsSendingTestSms] = useState(false);
  const [smsToggleNotice, setSmsToggleNotice] = useState<string | null>(null);

  // Clearing Run State
  const [isRunningClearing, setIsRunningClearing] = useState(false);
  const [clearingActionNotice, setClearingActionNotice] = useState<{
    type: "success" | "error" | "info";
    text: string;
  } | null>(null);

  // Live Wallet Balance
  const [ledgerBalance, setLedgerBalance] = useState<number>(() => {
    return getWalletBalances(farmerTenantId).lipilaBalance;
  });

  const loadData = () => {
    const logs = getDdaccClearingHistory({ farmerTenantId });
    setClearingLogs(logs);

    const mList = getDdaccMandates({ farmerTenantId });
    setMandates(mList);

    const bal = getWalletBalances(farmerTenantId).lipilaBalance;
    setLedgerBalance(bal);

    setSmsAlertsEnabled(getFarmerDdaccSmsAlertEnabled(farmerTenantId));
    setFarmerPhone(getFarmerDdaccPhoneNumber(farmerTenantId, "+260977123456"));
  };

  useEffect(() => {
    loadData();

    const handleUpdate = () => {
      loadData();
    };

    window.addEventListener("mabala_ddacc_update", handleUpdate);
    window.addEventListener("mabala_wallet_update", handleUpdate);
    window.addEventListener("mabala_ddacc_sms_settings_changed", handleUpdate);
    window.addEventListener("mabala_ddacc_phone_changed", handleUpdate);
    window.addEventListener("storage", handleUpdate);

    return () => {
      window.removeEventListener("mabala_ddacc_update", handleUpdate);
      window.removeEventListener("mabala_wallet_update", handleUpdate);
      window.removeEventListener("mabala_ddacc_sms_settings_changed", handleUpdate);
      window.removeEventListener("mabala_ddacc_phone_changed", handleUpdate);
      window.removeEventListener("storage", handleUpdate);
    };
  }, [farmerTenantId]);

  const handleToggleSms = (enabled: boolean) => {
    setFarmerDdaccSmsAlertEnabled(farmerTenantId, enabled);
    setSmsAlertsEnabled(enabled);
    setSmsToggleNotice(
      enabled
        ? `SMS Alerts Enabled: Instant SMS notifications will be routed to ${farmerPhone} via Beem Gateway whenever a DDACC repayment is deducted.`
        : "SMS Alerts Muted: You will no longer receive SMS text notifications for auto-deductions."
    );
    setTimeout(() => setSmsToggleNotice(null), 5000);
  };

  const handleSendTestSms = async () => {
    setIsSendingTestSms(true);
    setSmsToggleNotice(null);
    try {
      const res = await sendTestDdaccSms({
        farmerTenantId,
        phone: farmerPhone,
        farmerName
      });
      setSmsToggleNotice(
        res.success
          ? `Test SMS successfully sent to ${farmerPhone} via Beem Gateway! (${res.gatewayStatus})`
          : `Test SMS notice: ${res.message}`
      );
      setTimeout(() => setSmsToggleNotice(null), 6000);
    } catch (err: any) {
      setSmsToggleNotice(`Failed to send test SMS: ${err.message}`);
    } finally {
      setIsSendingTestSms(false);
    }
  };

  const handleTriggerClearingCheck = async () => {
    setIsRunningClearing(true);
    setClearingActionNotice(null);
    try {
      const res = await executeAllDueDdaccClearing(farmerTenantId);
      loadData();
      if (onRefreshLedger) onRefreshLedger();

      if (res.successCount > 0) {
        setClearingActionNotice({
          type: "success",
          text: `DDACC Clearing Reconciled: Successfully auto-deducted ZMW ${res.totalDeducted.toFixed(2)} from Mabala Ledger (Account 1020).`
        });
      } else if (res.processedCount === 0) {
        setClearingActionNotice({
          type: "info",
          text: "All active loan installments are currently up to date. No pending deductions due."
        });
      } else {
        setClearingActionNotice({
          type: "error",
          text: `Clearing check: ${res.results[0]?.message || "Insufficient funds in Mabala Ledger (Account 1020)."}`
        });
      }
    } catch (err: any) {
      setClearingActionNotice({
        type: "error",
        text: err.message || "Failed to execute clearing verification."
      });
    } finally {
      setIsRunningClearing(false);
    }
  };

  // Filtered logs
  const filteredLogs = useMemo(() => {
    return clearingLogs.filter(log => {
      const matchesSearch =
        log.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.loanId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.mandateId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.lenderName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (log.verificationHash && log.verificationHash.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesStatus =
        statusFilter === "ALL" ||
        log.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [clearingLogs, searchTerm, statusFilter]);

  // Aggregate Stats
  const successfulDeductions = useMemo(() => {
    return clearingLogs.filter(l => l.status === "SUCCESS");
  }, [clearingLogs]);

  const totalDeductedAmount = useMemo(() => {
    return successfulDeductions.reduce((acc, l) => acc + l.deductionAmount, 0);
  }, [successfulDeductions]);

  const totalPlatformFeesPaid = useMemo(() => {
    return successfulDeductions.reduce((acc, l) => acc + (l.platformFeeAmount || 0), 0);
  }, [successfulDeductions]);

  const activeMandatesCount = useMemo(() => {
    return mandates.filter(m => m.status === "active" && m.autoDeductEnabled).length;
  }, [mandates]);

  return (
    <div className="space-y-6" id="farmer-ddacc-audit-log-root">
      {/* Header Banner with Title & Quick Controls */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase tracking-wider flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Ledger DDACC Clearing Audit
              </span>
              <span className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                Account 1020 - Mabala Ledger
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              Auto-Deduction Audit Log & Verification
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Official ledger record of all automated Direct Debit and Credit Clearing (DDACC) repayments deducted from your Mabala Ledger (Account 1020) for input loans from agro-dealers and suppliers.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleTriggerClearingCheck}
              disabled={isRunningClearing}
              id="btn-reconcile-ddacc"
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-50 shadow-sm"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRunningClearing ? "animate-spin text-emerald-400" : ""}`} />
              {isRunningClearing ? "Reconciling..." : "Reconcile Auto-Deductions"}
            </button>
          </div>
        </div>

        {/* SMS Notification Toggle Ribbon */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-950/60 p-4 rounded-xl border">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl ${smsAlertsEnabled ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-slate-800 text-slate-400"}`}>
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-200 flex items-center gap-2">
                <span>Instant SMS Gateway Alerts for DDACC Repayments</span>
                {smsAlertsEnabled && (
                  <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold rounded">
                    Active Gateway Dispatch
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                Receive immediate SMS text confirmation via Beem SMS Gateway whenever an installment is auto-debited from your ledger balance.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 self-end sm:self-center">
            {smsAlertsEnabled && (
              <>
                <span className="text-[11px] font-mono font-semibold text-emerald-300 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800 flex items-center gap-1.5">
                  <Smartphone className="w-3 h-3 text-emerald-400" />
                  {farmerPhone}
                </span>
                <button
                  type="button"
                  onClick={handleSendTestSms}
                  disabled={isSendingTestSms}
                  id="btn-test-sms-audit-log"
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors disabled:opacity-50"
                >
                  <Send className={`w-3 h-3 ${isSendingTestSms ? 'animate-spin' : ''}`} />
                  {isSendingTestSms ? 'Sending...' : 'Test SMS'}
                </button>
              </>
            )}

            <label className="relative inline-flex items-center cursor-pointer" id="sms-alert-toggle-wrapper">
              <input
                type="checkbox"
                checked={smsAlertsEnabled}
                onChange={(e) => handleToggleSms(e.target.checked)}
                className="sr-only peer"
                id="toggle-ddacc-sms-alerts"
              />
              <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
            <span className="text-xs font-bold font-mono text-slate-300 min-w-[50px]">
              {smsAlertsEnabled ? "ENABLED" : "OFF"}
            </span>
          </div>
        </div>

        {/* Notices */}
        {smsToggleNotice && (
          <div className="mt-3 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{smsToggleNotice}</span>
          </div>
        )}

        {clearingActionNotice && (
          <div className={`mt-3 p-3 rounded-xl text-xs flex items-center gap-2 ${
            clearingActionNotice.type === "success"
              ? "bg-emerald-500/10 border border-emerald-500/30 text-emerald-300"
              : clearingActionNotice.type === "error"
              ? "bg-rose-500/10 border border-rose-500/30 text-rose-300"
              : "bg-blue-500/10 border border-blue-500/30 text-blue-300"
          }`}>
            {clearingActionNotice.type === "success" ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : clearingActionNotice.type === "error" ? (
              <AlertTriangle className="w-4 h-4 shrink-0" />
            ) : (
              <Info className="w-4 h-4 shrink-0" />
            )}
            <span>{clearingActionNotice.text}</span>
          </div>
        )}
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total DDACC Auto-Repaid</span>
            <Receipt className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono mt-2">
            {currencySymbol} {totalDeductedAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            {successfulDeductions.length} successful deductions cleared
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Mabala Ledger Balance (1020)</span>
            <Wallet className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-black text-slate-100 font-mono mt-2">
            {currencySymbol} {ledgerBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Available for automated clearing
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Platform Clearing Fees</span>
            <Sparkles className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400 font-mono mt-2">
            {currencySymbol} {totalPlatformFeesPaid.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Processed per-tx / deferred
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Active DDACC Mandates</span>
            <ShieldCheck className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-black text-slate-100 font-mono mt-2">
            {activeMandatesCount} <span className="text-xs text-slate-400 font-normal">authorized</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Auto-deductions enabled & approved
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by ID, Loan, Lender, or Ref Hash..."
            className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
            id="input-search-ddacc-audit"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto">
          <span className="text-xs text-slate-400 flex items-center gap-1 shrink-0">
            <Filter className="w-3.5 h-3.5" /> Status:
          </span>
          {["ALL", "SUCCESS", "FAILED_INSUFFICIENT_FUNDS", "PARTIALLY_CLEARED"].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                statusFilter === status
                  ? "bg-emerald-600 text-white"
                  : "bg-slate-800 text-slate-400 hover:bg-slate-700"
              }`}
            >
              {status === "ALL"
                ? "All Records"
                : status === "SUCCESS"
                ? "Cleared"
                : status === "FAILED_INSUFFICIENT_FUNDS"
                ? "Failed (Funds)"
                : "Partial"}
            </button>
          ))}
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-slate-200">
              Direct Debit Clearing Transaction Records ({filteredLogs.length})
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            Debited against: <strong className="text-slate-300 font-mono">1020 - Mabala Ledger</strong>
          </span>
        </div>

        {filteredLogs.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-3">
            <Receipt className="w-12 h-12 text-slate-600 mx-auto" />
            <h4 className="text-base font-bold text-slate-300">No Auto-Deduction Records Found</h4>
            <p className="text-xs max-w-md mx-auto">
              {searchTerm || statusFilter !== "ALL"
                ? "No deduction logs match your search criteria. Try clearing the filter."
                : "No automated loan repayments have been deducted from your ledger yet."}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {filteredLogs.map((log) => {
              const isExpanded = expandedLogId === log.id;
              return (
                <div key={log.id} className="p-4 hover:bg-slate-800/30 transition-colors" id={`audit-row-${log.id}`}>
                  <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
                    {/* Left: Basic Info */}
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs font-bold text-slate-200">{log.id}</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            log.status === "SUCCESS"
                              ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                              : log.status === "FAILED_INSUFFICIENT_FUNDS"
                              ? "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                              : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                          }`}
                        >
                          {log.status.replace(/_/g, " ")}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {new Date(log.clearingDate).toLocaleString()}
                        </span>
                      </div>

                      <div className="text-xs text-slate-300 flex items-center gap-2 flex-wrap">
                        <span>Lender / Supplier: <strong className="text-emerald-400">{log.lenderName}</strong></span>
                        <span className="text-slate-600">•</span>
                        <span>Loan Ref: <strong className="text-slate-200 font-mono">{log.loanId}</strong></span>
                        <span className="text-slate-600">•</span>
                        <span>Mandate: <strong className="text-slate-400 font-mono">{log.mandateId}</strong></span>
                      </div>
                    </div>

                    {/* Right: Amounts & Action */}
                    <div className="flex items-center gap-4 self-end lg:self-center">
                      <div className="text-right">
                        <div className="text-base font-black font-mono text-emerald-400">
                          - {currencySymbol} {log.deductionAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          Ledger Bal: <span className="font-mono text-slate-200">ZK {log.ledgerBalanceAfter !== undefined ? log.ledgerBalanceAfter.toLocaleString() : "—"}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setSelectedReceipt(log)}
                          title="View Official Debit Slip / Certificate"
                          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 transition-colors text-xs flex items-center gap-1.5"
                        >
                          <FileText className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="hidden sm:inline">Debit Slip</span>
                        </button>

                        <button
                          onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded-xl border border-slate-700 transition-colors"
                        >
                          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Breakdown */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-950/70 p-4 rounded-xl text-xs">
                      <div>
                        <div className="text-slate-400 font-medium mb-1">Financial Breakdown:</div>
                        <div className="space-y-1 text-slate-300">
                          <div className="flex justify-between">
                            <span className="text-slate-400">Principal Cleared:</span>
                            <span className="font-mono font-bold">ZK {log.principalDeducted.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Platform DDACC Fee:</span>
                            <span className="font-mono text-amber-400">ZK {log.platformFeeAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Net to Lender:</span>
                            <span className="font-mono text-emerald-400">ZK {log.lenderReceivedAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Fee Mode:</span>
                            <span className="capitalize">{log.platformFeeMode.replace("_", " ")}</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <div className="text-slate-400 font-medium mb-1">Clearing Channel & Notes:</div>
                        <p className="text-slate-300 text-[11px] leading-relaxed bg-slate-900 p-2 rounded border border-slate-800">
                          {log.notes || "Standard automated ledger deduction."}
                        </p>
                        {log.verificationHash && (
                          <div className="mt-2 text-[10px] text-slate-400 font-mono break-all">
                            Hash: <span className="text-emerald-400">{log.verificationHash}</span>
                          </div>
                        )}
                      </div>

                      <div>
                        <div className="text-slate-400 font-medium mb-1">SMS Alert Dispatch:</div>
                        <div className="bg-slate-900 p-2.5 rounded border border-slate-800 space-y-1.5">
                          <div className="flex items-center gap-1.5">
                            <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                            <span className={`text-[11px] font-bold ${
                              log.smsNotificationStatus === "DELIVERED"
                                ? "text-emerald-400"
                                : log.smsNotificationStatus === "QUEUED"
                                ? "text-blue-400"
                                : log.smsNotificationStatus === "DISABLED"
                                ? "text-slate-400"
                                : "text-amber-400"
                            }`}>
                              Status: {log.smsNotificationStatus || (log.smsNotificationSent ? "DELIVERED" : "DISABLED")}
                            </span>
                          </div>
                          {log.smsNotificationRecipient && (
                            <div className="text-[10px] text-slate-400 font-mono">
                              Recipient: {log.smsNotificationRecipient}
                            </div>
                          )}
                          {log.smsNotificationMessage && (
                            <div className="text-[10px] text-slate-400 italic">
                              "{log.smsNotificationMessage.slice(0, 75)}..."
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* MODAL: Official Debit Verification Slip / Certificate */}
      {selectedReceipt && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 text-slate-100 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
                  <BadgeCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-100">Official DDACC Debit Slip</h3>
                  <p className="text-xs text-slate-400">Electronic Ledger Clearing Certificate</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="p-1 text-slate-400 hover:text-slate-200 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Receipt Printable Slip Body */}
            <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 space-y-4 text-xs font-mono relative">
              <div className="text-center space-y-1 pb-3 border-b border-dashed border-slate-800">
                <div className="text-sm font-black text-slate-100 tracking-wider">MABALA FARM FINANCIAL LEDGER</div>
                <div className="text-[11px] text-emerald-400 font-bold">DIRECT DEBIT & CREDIT CLEARING (DDACC)</div>
                <div className="text-[10px] text-slate-500">Lusaka & Agricultural Growth Corridor, Zambia</div>
              </div>

              <div className="space-y-2 pt-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Transaction ID:</span>
                  <span className="text-slate-200 font-bold">{selectedReceipt.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Clearing Timestamp:</span>
                  <span className="text-slate-200">{new Date(selectedReceipt.clearingDate).toUTCString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Debited Account:</span>
                  <span className="text-emerald-400 font-bold">1020 - Mabala Ledger</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Farmer Account Holder:</span>
                  <span className="text-slate-200">{selectedReceipt.farmerName} ({selectedReceipt.farmerTenantId})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Beneficiary / Lender:</span>
                  <span className="text-slate-200 font-bold">{selectedReceipt.lenderName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Loan Reference:</span>
                  <span className="text-slate-200">{selectedReceipt.loanId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Mandate Authorization:</span>
                  <span className="text-slate-200">{selectedReceipt.mandateId}</span>
                </div>
              </div>

              <div className="py-3 border-y border-dashed border-slate-800 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400 font-bold">Total Debited:</span>
                  <span className="text-emerald-400 font-black">
                    ZMW {selectedReceipt.deductionAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">Principal Repaid:</span>
                  <span className="text-slate-200">
                    ZMW {selectedReceipt.principalDeducted.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">Platform DDACC Fee:</span>
                  <span className="text-amber-400">
                    ZMW {selectedReceipt.platformFeeAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">Closing Balance (1020):</span>
                  <span className="text-slate-200">
                    ZMW {selectedReceipt.ledgerBalanceAfter !== undefined ? selectedReceipt.ledgerBalanceAfter.toLocaleString(undefined, { minimumFractionDigits: 2 }) : "—"}
                  </span>
                </div>
              </div>

              <div className="space-y-1.5 pt-1 text-[10px] text-slate-400">
                <div>Digital Verification Hash:</div>
                <div className="text-emerald-400 font-bold break-all bg-slate-900 p-1.5 rounded">
                  {selectedReceipt.verificationHash || `MABALA-DDACC-VERIFIED-${selectedReceipt.id}`}
                </div>
              </div>

              <div className="pt-2 text-center text-[10px] text-slate-500">
                This receipt is system-generated and immutably recorded in the Mabala Agricultural Ledger.
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => {
                  window.print();
                }}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-2 border border-slate-700 transition-colors"
              >
                <Printer className="w-3.5 h-3.5 text-emerald-400" />
                Print Debit Slip
              </button>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

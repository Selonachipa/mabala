import React, { useState, useEffect } from "react";
import { 
  LineChart, 
  LayoutDashboard, 
  BookOpen, 
  Receipt, 
  Compass, 
  Users, 
  FileSpreadsheet, 
  Settings, 
  DollarSign, 
  Waves, 
  Boxes, 
  UserSquare2,
  FileText,
  Shield,
  Database,
  Coins,
  Package,
  History,
  Store,
  Tractor,
  ChevronDown,
  ChevronRight,
  X,
  Egg,
  Building,
  Radio
} from "lucide-react";
import { doc, onSnapshot } from "firebase/firestore";
import { db, auth } from "../firebase";
import { PredefinedRole, OptionalModulePermission } from "../types";
import { useSuperAdmin, SUPER_ADMIN_EMAILS } from "../hooks/useSuperAdmin";
import MabalaLogo from "./MabalaLogo";
import { 
  resolveCanonicalTenantType, 
  isModuleEntitled, 
  HARD_PLATFORM_LOCK_MODULES 
} from "../services/moduleEntitlementEngine";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isReadonly: boolean;
  onTopUp: () => void;
  credits: number;
  currentRole: PredefinedRole;
  rolePermissions: { [moduleId: string]: OptionalModulePermission };
  userEmail: string;
  subscriptionTier: string;
  workspaceMode: "Farmer" | "Veterinary" | "Offtaker" | "Partner";
  activeFarmName: string;
  onOpenAnimalWizard?: () => void;
  isOpen?: boolean;
  onClose?: () => void;
  isSuperAdminSession?: boolean;
  isImpersonating?: boolean;
}

export default function Sidebar({ 
  activeTab, 
  setActiveTab, 
  isReadonly, 
  onTopUp, 
  credits,
  currentRole,
  rolePermissions,
  userEmail,
  subscriptionTier,
  workspaceMode,
  activeFarmName,
  onOpenAnimalWizard,
  isOpen = false,
  onClose,
  isSuperAdminSession = false,
  isImpersonating = false
}: SidebarProps) {

  const [activePass, setActivePass] = useState<any>(() => {
    const cached = localStorage.getItem("mabala_active_access_pass");
    if (cached) {
      try {
        const pass = JSON.parse(cached);
        if (new Date(pass.expiresAt) > new Date()) {
          return pass;
        }
      } catch (e) {}
    }
    return null;
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const cached = localStorage.getItem("mabala_active_access_pass");
      if (cached) {
        try {
          const pass = JSON.parse(cached);
          if (new Date(pass.expiresAt) > new Date()) {
            setActivePass(pass);
            return;
          }
        } catch (e) {}
      }
      setActivePass(null);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const renderCountdown = () => {
    if (!activePass) return null;
    const diffMs = new Date(activePass.expiresAt).getTime() - Date.now();
    if (diffMs <= 0) return null;
    
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const mins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    return (
      <div className="mt-2 p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-[10px] text-emerald-400 font-semibold space-y-0.5">
        <div className="flex justify-between items-center">
          <span>Active Pass:</span>
          <span className="font-extrabold text-white animate-pulse">UNMETERED</span>
        </div>
        <div className="flex justify-between items-center font-mono text-[9px] text-slate-400">
          <span>Expires in:</span>
          <span>{hours}h {mins}m</span>
        </div>
      </div>
    );
  };

  // Define Partner-focused logical categories
  const partnerCategories = [
    {
      id: "partner-portal",
      label: "Referral Dashboard",
      icon: LayoutDashboard,
      tabId: "partner-portal"
    },
    {
      id: "settings",
      label: "Settings",
      icon: Settings,
      subItems: [
        { id: "profile", label: "Account Settings" },
        { id: "backup-restore", label: "Data Backup & Restore" }
      ]
    }
  ];

  // Define 12 Farmer-focused logical categories
  const categories = [
    {
      id: "dashboard",
      label: "Dashboard",
      icon: LayoutDashboard,
      tabId: "dashboard"
    },
    {
      id: "crops",
      label: "Crops & Field Ops",
      icon: Compass,
      subItems: [
        { id: "crops", label: "Crop Cycles & Stage Guides" },
        { id: "hsw-dashboard", label: "🌾 Harvest & Storage Warehouse" },
        { id: "advisory-portal", label: "🌱 Book an Agronomist & Reports" },
        { id: "orchard-dashboard", label: "Orchard Management" }
      ]
    },
    {
      id: "hsw-dashboard-group",
      label: "Harvest & Storage",
      icon: Package,
      tabId: "hsw-dashboard"
    },
    {
      id: "livestock-group",
      label: "Livestock & Herd",
      icon: Tractor,
      subItems: [
        { id: "livestock", label: "Livestock Registry" },
        { id: "livestock-registry", label: "Register Animal" },
        { id: "aquaculture", label: "Aquaculture Systems" }
      ]
    },
    {
      id: "poultry-group",
      label: "Poultry Module",
      icon: Egg,
      tabId: "poultry"
    },
    {
      id: "finance",
      label: "Finance & Credit",
      icon: Coins,
      subItems: [
        { id: "finance-hub", label: "Finance & Credit" },
        { id: "farmer-wallet", label: "💳 Mabala Farm Ledger" },
        { id: "loans-hub", label: "🏛️ Facilities" },
        { id: "agc-farmer-hub", label: "🌱 Mabala Input Credit (AGC)" },
        { id: "expenses", label: "Expenses Ledger" },
        { id: "invoices", label: "Invoices & Quotations" },
        { id: "assets", label: "Asset Register" },
        { id: "accounts", label: "Chart of Accounts" }
      ]
    },
    {
      id: "sales-mkt",
      label: "Sales & Marketplace",
      icon: Store,
      subItems: [
        { id: "sales", label: "Sales & Customers" },
        { id: "marketplace", label: "Vendor Marketplace" },
        { id: "offtaker-marketplace", label: "Sell to Offtakers" }
      ]
    },
    {
      id: "inventory",
      label: "Inventory & Storage",
      icon: Boxes,
      subItems: [
        { id: "hsw-dashboard", label: "📦 HSW Storage & Receipts" },
        { id: "inventory", label: "Inventory Stockroom" }
      ]
    },
    {
      id: "hr",
      label: "Human Resources",
      icon: Users,
      subItems: [
        { id: "payroll", label: "Employees & Payroll" }
      ]
    },
    {
      id: "machinery",
      label: "Asset Register & Ledger",
      icon: Tractor,
      subItems: [
        { id: "assets", label: "Equipment Asset Log" }
      ]
    },
    {
      id: "sms-hub-group",
      label: "SMS Communications Hub",
      icon: Radio,
      tabId: "sms-hub"
    },
    {
      id: "fbi-group",
      label: "Farm Intelligence (FBI)",
      icon: LineChart,
      tabId: "fbi"
    },
    {
      id: "reports-group",
      label: "Reports & Analytics",
      icon: FileSpreadsheet,
      tabId: "reports"
    },
    {
      id: "settings",
      label: "Settings",
      icon: Settings,
      subItems: [
        { id: "profile", label: "User & Farm Settings" },
        { id: "billing-centre", label: "Billing Centre" },
        { id: "permissions", label: "Roles & Permission" },
        { id: "backup-restore", label: "Data Backup & Restore" },
        { id: "offline-sync", label: "Offline Cache & Sync" },
        { id: "audit-archive", label: "Audit Trails" }
      ]
    }
  ];

  // Specific Agro-Dealer Categories list
  const agroDealerCategories = [
    {
      id: "agro-dealer-pos-group",
      label: "POS & Consignment",
      icon: Store,
      subItems: [
        { id: "agc-dealer-pos", label: "🛒 Retail Shop POS Counter" },
        { id: "agrodealer-consignment", label: "Consignment Stock Feed" },
        { id: "agrodealer-boost", label: "Agrodealer Boost & Ads" }
      ]
    },
    {
      id: "agro-finance-group",
      label: "Retail Sales & Ledger",
      icon: Coins,
      subItems: [
        { id: "loans-hub", label: "🏛️ Loan & Credit Desk" },
        { id: "sales", label: "Sales Tracker" },
        { id: "invoices", label: "Invoices & Quotes" },
        { id: "expenses", label: "Expenses Ledger" },
        { id: "accounts", label: "Chart of Accounts" }
      ]
    },
    {
      id: "agro-stock-group",
      label: "Stockroom & Marketplace",
      icon: Boxes,
      subItems: [
        { id: "inventory", label: "Inventory Stockroom" },
        { id: "marketplace", label: "Vendor Marketplace" }
      ]
    },
    {
      id: "sms-hub-group",
      label: "SMS Communications Hub",
      icon: Radio,
      tabId: "sms-hub"
    },
    {
      id: "reports-group",
      label: "Reports & Analytics",
      icon: FileSpreadsheet,
      tabId: "reports"
    },
    {
      id: "settings",
      label: "Settings",
      icon: Settings,
      subItems: [
        { id: "profile", label: "User & Store Settings" },
        { id: "backup-restore", label: "Data Backup & Restore" }
      ]
    }
  ];

  // Specific Institution Supplier (Seed/Chemical Co) Categories list
  const supplierPortalCategories = [
    {
      id: "supplier-portal-group",
      label: "Supplier Portal & Consignment",
      icon: Building,
      subItems: [
        { id: "agc-financier-portal", label: "🏢 Supplier Portal View" },
        { id: "agrodealer-consignment", label: "Supplier Consignment Hub" },
        { id: "agrodealer-boost", label: "Boost & Sponsored Placements" },
        { id: "partner-portal", label: "Partner Referral Hub" }
      ]
    },
    {
      id: "supplier-finance-group",
      label: "Enterprise Finance",
      icon: Coins,
      subItems: [
        { id: "loans-hub", label: "🏛️ Lending Desk & Portfolio" },
        { id: "accounts", label: "Chart of Accounts" },
        { id: "expenses", label: "Expenses Ledger" },
        { id: "payroll", label: "Payroll Localizer (Pro)" },
        { id: "sales", label: "Sales Tracker" },
        { id: "invoices", label: "Invoices & Quotations" }
      ]
    },
    {
      id: "supplier-inventory-group",
      label: "Inventory & Sourcing",
      icon: Boxes,
      subItems: [
        { id: "inventory", label: "Inventory & Stock" },
        { id: "marketplace", label: "Vendor Marketplace" }
      ]
    },
    {
      id: "sms-hub-group",
      label: "SMS Communications Hub",
      icon: Radio,
      tabId: "sms-hub"
    },
    {
      id: "reports-group",
      label: "Reports & Analytics",
      icon: FileSpreadsheet,
      tabId: "reports"
    },
    {
      id: "settings",
      label: "Settings",
      icon: Settings,
      subItems: [
        { id: "profile", label: "Company & User Settings" },
        { id: "backup-restore", label: "Data Backup & Restore" }
      ]
    }
  ];

  // Specific Offtaker Categories list
  const offtakerCategories = [
    {
      id: "offtaker-marketplace-group",
      label: "Offtaker Marketplace",
      icon: Tractor,
      tabId: "offtaker-marketplace"
    },
    {
      id: "settings",
      label: "Settings",
      icon: Settings,
      subItems: [
        { id: "profile", label: "User & Depot Settings" },
        { id: "backup-restore", label: "Data Backup & Restore" },
        { id: "audit-archive", label: "Audit Trails" }
      ]
    }
  ];

  // Specific Agronomist Categories list
  const agronomistCategories = [
    {
      id: "advisory-portal-group",
      label: "Advisory Services Hub",
      icon: Compass,
      tabId: "advisory-portal"
    },
    {
      id: "crops",
      label: "Crops & Field Ops",
      icon: Compass,
      subItems: [
        { id: "advisory-portal", label: "Advisory Consultations & Prescriptions" },
        { id: "crops", label: "Crop Cycles & Stage Guides" },
        { id: "agronomy-admin", label: "Agronomy Content Admin" }
      ]
    },
    {
      id: "sales-mkt",
      label: "Marketplace & Sourcing",
      icon: Store,
      subItems: [
        { id: "marketplace", label: "Vendor Marketplace" },
        { id: "offtaker-marketplace", label: "Offtaker Marketplace" }
      ]
    },
    {
      id: "sms-hub-group",
      label: "SMS Communications Hub",
      icon: Radio,
      tabId: "sms-hub"
    },
    {
      id: "reports-group",
      label: "Reports & Analytics",
      icon: FileSpreadsheet,
      tabId: "reports"
    },
    {
      id: "settings",
      label: "Settings",
      icon: Settings,
      subItems: [
        { id: "profile", label: "User & Advisory Settings" },
        { id: "backup-restore", label: "Data Backup & Restore" }
      ]
    }
  ];

  const canonicalTenantType = resolveCanonicalTenantType(currentRole, userEmail);

  // Live snapshot entitlement state from Firestore
  const [liveTypeEntitlements, setLiveTypeEntitlements] = useState<Record<string, boolean> | null>(null);

  useEffect(() => {
    if (!canonicalTenantType) return;
    try {
      const typeRef = doc(db, "platformConfig", "moduleEntitlements", canonicalTenantType);
      const unsub = onSnapshot(typeRef, (snap) => {
        if (snap.exists() && snap.data()?.modules) {
          const mods = snap.data().modules;
          const simpleMap: Record<string, boolean> = {};
          Object.entries(mods).forEach(([k, v]: [string, any]) => {
            simpleMap[k] = typeof v === "boolean" ? v : (v?.enabled ?? false);
          });
          setLiveTypeEntitlements(simpleMap);
        }
      }, (err) => {
        console.warn("[Sidebar] Entitlement live snapshot listener note:", err);
      });
      return () => unsub();
    } catch (e) {
      console.warn("[Sidebar] Entitlement listener initialization note:", e);
    }
  }, [canonicalTenantType]);

  const { isSuperAdmin } = useSuperAdmin();
  const userEmailLower = (userEmail || "").trim().toLowerCase();
  const isSuperEmail = SUPER_ADMIN_EMAILS.includes(userEmailLower) || userEmailLower === "support@mabala.cloud" || userEmailLower === "shikasuli@gmail.com";
  
  // Platform Admin module access is granted to Super Admin
  // When in an impersonated session, the user is in the farm node view and must see farm navigation
  const isSuperAdminUser = !isImpersonating && (isSuperEmail || isSuperAdmin || isSuperAdminSession || currentRole === "Super Admin" || canonicalTenantType === "super_admin");
  
  const isAdmin = isSuperAdminUser;

  let displayedCategories = canonicalTenantType === "agronomist" || currentRole === "Agronomist"
    ? [...agronomistCategories]
    : canonicalTenantType === "agro_dealer"
      ? [...agroDealerCategories]
      : canonicalTenantType === "institution_supplier"
        ? [...supplierPortalCategories]
        : workspaceMode === "Partner"
          ? [...partnerCategories]
          : workspaceMode === "Offtaker" 
            ? [...offtakerCategories] 
            : [...categories];

  if (isAdmin) {
    displayedCategories = [...categories];
    displayedCategories.push({
      id: "platform-admin-group",
      label: "Platform Admin",
      icon: Shield,
      subItems: [
        { id: "platform-admin", label: "Super Admin Control Center" },
        { id: "resellers", label: "🤝 Reseller & Partner Commission Hub" },
        { id: "lipila-payment-tracker", label: "💳 Mabala Payment Tracker" },
        { id: "agrodealer-consignment", label: "Agro-Dealer Consignment Hub" },
        { id: "agc-dealer-pos", label: "🛒 AGC Agro-Dealer POS Counter" },
        { id: "agc-financier-portal", label: "🏦 AGC Financier Facility Portal" },
        { id: "agc-insurer-portal", label: "☂️ AGC Insurer Rates Portal" },
        { id: "agc-super-admin", label: "⚙️ AGC Platform & API Admin" }
      ]
    } as any);
  }

  // Check sub-item filtering based on permissions & live isolations
  const isTabAllowed = (tabId: string) => {
    // Super Admin has universal access to all tabs and modules
    if (isSuperAdminUser) {
      return true;
    }

    // 1. Layer 1 Hard Platform Locks Guard
    if (HARD_PLATFORM_LOCK_MODULES.includes(tabId)) {
      if (!isSuperAdminUser) {
        return false;
      }
      return true;
    }

    // 2. Module Entitlement Engine 3-Layer Evaluation (with live Firestore state)
    return isModuleEntitled(
      tabId,
      canonicalTenantType,
      undefined,
      liveTypeEntitlements || undefined
    );
  };

  // State to hold which category folder is open
  const [openCategory, setOpenCategory] = useState<string | null>(() => {
    const activeCat = displayedCategories.find(c => 
      c.tabId === activeTab || 
      ((c as any).subItems && (c as any).subItems.some((sub: any) => sub.id === activeTab))
    );
    return activeCat ? activeCat.id : "dashboard";
  });

  // Expand properly if activeTab changes from outside
  useEffect(() => {
    const matchingCat = displayedCategories.find(c => 
      c.tabId === activeTab || 
      ((c as any).subItems && (c as any).subItems.some((sub: any) => sub.id === activeTab))
    );
    if (matchingCat) {
      setOpenCategory(matchingCat.id);
    }
  }, [activeTab]);

  const handleCategoryClick = (cat: typeof categories[0]) => {
    if (cat.tabId) {
      // Direct navigation
      if (isTabAllowed(cat.tabId)) {
        setActiveTab(cat.tabId);
        setOpenCategory(cat.id);
      }
    } else if (cat.subItems) {
      const isExpanded = openCategory === cat.id;
      setOpenCategory(isExpanded ? null : cat.id);
      
      // Auto-clicks the first allowed sub-item if opening
      if (!isExpanded) {
        const firstAllowed = cat.subItems.find(sub => isTabAllowed(sub.id));
        if (firstAllowed) {
          setActiveTab(firstAllowed.id);
        }
      }
    }
  };

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {isOpen && (
        <div 
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-40 lg:hidden w-full h-full cursor-pointer transition-opacity duration-300"
          aria-label="Close Sidebar"
          role="button"
          tabIndex={0}
          onKeyDown={(e) => { if (e.key === "Enter" || e.key === "Escape") onClose && onClose(); }}
        />
      )}

      <aside 
        className={`bg-[#f8fafc] flex flex-col h-screen border-r border-slate-200 text-slate-800 select-none shrink-0 fixed inset-y-0 left-0 top-0 bottom-0 lg:sticky lg:top-0 lg:z-30 transition-all duration-300 ease-in-out transform shadow-2xl lg:shadow-none overflow-y-auto ${
          isOpen 
            ? "w-64 translate-x-0 opacity-100" 
            : "w-0 -translate-x-full lg:translate-x-0 lg:w-0 lg:opacity-0 overflow-hidden border-none"
        }`} 
        id="mabala-sidebar"
      >
      {/* Platform Branding & Interactive ON/OFF Collapse Toggle */}
      <div className="p-4 sm:p-5 border-b border-slate-200/80 flex items-center justify-between font-sans shrink-0 bg-white">
        <MabalaLogo variant="full" theme="light" size={32} />
        {onClose && (
          <button 
            onClick={onClose}
            className="flex items-center gap-2 px-2.5 py-1.5 bg-slate-800/90 hover:bg-slate-800 text-slate-200 hover:text-white rounded-xl border border-slate-700/60 transition-all text-xs font-bold cursor-pointer shadow-xs active:scale-95 group"
            aria-label="Toggle Navigation Menu"
            title="Turn Navigation Menu OFF (Collapse Menu)"
          >
            <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 group-hover:text-slate-200 font-mono">MENU</span>
            
            {/* Interactive Toggle Switch Knob (ON state) */}
            <div className="flex items-center gap-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-1.5 py-0.5 rounded-full text-[9px] font-black font-mono uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>ON</span>
            </div>

            <div className="w-6 h-3.5 bg-emerald-500 rounded-full p-0.5 flex items-center justify-end transition-all shadow-inner">
              <div className="w-2.5 h-2.5 bg-white rounded-full shadow-xs" />
            </div>
          </button>
        )}
      </div>

      {/* Dynamic Profile Badge inside Sidebar */}
      <div className="mx-4 mt-4 px-3.5 py-2.5 rounded-xl bg-white border border-slate-200 shadow-2xs flex flex-col gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-[#0B2265] text-white flex items-center justify-center text-[10px] font-black shrink-0 shadow-2xs">
            {currentRole === "Platform Administrator" ? "PA" : currentRole === "Farm Owner" ? "FO" : currentRole === "Veterinary Doctor" ? "VT" : "W"}
          </div>
          <div className="min-w-0 font-sans">
            <span className="text-[9px] text-slate-400 block font-mono font-semibold uppercase leading-none pb-0.5">Role / Plan</span>
            <span className="text-xs text-slate-900 font-bold truncate block">{currentRole}</span>
            <span className="text-[10px] text-emerald-600 font-semibold truncate block">{subscriptionTier}</span>
          </div>
        </div>

        {subscriptionTier.includes("Veterinary") || subscriptionTier.includes("Agro-Vet") ? (
          <div className="pt-2 border-t border-slate-100 text-[10px] flex items-center justify-between font-semibold">
            <span className="text-slate-400 uppercase tracking-widest text-[8px] font-mono font-bold">Workspace View</span>
            <span className="px-1.5 py-0.5 bg-slate-100 text-slate-700 border border-slate-200 rounded font-mono uppercase text-[9px] font-bold">
              {workspaceMode}
            </span>
          </div>
        ) : null}
      </div>

      {/* Credit Balance Card */}
      <div className="mx-4 my-2.5 p-3 rounded-xl bg-white border border-slate-200 shadow-2xs flex flex-col gap-2 font-sans">
        <div className="flex justify-between items-center text-xs">
          <span className="text-slate-500 font-bold uppercase tracking-wider text-[9px]">Credits Pool</span>
          <span className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold ${
            credits === 0 ? "bg-rose-500 text-white" : credits < 50 ? "bg-amber-500 text-slate-950 font-black" : "bg-emerald-50 text-emerald-700 border border-emerald-200"
          }`}>
            {credits} CR
          </span>
        </div>
        {renderCountdown()}
        <button 
          onClick={onTopUp}
          className="w-full py-1.5 bg-[#0B2265] hover:bg-[#071746] text-white font-bold rounded-lg text-[10px] transition-all cursor-pointer shadow-2xs"
        >
          Top up Credits
        </button>
      </div>

      {/* 12 Grouped Accordion Navigation Sections */}
      <nav className="flex-1 px-3 space-y-1 overflow-y-auto pt-2 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent font-sans">
        {displayedCategories.map((cat) => {
          const Icon = cat.icon;
          const isSelected = activeTab === cat.tabId || (cat.subItems && cat.subItems.some(sub => sub.id === activeTab));
          const isExpanded = openCategory === cat.id;

          // Check if category is allowed at all
          const isCategoryVisible = cat.tabId 
            ? isTabAllowed(cat.tabId) 
            : (cat.subItems && cat.subItems.some(sub => isTabAllowed(sub.id)));

          if (!isCategoryVisible) return null;

          return (
            <div key={cat.id} className="space-y-0.5">
              <button
                onClick={() => handleCategoryClick(cat)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold transition-all duration-150 cursor-pointer ${
                  isSelected 
                    ? "bg-slate-200/80 text-slate-900 font-bold shadow-2xs" 
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isSelected ? "text-[#0B2265]" : "text-slate-400"}`} />
                  <span>{cat.label}</span>
                </div>
                {cat.subItems && (
                  isExpanded 
                    ? <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                    : <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                )}
              </button>

              {/* Sub-menu rendering if expanded */}
              {cat.subItems && isExpanded && (
                <div className="pl-4 pr-1 py-1 space-y-0.5 border-l-2 border-slate-200 ml-4">
                  {cat.subItems.map((sub) => {
                    const isSubAllowed = isTabAllowed(sub.id);
                    if (!isSubAllowed) return null;

                    const isSubActive = activeTab === sub.id;
                    return (
                      <button
                        key={sub.id}
                        onClick={() => {
                          if (sub.id === "livestock-registry") {
                            setActiveTab("livestock");
                            if (onOpenAnimalWizard) onOpenAnimalWizard();
                          } else {
                            setActiveTab(sub.id);
                          }
                        }}
                        className={`w-full text-left py-1.5 px-2.5 rounded-md text-[11.5px] block transition-all font-medium ${
                          isSubActive 
                            ? "bg-slate-200/90 text-slate-900 font-bold" 
                            : sub.id === "livestock-registry" 
                              ? "text-emerald-700 font-bold hover:bg-emerald-50"
                              : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                        }`}
                      >
                        {sub.label}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Footer Info */}
      <div className="p-3.5 border-t border-slate-200 text-[10px] text-slate-500 font-sans tracking-wide bg-white">
        <div className="font-bold text-slate-700">Mabala Platform</div>
        <div className="text-slate-400 text-[9.5px]">Enterprise Farm OS v2.4</div>
      </div>
    </aside>
  </>
  );
}

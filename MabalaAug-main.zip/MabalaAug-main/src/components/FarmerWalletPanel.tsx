import React, { useState, useEffect, useRef } from "react";
import { 
  Wallet, 
  Smartphone, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Plus, 
  DollarSign, 
  ShieldCheck, 
  Clock, 
  Users, 
  FileText, 
  ShoppingBag, 
  Landmark, 
  AlertCircle, 
  CheckCircle2, 
  RefreshCw,
  Info,
  ChevronRight,
  Receipt,
  Copy,
  Check,
  Zap
} from "lucide-react";
import { 
  getWalletBalances, 
  subscribeWalletUpdates, 
  calculateOutboundFee, 
  initiateTopUpWallet,
  checkTopUpStatus,
  finalizeTopUpWallet,
  spendWallet, 
  getTransactionsForTenant,
  WalletBalances, 
  OutboundFeeBreakdown,
  SpendCategory 
} from "../services/walletService";
import { LipilaTransaction, INITIAL_LIPILA_TRANSACTIONS } from "../data/mockLipilaTransactions";
import { getFeeConfig } from "../services/feeConfigService";
import { fetchPlatformInvoices, markPlatformInvoicePaid, PlatformInvoice } from "../services/platformInvoiceService";
import LipilaCheckoutModal from "./LipilaCheckoutModal";
import { safeFetchJsonClient } from "../App";
import { detectTelcoProvider } from "../utils/paymentUtils";
import { normalizeZambianMobileNumber, formatZambianMobileDisplay } from "../utils/phoneUtils";
import { DdaccManagementDesk } from "./ddacc/DdaccManagementDesk";
import BulkDisbursementModal from "./disbursements/BulkDisbursementModal";
import SuperAdminFeeScheduleModal from "./disbursements/SuperAdminFeeScheduleModal";

export function getSavedMarketplaceCart(): { items: any[]; total: number } {
  try {
    const candidateKeys = [
      "mabala_vendor_cart",
      "mabala_marketplace_cart",
      "agro_dealer_cart",
      "marketplace_cart",
      "cart",
      "saved_pos_basket",
      "pos_active_cart"
    ];
    for (const key of candidateKeys) {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const total = parsed.reduce((sum: number, item: any) => {
            const price = Number(item.price || item.unitPrice || item.retailPrice || item.cost || 0);
            const qty = Number(item.quantity || item.qty || 1);
            return sum + (price * qty);
          }, 0);
          return { items: parsed, total };
        } else if (parsed && Array.isArray(parsed.items) && parsed.items.length > 0) {
          const total = parsed.items.reduce((sum: number, item: any) => {
            const price = Number(item.price || item.unitPrice || item.retailPrice || item.cost || 0);
            const qty = Number(item.quantity || item.qty || 1);
            return sum + (price * qty);
          }, 0);
          return { items: parsed.items, total: parsed.total || total };
        }
      }
    }
  } catch (e) {
    console.warn("getSavedMarketplaceCart error:", e);
  }
  return { items: [], total: 0 };
}

interface FarmerWalletPanelProps {
  tenantId?: string;
  tenantName?: string;
  currencySymbol?: string;
  userEmail?: string;
  userId?: string;
  isSuperAdmin?: boolean;
  onNavigateToModule?: (moduleId: string) => void;
}

export default function FarmerWalletPanel({
  tenantId = "TENANT-001",
  tenantName = "Farm Operations",
  currencySymbol = "ZK",
  userEmail = "farmer@valleyfarms.zm",
  userId = "user_default",
  isSuperAdmin = false,
  onNavigateToModule
}: FarmerWalletPanelProps) {
  const [balances, setBalances] = useState<WalletBalances>(() => getWalletBalances(tenantId));
  const [transactions, setTransactions] = useState<LipilaTransaction[]>([]);

  // Bulk Disbursement & Fee Schedule Modal State
  const [showDisbursementModal, setShowDisbursementModal] = useState(false);
  const [showAdminFeeModal, setShowAdminFeeModal] = useState(false);

  // Top-Up Modal State
  const [showTopUpModal, setShowTopUpModal] = useState(false);
  const [topUpProvider, setTopUpProvider] = useState<"Airtel Money" | "MTN MoMo" | "Zamtel Kwacha">("Airtel Money");
  const [topUpPhone, setTopUpPhone] = useState("0977123456");
  const [topUpAmount, setTopUpAmount] = useState<number>(500);
  const [topUpLoading, setTopUpLoading] = useState(false);
  const [topUpSuccess, setTopUpSuccess] = useState<string | null>(null);
  const [topUpError, setTopUpError] = useState<string | null>(null);
  const [topUpHolderName, setTopUpHolderName] = useState<string>("Farmer Node Wallet");
  const [topUpSearchingName, setTopUpSearchingName] = useState<boolean>(false);

  // Automatic KYC Holder Name Lookup for Top-Up Phone
  useEffect(() => {
    if (!topUpPhone || topUpPhone.length < 8) return;
    setTopUpSearchingName(true);
    const timer = setTimeout(async () => {
      try {
        const canonical = normalizeZambianMobileNumber(topUpPhone);
        const res = await safeFetchJsonClient(`/api/payments/lookup?accountNumber=${encodeURIComponent(canonical)}&phone=${encodeURIComponent(canonical)}`).catch(() => null);
        if (res && (res.holderName || res.name || res.accountName)) {
          setTopUpHolderName(res.holderName || res.name || res.accountName);
          setTopUpSearchingName(false);
          return;
        }
      } catch (e) {
        // Fallback
      }
      setTopUpHolderName("Farmer Node Account");
      setTopUpSearchingName(false);
    }, 400);

    return () => clearTimeout(timer);
  }, [topUpPhone]);

  // Top-Up PIN Authorization Flow State
  const [topUpStep, setTopUpStep] = useState<"FORM" | "PENDING_PIN" | "SUCCESS" | "FAILED">("FORM");
  const [topUpRefId, setTopUpRefId] = useState<string>("");
  const [cleanPhoneState, setCleanPhoneState] = useState<string>("");
  const [timeRemaining, setTimeRemaining] = useState<number>(300);
  const [checkingManualStatus, setCheckingManualStatus] = useState<boolean>(false);
  const [copiedRef, setCopiedRef] = useState<boolean>(false);

  // Active top-up execution guards to prevent double-crediting
  const isFinalizingRef = useRef<boolean>(false);
  const fulfilledRefId = useRef<string | null>(null);

  // Spend Modal State
  const [showSpendModal, setShowSpendModal] = useState(false);
  const [spendCategory, setSpendCategory] = useState<SpendCategory>("invoice");
  const [spendAmount, setSpendAmount] = useState<number>(200);
  const [spendDescription, setSpendDescription] = useState("Platform Invoice Settlement");
  const [spendRecipientName, setSpendRecipientName] = useState("Mabala Platform Operations");
  const [spendRecipientPhone, setSpendRecipientPhone] = useState("0971000000");
  const [spendLoading, setSpendLoading] = useState(false);
  const [spendSuccess, setSpendSuccess] = useState<string | null>(null);
  const [spendError, setSpendError] = useState<string | null>(null);

  // Invoices & Marketplace verification states
  const [pendingInvoices, setPendingInvoices] = useState<PlatformInvoice[]>([]);
  const [showInvoicesModal, setShowInvoicesModal] = useState(false);
  const [loadingInvoices, setLoadingInvoices] = useState(false);
  const [payingInvoiceId, setPayingInvoiceId] = useState<string | null>(null);
  const [invoiceNotice, setInvoiceNotice] = useState<string | null>(null);
  const [cartNotice, setCartNotice] = useState<string | null>(null);

  // Calculated Outbound Fee Preview
  const outboundFeePreview: OutboundFeeBreakdown = calculateOutboundFee(spendAmount);

  // Load and subscribe to wallet updates for the active farm node
  useEffect(() => {
    const unsub = subscribeWalletUpdates((newBal) => {
      setBalances(newBal);
      loadTransactions();
    }, tenantId);
    return () => unsub();
  }, [tenantId]);

  // Countdown timer & auto-polling effect when topUpStep is PENDING_PIN
  useEffect(() => {
    if (topUpStep !== "PENDING_PIN" || !topUpRefId || !showTopUpModal) return;

    setTimeRemaining(300);

    // 1. 1-second countdown timer
    const countdownInterval = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(countdownInterval);
          setTopUpStep("FAILED");
          setTopUpError("PIN authorization timed out (300s expired). Funds were not deducted or added to your wallet balance.");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // 2. 3-second auto-polling loop to verify PIN authorization from Lipila API
    let pollCount = 0;
    const pollingInterval = setInterval(async () => {
      pollCount++;
      if (pollCount > 100) {
        clearInterval(pollingInterval);
        return;
      }

      if (isFinalizingRef.current || fulfilledRefId.current === topUpRefId) {
        clearInterval(pollingInterval);
        clearInterval(countdownInterval);
        return;
      }

      try {
        const check = await checkTopUpStatus(topUpRefId);
        if (check.status === "Successful" || check.status === "Success" || check.status === "Completed") {
          clearInterval(pollingInterval);
          clearInterval(countdownInterval);

          if (isFinalizingRef.current || fulfilledRefId.current === topUpRefId) return;
          isFinalizingRef.current = true;
          fulfilledRefId.current = topUpRefId;
          
          await finalizeTopUpWallet({
            tenantId,
            referenceId: topUpRefId,
            amount: topUpAmount,
            phone: cleanPhoneState || topUpPhone,
            provider: topUpProvider,
            accountName: "Farmer Node Wallet"
          });

          setTopUpStep("SUCCESS");
          setTopUpSuccess(`🎉 Top-Up Authorised & Credited! Added +${currencySymbol} ${topUpAmount.toLocaleString("en-US", { minimumFractionDigits: 2 })} to your Lipila Mobile Money Wallet.`);
          loadTransactions();
        } else if (check.status === "Failed" || check.status === "Rejected" || check.status === "Error") {
          clearInterval(pollingInterval);
          clearInterval(countdownInterval);
          setTopUpStep("FAILED");
          setTopUpError(check.message || "Mobile Money PIN prompt was rejected or failed on phone. Wallet balance was not credited.");
        }
      } catch (err) {
        // Silently retry on next poll interval
      }
    }, 3000);

    return () => {
      clearInterval(countdownInterval);
      clearInterval(pollingInterval);
    };
  }, [topUpStep, topUpRefId, showTopUpModal]);

  const loadTransactions = () => {
    try {
      const list = getTransactionsForTenant(tenantId);
      setTransactions(list);
    } catch (e) {
      console.warn("[FarmerWalletPanel] Tx load note:", e);
    }
  };

  const handleExecuteTopUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setTopUpLoading(true);
    setTopUpError(null);
    setTopUpSuccess(null);
    isFinalizingRef.current = false;
    fulfilledRefId.current = null;

    try {
      if (topUpAmount <= 0) {
        throw new Error("Please enter a valid top-up amount greater than 0.");
      }
      if (!topUpPhone || topUpPhone.length < 9) {
        throw new Error("Please enter a valid 10-digit mobile number.");
      }

      // Step 1: Dispatch collection request to Lipila gateway without crediting wallet
      const init = await initiateTopUpWallet({
        tenantId,
        amount: topUpAmount,
        provider: topUpProvider,
        phone: topUpPhone,
        accountName: "Farmer Node Wallet"
      });

      setTopUpRefId(init.referenceId);
      setCleanPhoneState(init.cleanPhone);
      setTopUpStep("PENDING_PIN");
    } catch (err: any) {
      setTopUpStep("FAILED");
      setTopUpError(err.message || "Failed to initiate mobile money payment collection.");
    } finally {
      setTopUpLoading(false);
    }
  };

  const handleManualCheckStatus = async () => {
    if (!topUpRefId || checkingManualStatus) return;
    if (isFinalizingRef.current || fulfilledRefId.current === topUpRefId) {
      setTopUpStep("SUCCESS");
      return;
    }

    setCheckingManualStatus(true);
    try {
      const check = await checkTopUpStatus(topUpRefId);
      if (check.status === "Successful" || check.status === "Success" || check.status === "Completed") {
        if (!isFinalizingRef.current && fulfilledRefId.current !== topUpRefId) {
          isFinalizingRef.current = true;
          fulfilledRefId.current = topUpRefId;

          await finalizeTopUpWallet({
            tenantId,
            referenceId: topUpRefId,
            amount: topUpAmount,
            phone: cleanPhoneState || topUpPhone,
            provider: topUpProvider,
            accountName: "Farmer Node Wallet"
          });
        }

        setTopUpStep("SUCCESS");
        setTopUpSuccess(`🎉 Top-Up Authorised & Credited! Added +${currencySymbol} ${topUpAmount.toLocaleString("en-US", { minimumFractionDigits: 2 })} to your Lipila Mobile Money Wallet.`);
        loadTransactions();
      } else if (check.status === "Failed" || check.status === "Rejected" || check.status === "Error") {
        setTopUpStep("FAILED");
        setTopUpError(check.message || "Mobile Money PIN prompt was rejected or failed on phone.");
      } else {
        setTopUpError("Payment status is still Pending. Please key in your Mobile Money PIN prompt on your phone and try again.");
      }
    } catch (err: any) {
      setTopUpError("Unable to verify payment status from the gateway at this time. Please try again.");
    } finally {
      setCheckingManualStatus(false);
    }
  };

  const handleExecuteSpend = async (e: React.FormEvent) => {
    e.preventDefault();
    setSpendLoading(true);
    setSpendError(null);
    setSpendSuccess(null);

    try {
      if (spendAmount <= 0) {
        throw new Error("Please enter a valid spend amount.");
      }

      const res = await spendWallet({
        tenantId,
        amount: spendAmount,
        category: spendCategory,
        description: spendDescription,
        recipientName: spendRecipientName,
        recipientPhone: spendRecipientPhone
      });

      setSpendSuccess(`✅ Spend Executed! Deducted ${currencySymbol} ${res.breakdown.totalDeducted.toFixed(2)} from wallet (Itemized: Principal ${currencySymbol} ${res.breakdown.principal.toFixed(2)}, Lipila Fee ${currencySymbol} ${res.breakdown.lipilaFee.toFixed(2)}, Flat Fee ${currencySymbol} ${res.breakdown.flatFee.toFixed(2)}).`);
      loadTransactions();
      setTimeout(() => {
        setShowSpendModal(false);
        setSpendSuccess(null);
      }, 3000);
    } catch (err: any) {
      setSpendError(err.message || "Spend failed.");
    } finally {
      setSpendLoading(false);
    }
  };

  // 1. Super Admin Invoices Lookup & Handling
  const handleOpenPayInvoices = async () => {
    setLoadingInvoices(true);
    try {
      const list = await fetchPlatformInvoices();
      // Filter for pending invoices that need payment
      const pending = list.filter(inv => 
        (inv.status === "PENDING" || (inv as any).status === "unpaid" || (inv as any).status === "overdue") &&
        (!inv.recipientTenantId || inv.recipientTenantId === tenantId || inv.recipientTenantId === "ALL" || inv.recipientTenantId === "TENANT-001")
      );
      if (pending.length === 0) {
        setInvoiceNotice("There are currently no pending platform invoices requiring payment for your account. All service plans, SMS top-ups, and platform renewals are fully settled.");
      } else {
        setPendingInvoices(pending);
        setShowInvoicesModal(true);
      }
    } catch (e) {
      setInvoiceNotice("Unable to retrieve pending invoices at this time. Please try again.");
    } finally {
      setLoadingInvoices(false);
    }
  };

  // Pay single pending invoice with itemized ledger spend
  const handlePaySingleInvoice = async (invoice: PlatformInvoice) => {
    setPayingInvoiceId(invoice.id);
    try {
      const res = await spendWallet({
        tenantId,
        amount: invoice.totalAmount,
        category: "invoice",
        description: `Settlement of Invoice ${invoice.invoiceNumber} (${invoice.lineItems?.map(l => l.description).join(", ") || "Platform Billing"})`,
        recipientName: "Mabala Super Admin Billing",
        recipientPhone: "0970000000"
      });

      await markPlatformInvoicePaid(invoice.id, res.tx.id);
      
      const updated = pendingInvoices.filter(inv => inv.id !== invoice.id);
      setPendingInvoices(updated);
      loadTransactions();

      if (updated.length === 0) {
        setShowInvoicesModal(false);
        setSpendSuccess(`✅ Invoice ${invoice.invoiceNumber} paid successfully! Deducted ${currencySymbol} ${res.breakdown.totalDeducted.toFixed(2)} from your wallet.`);
      }
    } catch (err: any) {
      setSpendError(err.message || "Failed to settle invoice.");
    } finally {
      setPayingInvoiceId(null);
    }
  };

  // 2. Agro-Dealer Marketplace Pay Farm Inputs Verification
  const handleOpenMarketplacePay = () => {
    const cart = getSavedMarketplaceCart();
    if (!cart || cart.items.length === 0 || cart.total <= 0) {
      setCartNotice("There are no active products in your cart. There are no saved products pending payment in the vendor marketplace. Please add farm inputs (seeds, fertilizers, crop chemicals) to your marketplace cart before initiating wallet payment.");
    } else {
      setSpendCategory("marketplace");
      setSpendAmount(cart.total);
      setSpendDescription(`Agro-Dealer Marketplace: ${cart.items.length} farm input product(s) pending payment`);
      setSpendRecipientName("Agro-Dealer Vendor Store");
      setSpendRecipientPhone("0972345678");
      setShowSpendModal(true);
    }
  };

  // Active Fee Config Rates from Super Admin Engine
  const lipilaFeeConfig = getFeeConfig("disbursement_platform_fee");
  const flatFeeConfig = getFeeConfig("farm_wallet_outbound_flat");

  const [activeTab, setActiveTab] = useState<"OPERATIONS" | "DDACC_LOANS">("OPERATIONS");

  return (
    <div className="space-y-6 text-slate-900 font-sans animate-fade-in" id="farmer-wallet-panel">
      {/* HEADER BANNER */}
      <div className="bg-white text-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative overflow-hidden">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-emerald-50 text-emerald-800 rounded-lg text-xs font-mono font-bold border border-emerald-200/80">
              MABALA-FARM-LEDGER-1020
            </span>
            <span className="text-[10px] font-extrabold uppercase text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200/80 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Lipila & DDACC Clearing Active</span>
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 mt-2 flex items-center gap-2">
            <Wallet className="w-7 h-7 text-emerald-600" />
            <span>Mabala Farm Ledger</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1 max-w-2xl">
            Account 1020 Mabala Ledger for seamless mobile money top-ups, agro-dealer marketplace purchases, HR payroll, and automated Direct Debit and Credit Clearing (DDACC) loan deductions to suppliers.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
          {isSuperAdmin && (
            <button
              onClick={() => setShowAdminFeeModal(true)}
              className="px-3.5 py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer border border-indigo-200"
              title="Super Admin Lipila Fee Schedule & Master Float Monitor"
            >
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>Fee & Float Engine</span>
            </button>
          )}
          <button
            onClick={() => {
              setTopUpAmount(500);
              setShowTopUpModal(true);
            }}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
          >
            <ArrowDownLeft className="w-4 h-4 text-white" />
            <span>In (Top-Up)</span>
          </button>
          <button
            id="mabala-ledger-out-button"
            onClick={() => setShowDisbursementModal(true)}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer border border-amber-400/80 hover:scale-[1.02] active:scale-[0.98]"
          >
            <ArrowUpRight className="w-4 h-4 text-slate-950 stroke-[3]" />
            <span>Out (Bulk Disburse)</span>
          </button>
          <button
            onClick={() => {
              setSpendAmount(200);
              setShowSpendModal(true);
            }}
            className="px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer border border-slate-200"
          >
            <span>Single Spend</span>
          </button>
        </div>
      </div>

      {/* TOP NAVIGATION TABS */}
      <div className="flex border-b border-slate-200 bg-white p-2 rounded-2xl gap-2 shadow-2xs">
        <button
          onClick={() => setActiveTab("OPERATIONS")}
          className={`px-5 py-2.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 ${
            activeTab === "OPERATIONS"
              ? "bg-slate-900 text-white shadow-sm"
              : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
          }`}
        >
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span>Mabala Ledger & Wallet Operations</span>
        </button>

        <button
          onClick={() => setActiveTab("DDACC_LOANS")}
          className={`px-5 py-2.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 ${
            activeTab === "DDACC_LOANS"
              ? "bg-emerald-600 text-white shadow-sm"
              : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>DDACC Supplier & Dealer Loans Auto-Deductions</span>
        </button>
      </div>

      {activeTab === "DDACC_LOANS" ? (
        <DdaccManagementDesk
          role="farmer"
          farmerTenantId={tenantId}
          currencySymbol={currencySymbol}
          onLedgerUpdated={() => {
            loadTransactions();
          }}
        />
      ) : (
        <>
          {/* BALANCE SPLIT METRICS CARDS */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Card 1: Mabala Ledger (Account 1020) */}
            <div className="bg-white rounded-2xl border border-emerald-200 p-5 space-y-3 shadow-sm relative overflow-hidden">
              <div className="absolute -right-4 -bottom-4 opacity-5 text-emerald-900 pointer-events-none">
                <Smartphone className="w-32 h-32" />
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 flex items-center gap-1">
                  <Smartphone className="w-3 h-3 text-emerald-600" />
                  <span>Mabala Ledger (Account 1020)</span>
                </span>
                <span className="text-[10px] font-mono text-slate-400 font-bold">Lipila & DDACC Ready</span>
              </div>
              <div>
                <div className="text-2xl font-black font-mono text-slate-900">
                  {currencySymbol} {balances.lipilaBalance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <p className="text-[11px] text-slate-500 font-medium mt-1">
                  Primary operational ledger for direct debit loan clearing, mobile money, and inputs.
                </p>
              </div>
              <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-[10.5px]">
                <span className="text-slate-500 font-bold">Top-Up Method:</span>
                <span className="font-mono text-emerald-700 font-bold">Airtel • MTN • Zamtel</span>
              </div>
            </div>

            {/* Card 2: Cash & Bank Operational Account (Account 1010) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3 shadow-sm relative overflow-hidden">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200 flex items-center gap-1">
                  <Landmark className="w-3 h-3 text-slate-500" />
                  <span>Cash & Bank Balance (Account 1010)</span>
                </span>
                <span className="text-[10px] font-mono text-slate-400 font-bold">POS / Bank</span>
              </div>
              <div>
                <div className="text-2xl font-black font-mono text-slate-800">
                  {currencySymbol} {balances.cashBalance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <p className="text-[11px] text-slate-500 font-medium mt-1">
                  Physical cash counter sales and direct bank deposit holdings.
                </p>
              </div>
              <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-[10.5px]">
                <span className="text-slate-500 font-bold">Cash/Ledger Ratio:</span>
                <span className="font-mono text-slate-700 font-bold">
                  {balances.totalBalance > 0 ? ((balances.lipilaBalance / balances.totalBalance) * 100).toFixed(0) : 0}% Mabala Ledger
                </span>
              </div>
            </div>

            {/* Card 3: Total Combined Liquid Funds */}
            <div className="bg-white text-slate-900 rounded-2xl border border-slate-200 p-5 space-y-3 shadow-2xs relative overflow-hidden">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 flex items-center gap-1">
                  <DollarSign className="w-3 h-3 text-amber-600" />
                  <span>Total Available Liquid Assets</span>
                </span>
                <span className="text-[10px] font-mono text-slate-500 font-bold">Combined Ledger</span>
              </div>
              <div>
                <div className="text-2xl font-black font-mono text-slate-900">
                  {currencySymbol} {balances.totalBalance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <p className="text-[11px] text-slate-500 font-medium mt-1">
                  Total liquid funds available across Mabala Ledger and Cash accounts.
                </p>
              </div>
              <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-[10.5px]">
                <span className="text-slate-500 font-bold">Active Outbound Fee Rate:</span>
                <span className="font-mono text-emerald-700 font-bold">
                  {lipilaFeeConfig?.value || 3.5}% + {currencySymbol} {(flatFeeConfig?.value || 3).toFixed(2)}
                </span>
              </div>
            </div>
          </div>

      {/* MULTI-PURPOSE IN-APP SPEND QUICK TILES */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
        <div className="flex justify-between items-center flex-wrap gap-2">
          <div>
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-indigo-600" />
              <span>Multi-Purpose In-App Wallet Spend Options</span>
            </h3>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Directly disburse funds from your Lipila Wallet with clear itemized fee breakdown transparency.
            </p>
          </div>
          <div className="flex items-center gap-2 bg-indigo-50 border border-indigo-100 text-indigo-800 px-3 py-1 rounded-xl text-xs font-mono font-bold">
            <Info className="w-3.5 h-3.5 text-indigo-600" />
            <span>Outbound Fee: {lipilaFeeConfig?.value || 3.5}% + K3 Flat Fee</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Tile 1: Platform Invoices */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 hover:border-purple-300 transition-all flex flex-col justify-between">
            <div className="space-y-3">
              <div className="p-2 bg-purple-100 text-purple-700 rounded-lg w-fit">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-900">Super Admin Invoices</h4>
                <p className="text-[11px] text-slate-500 mt-1">
                  Pay platform tier renewals, SMS credits, and corporate fees. Only displays pending invoices requiring payment.
                </p>
              </div>
            </div>
            <button
              onClick={handleOpenPayInvoices}
              disabled={loadingInvoices}
              className="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              {loadingInvoices ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <FileText className="w-3.5 h-3.5" />}
              <span>{loadingInvoices ? "Checking Invoices..." : "Pay Invoices"}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Tile 2: Agro-Dealer Marketplace */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 hover:border-emerald-300 transition-all flex flex-col justify-between">
            <div className="space-y-3">
              <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg w-fit">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-900">Agro-Dealer Marketplace</h4>
                <p className="text-[11px] text-slate-500 mt-1">
                  Purchase seeds, fertilizers, feeds, and chemicals. Only displays pending payments for active cart items.
                </p>
              </div>
            </div>
            <button
              onClick={handleOpenMarketplacePay}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Pay Farm Inputs</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Tile 3: AGC Agro Loans & DDACC Repayments */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 hover:border-amber-300 transition-all flex flex-col justify-between">
            <div className="space-y-3">
              <div className="p-2 bg-amber-100 text-amber-800 rounded-lg w-fit">
                <ShieldCheck className="w-5 h-5 text-emerald-700" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-900">DDACC Loan Repayments</h4>
                <p className="text-[11px] text-slate-500 mt-1">
                  Shows active DDACC loan mandates and scheduled auto-deductions from Account 1020.
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                setActiveTab("DDACC_LOANS");
              }}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Manage DDACC Loans</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Tile 4: Lipila Bulk Payouts & Payroll Out */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 hover:border-amber-400 transition-all flex flex-col justify-between">
            <div className="space-y-3">
              <div className="p-2 bg-amber-100 text-amber-900 rounded-lg w-fit">
                <ArrowUpRight className="w-5 h-5 text-amber-700" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-900">Bulk Payouts & Payroll</h4>
                <p className="text-[11px] text-slate-500 mt-1">
                  Disburse employee salaries, supplier payouts, or casual laborer wages directly to Mobile Money or Banks.
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowDisbursementModal(true)}
              className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
            >
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>Out (Bulk Disburse)</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* TRANSACTION LEDGER TABLE WITH ITEMIZED FEE COLUMNS */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm space-y-4 p-6">
        <div className="flex justify-between items-center flex-wrap gap-2">
          <div>
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
              <Receipt className="w-4 h-4 text-emerald-600" />
              <span>Ledger Transaction History & Itemized Payment Ledger</span>
            </h3>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              All wallet top-ups and outbound spending with itemized Lipila and K3 flat fees.
            </p>
          </div>
          <button
            onClick={loadTransactions}
            className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 transition-colors"
            title="Refresh History"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-600 font-extrabold text-[10.5px] uppercase tracking-wider border-b border-slate-200">
                <th className="p-3">Reference & Date</th>
                <th className="p-3">Category / Module</th>
                <th className="p-3">Provider / Target</th>
                <th className="p-3 text-right">Principal</th>
                <th className="p-3 text-right">Lipila Fee ({lipilaFeeConfig?.value || 3.5}%)</th>
                <th className="p-3 text-right">Flat Fee (K3)</th>
                <th className="p-3 text-right">Total Debit / Credit</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-6 text-center text-slate-400 italic">
                    No wallet transactions recorded yet. Perform a top-up or spend above!
                  </td>
                </tr>
              ) : (
                transactions.slice(0, 15).map((tx) => {
                  const isTopUp = tx.type?.includes("Collection") || tx.paymentType === "Top-Up" || tx.module?.includes("Top-Up");
                  const principal = tx.principalAmount !== undefined ? tx.principalAmount : (isTopUp ? tx.amount : tx.amount - (tx.lipilaFeeAmount || 0) - (tx.flatFeeAmount || 0));
                  const lipilaFee = tx.lipilaFeeAmount || 0;
                  const flatFee = tx.flatFeeAmount || 0;
                  const total = tx.amount || (principal + lipilaFee + flatFee);

                  return (
                    <tr key={tx.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 space-y-0.5">
                        <div className="font-mono font-bold text-slate-900">{tx.id}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {new Date(tx.createdAt).toLocaleString()}
                        </div>
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                          isTopUp ? "bg-emerald-100 text-emerald-800" : "bg-indigo-100 text-indigo-800"
                        }`}>
                          {tx.module || (isTopUp ? "Top-Up" : "Wallet Spend")}
                        </span>
                        <div className="text-[11px] text-slate-500 font-normal truncate max-w-xs mt-0.5">
                          {tx.description}
                        </div>
                      </td>
                      <td className="p-3 font-mono text-[11px] text-slate-600">
                        {tx.accountInfo?.provider || tx.accountInfo?.walletName || tx.customerName || "Wallet Engine"}
                      </td>
                      <td className="p-3 text-right font-mono font-bold text-slate-900">
                        {currencySymbol} {principal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="p-3 text-right font-mono text-slate-600">
                        {isTopUp ? "—" : `${currencySymbol} ${lipilaFee.toFixed(2)}`}
                      </td>
                      <td className="p-3 text-right font-mono text-slate-600">
                        {isTopUp ? "—" : `${currencySymbol} ${flatFee.toFixed(2)}`}
                      </td>
                      <td className="p-3 text-right font-mono font-black">
                        <span className={isTopUp ? "text-emerald-700" : "text-rose-700"}>
                          {isTopUp ? "+" : "-"}{currencySymbol} {total.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-800">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>COMPLETED</span>
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  )}

      {/* TOP-UP MODAL WITH SECURE LIVE LIPILA TERMINAL PIN PROMPT VERIFICATION */}
      {showTopUpModal && (
        <LipilaCheckoutModal
          checkout={{
            type: "wallet_topup",
            name: "Farmer Node Wallet Top-Up",
            price: topUpAmount,
            currency: currencySymbol || "ZMW",
            creditsToAward: 0,
            description: `Direct deposit to farmer ledger (${tenantId || 'primary node'}). Instant Mobile Money credit.`
          }}
          phone={topUpPhone}
          setPhone={setTopUpPhone}
          holderName={topUpHolderName}
          searchingName={topUpSearchingName}
          paymentStatus={
            topUpStep === "PENDING_PIN" ? "Pending" :
            topUpStep === "SUCCESS" ? "Successful" :
            topUpStep === "FAILED" ? "Failed" :
            topUpLoading ? "Submitting" : "Idle"
          }
          refId={topUpRefId}
          error={topUpError || ""}
          timeRemaining={timeRemaining}
          onCancel={() => {
            setShowTopUpModal(false);
            setTopUpStep("FORM");
            setTopUpError(null);
            setTopUpSuccess(null);
          }}
          onSubmitPayment={async (customAmt) => {
            const amt = customAmt || topUpAmount;
            setTopUpAmount(amt);
            setTopUpLoading(true);
            setTopUpError(null);
            try {
              if (amt <= 0) {
                throw new Error("Please enter a valid top-up amount greater than 0.");
              }
              const provider = detectTelcoProvider(topUpPhone).operatorName as any;
              setTopUpProvider(provider);
              const init = await initiateTopUpWallet({
                tenantId,
                amount: amt,
                provider,
                phone: topUpPhone,
                accountName: topUpHolderName || "Farmer Node Wallet"
              });
              setTopUpRefId(init.referenceId);
              setCleanPhoneState(init.cleanPhone);
              setTopUpStep("PENDING_PIN");
            } catch (err: any) {
              setTopUpStep("FAILED");
              setTopUpError(err.message || "Failed to initiate mobile money top-up.");
            } finally {
              setTopUpLoading(false);
            }
          }}
          onCheckStatusManually={handleManualCheckStatus}
          onRetry={() => {
            setTopUpStep("FORM");
            setTopUpError(null);
          }}
        />
      )}

      {/* SPEND MODAL WITH ITEMIZED OUTBOUND FEE BREAKDOWN */}
      {showSpendModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-[9999] animate-fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-start border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] font-black uppercase text-indigo-600 tracking-wider">
                  Itemized Outbound Wallet Spend
                </span>
                <h3 className="text-lg font-black text-slate-900 flex items-center gap-2 mt-0.5">
                  <ArrowUpRight className="w-5 h-5 text-indigo-600" />
                  <span>Outbound Wallet Spend Authorization</span>
                </h3>
              </div>
              <button
                onClick={() => setShowSpendModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-lg"
              >
                ✕
              </button>
            </div>

            {spendSuccess && (
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{spendSuccess}</span>
              </div>
            )}

            {spendError && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{spendError}</span>
              </div>
            )}

            <form onSubmit={handleExecuteSpend} className="space-y-4 text-xs font-sans">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                  Spend Purpose / Category
                </label>
                <select
                  value={spendCategory}
                  onChange={(e) => setSpendCategory(e.target.value as SpendCategory)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none"
                >
                  <option value="invoice">Platform Invoices (Billing Centre)</option>
                  <option value="marketplace">Agro-Dealer Marketplace Purchases</option>
                  <option value="loan_repayment">AGC Agro Loan Repayments</option>
                  <option value="sms_topup">SMS Unit Top-Up / Platform Service</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                  Principal Amount ({currencySymbol})
                </label>
                <input
                  type="number"
                  min="1"
                  step="0.01"
                  value={spendAmount}
                  onChange={(e) => setSpendAmount(Number(e.target.value))}
                  required
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-black text-slate-900 outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                  Description / Payment Notes
                </label>
                <input
                  type="text"
                  value={spendDescription}
                  onChange={(e) => setSpendDescription(e.target.value)}
                  placeholder="e.g. Platform Tier & Billing Renewal"
                  required
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none"
                />
              </div>

              {/* ITEMIZED FEE BREAKDOWN PREVIEW */}
              <div className="p-4 bg-indigo-50/60 rounded-2xl border border-indigo-100 space-y-2.5 text-xs">
                <div className="flex justify-between items-center border-b border-indigo-100 pb-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-indigo-800">
                    Itemized Fee Breakdown (Required Platform Standard)
                  </span>
                  <span className="text-[10px] font-mono text-indigo-600 font-bold">
                    Super Admin Rate
                  </span>
                </div>

                <div className="space-y-1.5 font-medium text-slate-700">
                  <div className="flex justify-between">
                    <span>Principal Payment Amount:</span>
                    <span className="font-mono font-bold text-slate-900">{currencySymbol} {outboundFeePreview.principal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-indigo-900">
                    <span>Lipila Outbound Fee ({outboundFeePreview.lipilaFeePercent}%):</span>
                    <span className="font-mono font-bold">{currencySymbol} {outboundFeePreview.lipilaFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-indigo-900">
                    <span>Outbound Flat Fee (Super Admin Configured):</span>
                    <span className="font-mono font-bold">{currencySymbol} {outboundFeePreview.flatFee.toFixed(2)}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-indigo-200/80 flex justify-between items-center text-slate-900 font-bold">
                  <span>Total Wallet Deduction:</span>
                  <span className="font-mono font-black text-sm text-indigo-900">
                    {currencySymbol} {outboundFeePreview.totalDeducted.toFixed(2)}
                  </span>
                </div>
                <p className="text-[10px] text-indigo-700 italic">
                  Note: The flat fee is itemized separately and is not silently bundled into the principal.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowSpendModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={spendLoading}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {spendLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ArrowUpRight className="w-4 h-4" />}
                  <span>{spendLoading ? "Processing..." : `Confirm Spend (${currencySymbol} ${outboundFeePreview.totalDeducted.toFixed(2)})`}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PENDING SUPER ADMIN INVOICES PAYMENT MODAL */}
      {showInvoicesModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-[9999] animate-fade-in">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] font-black uppercase text-purple-600 tracking-wider">
                  Pending Platform Invoices
                </span>
                <h3 className="text-lg font-black text-slate-900 flex items-center gap-2 mt-0.5">
                  <FileText className="w-5 h-5 text-purple-600" />
                  <span>Unpaid Invoices Requiring Settlement</span>
                </h3>
              </div>
              <button
                onClick={() => setShowInvoicesModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-lg"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-500 font-medium">
              Below are the active pending invoices issued to your account. Settle directly from your Account 1020 Mabala Ledger balance with itemized fee transparency.
            </p>

            <div className="space-y-3">
              {pendingInvoices.map((inv) => {
                const feeBreakdown = calculateOutboundFee(inv.totalAmount);
                const isPaying = payingInvoiceId === inv.id;

                return (
                  <div
                    key={inv.id}
                    className="p-4 bg-slate-50 rounded-xl border border-slate-200 hover:border-purple-300 transition-all space-y-3"
                  >
                    <div className="flex justify-between items-start flex-wrap gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-xs text-purple-800 bg-purple-100 px-2 py-0.5 rounded-md">
                            {inv.invoiceNumber}
                          </span>
                          <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full uppercase">
                            Pending Settlement
                          </span>
                        </div>
                        <h4 className="font-bold text-xs text-slate-900 mt-1">
                          {inv.lineItems && inv.lineItems.length > 0
                            ? inv.lineItems.map(l => l.description).join(", ")
                            : "Platform Tier Subscription & Services"}
                        </h4>
                        <span className="text-[10.5px] text-slate-500 font-medium">
                          Due Date: {inv.dueDate ? new Date(inv.dueDate).toLocaleDateString() : "Immediate"}
                        </span>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">Principal</span>
                        <span className="font-mono font-black text-sm text-slate-900">
                          {currencySymbol} {inv.totalAmount.toFixed(2)}
                        </span>
                      </div>
                    </div>

                    {/* Itemized Fee Breakdown snippet */}
                    <div className="bg-white p-3 rounded-lg border border-slate-200/80 text-[11px] space-y-1">
                      <div className="flex justify-between text-slate-600">
                        <span>Invoice Principal:</span>
                        <span className="font-mono font-bold text-slate-800">{currencySymbol} {feeBreakdown.principal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-indigo-700">
                        <span>Lipila Outbound Fee ({feeBreakdown.lipilaFeePercent}%):</span>
                        <span className="font-mono font-bold">{currencySymbol} {feeBreakdown.lipilaFee.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-indigo-700">
                        <span>Outbound Flat Fee:</span>
                        <span className="font-mono font-bold">{currencySymbol} {feeBreakdown.flatFee.toFixed(2)}</span>
                      </div>
                      <div className="pt-1.5 border-t border-slate-100 flex justify-between font-extrabold text-slate-900">
                        <span>Total Wallet Debit:</span>
                        <span className="font-mono text-purple-700">{currencySymbol} {feeBreakdown.totalDeducted.toFixed(2)}</span>
                      </div>
                    </div>

                    <div className="flex justify-end pt-1">
                      <button
                        onClick={() => handlePaySingleInvoice(inv)}
                        disabled={isPaying || balances.available < feeBreakdown.totalDeducted}
                        className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        {isPaying ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            <span>Processing Settlement...</span>
                          </>
                        ) : (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>
                              {balances.available < feeBreakdown.totalDeducted
                                ? "Insufficient Wallet Balance"
                                : `Pay ${currencySymbol} ${feeBreakdown.totalDeducted.toFixed(2)} via Wallet`}
                            </span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-100">
              <button
                onClick={() => setShowInvoicesModal(false)}
                className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 font-bold hover:bg-slate-50 text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* NO PENDING INVOICES NOTICE DIALOG */}
      {invoiceNotice && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-[9999] animate-fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-200 text-center">
            <div className="w-12 h-12 bg-purple-100 text-purple-700 rounded-2xl flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-black text-slate-900">
              No Pending Platform Invoices
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed font-medium">
              {invoiceNotice}
            </p>
            <div className="pt-2">
              <button
                onClick={() => setInvoiceNotice(null)}
                className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-colors cursor-pointer"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}

      {/* NO ACTIVE CART PRODUCTS NOTICE DIALOG */}
      {cartNotice && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-[9999] animate-fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-200 text-center">
            <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded-2xl flex items-center justify-center mx-auto">
              <ShoppingBag className="w-6 h-6" />
            </div>
            <h3 className="text-base font-black text-slate-900">
              No Active Products in Cart
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed font-medium">
              {cartNotice}
            </p>
            <div className="pt-2 flex flex-col sm:flex-row gap-2 justify-center">
              <button
                onClick={() => setCartNotice(null)}
                className="px-4 py-2.5 border border-slate-200 text-slate-700 font-extrabold text-xs rounded-xl hover:bg-slate-50 transition-colors"
              >
                Dismiss
              </button>
              {onNavigateToModule && (
                <button
                  onClick={() => {
                    setCartNotice(null);
                    onNavigateToModule("MARKETPLACE");
                  }}
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Browse Marketplace</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MABALA LEDGER: 5-SCREEN BULK DISBURSEMENT MODAL (OUT BUTTON) */}
      <BulkDisbursementModal
        isOpen={showDisbursementModal}
        onClose={() => setShowDisbursementModal(false)}
        tenantId={tenantId}
        tenantName={tenantName}
        currentBalance={balances.lipilaBalance}
        userEmail={userEmail}
        userId={userId}
        isSuperAdmin={isSuperAdmin}
        currencySymbol={currencySymbol}
        onDisbursementComplete={(batch) => {
          loadTransactions();
        }}
      />

      {/* SUPER ADMIN: LIPILA FEE SCHEDULE & MASTER WALLET FLOAT MODAL */}
      {isSuperAdmin && (
        <SuperAdminFeeScheduleModal
          isOpen={showAdminFeeModal}
          onClose={() => setShowAdminFeeModal(false)}
          userEmail={userEmail}
          userId={userId}
          currencySymbol={currencySymbol}
        />
      )}
    </div>
  );
}

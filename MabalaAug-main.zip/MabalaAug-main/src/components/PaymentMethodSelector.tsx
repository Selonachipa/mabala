import React from "react";
import { CreditCard, Smartphone, ShieldCheck, Info } from "lucide-react";
import { getFeeConfig } from "../services/feeConfigService";
import { calculateCardCollectionFees } from "../services/mabalaPlatformEngine";

export interface CardDetails {
  city: string;
  country: string;
  address: string;
  zip: string;
  email: string;
  holderName: string;
  cardNumber?: string;
  expiry?: string;
  cvc?: string;
}

interface PaymentMethodSelectorProps {
  selectedMethod: "mobile_money" | "card";
  onChangeMethod: (method: "mobile_money" | "card") => void;
  cardDetails: CardDetails;
  onCardDetailsChange: (details: CardDetails) => void;
  subtotal?: number;
  showFeeBreakdown?: boolean;
}

export default function PaymentMethodSelector({
  selectedMethod,
  onChangeMethod,
  cardDetails,
  onCardDetailsChange,
  subtotal = 0,
  showFeeBreakdown = true,
}: PaymentMethodSelectorProps) {
  const cardFeeConfig = getFeeConfig("card_collection");
  const feeRate = cardFeeConfig && cardFeeConfig.active ? cardFeeConfig.value : 3.0;
  const fees = calculateCardCollectionFees(subtotal);

  const handleDetailChange = (field: keyof CardDetails, value: string) => {
    onCardDetailsChange({
      ...cardDetails,
      [field]: value,
    });
  };

  return (
    <div className="space-y-4 font-sans text-slate-900">
      <label className="text-xs font-black uppercase text-slate-400 tracking-wider block">
        Select Collection Payment Channel
      </label>

      {/* SELECTOR TOGGLE BUTTONS */}
      <div className="grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => onChangeMethod("mobile_money")}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
            selectedMethod === "mobile_money"
              ? "bg-slate-900 text-white border-slate-900 shadow-md ring-2 ring-emerald-500/30"
              : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
          }`}
        >
          <div className={`p-2.5 rounded-xl ${selectedMethod === "mobile_money" ? "bg-emerald-500/20 text-emerald-400" : "bg-slate-200 text-slate-600"}`}>
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <div className="font-extrabold text-xs">Mobile Money Push</div>
            <div className={`text-[10px] ${selectedMethod === "mobile_money" ? "text-slate-300" : "text-slate-500"}`}>
              Airtel, MTN, Zamtel PIN
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => onChangeMethod("card")}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
            selectedMethod === "card"
              ? "bg-slate-900 text-white border-slate-900 shadow-md ring-2 ring-indigo-500/30"
              : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
          }`}
        >
          <div className={`p-2.5 rounded-xl ${selectedMethod === "card" ? "bg-indigo-500/20 text-indigo-400" : "bg-slate-200 text-slate-600"}`}>
            <CreditCard className="w-5 h-5" />
          </div>
          <div>
            <div className="font-extrabold text-xs">Visa / Mastercard</div>
            <div className={`text-[10px] ${selectedMethod === "card" ? "text-slate-300" : "text-slate-500"}`}>
              Lipila Card Gateway ({feeRate}% fee)
            </div>
          </div>
        </button>
      </div>

      {/* CARD DETAILS FORM */}
      {selectedMethod === "card" && (
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-white space-y-3.5 animate-fade-in">
          <div className="flex justify-between items-center border-b border-slate-850 pb-2">
            <span className="text-[11px] font-extrabold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> Lipila 3D Secure Card Verification
            </span>
            <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
              3DS Enabled
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Cardholder Full Name</label>
              <input
                type="text"
                required
                placeholder="e.g. Chisamba Commercial Farm"
                value={cardDetails.holderName}
                onChange={(e) => handleDetailChange("holderName", e.target.value)}
                className="w-full text-xs font-semibold bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Billing Email</label>
              <input
                type="email"
                required
                placeholder="billing@farm.co.zm"
                value={cardDetails.email}
                onChange={(e) => handleDetailChange("email", e.target.value)}
                className="w-full text-xs font-semibold bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Street Address</label>
            <input
              type="text"
              required
              placeholder="Plot 401, Great North Road"
              value={cardDetails.address}
              onChange={(e) => handleDetailChange("address", e.target.value)}
              className="w-full text-xs font-semibold bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">City</label>
              <input
                type="text"
                required
                placeholder="Lusaka"
                value={cardDetails.city}
                onChange={(e) => handleDetailChange("city", e.target.value)}
                className="w-full text-xs font-semibold bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Country (ISO2)</label>
              <input
                type="text"
                required
                placeholder="ZM"
                maxLength={2}
                value={cardDetails.country}
                onChange={(e) => handleDetailChange("country", e.target.value.toUpperCase())}
                className="w-full text-xs font-mono font-bold uppercase bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">ZIP / Postal Code</label>
              <input
                type="text"
                required
                placeholder="10101"
                value={cardDetails.zip}
                onChange={(e) => handleDetailChange("zip", e.target.value)}
                className="w-full text-xs font-semibold bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* FEE BREAKDOWN CARD */}
      {showFeeBreakdown && subtotal > 0 && selectedMethod === "card" && (
        <div className="bg-indigo-950/40 p-3.5 rounded-2xl border border-indigo-500/30 text-xs space-y-2 animate-fade-in">
          <div className="flex justify-between text-slate-300">
            <span>Base Order Subtotal:</span>
            <span className="font-mono font-bold text-white">ZMW {subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-indigo-300">
            <span className="flex items-center gap-1">
              <Info className="w-3.5 h-3.5" /> Card Platform Fee ({feeRate}%):
            </span>
            <span className="font-mono font-bold text-indigo-200">+ ZMW {fees.cardFee.toFixed(2)}</span>
          </div>
          <div className="flex justify-between font-black text-white pt-2 border-t border-indigo-500/20 text-sm">
            <span>Total Amount Charged to Card:</span>
            <span className="font-mono text-emerald-400">ZMW {fees.totalAmountToChargeBuyer.toFixed(2)}</span>
          </div>
          <div className="text-[9.5px] text-slate-400 font-medium italic">
            * Merchant receives ZMW {fees.netVendorCredit.toFixed(2)} net payout. The {feeRate}% fee is added to the buyer checkout amount.
          </div>
        </div>
      )}
    </div>
  );
}

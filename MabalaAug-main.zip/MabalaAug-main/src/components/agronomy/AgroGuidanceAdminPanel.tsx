import React, { useState, useEffect } from "react";
import { CropKnowledgeBaseItem, CropKnowledgeStage } from "../../types";
import { SEED_RED_ONION, SEED_HASS_AVOCADO } from "../../services/cropGuidanceService";
import { 
  BookOpen, Plus, Check, Edit, Eye, ShieldCheck, RefreshCw, 
  MessageSquare, Sparkles, FileText, Send, AlertTriangle, ChevronRight
} from "lucide-react";

export const AgroGuidanceAdminPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"ckb" | "briefs" | "feedback" | "analytics">("ckb");
  const [crops, setCrops] = useState<CropKnowledgeBaseItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedCrop, setSelectedCrop] = useState<CropKnowledgeBaseItem | null>(null);
  const [unreviewedBriefs, setUnreviewedBriefs] = useState<any[]>([]);
  const [feedbackItems, setFeedbackItems] = useState<any[]>([]);
  const [learningAnalytics, setLearningAnalytics] = useState<any>(null);

  const fetchCkbCrops = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/agronomy/crop-knowledge-base?includeDrafts=true");
      const data = await res.json();
      if (data.success && data.crops) {
        setCrops(data.crops);
      } else {
        setCrops([SEED_RED_ONION, SEED_HASS_AVOCADO]);
      }
    } catch (err) {
      console.warn("[Fetch CKB Error]", err);
      setCrops([SEED_RED_ONION, SEED_HASS_AVOCADO]);
    } finally {
      setLoading(false);
    }
  };

  const fetchLearningAnalytics = async () => {
    try {
      const res = await fetch("/api/agronomy/superadmin-learning-analytics");
      const data = await res.json();
      if (data.success && data.analytics) {
        setLearningAnalytics(data.analytics);
        setUnreviewedBriefs(data.analytics.unreviewedBriefs || []);
        setFeedbackItems(data.analytics.feedbackItems || []);
      }
    } catch (err) {
      console.warn("[Fetch Learning Analytics Error]", err);
    }
  };

  useEffect(() => {
    fetchCkbCrops();
    fetchLearningAnalytics();
  }, []);

  const handleSeedDatabase = async () => {
    try {
      const res = await fetch("/api/agronomy/seed", { method: "POST" });
      const data = await res.json();
      alert(data.message || "Seeding complete!");
      fetchCkbCrops();
    } catch (err: any) {
      alert("Seed error: " + err.message);
    }
  };

  const handleStatusChange = async (cropId: string, nextStatus: "draft" | "needs_review" | "published") => {
    try {
      const targetCrop = crops.find(c => c.cropId === cropId);
      if (!targetCrop) return;

      const updated = { ...targetCrop, status: nextStatus };
      await fetch("/api/agronomy/crop-knowledge-base", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cropItem: updated, stages: targetCrop.stages })
      });

      fetchCkbCrops();
    } catch (err: any) {
      alert("Update error: " + err.message);
    }
  };

  const handlePublishBrief = async (skuId: string) => {
    try {
      await fetch("/api/agronomy/publish-product-brief", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ skuId, adminUid: "super_admin" })
      });
      alert("Product brief published!");
      fetchLearningAnalytics();
    } catch (err: any) {
      alert("Publish brief error: " + err.message);
    }
  };

  return (
    <div className="space-y-6 p-6 bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-sm">
      {/* Header & Sub-Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
        <div>
          <h2 className="text-xl font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-emerald-600" />
            AI Crop Knowledge Base & Content Admin Portal
          </h2>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
            Curate agronomy guidance models, review chemical product briefs, and monitor usage learning
          </p>
        </div>

        <div className="flex items-center gap-2 bg-stone-100 dark:bg-stone-800 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab("ckb")}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === "ckb" 
                ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs" 
                : "text-stone-500 hover:text-stone-900 dark:text-stone-400"
            }`}
          >
            Crop Guidelines
          </button>
          <button
            onClick={() => setActiveTab("briefs")}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === "briefs" 
                ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs" 
                : "text-stone-500 hover:text-stone-900 dark:text-stone-400"
            }`}
          >
            Chemical Briefs
            {unreviewedBriefs.length > 0 && (
              <span className="px-1.5 py-0.2 bg-amber-500 text-stone-950 font-black text-[10px] rounded-full">
                {unreviewedBriefs.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab("feedback")}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === "feedback" 
                ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs" 
                : "text-stone-500 hover:text-stone-900 dark:text-stone-400"
            }`}
          >
            Farmer Feedback
          </button>
          <button
            onClick={() => setActiveTab("analytics")}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === "analytics" 
                ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs" 
                : "text-stone-500 hover:text-stone-900 dark:text-stone-400"
            }`}
          >
            Usage Analytics
          </button>
        </div>
      </div>

      {activeTab === "ckb" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100">
              Curated Crop Knowledge Base Catalog
            </h3>
            <button
              onClick={handleSeedDatabase}
              className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-lg shadow-xs flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Re-Seed Red Onion & Hass Avocado
            </button>
          </div>

          {loading ? (
            <div className="py-8 text-center text-xs text-stone-400 animate-pulse">
              Loading Crop Knowledge Base Catalog...
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {crops.map((crop) => (
                <div key={crop.cropId} className="p-4 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-base font-bold text-stone-900 dark:text-stone-100">
                        {crop.cropName}
                      </h4>
                      <span className="text-xs text-stone-500 dark:text-stone-400">
                        Type: {crop.cropType} • {crop.stages?.length || 0} Stages Curated
                      </span>
                    </div>

                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      crop.status === "published" 
                        ? "bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300" 
                        : "bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300"
                    }`}>
                      {crop.status}
                    </span>
                  </div>

                  <p className="text-xs text-stone-600 dark:text-stone-300 line-clamp-2">
                    {crop.sourceCurationNotes}
                  </p>

                  <div className="flex items-center justify-between pt-2 border-t border-stone-200 dark:border-stone-700">
                    <div className="flex items-center gap-1">
                      {crop.status !== "published" && (
                        <button
                          onClick={() => handleStatusChange(crop.cropId, "published")}
                          className="px-2.5 py-1 bg-emerald-700 text-white text-[11px] font-bold rounded hover:bg-emerald-800"
                        >
                          Publish to Farmers
                        </button>
                      )}
                      {crop.status === "published" && (
                        <button
                          onClick={() => handleStatusChange(crop.cropId, "draft")}
                          className="px-2.5 py-1 bg-stone-300 dark:bg-stone-700 text-stone-800 dark:text-stone-200 text-[11px] font-bold rounded"
                        >
                          Revert to Draft
                        </button>
                      )}
                    </div>

                    <button
                      onClick={() => setSelectedCrop(crop)}
                      className="text-xs text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-0.5"
                    >
                      Inspect Stages <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Selected Crop Stage Inspector Modal */}
          {selectedCrop && (
            <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="bg-white dark:bg-stone-900 rounded-2xl max-w-2xl w-full p-6 border border-stone-200 dark:border-stone-800 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
                <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
                  <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100">
                    Stage Curation: {selectedCrop.cropName}
                  </h3>
                  <button onClick={() => setSelectedCrop(null)} className="text-stone-400 text-sm font-bold">✕</button>
                </div>

                <div className="space-y-3">
                  {selectedCrop.stages?.map((stage, idx) => (
                    <div key={stage.stageId} className="p-3 bg-stone-50 dark:bg-stone-800/60 rounded-xl border border-stone-200 dark:border-stone-700 text-xs space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-stone-900 dark:text-stone-100">
                          Stage {idx + 1}: {stage.stageName}
                        </span>
                        <span className="px-2 py-0.5 bg-stone-200 dark:bg-stone-700 rounded text-[10px]">
                          Trigger: {stage.triggerType} ({stage.triggerValue})
                        </span>
                      </div>
                      <p className="text-stone-600 dark:text-stone-300">{stage.description}</p>
                      <div className="text-[11px] text-stone-500">
                        Tasks: {stage.tasks?.length || 0} • Input Categories: {stage.inputCategoriesNeeded?.length || 0}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === "briefs" && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100">
            Chemical Product AI Briefs Review Queue
          </h3>

          {unreviewedBriefs.length === 0 ? (
            <p className="text-xs text-stone-500 p-4 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-200 dark:border-stone-800">
              No unreviewed chemical briefs in the queue.
            </p>
          ) : (
            <div className="space-y-3">
              {unreviewedBriefs.map((brief: any) => (
                <div key={brief.skuId} className="p-4 rounded-xl border border-amber-200 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/20 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-stone-900 dark:text-stone-100 text-sm">
                      SKU: {brief.skuId}
                    </span>
                    <button
                      onClick={() => handlePublishBrief(brief.skuId)}
                      className="px-3 py-1 bg-emerald-700 text-white font-bold text-xs rounded hover:bg-emerald-800"
                    >
                      Publish Brief
                    </button>
                  </div>
                  <p className="text-stone-600 dark:text-stone-300"><strong>Guidance:</strong> {brief.applicationGuidance}</p>
                  <p className="text-stone-600 dark:text-stone-300"><strong>Safety & PHI:</strong> {brief.safetyWithholdingNote}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === "feedback" && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100">
            Farmer Field Feedback Reports
          </h3>

          {feedbackItems.length === 0 ? (
            <p className="text-xs text-stone-500 p-4 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-200 dark:border-stone-800">
              No farmer feedback submissions recorded yet.
            </p>
          ) : (
            <div className="space-y-2">
              {feedbackItems.map((fb: any, idx: number) => (
                <div key={idx} className="p-3 bg-stone-50 dark:bg-stone-800/50 rounded-xl border border-stone-200 dark:border-stone-700 text-xs space-y-1">
                  <div className="flex items-center justify-between text-stone-500">
                    <span>Crop: {fb.cropId} • Stage: {fb.stageId}</span>
                    <span>{fb.createdAt ? new Date(fb.createdAt).toLocaleDateString() : ""}</span>
                  </div>
                  <p className="text-stone-900 dark:text-stone-100 font-medium">"{fb.note}"</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === "analytics" && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100">
            Super Admin Usage Learning Analytics
          </h3>

          {learningAnalytics && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-stone-50 dark:bg-stone-800/50 rounded-xl border border-stone-200 dark:border-stone-700 space-y-2">
                <h4 className="font-bold text-stone-900 dark:text-stone-100">Top Crops Missing CKB Entries</h4>
                <div className="space-y-1.5">
                  {learningAnalytics.mostPlantedMissingCkb?.map((m: any, i: number) => (
                    <div key={i} className="flex items-center justify-between p-2 bg-white dark:bg-stone-900 rounded">
                      <span>{m.cropName}</span>
                      <span className="font-bold text-emerald-600">{m.activeCyclesCount} active farmer cycles</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-4 bg-stone-50 dark:bg-stone-800/50 rounded-xl border border-stone-200 dark:border-stone-700 space-y-2">
                <h4 className="font-bold text-stone-900 dark:text-stone-100">Stages with Task Delays / Abandonment</h4>
                <div className="space-y-1.5">
                  {learningAnalytics.abandonmentStages?.map((s: any, i: number) => (
                    <div key={i} className="flex items-center justify-between p-2 bg-white dark:bg-stone-900 rounded">
                      <span>{s.stageName}</span>
                      <span className="font-bold text-amber-600">+{s.delayDaysAvg} days delay</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from "react";
import { AgronomistCardsSection } from "./AgronomistCardsSection";
import { BookAgronomistModal, BookingFormData } from "./BookAgronomistModal";
import { AgronomistPayServiceModal } from "./AgronomistPayServiceModal";
import { AgronomyReportsSection } from "./AgronomyReportsSection";
import { AgronomistProfile, AGRONOMIST_PROFILES } from "./FarmerAgronomistPortal";
import { FarmNode, AdvisoryConsultation } from "../../types";

interface FarmerAgronomyHubProps {
  activeFarm?: FarmNode | null;
  farms?: FarmNode[];
  userProfile?: any;
  currencySymbol?: string;
  onConsultationBooked?: (consultation: AdvisoryConsultation) => void;
}

const DEFAULT_INITIAL_REPORTS: AdvisoryConsultation[] = [];

export const FarmerAgronomyHub: React.FC<FarmerAgronomyHubProps> = ({
  activeFarm,
  farms = [],
  userProfile,
  currencySymbol = "ZK",
  onConsultationBooked
}) => {
  // Consultations / Reports State
  const [consultations, setConsultations] = useState<AdvisoryConsultation[]>(() => {
    try {
      const saved = localStorage.getItem("mabala_agronomy_consultations");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {}
    return [];
  });

  // Save to localStorage whenever consultations update
  useEffect(() => {
    try {
      localStorage.setItem("mabala_agronomy_consultations", JSON.stringify(consultations));
    } catch (e) {}
  }, [consultations]);

  // Modal State for Booking
  const [selectedAgronomistForBooking, setSelectedAgronomistForBooking] = useState<AgronomistProfile | null>(null);
  const [isBookModalOpen, setIsBookModalOpen] = useState<boolean>(false);

  // Modal State for Lipila Checkout
  const [pendingBookingData, setPendingBookingData] = useState<BookingFormData | null>(null);
  const [isPayModalOpen, setIsPayModalOpen] = useState<boolean>(false);

  // Trigger Book Agronomist from Card
  const handleOpenBookModal = (agronomist: AgronomistProfile) => {
    setSelectedAgronomistForBooking(agronomist);
    setIsBookModalOpen(true);
  };

  // Proceed from Book Modal -> Lipila Pay Modal
  const handleProceedToPayment = (bookingData: BookingFormData) => {
    setIsBookModalOpen(false);
    setPendingBookingData(bookingData);
    setIsPayModalOpen(true);
  };

  // Complete Payment & Save Report
  const handlePaymentCompleted = (newConsultation: AdvisoryConsultation) => {
    setConsultations((prev) => [newConsultation, ...prev]);
    if (onConsultationBooked) {
      onConsultationBooked(newConsultation);
    }
  };

  return (
    <div className="space-y-6" id="farmer-agronomy-hub-section">
      {/* 1. Onboarded Agronomists Card Component */}
      <AgronomistCardsSection
        onBookAgronomist={handleOpenBookModal}
        currencySymbol={currencySymbol}
      />

      {/* 2. Agronomy Reports Section */}
      <AgronomyReportsSection
        consultations={consultations}
        onBookFollowUp={(rep) => {
          const matchedAgro = AGRONOMIST_PROFILES.find((a) => a.id === rep.agronomistId) || AGRONOMIST_PROFILES[0];
          handleOpenBookModal(matchedAgro);
        }}
        currencySymbol={currencySymbol}
        activeFarmName={activeFarm?.name}
      />

      {/* 3. 'Book Agronomist' Modal Dialog */}
      <BookAgronomistModal
        agronomist={selectedAgronomistForBooking}
        isOpen={isBookModalOpen}
        onClose={() => setIsBookModalOpen(false)}
        onProceedToPayment={handleProceedToPayment}
        activeFarm={activeFarm}
        farms={farms}
        userProfile={userProfile}
        currencySymbol={currencySymbol}
      />

      {/* 4. 'Pay for Service' Lipila Checkout Modal */}
      <AgronomistPayServiceModal
        bookingData={pendingBookingData}
        isOpen={isPayModalOpen}
        onClose={() => setIsPayModalOpen(false)}
        onPaymentComplete={handlePaymentCompleted}
        currencySymbol={currencySymbol}
        userProfile={userProfile}
      />
    </div>
  );
};
export default FarmerAgronomyHub;

import React, { useState } from "react";
import {
  Compass,
  Calendar,
  Clock,
  MapPin,
  Star,
  CheckCircle2,
  Phone,
  Mail,
  ShieldCheck,
  Search,
  Filter,
  DollarSign,
  FileText,
  Download,
  AlertTriangle,
  Award,
  BookOpen,
  Send,
  X,
  CreditCard,
  Smartphone,
  ChevronRight,
  Activity,
  Sprout,
  Stethoscope,
  Info,
  Check,
  Building,
  User,
  Users,
  Eye,
  RefreshCw,
  FileCheck,
  Droplets,
  Layers,
  ArrowRight
} from "lucide-react";
import jsPDF from "jspdf";
import { FarmNode, AdvisoryConsultation, AgronomistAvailabilitySlot } from "../../types";

export interface AgronomistProfile {
  id: string;
  name: string;
  title: string;
  degree: string;
  specialistType: "Agronomist" | "Veterinary Surgeon (Vet)";
  experienceYears: number;
  rating: number;
  reviewCount: number;
  provinces: string[];
  districts: string[];
  specialties: string[];
  bio: string;
  phone: string;
  email: string;
  verified: boolean;
  avatarUrl?: string;
  pricing: {
    farmVisit: number;
    virtualConsult: number;
    soilOrHerdAudit: number;
  };
  certifications: string[];
  recentReviews: {
    farmerName: string;
    farmName: string;
    date: string;
    rating: number;
    comment: string;
  }[];
}

export const AGRONOMIST_PROFILES: AgronomistProfile[] = [];

interface FarmerAgronomistPortalProps {
  userProfile?: any;
  activeFarm?: FarmNode | null;
  farms?: FarmNode[];
  currencySymbol?: string;
  consultations: AdvisoryConsultation[];
  availabilitySlots: AgronomistAvailabilitySlot[];
  onBookConsultation: (bookingData: any) => Promise<any>;
  onRateConsultation?: (ticketId: string, rating: number, comment: string) => Promise<any>;
}

export const FarmerAgronomistPortal: React.FC<FarmerAgronomistPortalProps> = ({
  userProfile,
  activeFarm,
  farms = [],
  currencySymbol = "ZMW",
  consultations = [],
  availabilitySlots = [],
  onBookConsultation,
  onRateConsultation
}) => {
  // Navigation tabs for Farmer View
  const [farmerActiveTab, setFarmerActiveTab] = useState<
    "find-agronomists" | "my-bookings" | "shared-reports"
  >("find-agronomists");

  // Filter States
  const [specialistTypeFilter, setSpecialistTypeFilter] = useState<"ALL" | "Agronomist" | "Vet">("ALL");
  const [provinceFilter, setProvinceFilter] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Modals & Selection States
  const [selectedAgronomist, setSelectedAgronomist] = useState<AgronomistProfile | null>(null);
  const [showProfileModal, setShowProfileModal] = useState<boolean>(false);

  // Booking Flow State
  const [showBookingModal, setShowBookingModal] = useState<boolean>(false);
  const [bookingStep, setBookingStep] = useState<"details" | "schedule" | "payment" | "success">("details");
  const [bookingServiceType, setBookingServiceType] = useState<
    "farmVisit" | "virtualConsult" | "soilOrHerdAudit"
  >("farmVisit");
  const [targetFarmName, setTargetFarmName] = useState<string>(activeFarm?.name || (farms[0]?.name || "My Farm"));
  const [targetCropOrAnimal, setTargetCropOrAnimal] = useState<string>("");
  const [farmerPhone, setFarmerPhone] = useState<string>(userProfile?.phone || "+260 977 123456");
  const [farmerFullName, setFarmerFullName] = useState<string>(userProfile?.name || userProfile?.fullName || "Farm Owner");
  const [issueDescription, setIssueDescription] = useState<string>("");
  const [urgencyLevel, setUrgencyLevel] = useState<"Routine" | "Medium" | "Urgent Outbreak">("Medium");
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date(Date.now() + 86400000 * 2).toISOString().split("T")[0]
  );
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>("09:00 AM - 11:00 AM");

  // Payment Selection in Booking Flow
  const [paymentMethod, setPaymentMethod] = useState<"lipila_momo" | "wallet" | "card">("lipila_momo");
  const [lipilaMomoProvider, setLipilaMomoProvider] = useState<"MTN" | "Airtel" | "Zamtel">("MTN");
  const [lipilaMomoPhone, setLipilaMomoPhone] = useState<string>(userProfile?.phone || "+260 977 123456");
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [paymentSuccessData, setPaymentSuccessData] = useState<any>(null);

  // Shared Reports Viewer State
  const [selectedReport, setSelectedReport] = useState<AdvisoryConsultation | null>(null);
  const [showReportModal, setShowReportModal] = useState<boolean>(false);

  // Rating Modal State
  const [ratingTicket, setRatingTicket] = useState<AdvisoryConsultation | null>(null);
  const [showRatingModal, setShowRatingModal] = useState<boolean>(false);
  const [ratingStars, setRatingStars] = useState<number>(5);
  const [ratingComment, setRatingComment] = useState<string>("");
  const [isSubmittingRating, setIsSubmittingRating] = useState<boolean>(false);

  // Derived Filtered Agronomists
  const filteredAgronomists = AGRONOMIST_PROFILES.filter((agro) => {
    const matchesType =
      specialistTypeFilter === "ALL" ||
      (specialistTypeFilter === "Agronomist" && agro.specialistType === "Agronomist") ||
      (specialistTypeFilter === "Vet" && agro.specialistType === "Veterinary Surgeon (Vet)");

    const matchesProvince =
      provinceFilter === "ALL" ||
      agro.provinces.some((p) => p.toLowerCase().includes(provinceFilter.toLowerCase()));

    const matchesSearch =
      !searchQuery ||
      agro.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      agro.specialties.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase())) ||
      agro.districts.some((d) => d.toLowerCase().includes(searchQuery.toLowerCase())) ||
      agro.title.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesType && matchesProvince && matchesSearch;
  });

  // Calculate Fee for Current Selection
  const calculateCurrentFee = () => {
    if (!selectedAgronomist) return 350;
    if (bookingServiceType === "farmVisit") return selectedAgronomist.pricing.farmVisit;
    if (bookingServiceType === "virtualConsult") return selectedAgronomist.pricing.virtualConsult;
    return selectedAgronomist.pricing.soilOrHerdAudit;
  };

  // Initiate Booking for an Agronomist
  const handleStartBooking = (agro: AgronomistProfile) => {
    setSelectedAgronomist(agro);
    setBookingStep("details");
    setShowBookingModal(true);
  };

  // Complete Payment & Confirm Booking
  const handleProcessBookingPayment = async () => {
    if (!selectedAgronomist) return;
    setIsProcessingPayment(true);

    const visitFee = calculateCurrentFee();
    const platformFee = Math.round(visitFee * 0.15);
    const totalAmount = visitFee + platformFee;
    const bookingReference = `AGRO-BK-${Date.now().toString().slice(-6)}`;

    try {
      // Simulate real-time Lipila gateway or wallet deduction
      await new Promise((resolve) => setTimeout(resolve, 1600));

      const bookingPayload = {
        referenceId: bookingReference,
        agronomistId: selectedAgronomist.id,
        agronomistName: selectedAgronomist.name,
        specialistType: selectedAgronomist.specialistType,
        serviceType: bookingServiceType,
        farmName: targetFarmName,
        farmerName: farmerFullName,
        farmerPhone: farmerPhone,
        cropType: targetCropOrAnimal || "Mixed Crops",
        symptomsDescription: issueDescription || "Scheduled on-site advisory visit",
        urgency: urgencyLevel,
        scheduledVisitDate: selectedDate,
        timeSlot: selectedTimeSlot,
        visitFee,
        platformFee,
        totalAmount,
        currency: currencySymbol,
        paymentStatus: "Paid",
        paymentMethod: paymentMethod === "lipila_momo" ? `Lipila ${lipilaMomoProvider} Mobile Money` : paymentMethod === "wallet" ? "Farmer Wallet" : "Card Payment",
        paymentPhone: paymentMethod === "lipila_momo" ? lipilaMomoPhone : undefined,
        status: "Scheduled",
        date: selectedDate,
        createdAt: new Date().toISOString()
      };

      if (onBookConsultation) {
        await onBookConsultation(bookingPayload);
      }

      setPaymentSuccessData({
        referenceId: bookingReference,
        agronomistName: selectedAgronomist.name,
        serviceLabel:
          bookingServiceType === "farmVisit"
            ? "On-Site Diagnostic Farm Visit"
            : bookingServiceType === "virtualConsult"
            ? "Virtual Agronomy Advisory"
            : "Soil & Health Audit",
        scheduledDate: selectedDate,
        timeSlot: selectedTimeSlot,
        farmName: targetFarmName,
        totalAmount,
        paymentMethod: paymentMethod === "lipila_momo" ? `${lipilaMomoProvider} Mobile Money (${lipilaMomoPhone})` : paymentMethod === "wallet" ? "Farmer Wallet Balance" : "Card Checkout"
      });

      setBookingStep("success");
    } catch (err: any) {
      console.error("[Booking Payment Error]:", err);
      alert(`Booking payment failed: ${err?.message || "Please check connection and retry."}`);
    } finally {
      setIsProcessingPayment(false);
    }
  };

  // Export official PDF report using jsPDF
  const handleDownloadPdfReport = (report: AdvisoryConsultation) => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();

      // Header Banner
      doc.setFillColor(15, 76, 58); // Deep forest teal
      doc.rect(0, 0, pageWidth, 40, "F");

      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(16);
      doc.text("MABALA AGRONOMIC & CROP HEALTH REPORT", 14, 20);

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text("Official Field Diagnosis, Treatment Prescription & Soil Advisory", 14, 28);
      doc.text(`Reference: ${report.id} | Date: ${report.date || new Date().toISOString().split("T")[0]}`, 14, 35);

      // Section 1: Farmer & Farm Info
      doc.setTextColor(30, 41, 59);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("1. FARM & CONSULTATION DETAILS", 14, 52);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.text(`Farm Name: ${report.farmName || "Registered Farm"}`, 14, 60);
      doc.text(`Farmer / Client: ${report.farmerName || userProfile?.name || "Client Farmer"}`, 14, 66);
      doc.text(`Crop & Block: ${report.cropType || "Crop Field"} (${report.fieldBlock || "Active Block"})`, 14, 72);
      doc.text(`Specialist Agronomist: ${report.agronomistName || "Certified Specialist"}`, 14, 78);
      doc.text(`Severity Level: ${report.severity || "Standard"} | Status: ${report.status}`, 14, 84);

      // Section 2: Diagnosis & Observations
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("2. FIELD OBSERVATIONS & DIAGNOSIS", 14, 96);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      const symptomsLines = doc.splitTextToSize(
        `Farmer Symptoms: ${report.symptomsDescription || "Routine crop inspection and agronomic health audit."}`,
        pageWidth - 28
      );
      doc.text(symptomsLines, 14, 104);

      let currentY = 104 + symptomsLines.length * 6;

      const diagnosisLines = doc.splitTextToSize(
        `Agronomist Diagnosis: ${report.diagnosisNotes || "Field inspection confirmed optimal growth with targeted preventive fungicide and micro-nutrient booster required."}`,
        pageWidth - 28
      );
      doc.text(diagnosisLines, 14, currentY);
      currentY += diagnosisLines.length * 6 + 6;

      // Section 3: Official Prescription (If Available)
      if (report.prescription) {
        doc.setFont("helvetica", "bold");
        doc.setFontSize(12);
        doc.text("3. OFFICIAL ZEMA CHEMICAL & TREATMENT PRESCRIPTION", 14, currentY);
        currentY += 8;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9.5);
        doc.text(`• Recommended Product: ${report.prescription.productName}`, 14, currentY);
        currentY += 6;
        doc.text(`• Active Ingredient: ${report.prescription.activeIngredient || "N/A"}`, 14, currentY);
        currentY += 6;
        doc.text(`• Calibrated Dosage: ${report.prescription.dosage}`, 14, currentY);
        currentY += 6;
        doc.text(`• Application Method: ${report.prescription.applicationMethod}`, 14, currentY);
        currentY += 6;
        doc.text(`• Pre-Harvest Interval (PHI): ${report.prescription.withdrawalPeriodDays || 14} Days`, 14, currentY);
        currentY += 6;
        
        const safetyLines = doc.splitTextToSize(`• Safety & PPE: ${report.prescription.safetyInstructions || "Wear nitrile gloves, respirator, and eye protection during spray calibration."}`, pageWidth - 28);
        doc.text(safetyLines, 14, currentY);
        currentY += safetyLines.length * 5 + 8;
      }

      // Section 4: Soil Lab Analysis (If Available)
      if (report.soilTest) {
        doc.setFont("helvetica", "bold");
        doc.setFontSize(12);
        doc.text("4. SOIL & NUTRIENT LAB ANALYSIS", 14, currentY);
        currentY += 8;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9.5);
        doc.text(`Soil pH: ${report.soilTest.ph} | Nitrogen (N): ${report.soilTest.nitrogenPpm} ppm | Phosphorus (P): ${report.soilTest.phosphorusPpm} ppm | Potassium (K): ${report.soilTest.potassiumPpm} ppm`, 14, currentY);
        currentY += 6;
        doc.text(`Organic Matter: ${report.soilTest.organicMatterPercent}%`, 14, currentY);
        currentY += 6;

        const recLines = doc.splitTextToSize(`Agronomist Recommendation: ${report.soilTest.recommendation}`, pageWidth - 28);
        doc.text(recLines, 14, currentY);
        currentY += recLines.length * 5 + 8;
      }

      // Footer
      doc.setDrawColor(200, 200, 200);
      doc.line(14, 275, pageWidth - 14, 275);
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text("Mabala Agronomic Services • Certified Agricultural Advisor Network • Republic of Zambia", 14, 282);
      doc.text("ZEMA Compliant Agro-Advisory • Verified Digital Diagnostic Record", 14, 287);

      doc.save(`Mabala_Agronomy_Report_${report.id}.pdf`);
    } catch (err: any) {
      console.error("PDF generation error:", err);
      alert("Unable to generate PDF. Details logged to console.");
    }
  };

  // Submit Rating
  const handleRatingSubmit = async () => {
    if (!ratingTicket || !onRateConsultation) return;
    setIsSubmittingRating(true);
    try {
      await onRateConsultation(ratingTicket.id, ratingStars, ratingComment);
      setShowRatingModal(false);
      setRatingTicket(null);
      setRatingComment("");
      alert("Thank you! Your rating and review for the agronomist has been submitted.");
    } catch (err: any) {
      alert(`Rating failed: ${err?.message}`);
    } finally {
      setIsSubmittingRating(false);
    }
  };

  return (
    <div className="space-y-6 p-4 sm:p-6 bg-slate-50 min-h-screen text-slate-900 font-sans">
      {/* Farmer Agronomy Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-teal-800/40 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 opacity-10 flex items-center pr-6 pointer-events-none">
          <Sprout className="w-96 h-96 text-emerald-300" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 rounded-full text-xs font-black uppercase tracking-wider border border-emerald-500/30 flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-emerald-400" />
                Farmer Agronomy Services
              </span>
              <span className="px-2.5 py-0.5 bg-teal-500/20 text-teal-300 rounded-full text-[10px] font-extrabold uppercase">
                Field Visits & Specialist Advice
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Certified Agronomists & Veterinary Doctors
            </h1>
            <p className="text-xs sm:text-sm text-teal-100 max-w-2xl font-medium">
              Browse verified agricultural experts, book on-farm diagnostic visits, pay securely via Mobile Money, and access your official crop treatment reports.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => {
                if (AGRONOMIST_PROFILES.length > 0) {
                  setSelectedAgronomist(AGRONOMIST_PROFILES[0]);
                }
                setBookingStep("details");
                setShowBookingModal(true);
              }}
              className="px-4 py-2.5 bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer shrink-0"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Field Visit</span>
            </button>
          </div>
        </div>

        {/* Quick Highlights Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-teal-800/50">
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <div className="text-[10px] text-teal-200 uppercase font-black">Verified Specialists</div>
            <div className="text-xl font-black text-white">{AGRONOMIST_PROFILES.length} Active</div>
            <div className="text-[9.5px] text-teal-300">ZEMA & VCZ Licensed</div>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <div className="text-[10px] text-teal-200 uppercase font-black">My Bookings</div>
            <div className="text-xl font-black text-white">{consultations.length} Visits</div>
            <div className="text-[9.5px] text-teal-300">Total Consultations</div>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <div className="text-[10px] text-teal-200 uppercase font-black">Official Reports</div>
            <div className="text-xl font-black text-white">
              {consultations.filter((c) => c.status === "Prescribed" || c.status === "Resolved" || c.prescription).length}
            </div>
            <div className="text-[9.5px] text-teal-300">Downloadable PDF</div>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <div className="text-[10px] text-teal-200 uppercase font-black">Satisfaction</div>
            <div className="text-xl font-black text-white">4.9 ★</div>
            <div className="text-[9.5px] text-teal-300">Farmer Reviews</div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setFarmerActiveTab("find-agronomists")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            farmerActiveTab === "find-agronomists"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Users className="w-4 h-4 text-emerald-400" />
          <span>Available Specialists & Profiles ({AGRONOMIST_PROFILES.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setFarmerActiveTab("my-bookings")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            farmerActiveTab === "my-bookings"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Calendar className="w-4 h-4 text-teal-400" />
          <span>My Consultations & Bookings ({consultations.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setFarmerActiveTab("shared-reports")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            farmerActiveTab === "shared-reports"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <FileCheck className="w-4 h-4 text-emerald-400" />
          <span>
            Shared Reports & Prescriptions (
            {consultations.filter((c) => c.status === "Prescribed" || c.status === "Resolved" || c.prescription).length}
            )
          </span>
        </button>
      </div>

      {/* TAB 1: FIND AGRONOMISTS & SPECIALIST PROFILES */}
      {farmerActiveTab === "find-agronomists" && (
        <div className="space-y-6">
          {/* Filters and Search Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col lg:flex-row items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-1">Specialist:</span>
              <button
                onClick={() => setSpecialistTypeFilter("ALL")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  specialistTypeFilter === "ALL"
                    ? "bg-slate-900 text-white shadow-xs"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
              >
                All ({AGRONOMIST_PROFILES.length})
              </button>
              <button
                onClick={() => setSpecialistTypeFilter("Agronomist")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  specialistTypeFilter === "Agronomist"
                    ? "bg-emerald-600 text-white shadow-xs"
                    : "bg-emerald-50 text-emerald-800 hover:bg-emerald-100"
                }`}
              >
                <Sprout className="w-3.5 h-3.5" />
                Agronomists
              </button>
              <button
                onClick={() => setSpecialistTypeFilter("Vet")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  specialistTypeFilter === "Vet"
                    ? "bg-indigo-600 text-white shadow-xs"
                    : "bg-indigo-50 text-indigo-800 hover:bg-indigo-100"
                }`}
              >
                <Stethoscope className="w-3.5 h-3.5" />
                Veterinary Doctors (Vets)
              </button>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
              {/* Province Selector */}
              <select
                value={provinceFilter}
                onChange={(e) => setProvinceFilter(e.target.value)}
                className="w-full sm:w-44 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="ALL">All Provinces</option>
                <option value="Lusaka">Lusaka Province</option>
                <option value="Central">Central Province</option>
                <option value="Southern">Southern Province</option>
                <option value="Copperbelt">Copperbelt Province</option>
                <option value="Eastern">Eastern Province</option>
              </select>

              {/* Search Box */}
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search name, specialty, crop..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                />
              </div>
            </div>
          </div>

          {/* Specialist Cards Grid */}
          {filteredAgronomists.length === 0 ? (
            <div className="bg-slate-50 border border-dashed border-slate-300 rounded-3xl p-12 text-center space-y-3">
              <Sprout className="w-12 h-12 text-slate-400 mx-auto" />
              <h3 className="text-sm font-bold text-slate-800">No Certified Specialists Listed Yet</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Certified agronomists and veterinary doctors registered for your region will appear here once onboarded.
              </p>
              <button
                type="button"
                onClick={() => {
                  setBookingStep("details");
                  setShowBookingModal(true);
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition inline-flex items-center gap-2 cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Request Agronomy Support</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredAgronomists.map((agro) => {
              const isVet = agro.specialistType === "Veterinary Surgeon (Vet)";

              return (
                <div
                  key={agro.id}
                  className="bg-white rounded-3xl border border-slate-200 shadow-xs hover:shadow-xl hover:border-emerald-500/50 transition-all flex flex-col justify-between overflow-hidden group"
                >
                  <div className="p-6 space-y-4">
                    {/* Specialist Header Badge */}
                    <div className="flex justify-between items-start">
                      <span
                        className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 ${
                          isVet
                            ? "bg-indigo-50 text-indigo-800 border border-indigo-200"
                            : "bg-emerald-50 text-emerald-800 border border-emerald-200"
                        }`}
                      >
                        {isVet ? <Stethoscope className="w-3 h-3 text-indigo-600" /> : <Sprout className="w-3 h-3 text-emerald-600" />}
                        {agro.specialistType}
                      </span>

                      {agro.verified && (
                        <span className="px-2.5 py-0.5 bg-teal-50 text-teal-800 rounded-full text-[10px] font-bold border border-teal-200 flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3 text-teal-600" />
                          Verified
                        </span>
                      )}
                    </div>

                    {/* Profile Basic Info */}
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-800 to-teal-950 text-white font-black text-lg flex items-center justify-center shadow-md shrink-0">
                        {agro.name.split(" ")[1]?.slice(0, 1) || agro.name.slice(0, 1)}
                      </div>
                      <div>
                        <h3 className="text-base font-black text-slate-900 group-hover:text-emerald-800 transition-colors leading-tight">
                          {agro.name}
                        </h3>
                        <p className="text-xs font-bold text-slate-600 mt-0.5">{agro.title}</p>
                        <p className="text-[11px] text-slate-400">{agro.degree}</p>
                      </div>
                    </div>

                    {/* Rating & Experience */}
                    <div className="flex items-center gap-3 text-xs pt-1">
                      <div className="flex items-center gap-1 text-amber-500 font-bold bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        <span>{agro.rating}</span>
                        <span className="text-slate-400 font-normal">({agro.reviewCount} reviews)</span>
                      </div>
                      <div className="text-slate-600 font-medium bg-slate-100 px-2.5 py-1 rounded-lg">
                        {agro.experienceYears} Years Exp.
                      </div>
                    </div>

                    {/* Specialties Pills */}
                    <div>
                      <div className="text-[10px] font-black uppercase text-slate-400 mb-1.5">Focus Areas:</div>
                      <div className="flex flex-wrap gap-1.5">
                        {agro.specialties.slice(0, 3).map((spec, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-lg text-[10.5px] font-medium"
                          >
                            {spec}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Coverage Area */}
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="truncate">{agro.districts.slice(0, 3).join(", ")} ({agro.provinces[0]})</span>
                    </div>

                    {/* Pricing Summary */}
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-slate-400 text-[10px] block">On-Site Visit:</span>
                        <span className="font-black text-slate-900 text-sm">
                          {currencySymbol} {agro.pricing.farmVisit}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-400 text-[10px] block">Virtual Consult:</span>
                        <span className="font-bold text-slate-700">
                          {currencySymbol} {agro.pricing.virtualConsult}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedAgronomist(agro);
                        setShowProfileModal(true);
                      }}
                      className="w-1/2 py-2.5 bg-white hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold border border-slate-200 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5 text-slate-500" />
                      <span>View Profile</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleStartBooking(agro)}
                      className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Book Visit</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
          )}
        </div>
      )}

      {/* TAB 2: MY CONSULTATIONS & BOOKINGS */}
      {farmerActiveTab === "my-bookings" && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-teal-600" />
                <span>My Booked Consultations & Field Visits</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Track appointments, scheduled visits, and access shared prescriptions from agronomists.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                if (AGRONOMIST_PROFILES.length > 0) {
                  setSelectedAgronomist(AGRONOMIST_PROFILES[0]);
                }
                setBookingStep("details");
                setShowBookingModal(true);
              }}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2 cursor-pointer shrink-0"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Specialist</span>
            </button>
          </div>

          {consultations.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <Sprout className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="text-sm font-bold text-slate-700">No Advisory Bookings Found</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                You have not booked any agronomist field visits yet. Select an available specialist to schedule an on-farm diagnostic review.
              </p>
              <button
                type="button"
                onClick={() => setFarmerActiveTab("find-agronomists")}
                className="px-4 py-2 bg-teal-900 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                Browse Available Agronomists
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-[10px] text-slate-400 uppercase font-black tracking-wider border-b border-slate-200">
                    <th className="p-3.5">Ticket / Date</th>
                    <th className="p-3.5">Specialist</th>
                    <th className="p-3.5">Farm & Crop</th>
                    <th className="p-3.5">Scheduled Date</th>
                    <th className="p-3.5">Visit Fee</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                  {consultations.map((ticket) => {
                    const isCompleted =
                      ticket.status === "Prescribed" ||
                      ticket.status === "Resolved" ||
                      (ticket.status as string) === "Closed" ||
                      ticket.prescription;

                    return (
                      <tr key={ticket.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-slate-900">
                          {ticket.id}
                          <span className="block text-[10px] font-normal text-slate-400">
                            {ticket.date || new Date().toISOString().split("T")[0]}
                          </span>
                        </td>
                        <td className="p-3.5">
                          <div className="font-bold text-slate-900">{ticket.agronomistName}</div>
                          <div className="text-[10.5px] text-slate-500">{ticket.category || "General Advisory"}</div>
                        </td>
                        <td className="p-3.5">
                          <div className="font-medium text-slate-800">{ticket.farmName}</div>
                          <div className="text-[11px] text-emerald-700 font-bold">{ticket.cropType || "Farm Crop"}</div>
                        </td>
                        <td className="p-3.5 font-medium text-slate-800">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                            <span>{ticket.scheduledVisitDate || "Scheduled"}</span>
                          </div>
                          {ticket.timeSlot && (
                            <div className="text-[10px] text-slate-400 mt-0.5">{ticket.timeSlot}</div>
                          )}
                        </td>
                        <td className="p-3.5 font-black text-slate-900">
                          {currencySymbol} {ticket.visitFee || 350}
                        </td>
                        <td className="p-3.5">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                              isCompleted
                                ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                                : ticket.status === "In Analysis"
                                ? "bg-amber-100 text-amber-800 border border-amber-200"
                                : "bg-teal-100 text-teal-800 border border-teal-200"
                            }`}
                          >
                            {ticket.status}
                          </span>
                        </td>
                        <td className="p-3.5 text-right space-x-2">
                          {isCompleted ? (
                            <>
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedReport(ticket);
                                  setShowReportModal(true);
                                }}
                                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-[11px] transition-all shadow-xs cursor-pointer inline-flex items-center gap-1"
                              >
                                <FileText className="w-3 h-3" />
                                <span>View Report</span>
                              </button>

                              {!ticket.rating && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setRatingTicket(ticket);
                                    setShowRatingModal(true);
                                  }}
                                  className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-[11px] transition-all shadow-xs cursor-pointer inline-flex items-center gap-1"
                                >
                                  <Star className="w-3 h-3 fill-slate-950" />
                                  <span>Rate</span>
                                </button>
                              )}
                            </>
                          ) : (
                            <span className="text-[11px] text-slate-400 font-medium">Pending Visit</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: SHARED REPORTS & PRESCRIPTIONS */}
      {farmerActiveTab === "shared-reports" && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-4">
              <div>
                <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-emerald-600" />
                  <span>Agronomist Prescriptions & Soil Lab Reports</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Official diagnostic findings, spray dosage instructions, withdrawal periods, and soil recommendations issued by agronomists.
                </p>
              </div>
            </div>

            {consultations.filter((c) => c.status === "Prescribed" || c.status === "Resolved" || c.prescription).length === 0 ? (
              <div className="text-center py-12 space-y-2">
                <FileText className="w-12 h-12 text-slate-300 mx-auto" />
                <h3 className="text-sm font-bold text-slate-700">No Reports Issued Yet</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Once an agronomist completes a field visit and submits a diagnostic report or prescription, it will appear here for viewing and PDF download.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {consultations
                  .filter((c) => c.status === "Prescribed" || c.status === "Resolved" || c.prescription)
                  .map((report) => (
                    <div
                      key={report.id}
                      className="bg-slate-50 rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-emerald-500 transition-all space-y-4 flex flex-col justify-between"
                    >
                      <div className="space-y-3">
                        <div className="flex justify-between items-start">
                          <span className="px-2.5 py-1 bg-emerald-100 text-emerald-900 rounded-lg text-[10.5px] font-black uppercase tracking-wider flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                            Official Report
                          </span>
                          <span className="text-xs font-mono font-bold text-slate-400">{report.id}</span>
                        </div>

                        <div>
                          <h3 className="text-sm font-black text-slate-900">{report.cropType} — {report.category}</h3>
                          <p className="text-xs text-slate-500 font-medium mt-0.5">{report.farmName} • {report.fieldBlock}</p>
                        </div>

                        <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-xs space-y-2">
                          <div>
                            <span className="font-bold text-slate-700 block">Diagnosed Condition:</span>
                            <p className="text-slate-600">{report.diagnosisNotes || "Alternaria fungal disease identified during field audit."}</p>
                          </div>

                          {report.prescription && (
                            <div className="pt-2 border-t border-slate-100">
                              <span className="font-bold text-emerald-800 block">Prescribed Treatment:</span>
                              <p className="text-slate-700 font-medium">{report.prescription.productName}</p>
                              <p className="text-[11px] text-slate-500">Dosage: {report.prescription.dosage}</p>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-2">
                        <span className="text-[11px] text-slate-500 font-medium">
                          Specialist: <strong>{report.agronomistName}</strong>
                        </span>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleDownloadPdfReport(report)}
                            className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl text-xs flex items-center gap-1 cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>PDF</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setSelectedReport(report);
                              setShowReportModal(true);
                            }}
                            className="px-3.5 py-1.5 bg-teal-900 hover:bg-teal-800 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-xs cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Full Report</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL 1: VIEW FULL AGRONOMIST PROFILE */}
      {showProfileModal && selectedAgronomist && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8 space-y-0">
            {/* Modal Header Banner */}
            <div className="bg-gradient-to-r from-emerald-900 to-teal-900 p-6 text-white relative">
              <button
                onClick={() => setShowProfileModal(false)}
                className="absolute right-4 top-4 p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-xl transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-2xl bg-white text-emerald-950 font-black text-2xl flex items-center justify-center shadow-lg shrink-0">
                  {selectedAgronomist.name.split(" ")[1]?.slice(0, 1) || selectedAgronomist.name.slice(0, 1)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 bg-emerald-500/30 text-emerald-200 rounded-full text-[10px] font-black uppercase tracking-wider">
                      {selectedAgronomist.specialistType}
                    </span>
                    {selectedAgronomist.verified && (
                      <span className="px-2 py-0.5 bg-teal-400 text-slate-950 rounded-full text-[9.5px] font-black uppercase flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3" />
                        Verified Expert
                      </span>
                    )}
                  </div>
                  <h2 className="text-xl font-black text-white mt-1">{selectedAgronomist.name}</h2>
                  <p className="text-xs text-teal-200 font-bold">{selectedAgronomist.title}</p>
                  <p className="text-[11px] text-teal-100">{selectedAgronomist.degree}</p>
                </div>
              </div>
            </div>

            {/* Modal Body Content */}
            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto text-xs text-slate-700">
              {/* Bio */}
              <div>
                <h4 className="font-black text-slate-900 uppercase text-[11px] tracking-wider mb-1.5">About Specialist</h4>
                <p className="text-slate-600 leading-relaxed">{selectedAgronomist.bio}</p>
              </div>

              {/* Service Pricing Grid */}
              <div>
                <h4 className="font-black text-slate-900 uppercase text-[11px] tracking-wider mb-2">Service Pricing & Rates</h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
                    <span className="text-slate-500 block text-[10.5px]">On-Site Farm Visit</span>
                    <span className="text-base font-black text-slate-900 mt-1 block">
                      {currencySymbol} {selectedAgronomist.pricing.farmVisit}
                    </span>
                    <span className="text-[10px] text-slate-400">Diagnosis & Prescription</span>
                  </div>

                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
                    <span className="text-slate-500 block text-[10.5px]">Virtual Consultation</span>
                    <span className="text-base font-black text-slate-900 mt-1 block">
                      {currencySymbol} {selectedAgronomist.pricing.virtualConsult}
                    </span>
                    <span className="text-[10px] text-slate-400">Phone / Video Advisory</span>
                  </div>

                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
                    <span className="text-slate-500 block text-[10.5px]">Complete Lab/Herd Audit</span>
                    <span className="text-base font-black text-slate-900 mt-1 block">
                      {currencySymbol} {selectedAgronomist.pricing.soilOrHerdAudit}
                    </span>
                    <span className="text-[10px] text-slate-400">Soil Sampling & Nutrition</span>
                  </div>
                </div>
              </div>

              {/* Specialties & Certifications */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-black text-slate-900 uppercase text-[11px] tracking-wider mb-2">Core Competencies</h4>
                  <ul className="space-y-1.5">
                    {selectedAgronomist.specialties.map((spec, i) => (
                      <li key={i} className="flex items-center gap-2 text-slate-700">
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{spec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-black text-slate-900 uppercase text-[11px] tracking-wider mb-2">Certifications & Accreditations</h4>
                  <ul className="space-y-1.5">
                    {selectedAgronomist.certifications.map((cert, i) => (
                      <li key={i} className="flex items-center gap-2 text-slate-700">
                        <Award className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                        <span>{cert}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Operating Provinces */}
              <div>
                <h4 className="font-black text-slate-900 uppercase text-[11px] tracking-wider mb-1.5">Operational Coverage</h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedAgronomist.districts.map((dist, i) => (
                    <span key={i} className="px-2.5 py-1 bg-emerald-50 text-emerald-800 rounded-lg font-bold text-[11px]">
                      {dist}
                    </span>
                  ))}
                </div>
              </div>

              {/* Recent Reviews */}
              {selectedAgronomist.recentReviews.length > 0 && (
                <div>
                  <h4 className="font-black text-slate-900 uppercase text-[11px] tracking-wider mb-2">
                    Verified Farmer Reviews ({selectedAgronomist.reviewCount})
                  </h4>
                  <div className="space-y-2">
                    {selectedAgronomist.recentReviews.map((rev, idx) => (
                      <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-slate-900">{rev.farmerName} ({rev.farmName})</span>
                          <span className="text-amber-500 font-bold">{"★".repeat(rev.rating)}</span>
                        </div>
                        <p className="text-slate-600 text-[11px]">"{rev.comment}"</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowProfileModal(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
              >
                Close
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowProfileModal(false);
                  handleStartBooking(selectedAgronomist);
                }}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Book This Specialist</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: INTERACTIVE STEP-BY-STEP BOOKING & PAYMENT FLOW */}
      {showBookingModal && selectedAgronomist && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8 space-y-0">
            {/* Header */}
            <div className="bg-slate-900 text-white p-5 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="text-base font-black">Book Specialist Consultation</h3>
                  <p className="text-[11px] text-slate-400">With {selectedAgronomist.name}</p>
                </div>
              </div>

              <button
                onClick={() => setShowBookingModal(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Stepper Header */}
            {bookingStep !== "success" && (
              <div className="grid grid-cols-3 bg-slate-100 border-b border-slate-200 text-center text-xs font-bold py-2.5">
                <div className={bookingStep === "details" ? "text-emerald-700 font-black" : "text-slate-500"}>
                  1. Details
                </div>
                <div className={bookingStep === "schedule" ? "text-emerald-700 font-black" : "text-slate-500"}>
                  2. Schedule
                </div>
                <div className={bookingStep === "payment" ? "text-emerald-700 font-black" : "text-slate-500"}>
                  3. Pay & Confirm
                </div>
              </div>
            )}

            {/* Step 1: Details */}
            {bookingStep === "details" && (
              <div className="p-6 space-y-4 text-xs text-slate-700">
                {/* Service Type Selection */}
                <div>
                  <label className="font-bold text-slate-900 block mb-1.5">Select Service Type</label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setBookingServiceType("farmVisit")}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                        bookingServiceType === "farmVisit"
                          ? "bg-emerald-50 border-emerald-500 text-emerald-950 font-bold ring-2 ring-emerald-500"
                          : "bg-white border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      <div className="font-black text-xs">On-Site Visit</div>
                      <div className="text-[11px] text-slate-500 mt-1">{currencySymbol} {selectedAgronomist.pricing.farmVisit}</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setBookingServiceType("virtualConsult")}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                        bookingServiceType === "virtualConsult"
                          ? "bg-emerald-50 border-emerald-500 text-emerald-950 font-bold ring-2 ring-emerald-500"
                          : "bg-white border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      <div className="font-black text-xs">Virtual Consult</div>
                      <div className="text-[11px] text-slate-500 mt-1">{currencySymbol} {selectedAgronomist.pricing.virtualConsult}</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setBookingServiceType("soilOrHerdAudit")}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                        bookingServiceType === "soilOrHerdAudit"
                          ? "bg-emerald-50 border-emerald-500 text-emerald-950 font-bold ring-2 ring-emerald-500"
                          : "bg-white border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      <div className="font-black text-xs">Complete Audit</div>
                      <div className="text-[11px] text-slate-500 mt-1">{currencySymbol} {selectedAgronomist.pricing.soilOrHerdAudit}</div>
                    </button>
                  </div>
                </div>

                {/* Farm & Crop */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-slate-900 block mb-1">Target Farm</label>
                    <input
                      type="text"
                      value={targetFarmName}
                      onChange={(e) => setTargetFarmName(e.target.value)}
                      placeholder="e.g. Chongwe Horizon Farm"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-900 block mb-1">Crop / Animal Subject</label>
                    <input
                      type="text"
                      value={targetCropOrAnimal}
                      onChange={(e) => setTargetCropOrAnimal(e.target.value)}
                      placeholder="e.g. Red Onion, Maize, Dairy Cattle"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                {/* Farmer Contact Info */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-slate-900 block mb-1">Farmer Name</label>
                    <input
                      type="text"
                      value={farmerFullName}
                      onChange={(e) => setFarmerFullName(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-900 block mb-1">Contact Phone (SMS Reminders)</label>
                    <input
                      type="text"
                      value={farmerPhone}
                      onChange={(e) => setFarmerPhone(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                    />
                  </div>
                </div>

                {/* Issue Description */}
                <div>
                  <label className="font-bold text-slate-900 block mb-1">Reason for Visit / Problem Description</label>
                  <textarea
                    rows={2}
                    value={issueDescription}
                    onChange={(e) => setIssueDescription(e.target.value)}
                    placeholder="Describe observed leaf spots, soil symptoms, pest damage, or vaccination goals..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>

                {/* Urgency */}
                <div>
                  <label className="font-bold text-slate-900 block mb-1">Urgency Level</label>
                  <div className="flex gap-2">
                    {(["Routine", "Medium", "Urgent Outbreak"] as const).map((urg) => (
                      <button
                        key={urg}
                        type="button"
                        onClick={() => setUrgencyLevel(urg)}
                        className={`px-3 py-1.5 rounded-xl font-bold text-xs cursor-pointer border ${
                          urgencyLevel === urg
                            ? urg === "Urgent Outbreak"
                              ? "bg-rose-100 text-rose-900 border-rose-300"
                              : "bg-emerald-100 text-emerald-900 border-emerald-300"
                            : "bg-slate-50 text-slate-600 border-slate-200"
                        }`}
                      >
                        {urg}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Buttons */}
                <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowBookingModal(false)}
                    className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => setBookingStep("schedule")}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl shadow-md cursor-pointer flex items-center gap-1.5"
                  >
                    <span>Proceed to Schedule</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Schedule */}
            {bookingStep === "schedule" && (
              <div className="p-6 space-y-4 text-xs text-slate-700">
                <div>
                  <label className="font-bold text-slate-900 block mb-1">Preferred Date</label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-900 block mb-1.5">Select Time Slot</label>
                  <div className="space-y-2">
                    {[
                      "08:30 AM - 10:30 AM (Morning Slot)",
                      "11:00 AM - 01:00 PM (Midday Slot)",
                      "02:30 PM - 04:30 PM (Afternoon Slot)"
                    ].map((slot, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setSelectedTimeSlot(slot)}
                        className={`w-full p-3 rounded-xl border text-left cursor-pointer flex items-center justify-between transition-all ${
                          selectedTimeSlot === slot
                            ? "bg-emerald-50 border-emerald-500 text-emerald-950 font-black ring-2 ring-emerald-500"
                            : "bg-white border-slate-200 hover:bg-slate-50"
                        }`}
                      >
                        <span className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-emerald-600" />
                          <span>{slot}</span>
                        </span>
                        <span className="text-[10px] uppercase font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                          Available
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-1">
                  <div className="font-bold text-slate-900">Summary:</div>
                  <div>Specialist: <strong>{selectedAgronomist.name}</strong></div>
                  <div>Location: <strong>{targetFarmName}</strong></div>
                  <div>Fee: <strong>{currencySymbol} {calculateCurrentFee()}</strong></div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setBookingStep("details")}
                    className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setBookingStep("payment")}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl shadow-md cursor-pointer flex items-center gap-1.5"
                  >
                    <span>Proceed to Payment</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Pay for Agronomist Services */}
            {bookingStep === "payment" && (
              <div className="p-6 space-y-4 text-xs text-slate-700">
                <div className="bg-emerald-950 text-white p-4 rounded-2xl space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-emerald-300 font-bold uppercase tracking-wider">Service Amount:</span>
                    <span className="text-lg font-black text-white">{currencySymbol} {calculateCurrentFee()}</span>
                  </div>
                  <div className="flex justify-between items-center text-[11px] text-emerald-200 border-t border-emerald-800/60 pt-1.5">
                    <span>Platform Booking & SMS Fee (15%):</span>
                    <span>{currencySymbol} {Math.round(calculateCurrentFee() * 0.15)}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm font-black text-emerald-400 border-t border-emerald-800 pt-1.5">
                    <span>Total Payable:</span>
                    <span>{currencySymbol} {calculateCurrentFee() + Math.round(calculateCurrentFee() * 0.15)}</span>
                  </div>
                </div>

                {/* Payment Methods */}
                <div>
                  <label className="font-bold text-slate-900 block mb-2">Select Payment Method</label>
                  <div className="space-y-2">
                    {/* Option 1: Mobile Money */}
                    <div
                      onClick={() => setPaymentMethod("lipila_momo")}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                        paymentMethod === "lipila_momo"
                          ? "bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500"
                          : "bg-white border-slate-200"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 font-bold text-slate-900">
                          <Smartphone className="w-4 h-4 text-emerald-600" />
                          <span>Mobile Money (Lipila MTN / Airtel / Zamtel)</span>
                        </div>
                        <span className="text-[10px] font-black uppercase text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                          Instant STK Push
                        </span>
                      </div>

                      {paymentMethod === "lipila_momo" && (
                        <div className="mt-3 pt-3 border-t border-emerald-200 space-y-2.5">
                          <div className="flex gap-2">
                            {(["MTN", "Airtel", "Zamtel"] as const).map((prov) => (
                              <button
                                key={prov}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setLipilaMomoProvider(prov);
                                }}
                                className={`px-3 py-1 rounded-xl text-xs font-bold border ${
                                  lipilaMomoProvider === prov
                                    ? "bg-emerald-600 text-white border-emerald-600"
                                    : "bg-white text-slate-700 border-slate-200"
                                }`}
                              >
                                {prov}
                              </button>
                            ))}
                          </div>

                          <div>
                            <label className="font-bold text-slate-700 block mb-1">Mobile Money Number</label>
                            <input
                              type="text"
                              value={lipilaMomoPhone}
                              onChange={(e) => setLipilaMomoPhone(e.target.value)}
                              placeholder="+260 977 000000"
                              className="w-full p-2.5 bg-white border border-slate-200 rounded-xl font-bold"
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Option 2: Farmer Mobile Wallet */}
                    <div
                      onClick={() => setPaymentMethod("wallet")}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                        paymentMethod === "wallet"
                          ? "bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500"
                          : "bg-white border-slate-200"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 font-bold text-slate-900">
                          <CreditCard className="w-4 h-4 text-teal-600" />
                          <span>Farmer Mobile Wallet Balance</span>
                        </div>
                        <span className="text-xs font-bold text-slate-500">Auto-Deduct</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setBookingStep("schedule")}
                    disabled={isProcessingPayment}
                    className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={handleProcessBookingPayment}
                    disabled={isProcessingPayment}
                    className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl shadow-lg cursor-pointer flex items-center gap-2"
                  >
                    {isProcessingPayment ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Authorizing Lipila Payment...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Pay {currencySymbol} {calculateCurrentFee() + Math.round(calculateCurrentFee() * 0.15)} & Confirm</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Step 4: Success Receipt */}
            {bookingStep === "success" && paymentSuccessData && (
              <div className="p-6 space-y-4 text-xs text-center text-slate-700">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircle2 className="w-10 h-10" />
                </div>

                <div>
                  <h3 className="text-lg font-black text-slate-900">Booking & Payment Confirmed!</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Your appointment with <strong>{paymentSuccessData.agronomistName}</strong> has been secured.
                  </p>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left space-y-2 font-medium">
                  <div className="flex justify-between border-b border-slate-200 pb-1.5">
                    <span className="text-slate-500">Booking Reference:</span>
                    <span className="font-mono font-bold text-slate-900">{paymentSuccessData.referenceId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Scheduled Date:</span>
                    <span className="font-bold text-slate-800">{paymentSuccessData.scheduledDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Time Window:</span>
                    <span className="font-bold text-slate-800">{paymentSuccessData.timeSlot}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Farm Location:</span>
                    <span className="font-bold text-slate-800">{paymentSuccessData.farmName}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-200 pt-1.5">
                    <span className="text-slate-500">Amount Paid:</span>
                    <span className="font-black text-emerald-700">{currencySymbol} {paymentSuccessData.totalAmount}</span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-500">
                  An SMS confirmation has been dispatched to <strong>{farmerPhone}</strong>.
                </p>

                <div className="pt-3 flex justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setShowBookingModal(false);
                      setFarmerActiveTab("my-bookings");
                    }}
                    className="px-6 py-2.5 bg-teal-900 hover:bg-teal-800 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer"
                  >
                    View My Bookings
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL 3: FULL REPORT & PRESCRIPTION VIEWER */}
      {showReportModal && selectedReport && (
        <div className="fixed inset-0 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8 space-y-0 text-left">
            {/* Header */}
            <div className="bg-gradient-to-r from-teal-900 to-slate-900 p-6 text-white flex justify-between items-center">
              <div>
                <span className="px-2.5 py-0.5 bg-emerald-500/30 text-emerald-300 rounded-full text-[10px] font-black uppercase tracking-wider">
                  Official Advisory Report
                </span>
                <h3 className="text-lg font-black text-white mt-1">Field Diagnosis & Treatment Plan</h3>
                <p className="text-xs text-teal-200">{selectedReport.farmName} • {selectedReport.cropType}</p>
              </div>

              <button
                onClick={() => setShowReportModal(false)}
                className="p-1.5 text-white/70 hover:text-white rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto text-xs text-slate-700">
              {/* Section 1: Overview */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-black block">Specialist</span>
                  <span className="font-bold text-slate-900">{selectedReport.agronomistName}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-black block">Date Logged</span>
                  <span className="font-bold text-slate-900">{selectedReport.date || "2026-08-04"}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-black block">Severity</span>
                  <span className="font-black text-rose-700">{selectedReport.severity || "High"}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-black block">Status</span>
                  <span className="font-black text-emerald-700">{selectedReport.status}</span>
                </div>
              </div>

              {/* Diagnosis */}
              <div className="space-y-1.5">
                <h4 className="font-black text-slate-900 uppercase text-[11px] tracking-wider">
                  Clinical Diagnosis & Field Findings
                </h4>
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                  <p className="text-slate-800 font-medium leading-relaxed">
                    {selectedReport.diagnosisNotes || "Alternaria porri infection amplified by prolonged dew period and excess soil moisture."}
                  </p>
                  <p className="text-slate-500 text-[11px]">
                    Symptoms Observed: {selectedReport.symptomsDescription || "Purple blotch lesions on upper leaf tips."}
                  </p>
                </div>
              </div>

              {/* Official Prescription */}
              {selectedReport.prescription && (
                <div className="space-y-2">
                  <h4 className="font-black text-emerald-900 uppercase text-[11px] tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Official ZEMA Chemical & Dosage Prescription</span>
                  </h4>

                  <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] text-emerald-800 font-black uppercase">Product Name:</span>
                        <div className="text-sm font-black text-emerald-950">{selectedReport.prescription.productName}</div>
                      </div>
                      <span className="px-2.5 py-1 bg-emerald-200/80 text-emerald-900 rounded-lg text-[10px] font-black uppercase">
                        ZEMA Approved
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="font-bold text-emerald-900 block">Active Ingredient:</span>
                        <span className="text-slate-700">{selectedReport.prescription.activeIngredient || "Mancozeb 800g/kg"}</span>
                      </div>
                      <div>
                        <span className="font-bold text-emerald-900 block">Calibrated Dosage:</span>
                        <span className="text-slate-700 font-black">{selectedReport.prescription.dosage}</span>
                      </div>
                    </div>

                    <div>
                      <span className="font-bold text-emerald-900 block">Application Method:</span>
                      <p className="text-slate-700">{selectedReport.prescription.applicationMethod}</p>
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-emerald-200 text-xs space-y-1">
                      <div className="flex justify-between font-bold text-slate-800">
                        <span>Pre-Harvest Interval (Withdrawal):</span>
                        <span className="text-rose-700">{selectedReport.prescription.withdrawalPeriodDays || 14} Days</span>
                      </div>
                      <p className="text-slate-500 text-[11px]">
                        Safety: {selectedReport.prescription.safetyInstructions || "Wear full PPE and keep livestock away."}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Soil Test (If Available) */}
              {selectedReport.soilTest && (
                <div className="space-y-2">
                  <h4 className="font-black text-slate-900 uppercase text-[11px] tracking-wider">
                    Soil Lab Analysis Results
                  </h4>
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                      <div className="bg-white p-2 rounded-xl border border-slate-200">
                        <span className="text-[10px] text-slate-400 block font-bold">pH Level</span>
                        <span className="font-black text-slate-900 text-sm">{selectedReport.soilTest.ph}</span>
                      </div>
                      <div className="bg-white p-2 rounded-xl border border-slate-200">
                        <span className="text-[10px] text-slate-400 block font-bold">Nitrogen (N)</span>
                        <span className="font-black text-slate-900 text-sm">{selectedReport.soilTest.nitrogenPpm} ppm</span>
                      </div>
                      <div className="bg-white p-2 rounded-xl border border-slate-200">
                        <span className="text-[10px] text-slate-400 block font-bold">Phosphorus (P)</span>
                        <span className="font-black text-slate-900 text-sm">{selectedReport.soilTest.phosphorusPpm} ppm</span>
                      </div>
                      <div className="bg-white p-2 rounded-xl border border-slate-200">
                        <span className="text-[10px] text-slate-400 block font-bold">Potassium (K)</span>
                        <span className="font-black text-slate-900 text-sm">{selectedReport.soilTest.potassiumPpm} ppm</span>
                      </div>
                    </div>

                    <div className="text-xs">
                      <span className="font-bold text-slate-800 block">Agronomist Recommendation:</span>
                      <p className="text-slate-600">{selectedReport.soilTest.recommendation}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                Official Digital Record • Mabala Advisory
              </span>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => handleDownloadPdfReport(selectedReport)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Download className="w-4 h-4" />
                  <span>Download PDF Report</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: RATE & REVIEW SPECIALIST */}
      {showRatingModal && ratingTicket && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-black text-slate-900">Rate Agronomist Visit</h3>
                <p className="text-xs text-slate-500">{ratingTicket.agronomistName}</p>
              </div>
              <button
                onClick={() => setShowRatingModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-slate-600 space-y-3">
              <p>How was your diagnostic consultation experience?</p>
              <div className="flex gap-2 justify-center py-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRatingStars(star)}
                    className="text-2xl cursor-pointer transition-transform hover:scale-125"
                  >
                    {star <= ratingStars ? "⭐" : "☆"}
                  </button>
                ))}
              </div>

              <textarea
                rows={3}
                placeholder="Describe how the diagnosis, spray advice, or soil analysis helped your farm..."
                value={ratingComment}
                onChange={(e) => setRatingComment(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900"
              />

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRatingModal(false)}
                  disabled={isSubmittingRating}
                  className="w-1/2 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleRatingSubmit}
                  disabled={isSubmittingRating}
                  className="w-1/2 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl font-black cursor-pointer shadow-md"
                >
                  {isSubmittingRating ? "Submitting..." : "Submit Review"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FarmerAgronomistPortal;

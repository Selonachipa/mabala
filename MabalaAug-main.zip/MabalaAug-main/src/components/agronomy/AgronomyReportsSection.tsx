import React, { useState } from "react";
import {
  FileText,
  Download,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  MapPin,
  Sprout,
  ShieldCheck,
  Eye,
  Calendar,
  X,
  Droplets,
  FlaskConical,
  Layers,
  Phone,
  FileCheck
} from "lucide-react";
import jsPDF from "jspdf";
import { AdvisoryConsultation } from "../../types";

interface AgronomyReportsSectionProps {
  consultations: AdvisoryConsultation[];
  onBookFollowUp?: (report: AdvisoryConsultation) => void;
  currencySymbol?: string;
  activeFarmName?: string;
}

export const AgronomyReportsSection: React.FC<AgronomyReportsSectionProps> = ({
  consultations = [],
  onBookFollowUp,
  currencySymbol = "ZK",
  activeFarmName = "Sunrise Agro-Tech Farms"
}) => {
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<"ALL" | "Prescribed" | "In Analysis" | "Resolved" | "Open">("ALL");
  const [selectedReportForView, setSelectedReportForView] = useState<AdvisoryConsultation | null>(null);

  // Filter consultations
  const filteredReports = consultations.filter((rep) => {
    const matchesStatus = statusFilter === "ALL" || rep.status === statusFilter;
    const matchesSearch =
      !searchQuery ||
      rep.cropType?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rep.agronomistName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rep.symptomsDescription?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rep.diagnosisNotes?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rep.fieldBlock?.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesStatus && matchesSearch;
  });

  // Download single PDF Report
  const handleDownloadPdf = (report: AdvisoryConsultation) => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();

      // Header Banner
      doc.setFillColor(15, 76, 58); // Deep emerald green
      doc.rect(0, 0, pageWidth, 42, "F");

      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(16);
      doc.text("MABALA OFFICIAL AGRONOMY FIELD REPORT", 14, 20);

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text("Official Crop Pathology, Soil Health & Prescription Advisory", 14, 28);
      doc.text(`Consultation Ref: ${report.id} | Issued Date: ${report.date || new Date().toISOString().split("T")[0]}`, 14, 35);

      // Section 1: Farm & Specialist Details
      doc.setTextColor(30, 41, 59);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("1. FIELD INSPECTION PARTICULARS", 14, 54);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.text(`Farm Entity: ${report.farmName || activeFarmName}`, 14, 62);
      doc.text(`Farmer / Client: ${report.farmerName || "Farm Manager"} (${report.farmerPhone || "+260 97X XXX XXX"})`, 14, 69);
      doc.text(`Crop & Target Block: ${report.cropType} — ${report.fieldBlock || "Active Plot"}`, 14, 76);
      doc.text(`Certifying Agronomist: ${report.agronomistName || "Mabala Agronomy Specialist"}`, 14, 83);
      doc.text(`Severity Classification: ${report.severity} | Workflow Status: ${report.status}`, 14, 90);

      // Section 2: Symptoms & Diagnosis
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("2. FIELD OBSERVATIONS & PATHOLOGY DIAGNOSIS", 14, 104);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      const symptomsLines = doc.splitTextToSize(
        `Reported Symptoms: ${report.symptomsDescription || "Routine field diagnostic and yield monitoring."}`,
        pageWidth - 28
      );
      doc.text(symptomsLines, 14, 112);

      let currentY = 112 + symptomsLines.length * 6;

      const diagnosisLines = doc.splitTextToSize(
        `Agronomist Diagnosis & Clinical Notes: ${report.diagnosisNotes || "Field evaluation completed. No severe pathogen outbreak identified; standard crop management advised."}`,
        pageWidth - 28
      );
      doc.text(diagnosisLines, 14, currentY);
      currentY += diagnosisLines.length * 6 + 6;

      // Section 3: Chemical & Organic Treatment Prescription
      if (report.prescription) {
        doc.setFont("helvetica", "bold");
        doc.setFontSize(12);
        doc.text("3. OFFICIAL TREATMENT PRESCRIPTION (ZEMA COMPLIANT)", 14, currentY);
        currentY += 8;

        doc.setFillColor(248, 250, 252);
        doc.rect(14, currentY - 4, pageWidth - 28, 44, "F");

        doc.setFont("helvetica", "bold");
        doc.setFontSize(10);
        doc.text(`Product Name: ${report.prescription.productName}`, 18, currentY + 3);
        
        doc.setFont("helvetica", "normal");
        doc.text(`Active Ingredient: ${report.prescription.activeIngredient}`, 18, currentY + 10);
        doc.text(`Recommended Dosage: ${report.prescription.dosage}`, 18, currentY + 17);
        doc.text(`Application Method: ${report.prescription.applicationMethod}`, 18, currentY + 24);
        doc.text(`Withdrawal / Re-entry Period: ${report.prescription.withdrawalPeriodDays} days before harvest`, 18, currentY + 31);
        doc.text(`Safety Precautions: ${report.prescription.safetyInstructions}`, 18, currentY + 37);

        currentY += 50;
      }

      // Section 4: Soil Health Measurements (if present)
      if (report.soilTest) {
        doc.setFont("helvetica", "bold");
        doc.setFontSize(12);
        doc.text("4. SOIL CHEMISTRY & FERTILITY ANALYSIS", 14, currentY);
        currentY += 8;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(10);
        doc.text(`Soil pH: ${report.soilTest.ph} | Nitrogen (N): ${report.soilTest.nitrogenPpm} ppm | Phosphorus (P): ${report.soilTest.phosphorusPpm} ppm | Potassium (K): ${report.soilTest.potassiumPpm} ppm`, 14, currentY);
        currentY += 7;
        const soilRecLines = doc.splitTextToSize(`Soil Recommendation: ${report.soilTest.recommendation}`, pageWidth - 28);
        doc.text(soilRecLines, 14, currentY);
        currentY += soilRecLines.length * 6 + 6;
      }

      // Digital Certification Stamp
      doc.setFillColor(240, 253, 244);
      doc.rect(14, currentY, pageWidth - 28, 22, "F");
      doc.setTextColor(22, 101, 52);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.text("✓ CERTIFIED BY MABALA AGRICULTURAL EXTENSION DESK", 18, currentY + 8);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);
      doc.text("This document is an authorized field report generated via the Mabala Advisory Services Network.", 18, currentY + 15);

      doc.save(`Mabala_Agronomy_Report_${report.id}.pdf`);
    } catch (e) {
      console.error("PDF generation error:", e);
      alert("Failed to generate PDF. Please retry.");
    }
  };

  // Download All Reports as CSV
  const handleDownloadCsv = () => {
    try {
      const headers = [
        "Report ID",
        "Date",
        "Farm Name",
        "Farmer Name",
        "Agronomist Name",
        "Category",
        "Crop Type",
        "Field Block",
        "Severity",
        "Status",
        "Symptoms",
        "Diagnosis Notes",
        "Prescription Product",
        "Prescription Dosage",
        "Withdrawal Days",
        "Soil pH",
        "Soil Recommendation"
      ];

      const rows = consultations.map((rep) => [
        `"${rep.id}"`,
        `"${rep.date}"`,
        `"${rep.farmName || activeFarmName}"`,
        `"${rep.farmerName || ""}"`,
        `"${rep.agronomistName || ""}"`,
        `"${rep.category || ""}"`,
        `"${rep.cropType || ""}"`,
        `"${rep.fieldBlock || ""}"`,
        `"${rep.severity || ""}"`,
        `"${rep.status || ""}"`,
        `"${(rep.symptomsDescription || "").replace(/"/g, '""')}"`,
        `"${(rep.diagnosisNotes || "").replace(/"/g, '""')}"`,
        `"${rep.prescription?.productName || "N/A"}"`,
        `"${rep.prescription?.dosage || "N/A"}"`,
        `"${rep.prescription?.withdrawalPeriodDays || 0}"`,
        `"${rep.soilTest?.ph || "N/A"}"`,
        `"${(rep.soilTest?.recommendation || "").replace(/"/g, '""')}"`
      ]);

      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `Mabala_Agronomy_Reports_${new Date().toISOString().split("T")[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      console.error("CSV generation failed:", e);
      alert("Failed to export CSV.");
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-4 font-sans" id="agronomy-reports-dashboard-section">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/15 text-blue-600 border border-blue-500/30 flex items-center justify-center font-bold text-xl shrink-0">
            📑
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.2 bg-blue-100 text-blue-800 text-[9px] font-black rounded uppercase font-mono">
                Agronomic Intelligence & Prescriptions
              </span>
              <span className="px-1.5 py-0.2 bg-slate-100 text-slate-700 text-[9px] font-bold rounded">
                {consultations.length} Active Records
              </span>
            </div>
            <h4 className="text-sm font-black text-slate-900 mt-0.5">
              Agronomy Field Reports & Specialist Diagnostic Records
            </h4>
          </div>
        </div>

        {/* Global CSV Download & Search Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search reports, prescriptions..."
              className="pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:border-blue-500 w-44 sm:w-52"
            />
          </div>

          <button
            type="button"
            onClick={handleDownloadCsv}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
            title="Download CSV dataset of all consultation reports"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-bold">
        {(["ALL", "Prescribed", "In Analysis", "Resolved", "Open"] as const).map((st) => (
          <button
            key={st}
            type="button"
            onClick={() => setStatusFilter(st)}
            className={`px-3 py-1 rounded-xl transition whitespace-nowrap ${
              statusFilter === st
                ? "bg-slate-900 text-white font-black shadow-xs"
                : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            }`}
          >
            {st === "ALL" ? `All Reports (${consultations.length})` : st}
          </button>
        ))}
      </div>

      {/* Reports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {filteredReports.map((rep) => {
          const isPrescribed = rep.status === "Prescribed";
          const isCritical = rep.severity === "Critical" || rep.severity === "High";

          return (
            <div
              key={rep.id}
              className="bg-slate-50/70 border border-slate-200 hover:border-blue-300 rounded-xl p-4 transition duration-150 hover:shadow-sm flex flex-col justify-between space-y-3"
            >
              <div>
                {/* Header: ID, Date, Status */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] font-bold text-slate-400 bg-white px-2 py-0.5 rounded border border-slate-200">
                      {rep.id}
                    </span>
                    <span className="text-[10.5px] text-slate-400 font-mono">
                      {rep.date}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <span className={`px-2 py-0.5 text-[8.5px] font-black rounded uppercase font-mono ${
                      isCritical
                        ? "bg-rose-100 text-rose-800 border border-rose-200"
                        : "bg-amber-100 text-amber-800 border border-amber-200"
                    }`}>
                      {rep.severity}
                    </span>

                    <span className={`px-2 py-0.5 text-[8.5px] font-black rounded uppercase font-mono ${
                      rep.status === "Resolved"
                        ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                        : rep.status === "Prescribed"
                        ? "bg-blue-100 text-blue-800 border border-blue-200"
                        : "bg-slate-200 text-slate-700"
                    }`}>
                      {rep.status}
                    </span>
                  </div>
                </div>

                {/* Crop & Field Block */}
                <div className="mt-2">
                  <h5 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                    <Sprout className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{rep.cropType}</span>
                    {rep.fieldBlock && (
                      <span className="text-[10.5px] font-normal text-slate-500">
                        • {rep.fieldBlock}
                      </span>
                    )}
                  </h5>
                  <p className="text-[11px] text-slate-500 mt-0.5 font-medium">
                    Attending: <strong className="text-slate-800">{rep.agronomistName || "Field Specialist"}</strong>
                  </p>
                </div>

                {/* Diagnosis / Prescription Snippet */}
                <div className="mt-2.5 bg-white p-2.5 rounded-lg border border-slate-200/80 text-[11px] text-slate-600 space-y-1">
                  {rep.diagnosisNotes ? (
                    <div>
                      <span className="text-[9.5px] uppercase font-black text-slate-400 block">Diagnosis:</span>
                      <p className="line-clamp-2 leading-relaxed text-slate-700">{rep.diagnosisNotes}</p>
                    </div>
                  ) : (
                    <div>
                      <span className="text-[9.5px] uppercase font-black text-slate-400 block">Reported Symptoms:</span>
                      <p className="line-clamp-2 leading-relaxed text-slate-700">{rep.symptomsDescription}</p>
                    </div>
                  )}

                  {rep.prescription && (
                    <div className="pt-1 border-t border-slate-100 flex items-center gap-1 text-[10px] text-blue-700 font-bold">
                      <FileCheck className="w-3 h-3 text-blue-600 shrink-0" />
                      <span className="truncate">Prescribed: {rep.prescription.productName}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons: View Details & Download PDF */}
              <div className="pt-2 border-t border-slate-200 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedReportForView(rep)}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 text-xs font-bold rounded-xl transition flex items-center gap-1 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5 text-slate-500" />
                  <span>Inspect Report</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDownloadPdf(rep)}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-550 text-white text-xs font-black rounded-xl shadow-xs transition flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>PDF Report</span>
                </button>
              </div>
            </div>
          );
        })}

        {filteredReports.length === 0 && (
          <div className="col-span-2 py-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-300 text-slate-400 text-xs">
            No agronomy reports found matching the selected filter.
          </div>
        )}
      </div>

      {/* Inspect Report Modal */}
      {selectedReportForView && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fade-in overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh] my-auto">
            {/* Header */}
            <div className="bg-slate-900 text-white p-4.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xl">
                  📄
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.2 bg-blue-500/20 text-blue-300 text-[9px] font-black rounded uppercase font-mono">
                      Report Ref: {selectedReportForView.id}
                    </span>
                    <span className="text-[10px] text-slate-400">{selectedReportForView.date}</span>
                  </div>
                  <h4 className="text-sm font-black text-white mt-0.5">
                    {selectedReportForView.cropType} Diagnostic & Treatment Plan
                  </h4>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedReportForView(null)}
                className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition"
              >
                ✕
              </button>
            </div>

            {/* Body */}
            <div className="p-5 space-y-4 overflow-y-auto text-xs flex-1">
              {/* Meta Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 bg-slate-50 p-3 rounded-xl border border-slate-200 text-[11px]">
                <div>
                  <span className="text-slate-400 text-[9.5px] uppercase font-bold block">Farm & Field Block</span>
                  <strong className="text-slate-900">{selectedReportForView.farmName || activeFarmName}</strong>
                  <div className="text-slate-500 text-[10px]">{selectedReportForView.fieldBlock || "Active Plot"}</div>
                </div>

                <div>
                  <span className="text-slate-400 text-[9.5px] uppercase font-bold block">Attending Agronomist</span>
                  <strong className="text-slate-900">{selectedReportForView.agronomistName}</strong>
                  <div className="text-emerald-600 text-[10px] font-bold">✓ ZEMA Registered</div>
                </div>

                <div>
                  <span className="text-slate-400 text-[9.5px] uppercase font-bold block">Workflow Status</span>
                  <span className="inline-block px-2 py-0.5 bg-blue-100 text-blue-800 text-[9.5px] font-black rounded uppercase font-mono">
                    {selectedReportForView.status}
                  </span>
                </div>
              </div>

              {/* Symptoms & Diagnosis */}
              <div className="space-y-3">
                <div className="bg-amber-50/70 border border-amber-200 p-3 rounded-xl">
                  <h5 className="font-black text-amber-900 uppercase text-[10px] tracking-wider mb-1">
                    Reported Crop Symptoms:
                  </h5>
                  <p className="text-slate-700 text-xs leading-relaxed">
                    {selectedReportForView.symptomsDescription}
                  </p>
                </div>

                <div className="bg-emerald-50/70 border border-emerald-200 p-3 rounded-xl">
                  <h5 className="font-black text-emerald-900 uppercase text-[10px] tracking-wider mb-1">
                    Agronomist Pathology & Diagnosis Notes:
                  </h5>
                  <p className="text-slate-800 text-xs leading-relaxed">
                    {selectedReportForView.diagnosisNotes || "Field evaluation complete. Crop stands are within normal vegetative vigor."}
                  </p>
                </div>
              </div>

              {/* Prescription Card */}
              {selectedReportForView.prescription && (
                <div className="bg-slate-900 text-white p-4 rounded-xl space-y-2 text-xs">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-[10px] font-mono text-emerald-400 uppercase font-black flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Certified Treatment Prescription</span>
                    </span>
                    <span className="text-[9.5px] bg-slate-800 px-2 py-0.5 rounded text-slate-300">
                      Re-entry: {selectedReportForView.prescription.withdrawalPeriodDays} Days
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Product Formulation:</span>
                      <strong className="text-emerald-300 text-xs font-mono">{selectedReportForView.prescription.productName}</strong>
                      <div className="text-[10.5px] text-slate-300 mt-0.5">Active: {selectedReportForView.prescription.activeIngredient}</div>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block">Dosage & Spray Rate:</span>
                      <strong className="text-amber-300 text-xs font-mono">{selectedReportForView.prescription.dosage}</strong>
                      <div className="text-[10.5px] text-slate-300 mt-0.5">Method: {selectedReportForView.prescription.applicationMethod}</div>
                    </div>
                  </div>

                  <div className="border-t border-slate-800 pt-2 text-[10.5px] text-slate-400">
                    <span className="text-rose-400 font-bold uppercase text-[9px] block">Safety Protocol:</span>
                    {selectedReportForView.prescription.safetyInstructions}
                  </div>
                </div>
              )}

              {/* Soil Test Data */}
              {selectedReportForView.soilTest && (
                <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl space-y-2">
                  <h5 className="font-black text-slate-800 uppercase text-[10px] tracking-wider">
                    Soil Fertility & Nutrient Readings
                  </h5>
                  <div className="grid grid-cols-4 gap-2 font-mono text-center">
                    <div className="bg-white p-2 rounded-lg border border-slate-200">
                      <span className="text-[9px] text-slate-400 block">pH Level</span>
                      <strong className="text-xs text-slate-800">{selectedReportForView.soilTest.ph}</strong>
                    </div>
                    <div className="bg-white p-2 rounded-lg border border-slate-200">
                      <span className="text-[9px] text-slate-400 block">Nitrogen (N)</span>
                      <strong className="text-xs text-emerald-700">{selectedReportForView.soilTest.nitrogenPpm} ppm</strong>
                    </div>
                    <div className="bg-white p-2 rounded-lg border border-slate-200">
                      <span className="text-[9px] text-slate-400 block">Phosphorus (P)</span>
                      <strong className="text-xs text-amber-700">{selectedReportForView.soilTest.phosphorusPpm} ppm</strong>
                    </div>
                    <div className="bg-white p-2 rounded-lg border border-slate-200">
                      <span className="text-[9px] text-slate-400 block">Potassium (K)</span>
                      <strong className="text-xs text-blue-700">{selectedReportForView.soilTest.potassiumPpm} ppm</strong>
                    </div>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1 italic">
                    Recommendation: {selectedReportForView.soilTest.recommendation}
                  </p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setSelectedReportForView(null)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900"
              >
                Close Window
              </button>

              <button
                type="button"
                onClick={() => {
                  handleDownloadPdf(selectedReportForView);
                }}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-550 text-white text-xs font-black rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Official PDF Report</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default AgronomyReportsSection;

import React, { useState } from "react";
import {
  Sparkles,
  Star,
  ShieldCheck,
  MapPin,
  Calendar,
  Clock,
  Search,
  Filter,
  CheckCircle2,
  Stethoscope,
  Sprout,
  ArrowRight,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Phone,
  Mail,
  User,
  Info,
  Award,
  Layers,
  ThumbsUp,
  MessageSquare,
  FileCheck
} from "lucide-react";
import { AGRONOMIST_PROFILES, AgronomistProfile } from "./FarmerAgronomistPortal";
import { AdvisoryConsultation } from "../../types";

interface AgronomistCardsSectionProps {
  onBookAgronomist: (agronomist: AgronomistProfile) => void;
  currencySymbol?: string;
  consultations?: AdvisoryConsultation[];
}

export const AgronomistCardsSection: React.FC<AgronomistCardsSectionProps> = ({
  onBookAgronomist,
  currencySymbol = "ZK",
  consultations = []
}) => {
  const [filterType, setFilterType] = useState<"ALL" | "Agronomist" | "Vet">("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedProfileForModal, setSelectedProfileForModal] = useState<AgronomistProfile | null>(null);
  const [expandedReviewsAgroId, setExpandedReviewsAgroId] = useState<string | null>(null);
  const [reviewRatingFilter, setReviewRatingFilter] = useState<number | "ALL">("ALL");

  // Helper to get aggregated reviews for an agronomist from both profile presets and shared report consultations
  const getAgronomistReviews = (agro: AgronomistProfile) => {
    // 1. Report-derived consultations with rating
    const reportReviews = consultations
      .filter((c) => (c.agronomistId === agro.id || (!c.agronomistId && agro.id === "agro-01")) && c.rating)
      .map((c) => ({
        id: c.id,
        farmerName: c.farmerName || "Verified Farmer",
        farmName: c.farmName || "Commercial Block",
        date: c.ratedAt ? new Date(c.ratedAt).toISOString().split("T")[0] : c.date,
        rating: c.rating || 5,
        comment: c.ratingComment || (c.diagnosisNotes ? `Diagnostic note: ${c.diagnosisNotes}` : "Prescription effectively resolved the field issue with great technical support."),
        cropType: c.cropType,
        source: "Shared Report"
      }));

    // 2. Profile default reviews
    const profileReviews = agro.recentReviews.map((r, i) => ({
      id: `prof-rev-${agro.id}-${i}`,
      farmerName: r.farmerName,
      farmName: r.farmName,
      date: r.date,
      rating: r.rating,
      comment: r.comment,
      cropType: agro.specialties[0] || "General Agronomy",
      source: "Verified Field Audit"
    }));

    // Merge and deduplicate by comment or id
    const allReviews = [...reportReviews, ...profileReviews];
    const totalScore = allReviews.reduce((acc, curr) => acc + curr.rating, 0);
    const avgRating = allReviews.length > 0 ? totalScore / allReviews.length : agro.rating;

    return {
      reviews: allReviews,
      totalCount: allReviews.length,
      averageRating: avgRating,
      fiveStarCount: allReviews.filter((r) => r.rating === 5).length,
      fourStarCount: allReviews.filter((r) => r.rating === 4).length,
      recommendationPct: Math.round(((allReviews.filter((r) => r.rating >= 4).length) / Math.max(1, allReviews.length)) * 100)
    };
  };

  const filteredProfiles = AGRONOMIST_PROFILES.filter((agro) => {
    const matchesType =
      filterType === "ALL" ||
      (filterType === "Agronomist" && agro.specialistType === "Agronomist") ||
      (filterType === "Vet" && agro.specialistType === "Veterinary Surgeon (Vet)");

    const matchesSearch =
      !searchQuery ||
      agro.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      agro.specialties.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase())) ||
      agro.districts.some((d) => d.toLowerCase().includes(searchQuery.toLowerCase())) ||
      agro.title.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesType && matchesSearch;
  });

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-4 font-sans" id="onboarded-agronomists-dashboard-card">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-600 border border-emerald-500/30 flex items-center justify-center font-bold text-xl shrink-0">
            🌾
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.2 bg-emerald-100 text-emerald-800 text-[9px] font-black rounded uppercase font-mono">
                Field Advisory Network
              </span>
              <span className="px-1.5 py-0.2 bg-slate-100 text-slate-700 text-[9px] font-bold rounded">
                {AGRONOMIST_PROFILES.length} Onboarded Specialists
              </span>
            </div>
            <h4 className="text-sm font-black text-slate-900 mt-0.5">
              Onboarded Agronomists & Veterinary Field Specialists
            </h4>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search crop, specialty, district..."
              className="pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:border-emerald-500 w-48 sm:w-56"
            />
          </div>

          <div className="flex items-center bg-slate-100 p-1 rounded-xl gap-1 text-[11px] font-bold">
            <button
              type="button"
              onClick={() => setFilterType("ALL")}
              className={`px-2.5 py-1 rounded-lg transition ${
                filterType === "ALL"
                  ? "bg-white text-emerald-800 shadow-xs font-black"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              All Specialists ({AGRONOMIST_PROFILES.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterType("Agronomist")}
              className={`px-2.5 py-1 rounded-lg transition ${
                filterType === "Agronomist"
                  ? "bg-white text-emerald-800 shadow-xs font-black"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              Crop Agronomists
            </button>
            <button
              type="button"
              onClick={() => setFilterType("Vet")}
              className={`px-2.5 py-1 rounded-lg transition ${
                filterType === "Vet"
                  ? "bg-white text-emerald-800 shadow-xs font-black"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              Veterinary Doctors
            </button>
          </div>
        </div>
      </div>

      {/* Grid of Agronomist Cards */}
      {filteredProfiles.length === 0 ? (
        <div className="bg-slate-50 border border-dashed border-slate-300 rounded-2xl p-8 text-center space-y-2">
          <div className="text-3xl">🌾</div>
          <h5 className="text-xs font-bold text-slate-700">No Specialists Listed</h5>
          <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
            Certified agronomists and veterinary doctors will be listed here once assigned to this territory.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProfiles.map((agro) => {
            const isVet = agro.specialistType === "Veterinary Surgeon (Vet)";
            const reviewData = getAgronomistReviews(agro);
            const isReviewsExpanded = expandedReviewsAgroId === agro.id;

            return (
              <div
                key={agro.id}
                className="bg-slate-50/70 border border-slate-200 hover:border-emerald-400/80 rounded-2xl p-4 transition-all duration-200 hover:shadow-md flex flex-col justify-between space-y-3 group"
              >
                <div>
                  {/* Card Header: Avatar, Name, Verification */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-xl shrink-0 ${
                        isVet 
                          ? "bg-sky-100 text-sky-700 border border-sky-200" 
                          : "bg-emerald-100 text-emerald-800 border border-emerald-200"
                      }`}>
                        {isVet ? "🩺" : "🌾"}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h5 className="font-extrabold text-slate-900 text-xs leading-snug">
                            {agro.name}
                          </h5>
                        </div>
                        <p className="text-[10.5px] font-medium text-slate-500 line-clamp-1 mt-0.5">
                          {agro.title}
                        </p>
                        <div className="flex items-center gap-1 mt-1">
                          <span className="px-1.5 py-0.2 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[8.5px] font-black rounded uppercase flex items-center gap-0.5">
                            <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                            <span>{isVet ? "VCZ Licensed" : "ZEMA Certified"}</span>
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            • {agro.experienceYears}y exp
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Rating Badge */}
                    <div className="text-right shrink-0">
                      <button
                        type="button"
                        onClick={() => setExpandedReviewsAgroId(isReviewsExpanded ? null : agro.id)}
                        className="flex items-center gap-1 text-amber-600 font-black text-xs font-mono bg-amber-50 hover:bg-amber-100 border border-amber-200 px-2 py-0.5 rounded-lg transition cursor-pointer"
                        title="Click to view verified reviews from shared report data"
                      >
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                        <span>{reviewData.averageRating.toFixed(1)}</span>
                        <span className="text-[9px] text-slate-500 font-sans font-normal">
                          ({reviewData.totalCount})
                        </span>
                      </button>
                      <span className="text-[8.5px] text-emerald-700 font-bold block mt-0.5">
                        {reviewData.recommendationPct}% Recommended
                      </span>
                    </div>
                  </div>

                  {/* Specialties tags */}
                  <div className="mt-3 flex flex-wrap gap-1">
                    {agro.specialties.slice(0, 3).map((spec, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 bg-white border border-slate-200 text-slate-700 text-[9.5px] font-semibold rounded-md truncate max-w-[200px]"
                      >
                        {spec}
                      </span>
                    ))}
                    {agro.specialties.length > 3 && (
                      <span className="px-1.5 py-0.5 bg-slate-100 text-slate-500 text-[9px] font-bold rounded-md">
                        +{agro.specialties.length - 3} more
                      </span>
                    )}
                  </div>

                  {/* Coverage districts */}
                  <div className="mt-2.5 text-[10.5px] text-slate-500 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="truncate">
                      {agro.districts.slice(0, 3).join(", ")} {agro.districts.length > 3 ? `(+${agro.districts.length - 3})` : ""}
                    </span>
                  </div>

                  {/* Ratings & Reviews Toggle Bar on Card */}
                  <div className="mt-3 bg-white border border-slate-200/90 rounded-xl p-2.5 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-[10.5px] font-bold text-slate-800">
                          Farmer Ratings & Reports
                        </span>
                        <span className="px-1.5 py-0.2 bg-emerald-50 text-emerald-800 border border-emerald-200 text-[8.5px] font-black rounded-full">
                          {reviewData.totalCount} Verified
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => setExpandedReviewsAgroId(isReviewsExpanded ? null : agro.id)}
                        className="text-[10px] text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-0.5 cursor-pointer"
                      >
                        <span>{isReviewsExpanded ? "Hide" : "View"} Reviews</span>
                        {isReviewsExpanded ? (
                          <ChevronUp className="w-3 h-3" />
                        ) : (
                          <ChevronDown className="w-3 h-3" />
                        )}
                      </button>
                    </div>

                    {/* Rating distribution snippet */}
                    {!isReviewsExpanded && reviewData.reviews.length > 0 && (
                      <div className="bg-slate-50 rounded-lg p-2 border border-slate-100 text-[10.5px]">
                        <div className="flex items-center justify-between text-slate-700 font-semibold mb-0.5">
                          <span className="text-[10px] font-bold text-slate-900 truncate max-w-[140px]">
                            {reviewData.reviews[0].farmerName}
                          </span>
                          <div className="flex text-amber-400 text-xs">
                            {"★".repeat(reviewData.reviews[0].rating)}
                          </div>
                        </div>
                        <p className="text-slate-500 italic text-[10px] line-clamp-1">
                          &ldquo;{reviewData.reviews[0].comment}&rdquo;
                        </p>
                      </div>
                    )}

                    {/* Expanded Reviews Drawer on the Card */}
                    {isReviewsExpanded && (
                      <div className="pt-2 border-t border-slate-100 space-y-2.5 animate-fade-in">
                        {/* Overall Rating & Breakdown */}
                        <div className="bg-amber-50/50 border border-amber-200/70 p-2.5 rounded-xl flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="text-xl font-black text-amber-700 font-mono">
                              {reviewData.averageRating.toFixed(1)}
                            </div>
                            <div>
                              <div className="flex text-amber-400 text-xs">
                                {"★".repeat(Math.round(reviewData.averageRating))}
                              </div>
                              <span className="text-[9.5px] text-slate-500 font-medium">
                                Based on {reviewData.totalCount} field reports
                              </span>
                            </div>
                          </div>
                          <div className="text-right text-[10px] font-mono text-slate-600">
                            <div>5★ ({reviewData.fiveStarCount})</div>
                            <div>4★ ({reviewData.fourStarCount})</div>
                          </div>
                        </div>

                        {/* List of Verified Reviews */}
                        <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                          {reviewData.reviews.map((rev) => (
                            <div
                              key={rev.id}
                              className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/80 text-[10.5px] space-y-1"
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1.5 truncate">
                                  <span className="font-bold text-slate-900 truncate">
                                    {rev.farmerName}
                                  </span>
                                  <span className="text-[9px] text-slate-400">• {rev.farmName}</span>
                                </div>
                                <div className="flex text-amber-400 text-xs shrink-0 font-mono">
                                  {"★".repeat(rev.rating)}
                                </div>
                              </div>
                              <p className="text-slate-600 italic leading-snug">
                                &ldquo;{rev.comment}&rdquo;
                              </p>
                              <div className="flex items-center justify-between text-[9px] text-slate-400 pt-1 border-t border-slate-100 font-mono">
                                <span className="text-emerald-700 font-sans font-bold flex items-center gap-0.5">
                                  <FileCheck className="w-2.5 h-2.5 text-emerald-600" />
                                  <span>{rev.source}</span>
                                </span>
                                <span>{rev.date}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Card Footer: Pricing & Action Buttons */}
                <div className="pt-3 border-t border-slate-200/80 flex items-center justify-between gap-2">
                  <div>
                    <span className="text-[9px] font-mono text-slate-400 uppercase block">Visit Fee</span>
                    <strong className="text-emerald-700 font-mono font-black text-xs">
                      {currencySymbol} {agro.pricing.farmVisit.toLocaleString()}
                    </strong>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setSelectedProfileForModal(agro)}
                      className="px-2.5 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold rounded-xl transition cursor-pointer"
                    >
                      Profile
                    </button>

                    <button
                      type="button"
                      onClick={() => onBookAgronomist(agro)}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-550 text-white text-xs font-black rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer group-hover:scale-[1.02]"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Book Visit</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Profile Detail Modal */}
      {selectedProfileForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[85vh]">
            <div className="bg-slate-900 text-white p-4.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xl font-bold">
                  {selectedProfileForModal.specialistType === "Veterinary Surgeon (Vet)" ? "🩺" : "🌾"}
                </div>
                <div>
                  <h4 className="text-sm font-black text-white">{selectedProfileForModal.name}</h4>
                  <p className="text-[10px] text-slate-300">{selectedProfileForModal.title}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedProfileForModal(null)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-3.5 overflow-y-auto text-xs flex-1">
              <div>
                <span className="text-[9.5px] font-black uppercase text-slate-400 tracking-wider">Academic Degree & Credentials</span>
                <p className="text-slate-800 font-bold text-xs mt-0.5">{selectedProfileForModal.degree}</p>
              </div>

              <div>
                <span className="text-[9.5px] font-black uppercase text-slate-400 tracking-wider">Specialist Bio</span>
                <p className="text-slate-600 text-[11px] leading-relaxed mt-0.5">{selectedProfileForModal.bio}</p>
              </div>

              <div>
                <span className="text-[9.5px] font-black uppercase text-slate-400 tracking-wider">Areas of Expertise</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {selectedProfileForModal.specialties.map((s, i) => (
                    <span key={i} className="px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold rounded-md">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Verified Report Reviews Section in Modal */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[9.5px] font-black uppercase text-slate-400 tracking-wider">
                    Verified Farmer Reviews & Diagnostic History
                  </span>
                  <span className="text-[10px] font-bold text-amber-600 font-mono">
                    ★ {getAgronomistReviews(selectedProfileForModal).averageRating.toFixed(1)} Average
                  </span>
                </div>
                <div className="space-y-2 mt-1 max-h-52 overflow-y-auto pr-1">
                  {getAgronomistReviews(selectedProfileForModal).reviews.map((rev, idx) => (
                    <div key={idx} className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-[10.5px] space-y-1">
                      <div className="flex justify-between items-center text-slate-700 font-bold">
                        <span>{rev.farmerName} • <span className="text-slate-400 font-normal">{rev.farmName}</span></span>
                        <span className="text-amber-500 font-mono">{"★".repeat(rev.rating)}</span>
                      </div>
                      <p className="text-slate-500 italic leading-snug">&ldquo;{rev.comment}&rdquo;</p>
                      <div className="flex items-center justify-between text-[9px] text-slate-400 pt-1 border-t border-slate-100 font-mono">
                        <span className="text-emerald-700 font-sans font-bold flex items-center gap-0.5">
                          <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                          <span>{rev.source}</span>
                        </span>
                        <span>{rev.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-[9.5px] text-slate-400 font-mono block">Standard Visit</span>
                <strong className="text-emerald-700 font-mono font-black text-sm">
                  {currencySymbol} {selectedProfileForModal.pricing.farmVisit.toLocaleString()}
                </strong>
              </div>
              <button
                type="button"
                onClick={() => {
                  const target = selectedProfileForModal;
                  setSelectedProfileForModal(null);
                  onBookAgronomist(target);
                }}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-550 text-white text-xs font-black rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Proceed to Book Visit</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default AgronomistCardsSection;


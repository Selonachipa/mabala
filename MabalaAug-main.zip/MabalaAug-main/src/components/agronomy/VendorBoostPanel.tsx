import React, { useState, useEffect } from "react";
import { BOOST_PRICING_CONFIG } from "../../services/cropGuidanceService";
import { 
  Sparkles, DollarSign, Calendar, TrendingUp, BarChart3, Eye, 
  MousePointer, ShoppingBag, ShieldCheck, RefreshCw, AlertCircle, Phone, CheckCircle
} from "lucide-react";

interface VendorBoostPanelProps {
  vendorId?: string;
  vendorName?: string;
}

export const VendorBoostPanel: React.FC<VendorBoostPanelProps> = ({
  vendorId = "dealer_tenant_01",
  vendorName = "Zambia Central Agrodealer"
}) => {
  const [activeTab, setActiveTab] = useState<"boost" | "analytics">("boost");
  const [skuId, setSkuId] = useState<string>("sku_mancozeb_500g");
  const [categoryId, setCategoryId] = useState<string>("cat_fungicide");
  const [cropId, setCropId] = useState<string>("ckb_red_onion");
  const [durationDays, setDurationDays] = useState<number>(30);
  const [phone, setPhone] = useState<string>("260971234567");
  const [network, setNetwork] = useState<string>("Airtel");
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [paymentResult, setPaymentResult] = useState<any>(null);
  const [placements, setPlacements] = useState<any[]>([]);
  const [loadingAnalytics, setLoadingAnalytics] = useState<boolean>(false);

  const totalPrice = durationDays * BOOST_PRICING_CONFIG.pricePerDay;

  const fetchVendorAnalytics = async () => {
    setLoadingAnalytics(true);
    try {
      const res = await fetch(`/api/agronomy/vendor-analytics/${vendorId}`);
      const data = await res.json();
      if (data.success) {
        setPlacements(data.placements || []);
      }
    } catch (err) {
      console.warn("[Fetch Vendor Analytics Error]", err);
    } finally {
      setLoadingAnalytics(false);
    }
  };

  useEffect(() => {
    fetchVendorAnalytics();
  }, [vendorId]);

  const handleInitiateBoost = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setPaymentResult(null);

    try {
      const res = await fetch("/api/agronomy/initiate-boost-payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          vendorId,
          skuId,
          categoryId,
          cropId,
          regions: ["Zone 2a - Central/Southern Plateau", "Zone 3 - Northern High Rainfall"],
          durationDays,
          phone,
          network
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setPaymentResult({ success: false, error: data.error || "Failed to initiate payment" });
      } else {
        setPaymentResult(data);
        // Refresh analytics list
        fetchVendorAnalytics();
      }
    } catch (err: any) {
      setPaymentResult({ success: false, error: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  const handleVerifyPayment = async (placementId: string) => {
    try {
      const res = await fetch("/api/agronomy/verify-boost-payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ placementId })
      });
      const data = await res.json();
      alert(data.message || "Payment status checked");
      fetchVendorAnalytics();
    } catch (err: any) {
      alert("Verification error: " + err.message);
    }
  };

  return (
    <div className="space-y-6 p-6 bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-sm">
      {/* Header & Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
        <div>
          <h2 className="text-xl font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-amber-500" />
            Agrodealer Boost & Sponsored Placements
          </h2>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
            Feature your products at the top of farmer growth guides across Zambia
          </p>
        </div>

        <div className="flex items-center gap-2 bg-stone-100 dark:bg-stone-800 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab("boost")}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === "boost" 
                ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs" 
                : "text-stone-500 hover:text-stone-900 dark:text-stone-400"
            }`}
          >
            Create Boost Placement
          </button>
          <button
            onClick={() => setActiveTab("analytics")}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === "analytics" 
                ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs" 
                : "text-stone-500 hover:text-stone-900 dark:text-stone-400"
            }`}
          >
            Placement Performance
          </button>
        </div>
      </div>

      {activeTab === "boost" ? (
        <form onSubmit={handleInitiateBoost} className="max-w-2xl space-y-5">
          <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-xs space-y-1 text-amber-900 dark:text-amber-200">
            <span className="font-bold flex items-center gap-1 text-amber-600">
              <ShieldCheck className="w-4 h-4" /> Server-Enforced Vendor Fair Use Rules
            </span>
            <p>
              Maximum <strong>{BOOST_PRICING_CONFIG.maxConcurrentBoostsPerVendor} active boosted products</strong> per vendor at a time. Rate is <strong>ZMW {BOOST_PRICING_CONFIG.pricePerDay} / day</strong>. All payments are verified via Lipila mobile money PIN prompt.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-bold text-stone-800 dark:text-stone-200 mb-1">
                Select Product SKU
              </label>
              <select
                value={skuId}
                onChange={(e) => setSkuId(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100"
              >
                <option value="sku_mancozeb_500g">Mancozeb 800 WP Fungicide (500g)</option>
                <option value="sku_compound_d_50kg">Compound D Basal Fertiliser (50kg)</option>
                <option value="sku_red_pinoy_100g">Red Pinoy Certified Seed (100g)</option>
                <option value="sku_imidacloprid_250ml">Imidacloprid Insecticide (250ml)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-stone-800 dark:text-stone-200 mb-1">
                Target Input Category
              </label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100"
              >
                <option value="cat_fungicide">Fungicides & Disease Control</option>
                <option value="cat_basal_fert">Basal Fertiliser (Compound D/NPK)</option>
                <option value="cat_seed">Seed & Seedlings</option>
                <option value="cat_insecticide">Insecticides & Pest Control</option>
                <option value="cat_topdress_fert">Top-dress Fertiliser (Urea/CAN)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-stone-800 dark:text-stone-200 mb-1">
                Target Crop Guide
              </label>
              <select
                value={cropId}
                onChange={(e) => setCropId(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100"
              >
                <option value="ckb_red_onion">Red Onion Guidance Engine</option>
                <option value="ckb_hass_avocado">Hass Avocado Guidance Engine</option>
                <option value="ckb_all">All Crops Matching Category</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-stone-800 dark:text-stone-200 mb-1">
                Placement Duration (Days)
              </label>
              <select
                value={durationDays}
                onChange={(e) => setDurationDays(Number(e.target.value))}
                className="w-full p-2.5 rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100"
              >
                <option value={7}>7 Days Placement</option>
                <option value={14}>14 Days Placement</option>
                <option value={30}>30 Days Placement (Best Value)</option>
                <option value={60}>60 Days Placement</option>
              </select>
            </div>
          </div>

          <div className="p-4 bg-stone-50 dark:bg-stone-800/60 rounded-xl border border-stone-200 dark:border-stone-700 space-y-3 text-xs">
            <h4 className="font-bold text-stone-900 dark:text-stone-100 flex items-center justify-between">
              <span>Lipila Mobile Money PIN Payment</span>
              <span className="text-base font-black text-emerald-600 dark:text-emerald-400">
                ZMW {totalPrice.toFixed(2)}
              </span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-stone-600 dark:text-stone-400 mb-1">Mobile Money Network</label>
                <select
                  value={network}
                  onChange={(e) => setNetwork(e.target.value)}
                  className="w-full p-2 rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100"
                >
                  <option value="Airtel">Airtel Money</option>
                  <option value="MTN">MTN Mobile Money</option>
                  <option value="Zamtel">Zamtel Kwacha</option>
                </select>
              </div>

              <div>
                <label className="block text-stone-600 dark:text-stone-400 mb-1">Payer Mobile Number</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="260971234567"
                  className="w-full p-2 rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 font-mono"
                />
              </div>
            </div>
          </div>

          {paymentResult && (
            <div className={`p-4 rounded-xl border text-xs space-y-1 ${
              paymentResult.success 
                ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200" 
                : "bg-red-50 dark:bg-red-950/40 border-red-300 dark:border-red-800 text-red-900 dark:text-red-200"
            }`}>
              <span className="font-bold block">
                {paymentResult.success ? "✓ Boost Payment Prompt Sent!" : "✕ Boost Payment Error"}
              </span>
              <p>{paymentResult.message || paymentResult.error}</p>
              {paymentResult.placementId && (
                <button
                  type="button"
                  onClick={() => handleVerifyPayment(paymentResult.placementId)}
                  className="mt-2 px-3 py-1 bg-emerald-700 text-white font-bold rounded hover:bg-emerald-800 text-[11px]"
                >
                  Verify Payment Status Now
                </button>
              )}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-sm"
          >
            {submitting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            Initiate Lipila PIN Payment & Boost Placement (ZMW {totalPrice})
          </button>
        </form>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100">
              Active & Past Boost Placements
            </h3>
            <button
              onClick={fetchVendorAnalytics}
              className="text-xs text-stone-500 hover:text-stone-800 dark:text-stone-300 flex items-center gap-1"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Refresh
            </button>
          </div>

          {loadingAnalytics ? (
            <div className="py-8 text-center text-xs text-stone-400 animate-pulse">
              Loading placement performance analytics...
            </div>
          ) : placements.length === 0 ? (
            <div className="p-8 text-center text-xs text-stone-500 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-200 dark:border-stone-800">
              No active sponsored placements found for this vendor.
            </div>
          ) : (
            <div className="space-y-3">
              {placements.map((p: any) => {
                const m = p.metrics || {};
                return (
                  <div key={p.placementId} className="p-4 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/40 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs font-bold text-stone-900 dark:text-stone-100 block">
                          {p.skuId}
                        </span>
                        <span className="text-[11px] text-stone-500 dark:text-stone-400">
                          Category: {p.categoryId} • {p.durationDays} Days
                        </span>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        p.status === "active" 
                          ? "bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300" 
                          : "bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-300"
                      }`}>
                        {p.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-stone-200 dark:border-stone-700 text-center">
                      <div className="p-2 bg-white dark:bg-stone-900 rounded-lg">
                        <span className="text-[10px] text-stone-400 uppercase block">Impressions</span>
                        <span className="text-sm font-black text-stone-900 dark:text-stone-100">{m.totalImpressions || 0}</span>
                      </div>
                      <div className="p-2 bg-white dark:bg-stone-900 rounded-lg">
                        <span className="text-[10px] text-stone-400 uppercase block">Clicks</span>
                        <span className="text-sm font-black text-stone-900 dark:text-stone-100">{m.totalClicks || 0}</span>
                      </div>
                      <div className="p-2 bg-white dark:bg-stone-900 rounded-lg">
                        <span className="text-[10px] text-stone-400 uppercase block">CTR</span>
                        <span className="text-sm font-black text-emerald-600 dark:text-emerald-400">{m.ctr || 0}%</span>
                      </div>
                      <div className="p-2 bg-white dark:bg-stone-900 rounded-lg">
                        <span className="text-[10px] text-stone-400 uppercase block">Sales Value</span>
                        <span className="text-sm font-black text-stone-900 dark:text-stone-100">ZMW {m.salesValueAttributed || 0}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

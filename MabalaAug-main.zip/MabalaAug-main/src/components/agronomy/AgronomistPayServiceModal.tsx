import React, { useState, useEffect } from "react";
import {
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Smartphone,
  CreditCard,
  X,
  Clock,
  Download,
  Calendar,
  MapPin,
  Sprout,
  User,
  Check,
  RefreshCw,
  ArrowRight,
  FileText
} from "lucide-react";
import jsPDF from "jspdf";
import { BookingFormData } from "./BookAgronomistModal";
import { detectTelcoProvider, normalizePhoneForLipila } from "../../utils/paymentUtils";

interface AgronomistPayServiceModalProps {
  bookingData: BookingFormData | null;
  isOpen: boolean;
  onClose: () => void;
  onPaymentComplete: (completedBooking: any) => void;
  currencySymbol?: string;
  userProfile?: any;
}

export const AgronomistPayServiceModal: React.FC<AgronomistPayServiceModalProps> = ({
  bookingData,
  isOpen,
  onClose,
  onPaymentComplete,
  currencySymbol = "ZK",
  userProfile
}) => {
  if (!isOpen || !bookingData) return null;

  const [paymentStatus, setPaymentStatus] = useState<"idle" | "submitting" | "pending_pin" | "successful" | "failed">("idle");
  const [carrier, setCarrier] = useState<"MTN" | "Airtel" | "Zamtel">("MTN");
  const [phoneNumber, setPhoneNumber] = useState<string>(() => {
    const raw = bookingData.siteContactPhone || userProfile?.phone || "977442211";
    return raw.replace(/^\+260/, "").trim();
  });
  const [accountHolderName, setAccountHolderName] = useState<string>(
    bookingData.siteContactPerson || userProfile?.name || "Bwalya Chisanga"
  );
  const [isSearchingHolder, setIsSearchingHolder] = useState<boolean>(false);
  const [countdown, setCountdown] = useState<number>(120);
  const [refId, setRefId] = useState<string>("");
  const [errorMessage, setErrorMessage] = useState<string>("");

  // Carrier auto-detection from phone number
  useEffect(() => {
    const detected = detectTelcoProvider(phoneNumber);
    if (detected.isAirtel) {
      setCarrier("Airtel");
    } else if (detected.isMtn) {
      setCarrier("MTN");
    } else if (detected.isZamtel) {
      setCarrier("Zamtel");
    }
  }, [phoneNumber]);

  // Account holder name lookup
  useEffect(() => {
    if (phoneNumber.length >= 9 && paymentStatus === "idle") {
      setIsSearchingHolder(true);
      const timer = setTimeout(async () => {
        try {
          const formatted = `+260${phoneNumber.replace(/^0+/, "")}`;
          const res = await fetch(`/api/lipila/name-lookup?number=${encodeURIComponent(formatted)}`);
          if (res.ok) {
            const data = await res.json();
            if (data?.name) {
              setAccountHolderName(data.name);
              setIsSearchingHolder(false);
              return;
            }
          }
        } catch (e) {
          // fallback to simulated profile
        }
        setAccountHolderName(bookingData.siteContactPerson || userProfile?.name || "Verified Farm Owner");
        setIsSearchingHolder(false);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [phoneNumber, bookingData.siteContactPerson, userProfile?.name, paymentStatus]);

  // USSD Countdown timer when awaiting PIN
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (paymentStatus === "pending_pin" && countdown > 0) {
      interval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            // Auto complete if in demo/test mode after timeout
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [paymentStatus, countdown]);

  const handleInitiatePayment = async () => {
    setPaymentStatus("submitting");
    setErrorMessage("");

    const generatedRef = `LIP-AGRO-${Date.now().toString().slice(-6)}`;
    setRefId(generatedRef);

    try {
      // Simulate real Lipila API handshake
      await new Promise((resolve) => setTimeout(resolve, 1200));
      setCountdown(120);
      setPaymentStatus("pending_pin");
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to contact Lipila Payment Gateway");
      setPaymentStatus("failed");
    }
  };

  const [smsDeliveryStatus, setSmsDeliveryStatus] = useState<any>(null);
  const [isSendingSms, setIsSendingSms] = useState<boolean>(false);

  const handleSimulatePinApproval = async () => {
    setPaymentStatus("successful");
    setIsSendingSms(true);
    
    // Construct confirmed booking object
    const completedBooking: any = {
      id: refId || `adv-booked-${Date.now()}`,
      referenceId: refId || `LIP-AGRO-${Date.now().toString().slice(-6)}`,
      farmId: `farm-${Date.now().toString().slice(-4)}`,
      farmName: bookingData.farmName,
      farmerName: bookingData.siteContactPerson,
      farmerPhone: `+260${phoneNumber.replace(/^0+/, "")}`,
      agronomistName: bookingData.agronomist.name,
      agronomistId: bookingData.agronomist.id,
      specialistType: bookingData.agronomist.specialistType,
      date: bookingData.date,
      scheduledVisitDate: bookingData.date,
      timeSlot: bookingData.timeSlot,
      category: bookingData.agronomist.specialistType === "Veterinary Surgeon (Vet)" ? "General Agronomy" : "Pest & Disease Outbreak",
      cropType: bookingData.cropOrLivestock,
      fieldBlock: bookingData.fieldBlock,
      symptomsDescription: bookingData.symptomsDescription,
      severity: bookingData.urgencyLevel === "Urgent Outbreak" ? "High" : "Medium",
      status: "Prescribed",
      visitFee: bookingData.baseFee,
      platformFeeShare: bookingData.platformFee,
      smsFee: bookingData.smsFee || 1.0,
      agronomistEarningsShare: bookingData.baseFee,
      totalAmount: bookingData.totalFee,
      paymentMethod: `Lipila ${carrier} Mobile Money`,
      paymentStatus: "Paid",
      paymentPhone: `+260${phoneNumber.replace(/^0+/, "")}`,
      smsReminderSent: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      siteDirections: bookingData.siteDirections,
      district: bookingData.district,
      province: bookingData.province,
      gpsCoordinates: bookingData.gpsCoordinates,
      // Sample diagnostic prescription data for immediate report availability
      diagnosisNotes: `On-site diagnostic audit booked for ${bookingData.farmName} (${bookingData.fieldBlock}). Priority: ${bookingData.urgencyLevel}.`,
      prescription: {
        productName: "Agronomic Health & Treatment Protocol",
        activeIngredient: "Certified ZEMA Registered Agronomic Formulations",
        dosage: "Standard calibrated rate per hectare / animal unit",
        applicationMethod: "Foliar spray / Targeted application upon field inspection",
        withdrawalPeriodDays: 14,
        safetyInstructions: "Follow full PPE guidelines, use clean calibrated sprayers, and adhere to recommended reentry intervals."
      },
      soilTest: {
        ph: 6.2,
        nitrogenPpm: 40,
        phosphorusPpm: 24,
        potassiumPpm: 150,
        organicMatterPercent: 2.8,
        recommendation: "Balanced nutrient regimen confirmed. Soil chemistry analysis ready for download."
      }
    };

    // 1. Dispatch Beem Africa Confirmation SMS to Farmer & Agronomist (charging farmer for SMS)
    try {
      const smsPayload = {
        uid: userProfile?.uid || userProfile?.id || "farmer-portal-user",
        farmerPhone: `+260${phoneNumber.replace(/^0+/, "")}`,
        farmerName: bookingData.siteContactPerson,
        agronomistPhone: bookingData.agronomist.phone || "+260977442211",
        agronomistName: bookingData.agronomist.name,
        farmName: bookingData.farmName,
        fieldBlock: bookingData.fieldBlock,
        district: bookingData.district,
        serviceLabel: bookingData.serviceLabel,
        date: bookingData.date,
        timeSlot: bookingData.timeSlot,
        referenceId: refId || completedBooking.referenceId,
        totalFee: bookingData.totalFee
      };

      const smsResp = await fetch("/api/agronomy/send-booking-confirmation-sms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(smsPayload)
      });
      if (smsResp.ok) {
        const smsResult = await smsResp.json();
        setSmsDeliveryStatus(smsResult);
      }
    } catch (smsErr) {
      console.warn("[Beem SMS Dispatch Warning]:", smsErr);
    } finally {
      setIsSendingSms(false);
    }

    // 2. Mark slot as Booked in Firestore availability
    try {
      await fetch("/api/agronomy/availability/book", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          slotId: bookingData.slotId,
          agronomistId: bookingData.agronomist.id,
          date: bookingData.date,
          timeSlot: bookingData.timeSlot,
          farmerName: bookingData.siteContactPerson,
          farmName: bookingData.farmName,
          consultationId: completedBooking.id
        })
      });
    } catch (bookErr) {
      console.warn("[Availability Slot Book Warning]:", bookErr);
    }

    onPaymentComplete(completedBooking);
  };

  const handleDownloadReceipt = () => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();

      // Top banner
      doc.setFillColor(15, 76, 58);
      doc.rect(0, 0, pageWidth, 38, "F");

      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(16);
      doc.text("LIPILA DIGITAL PAYMENT RECEIPT", 14, 18);

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text("Official Agronomist Service Payment & Appointment Confirmation", 14, 26);
      doc.text(`Reference: ${refId} | Date: ${new Date().toLocaleDateString()}`, 14, 33);

      // Body details
      doc.setTextColor(30, 41, 59);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("1. TRANSACTION & APPOINTMENT DETAILS", 14, 50);

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text(`Service Type: ${bookingData.serviceLabel}`, 14, 58);
      doc.text(`Specialist Agronomist: ${bookingData.agronomist.name}`, 14, 65);
      doc.text(`Target Farm: ${bookingData.farmName} (${bookingData.fieldBlock})`, 14, 72);
      doc.text(`Appointment Date & Time: ${bookingData.date} • ${bookingData.timeSlot}`, 14, 79);
      doc.text(`Site Location: ${bookingData.district}, ${bookingData.province}`, 14, 86);
      doc.text(`Payer / Contact: ${accountHolderName} (+260 ${phoneNumber})`, 14, 93);
      doc.text(`Payment Gateway: Lipila ${carrier} Mobile Money`, 14, 100);

      // Financials
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("2. SETTLEMENT SUMMARY", 14, 115);

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text(`Agronomist Consultation Fee: ${currencySymbol} ${bookingData.baseFee.toLocaleString()}`, 14, 123);
      doc.text(`Mabala Platform & Regulatory Fee: ${currencySymbol} ${bookingData.platformFee.toLocaleString()}`, 14, 130);
      doc.text(`Beem Africa SMS Gateway Charge (Dual Notice): ${currencySymbol} ${(bookingData.smsFee || 1.0).toFixed(2)}`, 14, 137);
      
      doc.setFont("helvetica", "bold");
      doc.text(`Total Cleared Amount: ${currencySymbol} ${bookingData.totalFee.toLocaleString()}`, 14, 147);
      doc.text(`Status: CLEARED & CONFIRMED (PAID)`, 14, 154);

      // Footer note
      doc.setFontSize(9);
      doc.setFont("helvetica", "italic");
      doc.text("Appointment notifications dispatched via Beem Africa SMS Gateway. Proof of booking for Mabala Agronomy Network.", 14, 168);

      doc.save(`Lipila_Receipt_${refId}.pdf`);
    } catch (e) {
      console.error("PDF Receipt generation failed:", e);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden my-auto max-h-[92vh] flex flex-col font-sans">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4.5 flex items-center justify-between shrink-0 border-b border-indigo-900/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-400 flex items-center justify-center font-bold text-lg shrink-0">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.2 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[9px] font-black rounded uppercase">
                  Lipila Mobile Money Gateway
                </span>
              </div>
              <h3 className="text-sm font-black text-white mt-0.5">
                Pay for Agronomist Service
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Status Views */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
          
          {/* View 1: Initial Form & Order Summary */}
          {paymentStatus === "idle" && (
            <div className="space-y-4">
              {/* Order Card */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-black uppercase text-indigo-600 tracking-wider">
                      Service Booking
                    </span>
                    <h4 className="font-extrabold text-slate-900 text-sm">
                      {bookingData.serviceLabel}
                    </h4>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      Specialist: <strong className="text-slate-800">{bookingData.agronomist.name}</strong>
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Total Due</span>
                    <strong className="text-emerald-700 font-mono text-base font-black">
                      {currencySymbol} {bookingData.totalFee.toLocaleString()}
                    </strong>
                  </div>
                </div>

                <div className="border-t border-slate-200 pt-2 grid grid-cols-2 gap-2 text-[10.5px] text-slate-600">
                  <div>
                    <span className="text-slate-400 block">Date & Time:</span>
                    <span className="font-bold text-slate-800">{bookingData.date} ({bookingData.timeSlot})</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Farm Site:</span>
                    <span className="font-bold text-slate-800">{bookingData.farmName} — {bookingData.district}</span>
                  </div>
                </div>
              </div>

              {/* Mobile Carrier Selection */}
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1.5">
                  Select Mobile Money Operator
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setCarrier("MTN")}
                    className={`py-2.5 px-3 rounded-xl border text-center transition cursor-pointer flex flex-col items-center justify-center ${
                      carrier === "MTN"
                        ? "bg-amber-500/10 border-amber-500 ring-2 ring-amber-500/20 text-amber-900 font-black"
                        : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    <span className="text-base">🟡</span>
                    <span className="text-xs mt-0.5">MTN MoMo</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCarrier("Airtel")}
                    className={`py-2.5 px-3 rounded-xl border text-center transition cursor-pointer flex flex-col items-center justify-center ${
                      carrier === "Airtel"
                        ? "bg-rose-500/10 border-rose-500 ring-2 ring-rose-500/20 text-rose-900 font-black"
                        : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    <span className="text-base">🔴</span>
                    <span className="text-xs mt-0.5">Airtel Money</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCarrier("Zamtel")}
                    className={`py-2.5 px-3 rounded-xl border text-center transition cursor-pointer flex flex-col items-center justify-center ${
                      carrier === "Zamtel"
                        ? "bg-emerald-500/10 border-emerald-500 ring-2 ring-emerald-500/20 text-emerald-900 font-black"
                        : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    <span className="text-base">🟢</span>
                    <span className="text-xs mt-0.5">Zamtel Kwacha</span>
                  </button>
                </div>
              </div>

              {/* Phone Number Input */}
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1">
                  Mobile Money Wallet Number
                </label>
                <div className="flex gap-2">
                  <div className="flex items-center justify-center px-3 py-2.5 bg-slate-100 border border-slate-300 rounded-xl text-xs font-bold font-mono text-slate-700">
                    +260
                  </div>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="97X XXX XXX"
                    required
                    className="flex-1 px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold font-mono text-slate-900 focus:border-indigo-600 focus:outline-none"
                  />
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  A USSD prompt will be sent immediately to this device.
                </span>
              </div>

              {/* Verified Account Holder */}
              <div className="bg-slate-900 text-white p-3 rounded-xl flex items-center justify-between border border-slate-800">
                <div>
                  <span className="text-[9px] uppercase font-black tracking-wider text-slate-400 block">
                    Verified Wallet Account Holder
                  </span>
                  <div className="font-extrabold text-white text-xs mt-0.5">
                    {isSearchingHolder ? (
                      <span className="text-slate-400 animate-pulse">Looking up account...</span>
                    ) : (
                      accountHolderName
                    )}
                  </div>
                </div>
                <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0">
                  ✓
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleInitiatePayment}
                  disabled={!phoneNumber || isSearchingHolder}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-550 text-white font-black text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Authorize & Pay {currencySymbol} {bookingData.totalFee.toLocaleString()}</span>
                </button>
              </div>
            </div>
          )}

          {/* View 2: Submitting / Connecting to Gateway */}
          {paymentStatus === "submitting" && (
            <div className="py-10 text-center space-y-4">
              <RefreshCw className="w-10 h-10 text-indigo-600 animate-spin mx-auto" />
              <div>
                <h4 className="text-sm font-black text-slate-800">
                  Connecting to Lipila Gateway...
                </h4>
                <p className="text-slate-500 text-xs mt-1">
                  Dispatching USSD push notification to +260 {phoneNumber}
                </p>
              </div>
            </div>
          )}

          {/* View 3: Awaiting USSD PIN Authorization */}
          {paymentStatus === "pending_pin" && (
            <div className="py-4 space-y-4 text-center">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-600 flex items-center justify-center mx-auto text-2xl animate-pulse">
                📱
              </div>

              <div className="space-y-1">
                <h4 className="text-sm font-extrabold text-slate-900">
                  Enter Your Mobile Money PIN
                </h4>
                <p className="text-slate-600 text-xs max-w-xs mx-auto">
                  A USSD prompt has been sent to <strong className="font-mono text-slate-900">+260 {phoneNumber}</strong> ({accountHolderName}). Please enter your 4 or 5-digit PIN on your phone to complete authorization.
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl max-w-xs mx-auto font-mono text-xs flex items-center justify-between">
                <span className="text-slate-500">Time remaining:</span>
                <span className="font-black text-rose-600 animate-pulse">{countdown}s</span>
              </div>

              {/* Ref Number & Carrier */}
              <div className="p-3 bg-slate-900 rounded-xl text-white text-[10.5px] font-mono max-w-xs mx-auto text-left space-y-1">
                <div>Ref: <strong className="text-indigo-300">{refId}</strong></div>
                <div>Amount: <strong className="text-emerald-400">{currencySymbol} {bookingData.totalFee.toLocaleString()}</strong></div>
                <div>Carrier: <strong>{carrier} Mobile Money</strong></div>
              </div>

              {/* Simulation Helper Buttons for Demo */}
              <div className="pt-2 space-y-2">
                <button
                  type="button"
                  onClick={handleSimulatePinApproval}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-550 text-white font-black text-xs rounded-xl shadow-sm transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Simulate PIN Confirmed (Instant Clear)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentStatus("idle")}
                  className="text-slate-400 hover:text-slate-600 text-[11px] font-bold block mx-auto transition"
                >
                  Cancel or Change Phone Number
                </button>
              </div>
            </div>
          )}

          {/* View 4: Payment Successful */}
          {paymentStatus === "successful" && (
            <div className="py-4 space-y-4 text-center">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-600 flex items-center justify-center mx-auto text-2xl font-black animate-bounce">
                ✓
              </div>

              <div className="space-y-1">
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[9.5px] font-black rounded uppercase font-mono">
                  Payment Cleared • Verified
                </span>
                <h4 className="text-base font-black text-slate-900 mt-1">
                  Appointment Confirmed & Paid!
                </h4>
                <p className="text-slate-600 text-xs max-w-sm mx-auto">
                  Your appointment with <strong className="text-slate-900">{bookingData.agronomist.name}</strong> on <strong className="text-slate-900">{bookingData.date}</strong> at <strong className="text-slate-900">{bookingData.timeSlot}</strong> has been secured and dispatched.
                </p>
              </div>

              {/* Receipt card */}
              <div className="bg-slate-900 text-white p-4 rounded-xl text-left space-y-2 text-[11px] font-mono">
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400 uppercase text-[9.5px] font-black">Transaction Receipt</span>
                  <span className="text-emerald-400 font-bold">{refId}</span>
                </div>
                <div className="space-y-1 text-slate-300">
                  <div className="flex justify-between">
                    <span>Service:</span>
                    <span className="font-sans font-bold text-white">{bookingData.serviceLabel}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Farm Location:</span>
                    <span className="font-sans text-white">{bookingData.farmName} ({bookingData.fieldBlock})</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Amount Cleared:</span>
                    <span className="font-bold text-emerald-400">{currencySymbol} {bookingData.totalFee.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Channel:</span>
                    <span className="text-white">Lipila {carrier} MoMo</span>
                  </div>
                </div>

                {/* SMS Delivery Notification */}
                <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-start gap-2">
                  <div className="w-5 h-5 rounded-md bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                    📱
                  </div>
                  <div className="text-[10px] font-sans leading-tight">
                    <span className="text-emerald-300 font-bold block">
                      Beem Africa SMS Dispatched
                    </span>
                    <span className="text-slate-400 block mt-0.5">
                      Confirmation sent to you (+260 {phoneNumber}) and {bookingData.agronomist.name}. Charge: {currencySymbol} {(bookingData.smsFee || 1.0).toFixed(2)} (2 SMS credits billed).
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
                <button
                  type="button"
                  onClick={handleDownloadReceipt}
                  className="w-full sm:flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download PDF Receipt</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="w-full sm:flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-550 text-white text-xs font-black rounded-xl shadow-sm transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>Done & View Reports</span>
                  <span>→</span>
                </button>
              </div>
            </div>
          )}

          {/* View 5: Failed State */}
          {paymentStatus === "failed" && (
            <div className="py-6 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-xl font-black">
                ✕
              </div>
              <div>
                <h4 className="text-sm font-black text-rose-600">Payment Authorization Failed</h4>
                <p className="text-slate-500 text-xs mt-1 max-w-xs mx-auto">
                  {errorMessage || "Unable to clear transaction on Mobile Money. Please check balance and PIN."}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPaymentStatus("idle")}
                className="px-5 py-2.5 bg-slate-900 text-white text-xs font-bold rounded-xl hover:bg-slate-800 transition cursor-pointer"
              >
                Retry Payment
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
export default AgronomistPayServiceModal;

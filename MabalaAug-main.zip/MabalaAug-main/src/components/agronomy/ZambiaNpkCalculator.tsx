import React, { useState } from "react";
import { Sprout, TestTube, Scale, DollarSign, AlertCircle, CheckCircle2, Download, RefreshCw, Info, ChevronRight, Sparkles, BookOpen } from "lucide-react";
import { CropCycle } from "../../types";

interface ZambiaNpkCalculatorProps {
  currencySymbol?: string;
  crops?: CropCycle[];
  onApplyRecommendationToCrop?: (cropId: string, recommendationNotes: string) => void;
}

export interface SoilTestData {
  cropType: string;
  targetYieldTonsPerHa: number;
  fieldAreaValue: number;
  fieldAreaUnit: "hectares" | "acres";
  phWater: number;
  organicMatterRating: "low" | "medium" | "high";
  phosphorusPpm: number; // Bray-1 P in ppm
  potassiumPpm: number;  // Exchangeable K in ppm
  soilTexture: "sandy" | "sandy_loam" | "clay_loam" | "heavy_clay";
  agroRegion: "region_1" | "region_2" | "region_3"; // Region I (low rain), Region II (medium), Region III (high rain/acid)
}

export function ZambiaNpkCalculator({
  currencySymbol = "ZMW",
  crops = [],
  onApplyRecommendationToCrop
}: ZambiaNpkCalculatorProps) {
  // Soil test state
  const [soilData, setSoilData] = useState<SoilTestData>({
    cropType: "Maize (Hybrid Commercial)",
    targetYieldTonsPerHa: 7.5,
    fieldAreaValue: 10,
    fieldAreaUnit: "hectares",
    phWater: 5.2,
    organicMatterRating: "medium",
    phosphorusPpm: 12, // Medium
    potassiumPpm: 140, // Medium
    soilTexture: "sandy_loam",
    agroRegion: "region_2"
  });

  const [selectedCropCycleId, setSelectedCropCycleId] = useState<string>("");
  const [savedPrescription, setSavedPrescription] = useState<boolean>(false);

  // Conversion factor to hectares
  const fieldInHectares = soilData.fieldAreaUnit === "acres" ? soilData.fieldAreaValue * 0.404686 : soilData.fieldAreaValue;

  // Calculation Engine based on Zambia ZARI / Mount Makulu Research Standards
  const calculateRecommendation = () => {
    const isMaize = soilData.cropType.toLowerCase().includes("maize");
    const isSoybean = soilData.cropType.toLowerCase().includes("soybean");
    const isWheat = soilData.cropType.toLowerCase().includes("wheat");
    const isTomato = soilData.cropType.toLowerCase().includes("tomato");
    const isPotato = soilData.cropType.toLowerCase().includes("potato");

    // Base NPK requirements per Tonne of yield goal (kg/ha)
    let baseN_perTon = isMaize ? 22 : isSoybean ? 8 : isWheat ? 26 : isTomato ? 18 : 20;
    let baseP_perTon = isMaize ? 10 : isSoybean ? 14 : isWheat ? 12 : isTomato ? 12 : 12;
    let baseK_perTon = isMaize ? 8 : isSoybean ? 12 : isWheat ? 10 : isTomato ? 22 : 18;

    let targetN = baseN_perTon * soilData.targetYieldTonsPerHa;
    let targetP = baseP_perTon * soilData.targetYieldTonsPerHa;
    let targetK = baseK_perTon * soilData.targetYieldTonsPerHa;

    // Adjust P based on Bray-1 Soil Test P (ppm)
    // < 10 ppm = Low (+25% P needed)
    // 10 - 20 ppm = Medium (Standard)
    // > 20 ppm = High (-35% P needed)
    if (soilData.phosphorusPpm < 10) targetP *= 1.25;
    else if (soilData.phosphorusPpm > 20) targetP *= 0.65;

    // Adjust K based on Soil Test K (ppm)
    // < 100 ppm = Low (+25% K needed)
    // 100 - 200 ppm = Medium (Standard)
    // > 200 ppm = High (-40% K needed)
    if (soilData.potassiumPpm < 100) targetK *= 1.25;
    else if (soilData.potassiumPpm > 200) targetK *= 0.60;

    // Adjust N based on Organic Matter
    if (soilData.organicMatterRating === "low") targetN += 15;
    else if (soilData.organicMatterRating === "high") targetN -= 20;

    // Soybeans fix nitrogen via inoculant
    if (isSoybean) {
      targetN = 20; // Starter N only
    }

    // Liming requirement if pH < 5.5
    let limeTonnesPerHa = 0;
    if (soilData.phWater < 5.5) {
      const bufferFactor = soilData.soilTexture === "heavy_clay" ? 3.2 : soilData.soilTexture === "clay_loam" ? 2.5 : 1.8;
      limeTonnesPerHa = Math.max(0, (5.8 - soilData.phWater) * bufferFactor);
    }

    // Basal Fertilizer selection in Zambia
    let basalType = "Compound D (10:20:10 + 6S + 0.1B)";
    let basalN = 0.10;
    let basalP = 0.20;
    let basalK = 0.10;

    if (isSoybean) {
      basalType = "Soy Blend (6:28:23 + 5S + 0.1B)";
      basalN = 0.06;
      basalP = 0.28;
      basalK = 0.23;
    } else if (isTomato || isPotato) {
      basalType = "Veg Mixture / Compound C (6:18:12 + 6S)";
      basalN = 0.06;
      basalP = 0.18;
      basalK = 0.12;
    }

    // Calculate Basal Bags (50kg) per Ha to meet P requirement
    const kgPPerBag = 50 * basalP;
    const basalBagsPerHa = Math.max(2, Math.ceil((targetP / kgPPerBag) * 2) / 2); // rounded to nearest 0.5 bag
    const basalTotalBags = Math.ceil(basalBagsPerHa * fieldInHectares);

    // Calculate N supplied by Basal
    const nSuppliedByBasal = basalBagsPerHa * 50 * basalN;
    const remainingNNeeded = Math.max(0, targetN - nSuppliedByBasal);

    // Top Dressing Selection
    let topDressingType = "Urea (46% N)";
    let topNPercent = 0.46;
    if (soilData.soilTexture === "sandy" && soilData.agroRegion === "region_3") {
      // High leaching risk in region 3 sandy soil - CAN or Ammonium Sulphate is safer
      topDressingType = "CAN - Calcium Ammonium Nitrate (27% N)";
      topNPercent = 0.27;
    }

    const kgNPerTopBag = 50 * topNPercent;
    const topBagsPerHa = isSoybean ? 0 : Math.max(1, Math.ceil((remainingNNeeded / kgNPerTopBag) * 2) / 2);
    const topTotalBags = Math.ceil(topBagsPerHa * fieldInHectares);

    // Price estimates in ZMW (Zambian Market Avg)
    const basalBagPrice = isSoybean ? 880 : 850;
    const topBagPrice = topDressingType.includes("CAN") ? 720 : 820;
    const limeTonPrice = 350; // Agricultural Lime ZMW per Tonne

    const totalBasalCost = basalTotalBags * basalBagPrice;
    const totalTopCost = topTotalBags * topBagPrice;
    const totalLimeCost = Math.ceil(limeTonnesPerHa * fieldInHectares) * limeTonPrice;
    const totalInputInvestment = totalBasalCost + totalTopCost + totalLimeCost;

    return {
      targetN: Math.round(targetN),
      targetP: Math.round(targetP),
      targetK: Math.round(targetK),
      limeTonnesPerHa: Number(limeTonnesPerHa.toFixed(1)),
      totalLimeTonnes: Math.ceil(limeTonnesPerHa * fieldInHectares),
      basalType,
      basalBagsPerHa,
      basalTotalBags,
      topDressingType,
      topBagsPerHa,
      topTotalBags,
      totalBasalCost,
      totalTopCost,
      totalLimeCost,
      totalInputInvestment,
      isSoybean
    };
  };

  const rec = calculateRecommendation();

  const handlePresetCrop = (cropName: string) => {
    let yieldGoal = 7.5;
    if (cropName.includes("Soybean")) yieldGoal = 3.0;
    else if (cropName.includes("Wheat")) yieldGoal = 6.5;
    else if (cropName.includes("Tomato")) yieldGoal = 35.0;
    else if (cropName.includes("Potato")) yieldGoal = 25.0;

    setSoilData(prev => ({
      ...prev,
      cropType: cropName,
      targetYieldTonsPerHa: yieldGoal
    }));
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200 font-sans" id="zambia-npk-calculator-wrapper">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 p-6 rounded-2xl text-white shadow-md relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 opacity-10 flex items-center pr-10 pointer-events-none">
          <TestTube className="w-64 h-64 text-emerald-300" />
        </div>
        <div className="relative z-10 max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/20 border border-emerald-400/30 rounded-full text-[11px] font-extrabold text-emerald-300 uppercase tracking-widest">
            <Sprout className="w-3.5 h-3.5" />
            Zambia Soil Research & Agronomy Standard (ZARI Aligned)
          </div>
          <h2 className="text-2xl font-black tracking-tight text-white">
            NPK Soil Test & Fertilizer Application Recommendation Engine
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed font-medium">
            Calculate precise basal and top-dressing 50kg bag requirements, soil acidity liming rates, and input budgets based on actual soil pH, Bray-1 phosphorus, potassium, and target crop yields across Zambia's agro-ecological zones.
          </p>
        </div>
      </div>

      {/* Main Grid: Inputs vs Recommendation Results */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Form: Soil Test & Target Inputs */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b pb-3">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <TestTube className="w-4 h-4 text-emerald-600" />
              Soil Test & Field Parameters
            </h3>
            <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
              Step 1 of 2
            </span>
          </div>

          {/* Quick Crop Selection Chips */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-extrabold text-slate-500 uppercase block">Target Crop Selection</label>
            <div className="flex flex-wrap gap-1.5">
              {[
                "Maize (Hybrid Commercial)",
                "Soybeans (Inoculated)",
                "Irrigated Winter Wheat",
                "Tomatoes (Fresh Market)",
                "Irish Potatoes"
              ].map(c => (
                <button
                  key={c}
                  type="button"
                  onClick={() => handlePresetCrop(c)}
                  className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                    soilData.cropType === c
                      ? "bg-emerald-600 text-white border-emerald-600 shadow-2xs"
                      : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
                  }`}
                >
                  {c.split(" ")[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Target Yield & Field Size */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Target Yield (MT/Ha)</label>
              <input
                type="number"
                step="0.5"
                min="1"
                max="80"
                value={soilData.targetYieldTonsPerHa}
                onChange={e => setSoilData({ ...soilData, targetYieldTonsPerHa: parseFloat(e.target.value) || 1 })}
                className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2.5 text-slate-800 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Field Area Size</label>
              <div className="flex gap-1">
                <input
                  type="number"
                  min="0.1"
                  step="0.5"
                  value={soilData.fieldAreaValue}
                  onChange={e => setSoilData({ ...soilData, fieldAreaValue: parseFloat(e.target.value) || 1 })}
                  className="w-2/3 text-xs font-bold border border-slate-300 rounded-lg p-2.5 text-slate-800 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none"
                />
                <select
                  value={soilData.fieldAreaUnit}
                  onChange={e => setSoilData({ ...soilData, fieldAreaUnit: e.target.value as any })}
                  className="w-1/3 text-[10px] font-extrabold border border-slate-300 rounded-lg p-1 text-slate-700 bg-slate-100"
                >
                  <option value="hectares">Ha</option>
                  <option value="acres">Acres</option>
                </select>
              </div>
            </div>
          </div>

          {/* Soil pH & Acidity status */}
          <div className="space-y-2 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <div className="flex justify-between items-center">
              <label className="text-[10px] font-extrabold text-slate-700 uppercase">Soil pH (H₂O Test)</label>
              <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                soilData.phWater < 5.5 ? "bg-rose-100 text-rose-800 border border-rose-300" : "bg-emerald-100 text-emerald-800"
              }`}>
                {soilData.phWater < 5.5 ? "🔴 Strongly Acidic (Liming Required)" : "🟢 Optimal Soil pH"}
              </span>
            </div>
            <input
              type="range"
              min="4.0"
              max="8.0"
              step="0.1"
              value={soilData.phWater}
              onChange={e => setSoilData({ ...soilData, phWater: parseFloat(e.target.value) })}
              className="w-full accent-emerald-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-bold text-slate-500">
              <span>4.0 (Severe Acid)</span>
              <span className="text-emerald-700 font-extrabold">pH {soilData.phWater.toFixed(1)}</span>
              <span>8.0 (Alkaline)</span>
            </div>
          </div>

          {/* Soil Nutrient Lab Values */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Bray-1 P (ppm)</label>
              <input
                type="number"
                min="1"
                max="100"
                value={soilData.phosphorusPpm}
                onChange={e => setSoilData({ ...soilData, phosphorusPpm: parseInt(e.target.value) || 0 })}
                className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2.5 text-slate-800 bg-slate-50 focus:bg-white outline-none"
              />
              <span className="text-[9px] text-slate-400 font-medium block mt-0.5">
                {soilData.phosphorusPpm < 10 ? "Low (<10 ppm)" : soilData.phosphorusPpm <= 20 ? "Medium (10-20 ppm)" : "High (>20 ppm)"}
              </span>
            </div>

            <div>
              <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Exchangeable K (ppm)</label>
              <input
                type="number"
                min="10"
                max="500"
                value={soilData.potassiumPpm}
                onChange={e => setSoilData({ ...soilData, potassiumPpm: parseInt(e.target.value) || 0 })}
                className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2.5 text-slate-800 bg-slate-50 focus:bg-white outline-none"
              />
              <span className="text-[9px] text-slate-400 font-medium block mt-0.5">
                {soilData.potassiumPpm < 100 ? "Low (<100 ppm)" : soilData.potassiumPpm <= 200 ? "Medium (100-200 ppm)" : "High (>200 ppm)"}
              </span>
            </div>
          </div>

          {/* Soil Texture & Region */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Soil Texture Class</label>
              <select
                value={soilData.soilTexture}
                onChange={e => setSoilData({ ...soilData, soilTexture: e.target.value as any })}
                className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 text-slate-800 bg-slate-50 outline-none"
              >
                <option value="sandy">Light Sandy Soil</option>
                <option value="sandy_loam">Sandy Clay Loam</option>
                <option value="clay_loam">Clay Loam</option>
                <option value="heavy_clay">Heavy Red Clay</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Agro-Ecological Zone</label>
              <select
                value={soilData.agroRegion}
                onChange={e => setSoilData({ ...soilData, agroRegion: e.target.value as any })}
                className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 text-slate-800 bg-slate-50 outline-none"
              >
                <option value="region_1">Region I (Valleys / Dry)</option>
                <option value="region_2">Region II (Central Plateau)</option>
                <option value="region_3">Region III (High Rainfall / Acid)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Right Panel: Recommendation Outputs */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Recommendation Overview Card */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-3">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  ZARI Agronomy Prescribed
                </span>
                <h3 className="text-lg font-black text-slate-900 mt-1">
                  Fertilizer & Liming Recommendation
                </h3>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-bold text-slate-400 block">Total Field Size</span>
                <span className="text-sm font-black text-slate-800 font-mono">
                  {soilData.fieldAreaValue} {soilData.fieldAreaUnit} ({fieldInHectares.toFixed(2)} Ha)
                </span>
              </div>
            </div>

            {/* Key Recommendation Bags Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              
              {/* Basal Bag Card */}
              <div className="bg-emerald-50/80 p-4 rounded-xl border border-emerald-200 space-y-1">
                <div className="text-[10px] font-black uppercase text-emerald-800 tracking-wider">
                  🌱 Basal Fertilizer
                </div>
                <div className="text-2xl font-black text-emerald-950 font-mono">
                  {rec.basalTotalBags} <span className="text-xs text-emerald-700 font-sans font-bold">Bags (50kg)</span>
                </div>
                <div className="text-[11px] font-extrabold text-emerald-900">
                  {rec.basalType}
                </div>
                <div className="text-[10px] text-emerald-700 font-medium">
                  Rate: <strong className="font-bold">{rec.basalBagsPerHa} bags/Ha</strong>
                </div>
              </div>

              {/* Top Dressing Bag Card */}
              <div className="bg-blue-50/80 p-4 rounded-xl border border-blue-200 space-y-1">
                <div className="text-[10px] font-black uppercase text-blue-800 tracking-wider">
                  ⚡ Top-Dressing
                </div>
                <div className="text-2xl font-black text-blue-950 font-mono">
                  {rec.topTotalBags} <span className="text-xs text-blue-700 font-sans font-bold">Bags (50kg)</span>
                </div>
                <div className="text-[11px] font-extrabold text-blue-900">
                  {rec.topDressingType}
                </div>
                <div className="text-[10px] text-blue-700 font-medium">
                  Rate: <strong className="font-bold">{rec.topBagsPerHa} bags/Ha</strong>
                </div>
              </div>

              {/* Lime Requirement Card */}
              <div className={`p-4 rounded-xl border space-y-1 ${
                rec.limeTonnesPerHa > 0 ? "bg-amber-50 border-amber-300" : "bg-slate-50 border-slate-200"
              }`}>
                <div className="text-[10px] font-black uppercase text-amber-800 tracking-wider">
                  🧱 Agricultural Lime
                </div>
                <div className="text-2xl font-black text-amber-950 font-mono">
                  {rec.totalLimeTonnes} <span className="text-xs text-amber-700 font-sans font-bold">Tonnes</span>
                </div>
                <div className="text-[11px] font-extrabold text-amber-900">
                  {rec.limeTonnesPerHa > 0 ? "Dolomitic / Calcitic Lime" : "Not Required (pH OK)"}
                </div>
                <div className="text-[10px] text-amber-700 font-medium">
                  Rate: <strong className="font-bold">{rec.limeTonnesPerHa} Tonnes/Ha</strong>
                </div>
              </div>

            </div>

            {/* Nutrient Target vs Supply Breakdown */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
              <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Scale className="w-3.5 h-3.5 text-slate-600" />
                Elemental Nutrient Rate per Hectare (kg/Ha)
              </h4>

              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                  <span className="text-[9px] font-extrabold text-slate-400 block uppercase">Nitrogen (N)</span>
                  <span className="text-sm font-black text-slate-900 font-mono">{rec.targetN} kg</span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                  <span className="text-[9px] font-extrabold text-slate-400 block uppercase">Phosphate (P₂O₅)</span>
                  <span className="text-sm font-black text-slate-900 font-mono">{rec.targetP} kg</span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                  <span className="text-[9px] font-extrabold text-slate-400 block uppercase">Potash (K₂O)</span>
                  <span className="text-sm font-black text-slate-900 font-mono">{rec.targetK} kg</span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                  <span className="text-[9px] font-extrabold text-slate-400 block uppercase">Sulphur (S)</span>
                  <span className="text-sm font-black text-slate-900 font-mono">15-25 kg</span>
                </div>
              </div>
            </div>

            {/* Application Timing Advisory */}
            <div className="bg-emerald-900 text-white p-4 rounded-xl space-y-2">
              <div className="text-[10px] font-black uppercase text-emerald-300 tracking-wider flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
                Agronomic Field Application Schedule
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs leading-relaxed text-emerald-100">
                <div className="space-y-1">
                  <strong className="text-white block font-bold">1. Basal Application (At Planting)</strong>
                  <p className="text-[11px]">
                    Place {rec.basalType} 3-5cm beside and 3cm below the seed row at planting. Do not place direct in seed hole.
                  </p>
                </div>
                <div className="space-y-1">
                  <strong className="text-white block font-bold">2. Top-Dressing Split Application</strong>
                  <p className="text-[11px]">
                    {rec.isSoybean 
                      ? "Inoculate Soybean seed with Bradyrhizobium inoculant (e.g. Soygro) at planting. No urea top-dressing needed."
                      : `Apply 50% Urea at 3-4 weeks post-emergence (V4 stage) and remaining 50% at 6-7 weeks (V8/tasseling stage).`}
                  </p>
                </div>
              </div>
            </div>

            {/* Estimated Local Market Investment Budget (ZMW) */}
            <div className="border-t pt-4 space-y-3">
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase">Input Budget Estimate</h4>
                  <span className="text-[10px] text-slate-500 font-medium">Zambian Agro-Dealer Retail Averages</span>
                </div>
                <div className="text-right">
                  <span className="text-xl font-black text-emerald-700 font-mono">
                    {currencySymbol} {rec.totalInputInvestment.toLocaleString()}
                  </span>
                  <span className="text-[9px] text-slate-400 block font-bold">Total Estimated Fertilizer & Lime Budget</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    const printContent = `
                      ===========================================================
                      ZAMBIA AGRONOMIC FERTILIZER & SOIL PRESCRIPTION REPORT
                      ===========================================================
                      Target Crop: ${soilData.cropType}
                      Target Yield: ${soilData.targetYieldTonsPerHa} MT/Ha
                      Field Area: ${soilData.fieldAreaValue} ${soilData.fieldAreaUnit} (${fieldInHectares.toFixed(2)} Ha)
                      Soil pH: ${soilData.phWater} | Bray-1 P: ${soilData.phosphorusPpm} ppm | K: ${soilData.potassiumPpm} ppm
                      -----------------------------------------------------------
                      RECOMMENDED INPUTS:
                      - Basal Fertilizer: ${rec.basalTotalBags} Bags (${rec.basalBagsPerHa} bags/Ha) of ${rec.basalType}
                      - Top-Dressing: ${rec.topTotalBags} Bags (${rec.topBagsPerHa} bags/Ha) of ${rec.topDressingType}
                      - Agricultural Lime: ${rec.totalLimeTonnes} Tonnes (${rec.limeTonnesPerHa} Tonnes/Ha)
                      -----------------------------------------------------------
                      ESTIMATED INVESTMENT: ${currencySymbol} ${rec.totalInputInvestment.toLocaleString()}
                      ===========================================================
                    `;
                    alert(printContent);
                  }}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer shadow-xs transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  Print Agronomy Prescription
                </button>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
export default ZambiaNpkCalculator;

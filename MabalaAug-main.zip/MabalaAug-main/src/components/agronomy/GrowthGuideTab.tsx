import React, { useState, useEffect } from "react";
import { CropCycle } from "../../types";
import { FIXED_CHEMICAL_DISCLAIMER } from "../../services/cropGuidanceService";
import { 
  Sprout, CheckSquare, Square, AlertTriangle, ShieldAlert, ShoppingBag, 
  ChevronRight, RefreshCw, Sparkles, MessageSquare, ExternalLink, Tag,
  Clock, CheckCircle, Info, Send
} from "lucide-react";

interface GrowthGuideTabProps {
  cropCycle: CropCycle;
  tenantId?: string;
  userRole?: string;
  onOpenAgronomistChat?: (initialMessage?: string) => void;
}

export const GrowthGuideTab: React.FC<GrowthGuideTabProps> = ({
  cropCycle,
  tenantId = "demo_tenant",
  userRole = "farmer",
  onOpenAgronomistChat
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [stageData, setStageData] = useState<any>(null);
  const [completedTasks, setCompletedTasks] = useState<string[]>([]);
  const [confirmedSignals, setConfirmedSignals] = useState<string[]>([]);
  const [recommendedProductsMap, setRecommendedProductsMap] = useState<Record<string, any[]>>({});
  const [loadingProducts, setLoadingProducts] = useState<Record<string, boolean>>({});
  const [selectedBriefProduct, setSelectedBriefProduct] = useState<any>(null);
  const [briefModalOpen, setBriefModalOpen] = useState<boolean>(false);
  const [productBrief, setProductBrief] = useState<any>(null);
  const [loadingBrief, setLoadingBrief] = useState<boolean>(false);
  const [feedbackNote, setFeedbackNote] = useState<string>("");
  const [feedbackSubmitted, setFeedbackSubmitted] = useState<boolean>(false);
  const [showFeedbackModal, setShowFeedbackModal] = useState<boolean>(false);

  // Cache key for offline persistence
  const cacheKey = `mabala_growth_guide_${cropCycle.id}`;

  const fetchResolvedStage = async (signals: string[] = confirmedSignals) => {
    setLoading(true);
    try {
      // Offline fallback check first
      const cached = localStorage.getItem(cacheKey);
      if (cached && !navigator.onLine) {
        const parsed = JSON.parse(cached);
        setStageData(parsed.stageData);
        setCompletedTasks(parsed.completedTasks || []);
        setLoading(false);
        return;
      }

      const res = await fetch("/api/agronomy/resolve-growth-stage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tenantId,
          cropCycleId: cropCycle.id,
          cropType: cropCycle.cropType,
          variety: cropCycle.variety,
          plantingDate: cropCycle.plantingDate,
          farmZone: cropCycle.fieldBlock || "Zone 2a - Central/Southern Plateau",
          confirmedSignals: signals
        })
      });

      const data = await res.json();
      if (data.success && data.resolution) {
        setStageData(data.resolution);
        const storedTasks = data.progress?.completedTasks || [];
        setCompletedTasks(storedTasks);

        // Save to local cache for offline resilience
        localStorage.setItem(cacheKey, JSON.stringify({
          stageData: data.resolution,
          completedTasks: storedTasks,
          updatedAt: new Date().toISOString()
        }));

        // Trigger loading product recommendations for input categories needed
        if (data.resolution.currentStage?.inputCategoriesNeeded) {
          fetchProductRecommendationsForCategories(
            data.resolution.currentStage.inputCategoriesNeeded,
            data.cropId,
            data.resolution.currentStage.stageId
          );
        }
      }
    } catch (err) {
      console.warn("[Growth Guide Resolution Fallback]", err);
      // Load offline cache if available
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        setStageData(parsed.stageData);
        setCompletedTasks(parsed.completedTasks || []);
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchProductRecommendationsForCategories = async (
    categories: any[],
    cropId: string,
    stageId: string
  ) => {
    for (const cat of categories) {
      const catId = cat.categoryId;
      setLoadingProducts(prev => ({ ...prev, [catId]: true }));
      try {
        const res = await fetch("/api/agronomy/get-recommended-products", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            tenantId,
            categoryId: catId,
            cropId,
            stageId,
            farmerRegion: cropCycle.fieldBlock || "Zone 2a - Central/Southern Plateau"
          })
        });
        const data = await res.json();
        if (data.success) {
          setRecommendedProductsMap(prev => ({ ...prev, [catId]: data.products }));
        }
      } catch (err) {
        console.warn(`[Product Recommendations Fallback for ${catId}]`, err);
      } finally {
        setLoadingProducts(prev => ({ ...prev, [catId]: false }));
      }
    }
  };

  useEffect(() => {
    fetchResolvedStage();
  }, [cropCycle.id, cropCycle.plantingDate]);

  const toggleTaskCompleted = (taskId: string) => {
    const nextCompleted = completedTasks.includes(taskId)
      ? completedTasks.filter(id => id !== taskId)
      : [...completedTasks, taskId];

    setCompletedTasks(nextCompleted);

    // Update offline cache immediately
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
      const parsed = JSON.parse(cached);
      parsed.completedTasks = nextCompleted;
      localStorage.setItem(cacheKey, JSON.stringify(parsed));
    }
  };

  const handleConfirmSignal = (signalText: string) => {
    const nextSignals = [...confirmedSignals, signalText];
    setConfirmedSignals(nextSignals);
    fetchResolvedStage(nextSignals);
  };

  const handleProductCardClick = async (product: any, category: any) => {
    if (product.placementId) {
      try {
        fetch("/api/agronomy/track-placement-click", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            placementId: product.placementId,
            farmerRegion: cropCycle.fieldBlock || "Zone 2a - Central/Southern Plateau",
            cropId: stageData?.cropId,
            stageId: stageData?.currentStage?.stageId
          })
        });
      } catch (_) {}
    }

    // Open Chemical Brief Modal if category requires agronomist disclaimer or is fungicide/insecticide/herbicide
    if (category.agronomistDisclaimerRequired || category.categoryId.includes("fungicide") || category.categoryId.includes("insecticide") || category.categoryId.includes("herbicide")) {
      setSelectedBriefProduct(product);
      setBriefModalOpen(true);
      fetchProductBrief(product.skuId, product.name);
    }
  };

  const fetchProductBrief = async (skuId: string, productName: string) => {
    setLoadingBrief(true);
    try {
      let res = await fetch(`/api/agronomy/product-brief/${skuId}`);
      let data = await res.json();

      if (!data.brief) {
        // Generate if not cached
        res = await fetch("/api/agronomy/generate-product-brief", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            skuId,
            productName,
            category: "Agrochemical"
          })
        });
        data = await res.json();
      }

      setProductBrief(data.brief || {
        skuId,
        targetPestsWeedsDiseases: ["Thrips", "Downy Mildew", "Purple Blotch"],
        recommendedCrops: [cropCycle.cropType],
        applicationGuidance: "Apply as a preventive or early-curative spray. Ensure full foliage coverage.",
        safetyWithholdingNote: "Observe 14-day pre-harvest interval (PHI). Wear protective mask and gloves.",
        disclaimer: FIXED_CHEMICAL_DISCLAIMER
      });
    } catch (err) {
      console.warn("[Brief Fetch Error]", err);
    } finally {
      setLoadingBrief(false);
    }
  };

  const handleSubmitFeedback = async () => {
    if (!feedbackNote.trim()) return;
    try {
      await fetch("/api/agronomy/content-feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cropId: stageData?.cropId || cropCycle.cropType,
          stageId: stageData?.currentStage?.stageId || "general",
          tenantId,
          note: feedbackNote
        })
      });
      setFeedbackSubmitted(true);
      setTimeout(() => {
        setShowFeedbackModal(false);
        setFeedbackSubmitted(false);
        setFeedbackNote("");
      }, 2000);
    } catch (err) {
      console.error("[Feedback Submit Error]", err);
    }
  };

  if (loading) {
    return (
      <div className="p-8 text-center text-emerald-800 dark:text-emerald-300 flex flex-col items-center justify-center min-h-[300px]">
        <RefreshCw className="w-8 h-8 animate-spin text-emerald-600 mb-3" />
        <p className="font-medium text-base">Resolving Growth Stage & Agronomy Directives...</p>
        <p className="text-xs text-stone-500 mt-1">Applying Agro-Ecological Zone calibration ({cropCycle.fieldBlock || "Zone 2a"})</p>
      </div>
    );
  }

  if (!stageData || !stageData.currentStage) {
    return (
      <div className="p-6 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-amber-900 dark:text-amber-200">
        <div className="flex items-center gap-3 mb-2">
          <AlertTriangle className="w-6 h-6 text-amber-600" />
          <h3 className="font-semibold text-lg">Growth Guide Pending Resolution</h3>
        </div>
        <p className="text-sm text-stone-600 dark:text-stone-300">
          The stage agronomy guide for <strong>{cropCycle.cropType}</strong> is currently in draft or initializing.
        </p>
        <button 
          onClick={() => fetchResolvedStage()} 
          className="mt-4 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-medium text-xs rounded-lg flex items-center gap-2"
        >
          <RefreshCw className="w-4 h-4" /> Retry Resolution
        </button>
      </div>
    );
  }

  const { currentStage, stageProgressDays, daysRemainingInStage, upcomingStage, allStages } = stageData;
  const stageIndex = allStages.findIndex((s: any) => s.stageId === currentStage.stageId);
  const progressPercent = currentStage.effectiveDurationDays 
    ? Math.min(100, Math.round((stageProgressDays / currentStage.effectiveDurationDays) * 100))
    : 50;

  return (
    <div className="space-y-6">
      {/* 1. Header Banner & Stage Navigation */}
      <div className="bg-gradient-to-br from-emerald-900 via-stone-900 to-emerald-950 text-white rounded-2xl p-6 shadow-xl border border-emerald-800/50">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-emerald-800/60">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase tracking-wider">
                Stage {stageIndex + 1} of {allStages.length}
              </span>
              <span className="text-xs text-stone-400">
                • {cropCycle.fieldBlock || "Zone 2a - Central/Southern Plateau"}
              </span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
              <Sprout className="w-7 h-7 text-emerald-400" />
              {currentStage.stageName}
            </h2>
            <p className="text-sm text-stone-300 mt-1 max-w-2xl leading-relaxed">
              {currentStage.description}
            </p>
          </div>

          <div className="bg-emerald-950/80 border border-emerald-800 rounded-xl p-4 min-w-[200px] text-right">
            <div className="text-xs font-medium text-stone-400 uppercase tracking-wider">Stage Progress</div>
            <div className="text-2xl font-black text-emerald-400 mt-0.5">
              Day {stageProgressDays}
              {daysRemainingInStage !== null && (
                <span className="text-xs font-normal text-stone-300 ml-1.5">
                  ({daysRemainingInStage} days remaining)
                </span>
              )}
            </div>
            <div className="w-full bg-stone-800 h-2 rounded-full mt-2 overflow-hidden">
              <div 
                className="bg-emerald-400 h-full rounded-full transition-all duration-500" 
                style={{ width: `${progressPercent}%` }} 
              />
            </div>
          </div>
        </div>

        {/* Stage Timeline Stepper */}
        <div className="pt-4 flex items-center gap-2 overflow-x-auto scrollbar-none">
          {allStages.map((s: any, idx: number) => {
            const isCurrent = s.stageId === currentStage.stageId;
            const isPassed = idx < stageIndex;
            return (
              <div 
                key={s.stageId} 
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  isCurrent 
                    ? "bg-emerald-500 text-stone-950 font-bold shadow-md" 
                    : isPassed 
                    ? "bg-emerald-900/60 text-emerald-300 border border-emerald-800/50" 
                    : "bg-stone-800/60 text-stone-400"
                }`}
              >
                {isPassed ? (
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <span className="w-3.5 h-3.5 rounded-full bg-stone-700/80 text-[10px] flex items-center justify-center text-white">
                    {idx + 1}
                  </span>
                )}
                <span>{s.stageName}</span>
              </div>
            );
          })}
        </div>

        {/* Phenological Signal Confirmation Trigger */}
        {currentStage.triggerType === "phenological_signal" && (
          <div className="mt-4 p-3.5 bg-amber-950/80 border border-amber-600/60 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-amber-200">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400 block">Phenological Signal Gating</span>
                <span className="text-sm font-medium">{currentStage.effectiveTriggerValue}</span>
              </div>
            </div>
            <button
              onClick={() => handleConfirmSignal(String(currentStage.effectiveTriggerValue))}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs rounded-lg shadow-md transition-all flex items-center gap-1.5 whitespace-nowrap"
            >
              <CheckCircle className="w-4 h-4" /> Confirm Signal Experienced
            </button>
          </div>
        )}
      </div>

      {/* 2. Main Content Grid: Tasks & Input Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Actionable Tasks (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white dark:bg-stone-900 rounded-xl p-5 border border-stone-200 dark:border-stone-800 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <CheckSquare className="w-5 h-5 text-emerald-600" />
                Required Stage Tasks ({completedTasks.length}/{currentStage.tasks?.length || 0})
              </h3>
              <button
                onClick={() => setShowFeedbackModal(true)}
                className="text-xs text-stone-500 hover:text-stone-800 dark:text-stone-400 dark:hover:text-stone-200 underline flex items-center gap-1"
              >
                <MessageSquare className="w-3.5 h-3.5" /> Report timing issue
              </button>
            </div>

            <div className="space-y-3">
              {currentStage.tasks?.map((task: any) => {
                const isChecked = completedTasks.includes(task.taskId);
                return (
                  <div
                    key={task.taskId}
                    onClick={() => toggleTaskCompleted(task.taskId)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                      isChecked 
                        ? "bg-emerald-50/70 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800/80" 
                        : "bg-stone-50 dark:bg-stone-800/50 border-stone-200 dark:border-stone-700/60 hover:border-emerald-400"
                    }`}
                  >
                    <button className="mt-0.5 text-emerald-600 dark:text-emerald-400 shrink-0">
                      {isChecked ? <CheckSquare className="w-5 h-5" /> : <Square className="w-5 h-5 text-stone-400" />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className={`text-sm font-semibold ${isChecked ? "line-through text-stone-500 dark:text-stone-400" : "text-stone-900 dark:text-stone-100"}`}>
                          {task.title}
                        </span>
                        <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-300 shrink-0">
                          {task.timingNote}
                        </span>
                      </div>
                      <p className="text-xs text-stone-600 dark:text-stone-300 mt-1 leading-relaxed">
                        {task.detail}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Decision Points & Agronomist Escalations */}
          {currentStage.decisionPoints && currentStage.decisionPoints.length > 0 && (
            <div className="bg-stone-900 text-stone-100 rounded-xl p-5 border border-stone-800 shadow-sm space-y-3">
              <h4 className="text-sm font-bold text-amber-400 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                Agronomy Decision & Troubleshooting Rules
              </h4>
              <div className="space-y-2.5">
                {currentStage.decisionPoints.map((dp: any, idx: number) => (
                  <div key={idx} className="p-3 bg-stone-800/80 border border-stone-700/70 rounded-lg text-xs space-y-1.5">
                    <div className="font-semibold text-stone-200 flex items-center justify-between">
                      <span>Condition: {dp.condition}</span>
                      {dp.escalateToAgronomist && (
                        <span className="px-1.5 py-0.5 bg-amber-500/20 text-amber-300 text-[10px] rounded font-bold border border-amber-500/30">
                          Escalate to Agronomist
                        </span>
                      )}
                    </div>
                    <p className="text-stone-300 leading-relaxed">{dp.guidance}</p>
                    {dp.escalateToAgronomist && onOpenAgronomistChat && (
                      <button
                        onClick={() => onOpenAgronomistChat(`I am experiencing this issue in ${cropCycle.cropType} (${currentStage.stageName}): ${dp.condition}`)}
                        className="mt-1 text-xs text-amber-400 hover:text-amber-300 font-medium underline flex items-center gap-1"
                      >
                        <MessageSquare className="w-3.5 h-3.5" /> Consult Hercules Agronomist AI
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Agrodealer Recommended Inputs + Boosted Placements (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-stone-50 dark:bg-stone-900/90 rounded-xl p-5 border border-stone-200 dark:border-stone-800 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-emerald-600" />
                Matched Agrodealer Inputs
              </h3>
              <span className="text-[11px] text-stone-500 dark:text-stone-400">
                Verified Zambian SKUs
              </span>
            </div>

            {currentStage.inputCategoriesNeeded?.length === 0 ? (
              <p className="text-xs text-stone-500 italic p-3">No specific commercial chemical inputs required for this stage.</p>
            ) : (
              <div className="space-y-4">
                {currentStage.inputCategoriesNeeded?.map((inputCat: any) => {
                  const catId = inputCat.categoryId;
                  const products = recommendedProductsMap[catId] || [];
                  const isLoadingCat = loadingProducts[catId];

                  return (
                    <div key={catId} className="bg-white dark:bg-stone-800/80 rounded-xl p-3.5 border border-stone-200 dark:border-stone-700/60 shadow-xs space-y-2.5">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-xs font-bold text-stone-900 dark:text-stone-100 block">
                            {inputCat.categoryLabel}
                          </span>
                          <span className="text-[11px] text-stone-500 dark:text-stone-400">
                            {inputCat.genericQuantityGuidance}
                          </span>
                        </div>
                        {inputCat.mandatory && (
                          <span className="px-2 py-0.5 bg-red-100 dark:bg-red-950/60 text-red-700 dark:text-red-300 text-[10px] font-bold rounded">
                            Mandatory
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-900/60 p-2 rounded border border-stone-100 dark:border-stone-800">
                        {inputCat.applicationGuidance}
                      </p>

                      {/* Product Recommendations */}
                      {isLoadingCat ? (
                        <div className="py-3 text-center text-xs text-stone-400 animate-pulse">
                          Matching local Agrodealer inventory...
                        </div>
                      ) : (
                        <div className="space-y-2 pt-1">
                          {products.map((prod: any) => (
                            <div
                              key={prod.skuId}
                              onClick={() => handleProductCardClick(prod, inputCat)}
                              className={`p-3 rounded-lg border transition-all cursor-pointer flex items-center justify-between gap-2 relative overflow-hidden ${
                                prod.isSponsored 
                                  ? "bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border-amber-300 dark:border-amber-700/80 shadow-xs" 
                                  : "bg-stone-50 dark:bg-stone-900/50 border-stone-200 dark:border-stone-700 hover:border-emerald-500"
                              }`}
                            >
                              {prod.isSponsored && (
                                <span className="absolute top-0 right-0 bg-amber-500 text-stone-950 font-black text-[9px] px-2 py-0.5 rounded-bl uppercase tracking-wider flex items-center gap-1 shadow-xs">
                                  <Sparkles className="w-2.5 h-2.5" /> Sponsored
                                </span>
                              )}

                              <div className="min-w-0 flex-1 pr-12">
                                <h5 className="text-xs font-bold text-stone-900 dark:text-stone-100 truncate">
                                  {prod.name}
                                </h5>
                                <p className="text-[11px] text-stone-500 dark:text-stone-400 truncate">
                                  Supplier: {prod.supplier}
                                </p>
                              </div>

                              <div className="text-right shrink-0">
                                <div className="text-xs font-black text-emerald-700 dark:text-emerald-400">
                                  {prod.currency} {prod.price}
                                </div>
                                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center justify-end gap-0.5">
                                  View SKU <ChevronRight className="w-3 h-3" />
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Upcoming Stage Preview */}
          {upcomingStage && (
            <div className="bg-stone-100 dark:bg-stone-900 rounded-xl p-4 border border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 space-y-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 block">
                What's Next (Upcoming Stage)
              </span>
              <h4 className="text-sm font-bold text-stone-900 dark:text-stone-100">
                Stage {stageIndex + 2}: {upcomingStage.stageName}
              </h4>
              <p className="text-xs leading-relaxed text-stone-600 dark:text-stone-400 line-clamp-2">
                {upcomingStage.description}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* 3. Chemical Product AI Brief Modal */}
      {briefModalOpen && selectedBriefProduct && (
        <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-stone-900 rounded-2xl max-w-lg w-full p-6 border border-stone-200 dark:border-stone-800 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
              <div>
                <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[10px] font-bold rounded uppercase">
                  Agrochemical Safety & Application Brief
                </span>
                <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100 mt-1">
                  {selectedBriefProduct.name}
                </h3>
              </div>
              <button 
                onClick={() => setBriefModalOpen(false)} 
                className="text-stone-400 hover:text-stone-600 text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            {loadingBrief ? (
              <div className="py-8 text-center text-xs text-stone-500 animate-pulse">
                Generating structured chemical advisory brief...
              </div>
            ) : productBrief ? (
              <div className="space-y-3 text-xs">
                <div>
                  <span className="font-bold text-stone-800 dark:text-stone-200 block mb-1">Target Pests, Weeds & Diseases:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {productBrief.targetPestsWeedsDiseases?.map((p: string, i: number) => (
                      <span key={i} className="px-2 py-0.5 bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 rounded font-medium">
                        {p}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="font-bold text-stone-800 dark:text-stone-200 block mb-1">Application Guidance:</span>
                  <p className="text-stone-600 dark:text-stone-300 leading-relaxed bg-stone-50 dark:bg-stone-800/50 p-2.5 rounded border border-stone-200 dark:border-stone-700">
                    {productBrief.applicationGuidance}
                  </p>
                </div>

                <div>
                  <span className="font-bold text-stone-800 dark:text-stone-200 block mb-1">Safety & Pre-Harvest Interval (PHI):</span>
                  <p className="text-stone-600 dark:text-stone-300 leading-relaxed bg-amber-50 dark:bg-amber-950/40 p-2.5 rounded border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200">
                    {productBrief.safetyWithholdingNote}
                  </p>
                </div>

                {/* MANDATORY FIXED DISCLAIMER TEXT */}
                <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/80 rounded-xl text-red-950 dark:text-red-200 text-[11px] leading-relaxed">
                  {FIXED_CHEMICAL_DISCLAIMER}
                </div>

                {/* MANDATORY ASK AN AGRONOMIST LINK/BUTTON */}
                <button
                  onClick={() => {
                    setBriefModalOpen(false);
                    if (onOpenAgronomistChat) {
                      onOpenAgronomistChat(`I need specific dosage and application advice for ${selectedBriefProduct.name} on my ${cropCycle.cropType} field (${currentStage.stageName}).`);
                    }
                  }}
                  className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-xs"
                >
                  <MessageSquare className="w-4 h-4" /> Ask an Agronomist about this product for your field
                </button>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* 4. Report Issue / Feedback Modal */}
      {showFeedbackModal && (
        <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-stone-900 rounded-2xl max-w-md w-full p-6 border border-stone-200 dark:border-stone-800 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-emerald-600" />
              Report Stage Timing or Guidance Feedback
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-300">
              Your feedback is sent directly to Deep Valley Farms agronomists to continuously improve regional crop models.
            </p>
            <textarea
              rows={4}
              value={feedbackNote}
              onChange={(e) => setFeedbackNote(e.target.value)}
              placeholder="e.g. In Southern Province, bulb initiation occurred 10 days earlier than recommended due to warmer weather..."
              className="w-full p-3 rounded-xl border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-xs text-stone-900 dark:text-stone-100 focus:ring-2 focus:ring-emerald-500"
            />
            {feedbackSubmitted && (
              <p className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                ✓ Thank you! Feedback recorded for agronomist review.
              </p>
            )}
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowFeedbackModal(false)}
                className="px-4 py-2 text-xs text-stone-600 dark:text-stone-400 font-medium hover:underline"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitFeedback}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-lg shadow-md flex items-center gap-1"
              >
                <Send className="w-3.5 h-3.5" /> Submit Feedback
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

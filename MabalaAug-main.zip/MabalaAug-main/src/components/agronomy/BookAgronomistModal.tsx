import React, { useState, useEffect } from "react";
import {
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  Sparkles,
  CheckCircle2,
  X,
  User,
  Phone,
  Layers,
  Sprout,
  Compass,
  AlertCircle,
  FileText,
  CreditCard,
  Building,
  Navigation,
  ChevronLeft,
  ChevronRight,
  MessageSquare,
  Send,
  Zap,
  Info
} from "lucide-react";
import { AgronomistProfile } from "./FarmerAgronomistPortal";
import { FarmNode } from "../../types";

export interface BookingFormData {
  agronomist: AgronomistProfile;
  serviceType: "farmVisit" | "soilOrHerdAudit" | "virtualConsult" | "emergencyOutbreak" | "irrigationAudit" | "vetDiagnostic";
  serviceLabel: string;
  date: string;
  timeSlot: string;
  slotId?: string;
  // Site location fields
  farmName: string;
  fieldBlock: string;
  province: string;
  district: string;
  siteDirections: string;
  gpsCoordinates?: string;
  siteContactPerson: string;
  siteContactPhone: string;
  // Agronomic details
  cropOrLivestock: string;
  urgencyLevel: "Routine" | "Moderate" | "Urgent Outbreak";
  symptomsDescription: string;
  // Pricing
  baseFee: number;
  platformFee: number;
  smsFee: number;
  totalFee: number;
}

interface BookAgronomistModalProps {
  agronomist: AgronomistProfile | null;
  isOpen: boolean;
  onClose: () => void;
  onProceedToPayment: (bookingData: BookingFormData) => void;
  activeFarm?: FarmNode | null;
  farms?: FarmNode[];
  userProfile?: any;
  currencySymbol?: string;
}

const SERVICE_OPTIONS: {
  id: BookingFormData["serviceType"];
  title: string;
  desc: string;
  icon: string;
  baseMultiplier: number;
  badge?: string;
}[] = [
  {
    id: "farmVisit",
    title: "On-Site Diagnostic & Treatment Visit",
    desc: "Comprehensive physical block inspection, pest/pathogen identification & written prescription.",
    icon: "🚜",
    baseMultiplier: 1.0,
    badge: "Most Popular"
  },
  {
    id: "soilOrHerdAudit",
    title: "Soil Fertility & Leaf Tissue Audit",
    desc: "Field core sampling, pH, N-P-K assessment and tailored dolomitic lime/fertilizer program.",
    icon: "🧪",
    baseMultiplier: 1.25
  },
  {
    id: "emergencyOutbreak",
    title: "Urgent Pest & Outbreak Emergency",
    desc: "Same-day/next-day rapid response for aggressive fall armyworm, bacterial wilt, or sudden mortality.",
    icon: "🚨",
    baseMultiplier: 1.35,
    badge: "Fast Track"
  },
  {
    id: "virtualConsult",
    title: "Virtual Video Advisory & Prescription",
    desc: "Remote high-definition video call with photo triage and electronic prescription sign-off.",
    icon: "📱",
    baseMultiplier: 0.5
  },
  {
    id: "irrigationAudit",
    title: "Drip Irrigation & Fertigation Audit",
    desc: "Pressure emitter uniformity, EC/pH inline check, and injector dosage calibration.",
    icon: "💧",
    baseMultiplier: 1.15
  },
  {
    id: "vetDiagnostic",
    title: "Veterinary Clinical & Herd Audit",
    desc: "Clinical examination, rectal palpation, vaccination review, and biosecurity clearance.",
    icon: "🩺",
    baseMultiplier: 1.2
  }
];

const DEFAULT_TIME_SLOTS = [
  "07:30 AM - 09:30 AM",
  "10:00 AM - 12:00 PM",
  "01:00 PM - 03:00 PM",
  "03:30 PM - 05:30 PM"
];

interface AvailabilitySlotItem {
  id: string;
  agronomistId: string;
  date: string;
  timeSlot: string;
  status: "Available" | "Booked" | "Blocked";
  visitFee: number;
}

export const BookAgronomistModal: React.FC<BookAgronomistModalProps> = ({
  agronomist,
  isOpen,
  onClose,
  onProceedToPayment,
  activeFarm,
  farms = [],
  userProfile,
  currencySymbol = "ZK"
}) => {
  if (!isOpen || !agronomist) return null;

  const isVet = agronomist.specialistType === "Veterinary Surgeon (Vet)";
  const [selectedService, setSelectedService] = useState<BookingFormData["serviceType"]>(
    isVet ? "vetDiagnostic" : "farmVisit"
  );

  // Calendar State
  const today = new Date();
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split("T")[0];
  const [currentCalendarMonth, setCurrentCalendarMonth] = useState<Date>(new Date());
  const [selectedDate, setSelectedDate] = useState<string>(tomorrow);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>(DEFAULT_TIME_SLOTS[0]);
  const [selectedSlotId, setSelectedSlotId] = useState<string>("");

  // Availability from API / Firestore
  const [availabilitySlots, setAvailabilitySlots] = useState<AvailabilitySlotItem[]>([]);
  const [isLoadingSlots, setIsLoadingSlots] = useState<boolean>(false);

  // Fetch real-time availability slots for agronomist
  useEffect(() => {
    if (!agronomist?.id) return;
    setIsLoadingSlots(true);
    fetch(`/api/agronomy/availability?agronomistId=${agronomist.id}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.slots) {
          setAvailabilitySlots(data.slots);
          // Set first available slot for tomorrow if exists
          const tomorrowSlots = data.slots.filter((s: AvailabilitySlotItem) => s.date === tomorrow && s.status === "Available");
          if (tomorrowSlots.length > 0) {
            setSelectedTimeSlot(tomorrowSlots[0].timeSlot);
            setSelectedSlotId(tomorrowSlots[0].id);
          }
        }
      })
      .catch((err) => {
        console.warn("[Availability Fetch Error]:", err);
      })
      .finally(() => {
        setIsLoadingSlots(false);
      });
  }, [agronomist?.id]);

  // Site Location Details
  const [farmName, setFarmName] = useState<string>(
    activeFarm?.name || farms[0]?.name || "Sunrise Agro-Tech Farm"
  );
  const [fieldBlock, setFieldBlock] = useState<string>("Block A - Pivot 1 (3.5 ha)");
  const [province, setProvince] = useState<string>(
    activeFarm?.province || agronomist.provinces[0] || "Lusaka Province"
  );
  const [district, setDistrict] = useState<string>(
    activeFarm?.district || agronomist.districts[0] || "Chongwe"
  );
  const [siteDirections, setSiteDirections] = useState<string>(
    "Plot 42, Off Great East Road, 3.5km East of Chongwe Bridge. Green gate on the right."
  );
  const [gpsCoordinates, setGpsCoordinates] = useState<string>(
    activeFarm?.latitude && activeFarm?.longitude
      ? `${activeFarm.latitude}, ${activeFarm.longitude}`
      : "-15.3289, 28.6811"
  );
  const [siteContactPerson, setSiteContactPerson] = useState<string>(
    userProfile?.name || userProfile?.fullName || "Farm Manager"
  );
  const [siteContactPhone, setSiteContactPhone] = useState<string>(
    userProfile?.phone || "+260 977 442211"
  );

  // Agronomic details
  const [cropOrLivestock, setCropOrLivestock] = useState<string>(
    isVet ? "Dairy Cattle (Friesian / Boran Cross)" : "Maize (Hybrid SC 719)"
  );
  const [urgencyLevel, setUrgencyLevel] = useState<BookingFormData["urgencyLevel"]>("Moderate");
  const [symptomsDescription, setSymptomsDescription] = useState<string>(
    isVet
      ? "Routine herd health evaluation and sub-clinical mastitis screening for 45 milking cows."
      : "Yellowing lower leaves and scattered leaf spot lesions observed across 2.5 hectares following heavy rain."
  );

  // Active step
  const [currentStep, setCurrentStep] = useState<"service_and_date" | "site_location" | "summary">("service_and_date");

  // Fee calculation (including Beem Africa SMS fee charge)
  const serviceDef = SERVICE_OPTIONS.find((s) => s.id === selectedService) || SERVICE_OPTIONS[0];
  const baseRate = agronomist.pricing?.farmVisit || 350;
  const baseFee = Math.round(baseRate * serviceDef.baseMultiplier);
  const platformFee = Math.round(baseFee * 0.1); // 10% platform fee
  const smsFee = 1.00; // 2 SMS messages @ 0.50 ZMW each (1 for farmer, 1 for agronomist)
  const totalFee = baseFee + platformFee + smsFee;

  // Calendar Helpers
  const year = currentCalendarMonth.getFullYear();
  const month = currentCalendarMonth.getMonth();
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayIndex = new Date(year, month, 1).getDay();

  const handlePrevMonth = () => {
    setCurrentCalendarMonth(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentCalendarMonth(new Date(year, month + 1, 1));
  };

  // Get slots for currently selected date
  const slotsForSelectedDate = availabilitySlots.filter((s) => s.date === selectedDate);
  const displaySlots = slotsForSelectedDate.length > 0
    ? slotsForSelectedDate
    : DEFAULT_TIME_SLOTS.map((t, idx) => ({
        id: `slot_gen_${selectedDate}_${idx}`,
        agronomistId: agronomist.id,
        date: selectedDate,
        timeSlot: t,
        status: "Available" as const,
        visitFee: baseFee
      }));

  const handleNextToLocation = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStep("site_location");
  };

  const handleNextToSummary = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStep("summary");
  };

  const handleFinalizeBooking = () => {
    const bookingData: BookingFormData = {
      agronomist,
      serviceType: selectedService,
      serviceLabel: serviceDef.title,
      date: selectedDate,
      timeSlot: selectedTimeSlot,
      slotId: selectedSlotId,
      farmName,
      fieldBlock,
      province,
      district,
      siteDirections,
      gpsCoordinates,
      siteContactPerson,
      siteContactPhone,
      cropOrLivestock,
      urgencyLevel,
      symptomsDescription,
      baseFee,
      platformFee,
      smsFee,
      totalFee
    };
    onProceedToPayment(bookingData);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col font-sans">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-emerald-950 text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-bold text-xl shrink-0">
              {isVet ? "🩺" : "🌾"}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-black rounded uppercase tracking-wider">
                  Book Specialist Visit
                </span>
                <span className="text-[10px] text-slate-300 font-medium">
                  {agronomist.specialistType}
                </span>
              </div>
              <h3 className="text-base font-black text-white mt-0.5">
                {agronomist.name}
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Bar */}
        <div className="bg-slate-100 border-b border-slate-200 px-5 py-2.5 flex items-center justify-between text-xs font-bold text-slate-600 shrink-0">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setCurrentStep("service_and_date")}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition ${
                currentStep === "service_and_date"
                  ? "bg-emerald-600 text-white font-black shadow-xs"
                  : "bg-white text-slate-700 hover:bg-slate-200"
              }`}
            >
              <span>1. Service & Calendar Slot</span>
            </button>
            <span className="text-slate-300">→</span>
            <button
              type="button"
              onClick={() => setCurrentStep("site_location")}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition ${
                currentStep === "site_location"
                  ? "bg-emerald-600 text-white font-black shadow-xs"
                  : "bg-white text-slate-700 hover:bg-slate-200"
              }`}
            >
              <span>2. Site Location</span>
            </button>
            <span className="text-slate-300">→</span>
            <button
              type="button"
              onClick={() => setCurrentStep("summary")}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition ${
                currentStep === "summary"
                  ? "bg-emerald-600 text-white font-black shadow-xs"
                  : "bg-white text-slate-700 hover:bg-slate-200"
              }`}
            >
              <span>3. Checkout</span>
            </button>
          </div>

          <div className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-black">
            Estimated: {currencySymbol} {totalFee.toLocaleString()}
          </div>
        </div>

        {/* Step 1: Service Type, Interactive Calendar & Availability Slots */}
        {currentStep === "service_and_date" && (
          <form onSubmit={handleNextToLocation} className="p-5 space-y-4 overflow-y-auto flex-1">
            {/* Service Options */}
            <div>
              <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-2">
                1. Select Advisory Service Type
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {SERVICE_OPTIONS.map((srv) => {
                  const srvFee = Math.round(baseRate * srv.baseMultiplier);
                  const isSelected = selectedService === srv.id;
                  return (
                    <div
                      key={srv.id}
                      onClick={() => setSelectedService(srv.id)}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition flex flex-col justify-between ${
                        isSelected
                          ? "bg-emerald-50/80 border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs"
                          : "bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="text-xl">{srv.icon}</span>
                          {srv.badge && (
                            <span className="text-[8.5px] font-black bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded uppercase">
                              {srv.badge}
                            </span>
                          )}
                        </div>
                        <h4 className="text-xs font-bold text-slate-900 mt-1.5 leading-snug">
                          {srv.title}
                        </h4>
                        <p className="text-[10.5px] text-slate-500 mt-1 leading-relaxed line-clamp-2">
                          {srv.desc}
                        </p>
                      </div>
                      <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                        <span className="text-slate-400 font-medium">Standard Rate</span>
                        <strong className="text-emerald-700 font-mono font-black">
                          {currencySymbol} {srvFee.toLocaleString()}
                        </strong>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Calendar & Time Slots View */}
            <div className="pt-2 border-t border-slate-100 space-y-3">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <CalendarIcon className="w-3.5 h-3.5 text-emerald-600" />
                  <span>2. Pick Available Specialist Slot from Calendar</span>
                </label>
                <span className="text-[10px] text-slate-400 font-medium">
                  {isLoadingSlots ? "Syncing slots..." : "Live Firestore Availability"}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                {/* Mini Calendar Month View */}
                <div className="bg-white p-3 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="text-xs font-black text-slate-800">
                      {monthNames[month]} {year}
                    </h5>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={handlePrevMonth}
                        className="p-1 rounded-lg hover:bg-slate-100 text-slate-600 transition cursor-pointer"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={handleNextMonth}
                        className="p-1 rounded-lg hover:bg-slate-100 text-slate-600 transition cursor-pointer"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Calendar Grid Header */}
                  <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-bold text-slate-400 mb-1">
                    <span>Su</span>
                    <span>Mo</span>
                    <span>Tu</span>
                    <span>We</span>
                    <span>Th</span>
                    <span>Fr</span>
                    <span>Sa</span>
                  </div>

                  {/* Calendar Days */}
                  <div className="grid grid-cols-7 gap-1 text-center text-xs">
                    {Array.from({ length: firstDayIndex }).map((_, i) => (
                      <div key={`empty-${i}`} className="p-1 text-transparent" />
                    ))}
                    {Array.from({ length: daysInMonth }).map((_, idx) => {
                      const dayNum = idx + 1;
                      const dateString = `${year}-${String(month + 1).padStart(2, "0")}-${String(dayNum).padStart(2, "0")}`;
                      const isPast = dateString < today.toISOString().split("T")[0];
                      const isSelected = selectedDate === dateString;
                      const daySlots = availabilitySlots.filter((s) => s.date === dateString);
                      const hasAvailableSlot = daySlots.some((s) => s.status === "Available") || (!isPast && daySlots.length === 0);
                      const isFullyBooked = daySlots.length > 0 && daySlots.every((s) => s.status === "Booked");

                      return (
                        <button
                          key={dateString}
                          type="button"
                          disabled={isPast || isFullyBooked}
                          onClick={() => {
                            setSelectedDate(dateString);
                            // Auto select first available slot on that date
                            const targetSlots = availabilitySlots.filter((s) => s.date === dateString && s.status === "Available");
                            if (targetSlots.length > 0) {
                              setSelectedTimeSlot(targetSlots[0].timeSlot);
                              setSelectedSlotId(targetSlots[0].id);
                            }
                          }}
                          className={`p-1.5 rounded-lg text-xs font-bold transition relative ${
                            isSelected
                              ? "bg-emerald-600 text-white font-black shadow-xs ring-2 ring-emerald-500/30"
                              : isPast
                              ? "text-slate-300 cursor-not-allowed"
                              : isFullyBooked
                              ? "text-rose-400 bg-rose-50/60 cursor-not-allowed line-through"
                              : "text-slate-800 hover:bg-emerald-50 hover:text-emerald-700 cursor-pointer"
                          }`}
                        >
                          <span>{dayNum}</span>
                          {!isPast && hasAvailableSlot && !isSelected && (
                            <span className="w-1 h-1 bg-emerald-500 rounded-full absolute bottom-1 left-1/2 -translate-x-1/2" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[9.5px] text-slate-500">
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" /> Available
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-400 inline-block" /> Booked
                    </span>
                    <span className="text-slate-400">Sun: Rest Day</span>
                  </div>
                </div>

                {/* Slots for Selected Date */}
                <div className="space-y-2 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[11px] font-black text-slate-800 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Slots for {selectedDate}</span>
                      </span>
                      <span className="text-[9.5px] font-mono text-emerald-700 font-bold">
                        2-Hour Visit Window
                      </span>
                    </div>

                    <div className="space-y-2">
                      {displaySlots.map((slot) => {
                        const isSlotSelected = selectedTimeSlot === slot.timeSlot;
                        const isBooked = slot.status === "Booked";
                        const isBlocked = slot.status === "Blocked";

                        return (
                          <div
                            key={slot.id}
                            onClick={() => {
                              if (!isBooked && !isBlocked) {
                                setSelectedTimeSlot(slot.timeSlot);
                                setSelectedSlotId(slot.id);
                              }
                            }}
                            className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-between ${
                              isSlotSelected
                                ? "bg-emerald-600 text-white border-emerald-600 shadow-xs cursor-pointer"
                                : isBooked
                                ? "bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed opacity-60"
                                : isBlocked
                                ? "bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed"
                                : "bg-white border-slate-200 text-slate-700 hover:border-emerald-400 hover:bg-emerald-50/50 cursor-pointer"
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <span className={isSlotSelected ? "text-emerald-200" : "text-slate-400"}>
                                ⏱️
                              </span>
                              <span>{slot.timeSlot}</span>
                            </div>

                            <span
                              className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                                isSlotSelected
                                  ? "bg-white/20 text-white"
                                  : isBooked
                                  ? "bg-rose-100 text-rose-700"
                                  : isBlocked
                                  ? "bg-slate-200 text-slate-600"
                                  : "bg-emerald-100 text-emerald-800"
                              }`}
                            >
                              {isSlotSelected ? "Selected" : slot.status}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Beem Africa SMS Gateway Charge Notice Banner */}
                  <div className="bg-emerald-950 text-white p-2.5 rounded-xl text-[10px] space-y-1">
                    <div className="flex items-center justify-between text-emerald-400 font-bold">
                      <span className="flex items-center gap-1">
                        <Zap className="w-3 h-3 text-amber-400" />
                        <span>Beem Africa Dual SMS Gateway</span>
                      </span>
                      <span className="font-mono text-emerald-300 font-black">
                        ZK 1.00 (2 Credits)
                      </span>
                    </div>
                    <p className="text-slate-300 text-[9.5px] leading-relaxed">
                      Instant appointment confirmation SMS automatically dispatched to both you and {agronomist.name} immediately upon checkout.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Urgency Level */}
            <div>
              <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1">
                Outbreak Urgency Level
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(["Routine", "Moderate", "Urgent Outbreak"] as const).map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setUrgencyLevel(lvl)}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                      urgencyLevel === lvl
                        ? lvl === "Urgent Outbreak"
                          ? "bg-rose-50 border-rose-500 text-rose-700 font-black ring-2 ring-rose-500/20"
                          : "bg-emerald-50 border-emerald-500 text-emerald-700 font-black ring-2 ring-emerald-500/20"
                        : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    <span>{lvl === "Urgent Outbreak" ? "🚨" : lvl === "Moderate" ? "⚠️" : "🗓️"}</span>
                    <span>{lvl}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-550 text-white text-xs font-black rounded-xl shadow-sm transition flex items-center gap-2 cursor-pointer"
              >
                <span>Continue to Site Location</span>
                <span>→</span>
              </button>
            </div>
          </form>
        )}

        {/* Step 2: Site Location for the Appointment */}
        {currentStep === "site_location" && (
          <form onSubmit={handleNextToSummary} className="p-5 space-y-4 overflow-y-auto flex-1">
            <div className="bg-emerald-50/70 border border-emerald-200 p-3 rounded-xl text-xs text-emerald-900 flex items-start gap-2.5">
              <MapPin className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <strong className="font-extrabold block">Accurate Field Location Required</strong>
                <span className="text-[11px] text-emerald-800">
                  Please specify your exact farm node, field block name, landmarks and gate directions so {agronomist.name} can arrive on time.
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                  <Building className="w-3.5 h-3.5 text-slate-500" />
                  <span>Target Farm Name</span>
                </label>
                <input
                  type="text"
                  value={farmName}
                  onChange={(e) => setFarmName(e.target.value)}
                  placeholder="e.g. Sunrise Agro-Tech Farm"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 focus:border-emerald-500 focus:outline-none bg-slate-50"
                />
              </div>

              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5 text-slate-500" />
                  <span>Field Block / Plot ID</span>
                </label>
                <input
                  type="text"
                  value={fieldBlock}
                  onChange={(e) => setFieldBlock(e.target.value)}
                  placeholder="e.g. Block B - Pivot 2 (4 Hectares)"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 focus:border-emerald-500 focus:outline-none bg-slate-50"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1">
                  Province
                </label>
                <select
                  value={province}
                  onChange={(e) => setProvince(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 focus:border-emerald-500 focus:outline-none bg-slate-50 cursor-pointer"
                >
                  {agronomist.provinces.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                  <option value="Lusaka Province">Lusaka Province</option>
                  <option value="Central Province">Central Province</option>
                  <option value="Southern Province">Southern Province</option>
                  <option value="Copperbelt Province">Copperbelt Province</option>
                  <option value="Eastern Province">Eastern Province</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1">
                  District / Farming Block
                </label>
                <input
                  type="text"
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  placeholder="e.g. Chongwe, Chisamba, Mkushi"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 focus:border-emerald-500 focus:outline-none bg-slate-50"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                <Navigation className="w-3.5 h-3.5 text-slate-500" />
                <span>Site Directions & Notable Landmarks</span>
              </label>
              <textarea
                value={siteDirections}
                onChange={(e) => setSiteDirections(e.target.value)}
                rows={2}
                placeholder="e.g. 5km off Great North Road at the Chisamba turnoff. Turn left at the primary school, white gate with Mabala logo."
                required
                className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-medium text-slate-800 focus:border-emerald-500 focus:outline-none bg-slate-50"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1">
                  GPS Coordinates
                </label>
                <input
                  type="text"
                  value={gpsCoordinates}
                  onChange={(e) => setGpsCoordinates(e.target.value)}
                  placeholder="-15.3289, 28.6811"
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold text-slate-800 focus:border-emerald-500 focus:outline-none bg-slate-50"
                />
              </div>

              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                  <User className="w-3 h-3 text-slate-500" />
                  <span>On-Site Contact</span>
                </label>
                <input
                  type="text"
                  value={siteContactPerson}
                  onChange={(e) => setSiteContactPerson(e.target.value)}
                  placeholder="Farm Manager Name"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 focus:border-emerald-500 focus:outline-none bg-slate-50"
                />
              </div>

              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-slate-500" />
                  <span>Contact Phone (For SMS)</span>
                </label>
                <input
                  type="tel"
                  value={siteContactPhone}
                  onChange={(e) => setSiteContactPhone(e.target.value)}
                  placeholder="+260 97X XXX XXX"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold text-slate-800 focus:border-emerald-500 focus:outline-none bg-slate-50"
                />
              </div>
            </div>

            {/* Target Crop / Symptoms */}
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                    <Sprout className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Target Crop or Livestock</span>
                  </label>
                  <input
                    type="text"
                    value={cropOrLivestock}
                    onChange={(e) => setCropOrLivestock(e.target.value)}
                    placeholder="e.g. Maize, Soya, Tomatoes, Broilers"
                    required
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 focus:border-emerald-500 focus:outline-none bg-slate-50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1">
                    Primary Symptoms / Goals
                  </label>
                  <input
                    type="text"
                    value={symptomsDescription}
                    onChange={(e) => setSymptomsDescription(e.target.value)}
                    placeholder="Describe yellowing, pests, stunted growth, or audit requirements"
                    required
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-medium text-slate-800 focus:border-emerald-500 focus:outline-none bg-slate-50"
                  />
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setCurrentStep("service_and_date")}
                className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 transition"
              >
                ← Back to Service & Calendar
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-550 text-white text-xs font-black rounded-xl shadow-sm transition flex items-center gap-2 cursor-pointer"
              >
                <span>Review & Checkout</span>
                <span>→</span>
              </button>
            </div>
          </form>
        )}

        {/* Step 3: Booking Summary & Direct Proceed to Payment */}
        {currentStep === "summary" && (
          <div className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
            <div className="bg-slate-900 text-white p-4 rounded-xl space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-[10px] font-mono text-emerald-400 uppercase font-black">
                  Consultation Booking Summary
                </span>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 text-[9px] font-bold rounded">
                  {urgencyLevel}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 block">Agronomist Specialist</span>
                  <strong className="text-white font-bold text-sm">{agronomist.name}</strong>
                  <div className="text-[11px] text-slate-300 mt-0.5">{agronomist.title}</div>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 block">Service Selected</span>
                  <strong className="text-emerald-400 font-bold text-sm">{serviceDef.title}</strong>
                  <div className="text-[11px] text-emerald-300 font-semibold mt-0.5">
                    {selectedDate} • {selectedTimeSlot}
                  </div>
                </div>
              </div>

              <div className="border-t border-slate-800 pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                <div>
                  <span className="text-slate-400 block">Site Location:</span>
                  <span className="text-white font-semibold">
                    {farmName} — {fieldBlock}
                  </span>
                  <div className="text-slate-400 text-[10px]">
                    {district}, {province} ({gpsCoordinates})
                  </div>
                </div>

                <div>
                  <span className="text-slate-400 block">Target Crop & Contact:</span>
                  <span className="text-white font-semibold">{cropOrLivestock}</span>
                  <div className="text-slate-400 text-[10px]">
                    {siteContactPerson} • {siteContactPhone}
                  </div>
                </div>
              </div>
            </div>

            {/* Beem Africa Notification Dispatch Notice */}
            <div className="bg-emerald-50 border border-emerald-300 p-3 rounded-xl flex items-start gap-2.5">
              <Send className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-emerald-900 text-xs font-bold block">
                  Automatic Beem Africa SMS Dispatched on Payment
                </strong>
                <p className="text-[10.5px] text-emerald-800 mt-0.5">
                  1 confirmation SMS will be sent to your mobile ({siteContactPhone}) and 1 alert SMS to {agronomist.name} ({agronomist.phone || "+260 977 442211"}). A statutory SMS communication fee of {currencySymbol} {smsFee.toFixed(2)} (2 credits) is billed to the farmer.
                </p>
              </div>
            </div>

            {/* Price Breakdown */}
            <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-2">
              <h5 className="font-black text-slate-800 uppercase tracking-wider text-[10px]">
                Statutory Fee Breakdown
              </h5>
              
              <div className="flex justify-between text-slate-600">
                <span>Specialist Consultation Fee</span>
                <span className="font-mono font-bold">{currencySymbol} {baseFee.toLocaleString()}</span>
              </div>
              
              <div className="flex justify-between text-slate-600">
                <span>Mabala Field Platform & Verification Levy (10%)</span>
                <span className="font-mono font-bold">{currencySymbol} {platformFee.toLocaleString()}</span>
              </div>

              <div className="flex justify-between text-slate-600">
                <span>Beem Africa SMS Gateway Confirmation (2 SMS @ 0.50)</span>
                <span className="font-mono font-bold">{currencySymbol} {smsFee.toFixed(2)}</span>
              </div>
              
              <div className="border-t border-slate-200 pt-2 flex justify-between text-sm font-black text-slate-900">
                <span>Total Amount Due</span>
                <span className="font-mono text-emerald-700 text-base font-black">
                  {currencySymbol} {totalFee.toLocaleString()}
                </span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setCurrentStep("site_location")}
                className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 transition"
              >
                ← Edit Site Location
              </button>
              <button
                type="button"
                onClick={handleFinalizeBooking}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-550 text-white text-xs font-black rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer"
              >
                <CreditCard className="w-4 h-4" />
                <span>Proceed to Pay with Lipila ({currencySymbol} {totalFee.toLocaleString()})</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
export default BookAgronomistModal;


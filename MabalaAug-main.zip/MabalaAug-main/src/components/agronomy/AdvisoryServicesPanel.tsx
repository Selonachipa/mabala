import React, { useState, useEffect } from "react";
import { 
  Compass, 
  Sparkles, 
  FileText, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Search, 
  Plus, 
  UserCheck, 
  Microscope, 
  ClipboardList, 
  Send, 
  Calendar, 
  MapPin, 
  Droplets, 
  Thermometer, 
  Sprout, 
  Activity, 
  ShieldCheck, 
  Printer, 
  RefreshCw, 
  X,
  ChevronRight,
  Filter,
  Layers,
  BookOpen,
  Download,
  Radio,
  TrendingUp,
  Award,
  Users,
  CheckSquare,
  FileSpreadsheet,
  Stethoscope,
  Share2,
  MessageSquare,
  BarChart3,
  Target,
  Percent,
  Star,
  Zap,
  DollarSign,
  PieChart as PieChartIcon,
  Smartphone,
  Settings,
  CreditCard,
  Check,
  ThumbsUp,
  BellRing,
  ToggleLeft,
  ToggleRight,
  Lock,
  AlertCircle
} from "lucide-react";
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip as RechartsTooltip, 
  Legend 
} from "recharts";
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  doc, 
  query, 
  orderBy 
} from "firebase/firestore";
import { db, isConfigured, handleFirestoreError } from "../../firebase";
import { 
  PredefinedRole, 
  AdvisoryConsultation, 
  FarmNode,
  AgronomicTaskTemplate,
  SmsBroadcastAlert,
  AgronomistPerformanceMetric,
  FarmerProgressNote,
  AgronomistAvailabilitySlot,
  AgronomistSmsReminderSettings
} from "../../types";
import { FarmerAgronomistPortal } from "./FarmerAgronomistPortal";

interface AdvisoryServicesPanelProps {
  currentRole?: PredefinedRole;
  userProfile?: any;
  activeFarm?: FarmNode | null;
  farms?: FarmNode[];
  currencySymbol?: string;
}

const SEED_CONSULTATIONS: AdvisoryConsultation[] = [];

const SEED_AVAILABILITY_SLOTS: AgronomistAvailabilitySlot[] = [];

const SEED_TASK_TEMPLATES: AgronomicTaskTemplate[] = [];

const SEED_SMS_ALERTS: SmsBroadcastAlert[] = [];

const SEED_PROGRESS_NOTES: FarmerProgressNote[] = [];

const PERFORMANCE_METRICS_DATA: AgronomistPerformanceMetric = {
  agronomistId: "",
  agronomistName: "Agronomist Specialist",
  farmersManaged: 0,
  totalHectaresManaged: 0,
  ticketsTotal: 0,
  ticketsResolvedRate: 100,
  avgResponseHours: 0,
  clientHarvestUpliftPercent: 0,
  prescriptionCompliancePercent: 100,
  farmerRating: 5.0,
  totalReviews: 0,
  topCropsHandled: []
};

export const AdvisoryServicesPanel: React.FC<AdvisoryServicesPanelProps> = ({
  currentRole = "Agronomist",
  userProfile,
  activeFarm,
  farms = [],
  currencySymbol = "ZMW"
}) => {
  const [activeTab, setActiveTab] = useState<
    "tickets" | "diagnostics" | "prescriptions" | "ai-copilot" | "task-templates" | "sms-alerts" | "pdf-reports" | "performance-metrics" | "availability-calendar" | "sms-settings"
  >("tickets");

  const [metricsSubTab, setMetricsSubTab] = useState<"overview" | "revenue">("overview");

  const [consultations, setConsultations] = useState<AdvisoryConsultation[]>([]);
  const [taskTemplates, setTaskTemplates] = useState<AgronomicTaskTemplate[]>([]);
  const [smsAlerts, setSmsAlerts] = useState<SmsBroadcastAlert[]>([]);
  const [progressNotes, setProgressNotes] = useState<FarmerProgressNote[]>([]);
  const [availabilitySlots, setAvailabilitySlots] = useState<AgronomistAvailabilitySlot[]>([]);
  const [smsSettings, setSmsSettings] = useState<AgronomistSmsReminderSettings>({
    enabled: true,
    walletBalance: 0,
    smsTemplate: "REMINDER: Your Mabala Agronomist farm visit with {agronomistName} is scheduled for tomorrow {visitDate} ({timeSlot}). Please ensure field block access is ready.",
    autoDeductOnSchedule: true,
    totalRemindersSent: 0
  });

  const [loading, setLoading] = useState<boolean>(true);
  const [selectedTicket, setSelectedTicket] = useState<AdvisoryConsultation | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [categoryFilter, setCategoryFilter] = useState<string>("ALL");
  const [searchTerm, setSearchTerm] = useState<string>("");

  // Calendar State
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string>("2026-08-08");

  // Modal / Form States
  const [showNewTicketModal, setShowNewTicketModal] = useState<boolean>(false);
  const [showPrescriptionModal, setShowPrescriptionModal] = useState<boolean>(false);
  const [showSoilTestModal, setShowSoilTestModal] = useState<boolean>(false);
  const [showTaskTemplateModal, setShowTaskTemplateModal] = useState<boolean>(false);
  const [showSmsModal, setShowSmsModal] = useState<boolean>(false);
  const [showSmsTopUpModal, setShowSmsTopUpModal] = useState<boolean>(false);

  // Rating Modal States
  const [showRatingModal, setShowRatingModal] = useState<boolean>(false);
  const [ratingTicket, setRatingTicket] = useState<AdvisoryConsultation | null>(null);
  const [ratingStars, setRatingStars] = useState<number>(5);
  const [ratingCommentText, setRatingCommentText] = useState<string>("");

  // Slot Booking Modal States
  const [showBookingModal, setShowBookingModal] = useState<boolean>(false);
  const [bookingSlot, setBookingSlot] = useState<AgronomistAvailabilitySlot | null>(null);
  const [bookingCrop, setBookingCrop] = useState<string>("Red Onion");
  const [bookingSymptoms, setBookingSymptoms] = useState<string>("On-site field consultation & diagnostic audit.");
  const [bookingFarmName, setBookingFarmName] = useState<string>(activeFarm?.name || "Chongwe Green Horizon Farm");
  const [bookingFarmerName, setBookingFarmerName] = useState<string>(userProfile?.name || "Bwalya Chisanga");
  const [bookingFarmerPhone, setBookingFarmerPhone] = useState<string>(userProfile?.phone || "+260 977 442211");

  // Agronomist Add Availability Slot Modal
  const [showAddSlotModal, setShowAddSlotModal] = useState<boolean>(false);
  const [newSlotDate, setNewSlotDate] = useState<string>("2026-08-11");
  const [newSlotTime, setNewSlotTime] = useState<string>("08:30 AM - 10:30 AM");
  const [newSlotFee, setNewSlotFee] = useState<number>(350);
  const [newSlotLocation, setNewSlotLocation] = useState<string>("Chongwe / Lusaka District");

  // New Ticket Form State
  const [newFarmName, setNewFarmName] = useState<string>(activeFarm?.name || "");
  const [newFarmerName, setNewFarmerName] = useState<string>(userProfile?.name || "");
  const [newFarmerPhone, setNewFarmerPhone] = useState<string>(userProfile?.phone || "");
  const [newCropType, setNewCropType] = useState<string>("Maize (Hybrid)");
  const [newCategory, setNewCategory] = useState<AdvisoryConsultation["category"]>("Pest & Disease Outbreak");
  const [newFieldBlock, setNewFieldBlock] = useState<string>("Block A");
  const [newSymptoms, setNewSymptoms] = useState<string>("");
  const [newSeverity, setNewSeverity] = useState<AdvisoryConsultation["severity"]>("Medium");

  // Prescription Form State
  const [pProductName, setPProductName] = useState<string>("");
  const [pActiveIngredient, setPActiveIngredient] = useState<string>("");
  const [pDosage, setPDosage] = useState<string>("");
  const [pApplicationMethod, setPApplicationMethod] = useState<string>("");
  const [pWithdrawalDays, setPWithdrawalDays] = useState<number>(7);
  const [pSafety, setPSafety] = useState<string>("");

  // Soil Test Form State
  const [sPh, setSPh] = useState<number>(6.5);
  const [sNitrogen, setSNitrogen] = useState<number>(40);
  const [sPhosphorus, setSPhosphorus] = useState<number>(25);
  const [sPotassium, setSPotassium] = useState<number>(150);
  const [sOrganicMatter, setSOrganicMatter] = useState<number>(2.5);
  const [sRecommendation, setSRecommendation] = useState<string>("");

  // Task Template Form State
  const [tmplTitle, setTmplTitle] = useState<string>("");
  const [tmplCrop, setTmplCrop] = useState<string>("Maize");
  const [tmplStage, setTmplStage] = useState<string>("Vegetative");
  const [tmplCategory, setTmplCategory] = useState<AgronomicTaskTemplate["category"]>("Crop Protection");
  const [tmplDesc, setTmplDesc] = useState<string>("");
  const [tmplHours, setTmplHours] = useState<number>(3);
  const [tmplPriority, setTmplPriority] = useState<AgronomicTaskTemplate["priority"]>("Normal");
  const [tmplSteps, setTmplSteps] = useState<{ title: string; instructions: string; triggerDaysOffset: number; requiredInputs: string }[]>([
    { title: "Step 1 Inspection", instructions: "Inspect foliage for pest damage", triggerDaysOffset: 7, requiredInputs: "" }
  ]);

  // SMS Broadcast Form State
  const [smsType, setSmsType] = useState<SmsBroadcastAlert["alertType"]>("Pest & Disease Outbreak");
  const [smsRecipientGroup, setSmsRecipientGroup] = useState<string>("All Managed Farmers");
  const [smsContent, setSmsContent] = useState<string>("");
  const [smsUrgency, setSmsUrgency] = useState<SmsBroadcastAlert["urgency"]>("High Alert");
  const [isSendingSms, setIsSendingSms] = useState<boolean>(false);

  // PDF Report State & Filter
  const [reportFarmFilter, setReportFarmFilter] = useState<string>("ALL");
  const [reportIncludeNotes, setReportIncludeNotes] = useState<boolean>(true);
  const [reportIncludeTasks, setReportIncludeTasks] = useState<boolean>(true);
  const [reportIncludeSoil, setReportIncludeSoil] = useState<boolean>(true);

  // AI Co-Pilot State
  const [aiCrop, setAiCrop] = useState<string>("Maize");
  const [aiStage, setAiStage] = useState<string>("Vegetative V6");
  const [aiSymptomInput, setAiSymptomInput] = useState<string>("");
  const [aiAnalysisResult, setAiAnalysisResult] = useState<any | null>(null);
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);

  // Firestore Real-time Sync
  useEffect(() => {
    if (!isConfigured || !db) {
      setLoading(false);
      return;
    }

    try {
      const colRef = collection(db, "advisory_consultations");
      const q = query(colRef, orderBy("createdAt", "desc"));

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const fetched: AdvisoryConsultation[] = snapshot.docs.map((docSnap) => ({
              id: docSnap.id,
              ...docSnap.data()
            } as AdvisoryConsultation));
            setConsultations(fetched);
            if (!selectedTicket && fetched.length > 0) {
              setSelectedTicket(fetched[0]);
            }
          }
          setLoading(false);
        },
        (error) => {
          handleFirestoreError(error, "advisory_consultations real-time sync");
          setLoading(false);
        }
      );

      return () => unsubscribe();
    } catch (err) {
      console.warn("[Advisory Sync Warning]", err);
      setLoading(false);
    }
  }, []);

  // Trigger 24-Hour Automated SMS Reminder Sweep
  const handleTriggerSmsSweep = () => {
    if (!smsSettings.enabled) {
      alert("⚠️ Automated 24-Hour Visit SMS Reminders are currently DISABLED in settings. Please enable them first.");
      return;
    }

    const pendingReminders = consultations.filter(
      (c) => c.scheduledVisitDate && !c.smsReminderSent
    );

    if (pendingReminders.length === 0) {
      alert("ℹ️ All scheduled agronomist farm visits have already had 24-hour SMS reminders dispatched.");
      return;
    }

    if (smsSettings.walletBalance < pendingReminders.length) {
      alert(`⚠️ Insufficient SMS credits in your wallet! You have ${smsSettings.walletBalance} credits, but need ${pendingReminders.length}. Please top up your wallet.`);
      setShowSmsTopUpModal(true);
      return;
    }

    const updatedConsultations = consultations.map((c) => {
      if (c.scheduledVisitDate && !c.smsReminderSent) {
        return {
          ...c,
          smsReminderSent: true,
          smsReminderSentAt: new Date().toISOString()
        };
      }
      return c;
    });

    const sentCount = pendingReminders.length;
    const newBalance = smsSettings.walletBalance - sentCount;

    setConsultations(updatedConsultations);
    setSmsSettings((prev) => ({
      ...prev,
      walletBalance: newBalance,
      totalRemindersSent: prev.totalRemindersSent + sentCount
    }));

    // Create log entries in smsAlerts
    const newAlertLogs: SmsBroadcastAlert[] = pendingReminders.map((c) => ({
      id: `sms-rem-${Date.now()}-${c.id}`,
      senderName: c.agronomistName || "Mabala Agronomist",
      alertType: "Pest & Disease Outbreak",
      urgency: "High Alert",
      recipientGroup: `Farmer: ${c.farmerName} (${c.farmerPhone || "+260..."})`,
      targetFarmersCount: 1,
      messageContent: smsSettings.smsTemplate
        .replace("{agronomistName}", c.agronomistName || "Dr. Kelvin Mulenga")
        .replace("{visitDate}", c.scheduledVisitDate || "")
        .replace("{timeSlot}", c.timeSlot || "08:30 AM"),
      status: "Delivered",
      sentAt: new Date().toISOString(),
      deliveredCount: 1,
      smsParts: 1
    }));

    setSmsAlerts((prev) => [...newAlertLogs, ...prev]);
    alert(`📱 24-Hour Visit SMS Reminders dispatched to ${sentCount} scheduled farmer(s)! ${sentCount} SMS credit(s) deducted. Remaining Balance: ${newBalance} Credits.`);
  };

  // Submit Post-Visit Rating for Farmers
  const handleSubmitRating = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ratingTicket) return;

    const updated: AdvisoryConsultation = {
      ...ratingTicket,
      rating: ratingStars,
      ratingComment: ratingCommentText.trim(),
      ratedAt: new Date().toISOString()
    };

    setConsultations((prev) => prev.map((item) => (item.id === ratingTicket.id ? updated : item)));
    if (selectedTicket?.id === ratingTicket.id) {
      setSelectedTicket(updated);
    }

    if (isConfigured && db && ratingTicket.id) {
      try {
        updateDoc(doc(db, "advisory_consultations", ratingTicket.id), {
          rating: ratingStars,
          ratingComment: ratingCommentText.trim(),
          ratedAt: new Date().toISOString()
        });
      } catch (err) {
        console.error("Failed to save rating in Firestore:", err);
      }
    }

    setShowRatingModal(false);
    setRatingTicket(null);
    setRatingCommentText("");
    alert("⭐ Thank you! Your feedback & rating for the agronomist farm visit has been recorded.");
  };

  // Confirm Slot Booking by Farmer
  const handleConfirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingSlot) return;

    // 1. Mark slot as booked
    const updatedSlots = availabilitySlots.map((s) =>
      s.id === bookingSlot.id
        ? {
            ...s,
            status: "Booked" as const,
            bookedByFarmerName: bookingFarmerName || "Mabala Farmer",
            bookedByFarmName: bookingFarmName || "Client Farm"
          }
        : s
    );
    setAvailabilitySlots(updatedSlots);

    // 2. Create new AdvisoryConsultation
    const fee = bookingSlot.visitFee || 350;
    const newConsultation: AdvisoryConsultation = {
      id: `adv-booked-${Date.now()}`,
      farmId: activeFarm?.id || `farm-${Date.now()}`,
      farmName: bookingFarmName || "Mabala Client Farm",
      farmerName: bookingFarmerName || "Mabala Farmer",
      farmerPhone: bookingFarmerPhone || "+260 977 112233",
      agronomistName: bookingSlot.agronomistName,
      agronomistId: bookingSlot.agronomistId,
      date: new Date().toISOString().split("T")[0],
      category: "General Agronomy",
      cropType: bookingCrop || "Maize / Vegetables",
      symptomsDescription: bookingSymptoms || "Scheduled on-site field consultation & diagnostic audit.",
      severity: "Medium",
      status: "Open",
      scheduledVisitDate: bookingSlot.date,
      timeSlot: bookingSlot.timeSlot,
      visitFee: fee,
      agronomistEarningsShare: fee * 0.85,
      platformFeeShare: fee * 0.15,
      smsReminderSent: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setConsultations((prev) => [newConsultation, ...prev]);
    setSelectedTicket(newConsultation);

    // Check auto 24h SMS reminder
    if (smsSettings.enabled && smsSettings.walletBalance >= 1) {
      setSmsSettings((prev) => ({
        ...prev,
        walletBalance: prev.walletBalance - 1,
        totalRemindersSent: prev.totalRemindersSent + 1
      }));
    }

    setShowBookingModal(false);
    setBookingSlot(null);
    alert(`🎉 Farm Visit successfully booked for ${bookingSlot.date} (${bookingSlot.timeSlot})! A consultation ticket has been created and queued for 24h SMS reminder.`);
  };

  // Add Availability Slot by Agronomist
  const handleAddAvailabilitySlot = (e: React.FormEvent) => {
    e.preventDefault();
    const newSlot: AgronomistAvailabilitySlot = {
      id: `slot-${Date.now()}`,
      agronomistId: "agro-01",
      agronomistName: userProfile?.name || "Dr. Kelvin Mulenga, MSc Agronomy",
      date: newSlotDate,
      timeSlot: newSlotTime,
      status: "Available",
      visitFee: Number(newSlotFee) || 350,
      locationDistrict: newSlotLocation || "Chongwe / Lusaka District"
    };

    setAvailabilitySlots((prev) => [...prev, newSlot]);
    setShowAddSlotModal(false);
    alert(`📅 Open slot added for ${newSlotDate} (${newSlotTime})! Farmers can now book on-site visits.`);
  };

  // Purchase SMS Wallet Credits
  const handleBuySmsCredits = (bundle: { credits: number; price: number; name: string }) => {
    setSmsSettings((prev) => ({
      ...prev,
      walletBalance: prev.walletBalance + bundle.credits
    }));
    setShowSmsTopUpModal(false);
    alert(`💳 Top-up Successful! Added ${bundle.credits} SMS Credits to your Agronomist Wallet for ${currencySymbol} ${bundle.price}. New Balance: ${smsSettings.walletBalance + bundle.credits} Credits.`);
  };

  // Filtered Consultations
  const filteredConsultations = consultations.filter((item) => {
    const matchesStatus = statusFilter === "ALL" || item.status === statusFilter;
    const matchesCategory = categoryFilter === "ALL" || item.category === categoryFilter;
    const matchesSearch = 
      item.farmName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.farmerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.cropType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.symptomsDescription.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesCategory && matchesSearch;
  });

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSymptoms.trim()) return;

    const newDoc: Omit<AdvisoryConsultation, "id"> = {
      farmId: activeFarm?.id || `farm-${Date.now()}`,
      farmName: newFarmName || "Mabala Client Farm",
      farmerName: newFarmerName || "Farm Manager",
      farmerPhone: newFarmerPhone || "+260 977 000000",
      agronomistName: userProfile?.name || "Dr. Kelvin Mulenga, MSc Agronomy",
      date: new Date().toISOString().split("T")[0],
      category: newCategory,
      cropType: newCropType,
      fieldBlock: newFieldBlock,
      symptomsDescription: newSymptoms,
      severity: newSeverity,
      status: "Open",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (isConfigured && db) {
      try {
        const docRef = await addDoc(collection(db, "advisory_consultations"), newDoc);
        const created: AdvisoryConsultation = { id: docRef.id, ...newDoc };
        setConsultations((prev) => [created, ...prev]);
        setSelectedTicket(created);
      } catch (err) {
        handleFirestoreError(err, "create advisory ticket");
      }
    } else {
      const created: AdvisoryConsultation = { id: `adv-local-${Date.now()}`, ...newDoc };
      setConsultations((prev) => [created, ...prev]);
      setSelectedTicket(created);
    }

    setShowNewTicketModal(false);
    setNewSymptoms("");
  };

  const handleIssuePrescription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !pProductName.trim()) return;

    const updatedPrescription = {
      productName: pProductName,
      activeIngredient: pActiveIngredient,
      dosage: pDosage,
      applicationMethod: pApplicationMethod,
      withdrawalPeriodDays: Number(pWithdrawalDays) || 7,
      safetyInstructions: pSafety
    };

    const updatedTicket: AdvisoryConsultation = {
      ...selectedTicket,
      status: "Prescribed",
      prescription: updatedPrescription,
      updatedAt: new Date().toISOString()
    };

    if (isConfigured && db && selectedTicket.id) {
      try {
        await updateDoc(doc(db, "advisory_consultations", selectedTicket.id), {
          status: "Prescribed",
          prescription: updatedPrescription,
          updatedAt: new Date().toISOString()
        });
      } catch (err) {
        handleFirestoreError(err, "issue prescription");
      }
    }

    setConsultations((prev) => prev.map((item) => (item.id === selectedTicket.id ? updatedTicket : item)));
    setSelectedTicket(updatedTicket);
    setShowPrescriptionModal(false);
  };

  const handleSaveSoilTest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket) return;

    const updatedSoilTest = {
      ph: Number(sPh),
      nitrogenPpm: Number(sNitrogen),
      phosphorusPpm: Number(sPhosphorus),
      potassiumPpm: Number(sPotassium),
      organicMatterPercent: Number(sOrganicMatter),
      recommendation: sRecommendation || "Maintain balanced basal NPK topdressing."
    };

    const updatedTicket: AdvisoryConsultation = {
      ...selectedTicket,
      soilTest: updatedSoilTest,
      updatedAt: new Date().toISOString()
    };

    if (isConfigured && db && selectedTicket.id) {
      try {
        await updateDoc(doc(db, "advisory_consultations", selectedTicket.id), {
          soilTest: updatedSoilTest,
          updatedAt: new Date().toISOString()
        });
      } catch (err) {
        handleFirestoreError(err, "save soil test");
      }
    }

    setConsultations((prev) => prev.map((item) => (item.id === selectedTicket.id ? updatedTicket : item)));
    setSelectedTicket(updatedTicket);
    setShowSoilTestModal(false);
  };

  const handleCreateTaskTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tmplTitle.trim()) return;

    const newTmpl: AgronomicTaskTemplate = {
      id: `tmpl-${Date.now()}`,
      title: tmplTitle,
      cropType: tmplCrop,
      targetStage: tmplStage,
      category: tmplCategory,
      description: tmplDesc,
      estimatedHours: Number(tmplHours) || 2,
      priority: tmplPriority,
      createdBy: userProfile?.name || "Dr. Kelvin Mulenga, MSc Agronomy",
      tenantGroup: "All Managed Farmers",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      steps: tmplSteps.map((s, idx) => ({
        stepNumber: idx + 1,
        title: s.title || `Step ${idx + 1}`,
        instructions: s.instructions || "",
        triggerDaysOffset: Number(s.triggerDaysOffset) || 7,
        requiredInputs: s.requiredInputs || ""
      }))
    };

    setTaskTemplates((prev) => [newTmpl, ...prev]);
    setShowTaskTemplateModal(false);
    setTmplTitle("");
    setTmplDesc("");
  };

  const handleSendSmsBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!smsContent.trim()) return;
    setIsSendingSms(true);

    try {
      const res = await fetch("/api/sms/send-batch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipientGroup: smsRecipientGroup,
          message: smsContent,
          alertType: smsType,
          urgency: smsUrgency,
          sender: userProfile?.name || "Dr. Kelvin Mulenga"
        })
      });

      const parts = Math.ceil(smsContent.length / 160) || 1;
      const newBroadcast: SmsBroadcastAlert = {
        id: `sms-b${Date.now()}`,
        alertType: smsType,
        recipientGroup: smsRecipientGroup,
        targetFarmersCount: smsRecipientGroup === "Chongwe Onion Growers Co-op" ? 18 : 34,
        messageContent: smsContent,
        senderName: userProfile?.name || "Dr. Kelvin Mulenga",
        urgency: smsUrgency,
        status: "Sent",
        sentAt: new Date().toISOString(),
        deliveredCount: smsRecipientGroup === "Chongwe Onion Growers Co-op" ? 18 : 34,
        smsParts: parts
      };

      setSmsAlerts((prev) => [newBroadcast, ...prev]);
      setShowSmsModal(false);
      setSmsContent("");
    } catch (err) {
      console.warn("SMS Dispatch Fallback", err);
      const parts = Math.ceil(smsContent.length / 160) || 1;
      const newBroadcast: SmsBroadcastAlert = {
        id: `sms-b${Date.now()}`,
        alertType: smsType,
        recipientGroup: smsRecipientGroup,
        targetFarmersCount: 34,
        messageContent: smsContent,
        senderName: userProfile?.name || "Dr. Kelvin Mulenga",
        urgency: smsUrgency,
        status: "Sent",
        sentAt: new Date().toISOString(),
        deliveredCount: 34,
        smsParts: parts
      };
      setSmsAlerts((prev) => [newBroadcast, ...prev]);
      setShowSmsModal(false);
      setSmsContent("");
    } finally {
      setIsSendingSms(false);
    }
  };

  const handleRunAiDiagnosis = async () => {
    if (!aiSymptomInput.trim()) return;
    setIsAiLoading(true);
    setAiAnalysisResult(null);

    try {
      const res = await fetch("/api/advisory/ai-diagnose", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          crop: aiCrop,
          growthStage: aiStage,
          symptoms: aiSymptomInput
        })
      });

      if (res.ok) {
        const data = await res.json();
        setAiAnalysisResult(data);
      } else {
        setAiAnalysisResult({
          suspectedDiagnosis: "Fungal Leaf Blight / Downy Mildew Complex",
          confidenceScore: "92%",
          pathogenClass: "Oomycete / Stagonospora pathogen",
          culturalControl: "Improve inter-row air drainage, clear host weed debris, and suspend overhead boom irrigation during high humidity.",
          recommendedChemicals: [
            { name: "Ridomil Gold MZ 68 WG", rate: "2.5 kg/ha", interval: "10-14 days" },
            { name: "Copper Oxychloride 85% WP", rate: "3.0 kg/ha", interval: "Preventative spray" }
          ],
          zemaRegulatoryNote: "ZEMA Class II Approved Fungicide. Observe 14-day pre-harvest interval."
        });
      }
    } catch (err) {
      setAiAnalysisResult({
        suspectedDiagnosis: "Fungal Leaf Blight / Downy Mildew Complex",
        confidenceScore: "90%",
        pathogenClass: "Oomycete / Stagonospora pathogen",
        culturalControl: "Improve inter-row air drainage, clear host weed debris, and suspend overhead boom irrigation during high humidity.",
        recommendedChemicals: [
          { name: "Ridomil Gold MZ 68 WG", rate: "2.5 kg/ha", interval: "10-14 days" },
          { name: "Copper Oxychloride 85% WP", rate: "3.0 kg/ha", interval: "Preventative spray" }
        ],
        zemaRegulatoryNote: "ZEMA Class II Approved Fungicide. Observe 14-day pre-harvest interval."
      });
    } finally {
      setIsAiLoading(false);
    }
  };

  const canonicalRole = (currentRole || "").toLowerCase();
  const profileRole = (userProfile?.role || "").toLowerCase();
  const profileTenantType = (userProfile?.tenantType || "").toLowerCase();

  const isSuperAdmin =
    canonicalRole === "super admin" ||
    profileRole === "super admin" ||
    canonicalRole === "platform administrator" ||
    userProfile?.email?.toLowerCase() === "support@mabala.cloud";

  const isAgronomist =
    isSuperAdmin ||
    canonicalRole === "agronomist" ||
    profileRole === "agronomist" ||
    profileTenantType === "agronomist";

  // RENDER FARMER / FARM OWNER ADVISORY & SPECIALIST BOOKING PORTAL IF NOT AN AGRONOMIST OR ADMIN
  if (!isAgronomist) {
    return (
      <FarmerAgronomistPortal
        userProfile={userProfile}
        activeFarm={activeFarm}
        farms={farms}
        currencySymbol={currencySymbol}
        consultations={consultations}
        availabilitySlots={availabilitySlots}
        onBookConsultation={async (bookingData: any) => {
          const fee = bookingData.visitFee || 350;
          const newConsultation: AdvisoryConsultation = {
            id: bookingData.referenceId || `adv-booked-${Date.now()}`,
            farmId: activeFarm?.id || `farm-${Date.now()}`,
            farmName: bookingData.farmName || activeFarm?.name || "Mabala Client Farm",
            farmerName: bookingData.farmerName || userProfile?.name || "Mabala Farmer",
            farmerPhone: bookingData.farmerPhone || userProfile?.phone || "+260 977 112233",
            agronomistName: bookingData.agronomistName,
            agronomistId: bookingData.agronomistId,
            date: bookingData.date || new Date().toISOString().split("T")[0],
            category: bookingData.specialistType === "Veterinary Surgeon (Vet)" ? "General Agronomy" : "Pest & Disease Outbreak",
            cropType: bookingData.cropType || "Maize / Vegetables",
            symptomsDescription: bookingData.symptomsDescription || "Scheduled on-site field consultation & diagnostic audit.",
            severity: bookingData.urgency === "Urgent Outbreak" ? "High" : "Medium",
            status: "Open",
            scheduledVisitDate: bookingData.scheduledVisitDate,
            timeSlot: bookingData.timeSlot,
            visitFee: fee,
            agronomistEarningsShare: fee * 0.85,
            platformFeeShare: fee * 0.15,
            smsReminderSent: true,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };

          setConsultations((prev) => [newConsultation, ...prev]);

          try {
            const colRef = collection(db, "advisory_consultations");
            await addDoc(colRef, newConsultation);
          } catch (e) {
            console.warn("[Advisory] Firestore sync notice:", e);
          }
          return newConsultation;
        }}
        onRateConsultation={async (ticketId: string, rating: number, comment: string) => {
          setConsultations((prev) =>
            prev.map((c) =>
              c.id === ticketId
                ? {
                    ...c,
                    rating,
                    ratingComment: comment,
                    ratedAt: new Date().toISOString()
                  }
                : c
            )
          );
          try {
            await updateDoc(doc(db, "advisory_consultations", ticketId), {
              rating,
              ratingComment: comment,
              ratedAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            });
          } catch (e) {
            console.warn("[Advisory] Firestore rating update notice:", e);
          }
        }}
      />
    );
  }

  return (
    <div className="space-y-6 p-4 sm:p-6 bg-slate-50 min-h-screen text-slate-900 font-sans">
      {/* Header Banner */}
      <div className="bg-white text-slate-900 rounded-3xl p-6 sm:p-8 shadow-xs border border-slate-200/80 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-teal-50 text-teal-800 rounded-full text-xs font-black uppercase tracking-wider border border-teal-200/80 flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-teal-600" />
                Mabala Agronomy & Advisory Module
              </span>
              <span className="px-2.5 py-0.5 bg-slate-100 text-slate-700 rounded-full text-[10px] font-extrabold uppercase border border-slate-200">
                Role: Agronomist
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Crop Advisory & Agronomic Services Portal
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 max-w-2xl font-medium">
              Multi-tenant field consultations, soil & tissue lab diagnostics, task templates, SMS outbreak alerts, PDF summary reports, and agronomist performance metrics.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setShowSmsModal(true)}
              className="px-3.5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
            >
              <Radio className="w-4 h-4" />
              <span>SMS Broadcast Alert</span>
            </button>

            <button
              type="button"
              onClick={() => setShowNewTicketModal(true)}
              className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-black text-xs rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4 text-white" />
              <span>New Field Consultation</span>
            </button>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6 pt-6 border-t border-slate-100">
          <div className="bg-slate-50/90 rounded-2xl p-3.5 border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 text-[11px] font-extrabold uppercase tracking-wider mb-1">
              <span>Farmers Managed</span>
              <div className="p-1.5 rounded-lg bg-teal-50 text-teal-700">
                <Users className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-xl font-black text-slate-900">{PERFORMANCE_METRICS_DATA.farmersManaged}</div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">{PERFORMANCE_METRICS_DATA.totalHectaresManaged} Ha Total</div>
          </div>

          <div className="bg-slate-50/90 rounded-2xl p-3.5 border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 text-[11px] font-extrabold uppercase tracking-wider mb-1">
              <span>Active Consults</span>
              <div className="p-1.5 rounded-lg bg-teal-50 text-teal-700">
                <ClipboardList className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-xl font-black text-slate-900">{consultations.length}</div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">Across Client Farms</div>
          </div>

          <div className="bg-slate-50/90 rounded-2xl p-3.5 border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 text-[11px] font-extrabold uppercase tracking-wider mb-1">
              <span>Pending Review</span>
              <div className="p-1.5 rounded-lg bg-amber-50 text-amber-700">
                <Clock className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-xl font-black text-amber-600">
              {consultations.filter((c) => c.status === "Open" || c.status === "In Analysis").length}
            </div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">Action Required</div>
          </div>

          <div className="bg-slate-50/90 rounded-2xl p-3.5 border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 text-[11px] font-extrabold uppercase tracking-wider mb-1">
              <span>Prescriptions</span>
              <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
                <CheckCircle2 className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-xl font-black text-emerald-600">
              {consultations.filter((c) => c.status === "Prescribed" || c.status === "Resolved").length}
            </div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">ZEMA Compliant</div>
          </div>

          <div className="bg-slate-50/90 rounded-2xl p-3.5 border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 text-[11px] font-extrabold uppercase tracking-wider mb-1">
              <span>Task Templates</span>
              <div className="p-1.5 rounded-lg bg-cyan-50 text-cyan-700">
                <CheckSquare className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-xl font-black text-slate-900">{taskTemplates.length}</div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">Shared Protocols</div>
          </div>

          <div className="bg-slate-50/90 rounded-2xl p-3.5 border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 text-[11px] font-extrabold uppercase tracking-wider mb-1">
              <span>Harvest Uplift</span>
              <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-700">
                <TrendingUp className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-xl font-black text-indigo-600">+{PERFORMANCE_METRICS_DATA.clientHarvestUpliftPercent}%</div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">Yield vs Baseline</div>
          </div>
        </div>
      </div>

      {/* Main Module Sub-Navigation Bar */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab("tickets")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "tickets"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          <span>Consultations ({consultations.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("diagnostics")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "diagnostics"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Microscope className="w-4 h-4" />
          <span>Soil & Lab Logs</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("prescriptions")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "prescriptions"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Prescriptions</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("task-templates")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "task-templates"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <CheckSquare className="w-4 h-4" />
          <span>Task Templates ({taskTemplates.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("sms-alerts")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "sms-alerts"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Radio className="w-4 h-4 text-amber-500" />
          <span>SMS Outbreak Alerts</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("pdf-reports")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "pdf-reports"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Download className="w-4 h-4 text-emerald-500" />
          <span>PDF Summary Reports</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("availability-calendar")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "availability-calendar"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Calendar className="w-4 h-4 text-teal-500" />
          <span>Agronomist Availability</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("sms-settings")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "sms-settings"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Smartphone className="w-4 h-4 text-cyan-500" />
          <span>24h SMS Reminders ({smsSettings.walletBalance} Credits)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("performance-metrics")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "performance-metrics"
              ? "bg-teal-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Award className="w-4 h-4 text-amber-400" />
          <span>Performance & Revenue</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("ai-copilot")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "ai-copilot"
              ? "bg-gradient-to-r from-teal-700 to-indigo-700 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>AI Disease Co-Pilot</span>
        </button>
      </div>

      {/* TAB 1: FIELD CONSULTATION TICKETS */}
      {activeTab === "tickets" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Tickets Master List */}
          <div className="lg:col-span-5 space-y-4">
            {/* Search & Filters */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Search farm, crop, or symptoms..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold outline-none focus:bg-white focus:border-teal-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none cursor-pointer"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="Open">Open</option>
                  <option value="In Analysis">In Analysis</option>
                  <option value="Prescribed">Prescribed</option>
                  <option value="Resolved">Resolved</option>
                </select>

                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none cursor-pointer"
                >
                  <option value="ALL">All Categories</option>
                  <option value="Pest & Disease Outbreak">Pest & Disease</option>
                  <option value="Soil Fertility & Fertilizer">Soil Fertility</option>
                  <option value="Water Quality & Irrigation">Irrigation & Water</option>
                  <option value="Plant Population & Yield">Plant Population</option>
                  <option value="General Agronomy">General Agronomy</option>
                </select>
              </div>
            </div>

            {/* List Cards */}
            <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
              {filteredConsultations.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-500 text-xs font-medium">
                  No consultation tickets match your search filters.
                </div>
              ) : (
                filteredConsultations.map((item) => {
                  const isSelected = selectedTicket?.id === item.id;
                  return (
                    <div
                      key={item.id}
                      onClick={() => setSelectedTicket(item)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer text-left space-y-2 ${
                        isSelected
                          ? "bg-teal-50/80 border-teal-500 shadow-md ring-1 ring-teal-500/20"
                          : "bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50"
                      }`}
                    >
                      <div className="flex justify-between items-start gap-2">
                        <div>
                          <span className="text-[10px] font-black uppercase text-teal-700 bg-teal-100 px-2 py-0.5 rounded-full border border-teal-200">
                            {item.category}
                          </span>
                          <h4 className="text-xs font-black text-slate-900 mt-1">
                            {item.farmName}
                          </h4>
                          <div className="text-[11px] font-bold text-slate-600">
                            {item.farmerName} • <span className="text-slate-500">{item.cropType}</span>
                          </div>
                        </div>

                        <span
                          className={`text-[9.5px] font-black uppercase px-2 py-0.5 rounded border shrink-0 ${
                            item.status === "Prescribed" || item.status === "Resolved"
                              ? "bg-emerald-100 text-emerald-800 border-emerald-300"
                              : item.status === "In Analysis"
                              ? "bg-blue-100 text-blue-800 border-blue-300"
                              : "bg-amber-100 text-amber-800 border-amber-300"
                          }`}
                        >
                          {item.status}
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-600 line-clamp-2 font-medium">
                        "{item.symptomsDescription}"
                      </p>

                      <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 pt-1 border-t border-slate-100">
                        <span>Block: {item.fieldBlock || "N/A"}</span>
                        <span>Date: {item.date}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right Column: Ticket Detailed Inspector & Actions */}
          <div className="lg:col-span-7">
            {selectedTicket ? (
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6 text-left">
                {/* Header */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black uppercase bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200">
                        Case ID: #{selectedTicket.id}
                      </span>
                      <span
                        className={`text-[10px] font-black uppercase px-2 py-0.5 rounded border ${
                          selectedTicket.severity === "Critical"
                            ? "bg-rose-100 text-rose-800 border-rose-300"
                            : selectedTicket.severity === "High"
                            ? "bg-amber-100 text-amber-800 border-amber-300"
                            : "bg-slate-100 text-slate-800 border-slate-200"
                        }`}
                      >
                        Severity: {selectedTicket.severity}
                      </span>
                    </div>
                    <h2 className="text-base font-black text-slate-900 mt-1">
                      {selectedTicket.farmName}
                    </h2>
                    <p className="text-xs font-semibold text-slate-500">
                      Farmer: {selectedTicket.farmerName} ({selectedTicket.farmerPhone})
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowPrescriptionModal(true)}
                      className="px-3 py-1.5 bg-teal-800 hover:bg-teal-700 text-white font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <FileText className="w-3.5 h-3.5 text-teal-300" />
                      <span>{selectedTicket.prescription ? "Edit Prescription" : "Issue Prescription"}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setShowSoilTestModal(true)}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <Droplets className="w-3.5 h-3.5 text-cyan-600" />
                      <span>{selectedTicket.soilTest ? "Update Lab Log" : "Add Soil Test"}</span>
                    </button>
                  </div>
                </div>

                {/* Crop & Problem Overview */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                  <div>
                    <span className="text-[10px] font-black uppercase text-slate-400 block">Target Crop</span>
                    <span className="font-bold text-slate-900">{selectedTicket.cropType}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase text-slate-400 block">Field Block / Plot</span>
                    <span className="font-bold text-slate-900">{selectedTicket.fieldBlock || "General Block"}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase text-slate-400 block">Assigned Agronomist</span>
                    <span className="font-bold text-slate-900">{selectedTicket.agronomistName || "Unassigned"}</span>
                  </div>
                </div>

                {/* Symptoms Description */}
                <div className="space-y-1.5">
                  <h4 className="text-xs font-black uppercase text-slate-700 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    <span>Farmer Observed Symptoms & Field Case Description</span>
                  </h4>
                  <div className="bg-amber-50/60 border border-amber-200/80 p-3.5 rounded-xl text-xs font-medium text-amber-950 leading-relaxed">
                    "{selectedTicket.symptomsDescription}"
                  </div>
                </div>

                {/* Soil & Nutrient Laboratory Log (If Present) */}
                {selectedTicket.soilTest && (
                  <div className="space-y-2 border-t border-slate-100 pt-4">
                    <h4 className="text-xs font-black uppercase text-slate-700 flex items-center gap-1.5">
                      <Microscope className="w-4 h-4 text-cyan-600" />
                      <span>Soil & Plant Tissue Laboratory Test Log</span>
                    </h4>

                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 bg-cyan-50/50 p-3 rounded-xl border border-cyan-200/60 text-center text-xs">
                      <div className="p-2 bg-white rounded-lg border border-cyan-100">
                        <span className="text-[9px] font-black uppercase text-slate-400 block">pH Level</span>
                        <span className="text-sm font-black text-cyan-950">{selectedTicket.soilTest.ph}</span>
                      </div>
                      <div className="p-2 bg-white rounded-lg border border-cyan-100">
                        <span className="text-[9px] font-black uppercase text-slate-400 block">Nitrogen (N)</span>
                        <span className="text-sm font-black text-cyan-950">{selectedTicket.soilTest.nitrogenPpm} ppm</span>
                      </div>
                      <div className="p-2 bg-white rounded-lg border border-cyan-100">
                        <span className="text-[9px] font-black uppercase text-slate-400 block">Phosphorus (P)</span>
                        <span className="text-sm font-black text-cyan-950">{selectedTicket.soilTest.phosphorusPpm} ppm</span>
                      </div>
                      <div className="p-2 bg-white rounded-lg border border-cyan-100">
                        <span className="text-[9px] font-black uppercase text-slate-400 block">Potassium (K)</span>
                        <span className="text-sm font-black text-cyan-950">{selectedTicket.soilTest.potassiumPpm} ppm</span>
                      </div>
                      <div className="p-2 bg-white rounded-lg border border-cyan-100 col-span-2 sm:col-span-1">
                        <span className="text-[9px] font-black uppercase text-slate-400 block">Org Matter</span>
                        <span className="text-sm font-black text-cyan-950">{selectedTicket.soilTest.organicMatterPercent}%</span>
                      </div>
                    </div>

                    <p className="text-[11px] font-semibold text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                      💡 <strong>Lab Advice:</strong> {selectedTicket.soilTest.recommendation}
                    </p>
                  </div>
                )}

                {/* Official Prescription Voucher (If Present) */}
                {selectedTicket.prescription ? (
                  <div className="space-y-3 bg-emerald-50/80 border border-emerald-300 p-4 rounded-2xl text-xs space-y-2">
                    <div className="flex justify-between items-center border-b border-emerald-200 pb-2">
                      <div className="flex items-center gap-1.5 font-black text-emerald-950 uppercase text-xs">
                        <ShieldCheck className="w-4 h-4 text-emerald-600" />
                        <span>Certified Agronomic Prescription Voucher</span>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300">
                        ZEMA Regulatory Compliant
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-emerald-950">
                      <div>
                        <span className="text-[9.5px] font-black uppercase text-emerald-800 block">Prescribed Product</span>
                        <span className="font-extrabold text-xs text-emerald-950">{selectedTicket.prescription.productName}</span>
                      </div>
                      <div>
                        <span className="text-[9.5px] font-black uppercase text-emerald-800 block">Active Ingredient</span>
                        <span className="font-semibold text-xs">{selectedTicket.prescription.activeIngredient}</span>
                      </div>
                      <div>
                        <span className="text-[9.5px] font-black uppercase text-emerald-800 block">Application Rate & Dosage</span>
                        <span className="font-bold text-xs">{selectedTicket.prescription.dosage}</span>
                      </div>
                      <div>
                        <span className="text-[9.5px] font-black uppercase text-emerald-800 block">Safety Withdrawal Period</span>
                        <span className="font-extrabold text-xs text-rose-700">
                          {selectedTicket.prescription.withdrawalPeriodDays} Days Before Harvest
                        </span>
                      </div>
                    </div>

                    <div className="bg-white/80 p-2.5 rounded-xl border border-emerald-200/80 text-[11px] text-emerald-950">
                      <strong>Application Instructions & Safety:</strong> {selectedTicket.prescription.safetyInstructions}
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-slate-50 border border-dashed border-slate-300 rounded-xl text-center space-y-2">
                    <p className="text-xs font-semibold text-slate-500">
                      No prescription has been issued yet for this consultation case.
                    </p>
                    <button
                      type="button"
                      onClick={() => setShowPrescriptionModal(true)}
                      className="px-3.5 py-1.5 bg-teal-800 hover:bg-teal-700 text-white font-black text-xs rounded-lg transition-all cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5 text-teal-300" />
                      <span>Generate Agronomic Prescription Now</span>
                    </button>
                  </div>
                )}

                {/* On-Site Farm Visit Schedule & 24h SMS Reminder Status */}
                <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200/80 pb-2.5">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-teal-700" />
                      <span className="font-extrabold text-xs text-slate-900">
                        On-Site Farm Visit Schedule & 24h SMS Reminder
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {selectedTicket.smsReminderSent ? (
                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-full text-[10.5px] font-black flex items-center gap-1">
                          <Smartphone className="w-3 h-3 text-emerald-600" />
                          24h SMS Reminder Sent
                        </span>
                      ) : selectedTicket.scheduledVisitDate ? (
                        <span className="px-2.5 py-1 bg-amber-100 text-amber-800 border border-amber-300 rounded-full text-[10.5px] font-black flex items-center gap-1">
                          <Clock className="w-3 h-3 text-amber-600" />
                          24h SMS Scheduled
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 bg-slate-200 text-slate-700 rounded-full text-[10.5px] font-bold">
                          No Visit Scheduled
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <span className="text-[9.5px] font-black uppercase text-slate-400 block">Scheduled Visit Date</span>
                      <span className="font-bold text-slate-900">{selectedTicket.scheduledVisitDate || "Not Scheduled"}</span>
                    </div>
                    <div>
                      <span className="text-[9.5px] font-black uppercase text-slate-400 block">Assigned Time Slot</span>
                      <span className="font-bold text-teal-800">{selectedTicket.timeSlot || "08:30 AM - 10:30 AM"}</span>
                    </div>
                    <div>
                      <span className="text-[9.5px] font-black uppercase text-slate-400 block">Visit Consultation Fee</span>
                      <span className="font-extrabold text-slate-900">{currencySymbol} {selectedTicket.visitFee || 350}</span>
                    </div>
                    <div>
                      <span className="text-[9.5px] font-black uppercase text-slate-400 block">SMS Dispatch Status</span>
                      <span className="font-semibold text-slate-700">
                        {selectedTicket.smsReminderSent
                          ? `Dispatched (${new Date(selectedTicket.smsReminderSentAt || "").toLocaleDateString()})`
                          : "Pending 24h Trigger"}
                      </span>
                    </div>
                  </div>

                  {!selectedTicket.smsReminderSent && selectedTicket.scheduledVisitDate && (
                    <div className="flex justify-end pt-1">
                      <button
                        type="button"
                        onClick={handleTriggerSmsSweep}
                        className="px-3 py-1.5 bg-cyan-800 hover:bg-cyan-700 text-white font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                      >
                        <Smartphone className="w-3.5 h-3.5 text-cyan-300" />
                        <span>Dispatch 24h Visit SMS Reminder Now (1 Credit)</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Post-Visit Farmer Rating & Feedback System */}
                <div className="bg-amber-50/40 border border-amber-200 p-4 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between border-b border-amber-200/60 pb-2">
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                      <span className="font-extrabold text-xs text-amber-950">
                        Farmer Post-Visit Rating & Agronomist Review
                      </span>
                    </div>

                    {selectedTicket.rating ? (
                      <div className="flex items-center gap-1 text-amber-700 font-extrabold text-xs bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-300">
                        <span>{selectedTicket.rating} / 5 Stars</span>
                      </div>
                    ) : (
                      <span className="text-[10px] font-black uppercase text-slate-400 bg-white px-2 py-0.5 rounded border border-slate-200">
                        Pending Farmer Feedback
                      </span>
                    )}
                  </div>

                  {selectedTicket.rating ? (
                    <div className="space-y-1.5 text-xs">
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-4 h-4 ${
                              star <= (selectedTicket.rating || 0)
                                ? "text-amber-500 fill-amber-500"
                                : "text-slate-300"
                            }`}
                          />
                        ))}
                        <span className="text-xs font-bold text-slate-700 ml-1">
                          Submitted on {new Date(selectedTicket.ratedAt || "").toLocaleDateString()}
                        </span>
                      </div>
                      {selectedTicket.ratingComment && (
                        <p className="text-slate-700 font-medium italic bg-white p-2.5 rounded-xl border border-amber-100">
                          "{selectedTicket.ratingComment}"
                        </p>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center justify-between bg-white p-3 rounded-xl border border-amber-200">
                      <p className="text-xs font-medium text-slate-600">
                        Completed or prescribed farm visit? Farmers can rate the agronomist 1-5 stars and submit feedback.
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setRatingTicket(selectedTicket);
                          setRatingStars(5);
                          setRatingCommentText("");
                          setShowRatingModal(true);
                        }}
                        className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
                      >
                        <Star className="w-3.5 h-3.5 fill-slate-950" />
                        <span>Rate Farm Visit</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-400 text-xs font-medium">
                Select a consultation ticket from the list to view field details, lab logs, and prescriptions.
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: SOIL & TISSUE LAB LOGS */}
      {activeTab === "diagnostics" && (
        <div className="space-y-4">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 text-left">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-black text-slate-900">Soil & Leaf Tissue Laboratory Diagnostic Registry</h3>
                <p className="text-xs text-slate-500 font-medium">
                  Track macro/micronutrient parameters (pH, N, P, K, Organic Carbon, EC) across registered client field blocks.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  if (selectedTicket) setShowSoilTestModal(true);
                  else alert("Please select or create a consultation ticket first.");
                }}
                className="px-3.5 py-2 bg-cyan-700 hover:bg-cyan-600 text-white text-xs font-black rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Log Soil Test Entry</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-semibold">
                <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="p-3">Farm & Field Block</th>
                    <th className="p-3">Target Crop</th>
                    <th className="p-3">pH Level</th>
                    <th className="p-3">Nitrogen (N)</th>
                    <th className="p-3">Phosphorus (P)</th>
                    <th className="p-3">Potassium (K)</th>
                    <th className="p-3">Org Carbon</th>
                    <th className="p-3">Agronomic Assessment</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {consultations.filter(c => c.soilTest).map((c) => (
                    <tr key={c.id} className="hover:bg-slate-50">
                      <td className="p-3">
                        <div className="font-black text-slate-900">{c.farmName}</div>
                        <div className="text-[10px] text-slate-500">{c.fieldBlock || "Block A"}</div>
                      </td>
                      <td className="p-3 font-bold text-slate-700">{c.cropType}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded font-black text-[11px] ${c.soilTest!.ph < 6.0 ? "bg-amber-100 text-amber-900" : "bg-emerald-100 text-emerald-900"}`}>
                          {c.soilTest!.ph}
                        </span>
                      </td>
                      <td className="p-3 text-slate-900">{c.soilTest!.nitrogenPpm} ppm</td>
                      <td className="p-3 text-slate-900">{c.soilTest!.phosphorusPpm} ppm</td>
                      <td className="p-3 text-slate-900">{c.soilTest!.potassiumPpm} ppm</td>
                      <td className="p-3 text-slate-900">{c.soilTest!.organicMatterPercent}%</td>
                      <td className="p-3 text-slate-600 max-w-xs truncate">{c.soilTest!.recommendation}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: AGRONOMIC PRESCRIPTIONS */}
      {activeTab === "prescriptions" && (
        <div className="space-y-4">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 text-left">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-black text-slate-900">Official Certified Prescription Vouchers</h3>
                <p className="text-xs text-slate-500 font-medium">
                  ZEMA-regulated chemical and organic intervention prescriptions issued to client farmers.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {consultations.filter(c => c.prescription).map((c) => (
                <div key={c.id} className="p-4 bg-emerald-50/50 border border-emerald-200 rounded-2xl space-y-3">
                  <div className="flex justify-between items-start border-b border-emerald-200 pb-2">
                    <div>
                      <span className="text-[9.5px] font-black uppercase text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                        Voucher #{c.id}
                      </span>
                      <h4 className="text-sm font-black text-slate-900 mt-1">{c.farmName}</h4>
                      <p className="text-[11px] font-semibold text-slate-600">Farmer: {c.farmerName} • {c.cropType}</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="p-1.5 bg-white hover:bg-slate-100 rounded-lg border border-emerald-300 text-emerald-800 font-bold text-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Print Voucher</span>
                    </button>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-800">
                    <div className="font-extrabold text-emerald-950">Product: {c.prescription!.productName}</div>
                    <div className="text-[11px] text-slate-600">Active Ingredient: {c.prescription!.activeIngredient}</div>
                    <div className="font-bold text-teal-900">Dosage: {c.prescription!.dosage}</div>
                    <div className="text-rose-800 font-bold bg-rose-50 px-2 py-1 rounded border border-rose-200 inline-block text-[10.5px]">
                      ⚠️ Safety Withdrawal Period: {c.prescription!.withdrawalPeriodDays} Days
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: AGRONOMIC TASK TEMPLATES */}
      {activeTab === "task-templates" && (
        <div className="space-y-6 text-left">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <CheckSquare className="w-5 h-5 text-teal-600" />
                  Standardized Agronomic Task Templates
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Create, store, and share crop-specific task protocols for farmers to ensure consistency in agricultural practices across tenant groups.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowTaskTemplateModal(true)}
                className="px-4 py-2 bg-teal-800 hover:bg-teal-700 text-white font-black text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-xs shrink-0"
              >
                <Plus className="w-4 h-4 text-teal-300" />
                <span>Create Task Template</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {taskTemplates.map((tmpl) => (
                <div key={tmpl.id} className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-4 hover:border-teal-300 transition-all">
                  <div className="flex justify-between items-start gap-2">
                    <span className="px-2.5 py-0.5 bg-teal-100 text-teal-900 font-black uppercase text-[10px] rounded-full border border-teal-200">
                      {tmpl.category}
                    </span>
                    <span className={`px-2 py-0.5 font-bold uppercase text-[9.5px] rounded ${
                      tmpl.priority === "Urgent" ? "bg-rose-100 text-rose-800" : "bg-slate-200 text-slate-700"
                    }`}>
                      {tmpl.priority}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-sm font-black text-slate-900">{tmpl.title}</h4>
                    <p className="text-xs text-slate-500 font-semibold mt-0.5">
                      Crop: <strong className="text-slate-800">{tmpl.cropType}</strong> ({tmpl.targetStage})
                    </p>
                  </div>

                  <p className="text-xs text-slate-600 font-medium line-clamp-2">
                    {tmpl.description}
                  </p>

                  <div className="space-y-2 border-t border-slate-200 pt-3">
                    <span className="text-[10px] font-black uppercase text-slate-400 block">Protocol Steps ({tmpl.steps.length})</span>
                    <div className="space-y-1.5">
                      {tmpl.steps.map((st) => (
                        <div key={st.stepNumber} className="bg-white p-2 rounded-lg border border-slate-200 text-xs flex justify-between items-center">
                          <span className="font-bold text-slate-800">{st.stepNumber}. {st.title}</span>
                          <span className="text-[10px] text-slate-500 font-semibold">Day +{st.triggerDaysOffset}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 flex justify-between items-center text-[10px] text-slate-400 font-bold border-t border-slate-200">
                    <span>By: {tmpl.createdBy}</span>
                    <button
                      type="button"
                      onClick={() => alert(`Assigned template "${tmpl.title}" to client farmers!`)}
                      className="px-3 py-1 bg-teal-600 hover:bg-teal-500 text-white rounded-lg font-black text-xs transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <Share2 className="w-3 h-3" />
                      <span>Assign To Farmers</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: SMS BROADCAST ALERTS */}
      {activeTab === "sms-alerts" && (
        <div className="space-y-6 text-left">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Radio className="w-5 h-5 text-amber-500" />
                  SMS Outbreak & Advisory Broadcast Gateway
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Dispatch instant pest outbreak alerts, weather warnings, and topdressing notices directly to registered farmers in your advisory groups.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowSmsModal(true)}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-xs shrink-0"
              >
                <Send className="w-4 h-4" />
                <span>Send Broadcast Alert</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {smsAlerts.map((b) => (
                <div key={b.id} className="p-5 bg-amber-50/40 border border-amber-200 rounded-2xl space-y-3">
                  <div className="flex justify-between items-start border-b border-amber-200/60 pb-2">
                    <div>
                      <span className="px-2 py-0.5 bg-amber-100 text-amber-900 font-black text-[9.5px] uppercase rounded border border-amber-300">
                        {b.alertType}
                      </span>
                      <h4 className="text-xs font-black text-slate-900 mt-1">To: {b.recipientGroup}</h4>
                    </div>

                    <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300">
                      {b.status} • {b.deliveredCount} Delivered
                    </span>
                  </div>

                  <p className="text-xs text-slate-800 font-medium leading-relaxed bg-white p-3 rounded-xl border border-amber-200/80">
                    "{b.messageContent}"
                  </p>

                  <div className="flex justify-between items-center text-[10px] font-bold text-slate-500">
                    <span>Sender: {b.senderName}</span>
                    <span>Sent: {new Date(b.sentAt).toLocaleString()} ({b.smsParts} Parts)</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: PDF SUMMARY REPORTS */}
      {activeTab === "pdf-reports" && (
        <div className="space-y-6 text-left">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Download className="w-5 h-5 text-emerald-600" />
                  Farmer Advisory Summary PDF Export Generator
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Compile complete advisory interaction logs, field progress notes, soil diagnostic tests, and task completion records into an official PDF document.
                </p>
              </div>

              <button
                type="button"
                onClick={() => window.print()}
                className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
              >
                <Printer className="w-4 h-4 text-emerald-300" />
                <span>Export / Print PDF Summary</span>
              </button>
            </div>

            {/* Filter controls */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Target Client Farm</label>
                <select
                  value={reportFarmFilter}
                  onChange={(e) => setReportFarmFilter(e.target.value)}
                  className="w-full p-2 bg-white border border-slate-200 rounded-lg font-bold text-slate-800"
                >
                  <option value="ALL">All Client Farms Summary</option>
                  {consultations.map((c) => (
                    <option key={c.id} value={c.farmName}>{c.farmName}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2 pt-4">
                <input
                  type="checkbox"
                  id="chkNotes"
                  checked={reportIncludeNotes}
                  onChange={(e) => setReportIncludeNotes(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300"
                />
                <label htmlFor="chkNotes" className="font-bold text-slate-700">Include Progress Notes</label>
              </div>

              <div className="flex items-center gap-2 pt-4">
                <input
                  type="checkbox"
                  id="chkTasks"
                  checked={reportIncludeTasks}
                  onChange={(e) => setReportIncludeTasks(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300"
                />
                <label htmlFor="chkTasks" className="font-bold text-slate-700">Include Task Completion</label>
              </div>

              <div className="flex items-center gap-2 pt-4">
                <input
                  type="checkbox"
                  id="chkSoil"
                  checked={reportIncludeSoil}
                  onChange={(e) => setReportIncludeSoil(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300"
                />
                <label htmlFor="chkSoil" className="font-bold text-slate-700">Include Soil Diagnostic Logs</label>
              </div>
            </div>

            {/* Document Print Layout Preview */}
            <div className="border border-slate-300 bg-white p-8 rounded-2xl shadow-inner space-y-6 max-w-4xl mx-auto print:border-none print:shadow-none print:p-0">
              {/* Document Header */}
              <div className="flex justify-between items-start border-b-2 border-teal-800 pb-4">
                <div>
                  <div className="text-xl font-black text-teal-950 uppercase tracking-tight">MABALA AGRONOMY SERVICES</div>
                  <div className="text-xs font-bold text-teal-700">Official Farmer Field Advisory & Agronomic Performance Summary</div>
                  <div className="text-[10px] text-slate-500 mt-1">Generated: {new Date().toLocaleDateString()} • Ref: MBL-ADV-LOG-2026</div>
                </div>

                <div className="text-right text-xs text-slate-600 space-y-0.5">
                  <div className="font-black text-slate-900">Dr. Kelvin Mulenga, MSc Agronomy</div>
                  <div>Certified Crop Protection Specialist</div>
                  <div className="text-[10px] text-teal-800 font-bold">Zambia / SADC Agronomy Registry</div>
                </div>
              </div>

              {/* Summary Stats Header */}
              <div className="grid grid-cols-3 gap-4 bg-teal-50/50 p-4 rounded-xl border border-teal-100 text-center text-xs">
                <div>
                  <span className="text-[10px] font-black text-slate-400 uppercase block">Consultations Logged</span>
                  <span className="text-base font-black text-teal-950">{consultations.length} Cases</span>
                </div>
                <div>
                  <span className="text-[10px] font-black text-slate-400 uppercase block">Prescriptions Issued</span>
                  <span className="text-base font-black text-emerald-950">{consultations.filter(c => c.prescription).length} Certified</span>
                </div>
                <div>
                  <span className="text-[10px] font-black text-slate-400 uppercase block">Task Completion Compliance</span>
                  <span className="text-base font-black text-indigo-950">92.4%</span>
                </div>
              </div>

              {/* Section 1: Advisory Consultations */}
              <div className="space-y-3">
                <h4 className="text-xs font-black uppercase text-teal-900 border-b border-slate-200 pb-1">
                  1. Field Consultation Cases & Diagnoses
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-[11px] font-semibold border border-slate-200">
                    <thead className="bg-slate-100 text-slate-700 uppercase text-[9px]">
                      <tr>
                        <th className="p-2 border-b">Date</th>
                        <th className="p-2 border-b">Farm & Farmer</th>
                        <th className="p-2 border-b">Crop & Block</th>
                        <th className="p-2 border-b">Category & Diagnosis</th>
                        <th className="p-2 border-b">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {consultations
                        .filter((c) => reportFarmFilter === "ALL" || c.farmName === reportFarmFilter)
                        .map((c) => (
                          <tr key={c.id}>
                            <td className="p-2">{c.date}</td>
                            <td className="p-2 font-bold">{c.farmName} ({c.farmerName})</td>
                            <td className="p-2">{c.cropType} - {c.fieldBlock || "Block A"}</td>
                            <td className="p-2">{c.symptomsDescription}</td>
                            <td className="p-2 font-bold text-teal-800">{c.status}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Section 2: Progress Notes & Task Completion */}
              {reportIncludeNotes && (
                <div className="space-y-3">
                  <h4 className="text-xs font-black uppercase text-teal-900 border-b border-slate-200 pb-1">
                    2. Farmer Progress Notes & Field Task Completion Records
                  </h4>
                  <div className="space-y-2">
                    {progressNotes.map((pn) => (
                      <div key={pn.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs flex justify-between items-center">
                        <div>
                          <div className="font-bold text-slate-900">{pn.farmName} • {pn.noteType} ({pn.date})</div>
                          <div className="text-[11px] text-slate-600 mt-0.5">{pn.summary}</div>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 rounded font-black text-[10px]">
                            Tasks: {pn.completedTasksCount}/{pn.totalTasksCount} ({pn.status})
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Sign-off Footer */}
              <div className="pt-6 border-t border-slate-200 flex justify-between items-end text-[11px] text-slate-500 font-semibold">
                <div>
                  <div>Mabala Cloud Platform Agronomic Services</div>
                  <div>Official Document Signature Code: MBL-SIG-883920</div>
                </div>

                <div className="text-right space-y-1">
                  <div className="font-bold text-slate-900">Agronomist Seal & Certification</div>
                  <div className="w-32 h-8 border-b-2 border-slate-400 inline-block"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: AGRONOMIST PERFORMANCE & REVENUE METRICS */}
      {activeTab === "performance-metrics" && (
        <div className="space-y-6 text-left">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="border-b border-slate-100 pb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Award className="w-5 h-5 text-amber-500" />
                  Agronomist Performance & Revenue Metrics Dashboard
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Track client farmer retention, yield uplift statistics, visit revenue distribution, and service fee splits.
                </p>
              </div>

              {/* Metrics Sub-Tab Switcher */}
              <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200">
                <button
                  type="button"
                  onClick={() => setMetricsSubTab("overview")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                    metricsSubTab === "overview"
                      ? "bg-white text-slate-900 shadow-xs"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <BarChart3 className="w-3.5 h-3.5 text-teal-600" />
                  <span>Overview & KPIs</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMetricsSubTab("revenue")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                    metricsSubTab === "revenue"
                      ? "bg-teal-900 text-white shadow-xs"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <PieChartIcon className="w-3.5 h-3.5 text-amber-400" />
                  <span>Revenue Distribution</span>
                </button>
              </div>
            </div>

            {/* SUB-TAB 1: OVERVIEW & KPIS */}
            {metricsSubTab === "overview" && (
              <>
                <div className="flex justify-end">
                  <span className="px-3 py-1 bg-amber-100 text-amber-900 font-black text-xs rounded-full border border-amber-300 flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                    <span>Rating: {PERFORMANCE_METRICS_DATA.farmerRating} / 5.0 ({PERFORMANCE_METRICS_DATA.totalReviews} Reviews)</span>
                  </span>
                </div>

                {/* Core KPI Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="p-5 bg-gradient-to-br from-teal-50 to-emerald-50 border border-teal-200 rounded-2xl space-y-2">
                    <div className="flex justify-between items-center text-teal-800 text-xs font-bold">
                      <span>Farmers Managed</span>
                      <Users className="w-4 h-4 text-teal-600" />
                    </div>
                    <div className="text-2xl font-black text-teal-950">{PERFORMANCE_METRICS_DATA.farmersManaged} Farmers</div>
                    <p className="text-[10.5px] font-semibold text-teal-700">{PERFORMANCE_METRICS_DATA.totalHectaresManaged} Total Hectares</p>
                  </div>

                  <div className="p-5 bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-200 rounded-2xl space-y-2">
                    <div className="flex justify-between items-center text-indigo-800 text-xs font-bold">
                      <span>Average Response Time</span>
                      <Zap className="w-4 h-4 text-indigo-600" />
                    </div>
                    <div className="text-2xl font-black text-indigo-950">{PERFORMANCE_METRICS_DATA.avgResponseHours} Hours</div>
                    <p className="text-[10.5px] font-semibold text-indigo-700">Target: &lt; 2.0 Hours (98% SLA)</p>
                  </div>

                  <div className="p-5 bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200 rounded-2xl space-y-2">
                    <div className="flex justify-between items-center text-amber-800 text-xs font-bold">
                      <span>Client Harvest Yield Uplift</span>
                      <TrendingUp className="w-4 h-4 text-amber-600" />
                    </div>
                    <div className="text-2xl font-black text-amber-950">+{PERFORMANCE_METRICS_DATA.clientHarvestUpliftPercent}%</div>
                    <p className="text-[10.5px] font-semibold text-amber-700">Compared to regional baseline</p>
                  </div>

                  <div className="p-5 bg-gradient-to-br from-emerald-50 to-green-50 border border-emerald-200 rounded-2xl space-y-2">
                    <div className="flex justify-between items-center text-emerald-800 text-xs font-bold">
                      <span>Prescription Compliance</span>
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    </div>
                    <div className="text-2xl font-black text-emerald-950">{PERFORMANCE_METRICS_DATA.prescriptionCompliancePercent}%</div>
                    <p className="text-[10.5px] font-semibold text-emerald-700">ZEMA & Withdrawal Period Followed</p>
                  </div>
                </div>

                {/* Performance breakdown list */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                  <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
                    <h4 className="text-xs font-black uppercase text-slate-800 flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-teal-600" />
                      Crop Focus & Hectare Allocation
                    </h4>

                    <div className="space-y-2">
                      {PERFORMANCE_METRICS_DATA.topCropsHandled.map((crop, idx) => (
                        <div key={crop} className="space-y-1">
                          <div className="flex justify-between text-xs font-bold text-slate-700">
                            <span>{crop}</span>
                            <span>{[95, 62, 45, 28, 18.5][idx]} Ha</span>
                          </div>
                          <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                            <div
                              className="bg-teal-700 h-full rounded-full"
                              style={{ width: `${100 - idx * 18}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
                    <h4 className="text-xs font-black uppercase text-slate-800 flex items-center gap-2">
                      <Target className="w-4 h-4 text-indigo-600" />
                      Client Success Outcomes & Satisfaction Ratings
                    </h4>

                    <div className="space-y-3 text-xs font-semibold text-slate-700">
                      <div className="p-3 bg-white rounded-xl border border-slate-200 flex justify-between items-center">
                        <div>
                          <div className="font-bold text-slate-900">Total Consultation Cases Solved</div>
                          <div className="text-[11px] text-slate-500">58 Cases logged in 2026</div>
                        </div>
                        <span className="text-sm font-black text-teal-800">{PERFORMANCE_METRICS_DATA.ticketsResolvedRate}% Solved</span>
                      </div>

                      <div className="p-3 bg-white rounded-xl border border-slate-200 flex justify-between items-center">
                        <div>
                          <div className="font-bold text-slate-900">Soil Laboratory Diagnostic Audit</div>
                          <div className="text-[11px] text-slate-500">100% field blocks tested pre-planting</div>
                        </div>
                        <span className="text-sm font-black text-emerald-800">Complete</span>
                      </div>

                      <div className="p-3 bg-white rounded-xl border border-slate-200 flex justify-between items-center">
                        <div>
                          <div className="font-bold text-slate-900">SMS Outbreak Alert Delivery Rate</div>
                          <div className="text-[11px] text-slate-500">Zero missed pest warnings in Q2</div>
                        </div>
                        <span className="text-sm font-black text-amber-800">100% Reach</span>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* SUB-TAB 2: REVENUE DISTRIBUTION (PIE CHART & FINANCIAL BREAKDOWN) */}
            {metricsSubTab === "revenue" && (
              <div className="space-y-6">
                {/* Revenue KPI Summary */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="p-5 bg-white text-slate-900 rounded-2xl space-y-2 border border-slate-200 shadow-2xs">
                    <div className="flex justify-between items-center text-slate-500 text-xs font-bold">
                      <span>Total Gross Visit Revenue</span>
                      <div className="p-1.5 rounded-lg bg-teal-50 text-teal-700">
                        <DollarSign className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-slate-900">
                      {currencySymbol} {((consultations.length + 37) * 350).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                    <p className="text-[10.5px] text-slate-500 font-medium">From {consultations.length + 37} Completed Farm Visits</p>
                  </div>

                  <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-2">
                    <div className="flex justify-between items-center text-emerald-800 text-xs font-bold">
                      <span>Agronomist Net Share (85%)</span>
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    </div>
                    <div className="text-2xl font-black text-emerald-950">
                      {currencySymbol} {(((consultations.length + 37) * 350) * 0.85).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                    <p className="text-[10.5px] text-emerald-700 font-semibold">Direct Earnings Payout</p>
                  </div>

                  <div className="p-5 bg-amber-50 border border-amber-200 rounded-2xl space-y-2">
                    <div className="flex justify-between items-center text-amber-800 text-xs font-bold">
                      <span>Mabala Platform Fee (15%)</span>
                      <Percent className="w-4 h-4 text-amber-600" />
                    </div>
                    <div className="text-2xl font-black text-amber-950">
                      {currencySymbol} {(((consultations.length + 37) * 350) * 0.15).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                    <p className="text-[10.5px] text-amber-700 font-semibold">Platform & Lab Maintenance Fee</p>
                  </div>

                  <div className="p-5 bg-cyan-50 border border-cyan-200 rounded-2xl space-y-2">
                    <div className="flex justify-between items-center text-cyan-800 text-xs font-bold">
                      <span>SMS Gateway Reserve</span>
                      <Smartphone className="w-4 h-4 text-cyan-600" />
                    </div>
                    <div className="text-2xl font-black text-cyan-950">
                      {currencySymbol} 450.00
                    </div>
                    <p className="text-[10.5px] text-cyan-700 font-semibold">{smsSettings.walletBalance} Purchased SMS Credits</p>
                  </div>
                </div>

                {/* Pie Chart Visualization */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center bg-slate-50 p-6 rounded-2xl border border-slate-200">
                  <div className="lg:col-span-7 h-72">
                    <h4 className="text-xs font-black uppercase text-slate-800 mb-2 flex items-center gap-2">
                      <PieChartIcon className="w-4 h-4 text-amber-500" />
                      Revenue Distribution Split (Pie Chart)
                    </h4>
                    <ResponsiveContainer width="100%" height="90%">
                      <PieChart>
                        <Pie
                          data={[
                            { name: "Agronomist Net Share (85%)", value: ((consultations.length + 37) * 350) * 0.85, color: "#0d9488" },
                            { name: "Mabala Platform Fee (15%)", value: ((consultations.length + 37) * 350) * 0.15, color: "#f59e0b" },
                            { name: "SMS Gateway Reserve", value: 450, color: "#3b82f6" }
                          ]}
                          cx="50%"
                          cy="50%"
                          innerRadius={65}
                          outerRadius={95}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {[
                            { color: "#0d9488" },
                            { color: "#f59e0b" },
                            { color: "#3b82f6" }
                          ].map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <RechartsTooltip
                          formatter={(val: number) => [`${currencySymbol} ${val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, "Amount"]}
                        />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="lg:col-span-5 space-y-3 border-t lg:border-t-0 lg:border-l border-slate-200 pt-4 lg:pt-0 lg:pl-6 text-xs">
                    <h4 className="font-black text-slate-900 uppercase">Fee Split Distribution Model</h4>
                    <p className="text-slate-600 leading-relaxed font-medium">
                      For every on-site farm visit booked and completed via the Advisory Services Panel, revenue is automatically distributed:
                    </p>
                    <ul className="space-y-2">
                      <li className="flex items-center justify-between p-2.5 bg-teal-50 border border-teal-200 rounded-xl font-bold text-teal-950">
                        <span className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-teal-600 inline-block"></span>
                          Agronomist Direct Earnings
                        </span>
                        <span className="font-extrabold text-teal-800">85%</span>
                      </li>
                      <li className="flex items-center justify-between p-2.5 bg-amber-50 border border-amber-200 rounded-xl font-bold text-amber-950">
                        <span className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block"></span>
                          Mabala Platform & Lab Fee
                        </span>
                        <span className="font-extrabold text-amber-800">15%</span>
                      </li>
                      <li className="flex items-center justify-between p-2.5 bg-blue-50 border border-blue-200 rounded-xl font-bold text-blue-950">
                        <span className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block"></span>
                          SMS Outbreak Gateway Reserve
                        </span>
                        <span className="font-extrabold text-blue-800">Dedicated Wallet</span>
                      </li>
                    </ul>
                  </div>
                </div>

                {/* Individual Visit Ledger Table */}
                <div className="space-y-3">
                  <h4 className="text-xs font-black uppercase text-slate-800">Completed On-Site Visit Revenue Ledger</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-semibold">
                      <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] border-b border-slate-200">
                        <tr>
                          <th className="p-3">Visit Ref / Farm</th>
                          <th className="p-3">Farmer Name</th>
                          <th className="p-3">Scheduled Date</th>
                          <th className="p-3">Gross Visit Fee</th>
                          <th className="p-3">Agronomist (85%)</th>
                          <th className="p-3">Platform Fee (15%)</th>
                          <th className="p-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {consultations.map((c) => {
                          const fee = c.visitFee || 350;
                          return (
                            <tr key={c.id} className="hover:bg-slate-50">
                              <td className="p-3 font-bold text-slate-900">
                                #{c.id} • {c.farmName}
                              </td>
                              <td className="p-3 text-slate-700">{c.farmerName}</td>
                              <td className="p-3 text-slate-600">{c.scheduledVisitDate || c.date}</td>
                              <td className="p-3 font-extrabold text-slate-900">{currencySymbol} {fee}</td>
                              <td className="p-3 font-extrabold text-teal-700">{currencySymbol} {(fee * 0.85).toFixed(2)}</td>
                              <td className="p-3 font-extrabold text-amber-700">{currencySymbol} {(fee * 0.15).toFixed(2)}</td>
                              <td className="p-3">
                                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[10px] font-extrabold">
                                  {c.status}
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 8: AI AGRONOMIST CO-PILOT */}
      {activeTab === "ai-copilot" && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6 text-left">
          <div className="border-b border-slate-100 pb-3 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-600" />
            <div>
              <h3 className="text-base font-black text-slate-900">AI Agronomist Disease & Deficiency Diagnostic Engine</h3>
              <p className="text-xs text-slate-500 font-medium">
                Enter crop symptoms, foliage signs, or environmental stress indicators to trigger intelligent agronomic diagnostics.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Crop Variety</label>
              <select
                value={aiCrop}
                onChange={(e) => setAiCrop(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900"
              >
                <option value="Maize">Maize (Hybrid / Commercial)</option>
                <option value="Red Onion">Red Onion (Texas Early Grano)</option>
                <option value="Hass Avocado">Hass Avocado Orchards</option>
                <option value="Tomato">Tomato (Determinate / Indeterminate)</option>
                <option value="Soya Beans">Soya Beans</option>
                <option value="Wheat">Irrigated Winter Wheat</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Growth Stage</label>
              <select
                value={aiStage}
                onChange={(e) => setAiStage(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900"
              >
                <option value="Emergence / Seedling">Emergence / Seedling</option>
                <option value="Vegetative V6">Vegetative (Active Foliage)</option>
                <option value="Flowering / Tasseling">Flowering / Tasseling</option>
                <option value="Fruiting / Bulb Expansion">Fruit Set / Bulb Expansion</option>
                <option value="Maturation / Pre-Harvest">Maturation / Pre-Harvest</option>
              </select>
            </div>

            <div className="md:col-span-3">
              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Observed Symptoms & Field Notes</label>
              <textarea
                rows={3}
                value={aiSymptomInput}
                onChange={(e) => setAiSymptomInput(e.target.value)}
                placeholder="e.g. Concentric purple water-soaked rings on mature onion foliage tips after heavy rain..."
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold outline-none focus:bg-white focus:border-teal-500"
              />
            </div>
          </div>

          <button
            type="button"
            disabled={isAiLoading || !aiSymptomInput.trim()}
            onClick={handleRunAiDiagnosis}
            className="px-6 py-3 bg-gradient-to-r from-teal-700 to-indigo-700 hover:from-teal-600 hover:to-indigo-600 text-white font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isAiLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4 text-amber-300" />}
            <span>{isAiLoading ? "Analyzing Symptoms with AI..." : "Run AI Agronomic Diagnosis"}</span>
          </button>

          {aiAnalysisResult && (
            <div className="bg-teal-50/70 border border-teal-300 p-5 rounded-2xl space-y-3">
              <div className="flex justify-between items-center border-b border-teal-200 pb-2">
                <span className="font-black text-teal-950 text-sm">{aiAnalysisResult.suspectedDiagnosis}</span>
                <span className="px-2.5 py-0.5 bg-teal-800 text-white text-[10px] font-black rounded-full">
                  Confidence: {aiAnalysisResult.confidenceScore}
                </span>
              </div>

              <div className="text-xs text-slate-800 space-y-2 font-medium">
                <p><strong>Pathogen / Root Cause:</strong> {aiAnalysisResult.pathogenClass}</p>
                <p><strong>Cultural Control:</strong> {aiAnalysisResult.culturalControl}</p>
                <div>
                  <strong>Recommended Chemical Controls:</strong>
                  <ul className="list-disc list-inside mt-1 space-y-0.5 font-bold text-teal-900">
                    {aiAnalysisResult.recommendedChemicals?.map((c: any, idx: number) => (
                      <li key={idx}>{c.name} — Rate: {c.rate} (Interval: {c.interval})</li>
                    ))}
                  </ul>
                </div>
                <p className="text-[11px] text-amber-900 font-bold bg-amber-100 p-2 rounded border border-amber-300">
                  ⚠️ {aiAnalysisResult.zemaRegulatoryNote}
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 9: AGRONOMIST AVAILABILITY CALENDAR */}
      {activeTab === "availability-calendar" && (
        <div className="space-y-6 text-left">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-teal-600" />
                  Agronomist Availability & On-Site Visit Calendar Widget
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Farmers can view open time slots on the agronomist schedule and book on-site field visits directly.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowAddSlotModal(true)}
                className="px-4 py-2.5 bg-teal-800 hover:bg-teal-700 text-white font-black text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                <Plus className="w-4 h-4 text-teal-300" />
                <span>Publish Open Visit Slot</span>
              </button>
            </div>

            {/* Date Pill Selector */}
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-slate-400 block">Select Schedule Date</label>
              <div className="flex items-center gap-2 overflow-x-auto pb-2">
                {["2026-08-07", "2026-08-08", "2026-08-09", "2026-08-10", "2026-08-11"].map((dStr) => {
                  const slotsForDay = availabilitySlots.filter((s) => s.date === dStr);
                  const openCount = slotsForDay.filter((s) => s.status === "Available").length;
                  const isSel = selectedCalendarDate === dStr;
                  return (
                    <button
                      key={dStr}
                      type="button"
                      onClick={() => setSelectedCalendarDate(dStr)}
                      className={`px-4 py-3 rounded-2xl text-xs font-black transition-all cursor-pointer flex flex-col items-center min-w-[110px] border ${
                        isSel
                          ? "bg-teal-900 text-white border-teal-900 shadow-md"
                          : "bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200"
                      }`}
                    >
                      <span className="text-[10px] opacity-80 uppercase">
                        {new Date(dStr).toLocaleDateString(undefined, { weekday: "short" })}
                      </span>
                      <span className="text-sm font-black mt-0.5">{dStr.slice(5)}</span>
                      <span className={`text-[9.5px] font-bold mt-1 px-2 py-0.5 rounded-full ${
                        isSel ? "bg-teal-800 text-teal-200" : "bg-teal-100 text-teal-900"
                      }`}>
                        {openCount} Open Slot{openCount !== 1 ? "s" : ""}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Time Slots Grid */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-black uppercase text-slate-800 flex items-center justify-between">
                <span>Time Slots for {selectedCalendarDate}</span>
                <span className="text-[11px] text-slate-500 font-normal">Standard Visit Fee: {currencySymbol} 350.00</span>
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {availabilitySlots
                  .filter((s) => s.date === selectedCalendarDate)
                  .map((slot) => (
                    <div
                      key={slot.id}
                      className={`p-5 rounded-2xl border text-xs space-y-3 transition-all ${
                        slot.status === "Available"
                          ? "bg-emerald-50/50 border-emerald-300 shadow-xs"
                          : slot.status === "Booked"
                          ? "bg-slate-50 border-slate-300 opacity-90"
                          : "bg-slate-100 border-slate-200 text-slate-400"
                      }`}
                    >
                      <div className="flex justify-between items-start border-b border-slate-200/80 pb-2">
                        <div>
                          <span className="font-black text-sm text-slate-900 block flex items-center gap-1.5">
                            <Clock className="w-4 h-4 text-teal-600" />
                            {slot.timeSlot}
                          </span>
                          <span className="text-[10px] font-bold text-slate-500">{slot.locationDistrict}</span>
                        </div>

                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase border ${
                            slot.status === "Available"
                              ? "bg-emerald-100 text-emerald-900 border-emerald-300"
                              : slot.status === "Booked"
                              ? "bg-indigo-100 text-indigo-900 border-indigo-300"
                              : "bg-slate-200 text-slate-700 border-slate-300"
                          }`}
                        >
                          {slot.status}
                        </span>
                      </div>

                      <div className="space-y-1 text-slate-700">
                        <div><strong>Agronomist:</strong> {slot.agronomistName}</div>
                        <div><strong>On-Site Fee:</strong> {currencySymbol} {slot.visitFee || 350}</div>
                        {slot.bookedByFarmerName && (
                          <div className="text-indigo-900 font-bold bg-indigo-50 p-2 rounded-lg border border-indigo-100 mt-1">
                            👤 Booked by: {slot.bookedByFarmerName} ({slot.bookedByFarmName})
                          </div>
                        )}
                      </div>

                      {slot.status === "Available" ? (
                        <button
                          type="button"
                          onClick={() => {
                            setBookingSlot(slot);
                            setShowBookingModal(true);
                          }}
                          className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-black text-xs rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Book On-Site Visit Slot ({currencySymbol} {slot.visitFee || 350})</span>
                        </button>
                      ) : slot.status === "Booked" ? (
                        <div className="text-center text-[10.5px] font-bold text-indigo-800 bg-indigo-50/80 py-1.5 rounded-lg border border-indigo-200">
                          ✓ Confirmed Farm Visit Scheduled
                        </div>
                      ) : (
                        <div className="text-center text-[10.5px] font-bold text-slate-500 bg-slate-200/60 py-1.5 rounded-lg">
                          🔒 Time Slot Reserved / Blocked
                        </div>
                      )}
                    </div>
                  ))}

                {availabilitySlots.filter((s) => s.date === selectedCalendarDate).length === 0 && (
                  <div className="col-span-full p-8 text-center bg-slate-50 border border-dashed border-slate-300 rounded-2xl text-slate-500 font-medium">
                    No open availability slots published for {selectedCalendarDate}. Click "Publish Open Visit Slot" above to add time slots.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 10: 24h SMS REMINDER SETTINGS */}
      {activeTab === "sms-settings" && (
        <div className="space-y-6 text-left">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-cyan-600" />
                  Automated 24-Hour Visit SMS Reminder Account Settings
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Automatically notify client farmers 24 hours prior to scheduled agronomist farm visits using credits in your SMS wallet.
                </p>
              </div>

              {/* Enable / Disable Feature Toggle */}
              <div className="flex items-center gap-3 bg-slate-50 p-2.5 rounded-2xl border border-slate-200">
                <span className="text-xs font-black text-slate-800">24h SMS Service Status:</span>
                <button
                  type="button"
                  onClick={() =>
                    setSmsSettings((prev) => ({ ...prev, enabled: !prev.enabled }))
                  }
                  className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shadow-xs ${
                    smsSettings.enabled
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-300 text-slate-700"
                  }`}
                >
                  {smsSettings.enabled ? (
                    <>
                      <ToggleRight className="w-4 h-4" />
                      <span>ENABLED (Active)</span>
                    </>
                  ) : (
                    <>
                      <ToggleLeft className="w-4 h-4" />
                      <span>DISABLED</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Wallet & Gateway Metrics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-5 bg-white text-slate-900 rounded-2xl space-y-2 shadow-2xs border border-slate-200">
                <div className="flex justify-between items-center text-slate-500 text-xs font-bold">
                  <span>Agronomist SMS Wallet Balance</span>
                  <div className="p-1.5 rounded-lg bg-cyan-50 text-cyan-700">
                    <CreditCard className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-black text-slate-900">{smsSettings.walletBalance} SMS Credits</div>
                <button
                  type="button"
                  onClick={() => setShowSmsTopUpModal(true)}
                  className="mt-2 w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl transition-all cursor-pointer shadow-xs flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Purchase SMS Credit Bundle</span>
                </button>
              </div>

              <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-2">
                <div className="flex justify-between items-center text-emerald-800 text-xs font-bold">
                  <span>Total 24h Reminders Sent</span>
                  <BellRing className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-2xl font-black text-emerald-950">{smsSettings.totalRemindersSent} SMS Dispatches</div>
                <p className="text-[10.5px] font-semibold text-emerald-700">1 Credit Deducted per Scheduled Visit</p>
              </div>

              <div className="p-5 bg-amber-50 border border-amber-200 rounded-2xl space-y-2">
                <div className="flex justify-between items-center text-amber-800 text-xs font-bold">
                  <span>Pending Visits Awaiting SMS</span>
                  <Clock className="w-4 h-4 text-amber-600" />
                </div>
                <div className="text-2xl font-black text-amber-950">
                  {consultations.filter((c) => c.scheduledVisitDate && !c.smsReminderSent).length} Visits
                </div>
                <button
                  type="button"
                  onClick={handleTriggerSmsSweep}
                  className="mt-1 w-full py-1.5 bg-cyan-800 hover:bg-cyan-700 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1"
                >
                  <Smartphone className="w-3.5 h-3.5 text-cyan-300" />
                  <span>Trigger 24h SMS Sweep Now</span>
                </button>
              </div>
            </div>

            {/* Template Editor */}
            <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
              <h4 className="text-xs font-black uppercase text-slate-800 flex items-center justify-between">
                <span>Automated 24h SMS Reminder Message Template</span>
                <span className="text-[11px] text-slate-500 font-normal">Variables: &#123;agronomistName&#125;, &#123;visitDate&#125;, &#123;timeSlot&#125;</span>
              </h4>

              <textarea
                rows={3}
                value={smsSettings.smsTemplate}
                onChange={(e) => setSmsSettings((prev) => ({ ...prev, smsTemplate: e.target.value }))}
                className="w-full p-3 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:ring-2 focus:ring-teal-500"
              />

              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500 font-medium">
                  Estimated length: {smsSettings.smsTemplate.length} chars ({Math.ceil(smsSettings.smsTemplate.length / 160)} SMS segment)
                </span>
                <button
                  type="button"
                  onClick={() => alert("✅ SMS Template updated and saved to agronomist settings.")}
                  className="px-4 py-2 bg-teal-800 text-white font-black text-xs rounded-xl hover:bg-teal-700 cursor-pointer"
                >
                  Save SMS Template Settings
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: New Field Consultation */}
      {showNewTicketModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl border border-slate-200 text-left">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900">Log Field Consultation Ticket</h3>
              <button type="button" onClick={() => setShowNewTicketModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTicket} className="space-y-3 text-xs">
              {farms && farms.length > 0 && (
                <div>
                  <label className="font-bold text-teal-900 block mb-1">Pick Active Registered Mabala Farm</label>
                  <select
                    onChange={(e) => {
                      const selectedVal = e.target.value;
                      if (!selectedVal) return;
                      const found = farms.find(f => f.name === selectedVal || f.id === selectedVal);
                      if (found) {
                        setNewFarmName(found.name || "");
                        setNewFarmerName(found.name || "");
                        setNewFarmerPhone(found.phone || "");
                        setNewFieldBlock(found.district ? `${found.district}, ${found.province || ""}` : (found.address || ""));
                      }
                    }}
                    className="w-full p-2.5 bg-teal-50/60 border border-teal-200 rounded-xl font-bold text-teal-950 mb-2"
                  >
                    <option value="">-- Choose active registered farm on Mabala --</option>
                    {farms.map((f, idx) => (
                      <option key={f.id || idx} value={f.name}>
                        {f.name} {f.district ? `(${f.district})` : ""}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="font-bold text-slate-700 block mb-1">Farm Name</label>
                <input
                  type="text"
                  required
                  value={newFarmName}
                  onChange={(e) => setNewFarmName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Farmer Name</label>
                  <input
                    type="text"
                    required
                    value={newFarmerName}
                    onChange={(e) => setNewFarmerName(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Farmer Phone</label>
                  <input
                    type="text"
                    value={newFarmerPhone}
                    onChange={(e) => setNewFarmerPhone(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Crop Type</label>
                  <input
                    type="text"
                    value={newCropType}
                    onChange={(e) => setNewCropType(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Field Block / Plot</label>
                  <input
                    type="text"
                    value={newFieldBlock}
                    onChange={(e) => setNewFieldBlock(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  >
                    <option value="Pest & Disease Outbreak">Pest & Disease</option>
                    <option value="Soil Fertility & Fertilizer">Soil Fertility</option>
                    <option value="Water Quality & Irrigation">Water Quality</option>
                    <option value="Plant Population & Yield">Plant Population</option>
                    <option value="General Agronomy">General Agronomy</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Severity Level</label>
                  <select
                    value={newSeverity}
                    onChange={(e) => setNewSeverity(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Critical">Critical</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Symptoms & Field Observations</label>
                <textarea
                  required
                  rows={3}
                  value={newSymptoms}
                  onChange={(e) => setNewSymptoms(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewTicketModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-800 text-white font-black rounded-xl"
                >
                  Save Consultation Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Issue Prescription */}
      {showPrescriptionModal && selectedTicket && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl border border-slate-200 text-left">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900">Issue Certified Prescription Voucher</h3>
              <button type="button" onClick={() => setShowPrescriptionModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleIssuePrescription} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Product Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mancozeb 800 WP"
                  value={pProductName}
                  onChange={(e) => setPProductName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Active Ingredient</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mancozeb 800g/kg"
                    value={pActiveIngredient}
                    onChange={(e) => setPActiveIngredient(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Application Dosage</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 2.0 kg / ha"
                    value={pDosage}
                    onChange={(e) => setPDosage(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Application Method & Timing</label>
                <input
                  type="text"
                  placeholder="e.g. Foliar spray during early mornings. Repeat in 7 days."
                  value={pApplicationMethod}
                  onChange={(e) => setPApplicationMethod(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Pre-Harvest Safety Days</label>
                  <input
                    type="number"
                    value={pWithdrawalDays}
                    onChange={(e) => setPWithdrawalDays(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Safety Precautions</label>
                  <input
                    type="text"
                    placeholder="e.g. Gloves, full respirator"
                    value={pSafety}
                    onChange={(e) => setPSafety(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPrescriptionModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-800 text-white font-black rounded-xl"
                >
                  Sign & Issue Voucher
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Soil Test Log */}
      {showSoilTestModal && selectedTicket && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl border border-slate-200 text-left">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900">Log Soil & Tissue Test</h3>
              <button type="button" onClick={() => setShowSoilTestModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSoilTest} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Soil pH Level</label>
                  <input
                    type="number"
                    step="0.1"
                    value={sPh}
                    onChange={(e) => setSPh(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Nitrogen (PPM)</label>
                  <input
                    type="number"
                    value={sNitrogen}
                    onChange={(e) => setSNitrogen(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Phosphorus (PPM)</label>
                  <input
                    type="number"
                    value={sPhosphorus}
                    onChange={(e) => setSPhosphorus(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Potassium (PPM)</label>
                  <input
                    type="number"
                    value={sPotassium}
                    onChange={(e) => setSPotassium(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Agronomic Lab Recommendation</label>
                <textarea
                  rows={2}
                  value={sRecommendation}
                  onChange={(e) => setSRecommendation(e.target.value)}
                  placeholder="e.g. Apply 1.5 Tons Agricultural Lime per Ha pre-planting..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowSoilTestModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-cyan-800 text-white font-black rounded-xl"
                >
                  Save Soil Test Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Create Task Template */}
      {showTaskTemplateModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl border border-slate-200 text-left">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900">Create Agronomic Task Template</h3>
              <button type="button" onClick={() => setShowTaskTemplateModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTaskTemplate} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Template Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Onion Purple Blotch Spray Routine"
                  value={tmplTitle}
                  onChange={(e) => setTmplTitle(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Crop Type</label>
                  <input
                    type="text"
                    value={tmplCrop}
                    onChange={(e) => setTmplCrop(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Target Stage</label>
                  <input
                    type="text"
                    value={tmplStage}
                    onChange={(e) => setTmplStage(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Protocol Description</label>
                <textarea
                  rows={2}
                  value={tmplDesc}
                  onChange={(e) => setTmplDesc(e.target.value)}
                  placeholder="Describe the agronomic goal and standard practice guidelines..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowTaskTemplateModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-800 text-white font-black rounded-xl"
                >
                  Save Task Template
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: SMS Broadcast */}
      {showSmsModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl border border-slate-200 text-left">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Radio className="w-5 h-5 text-amber-500" />
                Dispatch SMS Broadcast Alert
              </h3>
              <button type="button" onClick={() => setShowSmsModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendSmsBroadcast} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Alert Category</label>
                  <select
                    value={smsType}
                    onChange={(e) => setSmsType(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  >
                    <option value="Pest & Disease Outbreak">Pest & Disease Outbreak</option>
                    <option value="Weather & Frost Warning">Weather & Frost Warning</option>
                    <option value="Topdressing Schedule">Topdressing Schedule</option>
                    <option value="Field Advisory Training">Field Advisory Training</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Recipient Group</label>
                  <select
                    value={smsRecipientGroup}
                    onChange={(e) => setSmsRecipientGroup(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  >
                    <option value="All Managed Farmers">All Managed Farmers (34 Recipient Farmers)</option>
                    <option value="Chongwe Onion Growers Co-op">Chongwe Onion Growers (18 Farmers)</option>
                    <option value="Mazabuka Grain & Livestock Farmers">Mazabuka Grain Farmers (16 Farmers)</option>
                  </select>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-bold text-slate-700">SMS Message Content</label>
                  <span className="text-[10px] text-slate-500 font-bold">
                    {smsContent.length} / 160 Chars ({Math.ceil(smsContent.length / 160) || 1} Part)
                  </span>
                </div>
                <textarea
                  required
                  rows={4}
                  value={smsContent}
                  onChange={(e) => setSmsContent(e.target.value)}
                  placeholder="e.g. URGENT PEST ALERT: High fall armyworm counts detected in Chongwe. Spray Emamectin Benzoate 5% SG before sunset."
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-medium outline-none focus:border-amber-500"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowSmsModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSendingSms || !smsContent.trim()}
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl transition-all flex items-center gap-1.5"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSendingSms ? "Dispatching..." : "Send SMS Broadcast Now"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Post-Visit Farmer Rating & Feedback */}
      {showRatingModal && selectedTicket && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl border border-slate-200 text-left">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                <span>Submit Agronomist Visit Feedback</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowRatingModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <p className="font-bold text-slate-900">
                  {selectedTicket.farmName} ({selectedTicket.farmerName})
                </p>
                <p className="text-[11px] text-slate-500">
                  Visit Date: {selectedTicket.scheduledVisitDate || selectedTicket.date} • Agronomist: {selectedTicket.agronomistName || "Dr. Kelvin Mulenga"}
                </p>
              </div>

              <div>
                <label className="font-extrabold text-slate-700 block mb-2">1 - 5 Star Performance Rating</label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRatingStars(star)}
                      className="p-2 hover:scale-110 transition-all cursor-pointer"
                    >
                      <Star
                        className={`w-8 h-8 ${
                          star <= ratingStars
                            ? "text-amber-500 fill-amber-500"
                            : "text-slate-300 fill-slate-100"
                        }`}
                      />
                    </button>
                  ))}
                  <span className="ml-2 font-black text-sm text-amber-900">
                    {ratingStars} / 5 Stars
                  </span>
                </div>
              </div>

              <div>
                <label className="font-extrabold text-slate-700 block mb-1">Optional Farmer Feedback Comments</label>
                <textarea
                  rows={3}
                  value={ratingCommentText}
                  onChange={(e) => setRatingCommentText(e.target.value)}
                  placeholder="e.g. Excellent field diagnosis! Agronomist explained chemical application rates clearly and identified fall armyworm early."
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-medium outline-none focus:border-teal-600"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowRatingModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSubmitRating}
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Star className="w-4 h-4 fill-slate-950" />
                  <span>Submit Visit Rating</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Book On-Site Visit Slot */}
      {showBookingModal && bookingSlot && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl border border-slate-200 text-left">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-teal-600" />
                <span>Book On-Site Farm Visit</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowBookingModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-teal-50/70 border border-teal-200 rounded-2xl space-y-1 text-teal-950">
                <div className="font-black text-sm">{bookingSlot.date} @ {bookingSlot.timeSlot}</div>
                <div><strong>Agronomist:</strong> {bookingSlot.agronomistName}</div>
                <div><strong>Coverage District:</strong> {bookingSlot.locationDistrict}</div>
                <div><strong>Visit Fee:</strong> {currencySymbol} {bookingSlot.visitFee || 350}</div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Target Farm Name</label>
                <input
                  type="text"
                  value={bookingFarmName}
                  onChange={(e) => setBookingFarmName(e.target.value)}
                  placeholder="e.g. Chongwe Green Horizon Farm"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Farmer Name</label>
                  <input
                    type="text"
                    value={bookingFarmerName}
                    onChange={(e) => setBookingFarmerName(e.target.value)}
                    placeholder="e.g. Bwalya Chisanga"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Phone Number (SMS)</label>
                  <input
                    type="text"
                    value={bookingFarmerPhone}
                    onChange={(e) => setBookingFarmerPhone(e.target.value)}
                    placeholder="+260 977 442211"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Crop Type & Purpose of Visit</label>
                <input
                  type="text"
                  value={bookingCrop}
                  onChange={(e) => setBookingCrop(e.target.value)}
                  placeholder="e.g. Red Onion - Pest Diagnosis & Spray Calibration"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowBookingModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmBooking}
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-black rounded-xl transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Confirm Visit Booking ({currencySymbol} {bookingSlot.visitFee || 350})</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Publish Availability Slot */}
      {showAddSlotModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl border border-slate-200 text-left">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Plus className="w-5 h-5 text-teal-600" />
                <span>Publish Open Visit Availability Slot</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddSlotModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Date</label>
                <input
                  type="date"
                  value={newSlotDate}
                  onChange={(e) => setNewSlotDate(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Time Slot Window</label>
                <select
                  value={newSlotTime}
                  onChange={(e) => setNewSlotTime(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                >
                  <option value="08:30 AM - 10:30 AM">08:30 AM - 10:30 AM (Morning Field Visit)</option>
                  <option value="11:00 AM - 01:00 PM">11:00 AM - 01:00 PM (Mid-Day Field Visit)</option>
                  <option value="02:30 PM - 04:30 PM">02:30 PM - 04:30 PM (Afternoon Field Visit)</option>
                  <option value="05:00 PM - 06:30 PM">05:00 PM - 06:30 PM (Twilight Soil / Pest Walk)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Visit Fee ({currencySymbol})</label>
                  <input
                    type="number"
                    value={newSlotFee}
                    onChange={(e) => setNewSlotFee(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Coverage District</label>
                  <input
                    type="text"
                    value={newSlotLocation}
                    onChange={(e) => setNewSlotLocation(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddSlotModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleAddAvailabilitySlot}
                  className="px-5 py-2 bg-teal-800 hover:bg-teal-700 text-white font-black rounded-xl transition-all shadow-xs cursor-pointer"
                >
                  Publish Availability Slot
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Purchase SMS Credits */}
      {showSmsTopUpModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl border border-slate-200 text-left">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-cyan-600" />
                <span>Purchase Agronomist SMS Gateway Credits</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowSmsTopUpModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-600 font-medium">
                Choose an SMS bundle to top up your agronomist wallet. Credits are deducted automatically when 24h visit reminders or outbreak alerts are dispatched.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 text-center hover:border-cyan-500 transition-all">
                  <div className="font-extrabold text-slate-900">Starter Pack</div>
                  <div className="text-xl font-black text-cyan-800">50 Credits</div>
                  <div className="text-[11px] text-slate-500 font-bold">{currencySymbol} 150.00</div>
                  <button
                    type="button"
                    onClick={() => handleBuySmsCredits({ credits: 50, price: 150, name: "Starter Pack" })}
                    className="w-full py-2 bg-cyan-800 hover:bg-cyan-700 text-white font-black rounded-xl transition-all cursor-pointer"
                  >
                    Buy 50 Credits
                  </button>
                </div>

                <div className="p-4 bg-cyan-50 border border-cyan-300 rounded-2xl space-y-2 text-center relative shadow-xs">
                  <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-amber-500 text-slate-950 font-black text-[9px] uppercase px-2 py-0.5 rounded-full">
                    Best Value
                  </span>
                  <div className="font-extrabold text-slate-900 mt-1">Pro Advisory</div>
                  <div className="text-xl font-black text-cyan-950">150 Credits</div>
                  <div className="text-[11px] text-slate-600 font-bold">{currencySymbol} 400.00</div>
                  <button
                    type="button"
                    onClick={() => handleBuySmsCredits({ credits: 150, price: 400, name: "Pro Advisory" })}
                    className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl transition-all cursor-pointer shadow-xs"
                  >
                    Buy 150 Credits
                  </button>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 text-center hover:border-cyan-500 transition-all">
                  <div className="font-extrabold text-slate-900">Cooperative Pack</div>
                  <div className="text-xl font-black text-cyan-800">500 Credits</div>
                  <div className="text-[11px] text-slate-500 font-bold">{currencySymbol} 1,200.00</div>
                  <button
                    type="button"
                    onClick={() => handleBuySmsCredits({ credits: 500, price: 1200, name: "Cooperative Pack" })}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-black rounded-xl transition-all cursor-pointer"
                  >
                    Buy 500 Credits
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdvisoryServicesPanel;

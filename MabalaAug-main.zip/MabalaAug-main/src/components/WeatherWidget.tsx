import React, { useState, useEffect, useMemo } from "react";
import { 
  Sun, 
  Cloud, 
  CloudRain, 
  CloudLightning, 
  CloudSnow, 
  Wind, 
  Droplet, 
  Thermometer, 
  RefreshCw, 
  MapPin, 
  AlertCircle, 
  Compass,
  ArrowUpRight,
  Info,
  AlertTriangle,
  Flame,
  Zap,
  Activity,
  ShieldAlert,
  Search,
  Sprout,
  CheckCircle2,
  XCircle,
  Clock,
  Calendar,
  Sparkles,
  Sliders,
  Maximize2
} from "lucide-react";

export interface SevereAlert {
  id: string;
  title: string;
  severity: "Critical" | "Warning" | "Advisory";
  category: "Rain" | "Wind" | "Thermal" | "AirQuality";
  description: string;
  action: string;
  source: string;
  timestamp: string;
}

interface WeatherWidgetProps {
  onAlertsChange?: (alerts: SevereAlert[]) => void;
  farmLocationName?: string;
  farmLocation?: { lat: number; lng: number; source?: string };
  province?: string;
  district?: string;
}

export interface PresetLocation {
  name: string;
  region: string;
  lat: number;
  lon: number;
}

export const REGIONAL_FARM_NODES: PresetLocation[] = [
  { name: "Lusaka West (Mumbwa Road)", region: "Lusaka Province", lat: -15.4220, lon: 28.2000 },
  { name: "Lusaka (Central Hub)", region: "Lusaka Province", lat: -15.4167, lon: 28.2833 },
  { name: "Chongwe", region: "Lusaka Province", lat: -15.3292, lon: 28.7206 },
  { name: "Mazabuka", region: "Southern Province", lat: -15.8560, lon: 27.7480 },
  { name: "Mkushi Farming Block", region: "Central Province", lat: -13.6200, lon: 29.3900 },
  { name: "Kitwe", region: "Copperbelt", lat: -12.8024, lon: 28.2132 },
  { name: "Ndola", region: "Copperbelt", lat: -12.9587, lon: 28.6366 },
  { name: "Livingstone", region: "Southern Province", lat: -17.8419, lon: 25.8543 },
  { name: "Chipata", region: "Eastern Province", lat: -13.6333, lon: 32.6500 },
  { name: "Monze", region: "Southern Province", lat: -16.2700, lon: 27.4700 },
  { name: "Choma", region: "Southern Province", lat: -16.8065, lon: 26.9857 },
  { name: "Kasama", region: "Northern Province", lat: -10.2129, lon: 31.1808 },
  { name: "Solwezi", region: "North-Western Province", lat: -12.1688, lon: 26.3894 },
  { name: "Mansa", region: "Luapula Province", lat: -11.1998, lon: 28.8943 },
  { name: "Mongu", region: "Western Province", lat: -15.2484, lon: 23.1274 },
  { name: "Kabwe", region: "Central Province", lat: -14.4426, lon: 28.4510 },
  { name: "Serenje", region: "Central Province", lat: -13.2325, lon: 30.2352 },
  { name: "Petauke", region: "Eastern Province", lat: -14.2426, lon: 31.3253 },
];

interface HourlyForecastPoint {
  time: string;
  tempC: number;
  precipProb: number;
  windKm: number;
}

interface DailyForecastItem {
  dayName: string;
  dateStr: string;
  maxTemp: number;
  minTemp: number;
  code: number;
  precipSum: number;
}

interface WeatherData {
  temperature: number; // Celsius
  humidity: number; // %
  precipitation: number; // mm
  windSpeed: number; // km/h
  weatherCode: number;
  latitude: number;
  longitude: number;
  isRealLocation: boolean;
  city: string;
  region: string;
  forecastDailyMaxTemp?: number;
  forecastDailyMinTemp?: number;
  forecastDailyPrecipSum?: number;
  forecastDailyWindSum?: number;
  airQualityIndex?: number;
  pm2_5?: number;
  dust?: number;
  hourlyPoints: HourlyForecastPoint[];
  dailyItems: DailyForecastItem[];
}

export default function WeatherWidget({ onAlertsChange, farmLocationName, farmLocation, province, district }: WeatherWidgetProps) {
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [alerts, setAlerts] = useState<SevereAlert[]>([]);
  const [retryingGeo, setRetryingGeo] = useState<boolean>(false);
  
  // UI Tabs & Toggles
  const [tempUnit, setTempUnit] = useState<"C" | "F">("C");
  const [hourlyTab, setHourlyTab] = useState<"temp" | "precip" | "wind">("temp");
  const [selectedLocation, setSelectedLocation] = useState<PresetLocation>(REGIONAL_FARM_NODES[0]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLocationDropdownOpen, setIsLocationDropdownOpen] = useState(false);

  // Simulation controls
  const [simulationCategory, setSimulationCategory] = useState<"None" | "Flood" | "Gale" | "Frost" | "Heatwave" | "Dust">("None");

  const filteredLocations = useMemo(() => {
    if (!searchTerm.trim()) return REGIONAL_FARM_NODES;
    return REGIONAL_FARM_NODES.filter(loc => 
      loc.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      loc.region.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm]);

  const fetchWeather = async (lat: number, lon: number, isReal: boolean, cityName: string, regionName: string) => {
    try {
      setLoading(true);
      setError(null);

      // Open-Meteo Primary Forecast stream with hourly & daily data
      const primaryUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code&hourly=temperature_2m,precipitation_probability,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max&timezone=auto`;
      const airQualityUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=pm2_5,pm10,dust,european_aqi`;

      const [primaryRes, aqRes] = await Promise.allSettled([
        fetch(primaryUrl).then(res => res.ok ? res.json() : null),
        fetch(airQualityUrl).then(res => res.ok ? res.json() : null),
      ]);

      let temperature = 23.0;
      let humidity = 58;
      let precipitation = 0.0;
      let windSpeed = 11.0;
      let weatherCode = 0;
      let forecastDailyMaxTemp = 27.0;
      let forecastDailyMinTemp = 14.0;
      let forecastDailyPrecipSum = 0.0;
      let forecastDailyWindSum = 14.0;
      let airQualityIndex = 38;
      let pm2_5 = 8.0;
      let dust = 10.0;

      let hourlyPoints: HourlyForecastPoint[] = [];
      let dailyItems: DailyForecastItem[] = [];

      if (primaryRes.status === "fulfilled" && primaryRes.value) {
        const val = primaryRes.value;
        if (val.current) {
          temperature = val.current.temperature_2m ?? 23.0;
          humidity = val.current.relative_humidity_2m ?? 58;
          precipitation = val.current.precipitation ?? 0.0;
          windSpeed = val.current.wind_speed_10m ?? 11.0;
          weatherCode = val.current.weather_code ?? 0;
        }

        if (val.daily) {
          forecastDailyMaxTemp = val.daily.temperature_2m_max?.[0] ?? (temperature + 4);
          forecastDailyMinTemp = val.daily.temperature_2m_min?.[0] ?? (temperature - 6);
          forecastDailyPrecipSum = val.daily.precipitation_sum?.[0] ?? precipitation;
          forecastDailyWindSum = val.daily.wind_speed_10m_max?.[0] ?? windSpeed;

          // Build 7-day items
          const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
          const dates = val.daily.time || [];
          for (let i = 0; i < Math.min(7, dates.length); i++) {
            const dateObj = new Date(dates[i]);
            const dayName = i === 0 ? "Today" : days[dateObj.getDay()];
            dailyItems.push({
              dayName,
              dateStr: dates[i],
              maxTemp: Math.round(val.daily.temperature_2m_max[i] ?? 24),
              minTemp: Math.round(val.daily.temperature_2m_min[i] ?? 12),
              code: val.daily.weather_code[i] ?? 0,
              precipSum: val.daily.precipitation_sum[i] ?? 0
            });
          }
        }

        if (val.hourly && val.hourly.time) {
          // Take 8 sample hours across 24 hours (every 3 hrs)
          const nowIdx = new Date().getHours();
          const times = val.hourly.time;
          for (let i = nowIdx; i < Math.min(nowIdx + 24, times.length); i += 3) {
            const d = new Date(times[i]);
            const hours = d.getHours();
            const ampm = hours >= 12 ? 'pm' : 'am';
            const h12 = hours % 12 || 12;
            hourlyPoints.push({
              time: `${h12} ${ampm}`,
              tempC: Math.round(val.hourly.temperature_2m[i] ?? temperature),
              precipProb: Math.round(val.hourly.precipitation_probability?.[i] ?? 0),
              windKm: Math.round(val.hourly.wind_speed_10m?.[i] ?? windSpeed)
            });
          }
        }
      }

      // Fallback hourly points if empty
      if (hourlyPoints.length === 0) {
        hourlyPoints = [
          { time: "4 am", tempC: 12, precipProb: 0, windKm: 8 },
          { time: "7 am", tempC: 14, precipProb: 0, windKm: 10 },
          { time: "10 am", tempC: 20, precipProb: 10, windKm: 12 },
          { time: "1 pm", tempC: 25, precipProb: 20, windKm: 15 },
          { time: "4 pm", tempC: 24, precipProb: 10, windKm: 14 },
          { time: "7 pm", tempC: 19, precipProb: 0, windKm: 11 },
          { time: "10 pm", tempC: 16, precipProb: 0, windKm: 9 },
          { time: "1 am", tempC: 13, precipProb: 0, windKm: 7 }
        ];
      }

      // Fallback 7 daily items if empty
      if (dailyItems.length === 0) {
        dailyItems = [
          { dayName: "Today", dateStr: "2026-07-28", maxTemp: 25, minTemp: 12, code: 0, precipSum: 0 },
          { dayName: "Thu", dateStr: "2026-07-29", maxTemp: 26, minTemp: 13, code: 1, precipSum: 0 },
          { dayName: "Fri", dateStr: "2026-07-30", maxTemp: 24, minTemp: 11, code: 2, precipSum: 0.5 },
          { dayName: "Sat", dateStr: "2026-07-31", maxTemp: 22, minTemp: 10, code: 61, precipSum: 4.2 },
          { dayName: "Sun", dateStr: "2026-08-01", maxTemp: 23, minTemp: 11, code: 3, precipSum: 0.2 },
          { dayName: "Mon", dateStr: "2026-08-02", maxTemp: 25, minTemp: 12, code: 0, precipSum: 0 },
          { dayName: "Tue", dateStr: "2026-08-03", maxTemp: 27, minTemp: 14, code: 0, precipSum: 0 }
        ];
      }

      if (aqRes.status === "fulfilled" && aqRes.value && aqRes.value.current) {
        const val = aqRes.value.current;
        airQualityIndex = val.european_aqi ?? 38;
        pm2_5 = val.pm2_5 ?? 8.0;
        dust = val.dust ?? 10.0;
      }

      setWeather({
        temperature,
        humidity,
        precipitation,
        windSpeed,
        weatherCode,
        latitude: lat,
        longitude: lon,
        isRealLocation: isReal,
        city: cityName,
        region: regionName,
        forecastDailyMaxTemp,
        forecastDailyMinTemp,
        forecastDailyPrecipSum,
        forecastDailyWindSum,
        airQualityIndex,
        pm2_5,
        dust,
        hourlyPoints,
        dailyItems
      });
    } catch (err: any) {
      console.error("[WeatherWidget] Error querying Open-Meteo:", err);
      setError(err.message || "Failed to load meteorological stream");
    } finally {
      setLoading(false);
      setRetryingGeo(false);
    }
  };

  const handleSelectPreset = (preset: PresetLocation) => {
    setSelectedLocation(preset);
    setIsLocationDropdownOpen(false);
    fetchWeather(preset.lat, preset.lon, true, preset.name, preset.region);
  };

  const handleUseGPS = () => {
    setRetryingGeo(true);
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser environment.");
      setRetryingGeo(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        let latitude = pos.coords.latitude;
        let longitude = pos.coords.longitude;
        let locName = "My GPS Farm Station";
        let regionStr = "Precise GPS Node";

        // If coarse IP geolocation placed user in East Lusaka / Ibex Hill (lng > 28.27) while on Mumbwa Road / Lusaka West:
        if (longitude > 28.27 && latitude > -15.45 && latitude < -15.38) {
          latitude = -15.4220;
          longitude = 28.2000;
          locName = "Lusaka West (Mumbwa Road)";
          regionStr = "Refined Farm GPS";
        }

        const gpsLoc: PresetLocation = {
          name: locName,
          region: regionStr,
          lat: latitude,
          lon: longitude
        };
        setSelectedLocation(gpsLoc);
        fetchWeather(latitude, longitude, true, locName, regionStr);
      },
      (err) => {
        alert("GPS access failed: " + err.message + ". Snapping to Lusaka West (Mumbwa Road) station.");
        const fallbackLoc: PresetLocation = {
          name: "Lusaka West (Mumbwa Road)",
          region: "Lusaka Province",
          lat: -15.4220,
          lon: 28.2000
        };
        setSelectedLocation(fallbackLoc);
        fetchWeather(-15.4220, 28.2000, true, "Lusaka West (Mumbwa Road)", "Lusaka Province");
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  };

  useEffect(() => {
    // Check if user has a custom calibrated location in localStorage
    let activeLat = farmLocation?.lat;
    let activeLng = farmLocation?.lng;

    try {
      const savedLoc = localStorage.getItem("mabala_farm_location");
      if (savedLoc) {
        const parsed = JSON.parse(savedLoc);
        if (parsed.lat && parsed.lng) {
          activeLat = parsed.lat;
          activeLng = parsed.lng;
        }
      }
    } catch (e) {}

    if (activeLat && activeLng) {
      const nodeName = district || farmLocationName || "Calibrated Farm House Station";
      const regionName = province || "Lusaka West (Mumbwa Rd)";
      const customLoc: PresetLocation = {
        name: nodeName,
        region: regionName,
        lat: activeLat,
        lon: activeLng
      };
      setSelectedLocation(customLoc);
      fetchWeather(activeLat, activeLng, true, nodeName, regionName);
      return;
    }

    // If farmLocationName is passed from user profile, match preset
    if (farmLocationName) {
      const matched = REGIONAL_FARM_NODES.find(loc => 
        loc.name.toLowerCase().includes(farmLocationName.toLowerCase()) || 
        loc.region.toLowerCase().includes(farmLocationName.toLowerCase())
      );
      if (matched) {
        setSelectedLocation(matched);
        fetchWeather(matched.lat, matched.lon, true, matched.name, matched.region);
        return;
      }
    }
    fetchWeather(selectedLocation.lat, selectedLocation.lon, false, selectedLocation.name, selectedLocation.region);
  }, [farmLocation?.lat, farmLocation?.lng, province, district, farmLocationName]);

  // Listen for real-time location calibration events from GIS map
  useEffect(() => {
    const handleLocationUpdated = (e: any) => {
      if (e.detail?.lat && e.detail?.lng) {
        const lat = Number(e.detail.lat);
        const lon = Number(e.detail.lng);
        const customLoc: PresetLocation = {
          name: "Calibrated House Station",
          region: "Lusaka West (Mumbwa Rd)",
          lat,
          lon
        };
        setSelectedLocation(customLoc);
        fetchWeather(lat, lon, true, "Calibrated House Station", "Lusaka West");
      }
    };

    window.addEventListener("mabala_location_updated", handleLocationUpdated);
    return () => {
      window.removeEventListener("mabala_location_updated", handleLocationUpdated);
    };
  }, []);

  const generateAlertsList = (params: {
    temp: number;
    wind: number;
    precip: number;
    code: number;
    dailyMaxTemp?: number;
    dailyMinTemp?: number;
    dailyPrecipSum?: number;
    dailyWindMax?: number;
    aqi?: number;
    pm2_5?: number;
    dust?: number;
    sim?: typeof simulationCategory;
  }): SevereAlert[] => {
    const { temp, wind, precip, code, dailyMaxTemp, dailyMinTemp, dailyPrecipSum, dailyWindMax, aqi, pm2_5, dust, sim } = params;
    const list: SevereAlert[] = [];
    const timestampStr = new Date().toLocaleString();

    const finalPrecipSum = dailyPrecipSum !== undefined ? dailyPrecipSum : (precip * 6);
    const hasThunderstormCode = [95, 96, 99].includes(code);
    const hasHeavyRainCode = [65, 82].includes(code);

    if (sim === "Flood" || finalPrecipSum > 30 || hasThunderstormCode || hasHeavyRainCode) {
      list.push({
        id: "ALERT-FL-01",
        title: "Severe Flash Flood & Torrential Downpour Hazard",
        severity: "Critical",
        category: "Rain",
        description: `Torrential rainfall of ${(sim === "Flood" ? 45.5 : finalPrecipSum).toFixed(1)} mm is recorded or forecasted. Major convective thunderstorm activity active. High soil water-saturation index poses waterlogging threats to low-lying fields.`,
        action: "Immediately divert runoff ditches, seal bottom grain store doors, shut off water-pumping nodes, and move ground flock herds to elevated shelters.",
        source: "Mabala Severe Weather Warning Node",
        timestamp: timestampStr
      });
    }

    const finalWindMax = dailyWindMax !== undefined ? dailyWindMax : wind;
    if (sim === "Gale" || finalWindMax > 35) {
      list.push({
        id: "ALERT-WD-02",
        title: "High Crop Lodging & Gale-Force Wind Advisory",
        severity: "Warning",
        category: "Wind",
        description: `Extreme sustained wind gusts reaching ${(sim === "Gale" ? 48.2 : finalWindMax).toFixed(1)} km/h. Lodging danger for tall cereal crops (maize, pearl millet) and high structural fatigue on sheet structures.`,
        action: "Reinforce polythene greenhouse joints immediately, defer all direct tractor spraying routines to avoid drift, and safely latch broiler house windows.",
        source: "Agricultural Wind-Force Center",
        timestamp: timestampStr
      });
    }

    const finalMaxTemp = dailyMaxTemp !== undefined ? dailyMaxTemp : temp;
    if (sim === "Heatwave" || finalMaxTemp > 38) {
      list.push({
        id: "ALERT-TH-03",
        title: "Dangerous Thermal Stress & Crop Evapotranspiration Stage",
        severity: "Critical",
        category: "Thermal",
        description: `Critical temperature peak of ${(sim === "Heatwave" ? 41.2 : finalMaxTemp).toFixed(1)}°C. Elevating high livestock metabolic failure risks and extreme soil moisture vacuum ratios.`,
        action: "Increase aquaculture aerators (warm water drops oxygen fast). Turn on active misting nozzles in dairy stalls and feed sensitive layer-poultry in cooler hours.",
        source: "FAO Agrometeorological Advisory",
        timestamp: timestampStr
      });
    }

    const finalMinTemp = dailyMinTemp !== undefined ? dailyMinTemp : temp;
    if (sim === "Frost" || finalMinTemp < 2) {
      list.push({
        id: "ALERT-TH-04",
        title: "Hard Frost Crop Freezing Risk",
        severity: "Critical",
        category: "Thermal",
        description: `Nighttime cooling values expected to drop to ${(sim === "Frost" ? -1.5 : finalMinTemp).toFixed(1)}°C. Ice crystal formulation threatens leaves of tender tomatoes, peppers, and green beans.`,
        action: "Provide overhead canvas rows or crop shelter hoods. Carefully apply smoke smudge fire blankets on orchard windward edges to trap warm thermal layers.",
        source: "Global Frost Hazard Desk",
        timestamp: timestampStr
      });
    }

    const finalAqi = aqi !== undefined ? aqi : 35;
    const finalDust = dust !== undefined ? dust : 12;
    if (sim === "Dust" || finalAqi > 100 || finalDust > 60) {
      list.push({
        id: "ALERT-AQ-05",
        title: "Critical Inhaled Dust & Crop Particulate Advisory",
        severity: "Warning",
        category: "AirQuality",
        description: `Air Quality Index is alerting at ${(sim === "Dust" ? 185 : finalAqi)} points with active PM10/dust counts at ${(sim === "Dust" ? 120 : finalDust)} µg/m³. Threatens poultry respiratory tracks.`,
        action: "Equip machinery drivers with filter respirators. Minimize open tillage dry-dust runs. Keep chicks in covered coops to avoid bird dust-cough syndrome.",
        source: "Atmospheric Air Quality monitoring node",
        timestamp: timestampStr
      });
    }

    return list;
  };

  useEffect(() => {
    if (!weather) return;
    const computed = generateAlertsList({
      temp: weather.temperature,
      wind: weather.windSpeed,
      precip: weather.precipitation,
      code: weather.weatherCode,
      dailyMaxTemp: weather.forecastDailyMaxTemp,
      dailyMinTemp: weather.forecastDailyMinTemp,
      dailyPrecipSum: weather.forecastDailyPrecipSum,
      dailyWindMax: weather.forecastDailyWindSum,
      aqi: weather.airQualityIndex,
      pm2_5: weather.pm2_5,
      dust: weather.dust,
      sim: simulationCategory
    });
    setAlerts(computed);
    if (onAlertsChange) {
      onAlertsChange(computed);
    }
  }, [weather, simulationCategory]);

  const getWeatherMeta = (code: number) => {
    if ([0].includes(code)) {
      return { 
        text: "Clear & Sunny", 
        icon: <Sun className="w-12 h-12 text-amber-400 animate-[spin_40s_linear_infinite]" />, 
        bg: "from-amber-500/10 via-amber-100/30 to-slate-900/5",
        badgeColor: "bg-amber-100 text-amber-900 border-amber-300"
      };
    }
    if ([1, 2, 3].includes(code)) {
      return { 
        text: "Partly Cloudy", 
        icon: <Cloud className="w-12 h-12 text-sky-400" />, 
        bg: "from-sky-500/10 via-blue-100/30 to-slate-900/5",
        badgeColor: "bg-sky-100 text-sky-900 border-sky-300"
      };
    }
    if ([45, 48].includes(code)) {
      return { 
        text: "Foggy / Mist", 
        icon: <Cloud className="w-12 h-12 text-zinc-400 opacity-80" />, 
        bg: "from-zinc-500/10 via-zinc-100/30 to-slate-900/5",
        badgeColor: "bg-zinc-100 text-zinc-900 border-zinc-300"
      };
    }
    if ([51, 53, 54, 55, 56, 57, 61, 63, 65, 80, 81, 82].includes(code)) {
      return { 
        text: "Rain Showers", 
        icon: <CloudRain className="w-12 h-12 text-indigo-500 animate-bounce" />, 
        bg: "from-indigo-500/15 via-blue-100/40 to-slate-900/5",
        badgeColor: "bg-indigo-100 text-indigo-900 border-indigo-300"
      };
    }
    if ([95, 96, 99].includes(code)) {
      return { 
        text: "Thunderstorm", 
        icon: <CloudLightning className="w-12 h-12 text-amber-500" />, 
        bg: "from-rose-500/15 via-amber-100/40 to-slate-900/5",
        badgeColor: "bg-rose-100 text-rose-900 border-rose-300"
      };
    }
    return { 
      text: "Varying Conditions", 
      icon: <Cloud className="w-12 h-12 text-slate-400" />, 
      bg: "from-slate-500/10 via-slate-100/30 to-slate-900/5",
      badgeColor: "bg-slate-100 text-slate-900 border-slate-300"
    };
  };

  // Convert Temp helper
  const formatTemp = (celsius: number) => {
    if (tempUnit === "F") {
      return `${Math.round((celsius * 9/5) + 32)}°`;
    }
    return `${Math.round(celsius)}°`;
  };

  // Agronomy Activity Suitability Evaluator
  const getFarmerActivities = (tempC: number, windKm: number, precipMm: number, humidityPct: number) => {
    // 1. Planting & Tillage
    let planting: { status: "Optimal" | "Caution" | "Unsuitable"; label: string; details: string; color: string } = {
      status: "Optimal",
      label: "Highly Suitable",
      details: "Optimal soil moisture & temperature for seed placement and germinating crops.",
      color: "border-emerald-200 bg-emerald-50/60 text-emerald-900"
    };
    if (precipMm > 15) {
      planting = {
        status: "Unsuitable",
        label: "Unsuitable (Mud / Waterlogging)",
        details: "Excessive rainfall. Tractor compaction hazard and seed rot risk.",
        color: "border-rose-200 bg-rose-50/60 text-rose-900"
      };
    } else if (tempC > 34 || tempC < 10) {
      planting = {
        status: "Caution",
        label: "Moderate Caution",
        details: "Sub-optimal soil temperature for sensitive seed germination.",
        color: "border-amber-200 bg-amber-50/60 text-amber-900"
      };
    }

    // 2. Crop Spraying (Herbicides / Pesticides)
    let spraying: { status: "Optimal" | "Caution" | "Unsuitable"; label: string; details: string; color: string } = {
      status: "Optimal",
      label: "Favorable Spray Window",
      details: `Low wind speed (${windKm} km/h < 15 km/h limit), 0% chemical drift risk.`,
      color: "border-emerald-200 bg-emerald-50/60 text-emerald-900"
    };
    if (windKm > 15) {
      spraying = {
        status: "Unsuitable",
        label: "High Drift Hazard (Postpone)",
        details: `Elevated wind (${windKm} km/h). Defer chemical application to prevent off-target drift.`,
        color: "border-rose-200 bg-rose-50/60 text-rose-900"
      };
    } else if (precipMm > 0.5) {
      spraying = {
        status: "Unsuitable",
        label: "Rain Washout Warning",
        details: "Active precipitation will wash applied agrochemicals off foliage.",
        color: "border-rose-200 bg-rose-50/60 text-rose-900"
      };
    }

    // 3. Fertilizer Spreading
    let fertilizer: { status: "Optimal" | "Caution" | "Unsuitable"; label: string; details: string; color: string } = {
      status: "Optimal",
      label: "Recommended",
      details: "No heavy rainfall expected (minimal nutrient leaching / runoff hazard).",
      color: "border-emerald-200 bg-emerald-50/60 text-emerald-900"
    };
    if (precipMm > 20) {
      fertilizer = {
        status: "Unsuitable",
        label: "High Runoff Risk",
        details: "Heavy rain will wash top-dressed nitrogen into waterways.",
        color: "border-rose-200 bg-rose-50/60 text-rose-900"
      };
    }

    // 4. Livestock Grazing & Thermal Comfort
    let grazing: { status: "Optimal" | "Caution" | "Unsuitable"; label: string; details: string; color: string } = {
      status: "Optimal",
      label: "Safe Open Pasture Grazing",
      details: `Mild thermal environment. Low heat stress index for cattle & goats.`,
      color: "border-emerald-200 bg-emerald-50/60 text-emerald-900"
    };
    if (tempC > 33) {
      grazing = {
        status: "Caution",
        label: "High Heat Stress (Provide Shade)",
        details: "Elevated temperatures. Ensure shade shelters & fresh water tank refills.",
        color: "border-amber-200 bg-amber-50/60 text-amber-900"
      };
    } else if (tempC < 10) {
      grazing = {
        status: "Caution",
        label: "Chilly - Shelter Brooding Stock",
        details: "Chilly conditions. Provide warm bedding & windbreaks for young stock.",
        color: "border-blue-200 bg-blue-50/60 text-blue-900"
      };
    }

    // 5. Crop & Grain Sun-Drying
    let sunDrying: { status: "Optimal" | "Caution" | "Unsuitable"; label: string; details: string; color: string } = {
      status: "Optimal",
      label: "Ideal Solar Drying Window",
      details: `Relative humidity at ${humidityPct}% with dry ambient conditions for maize/groundnut drying.`,
      color: "border-emerald-200 bg-emerald-50/60 text-emerald-900"
    };
    if (precipMm > 0.1 || humidityPct > 80) {
      sunDrying = {
        status: "Unsuitable",
        label: "High Humidity / Moisture Risk",
        details: "High humidity or rain risk. Cover open drying tarps to avoid mold.",
        color: "border-amber-200 bg-amber-50/60 text-amber-900"
      };
    }

    return { planting, spraying, fertilizer, grazing, sunDrying };
  };

  const meta = weather ? getWeatherMeta(weather.weatherCode) : null;
  const farmerGuide = weather ? getFarmerActivities(weather.temperature, weather.windSpeed, weather.precipitation, weather.humidity) : null;

  // Format current day & time e.g., "Wednesday 3:00 am"
  const now = new Date();
  const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const currentDayName = daysOfWeek[now.getDay()];
  const currentHours = now.getHours();
  const currentAmpm = currentHours >= 12 ? 'pm' : 'am';
  const currentH12 = currentHours % 12 || 12;
  const currentMins = now.getMinutes().toString().padStart(2, '0');
  const formattedTimeStr = `${currentDayName} ${currentH12}:${currentMins} ${currentAmpm}`;

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden space-y-0 text-slate-800" id="meteorological-planning-weather-card">
      
      {/* TOP LOCATION CONTROL BAR */}
      <div className="p-4 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5 relative">
          <div className="p-2 bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 rounded-xl">
            <MapPin size={18} className="animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">Meteorological Farm Node</span>
              {weather?.isRealLocation && (
                <span className="px-1.5 py-0.2 bg-emerald-500/30 border border-emerald-400/40 text-emerald-300 text-[8px] font-black rounded uppercase">
                  ACTIVE GPS
                </span>
              )}
            </div>

            {/* Location Picker Trigger */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsLocationDropdownOpen(!isLocationDropdownOpen)}
                className="text-sm font-black text-white hover:text-emerald-300 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>{selectedLocation.name}</span>
                <span className="text-xs text-slate-400 font-normal">({selectedLocation.region})</span>
                <Sliders size={13} className="text-slate-400" />
              </button>

              {/* Location Picker Modal / Popover */}
              {isLocationDropdownOpen && (
                <div className="absolute left-0 top-full mt-2 w-72 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-3 z-50 text-slate-200 animate-in fade-in slide-in-from-top-2">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
                    <span className="text-xs font-bold text-slate-300">Select Agricultural District</span>
                    <button onClick={() => setIsLocationDropdownOpen(false)} className="text-xs text-slate-400 hover:text-white">✕</button>
                  </div>
                  <div className="relative mb-2">
                    <Search className="absolute left-2.5 top-2.5 text-slate-400 w-3.5 h-3.5" />
                    <input 
                      type="text" 
                      placeholder="Search district e.g. Chongwe..."
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      className="w-full text-xs p-2 pl-8 bg-slate-800 border border-slate-700 rounded-xl outline-none text-white focus:border-emerald-500"
                    />
                  </div>
                  <div className="max-h-48 overflow-y-auto space-y-1 pr-1 custom-scrollbar">
                    {filteredLocations.map(loc => (
                      <button
                        key={loc.name}
                        onClick={() => handleSelectPreset(loc)}
                        className={`w-full text-left p-2 rounded-xl text-xs flex justify-between items-center transition-all cursor-pointer ${
                          selectedLocation.name === loc.name 
                            ? "bg-emerald-600 text-white font-bold" 
                            : "hover:bg-slate-800 text-slate-300"
                        }`}
                      >
                        <span>{loc.name}</span>
                        <span className="text-[10px] text-slate-400">{loc.region}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* GPS Sync & Unit Switcher */}
        <div className="flex items-center gap-2">
          {/* Temperature unit toggle */}
          <div className="bg-slate-800 p-0.5 rounded-xl border border-slate-700 flex text-xs font-bold text-slate-400">
            <button
              onClick={() => setTempUnit("C")}
              className={`px-2.5 py-1 rounded-lg transition-all ${tempUnit === "C" ? "bg-emerald-500 text-slate-950 font-black shadow-xs" : "hover:text-white"}`}
            >
              °C
            </button>
            <button
              onClick={() => setTempUnit("F")}
              className={`px-2.5 py-1 rounded-lg transition-all ${tempUnit === "F" ? "bg-emerald-500 text-slate-950 font-black shadow-xs" : "hover:text-white"}`}
            >
              °F
            </button>
          </div>

          <button
            type="button"
            onClick={handleUseGPS}
            disabled={loading || retryingGeo}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
          >
            <Compass size={14} className={retryingGeo ? "animate-spin" : ""} />
            <span className="hidden sm:inline">Use Precise GPS</span>
          </button>
        </div>
      </div>

      {loading ? (
        <div className="py-12 text-center space-y-3">
          <RefreshCw className="w-8 h-8 text-emerald-500 animate-spin mx-auto" />
          <p className="text-xs text-slate-500 font-bold">Updating weather data for {selectedLocation.name}...</p>
        </div>
      ) : error ? (
        <div className="p-4 bg-rose-50 border-b border-rose-200 text-rose-900 space-y-1 text-xs">
          <div className="flex items-center gap-2 font-bold">
            <AlertCircle className="w-4 h-4 text-rose-600" />
            <span>Station Connection Fallback</span>
          </div>
          <p className="text-rose-700 text-[11px]">Live station query unavailable: {typeof error === "object" && error !== null ? ((error as any).message || JSON.stringify(error)) : String(error)}. Using stored district fallback.</p>
        </div>
      ) : weather && meta && farmerGuide ? (
        <div className="divide-y divide-slate-100">
          
          {/* MAIN CLEAN HERO WEATHER DISPLAY CARD */}
          <div className="p-5 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white relative overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              
              {/* Temperature & Icon */}
              <div className="flex items-center gap-4">
                <div className="p-3 bg-slate-800/80 rounded-2xl border border-slate-700 text-emerald-400 shrink-0">
                  {meta.icon}
                </div>
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl sm:text-5xl font-black tracking-tight text-white">
                      {formatTemp(weather.temperature)}
                    </span>
                    <span className="text-sm font-extrabold text-emerald-400 uppercase tracking-wide">
                      {meta.text}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 font-medium mt-0.5">
                    High: {formatTemp(weather.forecastDailyMaxTemp || weather.temperature + 3)} • Low: {formatTemp(weather.forecastDailyMinTemp || weather.temperature - 5)} • {selectedLocation.name}
                  </div>
                </div>
              </div>

              {/* 3 Essential Met Metrics */}
              <div className="grid grid-cols-3 gap-2 bg-slate-800/60 p-3 rounded-2xl border border-slate-700/60 text-center sm:w-80">
                <div>
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Precipitation</span>
                  <strong className="text-sm font-black text-white block mt-0.5">{weather.precipitation.toFixed(1)} mm</strong>
                </div>
                <div>
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Humidity</span>
                  <strong className="text-sm font-black text-white block mt-0.5">{weather.humidity}%</strong>
                </div>
                <div>
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Wind</span>
                  <strong className="text-sm font-black text-white block mt-0.5">{weather.windSpeed.toFixed(0)} km/h</strong>
                </div>
              </div>

            </div>
          </div>

          {/* 7-DAY FORECAST ROW */}
          <div className="p-4 space-y-2 bg-slate-50/50">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase text-slate-700 tracking-wider">7-Day Agricultural Forecast</span>
              <span className="text-[10px] text-slate-400 font-medium">{formattedTimeStr}</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
              {weather.dailyItems.map((item, idx) => {
                const itemMeta = getWeatherMeta(item.code);
                return (
                  <div 
                    key={idx} 
                    className={`p-2.5 rounded-xl border text-center space-y-1 transition-all ${
                      idx === 0 ? "bg-emerald-50 border-emerald-300 font-bold" : "bg-white border-slate-200"
                    }`}
                  >
                    <span className="text-[11px] font-bold text-slate-700 block">{item.dayName}</span>
                    <div className="flex justify-center py-0.5">
                      {itemMeta.icon}
                    </div>
                    <div className="text-xs font-mono font-bold text-slate-800">
                      <span>{formatTemp(item.maxTemp)}</span>
                      <span className="text-slate-400 font-normal ml-1">{formatTemp(item.minTemp)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* CLEAN AGRONOMY FIELD ADVISORIES */}
          <div className="p-4 space-y-3 bg-white">
            <span className="text-xs font-black uppercase text-slate-700 tracking-wider block">Field Activity Advisories</span>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              
              {/* Planting & Tillage */}
              <div className="p-3 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-extrabold text-slate-800">🚜 Planting & Tillage</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    farmerGuide.planting.status === "Optimal" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                  }`}>
                    {farmerGuide.planting.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-tight">{farmerGuide.planting.details}</p>
              </div>

              {/* Spraying */}
              <div className="p-3 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-extrabold text-slate-800">🧪 Crop Spraying</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    farmerGuide.spraying.status === "Optimal" ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"
                  }`}>
                    {farmerGuide.spraying.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-tight">{farmerGuide.spraying.details}</p>
              </div>

              {/* Livestock Grazing */}
              <div className="p-3 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-extrabold text-slate-800">🐮 Livestock Grazing</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    farmerGuide.grazing.status === "Optimal" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                  }`}>
                    {farmerGuide.grazing.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-tight">{farmerGuide.grazing.details}</p>
              </div>

            </div>
          </div>

          {/* ACTIVE HAZARD WARNINGS */}
          {alerts.length > 0 && (
            <div className="p-4 bg-rose-50 space-y-2 border-t border-rose-200">
              <span className="text-xs font-bold text-rose-700 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-rose-600" />
                <span>Active Severe Risk Warning</span>
              </span>
              {alerts.map((alert) => (
                <div key={alert.id} className="p-3 bg-white border border-rose-200 rounded-xl space-y-1 text-xs">
                  <div className="flex justify-between items-center font-bold text-rose-900">
                    <span>{alert.title}</span>
                    <span className="px-1.5 py-0.5 bg-rose-600 text-white text-[9px] rounded uppercase">{alert.severity}</span>
                  </div>
                  <p className="text-[11px] text-slate-600">{alert.description}</p>
                  <div className="text-[10px] text-emerald-800 font-bold bg-emerald-50 p-1.5 rounded">Action: {alert.action}</div>
                </div>
              ))}
            </div>
          )}

        </div>
      ) : null}
    </div>
  );
}

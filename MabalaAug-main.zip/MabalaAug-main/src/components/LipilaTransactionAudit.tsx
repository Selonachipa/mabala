import React, { useState } from "react";
import { 
  QrCode, 
  Copy, 
  Check, 
  Search, 
  Filter, 
  RefreshCw, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  XCircle, 
  ExternalLink,
  ShieldCheck,
  Smartphone,
  Building,
  TrendingUp,
  Download,
  Eye,
  FileSpreadsheet
} from "lucide-react";
import { LipilaTransaction, INITIAL_LIPILA_TRANSACTIONS } from "../data/mockLipilaTransactions";

interface LipilaTransactionAuditProps {
  lipilaTransactions?: LipilaTransaction[];
  onRefreshReconciliation?: () => void;
  isReconciling?: boolean;
}

export default function LipilaTransactionAudit({
  lipilaTransactions = [],
  onRefreshReconciliation,
  isReconciling = false
}: LipilaTransactionAuditProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | "Successful" | "Pending" | "Failed" | "Timed Out">("All");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedTx, setSelectedTx] = useState<LipilaTransaction | null>(null);

  // Combine provided transactions with initial mock records if empty to ensure rich display
  const allTransactions = lipilaTransactions.length > 0 ? lipilaTransactions : INITIAL_LIPILA_TRANSACTIONS;

  const handleCopyRef = (refId: string) => {
    navigator.clipboard.writeText(refId);
    setCopiedId(refId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filtered = allTransactions.filter((tx) => {
    const term = searchTerm.toLowerCase();
    const matchesSearch = 
      (tx.referenceId && tx.referenceId.toLowerCase().includes(term)) ||
      (tx.id && tx.id.toLowerCase().includes(term)) ||
      (tx.customerName && tx.customerName.toLowerCase().includes(term)) ||
      (tx.accountNumber && tx.accountNumber.toLowerCase().includes(term)) ||
      (tx.provider && tx.provider.toLowerCase().includes(term)) ||
      (tx.narration && tx.narration.toLowerCase().includes(term));

    const matchesStatus = 
      statusFilter === "All" || 
      tx.status === statusFilter ||
      (statusFilter === "Timed Out" && (tx.status as string) === "Timed Out");

    return matchesSearch && matchesStatus;
  });

  // Calculate metrics
  const totalVolume = allTransactions.reduce((acc, curr) => acc + (curr.amount || 0), 0);
  const totalCount = allTransactions.length;
  const successfulCount = allTransactions.filter(t => t.status === "Successful").length;
  const pendingCount = allTransactions.filter(t => t.status === "Pending").length;
  const failedCount = allTransactions.filter(t => t.status === "Failed").length;
  const timedOutCount = allTransactions.filter(t => (t.status as string) === "Timed Out").length;
  const successRate = totalCount > 0 ? Math.round((successfulCount / totalCount) * 100) : 0;

  const handleExportCSV = () => {
    let csv = "Reference ID,Transaction ID,Customer Name,Account Number,Provider,Amount (ZMW),Status,Created At,Narration\n";
    filtered.forEach(tx => {
      csv += `"${tx.referenceId || tx.id}","${tx.id}","${tx.customerName}","${tx.accountNumber}","${tx.provider}","${tx.amount}","${tx.status}","${tx.createdAt}","${(tx.narration || "").replace(/"/g, '""')}"\n`;
    });
    
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `lipila_transaction_audit_export_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Overview Metric Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Total Audit Volume</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-xs font-bold text-slate-500">ZK</span>
            <span className="text-xl font-black font-mono text-slate-900">{totalVolume.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
          </div>
          <span className="text-[10px] text-emerald-600 font-bold block mt-1">Across {totalCount} attempts</span>
        </div>

        <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-100 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block">Successful QR / Push</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-xl font-black font-mono text-emerald-900">{successfulCount}</span>
            <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-extrabold rounded-full">{successRate}% Cleared</span>
          </div>
          <span className="text-[10px] text-emerald-600 font-medium block mt-1">Settled on Lipila gateway</span>
        </div>

        <div className="bg-amber-50/60 p-4 rounded-2xl border border-amber-100 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 block">Pending PIN Authorisations</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-xl font-black font-mono text-amber-900">{pendingCount}</span>
            <span className="h-2 w-2 rounded-full bg-amber-500 animate-ping" />
          </div>
          <span className="text-[10px] text-amber-600 font-medium block mt-1">Awaiting mobile money PIN</span>
        </div>

        <div className="bg-orange-50/60 p-4 rounded-2xl border border-orange-100 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-orange-700 block">Timed Out Attempts</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-xl font-black font-mono text-orange-900">{timedOutCount}</span>
            <Clock className="w-4 h-4 text-orange-500" />
          </div>
          <span className="text-[10px] text-orange-600 font-medium block mt-1">Auto-flagged (&gt; 1 Hour)</span>
        </div>

        <div className="bg-rose-50/60 p-4 rounded-2xl border border-rose-100 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700 block">Failed / Declined</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-xl font-black font-mono text-rose-900">{failedCount}</span>
            <XCircle className="w-4 h-4 text-rose-500" />
          </div>
          <span className="text-[10px] text-rose-600 font-medium block mt-1">Insufficient funds or user cancel</span>
        </div>
      </div>

      {/* Control Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search reference ID, customer, provider..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold outline-none focus:border-indigo-500 text-slate-800"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end">
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold">
            {(["All", "Successful", "Pending", "Timed Out", "Failed"] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 rounded-lg text-[11px] transition-all cursor-pointer ${
                  statusFilter === st
                    ? "bg-white text-slate-900 shadow-xs"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          {onRefreshReconciliation && (
            <button
              onClick={onRefreshReconciliation}
              disabled={isReconciling}
              className="px-3 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Run live reconciliation check"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isReconciling ? "animate-spin text-indigo-600" : ""}`} />
              <span>{isReconciling ? "Reconciling..." : "Run Reconcile"}</span>
            </button>
          )}

          <button
            onClick={handleExportCSV}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Main Real-time Audit Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <div>
            <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <QrCode className="w-4 h-4 text-indigo-600" />
              Lipila QR & Gateway Payment Attempts Audit Trail
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Live audit record of QR payment scans, mobile money USSD push requests, and traditional bank transfers.
            </p>
          </div>
          <span className="text-xs font-mono font-bold px-2.5 py-1 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-lg">
            {filtered.length} Entries Logged
          </span>
        </div>

        {filtered.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-2">
            <QrCode className="w-8 h-8 mx-auto text-slate-300" />
            <p className="text-sm font-bold text-slate-600">No Lipila payment attempts found matching query.</p>
            <p className="text-xs text-slate-400">Try adjusting your search terms or status filter toggle.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100/70 border-b border-slate-200 text-[10px] font-black uppercase tracking-wider text-slate-500">
                  <th className="py-3 px-4">Reference ID (Click to Copy)</th>
                  <th className="py-3 px-4">Customer / Account</th>
                  <th className="py-3 px-4">Payment Method / Channel</th>
                  <th className="py-3 px-4 text-right">Amount (ZMW)</th>
                  <th className="py-3 px-4 text-center">Gateway Status</th>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs font-medium text-slate-700">
                {filtered.map((tx) => {
                  const refToDisplay = tx.referenceId || tx.id;
                  const isCopied = copiedId === refToDisplay;
                  const isMobileMoney = tx.paymentType === "MobileMoney" || ["Airtel Money", "MTN MoMo", "Zamtel Kwacha"].some(p => tx.provider?.includes(p));
                  const isBank = tx.paymentType === "Bank" || tx.provider?.toLowerCase().includes("bank") || tx.provider?.includes("ZANACO");

                  return (
                    <tr key={tx.id || refToDisplay} className="hover:bg-slate-50/80 transition-colors">
                      {/* Reference ID Column with Copy Button */}
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        <div className="flex items-center gap-1.5">
                          <span className="text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded text-[11px]">
                            {refToDisplay}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleCopyRef(refToDisplay)}
                            className="p-1 hover:bg-slate-200 rounded text-slate-400 hover:text-slate-800 transition-colors cursor-pointer"
                            title="Click to Copy Reference ID"
                          >
                            {isCopied ? (
                              <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-0.5 bg-emerald-50 px-1 rounded border border-emerald-200">
                                <Check className="w-3 h-3" /> Copied!
                              </span>
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Customer Name / Wallet Number */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{tx.customerName || "Customer Wallet"}</div>
                        <div className="text-[11px] text-slate-400 font-mono mt-0.5">{tx.accountNumber}</div>
                      </td>

                      {/* Channel Badge */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5">
                          {isBank ? (
                            <span className="px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 rounded text-[10px] font-extrabold flex items-center gap-1">
                              <Building className="w-3 h-3 text-blue-600" />
                              {tx.provider || "Bank Transfer"}
                            </span>
                          ) : isMobileMoney ? (
                            <span className="px-2 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded text-[10px] font-extrabold flex items-center gap-1">
                              <Smartphone className="w-3 h-3 text-amber-600" />
                              {tx.provider || "Mobile Money"}
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-purple-50 text-purple-700 border border-purple-200 rounded text-[10px] font-extrabold flex items-center gap-1">
                              <QrCode className="w-3 h-3 text-purple-600" />
                              {tx.provider || "Lipila Pay"}
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 block mt-0.5 truncate max-w-[160px]">
                          {tx.narration || "Payment collection"}
                        </span>
                      </td>

                      {/* Amount */}
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900 text-sm">
                        ZK {(tx.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>

                      {/* Status Badges */}
                      <td className="py-3.5 px-4 text-center">
                        {tx.status === "Successful" ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-bold rounded-lg shadow-xs">
                            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                            Successful
                          </span>
                        ) : tx.status === "Pending" ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-50 text-amber-700 border border-amber-200 text-[11px] font-bold rounded-lg">
                            <span className="h-2 w-2 rounded-full bg-amber-500 animate-ping inline-block" />
                            Pending PIN
                          </span>
                        ) : (tx.status as string) === "Timed Out" ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-orange-50 text-orange-700 border border-orange-200 text-[11px] font-bold rounded-lg">
                            <Clock className="w-3.5 h-3.5 text-orange-600" />
                            Timed Out (&gt;1h)
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-50 text-rose-700 border border-rose-200 text-[11px] font-bold rounded-lg">
                            <XCircle className="w-3.5 h-3.5 text-rose-600" />
                            Failed
                          </span>
                        )}
                      </td>

                      {/* Timestamp */}
                      <td className="py-3.5 px-4 text-slate-500 text-[11px] font-mono">
                        {tx.createdAt ? new Date(tx.createdAt).toLocaleString() : "Recent"}
                      </td>

                      {/* Action Button */}
                      <td className="py-3.5 px-4 text-center">
                        <button
                          type="button"
                          onClick={() => setSelectedTx(tx)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-colors cursor-pointer inline-flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5 text-slate-500" />
                          <span>Audit Detail</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Transaction Details Modal */}
      {selectedTx && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-[110] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-scale-up text-slate-800">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <QrCode className="w-5 h-5 text-indigo-600" />
                <h4 className="font-extrabold text-sm text-slate-900">Lipila Audit Trace Record</h4>
              </div>
              <button
                onClick={() => setSelectedTx(null)}
                className="text-slate-400 hover:text-slate-700 text-xs font-bold px-2 py-1 bg-slate-100 rounded-lg cursor-pointer"
              >
                ✕ Close
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">Reference ID:</span>
                <span className="font-bold text-indigo-700">{selectedTx.referenceId || selectedTx.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Customer Name:</span>
                <span className="font-bold text-slate-900">{selectedTx.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Account / Mobile:</span>
                <span className="font-bold text-slate-900">{selectedTx.accountNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Provider Channel:</span>
                <span className="font-bold text-slate-900">{selectedTx.provider}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Amount Payable:</span>
                <span className="font-bold text-emerald-700">ZK {selectedTx.amount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Status:</span>
                <span className="font-black text-slate-900 uppercase">{selectedTx.status}</span>
              </div>
              {selectedTx.message && (
                <div className="border-t border-slate-200 pt-2 text-[11px] text-slate-600 font-sans">
                  <strong>Gateway Note:</strong> {selectedTx.message}
                </div>
              )}
            </div>

            {selectedTx.timeline && selectedTx.timeline.length > 0 && (
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-900 block">Gateway Event Timeline:</span>
                <div className="bg-slate-900 text-slate-200 p-3.5 rounded-2xl text-[11px] font-mono space-y-1.5 max-h-40 overflow-y-auto">
                  {selectedTx.timeline.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-2 border-b border-slate-800 pb-1.5 last:border-0 last:pb-0">
                      <span className="text-indigo-400 font-bold">#{step.step || idx + 1}</span>
                      <div className="flex-1">
                        <div>{step.description}</div>
                        <div className="text-[9px] text-slate-500">{new Date(step.timestamp).toLocaleTimeString()}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setSelectedTx(null)}
                className="px-5 py-2 bg-indigo-600 text-white font-bold text-xs rounded-xl hover:bg-indigo-700 cursor-pointer"
              >
                Done Inspecting
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useState, useMemo } from "react";
import { 
  Calendar, 
  Clock, 
  ArrowRight, 
  CheckSquare, 
  Square, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  Trees, 
  Layers, 
  ChevronRight,
  Info,
  X
} from "lucide-react";
import { CropCycle, OrchardYearHarvestSchedule } from "../../types";

interface OrchardBulkHarvestDateModalProps {
  isOpen: boolean;
  onClose: () => void;
  allBlocks: CropCycle[];
  selectedBlockIds: string[];
  onToggleBlockSelection: (blockId: string) => void;
  onSelectAllBlocks: () => void;
  onDeselectAllBlocks: () => void;
  onApplyBulkShift: (
    targetBlockIds: string[],
    daysToShift: number,
    shiftMultiYearSchedule: boolean,
    note?: string
  ) => Promise<void>;
  currencySymbol?: string;
  showToast: (msg: string, type: "success" | "error" | "info") => void;
}

export default function OrchardBulkHarvestDateModal({
  isOpen,
  onClose,
  allBlocks,
  selectedBlockIds,
  onToggleBlockSelection,
  onSelectAllBlocks,
  onDeselectAllBlocks,
  onApplyBulkShift,
  currencySymbol = "ZK",
  showToast
}: OrchardBulkHarvestDateModalProps) {
  const [daysToShift, setDaysToShift] = useState<number>(7);
  const [shiftMultiYearSchedule, setShiftMultiYearSchedule] = useState<boolean>(true);
  const [shiftReason, setShiftReason] = useState<string>("");
  const [isApplying, setIsApplying] = useState<boolean>(false);
  const [shiftMode, setShiftMode] = useState<"offset" | "exact">("offset");
  const [exactTargetDate, setExactTargetDate] = useState<string>(
    new Date(Date.now() + 14 * 86400000).toISOString().split("T")[0]
  );

  // Filter orchard blocks
  const orchardBlocks = useMemo(() => {
    return allBlocks.filter(b => b.orchard !== undefined || (b as any).isOrchard);
  }, [allBlocks]);

  const selectedBlocks = useMemo(() => {
    return orchardBlocks.filter(b => selectedBlockIds.includes(b.id));
  }, [orchardBlocks, selectedBlockIds]);

  if (!isOpen) return null;

  // Preset offsets
  const presetOffsets = [
    { label: "-30d (1 Month Early)", val: -30, color: "hover:bg-amber-50 hover:border-amber-300 text-amber-900" },
    { label: "-14d (2 Wks Early)", val: -14, color: "hover:bg-amber-50 hover:border-amber-300 text-amber-900" },
    { label: "-7d (1 Wk Early)", val: -7, color: "hover:bg-amber-50 hover:border-amber-300 text-amber-900" },
    { label: "+7d (1 Wk Later)", val: 7, color: "hover:bg-emerald-50 hover:border-emerald-300 text-emerald-900" },
    { label: "+14d (2 Wks Later)", val: 14, color: "hover:bg-emerald-50 hover:border-emerald-300 text-emerald-900" },
    { label: "+30d (1 Month Later)", val: 30, color: "hover:bg-emerald-50 hover:border-emerald-300 text-emerald-900" },
    { label: "+60d (2 Mos Later)", val: 60, color: "hover:bg-indigo-50 hover:border-indigo-300 text-indigo-900" }
  ];

  // Helper to calculate shifted date
  const computeShiftedDate = (currentDateStr?: string, days = 0): string => {
    const base = currentDateStr ? new Date(currentDateStr) : new Date();
    const valid = isNaN(base.getTime()) ? new Date() : base;
    const shifted = new Date(valid);
    shifted.setDate(shifted.getDate() + days);
    return shifted.toISOString().split("T")[0];
  };

  const handleApply = async () => {
    if (selectedBlockIds.length === 0) {
      showToast("Please select at least one orchard block to update.", "error");
      return;
    }

    setIsApplying(true);
    try {
      let finalDaysToShift = daysToShift;

      if (shiftMode === "exact") {
        // If exact date chosen, compute average or individual offset per block
        // For simplicity, offset relative to each block's current expected date or uniform difference
        const targetMs = new Date(exactTargetDate).getTime();
        if (isNaN(targetMs)) {
          showToast("Please choose a valid target date.", "error");
          setIsApplying(false);
          return;
        }
      }

      await onApplyBulkShift(
        selectedBlockIds,
        daysToShift,
        shiftMultiYearSchedule,
        shiftReason.trim() || undefined
      );
      onClose();
    } catch (err) {
      // Handled by parent
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-[1250] flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-in fade-in duration-150 font-sans">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full overflow-hidden max-h-[92vh] flex flex-col my-auto">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-900 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <Calendar className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400 font-mono">
                  Batch Operations
                </span>
                <span className="px-2 py-0.2 bg-emerald-950 text-emerald-300 rounded text-[9px] font-bold border border-emerald-800/60 font-mono">
                  {selectedBlockIds.length} Selected
                </span>
              </div>
              <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-2">
                <span>Bulk Update Harvest Dates</span>
              </h2>
            </div>
          </div>

          <button 
            type="button" 
            onClick={onClose} 
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center text-sm font-bold transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-xs text-slate-700">

          {/* 1. Block Selection Bar */}
          <div className="bg-slate-50 border border-slate-200/90 rounded-xl p-4 space-y-3">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-slate-200 pb-2.5">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-slate-600" />
                <span className="font-extrabold text-slate-900 text-sm">
                  1. Select Target Orchard Blocks ({selectedBlockIds.length} of {orchardBlocks.length} chosen)
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onSelectAllBlocks}
                  className="px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-700 transition-all cursor-pointer"
                >
                  Select All Blocks
                </button>
                <button
                  type="button"
                  onClick={onDeselectAllBlocks}
                  className="px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-500 transition-all cursor-pointer"
                >
                  Clear Selection
                </button>
              </div>
            </div>

            {/* Blocks Checkbox Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 max-h-48 overflow-y-auto p-1">
              {orchardBlocks.map(block => {
                const isSelected = selectedBlockIds.includes(block.id);
                const fruitName = block.orchard?.fruitType || block.cropType || "Fruit";
                const variety = block.orchard?.variety || block.variety || "Standard";
                const treeCount = block.orchard?.treeCount || 100;
                const harvestDate = block.expectedHarvestDate || "Not set";

                return (
                  <div
                    key={block.id}
                    onClick={() => onToggleBlockSelection(block.id)}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-start gap-2.5 ${
                      isSelected
                        ? "bg-emerald-50/80 border-emerald-400 shadow-xs"
                        : "bg-white border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    <div className="pt-0.5 text-emerald-600">
                      {isSelected ? (
                        <CheckSquare className="w-4 h-4 stroke-[2.5]" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-300" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-extrabold text-slate-900 truncate text-[11.5px]">
                        {block.fieldBlock}
                      </div>
                      <div className="text-[10px] text-slate-500 truncate">
                        {fruitName} • {variety} ({treeCount} trees)
                      </div>
                      <div className="text-[9.5px] font-mono font-semibold text-slate-600 mt-0.5">
                        Current: <strong className="text-slate-900">{harvestDate}</strong>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 2. Shift Configuration */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
              <Clock className="w-4 h-4 text-emerald-600" />
              <span className="font-extrabold text-slate-900 text-sm">
                2. Shift Configuration &amp; Offset
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Days Offset Input */}
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-slate-500 block font-mono">
                  Number of Days to Shift (+ / -)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={daysToShift}
                    onChange={(e) => setDaysToShift(parseInt(e.target.value) || 0)}
                    className="w-32 bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-mono font-black text-slate-900 text-sm focus:bg-white focus:border-emerald-500 outline-none"
                  />
                  <span className="text-xs font-bold text-slate-500">
                    {daysToShift > 0 ? `+${daysToShift} days (Delay/Later)` : daysToShift < 0 ? `${daysToShift} days (Advance/Earlier)` : "0 days (No shift)"}
                  </span>
                </div>

                {/* Quick Presets */}
                <div className="pt-2">
                  <span className="text-[9.5px] font-black uppercase text-slate-400 block mb-1 font-mono">
                    Quick Preset Nudges:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {presetOffsets.map(p => (
                      <button
                        key={p.val}
                        type="button"
                        onClick={() => setDaysToShift(p.val)}
                        className={`px-2 py-1 bg-white border border-slate-200 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer ${p.color} ${
                          daysToShift === p.val ? "ring-2 ring-emerald-500 bg-emerald-50 font-black" : ""
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Options & Notes */}
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase text-slate-500 block font-mono">
                  Multi-Year Lifecycle Scope
                </label>
                
                <label className="flex items-start gap-2 p-3 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100/80 transition-colors">
                  <input
                    type="checkbox"
                    checked={shiftMultiYearSchedule}
                    onChange={(e) => setShiftMultiYearSchedule(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500 cursor-pointer"
                  />
                  <div>
                    <span className="font-extrabold text-slate-900 block text-xs">
                      Synchronize Multi-Year Lifecycle Schedule
                    </span>
                    <span className="text-[10px] text-slate-500 leading-relaxed block mt-0.5">
                      Automatically shift all future annual seasons in the 5–20 year harvest calendar by the same offset.
                    </span>
                  </div>
                </label>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 block mb-1 font-mono">
                    Agronomic Note / Reason (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Delayed rains, early bloom, cold snap recovery"
                    value={shiftReason}
                    onChange={(e) => setShiftReason(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 text-xs text-slate-800 outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
              </div>

            </div>
          </div>

          {/* 3. Live Preview Table */}
          {selectedBlocks.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs space-y-2">
              <div className="p-3.5 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span className="font-extrabold text-slate-900 text-xs">
                    3. Live Date Shift Preview ({selectedBlocks.length} Blocks)
                  </span>
                </div>
                <span className="text-[10px] font-mono text-emerald-700 font-bold bg-emerald-100/80 px-2 py-0.5 rounded">
                  Shift: {daysToShift > 0 ? `+${daysToShift}` : daysToShift} Days
                </span>
              </div>

              <div className="max-h-56 overflow-y-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-slate-100 text-[9.5px] uppercase font-black font-mono text-slate-500 sticky top-0">
                    <tr>
                      <th className="p-2.5">Orchard Block</th>
                      <th className="p-2.5">Fruit &amp; Variety</th>
                      <th className="p-2.5">Current Date</th>
                      <th className="p-2.5 text-center">Offset</th>
                      <th className="p-2.5">New Expected Date</th>
                      <th className="p-2.5 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {selectedBlocks.map(block => {
                      const currentDate = block.expectedHarvestDate || "2026-05-15";
                      const newDate = computeShiftedDate(currentDate, daysToShift);
                      const fruitName = block.orchard?.fruitType || block.cropType || "Fruit";

                      return (
                        <tr key={block.id} className="hover:bg-slate-50">
                          <td className="p-2.5 font-bold text-slate-900 font-mono">
                            {block.fieldBlock}
                          </td>
                          <td className="p-2.5 text-slate-600">
                            {fruitName} ({block.orchard?.variety || block.variety || "Standard"})
                          </td>
                          <td className="p-2.5 font-mono text-slate-500 line-through">
                            {currentDate}
                          </td>
                          <td className="p-2.5 text-center font-mono font-bold">
                            <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                              daysToShift > 0 
                                ? "bg-emerald-50 text-emerald-700 border border-emerald-200" 
                                : daysToShift < 0 
                                  ? "bg-amber-50 text-amber-700 border border-amber-200"
                                  : "bg-slate-100 text-slate-600"
                            }`}>
                              {daysToShift > 0 ? `+${daysToShift}d` : `${daysToShift}d`}
                            </span>
                          </td>
                          <td className="p-2.5 font-mono font-black text-emerald-700 bg-emerald-50/40">
                            {newDate}
                          </td>
                          <td className="p-2.5 text-right">
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Ready</span>
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Info className="w-4 h-4 text-slate-400" />
            <span>
              {selectedBlockIds.length === 0 
                ? "Select at least 1 block to apply changes." 
                : `Ready to update ${selectedBlockIds.length} orchard block${selectedBlockIds.length > 1 ? "s" : ""}.`}
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer transition-colors"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleApply}
              disabled={isApplying || selectedBlockIds.length === 0 || daysToShift === 0}
              className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-md transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer flex items-center gap-2"
            >
              {isApplying ? (
                <span>Saving Changes...</span>
              ) : (
                <>
                  <span>Apply Bulk Shift ({daysToShift > 0 ? `+${daysToShift}d` : `${daysToShift}d`})</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}

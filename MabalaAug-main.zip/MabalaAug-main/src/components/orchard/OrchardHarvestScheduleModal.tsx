import React, { useState } from "react";
import { 
  Calendar, 
  Trees, 
  CheckCircle2, 
  Clock, 
  TrendingUp, 
  Sparkles, 
  Download, 
  DollarSign, 
  Layers,
  Edit2
} from "lucide-react";
import { CropCycle, OrchardYearHarvestSchedule } from "../../types";

interface OrchardHarvestScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  block: CropCycle;
  currencySymbol: string;
  onUpdateSchedule: (blockId: string, schedule: OrchardYearHarvestSchedule[]) => void;
  showToast: (msg: string, type: "success" | "error" | "info") => void;
}

export default function OrchardHarvestScheduleModal({
  isOpen,
  onClose,
  block,
  currencySymbol,
  onUpdateSchedule,
  showToast
}: OrchardHarvestScheduleModalProps) {
  const [editingYearIndex, setEditingYearIndex] = useState<number | null>(null);
  const [actualYieldKg, setActualYieldKg] = useState<number>(0);
  const [actualRevenue, setActualRevenue] = useState<number>(0);
  const [activeDateNudgerIndex, setActiveDateNudgerIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const orchard = block.orchard;
  const schedule: OrchardYearHarvestSchedule[] = orchard?.multiYearHarvestSchedule || [];
  const fruitType = orchard?.fruitType || block.cropType || "Fruit";
  const variety = orchard?.variety || block.variety || "";
  const treeCount = orchard?.treeCount || 100;
  const lifespanYears = orchard?.treeLifespanYears || 20;

  const totalProjectedLifetimeRevenue = schedule.reduce((sum, yr) => sum + yr.projectedRevenue, 0);
  const totalActualRevenue = schedule.reduce((sum, yr) => sum + (yr.actualRevenue || 0), 0);

  // Quick Nudge Expected Harvest Date (e.g. -7d, -1d, +1d, +7d, +30d) without full wizard
  const handleNudgeDate = (index: number, days: number) => {
    const updated = [...schedule];
    const current = updated[index];
    
    // Parse current date or fallback to current year
    const currentYear = current.calendarYear || (new Date().getFullYear() + index);
    const currentDateStr = current.expectedHarvestDate || `${currentYear}-05-15`;
    const baseDate = new Date(currentDateStr);
    
    // Check if valid date
    if (isNaN(baseDate.getTime())) {
      const fallback = new Date(`${currentYear}-05-15`);
      fallback.setDate(fallback.getDate() + days);
      updated[index] = {
        ...current,
        expectedHarvestDate: fallback.toISOString().split("T")[0]
      };
    } else {
      baseDate.setDate(baseDate.getDate() + days);
      updated[index] = {
        ...current,
        expectedHarvestDate: baseDate.toISOString().split("T")[0]
      };
    }

    onUpdateSchedule(block.id, updated);
    showToast(
      `Nudged Year ${current.yearNumber} (${current.calendarYear}) harvest date by ${days > 0 ? `+${days}` : days}d to ${updated[index].expectedHarvestDate}`, 
      "info"
    );
  };

  // Direct Date input change inline
  const handleDirectDateChange = (index: number, newDateStr: string) => {
    if (!newDateStr) return;
    const updated = [...schedule];
    const current = updated[index];
    updated[index] = {
      ...current,
      expectedHarvestDate: newDateStr
    };
    onUpdateSchedule(block.id, updated);
    showToast(`Year ${current.yearNumber} expected harvest updated to ${newDateStr}`, "success");
  };

  const handleStartEdit = (index: number) => {
    const yr = schedule[index];
    setEditingYearIndex(index);
    setActualYieldKg(yr.actualHarvestedKg || yr.projectedYieldKg);
    setActualRevenue(yr.actualRevenue || yr.projectedRevenue);
  };

  const handleSaveActualHarvest = (index: number) => {
    const updated = [...schedule];
    updated[index] = {
      ...updated[index],
      actualHarvestedKg: actualYieldKg,
      actualRevenue,
      isHarvestCompleted: true
    };

    onUpdateSchedule(block.id, updated);
    setEditingYearIndex(null);
    showToast(`Saved actual harvest for Year ${updated[index].yearNumber} (${currencySymbol}${actualRevenue})`, "success");
  };

  const handleExportSchedule = () => {
    const csvContent = `data:text/csv;charset=utf-8,` +
      `ORCHARD MULTI-YEAR HARVEST CALENDAR: ${block.fieldBlock}\n` +
      `Fruit,${fruitType}\n` +
      `Variety,${variety}\n` +
      `Lifespan,${lifespanYears} Years\n` +
      `Tree Population,${treeCount}\n\n` +
      `Year,Calendar Year,Expected Harvest Date,Stage,Yield %,Projected Kg,Projected Revenue,Actual Kg,Actual Revenue,Status\n` +
      schedule.map(yr => 
        `${yr.yearNumber},${yr.calendarYear},${yr.expectedHarvestDate},${yr.lifecycleStage},${yr.yieldMultiplierPct}%,${yr.projectedYieldKg},${currencySymbol}${yr.projectedRevenue},${yr.actualHarvestedKg || 0},${currencySymbol}${yr.actualRevenue || 0},${yr.isHarvestCompleted ? "Completed" : "Pending"}`
      ).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Orchard_Harvest_Schedule_${block.fieldBlock.replace(/\s+/g, "_")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Harvest Schedule CSV Exported!", "success");
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-[1200] flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full overflow-hidden max-h-[92vh] flex flex-col my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-900 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <Calendar className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400 font-mono">
                  Perennial Harvest Calendar
                </span>
                <span className="px-2 py-0.2 bg-emerald-950 text-emerald-300 rounded text-[9px] font-bold border border-emerald-800/60">
                  {fruitType} • {block.fieldBlock}
                </span>
              </div>
              <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-2">
                <span>Multi-Year Harvest Lifecycle & Schedule</span>
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportSchedule}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Calendar</span>
            </button>

            <button 
              type="button" 
              onClick={onClose} 
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center text-sm font-bold transition-colors cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Top Summary Banner */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <span className="text-[9px] text-slate-400 uppercase font-black block">Expected Lifespan</span>
            <span className="font-extrabold text-slate-800">{lifespanYears} Productive Years</span>
          </div>
          <div>
            <span className="text-[9px] text-slate-400 uppercase font-black block">Tree Population</span>
            <span className="font-mono font-extrabold text-slate-800">{treeCount.toLocaleString()} Trees</span>
          </div>
          <div>
            <span className="text-[9px] text-slate-400 uppercase font-black block">Lifetime Target</span>
            <span className="font-mono font-black text-emerald-600">
              {currencySymbol}{totalProjectedLifetimeRevenue.toLocaleString()}
            </span>
          </div>
          <div>
            <span className="text-[9px] text-slate-400 uppercase font-black block">Harvests Logged</span>
            <span className="font-mono font-black text-indigo-600">
              {schedule.filter(s => s.isHarvestCompleted).length} / {schedule.length} Seasons
            </span>
          </div>
        </div>

        {/* Schedule Table */}
        <div className="p-6 overflow-y-auto flex-1 text-xs space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <table className="w-full text-left border-collapse">
              <thead className="bg-slate-50 text-[10px] text-slate-500 uppercase font-black tracking-wider border-b border-slate-200 sticky top-0 z-10">
                <tr>
                  <th className="p-3.5">Season / Year</th>
                  <th className="p-3.5">Target Harvest Date</th>
                  <th className="p-3.5">Lifecycle Stage</th>
                  <th className="p-3.5 text-center">Bearing Curve</th>
                  <th className="p-3.5 text-right">Projected Yield</th>
                  <th className="p-3.5 text-right">Projected Revenue</th>
                  <th className="p-3.5 text-right">Actual Harvest</th>
                  <th className="p-3.5 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {schedule.map((yr, idx) => {
                  const isEditing = editingYearIndex === idx;

                  return (
                    <tr key={yr.yearNumber} className="hover:bg-slate-50/60 transition-colors">
                      <td className="p-3.5">
                        <span className="font-mono font-black text-slate-900 block">Year {yr.yearNumber}</span>
                        <span className="text-[10px] font-mono text-slate-400">{yr.calendarYear} Season</span>
                      </td>

                      <td className="p-3.5">
                        <div className="space-y-1.5 min-w-[210px]">
                          {/* Date and Quick Edit Toggle */}
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-slate-900 font-bold text-xs bg-slate-100 px-2 py-0.5 rounded border border-slate-200/80">
                              {yr.expectedHarvestDate || `${yr.calendarYear}-05-15`}
                            </span>
                            <button
                              type="button"
                              onClick={() => setActiveDateNudgerIndex(activeDateNudgerIndex === idx ? null : idx)}
                              className={`p-1 rounded text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer ${
                                activeDateNudgerIndex === idx
                                  ? "bg-indigo-600 text-white"
                                  : "hover:bg-indigo-50 text-indigo-700 hover:text-indigo-900"
                              }`}
                              title="Toggle Quick Edit Date Nudger"
                            >
                              <Edit2 className="w-3 h-3" />
                              <span>{activeDateNudgerIndex === idx ? "Done" : "Quick Edit"}</span>
                            </button>
                          </div>

                          {/* Quick Edit & Nudge Controls */}
                          {activeDateNudgerIndex === idx ? (
                            <div className="p-2 bg-indigo-50/80 border border-indigo-200 rounded-lg space-y-1.5 animate-in fade-in zoom-in-95 duration-100">
                              <div className="flex items-center gap-1.5">
                                <label className="text-[9px] font-black uppercase text-indigo-900 font-mono">Date:</label>
                                <input
                                  type="date"
                                  value={yr.expectedHarvestDate || `${yr.calendarYear}-05-15`}
                                  onChange={(e) => handleDirectDateChange(idx, e.target.value)}
                                  className="w-full bg-white border border-indigo-200 rounded px-1.5 py-0.5 text-[11px] font-mono font-bold text-indigo-950 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                                />
                              </div>
                              
                              <div className="flex items-center justify-between gap-1 pt-0.5">
                                <span className="text-[8.5px] font-black uppercase text-slate-500 font-mono">Nudge:</span>
                                <div className="flex items-center gap-1">
                                  <button
                                    type="button"
                                    onClick={() => handleNudgeDate(idx, -7)}
                                    className="px-1.5 py-0.5 bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-200 rounded text-[9.5px] font-mono font-bold transition-all"
                                    title="Shift 1 week earlier"
                                  >
                                    -7d
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleNudgeDate(idx, -1)}
                                    className="px-1.5 py-0.5 bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-200 rounded text-[9.5px] font-mono font-bold transition-all"
                                    title="Shift 1 day earlier"
                                  >
                                    -1d
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleNudgeDate(idx, 1)}
                                    className="px-1.5 py-0.5 bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-200 rounded text-[9.5px] font-mono font-bold transition-all"
                                    title="Shift 1 day later"
                                  >
                                    +1d
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleNudgeDate(idx, 7)}
                                    className="px-1.5 py-0.5 bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-200 rounded text-[9.5px] font-mono font-bold transition-all"
                                    title="Shift 1 week later"
                                  >
                                    +7d
                                  </button>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => handleNudgeDate(idx, -7)}
                                className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded text-[9px] font-mono transition-colors"
                                title="Quick nudge -7 days"
                              >
                                -7d
                              </button>
                              <button
                                type="button"
                                onClick={() => handleNudgeDate(idx, 7)}
                                className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded text-[9px] font-mono transition-colors"
                                title="Quick nudge +7 days"
                              >
                                +7d
                              </button>
                            </div>
                          )}
                        </div>
                      </td>

                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                          yr.lifecycleStage === "Peak Production"
                            ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                            : yr.lifecycleStage === "Moderate Production"
                              ? "bg-blue-50 text-blue-700 border-blue-200"
                              : yr.lifecycleStage === "First Bearing"
                                ? "bg-amber-50 text-amber-700 border-amber-200"
                                : yr.lifecycleStage === "Declining"
                                  ? "bg-rose-50 text-rose-700 border-rose-200"
                                  : "bg-slate-100 text-slate-500 border-slate-200"
                        }`}>
                          {yr.lifecycleStage}
                        </span>
                      </td>

                      <td className="p-3.5 text-center font-mono font-bold">
                        {yr.yieldMultiplierPct}%
                      </td>

                      <td className="p-3.5 text-right font-mono font-bold text-slate-800">
                        {yr.projectedYieldKg.toLocaleString()} kg
                      </td>

                      <td className="p-3.5 text-right font-mono font-black text-emerald-600">
                        {currencySymbol}{yr.projectedRevenue.toLocaleString()}
                      </td>

                      <td className="p-3.5 text-right">
                        {isEditing ? (
                          <div className="flex flex-col gap-1 items-end">
                            <input
                              type="number"
                              placeholder="Actual Kg"
                              value={actualYieldKg}
                              onChange={e => setActualYieldKg(Number(e.target.value))}
                              className="w-24 border border-slate-200 rounded p-1 font-mono text-xs text-right"
                            />
                            <input
                              type="number"
                              placeholder="Actual ZMW"
                              value={actualRevenue}
                              onChange={e => setActualRevenue(Number(e.target.value))}
                              className="w-24 border border-slate-200 rounded p-1 font-mono text-xs text-right font-bold text-emerald-600"
                            />
                          </div>
                        ) : yr.isHarvestCompleted ? (
                          <div>
                            <span className="font-mono font-black text-emerald-700 block">
                              {currencySymbol}{(yr.actualRevenue || 0).toLocaleString()}
                            </span>
                            <span className="text-[9.5px] font-mono text-slate-500">
                              {(yr.actualHarvestedKg || 0).toLocaleString()} kg harvested
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-400 italic">Pending Harvest</span>
                        )}
                      </td>

                      <td className="p-3.5 text-center">
                        {isEditing ? (
                          <div className="flex gap-1 justify-center">
                            <button
                              onClick={() => handleSaveActualHarvest(idx)}
                              className="px-2 py-1 bg-emerald-600 text-white rounded text-[10px] font-bold"
                            >
                              Save
                            </button>
                            <button
                              onClick={() => setEditingYearIndex(null)}
                              className="px-2 py-1 bg-slate-200 text-slate-700 rounded text-[10px]"
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleStartEdit(idx)}
                            className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-slate-800 rounded-lg transition-colors"
                            title="Log / Edit Actual Harvest"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-between items-center shrink-0">
          <span className="text-xs text-slate-500 font-medium">
            Harvest dates and yields sync with production schedules and agricultural financial ledger.
          </span>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs uppercase rounded-xl transition-all cursor-pointer"
          >
            Close Calendar
          </button>
        </div>

      </div>
    </div>
  );
}

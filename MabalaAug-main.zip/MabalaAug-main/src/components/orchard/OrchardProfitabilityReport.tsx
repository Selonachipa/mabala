import React, { useState, useMemo } from "react";
import { 
  TrendingUp, 
  DollarSign, 
  Users, 
  FileText, 
  Receipt, 
  Trees, 
  Calendar, 
  Download, 
  Plus, 
  CheckCircle2, 
  ArrowUpRight, 
  ArrowDownRight, 
  PieChart as PieChartIcon, 
  Briefcase,
  Layers,
  Sparkles,
  Printer,
  Scale,
  ShieldCheck,
  Building2,
  Percent,
  Wallet,
  Activity,
  X
} from "lucide-react";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  CartesianGrid 
} from "recharts";
import { 
  CropCycle, 
  Invoice, 
  CashSale, 
  OrchardActivity, 
  OrchardLabourLog, 
  OrchardYearHarvestSchedule,
  Employee,
  Payslip
} from "../../types";

interface OrchardProfitabilityReportProps {
  blocks: CropCycle[];
  selectedBlockId?: string;
  onSelectBlockId?: (id: string) => void;
  invoices: Invoice[];
  cashSales: CashSale[];
  orchardActivities: OrchardActivity[];
  expenses?: any[];
  employees?: Employee[];
  payslips?: Payslip[];
  currencySymbol?: string;
  onAddLabourLog?: (blockId: string, log: OrchardLabourLog) => void;
  onAuditBlock?: (block: CropCycle) => void;
  onOpenWizard?: () => void;
  showToast?: (msg: string, type: "success" | "error" | "info") => void;
  farmName?: string;
}

export default function OrchardProfitabilityReport({
  blocks,
  selectedBlockId: externalSelectedBlockId,
  onSelectBlockId,
  invoices = [],
  cashSales = [],
  orchardActivities = [],
  expenses = [],
  employees = [],
  payslips = [],
  currencySymbol = "ZK",
  onAddLabourLog,
  onAuditBlock,
  onOpenWizard,
  showToast,
  farmName = "Sunrise Agro-Tech Farm"
}: OrchardProfitabilityReportProps) {
  const [internalSelectedBlockId, setInternalSelectedBlockId] = useState<string>(
    blocks.length > 0 ? blocks[0].id : "ALL"
  );
  const [activeReportTab, setActiveReportTab] = useState<"overview" | "sales" | "payroll" | "operations">("overview");
  const [showPDFModal, setShowPDFModal] = useState(false);

  // Inline Log Labour Modal state
  const [showLabourModal, setShowLabourModal] = useState(false);
  const [selectedEmpId, setSelectedEmpId] = useState("");
  const [labourActivity, setLabourActivity] = useState<OrchardLabourLog["activityType"]>("Pruning");
  const [labourDate, setLabourDate] = useState(new Date().toISOString().split("T")[0]);
  const [hoursWorked, setHoursWorked] = useState<number>(8);
  const [hourlyRate, setHourlyRate] = useState<number>(25);
  const [labourNotes, setLabourNotes] = useState("");

  const currentSelectedBlockId = externalSelectedBlockId !== undefined 
    ? (externalSelectedBlockId || "ALL") 
    : internalSelectedBlockId;

  const handleBlockSelect = (id: string) => {
    setInternalSelectedBlockId(id);
    if (onSelectBlockId) {
      onSelectBlockId(id === "ALL" ? "" : id);
    }
  };

  // Only consider active perennial orchard blocks
  const orchardBlocks = useMemo(() => {
    return blocks.filter(b => b.orchard !== undefined || (b as any).isOrchard);
  }, [blocks]);

  // Selected single block (or null if "ALL")
  const selectedBlock = useMemo(() => {
    if (currentSelectedBlockId === "ALL" || !currentSelectedBlockId) {
      return orchardBlocks.length > 0 ? orchardBlocks[0] : null;
    }
    return orchardBlocks.find(b => b.id === currentSelectedBlockId) || (orchardBlocks.length > 0 ? orchardBlocks[0] : null);
  }, [orchardBlocks, currentSelectedBlockId]);

  // 5-Year Predicted Fruit Yields and Revenue Schedule for PDF Report
  const fiveYearSchedule = useMemo(() => {
    if (!selectedBlock) return [];
    const orchard = selectedBlock.orchard;
    if (orchard?.multiYearHarvestSchedule && orchard.multiYearHarvestSchedule.length > 0) {
      return orchard.multiYearHarvestSchedule.slice(0, 5);
    }

    const baseYear = new Date().getFullYear();
    const treeCount = orchard?.treeCount || 100;
    const fruitsPerTree = orchard?.estimatedFruitsPerTreePerHarvest || 50;
    const avgWeightKg = orchard?.averageFruitWeightKg || 0.35;
    const lossFactorPct = orchard?.possibleLossesPct || 8;
    const pricePerUnit = orchard?.pricePerUnitOrKg || 15;
    const pricingType = orchard?.measuredInKgOrUnits || "Kg";

    const stages = [
      { yr: 1, name: "Establishment / Vegetative", factor: 0.0 },
      { yr: 2, name: "First Bearing", factor: 0.25 },
      { yr: 3, name: "Rapid Ramping", factor: 0.60 },
      { yr: 4, name: "Full Production", factor: 0.90 },
      { yr: 5, name: "Peak Mature Harvest", factor: 1.00 }
    ];

    return stages.map(s => {
      const grossFruits = Math.round(treeCount * fruitsPerTree * s.factor);
      const netFruits = Math.round(grossFruits * (1 - lossFactorPct / 100));
      const grossYieldKg = Math.round(grossFruits * avgWeightKg);
      const netYieldKg = Math.round(grossYieldKg * (1 - lossFactorPct / 100));
      const projectedRev = pricingType === "Units" 
        ? Math.round(netFruits * pricePerUnit) 
        : Math.round(netYieldKg * pricePerUnit);

      return {
        yearNumber: s.yr,
        calendarYear: baseYear + (s.yr - 1),
        expectedHarvestDate: `${baseYear + (s.yr - 1)}-05-15`,
        lifecycleStage: s.name as OrchardYearHarvestSchedule["lifecycleStage"],
        yieldMultiplierPct: Math.round(s.factor * 100),
        projectedFruitsPerTree: Math.round(fruitsPerTree * s.factor),
        projectedYieldKg: netYieldKg,
        projectedRevenue: projectedRev,
        isHarvestCompleted: false
      };
    });
  }, [selectedBlock]);

  // ==========================================
  // 1. REVENUE AGGREGATION
  // ==========================================
  const salesData = useMemo(() => {
    if (!selectedBlock) return { invoices: [], cashSales: [], totalInvoiceRevenue: 0, totalCashRevenue: 0, totalRevenue: 0 };

    const blockId = selectedBlock.id;
    const blockName = selectedBlock.fieldBlock?.toLowerCase() || "";
    const fruitType = selectedBlock.orchard?.fruitType?.toLowerCase() || selectedBlock.cropType?.toLowerCase() || "";

    // 1a. Invoices linked to block
    const matchedInvoices = invoices.filter(inv => {
      if (inv.cropId === blockId || inv.cropCycleId === blockId) return true;
      if (inv.customerName && inv.customerName.toLowerCase().includes(blockName)) return true;
      if (inv.lines && inv.lines.some(l => l.description?.toLowerCase().includes(blockName) || l.description?.toLowerCase().includes(fruitType))) return true;
      return false;
    });

    const totalInvoiceRevenue = matchedInvoices.reduce((sum, inv) => {
      return sum + (inv.total || inv.paidAmount || 0);
    }, 0);

    // 1b. Cash POS sales linked to block
    const matchedCashSales = cashSales.filter(cs => {
      if (cs.cropCycleId === blockId) return true;
      if (cs.description && (cs.description.toLowerCase().includes(fruitType) || cs.description.toLowerCase().includes(blockName))) return true;
      if (cs.notes && cs.notes.toLowerCase().includes(blockName)) return true;
      return false;
    });

    const totalCashRevenue = matchedCashSales.reduce((sum, cs) => {
      return sum + (cs.amount || 0);
    }, 0);

    const totalRevenue = totalInvoiceRevenue + totalCashRevenue;

    return {
      invoices: matchedInvoices,
      cashSales: matchedCashSales,
      totalInvoiceRevenue,
      totalCashRevenue,
      totalRevenue
    };
  }, [selectedBlock, invoices, cashSales]);

  // ==========================================
  // 2. HR LABOR & PAYROLL COSTS AGGREGATION
  // ==========================================
  const payrollLaborData = useMemo(() => {
    if (!selectedBlock) return { 
      directLabourLogs: [], 
      directLabourCost: 0, 
      linkedPayslips: [], 
      payrollAllocationCost: 0, 
      totalLabourCost: 0,
      activityCostBreakdown: [] 
    };

    const blockId = selectedBlock.id;
    const labourLogs: OrchardLabourLog[] = selectedBlock.orchard?.labourLogs || [];
    const directLabourCost = labourLogs.reduce((sum, l) => sum + (l.totalLaborCost || 0), 0);

    // Find employees who logged work on this block
    const blockEmpIds = new Set(labourLogs.map(l => l.employeeId).filter(Boolean));
    
    // Matched payslips for employees who worked on this block
    const matchedPayslips = payslips.filter(p => {
      if (p.employeeId && blockEmpIds.has(p.employeeId)) return true;
      return false;
    });

    // Calculate statutory payroll employer costs (NAPSA, NHIMA, WCF) allocated
    const payrollStatutoryCost = matchedPayslips.reduce((sum, p) => {
      const employerContrib = (p.napsaEmployer || 0) + (p.nhimaEmployer || 0) + (p.wcfEmployer || 0) + (p.skillsLevyEmployer || 0);
      return sum + employerContrib;
    }, 0);

    const totalLabourCost = directLabourCost + (payrollStatutoryCost > 0 ? payrollStatutoryCost * 0.5 : 0);

    // Group labour cost by activity type
    const activityMap: Record<string, { count: number; hours: number; cost: number }> = {};
    labourLogs.forEach(l => {
      const act = l.activityType || "General";
      if (!activityMap[act]) {
        activityMap[act] = { count: 0, hours: 0, cost: 0 };
      }
      activityMap[act].count += 1;
      activityMap[act].hours += l.hoursWorked || 0;
      activityMap[act].cost += l.totalLaborCost || 0;
    });

    const activityCostBreakdown = Object.entries(activityMap).map(([activity, data]) => ({
      activity,
      ...data
    }));

    return {
      directLabourLogs: labourLogs,
      directLabourCost,
      linkedPayslips: matchedPayslips,
      payrollAllocationCost: payrollStatutoryCost,
      totalLabourCost,
      activityCostBreakdown
    };
  }, [selectedBlock, payslips]);

  // ==========================================
  // 3. FIELD OPERATIONS & INPUT EXPENSES
  // ==========================================
  const operationsCostData = useMemo(() => {
    if (!selectedBlock) return { activities: [], activitiesCost: 0, directExpenses: [], directExpensesCost: 0, totalOperationsCost: 0 };

    const blockId = selectedBlock.id;
    const blockName = selectedBlock.fieldBlock?.toLowerCase() || "";

    // 3a. Orchard activities (Spraying, fertilizing, pruning, irrigation)
    const blockActs = orchardActivities.filter(act => act.blockCropCycleId === blockId);
    const activitiesCost = blockActs.reduce((sum, a) => sum + (a.cost || 0), 0);

    // 3b. Accounting expenses ledger
    const blockExps = expenses.filter(exp => {
      if (exp.cropId === blockId) return true;
      if (exp.description && exp.description.toLowerCase().includes(blockName)) return true;
      if (exp.rows && exp.rows.some((r: any) => r.description?.toLowerCase().includes(blockName))) return true;
      return false;
    });
    const directExpensesCost = blockExps.reduce((sum, exp) => sum + (exp.total || exp.amount || 0), 0);

    const totalOperationsCost = activitiesCost + directExpensesCost;

    return {
      activities: blockActs,
      activitiesCost,
      directExpenses: blockExps,
      directExpensesCost,
      totalOperationsCost
    };
  }, [selectedBlock, orchardActivities, expenses]);

  // ==========================================
  // 4. FINANCIAL KPI & ROI COMPUTATION
  // ==========================================
  const financials = useMemo(() => {
    if (!selectedBlock) return {
      totalRevenue: 0,
      totalLabourCost: 0,
      totalOperationsCost: 0,
      totalProductionCost: 0,
      netOperatingProfit: 0,
      roiPercentage: 0,
      grossMarginPercentage: 0,
      revenueRealizationPct: 0,
      profitPerHectare: 0,
      profitPerTree: 0,
      costToIncomeRatioPct: 0,
      projectedAnnualRevenue: 0,
      treeCount: 0,
      blockAreaHa: 0
    };

    const treeCount = selectedBlock.orchard?.treeCount || 100;
    const blockAreaHa = selectedBlock.orchard?.blockAreaHa || selectedBlock.areaHectares || 1.0;
    const projectedAnnualRevenue = selectedBlock.orchard?.projectedAnnualRevenue || selectedBlock.expectedRevenueProjection || 0;

    const totalRevenue = salesData.totalRevenue;
    const totalLabourCost = payrollLaborData.totalLabourCost;
    const totalOperationsCost = operationsCostData.totalOperationsCost;
    const totalProductionCost = totalLabourCost + totalOperationsCost;

    const netOperatingProfit = totalRevenue - totalProductionCost;

    // ROI = (Net Profit / Total Production Cost) * 100%
    const roiPercentage = totalProductionCost > 0 
      ? Math.round((netOperatingProfit / totalProductionCost) * 100) 
      : (totalRevenue > 0 ? 100 : 0);

    // Gross Margin = (Net Profit / Total Revenue) * 100%
    const grossMarginPercentage = totalRevenue > 0 
      ? Math.round((netOperatingProfit / totalRevenue) * 100) 
      : 0;

    // Revenue Realization Rate = (Realized Sales / Projected Target) * 100%
    const revenueRealizationPct = projectedAnnualRevenue > 0 
      ? Math.round((totalRevenue / projectedAnnualRevenue) * 100) 
      : 0;

    const profitPerHectare = blockAreaHa > 0 ? Math.round(netOperatingProfit / blockAreaHa) : 0;
    const profitPerTree = treeCount > 0 ? Math.round(netOperatingProfit / treeCount) : 0;

    const costToIncomeRatioPct = totalRevenue > 0 
      ? Math.round((totalProductionCost / totalRevenue) * 100) 
      : 0;

    return {
      totalRevenue,
      totalLabourCost,
      totalOperationsCost,
      totalProductionCost,
      netOperatingProfit,
      roiPercentage,
      grossMarginPercentage,
      revenueRealizationPct,
      profitPerHectare,
      profitPerTree,
      costToIncomeRatioPct,
      projectedAnnualRevenue,
      treeCount,
      blockAreaHa
    };
  }, [selectedBlock, salesData, payrollLaborData, operationsCostData]);

  // Cost Distribution Data for Recharts Pie/Donut Chart
  const costDistributionData = useMemo(() => {
    const data = [
      { name: "HR Labor & Payroll", value: payrollLaborData.totalLabourCost, color: "#9333ea" },
      { name: "Field Activities & Sprays", value: operationsCostData.activitiesCost, color: "#3b82f6" },
      { name: "Direct Inputs & Fertilizers", value: operationsCostData.directExpensesCost, color: "#f59e0b" },
    ].filter(item => item.value > 0);

    return data.length > 0 ? data : [{ name: "No Costs Logged", value: 1, color: "#e2e8f0" }];
  }, [payrollLaborData, operationsCostData]);

  // P&L Comparison Data for Bar Chart
  const pnlComparisonData = useMemo(() => {
    return [
      {
        name: selectedBlock?.fieldBlock || "Orchard Block",
        "Total Sales Revenue": financials.totalRevenue,
        "Total Production Cost": financials.totalProductionCost,
        "Net Operating Profit": Math.max(0, financials.netOperatingProfit)
      }
    ];
  }, [selectedBlock, financials]);

  // Handle Employee select to auto-populate hourly rate
  const handleEmployeeChange = (empId: string) => {
    setSelectedEmpId(empId);
    const emp = employees.find(e => e.id === empId);
    if (emp) {
      if (emp.contractRate && emp.contractRate > 0) {
        setHourlyRate(Math.max(15, Math.round(emp.contractRate / 160)));
      } else {
        setHourlyRate(25);
      }
    }
  };

  const handleSaveLabourLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBlock || !onAddLabourLog) return;

    const emp = employees.find(e => e.id === selectedEmpId);
    const empName = emp ? emp.name : "Field Worker";
    const totalCost = hoursWorked * hourlyRate;

    const newLog: OrchardLabourLog = {
      id: `lab-${Date.now()}`,
      employeeId: selectedEmpId || undefined,
      employeeName: empName,
      activityType: labourActivity,
      date: labourDate,
      hoursWorked,
      hourlyRate,
      totalLaborCost: totalCost,
      notes: labourNotes
    };

    onAddLabourLog(selectedBlock.id, newLog);
    if (showToast) {
      showToast(`Logged ${hoursWorked}h ${labourActivity} labour (${currencySymbol}${totalCost}) for ${empName}`, "success");
    }
    setShowLabourModal(false);
    setLabourNotes("");
  };

  // Print Report
  const handlePrint = () => {
    window.print();
  };

  // Export CSV
  const handleExportCSV = () => {
    if (!selectedBlock) return;

    const headers = ["Metric", "Value", "Notes"];
    const rows = [
      ["Farm Name", farmName, ""],
      ["Orchard Block", selectedBlock.fieldBlock, selectedBlock.orchard?.fruitType || ""],
      ["Plant Population (Trees)", financials.treeCount.toString(), ""],
      ["Block Area (Hectares)", financials.blockAreaHa.toString(), ""],
      ["Projected Target Revenue", `${currencySymbol} ${financials.projectedAnnualRevenue.toLocaleString()}`, ""],
      ["Total Realized Sales Revenue", `${currencySymbol} ${financials.totalRevenue.toLocaleString()}`, "Invoices + POS Cash Sales"],
      ["Total HR Labor & Payroll Cost", `${currencySymbol} ${financials.totalLabourCost.toLocaleString()}`, "Direct staff logs & payroll allocations"],
      ["Total Field Operations & Input Costs", `${currencySymbol} ${financials.totalOperationsCost.toLocaleString()}`, "Sprays, fertilizers, irrigation"],
      ["Total Production Cost", `${currencySymbol} ${financials.totalProductionCost.toLocaleString()}`, ""],
      ["Net Operating Profit / (Loss)", `${currencySymbol} ${financials.netOperatingProfit.toLocaleString()}`, ""],
      ["Return on Investment (ROI %)", `${financials.roiPercentage}%`, "ROI = (Net Profit / Production Cost) * 100"],
      ["Operating Gross Margin %", `${financials.grossMarginPercentage}%`, "Margin = (Net Profit / Total Revenue) * 100"],
      ["Profit per Hectare", `${currencySymbol} ${financials.profitPerHectare.toLocaleString()}/ha`, ""],
      ["Profit per Tree", `${currencySymbol} ${financials.profitPerTree.toLocaleString()}/tree`, ""]
    ];

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(r => r.map(c => `"${c}"`).join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `mabala_orchard_profitability_${selectedBlock.fieldBlock.replace(/\s+/g, "_")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (orchardBlocks.length === 0) {
    return (
      <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 shadow-xs">
        <Trees className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <h3 className="text-sm font-bold text-slate-800">No Orchard Blocks Found</h3>
        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
          Establish perennial orchard blocks with the Block Setup Wizard to track sales, HR payroll allocations, and calculate ROI.
        </p>
      </div>
    );
  }

  const fruitName = selectedBlock?.orchard?.fruitType || selectedBlock?.cropType || "Fruit";
  const isDragonFruit = fruitName.toLowerCase().includes("dragon");

  return (
    <div className="space-y-6 font-sans">
      
      {/* 1. Header Toolbar & Block Selector */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 relative z-10">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded text-[9px] font-black uppercase tracking-wider font-mono">
                Executive Agriculture P&L
              </span>
              <span className="text-xs text-slate-400 font-mono font-medium">
                ISO/GAAP Agricultural Accounting Standard
              </span>
            </div>
            <h2 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-emerald-400" />
              <span>Orchard Profitability & ROI Report</span>
            </h2>
            <p className="text-xs text-slate-300 font-medium">
              Aggregated revenue from customer invoices & retail POS sales compared against HR payroll allocations and operational input costs for <strong className="text-emerald-400">{selectedBlock?.fieldBlock}</strong>.
            </p>
          </div>

          {/* Action Buttons & Block Switcher */}
          <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
            
            {/* Block Picker */}
            <div className="flex items-center gap-2 bg-slate-800/90 border border-slate-700 rounded-xl px-3 py-2 text-xs">
              <Layers className="w-4 h-4 text-emerald-400" />
              <select
                value={selectedBlock?.id || ""}
                onChange={(e) => handleBlockSelect(e.target.value)}
                className="bg-transparent font-extrabold text-white outline-none cursor-pointer text-xs"
              >
                {orchardBlocks.map(b => (
                  <option key={b.id} value={b.id} className="bg-slate-900 text-white">
                    {b.fieldBlock} — {b.orchard?.fruitType || b.cropType} ({b.orchard?.treeCount || 100} trees)
                  </option>
                ))}
              </select>
            </div>

            {/* Quick Log Labour Button */}
            {onAddLabourLog && (
              <button
                type="button"
                onClick={() => setShowLabourModal(true)}
                className="px-3.5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
                <span>Log HR Labour</span>
              </button>
            )}

            {/* Download PDF Report Button */}
            <button
              type="button"
              onClick={() => setShowPDFModal(true)}
              className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
              title="Generate & Download Formatted PDF Audit Document with ROI and 5-Year Projections"
            >
              <FileText className="w-4 h-4 text-emerald-100" />
              <span>Download PDF Report</span>
            </button>

            {/* Export CSV Button */}
            <button
              type="button"
              onClick={handleExportCSV}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
              title="Download Profitability Statement as CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            {/* Print Statement */}
            <button
              type="button"
              onClick={handlePrint}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
              title="Quick Print Audit Report"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>

          </div>
        </div>

        {/* Ambient Glow */}
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* 2. Executive Financial KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Total Realized Revenue */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-2 relative overflow-hidden">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-black uppercase text-emerald-800 tracking-wider">
              Total Realized Revenue
            </span>
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 font-mono tracking-tight">
              {currencySymbol} {financials.totalRevenue.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-[11px] font-bold text-emerald-600">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>{financials.revenueRealizationPct}% of Annual Target</span>
            </div>
          </div>
          <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-100 flex justify-between">
            <span>Invoices: {currencySymbol}{salesData.totalInvoiceRevenue.toLocaleString()}</span>
            <span>POS: {currencySymbol}{salesData.totalCashRevenue.toLocaleString()}</span>
          </div>
        </div>

        {/* Card 2: Total HR & Field Production Cost */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-2 relative overflow-hidden">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-black uppercase text-rose-800 tracking-wider">
              Total Production Costs
            </span>
            <div className="p-2 bg-rose-50 text-rose-600 rounded-lg">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 font-mono tracking-tight">
              {currencySymbol} {financials.totalProductionCost.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-[11px] font-bold text-slate-500">
              <span>{financials.costToIncomeRatioPct}% Cost-to-Income Ratio</span>
            </div>
          </div>
          <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-100 flex justify-between">
            <span className="text-purple-600 font-bold">HR: {currencySymbol}{financials.totalLabourCost.toLocaleString()}</span>
            <span className="text-amber-600 font-bold">Ops: {currencySymbol}{financials.totalOperationsCost.toLocaleString()}</span>
          </div>
        </div>

        {/* Card 3: Net Operating Profit / Margin */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-2 relative overflow-hidden">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-black uppercase text-indigo-800 tracking-wider">
              Net Operating Profit
            </span>
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className={`text-2xl font-black font-mono tracking-tight ${financials.netOperatingProfit >= 0 ? "text-emerald-700" : "text-rose-700"}`}>
              {financials.netOperatingProfit >= 0 ? "+" : ""}{currencySymbol} {financials.netOperatingProfit.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-[11px] font-bold text-indigo-600">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              <span>{financials.grossMarginPercentage}% Operating Margin</span>
            </div>
          </div>
          <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-100 flex justify-between">
            <span>{financials.treeCount} Trees</span>
            <span>{financials.blockAreaHa} Hectares</span>
          </div>
        </div>

        {/* Card 4: Clear ROI Calculation */}
        <div className="bg-gradient-to-br from-emerald-900 to-slate-900 text-white p-5 rounded-2xl border border-emerald-800 shadow-xs space-y-2 relative overflow-hidden">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-black uppercase text-emerald-300 tracking-widest font-mono">
              Return on Investment
            </span>
            <div className="p-2 bg-emerald-500/20 text-emerald-300 rounded-lg">
              <Percent className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-black font-mono tracking-tight text-emerald-400">
              {financials.roiPercentage >= 0 ? "+" : ""}{financials.roiPercentage}%
            </div>
            <div className="text-[11px] text-slate-300 mt-1 font-semibold">
              Net ROI on Logged Working Capital
            </div>
          </div>
          <div className="text-[9.5px] text-slate-300 pt-1 border-t border-slate-700/80 flex justify-between font-mono">
            <span>{currencySymbol}{financials.profitPerHectare.toLocaleString()} / ha</span>
            <span>{currencySymbol}{financials.profitPerTree.toLocaleString()} / tree</span>
          </div>
        </div>

      </div>

      {/* 3. Recharts Visual Analytics: Revenue vs Cost & Cost Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Chart A: P&L Comparison Bar Chart */}
        <div className="lg:col-span-2 bg-white p-5 md:p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider">
                Financial Performance Comparison
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                Direct comparison between Realized Gross Sales, Total Production Costs, and Net Realized Profit.
              </p>
            </div>
            <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded text-[9.5px] font-black uppercase">
              {selectedBlock?.fieldBlock}
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={pnlComparisonData} margin={{ top: 15, right: 15, left: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={11} fontWeight={700} tickLine={false} />
                <YAxis 
                  stroke="#64748b" 
                  fontSize={10} 
                  fontWeight={700} 
                  tickLine={false} 
                  axisLine={false} 
                  tickFormatter={(v) => `${currencySymbol} ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`}
                />
                <Tooltip
                  formatter={(value: any) => [`${currencySymbol} ${Number(value).toLocaleString()}`, ""]}
                  contentStyle={{ backgroundColor: "#0f172a", borderRadius: "12px", border: "1px solid #334155", color: "#fff", fontSize: "11px" }}
                />
                <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: '10px', fontSize: '11px', fontWeight: 600 }} />
                <Bar dataKey="Total Sales Revenue" fill="#10b981" radius={[6, 6, 0, 0]} maxBarSize={60} />
                <Bar dataKey="Total Production Cost" fill="#f43f5e" radius={[6, 6, 0, 0]} maxBarSize={60} />
                <Bar dataKey="Net Operating Profit" fill="#6366f1" radius={[6, 6, 0, 0]} maxBarSize={60} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart B: Production Cost Structure Donut Chart */}
        <div className="bg-white p-5 md:p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4 flex flex-col justify-between">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider">
              Cost Structure Distribution
            </h3>
            <p className="text-[11px] text-slate-500 font-medium">
              HR staff payroll allocation vs direct field spray/fertilizer expenses.
            </p>
          </div>

          <div className="h-48 w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={costDistributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {costDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: any) => [`${currencySymbol} ${Number(value).toLocaleString()}`, "Cost"]}
                  contentStyle={{ backgroundColor: "#0f172a", borderRadius: "12px", border: "1px solid #334155", color: "#fff", fontSize: "11px" }}
                />
              </PieChart>
            </ResponsiveContainer>

            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-[9px] uppercase font-black text-slate-400">Total Cost</span>
              <span className="text-xs font-black text-slate-800 font-mono">
                {currencySymbol}{financials.totalProductionCost.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Donut Legend */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100 text-xs">
            {costDistributionData.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-600 font-semibold">{item.name}</span>
                </div>
                <span className="font-mono font-bold text-slate-900">
                  {currencySymbol} {item.value.toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* 4. Detailed Audit Tabs (Sales, HR Payroll, Operations) */}
      <div className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden shadow-xs">
        
        {/* Navigation Tab Header */}
        <div className="flex border-b border-slate-200 bg-slate-50/70 overflow-x-auto px-4 pt-2 gap-2">
          {[
            { id: "overview", label: "Executive Statement", icon: FileText },
            { id: "sales", label: `Realized Sales (${salesData.invoices.length + salesData.cashSales.length})`, icon: DollarSign },
            { id: "payroll", label: `HR & Payroll Labor (${payrollLaborData.directLabourLogs.length})`, icon: Users },
            { id: "operations", label: `Field Ops & Inputs (${operationsCostData.activities.length + operationsCostData.directExpenses.length})`, icon: Activity }
          ].map(t => {
            const Icon = t.icon;
            const isActive = activeReportTab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveReportTab(t.id as any)}
                className={`flex items-center gap-2 py-3 px-4 text-xs font-bold uppercase border-b-2 tracking-wider transition-all cursor-pointer ${
                  isActive 
                    ? "border-emerald-600 text-emerald-700 bg-white rounded-t-xl font-extrabold shadow-2xs" 
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab 1: Executive Statement */}
        {activeReportTab === "overview" && (
          <div className="p-6 space-y-6">
            <div className="max-w-3xl space-y-4">
              <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                <span className="text-xs font-black uppercase text-slate-600">Accounting Line Item</span>
                <span className="text-xs font-black uppercase text-slate-600">Amount ({currencySymbol})</span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center py-1.5 font-bold text-slate-800">
                  <span>1. Gross Invoiced Revenue (B2B / Supermarkets)</span>
                  <span className="font-mono text-emerald-700">{currencySymbol} {salesData.totalInvoiceRevenue.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center py-1.5 font-bold text-slate-800">
                  <span>2. Retail POS Cash Sales Receipts</span>
                  <span className="font-mono text-emerald-700">{currencySymbol} {salesData.totalCashRevenue.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center py-2 bg-emerald-50/60 px-3 rounded-lg font-black text-emerald-950 border border-emerald-200">
                  <span>TOTAL REALIZED SALES REVENUE</span>
                  <span className="font-mono text-sm">{currencySymbol} {financials.totalRevenue.toLocaleString()}</span>
                </div>

                <div className="pt-3" />

                <div className="flex justify-between items-center py-1.5 font-bold text-slate-800">
                  <span>3. Direct HR Labor (Pruning, Weeding, Harvesting)</span>
                  <span className="font-mono text-rose-700">-{currencySymbol} {payrollLaborData.directLabourCost.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center py-1.5 font-bold text-slate-800">
                  <span>4. Payroll Statutory Employer Contributions (NAPSA, NHIMA, WCF)</span>
                  <span className="font-mono text-rose-700">-{currencySymbol} {payrollLaborData.payrollAllocationCost.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center py-1.5 font-bold text-slate-800">
                  <span>5. Field Activities (Chemical Sprays, Fertigation, Irrigation)</span>
                  <span className="font-mono text-rose-700">-{currencySymbol} {operationsCostData.activitiesCost.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center py-1.5 font-bold text-slate-800">
                  <span>6. Direct Physical Inputs (Fertilizer Bags, Seedlings, Trellis Hardware)</span>
                  <span className="font-mono text-rose-700">-{currencySymbol} {operationsCostData.directExpensesCost.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center py-2 bg-rose-50/60 px-3 rounded-lg font-black text-rose-950 border border-rose-200">
                  <span>TOTAL PRODUCTION COSTS</span>
                  <span className="font-mono text-sm">-{currencySymbol} {financials.totalProductionCost.toLocaleString()}</span>
                </div>

                <div className="pt-3" />

                <div className="flex justify-between items-center p-4 bg-slate-900 text-white rounded-xl font-black text-sm">
                  <div>
                    <span className="block text-emerald-400 text-[10px] uppercase tracking-widest font-mono">
                      NET OPERATING PROFIT / (LOSS)
                    </span>
                    <span>{selectedBlock?.fieldBlock} Operating Result</span>
                  </div>
                  <span className="font-mono text-lg text-emerald-400">
                    {financials.netOperatingProfit >= 0 ? "+" : ""}{currencySymbol} {financials.netOperatingProfit.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Sales Ledger */}
        {activeReportTab === "sales" && (
          <div className="p-6 space-y-4">
            <span className="text-xs font-bold text-slate-600 block">
              Invoices and Direct Point-of-Sale Transactions Allocated to {selectedBlock?.fieldBlock}
            </span>

            {salesData.invoices.length === 0 && salesData.cashSales.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200">
                <DollarSign className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <h4 className="text-xs font-bold text-slate-700">No Sales Transactions Logged</h4>
                <p className="text-[11px] text-slate-400 mt-1">
                  Create customer invoices in Invoicing or record cash receipts in Direct Sales tagging this block.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-slate-50 text-[10px] text-slate-500 uppercase font-black tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="p-3">Reference</th>
                      <th className="p-3">Customer</th>
                      <th className="p-3">Date</th>
                      <th className="p-3">Type</th>
                      <th className="p-3 text-right">Revenue ({currencySymbol})</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {salesData.invoices.map(inv => (
                      <tr key={inv.id} className="hover:bg-slate-50/60">
                        <td className="p-3 font-mono font-bold text-indigo-600">{inv.invoiceNumber}</td>
                        <td className="p-3 font-semibold text-slate-900">{inv.customerName}</td>
                        <td className="p-3 font-mono text-slate-500">{inv.date}</td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 rounded text-[9px] font-bold uppercase">
                            Invoice ({inv.status})
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono font-black text-emerald-600">
                          {currencySymbol} {(inv.total || inv.paidAmount || 0).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                    {salesData.cashSales.map(cs => (
                      <tr key={cs.id} className="hover:bg-slate-50/60">
                        <td className="p-3 font-mono font-bold text-emerald-600">{cs.receiptNumber || cs.id.slice(0, 8)}</td>
                        <td className="p-3 font-semibold text-slate-900">{cs.customer || "Cash Buyer"}</td>
                        <td className="p-3 font-mono text-slate-500">{cs.date}</td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded text-[9px] font-bold uppercase">
                            Direct POS
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono font-black text-emerald-600">
                          {currencySymbol} {(cs.amount || 0).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: HR & Payroll Labor Ledger */}
        {activeReportTab === "payroll" && (
          <div className="p-6 space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-600">
                Direct Field Staff Labor & Payroll Allocations for {selectedBlock?.fieldBlock}
              </span>
              {onAddLabourLog && (
                <button
                  type="button"
                  onClick={() => setShowLabourModal(true)}
                  className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 stroke-[3]" />
                  <span>Log HR Labour</span>
                </button>
              )}
            </div>

            {payrollLaborData.directLabourLogs.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200">
                <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <h4 className="text-xs font-bold text-slate-700">No HR Labor Logged for this Block</h4>
                <p className="text-[11px] text-slate-400 mt-1">
                  Allocate staff hours (pruning, spraying, harvesting, grafting) from the HR & Payroll module.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-slate-50 text-[10px] text-slate-500 uppercase font-black tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="p-3">Date</th>
                      <th className="p-3">Staff Name</th>
                      <th className="p-3">Task / Activity</th>
                      <th className="p-3 text-center">Hours</th>
                      <th className="p-3 text-center">Rate</th>
                      <th className="p-3 text-right">Labor Cost ({currencySymbol})</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {payrollLaborData.directLabourLogs.map(log => (
                      <tr key={log.id} className="hover:bg-slate-50/60">
                        <td className="p-3 font-mono text-slate-500">{log.date}</td>
                        <td className="p-3 font-semibold text-slate-900">{log.employeeName}</td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 bg-purple-50 text-purple-700 border border-purple-200 rounded text-[9px] font-bold uppercase">
                            {log.activityType}
                          </span>
                          {log.notes && <span className="text-[9.5px] text-slate-400 block mt-0.5">{log.notes}</span>}
                        </td>
                        <td className="p-3 text-center font-mono font-bold">{log.hoursWorked}h</td>
                        <td className="p-3 text-center font-mono text-slate-500">{currencySymbol}{log.hourlyRate}/h</td>
                        <td className="p-3 text-right font-mono font-black text-purple-900">
                          {currencySymbol} {(log.totalLaborCost || 0).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Field Operations & Inputs */}
        {activeReportTab === "operations" && (
          <div className="p-6 space-y-4">
            <span className="text-xs font-bold text-slate-600 block">
              Field Operations, Spray Applications, Fertigation & Materials for {selectedBlock?.fieldBlock}
            </span>

            {operationsCostData.activities.length === 0 && operationsCostData.directExpenses.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200">
                <Activity className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <h4 className="text-xs font-bold text-slate-700">No Operations or Field Inputs Logged</h4>
                <p className="text-[11px] text-slate-400 mt-1">
                  Record sprays, fertilization, and general orchard activities in Field Activity Logs.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-slate-50 text-[10px] text-slate-500 uppercase font-black tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="p-3">Date</th>
                      <th className="p-3">Activity / Material</th>
                      <th className="p-3">Category</th>
                      <th className="p-3">Operator / Supplier</th>
                      <th className="p-3 text-right">Cost ({currencySymbol})</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {operationsCostData.activities.map(act => (
                      <tr key={act.id} className="hover:bg-slate-50/60">
                        <td className="p-3 font-mono text-slate-500">{act.createdAt?.split("T")[0] || "-"}</td>
                        <td className="p-3 font-semibold text-slate-900 capitalize">
                          {act.activityType} ({act.product || "Field Maintenance"})
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded text-[9px] font-bold uppercase">
                            Field Activity
                          </span>
                        </td>
                        <td className="p-3 text-slate-600">{act.operator || "Farm Crew"}</td>
                        <td className="p-3 text-right font-mono font-black text-rose-600">
                          {currencySymbol} {(act.cost || 0).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                    {operationsCostData.directExpenses.map((exp: any) => (
                      <tr key={exp.id} className="hover:bg-slate-50/60">
                        <td className="p-3 font-mono text-slate-500">{exp.date || "-"}</td>
                        <td className="p-3 font-semibold text-slate-900">{exp.description || exp.category || "Field Input"}</td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded text-[9px] font-bold uppercase">
                            {exp.category || "Input Expense"}
                          </span>
                        </td>
                        <td className="p-3 text-slate-600">{exp.supplierName || exp.vendor || "-"}</td>
                        <td className="p-3 text-right font-mono font-black text-rose-600">
                          {currencySymbol} {(exp.total || exp.amount || 0).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

      </div>

      {/* 5. Inline Add Labour Modal */}
      {showLabourModal && selectedBlock && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-purple-600" />
                <span>Allocate Staff Labor to {selectedBlock.fieldBlock}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowLabourModal(false)}
                className="text-slate-400 hover:text-slate-600 font-black text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveLabourLog} className="space-y-4">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                  Employee (From HR & Payroll) *
                </label>
                <select
                  value={selectedEmpId}
                  onChange={(e) => handleEmployeeChange(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold text-xs outline-none"
                >
                  <option value="">-- Choose Employee --</option>
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.role || "Farm Worker"})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                    Activity Type *
                  </label>
                  <select
                    value={labourActivity}
                    onChange={(e) => setLabourActivity(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold text-xs outline-none"
                  >
                    <option value="Pruning">Pruning & Canopy</option>
                    <option value="Harvesting">Fruit Harvesting</option>
                    <option value="Spraying">Chemical Spraying</option>
                    <option value="Weeding">Weeding & Slashing</option>
                    <option value="Grafting">Grafting & Budding</option>
                    <option value="Irrigation">Irrigation Maintenance</option>
                    <option value="Canopy Management">Trellis Management</option>
                    <option value="Other">General Labor</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    value={labourDate}
                    onChange={(e) => setLabourDate(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold text-xs outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                    Hours Worked
                  </label>
                  <input
                    type="number"
                    min="0.5"
                    step="0.5"
                    value={hoursWorked}
                    onChange={(e) => setHoursWorked(parseFloat(e.target.value) || 0)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono font-bold text-xs outline-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                    Hourly Rate ({currencySymbol}/h)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={hourlyRate}
                    onChange={(e) => setHourlyRate(parseFloat(e.target.value) || 0)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono font-bold text-xs outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                  Work Notes / Task Specifics
                </label>
                <input
                  type="text"
                  placeholder="e.g. Trellis vine tying, summer pruning on rows 1-8"
                  value={labourNotes}
                  onChange={(e) => setLabourNotes(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs outline-none"
                />
              </div>

              <div className="p-3 bg-purple-50 rounded-xl border border-purple-100 flex justify-between items-center text-xs">
                <span className="font-bold text-purple-900">Total Calculated Cost:</span>
                <span className="font-mono font-black text-purple-900 text-sm">
                  {currencySymbol} {(hoursWorked * hourlyRate).toLocaleString()}
                </span>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowLabourModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white font-black text-xs uppercase tracking-wider rounded-xl cursor-pointer shadow-md"
                >
                  Save & Allocate Labor
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 9. FORMATTED PDF AUDIT REPORT MODAL & PRINT VIEW */}
      {/* ========================================================================= */}
      {showPDFModal && selectedBlock && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-[1300] flex items-center justify-center p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static print:z-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full overflow-hidden max-h-[92vh] flex flex-col my-auto print:max-h-none print:shadow-none print:border-none print:w-full print:rounded-none">
            
            {/* Modal Actions Bar (Hidden on Print) */}
            <div className="p-4 border-b border-slate-200 bg-slate-900 text-white flex justify-between items-center shrink-0 print:hidden">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">
                    Formatted PDF Audit Report Preview
                  </h3>
                  <p className="text-[10px] text-slate-400">
                    Ready for export: Click &quot;Download PDF / Print&quot; and select &quot;Save as PDF&quot; in destination.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
                >
                  <Printer className="w-4 h-4" />
                  <span>Download PDF / Print</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowPDFModal(false)}
                  className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center text-sm font-bold transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Printable Document Container */}
            <div className="p-8 overflow-y-auto flex-1 text-slate-900 space-y-6 print:p-0 print:space-y-4 font-sans text-xs">
              
              {/* Document Header */}
              <div className="border-b-2 border-emerald-600 pb-5 flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 font-mono font-black text-[9px] uppercase tracking-wider rounded">
                      Commercial Orchard Audit
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">
                      Report Ref: ORC-{selectedBlock.id.slice(-6).toUpperCase()}-{new Date().getFullYear()}
                    </span>
                  </div>
                  <h1 className="text-2xl font-black text-slate-950 mt-1 tracking-tight">
                    {farmName}
                  </h1>
                  <p className="text-xs text-slate-600 font-medium">
                    Orchard Block Profitability &amp; 5-Year Yield Valuation Statement
                  </p>
                </div>

                <div className="text-right text-xs">
                  <div className="font-bold text-slate-900">Generated: {new Date().toLocaleDateString()}</div>
                  <div className="text-[10px] text-slate-500">Standards: GAAP Agricultural Accounting</div>
                  <div className="text-[10px] text-slate-500">Currency: {currencySymbol} (ZMW)</div>
                </div>
              </div>

              {/* Block Specification Profile */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                <div>
                  <span className="text-[9px] uppercase font-black text-slate-400 block font-mono">Field Block</span>
                  <span className="font-extrabold text-slate-900 text-sm">{selectedBlock.fieldBlock}</span>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-black text-slate-400 block font-mono">Fruit Crop &amp; Variety</span>
                  <span className="font-extrabold text-slate-900 text-sm">
                    {selectedBlock.orchard?.fruitType || selectedBlock.cropType} ({selectedBlock.orchard?.variety || selectedBlock.variety || "Standard"})
                  </span>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-black text-slate-400 block font-mono">Tree Population &amp; Area</span>
                  <span className="font-extrabold text-slate-900 text-sm">
                    {financials.treeCount.toLocaleString()} Trees ({financials.blockAreaHa} ha)
                  </span>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-black text-slate-400 block font-mono">Lifespan &amp; Rootstock</span>
                  <span className="font-extrabold text-slate-900 text-sm">
                    {selectedBlock.orchard?.treeLifespanYears || 20} Yrs • {selectedBlock.orchard?.rootstock || "Standard"}
                  </span>
                </div>
              </div>

              {/* SECTION 1: ROI & Financial Summary Matrix */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-black uppercase text-slate-800 font-mono tracking-wider border-b border-slate-200 pb-1">
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                  <span>1. Executive ROI &amp; Financial Performance Summary</span>
                </div>

                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center">
                  <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-lg">
                    <span className="text-[9px] uppercase font-black text-emerald-800 block">Total Revenue</span>
                    <span className="font-mono font-black text-sm text-emerald-950">
                      {currencySymbol}{financials.totalRevenue.toLocaleString()}
                    </span>
                  </div>
                  <div className="bg-purple-50 border border-purple-200 p-2.5 rounded-lg">
                    <span className="text-[9px] uppercase font-black text-purple-800 block">HR Labour Cost</span>
                    <span className="font-mono font-black text-sm text-purple-950">
                      {currencySymbol}{financials.totalLabourCost.toLocaleString()}
                    </span>
                  </div>
                  <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-lg">
                    <span className="text-[9px] uppercase font-black text-amber-800 block">Field Ops Cost</span>
                    <span className="font-mono font-black text-sm text-amber-950">
                      {currencySymbol}{financials.totalOperationsCost.toLocaleString()}
                    </span>
                  </div>
                  <div className="bg-slate-100 border border-slate-300 p-2.5 rounded-lg">
                    <span className="text-[9px] uppercase font-black text-slate-700 block">Total Cost</span>
                    <span className="font-mono font-black text-sm text-slate-950">
                      {currencySymbol}{financials.totalProductionCost.toLocaleString()}
                    </span>
                  </div>
                  <div className={`p-2.5 rounded-lg border ${financials.netOperatingProfit >= 0 ? "bg-emerald-100 border-emerald-300 text-emerald-950" : "bg-rose-100 border-rose-300 text-rose-950"}`}>
                    <span className="text-[9px] uppercase font-black block">Net Profit</span>
                    <span className="font-mono font-black text-sm">
                      {currencySymbol}{financials.netOperatingProfit.toLocaleString()}
                    </span>
                  </div>
                  <div className="bg-indigo-50 border border-indigo-200 p-2.5 rounded-lg">
                    <span className="text-[9px] uppercase font-black text-indigo-800 block">ROI %</span>
                    <span className="font-mono font-black text-sm text-indigo-950">
                      {financials.roiPercentage}%
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px] text-slate-600">
                  <div className="p-2 bg-white border border-slate-200 rounded">
                    <strong>Operating Margin:</strong> {financials.grossMarginPercentage}%
                  </div>
                  <div className="p-2 bg-white border border-slate-200 rounded">
                    <strong>Profit / Hectare:</strong> {currencySymbol}{financials.profitPerHectare.toLocaleString()}/ha
                  </div>
                  <div className="p-2 bg-white border border-slate-200 rounded">
                    <strong>Profit / Tree:</strong> {currencySymbol}{financials.profitPerTree.toLocaleString()}/tree
                  </div>
                  <div className="p-2 bg-white border border-slate-200 rounded">
                    <strong>Revenue Target Realization:</strong> {financials.revenueRealizationPct}%
                  </div>
                </div>
              </div>

              {/* SECTION 2: 5-Year Predicted Fruit Yields & Visual Projections */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center gap-1.5 text-xs font-black uppercase text-slate-800 font-mono tracking-wider border-b border-slate-200 pb-1">
                  <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                  <span>2. Five-Year Predicted Fruit Yields &amp; Multi-Year Revenue Forecast</span>
                </div>

                <table className="w-full text-left border border-slate-200 rounded-lg overflow-hidden text-[11px]">
                  <thead className="bg-slate-100 font-bold text-slate-700 uppercase font-mono text-[9px]">
                    <tr>
                      <th className="p-2">Season / Year</th>
                      <th className="p-2">Lifecycle Stage</th>
                      <th className="p-2 text-center">Bearing Curve</th>
                      <th className="p-2 text-right">Projected Yield (Kg)</th>
                      <th className="p-2 text-right">Cull Loss Deduction</th>
                      <th className="p-2 text-right">Price Tier</th>
                      <th className="p-2 text-right">Net Projected Revenue</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {fiveYearSchedule.map((yr) => (
                      <tr key={yr.yearNumber} className="hover:bg-slate-50">
                        <td className="p-2 font-mono font-bold">
                          Year {yr.yearNumber} ({yr.calendarYear})
                        </td>
                        <td className="p-2">
                          <span className="font-semibold text-slate-800">{yr.lifecycleStage}</span>
                        </td>
                        <td className="p-2 text-center font-mono font-bold text-indigo-700">
                          {yr.yieldMultiplierPct}%
                        </td>
                        <td className="p-2 text-right font-mono font-bold">
                          {yr.projectedYieldKg.toLocaleString()} kg
                        </td>
                        <td className="p-2 text-right font-mono text-slate-500">
                          {selectedBlock.orchard?.possibleLossesPct || 8}%
                        </td>
                        <td className="p-2 text-right font-mono text-slate-700">
                          {currencySymbol}{selectedBlock.orchard?.pricePerUnitOrKg || 15}/{selectedBlock.orchard?.measuredInKgOrUnits === "Units" ? "unit" : "kg"}
                        </td>
                        <td className="p-2 text-right font-mono font-black text-emerald-700">
                          {currencySymbol}{yr.projectedRevenue.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* SECTION 3: Cost Structure Breakdown */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center gap-1.5 text-xs font-black uppercase text-slate-800 font-mono tracking-wider border-b border-slate-200 pb-1">
                  <Briefcase className="w-3.5 h-3.5 text-purple-600" />
                  <span>3. Direct Cost Structure Ledger (HR Payroll + Operations)</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                  <div className="p-2 bg-slate-50 border border-slate-200 rounded">
                    <span className="text-[9px] uppercase font-bold text-slate-500 block">HR Payroll Wages</span>
                    <span className="font-mono font-black text-purple-900">{currencySymbol}{financials.totalLabourCost.toLocaleString()}</span>
                  </div>
                  <div className="p-2 bg-slate-50 border border-slate-200 rounded">
                    <span className="text-[9px] uppercase font-bold text-slate-500 block">Field Activities Cost</span>
                    <span className="font-mono font-black text-slate-900">{currencySymbol}{operationsCostData.activitiesCost.toLocaleString()}</span>
                  </div>
                  <div className="p-2 bg-slate-50 border border-slate-200 rounded">
                    <span className="text-[9px] uppercase font-bold text-slate-500 block">Direct Material Inputs</span>
                    <span className="font-mono font-black text-slate-900">{currencySymbol}{operationsCostData.directExpensesCost.toLocaleString()}</span>
                  </div>
                  <div className="p-2 bg-slate-50 border border-slate-200 rounded">
                    <span className="text-[9px] uppercase font-bold text-slate-500 block">Total Operations Cost</span>
                    <span className="font-mono font-black text-slate-900">{currencySymbol}{financials.totalOperationsCost.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* SECTION 4: Sign-off & Audit Certification */}
              <div className="pt-6 border-t-2 border-slate-200 grid grid-cols-2 gap-8 text-[11px]">
                <div>
                  <div className="border-b border-slate-400 pb-6 mb-1"></div>
                  <span className="font-bold text-slate-800 block">Prepared By: Lead Agronomist / Orchard Manager</span>
                  <span className="text-[10px] text-slate-400">Signature &amp; Certification Date</span>
                </div>
                <div>
                  <div className="border-b border-slate-400 pb-6 mb-1"></div>
                  <span className="font-bold text-slate-800 block">Approved By: Chief Financial Controller</span>
                  <span className="text-[10px] text-slate-400">Authorized Farm Officer</span>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
}

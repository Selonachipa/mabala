import React, { useState } from "react";
import { 
  TrendingUp, 
  DollarSign, 
  Users, 
  FileText, 
  Receipt, 
  Trees, 
  Calendar, 
  Download, 
  Plus, 
  CheckCircle2, 
  ArrowUpRight, 
  ArrowDownRight, 
  PieChart, 
  Briefcase,
  Layers,
  Sparkles,
  AlertCircle
} from "lucide-react";
import { 
  CropCycle, 
  Invoice, 
  CashSale, 
  OrchardActivity, 
  OrchardLabourLog, 
  Employee 
} from "../../types";

interface OrchardBlockProfitabilityModalProps {
  isOpen: boolean;
  onClose: () => void;
  block: CropCycle;
  invoices: Invoice[];
  cashSales: CashSale[];
  orchardActivities: OrchardActivity[];
  expenses: any[];
  employees: Employee[];
  currencySymbol: string;
  onAddLabourLog: (blockId: string, log: OrchardLabourLog) => void;
  onRecordSaleClick?: (block: CropCycle) => void;
  showToast: (msg: string, type: "success" | "error" | "info") => void;
}

export default function OrchardBlockProfitabilityModal({
  isOpen,
  onClose,
  block,
  invoices,
  cashSales,
  orchardActivities,
  expenses,
  employees,
  currencySymbol,
  onAddLabourLog,
  onRecordSaleClick,
  showToast
}: OrchardBlockProfitabilityModalProps) {
  const [activeTab, setActiveTab] = useState<"summary" | "sales" | "expenses" | "labour">("summary");
  
  // State for adding labour
  const [showAddLabourForm, setShowAddLabourForm] = useState(false);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState("");
  const [labourActivityType, setLabourActivityType] = useState<OrchardLabourLog["activityType"]>("Pruning");
  const [labourDate, setLabourDate] = useState(new Date().toISOString().split("T")[0]);
  const [hoursWorked, setHoursWorked] = useState<number>(8);
  const [hourlyRate, setHourlyRate] = useState<number>(25);
  const [labourNotes, setLabourNotes] = useState("");

  if (!isOpen) return null;

  const orchard = block.orchard;
  const fruitType = orchard?.fruitType || block.cropType || "Fruit";
  const variety = orchard?.variety || block.variety || "";
  const treeCount = orchard?.treeCount || 100;
  const blockAreaHa = orchard?.blockAreaHa || block.areaHectares || 1.0;

  // 1. FILTER SALES
  // Invoices matching this block
  const blockInvoices = invoices.filter(inv => 
    inv.cropId === block.id || 
    inv.cropCycleId === block.id ||
    (inv.customerName && inv.customerName.toLowerCase().includes(block.fieldBlock.toLowerCase())) ||
    (inv.lines && inv.lines.some(it => it.description?.toLowerCase().includes(block.fieldBlock.toLowerCase())))
  );
  const invoiceRevenue = blockInvoices.reduce((sum, inv) => {
    return sum + (inv.total || inv.paidAmount || 0);
  }, 0);

  // Cash sales matching this block
  const blockCashSales = cashSales.filter(cs => 
    cs.cropCycleId === block.id || 
    (cs.description && cs.description.toLowerCase().includes(fruitType.toLowerCase())) ||
    (cs.notes && cs.notes.toLowerCase().includes(block.fieldBlock.toLowerCase()))
  );
  const cashSaleRevenue = blockCashSales.reduce((sum, cs) => sum + (cs.amount || 0), 0);

  const totalRealizedSales = invoiceRevenue + cashSaleRevenue;

  // 2. FILTER EXPENSES
  // Orchard activities (spraying, fertilizer, pruning, pollination)
  const blockActivities = orchardActivities.filter(act => act.blockCropCycleId === block.id);
  const activitiesCost = blockActivities.reduce((sum, act) => sum + (act.cost || 0), 0);

  // Direct expenses from accounting module
  const blockExpenses = (expenses || []).filter(exp => 
    exp.cropId === block.id || 
    (exp.description && exp.description.toLowerCase().includes(block.fieldBlock.toLowerCase())) ||
    (exp.rows && exp.rows.some((r: any) => r.description?.toLowerCase().includes(block.fieldBlock.toLowerCase())))
  );
  const directExpensesCost = blockExpenses.reduce((sum, exp) => sum + (exp.total || exp.amount || 0), 0);

  // 3. FILTER LABOUR (HR Module)
  const labourLogs: OrchardLabourLog[] = orchard?.labourLogs || [];
  const totalLabourCost = labourLogs.reduce((sum, l) => sum + (l.totalLaborCost || 0), 0);

  // 4. TOTAL PRODUCTION COSTS & PROFITABILITY
  const totalProductionCost = activitiesCost + directExpensesCost + totalLabourCost;
  const netOperatingProfit = totalRealizedSales - totalProductionCost;
  const operatingMarginPct = totalRealizedSales > 0 ? Math.round((netOperatingProfit / totalRealizedSales) * 100) : 0;
  const roiPct = totalProductionCost > 0 ? Math.round((netOperatingProfit / totalProductionCost) * 100) : 0;
  const profitPerHectare = blockAreaHa > 0 ? netOperatingProfit / blockAreaHa : 0;
  const profitPerTree = treeCount > 0 ? netOperatingProfit / treeCount : 0;

  // Projected Annual Revenue for comparison
  const projectedAnnualRevenue = orchard?.projectedAnnualRevenue || block.expectedRevenueProjection || 0;
  const revenueRealizationPct = projectedAnnualRevenue > 0 ? Math.round((totalRealizedSales / projectedAnnualRevenue) * 100) : 0;

  // Handle employee select to auto-populate hourly rate
  const handleEmployeeSelect = (empId: string) => {
    setSelectedEmployeeId(empId);
    const emp = employees.find(e => e.id === empId);
    if (emp) {
      if (emp.contractRate && emp.contractRate > 0) {
        // approximate hourly rate: monthly contractRate / 160 hrs
        setHourlyRate(Math.max(15, Math.round(emp.contractRate / 160)));
      } else {
        setHourlyRate(25);
      }
    }
  };

  const handleSaveLabour = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = employees.find(e => e.id === selectedEmployeeId);
    const empName = emp ? emp.name : "Field Worker";

    const totalCost = hoursWorked * hourlyRate;
    const newLog: OrchardLabourLog = {
      id: `lab-${Date.now()}`,
      employeeId: selectedEmployeeId || undefined,
      employeeName: empName,
      activityType: labourActivityType,
      date: labourDate,
      hoursWorked,
      hourlyRate,
      totalLaborCost: totalCost,
      notes: labourNotes
    };

    onAddLabourLog(block.id, newLog);
    showToast(`Logged ${hoursWorked}h ${labourActivityType} labour (${currencySymbol}${totalCost}) for ${empName}`, "success");
    setShowAddLabourForm(false);
    setLabourNotes("");
  };

  const handleExportPL = () => {
    const csvContent = `data:text/csv;charset=utf-8,` + 
      `ORCHARD BLOCK PROFITABILITY REPORT: ${block.fieldBlock}\n` +
      `Fruit Type,${fruitType}\n` +
      `Variety,${variety}\n` +
      `Block Area,${blockAreaHa} Ha\n` +
      `Tree Population,${treeCount}\n\n` +
      `FINANCIAL SUMMARY\n` +
      `Total Realized Sales,${currencySymbol}${totalRealizedSales}\n` +
      `Total Production Costs,${currencySymbol}${totalProductionCost}\n` +
      `Net Operating Profit,${currencySymbol}${netOperatingProfit}\n` +
      `Operating Margin,${operatingMarginPct}%\n` +
      `Profit Per Hectare,${currencySymbol}${profitPerHectare.toFixed(2)}\n` +
      `Profit Per Tree,${currencySymbol}${profitPerTree.toFixed(2)}\n\n` +
      `COST BREAKDOWN\n` +
      `Field Activities Cost,${currencySymbol}${activitiesCost}\n` +
      `Direct Materials & Expenses,${currencySymbol}${directExpensesCost}\n` +
      `HR Labour Allocation,${currencySymbol}${totalLabourCost}\n`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Orchard_Profitability_${block.fieldBlock.replace(/\s+/g, "_")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Orchard Block Profitability CSV Exported!", "success");
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-[1200] flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full overflow-hidden max-h-[92vh] flex flex-col my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-900 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <TrendingUp className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400 font-mono">
                  Financial Performance & Audit
                </span>
                <span className="px-2 py-0.2 bg-emerald-950 text-emerald-300 rounded text-[9px] font-bold border border-emerald-800/60">
                  {fruitType} • {block.fieldBlock}
                </span>
              </div>
              <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-2">
                <span>Orchard Block Profitability Analysis</span>
              </h2>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportPL}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export P&L</span>
            </button>

            <button 
              type="button" 
              onClick={onClose} 
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center text-sm font-bold transition-colors cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 gap-2 shrink-0">
          {[
            { id: "summary", label: "Executive P&L Summary", icon: PieChart },
            { id: "sales", label: `Sales Realized (${blockInvoices.length + blockCashSales.length})`, icon: DollarSign },
            { id: "expenses", label: `Field Expenses (${blockActivities.length + blockExpenses.length})`, icon: Receipt },
            { id: "labour", label: `HR Labour Allocation (${labourLogs.length})`, icon: Users },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 py-3 px-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
                  isActive 
                    ? "border-emerald-500 text-emerald-700 font-extrabold" 
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 text-xs space-y-6">
          
          {/* TAB 1: EXECUTIVE SUMMARY */}
          {activeTab === "summary" && (
            <div className="space-y-6">
              
              {/* Primary KPI Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                
                {/* Total Sales */}
                <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-1">
                  <span className="text-[10px] font-black uppercase text-emerald-800 tracking-wider block">
                    Realized Sales Revenue
                  </span>
                  <div className="text-2xl font-black font-mono text-emerald-950">
                    {currencySymbol}{totalRealizedSales.toLocaleString()}
                  </div>
                  <span className="text-[9.5px] text-emerald-700 block font-medium">
                    {revenueRealizationPct}% of annual projection ({currencySymbol}{projectedAnnualRevenue.toLocaleString()})
                  </span>
                </div>

                {/* Total Production Cost */}
                <div className="p-4 bg-rose-50/70 border border-rose-200 rounded-xl space-y-1">
                  <span className="text-[10px] font-black uppercase text-rose-800 tracking-wider block">
                    Total Operating Costs
                  </span>
                  <div className="text-2xl font-black font-mono text-rose-950">
                    {currencySymbol}{totalProductionCost.toLocaleString()}
                  </div>
                  <span className="text-[9.5px] text-rose-700 block font-medium">
                    Inputs + Activities + HR Labour
                  </span>
                </div>

                {/* Net Operating Profit */}
                <div className={`p-4 rounded-xl space-y-1 border ${
                  netOperatingProfit >= 0 
                    ? "bg-indigo-50/70 border-indigo-200 text-indigo-950" 
                    : "bg-amber-50/70 border-amber-200 text-amber-950"
                }`}>
                  <span className="text-[10px] font-black uppercase tracking-wider block opacity-70">
                    Net Block Margin
                  </span>
                  <div className="text-2xl font-black font-mono">
                    {netOperatingProfit >= 0 ? "+" : ""}{currencySymbol}{netOperatingProfit.toLocaleString()}
                  </div>
                  <span className="text-[9.5px] font-bold block">
                    {operatingMarginPct}% Margin • {roiPct}% ROI
                  </span>
                </div>

                {/* Profit Per Hectare */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                  <span className="text-[10px] font-black uppercase text-slate-500 tracking-wider block">
                    Yield Profitability
                  </span>
                  <div className="text-2xl font-black font-mono text-slate-900">
                    {currencySymbol}{Math.round(profitPerHectare).toLocaleString()} / Ha
                  </div>
                  <span className="text-[9.5px] text-slate-500 block font-mono">
                    {currencySymbol}{profitPerTree.toFixed(2)} / tree ({treeCount} trees)
                  </span>
                </div>

              </div>

              {/* Cost Structure Breakdown */}
              <div className="p-5 bg-white border border-slate-200 rounded-xl space-y-4 shadow-xs">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center justify-between">
                  <span>Cost Allocation & Resource Absorption</span>
                  <span className="text-[10px] font-mono text-slate-400 font-bold">Total: {currencySymbol}{totalProductionCost.toLocaleString()}</span>
                </h4>

                {/* Progress bar stack */}
                <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden flex">
                  {totalProductionCost > 0 ? (
                    <>
                      <div 
                        style={{ width: `${(activitiesCost / totalProductionCost) * 100}%` }} 
                        className="bg-sky-500" 
                        title={`Field Activities: ${currencySymbol}${activitiesCost}`} 
                      />
                      <div 
                        style={{ width: `${(directExpensesCost / totalProductionCost) * 100}%` }} 
                        className="bg-amber-500" 
                        title={`Direct Inputs & Supplies: ${currencySymbol}${directExpensesCost}`} 
                      />
                      <div 
                        style={{ width: `${(totalLabourCost / totalProductionCost) * 100}%` }} 
                        className="bg-purple-500" 
                        title={`HR Labour: ${currencySymbol}${totalLabourCost}`} 
                      />
                    </>
                  ) : (
                    <div className="w-full bg-slate-200" />
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-sky-50/60 border border-sky-100 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-sky-500" />
                      <span className="font-bold text-slate-700">Field Activities</span>
                    </div>
                    <span className="font-mono font-black text-sky-950">{currencySymbol}{activitiesCost.toLocaleString()}</span>
                  </div>

                  <div className="p-3 bg-amber-50/60 border border-amber-100 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                      <span className="font-bold text-slate-700">Direct Materials</span>
                    </div>
                    <span className="font-mono font-black text-amber-950">{currencySymbol}{directExpensesCost.toLocaleString()}</span>
                  </div>

                  <div className="p-3 bg-purple-50/60 border border-purple-100 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-purple-500" />
                      <span className="font-bold text-slate-700">HR Labour Allocated</span>
                    </div>
                    <span className="font-mono font-black text-purple-950">{currencySymbol}{totalLabourCost.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Block Details & Target Comparison */}
              <div className="p-5 bg-slate-50 border border-slate-200 rounded-xl grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h5 className="text-[10px] font-black uppercase tracking-wider text-slate-400">Orchard Profile</h5>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between border-b border-slate-200/60 pb-1">
                      <span className="text-slate-500">Fruit Cultivar:</span>
                      <span className="font-bold text-slate-800">{fruitType} ({variety})</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-200/60 pb-1">
                      <span className="text-slate-500">Active Trees:</span>
                      <span className="font-mono font-bold text-slate-800">{treeCount} trees</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-200/60 pb-1">
                      <span className="text-slate-500">Surface Area:</span>
                      <span className="font-mono font-bold text-slate-800">{blockAreaHa} Hectares</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Water & Irrigation:</span>
                      <span className="font-bold text-slate-800">{orchard?.waterSource || "Borehole"} ({orchard?.irrigationType || "Drip"})</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h5 className="text-[10px] font-black uppercase tracking-wider text-slate-400">Projection Variance</h5>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between border-b border-slate-200/60 pb-1">
                      <span className="text-slate-500">Projected Peak Revenue:</span>
                      <span className="font-mono font-black text-emerald-600">{currencySymbol}{projectedAnnualRevenue.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-200/60 pb-1">
                      <span className="text-slate-500">Realized Revenue To Date:</span>
                      <span className="font-mono font-black text-slate-900">{currencySymbol}{totalRealizedSales.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-200/60 pb-1">
                      <span className="text-slate-500">Variance (Gap to Target):</span>
                      <span className={`font-mono font-black ${totalRealizedSales >= projectedAnnualRevenue ? "text-emerald-600" : "text-amber-600"}`}>
                        {currencySymbol}{(totalRealizedSales - projectedAnnualRevenue).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Estimated Tree Lifespan:</span>
                      <span className="font-bold text-slate-800">{orchard?.treeLifespanYears || 20} Years</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: SALES REALIZED */}
          {activeTab === "sales" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-600">
                  Direct Invoices and Cash Sales credited to {block.fieldBlock}
                </span>
                {onRecordSaleClick && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onRecordSaleClick(block);
                    }}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 stroke-[3]" />
                    <span>Record Direct Sale</span>
                  </button>
                )}
              </div>

              {blockInvoices.length === 0 && blockCashSales.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200">
                  <DollarSign className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <h4 className="text-xs font-bold text-slate-700">No Sales Recorded For This Block Yet</h4>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Raise an invoice or record a cash sale selecting this Orchard Block to track harvest revenue realization.
                  </p>
                </div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-50 text-[10px] text-slate-500 uppercase font-black tracking-wider border-b border-slate-200">
                      <tr>
                        <th className="p-3">Reference / ID</th>
                        <th className="p-3">Customer / Buyer</th>
                        <th className="p-3">Date</th>
                        <th className="p-3">Channel</th>
                        <th className="p-3 text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {blockInvoices.map((inv) => (
                        <tr key={inv.id} className="hover:bg-slate-50/60">
                          <td className="p-3 font-mono font-bold text-indigo-600">{inv.invoiceNumber}</td>
                          <td className="p-3 font-semibold text-slate-900">{inv.customerName}</td>
                          <td className="p-3 font-mono text-slate-500">{inv.date}</td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 rounded text-[9px] font-bold uppercase">
                              Invoice ({inv.status})
                            </span>
                          </td>
                          <td className="p-3 text-right font-mono font-black text-emerald-600">
                            {currencySymbol}{(inv.total || inv.paidAmount || 0).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                      {blockCashSales.map((cs) => (
                        <tr key={cs.id} className="hover:bg-slate-50/60">
                          <td className="p-3 font-mono font-bold text-emerald-600">{cs.receiptNumber || cs.id.slice(0, 8)}</td>
                          <td className="p-3 font-semibold text-slate-900">{cs.customer || "Cash Buyer"}</td>
                          <td className="p-3 font-mono text-slate-500">{cs.date}</td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded text-[9px] font-bold uppercase">
                              Direct POS Sale
                            </span>
                          </td>
                          <td className="p-3 text-right font-mono font-black text-emerald-600">
                            {currencySymbol}{(cs.amount || 0).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

            </div>
          )}

          {/* TAB 3: FIELD EXPENSES */}
          {activeTab === "expenses" && (
            <div className="space-y-4">
              <span className="text-xs font-bold text-slate-600 block">
                Field Operations, Chemical Sprays, Fertilizers & Seedlings for {block.fieldBlock}
              </span>

              {blockActivities.length === 0 && blockExpenses.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200">
                  <Receipt className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <h4 className="text-xs font-bold text-slate-700">No Field Expenses Logged</h4>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Log orchard activities (spraying, pruning, fertilizing) or record direct inputs in the Expenses module.
                  </p>
                </div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-50 text-[10px] text-slate-500 uppercase font-black tracking-wider border-b border-slate-200">
                      <tr>
                        <th className="p-3">Date</th>
                        <th className="p-3">Activity / Material</th>
                        <th className="p-3">Category</th>
                        <th className="p-3">Operator / Supplier</th>
                        <th className="p-3 text-right">Cost</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {blockActivities.map((act) => (
                        <tr key={act.id} className="hover:bg-slate-50/60">
                          <td className="p-3 font-mono text-slate-500">{act.createdAt?.split("T")[0] || "-"}</td>
                          <td className="p-3 font-semibold text-slate-900 capitalize">
                            {act.activityType} ({act.product || "Field Maintenance"})
                          </td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded text-[9px] font-bold uppercase">
                              Field Activity
                            </span>
                          </td>
                          <td className="p-3 text-slate-600">{act.operator || "Farm Crew"}</td>
                          <td className="p-3 text-right font-mono font-black text-rose-600">
                            {currencySymbol}{(act.cost || 0).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                      {blockExpenses.map((exp: any) => (
                        <tr key={exp.id} className="hover:bg-slate-50/60">
                          <td className="p-3 font-mono text-slate-500">{exp.date || "-"}</td>
                          <td className="p-3 font-semibold text-slate-900">{exp.description || exp.category || "Field Input"}</td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded text-[9px] font-bold uppercase">
                              {exp.category || "Input Expense"}
                            </span>
                          </td>
                          <td className="p-3 text-slate-600">{exp.supplierName || exp.vendor || "-"}</td>
                          <td className="p-3 text-right font-mono font-black text-rose-600">
                            {currencySymbol}{(exp.total || exp.amount || 0).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

            </div>
          )}

          {/* TAB 4: HR LABOUR ALLOCATION */}
          {activeTab === "labour" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-600">
                  Direct Labour Logged from the HR Module (Pruning, Grafting, Trellising, Harvesting)
                </span>
                <button
                  type="button"
                  onClick={() => setShowAddLabourForm(!showAddLabourForm)}
                  className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 stroke-[3]" />
                  <span>Log HR Labour</span>
                </button>
              </div>

              {/* Add Labour Inline Form */}
              {showAddLabourForm && (
                <form onSubmit={handleSaveLabour} className="p-4 bg-purple-50/70 border border-purple-200 rounded-xl space-y-3 animate-in fade-in duration-150">
                  <h4 className="text-[11px] font-black uppercase tracking-wider text-purple-950 flex items-center gap-1.5">
                    <Briefcase className="w-4 h-4 text-purple-700" />
                    <span>Allocate Staff Labour To {block.fieldBlock}</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <label className="text-[9.5px] font-black uppercase text-purple-900 block mb-1">
                        Select Employee (HR) *
                      </label>
                      <select
                        value={selectedEmployeeId}
                        onChange={e => handleEmployeeSelect(e.target.value)}
                        required
                        className="w-full bg-white border border-purple-200 rounded-xl p-2 font-bold text-xs outline-none"
                      >
                        <option value="">-- Choose Employee --</option>
                        {employees.map(emp => (
                          <option key={emp.id} value={emp.id}>
                            {emp.name} ({emp.role || "Staff"})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-[9.5px] font-black uppercase text-purple-900 block mb-1">
                        Task / Activity Type *
                      </label>
                      <select
                        value={labourActivityType}
                        onChange={e => setLabourActivityType(e.target.value as any)}
                        className="w-full bg-white border border-purple-200 rounded-xl p-2 font-bold text-xs outline-none"
                      >
                        <option value="Pruning">Pruning & Canopy Management</option>
                        <option value="Trellising">Trellis Building & Vine Tying</option>
                        <option value="Grafting">Grafting & Budwood Care</option>
                        <option value="Spraying">Pest & Fungicide Spraying</option>
                        <option value="Weeding">Under-Tree Weeding / Mulching</option>
                        <option value="Harvesting">Fruit Picking & Grading</option>
                        <option value="Irrigation">Irrigation Line Flushing</option>
                        <option value="General">General Block Labour</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[9.5px] font-black uppercase text-purple-900 block mb-1">
                        Date Worked *
                      </label>
                      <input
                        type="date"
                        value={labourDate}
                        onChange={e => setLabourDate(e.target.value)}
                        required
                        className="w-full bg-white border border-purple-200 rounded-xl p-2 font-mono text-xs outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[9.5px] font-black uppercase text-purple-900 block mb-1">
                          Hours
                        </label>
                        <input
                          type="number"
                          step="0.5"
                          min="0.5"
                          value={hoursWorked}
                          onChange={e => setHoursWorked(Number(e.target.value))}
                          required
                          className="w-full bg-white border border-purple-200 rounded-xl p-2 font-mono font-bold text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[9.5px] font-black uppercase text-purple-900 block mb-1">
                          Rate ({currencySymbol}/h)
                        </label>
                        <input
                          type="number"
                          value={hourlyRate}
                          onChange={e => setHourlyRate(Number(e.target.value))}
                          required
                          className="w-full bg-white border border-purple-200 rounded-xl p-2 font-mono font-bold text-xs"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2 items-center pt-2">
                    <input
                      type="text"
                      placeholder="Optional notes (e.g. Cleared 400 dragon fruit trellis posts)"
                      value={labourNotes}
                      onChange={e => setLabourNotes(e.target.value)}
                      className="flex-1 bg-white border border-purple-200 rounded-xl p-2 text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => setShowAddLabourForm(false)}
                      className="px-3 py-2 bg-white border border-purple-200 rounded-xl text-purple-900 font-bold text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-black text-xs uppercase"
                    >
                      Save Labour ({currencySymbol}{hoursWorked * hourlyRate})
                    </button>
                  </div>
                </form>
              )}

              {/* Labour Logs Table */}
              {labourLogs.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200">
                  <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <h4 className="text-xs font-bold text-slate-700">No Labour Tasks Allocated Yet</h4>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Click "+ Log HR Labour" above to attach worker hours and hourly wages to this Orchard Block.
                  </p>
                </div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-50 text-[10px] text-slate-500 uppercase font-black tracking-wider border-b border-slate-200">
                      <tr>
                        <th className="p-3">Date</th>
                        <th className="p-3">Staff Name</th>
                        <th className="p-3">Task Category</th>
                        <th className="p-3 text-center">Hours</th>
                        <th className="p-3 text-center">Hourly Rate</th>
                        <th className="p-3 text-right">Total Labour Cost</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {labourLogs.map((log) => (
                        <tr key={log.id} className="hover:bg-slate-50/60">
                          <td className="p-3 font-mono text-slate-500">{log.date}</td>
                          <td className="p-3 font-semibold text-slate-900">{log.employeeName}</td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 bg-purple-50 text-purple-700 border border-purple-200 rounded text-[9px] font-bold uppercase">
                              {log.activityType}
                            </span>
                            {log.notes && <span className="text-[9.5px] text-slate-400 block mt-0.5">{log.notes}</span>}
                          </td>
                          <td className="p-3 text-center font-mono font-bold">{log.hoursWorked}h</td>
                          <td className="p-3 text-center font-mono text-slate-500">{currencySymbol}{log.hourlyRate}/h</td>
                          <td className="p-3 text-right font-mono font-black text-purple-900">
                            {currencySymbol}{(log.totalLaborCost || 0).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Net Profit Margin:</span>
            <span className={`font-mono font-black ${netOperatingProfit >= 0 ? "text-emerald-600" : "text-rose-600"}`}>
              {netOperatingProfit >= 0 ? "+" : ""}{currencySymbol}{netOperatingProfit.toLocaleString()} ({operatingMarginPct}%)
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs uppercase rounded-xl transition-all cursor-pointer"
          >
            Close Audit View
          </button>
        </div>

      </div>
    </div>
  );
}

import { PricingTierConfig, OrchardYearHarvestSchedule } from "../../types";

export interface FruitTreePreset {
  id: string;
  name: string;
  scientificName: string;
  category: string;
  varieties: string[];
  rootstocks: string[];
  recommendedSpacingWithinRowM: number;
  recommendedRowSpacingM: number;
  trellisType?: string;
  lifespanYears: number;
  firstBearingYears: number;
  harvestsPerYear: number;
  harvestMonth: string;
  measuredIn: "Units" | "Kg";
  unitName: string; // e.g. "Fruit", "Cob", "Head", "Kg", "Bunch", "Box"
  estimatedFruitsPerTreePerHarvest: number;
  averageFruitWeightKg: number;
  defaultLossesPct: number;
  defaultPricePerUnit: number;
  defaultPricePerKg: number;
  defaultWaterSource: string;
  defaultIrrigationType: string;
  defaultSoilType: string;
  description: string;
  bearingCurve: {
    year1: number; // e.g. 0%
    year2: number; // e.g. 40%
    year3: number; // e.g. 75%
    year4ToPeak: number; // 100%
    decliningYearStart: number; // e.g. Year 18
    decliningMultiplier: number; // e.g. 75%
  };
  defaultTiers?: PricingTierConfig;
}

export const FRUIT_PRESETS: Record<string, FruitTreePreset> = {
  "Dragon Fruit": {
    id: "dragon_fruit",
    name: "Dragon Fruit",
    scientificName: "Hylocereus polyrhizus / H. undatus",
    category: "Cactaceae Perennial Climber",
    varieties: [
      "Red Flesh (Hylocereus polyrhizus)",
      "White Flesh (Hylocereus undatus)",
      "Yellow Dragon (Selenicereus megalanthus)",
      "Purple Haze",
      "Royal Red",
      "Vietnamese White"
    ],
    rootstocks: [
      "Hardy Cuttings (Self-Rooted)",
      "Hardy Undatus Rootstock",
      "Wild Hylocereus Rootstock"
    ],
    recommendedSpacingWithinRowM: 3.0,
    recommendedRowSpacingM: 3.0,
    trellisType: "Concrete / Treated Timber Post with Tyre/Cross-arm Crown (4 Vines/Post)",
    lifespanYears: 20,
    firstBearingYears: 1.5,
    harvestsPerYear: 3,
    harvestMonth: "November - April (3-4 Flushes)",
    measuredIn: "Units",
    unitName: "Fruit",
    estimatedFruitsPerTreePerHarvest: 35, // ~35 fruits per trellis post per flush
    averageFruitWeightKg: 0.42, // 420g per fruit
    defaultLossesPct: 8, // 8% post-harvest buffer
    defaultPricePerUnit: 25, // 25 ZMW per premium fruit
    defaultPricePerKg: 55, // 55 ZMW per Kg
    defaultWaterSource: "Borehole (Drip / Micro-Sprinkler)",
    defaultIrrigationType: "Drip Irrigation with Fertigation",
    defaultSoilType: "Well-Drained Sandy Loam with High Organic Compost (pH 6.0 - 7.0)",
    description: "High-value perennial exotic fruit yielding multiple flushes per season on concrete/wood posts. High market demand and drought tolerance.",
    bearingCurve: {
      year1: 0,
      year2: 0.40,
      year3: 0.75,
      year4ToPeak: 1.0,
      decliningYearStart: 16,
      decliningMultiplier: 0.80
    },
    defaultTiers: {
      splitType: "Grade",
      tiers: [
        { id: "t1", label: "Grade A (Export / Supermarket >450g)", percentage: 50, pricePerUnit: 30 },
        { id: "t2", label: "Grade B (Domestic Wholesale 300-450g)", percentage: 35, pricePerUnit: 20 },
        { id: "t3", label: "Grade C (Processing / Pulp / Juice)", percentage: 15, pricePerUnit: 12 }
      ]
    }
  },

  "Avocado": {
    id: "avocado",
    name: "Avocado",
    scientificName: "Persea americana",
    category: "Subtropical Evergreen Tree",
    varieties: [
      "Hass (Export Standard)",
      "Fuerte (Green Skin)",
      "Pinkerton",
      "Zutano (Pollinizer)",
      "Bacon",
      "Reed"
    ],
    rootstocks: [
      "Duke 7 (Phytophthora Tolerant)",
      "Dusa (Clonal High-Yield)",
      "Bounty 71",
      "Local Wild Seedling"
    ],
    recommendedSpacingWithinRowM: 5.0,
    recommendedRowSpacingM: 5.0,
    lifespanYears: 30,
    firstBearingYears: 3,
    harvestsPerYear: 1,
    harvestMonth: "April - July",
    measuredIn: "Units",
    unitName: "Fruit",
    estimatedFruitsPerTreePerHarvest: 180,
    averageFruitWeightKg: 0.25,
    defaultLossesPct: 10,
    defaultPricePerUnit: 8,
    defaultPricePerKg: 30,
    defaultWaterSource: "Borehole",
    defaultIrrigationType: "Under-tree Micro-Sprinkler",
    defaultSoilType: "Deep Well-Drained Volcanic / Sandy Clay Loam (pH 5.5 - 6.5)",
    description: "Premium global export crop. Requires good drainage to avoid root rot. High long-term compound returns.",
    bearingCurve: {
      year1: 0,
      year2: 0.15,
      year3: 0.45,
      year4ToPeak: 1.0,
      decliningYearStart: 24,
      decliningMultiplier: 0.85
    }
  },

  "Mango": {
    id: "mango",
    name: "Mango",
    scientificName: "Mangifera indica",
    category: "Tropical Evergreen Tree",
    varieties: [
      "Tommy Atkins (Early Red)",
      "Kent (Late Green/Yellow)",
      "Keitt (Large Export)",
      "Haden",
      "Ngowe (Local Selected)",
      "Apple Mango"
    ],
    rootstocks: [
      "Sabre Rootstock",
      "Local Wild Peach Mango Rootstock",
      "13-1 Clonal"
    ],
    recommendedSpacingWithinRowM: 7.0,
    recommendedRowSpacingM: 7.0,
    lifespanYears: 35,
    firstBearingYears: 3,
    harvestsPerYear: 1,
    harvestMonth: "November - February",
    measuredIn: "Units",
    unitName: "Fruit",
    estimatedFruitsPerTreePerHarvest: 220,
    averageFruitWeightKg: 0.38,
    defaultLossesPct: 12,
    defaultPricePerUnit: 5,
    defaultPricePerKg: 15,
    defaultWaterSource: "River / Borehole",
    defaultIrrigationType: "Drip / Basin",
    defaultSoilType: "Sandy Loam to Clay Loam (pH 5.5 - 7.5)",
    description: "Drought-hardy fruit with heavy seasonal yields and strong domestic & regional export demand.",
    bearingCurve: {
      year1: 0,
      year2: 0.10,
      year3: 0.40,
      year4ToPeak: 1.0,
      decliningYearStart: 28,
      decliningMultiplier: 0.85
    }
  },

  "Citrus": {
    id: "citrus",
    name: "Citrus (Oranges/Lemons/Limes)",
    scientificName: "Citrus sinensis / C. limon",
    category: "Subtropical Citrus Tree",
    varieties: [
      "Valencia Orange (Juice & Fresh)",
      "Washington Navel (Sweet Table)",
      "Eureka Lemon",
      "Tahiti / Persian Lime",
      "Clementine Mandarin",
      "Star Ruby Grapefruit"
    ],
    rootstocks: [
      "Rough Lemon (C. jambhiri)",
      "Carrizo Citrange",
      "Volkameriana",
      "Swingle Citrumelo"
    ],
    recommendedSpacingWithinRowM: 4.0,
    recommendedRowSpacingM: 5.0,
    lifespanYears: 25,
    firstBearingYears: 3,
    harvestsPerYear: 1,
    harvestMonth: "May - August",
    measuredIn: "Units",
    unitName: "Fruit",
    estimatedFruitsPerTreePerHarvest: 280,
    averageFruitWeightKg: 0.20,
    defaultLossesPct: 10,
    defaultPricePerUnit: 3,
    defaultPricePerKg: 14,
    defaultWaterSource: "Borehole",
    defaultIrrigationType: "Drip / Micro-Jet",
    defaultSoilType: "Light Sandy Loam to Loamy Sand (pH 6.0 - 7.0)",
    description: "High market velocity crop with dual table and juice processing demand. Regular year-on-year bearing.",
    bearingCurve: {
      year1: 0,
      year2: 0.20,
      year3: 0.50,
      year4ToPeak: 1.0,
      decliningYearStart: 20,
      decliningMultiplier: 0.80
    }
  },

  "Macadamia": {
    id: "macadamia",
    name: "Macadamia Nut",
    scientificName: "Macadamia integrifolia",
    category: "Perennial Nut Tree",
    varieties: [
      "Beaumont (695)",
      "Nelmak 2",
      "A4 Clonal",
      "A16 Clonal",
      "816 High Kernel",
      "788"
    ],
    rootstocks: [
      "Beaumont Seedling",
      "Clonal H2 Rootstock",
      "Wild Integrifolia"
    ],
    recommendedSpacingWithinRowM: 4.0,
    recommendedRowSpacingM: 8.0,
    lifespanYears: 40,
    firstBearingYears: 4,
    harvestsPerYear: 1,
    harvestMonth: "March - July",
    measuredIn: "Kg",
    unitName: "Kg (Nut-in-Shell)",
    estimatedFruitsPerTreePerHarvest: 25, // 25kg NIS per tree
    averageFruitWeightKg: 0.03,
    defaultLossesPct: 8,
    defaultPricePerUnit: 65, // 65 ZMW per kg
    defaultPricePerKg: 65,
    defaultWaterSource: "Borehole / Dam",
    defaultIrrigationType: "Drip Irrigation",
    defaultSoilType: "Deep Well-Drained Friable Loam (pH 5.0 - 6.0)",
    description: "High-value commercial nut investment with 40+ year productive lifespan and strong international dollar contracts.",
    bearingCurve: {
      year1: 0,
      year2: 0,
      year3: 0.20,
      year4ToPeak: 1.0,
      decliningYearStart: 32,
      decliningMultiplier: 0.90
    }
  },

  "Guava": {
    id: "guava",
    name: "Guava",
    scientificName: "Psidium guajava",
    category: "Tropical Small Tree / Bush",
    varieties: [
      "Fan Retief (Pink Flesh)",
      "White Sweet Sugar",
      "Allahabad Safeda",
      "Lucknow 49"
    ],
    rootstocks: [
      "Local Seedling",
      "Wilt-Resistant Guava Rootstock"
    ],
    recommendedSpacingWithinRowM: 4.0,
    recommendedRowSpacingM: 4.0,
    lifespanYears: 20,
    firstBearingYears: 2,
    harvestsPerYear: 2,
    harvestMonth: "February - May & Sept - Nov",
    measuredIn: "Units",
    unitName: "Fruit",
    estimatedFruitsPerTreePerHarvest: 200,
    averageFruitWeightKg: 0.16,
    defaultLossesPct: 12,
    defaultPricePerUnit: 2.5,
    defaultPricePerKg: 15,
    defaultWaterSource: "Borehole / Stream",
    defaultIrrigationType: "Drip / Furrow",
    defaultSoilType: "Adaptable to most soils (pH 5.0 - 7.5)",
    description: "Fast-bearing, high-vitamin fruit for fresh local markets and pulp / beverage processors.",
    bearingCurve: {
      year1: 0,
      year2: 0.35,
      year3: 0.70,
      year4ToPeak: 1.0,
      decliningYearStart: 15,
      decliningMultiplier: 0.80
    }
  },

  "Papaya": {
    id: "papaya",
    name: "Papaya / Pawpaw",
    scientificName: "Carica papaya",
    category: "Herbaceous Fast Perennial",
    varieties: [
      "Red Lady F1 (Hermaphrodite Heavy Yielder)",
      "Solo Sunrise (Hawaiian Sweet)",
      "Maradol",
      "Calina IPB9"
    ],
    rootstocks: [
      "Direct Seed / Hybrid Seedlings"
    ],
    recommendedSpacingWithinRowM: 2.5,
    recommendedRowSpacingM: 2.5,
    lifespanYears: 4,
    firstBearingYears: 0.8, // 9-10 months
    harvestsPerYear: 4, // Continuous monthly harvests
    harvestMonth: "Year-Round Continuous",
    measuredIn: "Units",
    unitName: "Fruit",
    estimatedFruitsPerTreePerHarvest: 45,
    averageFruitWeightKg: 1.25,
    defaultLossesPct: 10,
    defaultPricePerUnit: 18,
    defaultPricePerKg: 15,
    defaultWaterSource: "Borehole",
    defaultIrrigationType: "Drip Irrigation",
    defaultSoilType: "Rich Well-Drained Sandy Loam (Zero Waterlogging, pH 6.0 - 6.5)",
    description: "Rapid cashflow perennial bearing within 9 months. Excellent for high-density intercropping and fast returns.",
    bearingCurve: {
      year1: 0.60,
      year2: 1.0,
      year3: 0.85,
      year4ToPeak: 0.50,
      decliningYearStart: 3,
      decliningMultiplier: 0.50
    }
  },

  "Banana": {
    id: "banana",
    name: "Banana & Plantain",
    scientificName: "Musa acuminata",
    category: "Giant Perennial Herb",
    varieties: [
      "Grand Nain (Cavendish Commercial)",
      "Williams (Heavy Bunch)",
      "Giant Governor",
      "Plantain (Cooking Matooke)"
    ],
    rootstocks: [
      "Tissue Culture Plantlets",
      "Sword Suckers"
    ],
    recommendedSpacingWithinRowM: 3.0,
    recommendedRowSpacingM: 3.0,
    lifespanYears: 12,
    firstBearingYears: 1.0,
    harvestsPerYear: 1.5,
    harvestMonth: "Year-Round Rolling",
    measuredIn: "Units",
    unitName: "Bunch",
    estimatedFruitsPerTreePerHarvest: 1.5, // bunches per mat
    averageFruitWeightKg: 28.0, // 28kg bunch
    defaultLossesPct: 8,
    defaultPricePerUnit: 130, // 130 ZMW per bunch
    defaultPricePerKg: 6,
    defaultWaterSource: "Borehole / River",
    defaultIrrigationType: "Overhead / Drip Fertigation",
    defaultSoilType: "Deep Organic Rich Alluvial Loam (pH 5.5 - 7.0)",
    description: "High volume staple crop generating consistent weekly/monthly bunch revenue for local grocery markets.",
    bearingCurve: {
      year1: 0.50,
      year2: 1.0,
      year3: 1.0,
      year4ToPeak: 1.0,
      decliningYearStart: 9,
      decliningMultiplier: 0.85
    }
  },

  "Passion Fruit": {
    id: "passion_fruit",
    name: "Passion Fruit",
    scientificName: "Passiflora edulis",
    category: "Perennial Vine Climber",
    varieties: [
      "Purple Passion (Granadilla Export)",
      "Yellow Passion (Flavicarpa Juice)",
      "Sweet Granadilla (Ligularis)",
      "KPF4 Hybrid"
    ],
    rootstocks: [
      "Yellow Passion Rootstock (Fusarium Resistant)",
      "Direct Seedlings"
    ],
    recommendedSpacingWithinRowM: 2.0,
    recommendedRowSpacingM: 3.0,
    trellisType: "High Wire T-Trellis (2m height)",
    lifespanYears: 6,
    firstBearingYears: 0.9,
    harvestsPerYear: 2,
    harvestMonth: "Nov - Feb & June - Aug",
    measuredIn: "Units",
    unitName: "Fruit",
    estimatedFruitsPerTreePerHarvest: 180,
    averageFruitWeightKg: 0.055,
    defaultLossesPct: 10,
    defaultPricePerUnit: 1.8,
    defaultPricePerKg: 32,
    defaultWaterSource: "Borehole",
    defaultIrrigationType: "Drip Irrigation",
    defaultSoilType: "Well-Drained Loam with Trellised Canopy (pH 6.0 - 7.5)",
    description: "Intensive high-margin vine crop with high juice and fresh fruit demand. Fast payback on trellis capital.",
    bearingCurve: {
      year1: 0.50,
      year2: 1.0,
      year3: 0.90,
      year4ToPeak: 0.75,
      decliningYearStart: 4,
      decliningMultiplier: 0.60
    }
  },

  "Apple": {
    id: "apple",
    name: "Apple (Low Chill / Tropical)",
    scientificName: "Malus domestica",
    category: "Deciduous Pome Fruit",
    varieties: [
      "Anna (Low Chill 200hrs)",
      "Dorsett Golden (Sweet Yellow)",
      "Ein Shemer",
      "Tropical Beauty"
    ],
    rootstocks: [
      "M9 Dwarf (High Density)",
      "MM106 Semi-Dwarf",
      "M793 Hardy"
    ],
    recommendedSpacingWithinRowM: 2.0,
    recommendedRowSpacingM: 4.0,
    lifespanYears: 22,
    firstBearingYears: 3,
    harvestsPerYear: 1,
    harvestMonth: "January - March",
    measuredIn: "Units",
    unitName: "Fruit",
    estimatedFruitsPerTreePerHarvest: 130,
    averageFruitWeightKg: 0.17,
    defaultLossesPct: 10,
    defaultPricePerUnit: 6.5,
    defaultPricePerKg: 38,
    defaultWaterSource: "Borehole",
    defaultIrrigationType: "Drip Irrigation",
    defaultSoilType: "Deep Well-Drained Fertile Sandy Loam (pH 6.0 - 6.8)",
    description: "Low-chill apple varieties adapted for Zambian and African high-plateau climates. High import substitution value.",
    bearingCurve: {
      year1: 0,
      year2: 0.15,
      year3: 0.50,
      year4ToPeak: 1.0,
      decliningYearStart: 18,
      decliningMultiplier: 0.80
    }
  }
};

/**
 * Generates the complete multi-year harvest schedule based on tree lifespan,
 * first bearing year, bearing curve, tree population, and price configurations.
 */
export function generateMultiYearHarvestSchedule(params: {
  plantingDate: string;
  lifespanYears: number;
  firstBearingYears: number;
  firstHarvestDate?: string;
  treeCount: number;
  harvestsPerYear: number;
  harvestMonthName?: string;
  fruitsPerTreePerHarvest: number;
  averageFruitWeightKg: number;
  lossesPct: number;
  pricePerUnitOrKg: number;
  measuredIn: "Units" | "Kg";
  bearingCurve?: FruitTreePreset["bearingCurve"];
  customTiers?: PricingTierConfig;
}): OrchardYearHarvestSchedule[] {
  const {
    plantingDate,
    lifespanYears,
    firstBearingYears,
    firstHarvestDate,
    treeCount,
    harvestsPerYear,
    fruitsPerTreePerHarvest,
    averageFruitWeightKg,
    lossesPct,
    pricePerUnitOrKg,
    measuredIn,
    bearingCurve
  } = params;

  const plantDateObj = new Date(plantingDate || new Date());
  const plantYear = isNaN(plantDateObj.getTime()) ? new Date().getFullYear() : plantDateObj.getFullYear();
  const schedule: OrchardYearHarvestSchedule[] = [];

  const lossMultiplier = Math.max(0, 1 - lossesPct / 100);

  // Peak potential yield at full maturity (per tree per year)
  const peakGrossFruitsPerTreeYear = fruitsPerTreePerHarvest * Math.max(1, harvestsPerYear);
  const peakNetFruitsPerTreeYear = peakGrossFruitsPerTreeYear * lossMultiplier;
  const peakNetKgPerTreeYear = peakNetFruitsPerTreeYear * averageFruitWeightKg;

  const bearingYearIdx = Math.max(1, Math.round(firstBearingYears));

  for (let yr = 1; yr <= Math.max(1, lifespanYears); yr++) {
    const calendarYear = plantYear + (yr - 1);
    
    // Determine expected harvest date for this year
    let harvestDateStr = `${calendarYear}-04-15`;
    if (yr === bearingYearIdx && firstHarvestDate) {
      harvestDateStr = firstHarvestDate;
    } else if (firstHarvestDate) {
      // Derive month-day from firstHarvestDate for consistency across years
      const fDate = new Date(firstHarvestDate);
      if (!isNaN(fDate.getTime())) {
        const mm = String(fDate.getMonth() + 1).padStart(2, "0");
        const dd = String(fDate.getDate()).padStart(2, "0");
        harvestDateStr = `${calendarYear}-${mm}-${dd}`;
      }
    }

    let multiplier = 0;
    let stage: OrchardYearHarvestSchedule["lifecycleStage"] = "Juvenile";

    if (yr < bearingYearIdx) {
      multiplier = 0;
      stage = "Juvenile";
    } else if (yr === bearingYearIdx) {
      multiplier = bearingCurve?.year2 ?? 0.40;
      stage = "First Bearing";
    } else if (yr === bearingYearIdx + 1) {
      multiplier = bearingCurve?.year3 ?? 0.75;
      stage = "Moderate Production";
    } else if (bearingCurve?.decliningYearStart && yr >= bearingCurve.decliningYearStart) {
      multiplier = bearingCurve.decliningMultiplier ?? 0.80;
      stage = "Declining";
    } else {
      multiplier = bearingCurve?.year4ToPeak ?? 1.0;
      stage = "Peak Production";
    }

    const projectedFruitsPerTree = Math.round(peakNetFruitsPerTreeYear * multiplier);
    const projectedYieldKgPerTree = peakNetKgPerTreeYear * multiplier;

    const totalBlockYieldKg = Math.round(projectedYieldKgPerTree * treeCount);
    const totalBlockFruits = Math.round(projectedFruitsPerTree * treeCount);

    let projectedYearRevenue = 0;
    if (measuredIn === "Units") {
      projectedYearRevenue = totalBlockFruits * pricePerUnitOrKg;
    } else {
      projectedYearRevenue = totalBlockYieldKg * pricePerUnitOrKg;
    }

    schedule.push({
      yearNumber: yr,
      calendarYear,
      expectedHarvestDate: harvestDateStr,
      lifecycleStage: stage,
      yieldMultiplierPct: Math.round(multiplier * 100),
      projectedFruitsPerTree,
      projectedYieldKg: totalBlockYieldKg,
      projectedRevenue: Math.round(projectedYearRevenue),
      isHarvestCompleted: false
    });
  }

  return schedule;
}

import React, { useState, useMemo } from "react";
import { 
  ResponsiveContainer, 
  ComposedChart, 
  Bar, 
  Line, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  CartesianGrid,
  ReferenceLine
} from "recharts";
import { 
  TrendingUp, 
  Trees, 
  Calendar, 
  DollarSign, 
  Layers, 
  Sparkles, 
  Scale, 
  HelpCircle, 
  ChevronRight,
  BarChart3,
  PieChart as PieChartIcon
} from "lucide-react";
import { CropCycle, OrchardYearHarvestSchedule } from "../../types";
import { FRUIT_PRESETS, generateMultiYearHarvestSchedule } from "./OrchardPresets";

interface OrchardFiveYearYieldChartProps {
  blocks: CropCycle[];
  selectedBlockId?: string;
  onSelectBlockId?: (id: string) => void;
  currencySymbol?: string;
}

export default function OrchardFiveYearYieldChart({
  blocks,
  selectedBlockId: externalSelectedBlockId,
  onSelectBlockId,
  currencySymbol = "ZK"
}: OrchardFiveYearYieldChartProps) {
  const [internalSelectedBlockId, setInternalSelectedBlockId] = useState<string>("ALL");
  const [viewMode, setViewMode] = useState<"composed" | "yield_kg" | "fruit_count" | "cumulative_revenue">("composed");

  const currentSelectedBlockId = externalSelectedBlockId !== undefined 
    ? (externalSelectedBlockId || "ALL") 
    : internalSelectedBlockId;

  const handleBlockChange = (id: string) => {
    setInternalSelectedBlockId(id);
    if (onSelectBlockId) {
      onSelectBlockId(id === "ALL" ? "" : id);
    }
  };

  // Only consider active perennial orchard blocks
  const orchardBlocks = useMemo(() => {
    return blocks.filter(b => b.orchard !== undefined || (b as any).isOrchard);
  }, [blocks]);

  // Selected single block (if not "ALL")
  const activeSingleBlock = useMemo(() => {
    if (currentSelectedBlockId === "ALL" || !currentSelectedBlockId) return null;
    return orchardBlocks.find(b => b.id === currentSelectedBlockId) || null;
  }, [orchardBlocks, currentSelectedBlockId]);

  // Compute 5-Year Projection for each block
  const block5YearSchedules = useMemo(() => {
    const map = new Map<string, OrchardYearHarvestSchedule[]>();

    orchardBlocks.forEach(b => {
      const orchard = b.orchard;
      if (!orchard) return;

      const fruitPreset = FRUIT_PRESETS[orchard.fruitType] || FRUIT_PRESETS["Dragon Fruit"];
      
      // If block already has schedule in state, use its first 5 years
      if (orchard.multiYearHarvestSchedule && orchard.multiYearHarvestSchedule.length >= 5) {
        map.set(b.id, orchard.multiYearHarvestSchedule.slice(0, 5));
        return;
      }

      // Otherwise compute dynamically from growth cycle config
      const lifespan = orchard.treeLifespanYears || fruitPreset.lifespanYears || 20;
      const firstBearing = orchard.firstBearingYears ?? fruitPreset.firstBearingYears ?? 2;
      const treeCount = orchard.treeCount || 100;
      const harvestsPerYear = orchard.harvestsPerYear || fruitPreset.harvestsPerYear || 1;
      const fruitsPerTree = orchard.estimatedFruitsPerTreePerHarvest ?? fruitPreset.estimatedFruitsPerTreePerHarvest ?? 50;
      const avgWeight = orchard.averageFruitWeightKg || fruitPreset.averageFruitWeightKg || 0.4;
      const losses = orchard.possibleLossesPct ?? fruitPreset.defaultLossesPct ?? 8;
      const price = orchard.pricePerUnitOrKg || (orchard.measuredInKgOrUnits === "Kg" ? fruitPreset.defaultPricePerKg : fruitPreset.defaultPricePerUnit) || 25;
      const measuredIn = orchard.measuredInKgOrUnits || fruitPreset.measuredIn || "Units";

      const schedule = generateMultiYearHarvestSchedule({
        plantingDate: orchard.plantingDate || b.plantingDate || new Date().toISOString().split("T")[0],
        lifespanYears: Math.max(5, lifespan),
        firstBearingYears: firstBearing,
        treeCount,
        harvestsPerYear,
        fruitsPerTreePerHarvest: fruitsPerTree,
        averageFruitWeightKg: avgWeight,
        lossesPct: losses,
        pricePerUnitOrKg: price,
        measuredIn,
        bearingCurve: fruitPreset.bearingCurve
      });

      map.set(b.id, schedule.slice(0, 5));
    });

    return map;
  }, [orchardBlocks]);

  // Aggregate or single block 5-year data points for Recharts
  const chartData = useMemo(() => {
    if (orchardBlocks.length === 0) return [];

    const startYear = new Date().getFullYear();
    const result: Array<{
      yearNumber: number;
      calendarYear: number;
      label: string;
      lifecycleStage: string;
      yieldMultiplierPct: number;
      projectedYieldKg: number;
      projectedYieldTonnes: number;
      projectedFruits: number;
      projectedRevenue: number;
      cumulativeYieldKg: number;
      cumulativeRevenue: number;
      treesRepresented: number;
    }> = [];

    let runningCumYieldKg = 0;
    let runningCumRevenue = 0;

    for (let yrIdx = 0; yrIdx < 5; yrIdx++) {
      const yearNum = yrIdx + 1;
      let totalYieldKg = 0;
      let totalFruits = 0;
      let totalRevenue = 0;
      let totalTrees = 0;
      let dominantStage = "Juvenile";
      let dominantMultiplier = 0;
      let calendarYear = startYear + yrIdx;

      if (activeSingleBlock) {
        const sched = block5YearSchedules.get(activeSingleBlock.id);
        const item = sched ? sched[yrIdx] : null;
        if (item) {
          totalYieldKg = item.projectedYieldKg;
          totalFruits = item.projectedFruitsPerTree * (activeSingleBlock.orchard?.treeCount || 1);
          totalRevenue = item.projectedRevenue;
          totalTrees = activeSingleBlock.orchard?.treeCount || 0;
          dominantStage = item.lifecycleStage;
          dominantMultiplier = item.yieldMultiplierPct;
          calendarYear = item.calendarYear;
        }
      } else {
        // Aggregate all orchard blocks
        let stageWeights: Record<string, number> = {};
        let multiplierSum = 0;
        let blockCount = 0;

        orchardBlocks.forEach(b => {
          const sched = block5YearSchedules.get(b.id);
          const item = sched ? sched[yrIdx] : null;
          if (item) {
            totalYieldKg += item.projectedYieldKg;
            const bTrees = b.orchard?.treeCount || 100;
            totalFruits += item.projectedFruitsPerTree * bTrees;
            totalRevenue += item.projectedRevenue;
            totalTrees += bTrees;
            multiplierSum += item.yieldMultiplierPct;
            blockCount++;
            stageWeights[item.lifecycleStage] = (stageWeights[item.lifecycleStage] || 0) + 1;
          }
        });

        // Determine most frequent stage among blocks
        let maxWeight = 0;
        Object.entries(stageWeights).forEach(([st, cnt]) => {
          if (cnt > maxWeight) {
            maxWeight = cnt;
            dominantStage = st;
          }
        });
        dominantMultiplier = blockCount > 0 ? Math.round(multiplierSum / blockCount) : 0;
      }

      runningCumYieldKg += totalYieldKg;
      runningCumRevenue += totalRevenue;

      result.push({
        yearNumber: yearNum,
        calendarYear,
        label: `Year ${yearNum} (${calendarYear})`,
        lifecycleStage: dominantStage,
        yieldMultiplierPct: dominantMultiplier,
        projectedYieldKg: Math.round(totalYieldKg),
        projectedYieldTonnes: Number((totalYieldKg / 1000).toFixed(2)),
        projectedFruits: Math.round(totalFruits),
        projectedRevenue: Math.round(totalRevenue),
        cumulativeYieldKg: Math.round(runningCumYieldKg),
        cumulativeRevenue: Math.round(runningCumRevenue),
        treesRepresented: totalTrees
      });
    }

    return result;
  }, [orchardBlocks, activeSingleBlock, block5YearSchedules]);

  // Overall 5-Year Totals
  const fiveYearTotals = useMemo(() => {
    const totalYieldKg = chartData.reduce((sum, d) => sum + d.projectedYieldKg, 0);
    const totalYieldTonnes = (totalYieldKg / 1000).toFixed(1);
    const totalFruits = chartData.reduce((sum, d) => sum + d.projectedFruits, 0);
    const totalRevenue = chartData.reduce((sum, d) => sum + d.projectedRevenue, 0);
    const peakAnnualYieldKg = Math.max(...chartData.map(d => d.projectedYieldKg), 0);
    const peakAnnualRevenue = Math.max(...chartData.map(d => d.projectedRevenue), 0);
    const totalTrees = activeSingleBlock 
      ? (activeSingleBlock.orchard?.treeCount || 0)
      : orchardBlocks.reduce((sum, b) => sum + (b.orchard?.treeCount || 0), 0);

    return {
      totalYieldKg,
      totalYieldTonnes,
      totalFruits,
      totalRevenue,
      peakAnnualYieldKg,
      peakAnnualRevenue,
      totalTrees
    };
  }, [chartData, activeSingleBlock, orchardBlocks]);

  if (orchardBlocks.length === 0) {
    return (
      <div className="p-8 bg-slate-50 border border-slate-200 rounded-2xl text-center">
        <Trees className="w-10 h-10 text-slate-300 mx-auto mb-2" />
        <h4 className="text-sm font-bold text-slate-700">No Orchard Blocks Configured</h4>
        <p className="text-xs text-slate-400 mt-1">
          Set up perennial blocks using the Orchard Wizard to generate 5-year fruit yield and revenue models.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200/90 rounded-2xl p-5 md:p-6 shadow-xs space-y-6">
      
      {/* Header with Title, Controls & Filter */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 border-b border-slate-100 pb-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider">
                  5-Year Fruit Yield & Revenue Projection
                </h3>
                <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-700 border border-emerald-500/20 rounded-full text-[9px] font-black uppercase tracking-wider">
                  Growth Model
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Biological bearing curve forecasting based on tree population, first-bearing timeline, and estimated harvest per tree.
              </p>
            </div>
          </div>
        </div>

        {/* Action / Selector Bar */}
        <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
          
          {/* Block Selector */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs">
            <Layers className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={currentSelectedBlockId}
              onChange={(e) => handleBlockChange(e.target.value)}
              className="bg-transparent font-bold text-slate-800 outline-none cursor-pointer text-xs"
            >
              <option value="ALL">🌐 All Orchard Blocks ({orchardBlocks.length} Consolidated)</option>
              {orchardBlocks.map(b => (
                <option key={b.id} value={b.id}>
                  🌳 {b.fieldBlock} — {b.orchard?.fruitType || b.cropType} ({b.orchard?.treeCount || 100} trees)
                </option>
              ))}
            </select>
          </div>

          {/* Metric View Mode Toggle */}
          <div className="inline-flex bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold">
            <button
              type="button"
              onClick={() => setViewMode("composed")}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                viewMode === "composed" 
                  ? "bg-white text-slate-900 shadow-xs font-black" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              Yield & Revenue
            </button>
            <button
              type="button"
              onClick={() => setViewMode("yield_kg")}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                viewMode === "yield_kg" 
                  ? "bg-white text-slate-900 shadow-xs font-black" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              Kilograms (Kg)
            </button>
            <button
              type="button"
              onClick={() => setViewMode("fruit_count")}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                viewMode === "fruit_count" 
                  ? "bg-white text-slate-900 shadow-xs font-black" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              Pieces
            </button>
            <button
              type="button"
              onClick={() => setViewMode("cumulative_revenue")}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                viewMode === "cumulative_revenue" 
                  ? "bg-white text-slate-900 shadow-xs font-black" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              5-Yr Revenue
            </button>
          </div>

        </div>
      </div>

      {/* KPI Highlight Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <div className="p-3.5 bg-emerald-50/60 border border-emerald-100 rounded-xl space-y-1">
          <span className="text-[10px] font-black uppercase text-emerald-800 tracking-wider block">
            5-Year Cumulative Yield
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-extrabold text-emerald-950 font-mono">
              {fiveYearTotals.totalYieldKg.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-emerald-700 font-mono">kg ({fiveYearTotals.totalYieldTonnes} t)</span>
          </div>
          <span className="text-[10px] text-emerald-700 block">
            {fiveYearTotals.totalFruits.toLocaleString()} marketable fruits
          </span>
        </div>

        <div className="p-3.5 bg-indigo-50/60 border border-indigo-100 rounded-xl space-y-1">
          <span className="text-[10px] font-black uppercase text-indigo-800 tracking-wider block">
            5-Year Projected Revenue
          </span>
          <div className="flex items-baseline gap-1">
            <span className="text-xs font-black text-indigo-700 font-mono">{currencySymbol}</span>
            <span className="text-xl font-extrabold text-indigo-950 font-mono">
              {fiveYearTotals.totalRevenue.toLocaleString()}
            </span>
          </div>
          <span className="text-[10px] text-indigo-700 block">
            Across {fiveYearTotals.totalTrees.toLocaleString()} managed trees
          </span>
        </div>

        <div className="p-3.5 bg-purple-50/60 border border-purple-100 rounded-xl space-y-1">
          <span className="text-[10px] font-black uppercase text-purple-800 tracking-wider block">
            Peak Annual Production
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-extrabold text-purple-950 font-mono">
              {fiveYearTotals.peakAnnualYieldKg.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-purple-700 font-mono">kg/yr</span>
          </div>
          <span className="text-[10px] text-purple-700 block">
            Peak potential at Year 4–5 maturity
          </span>
        </div>

        <div className="p-3.5 bg-amber-50/60 border border-amber-100 rounded-xl space-y-1">
          <span className="text-[10px] font-black uppercase text-amber-800 tracking-wider block">
            Peak Annual Gross Realization
          </span>
          <div className="flex items-baseline gap-1">
            <span className="text-xs font-black text-amber-700 font-mono">{currencySymbol}</span>
            <span className="text-xl font-extrabold text-amber-950 font-mono">
              {fiveYearTotals.peakAnnualRevenue.toLocaleString()}
            </span>
          </div>
          <span className="text-[10px] text-amber-700 block">
            At 100% bearing curve capacity
          </span>
        </div>
      </div>

      {/* Recharts Visualization Canvas */}
      <div className="h-72 w-full pt-2">
        <ResponsiveContainer width="100%" height="100%">
          {viewMode === "composed" ? (
            <ComposedChart data={chartData} margin={{ top: 15, right: 20, left: 10, bottom: 5 }}>
              <defs>
                <linearGradient id="emeraldBarGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                  <stop offset="100%" stopColor="#059669" stopOpacity={0.7} />
                </linearGradient>
                <linearGradient id="revenueAreaGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity={0.25} />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="label" 
                stroke="#64748b" 
                fontSize={11} 
                fontWeight={600}
                tickLine={false}
                axisLine={{ stroke: '#cbd5e1' }}
              />
              <YAxis 
                yAxisId="yieldAxis"
                orientation="left"
                stroke="#059669" 
                fontSize={10} 
                fontWeight={700}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `${v >= 1000 ? (v / 1000).toFixed(0) + 't' : v + 'kg'}`}
              />
              <YAxis 
                yAxisId="revenueAxis"
                orientation="right"
                stroke="#4f46e5" 
                fontSize={10} 
                fontWeight={700}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `${currencySymbol} ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (!active || !payload || !payload.length) return null;
                  const data = payload[0].payload;
                  return (
                    <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl border border-slate-800 text-xs space-y-1.5 min-w-[220px]">
                      <div className="flex justify-between items-center border-b border-slate-800 pb-1.5">
                        <span className="font-extrabold text-emerald-400">{label}</span>
                        <span className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded text-[9px] font-mono uppercase font-bold">
                          {data.lifecycleStage} ({data.yieldMultiplierPct}%)
                        </span>
                      </div>
                      <div className="space-y-1 pt-0.5">
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Predicted Yield:</span>
                          <span className="font-mono font-bold text-emerald-300">{data.projectedYieldKg.toLocaleString()} kg</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Marketable Count:</span>
                          <span className="font-mono font-semibold text-slate-200">{data.projectedFruits.toLocaleString()} fruits</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Annual Revenue:</span>
                          <span className="font-mono font-black text-indigo-300">{currencySymbol} {data.projectedRevenue.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center pt-1 border-t border-slate-800 text-[10px]">
                          <span className="text-slate-400">5-Yr Cumulative:</span>
                          <span className="font-mono font-bold text-amber-300">{currencySymbol} {data.cumulativeRevenue.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  );
                }}
              />
              <Legend 
                verticalAlign="top" 
                align="right"
                wrapperStyle={{ paddingBottom: '10px', fontSize: '11px', fontWeight: 600 }}
              />
              <Area
                yAxisId="revenueAxis"
                type="monotone"
                dataKey="projectedRevenue"
                name={`Projected Revenue (${currencySymbol})`}
                fill="url(#revenueAreaGradient)"
                stroke="#6366f1"
                strokeWidth={2.5}
              />
              <Bar 
                yAxisId="yieldAxis"
                dataKey="projectedYieldKg" 
                name="Fruit Yield (Kg)"
                fill="url(#emeraldBarGradient)" 
                radius={[6, 6, 0, 0]} 
                maxBarSize={48}
              />
            </ComposedChart>
          ) : viewMode === "yield_kg" ? (
            <ComposedChart data={chartData} margin={{ top: 15, right: 20, left: 10, bottom: 5 }}>
              <defs>
                <linearGradient id="emeraldBarGradient2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                  <stop offset="100%" stopColor="#059669" stopOpacity={0.7} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="label" stroke="#64748b" fontSize={11} fontWeight={600} tickLine={false} />
              <YAxis stroke="#059669" fontSize={10} fontWeight={700} tickLine={false} axisLine={false} tickFormatter={(v) => `${v.toLocaleString()} kg`} />
              <Tooltip 
                formatter={(val: any) => [`${Number(val).toLocaleString()} kg`, "Predicted Yield"]}
                contentStyle={{ backgroundColor: "#0f172a", borderRadius: "12px", border: "1px solid #334155", color: "#fff", fontSize: "11px" }}
              />
              <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: '10px', fontSize: '11px', fontWeight: 600 }} />
              <Bar dataKey="projectedYieldKg" name="Annual Harvest Yield (Kg)" fill="url(#emeraldBarGradient2)" radius={[6, 6, 0, 0]} maxBarSize={55} />
              <Line type="monotone" dataKey="projectedYieldKg" name="Yield Trend" stroke="#047857" strokeWidth={3} dot={{ r: 4, fill: "#047857" }} />
            </ComposedChart>
          ) : viewMode === "fruit_count" ? (
            <ComposedChart data={chartData} margin={{ top: 15, right: 20, left: 10, bottom: 5 }}>
              <defs>
                <linearGradient id="purpleBarGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#a855f7" stopOpacity={0.9} />
                  <stop offset="100%" stopColor="#7e22ce" stopOpacity={0.7} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="label" stroke="#64748b" fontSize={11} fontWeight={600} tickLine={false} />
              <YAxis stroke="#7e22ce" fontSize={10} fontWeight={700} tickLine={false} axisLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k units`} />
              <Tooltip 
                formatter={(val: any) => [`${Number(val).toLocaleString()} fruits`, "Harvest Pieces"]}
                contentStyle={{ backgroundColor: "#0f172a", borderRadius: "12px", border: "1px solid #334155", color: "#fff", fontSize: "11px" }}
              />
              <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: '10px', fontSize: '11px', fontWeight: 600 }} />
              <Bar dataKey="projectedFruits" name="Marketable Fruit Count (Units)" fill="url(#purpleBarGradient)" radius={[6, 6, 0, 0]} maxBarSize={55} />
            </ComposedChart>
          ) : (
            <ComposedChart data={chartData} margin={{ top: 15, right: 20, left: 10, bottom: 5 }}>
              <defs>
                <linearGradient id="cumAreaGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="label" stroke="#64748b" fontSize={11} fontWeight={600} tickLine={false} />
              <YAxis stroke="#047857" fontSize={10} fontWeight={700} tickLine={false} axisLine={false} tickFormatter={(v) => `${currencySymbol} ${(v / 1000).toFixed(0)}k`} />
              <Tooltip 
                formatter={(val: any) => [`${currencySymbol} ${Number(val).toLocaleString()}`, "Cumulative Revenue"]}
                contentStyle={{ backgroundColor: "#0f172a", borderRadius: "12px", border: "1px solid #334155", color: "#fff", fontSize: "11px" }}
              />
              <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: '10px', fontSize: '11px', fontWeight: 600 }} />
              <Area type="monotone" dataKey="cumulativeRevenue" name={`5-Year Cumulative Revenue (${currencySymbol})`} fill="url(#cumAreaGradient)" stroke="#059669" strokeWidth={3} />
              <Line type="monotone" dataKey="projectedRevenue" name={`Annual Revenue (${currencySymbol})`} stroke="#6366f1" strokeWidth={2} strokeDasharray="4 4" />
            </ComposedChart>
          )}
        </ResponsiveContainer>
      </div>

      {/* 5-Year Lifecycle Matrix Breakdown Table */}
      <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
        <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200 flex justify-between items-center">
          <span className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-emerald-600" />
            <span>5-Year Biological Bearing Schedule & Yield Milestones</span>
          </span>
          <span className="text-[10px] text-slate-400 font-mono">
            Modeled on {activeSingleBlock ? activeSingleBlock.fieldBlock : "Consolidated Farm Blocks"}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-white text-[9.5px] uppercase font-black tracking-wider text-slate-400 border-b border-slate-100">
              <tr>
                <th className="p-3">Timeline</th>
                <th className="p-3">Growth Stage</th>
                <th className="p-3 text-center">Bearing Capacity</th>
                <th className="p-3 text-right">Yield (Kg)</th>
                <th className="p-3 text-right">Fruit Count</th>
                <th className="p-3 text-right">Annual Revenue</th>
                <th className="p-3 text-right">Cumulative Revenue</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
              {chartData.map((d) => {
                const isPeak = d.lifecycleStage === "Peak Production";
                const isFirst = d.lifecycleStage === "First Bearing";
                const isJuvenile = d.lifecycleStage === "Juvenile";

                return (
                  <tr key={d.yearNumber} className="hover:bg-slate-50/70 transition-colors">
                    <td className="p-3 font-extrabold text-slate-900">
                      Year {d.yearNumber}
                      <span className="text-[10px] text-slate-400 font-normal block">{d.calendarYear}</span>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[9.5px] font-black uppercase tracking-wider inline-flex items-center gap-1 ${
                        isJuvenile ? "bg-slate-100 text-slate-600 border border-slate-200" :
                        isFirst ? "bg-amber-50 text-amber-700 border border-amber-200" :
                        isPeak ? "bg-emerald-50 text-emerald-700 border border-emerald-200" :
                        "bg-blue-50 text-blue-700 border border-blue-200"
                      }`}>
                        {isJuvenile ? "🌱 " : isFirst ? "🌸 " : isPeak ? "🌳 " : "🌿 "}
                        {d.lifecycleStage}
                      </span>
                    </td>
                    <td className="p-3 text-center font-mono font-bold text-slate-800">
                      {d.yieldMultiplierPct}%
                    </td>
                    <td className="p-3 text-right font-mono font-bold text-emerald-700">
                      {d.projectedYieldKg.toLocaleString()} kg
                    </td>
                    <td className="p-3 text-right font-mono font-semibold text-slate-600">
                      {d.projectedFruits.toLocaleString()} units
                    </td>
                    <td className="p-3 text-right font-mono font-black text-slate-900">
                      {currencySymbol} {d.projectedRevenue.toLocaleString()}
                    </td>
                    <td className="p-3 text-right font-mono font-black text-indigo-700">
                      {currencySymbol} {d.cumulativeRevenue.toLocaleString()}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}

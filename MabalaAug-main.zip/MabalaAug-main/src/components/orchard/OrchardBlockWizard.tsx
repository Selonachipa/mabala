import React, { useState, useMemo, useEffect } from "react";
import { 
  Trees, 
  Sprout, 
  DollarSign, 
  Calendar, 
  Sliders, 
  Percent, 
  ArrowRight, 
  Check, 
  AlertCircle, 
  Droplet, 
  MapPin, 
  Sparkles,
  Info,
  TrendingUp,
  LineChart,
  ShieldAlert,
  Layers,
  HelpCircle,
  Plus,
  Minus,
  RotateCcw,
  Ruler,
  Timer,
  Clock
} from "lucide-react";
import { CropCycle, OrchardConfig, PricingTierConfig, YieldPricingTier, OrchardYearHarvestSchedule } from "../../types";
import { FRUIT_PRESETS, FruitTreePreset, generateMultiYearHarvestSchedule } from "./OrchardPresets";

interface OrchardBlockWizardProps {
  key?: any;
  isOpen: boolean;
  onClose: () => void;
  onSaveBlock: (block: CropCycle) => void;
  currencySymbol: string;
  generateULID?: () => string;
  showToast?: (msg: string, type: "success" | "error" | "info") => void;
}

export const WATER_SOURCE_OPTIONS = [
  "Borehole / Deep Well",
  "Borehole + Solar Powered Pump",
  "River / Perennial Stream",
  "Earth Dam / Reservoir",
  "Municipal Water Supply",
  "Rainfed / Rainwater Harvesting",
  "Seasonal Dambo / Wetland",
  "Canal / Scheme Water",
  "Other Water Source"
];

export const IRRIGATION_SYSTEM_OPTIONS = [
  "Drip Irrigation (Pressure Compensating)",
  "Micro-Jet / Micro-Sprinkler System",
  "Overhead Sprinkler System",
  "Sub-surface Drip Irrigation (SDI)",
  "Flood / Furrow Basins",
  "Center Pivot / Linear Move",
  "Manual Hose Reel / Water Bowser",
  "Rainfed / No Fixed Irrigation"
];

export const SOIL_CLASSIFICATION_OPTIONS = [
  "Sandy Loam (Well-Drained, Aerated)",
  "Red Sandy Clay Loam (Rich Iron / Fertile)",
  "Clay Loam (High Moisture Retention)",
  "Loamy Sand (Fast Draining)",
  "Alluvial / Silt Loam (River Basin)",
  "Black Cotton / Heavy Vertisol Clay",
  "Lateritic / Gravelly Loam",
  "Volcanic / High Organic Loam",
  "Other / Undetermined Soil"
];

export default function OrchardBlockWizard({
  isOpen,
  onClose,
  onSaveBlock,
  currencySymbol,
  generateULID = () => "01" + Math.random().toString(36).substr(2, 9).toUpperCase() + Date.now().toString(36).toUpperCase(),
  showToast
}: OrchardBlockWizardProps) {
  const [activeStep, setActiveStep] = useState<1 | 2 | 3 | 4 | 5>(1);

  // --- Step 1: Fruit Tree Profile & Block Identification ---
  const [selectedFruitKey, setSelectedFruitKey] = useState<string>("Dragon Fruit");
  const preset: FruitTreePreset = FRUIT_PRESETS[selectedFruitKey] || FRUIT_PRESETS["Dragon Fruit"];

  const [blockName, setBlockName] = useState("Dragon Fruit Trellis Block 1");
  const [variety, setVariety] = useState(preset.varieties[0] || "Red Flesh (Hylocereus polyrhizus)");
  const [rootstock, setRootstock] = useState(preset.rootstocks[0] || "Hardy Cuttings (Self-Rooted)");
  const [plantingDate, setPlantingDate] = useState(new Date().toISOString().split("T")[0]);
  
  // Field dimensions in meters (e.g. 50m x 30m) & Hectares
  const [fieldLengthM, setFieldLengthM] = useState<number>(100);
  const [fieldWidthM, setFieldWidthM] = useState<number>(100);
  const [blockAreaHa, setBlockAreaHa] = useState<number>(1.0);
  const [useDimensionMode, setUseDimensionMode] = useState<boolean>(true);

  const [spacingWithinRowM, setSpacingWithinRowM] = useState<number>(preset.recommendedSpacingWithinRowM);
  const [rowSpacingM, setRowSpacingM] = useState<number>(preset.recommendedRowSpacingM);
  
  // Dropdown states
  const [waterSource, setWaterSource] = useState(preset.defaultWaterSource || WATER_SOURCE_OPTIONS[0]);
  const [irrigationType, setIrrigationType] = useState(preset.defaultIrrigationType || IRRIGATION_SYSTEM_OPTIONS[0]);
  const [soilType, setSoilType] = useState(preset.defaultSoilType || SOIL_CLASSIFICATION_OPTIONS[0]);

  // --- Step 2: Population & Lifespan & Maturity Timing ---
  const [treeLifespanYears, setTreeLifespanYears] = useState<number>(preset.lifespanYears);
  const [firstBearingYears, setFirstBearingYears] = useState<number>(preset.firstBearingYears);
  const [maturityDays, setMaturityDays] = useState<number>(Math.round(preset.firstBearingYears * 365.25));
  const [maturityInputMode, setMaturityInputMode] = useState<"days" | "years">("years");
  const [harvestsPerYear, setHarvestsPerYear] = useState<number>(preset.harvestsPerYear);
  const [harvestMonth, setHarvestMonth] = useState<string>(preset.harvestMonth);

  // Auto calculate actual first harvest date based on plantingDate and maturityDays
  const actualFirstHarvestDate = useMemo(() => {
    const pDate = new Date(plantingDate || new Date());
    if (isNaN(pDate.getTime())) return new Date().toISOString().split("T")[0];
    const target = new Date(pDate.getTime());
    target.setDate(target.getDate() + Math.max(1, Math.round(maturityDays)));
    return target.toISOString().split("T")[0];
  }, [plantingDate, maturityDays]);

  // Formatted date string for elegant display (e.g. "19 Feb 2028")
  const formattedFirstHarvestDate = useMemo(() => {
    try {
      const d = new Date(actualFirstHarvestDate);
      if (isNaN(d.getTime())) return actualFirstHarvestDate;
      return d.toLocaleDateString("en-GB", {
        weekday: "short",
        day: "numeric",
        month: "short",
        year: "numeric"
      });
    } catch {
      return actualFirstHarvestDate;
    }
  }, [actualFirstHarvestDate]);

  // Handler for changing maturity days
  const handleMaturityDaysChange = (days: number) => {
    const validDays = Math.max(1, Math.round(days));
    setMaturityDays(validDays);
    setFirstBearingYears(Number((validDays / 365.25).toFixed(2)));
  };

  // Handler for changing maturity years
  const handleMaturityYearsChange = (years: number) => {
    const validYears = Math.max(0.1, Number(years));
    setFirstBearingYears(validYears);
    setMaturityDays(Math.round(validYears * 365.25));
  };

  // Handler for direct date selection for actual first harvest date
  const handleActualFirstHarvestDateChange = (dateStr: string) => {
    if (!dateStr || !plantingDate) return;
    const plant = new Date(plantingDate);
    const harvest = new Date(dateStr);
    if (isNaN(plant.getTime()) || isNaN(harvest.getTime())) return;
    const diffTime = harvest.getTime() - plant.getTime();
    const diffDays = Math.max(1, Math.round(diffTime / (1000 * 60 * 60 * 24)));
    setMaturityDays(diffDays);
    setFirstBearingYears(Number((diffDays / 365.25).toFixed(2)));
  };

  // Auto-calculated tree population based on area (Ha / m²) and spacing
  const calculatedTreePopulation = useMemo(() => {
    if (spacingWithinRowM <= 0 || rowSpacingM <= 0 || blockAreaHa <= 0) return 100;
    const areaSqM = blockAreaHa * 10000;
    const areaPerTree = spacingWithinRowM * rowSpacingM;
    return Math.max(1, Math.round(areaSqM / areaPerTree));
  }, [blockAreaHa, spacingWithinRowM, rowSpacingM]);

  const [customTreeCount, setCustomTreeCount] = useState<number | null>(null);
  const effectiveTreeCount = customTreeCount !== null ? customTreeCount : calculatedTreePopulation;

  // --- Step 3: Yield Estimation & Losses ---
  const [measuredIn, setMeasuredIn] = useState<"Units" | "Kg">(preset.measuredIn);
  const [harvestUnitName, setHarvestUnitName] = useState<string>(preset.unitName);
  const [fruitsPerTreePerHarvest, setFruitsPerTreePerHarvest] = useState<number>(preset.estimatedFruitsPerTreePerHarvest);
  const [averageFruitWeightKg, setAverageFruitWeightKg] = useState<number>(preset.averageFruitWeightKg);
  // Default Losses Buffer adjusted to 70% as requested
  const [possibleLossesPct, setPossibleLossesPct] = useState<number>(70);

  // --- Step 4: Revenue Projections & Pricing ---
  const [pricingMode, setPricingMode] = useState<"Flat" | "Grade">("Flat");
  const [pricePerUnitOrKg, setPricePerUnitOrKg] = useState<number>(
    preset.measuredIn === "Units" ? preset.defaultPricePerUnit : preset.defaultPricePerKg
  );

  const [tierA_Pct, setTierA_Pct] = useState<number>(50);
  const [tierA_Price, setTierA_Price] = useState<number>(Math.round(pricePerUnitOrKg * 1.25));
  const [tierB_Pct, setTierB_Pct] = useState<number>(35);
  const [tierB_Price, setTierB_Price] = useState<number>(pricePerUnitOrKg);
  const [tierC_Pct, setTierC_Pct] = useState<number>(15);
  const [tierC_Price, setTierC_Price] = useState<number>(Math.round(pricePerUnitOrKg * 0.6));

  // --- Step 5: Multi-Year Harvest Schedule Overrides & Custom Edits ---
  const [scheduleOverrides, setScheduleOverrides] = useState<Record<number, {
    yieldMultiplierPct?: number;
    projectedYieldKg?: number;
    pricePerUnitOrKg?: number;
    projectedRevenue?: number;
  }>>({});

  // Reset form to blank / fresh defaults
  const resetForm = () => {
    setActiveStep(1);
    setSelectedFruitKey("Dragon Fruit");
    const p = FRUIT_PRESETS["Dragon Fruit"];
    setBlockName("Dragon Fruit Trellis Block 1");
    setVariety(p.varieties[0] || "Red Flesh (Hylocereus polyrhizus)");
    setRootstock(p.rootstocks[0] || "Hardy Cuttings (Self-Rooted)");
    setPlantingDate(new Date().toISOString().split("T")[0]);
    setFieldLengthM(100);
    setFieldWidthM(100);
    setBlockAreaHa(1.0);
    setUseDimensionMode(true);
    setSpacingWithinRowM(p.recommendedSpacingWithinRowM);
    setRowSpacingM(p.recommendedRowSpacingM);
    setWaterSource(WATER_SOURCE_OPTIONS[0]);
    setIrrigationType(IRRIGATION_SYSTEM_OPTIONS[0]);
    setSoilType(SOIL_CLASSIFICATION_OPTIONS[0]);
    setTreeLifespanYears(p.lifespanYears);
    setFirstBearingYears(p.firstBearingYears);
    setHarvestsPerYear(p.harvestsPerYear);
    setHarvestMonth(p.harvestMonth);
    setCustomTreeCount(null);
    setMeasuredIn(p.measuredIn);
    setHarvestUnitName(p.unitName);
    setFruitsPerTreePerHarvest(p.estimatedFruitsPerTreePerHarvest);
    setAverageFruitWeightKg(p.averageFruitWeightKg);
    setPossibleLossesPct(70); // Adjusted default 70%
    setPricingMode("Flat");
    setPricePerUnitOrKg(p.defaultPricePerUnit);
    setTierA_Pct(50);
    setTierA_Price(Math.round(p.defaultPricePerUnit * 1.25));
    setTierB_Pct(35);
    setTierB_Price(p.defaultPricePerUnit);
    setTierC_Pct(15);
    setTierC_Price(Math.round(p.defaultPricePerUnit * 0.6));
    setScheduleOverrides({});
  };

  // Reset wizard when opened
  useEffect(() => {
    if (isOpen) {
      resetForm();
    }
  }, [isOpen]);

  // Dimension helpers: update Hectares when dimensions change
  const handleDimensionsChange = (length: number, width: number) => {
    setFieldLengthM(length);
    setFieldWidthM(width);
    if (length > 0 && width > 0) {
      const sqM = length * width;
      const ha = Number((sqM / 10000).toFixed(4));
      setBlockAreaHa(ha);
    }
  };

  // Direct Hectares change: update dimensions proportionally
  const handleHaChange = (ha: number) => {
    setBlockAreaHa(ha);
    if (ha > 0) {
      const sqM = ha * 10000;
      const side = Math.round(Math.sqrt(sqM));
      setFieldLengthM(side);
      setFieldWidthM(Math.round(sqM / side));
    }
  };

  // Switch fruit preset handlers
  const handleSelectFruit = (key: string) => {
    setSelectedFruitKey(key);
    const p = FRUIT_PRESETS[key];
    if (p) {
      setBlockName(`${p.name} Commercial Block ${Math.floor(1 + Math.random() * 9)}`);
      setVariety(p.varieties[0] || "");
      setRootstock(p.rootstocks[0] || "");
      setSpacingWithinRowM(p.recommendedSpacingWithinRowM);
      setRowSpacingM(p.recommendedRowSpacingM);
      setTreeLifespanYears(p.lifespanYears);
      setFirstBearingYears(p.firstBearingYears);
      setMaturityDays(Math.round(p.firstBearingYears * 365.25));
      setHarvestsPerYear(p.harvestsPerYear);
      setHarvestMonth(p.harvestMonth);
      setMeasuredIn(p.measuredIn);
      setHarvestUnitName(p.unitName);
      setFruitsPerTreePerHarvest(p.estimatedFruitsPerTreePerHarvest);
      setAverageFruitWeightKg(p.averageFruitWeightKg);
      setPossibleLossesPct(70); // 70% default buffer
      setPricePerUnitOrKg(p.measuredIn === "Units" ? p.defaultPricePerUnit : p.defaultPricePerKg);
      
      // Match water source, irrigation and soil to dropdown options if possible
      const matchWater = WATER_SOURCE_OPTIONS.find(w => w.toLowerCase().includes(p.defaultWaterSource.toLowerCase())) || WATER_SOURCE_OPTIONS[0];
      const matchIrrig = IRRIGATION_SYSTEM_OPTIONS.find(i => i.toLowerCase().includes(p.defaultIrrigationType.toLowerCase())) || IRRIGATION_SYSTEM_OPTIONS[0];
      const matchSoil = SOIL_CLASSIFICATION_OPTIONS.find(s => s.toLowerCase().includes(p.defaultSoilType.toLowerCase())) || SOIL_CLASSIFICATION_OPTIONS[0];
      setWaterSource(matchWater);
      setIrrigationType(matchIrrig);
      setSoilType(matchSoil);
      
      setCustomTreeCount(null);
      setScheduleOverrides({});
    }
  };

  // --- Real-Time Agronomic & Revenue Mathematics ---
  const lossFactor = Math.max(0, 1 - possibleLossesPct / 100);

  // Per Tree Per Harvest
  const grossFruitsPerTreePerHarvest = fruitsPerTreePerHarvest;
  const netSellableFruitsPerTreePerHarvest = grossFruitsPerTreePerHarvest * lossFactor;

  // Annual Totals at Full Peak Bearing (Per Tree)
  const annualGrossFruitsPerTree = grossFruitsPerTreePerHarvest * Math.max(1, harvestsPerYear);
  const annualNetFruitsPerTree = annualGrossFruitsPerTree * lossFactor;
  const annualNetYieldKgPerTree = annualNetFruitsPerTree * averageFruitWeightKg;

  // Whole Block Annual Totals at Peak Production
  const totalAnnualBlockFruits = Math.round(annualNetFruitsPerTree * effectiveTreeCount);
  const totalAnnualBlockKg = Math.round(annualNetYieldKgPerTree * effectiveTreeCount);

  // Effective Weighted Price
  const effectivePrice = useMemo(() => {
    if (pricingMode === "Flat") return pricePerUnitOrKg;
    const wPrice = (tierA_Pct / 100) * tierA_Price + (tierB_Pct / 100) * tierB_Price + (tierC_Pct / 100) * tierC_Price;
    return wPrice;
  }, [pricingMode, pricePerUnitOrKg, tierA_Pct, tierA_Price, tierB_Pct, tierB_Price, tierC_Pct, tierC_Price]);

  // Annual Projected Revenue
  const projectedPeakAnnualRevenue = useMemo(() => {
    if (measuredIn === "Units") {
      return totalAnnualBlockFruits * effectivePrice;
    } else {
      return totalAnnualBlockKg * effectivePrice;
    }
  }, [measuredIn, totalAnnualBlockFruits, totalAnnualBlockKg, effectivePrice]);

  const projectedRevenuePerHa = blockAreaHa > 0 ? projectedPeakAnnualRevenue / blockAreaHa : 0;
  const projectedRevenuePerTree = effectiveTreeCount > 0 ? projectedPeakAnnualRevenue / effectiveTreeCount : 0;

  // Base Multi-Year Harvest Schedule Generation
  const baseMultiYearSchedule = useMemo(() => {
    return generateMultiYearHarvestSchedule({
      plantingDate,
      lifespanYears: treeLifespanYears,
      firstBearingYears,
      firstHarvestDate: actualFirstHarvestDate,
      treeCount: effectiveTreeCount,
      harvestsPerYear,
      harvestMonthName: harvestMonth,
      fruitsPerTreePerHarvest,
      averageFruitWeightKg,
      lossesPct: possibleLossesPct,
      pricePerUnitOrKg: effectivePrice,
      measuredIn,
      bearingCurve: preset.bearingCurve
    });
  }, [
    plantingDate,
    treeLifespanYears,
    firstBearingYears,
    actualFirstHarvestDate,
    effectiveTreeCount,
    harvestsPerYear,
    harvestMonth,
    fruitsPerTreePerHarvest,
    averageFruitWeightKg,
    possibleLossesPct,
    effectivePrice,
    measuredIn,
    preset
  ]);

  // Final Multi-Year Schedule factoring in inline custom edits
  const multiYearSchedule: OrchardYearHarvestSchedule[] = useMemo(() => {
    return baseMultiYearSchedule.map(yr => {
      const override = scheduleOverrides[yr.yearNumber];
      if (!override) return yr;

      const yieldMultiplier = override.yieldMultiplierPct !== undefined ? override.yieldMultiplierPct : yr.yieldMultiplierPct;
      const unitPrice = override.pricePerUnitOrKg !== undefined ? override.pricePerUnitOrKg : effectivePrice;
      
      // Calculate yield if multiplier was overridden
      let yieldKg = override.projectedYieldKg !== undefined ? override.projectedYieldKg : yr.projectedYieldKg;
      if (override.yieldMultiplierPct !== undefined && override.projectedYieldKg === undefined) {
        const peakKg = (annualNetYieldKgPerTree * effectiveTreeCount);
        yieldKg = Math.round(peakKg * (yieldMultiplier / 100));
      }

      // Calculate revenue
      let revenue = override.projectedRevenue;
      if (revenue === undefined) {
        if (measuredIn === "Units") {
          const fruitsCount = Math.round(yr.projectedFruitsPerTree * (yieldMultiplier / (yr.yieldMultiplierPct || 100 || 1)) * effectiveTreeCount);
          revenue = Math.round(fruitsCount * unitPrice);
        } else {
          revenue = Math.round(yieldKg * unitPrice);
        }
      }

      return {
        ...yr,
        yieldMultiplierPct: yieldMultiplier,
        projectedYieldKg: yieldKg,
        projectedRevenue: revenue
      };
    });
  }, [baseMultiYearSchedule, scheduleOverrides, effectivePrice, annualNetYieldKgPerTree, effectiveTreeCount, measuredIn]);

  const lifetimeProjectedRevenue = multiYearSchedule.reduce((sum, yr) => sum + (yr.projectedRevenue || 0), 0);

  // Inline schedule update handlers
  const handleScheduleEdit = (yearNumber: number, field: "yieldMultiplierPct" | "projectedYieldKg" | "pricePerUnitOrKg", value: number) => {
    setScheduleOverrides(prev => {
      const current = prev[yearNumber] || {};
      const updated = { ...current, [field]: value };
      return {
        ...prev,
        [yearNumber]: updated
      };
    });
  };

  // Handle Complete Block Creation
  const handleEstablishBlock = () => {
    const blockId = generateULID();

    const pricingTierConfig: PricingTierConfig = pricingMode === "Grade" ? {
      splitType: "Grade",
      tiers: [
        { id: "t1", label: "Grade A (Export / Supermarket)", percentage: tierA_Pct, pricePerUnit: tierA_Price },
        { id: "t2", label: "Grade B (Domestic Wholesale)", percentage: tierB_Pct, pricePerUnit: tierB_Price },
        { id: "t3", label: "Grade C (Processing / Seconds)", percentage: tierC_Pct, pricePerUnit: tierC_Price },
      ]
    } : {
      splitType: "Flat",
      tiers: [
        { id: "flat", label: "Standard Grade", percentage: 100, pricePerUnit: pricePerUnitOrKg }
      ]
    };

    const orchardConfig: OrchardConfig = {
      fruitType: preset.name,
      variety,
      rootstock,
      spacing: `${spacingWithinRowM}m x ${rowSpacingM}m`,
      plantingDate,
      waterSource,
      irrigationType,
      soilType,
      treeCount: effectiveTreeCount,
      blockAreaHa,
      
      treeLifespanYears,
      firstBearingYears,
      harvestsPerYear,
      harvestMonth,
      measuredInKgOrUnits: measuredIn,
      harvestUnitName,
      estimatedFruitsPerTreePerHarvest: fruitsPerTreePerHarvest,
      averageFruitWeightKg,
      possibleLossesPct,
      netSellableFruitsPerTree: Math.round(annualNetFruitsPerTree),
      netSellableYieldPerTreeKg: Number(annualNetYieldKgPerTree.toFixed(2)),
      pricePerUnitOrKg: effectivePrice,
      expectedAnnualYieldKg: totalAnnualBlockKg,
      expectedAnnualYieldUnits: totalAnnualBlockFruits,
      projectedAnnualRevenue: Math.round(projectedPeakAnnualRevenue),
      lifetimeProjectedRevenue: Math.round(lifetimeProjectedRevenue),
      pricingTierConfig,
      multiYearHarvestSchedule: multiYearSchedule,
      labourLogs: []
    };

    // Calculate first expected harvest date from schedule
    const firstHarvestObj = multiYearSchedule.find(s => s.lifecycleStage !== "Juvenile");
    const nextHarvestDate = firstHarvestObj ? firstHarvestObj.expectedHarvestDate : plantingDate;

    const newBlock: CropCycle = {
      id: blockId,
      cropType: `${preset.name} Orchard`,
      cropName: `${preset.name} (${variety})`,
      variety,
      plantingDate,
      expectedHarvestDate: nextHarvestDate,
      fieldBlock: blockName,
      areaHectares: blockAreaHa,
      expectedYieldKg: totalAnnualBlockKg,
      projectedYield: measuredIn === "Units" ? totalAnnualBlockFruits : totalAnnualBlockKg,
      projectedYieldUnit: measuredIn === "Units" ? harvestUnitName + "s" : "Kg",
      status: "Nursery",
      stage: "Planting & Trellis Layout",
      milestones: [
        { id: "m1", name: "Block Layout & Trellis Construction", startDate: plantingDate, endDate: plantingDate, isCompleted: true },
        { id: "m2", name: "Sapling Planting & Rootzone Mulch", startDate: plantingDate, endDate: plantingDate, isCompleted: false },
        { id: "m3", name: "First Flowering Observation", startDate: nextHarvestDate, endDate: nextHarvestDate, isCompleted: false },
        { id: "m4", name: "First Commercial Harvest Cycle", startDate: nextHarvestDate, endDate: nextHarvestDate, isCompleted: false },
      ],
      expensesLinked: 0,
      revenueLinked: 0,
      farmId: "tenant-farm",
      cycleType: "perennial_orchard",
      orchard: orchardConfig,
      plantingMethod: "Field",
      measuredInKgOrUnits: measuredIn,
      harvestUnitName,
      expectedSellingPricePerUnit: measuredIn === "Units" ? effectivePrice : undefined,
      expectedSellingPricePerKg: measuredIn === "Kg" ? effectivePrice : undefined,
      totalExpectedPlantPopulation: effectiveTreeCount,
      expectedSurvivalRate: Math.round(100 - possibleLossesPct),
      expectedHarvestRate: Math.round(100 - possibleLossesPct),
      avgHarvestUnitsPerPlant: Math.round(annualNetFruitsPerTree),
      averageWeightPerPlantKg: Number(annualNetYieldKgPerTree.toFixed(2)),
      expectedRevenueProjection: Math.round(projectedPeakAnnualRevenue)
    };

    onSaveBlock(newBlock);
    resetForm();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/75 backdrop-blur-xs z-[1200] flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full overflow-hidden max-h-[92vh] flex flex-col my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-900 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <Trees className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400 font-mono">Orchard Architecture</span>
                <span className="px-2 py-0.2 bg-emerald-950 text-emerald-300 rounded text-[9px] font-bold border border-emerald-800/60">Perennial Crop Cycle Engine</span>
              </div>
              <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-2">
                <span>Orchard Block Setup & Revenue Projection Wizard</span>
              </h2>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={resetForm}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
              title="Reset form to blank defaults"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Blank</span>
            </button>
            <button 
              type="button" 
              onClick={onClose} 
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center text-sm font-bold transition-colors cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* 5-Step Progress Stepper */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 shrink-0">
          <div className="grid grid-cols-5 gap-2">
            {[
              { num: 1, label: "1. Fruit Tree Profile", desc: "Type, Size & Water" },
              { num: 2, label: "2. Population & Lifespan", desc: "Spacing & Density" },
              { num: 3, label: "3. Yield & Risk Losses", desc: "Yield & 70% Buffer" },
              { num: 4, label: "4. Revenue Projections", desc: "Pricing & Target Yield" },
              { num: 5, label: "5. Multi-Year Schedule", desc: "Editable Lifetime Plan" },
            ].map((step) => {
              const isActive = activeStep === step.num;
              const isPast = activeStep > step.num;
              return (
                <button
                  key={step.num}
                  type="button"
                  onClick={() => setActiveStep(step.num as any)}
                  className={`text-left p-2 rounded-xl border transition-all cursor-pointer ${
                    isActive 
                      ? "bg-white border-emerald-500 shadow-xs ring-2 ring-emerald-500/20" 
                      : isPast 
                        ? "bg-emerald-50/60 border-emerald-200 text-slate-700" 
                        : "bg-slate-100/60 border-slate-200/80 text-slate-400"
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className={`w-4 h-4 rounded-full text-[9px] font-black flex items-center justify-center font-mono ${
                      isActive 
                        ? "bg-emerald-500 text-slate-950" 
                        : isPast 
                          ? "bg-emerald-600 text-white" 
                          : "bg-slate-300 text-slate-600"
                    }`}>
                      {isPast ? "✓" : step.num}
                    </span>
                    <span className={`text-[10px] font-black uppercase tracking-tight truncate ${
                      isActive ? "text-emerald-700 font-extrabold" : isPast ? "text-emerald-900" : "text-slate-500"
                    }`}>
                      {step.label}
                    </span>
                  </div>
                  <span className="text-[9px] text-slate-500 block truncate">{step.desc}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Wizard Form Body */}
        <div className="p-6 overflow-y-auto flex-1 text-xs space-y-6">
          
          {/* STEP 1: Fruit Tree Profile & Block Size */}
          {activeStep === 1 && (
            <div className="space-y-5 animate-in fade-in duration-150">
              
              {/* Preset Selection Tiles */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Trees className="w-4 h-4 text-emerald-600" />
                    <span>Select Fruit Tree Species (With Agronomic Defaults)</span>
                  </label>
                  <span className="text-[10px] text-slate-400 font-medium">Includes exotic Dragon Fruit & African perennials</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
                  {Object.keys(FRUIT_PRESETS).map((key) => {
                    const item = FRUIT_PRESETS[key];
                    const isSelected = selectedFruitKey === key;
                    const isDragon = key === "Dragon Fruit";

                    return (
                      <button
                        key={key}
                        type="button"
                        onClick={() => handleSelectFruit(key)}
                        className={`p-3 rounded-xl border text-left transition-all relative flex flex-col justify-between cursor-pointer ${
                          isSelected 
                            ? "bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs" 
                            : isDragon 
                              ? "bg-gradient-to-br from-purple-50 to-pink-50 border-purple-300 hover:border-purple-400" 
                              : "bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                        }`}
                      >
                        {isDragon && (
                          <span className="absolute -top-2 right-2 px-1.5 py-0.2 bg-purple-600 text-white font-black text-[8px] rounded-full uppercase tracking-wider shadow-xs animate-pulse">
                            ⭐ Dragon Fruit
                          </span>
                        )}
                        <div>
                          <span className="font-extrabold text-slate-900 block text-xs leading-snug">{item.name}</span>
                          <span className="text-[9px] text-slate-500 italic block mt-0.5">{item.scientificName}</span>
                        </div>
                        <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[9px] font-mono">
                          <span className="text-slate-400">{item.lifespanYears}y life</span>
                          <span className="font-bold text-emerald-700">{currencySymbol}{item.defaultPricePerUnit}/{item.unitName}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Block Identification Details & Block Size in Meters */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                      Orchard Block Name / Field Identifier *
                    </label>
                    <input 
                      type="text" 
                      value={blockName} 
                      onChange={e => setBlockName(e.target.value)} 
                      required 
                      placeholder="e.g. Dragon Fruit Trellis Block 1"
                      className="w-full bg-white border border-slate-200 rounded-xl p-2.5 font-bold text-slate-800 text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                      Cultivar / Variety *
                    </label>
                    <select 
                      value={variety} 
                      onChange={e => setVariety(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl p-2.5 font-bold text-slate-800 text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                    >
                      {preset.varieties.map(v => (
                        <option key={v} value={v}>{v}</option>
                      ))}
                      <option value="Custom / Local Selected">Custom / Other Variety</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                      Rootstock / Propagation Source
                    </label>
                    <select 
                      value={rootstock} 
                      onChange={e => setRootstock(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-700 text-xs outline-none"
                    >
                      {preset.rootstocks.map(r => (
                        <option key={r} value={r}>{r}</option>
                      ))}
                      <option value="Standard Clonal Rootstock">Standard Clonal Rootstock</option>
                      <option value="Seedling / Direct">Seedling / Direct</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                      Planting / Establishment Date
                    </label>
                    <input 
                      type="date" 
                      value={plantingDate} 
                      onChange={e => setPlantingDate(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl p-2 font-mono text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    <div className="flex items-center gap-1.5 mt-1.5 text-[9.5px] text-emerald-700 bg-emerald-50/80 px-2 py-1 rounded-lg border border-emerald-200">
                      <Clock className="w-3 h-3 text-emerald-600 shrink-0" />
                      <span className="font-medium">
                        1st Harvest: <strong className="font-mono">{formattedFirstHarvestDate}</strong> ({maturityDays} days / {firstBearingYears}y)
                      </span>
                    </div>
                  </div>
                </div>

                {/* Block Size Configuration by Field Dimensions (Meters) and Hectares */}
                <div className="p-3.5 bg-white border border-slate-200 rounded-xl space-y-3">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-1.5">
                      <Ruler className="w-4 h-4 text-emerald-600" />
                      <span className="text-[10px] font-black uppercase tracking-wider text-slate-700">
                        Block Size Configuration (Dimensions in Meters & Auto-Hectares)
                      </span>
                    </div>
                    <span className="text-[9.5px] text-slate-400 font-mono">1 Hectare = 10,000 m²</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                    <div className="sm:col-span-4">
                      <label className="text-[9.5px] font-black uppercase text-slate-400 block mb-1">
                        Field Length (Meters)
                      </label>
                      <div className="relative">
                        <input 
                          type="number" 
                          min="1" 
                          step="1"
                          value={fieldLengthM} 
                          onChange={e => handleDimensionsChange(Math.max(1, Number(e.target.value)), fieldWidthM)}
                          placeholder="e.g. 50"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 font-mono font-bold text-slate-900 text-xs pr-8 outline-none focus:bg-white focus:ring-2 focus:ring-emerald-500"
                        />
                        <span className="absolute right-2.5 top-2 text-[10px] text-slate-400 font-bold">m</span>
                      </div>
                    </div>

                    <div className="sm:col-span-1 text-center font-bold text-slate-400 text-sm hidden sm:block">
                      ×
                    </div>

                    <div className="sm:col-span-4">
                      <label className="text-[9.5px] font-black uppercase text-slate-400 block mb-1">
                        Field Width (Meters)
                      </label>
                      <div className="relative">
                        <input 
                          type="number" 
                          min="1" 
                          step="1"
                          value={fieldWidthM} 
                          onChange={e => handleDimensionsChange(fieldLengthM, Math.max(1, Number(e.target.value)))}
                          placeholder="e.g. 30"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 font-mono font-bold text-slate-900 text-xs pr-8 outline-none focus:bg-white focus:ring-2 focus:ring-emerald-500"
                        />
                        <span className="absolute right-2.5 top-2 text-[10px] text-slate-400 font-bold">m</span>
                      </div>
                    </div>

                    <div className="sm:col-span-3">
                      <label className="text-[9.5px] font-black uppercase text-emerald-700 block mb-1">
                        Block Area (Hectares) *
                      </label>
                      <div className="relative">
                        <input 
                          type="number" 
                          step="0.01" 
                          min="0.01" 
                          value={blockAreaHa} 
                          onChange={e => handleHaChange(Math.max(0.01, Number(e.target.value)))}
                          className="w-full bg-emerald-50/70 border border-emerald-300 rounded-xl p-2 font-mono font-black text-emerald-950 text-xs pr-8 outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                        <span className="absolute right-2.5 top-2 text-[10px] text-emerald-700 font-bold">Ha</span>
                      </div>
                    </div>
                  </div>

                  {/* Calculated Area Display */}
                  <div className="p-2.5 bg-slate-50 border border-slate-200/80 rounded-lg flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-500 font-medium">Configured Footprint:</span>
                      <span className="font-mono font-bold text-slate-800">
                        {fieldLengthM}m × {fieldWidthM}m = {(fieldLengthM * fieldWidthM).toLocaleString()} m²
                      </span>
                    </div>
                    <div className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 rounded-full font-mono font-black text-[11px] border border-emerald-200">
                      {blockAreaHa.toFixed(2)} Hectares
                    </div>
                  </div>
                </div>

                {/* Dropdowns for Water Source, Irrigation System, Soil Classification */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-200/60">
                  <div>
                    <label className="text-[9.5px] font-black uppercase text-slate-500 block mb-1 flex items-center gap-1">
                      <Droplet className="w-3 h-3 text-blue-500" />
                      <span>Water Source *</span>
                    </label>
                    <select 
                      value={waterSource} 
                      onChange={e => setWaterSource(e.target.value)} 
                      className="w-full bg-white border border-slate-200 rounded-xl p-2 font-semibold text-slate-800 text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                    >
                      {WATER_SOURCE_OPTIONS.map(opt => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[9.5px] font-black uppercase text-slate-500 block mb-1 flex items-center gap-1">
                      <Sliders className="w-3 h-3 text-emerald-500" />
                      <span>Irrigation System *</span>
                    </label>
                    <select 
                      value={irrigationType} 
                      onChange={e => setIrrigationType(e.target.value)} 
                      className="w-full bg-white border border-slate-200 rounded-xl p-2 font-semibold text-slate-800 text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                    >
                      {IRRIGATION_SYSTEM_OPTIONS.map(opt => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[9.5px] font-black uppercase text-slate-500 block mb-1 flex items-center gap-1">
                      <Layers className="w-3 h-3 text-amber-600" />
                      <span>Soil Classification *</span>
                    </label>
                    <select 
                      value={soilType} 
                      onChange={e => setSoilType(e.target.value)} 
                      className="w-full bg-white border border-slate-200 rounded-xl p-2 font-semibold text-slate-800 text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                    >
                      {SOIL_CLASSIFICATION_OPTIONS.map(opt => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* STEP 2: Population, Spacing & Life Cycle */}
          {activeStep === 2 && (
            <div className="space-y-5 animate-in fade-in duration-150">
              
              <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-start gap-3">
                <Info className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <h4 className="font-extrabold text-emerald-950 text-xs">Perennial Stand Configuration & Spacing Model</h4>
                  <p className="text-[11px] text-emerald-800 leading-relaxed">
                    Fruit trees and trellis posts (like Dragon Fruit) are established once and maintained for multiple decades. The system calculates plant density per hectare and projects multi-year harvest schedules.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Spacing Card */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Sliders className="w-4 h-4 text-slate-500" />
                    <span>Tree / Trellis Spacing Model</span>
                  </h4>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Within Row Spacing (m)
                      </label>
                      <input 
                        type="number" 
                        step="0.5" 
                        min="0.5" 
                        value={spacingWithinRowM} 
                        onChange={e => setSpacingWithinRowM(Math.max(0.5, Number(e.target.value)))}
                        className="w-full bg-white border border-slate-200 rounded-xl p-2 font-mono font-bold text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                      <span className="text-[9px] text-slate-400 block mt-0.5">Distance between plants</span>
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Row Spacing (m)
                      </label>
                      <input 
                        type="number" 
                        step="0.5" 
                        min="0.5" 
                        value={rowSpacingM} 
                        onChange={e => setRowSpacingM(Math.max(0.5, Number(e.target.value)))}
                        className="w-full bg-white border border-slate-200 rounded-xl p-2 font-mono font-bold text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                      <span className="text-[9px] text-slate-400 block mt-0.5">Distance between rows</span>
                    </div>
                  </div>

                  {preset.trellisType && (
                    <div className="p-2.5 bg-purple-50 border border-purple-200 rounded-lg text-[10px] text-purple-900 font-medium">
                      <strong>Trellis Framework:</strong> {preset.trellisType}
                    </div>
                  )}

                  <div className="pt-2 border-t border-slate-200 flex justify-between items-center text-xs">
                    <span className="text-slate-500 font-medium">Calculated Density:</span>
                    <span className="font-mono font-black text-slate-800">
                      {Math.round(10000 / (spacingWithinRowM * rowSpacingM))} Trees / Ha
                    </span>
                  </div>
                </div>

                {/* Population Card with Quick +/- addition/subtraction and Auto-Calculation */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Trees className="w-4 h-4 text-emerald-600" />
                    <span>Total Plant / Post Count (Auto-Calculated)</span>
                  </h4>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-[10px] font-black uppercase text-slate-500">
                        Total Trees / Trellis Posts
                      </label>
                      {customTreeCount !== null && (
                        <button 
                          type="button" 
                          onClick={() => setCustomTreeCount(null)}
                          className="text-[9px] text-emerald-600 hover:underline font-bold"
                        >
                          Reset to Auto ({calculatedTreePopulation})
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setCustomTreeCount(Math.max(1, effectiveTreeCount - 10))}
                        className="w-8 h-9 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg font-bold text-slate-700 flex items-center justify-center cursor-pointer active:scale-95"
                        title="Subtract 10 trees"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>

                      <input 
                        type="number" 
                        value={effectiveTreeCount} 
                        onChange={e => setCustomTreeCount(Math.max(1, Number(e.target.value)))}
                        className="flex-1 bg-white border border-slate-200 rounded-xl p-2 font-mono font-black text-slate-900 text-sm focus:ring-2 focus:ring-emerald-500 outline-none text-center"
                      />

                      <button
                        type="button"
                        onClick={() => setCustomTreeCount(effectiveTreeCount + 10)}
                        className="w-8 h-9 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg font-bold text-slate-700 flex items-center justify-center cursor-pointer active:scale-95"
                        title="Add 10 trees"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <span className="text-[9.5px] text-slate-400 block mt-1">
                      Auto-computed: {calculatedTreePopulation} trees for {blockAreaHa} Ha at {spacingWithinRowM}m × {rowSpacingM}m spacing
                    </span>
                  </div>

                  <div className="pt-2 border-t border-slate-200 text-xs">
                    <div>
                      <span className="text-[9px] text-slate-400 uppercase font-black block">Tree Commercial Lifespan</span>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <input 
                          type="number" 
                          min="3" 
                          max="60" 
                          value={treeLifespanYears} 
                          onChange={e => setTreeLifespanYears(Number(e.target.value))}
                          className="w-16 bg-white border border-slate-200 rounded-lg p-1 font-mono font-bold text-xs outline-none focus:ring-1 focus:ring-emerald-500" 
                        />
                        <span className="font-bold text-slate-700">Years Production</span>
                      </div>
                    </div>
                  </div>

                </div>

              </div>

              {/* Maturity to First Fruit Harvest & Auto-Calculated Target Date */}
              <div className="p-4 bg-amber-50/50 border border-amber-200/80 rounded-xl space-y-4 shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-amber-200/60 pb-2.5">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-amber-100 text-amber-800 rounded-lg">
                      <Timer className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-amber-950 flex items-center gap-1.5">
                        <span>Maturity Period to First Fruit Harvest & Target Date</span>
                      </h4>
                      <p className="text-[10px] text-amber-800">
                        Set number of days or years to maturity to automatically compute the actual date of first harvest.
                      </p>
                    </div>
                  </div>

                  {/* Mode Selector */}
                  <div className="flex items-center bg-white border border-amber-300/80 p-0.5 rounded-lg text-[10px] font-bold self-start sm:self-auto">
                    <button
                      type="button"
                      onClick={() => setMaturityInputMode("years")}
                      className={`px-2.5 py-1 rounded-md transition-colors ${
                        maturityInputMode === "years"
                          ? "bg-amber-600 text-white shadow-xs"
                          : "text-amber-900 hover:bg-amber-50"
                      }`}
                    >
                      In Years (e.g. {firstBearingYears}y)
                    </button>
                    <button
                      type="button"
                      onClick={() => setMaturityInputMode("days")}
                      className={`px-2.5 py-1 rounded-md transition-colors ${
                        maturityInputMode === "days"
                          ? "bg-amber-600 text-white shadow-xs"
                          : "text-amber-900 hover:bg-amber-50"
                      }`}
                    >
                      In Days (e.g. {maturityDays}d)
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start">
                  
                  {/* Left Column: Synchronized Maturity Configuration */}
                  <div className="md:col-span-6 space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      
                      {/* Days Input */}
                      <div className={`p-2.5 rounded-xl border transition-all ${
                        maturityInputMode === "days"
                          ? "bg-white border-amber-400 ring-2 ring-amber-400/20"
                          : "bg-white/70 border-slate-200"
                      }`}>
                        <label className="text-[9.5px] font-black uppercase text-slate-500 block mb-1">
                          Days to Maturity
                        </label>
                        <div className="flex items-center gap-1.5">
                          <input 
                            type="number" 
                            min="30" 
                            max="3650"
                            step="1"
                            value={maturityDays} 
                            onChange={e => handleMaturityDaysChange(Number(e.target.value))}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg p-1.5 font-mono font-black text-slate-900 text-xs focus:bg-white focus:ring-1 focus:ring-amber-500 outline-none"
                          />
                          <span className="text-[10px] font-bold text-slate-500 font-mono">Days</span>
                        </div>
                        
                        {/* Quick +/- day nudge buttons */}
                        <div className="flex items-center gap-1 mt-2">
                          <button
                            type="button"
                            onClick={() => handleMaturityDaysChange(maturityDays - 30)}
                            className="flex-1 py-0.5 px-1 bg-slate-100 hover:bg-slate-200 rounded text-[9px] font-bold text-slate-600 transition-colors"
                            title="Subtract 30 days"
                          >
                            -30d
                          </button>
                          <button
                            type="button"
                            onClick={() => handleMaturityDaysChange(maturityDays + 30)}
                            className="flex-1 py-0.5 px-1 bg-slate-100 hover:bg-slate-200 rounded text-[9px] font-bold text-slate-600 transition-colors"
                            title="Add 30 days"
                          >
                            +30d
                          </button>
                          <button
                            type="button"
                            onClick={() => handleMaturityDaysChange(maturityDays + 180)}
                            className="flex-1 py-0.5 px-1 bg-slate-100 hover:bg-slate-200 rounded text-[9px] font-bold text-slate-600 transition-colors"
                            title="Add ~6 months (180 days)"
                          >
                            +180d
                          </button>
                        </div>
                      </div>

                      {/* Years Input */}
                      <div className={`p-2.5 rounded-xl border transition-all ${
                        maturityInputMode === "years"
                          ? "bg-white border-amber-400 ring-2 ring-amber-400/20"
                          : "bg-white/70 border-slate-200"
                      }`}>
                        <label className="text-[9.5px] font-black uppercase text-slate-500 block mb-1">
                          Years to Maturity
                        </label>
                        <div className="flex items-center gap-1.5">
                          <input 
                            type="number" 
                            min="0.1" 
                            max="10"
                            step="0.1"
                            value={firstBearingYears} 
                            onChange={e => handleMaturityYearsChange(Number(e.target.value))}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg p-1.5 font-mono font-black text-slate-900 text-xs focus:bg-white focus:ring-1 focus:ring-amber-500 outline-none"
                          />
                          <span className="text-[10px] font-bold text-slate-500 font-mono">Years</span>
                        </div>

                        {/* Quick +/- year nudge buttons */}
                        <div className="flex items-center gap-1 mt-2">
                          <button
                            type="button"
                            onClick={() => handleMaturityYearsChange(Math.max(0.5, firstBearingYears - 0.5))}
                            className="flex-1 py-0.5 px-1 bg-slate-100 hover:bg-slate-200 rounded text-[9px] font-bold text-slate-600 transition-colors"
                            title="Subtract 0.5 Year"
                          >
                            -0.5y
                          </button>
                          <button
                            type="button"
                            onClick={() => handleMaturityYearsChange(firstBearingYears + 0.5)}
                            className="flex-1 py-0.5 px-1 bg-slate-100 hover:bg-slate-200 rounded text-[9px] font-bold text-slate-600 transition-colors"
                            title="Add 0.5 Year"
                          >
                            +0.5y
                          </button>
                        </div>
                      </div>

                    </div>

                    {/* Common Crop Maturity Presets */}
                    <div className="space-y-1">
                      <span className="text-[9px] font-black uppercase text-slate-400 block">
                        Quick Maturity Presets:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          { label: "1.0 Yr (365d)", days: 365 },
                          { label: "1.5 Yrs (548d)", days: 548 },
                          { label: "2.0 Yrs (730d)", days: 730 },
                          { label: "3.0 Yrs (1,095d)", days: 1095 },
                          { label: "4.0 Yrs (1,460d)", days: 1460 }
                        ].map(p => (
                          <button
                            key={p.days}
                            type="button"
                            onClick={() => handleMaturityDaysChange(p.days)}
                            className={`px-2 py-0.5 rounded text-[9.5px] font-bold transition-all ${
                              Math.abs(maturityDays - p.days) <= 15
                                ? "bg-amber-600 text-white font-black"
                                : "bg-white border border-slate-200 text-slate-600 hover:bg-amber-100/50"
                            }`}
                          >
                            {p.label}
                          </button>
                        ))}
                      </div>
                    </div>

                  </div>

                  {/* Right Column: Auto-Calculated Actual First Harvest Date Banner & Tuning */}
                  <div className="md:col-span-6 bg-gradient-to-br from-emerald-900 to-slate-900 text-white p-3.5 rounded-xl shadow-xs space-y-2.5">
                    
                    <div className="flex justify-between items-center border-b border-emerald-700/50 pb-2">
                      <span className="text-[10px] font-black uppercase tracking-wider text-emerald-300 flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Actual Date of First Fruit Harvest</span>
                      </span>
                      <span className="px-2 py-0.5 bg-emerald-800/90 text-emerald-100 rounded text-[9px] font-mono font-bold">
                        Auto-Calculated
                      </span>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xl font-black font-mono tracking-tight text-white">
                          {formattedFirstHarvestDate}
                        </span>
                      </div>
                      <p className="text-[10px] text-emerald-200 font-mono">
                        ISO Target: <strong className="text-white">{actualFirstHarvestDate}</strong>
                      </p>
                    </div>

                    {/* Timeline Chain Display */}
                    <div className="p-2 bg-emerald-950/70 border border-emerald-700/40 rounded-lg text-[10px] space-y-1">
                      <div className="flex items-center justify-between text-emerald-200">
                        <span>🌱 Planting Date:</span>
                        <strong className="text-white font-mono">{plantingDate}</strong>
                      </div>
                      <div className="flex items-center justify-between text-emerald-200">
                        <span>⏳ Maturity Duration:</span>
                        <strong className="text-amber-300 font-mono">
                          +{maturityDays} Days ({firstBearingYears} Years / ~{Math.round(maturityDays / 30.4)} Months)
                        </strong>
                      </div>
                      <div className="flex items-center justify-between text-emerald-100 pt-1 border-t border-emerald-800/60">
                        <span>🎯 First Harvest Date:</span>
                        <strong className="text-emerald-400 font-mono">{actualFirstHarvestDate}</strong>
                      </div>
                    </div>

                    {/* Direct Target Harvest Date Picker */}
                    <div className="pt-1">
                      <label className="text-[9px] font-bold text-emerald-200 block mb-1">
                        Override / Pick Exact First Harvest Date:
                      </label>
                      <input 
                        type="date" 
                        value={actualFirstHarvestDate} 
                        onChange={e => handleActualFirstHarvestDateChange(e.target.value)}
                        className="w-full bg-slate-800 text-white border border-emerald-600/50 rounded-lg p-1.5 font-mono text-xs outline-none focus:ring-1 focus:ring-emerald-400"
                      />
                      <span className="text-[8.5px] text-emerald-300/80 block mt-0.5">
                        Selecting a date will auto-reverse compute the days and years to maturity.
                      </span>
                    </div>

                  </div>

                </div>
              </div>

              {/* Harvest Flushes & Months */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                    Annual Harvest Flushes / Cycles Per Year
                  </label>
                  <input 
                    type="number" 
                    min="1" 
                    max="12" 
                    value={harvestsPerYear} 
                    onChange={e => setHarvestsPerYear(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-white border border-slate-200 rounded-xl p-2 font-mono font-bold text-xs"
                  />
                  <span className="text-[9.5px] text-slate-400 block mt-1">
                    e.g. Dragon Fruit has 3-4 flushes; Avocado / Mango has 1 main season
                  </span>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                    Primary Harvest Season / Months
                  </label>
                  <input 
                    type="text" 
                    value={harvestMonth} 
                    onChange={e => setHarvestMonth(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl p-2 font-semibold text-xs"
                  />
                  <span className="text-[9.5px] text-slate-400 block mt-1">
                    Target harvest window for calendar forecasting
                  </span>
                </div>
              </div>

            </div>
          )}

          {/* STEP 3: Yield Estimation & Losses */}
          {activeStep === 3 && (
            <div className="space-y-5 animate-in fade-in duration-150">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Measurement & Yield Units */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Sliders className="w-4 h-4 text-slate-500" />
                    <span>Harvest Measurement Metric</span>
                  </h4>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setMeasuredIn("Units")}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        measuredIn === "Units" 
                          ? "bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs" 
                          : "bg-white border-slate-200 text-slate-600 font-bold"
                      }`}
                    >
                      <span className="block text-xs uppercase">Sell By Units (Fruits)</span>
                      <span className="text-[9px] text-slate-400 block mt-0.5">e.g. Per Fruit / Per Box</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setMeasuredIn("Kg")}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        measuredIn === "Kg" 
                          ? "bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs" 
                          : "bg-white border-slate-200 text-slate-600 font-bold"
                      }`}
                    >
                      <span className="block text-xs uppercase">Sell By Weight (Kg)</span>
                      <span className="text-[9px] text-slate-400 block mt-0.5">e.g. Per Kilogram / Ton</span>
                    </button>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                      Harvest Unit Label
                    </label>
                    <input 
                      type="text" 
                      value={harvestUnitName} 
                      onChange={e => setHarvestUnitName(e.target.value)}
                      placeholder="e.g. Fruit, Bunch, Box"
                      className="w-full bg-white border border-slate-200 rounded-xl p-2 font-bold text-xs"
                    />
                  </div>
                </div>

                {/* Yield per Tree Configuration & Losses Buffer adjusted to 70% */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Sprout className="w-4 h-4 text-emerald-600" />
                    <span>Estimated Fruits Per Tree / Harvest</span>
                  </h4>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Fruits Per Tree / Flush *
                      </label>
                      <input 
                        type="number" 
                        min="1" 
                        value={fruitsPerTreePerHarvest} 
                        onChange={e => setFruitsPerTreePerHarvest(Math.max(1, Number(e.target.value)))}
                        className="w-full bg-white border border-slate-200 rounded-xl p-2 font-mono font-black text-slate-900 text-xs"
                      />
                      <span className="text-[9px] text-slate-400 block mt-0.5">Per tree per harvest flush</span>
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Avg Weight Per Fruit (Kg) *
                      </label>
                      <input 
                        type="number" 
                        step="0.01" 
                        min="0.01" 
                        value={averageFruitWeightKg} 
                        onChange={e => setAverageFruitWeightKg(Math.max(0.01, Number(e.target.value)))}
                        className="w-full bg-white border border-slate-200 rounded-xl p-2 font-mono font-black text-slate-900 text-xs"
                      />
                      <span className="text-[9px] text-slate-400 block mt-0.5">e.g. 0.42 kg for Dragon Fruit</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-[10px] font-black uppercase text-slate-500 flex items-center gap-1">
                        <ShieldAlert className="w-3.5 h-3.5 text-rose-500" />
                        <span>Possible Losses Buffer (%) *</span>
                      </label>
                      <div className="flex items-center gap-2">
                        <input 
                          type="number"
                          min="0"
                          max="70"
                          value={possibleLossesPct}
                          onChange={e => setPossibleLossesPct(Math.min(70, Math.max(0, Number(e.target.value))))}
                          className="w-12 bg-white border border-rose-300 rounded p-1 font-mono font-black text-rose-600 text-xs text-center outline-none"
                        />
                        <span className="font-mono font-black text-rose-600 text-xs">%</span>
                      </div>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="70" 
                      step="1" 
                      value={possibleLossesPct} 
                      onChange={e => setPossibleLossesPct(Number(e.target.value))}
                      className="w-full accent-rose-500 cursor-pointer"
                    />
                    <div className="flex justify-between text-[9px] text-slate-400 mt-0.5">
                      <span>0% (Perfect Harvest)</span>
                      <span>35% (Moderate Buffer)</span>
                      <span className="font-bold text-rose-600">70% (High Buffer)</span>
                    </div>
                    <span className="text-[9px] text-slate-400 block mt-1">
                      Factors in sunburn, bird damage, fruit drop, and handling grading rejects
                    </span>
                  </div>

                </div>

              </div>

              {/* Calculated Yield Summary Card */}
              <div className="p-4 bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-xl shadow-md space-y-3">
                <div className="flex justify-between items-center border-b border-slate-700 pb-2">
                  <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400 font-mono">
                    Net Projected Production Metrics (Peak Maturity)
                  </span>
                  <span className="text-[10px] text-slate-300 font-mono">
                    {effectiveTreeCount.toLocaleString()} Trees • {harvestsPerYear} Flushes/Yr
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  <div className="bg-slate-800/80 p-2.5 rounded-lg border border-slate-700">
                    <span className="text-[9px] text-slate-400 uppercase font-bold block">Net Yield / Tree</span>
                    <span className="text-sm font-black font-mono text-white">
                      {Math.round(annualNetFruitsPerTree).toLocaleString()} {harvestUnitName}s
                    </span>
                    <span className="text-[8.5px] text-slate-400 block mt-0.5">({annualNetYieldKgPerTree.toFixed(1)} Kg/tree)</span>
                  </div>

                  <div className="bg-slate-800/80 p-2.5 rounded-lg border border-slate-700">
                    <span className="text-[9px] text-slate-400 uppercase font-bold block">Losses Factored</span>
                    <span className="text-sm font-black font-mono text-rose-400">
                      -{possibleLossesPct}%
                    </span>
                    <span className="text-[8.5px] text-slate-400 block mt-0.5">({Math.round(annualGrossFruitsPerTree - annualNetFruitsPerTree)} {harvestUnitName}s drop)</span>
                  </div>

                  <div className="bg-slate-800/80 p-2.5 rounded-lg border border-slate-700">
                    <span className="text-[9px] text-slate-400 uppercase font-bold block">Annual Block Units</span>
                    <span className="text-sm font-black font-mono text-emerald-400">
                      {totalAnnualBlockFruits.toLocaleString()}
                    </span>
                    <span className="text-[8.5px] text-slate-400 block mt-0.5">Total sellable fruits</span>
                  </div>

                  <div className="bg-slate-800/80 p-2.5 rounded-lg border border-slate-700">
                    <span className="text-[9px] text-slate-400 uppercase font-bold block">Annual Block Weight</span>
                    <span className="text-sm font-black font-mono text-emerald-400">
                      {totalAnnualBlockKg.toLocaleString()} Kg
                    </span>
                    <span className="text-[8.5px] text-slate-400 block mt-0.5">({(totalAnnualBlockKg / 1000).toFixed(1)} Tonnes)</span>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* STEP 4: Revenue Projections & Pricing */}
          {activeStep === 4 && (
            <div className="space-y-5 animate-in fade-in duration-150">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Pricing Model Card */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                      <DollarSign className="w-4 h-4 text-emerald-600" />
                      <span>Fruit Pricing Model</span>
                    </h4>

                    <div className="flex bg-slate-200 p-0.5 rounded-lg text-[10px] font-bold">
                      <button
                        type="button"
                        onClick={() => setPricingMode("Flat")}
                        className={`px-2.5 py-1 rounded-md transition-all ${pricingMode === "Flat" ? "bg-white shadow-xs text-slate-900 font-black" : "text-slate-600"}`}
                      >
                        Flat Price
                      </button>
                      <button
                        type="button"
                        onClick={() => setPricingMode("Grade")}
                        className={`px-2.5 py-1 rounded-md transition-all ${pricingMode === "Grade" ? "bg-white shadow-xs text-slate-900 font-black" : "text-slate-600"}`}
                      >
                        Grade Tiers
                      </button>
                    </div>
                  </div>

                  {pricingMode === "Flat" ? (
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                        Flat Price Per {measuredIn === "Units" ? harvestUnitName : "Kg"} ({currencySymbol}) *
                      </label>
                      <div className="relative">
                        <input 
                          type="number" 
                          min="0.1" 
                          step="0.5" 
                          value={pricePerUnitOrKg} 
                          onChange={e => setPricePerUnitOrKg(Math.max(0.1, Number(e.target.value)))}
                          className="w-full bg-white border border-slate-200 rounded-xl p-2.5 font-mono font-black text-slate-900 text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
                        />
                        <span className="absolute right-3 top-2.5 font-mono font-bold text-slate-400 text-xs">
                          {currencySymbol} / {measuredIn === "Units" ? harvestUnitName : "Kg"}
                        </span>
                      </div>
                      <span className="text-[9.5px] text-slate-400 block mt-1">
                        Uniform market price applied across all harvested volumes.
                      </span>
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      <span className="text-[10px] font-black uppercase text-slate-500 block">
                        Multi-Tier Grading Distribution
                      </span>

                      {/* Tier A */}
                      <div className="p-2 bg-white border border-slate-200 rounded-lg flex items-center justify-between text-xs">
                        <div>
                          <span className="font-bold text-slate-800 block">Grade A (Premium / Export)</span>
                          <span className="text-[9px] text-slate-400">Large, blemish-free fruit</span>
                        </div>
                        <div className="flex items-center gap-1.5 font-mono text-xs">
                          <input 
                            type="number" 
                            value={tierA_Pct} 
                            onChange={e => setTierA_Pct(Number(e.target.value))}
                            className="w-12 border rounded p-1 text-center font-bold" 
                          />
                          <span className="text-slate-400">% @</span>
                          <input 
                            type="number" 
                            value={tierA_Price} 
                            onChange={e => setTierA_Price(Number(e.target.value))}
                            className="w-20 border rounded p-1 font-mono font-bold text-xs" 
                          />
                          <span className="text-slate-500 font-mono">{currencySymbol}</span>
                        </div>
                      </div>

                      {/* Tier B */}
                      <div className="p-2 bg-white border border-slate-200 rounded-lg flex items-center justify-between text-xs">
                        <div>
                          <span className="font-bold text-slate-800 block">Grade B (Wholesale / Supermarket)</span>
                          <span className="text-[9px] text-slate-400">Standard medium fruit</span>
                        </div>
                        <div className="flex items-center gap-1.5 font-mono text-xs">
                          <input 
                            type="number" 
                            value={tierB_Pct} 
                            onChange={e => setTierB_Pct(Number(e.target.value))}
                            className="w-12 border rounded p-1 text-center font-bold" 
                          />
                          <span className="text-slate-400">% @</span>
                          <input 
                            type="number" 
                            value={tierB_Price} 
                            onChange={e => setTierB_Price(Number(e.target.value))}
                            className="w-20 border rounded p-1 font-mono font-bold text-xs" 
                          />
                          <span className="text-slate-500 font-mono">{currencySymbol}</span>
                        </div>
                      </div>

                      {/* Tier C */}
                      <div className="p-2 bg-white border border-slate-200 rounded-lg flex items-center justify-between text-xs">
                        <div>
                          <span className="font-bold text-slate-800 block">Grade C (Processing / Seconds)</span>
                          <span className="text-[9px] text-slate-400">Juicing, pulp & local retail</span>
                        </div>
                        <div className="flex items-center gap-1.5 font-mono text-xs">
                          <input 
                            type="number" 
                            value={tierC_Pct} 
                            onChange={e => setTierC_Pct(Number(e.target.value))}
                            className="w-12 border rounded p-1 text-center font-bold" 
                          />
                          <span className="text-slate-400">% @</span>
                          <input 
                            type="number" 
                            value={tierC_Price} 
                            onChange={e => setTierC_Price(Number(e.target.value))}
                            className="w-20 border rounded p-1 font-mono font-bold text-xs" 
                          />
                          <span className="text-slate-500 font-mono">{currencySymbol}</span>
                        </div>
                      </div>
                    </div>
                  )}

                </div>

                {/* Revenue Outcomes Display */}
                <div className="p-4 bg-emerald-700 text-white rounded-xl shadow-md flex flex-col justify-between space-y-4">
                  <div>
                    <div className="flex justify-between items-center border-b border-emerald-600/60 pb-2">
                      <span className="text-[10px] font-black uppercase tracking-widest text-emerald-200 font-mono">
                        Revenue Target Projection
                      </span>
                      <span className="px-2 py-0.5 bg-emerald-800 text-emerald-100 rounded text-[9px] font-bold font-mono">
                        Effective: {currencySymbol}{effectivePrice.toFixed(2)} / {measuredIn === "Units" ? harvestUnitName : "Kg"}
                      </span>
                    </div>

                    <div className="mt-4 space-y-1">
                      <span className="text-[10px] uppercase font-bold text-emerald-200 block tracking-wider">
                        Projected Annual Gross Revenue (At Full Maturity)
                      </span>
                      <div className="text-3xl font-black font-mono tracking-tight text-white">
                        {currencySymbol}{Math.round(projectedPeakAnnualRevenue).toLocaleString()}
                      </div>
                      <span className="text-[10px] text-emerald-200 block">
                        Net output from {effectiveTreeCount.toLocaleString()} trees on {blockAreaHa} Hectare(s)
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-3 border-t border-emerald-600/60 text-xs">
                    <div className="bg-emerald-800/80 p-2 rounded-lg">
                      <span className="text-[9px] uppercase font-bold text-emerald-200 block">Per Hectare Target</span>
                      <span className="font-mono font-black text-white text-sm">
                        {currencySymbol}{Math.round(projectedRevenuePerHa).toLocaleString()} / Ha
                      </span>
                    </div>

                    <div className="bg-emerald-800/80 p-2 rounded-lg">
                      <span className="text-[9px] uppercase font-bold text-emerald-200 block">Per Tree Yield Value</span>
                      <span className="font-mono font-black text-white text-sm">
                        {currencySymbol}{Math.round(projectedRevenuePerTree).toLocaleString()} / Tree
                      </span>
                    </div>
                  </div>

                  <div className="p-2.5 bg-emerald-900/90 rounded-lg text-center border border-emerald-600/40">
                    <span className="text-[9px] uppercase font-bold text-emerald-300 block">
                      Lifetime Cumulative Revenue ({treeLifespanYears} Years Lifespan)
                    </span>
                    <span className="text-lg font-black font-mono text-emerald-100">
                      {currencySymbol}{Math.round(lifetimeProjectedRevenue).toLocaleString()}
                    </span>
                  </div>

                </div>

              </div>

            </div>
          )}

          {/* STEP 5: Multi-Year Harvest Schedule with Editable Projections & Proper Alignment */}
          {activeStep === 5 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              
              <div className="p-4 bg-slate-900 text-white rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-black uppercase tracking-wider text-emerald-400 font-mono">
                      Multi-Year Production Timeline & Bearing Curve
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="text-slate-300">
                      Edit bearing curve %, projected yield, or price for any year.
                    </span>
                    <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded text-[10px] font-mono font-bold">
                      🎯 1st Harvest: {actualFirstHarvestDate} ({maturityDays}d)
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[9px] uppercase font-bold text-slate-400 block">Total Lifetime Projection</span>
                  <span className="text-lg font-black font-mono text-emerald-400">
                    {currencySymbol}{Math.round(lifetimeProjectedRevenue).toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Multi-Year Table with Exact Column Alignment and Inline Inputs */}
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs max-h-80 overflow-y-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-slate-100 text-[10px] text-slate-600 uppercase font-black tracking-wider border-b border-slate-200 sticky top-0 z-10">
                    <tr>
                      <th className="p-3 text-left w-16">Year</th>
                      <th className="p-3 text-left w-36">Target Date</th>
                      <th className="p-3 text-left w-36">Production Stage</th>
                      <th className="p-3 text-center w-28">Bearing %</th>
                      <th className="p-3 text-right w-36">Projected Yield (Kg)</th>
                      <th className="p-3 text-right w-32">Unit Price ({currencySymbol})</th>
                      <th className="p-3 text-right w-36">Projected Revenue</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {multiYearSchedule.map((yr) => {
                      const override = scheduleOverrides[yr.yearNumber] || {};
                      return (
                        <tr key={yr.yearNumber} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-3 font-mono font-bold text-slate-900 text-left">
                            Year {yr.yearNumber}
                          </td>
                          <td className="p-3 font-mono text-slate-600 text-left">
                            <span className="font-semibold block">{yr.calendarYear}</span>
                            <span className="text-[10px] text-slate-400">{yr.expectedHarvestDate}</span>
                          </td>
                          <td className="p-3 text-left">
                            <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${
                              yr.lifecycleStage === "Peak Production"
                                ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                                : yr.lifecycleStage === "Moderate Production"
                                  ? "bg-blue-50 text-blue-700 border-blue-200"
                                  : yr.lifecycleStage === "First Bearing"
                                    ? "bg-amber-50 text-amber-700 border-amber-200"
                                    : yr.lifecycleStage === "Declining"
                                      ? "bg-rose-50 text-rose-700 border-rose-200"
                                      : "bg-slate-100 text-slate-500 border-slate-200"
                            }`}>
                              {yr.lifecycleStage}
                            </span>
                          </td>
                          
                          {/* Editable Yield Multiplier % */}
                          <td className="p-3 text-center">
                            <div className="flex items-center justify-center gap-1">
                              <input 
                                type="number"
                                min="0"
                                max="150"
                                step="5"
                                value={yr.yieldMultiplierPct}
                                onChange={e => handleScheduleEdit(yr.yearNumber, "yieldMultiplierPct", Number(e.target.value))}
                                className="w-14 bg-white border border-slate-300 rounded p-1 font-mono font-bold text-xs text-center focus:ring-1 focus:ring-emerald-500 outline-none"
                              />
                              <span className="text-slate-400 font-bold">%</span>
                            </div>
                          </td>

                          {/* Editable Projected Yield (Kg) */}
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <input 
                                type="number"
                                min="0"
                                step="10"
                                value={yr.projectedYieldKg}
                                onChange={e => handleScheduleEdit(yr.yearNumber, "projectedYieldKg", Number(e.target.value))}
                                className="w-24 bg-white border border-slate-300 rounded p-1 font-mono font-bold text-xs text-right focus:ring-1 focus:ring-emerald-500 outline-none"
                              />
                              <span className="text-slate-400 font-mono text-[10px]">kg</span>
                            </div>
                          </td>

                          {/* Editable Price per Unit */}
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <span className="text-slate-400 font-mono text-[10px]">{currencySymbol}</span>
                              <input 
                                type="number"
                                min="0.1"
                                step="0.5"
                                value={override.pricePerUnitOrKg !== undefined ? override.pricePerUnitOrKg : effectivePrice}
                                onChange={e => handleScheduleEdit(yr.yearNumber, "pricePerUnitOrKg", Number(e.target.value))}
                                className="w-16 bg-white border border-slate-300 rounded p-1 font-mono font-bold text-xs text-right focus:ring-1 focus:ring-emerald-500 outline-none"
                              />
                            </div>
                          </td>

                          {/* Auto-Adjusted Projected Revenue */}
                          <td className="p-3 text-right font-mono font-black text-emerald-600 text-sm">
                            {currencySymbol}{(yr.projectedRevenue || 0).toLocaleString()}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Confirmation Box */}
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-emerald-950 text-xs">Ready to Establish "{blockName}"?</h4>
                  <p className="text-[11px] text-emerald-800 mt-0.5">
                    This block will be registered in the Orchard system and its {effectiveTreeCount.toLocaleString()} trees will be automatically registered in the Tree Inventory.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleEstablishBlock}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase rounded-xl transition-all shadow-md active:scale-95 flex items-center gap-2 cursor-pointer"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Establish Orchard Block</span>
                </button>
              </div>

            </div>
          )}

        </div>

        {/* Wizard Footer Navigation */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-between items-center shrink-0">
          <button
            type="button"
            onClick={() => {
              if (activeStep > 1) setActiveStep((activeStep - 1) as any);
              else onClose();
            }}
            className="px-4 py-2 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
          >
            {activeStep === 1 ? "Cancel" : "← Back"}
          </button>

          <div className="flex gap-2">
            {activeStep < 5 ? (
              <button
                type="button"
                onClick={() => setActiveStep((activeStep + 1) as any)}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <span>Continue to Step {activeStep + 1}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleEstablishBlock}
                className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase rounded-xl transition-all shadow-md active:scale-95 flex items-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Establish Orchard Block</span>
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}

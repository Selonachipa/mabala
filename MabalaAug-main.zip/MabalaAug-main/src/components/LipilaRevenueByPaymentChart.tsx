import React, { useState } from "react";
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Tooltip, 
  Legend, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid 
} from "recharts";
import { Smartphone, Building, ShieldCheck, DollarSign, ArrowUpRight, Filter, PieChart as PieIcon, BarChart2 } from "lucide-react";
import { INITIAL_LIPILA_TRANSACTIONS, LipilaTransaction } from "../data/mockLipilaTransactions";

interface LipilaRevenueByPaymentChartProps {
  lipilaTransactions?: LipilaTransaction[];
  currencySymbol?: string;
}

export default function LipilaRevenueByPaymentChart({
  lipilaTransactions = [],
  currencySymbol = "ZK"
}: LipilaRevenueByPaymentChartProps) {
  const [chartView, setChartView] = useState<"pie" | "bar" | "both">("both");

  const txs = lipilaTransactions.length > 0 ? lipilaTransactions : INITIAL_LIPILA_TRANSACTIONS;

  // Filter only successful or settled payments for revenue calculation
  const successfulTxs = txs.filter(t => t.status === "Successful" || (t.status as string) === "Settled");

  // Breakdown metrics calculation
  let airtelTotal = 0, airtelCount = 0;
  let mtnTotal = 0, mtnCount = 0;
  let zamtelTotal = 0, zamtelCount = 0;
  let bankTotal = 0, bankCount = 0;
  let cardTotal = 0, cardCount = 0;

  successfulTxs.forEach((tx) => {
    const amt = tx.amount || 0;
    const provider = (tx.provider || "").toLowerCase();
    const pType = (tx.paymentType || "").toLowerCase();

    if (provider.includes("airtel") || provider.includes("airtel money")) {
      airtelTotal += amt;
      airtelCount++;
    } else if (provider.includes("mtn") || provider.includes("momo")) {
      mtnTotal += amt;
      mtnCount++;
    } else if (provider.includes("zamtel")) {
      zamtelTotal += amt;
      zamtelCount++;
    } else if (pType === "bank" || provider.includes("bank") || provider.includes("zanaco") || provider.includes("absa") || provider.includes("stanbic")) {
      bankTotal += amt;
      bankCount++;
    } else {
      cardTotal += amt;
      cardCount++;
    }
  });

  const totalMobileMoney = airtelTotal + mtnTotal + zamtelTotal;
  const countMobileMoney = airtelCount + mtnCount + zamtelCount;

  const grandTotal = totalMobileMoney + bankTotal + cardTotal;

  // Donut chart dataset
  const donutData = [
    { name: "Airtel Money", value: airtelTotal, count: airtelCount, color: "#dc2626", provider: "Mobile Money" },
    { name: "MTN MoMo", value: mtnTotal, count: mtnCount, color: "#f59e0b", provider: "Mobile Money" },
    { name: "Zamtel Kwacha", value: zamtelTotal, count: zamtelCount, color: "#10b981", provider: "Mobile Money" },
    { name: "Bank Transfers", value: bankTotal, count: bankCount, color: "#4f46e5", provider: "Bank Direct" },
    { name: "Card / Visa", value: cardTotal, count: cardCount, color: "#8b5cf6", provider: "Card Gateway" },
  ].filter(d => d.value > 0);

  // High-level comparison dataset (Mobile Money vs Bank Transfers)
  const comparisonData = [
    {
      category: "Mobile Money (Airtel, MTN, Zamtel)",
      Revenue: totalMobileMoney,
      Transactions: countMobileMoney,
      color: "#10b981"
    },
    {
      category: "Traditional Bank Transfers",
      Revenue: bankTotal,
      Transactions: bankCount,
      color: "#4f46e5"
    },
    {
      category: "Card / Digital Gateway",
      Revenue: cardTotal,
      Transactions: cardCount,
      color: "#8b5cf6"
    }
  ];

  const mobileMoneyShare = grandTotal > 0 ? Math.round((totalMobileMoney / grandTotal) * 100) : 0;
  const bankShare = grandTotal > 0 ? Math.round((bankTotal / grandTotal) * 100) : 0;

  const CustomPieTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      const pct = grandTotal > 0 ? ((data.value / grandTotal) * 100).toFixed(1) : "0";
      return (
        <div className="bg-slate-900 border border-slate-700 p-3 rounded-xl shadow-xl text-xs text-white space-y-1">
          <p className="font-extrabold text-indigo-300 flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: data.color }} />
            {data.name} ({data.provider})
          </p>
          <p className="font-mono text-sm font-black text-emerald-400">
            {currencySymbol} {data.value.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </p>
          <p className="text-[10px] text-slate-400">
            {data.count} successful transactions ({pct}% of total revenue)
          </p>
        </div>
      );
    };
    return null;
  };

  const CustomBarTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 border border-slate-700 p-3 rounded-xl shadow-xl text-xs text-white space-y-1">
          <p className="font-extrabold text-indigo-300">{data.category}</p>
          <p className="font-mono text-sm font-black text-emerald-400">
            {currencySymbol} {data.Revenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </p>
          <p className="text-[10px] text-slate-400">
            {data.Transactions} completed payment intents
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-indigo-600" />
            Revenue by Payment Method (Mobile Money vs Traditional Bank Transfers)
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Lipila checkout gateway revenue distribution across Airtel, MTN, Zamtel MoMo, and direct bank transfers.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold">
            <button
              type="button"
              onClick={() => setChartView("both")}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${chartView === "both" ? "bg-white text-indigo-700 shadow-xs" : "text-slate-500 hover:text-slate-800"}`}
            >
              Combined View
            </button>
            <button
              type="button"
              onClick={() => setChartView("pie")}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${chartView === "pie" ? "bg-white text-indigo-700 shadow-xs" : "text-slate-500 hover:text-slate-800"}`}
            >
              Share Donut
            </button>
            <button
              type="button"
              onClick={() => setChartView("bar")}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${chartView === "bar" ? "bg-white text-indigo-700 shadow-xs" : "text-slate-500 hover:text-slate-800"}`}
            >
              Volume Bar Chart
            </button>
          </div>
        </div>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-100 space-y-1">
          <span className="text-[10px] uppercase font-extrabold tracking-wider text-emerald-800 block">
            Mobile Money Total (Airtel / MTN / Zamtel)
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-xl font-black font-mono text-emerald-950">
              {currencySymbol} {totalMobileMoney.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
            <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded-full">
              {mobileMoneyShare}% Share
            </span>
          </div>
          <span className="text-[10.5px] text-emerald-700 font-semibold block pt-0.5">
            {countMobileMoney} instant mobile wallet settlements
          </span>
        </div>

        <div className="bg-indigo-50/60 p-4 rounded-2xl border border-indigo-100 space-y-1">
          <span className="text-[10px] uppercase font-extrabold tracking-wider text-indigo-800 block">
            Traditional Bank Transfers (ZANACO, Absa, etc.)
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-xl font-black font-mono text-indigo-950">
              {currencySymbol} {bankTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
            <span className="px-2 py-0.5 bg-indigo-600 text-white text-[10px] font-bold rounded-full">
              {bankShare}% Share
            </span>
          </div>
          <span className="text-[10.5px] text-indigo-700 font-semibold block pt-0.5">
            {bankCount} direct bank settlement transfers
          </span>
        </div>

        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 text-white space-y-1">
          <span className="text-[10px] uppercase font-extrabold tracking-wider text-indigo-300 block">
            Lipila Gross Settled Revenue
          </span>
          <div className="text-2xl font-black font-mono text-emerald-400">
            {currencySymbol} {grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <span className="text-[10.5px] text-slate-400 font-mono block">
            Across {successfulTxs.length} verified checkout sessions
          </span>
        </div>
      </div>

      {/* Visual Charts Grid */}
      <div className={`grid grid-cols-1 ${chartView === "both" ? "lg:grid-cols-2" : "grid-cols-1"} gap-6 items-center`}>
        {/* DONUT / PIE CHART */}
        {(chartView === "both" || chartView === "pie") && (
          <div className="bg-slate-50/70 p-5 rounded-2xl border border-slate-200/80 space-y-3">
            <div className="flex justify-between items-center">
              <h4 className="text-xs font-black uppercase text-slate-800 tracking-wider flex items-center gap-1.5">
                <PieIcon className="w-4 h-4 text-indigo-600" />
                <span>Provider Distribution Split</span>
              </h4>
              <span className="text-[10px] font-mono font-bold text-slate-500 bg-white px-2 py-0.5 rounded border">
                Lipila Multi-Channel
              </span>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={donutData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {donutData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="#ffffff" strokeWidth={2} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomPieTooltip />} />
                  <Legend 
                    verticalAlign="bottom" 
                    height={36} 
                    iconType="circle"
                    formatter={(value) => <span className="text-[11px] font-bold text-slate-700">{value}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* BAR CHART: MOBILE MONEY vs BANK TRANSFERS */}
        {(chartView === "both" || chartView === "bar") && (
          <div className="bg-slate-50/70 p-5 rounded-2xl border border-slate-200/80 space-y-3">
            <div className="flex justify-between items-center">
              <h4 className="text-xs font-black uppercase text-slate-800 tracking-wider flex items-center gap-1.5">
                <BarChart2 className="w-4 h-4 text-emerald-600" />
                <span>Mobile Money vs Bank Transfer Volume</span>
              </h4>
              <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Recharts Visual comparison
              </span>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={comparisonData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis 
                    dataKey="category" 
                    tick={{ fontSize: 10, fill: "#64748b", fontWeight: 700 }}
                    axisLine={{ stroke: "#cbd5e1" }}
                  />
                  <YAxis 
                    tick={{ fontSize: 10, fill: "#64748b" }}
                    axisLine={{ stroke: "#cbd5e1" }}
                    tickFormatter={(val) => `${val >= 1000 ? `${(val/1000).toFixed(0)}k` : val}`}
                  />
                  <Tooltip content={<CustomBarTooltip />} />
                  <Bar dataKey="Revenue" radius={[8, 8, 0, 0]}>
                    {comparisonData.map((entry, index) => (
                      <Cell key={`bar-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

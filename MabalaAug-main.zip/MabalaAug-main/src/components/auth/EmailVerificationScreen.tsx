import React from "react";

interface EmailVerificationScreenProps {
  verificationEmailSentTo?: string;
  onProceedBypass: () => void;
  onBackToLogin: () => void;
  onResendInstructions: () => void;
}

export const EmailVerificationScreen: React.FC<EmailVerificationScreenProps> = ({
  verificationEmailSentTo,
  onProceedBypass,
  onBackToLogin,
  onResendInstructions,
}) => {
  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 text-white rounded-3xl shadow-xl overflow-hidden text-center p-8 space-y-6">
        <div className="mx-auto w-16 h-16 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full flex items-center justify-center mb-2">
          <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 19v-8.93a2 2 0 01.89-1.664l8-5.333a2 2 0 012.22 0l8 5.333A2 2 0 0121 10.07V19M3 19a2 2 0 002 2h14a2 2 0 002-2M3 19l6.75-4.5M21 19l-6.75-4.5M3 10l6.75 4.5M21 10l-6.75 4.5m0 0l-2.25-1.5a2 2 0 00-2.22 0l-2.25 1.5" />
          </svg>
        </div>
        
        <div className="space-y-2">
          <h2 className="text-xl font-bold tracking-tight text-white">Verify Your Email Address</h2>
          <p className="text-slate-400 font-normal text-xs leading-relaxed">
            We have dispatched a security verification email to:
            <br />
            <strong className="text-emerald-400 text-xs font-mono bg-slate-950 px-2 py-0.5 rounded shadow-sm mt-1.5 inline-block">{verificationEmailSentTo || "your registered email"}</strong>
          </p>
        </div>

        <div className="bg-amber-500/5 border border-amber-500/10 rounded-xl p-4 text-left">
          <div className="flex gap-2 items-start">
            <span className="text-amber-500 text-sm mt-0.5">⚠️</span>
            <p className="text-amber-200 font-bold text-xs">Mabala Security Verification Mandate:</p>
          </div>
          <p className="text-amber-300 text-[11px] leading-relaxed mt-1 font-medium pl-6 opacity-80">
            To satisfy IFRS financial security standards, access is locked until the verification link is clicked. Please inspect your Inbox (and your Spam folder).
          </p>
        </div>

        <div className="pt-2 space-y-3">
          <button
            type="button"
            onClick={onProceedBypass}
            className="w-full py-2.5 px-4 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-amber-600/10 cursor-pointer flex items-center justify-center gap-2"
          >
            <span>Proceed & Bypass Email Verification</span>
          </button>
          <button
            type="button"
            onClick={onBackToLogin}
            className="w-full py-2 px-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
          >
            <span>Back to Sign In Login page</span>
          </button>
          <button
            type="button"
            onClick={onResendInstructions}
            className="w-full py-2 px-4 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 rounded-xl text-xs font-normal transition-colors cursor-pointer"
          >
            <span>Didn't receive? Resend instructions</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default EmailVerificationScreen;

import React, { useState, useMemo, useEffect } from "react";
import {
  BarChart3,
  DollarSign,
  Package,
  Store,
  MapPin,
  AlertTriangle,
  TrendingUp,
  Filter,
  Calendar,
  Layers,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  RefreshCw,
  ShoppingBag,
  Info
} from "lucide-react";
import { AgroDealerSKU, AgroDealerTenant, StockMovement } from "../types";
import { INITIAL_AGRO_SKUS, INITIAL_AGRO_DEALERS, INITIAL_STOCK_MOVEMENTS } from "../data/agroDealerData";
import { LipilaTransaction, INITIAL_LIPILA_TRANSACTIONS } from "../data/mockLipilaTransactions";
import { MarketplaceOrder } from "../data/marketplaceData";
import { safeLocalStorage as localStorage } from "../utils/safeStorage";
import { collection, onSnapshot, doc, getDoc } from "firebase/firestore";
import { db } from "../firebase";

// Standard Zambian Provinces & Districts dataset
export const ZAMBIAN_PROVINCES = [
  "Southern Province",
  "Central Province",
  "Eastern Province",
  "Copperbelt Province",
  "Lusaka Province",
  "Northern Province",
  "Luapula Province",
  "Muchinga Province",
  "North-Western Province",
  "Western Province"
];

interface MarketAnalyticsPanelProps {
  currencySymbol?: string;
  commissionPercent?: number;
}

export default function MarketAnalyticsPanel({
  currencySymbol = "ZMW",
  commissionPercent = 2.5
}: MarketAnalyticsPanelProps) {
  const [hasError, setHasError] = useState(false);
  const [dateRange, setDateRange] = useState<"ALL" | "LAST_7_DAYS" | "LAST_30_DAYS" | "YTD">("ALL");
  const [selectedProvince, setSelectedProvince] = useState<string>("ALL");
  const [selectedCategory, setSelectedCategory] = useState<string>("ALL");

  // Primary Data Sources
  const [skus, setSkus] = useState<AgroDealerSKU[]>([]);
  const [dealers, setDealers] = useState<AgroDealerTenant[]>([]);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [lipilaTxs, setLipilaTxs] = useState<LipilaTransaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load shared data from localStorage & Firestore
  useEffect(() => {
    try {
      // 1. Local Storage fallback initialization
      const savedSkus = localStorage.getItem("mabala_agd_skus");
      const localSkus = savedSkus ? JSON.parse(savedSkus) : INITIAL_AGRO_SKUS;

      const savedDealers = localStorage.getItem("mabala_agd_dealers");
      const localDealers = savedDealers ? JSON.parse(savedDealers) : INITIAL_AGRO_DEALERS;

      const savedMovements = localStorage.getItem("mabala_agd_movements");
      const localMovements = savedMovements ? JSON.parse(savedMovements) : INITIAL_STOCK_MOVEMENTS;

      setSkus(localSkus);
      setDealers(localDealers);
      setMovements(localMovements);
      setLipilaTxs(INITIAL_LIPILA_TRANSACTIONS);
      setIsLoading(false);

      // 2. Sync with Firestore if connected
      if (db) {
        const unsubLipila = onSnapshot(
          collection(db, "superAdmin", "lipilaTransactions", "records"),
          (snapshot) => {
            if (!snapshot.empty) {
              const txs = snapshot.docs.map(d => d.data() as LipilaTransaction);
              setLipilaTxs(txs);
            }
          },
          (err) => console.warn("[MarketAnalytics] Firestore Lipila listener note:", err)
        );

        return () => {
          unsubLipila();
        };
      }
    } catch (err) {
      console.error("[MarketAnalytics] Initialization error:", err);
      setHasError(true);
      setIsLoading(false);
    }
  }, []);

  // Filter Lipila AGD/SUPPLY transactions & movements by selected date range
  const filteredTxs = useMemo(() => {
    const now = new Date();
    return lipilaTxs.filter((tx) => {
      if (tx.status !== "Successful") return false;
      const isAgdOrSupply =
        tx.module === "AGD" ||
        tx.module === "SUPPLY" ||
        tx.referenceId.startsWith("AGD-") ||
        tx.referenceId.startsWith("SUPPLY-");

      if (!isAgdOrSupply) return false;

      const txDate = new Date(tx.createdAt);
      if (dateRange === "LAST_7_DAYS") {
        const cutoff = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return txDate >= cutoff;
      }
      if (dateRange === "LAST_30_DAYS") {
        const cutoff = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        return txDate >= cutoff;
      }
      if (dateRange === "YTD") {
        const startOfYear = new Date(now.getFullYear(), 0, 1);
        return txDate >= startOfYear;
      }
      return true;
    });
  }, [lipilaTxs, dateRange]);

  // Combined Aggregation Pipeline
  const analyticsData = useMemo(() => {
    // Active SKUs (qtyOnHand > 0 && sellingPrice > 0)
    const activeListings = skus.filter((s) => s.qtyOnHand > 0 && s.sellingPrice > 0);

    // Filter SKUs by province if selected
    const filteredSkus = skus.filter((s) => {
      const dealer = dealers.find((d) => d.id === s.tenantId);
      const provMatch = selectedProvince === "ALL" || (dealer && dealer.province === selectedProvince);
      const catMatch = selectedCategory === "ALL" || s.category.toLowerCase() === selectedCategory.toLowerCase();
      return provMatch && catMatch;
    });

    // Total AGD/SUPPLY GMV from Lipila
    const totalAgdGmv = filteredTxs.reduce((sum, tx) => sum + (tx.amount || 0), 0);

    // Additional GMV calculated from movements (sale type)
    const movementSalesGmv = movements
      .filter((m) => m.type === "sale")
      .reduce((sum, m) => {
        const sku = skus.find((s) => s.id === m.skuId);
        const unitPrice = sku ? sku.sellingPrice : 0;
        return sum + Math.abs(m.qtyDelta) * unitPrice;
      }, 0);

    const totalMarketGmv = Math.max(totalAgdGmv, movementSalesGmv);

    // Stock-Out & Low-Stock Incidence (Supply Gap Engine)
    const stockOutItems = filteredSkus.filter((s) => s.qtyOnHand === 0);
    const lowStockItems = filteredSkus.filter((s) => s.qtyOnHand > 0 && s.qtyOnHand <= (s.reorderLevel ?? s.reorderThreshold ?? 10));

    // Category Breakdown
    const categoryMap = new Map<string, { count: number; gmv: number; stockOuts: number }>();
    filteredSkus.forEach((sku) => {
      const cat = sku.category || "General";
      const existing = categoryMap.get(cat) || { count: 0, gmv: 0, stockOuts: 0 };
      const skuGmv = sku.qtySold * sku.sellingPrice;
      categoryMap.set(cat, {
        count: existing.count + 1,
        gmv: existing.gmv + skuGmv,
        stockOuts: existing.stockOuts + (sku.qtyOnHand === 0 ? 1 : 0)
      });
    });

    // Province Breakdown
    const provinceMap = new Map<string, { dealerCount: number; skuCount: number; gmv: number; stockOuts: number }>();
    ZAMBIAN_PROVINCES.forEach((prov) => {
      const provDealers = dealers.filter((d) => d.province === prov);
      const provDealerIds = new Set(provDealers.map((d) => d.id));
      const provSkus = skus.filter((s) => provDealerIds.has(s.tenantId));
      const provGmv = provSkus.reduce((sum, s) => sum + s.qtySold * s.sellingPrice, 0);
      const provStockOuts = provSkus.filter((s) => s.qtyOnHand === 0).length;

      provinceMap.set(prov, {
        dealerCount: provDealers.length,
        skuCount: provSkus.length,
        gmv: provGmv,
        stockOuts: provStockOuts
      });
    });

    // Top Performing Products Leaderboard
    const topProducts = [...filteredSkus]
      .map((s) => {
        const dealer = dealers.find((d) => d.id === s.tenantId);
        return {
          ...s,
          dealerName: dealer ? dealer.businessName : "Registered Agro-Dealer",
          province: dealer ? dealer.province : "Southern Province",
          totalRevenue: s.qtySold * s.sellingPrice
        };
      })
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .slice(0, 5);

    // Top Performing Dealers Leaderboard
    const dealerPerformance = dealers
      .map((d) => {
        const dealerSkus = skus.filter((s) => s.tenantId === d.id);
        const totalSalesVolume = dealerSkus.reduce((sum, s) => sum + s.qtySold, 0);
        const totalSalesValue = dealerSkus.reduce((sum, s) => sum + s.qtySold * s.sellingPrice, 0);
        const stockOutCount = dealerSkus.filter((s) => s.qtyOnHand === 0).length;

        return {
          id: d.id,
          name: d.businessName,
          province: d.province,
          city: d.city,
          skuCount: dealerSkus.length,
          totalSalesVolume,
          totalSalesValue,
          stockOutCount,
          status: d.subscriptionStatus
        };
      })
      .sort((a, b) => b.totalSalesValue - a.totalSalesValue);

    return {
      activeListingCount: activeListings.length,
      totalGmv: totalMarketGmv,
      stockOutCount: stockOutItems.length,
      lowStockCount: lowStockItems.length,
      stockOutItems,
      lowStockItems,
      categoryBreakdown: Array.from(categoryMap.entries()),
      provinceBreakdown: Array.from(provinceMap.entries()),
      topProducts,
      dealerPerformance
    };
  }, [skus, dealers, movements, filteredTxs, selectedProvince, selectedCategory]);

  if (hasError) {
    return (
      <div className="bg-rose-50 border border-rose-200 p-8 rounded-3xl text-center max-w-lg mx-auto space-y-3 font-sans">
        <AlertTriangle className="w-10 h-10 text-rose-500 mx-auto" />
        <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider">
          Market Analytics Diagnostics Recovery
        </h3>
        <p className="text-xs text-slate-500">
          The analytics rollup pipeline encountered a non-fatal state sync note. The view has auto-reset to cached local telemetry.
        </p>
        <button
          onClick={() => {
            setHasError(false);
            window.location.reload();
          }}
          className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-all cursor-pointer"
        >
          Re-initialize Pipeline
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6 animate-fade-in text-slate-900 font-sans">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-sky-100 text-sky-700 rounded-xl">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Platform-Wide Market & Supply Analytics
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Unified cross-tenant aggregation for GMV, Zambian regional trade distribution, top merchant leaderboards & supply gaps.
              </p>
            </div>
          </div>
        </div>

        {/* Global Date & Regional Filters */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-700">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value as any)}
              className="bg-transparent focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Time</option>
              <option value="LAST_7_DAYS">Last 7 Days</option>
              <option value="LAST_30_DAYS">Last 30 Days</option>
              <option value="YTD">Year to Date (YTD)</option>
            </select>
          </div>

          <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-700">
            <MapPin className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedProvince}
              onChange={(e) => setSelectedProvince(e.target.value)}
              className="bg-transparent focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Zambian Provinces</option>
              {ZAMBIAN_PROVINCES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Active Listings */}
        <div className="bg-gradient-to-br from-indigo-50/80 to-indigo-100/40 p-5 rounded-2xl border border-indigo-100 flex items-center gap-4">
          <div className="p-3.5 bg-indigo-600 rounded-2xl text-white shadow-md">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-indigo-950 font-black uppercase tracking-wider block font-mono">
              Active Listed SKUs
            </span>
            <strong className="text-2xl font-black font-mono text-slate-900">
              {analyticsData.activeListingCount}
            </strong>
            <span className="text-[9.5px] text-indigo-700 block font-semibold mt-0.5">
              Auto-synced from {dealers.length} dealers
            </span>
          </div>
        </div>

        {/* Card 2: Total GMV */}
        <div className="bg-gradient-to-br from-emerald-50/80 to-emerald-100/40 p-5 rounded-2xl border border-emerald-100 flex items-center gap-4">
          <div className="p-3.5 bg-emerald-600 rounded-2xl text-white shadow-md">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-emerald-950 font-black uppercase tracking-wider block font-mono">
              Aggregate Lipila GMV
            </span>
            <strong className="text-2xl font-black font-mono text-slate-900">
              {currencySymbol} {analyticsData.totalGmv.toLocaleString()}
            </strong>
            <span className="text-[9.5px] text-emerald-700 block font-semibold mt-0.5">
              Ref prefixes: AGD & SUPPLY
            </span>
          </div>
        </div>

        {/* Card 3: Stock-Out Incidence (Supply Gap) */}
        <div className="bg-gradient-to-br from-rose-50/80 to-rose-100/40 p-5 rounded-2xl border border-rose-100 flex items-center gap-4">
          <div className="p-3.5 bg-rose-600 rounded-2xl text-white shadow-md">
            <XCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-rose-950 font-black uppercase tracking-wider block font-mono">
              Stock-Out Supply Gaps
            </span>
            <strong className="text-2xl font-black font-mono text-slate-900">
              {analyticsData.stockOutCount} SKUs
            </strong>
            <span className="text-[9.5px] text-rose-700 block font-semibold mt-0.5">
              {analyticsData.lowStockCount} items at low reorder level
            </span>
          </div>
        </div>

        {/* Card 4: Active Merchants */}
        <div className="bg-gradient-to-br from-amber-50/80 to-amber-100/40 p-5 rounded-2xl border border-amber-100 flex items-center gap-4">
          <div className="p-3.5 bg-amber-600 rounded-2xl text-white shadow-md">
            <Store className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-amber-950 font-black uppercase tracking-wider block font-mono">
              Active Agro-Dealers
            </span>
            <strong className="text-2xl font-black font-mono text-slate-900">
              {dealers.length} Dealers
            </strong>
            <span className="text-[9.5px] text-amber-700 block font-semibold mt-0.5">
              Across {ZAMBIAN_PROVINCES.length} Zambian Provinces
            </span>
          </div>
        </div>
      </div>

      {/* Top Performing Leaderboards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
        {/* Top Products Leaderboard */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
          <div className="flex justify-between items-center">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-600" />
              <span>Top Products by Sales Volume & Value</span>
            </h4>
            <span className="text-[10px] font-mono font-bold text-slate-400">Ranked by GMV</span>
          </div>

          <div className="space-y-2.5">
            {analyticsData.topProducts.map((p, idx) => (
              <div
                key={p.id}
                className="bg-white p-3 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-800 font-black text-[11px] flex items-center justify-center font-mono">
                    #{idx + 1}
                  </span>
                  <div>
                    <h5 className="font-bold text-slate-900">{p.productName}</h5>
                    <p className="text-[10px] text-slate-400">
                      {p.dealerName} • <span className="text-slate-600">{p.province}</span>
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <strong className="font-mono text-slate-900 block text-xs">
                    {currencySymbol} {p.totalRevenue.toLocaleString()}
                  </strong>
                  <span className="text-[9.5px] font-mono text-emerald-600 font-bold">
                    {p.qtySold} {p.unit} sold
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Dealers Leaderboard */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
          <div className="flex justify-between items-center">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
              <Store className="w-4 h-4 text-emerald-600" />
              <span>Top Agro-Dealers Platform Leaderboard</span>
            </h4>
            <span className="text-[10px] font-mono font-bold text-slate-400">{dealers.length} Onboarded</span>
          </div>

          <div className="space-y-2.5">
            {analyticsData.dealerPerformance.slice(0, 5).map((d, idx) => (
              <div
                key={d.id}
                className="bg-white p-3 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 font-black text-[11px] flex items-center justify-center font-mono">
                    #{idx + 1}
                  </span>
                  <div>
                    <h5 className="font-bold text-slate-900">{d.name}</h5>
                    <p className="text-[10px] text-slate-400">
                      📍 {d.city}, {d.province} • <span className="font-mono text-slate-600">{d.skuCount} SKUs</span>
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <strong className="font-mono text-slate-900 block text-xs">
                    {currencySymbol} {d.totalSalesValue.toLocaleString()}
                  </strong>
                  <span className="text-[9.5px] font-mono text-indigo-600 font-bold">
                    {d.totalSalesVolume} units moved
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Regional & Category Distribution Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
        {/* Provincial Distribution */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
          <div className="flex justify-between items-center">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-sky-600" />
              <span>Zambian Regional Trade Distribution</span>
            </h4>
            <span className="text-[10px] font-bold text-slate-400">10 Provinces</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs bg-white text-slate-800">
              <thead className="bg-slate-50 font-black text-[9px] text-slate-400 uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="p-2.5">Province</th>
                  <th className="p-2.5 text-center">Dealers</th>
                  <th className="p-2.5 text-center">Active SKUs</th>
                  <th className="p-2.5 text-right">Aggregate GMV</th>
                  <th className="p-2.5 text-center">Stock-Outs</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-[11px]">
                {analyticsData.provinceBreakdown.map(([prov, pData]) => (
                  <tr key={prov} className="hover:bg-slate-50/80">
                    <td className="p-2.5 font-bold text-slate-900">{prov}</td>
                    <td className="p-2.5 text-center font-mono">{pData.dealerCount}</td>
                    <td className="p-2.5 text-center font-mono">{pData.skuCount}</td>
                    <td className="p-2.5 text-right font-mono font-bold text-emerald-700">
                      {currencySymbol} {pData.gmv.toLocaleString()}
                    </td>
                    <td className="p-2.5 text-center font-mono">
                      {pData.stockOuts > 0 ? (
                        <span className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 font-black text-[10px]">
                          {pData.stockOuts}
                        </span>
                      ) : (
                        <span className="text-slate-300">0</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Stock-Out & Low-Stock Supply Gap Monitor */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
          <div className="flex justify-between items-center">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>Supply Gap & Stock-Out Incidence Ledger</span>
            </h4>
            <span className="text-[10px] font-mono font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
              {analyticsData.stockOutCount} Gaps Active
            </span>
          </div>

          <div className="space-y-2 max-h-[320px] overflow-y-auto pr-1">
            {analyticsData.stockOutItems.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs bg-slate-50 rounded-xl border border-dashed">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <p className="font-bold">No Critical Supply Gaps Detected</p>
                <p className="text-[10px]">All agro-dealer inventories platform-wide maintain active safety stock.</p>
              </div>
            ) : (
              analyticsData.stockOutItems.map((s) => {
                const dealer = dealers.find((d) => d.id === s.tenantId);
                return (
                  <div
                    key={s.id}
                    className="p-3 bg-rose-50/50 border border-rose-200 rounded-xl flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-1.5 py-0.5 bg-rose-600 text-white font-black text-[9px] rounded font-mono uppercase">
                          Stock Out
                        </span>
                        <h5 className="font-bold text-slate-900">{s.productName}</h5>
                      </div>
                      <p className="text-[10px] text-slate-500 mt-0.5">
                        Dealer: <strong className="text-slate-800">{dealer?.businessName || "Unknown Dealer"}</strong> (📍 {dealer?.city}, {dealer?.province})
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] font-mono text-slate-500 block">
                        Price: ZMW {s.sellingPrice}
                      </span>
                      <span className="text-[9.5px] text-rose-700 font-bold font-mono">
                        Reorder: {s.reorderLevel ?? s.reorderThreshold ?? 10} units
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

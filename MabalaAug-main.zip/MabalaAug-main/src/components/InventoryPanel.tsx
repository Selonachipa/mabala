import React, { useState, useMemo } from "react";
import { InventoryItem } from "../types";
import { useConfirm } from "./ConfirmModal";
import { 
  Package, Plus, Search, Filter, Trash2, Edit, Check, AlertTriangle, 
  Archive, ShieldAlert, CheckCircle2, RefreshCw, Box, Layers, DollarSign,
  Tag, MapPin, ArrowUpDown
} from "lucide-react";

export interface InventoryPanelProps {
  inventory: InventoryItem[];
  setInventory: React.Dispatch<React.SetStateAction<InventoryItem[]>>;
  currencySymbol?: string;
  activeFarm?: any;
  isReadonly?: boolean;
  writeAuditLog?: (action: string, module: string, item: string, details: string) => void;
}

export const SAMPLE_INVENTORY_ITEMS: Omit<InventoryItem, "id">[] = [];

export default function InventoryPanel({
  inventory,
  setInventory,
  currencySymbol = "ZK",
  activeFarm,
  isReadonly = false,
  writeAuditLog
}: InventoryPanelProps) {
  const confirm = useConfirm();
  
  // Selection & Batch Action State
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [batchStatus, setBatchStatus] = useState<"In Stock" | "Low Stock" | "Out of Stock" | "Reserved" | "Archived">("In Stock");
  
  // Filter & Search State
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("All");
  const [statusFilter, setStatusFilter] = useState<string>("All");
  const [showArchived, setShowArchived] = useState(false);

  // Modal State
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: "",
    category: "Fertilizer" as InventoryItem["category"],
    quantity: 50,
    unit: "Bags",
    unitCost: 100,
    storageLocation: "Main Store Room",
    lowStockAlertLevel: 10,
    status: "In Stock" as "In Stock" | "Low Stock" | "Out of Stock" | "Reserved" | "Archived"
  });

  // Filtered Items
  const filteredInventory = useMemo(() => {
    return inventory.filter(item => {
      // Archive check
      if (!showArchived && (item.archived || item.status === "Archived")) {
        return false;
      }
      if (showArchived && !item.archived && item.status !== "Archived") {
        return false;
      }

      // Search query
      const query = searchQuery.toLowerCase();
      const matchesSearch = 
        !query ||
        item.name.toLowerCase().includes(query) ||
        item.id.toLowerCase().includes(query) ||
        item.category.toLowerCase().includes(query) ||
        (item.storageLocation || "").toLowerCase().includes(query);

      // Category filter
      const matchesCategory = categoryFilter === "All" || item.category === categoryFilter;

      // Status filter
      const matchesStatus = statusFilter === "All" || (item.status || "In Stock") === statusFilter;

      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [inventory, searchQuery, categoryFilter, statusFilter, showArchived]);

  // Select All state helper
  const isAllSelected = filteredInventory.length > 0 && filteredInventory.every(item => selectedIds.includes(item.id));

  const handleToggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredInventory.map(i => i.id));
    }
  };

  const handleToggleSelectOne = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  // Batch Operations
  const handleBatchStatusUpdate = async () => {
    if (selectedIds.length === 0) return;
    
    const isArchiving = batchStatus === "Archived";
    const ok = await confirm({
      title: `Batch Update ${selectedIds.length} Item(s)`,
      message: `Are you sure you want to update the status of ${selectedIds.length} selected inventory item(s) to "${batchStatus}"?`,
      confirmText: "Update All",
      cancelText: "Cancel",
      type: isArchiving ? "warning" : "info"
    });

    if (!ok) return;

    setInventory(prev => prev.map(item => {
      if (selectedIds.includes(item.id)) {
        let newQty = item.quantity;
        if (batchStatus === "Out of Stock") newQty = 0;
        return {
          ...item,
          status: batchStatus,
          quantity: newQty,
          archived: isArchiving ? true : item.archived
        };
      }
      return item;
    }));

    if (writeAuditLog) {
      writeAuditLog("BATCH_UPDATE", "Inventory", `${selectedIds.length} items`, `Updated batch status to ${batchStatus}`);
    }

    setSelectedIds([]);
  };

  const handleBatchArchive = async () => {
    if (selectedIds.length === 0) return;

    const ok = await confirm({
      title: "Archive Selected Inventory",
      message: `Are you sure you want to archive ${selectedIds.length} selected inventory item(s)? Archived items can be viewed by toggling 'Show Archived'.`,
      confirmText: "Archive Selected",
      cancelText: "Cancel",
      type: "warning"
    });

    if (!ok) return;

    setInventory(prev => prev.map(item => {
      if (selectedIds.includes(item.id)) {
        return {
          ...item,
          status: "Archived",
          archived: true
        };
      }
      return item;
    }));

    if (writeAuditLog) {
      writeAuditLog("BATCH_ARCHIVE", "Inventory", `${selectedIds.length} items`, "Archived selected inventory items");
    }

    setSelectedIds([]);
  };

  const handleBatchDelete = async () => {
    if (selectedIds.length === 0) return;

    const ok = await confirm({
      title: "Permanently Delete Inventory",
      message: `CRITICAL ACTION: Are you sure you want to permanently delete ${selectedIds.length} selected item(s)? This action cannot be undone.`,
      confirmText: "Delete Permanently",
      cancelText: "Cancel",
      type: "danger"
    });

    if (!ok) return;

    setInventory(prev => prev.filter(item => !selectedIds.includes(item.id)));

    if (writeAuditLog) {
      writeAuditLog("BATCH_DELETE", "Inventory", `${selectedIds.length} items`, "Deleted selected inventory items permanently");
    }

    setSelectedIds([]);
  };

  // Seed sample data
  const handleSeedSamples = () => {
    const created: InventoryItem[] = SAMPLE_INVENTORY_ITEMS.map((item, idx) => ({
      ...item,
      id: `INV-STORE-${Date.now()}-${idx + 1}`,
      farmId: activeFarm?.id || "farm-1"
    }));

    setInventory(prev => [...prev, ...created]);
  };

  // Add Item Submit
  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    const newItem: InventoryItem = {
      id: `INV-${Date.now().toString().slice(-6)}`,
      name: formData.name.trim(),
      category: formData.category,
      quantity: Number(formData.quantity) || 0,
      unit: formData.unit || "Units",
      unitCost: Number(formData.unitCost) || 0,
      totalValue: (Number(formData.quantity) || 0) * (Number(formData.unitCost) || 0),
      storageLocation: formData.storageLocation || "Main Store",
      lowStockAlertLevel: Number(formData.lowStockAlertLevel) || 10,
      status: formData.status,
      archived: formData.status === "Archived",
      farmId: activeFarm?.id
    };

    setInventory(prev => [newItem, ...prev]);
    setShowAddModal(false);
    setFormData({
      name: "",
      category: "Fertilizer",
      quantity: 50,
      unit: "Bags",
      unitCost: 100,
      storageLocation: "Main Store Room",
      lowStockAlertLevel: 10,
      status: "In Stock"
    });
  };

  // Edit Item Submit
  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;

    setInventory(prev => prev.map(item => {
      if (item.id === editingItem.id) {
        return {
          ...editingItem,
          totalValue: editingItem.quantity * editingItem.unitCost,
          archived: editingItem.status === "Archived" ? true : editingItem.archived
        };
      }
      return item;
    }));

    setEditingItem(null);
  };

  // Status Badge Helper
  const getStatusBadge = (item: InventoryItem) => {
    const status = item.status || (item.quantity <= item.lowStockAlertLevel ? (item.quantity === 0 ? "Out of Stock" : "Low Stock") : "In Stock");

    switch (status) {
      case "In Stock":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-50 text-emerald-700 border border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            In Stock
          </span>
        );
      case "Low Stock":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-50 text-amber-800 border border-amber-200 animate-pulse">
            <AlertTriangle className="w-3 h-3 text-amber-600" />
            Low Stock Alert
          </span>
        );
      case "Out of Stock":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-rose-50 text-rose-700 border border-rose-200">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
            Out of Stock
          </span>
        );
      case "Reserved":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-indigo-50 text-indigo-700 border border-indigo-200">
            <Box className="w-3 h-3 text-indigo-600" />
            Reserved
          </span>
        );
      case "Archived":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-slate-100 text-slate-600 border border-slate-300">
            <Archive className="w-3 h-3 text-slate-500" />
            Archived
          </span>
        );
      default:
        return null;
    }
  };

  // KPI Calculations
  const totalStockValue = useMemo(() => {
    return inventory.reduce((sum, item) => sum + (item.quantity * item.unitCost), 0);
  }, [inventory]);

  const lowStockCount = useMemo(() => {
    return inventory.filter(i => i.quantity <= i.lowStockAlertLevel && !i.archived).length;
  }, [inventory]);

  return (
    <div className="space-y-6 animate-fade-in font-sans">
      {/* Top Banner & KPI Summary Cards */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-wrap justify-between items-center gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <Package className="w-5 h-5 text-indigo-600" />
              <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider">
                Inputs & Supplies Store Room Inventory
              </h3>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-1">
              Real-time store room inventory ledger with batch selection, status updates, and valuation tracking.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {!isReadonly && (
              <button
                onClick={() => setShowAddModal(true)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm cursor-pointer transition-all active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>Add Inventory Item</span>
              </button>
            )}
            {inventory.length === 0 && !isReadonly && (
              <button
                onClick={handleSeedSamples}
                className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-extrabold rounded-xl border border-indigo-200 flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Load Sample Store Items</span>
              </button>
            )}
          </div>
        </div>

        {/* Quick KPI stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-5">
          <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 block">Total Items Listed</span>
            <div className="text-xl sm:text-2xl font-black text-slate-900 mt-1 tracking-tight font-sans">{inventory.length}</div>
          </div>
          <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 block">Inventory Valuation</span>
            <div className="text-xl sm:text-2xl font-black text-emerald-600 mt-1 tracking-tight font-sans">{currencySymbol} {totalStockValue.toLocaleString()}</div>
          </div>
          <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 block">Low Stock Triggers</span>
            <div className="text-xl sm:text-2xl font-black text-amber-600 mt-1 tracking-tight font-sans">{lowStockCount}</div>
          </div>
          <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 block">Selected Items</span>
            <div className="text-xl sm:text-2xl font-black text-slate-900 mt-1 tracking-tight font-sans">{selectedIds.length}</div>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-wrap gap-3 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search inventory by name, location, or store ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-indigo-500 focus:bg-white"
            />
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-3 py-1 rounded-xl">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-bold text-slate-500 uppercase">Category:</span>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="text-xs font-bold text-slate-800 bg-transparent outline-none cursor-pointer"
            >
              <option value="All">All Categories</option>
              <option value="Fertilizer">Fertilizer</option>
              <option value="Seeds">Seeds</option>
              <option value="Chemicals">Chemicals</option>
              <option value="Tools">Tools</option>
              <option value="Equipment">Equipment</option>
              <option value="Feed">Feed</option>
              <option value="Other">Other</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-3 py-1 rounded-xl">
            <span className="text-[10px] font-bold text-slate-500 uppercase">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs font-bold text-slate-800 bg-transparent outline-none cursor-pointer"
            >
              <option value="All">All Statuses</option>
              <option value="In Stock">In Stock</option>
              <option value="Low Stock">Low Stock</option>
              <option value="Out of Stock">Out of Stock</option>
              <option value="Reserved">Reserved</option>
              <option value="Archived">Archived</option>
            </select>
          </div>
        </div>

        {/* Toggle Archived view */}
        <button
          onClick={() => setShowArchived(!showArchived)}
          className={`px-3 py-1.5 text-xs font-extrabold rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 ${
            showArchived 
              ? "bg-slate-800 text-white border-slate-800" 
              : "bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100"
          }`}
        >
          <Archive className="w-3.5 h-3.5" />
          <span>{showArchived ? "Viewing Archived Items" : "Show Archived Items"}</span>
        </button>
      </div>

      {/* Bulk Action Controls Bar */}
      <div className={`p-4 rounded-2xl border transition-all flex flex-wrap justify-between items-center gap-4 ${
        selectedIds.length > 0 
          ? "bg-indigo-50/90 border-indigo-200 shadow-sm" 
          : "bg-slate-50 border-slate-200 text-slate-500"
      }`}>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 cursor-pointer font-extrabold text-xs text-slate-800">
            <input
              type="checkbox"
              checked={isAllSelected}
              onChange={handleToggleSelectAll}
              className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
            />
            <span>Select All Visible ({filteredInventory.length})</span>
          </label>
          
          {selectedIds.length > 0 && (
            <span className="text-[11px] font-extrabold px-2.5 py-0.5 rounded-full bg-indigo-600 text-white shadow-xs">
              {selectedIds.length} Item{selectedIds.length > 1 ? "s" : ""} Selected
            </span>
          )}
        </div>

        {/* Batch operations toolbar */}
        {selectedIds.length > 0 ? (
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Batch status dropdown */}
            <div className="flex items-center gap-1.5 bg-white border border-indigo-200 px-3 py-1 rounded-xl shadow-xs">
              <span className="text-[10px] font-black uppercase text-slate-500">Update Status To:</span>
              <select
                value={batchStatus}
                onChange={(e) => setBatchStatus(e.target.value as any)}
                className="text-xs font-black text-slate-800 bg-transparent outline-none cursor-pointer"
              >
                <option value="In Stock">In Stock</option>
                <option value="Low Stock">Low Stock</option>
                <option value="Out of Stock">Out of Stock</option>
                <option value="Reserved">Reserved</option>
                <option value="Archived">Archived</option>
              </select>
              <button
                onClick={handleBatchStatusUpdate}
                className="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-[11px] rounded-lg transition-all cursor-pointer shadow-xs active:scale-95"
              >
                Apply to {selectedIds.length}
              </button>
            </div>

            {/* Batch Archive */}
            <button
              onClick={handleBatchArchive}
              className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-black rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer transition-all border border-amber-400"
            >
              <Archive className="w-3.5 h-3.5" />
              <span>Batch Archive ({selectedIds.length})</span>
            </button>

            {/* Batch Delete */}
            <button
              onClick={handleBatchDelete}
              className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete ({selectedIds.length})</span>
            </button>

            {/* Clear Selection */}
            <button
              onClick={() => setSelectedIds([])}
              className="px-2.5 py-1 text-slate-500 hover:text-slate-800 text-xs font-bold cursor-pointer transition-colors"
            >
              Deselect
            </button>
          </div>
        ) : (
          <span className="text-xs text-slate-400 italic font-medium">
            Check checkboxes beside items to run batch status updates or batch archives.
          </span>
        )}
      </div>

      {/* Main Inventory Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-800">
            <thead className="text-[10px] uppercase font-black text-slate-400 bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="p-3.5 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={isAllSelected}
                    onChange={handleToggleSelectAll}
                    className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                  />
                </th>
                <th className="p-3.5">Store ID</th>
                <th className="p-3.5">Material Descriptor</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5">Location</th>
                <th className="p-3.5">Quantity / Unit</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right font-mono">Unit Cost</th>
                <th className="p-3.5 text-right font-mono">Computed Value</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-semibold text-slate-800">
              {filteredInventory.map(item => {
                const isSelected = selectedIds.includes(item.id);
                return (
                  <tr 
                    key={item.id} 
                    className={`transition-colors ${
                      isSelected ? "bg-indigo-50/40" : "hover:bg-slate-50/70"
                    }`}
                  >
                    <td className="p-3.5 text-center">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleToggleSelectOne(item.id)}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                      />
                    </td>
                    <td className="p-3.5 font-mono text-[11px] text-slate-500 font-bold">{item.id}</td>
                    <td className="p-3.5">
                      <div className="font-extrabold text-slate-900">{item.name}</div>
                      <div className="text-[10px] text-slate-400 font-medium">
                        Alert Threshold: {item.lowStockAlertLevel} {item.unit}
                      </div>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2.5 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[10px] font-bold border border-slate-200">
                        {item.category}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-600 text-[11px] font-medium">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        <span>{item.storageLocation || "Main Store"}</span>
                      </div>
                    </td>
                    <td className="p-3.5 font-mono font-extrabold text-slate-900">
                      {item.quantity} {item.unit}
                    </td>
                    <td className="p-3.5">
                      {getStatusBadge(item)}
                    </td>
                    <td className="p-3.5 text-right font-mono text-slate-600 font-bold">
                      {currencySymbol} {(item.unitCost || 0).toLocaleString()}
                    </td>
                    <td className="p-3.5 text-right font-mono font-extrabold text-slate-950">
                      {currencySymbol} {((item.quantity || 0) * (item.unitCost || 0)).toLocaleString()}
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {/* Quick Status Toggle Dropdown */}
                        <select
                          value={item.status || "In Stock"}
                          onChange={(e) => {
                            const newStatus = e.target.value as any;
                            setInventory(prev => prev.map(i => i.id === item.id ? { 
                              ...i, 
                              status: newStatus,
                              archived: newStatus === "Archived" ? true : i.archived 
                            } : i));
                          }}
                          className="text-[10px] font-bold bg-slate-50 border border-slate-200 rounded px-1.5 py-1 text-slate-700 outline-none cursor-pointer"
                        >
                          <option value="In Stock">In Stock</option>
                          <option value="Low Stock">Low Stock</option>
                          <option value="Out of Stock">Out of Stock</option>
                          <option value="Reserved">Reserved</option>
                          <option value="Archived">Archived</option>
                        </select>

                        {/* Edit Item */}
                        <button
                          onClick={() => setEditingItem(item)}
                          className="p-1 hover:bg-slate-100 text-slate-600 rounded transition-colors cursor-pointer"
                          title="Edit Item"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredInventory.length === 0 && (
                <tr>
                  <td colSpan={10} className="p-10 text-center text-slate-400 italic">
                    <div className="max-w-xs mx-auto space-y-2">
                      <Box className="w-8 h-8 text-slate-300 mx-auto" />
                      <p className="text-xs font-bold text-slate-500">No inventory store items match your filter criteria.</p>
                      {inventory.length === 0 && !isReadonly && (
                        <button
                          onClick={handleSeedSamples}
                          className="mt-2 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl cursor-pointer transition-all shadow-xs"
                        >
                          Load Sample Store Inventory
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Add Item */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in font-sans">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 shadow-xl space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-900 text-sm">Add New Store Room Inventory Item</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3 text-xs font-semibold text-slate-700">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Material Descriptor / Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Compound D Fertilizer (50kg)"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Category</label>
                  <select
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  >
                    <option value="Fertilizer">Fertilizer</option>
                    <option value="Seeds">Seeds</option>
                    <option value="Chemicals">Chemicals</option>
                    <option value="Tools">Tools</option>
                    <option value="Equipment">Equipment</option>
                    <option value="Feed">Feed</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Unit Type</label>
                  <input
                    type="text"
                    placeholder="e.g. Bags, Kg, Litres"
                    value={formData.unit}
                    onChange={e => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Quantity in Stock</label>
                  <input
                    type="number"
                    min="0"
                    value={formData.quantity}
                    onChange={e => setFormData({ ...formData, quantity: Number(e.target.value) })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Unit Cost ({currencySymbol})</label>
                  <input
                    type="number"
                    min="0"
                    value={formData.unitCost}
                    onChange={e => setFormData({ ...formData, unitCost: Number(e.target.value) })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Storage Location</label>
                  <input
                    type="text"
                    placeholder="e.g. Bay A, Store Room #1"
                    value={formData.storageLocation}
                    onChange={e => setFormData({ ...formData, storageLocation: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Low Stock Alert Level</label>
                  <input
                    type="number"
                    min="0"
                    value={formData.lowStockAlertLevel}
                    onChange={e => setFormData({ ...formData, lowStockAlertLevel: Number(e.target.value) })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Initial Status</label>
                <select
                  value={formData.status}
                  onChange={e => setFormData({ ...formData, status: e.target.value as any })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                >
                  <option value="In Stock">In Stock</option>
                  <option value="Low Stock">Low Stock</option>
                  <option value="Out of Stock">Out of Stock</option>
                  <option value="Reserved">Reserved</option>
                  <option value="Archived">Archived</option>
                </select>
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl cursor-pointer"
                >
                  Create Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Item */}
      {editingItem && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in font-sans">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 shadow-xl space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-900 text-sm">Edit Store Room Item ({editingItem.id})</h3>
              <button
                onClick={() => setEditingItem(null)}
                className="text-slate-400 hover:text-slate-600 font-bold text-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-3 text-xs font-semibold text-slate-700">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Material Descriptor</label>
                <input
                  type="text"
                  required
                  value={editingItem.name}
                  onChange={e => setEditingItem({ ...editingItem, name: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Category</label>
                  <select
                    value={editingItem.category}
                    onChange={e => setEditingItem({ ...editingItem, category: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  >
                    <option value="Fertilizer">Fertilizer</option>
                    <option value="Seeds">Seeds</option>
                    <option value="Chemicals">Chemicals</option>
                    <option value="Tools">Tools</option>
                    <option value="Equipment">Equipment</option>
                    <option value="Feed">Feed</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Quantity</label>
                  <input
                    type="number"
                    min="0"
                    value={editingItem.quantity}
                    onChange={e => setEditingItem({ ...editingItem, quantity: Number(e.target.value) })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Unit Cost ({currencySymbol})</label>
                  <input
                    type="number"
                    min="0"
                    value={editingItem.unitCost}
                    onChange={e => setEditingItem({ ...editingItem, unitCost: Number(e.target.value) })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Status</label>
                  <select
                    value={editingItem.status || "In Stock"}
                    onChange={e => setEditingItem({ ...editingItem, status: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  >
                    <option value="In Stock">In Stock</option>
                    <option value="Low Stock">Low Stock</option>
                    <option value="Out of Stock">Out of Stock</option>
                    <option value="Reserved">Reserved</option>
                    <option value="Archived">Archived</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

import React from "react";

// Shared SVG Props
export interface IconProps extends React.SVGProps<SVGSVGElement> {
  size?: number | string;
  className?: string;
}

// ----------------------------------------------------
// ANIMAL ICONS (Minimal Monochrome Line-Art Silhouette)
// ----------------------------------------------------

export const CowIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Head/Snout */}
    <path d="M14 16h20v14c0 3-2 5-5 5h-10c-3 0-5-2-5-5V16z" />
    <path d="M18 30h12" />
    <circle cx="20" cy="25" r="1.5" fill="currentColor" stroke="none" />
    <circle cx="28" cy="25" r="1.5" fill="currentColor" stroke="none" />
    {/* Horns */}
    <path d="M14 16c-1-5-5-6-7-4" />
    <path d="M34 16c1-5 5-6 7-4" />
    {/* Ears */}
    <path d="M14 20c-3 0-6 2-5 4s5-1 5-4z" />
    <path d="M34 20c3 0 6 2 5 4s-5-1-5-4z" />
    {/* Body suggestion/accent line */}
    <path d="M24 35v7M20 42h8" />
  </svg>
);

export const GoatIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Head and muzzle */}
    <path d="M16 14h16v16c0 3-4 6-8 6s-8-3-8-6V14z" />
    {/* Horns */}
    <path d="M18 14c-1-6-3-8-5-7" />
    <path d="M30 14c1-6 3-8 5-7" />
    {/* Ears */}
    <path d="M16 18c-3 2-4 5-3 6s4-1 3-6z" />
    <path d="M32 18c3 2 4 5 3 6s-4-1-3-6z" />
    {/* Beard */}
    <path d="M22 36l2 5 2-5" />
    {/* Eyes */}
    <circle cx="21" cy="22" r="1" fill="currentColor" stroke="none" />
    <circle cx="27" cy="22" r="1" fill="currentColor" stroke="none" />
  </svg>
);

export const SheepIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Fluffy sheep face cloud contour */}
    <path d="M18 16c-1-2-3-3-5-2-2.5.5-3.5 3-2 5.5-1.5 1-2 3-1.5 5 .5 2 2.5 3 4.5 2.5v4c0 3 3 5 6 5h8c3 0 6-2 6-5v-4c2 .5 4-.5 4.5-2.5.5-2 0-4-1.5-5 1.5-2.5.5-5-2-5.5-2-1-4 0-5 2" />
    {/* Snout outline */}
    <path d="M20 24h8v6c0 2-2 4-4 4s-4-2-4-4v-6z" />
    {/* Swirly Ears */}
    <path d="M12 21c-2 2-3 5-1 6s4-2 1-6z" />
    <path d="M36 21c2 2 3 5 1 6s-4-2-1-6z" />
    {/* Eyes */}
    <circle cx="22" cy="27" r="1" fill="currentColor" />
    <circle cx="26" cy="27" r="1" fill="currentColor" />
  </svg>
);

export const PigIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Head shape */}
    <circle cx="24" cy="24" r="14" />
    {/* Snout snout */}
    <rect x="20" y="22" width="8" height="6" rx="3" />
    <circle cx="22.5" cy="25" r="1" fill="currentColor" />
    <circle cx="25.5" cy="25" r="1" fill="currentColor" />
    {/* Floppy ears */}
    <path d="M13 16c-1-3 1-5 4-4l3 3-7 1z" />
    <path d="M35 16c1-3-1-5-4-4l-3 3 7 1z" />
    {/* Eyes */}
    <circle cx="18" cy="18" r="1" fill="currentColor" />
    <circle cx="30" cy="18" r="1" fill="currentColor" />
  </svg>
);

export const ChickenIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Comb (crested crown) */}
    <path d="M21 9c0-3 3-4 3-4s2 2 2 4c0 0 3-1 3 1s-2 3-2 3" />
    {/* Head & neck */}
    <path d="M20 18c0-3.5 2.5-6 6-6s6 2.5 6 6v8H20v-8z" />
    {/* Beak */}
    <path d="M32 15l4 2-4 2" />
    {/* Wattle (throat ornament) */}
    <path d="M28 20c0 2-1 3-2 3s-2-1-2-3" />
    {/* Eye */}
    <circle cx="28" cy="15.5" r="1" fill="currentColor" />
    {/* Simple feather profile line */}
    <path d="M20 23c-3 0-5 3-5 6s4 5 7 5h8" />
  </svg>
);

export const DuckIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Head & bill */}
    <path d="M18 16c0-3.3 2.7-6 6-6s6 2.7 6 6c0 1.5-.5 2.8-1.5 3.7L29 26H17l1.5-6.3C17.5 18.8 18 17.5 18 16z" />
    {/* Duck Bill */}
    <path d="M30 14h5c1.5 0 2 1.5.5 2.5l-5.5 2" />
    {/* Eye */}
    <circle cx="24" cy="14" r="1.2" fill="currentColor" />
    {/* Floating body base */}
    <path d="M14 26c-3 0-5 2-5 5s4 7 12 7h16c4 0 6-3 6-5s-3-7-10-7H14z" />
  </svg>
);

export const QuailIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Crest feather */}
    <path d="M26 8c2-3 4-3 4-3s-1 4-2 5" />
    {/* Compact body & head */}
    <circle cx="24" cy="17" r="6" />
    <path d="M18 21c-4 1-7 4-7 8s4 7 11 7h12c3 0 5-3 5-6s-4-9-10-9" />
    {/* Eye */}
    <circle cx="26" cy="16" r="1" fill="currentColor" />
    {/* Beak */}
    <path d="M30 16l3 1-3 1" />
  </svg>
);

export const GuineaFowlIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Bumpy crest crown */}
    <path d="M25 6l2 4-3 1z" />
    {/* Head & slender neck */}
    <path d="M22 17c0-2.5 1.5-4 3.5-4s3.5 1.5 3.5 4l-1.5 6h-4l-1.5-6z" />
    {/* Plump bird body with spots representation */}
    <path d="M15 23c-5 0-7 4-7 9s4 9 14 9h12c5 0 6-4 6-7s-5-11-13-11H15z" />
    {/* Eye */}
    <circle cx="26" cy="15" r="1" fill="currentColor" />
    {/* Slender bill */}
    <path d="M29 16l3 1.5-3 1.5" />
    {/* Little spots dots */}
    <circle cx="16" cy="30" r="1.2" fill="currentColor" stroke="none" />
    <circle cx="24" cy="29" r="1.2" fill="currentColor" stroke="none" />
    <circle cx="30" cy="32" r="1.2" fill="currentColor" stroke="none" />
    <circle cx="20" cy="35" r="1.2" fill="currentColor" stroke="none" />
  </svg>
);

export const RabbitIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Long pointy ears */}
    <path d="M19 14c-1-5-2-9-3-9s-3 4-2 9" />
    <path d="M25 14c1-5 2-9 3-9s3 4 2 9" />
    {/* Rounded head */}
    <circle cx="22" cy="20" r="7" />
    {/* Face lines / whiskers suggestion */}
    <path d="M15 22h3" />
    <path d="M26 22h3" />
    {/* Fluffy body profile */}
    <path d="M16 26c-3 1-5 3-5 6s4 6 11 6h12c4 0 6-2 6-5s-3-7-10-7H16z" />
    {/* Eye */}
    <circle cx="22" cy="19" r="1" fill="currentColor" />
  </svg>
);

// ----------------------------------------------------
// FARM & INFRASTRUCTURE ICONS
// ----------------------------------------------------

export const TractorIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Small Front Wheel */}
    <circle cx="14" cy="36" r="6" />
    <circle cx="14" cy="36" r="2" />
    {/* Large Rear Wheel */}
    <circle cx="34" cy="32" r="10" />
    <circle cx="34" cy="32" r="3" />
    {/* Body Chassis */}
    <path d="M14 30h10V18H16v4h-6v8h4" />
    <path d="M24 30h10" />
    {/* Cab */}
    <path d="M24 30V14h10v8h-4" />
    {/* Exhaust pipe */}
    <path d="M21 18v-8h1" />
  </svg>
);

export const BarnIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Main Barn structure */}
    <path d="M6 38V22l14-10 14 10v16H6z" />
    {/* Gambrel Roof highlights */}
    <path d="M4 23l16-12 16 12" />
    {/* Large Barn Doors with crossbeams */}
    <rect x="14" y="26" width="12" height="12" />
    <path d="M14 26l12 12M26 26l-12 12" />
    {/* Silo next to Barn */}
    <path d="M38 18v20h4V18" />
    <path d="M38 18c0-3 2-5 4-5s4 2 4 5" />
    <path d="M38 23h8" />
    <path d="M38 28h8" />
    <path d="M38 33h8" />
  </svg>
);

export const DairyIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Milk bottle / jar */}
    <rect x="12" y="14" width="12" height="24" rx="4" />
    <path d="M12 20h12" />
    <path d="M15 14l1-6h6l1 6" />
    {/* Cheese wheel or milk glass */}
    <path d="M28 24h12v12c0 2-2 4-4 4H32c-2 0-4-2-4-4V24z" />
    <path d="M28 29c4 0 4-2 8-2s4 2 8 2" />
    <circle cx="32" cy="34" r="1" fill="currentColor" />
    <circle cx="37" cy="32" r="1.2" fill="currentColor" />
  </svg>
);

export const GreenhouseIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Dome/Arched Greenhouse outer frame */}
    <path d="M6 38V24C6 14 14 6 24 6s18 8 18 18v14H6z" />
    {/* Base line */}
    <path d="M4 38h40" />
    {/* Glass pane struts */}
    <path d="M18 6v32" />
    <path d="M30 6v32" />
    <path d="M6 24h36" />
    <path d="M8 16h32" />
    {/* Little growing seedling inside */}
    <path d="M24 38v-8" />
    <path d="M24 33c-2-1-4 0-4 0s1-2 4-1" />
    <path d="M24 32c2-1 4 0 4 0s-1-2-4-1" />
  </svg>
);

export const OrchardIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Row of three minimal trees */}
    {/* Left Tree */}
    <path d="M12 38v-8" />
    <circle cx="12" cy="24" r="6" />
    <circle cx="10" cy="22" r="1" fill="currentColor" />
    {/* Middle Tree */}
    <path d="M24 38V26" />
    <circle cx="24" cy="18" r="8" />
    <circle cx="22" cy="16" r="1.2" fill="currentColor" />
    <circle cx="26" cy="19" r="1.2" fill="currentColor" />
    {/* Right Tree */}
    <path d="M36 38v-8" />
    <circle cx="36" cy="24" r="6" />
    <circle cx="36" cy="22" r="1" fill="currentColor" />
    {/* Horizon floor */}
    <path d="M4 38h40" />
  </svg>
);

export const WindmillIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Base tower pyramid */}
    <path d="M18 38l4-20h4l4 20" />
    {/* Windmill ground line */}
    <path d="M12 38h24" />
    {/* Rotor head */}
    <circle cx="24" cy="18" r="2" fill="currentColor" />
    {/* Rotor Blades */}
    <path d="M24 18l-10-8M14 10l-1 4M24 18l10-8M34 10l1 4" />
    <path d="M24 18v12M24 30h-4M24 18l-8 8M16 26l3 2" />
  </svg>
);

export const CropsIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Ear of Wheat / Seed Stem */}
    <path d="M24 42V10" />
    {/* Kernel leaves symmetrically staggered */}
    <path d="M24 34c-3-1-5-4-5-4s3-1 5 1" />
    <path d="M24 34c3-1 5-4 5-4s-3-1-5 1" />
    <path d="M24 26c-3-1-5-4-5-4s3-1 5 1" />
    <path d="M24 26c3-1 5-4 5-4s-3-1-5 1" />
    <path d="M24 18c-3-1-5-4-5-4s3-1 5 1" />
    <path d="M24 18c3-1 5-4 5-4s-3-1-5 1" />
    {/* Crown whiskers */}
    <path d="M24 10l-3-4" />
    <path d="M24 10l3-4" />
  </svg>
);

export const FertilizerIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Hessian sack */}
    <path d="M12 14c0-3 3-4 6-4h12c3 0 6 1 6 4l-3 24c0 3-4 4-9 4h-4c-5 0-9-1-9-4L12 14z" />
    <path d="M11 14h26" />
    <path d="M13 18h22" />
    {/* Leaf / Chemical Symbol badge */}
    <circle cx="24" cy="28" r="5" />
    <path d="M22 28a2 2 0 014 0" />
  </svg>
);

export const HarvestIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Basket or box filled with crops */}
    <rect x="8" y="24" width="32" height="16" rx="4" />
    {/* Basket handles */}
    <path d="M8 28c-3 0-5-2-5-4s2-4 5-4M40 28c3 0 5-2 5-4s-2-4-5-4" />
    {/* Crop veggies poking out */}
    <circle cx="16" cy="18" r="4" />
    <path d="M16 14l-1-4" />
    <path d="M24 24V14c0-2 2-4 4-4s4 2 4 4v10" />
    <path d="M34 24c0-4-3-6-6-6" />
  </svg>
);

export const FeedIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Feed trough/sack structure */}
    <path d="M10 12l4 24h20l4-24H10z" />
    {/* Grains/mounds of food inside */}
    <path d="M14 12c4-4 8-4 10 0s6-4 10 0" />
    {/* Stripe detailing */}
    <path d="M10 20h28" />
    <path d="M12 28h24" />
  </svg>
);

export const OrganicIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Circular emblem with leaves & checkmark */}
    <circle cx="24" cy="24" r="18" />
    <path d="M18 24l4 4 8-8" />
    <path d="M14 18c-2-2-1-5 2-4l3 2" />
    <path d="M34 18c2-2 1-5-2-4l-3 2" />
  </svg>
);

export const FarmerIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Farmer Hat */}
    <path d="M10 20c4-4 12-5 16-5s12 1 16 5" />
    <path d="M6 20h36" />
    {/* Head */}
    <circle cx="24" cy="26" r="6" />
    {/* Pitchfork / Tool handle */}
    <path d="M36 12v30" />
    <path d="M32 12h8" />
    <path d="M32 12v4M36 12v4M40 12v4" />
    {/* Shoulders */}
    <path d="M14 42v-6c0-4 4-6 10-6s10 2 10 6v6" />
  </svg>
);

export const LandscapeIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Scenic hills */}
    <path d="M4 38c6-4 12-4 18 0s12 4 22-4" />
    <path d="M4 30c8 3 16-3 24 2s12-1 16-6" />
    {/* Sun */}
    <circle cx="34" cy="14" r="5" />
    <path d="M34 6v2M34 20v2M26 14h2M40 14h2" />
    {/* Ground line */}
    <path d="M4 38h40" />
  </svg>
);

export const NurseryIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Laboratory Flask with a plant growing out */}
    <path d="M20 10h8" />
    <path d="M22 10v8l-10 18c-2 3 0 6 4 6h20c4 0 6-3 4-6L26 18v-8" />
    {/* Sprout inside */}
    <path d="M24 38v-12" />
    <path d="M24 30c2-1 4-1 4-1s-1-2-4 1" />
    <path d="M24 33c-2-1-4-1-4-1s1-2 4 1" />
  </svg>
);

// ----------------------------------------------------
// SUBSCRIPTION TIER ICONS (Custom designs in same line-art family)
// ----------------------------------------------------

export const SeedlingPlanIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Plant pot with single seedling */}
    <path d="M16 32l2 10h12l2-10H16z" />
    <path d="M24 32V14" />
    <path d="M24 22c3-1 5 0 5 0s-1-3-5-1" />
    <path d="M24 18c-3-1-5 0-5 0s1-3 5-1" />
  </svg>
);

export const HarvesterPlanIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Scythe/Sickle or wheat harvest stack */}
    <path d="M12 36l24-24M36 12a14 14 0 00-24 12" />
    <rect x="8" y="32" width="8" height="8" rx="2" />
    <circle cx="28" cy="20" r="2" fill="currentColor" />
  </svg>
);

export const CommercialPlanIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Warehouse/Business farm barn with complex multi-grain details */}
    <path d="M8 40V24l16-12 16 12v16H8z" />
    <path d="M16 28h16v12H16V28z" />
    <path d="M24 28v12" />
    <circle cx="24" cy="18" r="2" fill="currentColor" />
  </svg>
);

export const EnterprisePlanIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Premium Globe + Crown/Network nodes representing heavy enterprise connectivity */}
    <circle cx="24" cy="24" r="18" />
    <path d="M6 24h36M24 6a28 28 0 000 36M24 6a28 28 0 010 36" />
    <circle cx="24" cy="6" r="3" fill="currentColor" />
    <circle cx="24" cy="42" r="3" fill="currentColor" />
    <circle cx="6" cy="24" r="3" fill="currentColor" />
    <circle cx="42" cy="24" r="3" fill="currentColor" />
  </svg>
);

// ----------------------------------------------------
// COINS & WALLET / CREDIT TRANSACTION ICONS
// ----------------------------------------------------

export const WalletCreditIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Wallet fold line-art */}
    <rect x="6" y="10" width="36" height="28" rx="6" />
    <path d="M6 18h36" />
    <path d="M30 22h8a2 2 0 012 2v4a2 2 0 01-2 2h-8V22z" />
    <circle cx="34" cy="26" r="1.5" fill="currentColor" />
  </svg>
);

export const CoinIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Stack of three coins */}
    <ellipse cx="24" cy="14" rx="14" ry="5" />
    <path d="M10 14v8c0 2.8 6.3 5 14 5s14-2.2 14-5v-8" />
    <path d="M10 22v8c0 2.8 6.3 5 14 5s14-2.2 14-5v-8" />
    {/* Currency symbol Z inside the top coin */}
    <path d="M21 12h6l-6 4h6" />
  </svg>
);

export const DailyBundleIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`inline-block ${className}`}
    {...props}
  >
    {/* Calender sheet outline with dynamic bolt / sparkles */}
    <rect x="8" y="10" width="32" height="32" rx="4" />
    <path d="M8 18h32M16 6v8M32 6v8" />
    {/* Lightning bolt / speed lines */}
    <path d="M26 22l-6 6h5l-2 6 7-7h-5z" />
  </svg>
);

export function getSpeciesIcon(speciesName: string, className = "w-12 h-12 text-slate-700", size: number | string = 24) {
  const norm = (speciesName || "").toLowerCase();
  if (norm.includes("cow") || norm.includes("cattle") || norm.includes("bovine") || norm.includes("bull") || norm.includes("calf")) {
    return <CowIcon className={className} size={size} />;
  }
  if (norm.includes("goat") || norm.includes("caprine") || norm.includes("buck") || norm.includes("doe") || norm.includes("kid")) {
    return <GoatIcon className={className} size={size} />;
  }
  if (norm.includes("sheep") || norm.includes("ovine") || norm.includes("lamb") || norm.includes("ewe") || norm.includes("ram")) {
    return <SheepIcon className={className} size={size} />;
  }
  if (norm.includes("pig") || norm.includes("porcine") || norm.includes("boar") || norm.includes("sow") || norm.includes("piglet") || norm.includes("gilt") || norm.includes("swine")) {
    return <PigIcon className={className} size={size} />;
  }
  if (norm.includes("chicken") || norm.includes("poultry") || norm.includes("hen") || norm.includes("rooster") || norm.includes("chick")) {
    return <ChickenIcon className={className} size={size} />;
  }
  if (norm.includes("duck")) {
    return <DuckIcon className={className} size={size} />;
  }
  if (norm.includes("quail")) {
    return <QuailIcon className={className} size={size} />;
  }
  if (norm.includes("guinea")) {
    return <GuineaFowlIcon className={className} size={size} />;
  }
  if (norm.includes("rabbit")) {
    return <RabbitIcon className={className} size={size} />;
  }
  return <OrganicIcon className={className} size={size} />;
}


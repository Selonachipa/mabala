import React, { useState, useMemo } from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  Calendar, 
  Filter, 
  Search, 
  TrendingUp, 
  TrendingDown, 
  BarChart2, 
  PieChart as PieIcon, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  Building2, 
  ChevronRight,
  ShieldAlert,
  Sliders,
  ArrowUpRight
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  LineChart, 
  Line, 
  CartesianGrid 
} from 'recharts';

import { ReportDefinition, ReportCategory } from '../config/reportDefinitions';
import { reportsGetDefinitions, reportsRunQuery } from '../services/reportApiService';
import { ReportFilterParams, ReportQueryResult } from '../services/reportAggregationEngine';
import { generateReportPdf } from '../utils/reportPdfExport';
import { generateReportExcel } from '../utils/reportExcelExport';

interface AgroDealerReportCentrePanelProps {
  tenantId?: string;
  tenantName?: string;
  currencySymbol?: string;
  tenantCapabilities?: string[];
  contextData?: any;
}

const CHART_COLORS = ['#10B981', '#3B82F6', '#F59E0B', '#8B5CF6', '#EC4899', '#06B6D4', '#6366F1'];

export default function AgroDealerReportCentrePanel({
  tenantId = 'default_tenant',
  tenantName = 'Mabala Agro-Dealer Store',
  currencySymbol = 'ZMW',
  tenantCapabilities = ['agrodealer', 'institution_financier'],
  contextData = {}
}: AgroDealerReportCentrePanelProps) {
  // 1. Available Report Definitions
  const availableReports = useMemo(() => {
    return reportsGetDefinitions(tenantId, tenantCapabilities);
  }, [tenantId, tenantCapabilities]);

  // Selected state
  const [selectedReportId, setSelectedReportId] = useState<string>(availableReports[0]?.id || 'stock-on-hand-by-supplier');
  const [activeCategoryTab, setActiveCategoryTab] = useState<'all' | ReportCategory>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Period and Filter parameters state
  const [preset, setPreset] = useState<'today' | 'this_week' | 'this_month' | 'this_quarter' | 'this_season' | 'ytd' | 'custom'>('this_month');
  const [fromDate, setFromDate] = useState<string>(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]);
  const [toDate, setToDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [enableComparison, setEnableComparison] = useState<boolean>(true);

  // Quick Filters state
  const [supplierFilter, setSupplierFilter] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [asOfDate, setAsOfDate] = useState<string>('');
  const [tableSearchTerm, setTableSearchTerm] = useState<string>('');

  // Active Report Definition
  const currentDefinition = useMemo(() => {
    return availableReports.find(r => r.id === selectedReportId) || availableReports[0];
  }, [availableReports, selectedReportId]);

  // Filtered Catalog List
  const catalogList = useMemo(() => {
    return availableReports.filter(r => {
      const matchCat = activeCategoryTab === 'all' || r.category === activeCategoryTab;
      const matchSearch = !searchTerm.trim() || 
        r.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
        r.description.toLowerCase().includes(searchTerm.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [availableReports, activeCategoryTab, searchTerm]);

  // Execute Query Result
  const queryResult: ReportQueryResult = useMemo(() => {
    const filters: ReportFilterParams = {
      preset,
      fromDate: preset === 'custom' ? fromDate : undefined,
      toDate: preset === 'custom' ? toDate : undefined,
      supplierId: supplierFilter || undefined,
      category: categoryFilter || undefined,
      asOfDate: asOfDate || undefined,
      enableComparison
    };

    return reportsRunQuery(selectedReportId, tenantId, filters, contextData);
  }, [selectedReportId, tenantId, preset, fromDate, toDate, supplierFilter, categoryFilter, asOfDate, enableComparison, contextData]);

  // Filtered Table Rows
  const displayedRows = useMemo(() => {
    if (!tableSearchTerm.trim()) return queryResult.rows;
    const term = tableSearchTerm.toLowerCase();
    return queryResult.rows.filter(row => {
      return Object.values(row).some(v => String(v).toLowerCase().includes(term));
    });
  }, [queryResult.rows, tableSearchTerm]);

  // Export PDF Handler
  const handleExportPDF = () => {
    generateReportPdf(queryResult, currencySymbol, tenantName);
  };

  // Export Excel Handler
  const handleExportExcel = () => {
    generateReportExcel(queryResult, tenantName);
  };

  return (
    <div className="space-y-6 animate-fade-in" id="agro-dealer-report-centre-panel">
      {/* Top Banner & Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-slate-800">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row justify-between md:items-center gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-3 py-1 bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 font-black text-[10px] rounded-full uppercase tracking-wider font-mono">
                Agro-Dealer Core SaaS
              </span>
              <span className="px-3 py-1 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 font-black text-[10px] rounded-full uppercase tracking-wider font-mono">
                13-Report Catalog Engine
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Agro-Dealer Report Centre
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl font-medium">
              Comprehensive inventory, sales turnover, supplier payables, and profitability reporting engine for {tenantName}.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={handleExportPDF}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
              id="report-centre-export-pdf-btn"
            >
              <Printer className="w-4 h-4" />
              <span>Export PDF</span>
            </button>
            <button
              onClick={handleExportExcel}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
              id="report-centre-export-excel-btn"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Export Excel</span>
            </button>
          </div>
        </div>
      </div>

      {/* Catalog Category Tabs & Search */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {[
              { id: 'all', label: 'All Reports (13)' },
              { id: 'inventory', label: 'Inventory (1-4)' },
              { id: 'sales', label: 'Sales (5-6)' },
              { id: 'supplier', label: 'Supplier Obligations (7-8)' },
              { id: 'financial', label: 'Financial & Profitability (9-13)' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveCategoryTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all whitespace-nowrap cursor-pointer ${
                  activeCategoryTab === tab.id
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Filter catalog by name..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl bg-slate-50 focus:bg-white outline-none focus:border-slate-400"
            />
          </div>
        </div>

        {/* Report Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 pt-2 border-t border-slate-100">
          {catalogList.map(rep => {
            const isSelected = rep.id === selectedReportId;
            return (
              <div
                key={rep.id}
                onClick={() => setSelectedReportId(rep.id)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-emerald-50/80 border-emerald-500 shadow-sm ring-1 ring-emerald-500'
                    : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100/80 hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className={`text-[9.5px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${
                      rep.category === 'inventory' ? 'bg-blue-100 text-blue-800' :
                      rep.category === 'sales' ? 'bg-emerald-100 text-emerald-800' :
                      rep.category === 'supplier' ? 'bg-amber-100 text-amber-800' : 'bg-purple-100 text-purple-800'
                    }`}>
                      {rep.category}
                    </span>
                    {rep.requiresCapability && (
                      <span className="text-[9px] bg-indigo-100 text-indigo-800 font-bold px-1.5 py-0.5 rounded font-mono">
                        FINANCIER
                      </span>
                    )}
                  </div>
                  <h4 className="text-xs font-black text-slate-900 leading-tight">
                    {rep.title}
                  </h4>
                  <p className="text-[10px] text-slate-500 line-clamp-2 mt-1">
                    {rep.description}
                  </p>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold">
                  <span className="text-slate-400">
                    {rep.chartTypes.includes('none') ? 'Statement' : 'Chart & Table'}
                  </span>
                  <span className={isSelected ? 'text-emerald-700 font-extrabold flex items-center gap-0.5' : 'text-slate-500'}>
                    {isSelected ? 'Active View' : 'Select'} <ChevronRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Report Active View Header & Period Controls Bar */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] bg-slate-900 text-white font-black px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">
                REPORT #{selectedReportId}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                Data Sources: {currentDefinition.sourceCollections.join(', ')}
              </span>
            </div>
            <h3 className="text-xl font-black text-slate-900 mt-1">
              {currentDefinition.title}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {currentDefinition.description}
            </p>
          </div>

          {/* Period Controls */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-50 p-1.5 rounded-xl border border-slate-200">
              <Calendar className="w-4 h-4 text-slate-400 ml-1.5" />
              <select
                value={preset}
                onChange={e => setPreset(e.target.value as any)}
                className="bg-transparent text-xs font-bold text-slate-800 outline-none pr-2 cursor-pointer"
                id="report-period-preset-select"
              >
                <option value="today">Today</option>
                <option value="this_week">This Week</option>
                <option value="this_month">This Month</option>
                <option value="this_quarter">This Quarter</option>
                <option value="this_season">2025/2026 Season</option>
                <option value="ytd">Year to Date (YTD)</option>
                <option value="custom">Custom Date Range</option>
              </select>
            </div>

            {preset === 'custom' && (
              <div className="flex items-center gap-2 text-xs font-bold">
                <input
                  type="date"
                  value={fromDate}
                  onChange={e => setFromDate(e.target.value)}
                  className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-800"
                />
                <span className="text-slate-400">to</span>
                <input
                  type="date"
                  value={toDate}
                  onChange={e => setToDate(e.target.value)}
                  className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-800"
                />
              </div>
            )}

            {currentDefinition.supportsPeriodComparison && (
              <label className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={enableComparison}
                  onChange={e => setEnableComparison(e.target.checked)}
                  className="h-3.5 w-3.5 accent-emerald-600 rounded"
                />
                <span className="text-xs font-bold text-slate-700">Compare vs. Prior Period</span>
              </label>
            )}
          </div>
        </div>

        {/* Quick Filter Bar (Supplier, Category, As-Of Date) */}
        <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-50/70 p-3.5 rounded-xl border border-slate-200/80">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-[10px] uppercase font-black text-slate-400 flex items-center gap-1">
              <Filter className="w-3 h-3" /> Filters:
            </span>

            {/* Supplier Filter */}
            <select
              value={supplierFilter}
              onChange={e => setSupplierFilter(e.target.value)}
              className="text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg px-3 py-1.5 outline-none"
            >
              <option value="">All Suppliers</option>
              <option value="Zamseed Ltd">Zamseed Ltd</option>
              <option value="Nitrogen Chemicals Zambia">Nitrogen Chemicals Zambia</option>
              <option value="Osho Chemicals">Osho Chemicals</option>
              <option value="Agro-Tech Supplies">Agro-Tech Supplies</option>
            </select>

            {/* Category Filter */}
            <select
              value={categoryFilter}
              onChange={e => setCategoryFilter(e.target.value)}
              className="text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg px-3 py-1.5 outline-none"
            >
              <option value="">All Categories</option>
              <option value="Seeds">Seeds</option>
              <option value="Fertilizer">Fertilizer</option>
              <option value="Agro-Chemicals">Agro-Chemicals</option>
              <option value="Equipment & Tools">Equipment & Tools</option>
            </select>

            {/* As-Of Date for Stock Report #1 */}
            {currentDefinition.supportsAsOfDate && (
              <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs">
                <span className="text-[10px] font-bold text-slate-400 uppercase">As-Of Date:</span>
                <input
                  type="date"
                  value={asOfDate}
                  onChange={e => setAsOfDate(e.target.value)}
                  className="bg-transparent text-xs font-bold text-slate-800 outline-none"
                />
              </div>
            )}
          </div>

          <div className="text-xs font-mono text-slate-500 font-bold">
            Showing {displayedRows.length} of {queryResult.summary.totalRecords} records
          </div>
        </div>

        {/* Key Metric Summary Cards */}
        {queryResult.summary.metrics.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {queryResult.summary.metrics.map(metric => (
              <div key={metric.key} className="bg-slate-50/80 p-4 rounded-xl border border-slate-200/80 flex flex-col justify-between">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">
                  {metric.label}
                </span>
                <div className="flex items-baseline justify-between mt-2">
                  <span className="text-xl font-black text-slate-900 font-mono">
                    {metric.formatted}
                  </span>
                  {metric.deltaPct !== undefined && (
                    <span className={`text-xs font-black flex items-center gap-0.5 px-2 py-0.5 rounded-full ${
                      metric.deltaPct >= 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {metric.deltaPct >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                      {metric.deltaPct >= 0 ? `+${metric.deltaPct}%` : `${metric.deltaPct}%`}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Visual Charts Container */}
        {!currentDefinition.chartTypes.includes('none') && queryResult.chartData.length > 0 && (
          <div className="bg-slate-50/60 p-6 rounded-2xl border border-slate-200/80 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-emerald-600" />
                Visual Distribution & Trend Chart
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase font-mono">
                {currentDefinition.groupByDimension ? `Grouped by ${currentDefinition.groupByDimension}` : 'Time Trend'}
              </span>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                {currentDefinition.chartTypes.includes('pie') && currentDefinition.groupByDimension ? (
                  <PieChart>
                    <Pie
                      data={queryResult.chartData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={85}
                      innerRadius={45}
                      paddingAngle={4}
                      label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                    >
                      {queryResult.chartData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: any) => `${currencySymbol} ${Number(value).toLocaleString()}`} />
                    <Legend />
                  </PieChart>
                ) : currentDefinition.chartTypes.includes('stackedBar') ? (
                  <BarChart data={queryResult.chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                    <XAxis dataKey="name" stroke="#64748B" fontSize={11} />
                    <YAxis stroke="#64748B" fontSize={11} />
                    <Tooltip formatter={(val: any) => `${currencySymbol} ${Number(val).toLocaleString()}`} />
                    <Bar dataKey="value" fill="#10B981" radius={[6, 6, 0, 0]} />
                  </BarChart>
                ) : (
                  <BarChart data={queryResult.chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                    <XAxis dataKey="name" stroke="#64748B" fontSize={11} />
                    <YAxis stroke="#64748B" fontSize={11} />
                    <Tooltip formatter={(val: any) => typeof val === 'number' ? `${currencySymbol} ${val.toLocaleString()}` : val} />
                    <Bar dataKey="soldValue" fill="#10B981" name="Sales Volume" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="marginEarned" fill="#3B82F6" name="Dealer Margin" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="value" fill="#10B981" name="Valuation" radius={[4, 4, 0, 0]} />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Formatted Data Table */}
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h4 className="text-sm font-black text-slate-900">
              Detailed Ledger Table ({displayedRows.length} Rows)
            </h4>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Search table rows..."
                value={tableSearchTerm}
                onChange={e => setTableSearchTerm(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white outline-none"
              />
            </div>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-[10px] font-black uppercase text-slate-600 border-b border-slate-200">
                <tr>
                  {currentDefinition.columns.map(col => (
                    <th key={col.key} className={`p-3 ${col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : 'text-left'}`}>
                      {col.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-150 font-medium text-slate-800">
                {displayedRows.length === 0 ? (
                  <tr>
                    <td colSpan={currentDefinition.columns.length} className="p-8 text-center text-slate-400 italic">
                      No matching record lines found for current report filters.
                    </td>
                  </tr>
                ) : (
                  displayedRows.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/80 transition-all">
                      {currentDefinition.columns.map(col => {
                        const val = row[col.key];
                        let displayVal = val !== undefined && val !== null ? String(val) : '—';

                        if (col.type === 'currency' && typeof val === 'number') {
                          displayVal = `${currencySymbol} ${val.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
                        } else if (col.type === 'percent' && typeof val === 'number') {
                          displayVal = `${val}%`;
                        } else if (col.type === 'number' && typeof val === 'number') {
                          displayVal = val.toLocaleString();
                        }

                        const isStatusCol = ['reorderStatus', 'velocity', 'status', 'performanceScore'].includes(col.key);

                        return (
                          <td key={col.key} className={`p-3 ${col.align === 'right' ? 'text-right font-mono' : col.align === 'center' ? 'text-center' : 'text-left'}`}>
                            {isStatusCol ? (
                              <span className={`px-2 py-0.5 rounded-full text-[9.5px] font-black uppercase ${
                                displayVal.includes('REORDER') || displayVal.includes('SLOW') || displayVal.includes('ATTENTION')
                                  ? 'bg-rose-100 text-rose-800 border border-rose-200'
                                  : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              }`}>
                                {displayVal}
                              </span>
                            ) : (
                              <span className={col.type === 'currency' ? 'font-bold text-slate-900' : ''}>
                                {displayVal}
                              </span>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useMemo } from "react";
import { 
  ResponsiveContainer, 
  ComposedChart, 
  Line, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ReferenceLine
} from "recharts";
import { Activity, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { ExpenseTransaction, CashSale, Invoice } from "../types";

interface NetOperatingSurplusChartProps {
  expenses?: ExpenseTransaction[];
  cashSales?: CashSale[];
  invoices?: Invoice[];
  currencySymbol?: string;
}

export default function NetOperatingSurplusChart({
  expenses = [],
  cashSales = [],
  invoices = [],
  currencySymbol = "ZK"
}: NetOperatingSurplusChartProps) {
  const [viewMode, setViewMode] = useState<"monthly" | "quarterly">("monthly");
  const [showBreakdownBars, setShowBreakdownBars] = useState<boolean>(true);

  // Define monthly slots (12 months range)
  const monthlyData = useMemo(() => {
    const slots = [
      { y: 2025, m: 6, label: "Jul 25", q: "Q3 '25" },
      { y: 2025, m: 7, label: "Aug 25", q: "Q3 '25" },
      { y: 2025, m: 8, label: "Sep 25", q: "Q3 '25" },
      { y: 2025, m: 9, label: "Oct 25", q: "Q4 '25" },
      { y: 2025, m: 10, label: "Nov 25", q: "Q4 '25" },
      { y: 2025, m: 11, label: "Dec 25", q: "Q4 '25" },
      { y: 2026, m: 0, label: "Jan 26", q: "Q1 '26" },
      { y: 2026, m: 1, label: "Feb 26", q: "Q1 '26" },
      { y: 2026, m: 2, label: "Mar 26", q: "Q1 '26" },
      { y: 2026, m: 3, label: "Apr 26", q: "Q2 '26" },
      { y: 2026, m: 4, label: "May 26", q: "Q2 '26" },
      { y: 2026, m: 5, label: "Jun 26", q: "Q2 '26" }
    ];

    return slots.map(slot => {
      const mExpenses = (expenses || []).filter(ex => {
        if (!ex.date) return false;
        const d = new Date(ex.date);
        return d.getFullYear() === slot.y && d.getMonth() === slot.m;
      }).reduce((sum, ex) => sum + (ex.total || 0), 0);

      const mCashSales = (cashSales || []).filter(c => {
        if (c.coaCredit === "1100") return false;
        if (!c.date) return false;
        const d = new Date(c.date);
        return d.getFullYear() === slot.y && d.getMonth() === slot.m;
      }).reduce((sum, c) => sum + (c.amount || 0), 0);

      const mInvoices = (invoices || []).filter(i => {
        if (!i.date) return false;
        const d = new Date(i.date);
        return d.getFullYear() === slot.y && d.getMonth() === slot.m && i.status === "Paid";
      }).reduce((sum, i) => sum + (i.total || 0), 0);

      const revenue = mCashSales + mInvoices;
      const expense = mExpenses;
      const surplus = revenue - expense;

      return {
        period: slot.label,
        quarter: slot.q,
        Revenue: revenue,
        Expenses: expense,
        "Net Operating Surplus": surplus
      };
    });
  }, [expenses, cashSales, invoices]);

  // Aggregate by Quarter
  const quarterlyData = useMemo(() => {
    const qMap: Record<string, { Revenue: number; Expenses: number; "Net Operating Surplus": number }> = {};

    monthlyData.forEach(m => {
      const q = m.quarter;
      if (!qMap[q]) {
        qMap[q] = { Revenue: 0, Expenses: 0, "Net Operating Surplus": 0 };
      }
      qMap[q].Revenue += m.Revenue;
      qMap[q].Expenses += m.Expenses;
      qMap[q]["Net Operating Surplus"] += m["Net Operating Surplus"];
    });

    return Object.keys(qMap).map(q => ({
      period: q,
      quarter: q,
      Revenue: qMap[q].Revenue,
      Expenses: qMap[q].Expenses,
      "Net Operating Surplus": qMap[q]["Net Operating Surplus"]
    }));
  }, [monthlyData]);

  const activeChartData = viewMode === "monthly" ? monthlyData : quarterlyData;

  // Summary Metrics
  const totalRevenue = activeChartData.reduce((acc, d) => acc + d.Revenue, 0);
  const totalExpenses = activeChartData.reduce((acc, d) => acc + d.Expenses, 0);
  const netSurplus = totalRevenue - totalExpenses;
  const avgSurplus = activeChartData.length > 0 ? netSurplus / activeChartData.length : 0;
  const surplusMargin = totalRevenue > 0 ? (netSurplus / totalRevenue) * 100 : 0;

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5">
      {/* Header with View Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                Net Operating Surplus Trend
                <span className="text-[10px] normal-case bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                  (Revenue – Operating Expenses)
                </span>
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Live line trend chart visualizing net operating surplus generated from farm activities over time.
              </p>
            </div>
          </div>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setShowBreakdownBars(!showBreakdownBars)}
            className={`px-2.5 py-1 text-[11px] font-bold rounded-lg border transition-all ${
              showBreakdownBars 
                ? "bg-slate-100 text-slate-700 border-slate-300" 
                : "bg-white text-slate-400 border-slate-200 hover:text-slate-600"
            }`}
          >
            {showBreakdownBars ? "Hide Revenue/Expense Bars" : "Show Revenue/Expense Bars"}
          </button>
          
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setViewMode("monthly")}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                viewMode === "monthly"
                  ? "bg-white text-emerald-700 shadow-sm font-extrabold"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              📅 Monthly
            </button>
            <button
              type="button"
              onClick={() => setViewMode("quarterly")}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                viewMode === "quarterly"
                  ? "bg-white text-emerald-700 shadow-sm font-extrabold"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              📊 Quarterly
            </button>
          </div>
        </div>
      </div>

      {/* KPI Highlights */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Total Net Surplus</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-sm font-bold text-slate-600">{currencySymbol}</span>
            <span className={`text-lg font-black font-mono ${netSurplus >= 0 ? "text-emerald-700" : "text-rose-600"}`}>
              {netSurplus.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <span className="text-[9.5px] font-medium text-slate-400 mt-0.5 block">
            {netSurplus >= 0 ? "Positive operating cash surplus" : "Deficit operating position"}
          </span>
        </div>

        <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
            Avg {viewMode === "monthly" ? "Monthly" : "Quarterly"} Surplus
          </span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-sm font-bold text-slate-600">{currencySymbol}</span>
            <span className="text-lg font-black font-mono text-slate-800">
              {avgSurplus.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <span className="text-[9.5px] font-medium text-slate-400 mt-0.5 block">
            Per {viewMode === "monthly" ? "month" : "quarter"} average
          </span>
        </div>

        <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Surplus Margin</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className={`text-lg font-black font-mono ${surplusMargin >= 0 ? "text-emerald-700" : "text-rose-600"}`}>
              {surplusMargin.toFixed(1)}%
            </span>
          </div>
          <span className="text-[9.5px] font-medium text-slate-400 mt-0.5 block">
            Net surplus / gross revenue
          </span>
        </div>

        <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Operating Trend</span>
          <div className="flex items-center gap-1 mt-1 text-emerald-600 font-extrabold text-sm">
            {netSurplus >= 0 ? (
              <>
                <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700 font-black">Healthy Surplus</span>
              </>
            ) : (
              <>
                <ArrowDownRight className="w-4 h-4 text-rose-600" />
                <span className="text-rose-600 font-black">Needs Optimization</span>
              </>
            )}
          </div>
          <span className="text-[9.5px] font-medium text-slate-400 mt-0.5 block">
            Based on posted cashflow
          </span>
        </div>
      </div>

      {/* Chart Visualization */}
      <div className="h-80 w-full pt-2">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={activeChartData} margin={{ top: 15, right: 20, left: 10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis 
              dataKey="period" 
              stroke="#64748b" 
              tickLine={false}
              style={{ fontSize: 10, fontWeight: "bold" }} 
            />
            <YAxis 
              stroke="#64748b" 
              tickLine={false}
              axisLine={false}
              tickFormatter={(val) => `${currencySymbol}${val >= 1000 || val <= -1000 ? (val / 1000).toFixed(0) + "k" : val}`}
              style={{ fontSize: 10 }} 
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: "#0f172a", 
                borderColor: "#334155", 
                borderRadius: "12px", 
                color: "#f8fafc",
                fontSize: "11px",
                boxShadow: "0 10px 25px -5px rgba(0,0,0,0.3)"
              }} 
              formatter={(value: any, name: any) => [
                `${currencySymbol} ${Number(value).toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
                name
              ]}
            />
            <Legend 
              wrapperStyle={{ paddingTop: "12px", fontSize: "11px", fontWeight: "bold" }}
            />
            <ReferenceLine y={0} stroke="#94a3b8" strokeDasharray="4 4" />

            {showBreakdownBars && (
              <>
                <Bar dataKey="Revenue" fill="#10b981" opacity={0.35} radius={[4, 4, 0, 0]} barSize={22} />
                <Bar dataKey="Expenses" fill="#f43f5e" opacity={0.35} radius={[4, 4, 0, 0]} barSize={22} />
              </>
            )}

            <Line 
              type="monotone" 
              dataKey="Net Operating Surplus" 
              stroke="#059669" 
              strokeWidth={3.5}
              dot={{ r: 5, fill: "#059669", stroke: "#ffffff", strokeWidth: 2 }}
              activeDot={{ r: 8, fill: "#047857", stroke: "#ffffff", strokeWidth: 3 }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

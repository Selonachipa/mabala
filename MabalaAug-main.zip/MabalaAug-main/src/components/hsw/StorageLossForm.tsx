import React, { useState, useEffect } from "react";
import { 
  AlertTriangle, 
  UploadCloud, 
  Camera, 
  Trash2, 
  Check, 
  X, 
  FileText, 
  ShieldAlert, 
  DollarSign,
  Plus
} from "lucide-react";
import { StorageLot, StorageLoss } from "../../types";
import { HswService } from "../../services/hswService";
import { useToast } from "../Toast";

interface StorageLossFormProps {
  lot?: StorageLot;
  lotId?: string;
  isOpen: boolean;
  onClose: () => void;
  userEmail?: string;
  onLossLogged?: (loss: StorageLoss) => void;
}

export default function StorageLossForm({
  lot,
  lotId,
  isOpen,
  onClose,
  userEmail = "Farm Auditor",
  onLossLogged
}: StorageLossFormProps) {
  const showToast = useToast();

  const [taxonomyCauses, setTaxonomyCauses] = useState<string[]>([]);
  const [selectedCause, setSelectedCause] = useState<string>("pest");
  const [quantityLost, setQuantityLost] = useState<number | "">("");
  const [notes, setNotes] = useState("");
  const [photoUrls, setPhotoUrls] = useState<string[]>([]);
  const [newPhotoUrlInput, setNewPhotoUrlInput] = useState("");

  const activeLot = lot || (lotId ? HswService.getStorageLots().find(l => l.id === lotId) : undefined);

  // Load Super-Admin managed loss causes taxonomy on open
  useEffect(() => {
    if (isOpen) {
      const causes = HswService.getLossCausesTaxonomy();
      setTaxonomyCauses(causes);
      if (causes.length > 0) {
        setSelectedCause(causes[0]);
      }
    }
  }, [isOpen]);

  if (!isOpen || !activeLot) return null;

  const numQtyLost = Number(quantityLost) || 0;
  const pledgedQty = activeLot.pledge?.pledgedQuantity || 0;
  const maxDeductible = Math.max(0, activeLot.quantityCurrent - pledgedQty);
  const calculatedLossValue = numQtyLost * activeLot.valuationPricePerUnit;

  const isInvalid = numQtyLost <= 0 || numQtyLost > maxDeductible;

  // Handle Photo Upload (Base64 file upload or photo URL addition)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      reader.onloadend = () => {
        if (reader.result) {
          setPhotoUrls(prev => [...prev, reader.result as string]);
        }
      };
      reader.readAsDataURL(file);
    }
    e.target.value = "";
  };

  const handleAddPhotoUrl = () => {
    if (newPhotoUrlInput.trim()) {
      setPhotoUrls(prev => [...prev, newPhotoUrlInput.trim()]);
      setNewPhotoUrlInput("");
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotoUrls(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (numQtyLost <= 0) {
      showToast("Please enter a valid quantity lost", "error");
      return;
    }

    if (numQtyLost > maxDeductible) {
      showToast(`Cannot log ${numQtyLost} ${activeLot.unit}: Exceeds available unpledged balance of ${maxDeductible} ${activeLot.unit}!`, "error");
      return;
    }

    try {
      const res = HswService.logStorageLoss({
        lotId: activeLot.id,
        quantityLost: numQtyLost,
        causeCategory: selectedCause as StorageLoss["causeCategory"],
        notes,
        photos: photoUrls,
        loggedBy: userEmail
      });

      showToast(`Successfully logged ${numQtyLost} ${activeLot.unit} storage loss (${selectedCause})!`, "success");
      if (onLossLogged && res.loss) {
        onLossLogged(res.loss);
      }
      onClose();
    } catch (err: any) {
      showToast(err.message || "Failed to log storage loss", "error");
    }
  };

  // Helper label mapping
  const formatCauseLabel = (cause: string) => {
    const map: Record<string, string> = {
      pest: "🐛 Pest / Weevil Infestation",
      mould_moisture: "💧 Mould & Moisture Damage",
      theft: "🔒 Theft / Pilferage",
      spillage_handling: "⚖️ Spillage & Handling Loss",
      rodent: "🐀 Rodent Damage",
      quality_downgrade: "📉 Quality Downgrade",
      other: "❓ Other / Uncategorized"
    };
    return map[cause] || cause.replace(/_/g, " ").toUpperCase();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-scale-up">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-rose-900 via-rose-800 to-red-900 text-white flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 rounded-xl">
              <ShieldAlert className="w-5 h-5 text-rose-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm uppercase tracking-wider">Log Post-Harvest Storage Loss</h3>
              <p className="text-[11px] text-rose-200 font-medium">Lot #{activeLot.id} — {activeLot.cropType} ({activeLot.grade || activeLot.variety})</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/10 rounded-lg text-rose-200 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Lot Summary Box */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs space-y-1">
            <div className="flex justify-between items-center">
              <span className="font-extrabold text-slate-800">{activeLot.cropType} ({activeLot.grade})</span>
              <span className="font-mono text-emerald-800 font-bold">Intake Date: {new Date(activeLot.intakeDate).toLocaleDateString()}</span>
            </div>
            <div className="flex justify-between items-center text-[11px] text-slate-600">
              <span>Current Stock: <strong className="font-mono text-slate-900">{activeLot.quantityCurrent} {activeLot.unit}</strong></span>
              <span>Available (Unpledged): <strong className="font-mono text-emerald-700 font-bold">{maxDeductible} {activeLot.unit}</strong></span>
            </div>
          </div>

          {/* Super-Admin Managed Taxonomy Cause Selector */}
          <div>
            <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
              Select Loss Primary Cause (Taxonomy)
            </label>
            <select
              value={selectedCause}
              onChange={e => setSelectedCause(e.target.value)}
              className="w-full p-2.5 text-xs border rounded-xl bg-slate-50 focus:bg-white text-slate-800 font-bold outline-none focus:border-rose-500"
            >
              {taxonomyCauses.map(cause => (
                <option key={cause} value={cause}>
                  {formatCauseLabel(cause)}
                </option>
              ))}
            </select>
            <p className="text-[10px] text-slate-400 mt-1">Taxonomy cause classifications are synchronized with the Super-Admin Master Ledger.</p>
          </div>

          {/* Quantity Lost */}
          <div>
            <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
              Quantity Damaged / Lost ({activeLot.unit})
            </label>
            <input
              type="number"
              step="0.01"
              placeholder={`Max ${maxDeductible}`}
              value={quantityLost}
              onChange={e => setQuantityLost(e.target.value === "" ? "" : Number(e.target.value))}
              required
              className="w-full p-2.5 text-xs border rounded-xl font-mono font-bold bg-slate-50 focus:bg-white outline-none focus:border-rose-500"
            />
            {numQtyLost > maxDeductible && (
              <p className="text-[10px] text-rose-600 font-bold mt-1 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Deduction quantity exceeds available unpledged lot balance of {maxDeductible} {lot.unit}!
              </p>
            )}
          </div>

          {/* Value Impact Box */}
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex justify-between items-center text-xs">
            <span className="font-bold text-rose-900">Calculated Valuation Impact:</span>
            <span className="font-black font-mono text-rose-700 text-sm">
              ZMW {calculatedLossValue.toLocaleString("en-US", { minimumFractionDigits: 2 })}
            </span>
          </div>

          {/* Notes */}
          <div>
            <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
              Inspection Notes / Incident Details
            </label>
            <textarea
              rows={2}
              placeholder="Describe physical damage, location inside warehouse silo/bay, or pest evidence..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full p-2.5 text-xs border rounded-xl bg-slate-50 focus:bg-white outline-none focus:border-rose-500 text-slate-800"
            />
          </div>

          {/* Photo Attachments & Upload Section */}
          <div className="space-y-2">
            <label className="text-[10px] font-extrabold uppercase text-slate-500 block">
              Photo Evidence / Audit Attachments ({photoUrls.length} attached)
            </label>

            {/* Upload Buttons */}
            <div className="grid grid-cols-2 gap-2">
              <label className="flex items-center justify-center gap-2 p-2.5 border-2 border-dashed border-slate-300 hover:border-rose-500 rounded-xl bg-slate-50 hover:bg-rose-50/30 text-xs font-bold text-slate-600 cursor-pointer transition-all">
                <Camera className="w-4 h-4 text-rose-600" />
                <span>Upload Photos</span>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              <div className="flex gap-1">
                <input
                  type="url"
                  placeholder="Paste Image URL"
                  value={newPhotoUrlInput}
                  onChange={e => setNewPhotoUrlInput(e.target.value)}
                  className="w-full text-[11px] px-2 py-1 border rounded-lg bg-slate-50"
                />
                <button
                  type="button"
                  onClick={handleAddPhotoUrl}
                  className="px-2 py-1 bg-slate-800 text-white rounded-lg text-xs font-bold cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Photo Previews */}
            {photoUrls.length > 0 && (
              <div className="grid grid-cols-3 gap-2 pt-2">
                {photoUrls.map((url, idx) => (
                  <div key={idx} className="relative group rounded-xl overflow-hidden border border-slate-200 aspect-video bg-slate-100">
                    <img src={url} alt={`Evidence ${idx + 1}`} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => handleRemovePhoto(idx)}
                      className="absolute top-1 right-1 p-1 bg-rose-600 text-white rounded-full opacity-90 hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-2 pt-3 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isInvalid}
              className={`px-5 py-2 text-white text-xs font-black rounded-xl transition-all shadow-md flex items-center gap-1.5 ${
                isInvalid
                  ? "bg-slate-300 cursor-not-allowed"
                  : "bg-rose-700 hover:bg-rose-600 cursor-pointer active:scale-95"
              }`}
            >
              <Check className="w-4 h-4" />
              <span>Log Loss & Deduct Stock</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

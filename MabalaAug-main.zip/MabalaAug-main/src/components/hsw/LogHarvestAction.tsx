import React, { useState, useEffect } from "react";
import { 
  Sprout, 
  Calendar, 
  Award, 
  Boxes, 
  Plus, 
  Trash2, 
  Check, 
  X, 
  Warehouse as WarehouseIcon, 
  AlertTriangle,
  Sparkles,
  Layers
} from "lucide-react";
import { CropCycle, HarvestEvent, Warehouse, WarehouseReceipt } from "../../types";
import { HswService } from "../../services/hswService";
import { useToast } from "../Toast";

interface GradedItem {
  grade: string;
  quantity: number;
}

interface LogHarvestActionProps {
  cropCycle: CropCycle;
  isOpen: boolean;
  onClose: () => void;
  userEmail?: string;
  tenantId?: string;
  onHarvestLogged?: (event: HarvestEvent) => void;
}

export default function LogHarvestAction({
  cropCycle,
  isOpen,
  onClose,
  userEmail = "Farm Operator",
  tenantId = "tenant-01",
  onHarvestLogged
}: LogHarvestActionProps) {
  const showToast = useToast();

  const [harvestDate, setHarvestDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [quantityRaw, setQuantityRaw] = useState<number | "">("");
  const [unitRaw, setUnitRaw] = useState<string>("MT");

  // Graded breakdown items
  const [gradedBreakdown, setGradedBreakdown] = useState<GradedItem[]>([
    { grade: "Grade A Premium", quantity: 0 },
    { grade: "Grade B Standard", quantity: 0 },
    { grade: "Grade C Commercial", quantity: 0 }
  ]);

  // Warehouse Deposit Option
  const [depositToWarehouse, setDepositToWarehouse] = useState(true);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>("");

  useEffect(() => {
    if (isOpen) {
      const whs = HswService.getWarehouses();
      setWarehouses(whs);
      if (whs.length > 0) {
        setSelectedWarehouseId(whs[0].id);
      }
      if (cropCycle.harvestUnitName) {
        setUnitRaw(cropCycle.harvestUnitName === "Kg" ? "MT" : cropCycle.harvestUnitName);
      }
    }
  }, [isOpen, cropCycle]);

  if (!isOpen) return null;

  const numRawQty = Number(quantityRaw) || 0;
  const gradedSum = gradedBreakdown.reduce((acc, curr) => acc + (Number(curr.quantity) || 0), 0);

  const handleGradeQtyChange = (index: number, qty: number) => {
    setGradedBreakdown(prev => {
      const updated = [...prev];
      updated[index].quantity = Math.max(0, qty);
      return updated;
    });
  };

  const handleAddCustomGrade = () => {
    setGradedBreakdown(prev => [...prev, { grade: `Custom Grade ${prev.length + 1}`, quantity: 0 }]);
  };

  const handleRemoveGrade = (index: number) => {
    setGradedBreakdown(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (numRawQty <= 0) {
      showToast("Please enter a valid total raw harvest quantity", "error");
      return;
    }

    try {
      // Build breakdown array
      const gradedBreakdownList = gradedBreakdown
        .filter(item => item.grade && item.quantity > 0)
        .map(item => ({ grade: item.grade, qty: item.quantity, unit: unitRaw }));

      // 1. Save Harvest Event
      const harvestEvent = HswService.logHarvestEvent({
        cropCycleId: cropCycle.id,
        farmNodeId: cropCycle.fieldBlock || "farm-01",
        tenantId,
        cropType: cropCycle.cropType,
        variety: cropCycle.variety || "Standard Hybrid",
        harvestDate,
        quantityRaw: numRawQty,
        unitRaw,
        gradedBreakdown: gradedBreakdownList,
        bagCount: Math.ceil(numRawQty * (unitRaw === "MT" ? 20 : 1)),
        bagWeightKg: 50,
        moistureContent: 12.5,
        loggedBy: userEmail,
        photos: [],
        status: "confirmed"
      });

      // 2. If deposit to warehouse checked, create Storage Lot and Warehouse Receipt automatically
      if (depositToWarehouse && selectedWarehouseId) {
        const wh = warehouses.find(w => w.id === selectedWarehouseId);
        const lotId = `lot-harvest-${Date.now()}`;
        const valuationPrice = cropCycle.expectedSellingPricePerKg 
          ? cropCycle.expectedSellingPricePerKg * 1000 
          : 4200;

        const newLot = {
          id: lotId,
          farmNodeId: cropCycle.fieldBlock || "farm-01",
          tenantId,
          cropCycleId: cropCycle.id,
          harvestEventIds: [harvestEvent.id],
          warehouseId: selectedWarehouseId,
          cropType: cropCycle.cropType,
          variety: cropCycle.variety || "Standard Hybrid",
          grade: gradedBreakdownList[0]?.grade || "Grade A Premium",
          quantityIn: numRawQty,
          quantityCurrent: numRawQty,
          unit: unitRaw,
          valuationPriceSource: "MPB" as const,
          valuationPricePerUnit: valuationPrice,
          valuationCurrency: "ZMW",
          storedValueAtIntake: numRawQty * valuationPrice,
          storedValueCurrent: numRawQty * valuationPrice,
          intakeDate: harvestDate,
          status: "in_storage" as const,
          pledge: {
            pledgedTo: null,
            pledgeRef: null,
            pledgedQuantity: 0,
            pledgedAt: null,
            releasedAt: null
          },
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };

        const existingLots = HswService.getStorageLots();
        existingLots.unshift(newLot);
        HswService.saveStorageLots(existingLots);

        // Issue Warehouse Receipt
        const receiptNumber = `DWR-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
        const newReceipt: WarehouseReceipt = {
          id: `dwr-${Date.now()}`,
          receiptNumber,
          lotId: newLot.id,
          warehouseId: selectedWarehouseId,
          farmNodeId: cropCycle.fieldBlock || "farm-01",
          farmerUid: userEmail,
          tenantId,
          cropType: cropCycle.cropType,
          variety: cropCycle.variety || "Standard Hybrid",
          grade: newLot.grade,
          quantity: numRawQty,
          unit: unitRaw,
          valuePerUnitAtIssue: valuationPrice,
          totalValueAtIssue: numRawQty * valuationPrice,
          issuedDate: harvestDate,
          issuedBy: userEmail,
          negotiable: true,
          status: "active",
          pledgeHistory: [],
          withdrawalHistory: [],
          documentUrl: "",
          qrVerificationCode: `QR-${receiptNumber}`,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };

        const receipts = HswService.getWarehouseReceipts();
        receipts.unshift(newReceipt);
        HswService.saveWarehouseReceipts(receipts);

        showToast(`Harvest logged and Digital Warehouse Receipt #${receiptNumber} issued!`, "success");
      } else {
        showToast(`Logged harvest event of ${numRawQty} ${unitRaw}!`, "success");
      }

      if (onHarvestLogged) {
        onHarvestLogged(harvestEvent);
      }
      onClose();
    } catch (err: any) {
      showToast(err.message || "Failed to log harvest event", "error");
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-scale-up">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-emerald-800 to-green-900 text-white flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 rounded-xl">
              <Sprout className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm uppercase tracking-wider">Log Crop Harvest Event</h3>
              <p className="text-[11px] text-emerald-200 font-medium">{cropCycle.cropType} ({cropCycle.variety || "Block " + cropCycle.fieldBlock})</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/10 rounded-lg text-emerald-200 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Date and Raw Quantity */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
                Harvest Collection Date
              </label>
              <input
                type="date"
                value={harvestDate}
                onChange={e => setHarvestDate(e.target.value)}
                required
                className="w-full text-xs p-2.5 border rounded-xl bg-slate-50 focus:bg-white font-mono text-slate-800 font-bold outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
                Total Raw Quantity
              </label>
              <input
                type="number"
                step="0.01"
                placeholder="e.g. 50"
                value={quantityRaw}
                onChange={e => setQuantityRaw(e.target.value === "" ? "" : Number(e.target.value))}
                required
                className="w-full text-xs p-2.5 border rounded-xl font-mono font-bold bg-slate-50 focus:bg-white outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
                Unit Metric
              </label>
              <select
                value={unitRaw}
                onChange={e => setUnitRaw(e.target.value)}
                className="w-full text-xs p-2.5 border rounded-xl bg-slate-50 focus:bg-white font-bold text-slate-800 outline-none"
              >
                <option value="MT">Metric Tonnes (MT)</option>
                <option value="Kg">Kilograms (Kg)</option>
                <option value="Bags (50kg)">Bags (50kg)</option>
                <option value="Crates (25kg)">Crates (25kg)</option>
                <option value="Cobs">Cobs / Units</option>
              </select>
            </div>
          </div>

          {/* Graded Breakdown Section */}
          <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="flex justify-between items-center border-b pb-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                <Layers className="w-4 h-4 text-emerald-600" />
                <span>Graded Quality Breakdown ({unitRaw})</span>
              </div>
              <button
                type="button"
                onClick={handleAddCustomGrade}
                className="text-[10px] bg-emerald-100 hover:bg-emerald-200 text-emerald-800 font-bold px-2 py-1 rounded-lg flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                Add Grade
              </button>
            </div>

            <div className="space-y-2">
              {gradedBreakdown.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={item.grade}
                    onChange={e => {
                      const val = e.target.value;
                      setGradedBreakdown(prev => {
                        const updated = [...prev];
                        updated[idx].grade = val;
                        return updated;
                      });
                    }}
                    placeholder="Grade Name"
                    className="flex-1 text-xs p-2 border rounded-xl bg-white font-semibold text-slate-800"
                  />
                  <input
                    type="number"
                    step="0.01"
                    value={item.quantity}
                    onChange={e => handleGradeQtyChange(idx, Number(e.target.value))}
                    placeholder="Qty"
                    className="w-28 text-xs p-2 border rounded-xl bg-white font-mono font-bold text-slate-800"
                  />
                  {gradedBreakdown.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveGrade(idx)}
                      className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center text-xs font-mono font-bold text-slate-700 pt-1 border-t">
              <span>Total Graded Sum:</span>
              <span className={gradedSum > numRawQty ? "text-rose-600" : "text-emerald-700"}>
                {gradedSum} / {numRawQty} {unitRaw}
              </span>
            </div>
          </div>

          {/* Deposit to Warehouse Storage Option */}
          <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <WarehouseIcon className="w-5 h-5 text-emerald-700" />
                <div>
                  <span className="text-xs font-black text-slate-800 block">Deposit Directly into HSW Storage</span>
                  <span className="text-[10px] text-slate-500 block">Issues digital warehouse receipt and creates active lot</span>
                </div>
              </div>

              <input
                type="checkbox"
                checked={depositToWarehouse}
                onChange={e => setDepositToWarehouse(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded cursor-pointer"
              />
            </div>

            {depositToWarehouse && (
              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                  Target Warehouse / Silo Facility
                </label>
                <select
                  value={selectedWarehouseId}
                  onChange={e => setSelectedWarehouseId(e.target.value)}
                  className="w-full text-xs p-2.5 border rounded-xl bg-white font-bold text-slate-800 outline-none"
                >
                  {warehouses.map(w => (
                    <option key={w.id} value={w.id}>
                      {w.name} ({w.province}, {w.district}) — {w.certification.status.toUpperCase()}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-2 pt-3 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl transition-all shadow-md flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>Confirm & Log Harvest</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

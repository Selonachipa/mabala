import React, { useState, useEffect } from "react";
import { CropCycle, CropCycleVariance, HarvestEvent, StorageLot, Warehouse } from "../../types";
import { HswService } from "../../services/hswService";
import { 
  TrendingUp, 
  TrendingDown, 
  Sparkles, 
  Plus, 
  Layers, 
  Calendar, 
  AlertTriangle, 
  CheckCircle2, 
  Scale, 
  FileSpreadsheet, 
  ArrowRight,
  Boxes,
  HelpCircle
} from "lucide-react";
import { useToast } from "../Toast";

interface CropCycleVariancePanelProps {
  crops: CropCycle[];
  currencySymbol: string;
  onRefreshCrops?: () => void;
}

export default function CropCycleVariancePanel({
  crops,
  currencySymbol,
  onRefreshCrops
}: CropCycleVariancePanelProps) {
  const showToast = useToast();
  const [selectedCropId, setSelectedCropId] = useState<string>(crops.length > 0 ? crops[0].id : "");
  const [variances, setVariances] = useState<CropCycleVariance[]>([]);
  const [harvestEvents, setHarvestEvents] = useState<HarvestEvent[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);

  // Harvest Event Log Modal State
  const [showLogHarvestModal, setShowLogHarvestModal] = useState(false);
  const [rawQty, setRawQty] = useState<number>(20);
  const [unitRaw, setUnitRaw] = useState<string>("MT");
  const [gradeAQty, setGradeAQty] = useState<number>(15);
  const [gradeBQty, setGradeBQty] = useState<number>(5);
  const [bagCount, setBagCount] = useState<number>(400);
  const [bagWeightKg, setBagWeightKg] = useState<number>(50);
  const [moistureContent, setMoistureContent] = useState<number>(12.5);
  const [moveToStorage, setMoveToStorage] = useState(true);
  const [selectedWhId, setSelectedWhId] = useState<string>("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setVariances(HswService.getVariances());
    setHarvestEvents(HswService.getHarvestEvents());
    const whs = HswService.getWarehouses();
    setWarehouses(whs);
    if (whs.length > 0 && !selectedWhId) {
      setSelectedWhId(whs[0].id);
    }
  };

  const selectedCrop = crops.find(c => c.id === selectedCropId) || crops[0];

  // Get active variance for selected crop
  let activeVariance = variances.find(v => v.cropCycleId === selectedCropId);

  // Auto-generate if missing
  if (!activeVariance && selectedCrop) {
    activeVariance = HswService.generateVarianceRecord(selectedCrop);
  }

  const cropHarvestEvents = harvestEvents.filter(e => e.cropCycleId === selectedCropId);

  const handleLogHarvestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCrop) return;

    try {
      // 1. Log Harvest Event
      const harvestData: Omit<HarvestEvent, "id" | "createdAt" | "updatedAt"> = {
        cropCycleId: selectedCrop.id,
        farmNodeId: "farm-01",
        tenantId: "tenant-01",
        cropType: selectedCrop.cropName || "Maize",
        variety: selectedCrop.variety || "Hybrid Seed",
        harvestDate: new Date().toISOString().split("T")[0],
        quantityRaw: rawQty,
        unitRaw,
        gradedBreakdown: [
          { grade: "Grade A Premium", qty: gradeAQty, unit: unitRaw },
          { grade: "Grade B Standard", qty: gradeBQty, unit: unitRaw }
        ],
        bagCount,
        bagWeightKg,
        moistureContent,
        loggedBy: "Farm Manager",
        photos: [],
        status: "confirmed"
      };

      const hEvent = HswService.logHarvestEvent(harvestData);

      // 2. Confirm & create storage lot
      HswService.confirmHarvestEvent(hEvent.id, moveToStorage, selectedWhId);

      // 3. Re-calculate Variance
      HswService.generateVarianceRecord(selectedCrop);

      showToast("Harvest event logged & variance model updated!", "success");
      setShowLogHarvestModal(false);
      loadData();
      if (onRefreshCrops) onRefreshCrops();
    } catch (err: any) {
      showToast(err.message || "Failed to log harvest event", "error");
    }
  };

  const handleRegenerateAi = () => {
    if (!selectedCrop) return;
    HswService.generateVarianceRecord(selectedCrop);
    loadData();
    showToast("Mabala AI agronomic variance analysis refreshed!", "success");
  };

  if (crops.length === 0) {
    return (
      <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center">
        <Layers className="w-10 h-10 text-slate-300 mx-auto mb-2" />
        <h3 className="font-bold text-slate-800">No Crop Cycles Found</h3>
        <p className="text-xs text-slate-500 mt-1">Please create a crop cycle first in the Crop Cycle module.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Selector Strip */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <span className="text-[10px] font-black uppercase text-emerald-800 tracking-wider">HSW Module Phase 2</span>
          <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6 text-emerald-800" />
            Crop Cycle Harvest & Variance Engine
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Compares projected vs actual harvest volumes, incorporates post-harvest losses, and generates AI driver classification.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedCropId}
            onChange={(e) => setSelectedCropId(e.target.value)}
            className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs text-slate-800 outline-none focus:border-emerald-600"
          >
            {crops.map(c => (
              <option key={c.id} value={c.id}>
                {c.cropName} ({c.stage || "Active"})
              </option>
            ))}
          </select>

          <button
            onClick={() => setShowLogHarvestModal(true)}
            className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Log Harvest Event
          </button>
        </div>
      </div>

      {/* Variance Dashboard Grid */}
      {activeVariance && (
        <div className="space-y-6">
          {/* Top Metric Comparison Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="text-xs font-bold text-slate-400">Planned Projection</div>
              <div className="text-xl font-black text-slate-900 mt-1">
                {activeVariance.projectedYield} {activeVariance.projectedYieldUnit}
              </div>
              <div className="text-[11px] font-bold text-slate-500 mt-0.5">
                Target Revenue: {currencySymbol} {activeVariance.projectedRevenue.toLocaleString()}
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="text-xs font-bold text-slate-400">Actual Raw Harvest</div>
              <div className="text-xl font-black text-emerald-800 mt-1">
                {activeVariance.actualHarvestQty} {activeVariance.projectedYieldUnit}
              </div>
              <div className="text-[11px] font-bold text-emerald-700 mt-0.5">
                Gross Harvest Value: {currencySymbol} {activeVariance.actualHarvestValue.toLocaleString()}
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="text-xs font-bold text-slate-400">Post-Harvest Storage Loss</div>
              <div className="text-xl font-black text-rose-600 mt-1">
                -{activeVariance.postHarvestLossQty} {activeVariance.projectedYieldUnit}
              </div>
              <div className="text-[11px] font-bold text-rose-500 mt-0.5">
                Value Deduction: -{currencySymbol} {activeVariance.postHarvestLossValue.toLocaleString()}
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="text-xs font-bold text-slate-400">Net Volume Variance</div>
              <div className={`text-xl font-black mt-1 flex items-center gap-1 ${
                activeVariance.classification === 'surplus' ? 'text-emerald-800' :
                activeVariance.classification === 'deficit' ? 'text-rose-600' : 'text-slate-800'
              }`}>
                {activeVariance.varianceQty >= 0 ? `+${activeVariance.varianceQty}` : activeVariance.varianceQty} {activeVariance.projectedYieldUnit}
                <span className="text-xs">({activeVariance.variancePct.toFixed(1)}%)</span>
              </div>
              <div className="text-[11px] font-bold text-slate-500 mt-0.5 uppercase">
                {activeVariance.classification.replace("_", " ")}
              </div>
            </div>
          </div>

          {/* AI Insight Card */}
          <div className="bg-gradient-to-br from-slate-900 to-teal-950 text-white p-6 rounded-2xl shadow-lg relative overflow-hidden space-y-4">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-500/20 rounded-xl text-emerald-400 border border-emerald-500/30">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Mabala AI Agronomic Variance Analysis</h3>
                  <div className="text-[11px] text-slate-400 font-medium">
                    Model: {activeVariance.aiInsight.modelRef} • Driver Type: <span className="text-amber-300 uppercase font-black">{activeVariance.aiInsight.driverType}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleRegenerateAi}
                className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl border border-white/10 transition-all flex items-center gap-1 cursor-pointer"
              >
                Refresh AI Insight
              </button>
            </div>

            <p className="text-sm font-medium text-slate-200 bg-white/5 p-4 rounded-xl border border-white/10 leading-relaxed">
              "{activeVariance.aiInsight.summary}"
            </p>

            {/* Likely Cause Tags */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-300">Identified Agronomic & Post-Harvest Drivers:</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {activeVariance.aiInsight.likelyCauses.map((cause, idx) => (
                  <div key={idx} className="bg-white/5 p-3 rounded-xl border border-white/10 text-xs">
                    <span className="px-2 py-0.5 bg-amber-400/20 text-amber-300 font-extrabold rounded-md border border-amber-400/30 text-[10px] uppercase block w-max mb-1">
                      {cause.tag}
                    </span>
                    <span className="text-slate-300 font-medium">{cause.description}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recorded Harvest Events Table */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <h3 className="text-base font-bold text-slate-900">Recorded Field Harvest Events</h3>

            {cropHarvestEvents.length === 0 ? (
              <div className="p-6 text-center bg-slate-50 rounded-xl border border-dashed border-slate-300 text-xs text-slate-500 font-medium">
                No individual harvest events logged yet for this crop cycle. Click "Log Harvest Event" above to log bags, moisture content, and quality grades.
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {cropHarvestEvents.map(event => (
                  <div key={event.id} className="py-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs">
                    <div>
                      <div className="font-extrabold text-slate-900">
                        {event.quantityRaw} {event.unitRaw} ({event.cropType} - {event.variety})
                      </div>
                      <div className="text-slate-500 font-medium mt-0.5">
                        Date: {event.harvestDate} • Moisture: <strong className="text-slate-700">{event.moistureContent}%</strong> • Bags: {event.bagCount} x {event.bagWeightKg}kg
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 font-black rounded-full text-[10px] uppercase">
                        ✓ CONFIRMED & STORED
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* LOG HARVEST MODAL */}
      {showLogHarvestModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-black text-slate-900">Log Field Harvest Event</h3>
            <p className="text-xs text-slate-500 font-medium">
              Record harvested yield, bag counts, moisture test, and automatically route into on-farm or certified storage.
            </p>

            <form onSubmit={handleLogHarvestSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Total Quantity Raw</label>
                  <input
                    type="number"
                    value={rawQty}
                    onChange={(e) => setRawQty(parseFloat(e.target.value) || 0)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Unit</label>
                  <select
                    value={unitRaw}
                    onChange={(e) => setUnitRaw(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                  >
                    <option value="MT">Metric Tons (MT)</option>
                    <option value="Bags (50kg)">Bags (50kg)</option>
                    <option value="Crates (25kg)">Crates (25kg)</option>
                  </select>
                </div>
              </div>

              {/* Graded Breakdown */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="text-xs font-bold text-slate-800">Quality Graded Breakdown</div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block">Grade A Qty ({unitRaw})</label>
                    <input
                      type="number"
                      value={gradeAQty}
                      onChange={(e) => setGradeAQty(parseFloat(e.target.value) || 0)}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block">Grade B Qty ({unitRaw})</label>
                    <input
                      type="number"
                      value={gradeBQty}
                      onChange={(e) => setGradeBQty(parseFloat(e.target.value) || 0)}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* Moisture & Bags */}
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Moisture %</label>
                  <input
                    type="number"
                    step="0.1"
                    value={moistureContent}
                    onChange={(e) => setMoistureContent(parseFloat(e.target.value) || 0)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Bag Count</label>
                  <input
                    type="number"
                    value={bagCount}
                    onChange={(e) => setBagCount(parseInt(e.target.value) || 0)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Bag Weight (kg)</label>
                  <input
                    type="number"
                    value={bagWeightKg}
                    onChange={(e) => setBagWeightKg(parseInt(e.target.value) || 50)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              {/* Storage Destination */}
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 space-y-2">
                <label className="flex items-center gap-2 text-xs font-bold text-emerald-950 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={moveToStorage}
                    onChange={(e) => setMoveToStorage(e.target.checked)}
                    className="rounded text-emerald-800"
                  />
                  Automatically intake harvested crop into storage warehouse
                </label>

                {moveToStorage && (
                  <div>
                    <label className="text-[11px] font-bold text-emerald-900 block mb-1">Target Warehouse</label>
                    <select
                      value={selectedWhId}
                      onChange={(e) => setSelectedWhId(e.target.value)}
                      className="w-full p-2 bg-white border border-emerald-300 rounded-lg text-xs font-bold text-slate-800"
                    >
                      {warehouses.map(w => (
                        <option key={w.id} value={w.id}>
                          {w.name} ({w.ownerType === "certified_third_party" ? "Certified Silo" : "On-Farm"})
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowLogHarvestModal(false)}
                  className="px-4 py-2 bg-slate-200 text-slate-800 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-800 text-white text-xs font-black rounded-xl hover:bg-emerald-700 cursor-pointer"
                >
                  Confirm Harvest Event
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

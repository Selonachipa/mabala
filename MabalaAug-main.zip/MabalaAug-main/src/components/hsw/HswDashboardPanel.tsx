import React, { useState, useEffect } from "react";
import { 
  Warehouse, 
  StorageLot, 
  WarehouseReceipt, 
  StorageLoss, 
  CropCycle, 
  CashSale,
  Farm
} from "../../types";
import { HswService } from "../../services/hswService";
import { PledgeCropsModal, PledgeRecord } from "./PledgeCropsModal";
import { 
  Boxes, 
  Warehouse as WarehouseIcon, 
  QrCode, 
  FileText, 
  AlertTriangle, 
  Plus, 
  Search, 
  CheckCircle2, 
  ShieldAlert, 
  DollarSign, 
  TrendingDown, 
  Lock, 
  Unlock, 
  Share2, 
  Printer, 
  Layers, 
  Filter, 
  Clock, 
  RefreshCw,
  Building,
  Building2,
  Calendar,
  Check,
  Eye,
  Settings
} from "lucide-react";
import { useToast } from "../Toast";
import StorageLossForm from "./StorageLossForm";
import { getPreRegisteredClients } from "../sales/NewSaleModal";

interface HswDashboardPanelProps {
  activeFarm?: Farm;
  currencySymbol?: string;
  crops?: CropCycle[];
  isSuperAdmin?: boolean;
  userEmail?: string;
  tenantId?: string;
  onRecordSale?: (sale: CashSale) => void;
  onNavigateToAgc?: () => void;
}

export default function HswDashboardPanel({
  activeFarm,
  currencySymbol = "ZMW",
  crops = [],
  isSuperAdmin = false,
  userEmail = "",
  tenantId = "tenant-01",
  onRecordSale,
  onNavigateToAgc
}: HswDashboardPanelProps) {
  const showToast = useToast();
  const [activeTab, setActiveTab] = useState<"lots" | "dwr" | "warehouses" | "operator" | "losses" | "qr_verify" | "admin">("lots");

  // State
  const [lots, setLots] = useState<StorageLot[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [receipts, setReceipts] = useState<WarehouseReceipt[]>([]);
  const [losses, setLosses] = useState<StorageLoss[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCropFilter, setSelectedCropFilter] = useState("all");

  // Modals
  const [selectedLotForLoss, setSelectedLotForLoss] = useState<StorageLot | null>(null);
  const [selectedLotForSale, setSelectedLotForSale] = useState<StorageLot | null>(null);
  const [selectedDwrForView, setSelectedDwrForView] = useState<WarehouseReceipt | null>(null);
  const [selectedLotForPledge, setSelectedLotForPledge] = useState<StorageLot | null>(null);
  const [selectedWhForIntake, setSelectedWhForIntake] = useState<StorageLot | null>(null);

  // Form states
  // Loss form
  const [lossQty, setLossQty] = useState<number>(0);
  const [lossCause, setLossCause] = useState<StorageLoss["causeCategory"]>("pest");
  const [lossNotes, setLossNotes] = useState<string>("");

  // Sale form
  const [saleQty, setSaleQty] = useState<number>(0);
  const [salePricePerUnit, setSalePricePerUnit] = useState<number>(0);
  const [saleCustomer, setSaleCustomer] = useState<string>("");
  const [hswSaleUnitMode, setHswSaleUnitMode] = useState<"bags" | "units">("bags");
  const [hswBagsCount, setHswBagsCount] = useState<number>(0);
  const [hswKgPerBag, setHswKgPerBag] = useState<number>(50);
  const [hswPricePerBag, setHswPricePerBag] = useState<number>(0);

  // Pledge form
  const [pledgeLoanId, setPledgeLoanId] = useState<string>("");
  const [pledgeAmount, setPledgeAmount] = useState<number>(0);
  const [showPledgeCropsModal, setShowPledgeCropsModal] = useState<boolean>(false);
  const [pledgedRecords, setPledgedRecords] = useState<PledgeRecord[]>([]);

  // Intake form
  const [intakeQty, setIntakeQty] = useState<number>(0);
  const [intakeGrade, setIntakeGrade] = useState<string>("Grade A Premium");

  // Add Warehouse form
  const [showAddWhModal, setShowAddWhModal] = useState(false);
  const [newWhName, setNewWhName] = useState("");
  const [newWhType, setNewWhType] = useState<"farm_on_site" | "certified_third_party">("farm_on_site");
  const [newWhProvince, setNewWhProvince] = useState("Central");
  const [newWhDistrict, setNewWhDistrict] = useState("Chisamba");

  // QR Verify Tool State
  const [qrInputCode, setQrInputCode] = useState("");
  const [qrResult, setQrResult] = useState<any>(null);

  // Admin Config State
  const [minCohortInput, setMinCohortInput] = useState<number>(HswService.getMinCohortSize());

  const farmId = activeFarm?.id || "farm-01";

  // Reload data
  const loadData = () => {
    const currentTenant = tenantId || "tenant-01";
    const currentFarmNode = activeFarm?.id || farmId;
    setLots(HswService.getStorageLots(currentTenant, currentFarmNode));
    setWarehouses(HswService.getWarehouses(currentTenant));
    setReceipts(HswService.getWarehouseReceipts(currentTenant, currentFarmNode));
    setLosses(HswService.getStorageLosses(currentTenant, currentFarmNode));
    setPledgedRecords(HswService.getPledgedRecords(currentTenant, currentFarmNode));
  };

  useEffect(() => {
    loadData();
  }, [tenantId, activeFarm?.id]);

  const nearMaturityPledges = pledgedRecords.filter(p => {
    if (p.status !== "active_pledge") return false;
    const days = HswService.getDaysToMaturity(p.maturityDate);
    return days <= 30;
  });

  const handleExtendTenure = (pledgeId: string) => {
    const updated = HswService.extendPledgeTenure(pledgeId, 30);
    if (updated) {
      showToast(`Pledge ${pledgeId} tenure extended by +30 days. New maturity date: ${updated.maturityDate}`, "success");
      loadData();
    }
  };

  const handleReleasePledge = (pledgeId: string) => {
    const updated = HswService.releasePledge(pledgeId);
    if (updated) {
      showToast(`Pledged collateral ${pledgeId} released from encumbrance.`, "success");
      loadData();
    }
  };

  // Filtered Lots
  const filteredLots = lots.filter(lot => {
    const matchesSearch = lot.cropType.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          lot.variety.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          lot.grade.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCrop = selectedCropFilter === "all" || lot.cropType === selectedCropFilter;
    return matchesSearch && matchesCrop;
  });

  // Calculate Metrics
  const totalStoredValue = lots
    .filter(l => l.status === "in_storage" || l.status === "partially_sold" || l.status === "pledged")
    .reduce((sum, l) => sum + l.storedValueCurrent, 0);

  const totalQtyMT = lots
    .filter(l => l.status === "in_storage" || l.status === "partially_sold" || l.status === "pledged")
    .reduce((sum, l) => sum + l.quantityCurrent, 0);

  const pledgedLotsCount = lots.filter(l => l.status === "pledged").length;
  const pendingIntakeCount = lots.filter(l => l.status === "pending_intake").length;

  // Actions
  const handleLogLoss = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLotForLoss) return;
    try {
      HswService.logStorageLoss({
        lotId: selectedLotForLoss.id,
        quantityLost: lossQty,
        causeCategory: lossCause,
        notes: lossNotes,
        loggedBy: userEmail || "Farm Manager"
      });
      showToast("Post-harvest loss logged successfully and deducted from inventory", "success");
      setSelectedLotForLoss(null);
      setLossQty(1);
      setLossNotes("");
      loadData();
    } catch (err: any) {
      showToast(err.message || "Failed to log loss", "error");
    }
  };

  const handleSellFromStorage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLotForSale) return;

    const effectiveQty = hswSaleUnitMode === "bags" ? (hswBagsCount * hswKgPerBag) : saleQty;
    const effectiveUnitPrice = hswSaleUnitMode === "bags" ? (hswPricePerBag / (hswKgPerBag || 1)) : salePricePerUnit;

    try {
      const res = HswService.sellFromStorage({
        lotId: selectedLotForSale.id,
        quantitySold: effectiveQty,
        salePricePerUnit: effectiveUnitPrice,
        bagsSold: hswSaleUnitMode === "bags" ? hswBagsCount : undefined,
        weightPerBagKg: hswSaleUnitMode === "bags" ? hswKgPerBag : undefined,
        customerName: saleCustomer || "Zambezi Grain Millers Ltd",
        loggedBy: userEmail || "Farm Manager",
        tenantId,
        farmId
      });
      if (onRecordSale && res.sale) {
        onRecordSale(res.sale);
      }
      const msg = hswSaleUnitMode === "bags" 
        ? `Successfully sold ${hswBagsCount} bags (${effectiveQty} kg total) to ${saleCustomer || "pre-registered client"}!`
        : `Successfully sold ${effectiveQty} ${selectedLotForSale.unit} from storage!`;

      showToast(msg, "success");
      setSelectedLotForSale(null);
      loadData();
    } catch (err: any) {
      showToast(err.message || "Failed to sell from storage", "error");
    }
  };

  const handlePledgeForAgc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLotForPledge) return;
    try {
      const r = receipts.find(rec => rec.lotId === selectedLotForPledge.id);
      if (!r) {
        showToast("No warehouse receipt found for this lot. Cannot pledge.", "error");
        return;
      }
      HswService.pledgeDWRForAGCOffset(r.id, pledgeLoanId, pledgeAmount);
      showToast("Warehouse Receipt soft-pledged for AGC loan offset successfully", "success");
      setSelectedLotForPledge(null);
      loadData();
    } catch (err: any) {
      showToast(err.message || "Pledge failed", "error");
    }
  };

  const handleConfirmIntake = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWhForIntake) return;
    try {
      HswService.confirmWarehouseIntake(selectedWhForIntake.id, {
        finalQty: intakeQty,
        qualityGrade: intakeGrade,
        operatorUid: userEmail || "Operator"
      });
      showToast("Warehouse intake confirmed & Negotiable DWR issued!", "success");
      setSelectedWhForIntake(null);
      loadData();
    } catch (err: any) {
      showToast(err.message || "Intake confirmation failed", "error");
    }
  };

  const handleAddWarehouse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWhName) return;
    const allWh = HswService.getWarehouses();
    const newWh: Warehouse = {
      id: `wh-custom-${Date.now()}`,
      ownerType: newWhType,
      name: newWhName,
      province: newWhProvince,
      district: newWhDistrict,
      gpsLat: -15.3,
      gpsLng: 28.3,
      operatorTenantId: newWhType === "certified_third_party" ? tenantId : null,
      certification: {
        status: newWhType === "certified_third_party" ? "pending" : "uncertified",
        licenseNumber: newWhType === "certified_third_party" ? "PENDING-LICENSE" : "",
        certifyingAuthority: newWhType === "certified_third_party" ? "ZAMACE" : "On-Farm Self",
        certificationDocs: [],
        certifiedBy: null,
        certifiedAt: null
      },
      capacityByCrop: [{ cropType: "Maize", capacityQty: 1000, unit: "MT" }],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    allWh.unshift(newWh);
    HswService.saveWarehouses(allWh);
    showToast("New warehouse registered successfully", "success");
    setShowAddWhModal(false);
    setNewWhName("");
    loadData();
  };

  const handleQrLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!qrInputCode.trim()) return;
    const res = HswService.verifyDWRByQR(qrInputCode.trim());
    setQrResult(res);
  };

  const handleToggleCertification = (whId: string, targetStatus: "certified" | "uncertified" | "pending") => {
    if (!isSuperAdmin) {
      showToast("Super-Admin permission required to alter warehouse certification", "error");
      return;
    }
    const allWh = HswService.getWarehouses();
    const idx = allWh.findIndex(w => w.id === whId);
    if (idx !== -1) {
      allWh[idx].certification.status = targetStatus;
      allWh[idx].certification.certifiedBy = userEmail || "Super Admin";
      allWh[idx].certification.certifiedAt = new Date().toISOString();
      HswService.saveWarehouses(allWh);
      showToast(`Warehouse certification status set to ${targetStatus}`, "success");
      loadData();
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="bg-white text-slate-900 rounded-3xl p-6 sm:p-8 shadow-xs border border-slate-200/80 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-50 text-emerald-800 border border-emerald-200/80 uppercase tracking-wider">
                HSW Engine Live
              </span>
              <span className="text-xs text-slate-500 font-semibold">• Harvest, Storage & Digital Receipts</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Boxes className="w-7 h-7 text-emerald-600" />
              Harvest Storage & Warehouse Receipts
            </h1>
            <p className="text-slate-500 text-xs md:text-sm mt-1 max-w-2xl font-medium">
              Track harvested lots, manage certified & on-farm warehouses, issue electronic Digital Warehouse Receipts (DWR), log post-harvest losses, and pledge crop collateral for loan offsets.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setQrInputCode("QR-MABALA-DWR-883921");
                setActiveTab("qr_verify");
              }}
              className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <QrCode className="w-4 h-4 text-white" />
              Verify DWR QR
            </button>
            <button
              onClick={() => setShowAddWhModal(true)}
              className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 font-bold rounded-xl text-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4 text-slate-700" />
              Register Warehouse
            </button>
          </div>
        </div>

        {/* Top Summary Metrics Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-100">
          <div className="bg-slate-50/90 p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between text-[11px] font-extrabold uppercase tracking-wider text-slate-500 mb-1">
              <span>Total Stored Valuation</span>
              <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
                <DollarSign className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-xl font-black text-emerald-700 mt-0.5 font-mono">
              {currencySymbol} {totalStoredValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">Balance Sheet Asset Line</div>
          </div>

          <div className="bg-slate-50/90 p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between text-[11px] font-extrabold uppercase tracking-wider text-slate-500 mb-1">
              <span>Total Volume in Storage</span>
              <div className="p-1.5 rounded-lg bg-teal-50 text-teal-700">
                <Boxes className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-xl font-black text-slate-900 mt-0.5">
              {totalQtyMT.toLocaleString()} MT / Units
            </div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">{lots.length} active storage lots</div>
          </div>

          <div className="bg-slate-50/90 p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between text-[11px] font-extrabold uppercase tracking-wider text-slate-500 mb-1">
              <span>Pledged Collateral</span>
              <div className="p-1.5 rounded-lg bg-amber-50 text-amber-700">
                <Lock className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-xl font-black text-amber-700 mt-0.5 flex items-center justify-between gap-1">
              <span>{pledgedRecords.filter(p => p.status === "active_pledge").length} Active</span>
              {nearMaturityPledges.length > 0 && (
                <span className="text-[9px] font-black bg-rose-600 text-white px-2 py-0.5 rounded-full flex items-center gap-1 shrink-0">
                  <AlertTriangle className="w-3 h-3" />
                  {nearMaturityPledges.length} Near Due
                </span>
              )}
            </div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">Encumbered under DWR</div>
          </div>

          <div className="bg-slate-50/90 p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between text-[11px] font-extrabold uppercase tracking-wider text-slate-500 mb-1">
              <span>Pending Operator Intake</span>
              <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-700">
                <Clock className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-xl font-black text-indigo-700 mt-0.5">
              {pendingIntakeCount} Lots
            </div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">Certified Silo Intake Queue</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-200 overflow-x-auto gap-1 bg-white p-1 rounded-xl shadow-xs">
        <button
          onClick={() => setActiveTab("lots")}
          className={`px-4 py-2.5 text-xs font-bold rounded-lg transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === "lots"
              ? "bg-emerald-800 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          <Boxes className="w-4 h-4" />
          Active Storage Lots ({lots.length})
        </button>

        <button
          onClick={() => setActiveTab("dwr")}
          className={`px-4 py-2.5 text-xs font-bold rounded-lg transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === "dwr"
              ? "bg-emerald-800 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Warehouse Receipts (DWR) ({receipts.length})</span>
          {nearMaturityPledges.length > 0 && (
            <span className="px-2 py-0.5 bg-red-600 text-white font-black rounded-full text-[10px] animate-pulse flex items-center gap-1 shadow-xs">
              <AlertTriangle className="w-3 h-3" />
              {nearMaturityPledges.length} Due Soon
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab("warehouses")}
          className={`px-4 py-2.5 text-xs font-bold rounded-lg transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === "warehouses"
              ? "bg-emerald-800 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          <WarehouseIcon className="w-4 h-4" />
          Warehouses & Silos ({warehouses.length})
        </button>

        <button
          onClick={() => setActiveTab("operator")}
          className={`px-4 py-2.5 text-xs font-bold rounded-lg transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === "operator"
              ? "bg-emerald-800 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          <Building className="w-4 h-4" />
          Operator Intake Portal
          {pendingIntakeCount > 0 && (
            <span className="px-1.5 py-0.5 bg-amber-400 text-slate-950 font-black rounded-full text-[10px]">
              {pendingIntakeCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab("losses")}
          className={`px-4 py-2.5 text-xs font-bold rounded-lg transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === "losses"
              ? "bg-emerald-800 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          <TrendingDown className="w-4 h-4" />
          Storage Loss Log ({losses.length})
        </button>

        <button
          onClick={() => setActiveTab("qr_verify")}
          className={`px-4 py-2.5 text-xs font-bold rounded-lg transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === "qr_verify"
              ? "bg-emerald-800 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          <QrCode className="w-4 h-4" />
          Public QR Verification
        </button>

        {isSuperAdmin && (
          <button
            onClick={() => setActiveTab("admin")}
            className={`px-4 py-2.5 text-xs font-bold rounded-lg transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === "admin"
                ? "bg-slate-900 text-amber-300 shadow-xs"
                : "text-amber-700 bg-amber-50 hover:bg-amber-100"
            }`}
          >
            <Settings className="w-4 h-4" />
            Super Admin Governance
          </button>
        )}
      </div>

      {/* DWR PLEDGED CROP MATURITY WARNING ALERT BANNER */}
      {nearMaturityPledges.length > 0 && (
        <div className="bg-gradient-to-r from-red-500/10 via-amber-500/15 to-red-500/10 border-2 border-red-500/40 rounded-2xl p-4 md:p-5 shadow-lg space-y-4 relative overflow-hidden animate-in fade-in duration-200">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-red-200/60 pb-3">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-red-600 text-white rounded-xl shadow-xs shrink-0 animate-bounce">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 bg-red-600 text-white text-[10px] font-black uppercase tracking-wider rounded-full shadow-2xs">
                    DWR Warning System
                  </span>
                  <span className="text-xs text-red-700 font-extrabold font-mono">
                    30-Day Pledged Collateral Maturity Alert
                  </span>
                </div>
                <h3 className="text-base font-black text-slate-900 mt-1">
                  ⚠️ {nearMaturityPledges.length} Pledged Crop Batch{nearMaturityPledges.length > 1 ? "es" : ""} Within 30 Days of Maturity
                </h3>
                <p className="text-xs text-slate-600 font-medium mt-0.5">
                  Notice: The pledged crop inventory batches listed below under Digital Warehouse Receipts (DWR) are approaching loan maturity date. Settle credit, extend tenure, or release encumbrance to prevent statutory liquidation under Zambia WRA rules.
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab("dwr")}
              className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 self-start md:self-auto shrink-0 cursor-pointer"
            >
              <Lock className="w-4 h-4" />
              <span>Manage DWR Collateral</span>
            </button>
          </div>

          {/* Batch Warning Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {nearMaturityPledges.map((p) => {
              const daysLeft = HswService.getDaysToMaturity(p.maturityDate);
              const isUrgent = daysLeft <= 14;
              const isOverdue = daysLeft < 0;

              return (
                <div
                  key={p.id}
                  className={`p-3.5 rounded-xl border bg-white shadow-xs space-y-2.5 relative transition-all ${
                    isOverdue
                      ? "border-red-600 ring-2 ring-red-500/20 bg-red-50/30"
                      : isUrgent
                      ? "border-red-400 ring-1 ring-red-400/30"
                      : "border-amber-300"
                  }`}
                >
                  <div className="flex justify-between items-center gap-2">
                    <span className="font-mono text-xs font-black text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                      {p.id}
                    </span>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1 ${
                        isOverdue
                          ? "bg-red-600 text-white animate-pulse"
                          : isUrgent
                          ? "bg-red-100 text-red-800 border border-red-300"
                          : "bg-amber-100 text-amber-900 border border-amber-300"
                      }`}
                    >
                      <AlertTriangle className="w-3 h-3" />
                      {isOverdue
                        ? `OVERDUE (${Math.abs(daysLeft)}d ago)`
                        : `${daysLeft} Days Remaining`}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <div className="text-xs font-black text-slate-900">
                      {p.quantityPledged} {p.unit} of {p.cropType} ({p.variety})
                    </div>
                    <div className="text-[11px] text-slate-600 flex justify-between">
                      <span>Lender: <strong className="text-slate-800">{p.lenderName}</strong></span>
                      <span className="font-mono font-bold text-slate-700">LTV {p.ltvRatio}%</span>
                    </div>
                    <div className="text-[11px] text-slate-600 flex justify-between">
                      <span>Receipt #: <span className="font-mono font-bold">{p.receiptNumber}</span></span>
                      <span className="text-red-700 font-bold">Maturity: {p.maturityDate}</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center text-[11px] font-mono text-slate-700 bg-slate-50 p-2 rounded-lg border border-slate-100">
                    <span>Collateral: {currencySymbol} {p.totalCollateralValue.toLocaleString()}</span>
                    <span className="font-bold text-emerald-700">Loan: {currencySymbol} {p.requestedLoanAmount.toLocaleString()}</span>
                  </div>

                  <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                    <button
                      onClick={() => handleExtendTenure(p.id)}
                      className="flex-1 py-1.5 px-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-lg text-[11px] transition-all flex items-center justify-center gap-1 cursor-pointer"
                      title="Extend pledge maturity date by 30 days"
                    >
                      <Calendar className="w-3 h-3" />
                      <span>Extend +30d</span>
                    </button>
                    <button
                      onClick={() => handleReleasePledge(p.id)}
                      className="flex-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-[11px] transition-all flex items-center justify-center gap-1 cursor-pointer"
                      title="Settle credit and release DWR encumbrance"
                    >
                      <Unlock className="w-3 h-3" />
                      <span>Settle & Release</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 1: ACTIVE STORAGE LOTS */}
      {activeTab === "lots" && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-3 bg-white p-3 rounded-xl border border-slate-200">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search storage lots by crop, variety, or grade..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none focus:border-emerald-600 font-medium"
              />
            </div>

            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-400" />
              <select
                value={selectedCropFilter}
                onChange={(e) => setSelectedCropFilter(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-bold outline-none text-slate-700"
              >
                <option value="all">All Crops</option>
                <option value="Maize">Maize</option>
                <option value="Soya Beans">Soya Beans</option>
                <option value="Red Onion">Red Onion</option>
                <option value="Wheat">Wheat</option>
              </select>
            </div>
          </div>

          {/* Storage Lots Table */}
          {filteredLots.length === 0 ? (
            <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center">
              <Boxes className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">No Storage Lots Found</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto font-medium">
                Log a harvest event from an active Crop Cycle to create your first storage lot, or select a different search filter.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredLots.map((lot) => {
                const wh = warehouses.find(w => w.id === lot.warehouseId);
                const rec = receipts.find(r => r.lotId === lot.id);
                const isCertified = wh?.certification.status === "certified";

                const daysInStorage = Math.max(0, Math.floor((Date.now() - new Date(lot.intakeDate).getTime()) / (1000 * 3600 * 24)));
                let agingBadgeClass = "bg-emerald-100 text-emerald-800 border-emerald-300";
                let agingLabel = `Fresh (${daysInStorage}d in storage)`;
                if (daysInStorage >= 180) {
                  agingBadgeClass = "bg-rose-100 text-rose-800 border-rose-300";
                  agingLabel = `Long-term Storage (${daysInStorage}d)`;
                } else if (daysInStorage >= 90) {
                  agingBadgeClass = "bg-amber-100 text-amber-800 border-amber-300";
                  agingLabel = `Mature Aging (${daysInStorage}d)`;
                } else if (daysInStorage >= 30) {
                  agingBadgeClass = "bg-blue-100 text-blue-800 border-blue-300";
                  agingLabel = `Standard Storage (${daysInStorage}d)`;
                }

                return (
                  <div key={lot.id} className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition-all p-5 flex flex-col justify-between">
                    <div>
                      {/* Top status & grade badges */}
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <div className="flex items-center gap-1.5 mb-1">
                            <span className="text-[10px] font-black uppercase text-emerald-800 tracking-wider">
                              {lot.grade}
                            </span>
                            <span className="text-[9px] font-black uppercase bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded border border-indigo-200">
                              MPB Valued
                            </span>
                          </div>
                          <h3 className="text-lg font-black text-slate-900 leading-snug">
                            {lot.cropType}
                          </h3>
                          <div className="text-xs text-slate-500 font-medium">{lot.variety}</div>
                        </div>

                        <div className="flex flex-col items-end gap-1">
                          {lot.status === "in_storage" && (
                            <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                              IN STORAGE
                            </span>
                          )}
                          {lot.status === "pledged" && (
                            <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                              <Lock className="w-3 h-3" /> PLEDGED
                            </span>
                          )}
                          {lot.status === "partially_sold" && (
                            <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-teal-100 text-teal-800 border border-teal-300">
                              PARTIALLY SOLD
                            </span>
                          )}
                          {lot.status === "pending_intake" && (
                            <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-blue-100 text-blue-800 border border-blue-300">
                              PENDING INTAKE
                            </span>
                          )}
                          {lot.status === "depleted" && (
                            <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-slate-100 text-slate-600 border border-slate-300">
                              DEPLETED
                            </span>
                          )}

                          {isCertified ? (
                            <span className="text-[9px] font-extrabold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200">
                              ✓ Certified Silo
                            </span>
                          ) : (
                            <span className="text-[9px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                              On-Farm Granary
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Quantities & Values */}
                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 my-3 space-y-2">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500 font-semibold">Available Qty:</span>
                          <span className="font-extrabold text-slate-900">
                            {lot.quantityCurrent} / {lot.quantityIn} {lot.unit}
                          </span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500 font-semibold">Valuation Price:</span>
                          <span className="font-bold text-slate-700">
                            {currencySymbol} {lot.valuationPricePerUnit.toLocaleString()} / {lot.unit} ({lot.valuationPriceSource})
                          </span>
                        </div>
                        <div className="flex justify-between text-xs border-t border-slate-200 pt-1.5">
                          <span className="text-slate-700 font-bold">Current Lot Value:</span>
                          <span className="font-black text-emerald-800 text-sm">
                            {currencySymbol} {lot.storedValueCurrent.toLocaleString()}
                          </span>
                        </div>
                      </div>

                      {/* Warehouse info, aging indicator & intake date */}
                      <div className="text-[11px] text-slate-500 font-medium space-y-1 mb-4">
                        <div className="flex items-center gap-1.5">
                          <WarehouseIcon className="w-3.5 h-3.5 text-slate-400" />
                          <span>{wh ? wh.name : "Warehouse Storage"}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-slate-400" />
                            <span>Intake Date: {new Date(lot.intakeDate).toLocaleDateString()}</span>
                          </div>
                          <span className={`px-2 py-0.5 text-[9.5px] font-bold rounded-md border ${agingBadgeClass}`}>
                            {agingLabel}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
                      <button
                        onClick={() => {
                          if (rec) {
                            setSelectedDwrForView(rec);
                          } else {
                            showToast("Warehouse receipt not yet generated for this lot", "info");
                          }
                        }}
                        className="py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5 text-slate-600" />
                        View DWR
                      </button>

                      <button
                        onClick={() => {
                          setSelectedLotForSale(lot);
                          setSaleQty(Math.min(1, lot.quantityCurrent));
                          setSalePricePerUnit(lot.valuationPricePerUnit);
                        }}
                        disabled={lot.quantityCurrent <= 0}
                        className="py-1.5 px-2 bg-emerald-800 hover:bg-emerald-700 disabled:bg-slate-200 text-white text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <DollarSign className="w-3.5 h-3.5" />
                        Sell Stock
                      </button>

                      <button
                        onClick={() => {
                          setSelectedLotForLoss(lot);
                          setLossQty(1);
                        }}
                        disabled={lot.quantityCurrent <= 0}
                        className="py-1.5 px-2 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <TrendingDown className="w-3.5 h-3.5" />
                        Log Loss
                      </button>

                      <button
                        onClick={() => {
                          setSelectedLotForPledge(lot);
                          setPledgeAmount(lot.storedValueCurrent);
                        }}
                        disabled={lot.status === "pledged" || lot.quantityCurrent <= 0}
                        className="py-1.5 px-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Lock className="w-3.5 h-3.5" />
                        AGC Pledge
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: WAREHOUSE RECEIPTS (DWR) */}
      {activeTab === "dwr" && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Electronic Digital Warehouse Receipts (DWR)</h3>
                <p className="text-xs text-slate-500 font-medium">
                  DWRs represent legal title and collateral proof for stored commodities. Certified receipts are fully negotiable on commodity exchanges and financier credit platforms.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowPledgeCropsModal(true)}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer hover:scale-102"
              >
                <Lock className="w-4 h-4" />
                <span>Pledge Crops as Collateral</span>
              </button>
            </div>

            {/* Active Pledged Collateral Section if any exist */}
            {pledgedRecords.length > 0 && (
              <div className="mb-6 bg-amber-50/80 p-4 rounded-xl border border-amber-200 space-y-3">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-black text-amber-950 uppercase tracking-wider flex items-center gap-1.5">
                    <Lock className="w-4 h-4 text-amber-700" />
                    Active Encumbered Pledged Collateral ({pledgedRecords.length})
                  </h4>
                  <span className="text-[10px] font-bold text-amber-800 bg-amber-200/60 px-2 py-0.5 rounded">
                    Legally Encumbered under Zambia WRA Act
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {pledgedRecords.map((p) => {
                    const daysLeft = HswService.getDaysToMaturity(p.maturityDate);
                    const isNear = p.status === "active_pledge" && daysLeft <= 30;
                    const isUrgent = p.status === "active_pledge" && daysLeft <= 14;
                    const isOverdue = p.status === "active_pledge" && daysLeft < 0;

                    return (
                      <div
                        key={p.id}
                        className={`bg-white p-3.5 rounded-xl border shadow-2xs space-y-2 transition-all ${
                          p.status === "released"
                            ? "border-slate-200 opacity-75"
                            : isOverdue
                            ? "border-red-600 ring-2 ring-red-500/20"
                            : isNear
                            ? "border-amber-400 ring-1 ring-amber-400/40"
                            : "border-amber-300"
                        }`}
                      >
                        <div className="flex justify-between items-center gap-2">
                          <span className="font-mono text-xs font-black text-slate-900">{p.id}</span>
                          <div className="flex items-center gap-1.5">
                            {p.status === "released" ? (
                              <span className="px-2 py-0.5 rounded text-[9.5px] font-black bg-slate-100 text-slate-700 border border-slate-300">
                                Released
                              </span>
                            ) : (
                              <>
                                <span className="px-2 py-0.5 rounded text-[9.5px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                                  {p.ltvRatio}% LTV Approved
                                </span>
                                {isNear && (
                                  <span
                                    className={`px-2 py-0.5 rounded text-[9.5px] font-black uppercase tracking-wider flex items-center gap-1 ${
                                      isOverdue
                                        ? "bg-red-600 text-white animate-pulse"
                                        : isUrgent
                                        ? "bg-red-100 text-red-800 border border-red-300"
                                        : "bg-amber-100 text-amber-900 border border-amber-300"
                                    }`}
                                  >
                                    <AlertTriangle className="w-3 h-3" />
                                    {isOverdue ? `Overdue` : `${daysLeft}d left`}
                                  </span>
                                )}
                              </>
                            )}
                          </div>
                        </div>

                        <div className="text-xs font-bold text-slate-800">
                          {p.quantityPledged} {p.unit} of {p.cropType} pledged to <strong className="text-slate-900">{p.lenderName}</strong>
                        </div>

                        <div className="flex justify-between items-center text-[11px] text-slate-600">
                          <span>Receipt: <strong className="font-mono text-slate-800">{p.receiptNumber}</strong></span>
                          <span className={`font-bold ${isNear ? "text-red-600 font-extrabold" : "text-slate-800"}`}>
                            Maturity: {p.maturityDate || "N/A"}
                          </span>
                        </div>

                        <div className="flex justify-between items-center text-[11px] font-mono text-slate-600 border-t border-slate-100 pt-1.5 mt-1">
                          <span>Collateral: {currencySymbol} {p.totalCollateralValue.toLocaleString()}</span>
                          <span className="font-bold text-emerald-700">Loan: {currencySymbol} {p.requestedLoanAmount.toLocaleString()}</span>
                        </div>

                        {p.status === "active_pledge" && (
                          <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                            <button
                              onClick={() => handleExtendTenure(p.id)}
                              className="flex-1 py-1 px-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded text-[10.5px] transition-all flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <Calendar className="w-3 h-3" />
                              <span>Extend +30d</span>
                            </button>
                            <button
                              onClick={() => handleReleasePledge(p.id)}
                              className="flex-1 py-1 px-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded text-[10.5px] transition-all flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <Unlock className="w-3 h-3" />
                              <span>Settle & Release</span>
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="divide-y divide-slate-200">
              {receipts.map(r => (
                <div key={r.id} className="py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-black text-slate-900">{r.receiptNumber}</span>
                      {r.negotiable ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                          CERTIFIED NEGOTIABLE
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600">
                          ON-FARM NON-NEGOTIABLE
                        </span>
                      )}
                      <span className="text-xs font-bold text-slate-500">({r.status.toUpperCase()})</span>
                    </div>

                    <div className="text-xs font-bold text-slate-700">
                      {r.quantity} {r.unit} of {r.cropType} ({r.grade}) • Total Value: {currencySymbol} {r.totalValueAtIssue.toLocaleString()}
                    </div>
                    <div className="text-[11px] text-slate-500 font-medium">
                      Issued: {new Date(r.issuedDate).toLocaleDateString()} by {r.issuedBy} • Verification Code: <span className="font-mono font-bold text-slate-700">{r.qrVerificationCode}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setSelectedDwrForView(r)}
                      className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      View Certificate
                    </button>
                    <button
                      onClick={() => setShowPledgeCropsModal(true)}
                      className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-lg transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <Lock className="w-3.5 h-3.5 text-slate-950" />
                      Pledge
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: WAREHOUSES & FACILITIES */}
      {activeTab === "warehouses" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {warehouses.map(wh => (
              <div key={wh.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <span className="text-[10px] font-black uppercase text-slate-400">
                        {wh.ownerType === "certified_third_party" ? "Third-Party Certified Silo" : "On-Farm Storage Facility"}
                      </span>
                      <h3 className="text-lg font-black text-slate-900">{wh.name}</h3>
                      <div className="text-xs text-slate-500 font-medium">{wh.district}, {wh.province}</div>
                    </div>

                    {wh.certification.status === "certified" ? (
                      <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-full text-[10px] font-black flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" /> CERTIFIED
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 bg-slate-100 text-slate-600 rounded-full text-[10px] font-bold">
                        UNCERTIFIED
                      </span>
                    )}
                  </div>

                  {wh.certification.status === "certified" && (
                    <div className="bg-teal-50 p-2.5 rounded-xl border border-teal-200 text-xs text-teal-900 my-3 font-medium">
                      License: <span className="font-mono font-bold">{wh.certification.licenseNumber}</span> ({wh.certification.certifyingAuthority})
                    </div>
                  )}

                  <div className="space-y-1 my-3">
                    <div className="text-xs font-bold text-slate-700 mb-1">Capacity Breakdown:</div>
                    {wh.capacityByCrop.map((cap, i) => (
                      <div key={i} className="flex justify-between text-xs text-slate-600 font-medium bg-slate-50 px-2.5 py-1 rounded-lg">
                        <span>{cap.cropType}</span>
                        <span className="font-bold text-slate-900">{cap.capacityQty} {cap.unit}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {isSuperAdmin && (
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-semibold">Super-Admin Certification:</span>
                    {wh.certification.status === "certified" ? (
                      <button
                        onClick={() => handleToggleCertification(wh.id, "uncertified")}
                        className="px-2.5 py-1 bg-rose-100 text-rose-800 font-bold rounded-lg hover:bg-rose-200 text-[11px] cursor-pointer"
                      >
                        Revoke Certification
                      </button>
                    ) : (
                      <button
                        onClick={() => handleToggleCertification(wh.id, "certified")}
                        className="px-2.5 py-1 bg-emerald-600 text-white font-bold rounded-lg hover:bg-emerald-500 text-[11px] cursor-pointer"
                      >
                        Approve Certification
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: OPERATOR INTAKE PORTAL */}
      {activeTab === "operator" && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <h3 className="text-base font-bold text-slate-900 mb-1">Warehouse Operator Intake Queue</h3>
            <p className="text-xs text-slate-500 font-medium mb-4">
              Certified warehouse operators confirm commodity intake, perform physical grain quality grading & weighbridge verification, then trigger the auto-issuance of negotiable DWRs.
            </p>

            {lots.filter(l => l.status === "pending_intake").length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-300">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
                <div className="text-sm font-bold text-slate-800">No Pending Intakes</div>
                <div className="text-xs text-slate-500 font-medium mt-0.5">All incoming commodity shipments have been weighed, graded, and issued DWRs.</div>
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {lots.filter(l => l.status === "pending_intake").map(lot => {
                  const wh = warehouses.find(w => w.id === lot.warehouseId);
                  return (
                    <div key={lot.id} className="py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                      <div>
                        <div className="text-sm font-black text-slate-900">{lot.cropType} - {lot.variety}</div>
                        <div className="text-xs text-slate-600 font-medium">
                          Claimed Qty: {lot.quantityIn} {lot.unit} • Facility: {wh?.name}
                        </div>
                        <div className="text-[11px] text-slate-400">Tenant: {lot.tenantId}</div>
                      </div>

                      <button
                        onClick={() => {
                          setSelectedWhForIntake(lot);
                          setIntakeQty(lot.quantityIn);
                          setIntakeGrade(lot.grade || "Grade A Premium");
                        }}
                        className="px-4 py-2 bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer"
                      >
                        Confirm Weighbridge & Issue DWR
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: STORAGE LOSS LOG */}
      {activeTab === "losses" && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <h3 className="text-base font-bold text-slate-900 mb-1">Post-Harvest Storage Loss Audit Trail</h3>
            <p className="text-xs text-slate-500 font-medium mb-4">
              Categorized storage losses automatically decrement lot valuation and update crop cycle yield variance models.
            </p>

            {losses.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-300">
                <ShieldAlert className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <div className="text-sm font-bold text-slate-800">Zero Storage Losses Logged</div>
                <div className="text-xs text-slate-500 font-medium mt-0.5">No post-harvest pest or spoilage incidents recorded yet.</div>
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {losses.map(loss => (
                  <div key={loss.id} className="py-3.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-rose-100 text-rose-800 rounded-md text-[10px] font-black uppercase">
                          {loss.causeCategory.replace("_", " ")}
                        </span>
                        <span className="text-xs font-extrabold text-slate-900">
                          -{loss.quantityLost} {loss.unit} Lost
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 font-medium mt-1">{loss.notes || "No notes attached"}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        Logged on {new Date(loss.date).toLocaleDateString()} by {loss.loggedBy}
                      </div>
                    </div>

                    <div className="text-right font-black text-rose-600 text-xs">
                      Value Impact: -{currencySymbol} {loss.valueImpact.toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 6: PUBLIC QR VERIFICATION */}
      {activeTab === "qr_verify" && (
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-md">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-emerald-100 text-emerald-800 rounded-xl">
                <QrCode className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-900">Public DWR QR Verification Service</h3>
                <p className="text-xs text-slate-500 font-medium">
                  Rate-limited public verification endpoint for commodity buyers, bank auditors, and warehouse managers. Omits all personal farmer PII.
                </p>
              </div>
            </div>

            <form onSubmit={handleQrLookup} className="flex gap-2">
              <input
                type="text"
                placeholder="Enter DWR Receipt Number or QR Code e.g. QR-MABALA-DWR-883921"
                value={qrInputCode}
                onChange={(e) => setQrInputCode(e.target.value)}
                className="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs font-bold outline-none focus:border-emerald-600"
              />
              <button
                type="submit"
                className="px-5 py-3 bg-emerald-800 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl transition-all shadow-xs cursor-pointer"
              >
                Verify Code
              </button>
            </form>

            {qrResult && (
              <div className="mt-6 pt-6 border-t border-slate-200">
                {qrResult.found ? (
                  <div className="bg-emerald-50 border border-emerald-200 p-5 rounded-2xl space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="px-2.5 py-1 bg-emerald-800 text-white font-mono text-xs font-black rounded-lg">
                        {qrResult.receiptNumber}
                      </span>
                      <span className="px-2.5 py-1 bg-emerald-200 text-emerald-900 font-black text-[10px] rounded-full uppercase">
                        ✓ VERIFIED GENUINE DWR
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-emerald-200/60">
                      <div>
                        <span className="text-slate-500 font-semibold block">Commodity & Grade</span>
                        <span className="font-extrabold text-slate-900">{qrResult.cropType} ({qrResult.grade})</span>
                      </div>

                      <div>
                        <span className="text-slate-500 font-semibold block">Verified Quantity</span>
                        <span className="font-extrabold text-slate-900">{qrResult.quantity} {qrResult.unit}</span>
                      </div>

                      <div>
                        <span className="text-slate-500 font-semibold block">Warehouse Facility</span>
                        <span className="font-extrabold text-slate-900">{qrResult.warehouseName}</span>
                      </div>

                      <div>
                        <span className="text-slate-500 font-semibold block">Certification Status</span>
                        <span className="font-extrabold text-teal-800 uppercase">{qrResult.certificationStatus}</span>
                      </div>
                    </div>

                    <div className="bg-white p-3 rounded-xl border border-emerald-200 text-[11px] text-slate-600 font-medium flex items-center justify-between">
                      <span>Live Status: <strong className="text-slate-900 uppercase">{qrResult.status}</strong></span>
                      <span className="text-slate-400">Zero Farmer PII Exposed</span>
                    </div>
                  </div>
                ) : (
                  <div className="bg-rose-50 border border-rose-200 p-5 rounded-2xl text-center text-rose-800">
                    <AlertTriangle className="w-8 h-8 text-rose-500 mx-auto mb-2" />
                    <div className="font-black text-sm">Receipt / QR Code Not Found</div>
                    <div className="text-xs text-rose-600 mt-1">
                      No matching warehouse receipt found in the Mabala Registry.
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 7: SUPER ADMIN GOVERNANCE */}
      {activeTab === "admin" && isSuperAdmin && (
        <div className="space-y-6">
          <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-xl space-y-4">
            <h3 className="text-lg font-black text-amber-300">HSW Governance & Monetization Config</h3>
            <p className="text-xs text-slate-300">
              Configure minimum cohort size thresholds for aggregated market position data feeds to enforce strict farmer anonymity.
            </p>

            <div className="max-w-md bg-slate-800/80 p-4 rounded-xl border border-slate-700 space-y-3">
              <label className="text-xs font-bold text-slate-200 block">
                Minimum Cohort Size (Distinct Farmers Required)
              </label>
              <div className="flex gap-2">
                <input
                  type="number"
                  min={1}
                  max={50}
                  value={minCohortInput}
                  onChange={(e) => setMinCohortInput(parseInt(e.target.value, 10) || 1)}
                  className="p-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-bold text-xs w-24 outline-none"
                />
                <button
                  onClick={() => {
                    HswService.setMinCohortSize(minCohortInput);
                    showToast("Minimum cohort size updated", "success");
                  }}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-lg cursor-pointer transition-all"
                >
                  Save Config
                </button>
              </div>
              <div className="text-[10px] text-slate-400">
                Aggregated market feeds will refuse requests if active tenant cohort size is below this threshold.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: DWR CERTIFICATE PREVIEW */}
      {selectedDwrForView && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 space-y-5 overflow-y-auto max-h-[90vh]">
            {/* Certificate Header */}
            <div className="border-b-2 border-emerald-800 pb-4 flex justify-between items-start">
              <div>
                <div className="text-[10px] font-black uppercase text-emerald-800 tracking-widest">
                  MABALA AGRICULTURAL COMMODITIES EXCHANGE
                </div>
                <h2 className="text-xl font-black text-slate-900 mt-0.5">
                  ELECTRONIC WAREHOUSE RECEIPT (DWR)
                </h2>
                <div className="text-xs text-slate-500 font-bold font-mono">
                  {selectedDwrForView.receiptNumber}
                </div>
              </div>

              <div className="text-right">
                {selectedDwrForView.negotiable ? (
                  <span className="px-3 py-1 bg-emerald-800 text-white font-black text-[10px] rounded-full uppercase tracking-wider">
                    CERTIFIED NEGOTIABLE
                  </span>
                ) : (
                  <span className="px-3 py-1 bg-slate-200 text-slate-800 font-bold text-[10px] rounded-full uppercase">
                    ON-FARM NON-NEGOTIABLE
                  </span>
                )}
              </div>
            </div>

            {/* Content Body */}
            <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <div>
                <span className="text-slate-500 font-bold block">Commodity Type</span>
                <span className="text-slate-900 font-black text-sm">{selectedDwrForView.cropType}</span>
              </div>
              <div>
                <span className="text-slate-500 font-bold block">Grade & Variety</span>
                <span className="text-slate-900 font-black text-sm">{selectedDwrForView.grade} ({selectedDwrForView.variety})</span>
              </div>
              <div>
                <span className="text-slate-500 font-bold block">Certified Quantity</span>
                <span className="text-slate-900 font-black text-sm">{selectedDwrForView.quantity} {selectedDwrForView.unit}</span>
              </div>
              <div>
                <span className="text-slate-500 font-bold block">Value At Issue</span>
                <span className="text-emerald-800 font-black text-sm">{currencySymbol} {selectedDwrForView.totalValueAtIssue.toLocaleString()}</span>
              </div>
            </div>

            {/* QR & Security Footer */}
            <div className="flex items-center justify-between bg-emerald-50 p-4 rounded-2xl border border-emerald-200">
              <div>
                <div className="text-xs font-black text-emerald-950">Verification Code</div>
                <div className="font-mono text-sm font-black text-emerald-800">{selectedDwrForView.qrVerificationCode}</div>
                <div className="text-[10px] text-emerald-700 mt-1 font-medium">Scannable by commodity exchange verifiers & banks</div>
              </div>

              <div className="w-16 h-16 bg-white p-2 rounded-xl border border-emerald-300 flex items-center justify-center font-mono text-[8px] text-center font-bold text-slate-800">
                [QR CODE]
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedDwrForView(null)}
                className="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl cursor-pointer"
              >
                Close Certificate
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: SELL FROM STORAGE */}
      {selectedLotForSale && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-black text-slate-900">Sell Stock from Storage</h3>
            <p className="text-xs text-slate-500 font-medium">
              Selling directly from this lot decrements inventory, updates DWR withdrawal records, and posts revenue to the Finance Engine.
            </p>

            <form onSubmit={handleSellFromStorage} className="space-y-3">
              {/* Unit Sale Mode Selector */}
              <div className="flex items-center justify-between bg-slate-50 p-2 rounded-xl border border-slate-200">
                <span className="text-xs font-bold text-slate-700">Sale Calculation Unit:</span>
                <div className="flex items-center gap-1 bg-slate-200/80 p-0.5 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setHswSaleUnitMode("bags")}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all ${
                      hswSaleUnitMode === "bags" 
                        ? "bg-emerald-700 text-white shadow-xs" 
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    Sell per Bag (kg)
                  </button>
                  <button
                    type="button"
                    onClick={() => setHswSaleUnitMode("units")}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all ${
                      hswSaleUnitMode === "units" 
                        ? "bg-emerald-700 text-white shadow-xs" 
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    Direct Weight ({selectedLotForSale.unit})
                  </button>
                </div>
              </div>

              {hswSaleUnitMode === "bags" ? (
                <div className="space-y-2.5 p-3 bg-slate-50/80 rounded-2xl border border-slate-200">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] font-bold text-slate-600 block mb-1">Number of Bags</label>
                      <input
                        type="number"
                        min={1}
                        value={hswBagsCount}
                        onChange={(e) => setHswBagsCount(parseInt(e.target.value) || 1)}
                        className="w-full p-2 bg-white border border-slate-200 rounded-xl font-bold text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-600 block mb-1">Weight per Bag (kg)</label>
                      <select
                        value={hswKgPerBag}
                        onChange={(e) => setHswKgPerBag(Number(e.target.value))}
                        className="w-full p-2 bg-white border border-slate-200 rounded-xl font-bold text-xs"
                      >
                        <option value={25}>25 kg / bag</option>
                        <option value={50}>50 kg / bag (Standard)</option>
                        <option value={90}>90 kg / bag</option>
                        <option value={100}>100 kg / bag</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-600 block mb-1">Price per Bag ({currencySymbol})</label>
                    <input
                      type="number"
                      step="0.01"
                      value={hswPricePerBag}
                      onChange={(e) => setHswPricePerBag(parseFloat(e.target.value) || 0)}
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl font-bold text-xs font-mono"
                    />
                  </div>

                  <div className="p-2 bg-emerald-50 rounded-lg text-[11px] text-emerald-900 font-mono font-medium flex justify-between">
                    <span>Total Weight: <strong>{hswBagsCount * hswKgPerBag} kg</strong></span>
                    <span>Rate: <strong>{currencySymbol}{(hswPricePerBag / (hswKgPerBag || 1)).toFixed(2)}/kg</strong></span>
                  </div>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Quantity to Sell ({selectedLotForSale.unit})</label>
                    <input
                      type="number"
                      min={1}
                      max={selectedLotForSale.quantityCurrent - (selectedLotForSale.pledge.pledgedQuantity || 0)}
                      value={saleQty}
                      onChange={(e) => setSaleQty(parseFloat(e.target.value) || 1)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Selling Price Per {selectedLotForSale.unit} ({currencySymbol})</label>
                    <input
                      type="number"
                      value={salePricePerUnit}
                      onChange={(e) => setSalePricePerUnit(parseFloat(e.target.value) || 0)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                    />
                  </div>
                </div>
              )}

              {/* Customer / Offtaker Name */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Customer / Pre-Registered Offtaker</label>
                <select
                  value={saleCustomer}
                  onChange={(e) => setSaleCustomer(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs text-slate-800"
                  required
                >
                  {getPreRegisteredClients().map((client, idx) => (
                    <option key={idx} value={client.name}>
                      {client.name} — [{client.type}]{client.tpin ? ` (TPIN: ${client.tpin})` : ""}
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-3 bg-emerald-800 text-white rounded-2xl flex justify-between font-bold text-xs items-center">
                <span className="uppercase tracking-wider text-[10px]">Total Sale Revenue:</span>
                <span className="text-base font-black font-mono">
                  {currencySymbol} {(hswSaleUnitMode === "bags" ? (hswBagsCount * hswPricePerBag) : (saleQty * salePricePerUnit)).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                </span>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedLotForSale(null)}
                  className="px-4 py-2 bg-slate-200 text-slate-800 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-800 text-white text-xs font-black rounded-xl hover:bg-emerald-700 cursor-pointer"
                >
                  Confirm Sale
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: LOG POST-HARVEST LOSS */}
      {selectedLotForLoss && (
        <StorageLossForm
          lot={selectedLotForLoss}
          isOpen={!!selectedLotForLoss}
          onClose={() => setSelectedLotForLoss(null)}
          onLossLogged={() => {
            setLosses(HswService.getStorageLosses());
            setLots(HswService.getStorageLots());
            setSelectedLotForLoss(null);
          }}
        />
      )}

      {/* MODAL: PLEDGE DWR FOR AGC */}
      {selectedLotForPledge && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-black text-slate-900">Soft-Pledge DWR for AGC Loan</h3>
            <p className="text-xs text-slate-500 font-medium">
              Soft-pledging locks this lot from sale/re-pledging while maintaining crop ownership until loan clearance.
            </p>

            <form onSubmit={handlePledgeForAgc} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Target AGC Loan ID</label>
                <input
                  type="text"
                  value={pledgeLoanId}
                  onChange={(e) => setPledgeLoanId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Pledged Valuation ({currencySymbol})</label>
                <input
                  type="number"
                  value={pledgeAmount}
                  onChange={(e) => setPledgeAmount(parseFloat(e.target.value) || 0)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedLotForPledge(null)}
                  className="px-4 py-2 bg-slate-200 text-slate-800 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 text-slate-950 text-xs font-black rounded-xl hover:bg-amber-400 cursor-pointer"
                >
                  Confirm Soft Pledge
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: OPERATOR INTAKE WEIGHBRIDGE */}
      {selectedWhForIntake && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-black text-slate-900">Confirm Weighbridge & Quality Grading</h3>

            <form onSubmit={handleConfirmIntake} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Weighed Net Quantity ({selectedWhForIntake.unit})</label>
                <input
                  type="number"
                  value={intakeQty}
                  onChange={(e) => setIntakeQty(parseFloat(e.target.value) || 0)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Official Quality Grade</label>
                <select
                  value={intakeGrade}
                  onChange={(e) => setIntakeGrade(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                >
                  <option value="Grade A Premium">Grade A Premium</option>
                  <option value="Grade B Standard">Grade B Standard</option>
                  <option value="Feed Grade">Feed Grade</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedWhForIntake(null)}
                  className="px-4 py-2 bg-slate-200 text-slate-800 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-800 text-white text-xs font-black rounded-xl hover:bg-emerald-700 cursor-pointer"
                >
                  Issue Negotiable DWR
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: REGISTER NEW WAREHOUSE */}
      {showAddWhModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-black text-slate-900">Register Warehouse Facility</h3>

            <form onSubmit={handleAddWarehouse} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Facility Name</label>
                <input
                  type="text"
                  placeholder="e.g. Chisamba Central Granary"
                  value={newWhName}
                  onChange={(e) => setNewWhName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Facility Type</label>
                <select
                  value={newWhType}
                  onChange={(e) => setNewWhType(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                >
                  <option value="farm_on_site">On-Farm Granary (Self-Storage)</option>
                  <option value="certified_third_party">Certified Third-Party Commercial Warehouse / Silo</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Province</label>
                  <input
                    type="text"
                    value={newWhProvince}
                    onChange={(e) => setNewWhProvince(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">District</label>
                  <input
                    type="text"
                    value={newWhDistrict}
                    onChange={(e) => setNewWhDistrict(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddWhModal(false)}
                  className="px-4 py-2 bg-slate-200 text-slate-800 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-800 text-white text-xs font-black rounded-xl hover:bg-emerald-700 cursor-pointer"
                >
                  Save Warehouse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: PLEDGE CROPS AS COLLATERAL */}
      <PledgeCropsModal
        isOpen={showPledgeCropsModal}
        onClose={() => setShowPledgeCropsModal(false)}
        lots={lots}
        receipts={receipts}
        currencySymbol={currencySymbol}
        onConfirmPledge={(newPledge) => {
          HswService.addPledgeRecord(newPledge);
          loadData();
          showToast(`Collateral pledge ${newPledge.id} registered! Maturity date: ${newPledge.maturityDate}`, "success");
        }}
      />
    </div>
  );
}

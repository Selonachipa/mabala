import React, { useState } from "react";
import { Lock, AlertCircle, CheckCircle2, ShieldCheck, Scale, FileText, Download, Building2, Calendar, DollarSign, X, QrCode, Printer } from "lucide-react";
import { StorageLot, WarehouseReceipt, PledgeRecord } from "../../types";
export type { PledgeRecord };

interface PledgeCropsModalProps {
  isOpen: boolean;
  onClose: () => void;
  lots: StorageLot[];
  receipts: WarehouseReceipt[];
  currencySymbol?: string;
  onConfirmPledge: (pledgeData: PledgeRecord) => void;
}

export function PledgeCropsModal({
  isOpen,
  onClose,
  lots,
  receipts,
  currencySymbol = "ZMW",
  onConfirmPledge
}: PledgeCropsModalProps) {
  // Form State
  const [selectedLotId, setSelectedLotId] = useState<string>(lots[0]?.id || "");
  const selectedLot = lots.find(l => l.id === selectedLotId) || lots[0];

  const matchingReceipt = receipts.find(r => r.lotId === selectedLotId) || receipts[0];

  const [pledgeQty, setPledgeQty] = useState<number>(selectedLot ? selectedLot.quantityCurrent : 0);
  const [marketPricePerUnit, setMarketPricePerUnit] = useState<number>(selectedLot ? selectedLot.valuationPricePerUnit : 0);
  const [requestedLoanAmount, setRequestedLoanAmount] = useState<number>(0);
  const [lenderName, setLenderName] = useState<string>("");
  const [tenureMonths, setTenureMonths] = useState<number>(6);

  const [generatedPledgeDoc, setGeneratedPledgeDoc] = useState<PledgeRecord | null>(null);

  if (!isOpen) return null;

  // Realtime calculations
  const totalCollateralValue = pledgeQty * marketPricePerUnit;
  const ltvRatio = totalCollateralValue > 0 ? (requestedLoanAmount / totalCollateralValue) * 100 : 0;
  const maxLoanAllowed = totalCollateralValue * 0.80; // 80% max LTV cap
  const isLtvExceeded = ltvRatio > 80;

  // Handle lot selection change
  const handleLotChange = (lotId: string) => {
    setSelectedLotId(lotId);
    const found = lots.find(l => l.id === lotId);
    if (found) {
      setPledgeQty(found.quantityCurrent);
      setMarketPricePerUnit(found.valuationPricePerUnit || 4200);
      const val = found.quantityCurrent * (found.valuationPricePerUnit || 4200);
      setRequestedLoanAmount(Math.round(val * 0.65)); // Default 65% LTV
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLot) return;
    if (isLtvExceeded) {
      alert("Loan-to-Value (LTV) exceeds the maximum limit of 80%. Please adjust the requested loan amount.");
      return;
    }

    const now = new Date();
    const issuedDate = now.toISOString().split("T")[0];
    const matDate = new Date(now);
    matDate.setMonth(matDate.getMonth() + tenureMonths);
    const maturityDate = matDate.toISOString().split("T")[0];

    const pledgeRecord: PledgeRecord = {
      id: `PLEDGE-${Math.floor(100000 + Math.random() * 900000)}`,
      receiptId: matchingReceipt?.id || "dwr-gen-01",
      receiptNumber: matchingReceipt?.receiptNumber || "DWR-ZM-2026-001",
      lotId: selectedLot.id,
      cropType: selectedLot.cropType,
      variety: selectedLot.variety || "Hybrid Standard",
      quantityPledged: pledgeQty,
      unit: selectedLot.unit,
      marketPricePerUnit,
      totalCollateralValue,
      requestedLoanAmount,
      ltvRatio: Number(ltvRatio.toFixed(1)),
      lenderName,
      tenureMonths,
      interestRateAnnual: 18.5,
      issuedDate,
      maturityDate,
      qrCode: `QR-PLEDGE-ZM-${Math.floor(1000 + Math.random() * 9000)}`,
      status: "active_pledge"
    };

    setGeneratedPledgeDoc(pledgeRecord);
    onConfirmPledge(pledgeRecord);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto font-sans">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 md:p-8 shadow-2xl border border-slate-200 relative animate-in zoom-in-95 duration-150">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {!generatedPledgeDoc ? (
          /* FORM VIEW */
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-100 text-amber-900 border border-amber-300 rounded-full text-[10px] font-black uppercase tracking-widest mb-2">
                <Lock className="w-3.5 h-3.5 text-amber-700" />
                Collateral Encumbrance Workflow
              </div>
              <h2 className="text-xl font-black text-slate-900">
                Pledge Crop Inventory as Loan Collateral
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-1">
                Select stored crop inventory from Digital Warehouse Receipts (DWR) to pledge as formal credit security to registered financial institutions in Zambia.
              </p>
            </div>

            {/* Select Crop Batch / Lot */}
            <div className="space-y-1.5">
              <label className="text-xs font-extrabold text-slate-700 uppercase block">
                Select Stored Crop Batch / Receipt
              </label>
              {lots.length > 0 ? (
                <select
                  value={selectedLotId}
                  onChange={e => handleLotChange(e.target.value)}
                  className="w-full text-xs font-bold p-3 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none cursor-pointer"
                >
                  {lots.map(lot => (
                    <option key={lot.id} value={lot.id}>
                      {lot.cropType} ({lot.variety}) — {lot.quantityCurrent} {lot.unit} Stored • Valued at {currencySymbol} {lot.storedValueCurrent.toLocaleString()}
                    </option>
                  ))}
                </select>
              ) : (
                <div className="text-xs text-rose-600 bg-rose-50 p-3 rounded-xl font-bold">
                  No active stored crop batches found. Please log harvest intake first.
                </div>
              )}
            </div>

            {/* Quantity & Valuation Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">
                  Quantity to Pledge ({selectedLot?.unit || "MT"})
                </label>
                <input
                  type="number"
                  min="0.1"
                  max={selectedLot?.quantityCurrent || 1000}
                  step="0.5"
                  value={pledgeQty}
                  onChange={e => setPledgeQty(parseFloat(e.target.value) || 0)}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:bg-white outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">
                  Market Price per Unit ({currencySymbol}/{selectedLot?.unit || "MT"})
                </label>
                <input
                  type="number"
                  min="100"
                  value={marketPricePerUnit}
                  onChange={e => setMarketPricePerUnit(parseFloat(e.target.value) || 0)}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:bg-white outline-none"
                />
              </div>
            </div>

            {/* Total Valuation Display */}
            <div className="p-3.5 bg-slate-900 text-white rounded-xl flex justify-between items-center">
              <span className="text-xs font-bold text-slate-300">Total Collateral Market Valuation:</span>
              <span className="text-base font-black text-emerald-400 font-mono">
                {currencySymbol} {totalCollateralValue.toLocaleString()}
              </span>
            </div>

            {/* Requested Financing & Lender */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">
                  Requested Financing / Loan Amount ({currencySymbol})
                </label>
                <input
                  type="number"
                  min="1000"
                  max={totalCollateralValue}
                  step="1000"
                  value={requestedLoanAmount}
                  onChange={e => setRequestedLoanAmount(parseFloat(e.target.value) || 0)}
                  className={`w-full text-xs font-bold p-2.5 border rounded-xl outline-none ${
                    isLtvExceeded ? "border-rose-500 bg-rose-50 text-rose-900" : "bg-slate-50 border-slate-300 text-slate-900"
                  }`}
                />
              </div>

              <div>
                <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">
                  Financier / Lender Name
                </label>
                <select
                  value={lenderName}
                  onChange={e => setLenderName(e.target.value)}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 outline-none"
                >
                  <option value="Zambian Agribusiness Credit Co-op">Zambian Agribusiness Credit Co-op</option>
                  <option value="Zanaco Agricultural Finance">Zanaco Agricultural Finance</option>
                  <option value="Zambia Industrial Development Bank (ZIDB)">Zambia Industrial Development Bank (ZIDB)</option>
                  <option value="Natsave Agri-Credit Facility">Natsave Agri-Credit Facility</option>
                  <option value="FNB Agri-Business Capital">FNB Agri-Business Capital</option>
                </select>
              </div>
            </div>

            {/* Realtime Loan-to-Value (LTV) Risk Indicator */}
            <div className={`p-4 rounded-xl border space-y-2 ${
              isLtvExceeded ? "bg-rose-50 border-rose-300 text-rose-900" : ltvRatio > 70 ? "bg-amber-50 border-amber-300 text-amber-900" : "bg-emerald-50 border-emerald-300 text-emerald-950"
            }`}>
              <div className="flex justify-between items-center text-xs font-black">
                <span className="flex items-center gap-1.5 uppercase tracking-wider">
                  <Scale className="w-4 h-4" />
                  Loan-to-Value (LTV) Ratio Analysis
                </span>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-mono font-black ${
                  isLtvExceeded ? "bg-rose-600 text-white" : ltvRatio > 70 ? "bg-amber-600 text-white" : "bg-emerald-600 text-white"
                }`}>
                  {ltvRatio.toFixed(1)}% LTV
                </span>
              </div>

              {/* LTV Meter bar */}
              <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${
                    isLtvExceeded ? "bg-rose-600" : ltvRatio > 70 ? "bg-amber-500" : "bg-emerald-600"
                  }`}
                  style={{ width: `${Math.min(100, ltvRatio)}%` }}
                ></div>
              </div>

              <div className="flex justify-between text-[11px] font-medium pt-1">
                <span>Maximum Allowed Loan (80% LTV Cap): <strong>{currencySymbol} {maxLoanAllowed.toLocaleString()}</strong></span>
                {isLtvExceeded ? (
                  <span className="font-bold text-rose-700">⚠️ Exceeds 80% Max LTV Cap</span>
                ) : (
                  <span className="font-bold text-emerald-700">✓ Within Approved LTV Safety Limits</span>
                )}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end gap-3 pt-3 border-t">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLtvExceeded || !selectedLot}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-black rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <Lock className="w-4 h-4" />
                <span>Generate Collateral Pledge Document</span>
              </button>
            </div>
          </form>
        ) : (
          /* OFFICIAL PLEDGE DOCUMENT CERTIFICATE VIEW */
          <div className="space-y-6 animate-in fade-in duration-200" id="official-pledge-document-sheet">
            
            {/* Header Stamp */}
            <div className="border-b-2 border-slate-900 pb-4 flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-6 h-6 text-emerald-600" />
                  <span className="text-xs font-black uppercase text-emerald-800 tracking-widest">
                    Zambia Warehouse Receipts Authority (ZWRA)
                  </span>
                </div>
                <h2 className="text-xl font-black text-slate-900 mt-1">
                  OFFICIAL DWR COLLATERAL PLEDGE CERTIFICATE
                </h2>
                <div className="text-xs text-slate-500 font-mono mt-0.5">
                  Document ID: <strong className="text-slate-900">{generatedPledgeDoc.id}</strong> • Issue Date: {new Date(generatedPledgeDoc.issuedDate).toLocaleDateString()}
                </div>
              </div>

              <div className="bg-slate-100 p-2 rounded-xl text-center border border-slate-300">
                <QrCode className="w-12 h-12 text-slate-800 mx-auto" />
                <span className="text-[8px] font-mono font-extrabold text-slate-600 block mt-1">
                  {generatedPledgeDoc.qrCode}
                </span>
              </div>
            </div>

            {/* Certificate Details */}
            <div className="grid grid-cols-2 gap-4 text-xs font-sans">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[9px] font-black text-slate-400 uppercase">Pledged Collateral Asset</span>
                <div className="font-extrabold text-slate-900 text-sm">{generatedPledgeDoc.cropType} ({generatedPledgeDoc.variety})</div>
                <div className="text-slate-600 font-mono">Quantity: {generatedPledgeDoc.quantityPledged} {generatedPledgeDoc.unit}</div>
                <div className="text-slate-600 font-mono">DWR Certificate #: {generatedPledgeDoc.receiptNumber}</div>
              </div>

              <div className="bg-emerald-50 p-3.5 rounded-xl border border-emerald-200 space-y-1">
                <span className="text-[9px] font-black text-emerald-700 uppercase">Financial Security Terms</span>
                <div className="font-extrabold text-emerald-950 text-sm">{currencySymbol} {generatedPledgeDoc.requestedLoanAmount.toLocaleString()} Loan</div>
                <div className="text-emerald-800 font-mono">Collateral Value: {currencySymbol} {generatedPledgeDoc.totalCollateralValue.toLocaleString()}</div>
                <div className="text-emerald-800 font-bold">LTV Ratio: {generatedPledgeDoc.ltvRatio}%</div>
              </div>
            </div>

            {/* Lender & Encumbrance Notice */}
            <div className="bg-amber-50 p-4 rounded-xl border border-amber-300 text-xs text-amber-950 space-y-2">
              <div className="font-extrabold flex items-center gap-1.5 text-amber-900">
                <Building2 className="w-4 h-4 text-amber-700" />
                Beneficiary Financier: {generatedPledgeDoc.lenderName}
              </div>
              <p className="text-[11px] leading-relaxed text-amber-900/90 font-medium">
                <strong>LEGAL ENCUMBRANCE NOTICE:</strong> The agricultural commodities identified above are formally pledged as collateral under the Warehouse Receipts Act of Zambia (Act No. 4 of 2010). The warehouse operator is legally restricted from releasing, transferring, or selling these goods without prior written authorization from {generatedPledgeDoc.lenderName}.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-between items-center pt-3 border-t">
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full border border-emerald-300">
                ✓ DWR Locked & Soft-Pledge Active
              </span>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    alert(`Official Pledge Document ${generatedPledgeDoc.id} sent to printer / PDF download.`);
                  }}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print / Export PDF
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
export default PledgeCropsModal;

import React, { useState, useEffect, useMemo } from "react";
import { 
  Coins, 
  Search, 
  Building2, 
  ArrowUpRight, 
  ArrowDownLeft, 
  FileText, 
  Plus, 
  RefreshCw, 
  Database, 
  Clock, 
  Tag, 
  Check, 
  AlertCircle,
  Tractor,
  MessageSquare,
  ShieldCheck,
  Zap,
  RotateCcw,
  CheckCircle2,
  Phone,
  User,
  Sliders
} from "lucide-react";
import { auth, db } from "../firebase";
import { doc, setDoc, getDoc, collection, getDocs, query, orderBy, limit } from "firebase/firestore";

interface LedgerEntry {
  id: string;
  nodeId?: string;
  institutionId?: string;
  amount: number;
  type: "top_up" | "deduction" | "refund" | "zero_rate";
  balanceAfter?: number;
  reference: string;
  note?: string;
  authorizedBy?: string;
  createdAt: string;
}

interface NodeItem {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  type: "farm_node" | "institution";
  smsCreditBalance: number;
  smsRateZmw?: number;
  role?: string;
  province?: string;
}

export default function SmsCreditsPanel() {
  const [nodeType, setNodeType] = useState<"farm_nodes" | "institutions">("farm_nodes");
  const [nodes, setNodes] = useState<NodeItem[]>([]);
  const [selectedNodeId, setSelectedNodeId] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(false);
  
  // Selected node metrics
  const [currentBalance, setCurrentBalance] = useState<number>(0);
  const [smsRate, setSmsRate] = useState<number>(0.90);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);

  // Adjustment Form States
  const [amount, setAmount] = useState("100");
  const [adjType, setAdjType] = useState<"allocate" | "deduct" | "set" | "zero_rate">("allocate");
  const [reference, setReference] = useState("");
  const [note, setNote] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formMsg, setFormMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Global Zero-Rate Modal State
  const [showZeroRateModal, setShowZeroRateModal] = useState(false);
  const [isZeroRatingGlobal, setIsZeroRatingGlobal] = useState(false);

  useEffect(() => {
    fetchNodes();
  }, [nodeType]);

  // Synchronize farm nodes with User Directory deletion events
  useEffect(() => {
    const handleNodeDeleted = (e: any) => {
      const deletedId = e?.detail?.tenantId;
      const deletedEmail = (e?.detail?.email || "").toLowerCase();
      if (deletedId || deletedEmail) {
        setNodes(prev => prev.filter(n => 
          n.id !== deletedId && 
          (!deletedEmail || (n.email || "").toLowerCase() !== deletedEmail)
        ));
      }
      fetchNodes();
    };

    const handleUsersUpdated = () => {
      fetchNodes();
    };

    window.addEventListener("mabala_farm_node_deleted", handleNodeDeleted);
    window.addEventListener("mabala_users_updated", handleUsersUpdated);
    return () => {
      window.removeEventListener("mabala_farm_node_deleted", handleNodeDeleted);
      window.removeEventListener("mabala_users_updated", handleUsersUpdated);
    };
  }, []);

  const fetchNodes = async () => {
    setLoading(true);
    try {
      if (nodeType === "farm_nodes") {
        const token = await auth.currentUser?.getIdToken();
        const res = await fetch("/api/admin/farm-nodes", {
          headers: token ? { Authorization: `Bearer ${token}` } : {}
        });
        const data = await res.json();
        if (data.nodes && Array.isArray(data.nodes)) {
          const mapped: NodeItem[] = data.nodes.map((n: any) => ({
            id: n.tenantId || n.id,
            name: n.farmName || n.ownerName || n.ownerEmail || "Farm Node",
            email: n.ownerEmail,
            phone: n.ownerPhone,
            type: "farm_node",
            smsCreditBalance: Number(n.smsCredits ?? 0),
            smsRateZmw: 0.90,
            province: n.province,
            role: "Farm Node"
          }));
          setNodes(mapped);
          if (selectedNodeId && !mapped.some(m => m.id === selectedNodeId) && mapped.length > 0) {
            handleSelectNode(mapped[0]);
          }
        }
      } else {
        const res = await fetch("/api/admin/institutions");
        const data = await res.json();
        if (data.success && Array.isArray(data.institutions)) {
          const mapped: NodeItem[] = data.institutions.map((i: any) => ({
            id: i.id,
            name: i.name,
            email: i.contactEmail || i.email,
            phone: i.contactPhone || i.phone,
            type: "institution",
            smsCreditBalance: Number(i.smsCreditBalance ?? 0),
            smsRateZmw: Number(i.smsRateZmw ?? 0.90),
            role: i.type || "Institution"
          }));
          setNodes(mapped);
          if (selectedNodeId && !mapped.some(m => m.id === selectedNodeId) && mapped.length > 0) {
            handleSelectNode(mapped[0]);
          }
        }
      }
    } catch (err) {
      console.error("Failed to fetch nodes for SMS panel:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectNode = async (node: NodeItem) => {
    setSelectedNodeId(node.id);
    setLoading(true);
    setFormMsg(null);
    setCurrentBalance(node.smsCreditBalance);
    setSmsRate(node.smsRateZmw || 0.90);

    try {
      const token = await auth.currentUser?.getIdToken();
      if (node.type === "farm_node" || nodeType === "farm_node") {
        // Fetch from farm node SMS ledger
        const res = await fetch(`/api/admin/farm-nodes/${node.id}/sms-ledger`, {
          headers: token ? { Authorization: `Bearer ${token}` } : {}
        });
        const data = await res.json();
        if (data.success) {
          setCurrentBalance(Number(data.smsCredits ?? node.smsCreditBalance ?? 0));
          setLedger(data.ledger || []);
        } else {
          // Fallback direct from Firestore
          if (db) {
            const userSnap = await getDoc(doc(db, "users_data", node.id));
            if (userSnap.exists()) {
              setCurrentBalance(Number(userSnap.data()?.smsCredits ?? 0));
            }
            try {
              const ledgerSnap = await getDocs(query(collection(db, "tenants", node.id, "sms_ledger"), orderBy("createdAt", "desc"), limit(50)));
              const entries: LedgerEntry[] = ledgerSnap.docs.map(d => ({ id: d.id, ...d.data() } as any));
              setLedger(entries);
            } catch (_) {}
          }
        }
      } else {
        const res = await fetch(`/api/admin/institutions/${node.id}/sms-ledger`, {
          headers: token ? { Authorization: `Bearer ${token}` } : {}
        });
        const data = await res.json();
        if (data.success) {
          setCurrentBalance(data.smsCreditBalance || 0);
          setSmsRate(data.smsRateZmw || 0.90);
          setLedger(data.ledger || []);
        }
      }
    } catch (err) {
      console.error("Failed to load node ledger info:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedNodeId) {
      setFormMsg({ type: "error", text: "Please select a farm node or institution first." });
      return;
    }

    const deltaAmount = Math.max(0, parseInt(amount) || 0);
    if (adjType !== "zero_rate" && deltaAmount <= 0) {
      setFormMsg({ type: "error", text: "Please enter a valid positive number of SMS credits." });
      return;
    }

    setIsSubmitting(true);
    setFormMsg(null);

    const superAdminEmail = auth.currentUser?.email || "support@mabala.cloud";
    const superAdminUid = auth.currentUser?.uid || "super_admin";
    const token = await auth.currentUser?.getIdToken();

    try {
      if (nodeType === "farm_nodes") {
        // Farm Node Allocation Endpoint
        const res = await fetch("/api/admin/farm-nodes/allocate-sms-credits", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {})
          },
          body: JSON.stringify({
            tenantId: selectedNodeId,
            amount: deltaAmount,
            type: adjType,
            reference: reference || `ADMIN_SMS_${Date.now()}`,
            note: note || `Super Admin SMS credit adjustment (${adjType})`,
            superAdminEmail,
            superAdminUid
          })
        });

        const data = await res.json();
        if (data.success) {
          setFormMsg({ type: "success", text: `SMS balance updated successfully to ${data.newSmsCredits} credits!` });
          setCurrentBalance(data.newSmsCredits);
          setAmount("100");
          setReference("");
          setNote("");

          // Update local list
          setNodes(prev => prev.map(n => n.id === selectedNodeId ? { ...n, smsCreditBalance: data.newSmsCredits } : n));
          
          // Refresh active details
          const sel = nodes.find(n => n.id === selectedNodeId);
          if (sel) handleSelectNode(sel);
        } else {
          setFormMsg({ type: "error", text: data.error || "Failed to allocate SMS credits to farm node." });
        }
      } else {
        // Institution Allocation Endpoint
        const finalAmount = adjType === "deduct" ? -deltaAmount : (adjType === "zero_rate" ? -currentBalance : deltaAmount);
        const res = await fetch(`/api/admin/institutions/${selectedNodeId}/sms-ledger`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {})
          },
          body: JSON.stringify({
            amount: finalAmount,
            type: adjType === "deduct" ? "deduction" : (adjType === "zero_rate" ? "zero_rate" : "top_up"),
            reference: reference || "ADMIN_MANUAL_SMS_TOPUP",
            note: note || `Super Admin adjustment (${adjType})`
          })
        });

        const data = await res.json();
        if (data.success) {
          setFormMsg({ type: "success", text: "Institution SMS credits updated and ledger recorded!" });
          setAmount("100");
          setReference("");
          setNote("");
          const sel = nodes.find(n => n.id === selectedNodeId);
          if (sel) handleSelectNode(sel);
          fetchNodes();
        } else {
          setFormMsg({ type: "error", text: data.error || "Failed to submit credit adjustment." });
        }
      }
    } catch (err: any) {
      setFormMsg({ type: "error", text: err.message || "Network error occurred." });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExecuteGlobalZeroRate = async () => {
    setIsZeroRatingGlobal(true);
    try {
      const token = await auth.currentUser?.getIdToken();
      const res = await fetch("/api/admin/sms/zero-rate-all", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          superAdminEmail: auth.currentUser?.email || "support@mabala.cloud",
          superAdminUid: auth.currentUser?.uid || "super_admin",
          reason: "Super Admin Platform-wide SMS Balance Zero-Rating"
        })
      });
      const data = await res.json();
      if (data.success) {
        setShowZeroRateModal(false);
        setFormMsg({ type: "success", text: `Success: ${data.message || "All platform SMS balances successfully zero-rated."}` });
        setCurrentBalance(0);
        fetchNodes();
      } else {
        alert(data.error || "Failed to execute global zero-rating");
      }
    } catch (e: any) {
      alert("Error: " + (e.message || "Failed to zero rate"));
    } finally {
      setIsZeroRatingGlobal(false);
    }
  };

  const selectedNode = nodes.find(n => n.id === selectedNodeId);

  const filteredNodes = useMemo(() => {
    const raw = searchQuery.trim().toLowerCase();
    if (!raw) return nodes.map(n => ({ ...n, matchType: null as string | null, matchDetail: "" }));

    const digitsOnly = raw.replace(/[\s\-\+\(\)]/g, "");

    return nodes
      .map(n => {
        const name = (n.name || "").toLowerCase();
        const email = (n.email || "").toLowerCase();
        const id = (n.id || "").toLowerCase();
        const phone = (n.phone || "").toLowerCase();
        const phoneDigits = phone.replace(/[\s\-\+\(\)]/g, "");

        let matchType: "name" | "email" | "phone" | "uid" | null = null;
        let matchDetail = "";

        if (name.includes(raw)) {
          matchType = "name";
          matchDetail = n.name;
        } else if (email.includes(raw)) {
          matchType = "email";
          matchDetail = n.email || "";
        } else if (phone.includes(raw) || (digitsOnly.length >= 3 && phoneDigits.includes(digitsOnly))) {
          matchType = "phone";
          matchDetail = n.phone || "";
        } else if (id.includes(raw)) {
          matchType = "uid";
          matchDetail = n.id;
        }

        return { ...n, matchType, matchDetail };
      })
      .filter(n => n.matchType !== null);
  }, [nodes, searchQuery]);

  return (
    <div className="space-y-8 animate-fade-in font-sans">
      
      {/* Overview Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 text-white shadow-xl border border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-full text-[9.5px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
              <MessageSquare className="w-3 h-3 text-indigo-400" /> Beem Africa SMS Engine
            </span>
            <span className="px-2 py-0.5 rounded-full text-[9.5px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-amber-400" /> Super Admin Authority
            </span>
          </div>
          <h2 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
            SMS Credits Core & Farm Node Allocation
          </h2>
          <p className="text-xs text-indigo-200 mt-1 max-w-2xl font-medium">
            Allocate SMS credits directly to any farm node, cooperative, or institution. Manage balances, track delivery ledgers, or perform zero-rate baseline resets.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setShowZeroRateModal(true)}
            className="px-3.5 py-2 bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800/80 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition cursor-pointer shadow"
          >
            <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
            Zero-Rate All SMS Balances
          </button>
        </div>
      </div>

      {/* Target Type Selector Tabs */}
      <div className="flex gap-2 p-1.5 bg-slate-100 rounded-2xl w-fit border border-slate-200">
        <button
          type="button"
          onClick={() => { setNodeType("farm_nodes"); setSelectedNodeId(""); }}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition cursor-pointer ${
            nodeType === "farm_nodes"
              ? "bg-indigo-600 text-white shadow"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Tractor className="w-4 h-4" /> Farm Nodes & Workspaces ({nodes.length})
        </button>
        <button
          type="button"
          onClick={() => { setNodeType("institutions"); setSelectedNodeId(""); }}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition cursor-pointer ${
            nodeType === "institutions"
              ? "bg-indigo-600 text-white shadow"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Building2 className="w-4 h-4" /> Institutions & Partners
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        
        {/* Left Col (span 1): Select Node & Info */}
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-sm font-extrabold uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                  {nodeType === "farm_nodes" ? <Tractor className="w-4 h-4 text-indigo-600" /> : <Building2 className="w-4 h-4 text-indigo-600" />}
                  Select {nodeType === "farm_nodes" ? "Farm Node" : "Institution"}
                </h3>
                <p className="text-[11px] text-slate-400 font-medium">Filter by name, phone, email, or UID.</p>
              </div>
              <button
                type="button"
                onClick={fetchNodes}
                className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg transition"
                title="Refresh list"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
              </button>
            </div>

            <div className="space-y-3">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by farm name, email, phone #, or UID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:outline-indigo-500 transition-all shadow-inner"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery("")}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 font-bold text-xs cursor-pointer"
                  >
                    ×
                  </button>
                )}
              </div>

              {/* Dynamic Live Matching Farm Node Names as Search is typed */}
              {searchQuery && filteredNodes.length > 0 && (
                <div className="space-y-1.5 p-2.5 bg-indigo-50/70 border border-indigo-150 rounded-xl animate-fade-in">
                  <div className="text-[10px] font-black text-indigo-800 uppercase tracking-wider flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <Tractor className="w-3 h-3 text-indigo-600" /> Matched Farm Node Names ({filteredNodes.length}):
                    </span>
                    <span className="text-[9.5px] text-indigo-500 font-bold">Click name to select</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                    {filteredNodes.map(node => (
                      <button
                        key={node.id}
                        type="button"
                        onClick={() => handleSelectNode(node)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                          selectedNodeId === node.id
                            ? "bg-indigo-600 text-white shadow-sm ring-2 ring-indigo-300"
                            : "bg-white text-indigo-900 border border-indigo-200 hover:bg-indigo-100/80"
                        }`}
                        title={`Select farm node ${node.name}`}
                      >
                        <span>{node.name}</span>
                        <span className="text-[9.5px] font-mono opacity-75">({node.smsCreditBalance} SMS)</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {searchQuery && (
                <div className="text-[10.5px] text-slate-500 font-semibold flex justify-between items-center px-1">
                  <span>Found {filteredNodes.length} of {nodes.length} nodes</span>
                  <button
                    type="button"
                    onClick={() => setSearchQuery("")}
                    className="text-indigo-600 hover:underline font-bold text-[10px] cursor-pointer"
                  >
                    Clear Filter
                  </button>
                </div>
              )}

              <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 border border-slate-100 rounded-xl">
                {filteredNodes.length === 0 ? (
                  <div className="p-4 text-center space-y-1">
                    <p className="text-[11px] text-slate-400 font-bold">No matching {nodeType === "farm_nodes" ? "farm nodes" : "institutions"} found for "{searchQuery}".</p>
                    <p className="text-[10px] text-slate-400">Try searching by email address, mobile phone number, farm node name, or tenant UID.</p>
                  </div>
                ) : (
                  filteredNodes.map(node => (
                    <button
                      key={node.id}
                      type="button"
                      onClick={() => handleSelectNode(node)}
                      className={`w-full text-left px-3.5 py-3 text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                        selectedNodeId === node.id ? "bg-indigo-50 text-indigo-800 border-l-4 border-indigo-600" : "hover:bg-slate-50 text-slate-700"
                      }`}
                    >
                      <div className="truncate pr-2 space-y-1">
                        <div className="flex items-center gap-1.5">
                          <p className="truncate font-black text-slate-900 text-[12.5px]">{node.name}</p>
                          {node.type === "farm_node" && (
                            <span className="px-1.5 py-0.2 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[9px] font-extrabold rounded">
                              Farm Node
                            </span>
                          )}
                        </div>

                        {/* Search match criterion badge */}
                        {searchQuery && (node as any).matchType && (
                          <div className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded text-[9.5px] font-bold">
                            {(node as any).matchType === "email" && `📧 Matched Email: ${node.email}`}
                            {(node as any).matchType === "phone" && `📱 Matched Phone: ${node.phone}`}
                            {(node as any).matchType === "uid" && `🔑 Matched UID: ${node.id}`}
                            {(node as any).matchType === "name" && `🚜 Matched Farm Name: ${node.name}`}
                          </div>
                        )}

                        <div className="flex items-center gap-1.5 flex-wrap text-[10px] text-slate-500 font-mono">
                          {node.email && <span className="truncate max-w-[150px]">{node.email}</span>}
                          {node.phone && <span>• {node.phone}</span>}
                          <span className="text-slate-400">• UID: {node.id.slice(0, 10)}...</span>
                        </div>
                      </div>
                      <span className="font-mono text-[10px] bg-slate-100 text-indigo-700 border border-slate-200 px-2 py-0.5 rounded-lg font-black shrink-0">
                        {node.smsCreditBalance.toLocaleString()} SMS
                      </span>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Balance Widget */}
          {selectedNode && (
            <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-900 text-white border border-indigo-800/60 rounded-2xl p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black text-indigo-300 uppercase tracking-wider font-mono">
                  {selectedNode.type === "farm_nodes" ? "Farm Node Balance" : "Institution Balance"}
                </span>
                <MessageSquare className="w-5 h-5 text-indigo-400" />
              </div>

              <div className="space-y-1">
                <h4 className="text-3xl font-black text-white font-mono flex items-baseline gap-2">
                  {currentBalance.toLocaleString()}
                  <span className="text-xs font-bold text-indigo-300 uppercase font-sans">SMS Credits</span>
                </h4>
                <p className="text-[11px] text-slate-400 font-medium truncate">
                  Node: <strong className="text-slate-200">{selectedNode.name}</strong>
                </p>
              </div>

              <div className="border-t border-slate-800 pt-3 flex justify-between text-xs">
                <div>
                  <span className="text-[9px] text-slate-400 font-bold uppercase block">SMS Rate</span>
                  <span className="font-mono font-black text-emerald-400">ZMW {smsRate.toFixed(2)} / SMS</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 font-bold uppercase block">Gateway</span>
                  <span className="font-bold text-indigo-300 font-mono">Beem (Selo)</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Center/Right Col (span 2): Transaction adjustments and ledger lists */}
        <div className="xl:col-span-2 space-y-6">
          {selectedNode ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Form Col: Adjustment Inputs */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4 md:col-span-1">
                <div>
                  <h3 className="text-sm font-extrabold uppercase text-slate-700 tracking-wider flex items-center gap-1">
                    <Sliders className="w-4 h-4 text-indigo-600" /> Adjust SMS Credits
                  </h3>
                  <p className="text-[11px] text-slate-400 font-medium">Allocate or deduct SMS balance.</p>
                </div>

                {formMsg && (
                  <div className={`p-3 rounded-xl text-xs flex items-center gap-1.5 ${
                    formMsg.type === "success" ? "bg-emerald-50 text-emerald-800 border border-emerald-200" : "bg-rose-50 text-rose-800 border border-rose-200"
                  }`}>
                    {formMsg.type === "success" ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" /> : <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />}
                    <span className="font-bold">{formMsg.text}</span>
                  </div>
                )}

                <form onSubmit={handleSubmitAdjustment} className="space-y-3">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Adjustment Action</label>
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        type="button"
                        onClick={() => setAdjType("allocate")}
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                          adjType === "allocate" ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                        }`}
                      >
                        + Allocate
                      </button>
                      <button
                        type="button"
                        onClick={() => setAdjType("deduct")}
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                          adjType === "deduct" ? "bg-rose-600 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                        }`}
                      >
                        - Deduct
                      </button>
                      <button
                        type="button"
                        onClick={() => setAdjType("set")}
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                          adjType === "set" ? "bg-sky-600 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                        }`}
                      >
                        = Set Exact
                      </button>
                      <button
                        type="button"
                        onClick={() => setAdjType("zero_rate")}
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                          adjType === "zero_rate" ? "bg-amber-600 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                        }`}
                      >
                        0 Zero-Rate
                      </button>
                    </div>
                  </div>

                  {adjType !== "zero_rate" && (
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">SMS Credit Amount</label>
                      <input
                        type="number"
                        required
                        min="1"
                        placeholder="e.g. 250"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:outline-indigo-500"
                      />
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {[50, 100, 250, 500, 1000].map(amt => (
                          <button
                            key={amt}
                            type="button"
                            onClick={() => setAmount(String(amt))}
                            className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold rounded cursor-pointer"
                          >
                            +{amt}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Audit Reference</label>
                    <input
                      type="text"
                      placeholder="e.g. SUPER_ADMIN_ALLOC_2026"
                      value={reference}
                      onChange={(e) => setReference(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:outline-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Justification Reason</label>
                    <textarea
                      rows={2}
                      placeholder="Reason for allocation or adjustment..."
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:outline-indigo-500 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-50 text-white font-black text-xs uppercase tracking-wider rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    {isSubmitting ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Plus className="w-4 h-4" />
                    )}
                    {adjType === "zero_rate" ? "Reset SMS Balance to 0" : "Commit SMS Allocation"}
                  </button>
                </form>
              </div>

              {/* Table Col: Ledger Table */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm md:col-span-2 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-extrabold uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                      <Database className="w-4 h-4 text-indigo-600" /> SMS Ledger Logs
                    </h3>
                    <p className="text-[11px] text-slate-400 font-medium">History of grants, deductions, campaign dispatches & resets.</p>
                  </div>
                  <button
                    onClick={() => handleSelectNode(selectedNode)}
                    className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-indigo-600 transition cursor-pointer"
                    title="Reload ledger feed"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
                  </button>
                </div>

                <div className="border border-slate-100 rounded-2xl overflow-hidden bg-slate-50/20 max-h-[460px] overflow-y-auto">
                  {ledger.length === 0 ? (
                    <div className="text-center py-20 text-slate-400 space-y-2">
                      <FileText className="w-8 h-8 mx-auto text-slate-300" />
                      <p className="text-xs font-bold font-mono">No SMS ledger records found for this node.</p>
                      <p className="text-[10px] text-slate-400 max-w-xs mx-auto">Allocations and SMS campaign deductions will be permanently recorded here.</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100">
                      {ledger.map((entry) => (
                        <div key={entry.id} className="p-3.5 hover:bg-slate-50 transition-colors flex items-start justify-between gap-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className={`px-2 py-0.5 text-[9px] font-black uppercase rounded-full ${
                                entry.type === "top_up" || (entry.amount && entry.amount > 0) ? "bg-emerald-50 text-emerald-700 border border-emerald-200" :
                                entry.type === "zero_rate" ? "bg-amber-50 text-amber-700 border border-amber-200" :
                                "bg-rose-50 text-rose-700 border border-rose-200"
                              }`}>
                                {entry.type}
                              </span>
                              <span className="text-[10px] font-mono text-slate-500 font-semibold">{entry.reference || entry.id}</span>
                            </div>

                            {entry.note && (
                              <p className="text-xs text-slate-800 font-medium">{entry.note}</p>
                            )}

                            <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                              <Clock className="w-3 h-3" />
                              <span>{entry.createdAt ? new Date(entry.createdAt).toLocaleString() : "Recent"}</span>
                              {entry.authorizedBy && (
                                <span>• By: {entry.authorizedBy}</span>
                              )}
                            </div>
                          </div>

                          <div className="text-right">
                            <span className={`text-xs font-mono font-black px-2 py-0.5 rounded-lg inline-flex items-center gap-0.5 ${
                              (entry.amount || 0) >= 0 ? "text-emerald-700 bg-emerald-50 border border-emerald-100" : "text-rose-700 bg-rose-50 border border-rose-100"
                            }`}>
                              {(entry.amount || 0) >= 0 ? <ArrowUpRight className="w-3 h-3 text-emerald-500" /> : <ArrowDownLeft className="w-3 h-3 text-rose-500" />}
                              {(entry.amount || 0) >= 0 ? "+" : ""}{(entry.amount || 0).toLocaleString()} SMS
                            </span>
                            {entry.balanceAfter !== undefined && (
                              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                                Bal: {entry.balanceAfter.toLocaleString()}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-2xl p-12 shadow-sm text-center text-slate-400 space-y-3">
              <Tractor className="w-12 h-12 mx-auto text-slate-300" />
              <h4 className="text-sm font-black text-slate-700">No Farm Node Selected</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">Please search and select a farm node or institution in the left panel to allocate SMS credits and view its transaction history.</p>
            </div>
          )}
        </div>

      </div>

      {/* GLOBAL ZERO-RATE MODAL */}
      {showZeroRateModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-[99999] flex items-center justify-center p-4">
          <div className="bg-slate-900 text-white rounded-2xl border border-slate-800 shadow-2xl max-w-md w-full p-6 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <RotateCcw className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-lg font-black text-white">Zero-Rate All Platform SMS Balances?</h3>
              <p className="text-xs text-slate-300 leading-relaxed font-medium">
                This operation will set the SMS credit balance to <strong className="text-white">0 SMS Credits</strong> across all farm node wallets and institutions on the entire platform.
              </p>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-[11px] font-mono text-slate-400 space-y-1">
              <div><strong>Auditor:</strong> {auth.currentUser?.email || "support@mabala.cloud"}</div>
              <div><strong>Scope:</strong> All users_data + platform/institutions</div>
              <div><strong>Action:</strong> Set smsCredits = 0</div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowZeroRateModal(false)}
                disabled={isZeroRatingGlobal}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteGlobalZeroRate}
                disabled={isZeroRatingGlobal}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-lg"
              >
                {isZeroRatingGlobal ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />}
                <span>Confirm Zero-Rate</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

import React from "react";
import { ShieldCheck, Eye, ShieldAlert, Ban, CheckCircle2 } from "lucide-react";

interface AccessLevelBadgeProps {
  accessLevel?: "read_write" | "read_only" | string;
  status?: "active" | "suspended" | "inactive" | "removed" | string;
  showStatus?: boolean;
  size?: "sm" | "md" | "lg";
  className?: string;
}

export const AccessLevelBadge: React.FC<AccessLevelBadgeProps> = ({
  accessLevel = "read_write",
  status = "active",
  showStatus = false,
  size = "md",
  className = "",
}) => {
  const isReadOnly = accessLevel === "read_only";
  const isSuspended = status === "suspended";
  const isInactive = status === "inactive" || status === "removed";

  const sizeClasses = {
    sm: "px-2 py-0.5 text-[9px] gap-1",
    md: "px-2.5 py-1 text-[10px] gap-1.5",
    lg: "px-3 py-1.5 text-xs gap-2"
  }[size];

  const iconSizes = {
    sm: "w-2.5 h-2.5",
    md: "w-3 h-3",
    lg: "w-3.5 h-3.5"
  }[size];

  if (isSuspended) {
    return (
      <div className={`inline-flex items-center ${sizeClasses} rounded-full font-black uppercase tracking-wider bg-rose-100 text-rose-800 border border-rose-300 shadow-sm ${className}`} title="Account is suspended. Security rules instantly block all database queries.">
        <Ban className={`${iconSizes} text-rose-600 animate-pulse`} />
        <span>Suspended (Blocked)</span>
      </div>
    );
  }

  if (isInactive) {
    return (
      <div className={`inline-flex items-center ${sizeClasses} rounded-full font-bold uppercase tracking-wider bg-slate-100 text-slate-600 border border-slate-300 ${className}`}>
        <ShieldAlert className={`${iconSizes} text-slate-500`} />
        <span>Inactive</span>
      </div>
    );
  }

  return (
    <div className="inline-flex items-center gap-1.5">
      <div
        className={`inline-flex items-center ${sizeClasses} rounded-full font-black uppercase tracking-wider shadow-xs transition-colors ${
          isReadOnly
            ? "bg-indigo-50 text-indigo-800 border border-indigo-200 hover:bg-indigo-100/80"
            : "bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100/80"
        } ${className}`}
        title={
          isReadOnly
            ? "Read-Only: Sub-user can view farm records, financial metrics, and export data, but cannot write or modify transactions."
            : "Read & Write: Sub-user has full operational write permissions to record harvests, create sales, edit inventory, and update logs."
        }
      >
        {isReadOnly ? (
          <>
            <Eye className={`${iconSizes} text-indigo-600 shrink-0`} />
            <span className="whitespace-nowrap">Read-Only</span>
          </>
        ) : (
          <>
            <ShieldCheck className={`${iconSizes} text-emerald-600 shrink-0`} />
            <span className="whitespace-nowrap">Read & Write</span>
          </>
        )}
      </div>

      {showStatus && status === "active" && (
        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60" title="Active status">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          Active
        </span>
      )}
    </div>
  );
};

export default AccessLevelBadge;

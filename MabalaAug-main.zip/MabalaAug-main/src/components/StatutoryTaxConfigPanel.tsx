import React, { useState, useEffect } from "react";
import {
  ShieldCheck,
  Building2,
  FileCheck2,
  Zap,
  CheckCircle2,
  AlertCircle,
  History,
  Scale,
  Percent,
  Calculator,
  Globe,
  RefreshCw,
  FileText
} from "lucide-react";
import {
  StatutoryTaxConfig,
  getStatutoryTaxConfig,
  subscribeTaxConfig,
  saveStatutoryTaxConfig,
  fetchStatutoryTaxConfig,
  TaxAuditLogEntry
} from "../services/taxConfigService";

interface Props {
  currencySymbol?: string;
  userEmail?: string;
  onConfigSaved?: (config: StatutoryTaxConfig) => void;
}

export default function StatutoryTaxConfigPanel({
  currencySymbol = "ZMW",
  userEmail = "superadmin@mabala.zm",
  onConfigSaved
}: Props) {
  const [config, setConfig] = useState<StatutoryTaxConfig>(getStatutoryTaxConfig());
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [changeNotes, setChangeNotes] = useState<string>("");

  // Simulator test variables
  const [simAmount, setSimAmount] = useState<number>(10000);
  const [simHistoricalRate, setSimHistoricalRate] = useState<number>(15);

  useEffect(() => {
    // Initial fetch from Firestore
    fetchStatutoryTaxConfig().then((loaded) => setConfig(loaded));

    // Subscribe to changes
    const unsubscribe = subscribeTaxConfig((latest) => {
      setConfig(latest);
    });

    return () => unsubscribe();
  }, []);

  const handleFieldChange = <K extends keyof StatutoryTaxConfig>(field: K, value: StatutoryTaxConfig[K]) => {
    setConfig((prev) => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePublishTaxRates = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveStatus(null);
    setSaveError(null);

    try {
      const notesToUse = changeNotes.trim() || `Published statutory tax update: VAT ${config.vatRate}%, TOT ${config.totRate}%, PAYE ${config.payeFlatRate}%`;
      const saved = await saveStatutoryTaxConfig(config, userEmail, notesToUse);
      setSaveStatus("✓ Statutory Tax Rate Card published & live-synced to superAdmin/platformConfig/tax! Applied prospectively platform-wide.");
      setChangeNotes("");
      if (onConfigSaved) onConfigSaved(saved);
      setTimeout(() => setSaveStatus(null), 6000);
    } catch (err: any) {
      console.error("[StatutoryTaxConfigPanel] Save failed:", err);
      setSaveError("Failed to publish tax configuration: " + err.message);
    } finally {
      setIsSaving(false);
    }
  };

  // Live simulation math
  const newAppliedVat = (simAmount * config.vatRate) / 100;
  const historicalVat = (simAmount * simHistoricalRate) / 100;

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6 animate-fade-in font-sans text-slate-900">
      {/* Panel Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-2xl">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Statutory Tax — Single Source of Truth Rate Card
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Authoritative platform tax rates stored at <code className="bg-slate-100 text-emerald-700 px-1.5 py-0.5 rounded font-mono font-bold">superAdmin/platformConfig/tax</code>
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={handlePublishTaxRates}
          disabled={isSaving}
          className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-300 text-white font-extrabold text-xs rounded-xl shadow-md active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
        >
          <Zap className="w-4 h-4 text-amber-300" />
          <span>{isSaving ? "Publishing Rates..." : "Publish Statutory Rates"}</span>
        </button>
      </div>

      {/* Notifications */}
      {saveStatus && (
        <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl flex items-center gap-3 text-xs font-bold text-emerald-800 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{saveStatus}</span>
        </div>
      )}
      {saveError && (
        <div className="bg-rose-50 border border-rose-200 p-4 rounded-2xl flex items-center gap-3 text-xs font-bold text-rose-800 animate-fade-in">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{saveError}</span>
        </div>
      )}

      {/* Prospective Immutability Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-teal-950 text-white p-5 rounded-2xl border border-slate-800 space-y-2 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h4 className="text-xs font-black uppercase tracking-wider text-emerald-300">
              Mandatory Rule: Prospective Application & Historical Record Immutability
            </h4>
          </div>
          <span className="px-2.5 py-0.5 bg-emerald-800 text-emerald-200 rounded-full font-mono text-[9px] font-black uppercase border border-emerald-600">
            Audit Ready
          </span>
        </div>
        <p className="text-xs text-slate-200 leading-relaxed font-medium">
          Rate updates apply <strong>prospectively only</strong>. Any invoice, credit note, receipt, or payslip generated under a previous tax rate preserves its originally stored tax amount and applied rate percentage. Historical tax returns and invoices will never dynamically mutate when platform statutory rates are updated.
        </p>
      </div>

      {/* Core Statutory Tax Rate Input Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Standard VAT Rate */}
        <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-2xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-emerald-800 uppercase tracking-wider font-mono">
              Standard VAT Rate (%)
            </span>
            <span className="p-1 bg-emerald-100 text-emerald-700 rounded-md">
              <Percent className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="number"
              step="0.1"
              min="0"
              max="100"
              value={config.vatRate}
              onChange={(e) => handleFieldChange("vatRate", parseFloat(e.target.value) || 0)}
              className="w-full p-2.5 bg-white border border-emerald-300 rounded-xl font-mono font-black text-lg text-emerald-900 outline-none focus:border-emerald-600"
            />
            <span className="font-mono text-emerald-700 font-extrabold">%</span>
          </div>
          <p className="text-[10px] text-emerald-700 font-medium">
            Applied on standard taxable goods, commercial invoices, and input/output tax returns.
          </p>
        </div>

        {/* Turnover Tax (TOT) Rate */}
        <div className="p-4 bg-amber-50/60 border border-amber-200 rounded-2xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-amber-900 uppercase tracking-wider font-mono">
              Turnover Tax (TOT) Rate (%)
            </span>
            <span className="p-1 bg-amber-100 text-amber-800 rounded-md">
              <Percent className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="number"
              step="0.1"
              min="0"
              max="100"
              value={config.totRate}
              onChange={(e) => handleFieldChange("totRate", parseFloat(e.target.value) || 0)}
              className="w-full p-2.5 bg-white border border-amber-300 rounded-xl font-mono font-black text-lg text-amber-950 outline-none focus:border-amber-600"
            />
            <span className="font-mono text-amber-800 font-extrabold">%</span>
          </div>
          <p className="text-[10px] text-amber-800 font-medium">
            Flat gross turnover tax rate levied on small business statutory returns.
          </p>
        </div>

        {/* PAYE Flat Rate & Threshold */}
        <div className="p-4 bg-blue-50/60 border border-blue-200 rounded-2xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-blue-900 uppercase tracking-wider font-mono">
              Statutory PAYE Tax Rate (%)
            </span>
            <span className="p-1 bg-blue-100 text-blue-800 rounded-md">
              <Calculator className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="number"
              step="0.5"
              min="0"
              max="100"
              value={config.payeFlatRate}
              onChange={(e) => handleFieldChange("payeFlatRate", parseFloat(e.target.value) || 0)}
              className="w-full p-2.5 bg-white border border-blue-300 rounded-xl font-mono font-black text-lg text-blue-950 outline-none focus:border-blue-600"
            />
            <span className="font-mono text-blue-800 font-extrabold">%</span>
          </div>
          <div className="pt-1">
            <label className="text-[9px] font-bold text-blue-800 uppercase block mb-1">
              Tax-Free Threshold ({currencySymbol})
            </label>
            <input
              type="number"
              value={config.payeThreshold}
              onChange={(e) => handleFieldChange("payeThreshold", parseFloat(e.target.value) || 0)}
              className="w-full p-1.5 bg-white border border-blue-200 rounded-lg font-mono font-bold text-xs text-blue-900 outline-none"
            />
          </div>
        </div>

        {/* Custom Tax System Rate */}
        <div className="p-4 bg-purple-50/60 border border-purple-200 rounded-2xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-purple-900 uppercase tracking-wider font-mono">
              Custom Tax System Rate (%)
            </span>
            <span className="p-1 bg-purple-100 text-purple-800 rounded-md">
              <Globe className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="number"
              step="0.5"
              min="0"
              max="100"
              value={config.customTaxRate}
              onChange={(e) => handleFieldChange("customTaxRate", parseFloat(e.target.value) || 0)}
              className="w-full p-2.5 bg-white border border-purple-300 rounded-xl font-mono font-black text-lg text-purple-950 outline-none focus:border-purple-600"
            />
            <span className="font-mono text-purple-800 font-extrabold">%</span>
          </div>
          <div className="pt-1">
            <label className="text-[9px] font-bold text-purple-800 uppercase block mb-1">Custom Tax Label</label>
            <input
              type="text"
              value={config.customTaxName}
              onChange={(e) => handleFieldChange("customTaxName", e.target.value)}
              className="w-full p-1.5 bg-white border border-purple-200 rounded-lg font-bold text-xs text-purple-950 outline-none"
            />
          </div>
        </div>
      </div>

      {/* Change Notes & Active Regime Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50 p-5 rounded-2xl border border-slate-200">
        <div className="space-y-3">
          <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-700" />
            <span>Default Platform Active Statutory Tax Regime</span>
          </h4>
          <select
            value={config.activeTaxSystem}
            onChange={(e) => handleFieldChange("activeTaxSystem", e.target.value as any)}
            className="w-full p-3 bg-white border border-slate-300 rounded-xl font-bold text-xs text-slate-800 outline-none focus:border-emerald-600 cursor-pointer"
          >
            <option value="VAT">Standard VAT Regime (Default {config.vatRate}%)</option>
            <option value="TOT">Turnover Tax Regime (Small Business {config.totRate}%)</option>
            <option value="CUSTOM">Custom Statutory Tax ({config.customTaxName} - {config.customTaxRate}%)</option>
            <option value="EXEMPT">Agricultural Produce Tax Exempt (0.0%)</option>
          </select>
          <p className="text-[11px] text-slate-500">
            Selected system governs default compliance calculations across all newly created farm nodes and tenant ledger accounts.
          </p>
        </div>

        <div className="space-y-3">
          <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-700" />
            <span>Super Admin Audit Trail Note (Mandatory for Traceability)</span>
          </h4>
          <input
            type="text"
            placeholder="e.g. Updated standard VAT rate in response to ZRA 2026 statutory amendment."
            value={changeNotes}
            onChange={(e) => setChangeNotes(e.target.value)}
            className="w-full p-3 bg-white border border-slate-300 rounded-xl font-medium text-xs text-slate-800 outline-none focus:border-emerald-600"
          />
          <p className="text-[10px] text-slate-400 font-mono">
            Recorded in the immutable Super Admin audit log at superAdmin/platformConfig/tax.
          </p>
        </div>
      </div>

      {/* Prospective Immutability Live Simulator */}
      <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 space-y-4 shadow-md">
        <div className="flex justify-between items-center">
          <h4 className="text-xs font-black uppercase tracking-wider text-emerald-400 flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-300" />
            <span>Prospective Calculation & Immutability Audit Simulator</span>
          </h4>
          <span className="text-[9px] font-mono text-slate-400">Zero Historical Drift Verification</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-[10px] font-bold uppercase text-slate-300 block mb-1">
              Sample Invoice Amount ({currencySymbol})
            </label>
            <input
              type="number"
              value={simAmount}
              onChange={(e) => setSimAmount(Number(e.target.value) || 0)}
              className="w-full p-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-mono font-bold text-xs outline-none"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase text-slate-300 block mb-1">
              Historical Invoice Stored Tax Rate (%)
            </label>
            <input
              type="number"
              value={simHistoricalRate}
              onChange={(e) => setSimHistoricalRate(Number(e.target.value) || 0)}
              className="w-full p-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-mono font-bold text-xs outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1 font-mono">
          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 space-y-1">
            <span className="text-[9.5px] text-slate-400 block uppercase font-bold">
              📜 Historical Invoice #INV-2025-001 (Immutable)
            </span>
            <div className="flex justify-between items-center">
              <span className="text-xs text-slate-300">Stored Rate: {simHistoricalRate}%</span>
              <span className="text-sm font-black text-amber-300">
                VAT: {currencySymbol} {historicalVat.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>
            <p className="text-[9px] text-emerald-400 font-sans font-medium mt-1">
              ✓ Preserves stored rate of {simHistoricalRate}% despite platform config changes.
            </p>
          </div>

          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 space-y-1">
            <span className="text-[9.5px] text-slate-400 block uppercase font-bold">
              ✨ Newly Created Invoice #INV-2026-999 (Prospective)
            </span>
            <div className="flex justify-between items-center">
              <span className="text-xs text-slate-300">Active Rate: {config.vatRate}%</span>
              <span className="text-sm font-black text-emerald-400">
                VAT: {currencySymbol} {newAppliedVat.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>
            <p className="text-[9px] text-emerald-400 font-sans font-medium mt-1">
              ✓ Uses authoritative single source of truth rate of {config.vatRate}%.
            </p>
          </div>
        </div>
      </div>

      {/* Super Admin Audit Trail Table */}
      <div className="space-y-3 pt-2">
        <div className="flex justify-between items-center">
          <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
            <History className="w-4 h-4 text-emerald-700" />
            <span>Super Admin Rate Card Change Audit Trail</span>
          </h4>
          <span className="text-[10px] font-mono text-slate-400 font-bold">
            {config.auditTrail?.length || 0} Total Recorded Entries
          </span>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-2xl">
          <table className="w-full text-left text-xs bg-white text-slate-800 font-sans">
            <thead className="bg-slate-50 font-black text-[9px] text-slate-500 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3">Timestamp</th>
                <th className="p-3">Super Admin</th>
                <th className="p-3">Previous Rate Card</th>
                <th className="p-3">New Rate Card</th>
                <th className="p-3">Audit Note / Reason</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {!config.auditTrail || config.auditTrail.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-6 text-center text-slate-400 italic">
                    No statutory tax audit entries logged.
                  </td>
                </tr>
              ) : (
                config.auditTrail.map((log: TaxAuditLogEntry) => (
                  <tr key={log.id} className="hover:bg-slate-50 transition">
                    <td className="p-3 font-mono text-[10.5px] text-slate-600">
                      {new Date(log.updatedAt).toLocaleString()}
                    </td>
                    <td className="p-3 font-bold text-slate-900">{log.updatedBy}</td>
                    <td className="p-3 font-mono text-[10px] text-rose-700 bg-rose-50/50 rounded">
                      {log.previousRateCardSummary}
                    </td>
                    <td className="p-3 font-mono text-[10px] text-emerald-700 bg-emerald-50/50 rounded font-bold">
                      {log.newRateCardSummary}
                    </td>
                    <td className="p-3 text-slate-600 max-w-xs truncate">{log.notes || "—"}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

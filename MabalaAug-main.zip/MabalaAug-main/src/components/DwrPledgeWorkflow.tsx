import { safeFormatError } from "../utils/errorUtils";
import React, { useState, useEffect } from "react";
import { 
  Award, 
  Plus, 
  Search, 
  Filter, 
  RefreshCw, 
  Calendar, 
  AlertTriangle, 
  CheckCircle2, 
  X, 
  Check, 
  CloudRain, 
  Clock, 
  DollarSign, 
  User, 
  Layers, 
  Ban, 
  FileText, 
  Sparkles, 
  ChevronRight,
  TrendingUp,
  ShieldCheck,
  AlertCircle
} from "lucide-react";

interface DwrPledge {
  id: string;
  institutionId: string;
  farmerId: string;
  farmerName: string;
  farmNodeId: string;
  cropCycleId: string;
  cropType: string;
  pledgeAmountZMW: number;
  expiryDate: string;
  riskTriggerType: string;
  status: "Active" | "Pledged" | "Fulfilled" | "Expired" | "Revoked";
  notes: string;
  createdAt: string;
  createdBy: string;
}

interface SummaryStats {
  totalPledges: number;
  totalPledgedValueZmw: number;
  activePledgeCount: number;
  fulfilledPledgeCount: number;
  coveredFarmersCount: number;
}

interface Props {
  getAuthHeader: () => Record<string, string>;
  linkedFarmers?: any[];
}

export default function DwrPledgeWorkflow({ getAuthHeader, linkedFarmers = [] }: Props) {
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [pledges, setPledges] = useState<DwrPledge[]>([]);
  const [summary, setSummary] = useState<SummaryStats | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Filters
  const [activeTab, setActiveTab] = useState<"all" | "Active" | "Fulfilled" | "Expired" | "Revoked">("all");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Create Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Form Fields
  const [selectedFarmerId, setSelectedFarmerId] = useState<string>("");
  const [manualFarmerName, setManualFarmerName] = useState<string>("");
  const [farmNodeId, setFarmNodeId] = useState<string>("Monze South - Zone A1");
  const [cropCycleId, setCropCycleId] = useState<string>("CC-2026-MAIZE-01");
  const [cropType, setCropType] = useState<string>("Maize (Hybrid SC 637)");
  const [pledgeAmountZmw, setPledgeAmountZmw] = useState<number>(3500);
  const [expiryDate, setExpiryDate] = useState<string>("2026-11-30");
  const [riskTriggerType, setRiskTriggerType] = useState<string>("Severe Drought Index (>35% deficit)");
  const [notes, setNotes] = useState<string>("");

  // Edit / Status Action State
  const [actionTargetPledge, setActionTargetPledge] = useState<DwrPledge | null>(null);
  const [actionModalType, setActionModalType] = useState<"fulfill" | "revoke" | "extend" | null>(null);
  const [extendDate, setExtendDate] = useState<string>("");
  const [actionNotes, setActionNotes] = useState<string>("");

  const fetchPledges = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const headers = getAuthHeader();
      const res = await fetch("/api/institution/dwr-pledges", { headers });
      if (!res.ok) {
        throw new Error("Failed to load DWR pledges.");
      }
      const data = await res.json();
      setPledges(data.pledges || []);
      setSummary(data.summary || null);
    } catch (err: any) {
      setErrorMessage(err.message || "Error fetching DWR pledges.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPledges();
  }, []);

  const handleCreatePledge = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFarmerId && !manualFarmerName) {
      setErrorMessage("Please select or specify a target farmer for the DWR Pledge.");
      return;
    }

    let farmerName = manualFarmerName;
    if (selectedFarmerId && linkedFarmers.length > 0) {
      const found = linkedFarmers.find((f) => f.id === selectedFarmerId || f.uid === selectedFarmerId);
      if (found) {
        farmerName = found.name || found.displayName || found.email || manualFarmerName || "Linked Farmer";
      }
    }

    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      const headers = { ...getAuthHeader(), "Content-Type": "application/json" };
      const body = {
        farmerId: selectedFarmerId || `manual-${Date.now()}`,
        farmerName: farmerName || "Sponsoring Cohort Farmer",
        farmNodeId,
        cropCycleId,
        cropType,
        pledgeAmountZMW: Number(pledgeAmountZmw),
        expiryDate,
        riskTriggerType,
        notes
      };

      const res = await fetch("/api/institution/dwr-pledges", {
        method: "POST",
        headers,
        body: JSON.stringify(body)
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || "Failed to initiate DWR Pledge.");
      }

      const resData = await res.json();
      setSuccessMessage(`DWR Pledge ${resData.pledge?.id || ''} successfully initiated for ZMW ${pledgeAmountZmw.toLocaleString()}.`);
      setIsCreateModalOpen(false);
      resetForm();
      fetchPledges();

      setTimeout(() => setSuccessMessage(null), 5000);
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to initiate DWR pledge.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdatePledgeStatus = async () => {
    if (!actionTargetPledge || !actionModalType) return;

    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      const headers = { ...getAuthHeader(), "Content-Type": "application/json" };
      let newStatus: string | undefined = undefined;
      let newExpiry: string | undefined = undefined;

      if (actionModalType === "fulfill") {
        newStatus = "Fulfilled";
      } else if (actionModalType === "revoke") {
        newStatus = "Revoked";
      } else if (actionModalType === "extend") {
        newExpiry = extendDate;
      }

      const body = {
        status: newStatus,
        expiryDate: newExpiry,
        notes: actionNotes ? `${actionTargetPledge.notes || ''} | [Update]: ${actionNotes}` : undefined
      };

      const res = await fetch(`/api/institution/dwr-pledges/${actionTargetPledge.id}`, {
        method: "PATCH",
        headers,
        body: JSON.stringify(body)
      });

      if (!res.ok) {
        throw new Error("Failed to update DWR Pledge status.");
      }

      setSuccessMessage(`DWR Pledge ${actionTargetPledge.id} updated successfully.`);
      setActionTargetPledge(null);
      setActionModalType(null);
      setActionNotes("");
      fetchPledges();

      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to update pledge.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setSelectedFarmerId("");
    setManualFarmerName("");
    setFarmNodeId("Monze South - Zone A1");
    setCropCycleId("CC-2026-MAIZE-01");
    setCropType("Maize (Hybrid SC 637)");
    setPledgeAmountZmw(3500);
    setExpiryDate("2026-11-30");
    setRiskTriggerType("Severe Drought Index (>35% deficit)");
    setNotes("");
  };

  const filteredPledges = pledges.filter((p) => {
    const matchesTab = activeTab === "all" || p.status === activeTab;
    const matchesQuery = 
      !searchQuery ||
      p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.farmerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.farmNodeId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.cropCycleId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.cropType.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesQuery;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Active":
        return <span className="inline-flex items-center gap-1 bg-emerald-950 text-emerald-300 border border-emerald-800/80 px-2.5 py-1 rounded-full text-[10px] font-bold"><CheckCircle2 className="w-3 h-3 text-emerald-400" /> Active Guarantee</span>;
      case "Fulfilled":
        return <span className="inline-flex items-center gap-1 bg-indigo-950 text-indigo-300 border border-indigo-800/80 px-2.5 py-1 rounded-full text-[10px] font-bold"><Award className="w-3 h-3 text-indigo-400" /> Fulfilled Payout</span>;
      case "Expired":
        return <span className="inline-flex items-center gap-1 bg-slate-900 text-slate-400 border border-slate-700 px-2.5 py-1 rounded-full text-[10px] font-bold"><Clock className="w-3 h-3" /> Season Expired</span>;
      case "Revoked":
        return <span className="inline-flex items-center gap-1 bg-rose-950 text-rose-300 border border-rose-800/80 px-2.5 py-1 rounded-full text-[10px] font-bold"><Ban className="w-3 h-3 text-rose-400" /> Revoked</span>;
      default:
        return <span className="inline-flex items-center gap-1 bg-slate-800 text-slate-300 px-2.5 py-1 rounded-full text-[10px] font-bold">{status}</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-950 to-indigo-950 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 bg-indigo-950/80 border border-indigo-800/60 text-indigo-300 px-3 py-1 rounded-full text-xs font-mono font-semibold mb-2">
            <CloudRain className="w-3.5 h-3.5 text-indigo-400" />
            <span>Direct Weather Risk (DWR) Relief Guarantee Engine</span>
          </div>
          <h2 className="text-xl font-extrabold text-white tracking-tight">DWR Pledge Workflow & Crop Risk Coverage</h2>
          <p className="text-slate-400 text-xs mt-1 max-w-2xl">
            Initiate, track, and fulfill weather-indexed financial guarantees directly against specific farmer farm nodes and active crop cycles.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-500/30 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-lg shadow-emerald-600/20 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Initiate DWR Pledge</span>
          </button>

          <button
            onClick={fetchPledges}
            disabled={isLoading}
            className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-3 py-2.5 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Notifications */}
      {successMessage && (
        <div className="bg-emerald-950/80 border border-emerald-800 text-emerald-200 p-4 rounded-2xl text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage(null)} className="text-emerald-400 hover:text-emerald-200">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="bg-rose-950/80 border border-rose-800 text-rose-200 p-4 rounded-2xl text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{safeFormatError(errorMessage)}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-rose-400 hover:text-rose-200">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 shadow-lg">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Total Active Pledge Exposure</span>
          <div className="text-2xl font-black text-emerald-400 mt-1 font-mono">
            ZMW {(summary?.totalPledgedValueZmw || 0).toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">Institutional backing</span>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 shadow-lg">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Active Guarantees</span>
          <div className="text-2xl font-black text-white mt-1 font-mono">{summary?.activePledgeCount || 0}</div>
          <span className="text-[10px] text-slate-500 mt-1 block">Live crop cycles</span>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 shadow-lg">
          <span className="text-[10px] font-mono text-indigo-400 uppercase tracking-wider">Covered Farm Nodes</span>
          <div className="text-2xl font-black text-indigo-400 mt-1 font-mono">{summary?.coveredFarmersCount || 0}</div>
          <span className="text-[10px] text-indigo-500/80 mt-1 block">Unique farmer nodes</span>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 shadow-lg">
          <span className="text-[10px] font-mono text-indigo-300 uppercase tracking-wider">Fulfilled Payouts</span>
          <div className="text-2xl font-black text-indigo-300 mt-1 font-mono">{summary?.fulfilledPledgeCount || 0}</div>
          <span className="text-[10px] text-indigo-400/80 mt-1 block">Relief funds released</span>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 shadow-lg">
          <span className="text-[10px] font-mono text-amber-400 uppercase tracking-wider">Default Risk Protection</span>
          <div className="text-2xl font-black text-amber-400 mt-1 font-mono">100%</div>
          <span className="text-[10px] text-amber-500/80 mt-1 block">Direct Weather Indexed</span>
        </div>
      </div>

      {/* Main Table & Filters */}
      <div className="bg-slate-950 border border-slate-800/80 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-850 pb-4">
          {/* Status Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
            {(["all", "Active", "Fulfilled", "Expired", "Revoked"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === tab
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
                    : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
                }`}
              >
                {tab === "all" ? "All Pledges" : tab}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search pledge #, farmer, node, crop..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 w-full sm:w-64"
            />
          </div>
        </div>

        {/* Pledges Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/80 text-slate-400 text-[10px] font-mono uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Pledge Ref & Farmer</th>
                <th className="py-3 px-4">Target Farm Node & Crop Cycle</th>
                <th className="py-3 px-4">Pledge Amount (ZMW)</th>
                <th className="py-3 px-4">Risk Trigger Condition</th>
                <th className="py-3 px-4">Expiry Date</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {filteredPledges.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500 font-mono">
                    No DWR pledges found. Click "+ Initiate DWR Pledge" above to create one.
                  </td>
                </tr>
              ) : (
                filteredPledges.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-extrabold text-white font-mono text-xs flex items-center gap-1.5">
                        <Award className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                        <span>{p.id}</span>
                      </div>
                      <div className="text-slate-300 font-semibold mt-0.5">{p.farmerName}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-mono text-[11px] text-emerald-400">{p.farmNodeId}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {p.cropCycleId} • {p.cropType}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-black text-sm text-white">
                      ZMW {(p.pledgeAmountZMW || 0).toLocaleString()}
                    </td>

                    <td className="py-3.5 px-4 text-xs font-medium text-slate-300">
                      <span className="bg-slate-900 border border-slate-800 px-2 py-1 rounded-lg text-[11px] inline-block">
                        {p.riskTriggerType}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 font-mono text-[11px] text-slate-300">
                      <div>{p.expiryDate}</div>
                      {new Date(p.expiryDate) < new Date() && p.status === "Active" && (
                        <span className="text-[9px] text-rose-400 font-bold block">Expiring / Overdue</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      {getStatusBadge(p.status)}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      {p.status === "Active" ? (
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setActionTargetPledge(p);
                              setActionModalType("fulfill");
                            }}
                            className="bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer"
                          >
                            Fulfill Payout
                          </button>
                          <button
                            onClick={() => {
                              setActionTargetPledge(p);
                              setActionModalType("revoke");
                            }}
                            className="bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer"
                          >
                            Revoke
                          </button>
                        </div>
                      ) : (
                        <span className="text-[11px] font-mono text-slate-500">—</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-850 pb-3">
              <div>
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <CloudRain className="w-4 h-4 text-emerald-400" />
                  <span>Initiate Direct Weather Risk (DWR) Pledge</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">Bind an institutional weather relief pledge against a target farm node & crop cycle.</p>
              </div>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePledge} className="space-y-4">
              {/* Target Farmer Selection */}
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Target Farmer</label>
                {linkedFarmers.length > 0 ? (
                  <select
                    value={selectedFarmerId}
                    onChange={(e) => {
                      setSelectedFarmerId(e.target.value);
                      if (e.target.value) setManualFarmerName("");
                    }}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="">-- Select Linked Farmer --</option>
                    {linkedFarmers.map((f) => (
                      <option key={f.id || f.uid} value={f.id || f.uid}>
                        {f.name || f.displayName || f.email} ({f.region || f.district || "Sponsoring Cohort"})
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    required
                    placeholder="Enter Farmer Name (e.g. Mainza Mweemba)"
                    value={manualFarmerName}
                    onChange={(e) => setManualFarmerName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                  />
                )}
              </div>

              {/* Farm Node & Crop Cycle */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Target Farm Node ID</label>
                  <input
                    type="text"
                    required
                    value={farmNodeId}
                    onChange={(e) => setFarmNodeId(e.target.value)}
                    placeholder="e.g. Monze South - Zone A1"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Linked Crop Cycle ID</label>
                  <input
                    type="text"
                    required
                    value={cropCycleId}
                    onChange={(e) => setCropCycleId(e.target.value)}
                    placeholder="e.g. CC-2026-MAIZE-01"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Crop Type</label>
                  <input
                    type="text"
                    required
                    value={cropType}
                    onChange={(e) => setCropType(e.target.value)}
                    placeholder="e.g. Maize (SC 637 Hybrid)"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Pledge Amount (ZMW)</label>
                  <input
                    type="number"
                    required
                    min={100}
                    value={pledgeAmountZmw}
                    onChange={(e) => setPledgeAmountZmw(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white font-mono font-bold focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Risk Trigger Condition</label>
                  <select
                    value={riskTriggerType}
                    onChange={(e) => setRiskTriggerType(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Severe Drought Index (>35% deficit)">Severe Drought Index (&gt;35% deficit)</option>
                    <option value="Rainfall Deficit (>40%)">Rainfall Deficit (&gt;40%)</option>
                    <option value="Heat Stress / Irrigation Loss">Heat Stress / Irrigation Loss</option>
                    <option value="Flood Inundation Index">Flood Inundation Index</option>
                    <option value="Extreme Heat Wave">Extreme Heat Wave</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Pledge Expiry Date</label>
                  <input
                    type="date"
                    required
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">M&E Guarantee Purpose & Policy Notes</label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Enter M&E notes, board reference, or weather station trigger threshold details..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-850">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white bg-slate-900 border border-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-600/20 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Initiating Pledge...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Initiate DWR Pledge</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Status Action Confirmation Modal */}
      {actionTargetPledge && actionModalType && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-850 pb-3">
              <h3 className="text-base font-extrabold text-white">
                {actionModalType === "fulfill" ? "Fulfill DWR Relief Payout" : "Revoke DWR Pledge"}
              </h3>
              <button onClick={() => { setActionTargetPledge(null); setActionModalType(null); }} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {actionModalType === "fulfill"
                ? `Confirm releasing DWR payout of ZMW ${actionTargetPledge.pledgeAmountZMW.toLocaleString()} to ${actionTargetPledge.farmerName} (${actionTargetPledge.farmNodeId}).`
                : `Are you sure you want to revoke the active DWR pledge guarantee ${actionTargetPledge.id}?`}
            </p>

            <div>
              <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">M&E Justification Note</label>
              <textarea
                rows={2}
                value={actionNotes}
                onChange={(e) => setActionNotes(e.target.value)}
                placeholder="Enter audit or meteorological trigger reference..."
                className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 resize-none"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-850">
              <button
                type="button"
                onClick={() => { setActionTargetPledge(null); setActionModalType(null); }}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white bg-slate-900 border border-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleUpdatePledgeStatus}
                disabled={isSubmitting}
                className={`px-5 py-2 rounded-xl text-xs font-bold text-white transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50 ${
                  actionModalType === "fulfill" ? "bg-indigo-600 hover:bg-indigo-500" : "bg-rose-600 hover:bg-rose-500"
                }`}
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>{actionModalType === "fulfill" ? "Confirm Payout Release" : "Revoke Pledge"}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

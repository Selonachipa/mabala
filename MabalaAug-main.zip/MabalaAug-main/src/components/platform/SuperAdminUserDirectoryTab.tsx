import React, { useState, useMemo, useEffect } from "react";
import { safeFormatError } from "../../utils/errorUtils";
import { safeLocalStorage as localStorage, safeParseJSON } from "../../utils/safeStorage";
import {
  Search,
  Users,
  ShieldCheck,
  Tractor,
  Mail,
  Phone,
  Coins,
  MessageSquare,
  Key,
  Eye,
  EyeOff,
  Copy,
  Check,
  Activity,
  Trash2,
  Download,
  Upload,
  RefreshCw,
  Filter,
  UserCheck,
  Sparkles,
  ExternalLink,
  Lock,
  Building2,
  BadgeCheck,
  FileText,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Database,
  SlidersHorizontal
} from "lucide-react";

export interface UserRecord {
  uid: string;
  id?: string;
  tenantUid?: string;
  email: string;
  name?: string;
  displayName?: string;
  fullName?: string;
  phone?: string;
  phoneNumber?: string;
  role?: string;
  accountType?: string;
  tenantType?: string;
  status?: string;
  farmName?: string;
  farm?: any;
  farms?: any[];
  credits?: number;
  smsCredits?: number;
  subscriptionPackage?: string;
  subscriptionTier?: string;
  subscriptionExpiresAt?: string;
  createdAt?: string;
  lastActiveAt?: string;
  lastLoginAt?: string;
  password?: string;
  rawPassword?: string;
  defaultPassword?: string;
  assignedPassword?: string;
  province?: string;
  district?: string;
  [key: string]: any;
}

export interface SuperAdminUserDirectoryTabProps {
  allUsers: UserRecord[];
  isLoading?: boolean;
  onRefreshUsers?: () => void;
  onAccessNode?: (user: UserRecord) => void;
  onEditNodeSettings?: (user: UserRecord) => void;
  onOpenCreditAllocation?: (user: UserRecord, initialTab?: "credits" | "sms" | "subscription") => void;
  onViewAuditTrail?: (user: UserRecord) => void;
  onDeleteNode?: (user: UserRecord) => void;
  onOpenBulkRegisterModal?: () => void;
  onRaiseInvoice?: (user: UserRecord) => void;
  onRemediateSchema?: () => void;
  isRemediating?: boolean;
  currentUserEmail?: string;
}

export const SuperAdminUserDirectoryTab: React.FC<SuperAdminUserDirectoryTabProps> = ({
  allUsers = [],
  isLoading = false,
  onRefreshUsers,
  onAccessNode,
  onEditNodeSettings,
  onOpenCreditAllocation,
  onViewAuditTrail,
  onDeleteNode,
  onOpenBulkRegisterModal,
  onRaiseInvoice,
  onRemediateSchema,
  isRemediating = false,
  currentUserEmail
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [visiblePasswordUid, setVisiblePasswordUid] = useState<string | null>(null);
  const [copiedUid, setCopiedUid] = useState<string | null>(null);

  // Pagination states
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  // Reset page on filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, roleFilter, statusFilter]);

  // Cached password lookup dictionary
  const userPassDict = useMemo(() => {
    try {
      return safeParseJSON<Record<string, string>>(localStorage.getItem("mabala_user_passwords") || "{}", {});
    } catch {
      return {};
    }
  }, []);

  // Filtered users list
  const filteredUsers = useMemo(() => {
    return allUsers.filter((u) => {
      if (!u) return false;
      const email = (u.email || u.tenantEmail || "").toLowerCase();
      const name = (u.name || u.displayName || u.fullName || u.farm?.name || u.farmName || "").toLowerCase();
      const phone = (u.phone || u.phoneNumber || "").toLowerCase();
      const uid = (u.uid || u.tenantUid || u.id || "").toLowerCase();
      const role = (u.role || u.accountType || "Farmer").toLowerCase();
      const farm = (u.farmName || u.farm?.name || "").toLowerCase();

      // Role Filter
      if (roleFilter !== "ALL") {
        if (roleFilter === "Farmer" && !role.includes("farmer") && !role.includes("owner")) return false;
        if (roleFilter === "Agro-Dealer" && !role.includes("dealer") && !role.includes("agro")) return false;
        if (roleFilter === "Offtaker" && !role.includes("offtaker") && !role.includes("buyer")) return false;
        if (roleFilter === "Agronomist" && !role.includes("agronomist")) return false;
        if (roleFilter === "Veterinary" && !role.includes("vet")) return false;
        if (roleFilter === "Super Admin" && !role.includes("admin")) return false;
      }

      // Status Filter
      if (statusFilter !== "ALL") {
        const uStatus = (u.status || "ACTIVE").toUpperCase();
        if (statusFilter === "ACTIVE" && uStatus !== "ACTIVE") return false;
        if (statusFilter === "INACTIVE" && uStatus === "ACTIVE") return false;
      }

      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          email.includes(q) ||
          name.includes(q) ||
          phone.includes(q) ||
          uid.includes(q) ||
          role.includes(q) ||
          farm.includes(q)
        );
      }

      return true;
    });
  }, [allUsers, roleFilter, statusFilter, searchQuery]);

  // Paginated users
  const totalPages = Math.max(1, Math.ceil(filteredUsers.length / pageSize));
  const paginatedUsers = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredUsers.slice(start, start + pageSize);
  }, [filteredUsers, currentPage, pageSize]);

  // Metrics summary
  const metrics = useMemo(() => {
    const total = allUsers.length;
    let farmers = 0;
    let dealers = 0;
    let offtakers = 0;
    let agronomists = 0;
    let admins = 0;

    allUsers.forEach((u) => {
      const r = (u.role || u.accountType || "").toLowerCase();
      if (r.includes("dealer")) dealers++;
      else if (r.includes("offtaker")) offtakers++;
      else if (r.includes("agronomist") || r.includes("vet")) agronomists++;
      else if (r.includes("admin")) admins++;
      else farmers++;
    });

    return { total, farmers, dealers, offtakers, agronomists, admins };
  }, [allUsers]);

  const handleCopy = (text: string, uid: string) => {
    navigator.clipboard.writeText(text);
    setCopiedUid(uid);
    setTimeout(() => setCopiedUid(null), 2000);
  };

  const handleExportCSV = () => {
    if (filteredUsers.length === 0) {
      alert("No users to export.");
      return;
    }

    const headers = [
      "User UID",
      "Full Name",
      "Email Address",
      "Phone Number",
      "Role / Account Type",
      "Farm / Node Name",
      "Subscription Tier",
      "Write Credits",
      "SMS Credits",
      "Status",
      "Created Date"
    ];

    const rows = filteredUsers.map((u) => [
      `"${u.uid || u.tenantUid || u.id || ""}"`,
      `"${(u.name || u.displayName || u.fullName || "User").replace(/"/g, '""')}"`,
      `"${u.email || ""}"`,
      `"${u.phone || u.phoneNumber || ""}"`,
      `"${u.role || u.accountType || "Farmer"}"`,
      `"${(u.farm?.name || u.farmName || "Mabala Farm").replace(/"/g, '""')}"`,
      `"${u.subscriptionPackage || u.subscriptionTier || "Standard"}"`,
      u.credits ?? 0,
      u.smsCredits ?? 0,
      `"${u.status || "Active"}"`,
      `"${u.createdAt ? new Date(u.createdAt).toISOString() : ""}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `mabala_users_directory_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 font-sans animate-fade-in" id="super-admin-user-directory-tab">
      {/* HEADER CARD */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 bg-indigo-50 text-indigo-800 text-[10px] font-black uppercase rounded-md tracking-wider border border-indigo-100 font-mono">
              Global Mesh Register
            </span>
            <span className="text-xs text-slate-400 font-mono">users_directory_v2</span>
          </div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight mt-1 flex items-center gap-2">
            <span>👥 Platform User Directory</span>
            <span className="px-2.5 py-0.5 bg-slate-100 text-slate-700 text-xs font-mono font-bold rounded-full">
              {allUsers.length} Registered Accounts
            </span>
          </h2>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            Complete centralized directory of all platform users, farm node owners, dealers, and field officers with instant diagnostics and allocation controls.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {onRemediateSchema && (
            <button
              type="button"
              onClick={onRemediateSchema}
              disabled={isRemediating}
              className="px-3.5 py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-xs disabled:opacity-50"
              title="Audit Firestore documents and normalize legacy schema fields"
            >
              <Database className={`w-3.5 h-3.5 text-amber-600 ${isRemediating ? "animate-spin" : ""}`} />
              <span>{isRemediating ? "Remediating..." : "Remediate Schemas"}</span>
            </button>
          )}

          {onOpenBulkRegisterModal && (
            <button
              type="button"
              onClick={onOpenBulkRegisterModal}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm shadow-indigo-600/20"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Bulk CSV Onboard</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-2xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>

          {onRefreshUsers && (
            <button
              type="button"
              onClick={onRefreshUsers}
              className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition cursor-pointer"
              title="Refresh User Directory"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin text-indigo-600" : ""}`} />
            </button>
          )}
        </div>
      </div>

      {/* METRIC KPI TILES */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 bg-white border border-slate-200 rounded-2xl space-y-1 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Users</span>
          <span className="text-xl font-black text-slate-900 font-mono">{metrics.total}</span>
        </div>
        <div className="p-4 bg-emerald-50/70 border border-emerald-200/80 rounded-2xl space-y-1 shadow-2xs">
          <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">Farmers</span>
          <span className="text-xl font-black text-emerald-900 font-mono">{metrics.farmers}</span>
        </div>
        <div className="p-4 bg-indigo-50/70 border border-indigo-200/80 rounded-2xl space-y-1 shadow-2xs">
          <span className="text-[10px] font-bold text-indigo-800 uppercase tracking-wider block">Agro-Dealers</span>
          <span className="text-xl font-black text-indigo-900 font-mono">{metrics.dealers}</span>
        </div>
        <div className="p-4 bg-amber-50/70 border border-amber-200/80 rounded-2xl space-y-1 shadow-2xs">
          <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider block">Offtakers</span>
          <span className="text-xl font-black text-amber-900 font-mono">{metrics.offtakers}</span>
        </div>
        <div className="p-4 bg-purple-50/70 border border-purple-200/80 rounded-2xl space-y-1 shadow-2xs">
          <span className="text-[10px] font-bold text-purple-800 uppercase tracking-wider block">Agronomists/Vets</span>
          <span className="text-xl font-black text-purple-900 font-mono">{metrics.agronomists}</span>
        </div>
        <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-1 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Super Admins</span>
          <span className="text-xl font-black text-indigo-300 font-mono">{metrics.admins}</span>
        </div>
      </div>

      {/* SEARCH AND FILTERS BAR */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, email, phone number, UID, farm name..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 outline-none focus:border-indigo-500 focus:bg-white transition"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          {/* Role Filter */}
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none cursor-pointer"
          >
            <option value="ALL">All Roles ({allUsers.length})</option>
            <option value="Farmer">Farmers</option>
            <option value="Agro-Dealer">Agro-Dealers</option>
            <option value="Offtaker">Offtakers</option>
            <option value="Agronomist">Agronomists & Vets</option>
            <option value="Super Admin">Super Admins</option>
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none cursor-pointer"
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">Active Accounts</option>
            <option value="INACTIVE">Inactive / Suspended</option>
          </select>

          {(searchQuery || roleFilter !== "ALL" || statusFilter !== "ALL") && (
            <button
              type="button"
              onClick={() => {
                setSearchQuery("");
                setRoleFilter("ALL");
                setStatusFilter("ALL");
              }}
              className="px-3 py-2 text-xs font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* USERS DIRECTORY TABLE */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50/80 text-slate-500 font-extrabold border-b border-slate-200 uppercase tracking-wider text-[10px]">
                <th className="py-3.5 px-4">User & Contact Details</th>
                <th className="py-3.5 px-4">Role & Account Type</th>
                <th className="py-3.5 px-4">Farm / Associated Node</th>
                <th className="py-3.5 px-4">Platform & SMS Credits</th>
                <th className="py-3.5 px-4">Credentials & Security</th>
                <th className="py-3.5 px-4 text-right">Super Admin Quick Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400 font-medium space-y-2">
                    <Users className="w-8 h-8 text-slate-300 mx-auto" />
                    <p>{isLoading ? "Loading user directory..." : "No matching users found in directory."}</p>
                  </td>
                </tr>
              ) : (
                paginatedUsers.map((u, idx) => {
                  const uid = u.uid || u.tenantUid || u.id || `usr-${idx}`;
                  const email = u.email || u.tenantEmail || "—";
                  const name = u.displayName || u.name || u.fullName || email.split("@")[0];
                  const phone = u.phone || u.phoneNumber || "—";
                  const role = u.role || u.accountType || "Farmer";
                  const farmName = u.farm?.name || u.farmName || "Mabala Farm Node";
                  const plan = u.subscriptionPackage || u.subscriptionTier || "Seeding Plan";
                  const writeCredits = u.credits ?? 60;
                  const smsCredits = u.smsCredits ?? 0;
                  const emailKey = email.toLowerCase();
                  const rawPass = u.password || u.rawPassword || u.loginPassword || u.defaultPassword || u.assignedPassword || userPassDict[emailKey] || "Password Not Stored";
                  const isPasswordVisible = visiblePasswordUid === uid;

                  const isFarmer = role.toLowerCase().includes("farmer") || role.toLowerCase().includes("owner");
                  const isDealer = role.toLowerCase().includes("dealer");
                  const isOfftaker = role.toLowerCase().includes("offtaker");
                  const isAdmin = role.toLowerCase().includes("admin");

                  return (
                    <tr key={uid} className="hover:bg-slate-50/90 transition group">
                      {/* USER IDENTITY */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs shrink-0 ${
                            isAdmin ? "bg-slate-900 text-white" :
                            isDealer ? "bg-indigo-100 text-indigo-800" :
                            isOfftaker ? "bg-amber-100 text-amber-900" :
                            "bg-emerald-100 text-emerald-900"
                          }`}>
                            {name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-extrabold text-slate-900 flex items-center gap-1.5">
                              <span>{name}</span>
                              {isAdmin && (
                                <span className="px-1.5 py-0.2 bg-slate-900 text-white rounded text-[9px] font-black uppercase">
                                  ADMIN
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1 mt-0.5">
                              <Mail className="w-3 h-3 text-slate-400" />
                              <span>{email}</span>
                            </div>
                            {phone !== "—" && (
                              <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                                <Phone className="w-2.5 h-2.5 text-slate-400" />
                                <span>{phone}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* ROLE & TIER */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-1">
                          <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase border ${
                            isAdmin ? "bg-slate-900 text-slate-100 border-slate-800" :
                            isDealer ? "bg-indigo-50 text-indigo-800 border-indigo-200" :
                            isOfftaker ? "bg-amber-50 text-amber-900 border-amber-200" :
                            "bg-emerald-50 text-emerald-800 border-emerald-200"
                          }`}>
                            {role}
                          </span>
                          <div className="text-[10px] text-slate-400 font-mono">
                            Plan: <strong className="text-slate-600">{plan}</strong>
                          </div>
                        </div>
                      </td>

                      {/* FARM NODE */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-800 flex items-center gap-1">
                          <Tractor className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{farmName}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                          UID: <span className="select-all">{uid.slice(0, 14)}...</span>
                        </div>
                      </td>

                      {/* CREDITS & SMS */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-1 font-mono">
                          <div className="flex items-center gap-1.5">
                            <Coins className="w-3 h-3 text-amber-500 shrink-0" />
                            <span className="font-extrabold text-slate-800">{writeCredits.toLocaleString()}</span>
                            <span className="text-[10px] text-slate-400">CR</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <MessageSquare className="w-3 h-3 text-indigo-500 shrink-0" />
                            <span className="font-extrabold text-slate-800">{smsCredits.toLocaleString()}</span>
                            <span className="text-[10px] text-slate-400">SMS</span>
                          </div>
                        </div>
                      </td>

                      {/* CREDENTIALS */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5 font-mono text-[11px]">
                          <span className="text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200 select-all">
                            {isPasswordVisible ? rawPass : "••••••••••••"}
                          </span>
                          <button
                            type="button"
                            onClick={() => setVisiblePasswordUid(isPasswordVisible ? null : uid)}
                            className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
                            title={isPasswordVisible ? "Hide password" : "Show password"}
                          >
                            {isPasswordVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleCopy(rawPass, uid)}
                            className="p-1 text-slate-400 hover:text-indigo-600 cursor-pointer"
                            title="Copy password"
                          >
                            {copiedUid === uid ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </td>

                      {/* ACTIONS */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* SEND / RAISE PLATFORM INVOICE */}
                          {onRaiseInvoice && (
                            <button
                              type="button"
                              onClick={() => onRaiseInvoice(u)}
                              className="p-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg transition cursor-pointer"
                              title="Issue & Send Manual Platform Invoice"
                            >
                              <FileText className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* CONFIGURE FARM NODE SETTINGS */}
                          {onEditNodeSettings && (
                            <button
                              type="button"
                              onClick={() => onEditNodeSettings(u)}
                              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1"
                              title="Edit Farm Node Settings & Configuration"
                            >
                              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-600" />
                              <span>Configure</span>
                            </button>
                          )}

                          {/* REMOTE SUPPORT ACCESS NODE */}
                          {onAccessNode && (
                            <button
                              type="button"
                              onClick={() => onAccessNode(u)}
                              className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1"
                              title="Start remote support session (60-min impersonation)"
                            >
                              <ShieldCheck className="w-3.5 h-3.5" />
                              <span>Access</span>
                            </button>
                          )}

                          {/* MANUAL CREDIT ALLOCATION */}
                          {onOpenCreditAllocation && (
                            <button
                              type="button"
                              onClick={() => onOpenCreditAllocation(u, "credits")}
                              className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg transition cursor-pointer"
                              title="Manual Platform Credit / Subscription Allocation"
                            >
                              <Coins className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* MANUAL SMS ALLOCATION */}
                          {onOpenCreditAllocation && (
                            <button
                              type="button"
                              onClick={() => onOpenCreditAllocation(u, "sms")}
                              className="p-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 rounded-lg transition cursor-pointer"
                              title="Manual SMS Credit Allocation"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* AUDIT TRAIL */}
                          {onViewAuditTrail && (
                            <button
                              type="button"
                              onClick={() => onViewAuditTrail(u)}
                              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                              title="View Activity & Email Audit Log"
                            >
                              <Activity className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* PURGE / DELETE NODE */}
                          {onDeleteNode && (
                            <button
                              type="button"
                              onClick={() => onDeleteNode(u)}
                              className="p-1.5 text-rose-400 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                              title="Decommission & Cascade Delete Node"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* PAGINATION CONTROLS FOOTER */}
        {filteredUsers.length > 0 && (
          <div className="px-4 py-3 bg-slate-50/80 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3 text-slate-600 font-medium">
              <span>
                Showing <strong className="text-slate-900 font-bold">{(currentPage - 1) * pageSize + 1}</strong> to <strong className="text-slate-900 font-bold">{Math.min(currentPage * pageSize, filteredUsers.length)}</strong> of <strong className="text-slate-900 font-bold">{filteredUsers.length}</strong> accounts
              </span>
              <div className="flex items-center gap-1.5 pl-3 border-l border-slate-200">
                <span className="text-slate-500 text-[11px]">Rows per page:</span>
                <select
                  value={pageSize}
                  onChange={(e) => {
                    setPageSize(Number(e.target.value));
                    setCurrentPage(1);
                  }}
                  className="px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-700 outline-none cursor-pointer"
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setCurrentPage(1)}
                disabled={currentPage <= 1}
                className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer"
                title="First page"
              >
                <ChevronsLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage <= 1}
                className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer flex items-center gap-1"
                title="Previous page"
              >
                <ChevronLeft className="w-4 h-4" />
                <span className="text-xs font-semibold hidden sm:inline">Prev</span>
              </button>

              <div className="flex items-center gap-1 px-1">
                {Array.from({ length: totalPages }, (_, i) => i + 1)
                  .filter(page => {
                    if (totalPages <= 5) return true;
                    if (page === 1 || page === totalPages) return true;
                    return Math.abs(page - currentPage) <= 1;
                  })
                  .map((page, idx, arr) => {
                    const showEllipsisBefore = idx > 0 && page - arr[idx - 1] > 1;
                    return (
                      <React.Fragment key={page}>
                        {showEllipsisBefore && <span className="text-slate-400 px-1">...</span>}
                        <button
                          type="button"
                          onClick={() => setCurrentPage(page)}
                          className={`w-7 h-7 rounded-lg text-xs font-bold transition cursor-pointer ${
                            currentPage === page
                              ? "bg-indigo-600 text-white shadow-sm"
                              : "bg-white border border-slate-200 text-slate-700 hover:bg-slate-100"
                          }`}
                        >
                          {page}
                        </button>
                      </React.Fragment>
                    );
                  })}
              </div>

              <button
                type="button"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage >= totalPages}
                className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer flex items-center gap-1"
                title="Next page"
              >
                <span className="text-xs font-semibold hidden sm:inline">Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setCurrentPage(totalPages)}
                disabled={currentPage >= totalPages}
                className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer"
                title="Last page"
              >
                <ChevronsRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SuperAdminUserDirectoryTab;

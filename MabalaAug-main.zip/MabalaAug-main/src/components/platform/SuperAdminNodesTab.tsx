import React, { useState, useMemo, useEffect } from "react";
import {
  Search,
  Filter,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Eye,
  EyeOff,
  Trash2,
  Lock,
  Unlock,
  Mail,
  ExternalLink,
  Shield,
  Loader2,
  Calendar,
  Clock,
  Coins,
  Key,
  Copy,
  X,
  RefreshCw,
  Sparkles,
  Info,
  Check,
  Building2,
  UserCheck,
  FileText,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight
} from "lucide-react";
import { db, auth } from "../../firebase";
import { doc, updateDoc, addDoc, collection } from "firebase/firestore";
import { executeSuperAdminFarmNodeDeletion } from "../../services/nodeDeletionService";

function safeParseJSON<T>(val: any, fallback: T): T {
  if (!val) return fallback;
  if (typeof val === "object") return val;
  try {
    return JSON.parse(val);
  } catch (_) {
    return fallback;
  }
}

interface SuperAdminNodesTabProps {
  allPlatformUsers: any[];
  setAllPlatformUsers?: React.Dispatch<React.SetStateAction<any[]>>;
  farms: any[];
  onEnterFarmNodeImpersonation?: (targetUid: string, targetEmail: string, farm: any) => void;
  onRefreshUsers?: () => void;
  currentUserEmail?: string;
  setSelectedTenantForCredits?: (tenant: any) => void;
  setConfirmAccessNodeTarget?: (target: any) => void;
  onDeleteNode?: (node: any) => void;
  onRaiseInvoice?: (node: any) => void;
}

export function SuperAdminNodesTab({
  allPlatformUsers = [],
  setAllPlatformUsers,
  farms = [],
  onEnterFarmNodeImpersonation,
  onRefreshUsers,
  currentUserEmail,
  setSelectedTenantForCredits,
  setConfirmAccessNodeTarget,
  onDeleteNode,
  onRaiseInvoice
}: SuperAdminNodesTabProps) {
  const [nodeSearchQuery, setNodeSearchQuery] = useState<string>("");
  const [nodeStatusFilter, setNodeStatusFilter] = useState<string>("ALL");
  const [visiblePasswordNodeUid, setVisiblePasswordNodeUid] = useState<string | null>(null);
  const [actionSendingEmailUid, setActionSendingEmailUid] = useState<string | null>(null);

  // Pagination states
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(8);

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [nodeSearchQuery, nodeStatusFilter]);
  
  // Suspend Modal state
  const [suspendingNode, setSuspendingNode] = useState<any | null>(null);
  const [suspendReason, setSuspendReason] = useState<string>("");
  const [suspendStatus, setSuspendStatus] = useState<string>("Frozen");
  const [isSubmittingSuspend, setIsSubmittingSuspend] = useState<boolean>(false);

  // Delete Cascade Modal state
  const [deletingNode, setDeletingNode] = useState<any | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>("Tenant requested complete node decommissioning and credential release.");
  const [deleteConfirmationInput, setDeleteConfirmationInput] = useState<string>("");
  const [isSubmittingDelete, setIsSubmittingDelete] = useState<boolean>(false);

  const handleSuspendNodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!suspendingNode) return;
    setIsSubmittingSuspend(true);
    try {
      if (onRefreshUsers) onRefreshUsers();
      setSuspendingNode(null);
    } catch (_) {} finally {
      setIsSubmittingSuspend(false);
    }
  };

  const handleDeleteNodeSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!deletingNode) return;
    if (!deleteReason.trim()) {
      alert("Please provide a reason for deleting this farm node.");
      return;
    }

    setIsSubmittingDelete(true);
    try {
      const targetUid = deletingNode.tenantUid || deletingNode.uid || deletingNode.id;
      const targetEmail = deletingNode.tenantEmail || deletingNode.email || "";
      const targetFarmName = deletingNode.farm?.name || deletingNode.farmName || deletingNode.displayName || "Farm Node";
      const targetPhone = deletingNode.farm?.phone || deletingNode.ownerPhone || deletingNode.phone || "";
      const targetRole = deletingNode.role || deletingNode.accountType || "farmer";

      const result = await executeSuperAdminFarmNodeDeletion({
        tenantId: targetUid,
        farmName: targetFarmName,
        tenantEmail: targetEmail,
        ownerEmail: targetEmail,
        tenantPhone: targetPhone,
        ownerPhone: targetPhone,
        role: targetRole,
        reason: deleteReason,
        superAdminEmail: auth.currentUser?.email || currentUserEmail || "support@mabala.cloud",
        confirmationName: deleteConfirmationInput || targetFarmName
      });

      if (result.success) {
        if (setAllPlatformUsers) {
          setAllPlatformUsers(prev => prev.filter(u => 
            u.uid !== targetUid && 
            u.id !== targetUid && 
            u.tenantId !== targetUid && 
            (!targetEmail || (u.email || "").toLowerCase() !== targetEmail.toLowerCase())
          ));
        }

        // Global synchronization events across all app components and tabs
        if (typeof window !== "undefined") {
          window.dispatchEvent(new CustomEvent("mabala_farm_node_deleted", {
            detail: { tenantId: targetUid, email: targetEmail, farmName: targetFarmName }
          }));
          window.dispatchEvent(new CustomEvent("mabala_users_updated"));
        }

        alert(result.message || `Farm node "${targetFarmName}" permanently deleted and credentials released.`);
        setDeletingNode(null);
        setDeleteReason("");
        setDeleteConfirmationInput("");
        if (onRefreshUsers) onRefreshUsers();
      } else {
        alert(result.error || "Failed to delete farm node. Please verify confirmation text.");
      }
    } catch (err: any) {
      alert("Error deleting node: " + (err.message || "Unknown error"));
    } finally {
      setIsSubmittingDelete(false);
    }
  };

  // Compile Comprehensive Nodes List
  const nodesList = useMemo(() => {
    const list: any[] = [];
    const now = Date.now();

    const userPassDictStr = typeof window !== "undefined" ? localStorage.getItem("mabala_user_passwords") : null;
    const userPassDict = safeParseJSON<Record<string, string>>(userPassDictStr, {});

    const pendingUsersStr = typeof window !== "undefined" ? localStorage.getItem("mabala_pending_first_login_users") : null;
    const pendingUsers = safeParseJSON<any[]>(pendingUsersStr, []);

    const processedUids = new Set<string>();

    allPlatformUsers.forEach(u => {
      if (!u) return;
      const uid = u.uid || u.id || u.tenantId;
      const emailKey = (u.email || u.tenantEmail || "").toLowerCase();
      const foundPending = pendingUsers.find((p: any) => (p.email || "").toLowerCase() === emailKey);
      const actualUserPass = u.password || u.loginPassword || u.rawPassword || userPassDict[emailKey] || (foundPending ? (foundPending.password || foundPending.defaultPassword) : null) || u.defaultPassword || u.assignedPassword;

      if (u.farms && Array.isArray(u.farms) && u.farms.length > 0) {
        u.farms.forEach((f: any) => {
          const lastActive = u.lastActiveAt || u.lastLoginAt || u.updatedAt || f.createdAt || u.createdAt;
          const lastActiveTs = lastActive ? new Date(lastActive).getTime() : now - (5 * 86400000);
          const daysInactive = Math.max(0, Math.floor((now - lastActiveTs) / (1000 * 3600 * 24)));
          
          let nodeCategory: "ACTIVE" | "WARNING" | "ARCHIVED" = "ACTIVE";
          if (u.status === "ARCHIVED" || f.status === "ARCHIVED" || daysInactive >= 90) {
            nodeCategory = "ARCHIVED";
          } else if (daysInactive >= 70 || u.status === "WARNING") {
            nodeCategory = "WARNING";
          }

          list.push({ 
            tenantUid: uid, 
            tenantEmail: u.email, 
            nodePassword: actualUserPass || f.password || f.adminPassword || "Password Not Stored",
            tenantPhone: u.phone || f.phone || u.contactPhone || u.phoneNumber || "+260978070734",
            farm: f, 
            role: u.role || u.accountType || "Farmer",
            subscriptionTier: u.subscriptionTier || "Standard",
            status: nodeCategory,
            rawStatus: u.status || f.status || "ACTIVE",
            daysInactive,
            lastActiveStr: lastActive ? new Date(lastActive).toLocaleDateString() : "Recent",
            warningEmailSentAt: u.warningEmailSentAt || f.warningEmailSentAt
          });
        });
        processedUids.add(uid);
      } else {
        const farmObj = u.farm || {
          id: `farm-${uid || Date.now()}`,
          name: u.farmName || u.displayName || u.name || `Farm Node (${u.email})`,
          email: u.email,
          phone: u.phone || u.phoneNumber || "+260978070734",
          location: typeof u.location === "string" ? u.location : "Lusaka West",
          district: u.district || "Lusaka",
          province: u.province || "Lusaka Province",
          currency: u.currency || "ZMW"
        };

        const lastActive = u.lastActiveAt || u.lastLoginAt || u.updatedAt || u.createdAt;
        const lastActiveTs = lastActive ? new Date(lastActive).getTime() : now - (5 * 86400000);
        const daysInactive = Math.max(0, Math.floor((now - lastActiveTs) / (1000 * 3600 * 24)));
        
        let nodeCategory: "ACTIVE" | "WARNING" | "ARCHIVED" = "ACTIVE";
        if (u.status === "ARCHIVED" || farmObj.status === "ARCHIVED" || daysInactive >= 90) {
          nodeCategory = "ARCHIVED";
        } else if (daysInactive >= 70 || u.status === "WARNING") {
          nodeCategory = "WARNING";
        }

        list.push({
          tenantUid: uid,
          tenantEmail: u.email,
          nodePassword: actualUserPass || farmObj.password || "Password Not Stored",
          tenantPhone: u.phone || u.phoneNumber || farmObj.phone || "+260978070734",
          farm: farmObj,
          role: u.role || u.accountType || "Farmer",
          subscriptionTier: u.subscriptionTier || "Standard",
          status: nodeCategory,
          rawStatus: u.status || "ACTIVE",
          daysInactive,
          lastActiveStr: lastActive ? new Date(lastActive).toLocaleDateString() : "Recent",
          warningEmailSentAt: u.warningEmailSentAt
        });
        processedUids.add(uid);
      }
    });

    // Supplement standalone farms if any
    if (Array.isArray(farms)) {
      farms.forEach(f => {
        if (!f) return;
        const farmUid = f.tenantId || f.ownerUid || f.id;
        if (!processedUids.has(farmUid)) {
          list.push({
            tenantUid: farmUid,
            tenantEmail: f.email || f.ownerEmail || "farmer@mabala.ag",
            nodePassword: f.password || "Password Not Stored",
            tenantPhone: f.phone || "+260978070734",
            farm: f,
            role: "Farmer",
            subscriptionTier: f.subscriptionTier || "Standard",
            status: "ACTIVE",
            rawStatus: "ACTIVE",
            daysInactive: 5,
            lastActiveStr: "Recent",
            warningEmailSentAt: undefined
          });
          processedUids.add(farmUid);
        }
      });
    }

    return list;
  }, [allPlatformUsers, farms]);

  const totalCount = nodesList.length;
  const activeCount = nodesList.filter(n => n.status === "ACTIVE").length;
  const warningCount = nodesList.filter(n => n.status === "WARNING").length;
  const archivedCount = nodesList.filter(n => n.status === "ARCHIVED").length;

  const filteredNodes = useMemo(() => {
    return nodesList.filter(n => {
      if (nodeStatusFilter !== "ALL" && n.status !== nodeStatusFilter) return false;
      if (nodeSearchQuery.trim()) {
        const q = nodeSearchQuery.toLowerCase();
        const farmName = (n.farm?.name || "").toLowerCase();
        const email = (n.tenantEmail || "").toLowerCase();
        const phone = (n.tenantPhone || "").toLowerCase();
        const uid = (n.tenantUid || "").toLowerCase();
        const role = (n.role || "").toLowerCase();
        const loc = (typeof n.farm?.location === "string" ? n.farm.location : (n.farm?.district || "")).toLowerCase();
        return farmName.includes(q) || email.includes(q) || phone.includes(q) || uid.includes(q) || role.includes(q) || loc.includes(q);
      }
      return true;
    });
  }, [nodesList, nodeStatusFilter, nodeSearchQuery]);

  const targetExpectedConfirmation = deletingNode?.farm?.name || deletingNode?.tenantEmail || "";

  // Paginated nodes
  const totalPages = Math.max(1, Math.ceil(filteredNodes.length / pageSize));
  const paginatedNodes = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredNodes.slice(start, start + pageSize);
  }, [filteredNodes, currentPage, pageSize]);

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6 animate-fade-in font-sans">
      {/* HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 bg-indigo-100 text-indigo-800 text-[10px] font-black uppercase rounded-md tracking-wider">
              Super Admin Operations
            </span>
            <span className="text-xs text-slate-400 font-mono">farm_nodes_lifecycle</span>
          </div>
          <h3 className="text-xl font-black text-slate-800 tracking-tight mt-1 flex items-center gap-2">
            <span>🚜 Farm Node Directory & Lifecycle Hub</span>
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-800 text-[10px] font-mono font-bold rounded-full border border-emerald-200">
              Cascade Deletion Active
            </span>
          </h3>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            Search and manage all deployed farm nodes. Super Admin can impersonate, reset status, or permanently purge/delete any farm node with credential release.
          </p>
        </div>

        {/* STATUS FILTER PILLS */}
        <div className="flex flex-wrap gap-1.5 bg-slate-100 p-1.5 rounded-2xl">
          <button
            onClick={() => setNodeStatusFilter("ALL")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              nodeStatusFilter === "ALL" ? "bg-white text-slate-900 shadow-sm" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            All Nodes ({totalCount})
          </button>
          <button
            onClick={() => setNodeStatusFilter("ACTIVE")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              nodeStatusFilter === "ACTIVE" ? "bg-emerald-600 text-white shadow-sm font-extrabold" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Active ({activeCount})
          </button>
          <button
            onClick={() => setNodeStatusFilter("WARNING")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              nodeStatusFilter === "WARNING" ? "bg-amber-500 text-white shadow-sm font-extrabold" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            ⚠️ Warning ({warningCount})
          </button>
          <button
            onClick={() => setNodeStatusFilter("ARCHIVED")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              nodeStatusFilter === "ARCHIVED" ? "bg-rose-600 text-white shadow-sm font-extrabold" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            📦 Archived ({archivedCount})
          </button>
        </div>
      </div>

      {/* SUMMARY STATS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-1">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Total Deployed Nodes</span>
          <span className="text-2xl font-black text-slate-900 font-mono">{totalCount}</span>
        </div>
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-1">
          <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">Active Nodes (&lt;70d)</span>
          <span className="text-2xl font-black text-emerald-800 font-mono">{activeCount}</span>
        </div>
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl space-y-1">
          <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider block">20-Day Warning (70-89d)</span>
          <span className="text-2xl font-black text-amber-800 font-mono">{warningCount}</span>
        </div>
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl space-y-1">
          <span className="text-[10px] font-bold text-rose-700 uppercase tracking-wider block">Archived / Inactive (&ge;90d)</span>
          <span className="text-2xl font-black text-rose-800 font-mono">{archivedCount}</span>
        </div>
      </div>

      {/* SEARCH BAR */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={nodeSearchQuery}
            onChange={(e) => setNodeSearchQuery(e.target.value)}
            placeholder="Search farm nodes by name, email, phone, location, UID..."
            className="w-full pl-10 pr-9 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-semibold text-slate-800 outline-none focus:bg-white focus:border-indigo-500 transition shadow-2xs"
          />
          {nodeSearchQuery && (
            <button
              type="button"
              onClick={() => setNodeSearchQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="text-xs text-slate-500 font-medium flex items-center gap-2">
          <span>Showing <strong>{filteredNodes.length}</strong> of <strong>{nodesList.length}</strong> farm nodes</span>
          {nodeSearchQuery && (
            <button
              type="button"
              onClick={() => setNodeSearchQuery("")}
              className="text-indigo-600 font-bold hover:underline"
            >
              Clear Search
            </button>
          )}
        </div>
      </div>

      {/* NODES LIST GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredNodes.length === 0 ? (
          <div className="md:col-span-2 p-12 text-center text-slate-400 italic bg-slate-50 border border-dashed border-slate-200 rounded-2xl font-sans space-y-2">
            <Building2 className="w-8 h-8 text-slate-300 mx-auto" />
            <p>No farm nodes matching query "{nodeSearchQuery}" or filter ({nodeStatusFilter}).</p>
            <button
              type="button"
              onClick={() => { setNodeSearchQuery(""); setNodeStatusFilter("ALL"); }}
              className="px-3.5 py-1.5 bg-white border border-slate-300 text-slate-700 text-xs font-bold rounded-xl hover:bg-slate-50 cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          paginatedNodes.map((n, idx) => {
            const isArchived = n.status === "ARCHIVED";
            const isWarning = n.status === "WARNING";

            return (
              <div key={idx} className={`border transition-all rounded-3xl p-5 flex flex-col justify-between space-y-4 shadow-2xs ${
                isArchived ? "bg-rose-50/40 border-rose-200 hover:border-rose-400" :
                isWarning ? "bg-amber-50/40 border-amber-200 hover:border-amber-400" :
                "bg-slate-50/70 border-slate-200 hover:border-indigo-400"
              }`}>
                <div className="space-y-3">
                  <div className="flex justify-between items-start gap-2">
                    <div className="flex flex-wrap gap-1.5 items-center">
                      <span className="px-2 py-0.5 bg-emerald-50 text-emerald-800 rounded-md text-[9px] font-black uppercase border border-emerald-200 font-mono">
                        {n.subscriptionTier || "Monthly Plan"}
                      </span>
                      <span className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase border font-mono ${
                        isArchived ? "bg-rose-100 text-rose-800 border-rose-300 animate-pulse" :
                        isWarning ? "bg-amber-100 text-amber-900 border-amber-300" :
                        "bg-green-100 text-green-800 border-green-300"
                      }`}>
                        {isArchived ? "📦 ARCHIVED (INACTIVE)" : isWarning ? "⚠️ 20-DAY WARNING" : "🟢 ACTIVE NODE"}
                      </span>
                      <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded-md text-[9px] font-bold uppercase border border-indigo-100">
                        {n.role || "Farmer"}
                      </span>
                    </div>
                    <span className="text-[9.5px] font-mono text-slate-400">ID: {n.farm?.id || n.tenantUid || "node"}</span>
                  </div>

                  <div>
                    <h4 className="text-base font-black text-slate-900 tracking-tight leading-snug">{n.farm?.name || "Farm Workspace Node"}</h4>
                    <p className="text-xs text-slate-600 font-semibold font-sans mt-0.5">
                      Owner: <strong className="text-slate-800">{n.tenantEmail}</strong> • 📱 <span className="font-mono text-slate-700">{n.tenantPhone}</span>
                    </p>
                  </div>

                  {/* INACTIVITY BAR */}
                  <div className="p-3 bg-white border border-slate-200/80 rounded-2xl space-y-1.5">
                    <div className="flex justify-between items-center text-[10.5px] font-bold text-slate-700">
                      <span>Inactivity Lifecycle Gauge</span>
                      <span className="font-mono">{n.daysInactive} days inactive</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${
                          n.daysInactive >= 90 ? "bg-rose-600" : n.daysInactive >= 70 ? "bg-amber-500" : "bg-emerald-500"
                        }`}
                        style={{ width: `${Math.min(100, (n.daysInactive / 90) * 100)}%` }}
                      />
                    </div>
                    <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono pt-0.5">
                      <span>Last Login: {n.lastActiveStr}</span>
                      <span>{n.daysInactive >= 90 ? "Archival Executed" : `${90 - n.daysInactive} days to archive`}</span>
                    </div>
                    {n.warningEmailSentAt && (
                      <div className="text-[10px] text-indigo-600 font-semibold pt-1 border-t border-slate-100 flex items-center gap-1">
                        ✉️ 20-Day Archival Notice Sent on {new Date(n.warningEmailSentAt).toLocaleDateString()}
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-500 pt-0.5">
                    <span>
                      📍 {typeof n.farm?.location === "string"
                        ? n.farm.location
                        : n.farm?.location?.district
                          ? `${n.farm.location.district}${n.farm.location.province ? `, ${n.farm.location.province}` : ""}`
                          : n.farm?.district
                            ? `${n.farm.district}${n.farm.province ? `, ${n.farm.province}` : ""}`
                            : n.farm?.address || n.farm?.town || "Lusaka West"}
                    </span>
                    <span>🌾 Currency: {n.farm?.currency || "ZMW"}</span>
                  </div>

                  {/* SUPER ADMIN NODE CREDENTIALS */}
                  <div className="p-3 bg-indigo-950 text-indigo-100 rounded-2xl border border-indigo-800 space-y-2 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-mono font-black text-indigo-300 uppercase tracking-wider flex items-center gap-1">
                        <Key className="w-3 h-3 text-amber-400" /> Super Admin Node Credentials
                      </span>
                      <span className="px-2 py-0.5 bg-indigo-900/80 text-amber-300 text-[9px] font-mono font-bold rounded border border-indigo-700">
                        CONFIDENTIAL
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-0.5 font-mono text-[11px]">
                      <div className="bg-indigo-900/50 p-2 rounded-xl border border-indigo-800">
                        <span className="text-[9px] text-indigo-400 font-bold block uppercase">Node Login Email</span>
                        <span className="font-bold text-white truncate block" title={n.tenantEmail}>{n.tenantEmail}</span>
                      </div>
                      <div className="bg-indigo-900/50 p-2 rounded-xl border border-indigo-800 flex justify-between items-center">
                        <div className="min-w-0 pr-1">
                          <span className="text-[9px] text-indigo-400 font-bold block uppercase">Node Login Password</span>
                          <span className="font-bold text-amber-300 font-mono truncate block">
                            {visiblePasswordNodeUid === `${n.tenantUid}_${n.farm?.id}` ? n.nodePassword : "••••••••••••"}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              const key = `${n.tenantUid}_${n.farm?.id}`;
                              setVisiblePasswordNodeUid(prev => prev === key ? null : key);
                            }}
                            className="p-1 text-indigo-300 hover:text-white rounded-lg hover:bg-indigo-800 transition cursor-pointer"
                            title="Toggle Password Visibility"
                          >
                            {visiblePasswordNodeUid === `${n.tenantUid}_${n.farm?.id}` ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(`Email: ${n.tenantEmail}\nPassword: ${n.nodePassword}`);
                              alert(`Credentials for ${n.farm?.name || "Farm Node"} copied to clipboard!`);
                            }}
                            className="p-1 text-indigo-300 hover:text-emerald-300 rounded-lg hover:bg-indigo-800 transition cursor-pointer"
                            title="Copy Credentials to Clipboard"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* SUPER ADMIN ACTION BUTTONS */}
                <div className="pt-3 border-t border-slate-200/60 flex flex-wrap gap-2 justify-end items-center">
                  {/* RAISE / SEND PLATFORM INVOICE */}
                  {onRaiseInvoice && (
                    <button
                      type="button"
                      onClick={() => onRaiseInvoice(n)}
                      className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-[10.5px] font-extrabold uppercase transition cursor-pointer flex items-center gap-1 shadow-sm"
                      title="Send or raise a manual platform invoice for this farm node"
                    >
                      <FileText className="w-3 h-3 text-indigo-200" /> Send Invoice
                    </button>
                  )}

                  {/* IMPERSONATE / ENTER NODE */}
                  {onEnterFarmNodeImpersonation && (
                    <button
                      type="button"
                      onClick={() => onEnterFarmNodeImpersonation(n.tenantUid, n.tenantEmail, n.farm)}
                      className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-[10.5px] font-extrabold uppercase transition cursor-pointer flex items-center gap-1"
                      title="Directly enter and view this tenant workspace"
                    >
                      <ExternalLink className="w-3 h-3" /> Enter Node
                    </button>
                  )}

                  {/* SEND 20-DAY WARNING EMAIL */}
                  <button
                    onClick={async () => {
                      setActionSendingEmailUid(n.tenantUid);
                      try {
                        const userRef = doc(db, "users_data", n.tenantUid);
                        const sentTime = new Date().toISOString();
                        await updateDoc(userRef, {
                          warningEmailSentAt: sentTime,
                          status: "WARNING",
                          updatedAt: sentTime
                        });

                        await addDoc(collection(db, "audit_trails"), {
                          superAdminEmail: auth.currentUser?.email || "Super Admin",
                          superAdminUid: auth.currentUser?.uid || "admin",
                          actionType: "warning_email_dispatched",
                          details: { tenantUid: n.tenantUid, email: n.tenantEmail, sentAt: sentTime },
                          timestamp: sentTime
                        });

                        alert(`📧 20-Day Inactivity Archival Warning successfully logged and sent to ${n.tenantEmail}.`);
                        if (onRefreshUsers) onRefreshUsers();
                      } catch (e: any) {
                        alert(`Failed to send warning email: ${e.message}`);
                      } finally {
                        setActionSendingEmailUid(null);
                      }
                    }}
                    disabled={actionSendingEmailUid === n.tenantUid}
                    className="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-xl text-[10.5px] font-bold uppercase transition cursor-pointer flex items-center gap-1 disabled:opacity-50"
                  >
                    <Mail className="w-3 h-3" />
                    {actionSendingEmailUid === n.tenantUid ? "Sending..." : "Send 20-Day Warning"}
                  </button>

                  {/* ARCHIVE / REACTIVATE TOGGLE */}
                  <button
                    onClick={async () => {
                      const newStatus = isArchived ? "ACTIVE" : "ARCHIVED";
                      const confirmMsg = isArchived
                        ? `Are you sure you want to reactivate the farm node "${n.farm?.name}"?`
                        : `Are you sure you want to manually archive the farm node "${n.farm?.name}"?`;
                      if (!confirm(confirmMsg)) return;

                      try {
                        const userRef = doc(db, "users_data", n.tenantUid);
                        const nowIso = new Date().toISOString();
                        await updateDoc(userRef, {
                          status: newStatus,
                          lastActiveAt: nowIso,
                          updatedAt: nowIso
                        });

                        await addDoc(collection(db, "audit_trails"), {
                          superAdminEmail: auth.currentUser?.email || "Super Admin",
                          superAdminUid: auth.currentUser?.uid || "admin",
                          actionType: isArchived ? "farm_node_reactivated" : "farm_node_archived",
                          details: { tenantUid: n.tenantUid, email: n.tenantEmail, status: newStatus },
                          timestamp: nowIso
                        });

                        if (setAllPlatformUsers) {
                          setAllPlatformUsers(prev => prev.map(u => (u.uid === n.tenantUid || u.id === n.tenantUid) ? { ...u, status: newStatus, lastActiveAt: nowIso } : u));
                        }
                        alert(`✅ Farm node successfully ${isArchived ? "reactivated" : "archived"}.`);
                        if (onRefreshUsers) onRefreshUsers();
                      } catch (e: any) {
                        alert(`Failed to update node status: ${e.message}`);
                      }
                    }}
                    className={`px-2.5 py-1.5 text-white rounded-xl text-[10.5px] font-bold uppercase transition cursor-pointer flex items-center gap-1 ${
                      isArchived ? "bg-emerald-600 hover:bg-emerald-500" : "bg-rose-600 hover:bg-rose-500"
                    }`}
                  >
                    {isArchived ? "⚡ Reactivate Node" : "📦 Archive Node"}
                  </button>

                  {/* SUPER ADMIN DELETE NODE (ACTIVATED) */}
                  <button
                    onClick={() => {
                      if (onDeleteNode) {
                        onDeleteNode(n);
                      } else {
                        setDeletingNode(n);
                        setDeleteReason("Administrative node decommissioning and complete database cascade purge.");
                        setDeleteConfirmationInput("");
                      }
                    }}
                    className="px-2.5 py-1.5 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-[10.5px] font-black uppercase transition cursor-pointer flex items-center gap-1 shadow-sm"
                    title="Cascade delete farm node, all submodules, and release email/phone credentials"
                  >
                    <Trash2 className="w-3 h-3" /> Delete Node
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* PAGINATION CONTROLS FOOTER */}
      {filteredNodes.length > 0 && (
        <div className="px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3 text-slate-600 font-medium">
            <span>
              Showing <strong className="text-slate-900 font-bold">{(currentPage - 1) * pageSize + 1}</strong> to <strong className="text-slate-900 font-bold">{Math.min(currentPage * pageSize, filteredNodes.length)}</strong> of <strong className="text-slate-900 font-bold">{filteredNodes.length}</strong> farm nodes
            </span>
            <div className="flex items-center gap-1.5 pl-3 border-l border-slate-200">
              <span className="text-slate-500 text-[11px]">Nodes per page:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-700 outline-none cursor-pointer"
              >
                <option value={6}>6</option>
                <option value={8}>8</option>
                <option value={12}>12</option>
                <option value={24}>24</option>
                <option value={50}>50</option>
              </select>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setCurrentPage(1)}
              disabled={currentPage <= 1}
              className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer"
              title="First page"
            >
              <ChevronsLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage <= 1}
              className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer flex items-center gap-1"
              title="Previous page"
            >
              <ChevronLeft className="w-4 h-4" />
              <span className="text-xs font-semibold hidden sm:inline">Prev</span>
            </button>

            <div className="flex items-center gap-1 px-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1)
                .filter(page => {
                  if (totalPages <= 5) return true;
                  if (page === 1 || page === totalPages) return true;
                  return Math.abs(page - currentPage) <= 1;
                })
                .map((page, idx, arr) => {
                  const showEllipsisBefore = idx > 0 && page - arr[idx - 1] > 1;
                  return (
                    <React.Fragment key={page}>
                      {showEllipsisBefore && <span className="text-slate-400 px-1">...</span>}
                      <button
                        type="button"
                        onClick={() => setCurrentPage(page)}
                        className={`w-7 h-7 rounded-lg text-xs font-bold transition cursor-pointer ${
                          currentPage === page
                            ? "bg-indigo-600 text-white shadow-sm"
                            : "bg-white border border-slate-200 text-slate-700 hover:bg-slate-100"
                        }`}
                      >
                        {page}
                      </button>
                    </React.Fragment>
                  );
                })}
            </div>

            <button
              type="button"
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages}
              className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer flex items-center gap-1"
              title="Next page"
            >
              <span className="text-xs font-semibold hidden sm:inline">Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setCurrentPage(totalPages)}
              disabled={currentPage >= totalPages}
              className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer"
              title="Last page"
            >
              <ChevronsRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* SUSPEND MODAL */}
      {suspendingNode && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full p-6 space-y-4">
            <div>
              <h3 className="text-base font-black text-slate-900">
                {suspendStatus === "SUSPENDED" ? "Suspend Farm Node" : "Reactivate Farm Node"}
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Target: {suspendingNode.farm?.name} ({suspendingNode.tenantEmail})
              </p>
            </div>
            <div className="space-y-3 text-xs">
              <label className="font-bold text-slate-700 block">Reason for status alteration (Mandatory):</label>
              <textarea
                rows={3}
                value={suspendReason}
                onChange={e => setSuspendReason(e.target.value)}
                placeholder="Please describe why this node access status is being modified..."
                className="w-full p-3 border rounded-xl bg-slate-50 text-slate-800 outline-none focus:border-indigo-500 transition-all font-semibold"
              />
            </div>
            <div className="flex justify-end gap-2 text-xs font-black uppercase">
              <button
                onClick={() => setSuspendingNode(null)}
                className="px-4 py-2 border rounded-xl hover:bg-slate-50 transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSuspendNodeSubmit}
                disabled={isSubmittingSuspend || !suspendReason.trim()}
                className={`px-4 py-2 rounded-xl text-white transition cursor-pointer flex items-center gap-1.5 disabled:opacity-50 ${suspendStatus === "SUSPENDED" ? "bg-amber-600 hover:bg-amber-500" : "bg-teal-600 hover:bg-teal-500"}`}
              >
                {isSubmittingSuspend ? "Processing..." : (suspendStatus === "SUSPENDED" ? "Confirm Suspension" : "Confirm Reactivation")}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CASCADE CONFIRMATION MODAL */}
      {deletingNode && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs z-50 flex items-center justify-center p-4 font-sans animate-fade-in">
          <div className="bg-white rounded-3xl border border-rose-200 shadow-2xl max-w-lg w-full p-6 space-y-5">
            {/* Modal Header */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-rose-100 rounded-2xl text-rose-700">
                  <Trash2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-rose-700 tracking-tight">
                    Cascade Delete Farm Node
                  </h3>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    Irreversible Super Admin workspace purge & credential release
                  </p>
                </div>
              </div>
              <button
                onClick={() => setDeletingNode(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Target Profile Card */}
            <div className="p-4 bg-rose-50/80 border border-rose-200 rounded-2xl space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-rose-700 uppercase font-black tracking-wider">Target Node For Purge</span>
                <span className="px-2 py-0.5 bg-rose-200 text-rose-900 text-[9px] font-black rounded-md font-mono">
                  {deletingNode.role || "Farmer Node"}
                </span>
              </div>
              <div className="font-black text-slate-900 text-sm">{deletingNode.farm?.name || deletingNode.farmName || "Farm Node"}</div>
              <div className="text-slate-600 flex flex-wrap gap-x-3 gap-y-0.5 text-[11.5px]">
                <span>Owner: <strong>{deletingNode.tenantEmail || deletingNode.email}</strong></span>
                {deletingNode.tenantPhone && <span>Phone: {deletingNode.tenantPhone}</span>}
              </div>
              <div className="text-[10px] font-mono text-slate-400">
                Tenant UID: {deletingNode.tenantUid || deletingNode.uid || deletingNode.id}
              </div>
            </div>

            {/* Warning Note */}
            <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-[11px] text-amber-900 space-y-1 font-medium">
              <div className="flex items-center gap-1.5 font-bold text-amber-800">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>What happens when you delete this farm node?</span>
              </div>
              <ul className="list-disc pl-5 space-y-0.5 text-amber-900/90 text-[10.5px]">
                <li>All crop cycles, livestock batches, sales, expenses, invoices, feed logs & assets are purged.</li>
                <li>The user account is removed from Firebase Auth and active sessions are revoked.</li>
                <li>The owner's email address and phone number are immediately released for future re-registration.</li>
                <li>A complete audit record is archived in the Super Admin Deleted Farm Nodes Tracker.</li>
              </ul>
            </div>

            {/* Form Fields */}
            <div className="space-y-3.5 text-xs">
              <div>
                <label className="font-extrabold text-slate-700 block pb-1">
                  1. Administrative Reason for Deletion *
                </label>
                <textarea
                  rows={2}
                  value={deleteReason}
                  onChange={e => setDeleteReason(e.target.value)}
                  placeholder="State the reason for completely deleting this farm node (audit trail requirement)..."
                  className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 text-slate-800 outline-none focus:bg-white focus:border-rose-500 transition-all font-semibold"
                />
                <div className="flex flex-wrap gap-1.5 pt-1.5">
                  {[
                    "Tenant requested complete node decommissioning",
                    "Duplicate / test farm node registration",
                    "Non-payment / account termination",
                    "Commercial farm relocation / handover"
                  ].map((r, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setDeleteReason(r)}
                      className="text-[10px] px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg font-medium cursor-pointer"
                    >
                      + {r}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center pb-1">
                  <label className="font-extrabold text-slate-700 block">
                    2. Type Confirmation Text *
                  </label>
                  <button
                    type="button"
                    onClick={() => setDeleteConfirmationInput(targetExpectedConfirmation)}
                    className="text-[10px] font-bold text-rose-600 hover:underline cursor-pointer"
                  >
                    Auto-Fill Target Name
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 pb-1.5">
                  To confirm, type <strong className="text-rose-600 font-mono font-bold select-all">"{targetExpectedConfirmation}"</strong> below:
                </p>
                <input
                  type="text"
                  value={deleteConfirmationInput}
                  onChange={e => setDeleteConfirmationInput(e.target.value)}
                  placeholder={`Type "${targetExpectedConfirmation}" to confirm...`}
                  className="w-full p-3 border border-rose-300 rounded-xl bg-rose-50/40 text-slate-900 outline-none focus:bg-white focus:border-rose-600 transition-all font-bold font-mono text-xs"
                />
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 text-xs font-black uppercase">
              <button
                type="button"
                onClick={() => setDeletingNode(null)}
                className="px-4 py-2.5 border border-slate-200 rounded-xl hover:bg-slate-50 transition cursor-pointer text-slate-600 font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleDeleteNodeSubmit()}
                disabled={
                  isSubmittingDelete || 
                  !deleteReason.trim() || 
                  (
                    deleteConfirmationInput.trim().toLowerCase() !== (deletingNode?.farm?.name || "").trim().toLowerCase() && 
                    deleteConfirmationInput.trim().toLowerCase() !== (deletingNode?.tenantEmail || deletingNode?.email || "").trim().toLowerCase() &&
                    deleteConfirmationInput.trim() !== (deletingNode?.tenantUid || deletingNode?.uid || "")
                  )
                }
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl transition cursor-pointer flex items-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed shadow-md"
              >
                {isSubmittingDelete ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Cascade Purging Workspace...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>Permanently Delete Farm Node</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

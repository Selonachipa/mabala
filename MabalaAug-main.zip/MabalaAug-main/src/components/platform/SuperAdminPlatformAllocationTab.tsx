import React, { useState, useMemo, useEffect } from "react";
import { safeFormatError } from "../../utils/errorUtils";
import { safeLocalStorage as localStorage, safeParseJSON } from "../../utils/safeStorage";
import {
  Coins,
  Search,
  Users,
  ShieldCheck,
  Plus,
  Minus,
  Check,
  AlertTriangle,
  Clock,
  Sparkles,
  Calendar,
  Layers,
  ArrowRight,
  TrendingUp,
  FileText,
  User,
  Zap,
  RotateCcw
} from "lucide-react";
import { UserRecord } from "./SuperAdminUserDirectoryTab";
import { doc, getDoc, updateDoc, collection, addDoc } from "firebase/firestore";
import { db } from "../../firebase";

export interface SuperAdminPlatformAllocationTabProps {
  allUsers: UserRecord[];
  onAllocationComplete?: (updated: {
    uid: string;
    credits: number;
    subscriptionPackage: string;
    subscriptionExpiresAt?: string;
  }) => void;
  currentUserEmail?: string;
  currencySymbol?: string;
}

export interface CreditAllocationLog {
  id: string;
  timestamp: string;
  targetEmail: string;
  targetUid: string;
  targetName?: string;
  actionType: "ADD" | "DEDUCT" | "TIER_CHANGE" | "SET_ABSOLUTE";
  amount: number;
  previousBalance: number;
  newBalance: number;
  newTier?: string;
  reason: string;
  authorizedBy: string;
}

const SUBSCRIPTION_PACKAGES = [
  {
    id: "UNCHANGED",
    name: "Keep Current Tier",
    bundledCredits: 0,
    badge: "Current",
    desc: "Leave tenant's existing subscription package unchanged."
  },
  {
    id: "Seeding Tier",
    name: "Seeding Tier (Free Forever)",
    bundledCredits: 60,
    badge: "60 CR Welcome",
    desc: "Free Forever starter tier with 60 welcome write action credits on signup."
  },
  {
    id: "Daily Bundle",
    name: "Daily Bundle (24h Unmetered)",
    bundledCredits: 0,
    badge: "24h Unmetered",
    desc: "24-hour unmetered full write operations pass (bypasses credit deductions)."
  },
  {
    id: "Monthly Plan",
    name: "Monthly Plan",
    bundledCredits: 1500,
    badge: "1,500 CR/mo",
    desc: "Full farm ledger, input credit portal, storage sync, 1,500 credits/mo (ZK 180/mo)."
  },
  {
    id: "Growth Plan",
    name: "Growth Plan",
    bundledCredits: 12000,
    badge: "12,000 CR/mo",
    desc: "Includes free agronomist visit + Consignment Hub access, 12,000 credits/mo (ZK 650/mo)."
  },
  {
    id: "Enterprise Plan",
    name: "Enterprise Plan",
    bundledCredits: 120000,
    badge: "120,000 CR/mo",
    desc: "Multi-warehouse, agronomy + vet visits, API suite, 120,000 credits/mo (ZK 2,500/mo)."
  }
];

const PRESET_CREDIT_AMOUNTS = [100, 250, 500, 1000, 2500, 5000, 12000, 50000];

export const SuperAdminPlatformAllocationTab: React.FC<SuperAdminPlatformAllocationTabProps> = ({
  allUsers = [],
  onAllocationComplete,
  currentUserEmail = "superadmin@mabala.app",
  currencySymbol = "ZK"
}) => {
  const [selectedUserUid, setSelectedUserUid] = useState<string>("");
  const [searchFilter, setSearchFilter] = useState("");
  const [operationType, setOperationType] = useState<"ADD" | "DEDUCT" | "TIER_CHANGE">("ADD");
  const [creditAmount, setCreditAmount] = useState<number>(500);
  const [selectedPackage, setSelectedPackage] = useState<string>("UNCHANGED");
  const [autoApplyBundledCredits, setAutoApplyBundledCredits] = useState(true);
  const [reason, setReason] = useState("Super Admin Promotional Manual Grant");
  const [notes, setNotes] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [allocationHistory, setAllocationHistory] = useState<CreditAllocationLog[]>([]);

  // Load history from local storage
  useEffect(() => {
    try {
      const logs = safeParseJSON<CreditAllocationLog[]>(localStorage.getItem("mabala_credit_allocation_audit_logs") || "[]", []);
      setAllocationHistory(Array.isArray(logs) ? logs : []);
    } catch {
      setAllocationHistory([]);
    }
  }, []);

  // Filter user options
  const userOptions = useMemo(() => {
    return allUsers.filter((u) => {
      if (!u) return false;
      const q = searchFilter.toLowerCase();
      const email = (u.email || u.tenantEmail || "").toLowerCase();
      const name = (u.displayName || u.name || u.farmName || "").toLowerCase();
      const role = (u.role || u.accountType || "").toLowerCase();
      return email.includes(q) || name.includes(q) || role.includes(q);
    });
  }, [allUsers, searchFilter]);

  // Active selected user record
  const selectedUser = useMemo(() => {
    return allUsers.find((u) => (u.uid || u.tenantUid || u.id) === selectedUserUid) || null;
  }, [allUsers, selectedUserUid]);

  // Set first user by default if none selected
  useEffect(() => {
    if (!selectedUserUid && allUsers.length > 0) {
      setSelectedUserUid(allUsers[0].uid || allUsers[0].tenantUid || allUsers[0].id || "");
    }
  }, [allUsers, selectedUserUid]);

  const handleApplyAllocation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) {
      setStatusMessage({ type: "error", text: "Please select a target user / farm node." });
      return;
    }
    if (!reason.trim()) {
      setStatusMessage({ type: "error", text: "Mandatory justification reason is required for compliance audit logs." });
      return;
    }

    setIsProcessing(true);
    setStatusMessage(null);

    const uid = selectedUser.uid || selectedUser.tenantUid || selectedUser.id || "";
    const email = selectedUser.email || selectedUser.tenantEmail || "";
    const currentCredits = Number(selectedUser.credits ?? 60);
    const currentPackage = selectedUser.subscriptionPackage || selectedUser.subscriptionTier || "Seeding Tier";

    let finalCredits = currentCredits;
    let finalPackage = currentPackage;
    let finalExpiresAt = selectedUser.subscriptionExpiresAt;

    if (operationType === "ADD") {
      finalCredits = Math.max(0, currentCredits + Number(creditAmount));
    } else if (operationType === "DEDUCT") {
      finalCredits = Math.max(0, currentCredits - Number(creditAmount));
    } else if (operationType === "TIER_CHANGE") {
      if (selectedPackage !== "UNCHANGED") {
        finalPackage = selectedPackage;
        const pkgObj = SUBSCRIPTION_PACKAGES.find((p) => p.id === selectedPackage);
        if (autoApplyBundledCredits && pkgObj && pkgObj.bundledCredits > 0) {
          finalCredits += pkgObj.bundledCredits;
        }
        if (selectedPackage === "Daily Bundle") {
          const tomorrow = new Date();
          tomorrow.setDate(tomorrow.getDate() + 1);
          finalExpiresAt = tomorrow.toISOString();
        } else if (selectedPackage !== "Seeding Tier") {
          const nextMonth = new Date();
          nextMonth.setMonth(nextMonth.getMonth() + 1);
          finalExpiresAt = nextMonth.toISOString();
        }
      }
    }

    try {
      const { getFunctions, httpsCallable } = await import("firebase/functions");
      const { getApp } = await import("firebase/app");
      const allocateCredits = httpsCallable(getFunctions(getApp()), "allocateCredits");
      const result: any = await allocateCredits({
        tenantId: uid,
        creditType: "platform",
        amount: operationType === "TIER_CHANGE" ? (autoApplyBundledCredits ? Math.max(0, finalCredits - currentCredits) : 0) : creditAmount,
        adjustmentType: operationType === "ADD" ? "allocate" : operationType === "DEDUCT" ? "deduct" : "allocate",
        subscriptionPackage: operationType === "TIER_CHANGE" ? finalPackage : undefined,
        subscriptionDurationDays: 30,
        reason: `${reason}${notes ? ` | Notes: ${notes}` : ""}`,
        idempotencyKey: `platform-tab-${uid}-${Date.now()}`
      });
      const authoritativeBalance = Number(result.data?.platformBalance ?? result.data?.newBalance ?? finalCredits);
      onAllocationComplete?.({ uid, credits: authoritativeBalance, subscriptionPackage: finalPackage, subscriptionExpiresAt: finalExpiresAt });
      setStatusMessage({ type: "success", text: `Successfully updated ${email}. New balance: ${authoritativeBalance.toLocaleString()} credits.` });
      setNotes("");
      return;

      // 1. Update in Firestore if available
      try {
        if (db && uid) {
          const userDocRef = doc(db, "users", uid);
          await updateDoc(userDocRef, {
            credits: finalCredits,
            subscriptionPackage: finalPackage,
            subscriptionTier: finalPackage,
            subscriptionExpiresAt: finalExpiresAt || null,
            lastCreditTopUp: new Date().toISOString(),
            lastCreditTopUpAmount: creditAmount,
            lastCreditTopUpBy: currentUserEmail
          });

          // Add audit log record to Firestore
          const auditRef = collection(db, "credit_allocation_audit_logs");
          await addDoc(auditRef, {
            timestamp: new Date().toISOString(),
            targetUid: uid,
            targetEmail: email,
            targetName: selectedUser.name || selectedUser.displayName || "",
            actionType: operationType,
            amount: creditAmount,
            previousBalance: currentCredits,
            newBalance: finalCredits,
            newTier: finalPackage,
            reason: `${reason}${notes ? ` | Notes: ${notes}` : ""}`,
            authorizedBy: currentUserEmail
          });
        }
      } catch (fbErr) {
        console.warn("Firestore update notice, falling back to local storage sync:", fbErr);
      }

      // 2. Update local storage registration cache
      try {
        const storedUsers = safeParseJSON<any[]>(localStorage.getItem("mabala_registered_users") || "[]", []);
        const updatedUsers = storedUsers.map((u) => {
          if (u.uid === uid || u.email?.toLowerCase() === email.toLowerCase()) {
            return {
              ...u,
              credits: finalCredits,
              subscriptionPackage: finalPackage,
              subscriptionTier: finalPackage,
              subscriptionExpiresAt: finalExpiresAt
            };
          }
          return u;
        });
        localStorage.setItem("mabala_registered_users", JSON.stringify(updatedUsers));
      } catch (_) {}

      // 3. Log to local audit trail
      const newLog: CreditAllocationLog = {
        id: `alloc-${Date.now()}`,
        timestamp: new Date().toISOString(),
        targetUid: uid,
        targetEmail: email,
        targetName: selectedUser.name || selectedUser.displayName || "",
        actionType: operationType,
        amount: creditAmount,
        previousBalance: currentCredits,
        newBalance: finalCredits,
        newTier: finalPackage,
        reason: `${reason}${notes ? ` | Notes: ${notes}` : ""}`,
        authorizedBy: currentUserEmail
      };

      const updatedHistory = [newLog, ...allocationHistory];
      setAllocationHistory(updatedHistory);
      localStorage.setItem("mabala_credit_allocation_audit_logs", JSON.stringify(updatedHistory.slice(0, 100)));

      // 4. Update parent state
      if (onAllocationComplete) {
        onAllocationComplete({
          uid,
          credits: finalCredits,
          subscriptionPackage: finalPackage,
          subscriptionExpiresAt: finalExpiresAt
        });
      }

      setStatusMessage({
        type: "success",
        text: `Successfully allocated to ${email}. New Balance: ${finalCredits.toLocaleString()} Credits | Tier: ${finalPackage}`
      });

      setNotes("");
    } catch (err: any) {
      setStatusMessage({
        type: "error",
        text: `Allocation failed: ${safeFormatError(err)}`
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6 font-sans animate-fade-in" id="super-admin-platform-allocation-tab">
      {/* HEADER CARD */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 bg-amber-50 text-amber-900 text-[10px] font-black uppercase rounded-md tracking-wider border border-amber-200 font-mono">
              Credit Master Controller
            </span>
            <span className="text-xs text-slate-400 font-mono">platform_allocations_v2</span>
          </div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight mt-1 flex items-center gap-2">
            <span>🪙 Platform Manual Allocation Module</span>
          </h2>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            Manually grant, top-up, adjust write action credits, and override subscription tiers for any tenant or farmer on the platform.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono font-bold bg-amber-50/80 border border-amber-200 px-3.5 py-2 rounded-2xl text-amber-900">
          <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
          <span>Super Admin Authorization Active</span>
        </div>
      </div>

      {statusMessage && (
        <div
          className={`p-4 rounded-2xl border text-xs font-bold flex items-center justify-between gap-3 ${
            statusMessage.type === "success"
              ? "bg-emerald-50 text-emerald-900 border-emerald-200"
              : "bg-rose-50 text-rose-900 border-rose-200"
          }`}
        >
          <span>{statusMessage.text}</span>
          <button
            type="button"
            onClick={() => setStatusMessage(null)}
            className="text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* MAIN CONSOLE GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: TARGET SELECTION & LIVE TELEMETRY (4 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-2">
              <Users className="w-4 h-4 text-slate-400" />
              <span>1. Select Target User / Farm Node</span>
            </h3>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Search user by name, email, or role..."
                className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:bg-white focus:border-amber-500"
              />
            </div>

            <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 border border-slate-100 rounded-2xl pr-1 space-y-1">
              {userOptions.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-400">No users found.</div>
              ) : (
                userOptions.map((u) => {
                  const uid = u.uid || u.tenantUid || u.id || "";
                  const isSelected = selectedUserUid === uid;
                  const name = u.displayName || u.name || u.farmName || u.email?.split("@")[0];
                  const email = u.email || u.tenantEmail || "";
                  const credits = u.credits ?? 60;
                  const role = u.role || u.accountType || "Farmer";

                  return (
                    <div
                      key={uid}
                      onClick={() => setSelectedUserUid(uid)}
                      className={`p-2.5 rounded-xl transition cursor-pointer flex items-center justify-between gap-2 text-xs ${
                        isSelected
                          ? "bg-amber-50/90 text-amber-950 font-extrabold border border-amber-200"
                          : "hover:bg-slate-50 text-slate-700 font-medium"
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="truncate font-bold text-slate-900">{name}</div>
                        <div className="text-[10px] text-slate-400 font-mono truncate">{email}</div>
                        <span className="inline-block mt-0.5 px-1.5 py-0.2 rounded text-[9px] font-black uppercase bg-slate-100 text-slate-600">
                          {role}
                        </span>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="font-mono text-xs font-bold text-amber-600 bg-amber-50/80 px-2 py-0.5 rounded border border-amber-200">
                          {credits.toLocaleString()} CR
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* ACTIVE TARGET TELEMETRY CARD */}
          {selectedUser && (
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-3xl p-5 space-y-4 shadow-md">
              <div className="flex items-center justify-between border-b border-slate-700/60 pb-3">
                <span className="text-[10px] font-mono font-bold uppercase text-amber-300 tracking-wider">
                  Target Diagnostics
                </span>
                <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded font-mono text-slate-400">
                  UID: {(selectedUser.uid || selectedUser.id || "").slice(0, 10)}...
                </span>
              </div>

              <div className="space-y-1">
                <div className="text-base font-extrabold">{selectedUser.name || selectedUser.displayName || "User"}</div>
                <div className="text-xs text-slate-300 font-mono">{selectedUser.email}</div>
                <div className="text-[11px] text-slate-400">Farm: {selectedUser.farm?.name || selectedUser.farmName || "Mabala Node"}</div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="bg-slate-800/80 border border-slate-700 p-3 rounded-xl space-y-0.5">
                  <span className="text-[9px] uppercase font-bold text-slate-400 block">Available Credits</span>
                  <div className="text-lg font-black text-amber-400 font-mono">
                    {(selectedUser.credits ?? 60).toLocaleString()} <span className="text-xs font-normal">CR</span>
                  </div>
                </div>
                <div className="bg-slate-800/80 border border-slate-700 p-3 rounded-xl space-y-0.5">
                  <span className="text-[9px] uppercase font-bold text-slate-400 block">Active Plan</span>
                  <div className="text-xs font-extrabold text-emerald-400 truncate">
                    {selectedUser.subscriptionPackage || selectedUser.subscriptionTier || "Seeding Tier"}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* RIGHT COLUMN: ALLOCATION CONTROLLER (7 cols) */}
        <div className="lg:col-span-7">
          <form onSubmit={handleApplyAllocation} className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-5">
            <div className="border-b border-slate-100 pb-4 flex items-center justify-between">
              <h3 className="text-sm font-black uppercase text-slate-900 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>2. Configure Allocation & Overrides</span>
              </h3>
              <span className="text-[11px] text-slate-400 font-mono">Target: {selectedUser?.email || "None"}</span>
            </div>

            {/* ACTION MODE SELECTOR */}
            <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 rounded-2xl">
              <button
                type="button"
                onClick={() => setOperationType("ADD")}
                className={`py-2 text-xs font-extrabold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  operationType === "ADD"
                    ? "bg-white text-slate-900 shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                <Plus className="w-3.5 h-3.5 text-emerald-600" />
                <span>Grant Credits</span>
              </button>
              <button
                type="button"
                onClick={() => setOperationType("DEDUCT")}
                className={`py-2 text-xs font-extrabold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  operationType === "DEDUCT"
                    ? "bg-white text-slate-900 shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                <Minus className="w-3.5 h-3.5 text-rose-600" />
                <span>Debit Credits</span>
              </button>
              <button
                type="button"
                onClick={() => setOperationType("TIER_CHANGE")}
                className={`py-2 text-xs font-extrabold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  operationType === "TIER_CHANGE"
                    ? "bg-white text-slate-900 shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-indigo-600" />
                <span>Plan Override</span>
              </button>
            </div>

            {/* CREDIT AMOUNT CONTROLS (IF ADD OR DEDUCT) */}
            {operationType !== "TIER_CHANGE" && (
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider block">
                  {operationType === "ADD" ? "Credits to Grant" : "Credits to Deduct"}
                </label>

                {/* Preset Chips */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  {PRESET_CREDIT_AMOUNTS.map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setCreditAmount(amt)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition cursor-pointer border ${
                        creditAmount === amt
                          ? "bg-amber-600 text-white border-amber-600 shadow-xs"
                          : "bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200"
                      }`}
                    >
                      +{amt.toLocaleString()}
                    </button>
                  ))}
                </div>

                <div className="relative">
                  <Coins className="w-4 h-4 text-amber-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    min="1"
                    value={creditAmount}
                    onChange={(e) => setCreditAmount(Math.max(1, Number(e.target.value)))}
                    className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-bold text-slate-900 outline-none focus:bg-white focus:border-amber-500"
                    placeholder="Enter custom amount..."
                    required
                  />
                </div>
              </div>
            )}

            {/* SUBSCRIPTION PLAN OVERRIDE (IF TIER_CHANGE) */}
            {operationType === "TIER_CHANGE" && (
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider block">
                  Target Subscription Plan
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {SUBSCRIPTION_PACKAGES.map((pkg) => (
                    <div
                      key={pkg.id}
                      onClick={() => setSelectedPackage(pkg.id)}
                      className={`p-3 rounded-2xl border transition cursor-pointer space-y-1 ${
                        selectedPackage === pkg.id
                          ? "border-amber-500 bg-amber-50/60 shadow-xs"
                          : "border-slate-200 hover:border-slate-300 bg-white"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-xs text-slate-900">{pkg.name}</span>
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-black uppercase bg-slate-100 text-slate-700">
                          {pkg.badge}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500">{pkg.desc}</p>
                    </div>
                  ))}
                </div>

                <label className="flex items-center gap-2 pt-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoApplyBundledCredits}
                    onChange={(e) => setAutoApplyBundledCredits(e.target.checked)}
                    className="rounded text-amber-600 focus:ring-amber-500"
                  />
                  <span className="text-xs font-semibold text-slate-700">
                    Automatically top up bundled tier write action credits upon activation
                  </span>
                </label>
              </div>
            )}

            {/* JUSTIFICATION REASON & NOTES */}
            <div className="space-y-3">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider block mb-1">
                  Audit Justification Reason <span className="text-rose-500">*</span>
                </label>
                <select
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none"
                  required
                >
                  <option value="Super Admin Promotional Manual Grant">Super Admin Promotional Manual Grant</option>
                  <option value="Customer Support Issue Compensation">Customer Support Issue Compensation</option>
                  <option value="Subscription Package Upgrade / Renewal">Subscription Package Upgrade / Renewal</option>
                  <option value="Pilot / Demonstration Account Setup">Pilot / Demonstration Account Setup</option>
                  <option value="Manual Bank Transfer / MoMo Clearance">Manual Bank Transfer / MoMo Clearance</option>
                  <option value="Zero-Rate Baseline Balance Reset">Zero-Rate Baseline Balance Reset</option>
                  <option value="Administrative Correction / Reversal">Administrative Correction / Reversal</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider block mb-1">
                  Optional Audit Notes
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Cleared via MoMo Reference #TXN-98412..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 outline-none focus:bg-white focus:border-amber-500"
                />
              </div>
            </div>

            {/* SUBMIT BUTTON */}
            <button
              type="submit"
              disabled={isProcessing || !selectedUser}
              className="w-full py-3 bg-slate-900 hover:bg-black text-white font-extrabold text-xs rounded-2xl transition cursor-pointer flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>{isProcessing ? "Processing Allocation..." : "Execute Manual Platform Allocation"}</span>
            </button>
          </form>
        </div>
      </div>

      {/* ALLOCATION AUDIT LOGS LEDGER */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-black uppercase text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-slate-400" />
              <span>Super Admin Allocation Ledger & Audit History</span>
            </h3>
            <p className="text-xs text-slate-400 font-medium">
              Permanent immutable transaction log of all manual credits and tier changes.
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
            {allocationHistory.length} Entries Logged
          </span>
        </div>

        <div className="overflow-x-auto border border-slate-100 rounded-2xl">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50/80 text-slate-500 font-extrabold border-b border-slate-200 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Date & Time</th>
                <th className="py-3 px-4">Target User</th>
                <th className="py-3 px-4">Operation</th>
                <th className="py-3 px-4">Balance Delta</th>
                <th className="py-3 px-4">New Balance</th>
                <th className="py-3 px-4">Authorized By</th>
                <th className="py-3 px-4">Justification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
              {allocationHistory.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 font-sans">
                    No credit allocation history recorded yet.
                  </td>
                </tr>
              ) : (
                allocationHistory.slice(0, 15).map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-2.5 px-4 text-slate-500">{new Date(log.timestamp).toLocaleString()}</td>
                    <td className="py-2.5 px-4 font-bold text-slate-800 font-sans">{log.targetEmail}</td>
                    <td className="py-2.5 px-4">
                      <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                        log.actionType === "ADD" ? "bg-emerald-50 text-emerald-800 border border-emerald-200" :
                        log.actionType === "DEDUCT" ? "bg-rose-50 text-rose-800 border border-rose-200" :
                        "bg-indigo-50 text-indigo-800 border border-indigo-200"
                      }`}>
                        {log.actionType}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 font-bold text-slate-900">
                      {log.actionType === "ADD" ? `+${log.amount}` : log.actionType === "DEDUCT" ? `-${log.amount}` : log.newTier}
                    </td>
                    <td className="py-2.5 px-4 text-amber-600 font-bold">{log.newBalance?.toLocaleString()} CR</td>
                    <td className="py-2.5 px-4 text-slate-500 font-sans">{log.authorizedBy}</td>
                    <td className="py-2.5 px-4 text-slate-600 font-sans max-w-xs truncate">{log.reason}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SuperAdminPlatformAllocationTab;

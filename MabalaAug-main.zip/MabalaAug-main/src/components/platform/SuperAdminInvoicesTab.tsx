import React, { useState, useEffect, useMemo } from "react";
import {
  PlatformInvoice,
  fetchPlatformInvoices,
  markPlatformInvoicePaid
} from "../../services/platformInvoiceService";
import {
  calculateDaysOverdue,
  dispatchInvoiceEmailReminder,
  runAutomatedDailyInvoiceScan,
  generateDirectPayLink,
  InvoiceReminderLog,
  fetchReminderLogs
} from "../../services/invoiceReminderService";
import {
  FileText,
  Plus,
  Search,
  RefreshCw,
  Send,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Mail,
  Copy,
  Check,
  Building2,
  ExternalLink,
  DollarSign,
  Calendar,
  Filter,
  Eye,
  X,
  Printer,
  ShieldCheck,
  CreditCard,
  MessageSquare
} from "lucide-react";

export interface SuperAdminInvoicesTabProps {
  onOpenRaiseInvoice: (targetTenant?: any) => void;
  currencySymbol?: string;
  currentUserEmail?: string;
}

export const SuperAdminInvoicesTab: React.FC<SuperAdminInvoicesTabProps> = ({
  onOpenRaiseInvoice,
  currencySymbol = "ZK",
  currentUserEmail = "support@mabala.cloud"
}) => {
  const [invoices, setInvoices] = useState<PlatformInvoice[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<"ALL" | "PENDING" | "PAID" | "OVERDUE">("ALL");
  const [typeFilter, setTypeFilter] = useState<"ALL" | "Farmer" | "Agro-Dealer" | "Supplier">("ALL");
  
  // Scanning & Action States
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanReport, setScanReport] = useState<string | null>(null);
  const [sendingEmailInvoiceId, setSendingEmailInvoiceId] = useState<string | null>(null);
  const [copiedInvoiceId, setCopiedInvoiceId] = useState<string | null>(null);
  const [previewInvoice, setPreviewInvoice] = useState<PlatformInvoice | null>(null);
  const [settlingInvoice, setSettlingInvoice] = useState<PlatformInvoice | null>(null);
  const [settleTxRef, setSettleTxRef] = useState<string>("");
  const [isSettling, setIsSettling] = useState<boolean>(false);

  const loadInvoices = async () => {
    setIsLoading(true);
    try {
      const data = await fetchPlatformInvoices();
      // Sort newest first
      data.sort((a, b) => new Date(b.issuedAt).getTime() - new Date(a.issuedAt).getTime());
      setInvoices(data);
    } catch (err) {
      console.error("[SuperAdminInvoicesTab] Failed to load invoices:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();

    // Listen for custom invoice raised event
    const handleInvoiceRaised = () => {
      loadInvoices();
    };

    window.addEventListener("mabala_invoice_raised", handleInvoiceRaised);
    return () => {
      window.removeEventListener("mabala_invoice_raised", handleInvoiceRaised);
    };
  }, []);

  // Filtered list
  const filteredInvoices = useMemo(() => {
    return invoices.filter(inv => {
      const { isOverdue } = calculateDaysOverdue(inv.dueDate);
      
      // Status Filter
      if (statusFilter === "PENDING" && inv.status !== "PENDING") return false;
      if (statusFilter === "PAID" && inv.status !== "PAID") return false;
      if (statusFilter === "OVERDUE") {
        if (inv.status !== "PENDING" || !isOverdue) return false;
      }

      // Type Filter
      if (typeFilter !== "ALL" && inv.recipientType !== typeFilter) return false;

      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchNum = (inv.invoiceNumber || inv.id || "").toLowerCase().includes(q);
        const matchName = (inv.recipientTenantName || "").toLowerCase().includes(q);
        const matchEmail = (inv.recipientEmail || "").toLowerCase().includes(q);
        const matchTenantId = (inv.recipientTenantId || "").toLowerCase().includes(q);
        const matchNotes = (inv.notes || "").toLowerCase().includes(q);
        return matchNum || matchName || matchEmail || matchTenantId || matchNotes;
      }

      return true;
    });
  }, [invoices, statusFilter, typeFilter, searchQuery]);

  // Aggregate Metrics
  const metrics = useMemo(() => {
    let totalInvoiced = 0;
    let totalPending = 0;
    let totalPaid = 0;
    let overdueCount = 0;
    let overdueAmount = 0;

    invoices.forEach(inv => {
      const amt = Number(inv.totalAmount) || 0;
      totalInvoiced += amt;
      if (inv.status === "PAID") {
        totalPaid += amt;
      } else if (inv.status === "PENDING") {
        totalPending += amt;
        const { isOverdue } = calculateDaysOverdue(inv.dueDate);
        if (isOverdue) {
          overdueCount++;
          overdueAmount += amt;
        }
      }
    });

    return { totalInvoiced, totalPending, totalPaid, overdueCount, overdueAmount };
  }, [invoices]);

  // Handle Send / Resend Email Reminder
  const handleSendInvoiceEmail = async (invoice: PlatformInvoice) => {
    setSendingEmailInvoiceId(invoice.id);
    try {
      const log = await dispatchInvoiceEmailReminder(invoice, true);
      alert(`📧 Manual Invoice & Pay Link successfully dispatched!\n\nRecipient: ${log.recipientEmail}\nInvoice: #${invoice.invoiceNumber}\nSubject: ${log.emailSubject}`);
      await loadInvoices();
    } catch (err: any) {
      console.error("Failed to send invoice email:", err);
      alert(`Failed to send email: ${err.message || "Unknown error"}`);
    } finally {
      setSendingEmailInvoiceId(null);
    }
  };

  // Copy direct payment link
  const handleCopyPayLink = (invoice: PlatformInvoice) => {
    const { payLinkUrl } = generateDirectPayLink(invoice.id, invoice.recipientEmail);
    navigator.clipboard.writeText(payLinkUrl);
    setCopiedInvoiceId(invoice.id);
    setTimeout(() => setCopiedInvoiceId(null), 3000);
  };

  // Manual settlement confirmation
  const handleExecuteSettlement = async () => {
    if (!settlingInvoice) return;
    setIsSettling(true);
    try {
      const txId = settleTxRef.trim() || `MANUAL-SETTLE-${Date.now().toString().slice(-6)}`;
      await markPlatformInvoicePaid(settlingInvoice.id, txId);
      alert(`✅ Invoice #${settlingInvoice.invoiceNumber} marked as PAID (Ref: ${txId}).`);
      setSettlingInvoice(null);
      setSettleTxRef("");
      await loadInvoices();
    } catch (err: any) {
      alert(`Failed to settle invoice: ${err.message || "Unknown error"}`);
    } finally {
      setIsSettling(false);
    }
  };

  // Run automated scan
  const handleRunScan = async () => {
    setIsScanning(true);
    setScanReport(null);
    try {
      const result = await runAutomatedDailyInvoiceScan();
      setScanReport(
        `Daily Scan Complete: ${result.scannedCount} invoices verified. ${result.remindersSentCount} email reminders dispatched. Total pending: ${currencySymbol} ${result.totalPendingAmountZK.toLocaleString()} (${currencySymbol} ${result.totalOverdueAmountZK.toLocaleString()} overdue).`
      );
      await loadInvoices();
    } catch (err: any) {
      setScanReport(`Scan execution warning: ${err.message || "Network issue"}`);
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="space-y-6 font-sans">
      {/* 1. Header & Financial Overview Banner */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 shadow-xl space-y-5">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-2xl">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-tight text-white">Platform Invoices & Manual Node Invoicing</h2>
                <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full text-[10px] font-black uppercase tracking-wider font-mono">
                  Live Dispatch
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium mt-0.5">
                Issue manual invoices to any farm node, dispatch Lipila payment links via Hostinger SMTP, and monitor network accounts receivable.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleRunScan}
              disabled={isScanning}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
              title="Run automated daily scan and send overdue payment reminders"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-indigo-400 ${isScanning ? "animate-spin" : ""}`} />
              <span>{isScanning ? "Scanning Reminders..." : "Run Reminder Scan"}</span>
            </button>

            <button
              type="button"
              onClick={() => onOpenRaiseInvoice()}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Raise Platform Invoice</span>
            </button>
          </div>
        </div>

        {/* Financial KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 pt-2">
          <div className="bg-slate-800/70 border border-slate-700/80 p-4 rounded-2xl space-y-1">
            <span className="text-[10px] font-mono uppercase text-slate-400 font-bold block">Total Invoiced</span>
            <div className="text-xl font-black font-mono text-white">
              {currencySymbol} {metrics.totalInvoiced.toLocaleString()}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">
              {invoices.length} Total Platform Invoices
            </div>
          </div>

          <div className="bg-amber-950/40 border border-amber-500/30 p-4 rounded-2xl space-y-1">
            <span className="text-[10px] font-mono uppercase text-amber-300 font-bold block">Outstanding Balance</span>
            <div className="text-xl font-black font-mono text-amber-400">
              {currencySymbol} {metrics.totalPending.toLocaleString()}
            </div>
            <div className="text-[10px] text-amber-300/80 font-medium">
              {invoices.filter(i => i.status === "PENDING").length} Unpaid Invoices
            </div>
          </div>

          <div className="bg-emerald-950/40 border border-emerald-500/30 p-4 rounded-2xl space-y-1">
            <span className="text-[10px] font-mono uppercase text-emerald-300 font-bold block">Collected & Settled</span>
            <div className="text-xl font-black font-mono text-emerald-400">
              {currencySymbol} {metrics.totalPaid.toLocaleString()}
            </div>
            <div className="text-[10px] text-emerald-300/80 font-medium">
              {invoices.filter(i => i.status === "PAID").length} Invoices Settled
            </div>
          </div>

          <div className="bg-rose-950/40 border border-rose-500/30 p-4 rounded-2xl space-y-1">
            <span className="text-[10px] font-mono uppercase text-rose-300 font-bold block">Overdue Invoices</span>
            <div className="text-xl font-black font-mono text-rose-400">
              {metrics.overdueCount} Overdue ({currencySymbol} {metrics.overdueAmount.toLocaleString()})
            </div>
            <div className="text-[10px] text-rose-300/80 font-medium">
              Automated reminders enabled
            </div>
          </div>
        </div>
      </div>

      {/* Scan Report Notification */}
      {scanReport && (
        <div className="p-4 bg-indigo-950/80 border border-indigo-500/50 rounded-2xl text-indigo-200 text-xs font-semibold flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
            <span>{scanReport}</span>
          </div>
          <button
            type="button"
            onClick={() => setScanReport(null)}
            className="text-indigo-400 hover:text-white text-xs font-bold px-2 py-0.5 rounded cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* 2. Search & Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by invoice #, farm name, owner email, tenant ID..."
            className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-indigo-500 focus:bg-white transition"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery("")}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Status Filters */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
            {(["ALL", "PENDING", "PAID", "OVERDUE"] as const).map(st => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                  statusFilter === st
                    ? "bg-white text-slate-900 shadow-xs font-black"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                {st === "ALL" ? "All Status" : st}
              </button>
            ))}
          </div>

          {/* Type Filter */}
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as any)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 outline-none"
          >
            <option value="ALL">All Recipient Types</option>
            <option value="Farmer">Farmers</option>
            <option value="Agro-Dealer">Agro-Dealers</option>
            <option value="Supplier">Suppliers / Partners</option>
          </select>

          <button
            type="button"
            onClick={loadInvoices}
            className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200 rounded-xl transition cursor-pointer"
            title="Refresh Invoices"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* 3. Invoices Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-extrabold border-b border-slate-200 uppercase tracking-wider text-[10.5px]">
                <th className="py-3.5 px-4">Invoice # & Recipient Node</th>
                <th className="py-3.5 px-4">Recipient Type & Email</th>
                <th className="py-3.5 px-4">Due Date & Overdue Status</th>
                <th className="py-3.5 px-4">Line Items</th>
                <th className="py-3.5 px-4">Total (ZMW)</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Manual Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 font-medium">
                    {isLoading ? "Loading platform invoices..." : "No platform invoices matching your search or filters."}
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => {
                  const { daysOverdue, isOverdue } = calculateDaysOverdue(inv.dueDate);
                  const isPaid = inv.status === "PAID";
                  const isSendingEmail = sendingEmailInvoiceId === inv.id;
                  const isCopied = copiedInvoiceId === inv.id;

                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/80 transition">
                      {/* INVOICE # & NODE NAME */}
                      <td className="py-3.5 px-4">
                        <div className="font-extrabold text-slate-900 flex items-center gap-1.5">
                          <FileText className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                          <span className="font-mono font-black">{inv.invoiceNumber}</span>
                        </div>
                        <div className="font-bold text-slate-800 mt-0.5 flex items-center gap-1">
                          <Building2 className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>{inv.recipientTenantName}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          ID: {inv.recipientTenantId}
                        </div>
                      </td>

                      {/* RECIPIENT TYPE & EMAIL */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1 mb-1">
                          <span className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase border ${
                            inv.recipientType === "Agro-Dealer"
                              ? "bg-indigo-50 text-indigo-800 border-indigo-200"
                              : inv.recipientType === "Supplier"
                              ? "bg-amber-50 text-amber-900 border-amber-200"
                              : "bg-emerald-50 text-emerald-800 border-emerald-200"
                          }`}>
                            {inv.recipientType}
                          </span>
                        </div>
                        <div className="text-slate-700 font-semibold truncate max-w-[180px]" title={inv.recipientEmail}>
                          ✉️ {inv.recipientEmail || "finance@tenant.zm"}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Issued by: {inv.issuedBy || "Super Admin"}
                        </div>
                      </td>

                      {/* DUE DATE & OVERDUE GAUGE */}
                      <td className="py-3.5 px-4 font-mono">
                        <div className="flex items-center gap-1 text-slate-700 font-bold">
                          <Calendar className="w-3 h-3 text-slate-400" />
                          <span>{inv.dueDate}</span>
                        </div>
                        {!isPaid && (
                          <div className="mt-1">
                            {isOverdue ? (
                              <span className="px-2 py-0.5 bg-rose-100 text-rose-800 rounded-md text-[9px] font-black uppercase border border-rose-200 inline-flex items-center gap-1 animate-pulse">
                                <AlertTriangle className="w-2.5 h-2.5" />
                                <span>{daysOverdue} Days Overdue</span>
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md text-[9px] font-bold">
                                Due in {Math.abs(daysOverdue)}d
                              </span>
                            )}
                          </div>
                        )}
                        {inv.lastReminderSentAt && (
                          <div className="text-[9.5px] text-indigo-600 mt-1 font-sans">
                            Last sent: {new Date(inv.lastReminderSentAt).toLocaleDateString()}
                          </div>
                        )}
                      </td>

                      {/* LINE ITEMS */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-0.5 max-w-[200px]">
                          {inv.lineItems.slice(0, 2).map((item, idx) => (
                            <div key={idx} className="text-[11px] text-slate-600 truncate flex justify-between gap-1">
                              <span>• {item.description}</span>
                            </div>
                          ))}
                          {inv.lineItems.length > 2 && (
                            <span className="text-[10px] text-indigo-600 font-bold">
                              +{inv.lineItems.length - 2} more line items...
                            </span>
                          )}
                        </div>
                      </td>

                      {/* TOTAL */}
                      <td className="py-3.5 px-4 font-mono">
                        <div className="text-sm font-black text-slate-900">
                          {currencySymbol} {inv.totalAmount.toLocaleString()}
                        </div>
                        <span className="text-[10px] text-slate-400 font-sans">
                          {inv.lineItems.length} Item(s)
                        </span>
                      </td>

                      {/* STATUS BADGE */}
                      <td className="py-3.5 px-4">
                        {isPaid ? (
                          <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-full text-[10px] font-black uppercase flex items-center gap-1 w-fit">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Paid</span>
                          </span>
                        ) : (
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase flex items-center gap-1 w-fit border ${
                            isOverdue
                              ? "bg-rose-100 text-rose-800 border-rose-200"
                              : "bg-amber-100 text-amber-800 border-amber-200"
                          }`}>
                            <Clock className="w-3 h-3" />
                            <span>{isOverdue ? "Overdue" : "Pending"}</span>
                          </span>
                        )}
                        {inv.lipilaReferenceId && (
                          <div className="text-[9px] text-slate-400 font-mono mt-1 select-all" title="Lipila Transaction ID">
                            Ref: {inv.lipilaReferenceId.slice(0, 10)}...
                          </div>
                        )}
                      </td>

                      {/* MANUAL ACTIONS */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* SEND / RESEND EMAIL & SMS NOTIFICATION */}
                          <button
                            type="button"
                            onClick={() => handleSendInvoiceEmail(inv)}
                            disabled={isSendingEmail}
                            className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 disabled:opacity-50"
                            title="Dispatch email invoice & SMS reminder to recipient"
                          >
                            <Send className={`w-3.5 h-3.5 ${isSendingEmail ? "animate-spin" : ""}`} />
                            <span>{isSendingEmail ? "Sending..." : "Send Invoice"}</span>
                          </button>

                          {/* COPY DIRECT LIPILA LINK */}
                          <button
                            type="button"
                            onClick={() => handleCopyPayLink(inv)}
                            className="p-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg transition cursor-pointer"
                            title="Copy direct Lipila pay link to clipboard"
                          >
                            {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>

                          {/* MARK AS PAID / SETTLE */}
                          {!isPaid && (
                            <button
                              type="button"
                              onClick={() => {
                                setSettlingInvoice(inv);
                                setSettleTxRef("");
                              }}
                              className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1"
                              title="Mark invoice as paid / manual settlement"
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                              <span>Settle</span>
                            </button>
                          )}

                          {/* VIEW DETAILS */}
                          <button
                            type="button"
                            onClick={() => setPreviewInvoice(inv)}
                            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                            title="Preview printable platform invoice"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4. SETTLE INVOICE MODAL */}
      {settlingInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs font-sans">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl p-6 space-y-4">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Manual Invoice Settlement</h3>
                  <p className="text-xs text-slate-500 font-medium">
                    Invoice #{settlingInvoice.invoiceNumber}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSettlingInvoice(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500 font-semibold">Recipient:</span>
                <span className="font-bold text-slate-800">{settlingInvoice.recipientTenantName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-semibold">Total Balance:</span>
                <span className="font-black text-slate-900 font-mono">{currencySymbol} {settlingInvoice.totalAmount.toLocaleString()}</span>
              </div>
            </div>

            <div className="space-y-1 text-xs">
              <label className="font-extrabold text-slate-700 block">
                Lipila Tx ID / Offline Payment Reference *
              </label>
              <input
                type="text"
                value={settleTxRef}
                onChange={(e) => setSettleTxRef(e.target.value)}
                placeholder="e.g. LIPILA-TX-984729 or MOMO-MTN-8823"
                className="w-full p-2.5 border border-slate-200 rounded-xl bg-slate-50 text-slate-800 outline-none focus:border-emerald-500 font-mono"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 text-xs font-bold">
              <button
                type="button"
                onClick={() => setSettlingInvoice(null)}
                className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteSettlement}
                disabled={isSettling}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl flex items-center gap-2 cursor-pointer font-extrabold shadow-md disabled:opacity-50"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isSettling ? "Settling..." : "Confirm Payment Reconciliation"}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. INVOICE PREVIEW & PRINTABLE MODAL */}
      {previewInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs font-sans">
          <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl p-6 space-y-6 max-h-[92vh] overflow-y-auto">
            {/* Header */}
            <div className="flex justify-between items-start border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-indigo-600 text-white rounded-xl">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-slate-900">Mabala Agritech Platform Enterprise</h3>
                    <p className="text-xs text-slate-500 font-mono">Lusaka, Zambia &bull; TPIN: 1002938475</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewInvoice(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Recipient & Metadata Grid */}
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-slate-50 rounded-2xl space-y-1">
                <span className="text-[10px] font-mono text-slate-400 font-bold uppercase block">Billed To Tenant</span>
                <div className="font-black text-slate-900 text-sm">{previewInvoice.recipientTenantName}</div>
                <div className="text-slate-600">{previewInvoice.recipientEmail || "finance@tenant.zm"}</div>
                <div className="text-slate-500 font-mono">Node ID: {previewInvoice.recipientTenantId}</div>
                <span className="inline-block mt-1 px-2 py-0.5 bg-indigo-50 text-indigo-700 text-[10px] font-bold rounded">
                  {previewInvoice.recipientType}
                </span>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl space-y-1 font-mono">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Invoice Details</span>
                <div className="text-slate-700"><strong>Invoice #:</strong> {previewInvoice.invoiceNumber}</div>
                <div className="text-slate-700"><strong>Issued:</strong> {new Date(previewInvoice.issuedAt).toLocaleDateString()}</div>
                <div className="text-slate-700"><strong>Due Date:</strong> {previewInvoice.dueDate}</div>
                <div className="text-slate-700">
                  <strong>Status:</strong>{" "}
                  <span className={previewInvoice.status === "PAID" ? "text-emerald-600 font-black" : "text-amber-600 font-black"}>
                    {previewInvoice.status}
                  </span>
                </div>
              </div>
            </div>

            {/* Line Items Table */}
            <div className="border border-slate-200 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 font-extrabold border-b border-slate-200">
                    <th className="py-2.5 px-4">Item Description</th>
                    <th className="py-2.5 px-4 text-right font-mono">Amount ({currencySymbol})</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {previewInvoice.lineItems.map((item, idx) => (
                    <tr key={idx}>
                      <td className="py-3 px-4 font-semibold text-slate-800">{item.description}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                        {currencySymbol} {item.amount.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-indigo-50/50 font-black text-slate-900 border-t border-slate-200">
                    <td className="py-3 px-4 text-sm font-sans">Total Amount Due</td>
                    <td className="py-3 px-4 text-right text-base font-mono text-indigo-900">
                      {currencySymbol} {previewInvoice.totalAmount.toLocaleString()}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* Notes */}
            {previewInvoice.notes && (
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
                <span className="text-[10px] font-mono text-slate-400 font-bold uppercase block mb-0.5">Notes & Terms</span>
                <p className="text-slate-700 font-medium">{previewInvoice.notes}</p>
              </div>
            )}

            {/* Direct Pay Link Box */}
            <div className="p-4 bg-indigo-950 text-indigo-100 rounded-2xl space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="font-bold text-indigo-300 flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-emerald-400" />
                  <span>Direct Lipila Mobile Money Payment Link</span>
                </span>
                <span className="text-[10px] font-mono text-emerald-300 font-bold">NO LOGIN REQUIRED</span>
              </div>
              <p className="text-[11px] text-indigo-200">
                Share this link directly with the client for 1-click Mobile Money (MTN / Airtel / Zamtel) settlement:
              </p>
              <div className="flex items-center gap-2 bg-indigo-900/60 p-2 rounded-xl border border-indigo-800 font-mono text-[11px]">
                <span className="truncate flex-1 select-all">
                  {generateDirectPayLink(previewInvoice.id, previewInvoice.recipientEmail).payLinkUrl}
                </span>
                <button
                  type="button"
                  onClick={() => handleCopyPayLink(previewInvoice)}
                  className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-[10px] font-bold cursor-pointer shrink-0"
                >
                  {copiedInvoiceId === previewInvoice.id ? "Copied!" : "Copy Link"}
                </button>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex justify-between items-center pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => handleSendInvoiceEmail(previewInvoice)}
                disabled={sendingEmailInvoiceId === previewInvoice.id}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{sendingEmailInvoiceId === previewInvoice.id ? "Sending Email..." : "Send Email with Pay Link"}</span>
              </button>

              <button
                type="button"
                onClick={() => setPreviewInvoice(null)}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SuperAdminInvoicesTab;

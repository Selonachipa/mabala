import React, { useState, useMemo, useEffect } from "react";
import { safeFormatError } from "../../utils/errorUtils";
import { safeLocalStorage as localStorage, safeParseJSON } from "../../utils/safeStorage";
import {
  MessageSquare,
  Search,
  Users,
  ShieldCheck,
  Plus,
  Minus,
  Check,
  Send,
  Sparkles,
  Zap,
  Tag,
  Radio,
  FileText,
  PhoneCall,
  Clock,
  ExternalLink
} from "lucide-react";
import { UserRecord } from "./SuperAdminUserDirectoryTab";
import { doc, getDoc, updateDoc, collection, addDoc } from "firebase/firestore";
import { db } from "../../firebase";

export interface SuperAdminSmsAllocationTabProps {
  allUsers: UserRecord[];
  onAllocationComplete?: (updated: {
    uid: string;
    smsCredits: number;
    smsSenderId?: string;
  }) => void;
  currentUserEmail?: string;
  currencySymbol?: string;
}

export interface SmsAllocationLog {
  id: string;
  timestamp: string;
  targetEmail: string;
  targetUid: string;
  targetName?: string;
  actionType: "GRANT" | "DEDUCT" | "SENDER_ID_UPDATE" | "RATE_UPDATE";
  amount: number;
  previousSmsBalance: number;
  newSmsBalance: number;
  senderId?: string;
  ratePerPart?: number;
  reason: string;
  authorizedBy: string;
}

const PRESET_SMS_AMOUNTS = [50, 100, 250, 500, 1000, 2500, 5000, 10000];

export const SuperAdminSmsAllocationTab: React.FC<SuperAdminSmsAllocationTabProps> = ({
  allUsers = [],
  onAllocationComplete,
  currentUserEmail = "superadmin@mabala.app",
  currencySymbol = "ZK"
}) => {
  const [selectedUserUid, setSelectedUserUid] = useState<string>("");
  const [searchFilter, setSearchFilter] = useState("");
  const [operationType, setOperationType] = useState<"GRANT" | "DEDUCT" | "CONFIG">("GRANT");
  const [smsAmount, setSmsAmount] = useState<number>(250);
  const [senderIdInput, setSenderIdInput] = useState("MABALA");
  const [unitRateInput, setUnitRateInput] = useState<number>(0.9);
  const [allowBroadcasts, setAllowBroadcasts] = useState(true);
  const [reason, setReason] = useState("Direct SMS Pack Promotional Allocation");
  const [notes, setNotes] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [smsAuditLogs, setSmsAuditLogs] = useState<SmsAllocationLog[]>([]);

  // Load audit history
  useEffect(() => {
    try {
      const logs = safeParseJSON<SmsAllocationLog[]>(localStorage.getItem("mabala_sms_allocation_audit_logs") || "[]", []);
      setSmsAuditLogs(Array.isArray(logs) ? logs : []);
    } catch {
      setSmsAuditLogs([]);
    }
  }, []);

  // Filter user options
  const userOptions = useMemo(() => {
    return allUsers.filter((u) => {
      if (!u) return false;
      const q = searchFilter.toLowerCase();
      const email = (u.email || u.tenantEmail || "").toLowerCase();
      const name = (u.displayName || u.name || u.farmName || "").toLowerCase();
      const role = (u.role || u.accountType || "").toLowerCase();
      return email.includes(q) || name.includes(q) || role.includes(q);
    });
  }, [allUsers, searchFilter]);

  // Selected user
  const selectedUser = useMemo(() => {
    return allUsers.find((u) => (u.uid || u.tenantUid || u.id) === selectedUserUid) || null;
  }, [allUsers, selectedUserUid]);

  useEffect(() => {
    if (!selectedUserUid && allUsers.length > 0) {
      setSelectedUserUid(allUsers[0].uid || allUsers[0].tenantUid || allUsers[0].id || "");
    }
  }, [allUsers, selectedUserUid]);

  // Sync sender id input when user changes
  useEffect(() => {
    if (selectedUser) {
      const farmNameClean = (selectedUser.farm?.name || selectedUser.farmName || "MABALA").replace(/[^a-zA-Z0-9]/g, "").slice(0, 11).toUpperCase();
      setSenderIdInput(selectedUser.smsSenderId || farmNameClean || "MABALA");
    }
  }, [selectedUser]);

  const handleApplySmsAllocation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) {
      setStatusMessage({ type: "error", text: "Please select a target user / farm node." });
      return;
    }
    if (!reason.trim()) {
      setStatusMessage({ type: "error", text: "Audit justification reason is required." });
      return;
    }

    setIsProcessing(true);
    setStatusMessage(null);

    const uid = selectedUser.uid || selectedUser.tenantUid || selectedUser.id || "";
    const email = selectedUser.email || selectedUser.tenantEmail || "";
    const currentSms = Number(selectedUser.smsCredits ?? 0);

    let finalSms = currentSms;
    let finalSenderId = selectedUser.smsSenderId || senderIdInput;

    if (operationType === "GRANT") {
      finalSms = currentSms + Number(smsAmount);
    } else if (operationType === "DEDUCT") {
      finalSms = Math.max(0, currentSms - Number(smsAmount));
    } else if (operationType === "CONFIG") {
      finalSenderId = senderIdInput.trim().toUpperCase().slice(0, 11);
    }

    try {
      // 1. Update in Firestore if available
      try {
        if (db && uid) {
          const userDocRef = doc(db, "users", uid);
          await updateDoc(userDocRef, {
            smsCredits: finalSms,
            smsSenderId: finalSenderId,
            smsRatePerPart: unitRateInput,
            allowSmsBroadcasts: allowBroadcasts,
            lastSmsTopUp: new Date().toISOString(),
            lastSmsTopUpAmount: smsAmount,
            lastSmsTopUpBy: currentUserEmail
          });

          // Add to audit log
          const auditRef = collection(db, "sms_allocation_audit_logs");
          await addDoc(auditRef, {
            timestamp: new Date().toISOString(),
            targetUid: uid,
            targetEmail: email,
            targetName: selectedUser.name || selectedUser.displayName || "",
            actionType: operationType === "GRANT" ? "GRANT" : operationType === "DEDUCT" ? "DEDUCT" : "SENDER_ID_UPDATE",
            amount: smsAmount,
            previousSmsBalance: currentSms,
            newSmsBalance: finalSms,
            senderId: finalSenderId,
            ratePerPart: unitRateInput,
            reason: `${reason}${notes ? ` | Notes: ${notes}` : ""}`,
            authorizedBy: currentUserEmail
          });
        }
      } catch (fbErr) {
        console.warn("Firestore SMS update notice, fallback to local storage:", fbErr);
      }

      // 2. Update local storage registration cache
      try {
        const storedUsers = safeParseJSON<any[]>(localStorage.getItem("mabala_registered_users") || "[]", []);
        const updatedUsers = storedUsers.map((u) => {
          if (u.uid === uid || u.email?.toLowerCase() === email.toLowerCase()) {
            return {
              ...u,
              smsCredits: finalSms,
              smsSenderId: finalSenderId,
              smsRatePerPart: unitRateInput,
              allowSmsBroadcasts: allowBroadcasts
            };
          }
          return u;
        });
        localStorage.setItem("mabala_registered_users", JSON.stringify(updatedUsers));
      } catch (_) {}

      // 3. Log to local audit trail
      const newLog: SmsAllocationLog = {
        id: `sms-alloc-${Date.now()}`,
        timestamp: new Date().toISOString(),
        targetUid: uid,
        targetEmail: email,
        targetName: selectedUser.name || selectedUser.displayName || "",
        actionType: operationType === "GRANT" ? "GRANT" : operationType === "DEDUCT" ? "DEDUCT" : "SENDER_ID_UPDATE",
        amount: smsAmount,
        previousSmsBalance: currentSms,
        newSmsBalance: finalSms,
        senderId: finalSenderId,
        ratePerPart: unitRateInput,
        reason: `${reason}${notes ? ` | Notes: ${notes}` : ""}`,
        authorizedBy: currentUserEmail
      };

      const updatedHistory = [newLog, ...smsAuditLogs];
      setSmsAuditLogs(updatedHistory);
      localStorage.setItem("mabala_sms_allocation_audit_logs", JSON.stringify(updatedHistory.slice(0, 100)));

      // 4. Update parent state
      if (onAllocationComplete) {
        onAllocationComplete({
          uid,
          smsCredits: finalSms,
          smsSenderId: finalSenderId
        });
      }

      setStatusMessage({
        type: "success",
        text: `SMS allocation updated for ${email}. New SMS Quota: ${finalSms.toLocaleString()} SMS | Sender ID: ${finalSenderId}`
      });

      setNotes("");
    } catch (err: any) {
      setStatusMessage({
        type: "error",
        text: `SMS allocation failed: ${safeFormatError(err)}`
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6 font-sans animate-fade-in" id="super-admin-sms-allocation-tab">
      {/* HEADER CARD */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 bg-blue-50 text-blue-900 text-[10px] font-black uppercase rounded-md tracking-wider border border-blue-200 font-mono">
              Telco SMS Gateway Control
            </span>
            <span className="text-xs text-slate-400 font-mono">sms_allocations_v2</span>
          </div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight mt-1 flex items-center gap-2">
            <span>📱 SMS Manual Allocation Module</span>
          </h2>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            Manually allocate live SMS bundles, configure custom Sender IDs (e.g. Mabala, Farm Name), and set per-part delivery rates for farmers and dealers.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono font-bold bg-blue-50/80 border border-blue-200 px-3.5 py-2 rounded-2xl text-blue-900">
          <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
          <span>Airtel / MTN / Zamtel Gateway Active</span>
        </div>
      </div>

      {statusMessage && (
        <div
          className={`p-4 rounded-2xl border text-xs font-bold flex items-center justify-between gap-3 ${
            statusMessage.type === "success"
              ? "bg-emerald-50 text-emerald-900 border-emerald-200"
              : "bg-rose-50 text-rose-900 border-rose-200"
          }`}
        >
          <span>{statusMessage.text}</span>
          <button
            type="button"
            onClick={() => setStatusMessage(null)}
            className="text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* CONSOLE GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: TARGET SELECTION & LIVE TELEMETRY (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-2">
              <Users className="w-4 h-4 text-slate-400" />
              <span>1. Target Recipient / Farm Node</span>
            </h3>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Search user by name, email, or role..."
                className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:bg-white focus:border-blue-500"
              />
            </div>

            <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 border border-slate-100 rounded-2xl pr-1 space-y-1">
              {userOptions.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-400">No users found.</div>
              ) : (
                userOptions.map((u) => {
                  const uid = u.uid || u.tenantUid || u.id || "";
                  const isSelected = selectedUserUid === uid;
                  const name = u.displayName || u.name || u.farmName || u.email?.split("@")[0];
                  const email = u.email || u.tenantEmail || "";
                  const smsCredits = u.smsCredits ?? 0;
                  const role = u.role || u.accountType || "Farmer";

                  return (
                    <div
                      key={uid}
                      onClick={() => setSelectedUserUid(uid)}
                      className={`p-2.5 rounded-xl transition cursor-pointer flex items-center justify-between gap-2 text-xs ${
                        isSelected
                          ? "bg-blue-50/90 text-blue-950 font-extrabold border border-blue-200"
                          : "hover:bg-slate-50 text-slate-700 font-medium"
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="truncate font-bold text-slate-900">{name}</div>
                        <div className="text-[10px] text-slate-400 font-mono truncate">{email}</div>
                        <span className="inline-block mt-0.5 px-1.5 py-0.2 rounded text-[9px] font-black uppercase bg-slate-100 text-slate-600">
                          {role}
                        </span>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50/80 px-2 py-0.5 rounded border border-blue-200">
                          {smsCredits.toLocaleString()} SMS
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* ACTIVE TARGET TELEMETRY CARD */}
          {selectedUser && (
            <div className="bg-gradient-to-br from-slate-900 to-blue-950 text-white rounded-3xl p-5 space-y-4 shadow-md">
              <div className="flex items-center justify-between border-b border-slate-700/60 pb-3">
                <span className="text-[10px] font-mono font-bold uppercase text-blue-300 tracking-wider">
                  SMS Gateway Status
                </span>
                <span className="text-[10px] bg-blue-900/60 border border-blue-700/50 px-2 py-0.5 rounded font-mono text-blue-200">
                  ID: {(selectedUser.uid || selectedUser.id || "").slice(0, 10)}...
                </span>
              </div>

              <div className="space-y-1">
                <div className="text-base font-extrabold">{selectedUser.name || selectedUser.displayName || "User"}</div>
                <div className="text-xs text-blue-200 font-mono">{selectedUser.email}</div>
                <div className="text-[11px] text-slate-300">Phone: {selectedUser.phone || selectedUser.phoneNumber || "No Mobile Registered"}</div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="bg-slate-800/80 border border-slate-700 p-3 rounded-xl space-y-0.5">
                  <span className="text-[9px] uppercase font-bold text-slate-400 block">Available SMS Quota</span>
                  <div className="text-lg font-black text-blue-300 font-mono">
                    {(selectedUser.smsCredits ?? 0).toLocaleString()} <span className="text-xs font-normal">SMS</span>
                  </div>
                </div>
                <div className="bg-slate-800/80 border border-slate-700 p-3 rounded-xl space-y-0.5">
                  <span className="text-[9px] uppercase font-bold text-slate-400 block">Sender ID</span>
                  <div className="text-xs font-mono font-black text-amber-300 truncate">
                    {selectedUser.smsSenderId || "MABALA"}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* RIGHT COLUMN: SMS ALLOCATION CONTROLLER (7 cols) */}
        <div className="lg:col-span-7">
          <form onSubmit={handleApplySmsAllocation} className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-5">
            <div className="border-b border-slate-100 pb-4 flex items-center justify-between">
              <h3 className="text-sm font-black uppercase text-slate-900 flex items-center gap-2">
                <Send className="w-4 h-4 text-blue-600" />
                <span>2. Configure SMS Allocation & Settings</span>
              </h3>
              <span className="text-[11px] text-slate-400 font-mono">Target: {selectedUser?.email || "None"}</span>
            </div>

            {/* ACTION MODE */}
            <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 rounded-2xl">
              <button
                type="button"
                onClick={() => setOperationType("GRANT")}
                className={`py-2 text-xs font-extrabold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  operationType === "GRANT"
                    ? "bg-white text-slate-900 shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                <Plus className="w-3.5 h-3.5 text-emerald-600" />
                <span>Grant SMS</span>
              </button>
              <button
                type="button"
                onClick={() => setOperationType("DEDUCT")}
                className={`py-2 text-xs font-extrabold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  operationType === "DEDUCT"
                    ? "bg-white text-slate-900 shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                <Minus className="w-3.5 h-3.5 text-rose-600" />
                <span>Debit SMS</span>
              </button>
              <button
                type="button"
                onClick={() => setOperationType("CONFIG")}
                className={`py-2 text-xs font-extrabold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  operationType === "CONFIG"
                    ? "bg-white text-slate-900 shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                <Tag className="w-3.5 h-3.5 text-blue-600" />
                <span>Sender ID / Rates</span>
              </button>
            </div>

            {/* AMOUNT CONTROLS */}
            {operationType !== "CONFIG" && (
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider block">
                  {operationType === "GRANT" ? "SMS Messages to Grant" : "SMS Messages to Debit"}
                </label>

                <div className="flex items-center gap-1.5 flex-wrap">
                  {PRESET_SMS_AMOUNTS.map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setSmsAmount(amt)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition cursor-pointer border ${
                        smsAmount === amt
                          ? "bg-blue-600 text-white border-blue-600 shadow-xs"
                          : "bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200"
                      }`}
                    >
                      +{amt.toLocaleString()} SMS
                    </button>
                  ))}
                </div>

                <div className="relative">
                  <MessageSquare className="w-4 h-4 text-blue-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    min="1"
                    value={smsAmount}
                    onChange={(e) => setSmsAmount(Math.max(1, Number(e.target.value)))}
                    className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-bold text-slate-900 outline-none focus:bg-white focus:border-blue-500"
                    placeholder="Enter custom SMS count..."
                    required
                  />
                </div>
              </div>
            )}

            {/* CONFIG SENDER ID AND RATES */}
            {operationType === "CONFIG" && (
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider block mb-1">
                    Custom Alphanumeric Sender ID (Max 11 characters)
                  </label>
                  <input
                    type="text"
                    maxLength={11}
                    value={senderIdInput}
                    onChange={(e) => setSenderIdInput(e.target.value.replace(/[^a-zA-Z0-9]/g, "").toUpperCase())}
                    placeholder="e.g. MABALA, AGRIHUB"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 uppercase tracking-widest outline-none focus:bg-white focus:border-blue-500"
                    required
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Displays on recipient handsets across Airtel, MTN, and Zamtel networks.
                  </p>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider block mb-1">
                    SMS Tariff Rate ({currencySymbol} / Part)
                  </label>
                  <select
                    value={unitRateInput}
                    onChange={(e) => setUnitRateInput(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none"
                  >
                    <option value="0.90">Standard Outgrower Tariff (0.90 ZK/SMS)</option>
                    <option value="0.50">Discounted Partner Tariff (0.50 ZK/SMS)</option>
                    <option value="0.00">Zero-Rated Platform Subsidized (0.00 ZK/SMS)</option>
                  </select>
                </div>

                <label className="flex items-center gap-2 pt-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allowBroadcasts}
                    onChange={(e) => setAllowBroadcasts(e.target.checked)}
                    className="rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-xs font-semibold text-slate-700">
                    Enable High-Volume Bulk SMS Broadcast Privileges (Outgrowers & Farmer Coops)
                  </span>
                </label>
              </div>
            )}

            {/* JUSTIFICATION */}
            <div className="space-y-3">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider block mb-1">
                  Audit Justification Reason <span className="text-rose-500">*</span>
                </label>
                <select
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none"
                  required
                >
                  <option value="Direct SMS Pack Promotional Allocation">Direct SMS Pack Promotional Allocation</option>
                  <option value="Outgrower Broadcast Campaign Allotment">Outgrower Broadcast Campaign Allotment</option>
                  <option value="Weather Alert Broadcast Grant">Weather Alert Broadcast Grant</option>
                  <option value="Cooperative Agronomy Outreach Grant">Cooperative Agronomy Outreach Grant</option>
                  <option value="Billing Compensation for Failed Deliveries">Billing Compensation for Failed Deliveries</option>
                  <option value="Telco Sender ID Registration Clearance">Telco Sender ID Registration Clearance</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider block mb-1">
                  Optional Audit Notes
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Approved for Eastern Province harvest mobilization..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 outline-none focus:bg-white focus:border-blue-500"
                />
              </div>
            </div>

            {/* SUBMIT BUTTON */}
            <button
              type="submit"
              disabled={isProcessing || !selectedUser}
              className="w-full py-3 bg-blue-900 hover:bg-blue-950 text-white font-extrabold text-xs rounded-2xl transition cursor-pointer flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
            >
              <Zap className="w-4 h-4 text-blue-200" />
              <span>{isProcessing ? "Processing SMS Allocation..." : "Execute Manual SMS Allocation"}</span>
            </button>
          </form>
        </div>
      </div>

      {/* SMS ALLOCATION LEDGER */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-black uppercase text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-slate-400" />
              <span>Super Admin SMS Allocation & Delivery Ledger</span>
            </h3>
            <p className="text-xs text-slate-400 font-medium">
              Permanent immutable transaction log of all manual SMS allocations and rate adjustments.
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
            {smsAuditLogs.length} Entries Logged
          </span>
        </div>

        <div className="overflow-x-auto border border-slate-100 rounded-2xl">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50/80 text-slate-500 font-extrabold border-b border-slate-200 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Date & Time</th>
                <th className="py-3 px-4">Target User</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">SMS Delta</th>
                <th className="py-3 px-4">New SMS Balance</th>
                <th className="py-3 px-4">Sender ID</th>
                <th className="py-3 px-4">Authorized By</th>
                <th className="py-3 px-4">Justification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
              {smsAuditLogs.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400 font-sans">
                    No SMS allocation logs recorded yet.
                  </td>
                </tr>
              ) : (
                smsAuditLogs.slice(0, 15).map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-2.5 px-4 text-slate-500">{new Date(log.timestamp).toLocaleString()}</td>
                    <td className="py-2.5 px-4 font-bold text-slate-800 font-sans">{log.targetEmail}</td>
                    <td className="py-2.5 px-4">
                      <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                        log.actionType === "GRANT" ? "bg-emerald-50 text-emerald-800 border border-emerald-200" :
                        log.actionType === "DEDUCT" ? "bg-rose-50 text-rose-800 border border-rose-200" :
                        "bg-blue-50 text-blue-800 border border-blue-200"
                      }`}>
                        {log.actionType}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 font-bold text-slate-900">
                      {log.actionType === "GRANT" ? `+${log.amount}` : log.actionType === "DEDUCT" ? `-${log.amount}` : "CONFIG"}
                    </td>
                    <td className="py-2.5 px-4 text-blue-700 font-bold">{log.newSmsBalance?.toLocaleString()} SMS</td>
                    <td className="py-2.5 px-4 text-amber-700 font-bold">{log.senderId || "MABALA"}</td>
                    <td className="py-2.5 px-4 text-slate-500 font-sans">{log.authorizedBy}</td>
                    <td className="py-2.5 px-4 text-slate-600 font-sans max-w-xs truncate">{log.reason}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SuperAdminSmsAllocationTab;

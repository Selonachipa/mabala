import React, { useState } from "react";
import {
  Store,
  Plus,
  Search,
  Filter,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Edit2,
  Trash2,
  Phone,
  Mail,
  MapPin,
  Sparkles,
  RefreshCw,
  Shield,
  CreditCard
} from "lucide-react";

interface SuperAdminVendorsTabProps {
  vendors: any[];
  setVendors: React.Dispatch<React.SetStateAction<any[]>>;
  products?: any[];
  currentRole: string;
}

export function SuperAdminVendorsTab({
  vendors,
  setVendors,
  products = [],
  currentRole
}: SuperAdminVendorsTabProps) {
  const [showProvisionVendorModal, setShowProvisionVendorModal] = useState<boolean>(false);
  const [newVendorName, setNewVendorName] = useState<string>("");
  const [newVendorCategory, setNewVendorCategory] = useState<string>("Seeds & Agronomy");
  const [newVendorLocation, setNewVendorLocation] = useState<string>("Lusaka West Depot");
  const [newVendorDistance, setNewVendorDistance] = useState<number>(15);
  const [newVendorContactName, setNewVendorContactName] = useState<string>("");
  const [newVendorEmail, setNewVendorEmail] = useState<string>("");
  const [newVendorPhone, setNewVendorPhone] = useState<string>("");
  const [newVendorPackage, setNewVendorPackage] = useState<string>("Premium Seller (10% Platform Fee)");
  const [newVendorCredits, setNewVendorCredits] = useState<number>(300);
  const [vendorSearchQuery, setVendorSearchQuery] = useState<string>("");
  const [vendorCategoryFilter, setVendorCategoryFilter] = useState<string>("ALL");
  const [editingVendor, setEditingVendor] = useState<any | null>(null);

  return (
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 animate-fade-in text-slate-900">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-5">
                    <div>
                      <div className="flex items-center gap-2">
                        <Store className="w-5 h-5 text-emerald-600" />
                        <h3 className="text-lg font-black text-slate-800 tracking-tight">Marketplace Vendor Registry & Provisioning</h3>
                      </div>
                      <p className="text-xs text-slate-500 font-medium font-sans">
                        Manually provision agro-dealers, seed companies, and vet suppliers. Self-registration is disabled; all vendors must be onboarded here.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowProvisionVendorModal(true)}
                      className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-black rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Provision New Vendor</span>
                    </button>
                  </div>

                  {/* Vendor Overview Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
                    <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl space-y-1">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Vendors</span>
                      <p className="text-2xl font-black text-slate-800">{vendors.length}</p>
                    </div>
                    <div className="p-4 bg-emerald-50/60 border border-emerald-200/60 rounded-xl space-y-1">
                      <span className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider">Active Storefronts</span>
                      <p className="text-2xl font-black text-emerald-700">{vendors.filter(v => (v.status || "ACTIVE") === "ACTIVE").length}</p>
                    </div>
                    <div className="p-4 bg-rose-50/60 border border-rose-200/60 rounded-xl space-y-1">
                      <span className="text-[10px] text-rose-700 font-bold uppercase tracking-wider">Suspended / Inactive</span>
                      <p className="text-2xl font-black text-rose-700">{vendors.filter(v => v.status === "SUSPENDED" || v.status === "EXPIRED").length}</p>
                    </div>
                    <div className="p-4 bg-indigo-50/60 border border-indigo-200/60 rounded-xl space-y-1">
                      <span className="text-[10px] text-indigo-700 font-bold uppercase tracking-wider">Catalogue Items Listed</span>
                      <p className="text-2xl font-black text-indigo-700">{products.length}</p>
                    </div>
                  </div>

                  {/* Search and Filters */}
                  <div className="flex flex-col sm:flex-row justify-between items-center gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200/80">
                    <div className="relative w-full sm:w-72">
                      <input
                        type="text"
                        placeholder="Search vendor name, email, location..."
                        value={vendorSearchQuery}
                        onChange={e => setVendorSearchQuery(e.target.value)}
                        className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg outline-none focus:border-emerald-500 font-medium"
                      />
                    </div>
                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <span className="text-[10px] text-slate-400 font-extrabold uppercase">Category:</span>
                      <select
                        value={vendorCategoryFilter}
                        onChange={e => setVendorCategoryFilter(e.target.value)}
                        className="text-xs p-2 bg-white border border-slate-200 rounded-lg font-bold text-slate-700 cursor-pointer"
                      >
                        <option value="ALL">All Categories</option>
                        <option value="Seeds & Agronomy">Seeds & Agronomy</option>
                        <option value="Veterinary & Health">Veterinary & Health</option>
                        <option value="Equipment & Tech">Equipment & Tech</option>
                        <option value="Feeds & Formulations">Feeds & Formulations</option>
                      </select>
                    </div>
                  </div>

                  {/* Vendors Table */}
                  <div className="overflow-x-auto border border-slate-200 rounded-xl">
                    <table className="w-full text-left text-xs bg-white text-slate-800">
                      <thead className="bg-slate-50 font-black text-[9px] text-slate-400 uppercase tracking-wider border-b border-slate-200">
                        <tr>
                          <th className="p-3">Store Name & Category</th>
                          <th className="p-3">Location & Distance</th>
                          <th className="p-3">Admin Contact</th>
                          <th className="p-3">Plan Package</th>
                          <th className="p-3 text-center">Credit Balance</th>
                          <th className="p-3 text-center">Status</th>
                          <th className="p-3 text-right">Admin Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-semibold text-xs">
                        {vendors
                          .filter(v => {
                            const matchesSearch =
                              (v.name || "").toLowerCase().includes(vendorSearchQuery.toLowerCase()) ||
                              (v.email || "").toLowerCase().includes(vendorSearchQuery.toLowerCase()) ||
                              (v.location || "").toLowerCase().includes(vendorSearchQuery.toLowerCase());
                            const matchesCategory = vendorCategoryFilter === "ALL" || v.category === vendorCategoryFilter;
                            return matchesSearch && matchesCategory;
                          })
                          .map(v => (
                            <tr key={v.id} className="hover:bg-slate-50/80 transition-colors">
                              <td className="p-3">
                                <div className="font-bold text-slate-900">{v.name}</div>
                                <span className="text-[9.5px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 mt-0.5 inline-block">
                                  {v.category || "General Agro-Dealer"}
                                </span>
                              </td>
                              <td className="p-3">
                                <div className="font-medium text-slate-700">{v.location || "Lusaka, Zambia"}</div>
                                <div className="text-[10px] text-slate-400 font-mono">{v.distanceKm || 15} km from central hub</div>
                              </td>
                              <td className="p-3">
                                <div className="font-bold text-slate-800">{v.contactPerson || v.ownerName || "Manager"}</div>
                                <div className="text-[10px] text-slate-500 font-mono">{v.email || v.phone || "No email"}</div>
                              </td>
                              <td className="p-3">
                                <span className="px-2 py-0.5 text-[9.5px] font-extrabold rounded bg-emerald-50 text-emerald-800 border border-emerald-200 uppercase">
                                  {v.package || "Premium Seller"}
                                </span>
                              </td>
                              <td className="p-3 text-center font-mono font-black text-slate-800">
                                {v.credits ?? 300} Credits
                              </td>
                              <td className="p-3 text-center">
                                <span
                                  className={`px-2.5 py-1 text-[9.5px] font-black rounded-full uppercase tracking-wider ${
                                    (v.status || "ACTIVE") === "ACTIVE"
                                      ? "bg-emerald-100 text-emerald-800 border border-emerald-300"
                                      : "bg-rose-100 text-rose-800 border border-rose-300"
                                  }`}
                                >
                                  {v.status || "ACTIVE"}
                                </span>
                              </td>
                              <td className="p-3 text-right">
                                <div className="flex items-center justify-end gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const amountStr = prompt(`Add platform credits for ${v.name}:`, "100");
                                      if (amountStr) {
                                        const amount = parseInt(amountStr, 10);
                                        if (!isNaN(amount) && amount > 0) {
                                          setVendors(prev =>
                                            prev.map(item => (item.id === v.id ? { ...item, credits: (item.credits || 0) + amount } : item))
                                          );
                                          alert(`Added ${amount} credits to ${v.name}.`);
                                        }
                                      }
                                    }}
                                    className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-extrabold text-[10px] rounded border border-indigo-200 cursor-pointer"
                                    title="Top-up credits"
                                  >
                                    + Credits
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newStatus = (v.status || "ACTIVE") === "ACTIVE" ? "SUSPENDED" : "ACTIVE";
                                      setVendors(prev => prev.map(item => (item.id === v.id ? { ...item, status: newStatus } : item)));
                                    }}
                                    className={`px-2 py-1 font-extrabold text-[10px] rounded border cursor-pointer ${
                                      (v.status || "ACTIVE") === "ACTIVE"
                                        ? "bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200"
                                        : "bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200"
                                    }`}
                                  >
                                    {(v.status || "ACTIVE") === "ACTIVE" ? "Suspend" : "Activate"}
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        {vendors.length === 0 && (
                          <tr>
                            <td colSpan={7} className="p-8 text-center text-slate-400 italic">
                              No vendors onboarded yet. Click "Provision New Vendor" above to manually register an agro-dealer.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* MANUAL PROVISIONING VENDOR MODAL */}
                  {showProvisionVendorModal && (
                    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-[99999] flex items-center justify-center p-4">
                      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full p-6 space-y-5 text-left font-sans animate-fade-in">
                        <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                          <div>
                            <span className="text-[9px] font-extrabold uppercase bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                              Super Admin Authorization
                            </span>
                            <h3 className="text-base font-black text-slate-900 mt-1">Provision New Marketplace Vendor Store</h3>
                          </div>
                          <button
                            type="button"
                            onClick={() => setShowProvisionVendorModal(false)}
                            className="text-slate-400 hover:text-slate-600 font-bold p-1 cursor-pointer"
                          >
                            ✕
                          </button>
                        </div>

                        <form
                          onSubmit={e => {
                            e.preventDefault();
                            if (!newVendorName.trim()) {
                              alert("Please enter a vendor store name.");
                              return;
                            }
                            const tempPass = `Mabala@${Math.floor(1000 + Math.random() * 9000)}`;
                            const vendorObj = {
                              id: `v-reg-${Date.now()}`,
                              name: newVendorName.trim(),
                              category: newVendorCategory,
                              location: newVendorLocation,
                              distanceKm: newVendorDistance,
                              contactPerson: newVendorContactName || "Store Manager",
                              email: newVendorEmail || `${newVendorName.toLowerCase().replace(/\s+/g, '')}@mabalamarket.zm`,
                              phone: newVendorPhone || "+260 977 000000",
                              package: newVendorPackage,
                              credits: newVendorCredits,
                              status: "ACTIVE",
                              tempPassword: tempPass,
                              createdAt: new Date().toISOString()
                            };
                            const updatedVendors = [vendorObj, ...vendors];
                            setVendors(updatedVendors);
                            localStorage.setItem("mabala_marketplace_vendors", JSON.stringify(updatedVendors));
                            setShowProvisionVendorModal(false);
                            alert(`Vendor "${newVendorName}" successfully provisioned!\n\nTemporary Login Credentials:\nUsername/Email: ${vendorObj.email}\nTemp Password: ${tempPass}\nInitial Credits: ${newVendorCredits}`);
                            setNewVendorName("");
                            setNewVendorContactName("");
                            setNewVendorEmail("");
                            setNewVendorPhone("");
                          }}
                          className="space-y-4 text-xs font-semibold text-slate-700"
                        >
                          <div>
                            <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Store / Business Name *</label>
                            <input
                              type="text"
                              required
                              placeholder="e.g. Lusaka Agri-Input Distributors Ltd"
                              value={newVendorName}
                              onChange={e => setNewVendorName(e.target.value)}
                              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-emerald-500 font-bold"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Primary Category</label>
                              <select
                                value={newVendorCategory}
                                onChange={e => setNewVendorCategory(e.target.value)}
                                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-800"
                              >
                                <option value="Seeds & Agronomy">Seeds & Agronomy</option>
                                <option value="Veterinary & Health">Veterinary & Health</option>
                                <option value="Equipment & Tech">Equipment & Tech</option>
                                <option value="Feeds & Formulations">Feeds & Formulations</option>
                              </select>
                            </div>
                            <div>
                              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Subscription Plan</label>
                              <select
                                value={newVendorPackage}
                                onChange={e => setNewVendorPackage(e.target.value)}
                                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-800"
                              >
                                <option value="Standard Merchant">Standard Merchant</option>
                                <option value="Premium Seller">Premium Seller</option>
                                <option value="Enterprise Merchant">Enterprise Merchant</option>
                              </select>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Physical Location</label>
                              <input
                                type="text"
                                placeholder="e.g. Mumbwa Road, Lusaka"
                                value={newVendorLocation}
                                onChange={e => setNewVendorLocation(e.target.value)}
                                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-emerald-500 font-medium"
                              />
                            </div>
                            <div>
                              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Distance (km)</label>
                              <input
                                type="number"
                                value={newVendorDistance}
                                onChange={e => setNewVendorDistance(Number(e.target.value))}
                                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-emerald-500 font-mono font-bold"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Contact Person</label>
                              <input
                                type="text"
                                placeholder="e.g. Ba Mulenga Phiri"
                                value={newVendorContactName}
                                onChange={e => setNewVendorContactName(e.target.value)}
                                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-emerald-500 font-medium"
                              />
                            </div>
                            <div>
                              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Contact Phone</label>
                              <input
                                type="text"
                                placeholder="+260 977 123456"
                                value={newVendorPhone}
                                onChange={e => setNewVendorPhone(e.target.value)}
                                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-emerald-500 font-mono font-medium"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Admin Email Address</label>
                              <input
                                type="email"
                                placeholder="vendor@mabalamarket.zm"
                                value={newVendorEmail}
                                onChange={e => setNewVendorEmail(e.target.value)}
                                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-emerald-500 font-mono font-medium"
                              />
                            </div>
                            <div>
                              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Initial Credit Top-up</label>
                              <input
                                type="number"
                                value={newVendorCredits}
                                onChange={e => setNewVendorCredits(Number(e.target.value))}
                                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-emerald-500 font-mono font-bold text-emerald-600"
                              />
                            </div>
                          </div>

                          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                            <button
                              type="button"
                              onClick={() => setShowProvisionVendorModal(false)}
                              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                            >
                              Cancel
                            </button>
                            <button
                              type="submit"
                              className="px-5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-black rounded-xl text-xs shadow-md transition-all cursor-pointer"
                            >
                              Authorize & Issue Credentials
                            </button>
                          </div>
                        </form>
                      </div>
                    </div>
                  )}
                </div>

  );
}

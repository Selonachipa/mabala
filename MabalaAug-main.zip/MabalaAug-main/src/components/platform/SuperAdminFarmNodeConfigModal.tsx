import React, { useState, useEffect } from "react";
import {
  X,
  Building2,
  Mail,
  Phone,
  MapPin,
  SlidersHorizontal,
  Save,
  Shield,
  FileText,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Tractor,
  Landmark,
  User,
  Layers,
  Sparkles,
  Info
} from "lucide-react";
import { DEFAULT_ZAMBIA_DISTRICTS, ZAMBIA_PROVINCES_ALPHABETICAL } from "../../config/zambiaDistricts";
import { doc, setDoc } from "firebase/firestore";
import { db, isConfigured, auth } from "../../firebase";

export interface SuperAdminFarmNodeConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  node: any;
  onSaveSuccess?: (updatedNode: any) => void;
  showToast?: (message: string, type?: "success" | "error" | "info" | "warning") => void;
}

export const SuperAdminFarmNodeConfigModal: React.FC<SuperAdminFarmNodeConfigModalProps> = ({
  isOpen,
  onClose,
  node,
  onSaveSuccess,
  showToast
}) => {
  const [activeTab, setActiveTab] = useState<"identity" | "location" | "statutory" | "platform">("identity");
  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: "",
    letterheadTitle: "",
    email: "",
    phone: "",
    managerName: "",
    registrationNumber: "",
    farmingType: "Mixed Crops & Livestock",
    province: "Central",
    district: "Kabwe",
    address: "",
    size: "50",
    sizeUnit: "Hectares",
    taxType: "TOT_5",
    taxSystem: "Turnover Tax",
    customTaxName: "",
    customTaxRate: 5,
    tpin: "",
    vatNumber: "",
    currency: "ZMW",
    currencySymbol: "ZK",
    financialYearStart: "2026-01-01",
    financialYearEnd: "2026-12-31",
    status: "active",
    role: "Farmer",
    tier: "Pay As You Go"
  });

  // Populate form when node changes or modal opens
  useEffect(() => {
    if (node && isOpen) {
      setErrorMsg(null);
      setSuccessMsg(null);

      const farmObj = (Array.isArray(node.farms) && node.farms[0]) ? node.farms[0] : (node.farm || {});
      const canonicalEmail = (
        node.email ||
        node.tenantEmail ||
        node.userProfile?.email ||
        farmObj.email ||
        ""
      ).trim().toLowerCase();

      const initialProvince = farmObj.province || node.province || "Central";
      const validDistricts = DEFAULT_ZAMBIA_DISTRICTS[initialProvince] || ["Kabwe"];
      const initialDistrict = farmObj.district || node.district || validDistricts[0] || "Kabwe";

      setFormData({
        name: farmObj.name || node.farmName || node.name || node.displayName || "Farm Node",
        letterheadTitle: farmObj.letterheadTitle || farmObj.name || node.farmName || node.name || "",
        email: canonicalEmail,
        phone: farmObj.phone || node.phone || node.userProfile?.phone || "",
        managerName: farmObj.managerName || node.managerName || node.name || "",
        registrationNumber: farmObj.registrationNumber || node.registrationNumber || "",
        farmingType: farmObj.farmingType || node.farmingType || "Mixed Crops & Livestock",
        province: initialProvince,
        district: initialDistrict,
        address: farmObj.address || node.address || "",
        size: String(farmObj.size || node.size || "50"),
        sizeUnit: farmObj.sizeUnit || node.sizeUnit || "Hectares",
        taxType: farmObj.taxType || node.activeFarmTaxType || node.taxType || "TOT_5",
        taxSystem: farmObj.taxSystem || "Turnover Tax",
        customTaxName: farmObj.customTaxName || "",
        customTaxRate: farmObj.customTaxRate !== undefined ? farmObj.customTaxRate : 5,
        tpin: farmObj.tpin || node.tpin || "",
        vatNumber: farmObj.vatNumber || node.vatNumber || "",
        currency: farmObj.currency || node.activeFarmCurrency || node.currency || "ZMW",
        currencySymbol: farmObj.currencySymbol || "ZK",
        financialYearStart: farmObj.financialYearStart || "2026-01-01",
        financialYearEnd: farmObj.financialYearEnd || "2026-12-31",
        status: (node.status || "active").toLowerCase(),
        role: node.role || node.userProfile?.role || "Farmer",
        tier: node.subscriptionTier || node.tier || "Pay As You Go"
      });
    }
  }, [node, isOpen]);

  if (!isOpen || !node) return null;

  const targetTenantId = node.uid || node.tenantUid || node.id || node._id;
  const availableDistricts = DEFAULT_ZAMBIA_DISTRICTS[formData.province] || [];

  const handleProvinceChange = (newProv: string) => {
    const districts = DEFAULT_ZAMBIA_DISTRICTS[newProv] || [];
    setFormData((prev) => ({
      ...prev,
      province: newProv,
      district: districts[0] || ""
    }));
  };

  const handleCurrencyChange = (curr: string) => {
    const symbolMap: Record<string, string> = {
      ZMW: "ZK",
      USD: "$",
      TZS: "TSh",
      KES: "KSh",
      ZAR: "R",
      BWP: "P",
      EUR: "€",
      GBP: "£"
    };
    setFormData((prev) => ({
      ...prev,
      currency: curr,
      currencySymbol: symbolMap[curr] || "ZK"
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      setErrorMsg("Farm name cannot be empty.");
      return;
    }

    setIsSaving(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanEmail = formData.email.trim().toLowerCase();

    const updatedNodePayload = {
      tenantId: targetTenantId,
      name: formData.name.trim(),
      letterheadTitle: formData.letterheadTitle.trim() || formData.name.trim(),
      email: cleanEmail,
      phone: formData.phone.trim(),
      managerName: formData.managerName.trim(),
      registrationNumber: formData.registrationNumber.trim(),
      farmingType: formData.farmingType,
      province: formData.province,
      district: formData.district,
      address: formData.address.trim(),
      size: formData.size,
      sizeUnit: formData.sizeUnit,
      taxType: formData.taxType,
      taxSystem: formData.taxType === "VAT_16" ? "VAT" : formData.taxType === "EXEMPT" ? "None" : "Turnover Tax",
      customTaxName: formData.customTaxName.trim(),
      customTaxRate: Number(formData.customTaxRate) || 0,
      tpin: formData.tpin.trim(),
      vatNumber: formData.vatNumber.trim(),
      currency: formData.currency,
      currencySymbol: formData.currencySymbol,
      financialYearStart: formData.financialYearStart,
      financialYearEnd: formData.financialYearEnd,
      status: formData.status,
      role: formData.role,
      tier: formData.tier
    };

    try {
      // 1. Direct Server API Call to /api/admin/farm-node/update-settings
      let apiSucceeded = false;
      try {
        const idToken = auth.currentUser ? await auth.currentUser.getIdToken() : "";
        const response = await fetch("/api/admin/farm-node/update-settings", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(idToken ? { Authorization: `Bearer ${idToken}` } : {})
          },
          body: JSON.stringify(updatedNodePayload)
        });
        if (response.ok) {
          apiSucceeded = true;
        }
      } catch (apiErr) {
        console.warn("[SuperAdminFarmNodeConfigModal] Server API call note:", apiErr);
      }

      // 2. Direct Firestore Client Write for Instant Realtime & Offline Resilience
      if (db && isConfigured && targetTenantId) {
        try {
          const farmObjToSave = {
            id: targetTenantId,
            name: updatedNodePayload.name,
            letterheadTitle: updatedNodePayload.letterheadTitle,
            email: cleanEmail,
            phone: updatedNodePayload.phone,
            managerName: updatedNodePayload.managerName,
            registrationNumber: updatedNodePayload.registrationNumber,
            farmingType: updatedNodePayload.farmingType,
            province: updatedNodePayload.province,
            district: updatedNodePayload.district,
            address: updatedNodePayload.address,
            size: updatedNodePayload.size,
            sizeUnit: updatedNodePayload.sizeUnit,
            taxType: updatedNodePayload.taxType,
            taxSystem: updatedNodePayload.taxSystem,
            customTaxName: updatedNodePayload.customTaxName,
            customTaxRate: updatedNodePayload.customTaxRate,
            tpin: updatedNodePayload.tpin,
            vatNumber: updatedNodePayload.vatNumber,
            currency: updatedNodePayload.currency,
            currencySymbol: updatedNodePayload.currencySymbol,
            financialYearStart: updatedNodePayload.financialYearStart,
            financialYearEnd: updatedNodePayload.financialYearEnd,
            updatedAt: new Date().toISOString()
          };

          // Update users_data/{targetTenantId}
          const userDocRef = doc(db, "users_data", targetTenantId);
          await setDoc(
            userDocRef,
            {
              farms: [farmObjToSave],
              activeFarmTaxType: updatedNodePayload.taxType,
              activeFarmCurrency: updatedNodePayload.currency,
              farmName: updatedNodePayload.name,
              email: cleanEmail,
              phone: updatedNodePayload.phone,
              province: updatedNodePayload.province,
              district: updatedNodePayload.district,
              status: updatedNodePayload.status,
              role: updatedNodePayload.role,
              subscriptionTier: updatedNodePayload.tier,
              userProfile: {
                name: updatedNodePayload.name,
                email: cleanEmail,
                phone: updatedNodePayload.phone,
                role: updatedNodePayload.role,
                updatedAt: new Date().toISOString()
              },
              updatedAt: new Date().toISOString()
            },
            { merge: true }
          );

          // Update module subcollection users_data/{targetTenantId}/modules/farms
          try {
            const farmModuleRef = doc(db, "users_data", targetTenantId, "modules", "farms");
            await setDoc(
              farmModuleRef,
              {
                data: [farmObjToSave],
                updatedAt: new Date().toISOString()
              },
              { merge: true }
            );
          } catch (_) {}

          // Update tenants/{targetTenantId}
          try {
            const tenantDocRef = doc(db, "tenants", targetTenantId);
            await setDoc(
              tenantDocRef,
              {
                name: updatedNodePayload.name,
                phone: updatedNodePayload.phone,
                address: updatedNodePayload.address,
                province: updatedNodePayload.province,
                district: updatedNodePayload.district,
                tpin: updatedNodePayload.tpin,
                status: updatedNodePayload.status,
                updatedAt: new Date().toISOString()
              },
              { merge: true }
            );
          } catch (_) {}
        } catch (dbErr: any) {
          console.warn("[SuperAdminFarmNodeConfigModal] Firestore write note:", dbErr);
        }
      }

      // 3. Assemble merged node object for UI callbacks
      const mergedNode = {
        ...node,
        name: updatedNodePayload.name,
        farmName: updatedNodePayload.name,
        email: cleanEmail,
        tenantEmail: cleanEmail,
        phone: updatedNodePayload.phone,
        managerName: updatedNodePayload.managerName,
        registrationNumber: updatedNodePayload.registrationNumber,
        farmingType: updatedNodePayload.farmingType,
        province: updatedNodePayload.province,
        district: updatedNodePayload.district,
        address: updatedNodePayload.address,
        size: updatedNodePayload.size,
        sizeUnit: updatedNodePayload.sizeUnit,
        taxType: updatedNodePayload.taxType,
        tpin: updatedNodePayload.tpin,
        vatNumber: updatedNodePayload.vatNumber,
        currency: updatedNodePayload.currency,
        status: updatedNodePayload.status,
        role: updatedNodePayload.role,
        subscriptionTier: updatedNodePayload.tier,
        farms: [
          {
            ...(Array.isArray(node.farms) && node.farms[0] ? node.farms[0] : {}),
            ...updatedNodePayload,
            id: targetTenantId
          }
        ]
      };

      setSuccessMsg("Farm node settings & configuration successfully updated across platform!");
      if (showToast) {
        showToast(`Farm node "${updatedNodePayload.name}" updated successfully!`, "success");
      }

      if (onSaveSuccess) {
        onSaveSuccess(mergedNode);
      }

      // Close modal after brief feedback
      setTimeout(() => {
        onClose();
      }, 900);
    } catch (err: any) {
      console.error("[SuperAdminFarmNodeConfigModal] Save error:", err);
      setErrorMsg(err.message || "Failed to update farm node configuration.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full border border-slate-200 shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        {/* MODAL HEADER */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-[#0B2265] text-white p-5 sm:p-6 flex items-start justify-between relative">
          <div className="space-y-1.5 pr-8">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 bg-indigo-500/30 border border-indigo-400/40 text-indigo-200 text-[10px] font-mono font-bold uppercase rounded-full tracking-wider flex items-center gap-1">
                <Shield className="w-3 h-3" />
                Super Admin Configuration
              </span>
              <span className="px-2.5 py-0.5 bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-[10px] font-mono font-bold uppercase rounded-full">
                UID: {targetTenantId?.slice(0, 14)}...
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black tracking-tight text-white flex items-center gap-2">
              <Tractor className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>{formData.name || "Edit Farm Node Settings"}</span>
            </h2>
            <p className="text-xs text-slate-300">
              Directly reconfigure operational directives, statutory tax regime, physical coordinates, and platform status for this farm node.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition cursor-pointer shrink-0"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* SECTION NAVIGATION TABS */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 pt-2 gap-1 overflow-x-auto scrollbar-none text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab("identity")}
            className={`px-4 py-2.5 rounded-t-xl transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === "identity"
                ? "bg-white text-indigo-900 border-t border-x border-slate-200 shadow-2xs"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Building2 className="w-4 h-4 text-indigo-600" />
            <span>Node Identity & Contact</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab("location")}
            className={`px-4 py-2.5 rounded-t-xl transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === "location"
                ? "bg-white text-indigo-900 border-t border-x border-slate-200 shadow-2xs"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <MapPin className="w-4 h-4 text-emerald-600" />
            <span>Territory & Land Area</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab("statutory")}
            className={`px-4 py-2.5 rounded-t-xl transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === "statutory"
                ? "bg-white text-indigo-900 border-t border-x border-slate-200 shadow-2xs"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Landmark className="w-4 h-4 text-amber-600" />
            <span>Statutory Tax & Currency</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab("platform")}
            className={`px-4 py-2.5 rounded-t-xl transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === "platform"
                ? "bg-white text-indigo-900 border-t border-x border-slate-200 shadow-2xs"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <SlidersHorizontal className="w-4 h-4 text-purple-600" />
            <span>Status & Entitlements</span>
          </button>
        </div>

        {/* FEEDBACK BANNERS */}
        {errorMsg && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mx-6 mt-4 p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* FORM BODY */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[60vh] overflow-y-auto">
          {/* TAB 1: NODE IDENTITY & CONTACT */}
          {activeTab === "identity" && (
            <div className="space-y-4">
              <div className="p-3.5 bg-indigo-50/60 border border-indigo-100 rounded-2xl flex items-start gap-3">
                <Info className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <p className="text-xs text-indigo-950 leading-relaxed">
                  The primary email and enterprise name uniquely identify this node on the Mabala Cloud platform. Updating this synchronizes all records across auth claims, local storage, and database collections.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Farm / Enterprise Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Deep Valley Farm Limited"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Official Letterhead Title
                  </label>
                  <input
                    type="text"
                    value={formData.letterheadTitle}
                    onChange={(e) => setFormData({ ...formData, letterheadTitle: e.target.value })}
                    placeholder="e.g. Deep Valley Farm & Milling Ltd"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                  />
                </div>

                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-xs font-bold text-slate-700 block flex items-center justify-between">
                    <span>Farm Node Primary Email (Unique Identifier)</span>
                    <span className="text-[10px] text-emerald-700 font-black">One Email Per Node</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="e.g. deepvaleyfarm@gmail.com"
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:border-indigo-500 outline-none transition shadow-2xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Primary Phone / WhatsApp
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="e.g. +260978070734"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Farm Manager / Key Contact
                  </label>
                  <input
                    type="text"
                    value={formData.managerName}
                    onChange={(e) => setFormData({ ...formData, managerName: e.target.value })}
                    placeholder="e.g. Kelvin Mwewa"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    PACRA / Business Registration No.
                  </label>
                  <input
                    type="text"
                    value={formData.registrationNumber}
                    onChange={(e) => setFormData({ ...formData, registrationNumber: e.target.value })}
                    placeholder="e.g. 120220045678"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Primary Sector / Enterprise Type
                  </label>
                  <select
                    value={formData.farmingType}
                    onChange={(e) => setFormData({ ...formData, farmingType: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition cursor-pointer"
                  >
                    <option value="Mixed Crops & Livestock">Mixed Crops & Livestock</option>
                    <option value="Commercial Row Crops (Maize, Soya, Wheat)">Commercial Row Crops (Maize, Soya, Wheat)</option>
                    <option value="Livestock & Dairy Farming">Livestock & Dairy Farming</option>
                    <option value="Commercial Poultry (Broilers & Layers)">Commercial Poultry (Broilers & Layers)</option>
                    <option value="Aquaculture & Fish Farming">Aquaculture & Fish Farming</option>
                    <option value="Horticulture & Orchard (Avocado, Macadamia, Citrus)">Horticulture & Orchard (Avocado, Macadamia, Citrus)</option>
                    <option value="Agro-Dealer Input & Distribution Hub">Agro-Dealer Input & Distribution Hub</option>
                    <option value="Offtaker Grain & Commodity Depot">Offtaker Grain & Commodity Depot</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TERRITORY & LAND AREA */}
          {activeTab === "location" && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Zambia Province <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formData.province}
                    onChange={(e) => handleProvinceChange(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition cursor-pointer"
                  >
                    {ZAMBIA_PROVINCES_ALPHABETICAL.map((prov) => (
                      <option key={prov} value={prov}>
                        {prov} Province
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    District <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formData.district}
                    onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition cursor-pointer"
                  >
                    {availableDistricts.map((dist) => (
                      <option key={dist} value={dist}>
                        {dist}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-xs font-bold text-slate-700 block">
                    Physical Farm Address / Plot Number
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="e.g. Farm Block 45, Mkushi Farming Block"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Total Land Size
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      step="any"
                      min="0"
                      value={formData.size}
                      onChange={(e) => setFormData({ ...formData, size: e.target.value })}
                      placeholder="50"
                      className="w-2/3 px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                    />
                    <select
                      value={formData.sizeUnit}
                      onChange={(e) => setFormData({ ...formData, sizeUnit: e.target.value })}
                      className="w-1/3 px-2 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition cursor-pointer"
                    >
                      <option value="Hectares">Ha</option>
                      <option value="Acres">Acres</option>
                      <option value="Plots">Plots</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: STATUTORY TAX & CURRENCY */}
          {activeTab === "statutory" && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    ZRA TPIN (Taxpayer Identification No.)
                  </label>
                  <input
                    type="text"
                    value={formData.tpin}
                    onChange={(e) => setFormData({ ...formData, tpin: e.target.value })}
                    placeholder="e.g. 1002498712"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    VAT Registration Number (Optional)
                  </label>
                  <input
                    type="text"
                    value={formData.vatNumber}
                    onChange={(e) => setFormData({ ...formData, vatNumber: e.target.value })}
                    placeholder="e.g. VAT-88992211"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                  />
                </div>

                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-xs font-bold text-slate-700 block">
                    Statutory Tax Regime (ZRA Directives)
                  </label>
                  <select
                    value={formData.taxType}
                    onChange={(e) => setFormData({ ...formData, taxType: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition cursor-pointer"
                  >
                    <option value="TOT_5">Turnover Tax - Standard TOT (5%)</option>
                    <option value="TOT_4">Turnover Tax - Agro Concession (4%)</option>
                    <option value="VAT_16">Standard Value Added Tax (VAT 16%)</option>
                    <option value="EXEMPT">Tax Exempt / Zero Rated Agricultural Output (0%)</option>
                    <option value="CUSTOM">Custom Statutory Jurisdiction Rate</option>
                  </select>
                </div>

                {formData.taxType === "CUSTOM" && (
                  <>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-700 block">
                        Custom Tax Name
                      </label>
                      <input
                        type="text"
                        value={formData.customTaxName}
                        onChange={(e) => setFormData({ ...formData, customTaxName: e.target.value })}
                        placeholder="e.g. District Agricultural Levy"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-700 block">
                        Custom Tax Rate (%)
                      </label>
                      <input
                        type="number"
                        step="any"
                        min="0"
                        max="100"
                        value={formData.customTaxRate}
                        onChange={(e) => setFormData({ ...formData, customTaxRate: Number(e.target.value) })}
                        placeholder="5"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                      />
                    </div>
                  </>
                )}

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Operational Accounting Currency
                  </label>
                  <select
                    value={formData.currency}
                    onChange={(e) => handleCurrencyChange(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition cursor-pointer"
                  >
                    <option value="ZMW">ZMW — Zambian Kwacha (ZK)</option>
                    <option value="USD">USD — United States Dollar ($)</option>
                    <option value="TZS">TZS — Tanzanian Shilling (TSh)</option>
                    <option value="KES">KES — Kenyan Shilling (KSh)</option>
                    <option value="ZAR">ZAR — South African Rand (R)</option>
                    <option value="BWP">BWP — Botswana Pula (P)</option>
                    <option value="EUR">EUR — Euro (€)</option>
                    <option value="GBP">GBP — British Pound (£)</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Financial Year Start Date
                  </label>
                  <input
                    type="date"
                    value={formData.financialYearStart}
                    onChange={(e) => setFormData({ ...formData, financialYearStart: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: PLATFORM STATUS & ENTITLEMENTS */}
          {activeTab === "platform" && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Node Operational Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition cursor-pointer"
                  >
                    <option value="active">Active (Full Read & Write Access)</option>
                    <option value="suspended">Suspended (Access Temporarily Locked)</option>
                    <option value="maintenance">Maintenance Mode</option>
                    <option value="trial">Trial / Sandbox Tier</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Assigned Primary Role
                  </label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition cursor-pointer"
                  >
                    <option value="Farmer">Farmer (Agricultural Producer)</option>
                    <option value="Agro-Dealer">Agro-Dealer (Input Merchant)</option>
                    <option value="Supplier">Supplier / Offtaker</option>
                    <option value="Agronomist">Agronomist (Crop Advisor)</option>
                    <option value="Super Admin">Super Admin (Platform Level)</option>
                  </select>
                </div>

                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-xs font-bold text-slate-700 block">
                    Subscription Tier & Access Level
                  </label>
                  <select
                    value={formData.tier}
                    onChange={(e) => setFormData({ ...formData, tier: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition cursor-pointer"
                  >
                    <option value="Pay As You Go">Pay As You Go (Default Balance Billing)</option>
                    <option value="Daily Pass">Daily Unlimited Pass</option>
                    <option value="Monthly Unlimited">Monthly Unlimited Node Plan</option>
                    <option value="Annual Enterprise">Annual Enterprise Commercial Farm</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* ACTIONS FOOTER */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2.5 bg-[#0B2265] hover:bg-[#071746] active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {isSaving ? "Saving Configuration..." : "Save Farm Node Configuration"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

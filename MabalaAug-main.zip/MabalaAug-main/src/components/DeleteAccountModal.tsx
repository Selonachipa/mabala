import { safeFormatError } from "../utils/errorUtils";
import React, { useState } from "react";
import { 
  AlertTriangle, 
  Download, 
  Trash2, 
  CheckCircle2, 
  ShieldAlert, 
  X, 
  Database, 
  FileText, 
  Sparkles,
  ArrowRight,
  Info,
  Lock
} from "lucide-react";
import { 
  downloadFarmNodeBackupArchive, 
  executeSelfFarmNodeDeletion 
} from "../services/nodeDeletionService";

interface DeleteAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: {
    uid: string;
    email: string;
    name?: string;
    fullName?: string;
    phone?: string;
    phoneNumber?: string;
    role?: string;
    accountType?: string;
    farmName?: string;
    farms?: any[];
  };
  currentRole?: string;
  onDeletionComplete: () => void;
}

export const DeleteAccountModal: React.FC<DeleteAccountModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  currentRole,
  onDeletionComplete
}) => {
  const [backupDownloaded, setBackupDownloaded] = useState<boolean>(false);
  const [backupDownloadTime, setBackupDownloadTime] = useState<string>("");
  const [backupRecordsCount, setBackupRecordsCount] = useState<number>(0);
  const [backupFileName, setBackupFileName] = useState<string>("");

  const [ackBackup, setAckBackup] = useState<boolean>(false);
  const [ackIrreversible, setAckIrreversible] = useState<boolean>(false);
  const [ackPurge, setAckPurge] = useState<boolean>(false);

  const [deletionReason, setDeletionReason] = useState<string>("");
  const [customReason, setCustomReason] = useState<string>("");
  const [confirmationInput, setConfirmationInput] = useState<string>("");
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>("");

  if (!isOpen) return null;

  const farmName = userProfile.farmName || 
    (userProfile.farms && userProfile.farms[0]?.name) || 
    userProfile.name || 
    userProfile.fullName || 
    "My Farm Node";

  const userEmail = userProfile.email || "";
  const userPhone = userProfile.phone || userProfile.phoneNumber || "Not provided";
  const userRole = userProfile.role || userProfile.accountType || "Farmer";
  const tenantId = userProfile.uid;

  const expectedConfirmText = "DELETE";

  const handleDownloadBackup = () => {
    try {
      const result = downloadFarmNodeBackupArchive(tenantId, farmName, userProfile);
      setBackupDownloaded(true);
      setBackupDownloadTime(new Date().toLocaleTimeString());
      setBackupRecordsCount(result.totalRecords);
      setBackupFileName(result.fileName);
      setAckBackup(true);
      setErrorMsg("");
    } catch (err: any) {
      setErrorMsg(`Failed to download backup: ${err.message || err}`);
    }
  };

  const isFormValid = 
    backupDownloaded && 
    ackBackup && 
    ackIrreversible && 
    ackPurge && 
    confirmationInput.trim().toUpperCase() === expectedConfirmText &&
    !isDeleting;

  const handleDeleteAccount = async () => {
    if (!isFormValid) return;

    const fullReason = deletionReason === "Other" 
      ? `Other: ${customReason}` 
      : (deletionReason || customReason || "User self-requested farm node deletion");

    setIsDeleting(true);
    setErrorMsg("");

    try {
      await executeSelfFarmNodeDeletion({
        tenantId,
        userEmail,
        userName: userProfile.name || userProfile.fullName || userEmail.split("@")[0],
        farmName,
        userPhone,
        role: userRole,
        tenantType: userProfile.accountType || userRole.toLowerCase(),
        reason: fullReason,
        backupDownloaded,
        backupDownloadedAt: new Date().toISOString()
      });

      onDeletionComplete();
    } catch (err: any) {
      setErrorMsg(err.message || "An unexpected error occurred while deleting your account.");
      setIsDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl border border-rose-200 shadow-2xl max-w-2xl w-full p-6 md:p-8 space-y-6 animate-scale-in my-8 text-slate-800">
        
        {/* HEADER */}
        <div className="flex items-start justify-between gap-4 border-b border-rose-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-rose-100 text-rose-600 rounded-2xl">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black text-rose-600 tracking-tight flex items-center gap-2">
                Delete Account & Farm Node
                <span className="px-2 py-0.5 bg-rose-50 text-rose-700 text-[10px] font-mono font-bold rounded-full border border-rose-200 uppercase">
                  {userRole}
                </span>
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Permanently purge your farm node workspace and release your email & phone number.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isDeleting}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* NODE PROFILE SUMMARY CARD */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Farm / Node</span>
            <span className="font-bold text-slate-900 truncate block" title={farmName}>{farmName}</span>
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Login Email</span>
            <span className="font-bold text-slate-900 truncate block" title={userEmail}>{userEmail}</span>
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Mobile Number</span>
            <span className="font-bold text-slate-900 truncate block">{userPhone}</span>
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Platform Role</span>
            <span className="font-bold text-emerald-700 block">{userRole}</span>
          </div>
        </div>

        {/* RE-REGISTRATION POLICY BANNER */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-amber-900 font-medium">
          <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">Credential Release Policy:</p>
            <p className="text-amber-800 mt-0.5">
              Once this farm node is deleted, your email (<strong>{userEmail}</strong>) and mobile number (<strong>{userPhone}</strong>) will be immediately released. You or your organization can reuse these credentials at any time to register a brand new farm node.
            </p>
          </div>
        </div>

        {/* ERROR MESSAGE */}
        {errorMsg && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2 text-xs font-bold text-rose-700">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{safeFormatError(errorMsg)}</span>
          </div>
        )}

        {/* STEP 1: MANDATORY BACKUP DOWNLOAD */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-slate-800 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-slate-900 text-white text-xs flex items-center justify-center font-mono">1</span>
              Mandatory: Download Farm Data Backup Archive
            </h3>
            {backupDownloaded && (
              <span className="flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5" /> Verified Downloaded
              </span>
            )}
          </div>

          <div className={`p-4 rounded-2xl border transition-all ${
            backupDownloaded 
              ? "bg-emerald-50/50 border-emerald-200" 
              : "bg-slate-50 border-slate-200"
          }`}>
            <p className="text-xs text-slate-600 font-medium mb-3">
              Mabala platform security policy mandates that all farm node records (crop cycles, livestock, sales, invoices, plot boundaries, and accounting ledgers) must be backed up and downloaded to your device before deletion is authorized.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                type="button"
                onClick={handleDownloadBackup}
                className="w-full sm:w-auto px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow transition cursor-pointer flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                {backupDownloaded ? "Re-Download Farm Backup Archive" : "Download Complete Farm Data Backup (.json)"}
              </button>

              {backupDownloaded && (
                <div className="text-right text-[11px] text-slate-500 font-mono">
                  <div>Records: <strong className="text-slate-800">{backupRecordsCount} records</strong></div>
                  <div>Timestamp: <span className="text-emerald-700 font-bold">{backupDownloadTime}</span></div>
                </div>
              )}
            </div>

            {backupFileName && (
              <p className="text-[10px] font-mono text-slate-400 mt-2 truncate">
                File: {backupFileName}
              </p>
            )}
          </div>
        </div>

        {/* STEP 2: ACKNOWLEDGEMENTS */}
        <div className="space-y-3">
          <h3 className="text-sm font-black text-slate-800 flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-slate-900 text-white text-xs flex items-center justify-center font-mono">2</span>
            Confirm Understanding & Legal Acknowledgement
          </h3>

          <div className="space-y-2.5 bg-rose-50/40 border border-rose-200/80 rounded-2xl p-4 text-xs font-semibold text-slate-700">
            <label className="flex items-start gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={ackBackup}
                onChange={e => setAckBackup(e.target.checked)}
                disabled={!backupDownloaded}
                className="mt-0.5 rounded text-rose-600 focus:ring-rose-500 w-4 h-4"
              />
              <span className={!backupDownloaded ? "text-slate-400" : ""}>
                I confirm that I have downloaded and safely stored my farm data backup archive.
              </span>
            </label>

            <label className="flex items-start gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={ackIrreversible}
                onChange={e => setAckIrreversible(e.target.checked)}
                className="mt-0.5 rounded text-rose-600 focus:ring-rose-500 w-4 h-4"
              />
              <span>
                I acknowledge and agree that this deletion is <strong className="text-rose-600 font-black">permanent and CANNOT be undone</strong>.
              </span>
            </label>

            <label className="flex items-start gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={ackPurge}
                onChange={e => setAckPurge(e.target.checked)}
                className="mt-0.5 rounded text-rose-600 focus:ring-rose-500 w-4 h-4"
              />
              <span>
                I understand that all active records, transactions, ledgers, and configurations associated with this farm node will be permanently removed from the Firebase database.
              </span>
            </label>
          </div>
        </div>

        {/* STEP 3: REASON & TYPE CONFIRMATION */}
        <div className="space-y-3">
          <h3 className="text-sm font-black text-slate-800 flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-slate-900 text-white text-xs flex items-center justify-center font-mono">3</span>
            Reason & Final Deletion Confirmation
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block text-slate-600 font-bold mb-1">Reason for Deleting Farm Node:</label>
              <select
                value={deletionReason}
                onChange={e => setDeletionReason(e.target.value)}
                className="w-full p-2.5 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 font-medium focus:border-rose-500 outline-none"
              >
                <option value="">-- Select Reason --</option>
                <option value="Starting a fresh farm node with clean records">Starting a fresh farm node with clean records</option>
                <option value="Farm operations retired / land sold">Farm operations retired / land sold</option>
                <option value="Migrating to a different cooperative/org">Migrating to a different cooperative/org</option>
                <option value="Platform testing completed">Platform testing completed</option>
                <option value="Other">Other (Please specify below)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-600 font-bold mb-1">
                Type <strong className="text-rose-600 font-black tracking-wider">DELETE</strong> to confirm:
              </label>
              <input
                type="text"
                value={confirmationInput}
                onChange={e => setConfirmationInput(e.target.value)}
                placeholder="Type DELETE"
                className="w-full p-2.5 border border-rose-300 rounded-xl bg-slate-50 text-slate-800 font-black uppercase text-center tracking-widest focus:border-rose-600 outline-none"
              />
            </div>
          </div>

          {deletionReason === "Other" && (
            <div>
              <label className="block text-slate-600 font-bold mb-1 text-xs">Specify Custom Reason:</label>
              <input
                type="text"
                value={customReason}
                onChange={e => setCustomReason(e.target.value)}
                placeholder="Please describe why you are closing this farm node..."
                className="w-full p-2.5 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 text-xs font-medium focus:border-rose-500 outline-none"
              />
            </div>
          )}
        </div>

        {/* ACTION BUTTONS */}
        <div className="flex flex-col-reverse sm:flex-row items-center justify-end gap-3 pt-4 border-t border-slate-200 text-xs font-bold uppercase">
          <button
            type="button"
            onClick={onClose}
            disabled={isDeleting}
            className="w-full sm:w-auto px-5 py-3 border border-slate-300 rounded-xl text-slate-600 hover:bg-slate-50 transition cursor-pointer"
          >
            Cancel & Keep Farm Node
          </button>
          
          <button
            type="button"
            onClick={handleDeleteAccount}
            disabled={!isFormValid}
            className="w-full sm:w-auto px-6 py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-lg transition cursor-pointer flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Trash2 className="w-4 h-4" />
            {isDeleting ? "Purging Farm Node & Releasing Credentials..." : "Permanently Delete Farm Node & Account"}
          </button>
        </div>

      </div>
    </div>
  );
};

export default DeleteAccountModal;

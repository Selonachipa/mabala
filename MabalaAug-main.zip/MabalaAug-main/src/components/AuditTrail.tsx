import { safeFormatError } from "../utils/errorUtils";
import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  History,
  Search,
  RefreshCw,
  FileJson,
  FileSpreadsheet,
  AlertTriangle,
  Ban,
  CheckCircle2,
  Lock,
  UserPlus,
  UserMinus,
  Sparkles,
  Info,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Shield,
  ShieldCheck,
  Clock,
  ChevronDown,
  ChevronRight as ChevronRightIcon,
  Copy,
  Check,
  Layers,
  Filter,
  PlusCircle
} from "lucide-react";
import { collection, query, orderBy, onSnapshot, getDocs, limit } from "firebase/firestore";
import { db } from "../firebase";
import { AuditLog } from "../types";
import { 
  handleFirestoreError, 
  OperationType, 
  recordSubUserAuditLog, 
  getSampleSubUserAuditLogs 
} from "../services/auditLogService";

export type SortField = "timestamp" | "actor" | "action" | "target" | "module" | "status";
export type SortOrder = "asc" | "desc";

export interface AuditTrailProps {
  tenantId?: string;
  farmName?: string;
  userProfile?: { 
    name: string; 
    email: string; 
    phone?: string; 
    uid?: string; 
    tenantId?: string;
    role?: string;
  };
  isOwner?: boolean;
  className?: string;
}

export const AuditTrail: React.FC<AuditTrailProps> = ({
  tenantId,
  farmName,
  userProfile,
  isOwner = true,
  className = ""
}) => {
  const resolvedTenantId = tenantId || userProfile?.tenantId || userProfile?.uid || "TENANT-001";
  
  // State
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLiveSync, setIsLiveSync] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  // Filters & Search State
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [actionCategory, setActionCategory] = useState<string>("ALL");
  const [selectedSubUser, setSelectedSubUser] = useState<string>("ALL");
  const [dateFilter, setDateFilter] = useState<"ALL" | "TODAY" | "7DAYS" | "30DAYS">("ALL");

  // Sorting State
  const [sortField, setSortField] = useState<SortField>("timestamp");
  const [sortOrder, setSortOrder] = useState<SortOrder>("desc");

  // Pagination State
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  // Load audit logs function
  const loadAuditLogs = useCallback(async (isManualRefresh: boolean = false) => {
    if (isManualRefresh) {
      setIsRefreshing(true);
    } else {
      setIsLoading(true);
    }
    setErrorMsg(null);
    const path = `platform/institutions/institutions/${resolvedTenantId}/auditLogs`;

    try {
      if (db && resolvedTenantId) {
        try {
          const colRef = collection(db, "platform", "institutions", "institutions", resolvedTenantId, "auditLogs");
          const q = query(colRef, orderBy("timestamp", "desc"), limit(250));
          
          const snap = await getDocs(q);
          const mappedLogs: AuditLog[] = snap.docs.map(docSnap => {
            const data = docSnap.data();
            let ts = data.timestamp || data.createdAt;
            if (ts && typeof ts.toDate === "function") {
              ts = ts.toDate().toISOString();
            } else if (ts && typeof ts === "object" && ts.seconds) {
              ts = new Date(ts.seconds * 1000).toISOString();
            }
            return {
              id: docSnap.id,
              ...data,
              timestamp: ts || new Date().toISOString()
            } as AuditLog;
          });

          if (mappedLogs.length > 0) {
            setLogs(mappedLogs);
            setIsLoading(false);
            setIsRefreshing(false);
            setIsLiveSync(true);
            try {
              localStorage.setItem(`mabala_audit_logs_${resolvedTenantId}`, JSON.stringify(mappedLogs));
            } catch (_) {}
            return;
          }
        } catch (firestoreErr) {
          handleFirestoreError(firestoreErr, OperationType.GET, path);
          console.warn("[AuditTrail] Direct Firestore query notice, trying REST API:", firestoreErr);
        }
      }

      // REST API Fallback
      let token = localStorage.getItem("mabala_id_token");
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
      }

      const res = await fetch(`/api/tenant/audit-logs?tenantId=${resolvedTenantId}`, {
        method: "GET",
        headers
      });

      if (res.ok) {
        const json = await res.json();
        if (json.auditLogs && Array.isArray(json.auditLogs) && json.auditLogs.length > 0) {
          setLogs(json.auditLogs);
          setIsLiveSync(true);
          setIsLoading(false);
          setIsRefreshing(false);
          return;
        }
      }

      // Local storage fallback for real recorded logs
      const localLogsKey = `mabala_audit_logs_${resolvedTenantId}`;
      const cached = localStorage.getItem(localLogsKey);
      if (cached) {
        try {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed)) {
            // Filter out any legacy dummy audit logs
            const realOnly = parsed.filter(l => !l.id?.startsWith("AUDIT-00") && l.actorName !== "Kelvin Phiri");
            setLogs(realOnly);
            setIsLoading(false);
            setIsRefreshing(false);
            return;
          }
        } catch (_) {}
      }

      // No dummy data - real production empty state
      setLogs([]);
    } catch (err: any) {
      console.warn("[AuditTrail] Error loading audit logs:", err);
      setErrorMsg("Failed to connect to real-time audit server. Showing local audit log entries.");
      setLogs([]);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [resolvedTenantId, farmName]);

  // Real-time Firestore onSnapshot attachment
  useEffect(() => {
    if (!resolvedTenantId) return;
    
    let unsubscribe: (() => void) | null = null;
    const path = `platform/institutions/institutions/${resolvedTenantId}/auditLogs`;

    try {
      if (db) {
        const colRef = collection(db, "platform", "institutions", "institutions", resolvedTenantId, "auditLogs");
        const q = query(colRef, orderBy("timestamp", "desc"), limit(250));

        unsubscribe = onSnapshot(q, (snapshot) => {
          const mappedLogs: AuditLog[] = snapshot.docs.map(docSnap => {
            const data = docSnap.data();
            let ts = data.timestamp || data.createdAt;
            if (ts && typeof ts.toDate === "function") {
              ts = ts.toDate().toISOString();
            } else if (ts && typeof ts === "object" && ts.seconds) {
              ts = new Date(ts.seconds * 1000).toISOString();
            }
            return {
              id: docSnap.id,
              ...data,
              timestamp: ts || new Date().toISOString()
            } as AuditLog;
          });

          if (mappedLogs.length > 0) {
            setLogs(mappedLogs);
            setIsLiveSync(true);
            try {
              localStorage.setItem(`mabala_audit_logs_${resolvedTenantId}`, JSON.stringify(mappedLogs));
            } catch (_) {}
          } else {
            // If collection snapshot is empty, fallback to cached or samples
            loadAuditLogs();
          }
          setIsLoading(false);
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, path);
          loadAuditLogs();
        });
      } else {
        loadAuditLogs();
      }
    } catch (err) {
      loadAuditLogs();
    }

    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, [resolvedTenantId, loadAuditLogs]);

  // Unique list of sub-users/actors from logs for filter dropdown
  const uniqueActors = useMemo(() => {
    const actorMap = new Map<string, string>();
    logs.forEach(l => {
      const name = l.actorName || l.actor || (l.actorEmail ? l.actorEmail.split("@")[0] : "");
      const email = l.actorEmail || "";
      if (email || name) {
        const key = email || name;
        actorMap.set(key, name ? `${name} (${email || "sub-user"})` : email);
      }
    });
    return Array.from(actorMap.entries()).map(([key, label]) => ({ key, label }));
  }, [logs]);

  // Filtered logs
  const filteredLogs = useMemo(() => {
    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;
    const sevenDays = 7 * oneDay;
    const thirtyDays = 30 * oneDay;

    return logs.filter((log) => {
      // Date filter
      if (dateFilter !== "ALL" && log.timestamp) {
        const logTime = new Date(log.timestamp).getTime();
        if (dateFilter === "TODAY" && now - logTime > oneDay) return false;
        if (dateFilter === "7DAYS" && now - logTime > sevenDays) return false;
        if (dateFilter === "30DAYS" && now - logTime > thirtyDays) return false;
      }

      // Sub-User filter
      if (selectedSubUser !== "ALL") {
        const actorKey = log.actorEmail || log.actorName || log.actor || "";
        if (!actorKey.toLowerCase().includes(selectedSubUser.toLowerCase())) {
          return false;
        }
      }

      // Action Category filter
      if (actionCategory !== "ALL") {
        const act = (log.action || "").toUpperCase();
        const mod = (log.module || "").toUpperCase();

        if (actionCategory === "PERMISSIONS") {
          if (!act.includes("PERMISSION") && !act.includes("ACCESS") && !act.includes("ELEVAT") && !act.includes("RESTRICT")) {
            return false;
          }
        } else if (actionCategory === "SUSPENSIONS") {
          if (!act.includes("SUSPEND") && !act.includes("BAN") && !act.includes("ACTIVAT") && !act.includes("REACTIVAT")) {
            return false;
          }
        } else if (actionCategory === "ROSTER") {
          if (!act.includes("USER_") && !act.includes("MEMBER") && !act.includes("INVITE") && !act.includes("DELETE_USER")) {
            return false;
          }
        } else if (actionCategory === "OPERATIONS") {
          const isAccessRelated = act.includes("SUSPEND") || act.includes("PERMISSION") || act.includes("ACCESS") || act.includes("USER_") || act.includes("BAN");
          if (isAccessRelated) return false;
        }
      }

      // Text search
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const actor = (log.actorName || log.actorEmail || log.actor || log.user || "").toLowerCase();
        const target = (log.targetName || log.targetEmail || log.targetUid || "").toLowerCase();
        const action = (log.action || "").toLowerCase();
        const moduleName = (log.module || "").toLowerCase();
        const record = (log.record || "").toLowerCase();
        const detail = (log.detail || log.description || JSON.stringify(log.details || {})).toLowerCase();

        return (
          actor.includes(q) ||
          target.includes(q) ||
          action.includes(q) ||
          moduleName.includes(q) ||
          record.includes(q) ||
          detail.includes(q)
        );
      }

      return true;
    });
  }, [logs, dateFilter, selectedSubUser, actionCategory, searchTerm]);

  // Sort logs
  const sortedLogs = useMemo(() => {
    return [...filteredLogs].sort((a, b) => {
      let valA: any = "";
      let valB: any = "";

      switch (sortField) {
        case "timestamp":
          valA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
          valB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
          break;
        case "actor":
          valA = (a.actorName || a.actor || a.actorEmail || "").toLowerCase();
          valB = (b.actorName || b.actor || b.actorEmail || "").toLowerCase();
          break;
        case "action":
          valA = (a.action || "").toLowerCase();
          valB = (b.action || "").toLowerCase();
          break;
        case "target":
          valA = (a.targetName || a.targetEmail || a.targetUid || "").toLowerCase();
          valB = (b.targetName || b.targetEmail || b.targetUid || "").toLowerCase();
          break;
        case "module":
          valA = (a.module || "").toLowerCase();
          valB = (b.module || "").toLowerCase();
          break;
        case "status":
          valA = (a.status || a.accessLevel || "").toLowerCase();
          valB = (b.status || b.accessLevel || "").toLowerCase();
          break;
      }

      if (valA < valB) return sortOrder === "asc" ? -1 : 1;
      if (valA > valB) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [filteredLogs, sortField, sortOrder]);

  // Pagination calculation
  const totalItems = sortedLogs.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  
  // Keep current page in bounds when filtering
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(1);
    }
  }, [totalPages, currentPage]);

  const paginatedLogs = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    return sortedLogs.slice(startIndex, startIndex + pageSize);
  }, [sortedLogs, currentPage, pageSize]);

  // Handle Sort column click
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(prev => prev === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder(field === "timestamp" ? "desc" : "asc");
    }
  };

  // Helper for Sort header icon
  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3 h-3 text-slate-400 group-hover:text-slate-600 transition" />;
    }
    return sortOrder === "asc" ? (
      <ArrowUp className="w-3 h-3 text-emerald-600 font-black" />
    ) : (
      <ArrowDown className="w-3 h-3 text-emerald-600 font-black" />
    );
  };

  // Format action badge visual properties
  const getActionBadge = (action: string, moduleName?: string) => {
    const act = (action || "").toUpperCase();

    if (act.includes("SUSPEND") || act.includes("BAN")) {
      return {
        label: "Sub-User Suspended",
        icon: <Ban className="w-3 h-3 text-rose-600" />,
        classes: "bg-rose-50 text-rose-800 border border-rose-200 font-bold",
        dot: "bg-rose-500"
      };
    }
    if (act.includes("ACTIVAT") || act.includes("REACTIVAT") || act.includes("UNBAN")) {
      return {
        label: "Sub-User Reactivated",
        icon: <CheckCircle2 className="w-3 h-3 text-emerald-600" />,
        classes: "bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold",
        dot: "bg-emerald-500"
      };
    }
    if (act.includes("READ_WRITE") || (act.includes("PERMISSION") && act.includes("ELEVAT"))) {
      return {
        label: "Granted Read & Write",
        icon: <ShieldCheck className="w-3 h-3 text-emerald-600" />,
        classes: "bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold",
        dot: "bg-emerald-500"
      };
    }
    if (act.includes("READ_ONLY") || (act.includes("PERMISSION") && act.includes("RESTRICT"))) {
      return {
        label: "Set to Read-Only",
        icon: <Lock className="w-3 h-3 text-indigo-600" />,
        classes: "bg-indigo-50 text-indigo-800 border border-indigo-200 font-bold",
        dot: "bg-indigo-500"
      };
    }
    if (act.includes("PERMISSION_CHANGE")) {
      return {
        label: "Permission Updated",
        icon: <Shield className="w-3 h-3 text-amber-600" />,
        classes: "bg-amber-50 text-amber-800 border border-amber-200 font-bold",
        dot: "bg-amber-500"
      };
    }
    if (act.includes("CREATED") || act.includes("LINKED") || act.includes("INVITE") || act.includes("SUB_USER_INVITED")) {
      return {
        label: "Sub-User Added",
        icon: <UserPlus className="w-3 h-3 text-sky-600" />,
        classes: "bg-sky-50 text-sky-800 border border-sky-200 font-bold",
        dot: "bg-sky-500"
      };
    }
    if (act.includes("REMOVED") || act.includes("UNLINK") || act.includes("DELETE_USER")) {
      return {
        label: "Sub-User Removed",
        icon: <UserMinus className="w-3 h-3 text-slate-700" />,
        classes: "bg-slate-100 text-slate-800 border border-slate-300 font-bold",
        dot: "bg-slate-500"
      };
    }
    if (act.includes("HARVEST") || act.includes("CROP") || act.includes("PLANT")) {
      return {
        label: act.replace(/_/g, " "),
        icon: <Sparkles className="w-3 h-3 text-emerald-600" />,
        classes: "bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold",
        dot: "bg-emerald-500"
      };
    }
    if (act.includes("EXPENSE") || act.includes("PAYROLL") || act.includes("SALE") || act.includes("INVOICE")) {
      return {
        label: act.replace(/_/g, " "),
        icon: <Layers className="w-3 h-3 text-indigo-600" />,
        classes: "bg-indigo-50 text-indigo-800 border border-indigo-200 font-bold",
        dot: "bg-indigo-500"
      };
    }

    return {
      label: action.replace(/_/g, " "),
      icon: <History className="w-3 h-3 text-slate-600" />,
      classes: "bg-slate-50 text-slate-700 border border-slate-200 font-medium",
      dot: "bg-slate-400"
    };
  };

  // Copy Log ID with toast
  const handleCopyId = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Simulate a sub-user activity for live demo / testing
  const handleSimulateSubUserAction = async () => {
    setIsSimulating(true);
    const subUserNames = [
      { name: "Kelvin Phiri", email: "kelvin.phiri@farm.co.zm", uid: "sub_01", role: "Field Operator" },
      { name: "Chileshe Mwape", email: "chileshe.mwape@farm.co.zm", uid: "sub_02", role: "Accountant" },
      { name: "Mutale Musonda", email: "mutale.m@farm.co.zm", uid: "sub_03", role: "Livestock Manager" }
    ];
    const picked = subUserNames[Math.floor(Math.random() * subUserNames.length)];
    
    const actions = [
      {
        action: "RECORD_FIELD_IRRIGATION",
        module: "Crop Operations",
        record: "Pivot Section 4",
        detail: `Irrigated 18 ha Winter Wheat with 25mm application depth via Pivot 4.`,
        details: { waterAppliedM3: 450, pivotPressureBar: 3.2, durationHours: 6.5 }
      },
      {
        action: "LOG_SOIL_ANALYSIS",
        module: "Crop Operations",
        record: "Soil Test Block A",
        detail: `Sampled 12 soil cores in Block A. Recorded pH 6.4 and Nitrogen index 42 mg/kg.`,
        details: { pH: 6.4, nitrogenIndex: 42, phosphorusPpm: 18 }
      },
      {
        action: "RECORD_MILK_YIELD",
        module: "Livestock & Dairy",
        record: "Morning Milking Batch",
        detail: `Collected 340 Litres fresh milk from 22 Holstein Friesians. Transferred to cooling tank.`,
        details: { totalLitres: 340, averagePerCow: 15.45, tankTempC: 3.8 }
      }
    ];
    const pickedAction = actions[Math.floor(Math.random() * actions.length)];

    try {
      await recordSubUserAuditLog({
        tenantId: resolvedTenantId,
        action: pickedAction.action,
        module: pickedAction.module,
        record: pickedAction.record,
        detail: pickedAction.detail,
        details: pickedAction.details,
        actorName: picked.name,
        actorEmail: picked.email,
        actorUid: picked.uid,
        accessLevel: "read_write",
        status: "active"
      });
      await loadAuditLogs(true);
    } catch (err) {
      console.warn("Simulation failed:", err);
    } finally {
      setIsSimulating(false);
    }
  };

  // Export handlers
  const exportToCSV = () => {
    if (sortedLogs.length === 0) return;
    const headers = [
      "Log_ID",
      "Timestamp",
      "Actor_Name",
      "Actor_Email",
      "Actor_UID",
      "Activity_Action",
      "Module",
      "Target_User",
      "Target_Email",
      "Access_Level",
      "Status",
      "Details_Summary",
      "Tenant_ID"
    ];
    const rows = sortedLogs.map(l => [
      `"${l.id || ""}"`,
      `"${l.timestamp || ""}"`,
      `"${l.actorName || l.actor || ""}"`,
      `"${l.actorEmail || ""}"`,
      `"${l.actorUid || ""}"`,
      `"${l.action || ""}"`,
      `"${l.module || ""}"`,
      `"${l.targetName || ""}"`,
      `"${l.targetEmail || ""}"`,
      `"${l.accessLevel || ""}"`,
      `"${l.status || ""}"`,
      `"${(l.detail || l.description || JSON.stringify(l.details || "")).replace(/"/g, '""')}"`,
      `"${resolvedTenantId}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `mabala_audit_trail_${resolvedTenantId}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportToJSON = () => {
    if (sortedLogs.length === 0) return;
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(sortedLogs, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `mabala_audit_trail_${resolvedTenantId}_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className={`bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden ${className}`} id="audit-trail-container">
      {/* Header Bar */}
      <div className="p-4 sm:p-5 border-b border-slate-200/80 bg-gradient-to-r from-slate-50 via-white to-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-slate-900 text-emerald-400 flex items-center justify-center shadow-xs">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base text-slate-900 flex items-center gap-2">
                <span>Sub-User Activities & Audit Trail</span>
                {isLiveSync && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-100/80 text-emerald-800 border border-emerald-200">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    Live Sync
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                Full immutable ledger of operations, permissions, and status modifications performed by sub-users for {farmName || "Farm Workspace"}.
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
          {/* Refresh Button */}
          <button
            type="button"
            onClick={() => loadAuditLogs(true)}
            disabled={isLoading || isRefreshing}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition cursor-pointer flex items-center gap-1.5"
            title="Refresh Audit Logs from Firestore"
            id="refresh-audit-logs-btn"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing || isLoading ? "animate-spin text-emerald-600" : ""}`} />
            <span>Refresh</span>
          </button>

          {/* Export Dropdown / Buttons */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={exportToCSV}
              disabled={sortedLogs.length === 0}
              className="px-2.5 py-1.5 bg-white hover:bg-slate-50 text-slate-700 font-bold text-[11px] rounded-xl border border-slate-200 transition cursor-pointer flex items-center gap-1 disabled:opacity-50"
              title="Export filtered logs as CSV"
              id="export-audit-csv-btn"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>CSV</span>
            </button>
            <button
              type="button"
              onClick={exportToJSON}
              disabled={sortedLogs.length === 0}
              className="px-2.5 py-1.5 bg-white hover:bg-slate-50 text-slate-700 font-bold text-[11px] rounded-xl border border-slate-200 transition cursor-pointer flex items-center gap-1 disabled:opacity-50"
              title="Export filtered logs as JSON"
              id="export-audit-json-btn"
            >
              <FileJson className="w-3.5 h-3.5 text-indigo-600" />
              <span>JSON</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-3 sm:p-4 bg-slate-50/60 border-b border-slate-200/70 space-y-3">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search by sub-user, action, module, or details..."
              className="w-full pl-8 pr-8 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:border-emerald-500 focus:outline-none placeholder:text-slate-400 font-medium"
              id="audit-search-input"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => {
                  setSearchTerm("");
                  setCurrentPage(1);
                }}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 font-bold text-xs"
              >
                ×
              </button>
            )}
          </div>

          {/* Secondary Dropdown Filters */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Sub-User Actor Filter */}
            <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-xl px-2 py-1 text-xs">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Actor:</span>
              <select
                value={selectedSubUser}
                onChange={(e) => {
                  setSelectedSubUser(e.target.value);
                  setCurrentPage(1);
                }}
                className="text-xs bg-transparent border-none font-semibold text-slate-700 focus:outline-none cursor-pointer"
                id="audit-actor-filter"
              >
                <option value="ALL">All Sub-Users & Staff</option>
                {uniqueActors.map(actor => (
                  <option key={actor.key} value={actor.key}>
                    {actor.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Date Range Preset */}
            <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-xl px-2 py-1 text-xs">
              <Clock className="w-3 h-3 text-slate-400" />
              <select
                value={dateFilter}
                onChange={(e) => {
                  setDateFilter(e.target.value as any);
                  setCurrentPage(1);
                }}
                className="text-xs bg-transparent border-none font-semibold text-slate-700 focus:outline-none cursor-pointer"
                id="audit-date-filter"
              >
                <option value="ALL">All Time</option>
                <option value="TODAY">Today</option>
                <option value="7DAYS">Last 7 Days</option>
                <option value="30DAYS">Last 30 Days</option>
              </select>
            </div>
          </div>
        </div>

        {/* Activity Category Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {[
            { key: "ALL", label: "All Activities", count: logs.length },
            { 
              key: "OPERATIONS", 
              label: "Sub-User Operations", 
              count: logs.filter(l => !l.action?.includes("SUSPEND") && !l.action?.includes("PERMISSION") && !l.action?.includes("USER_")).length 
            },
            { 
              key: "PERMISSIONS", 
              label: "Permission Changes", 
              count: logs.filter(l => l.action?.includes("PERMISSION") || l.action?.includes("ACCESS") || l.action?.includes("READ_")).length 
            },
            { 
              key: "SUSPENSIONS", 
              label: "Suspensions & Status", 
              count: logs.filter(l => l.action?.includes("SUSPEND") || l.action?.includes("BAN") || l.action?.includes("ACTIVAT")).length 
            },
            { 
              key: "ROSTER", 
              label: "Staff Provisioning", 
              count: logs.filter(l => l.action?.includes("USER_") || l.action?.includes("MEMBER") || l.action?.includes("INVITE")).length 
            }
          ].map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => {
                setActionCategory(tab.key);
                setCurrentPage(1);
              }}
              className={`px-3 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                actionCategory === tab.key
                  ? "bg-slate-900 text-white shadow-xs"
                  : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
              }`}
            >
              <span>{tab.label}</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-mono ${
                actionCategory === tab.key ? "bg-slate-800 text-emerald-400" : "bg-slate-100 text-slate-600"
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Error Alert if any */}
      {errorMsg && (
        <div className="p-3 bg-amber-50 border-b border-amber-200 text-amber-800 text-xs font-semibold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>{safeFormatError(errorMsg)}</span>
          </div>
          <button 
            type="button" 
            onClick={() => setErrorMsg(null)} 
            className="text-amber-600 hover:text-amber-900 font-bold text-sm"
          >
            ×
          </button>
        </div>
      )}

      {/* Sortable & Paginated Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-50/90 border-b border-slate-200 text-[10px] uppercase font-bold text-slate-500 tracking-wider select-none">
            <tr>
              {/* Sortable Timestamp Header */}
              <th 
                onClick={() => handleSort("timestamp")}
                className="p-3 pl-4 cursor-pointer hover:bg-slate-100/80 transition group"
                title="Click to sort by date and time"
              >
                <div className="flex items-center gap-1.5">
                  <span>Timestamp</span>
                  {renderSortIcon("timestamp")}
                </div>
              </th>

              {/* Sortable Actor Header */}
              <th 
                onClick={() => handleSort("actor")}
                className="p-3 cursor-pointer hover:bg-slate-100/80 transition group"
                title="Click to sort by sub-user / actor"
              >
                <div className="flex items-center gap-1.5">
                  <span>Sub-User / Actor</span>
                  {renderSortIcon("actor")}
                </div>
              </th>

              {/* Sortable Action Header */}
              <th 
                onClick={() => handleSort("action")}
                className="p-3 cursor-pointer hover:bg-slate-100/80 transition group"
                title="Click to sort by activity"
              >
                <div className="flex items-center gap-1.5">
                  <span>Activity / Action</span>
                  {renderSortIcon("action")}
                </div>
              </th>

              {/* Sortable Module Header */}
              <th 
                onClick={() => handleSort("module")}
                className="p-3 cursor-pointer hover:bg-slate-100/80 transition group hidden md:table-cell"
                title="Click to sort by module"
              >
                <div className="flex items-center gap-1.5">
                  <span>Module</span>
                  {renderSortIcon("module")}
                </div>
              </th>

              {/* Sortable Target Header */}
              <th 
                onClick={() => handleSort("target")}
                className="p-3 cursor-pointer hover:bg-slate-100/80 transition group"
                title="Click to sort by target subject"
              >
                <div className="flex items-center gap-1.5">
                  <span>Target / Subject</span>
                  {renderSortIcon("target")}
                </div>
              </th>

              {/* Details Column */}
              <th className="p-3">Details / Summary</th>

              {/* Sortable Status Header */}
              <th 
                onClick={() => handleSort("status")}
                className="p-3 cursor-pointer hover:bg-slate-100/80 transition group text-center"
                title="Click to sort by status"
              >
                <div className="flex items-center justify-center gap-1.5">
                  <span>Access / Status</span>
                  {renderSortIcon("status")}
                </div>
              </th>

              {/* Expand Header */}
              <th className="p-3 pr-4 text-right">Raw</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
            {isLoading && logs.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-12 text-center text-slate-500">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <RefreshCw className="w-7 h-7 animate-spin text-emerald-600" />
                    <span className="text-xs font-bold text-slate-700">Streaming sub-user audit logs...</span>
                    <span className="text-[11px] text-slate-400">Fetching from platform/institutions/institutions/{resolvedTenantId}/auditLogs</span>
                  </div>
                </td>
              </tr>
            ) : paginatedLogs.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-12 text-center text-slate-500">
                  <div className="max-w-sm mx-auto flex flex-col items-center gap-2">
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                      <Shield className="w-5 h-5" />
                    </div>
                    <div className="font-bold text-slate-800 text-sm">No Audit Logs Found</div>
                    <p className="text-[11px] text-slate-500 leading-relaxed">
                      {searchTerm
                        ? `No activities match "${searchTerm}". Try adjusting your search query or category filter.`
                        : "Sub-user activities, permissions, and operational logs will automatically appear here in real-time."}
                    </p>
                    {searchTerm && (
                      <button
                        type="button"
                        onClick={() => {
                          setSearchTerm("");
                          setActionCategory("ALL");
                          setSelectedSubUser("ALL");
                          setDateFilter("ALL");
                        }}
                        className="mt-2 px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition"
                      >
                        Reset All Filters
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ) : (
              paginatedLogs.map((log) => {
                const badge = getActionBadge(log.action, log.module);
                const isExpanded = expandedLogId === log.id;
                const formattedDate = log.timestamp
                  ? new Date(log.timestamp).toLocaleString("en-GB", {
                      day: "2-digit",
                      month: "short",
                      year: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                      second: "2-digit"
                    })
                  : "Just now";

                const isAccessElevation = log.accessLevel === "read_write";
                const isSuspended = log.status === "suspended";

                return (
                  <React.Fragment key={log.id}>
                    <tr className="hover:bg-slate-50/80 transition-colors">
                      {/* Timestamp */}
                      <td className="p-3 pl-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 text-slate-800 font-mono text-[11px]">
                          <Clock className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>{formattedDate}</span>
                        </div>
                      </td>

                      {/* Actor */}
                      <td className="p-3 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-slate-900 text-emerald-400 font-black text-[10px] flex items-center justify-center shrink-0">
                            {(log.actorName || log.actorEmail || log.actor || "U").charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 text-[11px]">
                              {log.actorName || log.actor || (log.actorEmail ? log.actorEmail.split("@")[0] : "Farm Sub-User")}
                            </div>
                            {log.actorEmail && (
                              <div className="text-[10px] text-slate-500 font-mono">{log.actorEmail}</div>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Action Badge */}
                      <td className="p-3 whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] uppercase tracking-wider ${badge.classes}`}>
                          {badge.icon}
                          <span>{badge.label}</span>
                        </span>
                      </td>

                      {/* Module */}
                      <td className="p-3 whitespace-nowrap hidden md:table-cell">
                        <span className="text-[11px] font-semibold text-slate-600 bg-slate-100/80 px-2 py-0.5 rounded-md border border-slate-200">
                          {log.module || "Access Control"}
                        </span>
                      </td>

                      {/* Target */}
                      <td className="p-3">
                        {log.targetEmail || log.targetName || log.targetUid || log.record ? (
                          <div>
                            <div className="font-bold text-slate-800 text-[11px]">
                              {log.targetName || log.record || (log.targetEmail ? log.targetEmail.split("@")[0] : log.targetUid)}
                            </div>
                            {log.targetEmail && (
                              <div className="text-[10px] text-slate-500 font-mono">{log.targetEmail}</div>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-400 text-[11px]">—</span>
                        )}
                      </td>

                      {/* Details / Summary */}
                      <td className="p-3 text-[11px] text-slate-600 max-w-xs truncate" title={log.detail || log.description}>
                        {log.detail || log.description || (log.details ? (
                          log.details.previousStatus
                            ? `Status: ${log.details.previousStatus} ➔ ${log.details.status || "updated"}`
                            : log.details.accessLevel
                              ? `Access: ${log.details.accessLevel}`
                              : typeof log.details === "string" ? log.details : JSON.stringify(log.details)
                        ) : "Operation executed successfully.")}
                      </td>

                      {/* Status / Access Level */}
                      <td className="p-3 text-center whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold ${
                          isSuspended
                            ? "bg-rose-50 text-rose-700 border border-rose-200"
                            : isAccessElevation
                              ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                              : "bg-indigo-50 text-indigo-700 border border-indigo-200"
                        }`}>
                          {isSuspended ? "Suspended" : isAccessElevation ? "Read & Write" : "Read-Only"}
                        </span>
                      </td>

                      {/* Expand Toggle */}
                      <td className="p-3 pr-4 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                          className="p-1 rounded-lg hover:bg-slate-200/80 text-slate-500 hover:text-slate-800 transition cursor-pointer"
                          title="Inspect raw audit payload and metadata"
                        >
                          {isExpanded ? (
                            <ChevronDown className="w-4 h-4 text-emerald-600 font-bold" />
                          ) : (
                            <ChevronRightIcon className="w-4 h-4" />
                          )}
                        </button>
                      </td>
                    </tr>

                    {/* Expandable JSON details row */}
                    {isExpanded && (
                      <tr className="bg-slate-900 text-slate-200">
                        <td colSpan={8} className="p-4 sm:p-5">
                          <div className="space-y-3">
                            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400 font-mono border-b border-slate-800 pb-2">
                              <div className="flex items-center gap-3">
                                <span>LOG ID: <strong className="text-white">{log.id}</strong></span>
                                <button
                                  type="button"
                                  onClick={(e) => handleCopyId(log.id, e)}
                                  className="text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                                  title="Copy Log ID"
                                >
                                  {copiedId === log.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                                  <span>{copiedId === log.id ? "Copied" : "Copy ID"}</span>
                                </button>
                              </div>
                              <span>TENANT: <strong className="text-emerald-400">{resolvedTenantId}</strong></span>
                              <span>COLLECTION: <strong className="text-slate-300">platform/institutions/institutions/{resolvedTenantId}/auditLogs</strong></span>
                            </div>

                            {/* Structured payload details */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1.5 text-xs">
                                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Activity Context</div>
                                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1 text-[11px] font-mono">
                                  <div><span className="text-slate-500">Action:</span> <span className="text-emerald-300">{log.action}</span></div>
                                  <div><span className="text-slate-500">Actor UID:</span> <span className="text-slate-300">{log.actorUid || "N/A"}</span></div>
                                  <div><span className="text-slate-500">Actor Email:</span> <span className="text-slate-300">{log.actorEmail || "N/A"}</span></div>
                                  <div><span className="text-slate-500">Target UID:</span> <span className="text-slate-300">{log.targetUid || "N/A"}</span></div>
                                  <div><span className="text-slate-500">Access Level:</span> <span className="text-indigo-300">{log.accessLevel || "N/A"}</span></div>
                                  <div><span className="text-slate-500">Account Status:</span> <span className="text-amber-300">{log.status || "active"}</span></div>
                                  <div><span className="text-slate-500">Timestamp (ISO):</span> <span className="text-slate-300">{log.timestamp}</span></div>
                                </div>
                              </div>

                              <div className="space-y-1.5 text-xs">
                                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Raw JSON Payload</div>
                                <pre className="p-3 bg-slate-950 rounded-xl text-[10px] font-mono text-emerald-400 overflow-x-auto border border-slate-800 max-h-48 leading-relaxed">
                                  {JSON.stringify(log, null, 2)}
                                </pre>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Paginated Footer Controls */}
      <div className="p-3 sm:p-4 bg-slate-50/80 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600 font-medium">
        {/* Left: Summary & Page Size Selector */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <Info className="w-3.5 h-3.5 text-slate-400" />
            <span>
              Showing {totalItems > 0 ? (currentPage - 1) * pageSize + 1 : 0} to{" "}
              {Math.min(currentPage * pageSize, totalItems)} of {totalItems} activit{totalItems === 1 ? "y" : "ies"}
            </span>
          </div>

          <div className="flex items-center gap-1 text-[11px] text-slate-500">
            <span>Per page:</span>
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="bg-white border border-slate-200 rounded-lg px-2 py-1 font-bold text-slate-700 text-xs focus:outline-none cursor-pointer"
              id="audit-page-size-select"
            >
              <option value={5}>5</option>
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
          </div>
        </div>

        {/* Right: Pagination Navigation Buttons */}
        <div className="flex items-center gap-1">
          {/* First Page */}
          <button
            type="button"
            onClick={() => setCurrentPage(1)}
            disabled={currentPage === 1}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed text-slate-600 transition cursor-pointer"
            title="First Page"
            id="audit-page-first-btn"
          >
            <ChevronsLeft className="w-3.5 h-3.5" />
          </button>

          {/* Previous Page */}
          <button
            type="button"
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            disabled={currentPage === 1}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed text-slate-600 transition cursor-pointer"
            title="Previous Page"
            id="audit-page-prev-btn"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          {/* Page Number Indicators */}
          <div className="flex items-center gap-1 px-1">
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let pageNum = i + 1;
              if (totalPages > 5) {
                if (currentPage > 3 && currentPage < totalPages - 2) {
                  pageNum = currentPage - 2 + i;
                } else if (currentPage >= totalPages - 2) {
                  pageNum = totalPages - 4 + i;
                }
              }
              return (
                <button
                  key={pageNum}
                  type="button"
                  onClick={() => setCurrentPage(pageNum)}
                  className={`w-7 h-7 rounded-lg text-xs font-bold transition cursor-pointer flex items-center justify-center ${
                    currentPage === pageNum
                      ? "bg-slate-900 text-white shadow-xs"
                      : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
                  }`}
                >
                  {pageNum}
                </button>
              );
            })}
          </div>

          {/* Next Page */}
          <button
            type="button"
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            disabled={currentPage === totalPages}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed text-slate-600 transition cursor-pointer"
            title="Next Page"
            id="audit-page-next-btn"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          {/* Last Page */}
          <button
            type="button"
            onClick={() => setCurrentPage(totalPages)}
            disabled={currentPage === totalPages}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed text-slate-600 transition cursor-pointer"
            title="Last Page"
            id="audit-page-last-btn"
          >
            <ChevronsRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuditTrail;

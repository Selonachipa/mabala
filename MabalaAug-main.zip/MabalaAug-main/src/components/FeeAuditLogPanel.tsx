import React, { useState, useEffect, useMemo } from "react";
import { 
  History, 
  Search, 
  Filter, 
  Download, 
  ShieldCheck, 
  UserCheck, 
  Clock, 
  ArrowRight, 
  FileText, 
  Sliders,
  CheckCircle2,
  Calendar,
  Layers
} from "lucide-react";
import { 
  FeeAuditLog, 
  FeeConfigItem, 
  getAuditLogsFromService, 
  subscribeFeeConfigChanges 
} from "../services/feeConfigService";
import { formatRelativeTime } from "../utils/userActivity";

interface FeeAuditLogPanelProps {
  userEmail?: string;
}

export default function FeeAuditLogPanel({ userEmail = "admin@mabala.cloud" }: FeeAuditLogPanelProps) {
  const [auditLogs, setAuditLogs] = useState<FeeAuditLog[]>([]);
  const [configs, setConfigs] = useState<FeeConfigItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFeeKey, setSelectedFeeKey] = useState("ALL");
  const [dateFilter, setDateFilter] = useState("ALL");

  useEffect(() => {
    const unsub = subscribeFeeConfigChanges((loadedConfigs) => {
      setConfigs(loadedConfigs);
      setAuditLogs(getAuditLogsFromService());
    });
    return () => unsub();
  }, []);

  const feeKeyOptions = useMemo(() => {
    const keys = Array.from(new Set(auditLogs.map(l => l.feeKey)));
    return ["ALL", ...keys];
  }, [auditLogs]);

  const filteredLogs = useMemo(() => {
    return auditLogs.filter((log) => {
      if (selectedFeeKey !== "ALL" && log.feeKey !== selectedFeeKey) return false;

      if (dateFilter !== "ALL") {
        const logTime = new Date(log.updatedAt).getTime();
        const now = Date.now();
        if (dateFilter === "TODAY" && now - logTime > 86400000) return false;
        if (dateFilter === "WEEK" && now - logTime > 7 * 86400000) return false;
        if (dateFilter === "MONTH" && now - logTime > 30 * 86400000) return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesKey = log.feeKey.toLowerCase().includes(q);
        const matchesName = (log.name || "").toLowerCase().includes(q);
        const matchesAdmin = (log.updatedBy || "").toLowerCase().includes(q);
        const matchesNotes = (log.notes || "").toLowerCase().includes(q);
        if (!matchesKey && !matchesName && !matchesAdmin && !matchesNotes) return false;
      }

      return true;
    });
  }, [auditLogs, selectedFeeKey, dateFilter, searchQuery]);

  const metrics = useMemo(() => {
    const totalChanges = auditLogs.length;
    const uniqueAdmins = new Set(auditLogs.map(l => l.updatedBy)).size;
    const lastChange = auditLogs.length > 0 ? auditLogs[0].updatedAt : null;
    const activeConfigsCount = configs.filter(c => c.active).length;

    return {
      totalChanges,
      uniqueAdmins,
      lastChange,
      activeConfigsCount
    };
  }, [auditLogs, configs]);

  const handleExportCSV = () => {
    if (filteredLogs.length === 0) return;
    const headers = ["ID", "Timestamp", "Fee Key", "Fee Name", "Old Value", "Old Type", "New Value", "New Type", "Modified By", "Notes"];
    const rows = filteredLogs.map(l => [
      l.id,
      l.updatedAt,
      l.feeKey,
      `"${(l.name || "").replace(/"/g, '""')}"`,
      l.oldValue,
      l.oldType,
      l.newValue,
      l.newType,
      `"${(l.updatedBy || "").replace(/"/g, '""')}"`,
      `"${(l.notes || "").replace(/"/g, '""')}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `mabala_fee_audit_logs_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 text-slate-900 font-sans animate-fade-in">
      {/* HEADER BANNER */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-indigo-500/20 text-indigo-400 rounded-lg text-xs font-mono font-bold">
              PLATFORM-FEE-AUDIT-01
            </span>
            <span className="text-[10px] font-black uppercase text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
              Tamper-Evident History Log
            </span>
          </div>
          <h2 className="text-xl font-black tracking-tight text-white mt-1">
            Fee Configuration Audit Log Console
          </h2>
          <p className="text-xs text-slate-400 font-medium mt-1 max-w-2xl">
            Track historical fee rate changes, admin authorizations, old-to-new transition deltas, and compliance notes across Mabala payment channels.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          disabled={filteredLogs.length === 0}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-extrabold rounded-xl transition-all shadow flex items-center gap-2 cursor-pointer"
        >
          <Download className="w-4 h-4" /> Export CSV Audit Trail
        </button>
      </div>

      {/* METRICS CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
            <span>Total Logged Changes</span>
            <History className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">{metrics.totalChanges}</div>
          <div className="text-[10px] text-slate-500 font-medium">Recorded in audit ledger</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
            <span>Last Rate Revision</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-base font-black text-slate-900 truncate">
            {metrics.lastChange ? formatRelativeTime(metrics.lastChange) : "Never"}
          </div>
          <div className="text-[10px] text-slate-500 font-mono">
            {metrics.lastChange ? new Date(metrics.lastChange).toLocaleDateString() : "No events"}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
            <span>Unique Admin Actors</span>
            <UserCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">{metrics.uniqueAdmins}</div>
          <div className="text-[10px] text-slate-500 font-medium font-mono">Super Admin authorized</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
            <span>Active Fee Policies</span>
            <Sliders className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">{metrics.activeConfigsCount}</div>
          <div className="text-[10px] text-slate-500 font-medium">Currently live in engine</div>
        </div>
      </div>

      {/* FILTERS & SEARCH BAR */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search fee key, admin, or notes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs font-medium border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex gap-2 w-full md:w-auto overflow-x-auto">
          <select
            value={selectedFeeKey}
            onChange={(e) => setSelectedFeeKey(e.target.value)}
            className="text-xs font-bold border border-slate-300 rounded-lg px-3 py-1.5 bg-white text-slate-700"
          >
            <option value="ALL">All Fee Keys ({feeKeyOptions.length - 1})</option>
            {feeKeyOptions.filter(k => k !== "ALL").map(key => (
              <option key={key} value={key}>{key}</option>
            ))}
          </select>

          <select
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="text-xs font-bold border border-slate-300 rounded-lg px-3 py-1.5 bg-white text-slate-700"
          >
            <option value="ALL">All Time</option>
            <option value="TODAY">Last 24 Hours</option>
            <option value="WEEK">Last 7 Days</option>
            <option value="MONTH">Last 30 Days</option>
          </select>
        </div>
      </div>

      {/* AUDIT LOG TABLE */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {filteredLogs.length === 0 ? (
          <div className="p-10 text-center space-y-2">
            <History className="w-10 h-10 text-slate-300 mx-auto" />
            <h4 className="text-sm font-bold text-slate-700">No Fee Audit Logs Found</h4>
            <p className="text-xs text-slate-400">
              No historical fee revisions match your search criteria.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-800">
              <thead className="bg-slate-50 text-[10px] font-black uppercase tracking-wider text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="p-4">Timestamp & Relative Time</th>
                  <th className="p-4">Fee Policy & Key</th>
                  <th className="p-4">Old Value</th>
                  <th className="p-4 text-center">Transition</th>
                  <th className="p-4">New Value</th>
                  <th className="p-4">Modified By</th>
                  <th className="p-4">Audit Reason / Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {filteredLogs.map((log) => {
                  const isIncrease = log.newValue > log.oldValue;
                  const isDecrease = log.newValue < log.oldValue;

                  return (
                    <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-4 space-y-0.5">
                        <div className="font-mono font-bold text-slate-900">
                          {new Date(log.updatedAt).toLocaleString()}
                        </div>
                        <div className="text-[10px] text-indigo-600 font-mono font-semibold">
                          {formatRelativeTime(log.updatedAt)}
                        </div>
                      </td>

                      <td className="p-4 space-y-0.5">
                        <div className="font-extrabold text-slate-900">{log.name || log.feeKey}</div>
                        <div className="inline-block text-[10px] font-mono font-black px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                          {log.feeKey}
                        </div>
                      </td>

                      <td className="p-4">
                        <span className="font-mono text-rose-700 font-bold bg-rose-50 px-2 py-1 rounded border border-rose-200">
                          {log.oldType === "percentage" ? `${log.oldValue}%` : `K${log.oldValue.toFixed(2)}`}
                        </span>
                      </td>

                      <td className="p-4 text-center">
                        <div className="inline-flex items-center gap-1 text-slate-400">
                          <ArrowRight className="w-4 h-4 text-indigo-500" />
                          {isIncrease && <span className="text-[9px] font-black text-amber-600 bg-amber-50 px-1 rounded">▲ UP</span>}
                          {isDecrease && <span className="text-[9px] font-black text-emerald-600 bg-emerald-50 px-1 rounded">▼ DOWN</span>}
                        </div>
                      </td>

                      <td className="p-4">
                        <span className="font-mono text-emerald-800 font-black bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200 text-sm">
                          {log.newType === "percentage" ? `${log.newValue}%` : `K${log.newValue.toFixed(2)}`}
                        </span>
                      </td>

                      <td className="p-4">
                        <div className="flex items-center gap-1.5 text-slate-800 font-bold">
                          <ShieldCheck className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                          <span className="truncate max-w-[140px]">{log.updatedBy}</span>
                        </div>
                      </td>

                      <td className="p-4 text-slate-600 text-xs italic max-w-xs leading-tight">
                        {log.notes || "Standard Super Admin Policy Update"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

import { safeFormatError } from "../utils/errorUtils";
import React, { useState, useEffect } from "react";
import { 
  ShieldCheck, 
  MapPin, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Search, 
  Filter, 
  RefreshCw, 
  Edit3, 
  Building2, 
  FileCheck, 
  X, 
  Check, 
  TrendingUp, 
  Download,
  AlertCircle
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from "recharts";

interface AgroDealer {
  id: string;
  name: string;
  type: "agro_dealer" | "supplier";
  phone: string;
  province: string;
  district: string;
  pacraNumber: string;
  pacraStatus: "Active" | "Pending" | "Flagged";
  zamraLicense: string;
  zamraStatus: "Valid" | "Expiring Soon" | "Expired" | "Missing";
  zraTpin: string;
  zraStatus: "Tax Compliant" | "TPIN Verified" | "Audit Pending" | "Flagged";
  zemaClearance: "Approved" | "Under Review" | "Non-Compliant";
  complianceScore: number;
  complianceStatus: "Compliant" | "Pending Audit" | "Flagged";
  lastAuditedDate: string;
  auditNotes: string;
}

interface ProvinceHeatmapItem {
  province: string;
  totalDealers: number;
  compliantCount: number;
  pendingCount: number;
  flaggedCount: number;
  avgComplianceScore: number;
  heatLevel: string;
}

interface ComplianceSummary {
  totalDealers: number;
  totalCompliant: number;
  totalPending: number;
  totalFlagged: number;
  overallComplianceRate: number;
}

interface Props {
  getAuthHeader: () => Record<string, string>;
}

export default function AgroDealerComplianceHeatmap({ getAuthHeader }: Props) {
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [dealers, setDealers] = useState<AgroDealer[]>([]);
  const [heatmap, setHeatmap] = useState<ProvinceHeatmapItem[]>([]);
  const [summary, setSummary] = useState<ComplianceSummary | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Filters
  const [selectedProvince, setSelectedProvince] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Edit / Audit Modal State
  const [selectedDealer, setSelectedDealer] = useState<AgroDealer | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Form fields for audit modal
  const [editPacraStatus, setEditPacraStatus] = useState<"Active" | "Pending" | "Flagged">("Active");
  const [editZamraStatus, setEditZamraStatus] = useState<"Valid" | "Expiring Soon" | "Expired" | "Missing">("Valid");
  const [editZraStatus, setEditZraStatus] = useState<"Tax Compliant" | "TPIN Verified" | "Audit Pending" | "Flagged">("Tax Compliant");
  const [editZemaClearance, setEditZemaClearance] = useState<"Approved" | "Under Review" | "Non-Compliant">("Approved");
  const [editComplianceStatus, setEditComplianceStatus] = useState<"Compliant" | "Pending Audit" | "Flagged">("Compliant");
  const [editNotes, setEditNotes] = useState<string>("");
  const [editScore, setEditScore] = useState<number>(90);

  const fetchComplianceData = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const headers = getAuthHeader();
      const res = await fetch("/api/institution/agro-dealer-compliance", { headers });
      if (!res.ok) {
        throw new Error("Failed to load statutory compliance data.");
      }
      const data = await res.json();
      setDealers(data.dealers || []);
      setHeatmap(data.provinceHeatmap || []);
      setSummary(data.summary || null);
    } catch (err: any) {
      setErrorMessage(err.message || "An error occurred fetching compliance heatmap.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchComplianceData();
  }, []);

  const openAuditModal = (dealer: AgroDealer) => {
    setSelectedDealer(dealer);
    setEditPacraStatus(dealer.pacraStatus);
    setEditZamraStatus(dealer.zamraStatus);
    setEditZraStatus(dealer.zraStatus);
    setEditZemaClearance(dealer.zemaClearance);
    setEditComplianceStatus(dealer.complianceStatus);
    setEditNotes(dealer.auditNotes || "");
    setEditScore(dealer.complianceScore || 80);
    setIsEditModalOpen(true);
  };

  const handleSaveAudit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDealer) return;

    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      const headers = { ...getAuthHeader(), "Content-Type": "application/json" };
      const body = {
        pacraStatus: editPacraStatus,
        zamraStatus: editZamraStatus,
        zraStatus: editZraStatus,
        zemaClearance: editZemaClearance,
        complianceStatus: editComplianceStatus,
        complianceScore: Number(editScore),
        auditNotes: editNotes,
        lastAuditedDate: new Date().toISOString().split("T")[0]
      };

      const res = await fetch(`/api/institution/agro-dealer-compliance/${selectedDealer.id}`, {
        method: "PATCH",
        headers,
        body: JSON.stringify(body)
      });

      if (!res.ok) {
        throw new Error("Failed to update dealer compliance record.");
      }

      setSuccessMessage(`Statutory audit successfully updated for ${selectedDealer.name}.`);
      setIsEditModalOpen(false);
      fetchComplianceData();

      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to update audit status.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredDealers = dealers.filter(d => {
    const matchesProvince = selectedProvince === "all" || d.province === selectedProvince;
    const matchesStatus = selectedStatus === "all" || d.complianceStatus === selectedStatus;
    const matchesQuery = 
      !searchQuery || 
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.district.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.pacraNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.zraTpin.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesProvince && matchesStatus && matchesQuery;
  });

  const getHeatColor = (score: number, flagged: number) => {
    if (flagged > 0 || score < 60) return "bg-rose-950/40 border-rose-800/80 text-rose-300";
    if (score < 85) return "bg-amber-950/40 border-amber-800/80 text-amber-300";
    return "bg-emerald-950/40 border-emerald-800/80 text-emerald-300";
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Compliant":
        return <span className="inline-flex items-center gap-1 bg-emerald-950 text-emerald-300 border border-emerald-800/80 px-2.5 py-1 rounded-full text-[10px] font-bold"><CheckCircle2 className="w-3 h-3 text-emerald-400" /> Compliant</span>;
      case "Pending Audit":
        return <span className="inline-flex items-center gap-1 bg-amber-950 text-amber-300 border border-amber-800/80 px-2.5 py-1 rounded-full text-[10px] font-bold"><Clock className="w-3 h-3 text-amber-400" /> Pending Audit</span>;
      case "Flagged":
        return <span className="inline-flex items-center gap-1 bg-rose-950 text-rose-300 border border-rose-800/80 px-2.5 py-1 rounded-full text-[10px] font-bold"><AlertTriangle className="w-3 h-3 text-rose-400" /> Flagged</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-950 to-indigo-950 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 bg-indigo-950/80 border border-indigo-800/60 text-indigo-300 px-3 py-1 rounded-full text-xs font-mono font-semibold mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            <span>Statutory Verification Engine & Geographic Heatmap</span>
          </div>
          <h2 className="text-xl font-extrabold text-white tracking-tight">Agro-Dealer Compliance Matrix</h2>
          <p className="text-slate-400 text-xs mt-1 max-w-2xl">
            Real-time monitoring of PACRA company registration, ZAMRA pesticide/drug permits, ZRA TPIN tax standing, and ZEMA environmental compliance across linked retail partners.
          </p>
        </div>

        <button
          onClick={fetchComplianceData}
          disabled={isLoading}
          className="self-start md:self-auto flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} />
          <span>Refresh Heatmap</span>
        </button>
      </div>

      {/* Success/Error Banners */}
      {successMessage && (
        <div className="bg-emerald-950/80 border border-emerald-800 text-emerald-200 p-4 rounded-2xl text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage(null)} className="text-emerald-400 hover:text-emerald-200">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="bg-rose-950/80 border border-rose-800 text-rose-200 p-4 rounded-2xl text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{safeFormatError(errorMessage)}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-rose-400 hover:text-rose-200">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 shadow-lg">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Total Linked Vendors</span>
          <div className="text-2xl font-black text-white mt-1 font-mono">{summary?.totalDealers || 0}</div>
          <span className="text-[10px] text-slate-500 mt-1 block">Retailers & Suppliers</span>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 shadow-lg">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Overall Compliance Score</span>
          <div className="text-2xl font-black text-indigo-400 mt-1 font-mono">{summary?.overallComplianceRate || 0}%</div>
          <div className="w-full bg-slate-900 h-1.5 rounded-full mt-2 overflow-hidden border border-slate-800">
            <div className="bg-indigo-500 h-full rounded-full transition-all duration-500" style={{ width: `${summary?.overallComplianceRate || 0}%` }} />
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 shadow-lg">
          <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider">Fully Compliant</span>
          <div className="text-2xl font-black text-emerald-400 mt-1 font-mono">{summary?.totalCompliant || 0}</div>
          <span className="text-[10px] text-emerald-500/80 mt-1 block">Statutory Clearance Active</span>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 shadow-lg">
          <span className="text-[10px] font-mono text-amber-400 uppercase tracking-wider">Pending Audit</span>
          <div className="text-2xl font-black text-amber-400 mt-1 font-mono">{summary?.totalPending || 0}</div>
          <span className="text-[10px] text-amber-500/80 mt-1 block">Renewal or Verification Due</span>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 shadow-lg">
          <span className="text-[10px] font-mono text-rose-400 uppercase tracking-wider">Flagged Non-Compliant</span>
          <div className="text-2xl font-black text-rose-400 mt-1 font-mono">{summary?.totalFlagged || 0}</div>
          <span className="text-[10px] text-rose-500/80 mt-1 block">Inspection Required</span>
        </div>
      </div>

      {/* Regional Compliance Heatmap Tiles Grid */}
      <div className="bg-slate-950 border border-slate-800/80 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-850 pb-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-400" />
              <span>Provincial Statutory Compliance Heatmap</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Click any province tile to filter the linked agro-dealer roster below.</p>
          </div>

          {selectedProvince !== "all" && (
            <button
              onClick={() => setSelectedProvince("all")}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              <span>Clear Region Filter ({selectedProvince})</span>
            </button>
          )}
        </div>

        {/* Tiles */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {heatmap.map((item) => {
            const isSelected = selectedProvince === item.province;
            return (
              <button
                key={item.province}
                onClick={() => setSelectedProvince(isSelected ? "all" : item.province)}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden ${getHeatColor(item.avgComplianceScore, item.flaggedCount)} ${
                  isSelected ? "ring-2 ring-indigo-500 scale-[1.02] shadow-xl" : "hover:scale-[1.01]"
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-extrabold font-mono tracking-tight text-white">{item.province}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full font-bold bg-slate-900/60 border border-white/10 text-slate-200">
                    {item.totalDealers} {item.totalDealers === 1 ? "dealer" : "dealers"}
                  </span>
                </div>

                <div className="text-xl font-black font-mono my-1">{item.avgComplianceScore}%</div>
                <div className="text-[10px] font-semibold opacity-90 truncate">{item.heatLevel}</div>

                <div className="mt-3 pt-2 border-t border-white/10 flex justify-between text-[10px] font-mono opacity-80">
                  <span className="text-emerald-400">✓ {item.compliantCount}</span>
                  <span className="text-amber-400">⏱ {item.pendingCount}</span>
                  <span className="text-rose-400">⚠ {item.flaggedCount}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Compliance Breakdown Recharts Visualization */}
      <div className="bg-slate-950 border border-slate-800/80 rounded-3xl p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-indigo-400" />
          <span>Regional Compliance Distribution Chart</span>
        </h3>

        <div className="h-64 w-full pt-2">
          {heatmap.length === 0 ? (
            <div className="h-full flex items-center justify-center text-slate-500 text-xs font-mono">
              Loading chart metrics...
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={heatmap}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="province" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} />
                <Tooltip contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: 12 }} />
                <Bar dataKey="avgComplianceScore" name="Avg Compliance %" fill="#6366f1" radius={[6, 6, 0, 0]}>
                  {heatmap.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.avgComplianceScore >= 85 ? "#10b981" : entry.avgComplianceScore >= 65 ? "#f59e0b" : "#ef4444"} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Interactive Dealers Roster Table */}
      <div className="bg-slate-950 border border-slate-800/80 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-850 pb-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-400" />
              <span>Statutory Compliance Registry</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Verified PACRA, ZAMRA, ZRA TPIN, and ZEMA environmental audit status for linked vendors.</p>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search vendor, TPIN, PACRA..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 w-48"
              />
            </div>

            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
            >
              <option value="all">All Statuses</option>
              <option value="Compliant">Compliant Only</option>
              <option value="Pending Audit">Pending Audit</option>
              <option value="Flagged">Flagged Non-Compliant</option>
            </select>
          </div>
        </div>

        {/* Roster Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/80 text-slate-400 text-[10px] font-mono uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Vendor & Location</th>
                <th className="py-3 px-4">PACRA Reg</th>
                <th className="py-3 px-4">ZAMRA License</th>
                <th className="py-3 px-4">ZRA Tax Status</th>
                <th className="py-3 px-4">ZEMA Clearance</th>
                <th className="py-3 px-4">Score</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {filteredDealers.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500 font-mono">
                    No linked agro-dealers found matching the selected region or compliance filter.
                  </td>
                </tr>
              ) : (
                filteredDealers.map((dealer) => (
                  <tr key={dealer.id} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-white">{dealer.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {dealer.district}, {dealer.province} • {dealer.phone}
                      </div>
                    </td>

                    <td className="py-3 px-4 font-mono text-[11px]">
                      <div>{dealer.pacraNumber}</div>
                      <span className={`text-[9px] ${dealer.pacraStatus === "Active" ? "text-emerald-400" : "text-amber-400"}`}>
                        ● {dealer.pacraStatus}
                      </span>
                    </td>

                    <td className="py-3 px-4 font-mono text-[11px]">
                      <div>{dealer.zamraLicense}</div>
                      <span className={`text-[9px] ${dealer.zamraStatus === "Valid" ? "text-emerald-400" : dealer.zamraStatus === "Expiring Soon" ? "text-amber-400" : "text-rose-400"}`}>
                        ● {dealer.zamraStatus}
                      </span>
                    </td>

                    <td className="py-3 px-4 font-mono text-[11px]">
                      <div>TPIN: {dealer.zraTpin}</div>
                      <span className={`text-[9px] ${dealer.zraStatus === "Tax Compliant" ? "text-emerald-400" : "text-amber-400"}`}>
                        ● {dealer.zraStatus}
                      </span>
                    </td>

                    <td className="py-3 px-4 font-mono text-[11px]">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        dealer.zemaClearance === "Approved" ? "bg-emerald-950 text-emerald-300 border border-emerald-800" :
                        dealer.zemaClearance === "Under Review" ? "bg-amber-950 text-amber-300 border border-amber-800" :
                        "bg-rose-950 text-rose-300 border border-rose-800"
                      }`}>
                        {dealer.zemaClearance}
                      </span>
                    </td>

                    <td className="py-3 px-4 font-mono font-bold text-indigo-400">
                      {dealer.complianceScore}%
                    </td>

                    <td className="py-3 px-4">
                      {getStatusBadge(dealer.complianceStatus)}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => openAuditModal(dealer)}
                        className="bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800/80 px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ml-auto cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Log Audit</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Audit Modal */}
      {isEditModalOpen && selectedDealer && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-850 pb-3">
              <div>
                <h3 className="text-base font-extrabold text-white">Log Statutory Compliance Audit</h3>
                <p className="text-xs text-slate-400 font-mono mt-0.5">{selectedDealer.name} ({selectedDealer.district}, {selectedDealer.province})</p>
              </div>
              <button onClick={() => setIsEditModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAudit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">PACRA Registration</label>
                  <select
                    value={editPacraStatus}
                    onChange={(e: any) => setEditPacraStatus(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Active">Active / Registered</option>
                    <option value="Pending">Pending Filing</option>
                    <option value="Flagged">Flagged</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">ZAMRA Permit Status</label>
                  <select
                    value={editZamraStatus}
                    onChange={(e: any) => setEditZamraStatus(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Valid">Valid Permit</option>
                    <option value="Expiring Soon">Expiring Soon (&lt;60d)</option>
                    <option value="Expired">Expired</option>
                    <option value="Missing">Missing License</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">ZRA Tax Standing</label>
                  <select
                    value={editZraStatus}
                    onChange={(e: any) => setEditZraStatus(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Tax Compliant">Tax Compliant</option>
                    <option value="TPIN Verified">TPIN Verified</option>
                    <option value="Audit Pending">Audit Pending</option>
                    <option value="Flagged">Flagged</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">ZEMA Clearance</label>
                  <select
                    value={editZemaClearance}
                    onChange={(e: any) => setEditZemaClearance(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Approved">Approved</option>
                    <option value="Under Review">Under Review</option>
                    <option value="Non-Compliant">Non-Compliant</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Overall Status</label>
                  <select
                    value={editComplianceStatus}
                    onChange={(e: any) => setEditComplianceStatus(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Compliant">Compliant</option>
                    <option value="Pending Audit">Pending Audit</option>
                    <option value="Flagged">Flagged</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Compliance Score (%)</label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={editScore}
                    onChange={(e) => setEditScore(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">M&E Field Notes & Audit Justification</label>
                <textarea
                  rows={3}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  placeholder="Enter notes on license verification, physical store inspection, or statutory renewal deadline..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-850">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white bg-slate-900 border border-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 transition-all shadow-lg shadow-indigo-600/20 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving Audit...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Save Compliance Audit</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useState, useMemo } from "react";
import { jsPDF } from "jspdf";
import { 
  BankingDestination, 
  BankingDestinationType, 
  ReconcilableSalesRecord, 
  FarmerBankReconciliationRun,
  CashSale,
  Invoice,
  OtherRevenue,
  Account
} from "../types";
import { 
  Landmark, 
  Smartphone, 
  Plus, 
  CheckCircle2, 
  AlertTriangle, 
  Scale, 
  Search, 
  Calendar, 
  FileSpreadsheet, 
  ArrowRight, 
  Building2, 
  Filter, 
  Clock, 
  DollarSign, 
  Trash2, 
  Eye, 
  Sparkles, 
  RefreshCw, 
  Download, 
  FileText,
  ShieldCheck,
  Zap,
  Info,
  Upload,
  FileUp,
  Check,
  ArrowUpRight
} from "lucide-react";
import { safeLocalStorage as localStorage } from "../utils/safeStorage";

interface BankReconciliationPanelProps {
  cashSales?: CashSale[];
  invoices?: Invoice[];
  otherRevenues?: OtherRevenue[];
  accounts?: Account[];
  currencySymbol: string;
  isReadonly?: boolean;
  farmName?: string;
  userProfileName?: string;
  onUpdateCashSaleStatus?: (id: string, status: string) => void;
}

const DEFAULT_DESTINATIONS: BankingDestination[] = [
  {
    id: "dest-zanaco-01",
    name: "Zanaco Agri-Business Checking",
    type: "Bank Account",
    accountNumber: "102938475601",
    institutionName: "Zambian National Commercial Bank (ZANACO)",
    currentBalance: 84500.00,
    lastReconciledDate: "2026-08-01",
    currency: "ZMW",
    notes: "Primary farm operating bank account for grain & produce sales"
  },
  {
    id: "dest-airtel-momo-02",
    name: "Airtel Money Merchant Wallet",
    type: "Mobile Money Wallet",
    accountNumber: "+260971234567",
    institutionName: "Airtel Money Zambia",
    currentBalance: 19850.50,
    lastReconciledDate: "2026-08-05",
    currency: "ZMW",
    notes: "Mobile money collection point for farm-gate sales and vegetable deliveries"
  },
  {
    id: "dest-mtn-momo-03",
    name: "MTN MoMo Corporate Wallet",
    type: "Mobile Money Wallet",
    accountNumber: "+260968987654",
    institutionName: "MTN Mobile Money Zambia",
    currentBalance: 12400.00,
    lastReconciledDate: "2026-07-28",
    currency: "ZMW",
    notes: "Secondary collection wallet for livestock & poultry orders"
  },
  {
    id: "dest-cash-drawer-04",
    name: "Farm Office Cash Safe",
    type: "Cash Box / Drawer",
    accountNumber: "CASH-SAFE-01",
    institutionName: "On-Farm Cash Drawer",
    currentBalance: 4200.00,
    lastReconciledDate: "2026-08-10",
    currency: "ZMW",
    notes: "Physical petty cash & daily farm-gate receipts awaiting bank deposit"
  }
];

export default function BankReconciliationPanel({
  cashSales = [],
  invoices = [],
  otherRevenues = [],
  accounts = [],
  currencySymbol,
  isReadonly = false,
  farmName = "Mabala Main Farm",
  userProfileName = "Farm Manager"
}: BankReconciliationPanelProps) {
  // Destinations State
  const [destinations, setDestinations] = useState<BankingDestination[]>(() => {
    const cached = localStorage.getItem("mabala_banking_destinations");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {}
    }
    return DEFAULT_DESTINATIONS;
  });

  // Reconciliation Runs History
  const [runs, setRuns] = useState<FarmerBankReconciliationRun[]>(() => {
    const cached = localStorage.getItem("mabala_bank_reconciliation_runs");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [
      {
        id: "run-001",
        runNumber: "BRC-2026-001",
        farmId: "FARM-01",
        destinationId: "dest-zanaco-01",
        destinationName: "Zanaco Agri-Business Checking",
        destinationType: "Bank Account",
        accountNumber: "102938475601",
        reconciliationDate: "2026-08-01",
        periodStart: "2026-07-01",
        periodEnd: "2026-07-31",
        statementEndingBalance: 84500.00,
        ledgerRecordedSalesTotal: 84620.00,
        bankDepositsMatchedTotal: 84620.00,
        bankFeesAndCharges: 120.00,
        interestOrAdjustments: 0.00,
        netReconciledAmount: 84500.00,
        unreconciledVariance: 0.00,
        status: "Balanced",
        reconciledBy: "Farm Accountant",
        matchedSalesIds: ["CS-101", "CS-102", "INV-201"],
        depositReferenceNumber: "ZAN-DEP-773910",
        notes: "Monthly July statement auto-matched with produce sales and bank charges deducted.",
        createdAt: "2026-08-01T14:30:00Z"
      }
    ];
  });

  // Reconciled items ID tracker
  const [reconciledItemIds, setReconciledItemIds] = useState<Set<string>>(() => {
    const set = new Set<string>();
    runs.forEach(r => r.matchedSalesIds.forEach(id => set.add(id)));
    return set;
  });

  // UI state
  const [activeTab, setActiveTab] = useState<"overview" | "wizard" | "history" | "destinations" | "csv-import">("overview");
  const [selectedDestinationId, setSelectedDestinationId] = useState<string>(destinations[0]?.id || "");
  const [showAddDestModal, setShowAddDestModal] = useState(false);
  const [selectedRunForView, setSelectedRunForView] = useState<FarmerBankReconciliationRun | null>(null);

  // CSV Statement Import State
  const [csvProviderPreset, setCsvProviderPreset] = useState<"Airtel" | "MTN" | "Zanaco" | "StanChart" | "Custom">("Airtel");
  const [csvRawContent, setCsvRawContent] = useState<string>("");
  const [csvFileName, setCsvFileName] = useState<string>("");
  const [csvParsedRows, setCsvParsedRows] = useState<any[]>([]);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [csvColMap, setCsvColMap] = useState({
    dateCol: "0",
    descCol: "1",
    refCol: "2",
    depositCol: "3",
    withdrawalCol: "4"
  });
  const [csvTargetDestinationId, setCsvTargetDestinationId] = useState<string>(destinations[0]?.id || "");
  const [csvImportSuccessMsg, setCsvImportSuccessMsg] = useState<string | null>(null);

  // New Destination Form
  const [destName, setDestName] = useState("");
  const [destType, setDestType] = useState<BankingDestinationType>("Bank Account");
  const [destAccountNum, setDestAccountNum] = useState("");
  const [destInst, setDestInst] = useState("");
  const [destInitBal, setDestInitBal] = useState("");
  const [destNotes, setDestNotes] = useState("");

  // Reconciliation Wizard Form
  const [wizDestinationId, setWizDestinationId] = useState<string>(destinations[0]?.id || "");
  const [wizPeriodStart, setWizPeriodStart] = useState("2026-08-01");
  const [wizPeriodEnd, setWizPeriodEnd] = useState(new Date().toISOString().substring(0, 10));
  const [wizStatementBalance, setWizStatementBalance] = useState<string>("");
  const [wizDepositRef, setWizDepositRef] = useState("");
  const [wizBankFees, setWizBankFees] = useState<string>("0");
  const [wizInterestAdj, setWizInterestAdj] = useState<string>("0");
  const [wizNotes, setWizNotes] = useState("");
  const [wizSelectedSalesIds, setWizSelectedSalesIds] = useState<string[]>([]);
  const [wizSearchFilter, setWizSearchFilter] = useState("");
  const [wizSourceModuleFilter, setWizSourceModuleFilter] = useState<string>("All");

  // Save destinations to local storage
  const saveDestinations = (updated: BankingDestination[]) => {
    setDestinations(updated);
    localStorage.setItem("mabala_banking_destinations", JSON.stringify(updated));
  };

  // Save runs to local storage
  const saveRuns = (updated: FarmerBankReconciliationRun[]) => {
    setRuns(updated);
    localStorage.setItem("mabala_bank_reconciliation_runs", JSON.stringify(updated));
  };

  // Aggregate ALL Reconcilable Sales & Revenue Records
  const allSalesRecords = useMemo<ReconcilableSalesRecord[]>(() => {
    const list: ReconcilableSalesRecord[] = [];

    // 1. Direct Cash Sales
    cashSales.forEach(cs => {
      const isRec = reconciledItemIds.has(cs.id);
      list.push({
        id: cs.id,
        date: cs.date || new Date().toISOString().substring(0, 10),
        sourceModule: "Cash Sales",
        title: cs.description || "Direct Grain / Harvest Produce Sale",
        customerOrBuyer: cs.customer || "Walk-in Buyer",
        amount: cs.amount || 0,
        paymentChannel: (cs.paymentMethod as any) || "Cash",
        referenceNumber: cs.coaDebit || `CS-${cs.id.substring(0, 6)}`,
        reconciliationStatus: isRec ? "Reconciled" : "Unreconciled"
      });
    });

    // 2. Paid Invoices
    invoices.filter(inv => inv.status === "Paid" || inv.status === "Partially Paid").forEach(inv => {
      const isRec = reconciledItemIds.has(inv.id);
      list.push({
        id: inv.id,
        date: inv.date || new Date().toISOString().substring(0, 10),
        sourceModule: "Invoices & Receivables",
        title: `Invoice #${inv.invoiceNumber} - ${inv.customerName}`,
        customerOrBuyer: inv.customerName,
        amount: inv.total || (inv.subtotal + (inv.taxAmount || 0)) || 0,
        paymentChannel: "Bank Transfer",
        referenceNumber: inv.invoiceNumber,
        reconciliationStatus: isRec ? "Reconciled" : "Unreconciled"
      });
    });

    // 3. Other Non-Crop Revenues
    otherRevenues.forEach(rev => {
      const isRec = reconciledItemIds.has(rev.id);
      list.push({
        id: rev.id,
        date: rev.date || new Date().toISOString().substring(0, 10),
        sourceModule: "Other Revenue",
        title: rev.description || `${rev.revenueType} Receipt`,
        customerOrBuyer: rev.source || "External Grantor / Shareholder",
        amount: rev.amount || 0,
        paymentChannel: "Bank Transfer",
        referenceNumber: rev.coaCode || `REV-${rev.id.substring(0, 6)}`,
        reconciliationStatus: isRec ? "Reconciled" : "Unreconciled"
      });
    });

    // Fallback seed records if zero sales exist in system
    if (list.length === 0) {
      return [
        {
          id: "CS-101",
          date: "2026-08-02",
          sourceModule: "Crop Sales",
          title: "Soybean Bulk Sale - 25 Tons to FRA Depot",
          customerOrBuyer: "Food Reserve Agency (FRA)",
          amount: 45000.00,
          paymentChannel: "Bank Transfer",
          referenceNumber: "ZAN-EFT-9982",
          reconciliationStatus: "Unreconciled"
        },
        {
          id: "CS-102",
          date: "2026-08-05",
          sourceModule: "Livestock & Poultry",
          title: "Layer Eggs Batch #12 - 300 Trays",
          customerOrBuyer: "Soweto Market Wholesaler",
          amount: 14500.00,
          paymentChannel: "Mobile Money",
          referenceNumber: "AIR-TXN-8821",
          reconciliationStatus: "Unreconciled"
        },
        {
          id: "CS-103",
          date: "2026-08-08",
          sourceModule: "Cash Sales",
          title: "Fresh Tomato Crates - Farm Gate Cash Collection",
          customerOrBuyer: "Lusaka Produce Retailers",
          amount: 8200.00,
          paymentChannel: "Cash",
          referenceNumber: "CASH-REC-004",
          reconciliationStatus: "Unreconciled"
        },
        {
          id: "CS-104",
          date: "2026-08-10",
          sourceModule: "Invoices & Receivables",
          title: "Invoice #INV-2026-042 - Onion Offtake",
          customerOrBuyer: "Zambeef Supermarkets",
          amount: 28500.00,
          paymentChannel: "Bank Transfer",
          referenceNumber: "INV-2026-042",
          reconciliationStatus: "Unreconciled"
        }
      ];
    }

    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [cashSales, invoices, otherRevenues, reconciledItemIds]);

  // Statistics
  const unreconciledSales = useMemo(() => {
    return allSalesRecords.filter(r => r.reconciliationStatus === "Unreconciled");
  }, [allSalesRecords]);

  const totalUnreconciledAmount = useMemo(() => {
    return unreconciledSales.reduce((sum, r) => sum + r.amount, 0);
  }, [unreconciledSales]);

  const totalReconciledAmount = useMemo(() => {
    return allSalesRecords.filter(r => r.reconciliationStatus === "Reconciled").reduce((sum, r) => sum + r.amount, 0);
  }, [allSalesRecords]);

  const totalBankBalances = useMemo(() => {
    return destinations.reduce((sum, d) => sum + d.currentBalance, 0);
  }, [destinations]);

  // Current active destination in Wizard
  const currentWizDestination = useMemo(() => {
    return destinations.find(d => d.id === wizDestinationId) || destinations[0];
  }, [destinations, wizDestinationId]);

  // Filtered sales for Wizard selection
  const wizFilteredSales = useMemo(() => {
    return unreconciledSales.filter(s => {
      const matchesSearch = s.title.toLowerCase().includes(wizSearchFilter.toLowerCase()) ||
                            s.customerOrBuyer.toLowerCase().includes(wizSearchFilter.toLowerCase()) ||
                            (s.referenceNumber && s.referenceNumber.toLowerCase().includes(wizSearchFilter.toLowerCase()));
      const matchesModule = wizSourceModuleFilter === "All" || s.sourceModule === wizSourceModuleFilter;
      return matchesSearch && matchesModule;
    });
  }, [unreconciledSales, wizSearchFilter, wizSourceModuleFilter]);

  // Wizard Totals Calculation
  const wizSelectedSalesTotal = useMemo(() => {
    return wizSelectedSalesIds.reduce((sum, id) => {
      const item = allSalesRecords.find(s => s.id === id);
      return sum + (item ? item.amount : 0);
    }, 0);
  }, [wizSelectedSalesIds, allSalesRecords]);

  const wizParsedBankFees = Number(wizBankFees) || 0;
  const wizParsedInterest = Number(wizInterestAdj) || 0;
  const wizParsedStatementBal = Number(wizStatementBalance) || 0;

  // Net calculated expected bank deposit
  const wizNetExpectedDeposit = wizSelectedSalesTotal - wizParsedBankFees + wizParsedInterest;

  // Unreconciled Variance = Statement Ending Balance - Expected Deposit
  const wizVariance = wizParsedStatementBal - wizNetExpectedDeposit;
  const isWizBalanced = Math.abs(wizVariance) < 0.01;

  // Add Destination Handler
  const handleAddDestinationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!destName || !destAccountNum || !destInst) {
      alert("Please complete required destination name, account number, and institution.");
      return;
    }
    const newDest: BankingDestination = {
      id: `dest-${Date.now()}`,
      name: destName,
      type: destType,
      accountNumber: destAccountNum,
      institutionName: destInst,
      currentBalance: Number(destInitBal) || 0,
      lastReconciledDate: new Date().toISOString().substring(0, 10),
      currency: "ZMW",
      notes: destNotes
    };
    saveDestinations([...destinations, newDest]);
    setDestName("");
    setDestAccountNum("");
    setDestInst("");
    setDestInitBal("");
    setDestNotes("");
    setShowAddDestModal(false);
  };

  // Toggle selection in Wizard
  const toggleWizardSaleSelect = (id: string) => {
    setWizSelectedSalesIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const selectAllWizardSales = () => {
    if (wizSelectedSalesIds.length === wizFilteredSales.length) {
      setWizSelectedSalesIds([]);
    } else {
      setWizSelectedSalesIds(wizFilteredSales.map(s => s.id));
    }
  };

  // Smart Match Button
  const handleSmartMatch = () => {
    if (!wizStatementBalance) {
      alert("Please enter a Statement Ending Balance first to perform Smart Auto-Match.");
      return;
    }
    const target = Number(wizStatementBalance) + wizParsedBankFees - wizParsedInterest;
    
    // Find subset matching target
    let exactMatch: string[] = [];
    let cumulative = 0;
    
    for (const item of unreconciledSales) {
      if (Math.abs(cumulative + item.amount - target) < 0.01) {
        exactMatch.push(item.id);
        break;
      } else if (cumulative + item.amount < target) {
        exactMatch.push(item.id);
        cumulative += item.amount;
      }
    }

    if (exactMatch.length > 0) {
      setWizSelectedSalesIds(exactMatch);
    } else {
      // Fallback: select all matching channel or date
      setWizSelectedSalesIds(unreconciledSales.slice(0, 5).map(s => s.id));
    }
  };

  // Save Reconciliation Run
  const handleExecuteReconciliation = () => {
    if (wizSelectedSalesIds.length === 0) {
      alert("Please select at least one sales or revenue record to reconcile.");
      return;
    }
    if (!wizStatementBalance) {
      alert("Please enter the Statement Ending Balance.");
      return;
    }

    const runNum = `BRC-2026-00${runs.length + 1}`;
    const newRun: FarmerBankReconciliationRun = {
      id: `run-${Date.now()}`,
      runNumber: runNum,
      farmId: "FARM-MAIN",
      destinationId: currentWizDestination.id,
      destinationName: currentWizDestination.name,
      destinationType: currentWizDestination.type,
      accountNumber: currentWizDestination.accountNumber,
      reconciliationDate: new Date().toISOString().substring(0, 10),
      periodStart: wizPeriodStart,
      periodEnd: wizPeriodEnd,
      statementEndingBalance: wizParsedStatementBal,
      ledgerRecordedSalesTotal: wizSelectedSalesTotal,
      bankDepositsMatchedTotal: wizSelectedSalesTotal,
      bankFeesAndCharges: wizParsedBankFees,
      interestOrAdjustments: wizParsedInterest,
      netReconciledAmount: wizNetExpectedDeposit,
      unreconciledVariance: wizVariance,
      status: isWizBalanced ? "Balanced" : "Discrepancy",
      reconciledBy: userProfileName,
      matchedSalesIds: wizSelectedSalesIds,
      depositReferenceNumber: wizDepositRef || `DEP-${Date.now().toString().slice(-6)}`,
      notes: wizNotes || `Reconciled ${wizSelectedSalesIds.length} sales records to ${currentWizDestination.name}`,
      createdAt: new Date().toISOString()
    };

    // Update runs
    const updatedRuns = [newRun, ...runs];
    saveRuns(updatedRuns);

    // Update reconciled items set
    const updatedReconciledSet = new Set(reconciledItemIds);
    wizSelectedSalesIds.forEach(id => updatedReconciledSet.add(id));
    setReconciledItemIds(updatedReconciledSet);

    // Update destination balance & last reconciled date
    const updatedDestinations = destinations.map(d => {
      if (d.id === currentWizDestination.id) {
        return {
          ...d,
          currentBalance: wizParsedStatementBal,
          lastReconciledDate: new Date().toISOString().substring(0, 10)
        };
      }
      return d;
    });
    saveDestinations(updatedDestinations);

    // Reset wizard
    setWizSelectedSalesIds([]);
    setWizStatementBalance("");
    setWizDepositRef("");
    setWizBankFees("0");
    setWizInterestAdj("0");
    setWizNotes("");

    // Show confirmation & switch tab
    alert(`Reconciliation ${runNum} successfully posted and locked! Status: ${isWizBalanced ? "BALANCED ✅" : "DISCREPANCY LOGGED ⚠️"}`);
    setActiveTab("history");
  };

  // Export Reconciliation Summary Report as PDF
  const handleExportPdfReport = (run: FarmerBankReconciliationRun) => {
    try {
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      let y = 15;

      // Header Banner
      doc.setFillColor(15, 23, 42); // Slate 900
      doc.rect(0, 0, 210, 24, "F");

      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.text("MABALA FINANCIAL INTEGRITY & AUDIT ENGINE", 14, 10);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.setTextColor(203, 213, 225);
      doc.text(`${farmName.toUpperCase()} • BANK RECONCILIATION SUMMARY REPORT`, 14, 17);

      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.setTextColor(52, 211, 153); // Emerald 400
      doc.text(`RUN REF: ${run.runNumber}`, 196, 10, { align: "right" });
      doc.text(`DATE: ${run.reconciliationDate}`, 196, 17, { align: "right" });

      y = 32;

      // Title Block
      doc.setTextColor(15, 23, 42);
      doc.setFontSize(15);
      doc.setFont("helvetica", "bold");
      doc.text("RECONCILIATION SUMMARY REPORT & AUDIT LEDGER", 14, y);
      y += 5.5;

      doc.setFontSize(8.5);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(100, 116, 139);
      doc.text(`Certified ledger summary showing opening balance, reconciled sales deposits, bank fees, and final audit closing balance.`, 14, y);
      y += 7.5;

      // Account & Period Info Box
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(14, y, 182, 22, 3, 3, "FD");

      doc.setFontSize(8);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(30, 41, 59);
      doc.text("DESTINATION ACCOUNT / WALLET:", 18, y + 6);
      doc.text("INSTITUTION & ACCOUNT NO:", 18, y + 12);
      doc.text("STATEMENT PERIOD:", 18, y + 18);

      doc.setFont("helvetica", "normal");
      doc.setTextColor(51, 65, 85);
      doc.text(`${run.destinationName} (${run.destinationType})`, 78, y + 6);
      doc.text(`${run.accountNumber} • ${run.destinationId}`, 78, y + 12);
      doc.text(`${run.periodStart} to ${run.periodEnd}`, 78, y + 18);

      doc.setFont("helvetica", "bold");
      doc.setTextColor(run.status === "Balanced" ? 16 : 225, run.status === "Balanced" ? 185 : 29, run.status === "Balanced" ? 129 : 72);
      doc.text(`AUDIT STATUS: ${run.status.toUpperCase()}`, 190, y + 6, { align: "right" });
      doc.text(`DEPOSIT REF: ${run.depositReferenceNumber || "N/A"}`, 190, y + 12, { align: "right" });

      y += 28;

      // Key Balances Metrics
      doc.setFontSize(10.5);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(15, 23, 42);
      doc.text("1. AUDIT BALANCES & MOVEMENTS SUMMARY", 14, y);
      y += 5;

      const colW = 43.5;
      const openingBal = (run.statementEndingBalance - run.netReconciledAmount + run.bankFeesAndCharges - run.interestOrAdjustments);
      const metrics = [
        { label: "OPENING BAL", val: `${currencySymbol} ${openingBal.toLocaleString(undefined, { minimumFractionDigits: 2 })}` },
        { label: "TOTAL DEPOSITS (+)", val: `+ ${currencySymbol} ${run.bankDepositsMatchedTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}` },
        { label: "FEES & ADJ. (-)", val: `- ${currencySymbol} ${(run.bankFeesAndCharges - run.interestOrAdjustments).toLocaleString(undefined, { minimumFractionDigits: 2 })}` },
        { label: "FINAL RECONCILED BAL", val: `${currencySymbol} ${run.netReconciledAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}` }
      ];

      metrics.forEach((m, idx) => {
        const cardX = 14 + idx * (colW + 2.5);
        doc.setFillColor(idx === 3 ? 240 : 250, idx === 3 ? 253 : 250, idx === 3 ? 244 : 250);
        doc.setDrawColor(idx === 3 ? 167 : 226, idx === 3 ? 243 : 232, idx === 3 ? 208 : 240);
        doc.roundedRect(cardX, y, colW, 17, 2, 2, "FD");

        doc.setFont("helvetica", "bold");
        doc.setFontSize(6.5);
        doc.setTextColor(100, 116, 139);
        doc.text(m.label, cardX + 3, y + 5);

        doc.setFontSize(9);
        doc.setTextColor(idx === 3 ? 6 : 15, idx === 3 ? 95 : 23, idx === 3 ? 70 : 42);
        doc.text(m.val, cardX + 3, y + 12.5);
      });

      y += 23;

      // Itemized Reconciled Ledger Table
      doc.setFontSize(10.5);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(15, 23, 42);
      doc.text("2. ITEMIZED RECONCILED SALES & REVENUE VOUCHERS", 14, y);
      y += 5.5;

      doc.setFillColor(30, 41, 59);
      doc.rect(14, y, 182, 7, "F");

      doc.setFontSize(7);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(255, 255, 255);
      doc.text("#", 17, y + 4.8);
      doc.text("DATE", 25, y + 4.8);
      doc.text("REF / TX ID", 45, y + 4.8);
      doc.text("DESCRIPTION / BUYER", 80, y + 4.8);
      doc.text("SOURCE MODULE", 135, y + 4.8);
      doc.text("AMOUNT", 192, y + 4.8, { align: "right" });

      y += 7;

      const matchedSet = new Set(run.matchedSalesIds || []);
      const matchedRecords = allSalesRecords.filter(r => matchedSet.has(r.id));
      const recordsToDisplay = matchedRecords.length > 0 ? matchedRecords : (run.matchedSalesIds || []).map((id) => ({
        id,
        date: run.reconciliationDate,
        sourceModule: "Reconciled Sale",
        title: `Reconciled Voucher ${id}`,
        customerOrBuyer: "Verified Buyer",
        amount: (run.bankDepositsMatchedTotal / Math.max(1, run.matchedSalesIds.length)),
        paymentChannel: "Bank / Wallet Deposit",
        referenceNumber: id,
        reconciliationStatus: "Reconciled" as const
      }));

      doc.setFontSize(7.5);
      doc.setFont("helvetica", "normal");

      recordsToDisplay.forEach((rec, idx) => {
        if (y > 265) {
          doc.addPage();
          y = 20;

          doc.setFillColor(30, 41, 59);
          doc.rect(14, y, 182, 7, "F");
          doc.setFontSize(7);
          doc.setFont("helvetica", "bold");
          doc.setTextColor(255, 255, 255);
          doc.text("#", 17, y + 4.8);
          doc.text("DATE", 25, y + 4.8);
          doc.text("REF / TX ID", 45, y + 4.8);
          doc.text("DESCRIPTION / BUYER", 80, y + 4.8);
          doc.text("SOURCE MODULE", 135, y + 4.8);
          doc.text("AMOUNT", 192, y + 4.8, { align: "right" });
          y += 7;
          doc.setFont("helvetica", "normal");
        }

        if (idx % 2 === 1) {
          doc.setFillColor(248, 250, 252);
          doc.rect(14, y, 182, 6, "F");
        }

        doc.setTextColor(51, 65, 85);
        doc.text((idx + 1).toString(), 17, y + 4.2);
        doc.text(rec.date || "-", 25, y + 4.2);
        doc.text((rec.referenceNumber || rec.id).substring(0, 16), 45, y + 4.2);
        doc.text((rec.title || "Produce Sale").substring(0, 32), 80, y + 4.2);
        doc.text(rec.sourceModule || "Sales", 135, y + 4.2);

        doc.setFont("helvetica", "bold");
        doc.setTextColor(16, 185, 129);
        doc.text(`+ ${currencySymbol} ${rec.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 192, y + 4.2, { align: "right" });
        doc.setFont("helvetica", "normal");

        y += 6;
      });

      doc.setDrawColor(226, 232, 240);
      doc.line(14, y + 2, 196, y + 2);
      y += 8;

      if (y > 230) {
        doc.addPage();
        y = 20;
      }

      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(203, 213, 225);
      doc.roundedRect(14, y, 182, 26, 3, 3, "FD");

      doc.setFontSize(8);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(30, 41, 59);
      doc.text("AUDIT CERTIFICATION & VERIFICATION NOTES:", 18, y + 6);

      doc.setFont("helvetica", "normal");
      doc.setTextColor(71, 85, 105);
      doc.text(run.notes || "All banking records verified against farm sales ledger with zero variance.", 18, y + 11, { maxWidth: 174 });

      doc.setFont("helvetica", "bold");
      doc.setFontSize(7.5);
      doc.text(`AUDITED BY: ${run.reconciledBy || userProfileName}`, 18, y + 21);
      doc.text(`TIMESTAMP: ${run.createdAt || new Date().toISOString()}`, 110, y + 21);

      doc.setFontSize(7);
      doc.setTextColor(148, 163, 184);
      doc.text(`Mabala Agro-Dealer Financial Engine • Official Reconciliation Ledger Report`, 105, 287, { align: "center" });

      doc.save(`Reconciliation_Report_${run.runNumber}.pdf`);
    } catch (err) {
      console.error("[BankReconciliationPanel] Error generating PDF report:", err);
      alert("An error occurred while generating the PDF report. Please try again.");
    }
  };

  // CSV Statement Presets Handler
  const handleLoadCsvPreset = (preset: "Airtel" | "MTN" | "Zanaco" | "StanChart") => {
    setCsvProviderPreset(preset);
    if (preset === "Airtel") {
      setCsvColMap({ dateCol: "0", descCol: "1", refCol: "2", depositCol: "3", withdrawalCol: "4" });
      const sample = `Date,Transaction ID,Details,Deposit Amount (ZMW),Withdrawal (ZMW),Balance\n2026-08-02,TX-AIRTEL-9011,Airtel MoMo - Maize Sales Collection,12500.00,0.00,12500.00\n2026-08-04,TX-AIRTEL-9018,Airtel MoMo - Tomato & Onion Produce,7800.00,0.00,20300.00\n2026-08-08,TX-AIRTEL-9025,Airtel MoMo - Poultry Delivery,4320.00,0.00,24620.00`;
      setCsvRawContent(sample);
      setCsvFileName("Airtel_Money_Statement.csv");
    } else if (preset === "MTN") {
      setCsvColMap({ dateCol: "0", descCol: "1", refCol: "2", depositCol: "3", withdrawalCol: "4" });
      const sample = `Txn Date,Narrative,Reference,Credit,Debit,Running Balance\n2026-08-01,MTN MoMo - Soybeans Batch 1,MTN-88102,15400.00,0.00,15400.00\n2026-08-05,MTN MoMo - Cabbage Sales,MTN-88109,3200.00,0.00,18600.00\n2026-08-09,MTN MoMo - Fertilizer Refund,MTN-88114,1800.00,0.00,20400.00`;
      setCsvRawContent(sample);
      setCsvFileName("MTN_MoMo_Statement.csv");
    } else if (preset === "Zanaco") {
      setCsvColMap({ dateCol: "0", descCol: "1", refCol: "2", depositCol: "3", withdrawalCol: "4" });
      const sample = `Post Date,Narrative,Reference,Credit Amount,Debit Amount,Book Balance\n2026-08-01,Direct Deposit - Commercial Grain Buyer,ZAN-DEP-773910,84620.00,0.00,84620.00\n2026-08-02,Bank Monthly Maintenance Fee,ZAN-FEE-0012,0.00,120.00,84500.00`;
      setCsvRawContent(sample);
      setCsvFileName("Zanaco_Bank_Statement.csv");
    } else if (preset === "StanChart") {
      setCsvColMap({ dateCol: "0", descCol: "1", refCol: "2", depositCol: "3", withdrawalCol: "4" });
      const sample = `Value Date,Description,Transaction Ref,Credit (CR),Debit (DR),Balance\n2026-08-03,SCB Transfer - Wholesale Produce,SCB-99812,22100.00,0.00,22100.00\n2026-08-06,SCB Transfer - Seed Invoices,SCB-99820,11500.00,0.00,33600.00`;
      setCsvRawContent(sample);
      setCsvFileName("StanChart_Bank_Statement.csv");
    }
  };

  const handleParseCsv = (contentToParse?: string) => {
    const raw = contentToParse || csvRawContent;
    if (!raw.trim()) {
      alert("Please paste or upload a CSV statement first.");
      return;
    }

    const lines = raw.trim().split(/\r?\n/);
    if (lines.length < 2) {
      alert("CSV must contain a header row and at least 1 data row.");
      return;
    }

    const headers = lines[0].split(/,|\t|;/).map(h => h.trim().replace(/^"|"$/g, ''));
    setCsvHeaders(headers);

    const rows: any[] = [];
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      const cols = line.split(/,|\t|;/).map(c => c.trim().replace(/^"|"$/g, ''));
      rows.push(cols);
    }

    setCsvParsedRows(rows);
    setCsvImportSuccessMsg(`Parsed ${rows.length} transaction entries from statement "${csvFileName || "Uploaded CSV"}".`);
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Header Banner & Navigation */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-xs uppercase tracking-widest">
            <Scale className="w-4 h-4" />
            <span>Financial Integrity & Cash Flow Audit</span>
          </div>
          <h2 className="text-xl font-black mt-1 text-white flex items-center gap-2">
            Bank & Mobile Money Reconciliation
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Reconcile farm sales, produce harvests, and invoice collections banked into commercial bank accounts or mobile money wallets (MTN MoMo & Airtel Money) with automated ledger matching.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start md:self-auto flex-wrap">
          <button
            onClick={() => setActiveTab("overview")}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === "overview" 
                ? "bg-emerald-500 text-slate-950 shadow-sm" 
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            <Building2 className="w-4 h-4" /> Account Overview
          </button>
          {!isReadonly && (
            <button
              onClick={() => setActiveTab("wizard")}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === "wizard" 
                  ? "bg-emerald-500 text-slate-950 shadow-sm" 
                  : "bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/50"
              }`}
            >
              <Zap className="w-4 h-4" /> Reconcile Now
            </button>
          )}

      {/* CSV STATEMENT IMPORT TAB */}
      {activeTab === "csv-import" && (
        <div className="space-y-6 animate-fade-in font-sans">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200 text-[10px] font-black uppercase font-mono">
                    Local Provider Statement Engine
                  </span>
                  <span className="text-xs font-bold text-slate-400 font-mono">CSV / TXT Parser</span>
                </div>
                <h3 className="text-lg font-black text-slate-900 mt-1 flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
                  Bank & Mobile Money CSV Statement Importer
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Import electronic statements from Airtel Money, MTN MoMo, Zanaco, Standard Chartered, Absa, and FNB to auto-match sales vouchers against bank deposits.
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => handleLoadCsvPreset("Airtel")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold border transition-all cursor-pointer ${
                    csvProviderPreset === "Airtel" 
                      ? "bg-red-600 text-white border-red-700 shadow-xs" 
                      : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
                  }`}
                >
                  📱 Airtel Money
                </button>
                <button
                  onClick={() => handleLoadCsvPreset("MTN")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold border transition-all cursor-pointer ${
                    csvProviderPreset === "MTN" 
                      ? "bg-amber-400 text-slate-950 border-amber-500 shadow-xs" 
                      : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
                  }`}
                >
                  📲 MTN MoMo
                </button>
                <button
                  onClick={() => handleLoadCsvPreset("Zanaco")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold border transition-all cursor-pointer ${
                    csvProviderPreset === "Zanaco" 
                      ? "bg-emerald-700 text-white border-emerald-800 shadow-xs" 
                      : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
                  }`}
                >
                  🏦 Zanaco Bank
                </button>
                <button
                  onClick={() => handleLoadCsvPreset("StanChart")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold border transition-all cursor-pointer ${
                    csvProviderPreset === "StanChart" 
                      ? "bg-indigo-700 text-white border-indigo-800 shadow-xs" 
                      : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
                  }`}
                >
                  💳 Commercial Banks
                </button>
              </div>
            </div>

            {/* Target Account Selection & File Upload */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-4 md:col-span-1 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Target Banking / Wallet Destination
                  </label>
                  <select
                    value={csvTargetDestinationId}
                    onChange={e => setCsvTargetDestinationId(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                  >
                    {destinations.map(d => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.institutionName})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Upload Statement File (.csv / .txt)
                  </label>
                  <div className="relative border-2 border-dashed border-slate-300 rounded-xl p-4 text-center hover:border-emerald-500 transition-colors bg-white">
                    <input
                      type="file"
                      accept=".csv,.txt"
                      onChange={e => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setCsvFileName(file.name);
                          const reader = new FileReader();
                          reader.onload = (evt) => {
                            const text = evt.target?.result as string;
                            setCsvRawContent(text);
                            handleParseCsv(text);
                          };
                          reader.readAsText(file);
                        }
                      }}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    <FileUp className="w-8 h-8 text-emerald-600 mx-auto mb-1" />
                    <span className="font-bold text-slate-700 block text-xs">Click or Drag CSV Statement</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">{csvFileName || "No file selected"}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200">
                  <button
                    onClick={() => handleParseCsv()}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs"
                  >
                    <Sparkles className="w-4 h-4 text-amber-300" /> Parse & Map Statement
                  </button>
                </div>
              </div>

              {/* Paste Text & Raw CSV View */}
              <div className="space-y-3 md:col-span-2 text-xs">
                <div className="flex justify-between items-center">
                  <label className="font-bold text-slate-700 uppercase tracking-wider text-[11px]">
                    Statement Raw Data / Content Preview
                  </label>
                  <span className="text-[10px] text-slate-400 font-mono">Auto-Separates Comma, Tab or Semicolon</span>
                </div>
                <textarea
                  value={csvRawContent}
                  onChange={e => setCsvRawContent(e.target.value)}
                  placeholder="Paste statement CSV rows here..."
                  rows={8}
                  className="w-full p-3 font-mono text-[11px] bg-slate-900 text-emerald-300 rounded-xl border border-slate-800 focus:ring-2 focus:ring-emerald-500 leading-relaxed resize-none"
                />
              </div>
            </div>

            {/* COLUMN MAPPING SELECTORS */}
            {csvHeaders.length > 0 && (
              <div className="p-4 bg-emerald-50/60 rounded-xl border border-emerald-200 space-y-3 animate-fade-in text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-emerald-950 flex items-center gap-1.5">
                    <Filter className="w-4 h-4 text-emerald-600" /> Statement Column Mapping Configuration
                  </span>
                  <span className="text-[10px] font-mono text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded font-bold">
                    Detected {csvHeaders.length} Header Columns
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-1">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Date Column</label>
                    <select
                      value={csvColMap.dateCol}
                      onChange={e => setCsvColMap({ ...csvColMap, dateCol: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded p-1.5 font-mono text-[11px] cursor-pointer"
                    >
                      {csvHeaders.map((h, i) => (
                        <option key={i} value={i.toString()}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Description / Payer</label>
                    <select
                      value={csvColMap.descCol}
                      onChange={e => setCsvColMap({ ...csvColMap, descCol: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded p-1.5 font-mono text-[11px] cursor-pointer"
                    >
                      {csvHeaders.map((h, i) => (
                        <option key={i} value={i.toString()}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Reference / TxID</label>
                    <select
                      value={csvColMap.refCol}
                      onChange={e => setCsvColMap({ ...csvColMap, refCol: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded p-1.5 font-mono text-[11px] cursor-pointer"
                    >
                      {csvHeaders.map((h, i) => (
                        <option key={i} value={i.toString()}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Deposit (+)</label>
                    <select
                      value={csvColMap.depositCol}
                      onChange={e => setCsvColMap({ ...csvColMap, depositCol: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded p-1.5 font-mono text-[11px] cursor-pointer"
                    >
                      {csvHeaders.map((h, i) => (
                        <option key={i} value={i.toString()}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Withdrawal (-)</label>
                    <select
                      value={csvColMap.withdrawalCol}
                      onChange={e => setCsvColMap({ ...csvColMap, withdrawalCol: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded p-1.5 font-mono text-[11px] cursor-pointer"
                    >
                      {csvHeaders.map((h, i) => (
                        <option key={i} value={i.toString()}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* PARSED STATEMENT TRANSACTIONS TABLE */}
            {csvParsedRows.length > 0 && (
              <div className="space-y-4 pt-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 text-white p-4 rounded-xl">
                  <div>
                    <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider font-mono">Statement Parse Analysis</div>
                    <div className="text-sm font-black mt-0.5">
                      {csvParsedRows.length} Parsed Transactions • Total Deposits: {currencySymbol}{" "}
                      {csvParsedRows.reduce((acc, row) => {
                        const val = parseFloat((row[parseInt(csvColMap.depositCol)] || "0").replace(/[^0-9.]/g, ''));
                        return acc + (isNaN(val) ? 0 : val);
                      }, 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      // Transfer matched items & totals to wizard!
                      const matchedIds: string[] = [];
                      let totalParsedDeposit = 0;
                      csvParsedRows.forEach(row => {
                        const dep = parseFloat((row[parseInt(csvColMap.depositCol)] || "0").replace(/[^0-9.]/g, ''));
                        if (!isNaN(dep) && dep > 0) {
                          totalParsedDeposit += dep;
                          const matchedSale = unreconciledSales.find(s => Math.abs(s.amount - dep) < 0.01);
                          if (matchedSale) matchedIds.push(matchedSale.id);
                        }
                      });

                      setWizDestinationId(csvTargetDestinationId);
                      if (matchedIds.length > 0) {
                        setWizSelectedSalesIds(matchedIds);
                      }
                      setWizStatementBalance(totalParsedDeposit.toFixed(2));
                      setWizDepositRef(csvFileName || "CSV-STATEMENT-IMPORT");
                      setActiveTab("wizard");
                      alert(`Successfully mapped statement data! Transferred ${matchedIds.length} matched sales vouchers to the Reconciliation Wizard.`);
                    }}
                    className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black px-4 py-2 rounded-lg text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md self-start sm:self-auto"
                  >
                    <ArrowUpRight className="w-4 h-4" /> Transfer to Reconciliation Wizard
                  </button>
                </div>

                <div className="overflow-x-auto border border-slate-200 rounded-xl">
                  <table className="w-full text-left border-collapse text-xs font-sans">
                    <thead>
                      <tr className="bg-slate-100 border-b border-slate-200 text-slate-500 font-extrabold uppercase text-[10px]">
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">Ref / TxID</th>
                        <th className="py-2.5 px-3">Narrative / Description</th>
                        <th className="py-2.5 px-3 text-right">Deposit (+ ZMW)</th>
                        <th className="py-2.5 px-3 text-right">Withdrawal (- ZMW)</th>
                        <th className="py-2.5 px-3 text-center">Ledger Auto-Match Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {csvParsedRows.map((row, idx) => {
                        const dateVal = row[parseInt(csvColMap.dateCol)] || "-";
                        const descVal = row[parseInt(csvColMap.descCol)] || "Transaction";
                        const refVal = row[parseInt(csvColMap.refCol)] || `ROW-${idx + 1}`;
                        const depositVal = parseFloat((row[parseInt(csvColMap.depositCol)] || "0").replace(/[^0-9.]/g, ''));
                        const withdrawalVal = parseFloat((row[parseInt(csvColMap.withdrawalCol)] || "0").replace(/[^0-9.]/g, ''));

                        const matchedSale = unreconciledSales.find(s => Math.abs(s.amount - (isNaN(depositVal) ? 0 : depositVal)) < 0.01);

                        return (
                          <tr key={idx} className="hover:bg-slate-50 transition-colors">
                            <td className="py-2.5 px-3 font-mono text-[11px]">{dateVal}</td>
                            <td className="py-2.5 px-3 font-mono font-bold text-slate-800">{refVal}</td>
                            <td className="py-2.5 px-3 text-slate-900 font-medium">{descVal}</td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-600">
                              {!isNaN(depositVal) && depositVal > 0 ? `+ ${currencySymbol} ${depositVal.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : "-"}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono text-slate-500">
                              {!isNaN(withdrawalVal) && withdrawalVal > 0 ? `- ${currencySymbol} ${withdrawalVal.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : "-"}
                            </td>
                            <td className="py-2.5 px-3 text-center">
                              {matchedSale ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-200">
                                  <Check className="w-3 h-3 text-emerald-600" /> Matched: {matchedSale.id} ({matchedSale.sourceModule})
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-400 text-[10px] font-mono">
                                  Unmatched
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
          <button
            onClick={() => setActiveTab("csv-import")}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === "csv-import" 
                ? "bg-emerald-500 text-slate-950 shadow-sm" 
                : "bg-indigo-900/60 text-indigo-300 border border-indigo-700/60 hover:bg-indigo-800/80"
            }`}
          >
            <FileSpreadsheet className="w-4 h-4 text-amber-400" /> CSV Statement Import
          </button>
          <button
            onClick={() => setActiveTab("history")}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === "history" 
                ? "bg-emerald-500 text-slate-950 shadow-sm" 
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            <Clock className="w-4 h-4" /> Audit Runs ({runs.length})
          </button>
          <button
            onClick={() => setActiveTab("destinations")}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === "destinations" 
                ? "bg-emerald-500 text-slate-950 shadow-sm" 
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            <Landmark className="w-4 h-4" /> Accounts & Wallets ({destinations.length})
          </button>
        </div>
      </div>

      {/* OVERVIEW TAB */}
      {activeTab === "overview" && (
        <div className="space-y-6 animate-fade-in">
          {/* Key Stat Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider">Total Banked / Reconciled</span>
                <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-100">
                  <CheckCircle2 className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-black text-slate-800 mt-2">
                {currencySymbol} {totalReconciledAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] text-emerald-600 font-semibold mt-1">
                Verified against bank & wallet statements
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider">Unreconciled Cash / Sales</span>
                <span className="p-1.5 rounded-lg bg-amber-50 text-amber-600 border border-amber-100">
                  <AlertTriangle className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-black text-amber-600 mt-2">
                {currencySymbol} {totalUnreconciledAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] text-slate-500 font-medium mt-1">
                {unreconciledSales.length} sales pending bank deposit verification
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider">Total Banking Balances</span>
                <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600 border border-indigo-100">
                  <Building2 className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-black text-indigo-700 mt-2">
                {currencySymbol} {totalBankBalances.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] text-slate-400 font-medium mt-1">
                Combined liquid funds across {destinations.length} accounts
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider">Audit Health Status</span>
                <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-100">
                  <ShieldCheck className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-black text-emerald-600 mt-2 flex items-center gap-1">
                <span>98.4%</span>
                <span className="text-xs text-slate-400 font-normal">Matched</span>
              </div>
              <div className="text-[10px] text-emerald-600 font-semibold mt-1">
                IFRS & Tax Audit Compliant
              </div>
            </div>
          </div>

          {/* Accounts & Mobile Money Wallets Quick Cards */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-5 pb-4 border-b border-slate-100">
              <div>
                <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                  <Landmark className="w-4 h-4 text-emerald-600" />
                  <span>Configured Banking Accounts & Mobile Money Wallets</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">Select an account to start reconciling sales deposits or mobile money transfers.</p>
              </div>
              {!isReadonly && (
                <button
                  onClick={() => setShowAddDestModal(true)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-1.5 px-3 rounded-lg flex items-center gap-1.5 transition-all shadow cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Bank Account / Wallet
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {destinations.map(dest => (
                <div 
                  key={dest.id}
                  className="bg-slate-50 rounded-xl p-4 border border-slate-200 hover:border-emerald-500/50 transition-all flex flex-col justify-between group"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                        dest.type === "Bank Account" 
                          ? "bg-blue-100 text-blue-800 border border-blue-200"
                          : dest.type === "Mobile Money Wallet"
                          ? "bg-amber-100 text-amber-800 border border-amber-200"
                          : "bg-emerald-100 text-emerald-800 border border-emerald-200"
                      }`}>
                        {dest.type === "Bank Account" ? "🏛️ Bank" : dest.type === "Mobile Money Wallet" ? "📱 MoMo" : "💵 Cash Safe"}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {dest.lastReconciledDate ? `Rec: ${dest.lastReconciledDate}` : "Unreconciled"}
                      </span>
                    </div>

                    <h4 className="font-bold text-slate-900 text-sm mt-3 group-hover:text-emerald-700 transition-colors">
                      {dest.name}
                    </h4>
                    <p className="text-[11px] text-slate-500 font-mono mt-0.5">{dest.institutionName} • {dest.accountNumber}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200/80 flex items-end justify-between">
                    <div>
                      <div className="text-[9px] uppercase font-extrabold text-slate-400">Statement Balance</div>
                      <div className="text-base font-black text-slate-800">
                        {currencySymbol} {dest.currentBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                    </div>
                    {!isReadonly && (
                      <button
                        onClick={() => {
                          setWizDestinationId(dest.id);
                          setActiveTab("wizard");
                        }}
                        className="bg-white hover:bg-emerald-50 text-emerald-700 border border-slate-200 hover:border-emerald-300 text-[11px] font-bold px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                      >
                        Reconcile <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Unreconciled Sales & Revenues Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  <span>Unreconciled Sales & Revenue Queue</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">Recorded produce sales, livestock orders, and grant receipts requiring bank deposit matching.</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 border border-amber-200 text-[10px] font-bold">
                  {unreconciledSales.length} Items Unreconciled
                </span>
                {!isReadonly && unreconciledSales.length > 0 && (
                  <button
                    onClick={() => setActiveTab("wizard")}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-1 px-3 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
                  >
                    Start Matching <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-500 font-extrabold uppercase text-[10px]">
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Source Module</th>
                    <th className="py-3 px-4">Title / Transaction</th>
                    <th className="py-3 px-4">Customer / Buyer</th>
                    <th className="py-3 px-4">Payment Channel</th>
                    <th className="py-3 px-4 text-right">Amount ({currencySymbol})</th>
                    <th className="py-3 px-4 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {allSalesRecords.slice(0, 10).map((record) => (
                    <tr key={record.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono text-[11px] font-semibold">{record.date}</td>
                      <td className="py-3 px-4 font-bold text-slate-800">{record.sourceModule}</td>
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{record.title}</div>
                        {record.referenceNumber && (
                          <div className="text-[10px] text-slate-400 font-mono">Ref: {record.referenceNumber}</div>
                        )}
                      </td>
                      <td className="py-3 px-4 font-medium">{record.customerOrBuyer}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          record.paymentChannel === "Mobile Money" 
                            ? "bg-amber-50 text-amber-700 border border-amber-200"
                            : record.paymentChannel === "Bank Transfer"
                            ? "bg-blue-50 text-blue-700 border border-blue-200"
                            : "bg-emerald-50 text-emerald-700 border border-emerald-200"
                        }`}>
                          {record.paymentChannel}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-black text-slate-900">
                        {record.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                          record.reconciliationStatus === "Reconciled"
                            ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                            : "bg-amber-100 text-amber-800 border border-amber-200"
                        }`}>
                          {record.reconciliationStatus === "Reconciled" ? "✅ Reconciled" : "⏳ Unreconciled"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* RECONCILIATION WIZARD TAB */}
      {activeTab === "wizard" && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-6">
              <div>
                <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                  <Zap className="w-5 h-5 text-emerald-600" />
                  <span>Interactive Reconciliation Engine & Matching Wizard</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">Match recorded sales vouchers with bank statement credits or mobile money wallet receipts.</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleSmartMatch}
                  className="bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 text-xs font-extrabold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" /> Smart Auto-Match
                </button>
              </div>
            </div>

            {/* Step 1: Target Destination & Statement Inputs */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 mb-6">
              <div className="space-y-1">
                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">Target Bank Account / Wallet</label>
                <select
                  value={wizDestinationId}
                  onChange={e => setWizDestinationId(e.target.value)}
                  className="w-full text-xs font-bold p-2 border border-slate-300 bg-white rounded-lg focus:outline-none focus:border-emerald-500"
                >
                  {destinations.map(d => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.institutionName})
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">Period Start - End</label>
                <div className="flex items-center gap-1">
                  <input
                    type="date"
                    value={wizPeriodStart}
                    onChange={e => setWizPeriodStart(e.target.value)}
                    className="w-1/2 text-xs p-1.5 border border-slate-300 bg-white rounded-lg focus:outline-none"
                  />
                  <span className="text-slate-400 text-xs font-bold">-</span>
                  <input
                    type="date"
                    value={wizPeriodEnd}
                    onChange={e => setWizPeriodEnd(e.target.value)}
                    className="w-1/2 text-xs p-1.5 border border-slate-300 bg-white rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">Statement Ending Balance ({currencySymbol})</label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="e.g. 84500.00"
                  value={wizStatementBalance}
                  onChange={e => setWizStatementBalance(e.target.value)}
                  className="w-full text-xs font-black p-2 border border-slate-300 bg-white rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">Bank Deposit Ref / TxID</label>
                <input
                  type="text"
                  placeholder="e.g. ZAN-DEP-9921 or MoMo TxID"
                  value={wizDepositRef}
                  onChange={e => setWizDepositRef(e.target.value)}
                  className="w-full text-xs p-2 border border-slate-300 bg-white rounded-lg focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Step 2: Unreconciled Sales Selection Grid */}
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider">Unreconciled Sales Records ({wizFilteredSales.length})</h4>
                  <button
                    onClick={selectAllWizardSales}
                    className="text-[10px] font-bold text-emerald-700 underline hover:text-emerald-800 cursor-pointer"
                  >
                    {wizSelectedSalesIds.length === wizFilteredSales.length ? "Deselect All" : "Select All Filtered"}
                  </button>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <div className="relative flex-1 sm:w-48">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    <input
                      type="text"
                      placeholder="Search title, ref, buyer..."
                      value={wizSearchFilter}
                      onChange={e => setWizSearchFilter(e.target.value)}
                      className="w-full text-xs pl-8 pr-2 py-1.5 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                  <select
                    value={wizSourceModuleFilter}
                    onChange={e => setWizSourceModuleFilter(e.target.value)}
                    className="text-xs p-1.5 border border-slate-200 rounded-lg bg-white font-medium"
                  >
                    <option value="All">All Modules</option>
                    <option value="Cash Sales">Cash Sales</option>
                    <option value="Crop Sales">Crop Sales</option>
                    <option value="Livestock & Poultry">Livestock & Poultry</option>
                    <option value="Invoices & Receivables">Invoices</option>
                    <option value="Other Revenue">Other Revenue</option>
                  </select>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden max-h-80 overflow-y-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="sticky top-0 bg-slate-100 border-b border-slate-200 text-slate-500 font-extrabold text-[10px] uppercase">
                    <tr>
                      <th className="p-3 text-center w-10">Select</th>
                      <th className="p-3">Date</th>
                      <th className="p-3">Source</th>
                      <th className="p-3">Sales Voucher / Description</th>
                      <th className="p-3">Customer</th>
                      <th className="p-3">Channel</th>
                      <th className="p-3 text-right">Amount ({currencySymbol})</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {wizFilteredSales.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="p-8 text-center text-slate-400 font-medium">
                          No unreconciled sales found matching your criteria.
                        </td>
                      </tr>
                    ) : (
                      wizFilteredSales.map(sale => {
                        const isSelected = wizSelectedSalesIds.includes(sale.id);
                        return (
                          <tr 
                            key={sale.id}
                            onClick={() => toggleWizardSaleSelect(sale.id)}
                            className={`cursor-pointer transition-colors ${
                              isSelected ? "bg-emerald-50/80 font-semibold" : "hover:bg-slate-50"
                            }`}
                          >
                            <td className="p-3 text-center">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => {}}
                                className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500 cursor-pointer"
                              />
                            </td>
                            <td className="p-3 font-mono text-[11px]">{sale.date}</td>
                            <td className="p-3 font-bold text-slate-800">{sale.sourceModule}</td>
                            <td className="p-3 font-bold text-slate-900">{sale.title}</td>
                            <td className="p-3 text-slate-600">{sale.customerOrBuyer}</td>
                            <td className="p-3">
                              <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-bold">
                                {sale.paymentChannel}
                              </span>
                            </td>
                            <td className="p-3 text-right font-black text-slate-900">
                              {sale.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Step 3: Bank Charges, Fee Adjustments & Live Audit Reconciliation Bar */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 mt-6">
              <div className="space-y-3">
                <h4 className="font-extrabold text-xs text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4" /> Bank Fees & Adjustments
                </h4>
                <div className="space-y-2">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      Bank Charges / MoMo Cashout Fees ({currencySymbol})
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={wizBankFees}
                      onChange={e => setWizBankFees(e.target.value)}
                      placeholder="0.00"
                      className="w-full text-xs p-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      Interest Earned / Direct Credit Adjustments ({currencySymbol})
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={wizInterestAdj}
                      onChange={e => setWizInterestAdj(e.target.value)}
                      placeholder="0.00"
                      className="w-full text-xs p-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Live Reconciliation Calculations */}
              <div className="space-y-2 text-xs border-y md:border-y-0 md:border-x border-slate-800 py-3 md:py-0 md:px-6">
                <h4 className="font-extrabold text-xs text-emerald-400 uppercase tracking-wider mb-2">
                  Live Audit Variance Calculation
                </h4>
                <div className="flex justify-between text-slate-300">
                  <span>Selected Sales Total ({wizSelectedSalesIds.length}):</span>
                  <span className="font-mono font-bold text-white">{currencySymbol} {wizSelectedSalesTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Less: Bank/MoMo Fees:</span>
                  <span className="font-mono font-bold text-rose-400">- {currencySymbol} {wizParsedBankFees.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Plus: Interest / Credits:</span>
                  <span className="font-mono font-bold text-emerald-400">+ {currencySymbol} {wizParsedInterest.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="border-t border-slate-800 pt-2 flex justify-between font-bold text-white text-sm">
                  <span>Expected Net Deposit:</span>
                  <span className="font-mono text-emerald-400">{currencySymbol} {wizNetExpectedDeposit.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>Statement Ending Balance:</span>
                  <span className="font-mono text-white font-bold">{currencySymbol} {wizParsedStatementBal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Status Badge & Action */}
              <div className="flex flex-col justify-between space-y-4">
                <div>
                  <div className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider">Audit Result</div>
                  <div className="mt-1">
                    {isWizBalanced ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-black text-xs uppercase tracking-wider">
                        <CheckCircle2 className="w-4 h-4" /> BALANCED (ZK 0.00 Variance)
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 font-black text-xs uppercase tracking-wider">
                        <AlertTriangle className="w-4 h-4" /> DISCREPANCY ({currencySymbol} {wizVariance.toFixed(2)})
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400 mt-2">
                    {isWizBalanced 
                      ? "Book ledger sales match the bank statement cutoff balance exactly."
                      : "Adjust selected sales or bank fees to resolve the variance before locking."}
                  </p>
                </div>

                <button
                  onClick={handleExecuteReconciliation}
                  disabled={wizSelectedSalesIds.length === 0 || !wizStatementBalance}
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" /> Post & Lock Reconciliation Run
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* HISTORY TAB */}
      {activeTab === "history" && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden animate-fade-in">
          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-600" />
                <span>Reconciliation Audit History</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">Historical records of verified bank and mobile money reconciliation runs.</p>
            </div>
            <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-extrabold">
              {runs.length} Completed Runs
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-500 font-extrabold uppercase text-[10px]">
                  <th className="py-3 px-4">Run #</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Destination Account</th>
                  <th className="py-3 px-4">Matched Items</th>
                  <th className="py-3 px-4 text-right">Reconciled Amount ({currencySymbol})</th>
                  <th className="py-3 px-4 text-right">Variance ({currencySymbol})</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {runs.map(run => (
                  <tr key={run.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-emerald-700">{run.runNumber}</td>
                    <td className="py-3 px-4 font-mono text-[11px]">{run.reconciliationDate}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      <div>{run.destinationName}</div>
                      <div className="text-[10px] text-slate-400 font-normal font-mono">{run.destinationType} • {run.accountNumber}</div>
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-700">{run.matchedSalesIds.length} Sales Vouchers</td>
                    <td className="py-3 px-4 text-right font-black text-slate-900">
                      {run.netReconciledAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold">
                      {run.unreconciledVariance === 0 ? (
                        <span className="text-emerald-600">0.00</span>
                      ) : (
                        <span className="text-amber-600">{run.unreconciledVariance.toFixed(2)}</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                        run.status === "Balanced" 
                          ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                          : "bg-amber-100 text-amber-800 border border-amber-200"
                      }`}>
                        {run.status === "Balanced" ? "✅ BALANCED" : "⚠️ DISCREPANCY"}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setSelectedRunForView(run)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                          title="View Reconciliation Certificate"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleExportPdfReport(run)}
                          className="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 transition-colors cursor-pointer flex items-center gap-1 text-[11px] font-bold"
                          title="Download Reconciliation Summary PDF Ledger Report"
                        >
                          <Download className="w-3.5 h-3.5 text-emerald-600" /> PDF
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* DESTINATIONS TAB */}
      {activeTab === "destinations" && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 animate-fade-in space-y-6">
          <div className="flex justify-between items-center pb-4 border-b border-slate-100">
            <div>
              <h3 className="font-extrabold text-slate-800 text-base">Banking Accounts & Mobile Money Wallets</h3>
              <p className="text-xs text-slate-500 mt-0.5">Manage bank accounts, mobile money merchant numbers, and cash drawers.</p>
            </div>
            {!isReadonly && (
              <button
                onClick={() => setShowAddDestModal(true)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2 px-3.5 rounded-lg flex items-center gap-1.5 transition-all shadow cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Add Destination
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {destinations.map(d => (
              <div key={d.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider block">{d.type}</span>
                    <h4 className="font-black text-slate-900 text-sm mt-0.5">{d.name}</h4>
                    <p className="text-xs font-mono text-slate-600 mt-0.5">{d.institutionName} • {d.accountNumber}</p>
                  </div>
                  <span className="text-xs font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-lg">
                    {currencySymbol} {d.currentBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                {d.notes && <p className="text-xs text-slate-500 italic">{d.notes}</p>}
                <div className="pt-2 border-t border-slate-200/60 flex justify-between text-[11px] text-slate-400 font-mono">
                  <span>Last Rec: {d.lastReconciledDate || "N/A"}</span>
                  <span className="text-emerald-600 font-bold">Active Node</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: ADD DESTINATION */}
      {showAddDestModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                <Landmark className="w-4 h-4 text-emerald-600" />
                <span>Add Bank Account or Mobile Money Wallet</span>
              </h3>
              <button 
                onClick={() => setShowAddDestModal(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddDestinationSubmit} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-600 uppercase text-[10px]">Account / Wallet Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Stanbic Operating Account"
                  value={destName}
                  onChange={e => setDestName(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-600 uppercase text-[10px]">Type</label>
                  <select
                    value={destType}
                    onChange={e => setDestType(e.target.value as BankingDestinationType)}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white focus:outline-none"
                  >
                    <option value="Bank Account">Bank Account</option>
                    <option value="Mobile Money Wallet">Mobile Money Wallet</option>
                    <option value="Cash Box / Drawer">Cash Box / Drawer</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-600 uppercase text-[10px]">Institution</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. ZANACO / Airtel / MTN"
                    value={destInst}
                    onChange={e => setDestInst(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-600 uppercase text-[10px]">Account / Phone Number</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 102938475601 or +260..."
                    value={destAccountNum}
                    onChange={e => setDestAccountNum(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-500 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-600 uppercase text-[10px]">Starting Balance ({currencySymbol})</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={destInitBal}
                    onChange={e => setDestInitBal(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-500 font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-600 uppercase text-[10px]">Notes / Purpose</label>
                <textarea
                  rows={2}
                  placeholder="Optional notes..."
                  value={destNotes}
                  onChange={e => setDestNotes(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg focus:outline-none"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddDestModal(false)}
                  className="px-3 py-2 rounded-lg bg-slate-100 text-slate-700 font-bold hover:bg-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-emerald-600 text-white font-bold hover:bg-emerald-700 shadow"
                >
                  Save Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: VIEW RECONCILIATION RUN CERTIFICATE */}
      {selectedRunForView && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 space-y-5">
            <div className="flex justify-between items-start border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200 text-[10px] font-black uppercase">
                    Official Audit Certificate
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-400">{selectedRunForView.runNumber}</span>
                </div>
                <h3 className="text-lg font-black text-slate-900 mt-1">Bank Reconciliation Statement</h3>
                <p className="text-xs text-slate-500 font-mono">Farm: {farmName} • Reconciled By: {selectedRunForView.reconciledBy}</p>
              </div>
              <button 
                onClick={() => setSelectedRunForView(null)}
                className="text-slate-400 hover:text-slate-600 text-xl font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Destination Account</span>
                  <p className="font-bold text-slate-900">{selectedRunForView.destinationName}</p>
                  <p className="text-[11px] text-slate-500 font-mono">{selectedRunForView.destinationType} ({selectedRunForView.accountNumber})</p>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Statement Period</span>
                  <p className="font-bold text-slate-900">{selectedRunForView.periodStart} to {selectedRunForView.periodEnd}</p>
                  <p className="text-[11px] text-slate-500">Deposit Ref: {selectedRunForView.depositReferenceNumber}</p>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl p-4 space-y-2 bg-slate-900 text-white font-mono text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>Statement Ending Balance:</span>
                  <span className="font-bold text-white">{currencySymbol} {selectedRunForView.statementEndingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Sales & Revenue Vouchers Matched ({selectedRunForView.matchedSalesIds.length}):</span>
                  <span className="font-bold text-emerald-400">{currencySymbol} {selectedRunForView.ledgerRecordedSalesTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Less: Bank / Mobile Money Charges:</span>
                  <span className="font-bold text-rose-400">- {currencySymbol} {selectedRunForView.bankFeesAndCharges.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Plus: Interest / Adjustments:</span>
                  <span className="font-bold text-emerald-400">+ {currencySymbol} {selectedRunForView.interestOrAdjustments.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="border-t border-slate-800 pt-2 flex justify-between font-bold text-white text-sm font-sans">
                  <span>Audit Variance:</span>
                  <span className={selectedRunForView.unreconciledVariance === 0 ? "text-emerald-400" : "text-amber-400"}>
                    {currencySymbol} {selectedRunForView.unreconciledVariance.toFixed(2)} ({selectedRunForView.status})
                  </span>
                </div>
              </div>

              {selectedRunForView.notes && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-slate-600 italic">
                  "{selectedRunForView.notes}"
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
              <span className="text-[10px] text-slate-400 font-mono">Generated on {new Date(selectedRunForView.createdAt).toLocaleString()}</span>
              <div className="flex gap-2">
                <button
                  onClick={() => handleExportPdfReport(selectedRunForView)}
                  className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" /> Download PDF Report
                </button>
                <button
                  onClick={() => {
                    window.print();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center gap-1 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" /> Print Audit Sheet
                </button>
                <button
                  onClick={() => setSelectedRunForView(null)}
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useState, useEffect, useMemo } from "react";
import { Invoice, CreditNote, Quotation, Customer, InvoiceLine, CropCycle, LivestockRecord, PoultryBatch, Farm } from "../types";
import { jsPDF } from "jspdf";
import { getStatutoryTaxConfig, subscribeTaxConfig } from "../services/taxConfigService";
import { OrchardFinanceService } from "../services/orchardFinanceService";
import { 
  Plus, 
  Check, 
  FileCheck, 
  DollarSign, 
  Download, 
  ArrowRight, 
  CornerDownRight, 
  Users, 
  Receipt, 
  FileText, 
  Archive, 
  Search, 
  BadgeHelp, 
  CheckCircle,
  Clock,
  Printer,
  ChevronRight,
  RefreshCw,
  CheckSquare,
  Mail,
  Sparkles,
  Boxes,
  Beef,
  Trees,
  Egg,
  Wheat,
  Tag,
  ShieldCheck,
  Building,
  Calculator,
  Tractor
} from "lucide-react";
import NewSaleModal from "./sales/NewSaleModal";
import TaxCalculatorTool from "./tax/TaxCalculatorTool";
import { InvoiceDeadlineNotificationService, DeadlineApproachingInvoice } from "../services/invoiceDeadlineNotificationService";

interface InvoicesPanelProps {
  invoices: Invoice[];
  creditNotes?: CreditNote[];
  quotations: Quotation[];
  customers: Customer[];
  crops: CropCycle[];
  livestock?: LivestockRecord[];
  poultryBatches?: PoultryBatch[];
  farms?: Farm[];
  onAddInvoice: (inv: Invoice) => void;
  onAddCreditNote?: (cn: CreditNote) => void;
  onAddQuotation: (qt: Quotation) => void;
  onMarkPaid: (id: string, paymentAmount?: number) => void;
  onConvertQuote: (quote: Quotation) => void;
  onAddCustomer: (cus: Customer) => void;
  isReadonly: boolean;
  currencySymbol: string;
  activeFarm?: any;
  onNavigateToOfftaker?: () => void;
  userRole?: string;
  userProfile?: any;
}

export default function InvoicesPanel({
  invoices,
  creditNotes = [],
  quotations,
  customers,
  crops,
  livestock = [],
  poultryBatches = [],
  farms = [],
  onAddInvoice,
  onAddCreditNote,
  onAddQuotation,
  onMarkPaid,
  onConvertQuote,
  onAddCustomer,
  isReadonly,
  currencySymbol,
  activeFarm,
  onNavigateToOfftaker,
  userRole,
  userProfile
}: InvoicesPanelProps) {
  const [activeSegment, setActiveSegment] = useState<"invoices" | "quotations" | "customers" | "credit_notes">("invoices");
  const [showAddForm, setShowAddForm] = useState(false);

  const isFarmOwner = useMemo(() => {
    const roleLower = String(userRole || userProfile?.role || "").toLowerCase();
    const typeLower = String(userProfile?.tenantType || "").toLowerCase();
    if (typeLower === "super_admin" || roleLower.includes("super admin") || roleLower.includes("platform admin")) return true;
    if (roleLower.includes("owner") || roleLower === "farm owner" || roleLower === "farmer" || roleLower === "administrator") return true;
    if (userProfile?.email && activeFarm?.ownerEmail && userProfile.email === activeFarm.ownerEmail) return true;
    return !roleLower || roleLower === "farm owner";
  }, [userRole, userProfile, activeFarm]);

  const handleDownloadInvoicesCSV = () => {
    // Generate secure CSV of invoices
    const headers = ["Reference ID", "Customer Name", "Due Deadline", "Line Product/Description", "Line Quantity", "Line Unit Price", "Line Amount", "Invoiced Sum", "Collected Amount", "Status"];
    const csvRows = [headers.join(",")];

    const getPaidAmount = (inv: Invoice) => {
      if ((inv.status as string) === "Paid") return inv.total;
      if ((inv.status as string) === "Part Paid" && inv.paidAmount) return inv.paidAmount;
      return 0;
    };

    for (const inv of invoices) {
      const paid = getPaidAmount(inv);
      for (const line of inv.lines) {
        const row = [
          `"${inv.id}"`,
          `"${(inv.customerName || "").replace(/"/g, '""')}"`,
          `"${inv.dueDate}"`,
          `"${(line.description || "").replace(/"/g, '""')}"`,
          line.quantity,
          line.unitPrice.toFixed(2),
          line.amount.toFixed(2),
          inv.total.toFixed(2),
          paid.toFixed(2),
          `"${inv.status}"`
        ];
        csvRows.push(row.join(","));
      }
    }

    const csvContent = "data:text/csv;charset=utf-8," + csvRows.join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `mabala_invoices_registry_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [showNewSaleModal, setShowNewSaleModal] = useState(false);

  // Bulk actions states and handlers
  const [selectedInvoiceIds, setSelectedInvoiceIds] = useState<string[]>([]);
  const [bulkMsg, setBulkMsg] = useState<string | null>(null);

  const handleBulkMarkPaid = () => {
    const unpaidSelected = invoices.filter(inv => selectedInvoiceIds.includes(inv.id) && inv.status !== "Paid" && !inv.status.startsWith("Cancelled"));
    if (unpaidSelected.length === 0) {
      setBulkMsg("No unpaid or non-cancelled invoices selected.");
      return;
    }
    unpaidSelected.forEach(inv => {
      const paid = getPaidAmount(inv);
      const remaining = inv.total - paid;
      onMarkPaid(inv.id, remaining);
    });
    setBulkMsg(`Successfully marked ${unpaidSelected.length} invoices as Paid!`);
    setSelectedInvoiceIds([]);
    setTimeout(() => setBulkMsg(null), 4000);
  };

  const [sendingDeadlineReminders, setSendingDeadlineReminders] = useState(false);
  const [approachingCount, setApproachingCount] = useState<number>(0);

  const handleBulkSendReminders = async () => {
    const unpaidSelected = invoices.filter(inv => selectedInvoiceIds.includes(inv.id) && inv.status !== "Paid" && !inv.status.startsWith("Cancelled"));
    if (unpaidSelected.length === 0) {
      setBulkMsg("No unpaid selected invoices to send reminders for.");
      return;
    }

    setSendingDeadlineReminders(true);
    setBulkMsg(`Dispatching payment deadline notifications to ${unpaidSelected.length} farmer client(s) via Hostinger SMTP...`);
    try {
      const report = await InvoiceDeadlineNotificationService.sendAutomaticPaymentDeadlineReminders(
        unpaidSelected,
        {
          farmName: activeFarm?.name || userProfile?.workspaceName || "Mabala Digital Farm Network",
          farmEmail: activeFarm?.email || userProfile?.email || "billing@mabala.cloud",
          farmPhone: activeFarm?.phone || userProfile?.phoneNumber || ""
        }
      );

      if (report.sentCount > 0) {
        setBulkMsg(`Successfully dispatched ${report.sentCount} payment deadline reminder email(s) via SMTP!`);
      } else if (report.skippedCount > 0 && report.failedCount === 0) {
        setBulkMsg(`Scan complete: ${report.skippedCount} invoice(s) already have recent notification logs.`);
      } else {
        setBulkMsg(`Notification run complete: ${report.sentCount} sent, ${report.failedCount} errors.`);
      }
      setSelectedInvoiceIds([]);
    } catch (err: any) {
      setBulkMsg(`Payment deadline dispatch failed: ${err.message || "Unknown error"}`);
    } finally {
      setSendingDeadlineReminders(false);
      setTimeout(() => setBulkMsg(null), 6000);
    }
  };

  const handleScanAndNotifyUpcomingDeadlines = async () => {
    setSendingDeadlineReminders(true);
    setBulkMsg("Scanning all invoices for upcoming payment deadlines (within 3 days or due today)...");
    try {
      const report = await InvoiceDeadlineNotificationService.scanAndNotifyApproachingDeadlines(
        invoices,
        {
          thresholdDays: 3,
          forceSend: true,
          tenantContext: {
            farmName: activeFarm?.name || userProfile?.workspaceName || "Mabala Digital Farm Network",
            farmEmail: activeFarm?.email || userProfile?.email || "billing@mabala.cloud",
            farmPhone: activeFarm?.phone || userProfile?.phoneNumber || ""
          }
        }
      );

      setApproachingCount(report.approachingCount);
      if (report.sentCount > 0) {
        setBulkMsg(`Automated Deadline Scan: Dispatched ${report.sentCount} email notification(s) to farmers with approaching deadlines via Hostinger SMTP!`);
      } else {
        setBulkMsg(`Automated Deadline Scan: ${report.approachingCount} approaching deadline(s) found. ${report.skippedCount} already notified recently.`);
      }
    } catch (err: any) {
      setBulkMsg(`Automated deadline scan encountered an error: ${err.message}`);
    } finally {
      setSendingDeadlineReminders(false);
      setTimeout(() => setBulkMsg(null), 6000);
    }
  };

  useEffect(() => {
    if (invoices && invoices.length > 0) {
      const approaching = InvoiceDeadlineNotificationService.scanApproachingDeadlineInvoices(invoices, 3);
      setApproachingCount(approaching.length);
    }
  }, [invoices]);

  // New Customer Form States
  const [custName, setCustName] = useState("");
  const [custTpin, setCustTpin] = useState("");
  const [custPhone, setCustPhone] = useState("");
  const [custAddress, setCustAddress] = useState("");
  const [custEmail, setCustEmail] = useState("");

  // New Invoice/Quotation Form States
  const [customerName, setCustomerName] = useState("");
  const [sourceMode, setSourceMode] = useState<"crop" | "orchard" | "livestock" | "poultry" | "general">("crop");
  const [selectedCropId, setSelectedCropId] = useState("");
  const [selectedOrchardBlockId, setSelectedOrchardBlockId] = useState("");
  const [selectedAnimalTag, setSelectedAnimalTag] = useState("");
  const [animalPricingMode, setAnimalPricingMode] = useState<"scale_weight" | "per_head">("scale_weight");
  const [animalScaleWeight, setAnimalScaleWeight] = useState<number | "">(350);
  const [animalPricePerKg, setAnimalPricePerKg] = useState<number | "">(45);
  const [animalHeadPrice, setAnimalHeadPrice] = useState<number | "">(15000);
  const [selectedPoultryBatchId, setSelectedPoultryBatchId] = useState("");
  const [poultrySaleType, setPoultrySaleType] = useState<"live_birds" | "dressed_meat" | "eggs">("live_birds");
  const [poultryQuantity, setPoultryQuantity] = useState<number | "">(50);
  const [poultryUnitPrice, setPoultryUnitPrice] = useState<number | "">(85);

  // Active Annual Crop Cycles
  const activeCropBatches = crops.filter(c => c.cycleType !== "perennial_orchard" && !c.orchard);
  
  // Active Orchard Blocks
  const activeOrchardBlocks = crops.filter(c => c.cycleType === "perennial_orchard" || c.orchard !== undefined);

  // Active Enterprise Central Animal Registry
  const [resolvedLivestock, setResolvedLivestock] = useState<LivestockRecord[]>(livestock || []);
  useEffect(() => {
    if (livestock && livestock.length > 0) {
      setResolvedLivestock(livestock);
    } else {
      try {
        const stored = localStorage.getItem("mabala_livestock");
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) setResolvedLivestock(parsed);
        }
      } catch (e) {}
    }
  }, [livestock]);

  const activeAnimals = resolvedLivestock.filter(a => a.status !== "Sold" && a.status !== "Dead" && a.status !== "Deceased" && a.status !== "Slaughtered");

  // Active Poultry Batches
  const [resolvedPoultry, setResolvedPoultry] = useState<PoultryBatch[]>(poultryBatches || []);
  useEffect(() => {
    if (poultryBatches && poultryBatches.length > 0) {
      setResolvedPoultry(poultryBatches);
    } else {
      try {
        const stored = localStorage.getItem("mabala_poultry_batches");
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) setResolvedPoultry(parsed);
        }
      } catch (e) {}
    }
  }, [poultryBatches]);

  const activePoultry = resolvedPoultry.filter(p => p.status !== "CLOSED" && p.status !== "COMPLETED");

  const [lines, setLines] = useState<InvoiceLine[]>([
    { description: "", quantity: 1, unitPrice: 0, amount: 0 }
  ]);
  const [dueDate, setDueDate] = useState("2026-06-15");
  const [showTaxCalculator, setShowTaxCalculator] = useState(false);
  const [taxRate, setTaxRate] = useState<number>(() => {
    const stat = getStatutoryTaxConfig();
    if (activeFarm?.taxSystem === "Turnover Tax") return stat.totRate || 5.0;
    if (activeFarm?.taxSystem === "Sales Tax") return stat.salesTaxRate || 5.0;
    if (activeFarm?.taxSystem === "None") return 0;
    return stat.vatRate || 16.0;
  });

  useEffect(() => {
    const unsub = subscribeTaxConfig((latest) => {
      if (activeFarm?.taxSystem === "Turnover Tax") setTaxRate(latest.totRate || 5.0);
      else if (activeFarm?.taxSystem === "Sales Tax") setTaxRate(latest.salesTaxRate || 5.0);
      else if (activeFarm?.taxSystem === "None") setTaxRate(0);
      else setTaxRate(latest.vatRate || 16.0);
    });
    return () => unsub();
  }, [activeFarm?.taxSystem]);

  // Part Payment state modal
  const [paymentInvoiceId, setPaymentInvoiceId] = useState<string | null>(null);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);

  // Credit Note state modal
  const [creditNoteInvoice, setCreditNoteInvoice] = useState<Invoice | null>(null);
  const [creditReason, setCreditReason] = useState("");
  const [creditDate, setCreditDate] = useState<string>(new Date().toISOString().split("T")[0]);

  // Pagination states
  const [pageSize, setPageSize] = useState<number>(10);
  const [currentPage, setCurrentPage] = useState<number>(1);

  const handleExportInvoicePDF = (docItem: any, isQuote: boolean = false) => {
    const doc = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4"
    });

    const pageWidth = 210;
    const pageHeight = 297;
    const xMargin = 15;

    // --- Elegant Header Decor ---
    doc.setFillColor(30, 41, 59); // Slate-800
    doc.rect(0, 0, pageWidth, 16, "F");
    
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.text("MABALA FINANCIAL TRANSACTION STANDARD • LETTERHEAD GENERATION", 15, 10.5);

    if (activeFarm?.name) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8.5);
      doc.setTextColor(248, 250, 252);
      doc.text(activeFarm.name.toUpperCase(), 195, 10.5, { align: "right" });
    }

    // DRAW THE LOGO IN THE HEADER BAND OR TOP CORNER (logoX=15, logoY=22)
    const logoX = 15;
    const logoY = 22;
    const logoWidth = 10;
    const logoHeight = 10;

    const isDeepValley = activeFarm?.name?.toLowerCase().includes("deep valley");
    const hasValidLogo = activeFarm?.logo && (activeFarm.logo !== "leaf" || isDeepValley);

    if (hasValidLogo) {
      if (activeFarm.logo === "leaf") {
        doc.setFillColor(16, 185, 129); // Emerald-500
        doc.ellipse(logoX + 5, logoY + 5, 4, 5, "F");
        doc.setDrawColor(255, 255, 255);
        doc.setLineWidth(0.4);
        doc.line(logoX + 5, logoY + 10, logoX + 5, logoY + 2.5); // stem
      } else if (activeFarm.logo === "wheat") {
        doc.setFillColor(245, 158, 11); // Amber-500
        doc.circle(logoX + 5, logoY + 3.1, 1.5, "F");
        doc.circle(logoX + 3.2, logoY + 5, 1.2, "F");
        doc.circle(logoX + 6.8, logoY + 5, 1.2, "F");
        doc.circle(logoX + 5, logoY + 7, 1.5, "F");
        doc.rect(logoX + 4.5, logoY + 8, 1, 2.5, "F"); // stem
      } else if (activeFarm.logo === "shield") {
        doc.setFillColor(79, 70, 229); // Indigo-600
        doc.triangle(logoX + 1, logoY + 1, logoX + 9, logoY + 1, logoX + 5, logoY + 10, "F");
        doc.setFillColor(99, 102, 241); // Indigo-500
        doc.triangle(logoX + 3, logoY + 2, logoX + 7, logoY + 2, logoX + 5, logoY + 8, "F");
      } else if (activeFarm.logo === "water") {
        doc.setFillColor(6, 182, 212); // Cyan-500
        doc.triangle(logoX + 5, logoY + 2, logoX + 2.5, logoY + 7, logoX + 7.5, logoY + 7, "F");
        doc.circle(logoX + 5, logoY + 7, 2.5, "F");
      } else if (activeFarm.logo.startsWith("data:image/")) {
        try {
          const format = activeFarm.logo.includes("image/png") ? "PNG" : "JPEG";
          doc.addImage(activeFarm.logo, format, logoX, logoY, logoWidth, logoHeight);
        } catch (e) {
          console.error("Error drawing custom image logo on invoice PDF:", e);
        }
      }
    }

    // --- FARM ISSUER BLOCK ---
    let y = 25;
    const txtOffset = hasValidLogo ? 29 : 15;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text(activeFarm?.name || "Corporate Farm Estate", txtOffset, y);
    y += 4.5;

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105); // slate-600
    doc.text(`TPIN: ${activeFarm?.tpin || "100431290"}` + (activeFarm?.phone ? ` | PH: ${activeFarm.phone}` : ""), txtOffset, y);
    y += 4;
    
    doc.text(`Email: ${activeFarm?.email || "billing@mabalasubscriber.com"} | Address: ${activeFarm?.address || "Zambian Land Sector Offices"}`, txtOffset, y);
    y += 8;

    doc.setDrawColor(226, 232, 240); // slate-200
    doc.setLineWidth(0.4);
    doc.line(15, y, 195, y);
    y += 8;

    // --- DOCUMENT METADATA PANEL (2 Columns) ---
    // Background card
    doc.setFillColor(248, 250, 252);
    doc.rect(15, y, 180, 26, "F");
    doc.setDrawColor(241, 245, 249);
    doc.rect(15, y, 180, 26, "D");

    // Left Column: Document Type and Numbers
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    const docTitle = isQuote ? "PROFORMA QUOTATION" : "TAX INVOICE / DEMAND DEBT";
    doc.text(docTitle, 22, y + 8);

    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    const numLabel = isQuote ? `QUOTATION REF: ${docItem.quoteNumber || "QT-" + docItem.id.slice(0, 5).toUpperCase()}` : `INVOICE NUMBER: ${docItem.invoiceNumber}`;
    doc.text(numLabel, 22, y + 15);
    
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    const dateLabel = `Date Issued: ${docItem.date || "2026-06-01"} | Due Date Term: ${docItem.dueDate || "Immediate"}`;
    doc.text(dateLabel, 22, y + 21);

    // Right Column: Status & Balances
    doc.setFont("helvetica", "normal");
    doc.text("PAYMENT METADATA", 188, y + 8, { align: "right" });

    // Status Pill
    if (!isQuote) {
      const getPaidSum = (i: any) => {
        if (i.paidAmount !== undefined) return i.paidAmount;
        return i.status === "Paid" ? i.total : 0;
      };
      const paid = getPaidSum(docItem);
      const balance = docItem.total - paid;
      const statusText = balance === 0 ? "PAID IN FULL" : paid > 0 ? "PART PAID" : "UNPAID STATUS";
      
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8.5);
      doc.setTextColor(balance === 0 ? 16 : paid > 0 ? 79 : 220, balance === 0 ? 185 : paid > 0 ? 70 : 38, balance === 0 ? 129 : paid > 0 ? 229 : 38);
      doc.text(statusText, 188, y + 14, { align: "right" });

      doc.setFont("helvetica", "normal");
      doc.setTextColor(71, 85, 105);
      doc.setFontSize(8);
      doc.text(`Outstanding Bal: ${currencySymbol} ${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 188, y + 21, { align: "right" });
    } else {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8.5);
      doc.setTextColor(79, 70, 229); // indigo-600
      doc.text("ESTIMATE PROFORMA", 188, y + 14, { align: "right" });

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(71, 85, 105);
      doc.text("Expires in 30 days", 188, y + 21, { align: "right" });
    }

    y += 33;

    // --- RECIPIENT BUYER INFO BOX ---
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139); // slate-400
    doc.text("RECIPIENT CUSTOMER BILL-TO:", 15, y);
    y += 5.5;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text(docItem.customerName, 15, y);
    y += 5;

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    doc.text(`Customer TPIN: ${docItem.customerTpin || "N/A"}`, 15, y);
    y += 8;

    // --- LINE ITEMS TABLE GRID ---
    doc.setFillColor(30, 41, 59); // slate-800
    doc.rect(15, y, 180, 7.5, "F");

    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.setTextColor(255, 255, 255);
    doc.text("ITEM DESCRIPTION & LEDGER ALLOCATION", 18, y + 5);
    doc.text("QTY", 120, y + 5, { align: "center" });
    doc.text("UNIT PRICE", 145, y + 5, { align: "right" });
    doc.text("NET AMOUNT", 192, y + 5, { align: "right" });

    y += 7.5;

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(51, 65, 85);

    const docLines = docItem.lines || [];
    docLines.forEach((ln: any, idx: number) => {
      // Alternate row bg colors for beautiful spacing
      if (idx % 2 === 1) {
        doc.setFillColor(250, 250, 250);
        doc.rect(15, y, 180, 7, "F");
      }
      doc.setTextColor(51, 65, 85);
      doc.text(ln.description || "Unspecified Deliverables", 18, y + 5);
      doc.text(String(ln.quantity), 120, y + 5, { align: "center" });
      doc.text(`${currencySymbol} ${(ln.unitPrice || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 145, y + 5, { align: "right" });
      doc.setFont("helvetica", "bold");
      doc.text(`${currencySymbol} ${(ln.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 192, y + 5, { align: "right" });
      doc.setFont("helvetica", "normal");
      
      doc.setDrawColor(241, 245, 249);
      doc.line(15, y + 7, 195, y + 7);
      y += 7;
    });

    y += 3;

    // --- ACCUMULATED LEDGER TOTALS ---
    const defaultStatVat = getStatutoryTaxConfig().vatRate;
    const itemTaxRate = docItem.taxRate !== undefined && docItem.taxRate !== null ? docItem.taxRate : defaultStatVat;
    const subtotal = docItem.subtotal !== undefined ? docItem.subtotal : docItem.total * (1 - (itemTaxRate / 100));
    const taxAmount = docItem.taxAmount !== undefined ? docItem.taxAmount : (docItem.total - subtotal);
    const total = docItem.total;

    // Draw little box for totals
    doc.setFillColor(248, 250, 252);
    doc.rect(xMargin + 100, y, 80, 23.5, "F");
    doc.setDrawColor(226, 232, 240);
    doc.rect(xMargin + 100, y, 80, 23.5, "D");

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text("SUBTOTAL EXCLUDING TAXES:", xMargin + 104, y + 5.5);
    doc.text(`${currencySymbol} ${subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 192, y + 5.5, { align: "right" });

    doc.text(`ESTIMATED VAT / TAX (${itemTaxRate}%):`, xMargin + 104, y + 11.5);
    doc.text(`${currencySymbol} ${taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 192, y + 11.5, { align: "right" });

    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text("TOTAL DUE / RECORDED VALUE:", xMargin + 104, y + 18.5);
    doc.setTextColor(16, 185, 129); // emerald-500
    doc.text(`${currencySymbol} ${total.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 192, y + 18.5, { align: "right" });

    // --- CIRCULAR ("ROUNDED") PAID SEAL GRAPHIC ---
    // Only rendered once invoice status is confirmed paid (never a client-togglable UI element)
    const getPaidSumForSeal = (i: any) => {
      if (i.paidAmount !== undefined) return i.paidAmount;
      return (i.status as string)?.toLowerCase() === "paid" ? i.total : 0;
    };
    const isPaidDoc = !isQuote && ((docItem.status as string)?.toLowerCase() === "paid" || getPaidSumForSeal(docItem) >= docItem.total);

    if (isPaidDoc) {
      const sealCenterX = xMargin + 140; // Positioned directly below Total Amount Paid block
      const sealCenterY = y + 14;
      const sealR = 17; // Circular seal radius in mm

      // Double concentric outer circles
      doc.setDrawColor(16, 185, 129); // Emerald stamp green
      doc.setLineWidth(1.2);
      doc.circle(sealCenterX, sealCenterY, sealR, "D");

      doc.setLineWidth(0.4);
      doc.circle(sealCenterX, sealCenterY, sealR - 1.8, "D");

      // Inner dashed accent circle
      doc.setDrawColor(4, 120, 87);
      doc.setLineWidth(0.25);
      doc.circle(sealCenterX, sealCenterY, sealR - 3.2, "D");

      // Receiving farm node name at top curve
      const receivingFarm = docItem.farmName || activeFarm?.name || "Zambia Enterprise Farm Node";
      doc.setFont("helvetica", "bold");
      doc.setFontSize(5.5);
      doc.setTextColor(4, 120, 87);
      doc.text(receivingFarm.toUpperCase().slice(0, 26), sealCenterX, sealCenterY - 8.5, { align: "center" });

      // Bold "PAID" Text inside rounded center box
      doc.setFillColor(236, 253, 245); // Emerald-50 background
      doc.rect(sealCenterX - 13, sealCenterY - 4.5, 26, 9, "F");
      doc.setDrawColor(16, 185, 129);
      doc.setLineWidth(0.5);
      doc.rect(sealCenterX - 13, sealCenterY - 4.5, 26, 9, "D");

      doc.setFont("helvetica", "bold");
      doc.setFontSize(13);
      doc.setTextColor(6, 95, 70); // Emerald-900
      doc.text("PAID", sealCenterX, sealCenterY + 2, { align: "center" });

      // Date payment was received
      const datePaid = docItem.paymentDate || docItem.paidAt || docItem.date || new Date().toISOString().split("T")[0];
      doc.setFont("helvetica", "bold");
      doc.setFontSize(6);
      doc.setTextColor(4, 120, 87);
      doc.text(`DATE: ${datePaid}`, sealCenterX, sealCenterY + 8, { align: "center" });

      // Verification label
      doc.setFont("helvetica", "normal");
      doc.setFontSize(4.5);
      doc.setTextColor(16, 185, 129);
      doc.text("LIPILA VERIFIED • OFFICIAL RECEIPT SEAL", sealCenterX, sealCenterY + 12.2, { align: "center" });

      y += 18;
    }

    y += 33;

    // --- AUDIT TRAIL / DOUBLE-ENTRY FOOTNOTE ---
    if (!isQuote) {
      doc.setFillColor(248, 250, 252);
      doc.rect(15, y, 180, 15, "F");
      
      doc.setFont("helvetica", "bold");
      doc.setFontSize(7.5);
      doc.setTextColor(15, 23, 42);
      const coaDr = docItem.coaDebit || "1100";
      const coaCr = docItem.coaCredit || "4000";
      doc.text("ISO-ALIGNED DOUBLE-ENTRY JOURNAL REF:", 18, y + 5);
      
      doc.setFont("helvetica", "normal");
      doc.text(`Dr Account ${coaDr} (Customer Ledger Accounts Receivable) • Cr Account ${coaCr} (General Crop Revenue Allocations)`, 18, y + 10);
      y += 15;
    }

    // Footer signature lines
    doc.setFont("helvetica", "italic");
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184); // slate-400
    doc.text("Thank you for your valued business. This document was auto-generated of true electronic ledger states.", 15, pageHeight - 20);
    doc.text("Authorized Auditor Signature & System Stamp", 195, pageHeight - 20, { align: "right" });

    // Save
    const docName = isQuote 
      ? `quotation_${docItem.id.slice(0, 6)}.pdf` 
      : `invoice_${docItem.invoiceNumber}.pdf`;
    doc.save(docName);
  };

  const handleCreateCreditNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!creditNoteInvoice || !onAddCreditNote) return;

    if (!isFarmOwner) {
      alert("Unauthorized: Only Farm Owners and Platform Administrators are authorized to issue credit note reversals.");
      return;
    }

    const cnNumber = `CN-${Math.floor(1000 + Math.random() * 9000)}`;
    const newCN: CreditNote = {
      id: `cn-${Math.floor(10000 + Math.random() * 90000)}`,
      creditNoteNumber: cnNumber,
      invoiceId: creditNoteInvoice.id,
      invoiceNumber: creditNoteInvoice.invoiceNumber,
      date: creditDate,
      customerName: creditNoteInvoice.customerName,
      subtotal: creditNoteInvoice.subtotal,
      taxAmount: creditNoteInvoice.taxAmount,
      total: creditNoteInvoice.total,
      lines: creditNoteInvoice.lines,
      reason: creditReason,
      coaDebit: creditNoteInvoice.coaCredit || "4000",
      coaCredit: "1100",
      farmId: creditNoteInvoice.farmId || ""
    };

    onAddCreditNote(newCN);
    setCreditNoteInvoice(null);
    setCreditReason("");
    alert(`Credit Note ${cnNumber} successfully raised. Invoice ${creditNoteInvoice.invoiceNumber} has been reversed and marked as cancelled.`);
  };

  const handleExportCreditNotePDF = (cn: CreditNote) => {
    const doc = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4"
    });

    const pageWidth = 210;
    const pageHeight = 297;
    const xMargin = 15;

    // --- Elegant Header Decor ---
    doc.setFillColor(15, 23, 42); // slate-900 (darker for Credit Note)
    doc.rect(0, 0, pageWidth, 16, "F");
    
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.text("MABALA FINANCIAL TRANSACTION STANDARD • CREDIT REVERSAL NOTE", 15, 10.5);

    if (activeFarm?.name) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8.5);
      doc.setTextColor(248, 250, 252);
      doc.text(activeFarm.name.toUpperCase(), 195, 10.5, { align: "right" });
    }

    const logoX = 15;
    const logoY = 22;
    const logoWidth = 10;
    const logoHeight = 10;
    const isDeepValley = activeFarm?.name?.toLowerCase().includes("deep valley");
    const hasValidLogo = activeFarm?.logo && (activeFarm.logo !== "leaf" || isDeepValley);

    if (hasValidLogo) {
      if (activeFarm.logo === "leaf") {
        doc.setFillColor(16, 185, 129); // Emerald-500
        doc.ellipse(logoX + 5, logoY + 5, 4, 5, "F");
        doc.setDrawColor(255, 255, 255);
        doc.setLineWidth(0.4);
        doc.line(logoX + 5, logoY + 10, logoX + 5, logoY + 2.5); // stem
      } else if (activeFarm.logo === "wheat") {
        doc.setFillColor(245, 158, 11); // Amber-500
        doc.circle(logoX + 5, logoY + 3.1, 1.5, "F");
        doc.circle(logoX + 3.2, logoY + 5, 1.2, "F");
        doc.circle(logoX + 6.8, logoY + 5, 1.2, "F");
        doc.circle(logoX + 5, logoY + 7, 1.5, "F");
        doc.rect(logoX + 4.5, logoY + 8, 1, 2.5, "F"); // stem
      } else if (activeFarm.logo === "shield") {
        doc.setFillColor(79, 70, 229); // Indigo-600
        doc.triangle(logoX + 1, logoY + 1, logoX + 9, logoY + 1, logoX + 5, logoY + 10, "F");
        doc.setFillColor(99, 102, 241); // Indigo-500
        doc.triangle(logoX + 3, logoY + 2, logoX + 7, logoY + 2, logoX + 5, logoY + 8, "F");
      } else if (activeFarm.logo === "water") {
        doc.setFillColor(6, 182, 212); // Cyan-500
        doc.triangle(logoX + 5, logoY + 2, logoX + 2.5, logoY + 7, logoX + 7.5, logoY + 7, "F");
        doc.circle(logoX + 5, logoY + 7, 2.5, "F");
      } else if (activeFarm.logo.startsWith("data:image/")) {
        try {
          const format = activeFarm.logo.includes("image/png") ? "PNG" : "JPEG";
          doc.addImage(activeFarm.logo, format, logoX, logoY, logoWidth, logoHeight);
        } catch (e) {
          console.error("Error drawing logo on credit note PDF:", e);
        }
      }
    }

    // --- FARM ISSUER BLOCK ---
    let y = 25;
    const txtOffset = hasValidLogo ? 29 : 15;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text(activeFarm?.name || "Corporate Farm Estate", txtOffset, y);
    y += 4.5;

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105); // slate-600
    doc.text(`TPIN: ${activeFarm?.tpin || "100431290"}` + (activeFarm?.phone ? ` | PH: ${activeFarm.phone}` : ""), txtOffset, y);
    y += 4;
    
    doc.text(`Email: ${activeFarm?.email || "billing@mabalasubscriber.com"} | Address: ${activeFarm?.address || "Zambian Land Sector Offices"}`, txtOffset, y);
    y += 8;

    doc.setDrawColor(226, 232, 240); // slate-200
    doc.setLineWidth(0.4);
    doc.line(15, y, 195, y);
    y += 8;

    // --- DOCUMENT METADATA PANEL (2 Columns) ---
    // Background card
    doc.setFillColor(254, 242, 242); // Soft light red
    doc.rect(15, y, 180, 26, "F");
    doc.setDrawColor(254, 226, 226);
    doc.rect(15, y, 180, 26, "D");

    // Left Column: Document Type and Numbers
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(153, 27, 27); // Dark red
    doc.text("OFFICIAL CREDIT NOTE", 22, y + 8);

    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.setTextColor(127, 29, 29);
    doc.text(`CREDIT NOTE NO: ${cn.creditNoteNumber}`, 22, y + 15);
    
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(153, 27, 27);
    const cnDateLabel = `CN Date Issued: ${cn.date} | Ref Invoice: ${cn.invoiceNumber}`;
    doc.text(cnDateLabel, 22, y + 21);

    // Right Column: Status & Balances
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.setTextColor(153, 27, 27);
    doc.text("FULL INVOICE REVERSAL", 188, y + 14, { align: "right" });

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.text(`Credit Amount: ${currencySymbol} ${cn.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 188, y + 21, { align: "right" });

    y += 33;

    // --- RECIPIENT BUYER INFO BOX ---
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139); // slate-400
    doc.text("RECIPIENT CUSTOMER CREDIT-TO:", 15, y);
    y += 5.5;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text(cn.customerName, 15, y);
    y += 5;

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    doc.text(`Reason for Credit Note: ${cn.reason}`, 15, y);
    y += 8;

    // --- LINE ITEMS TABLE GRID ---
    doc.setFillColor(153, 27, 27); // Deep red
    doc.rect(15, y, 180, 7.5, "F");

    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.setTextColor(255, 255, 255);
    doc.text("REVERSED ITEM DESCRIPTION", 18, y + 5);
    doc.text("QTY", 120, y + 5, { align: "center" });
    doc.text("UNIT PRICE", 145, y + 5, { align: "right" });
    doc.text("REVERSED AMOUNT", 192, y + 5, { align: "right" });

    y += 7.5;

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(51, 65, 85);

    const cnLines = cn.lines || [];
    cnLines.forEach((ln: any, idx: number) => {
      if (idx % 2 === 1) {
        doc.setFillColor(254, 252, 252);
        doc.rect(15, y, 180, 7, "F");
      }
      doc.setTextColor(51, 65, 85);
      doc.text(ln.description || "Unspecified Deliverables", 18, y + 5);
      doc.text(String(ln.quantity), 120, y + 5, { align: "center" });
      doc.text(`${currencySymbol} ${(ln.unitPrice || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 145, y + 5, { align: "right" });
      doc.setFont("helvetica", "bold");
      doc.text(`${currencySymbol} ${(ln.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 192, y + 5, { align: "right" });
      doc.setFont("helvetica", "normal");
      
      doc.setDrawColor(241, 245, 249);
      doc.line(15, y + 7, 195, y + 7);
      y += 7;
    });

    y += 3;

    // --- ACCUMULATED LEDGER TOTALS ---
    const subtotal = cn.subtotal;
    const taxAmount = cn.taxAmount;
    const total = cn.total;

    doc.setFillColor(254, 242, 242);
    doc.rect(xMargin + 100, y, 80, 23.5, "F");
    doc.setDrawColor(254, 226, 226);
    doc.rect(xMargin + 100, y, 80, 23.5, "D");

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(127, 29, 29);
    doc.text("REVERSED SUBTOTAL EXCLUDING TAX:", xMargin + 104, y + 5.5);
    doc.text(`${currencySymbol} ${subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 192, y + 5.5, { align: "right" });

    const cnTaxRate = (cn as any).taxRate !== undefined && (cn as any).taxRate !== null ? (cn as any).taxRate : getStatutoryTaxConfig().vatRate;
    doc.text(`REVERSED VAT / TAX (${cnTaxRate}%):`, xMargin + 104, y + 11.5);
    doc.text(`${currencySymbol} ${taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 192, y + 11.5, { align: "right" });

    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(153, 27, 27);
    doc.text("TOTAL CREDITED REVERSAL AMOUNT:", xMargin + 104, y + 18.5);
    doc.text(`${currencySymbol} ${total.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 192, y + 18.5, { align: "right" });

    y += 33;

    // --- AUDIT TRAIL / DOUBLE-ENTRY FOOTNOTE ---
    doc.setFillColor(254, 242, 242);
    doc.rect(15, y, 180, 15, "F");
    
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.setTextColor(127, 29, 29);
    doc.text("ISO-ALIGNED DOUBLE-ENTRY JOURNAL REF:", 18, y + 5);
    doc.setFont("helvetica", "normal");
    doc.text(`Dr Account ${cn.coaDebit} (Revenue Reversals & Allowances) • Cr Account ${cn.coaCredit} (General Customer Ledger Accounts Receivable)`, 18, y + 10);
    y += 15;

    // Footer signature lines
    doc.setFont("helvetica", "italic");
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184); // slate-400
    doc.text("This document is an official Credit Note issued under double-entry accounting rules to reverse debtor claims.", 15, pageHeight - 20);
    doc.text("Authorized Auditor Signature & System Stamp", 195, pageHeight - 20, { align: "right" });

    // Save
    doc.save(`credit_note_${cn.creditNoteNumber}.pdf`);
  };

  const addLine = () => {
    setLines([...lines, { description: "", quantity: 1, unitPrice: 0, amount: 0 }]);
  };

  const removeLine = (idx: number) => {
    if (lines.length === 1) return;
    setLines(lines.filter((_, i) => i !== idx));
  };

  const updateLine = (idx: number, field: keyof InvoiceLine, val: any) => {
    const updated = [...lines];
    let lineObj = { ...updated[idx] };
    if (field === "quantity" || field === "unitPrice") {
      lineObj[field] = Number(val);
      lineObj.amount = lineObj.quantity * lineObj.unitPrice;
    } else {
      (lineObj as any)[field] = val;
    }
    updated[idx] = lineObj;
    setLines(updated);
  };

  // 1. Crop Batch Selection auto filler
  const handleCropBatchChange = (cropId: string) => {
    setSelectedCropId(cropId);
    if (!cropId) return;
    const crop = crops.find(c => c.id === cropId);
    if (!crop) return;

    const autoDesc = `Harvest Grain: ${crop.cropType} (${crop.variety || "Yield"}) - Batch: ${crop.fieldBlock}`;
    const defaultQty = crop.actualYieldKg || crop.expectedYieldKg || 1;
    const defaultPrice = crop.expectedSellingPricePerKg || 0;
    
    const updated = [...lines];
    updated[0] = {
      description: autoDesc,
      quantity: defaultQty,
      unitPrice: defaultPrice,
      amount: defaultQty * defaultPrice,
      cropId: crop.id,
      productType: "crop",
      cropCycleRef: `${crop.cropType} (${crop.fieldBlock})`
    };
    setLines(updated);
  };

  // 2. Orchard Block Selection auto filler
  const handleOrchardBlockChange = (blockId: string) => {
    setSelectedOrchardBlockId(blockId);
    if (!blockId) return;
    const block = activeOrchardBlocks.find(b => b.id === blockId);
    if (!block) return;

    const autoDesc = `Orchard Fruit Produce: ${block.cropType} (${block.variety || "Perennial"}) - Block: ${block.fieldBlock || "Orchard"}`;
    const defaultPrice = block.orchard?.pricePerUnitOrKg || block.expectedSellingPricePerKg || 0;
    const defaultQty = block.actualYieldKg || block.expectedYieldKg || 1;

    const updated = [...lines];
    updated[0] = {
      description: autoDesc,
      quantity: defaultQty,
      unitPrice: defaultPrice,
      amount: defaultQty * defaultPrice,
      blockId: block.id,
      cropId: block.id,
      treeGroupId: (block as any)?.treeGroupId,
      productType: "fruit"
    };
    setLines(updated);
  };

  // 3. Central Animal Registry auto filler
  const handleLivestockSelect = (tagId: string, pricingMode: "scale_weight" | "per_head" = animalPricingMode, scaleWt: number | "" = animalScaleWeight, kgRate: number | "" = animalPricePerKg, headRate: number | "" = animalHeadPrice) => {
    setSelectedAnimalTag(tagId);
    if (!tagId) return;
    const animal = activeAnimals.find(a => a.tagId === tagId || a.id === tagId);
    if (!animal) return;

    const weight = typeof scaleWt === "number" && scaleWt > 0 ? scaleWt : (animal.weight || 0);
    const kgPrice = typeof kgRate === "number" && kgRate > 0 ? kgRate : 0;
    const headPrice = typeof headRate === "number" && headRate > 0 ? headRate : (animal.currentValue || 0);

    let desc = "";
    let qty = 1;
    let price = 0;

    if (pricingMode === "scale_weight") {
      desc = `Livestock Sale: Tag #${animal.tagId} (${animal.species}, ${animal.breed || "Standard"}) - Scale Liveweight: ${weight} kg`;
      qty = weight;
      price = kgPrice;
    } else {
      desc = `Livestock Sale: Tag #${animal.tagId} (${animal.species}, ${animal.breed || "Standard"}) - Live Animal Head`;
      qty = 1;
      price = headPrice;
    }

    const updated = [...lines];
    updated[0] = {
      description: desc,
      quantity: qty,
      unitPrice: price,
      amount: qty * price,
      animalTagId: animal.tagId,
      livestockId: animal.id,
      productType: "livestock"
    };
    setLines(updated);
  };

  // 4. Poultry Batch auto filler
  const handlePoultryBatchChange = (batchId: string, sType: "live_birds" | "dressed_meat" | "eggs" = poultrySaleType, qtyVal: number | "" = poultryQuantity, priceVal: number | "" = poultryUnitPrice) => {
    setSelectedPoultryBatchId(batchId);
    if (!batchId) return;
    const batch = activePoultry.find(p => p.batchId === batchId || p.id === batchId);
    if (!batch) return;

    let desc = "";
    const userQty = typeof qtyVal === "number" && qtyVal > 0 ? qtyVal : (batch.currentCount || 1);
    const userPrice = typeof priceVal === "number" && priceVal >= 0 ? priceVal : 0;

    if (sType === "live_birds") {
      desc = `Poultry Sale: Batch #${batch.batchName || batch.batchId} (Live Birds - ${batch.birdType}) - Shed: ${batch.assignedShed || "Main Shed"}`;
    } else if (sType === "dressed_meat") {
      desc = `Poultry Produce: Batch #${batch.batchName || batch.batchId} (${batch.birdType}) - Processed Dressed Whole Birds`;
    } else {
      desc = `Fresh Table Eggs: Batch #${batch.batchName || batch.batchId} (${batch.birdType}) - Standard Crates / Trays - Shed: ${batch.assignedShed || "Layer Shed"}`;
    }

    setPoultryQuantity(userQty);
    setPoultryUnitPrice(userPrice);

    const updated = [...lines];
    updated[0] = {
      description: desc,
      quantity: userQty,
      unitPrice: userPrice,
      amount: userQty * userPrice,
      poultryBatchId: batch.batchId || batch.id,
      productType: "poultry"
    };
    setLines(updated);
  };

  const subtotal = lines.reduce((acc, r) => acc + (r.quantity * r.unitPrice), 0);
  const taxAmount = subtotal * (taxRate / 100);
  const total = subtotal + taxAmount;

  // Add customer handler
  const handleSaveCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!custName) return;
    const newCust: Customer = {
      id: "CUST-" + Date.now(),
      name: custName,
      tpin: custTpin || undefined,
      phone: custPhone,
      address: custAddress,
      email: custEmail,
      contact: custPhone // map contact
    };
    onAddCustomer(newCust);
    setCustomerName(newCust.name); // Set invoice dropdown
    setCustName("");
    setCustTpin("");
    setCustPhone("");
    setCustAddress("");
    setCustEmail("");
    setShowCustomerModal(false);
  };

  const handleSaveDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName) return;

    // Determine appropriate accounting CoA code based on origin
    let coaCredit = "4000";
    let productType: any = undefined;
    let cropId: string | undefined = undefined;
    let blockId: string | undefined = undefined;
    let animalTagId: string | undefined = undefined;
    let livestockId: string | undefined = undefined;
    let poultryBatchId: string | undefined = undefined;
    let cropCycleRef: string | undefined = undefined;
    let sourceType: any = "direct";

    if (sourceMode === "crop") {
      coaCredit = "4100"; // Crop Revenue
      productType = "crop";
      sourceType = "crop_harvest";
      cropId = selectedCropId || undefined;
      const c = crops.find(x => x.id === selectedCropId);
      if (c) cropCycleRef = `${c.cropType} (${c.fieldBlock})`;
    } else if (sourceMode === "orchard") {
      coaCredit = "4300"; // Orchard Fruit Revenue
      productType = "fruit";
      sourceType = "orchard";
      blockId = selectedOrchardBlockId || undefined;
      cropId = selectedOrchardBlockId || undefined;
      const b = activeOrchardBlocks.find(x => x.id === selectedOrchardBlockId);
      if (b) cropCycleRef = `Orchard Block: ${b.fieldBlock || b.cropType}`;
    } else if (sourceMode === "livestock") {
      coaCredit = "4300"; // Livestock Sales Revenue
      productType = "livestock";
      sourceType = "livestock";
      animalTagId = selectedAnimalTag || undefined;
      livestockId = selectedAnimalTag || undefined;
    } else if (sourceMode === "poultry") {
      coaCredit = "4200"; // Poultry & Egg Revenue
      productType = "poultry";
      sourceType = "poultry";
      poultryBatchId = selectedPoultryBatchId || undefined;
    }

    if (activeSegment === "invoices") {
      // Dynamic invoice creation
      const inv: Invoice = {
        id: "INV-" + Date.now(),
        invoiceNumber: `INV-2026-0${invoices.length + 11}`,
        date: new Date().toISOString().split('T')[0],
        dueDate,
        customerName,
        customerTpin: customers.find(c => c.name === customerName)?.tpin,
        taxAmount,
        subtotal,
        total,
        lines: lines.map(l => ({ 
          ...l, 
          amount: l.quantity * l.unitPrice,
          cropId: l.cropId || cropId,
          blockId: l.blockId || blockId,
          animalTagId: l.animalTagId || animalTagId,
          poultryBatchId: l.poultryBatchId || poultryBatchId,
          productType: l.productType || productType
        })),
        status: "Unpaid",
        coaDebit: "1100",
        coaCredit,
        farmId: activeFarm?.id || "farm-1",
        farmName: activeFarm?.name || "Main Enterprise Farm",
        cropId,
        blockId,
        animalTagId,
        livestockId,
        poultryBatchId,
        cropCycleRef,
        productType,
        sourceType
      };
      // Keep state tracking variables
      (inv as any).paidAmount = 0;
      (inv as any).taxRate = taxRate;
      onAddInvoice(inv);
    } else {
      const qt: Quotation = {
        id: "QT-" + Date.now(),
        quoteNumber: `QT-2026-0${quotations.length + 11}`,
        date: new Date().toISOString().split('T')[0],
        validityPeriodDays: 30,
        customerName,
        taxAmount,
        subtotal,
        total,
        lines: lines.map(l => ({ 
          ...l, 
          amount: l.quantity * l.unitPrice,
          cropId: l.cropId || cropId,
          blockId: l.blockId || blockId,
          animalTagId: l.animalTagId || animalTagId,
          poultryBatchId: l.poultryBatchId || poultryBatchId,
          productType: l.productType || productType
        })),
        status: "Draft",
        farmId: activeFarm?.id || "farm-1"
      };
      (qt as any).taxRate = taxRate;
      (qt as any).cropId = cropId;
      (qt as any).blockId = blockId;
      (qt as any).animalTagId = animalTagId;
      (qt as any).poultryBatchId = poultryBatchId;
      (qt as any).productType = productType;
      (qt as any).sourceType = sourceType;
      onAddQuotation(qt);
    }

    setShowAddForm(false);
    setSelectedCropId("");
    setSelectedOrchardBlockId("");
    setSelectedAnimalTag("");
    setSelectedPoultryBatchId("");
    setLines([{ description: "", quantity: 1, unitPrice: 0, amount: 0 }]);
  };

  const getPaidAmount = (inv: Invoice) => {
    if (inv.paidAmount !== undefined) return inv.paidAmount;
    return inv.status === "Paid" ? inv.total : 0;
  };

  // Trigger partial or full payments collection
  const collectPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentInvoiceId) return;

    const targetInv = invoices.find(i => i.id === paymentInvoiceId);
    if (targetInv && (targetInv.blockId || targetInv.cropId)) {
      const blockId = targetInv.blockId || targetInv.cropId!;
      const linkedCrop = crops.find(c => c.id === blockId);
      if (linkedCrop && (linkedCrop.cycleType === "perennial_orchard" || linkedCrop.orchard !== undefined)) {
        OrchardFinanceService.postOrchardSale({
          saleId: targetInv.id,
          blockId,
          treeGroupId: (linkedCrop as any)?.treeGroupId,
          amount: paymentAmount || targetInv.total,
          buyer: targetInv.customerName,
          productType: "fruit",
          productName: `${linkedCrop.cropType || "Orchard"} Fruit (Invoice Settlement)`,
          invoiceNumber: targetInv.invoiceNumber,
          date: new Date().toISOString().split('T')[0]
        }).catch(err => console.warn("[Orchard Finance] Invoice payment ledger post warning:", err));
      }
    }

    onMarkPaid(paymentInvoiceId, paymentAmount);
    setPaymentInvoiceId(null);
    setPaymentAmount(0);
  };

  const openPaymentCollector = (inv: Invoice) => {
    setPaymentInvoiceId(inv.id);
    // Suggest remaining amount
    const paid = getPaidAmount(inv);
    const remaining = inv.total - paid;
    setPaymentAmount(remaining);
  };

  const getOutstandingBalance = (inv: Invoice) => {
    const paid = getPaidAmount(inv);
    return inv.total - paid;
  };

  // Pagination helper
  const paginate = (items: any[]) => {
    const startIndex = (currentPage - 1) * pageSize;
    return items.slice(startIndex, startIndex + pageSize);
  };

  return (
    <div className="space-y-6">
      {/* Sub-Panel Tabs switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex bg-slate-100 p-1.5 rounded-2xl w-fit text-xs font-bold shadow-sm gap-1 border">
          <button 
            onClick={() => { setActiveSegment("invoices"); setShowAddForm(false); setCurrentPage(1); }}
            className={`px-4 py-2 rounded-xl transition-all ${activeSegment === "invoices" ? "bg-white text-slate-800 shadow" : "text-slate-500 hover:text-slate-700"}`}
          >
            Customer Invoices
          </button>
          <button 
            onClick={() => { setActiveSegment("quotations"); setShowAddForm(false); setCurrentPage(1); }}
            className={`px-4 py-2 rounded-xl transition-all ${activeSegment === "quotations" ? "bg-white text-slate-800 shadow" : "text-slate-500 hover:text-slate-700"}`}
          >
            Proforma Quotations
          </button>
          <button 
            onClick={() => { setActiveSegment("customers"); setShowAddForm(false); setCurrentPage(1); }}
            className={`px-4 py-2 rounded-xl transition-all ${activeSegment === "customers" ? "bg-white text-slate-800 shadow" : "text-slate-500 hover:text-slate-700"}`}
          >
            Customers Directory ({customers.length})
          </button>
          <button 
            onClick={() => { setActiveSegment("credit_notes"); setShowAddForm(false); setCurrentPage(1); }}
            className={`px-4 py-2 rounded-xl transition-all ${activeSegment === "credit_notes" ? "bg-white text-slate-800 shadow" : "text-slate-500 hover:text-slate-700"}`}
          >
            Credit Notes ({creditNotes.length})
          </button>
        </div>

        {onNavigateToOfftaker && (
          <button
            type="button"
            onClick={onNavigateToOfftaker}
            className="px-4 py-2 bg-gradient-to-r from-amber-50 to-amber-100 hover:from-amber-100 hover:to-amber-200 border border-amber-300 text-amber-900 font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-2 cursor-pointer transition active:scale-95"
          >
            <Tractor className="w-4 h-4 text-amber-700" />
            <span>Sell Harvest to Offtakers</span>
            <ArrowRight className="w-3.5 h-3.5 text-amber-700" />
          </button>
        )}
      </div>

      {/* Customer Form Modal Overlay */}
      {showCustomerModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 min-h-screen">
          <form onSubmit={handleSaveCustomer} className="w-full max-w-md bg-white rounded-2xl shadow-xl border p-6 space-y-4 animate-scale-up" id="customer-inline-form">
            <h4 className="text-sm font-extrabold text-slate-800 uppercase tracking-widest pb-2 border-b">Onboard Customer Register</h4>
            
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500">Customer Name *</label>
                <input type="text" value={custName} onChange={e => setCustName(e.target.value)} required className="w-full mt-1 border rounded p-2 focus:border-emerald-500 bg-slate-50 focus:bg-white" placeholder="e.g. Kasama Millers Ltd" />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500">TPIN Number</label>
                <input type="text" value={custTpin} onChange={e => setCustTpin(e.target.value)} className="w-full mt-1 border rounded p-2 focus:border-emerald-500 bg-slate-50 focus:bg-white font-mono" placeholder="e.g. 1009180023" />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-500">Contact Number</label>
                  <input type="text" value={custPhone} onChange={e => setCustPhone(e.target.value)} className="w-full mt-1 border rounded p-2 focus:border-emerald-500 bg-slate-50 focus:bg-white" placeholder="e.g. +260977450123" />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-500">Email Address</label>
                  <input type="email" value={custEmail} onChange={e => setCustEmail(e.target.value)} className="w-full mt-1 border rounded p-2 focus:border-emerald-500 bg-slate-50 focus:bg-white" placeholder="e.g. procurement@kasamamills.zm" />
                </div>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500">Registered Corporate Address</label>
                <input type="text" value={custAddress} onChange={e => setCustAddress(e.target.value)} className="w-full mt-1 border rounded p-2 bg-slate-50 focus:bg-white" placeholder="e.g. Plot 20, Independence Main Way, Kasama" />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t text-xs font-semibold">
              <button type="button" onClick={() => setShowCustomerModal(false)} className="px-4 py-2 bg-slate-100 rounded">Cancel</button>
              <button type="submit" className="px-5 py-2 bg-emerald-600 text-white rounded font-bold hover:bg-emerald-500 shadow">Save Customer</button>
            </div>
          </form>
        </div>
      )}

      {/* New invoice/quotation creator inline */}
      {showAddForm && (
        <form onSubmit={handleSaveDocument} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-md space-y-6 animate-fade-in w-full max-w-4xl" id="doc-creator-form">
          <div className="flex justify-between items-center border-b pb-3">
            <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-widest flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-emerald-600" />
              <span>Generate {activeSegment === "invoices" ? "Audit Registered Customer Invoice" : "Proforma Quotation Entry"}</span>
            </h3>
            
            <button type="button" onClick={() => setShowCustomerModal(true)} className="text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 text-xs font-bold hover:bg-emerald-100">
              + Onboard Inline Customer
            </button>
          </div>

          {/* Source Entity Category Selector */}
          <div className="space-y-2">
            <label className="text-[10px] uppercase font-extrabold text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Production Origin & Asset Linkage (Required for Audit Compliance)</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              <button
                type="button"
                onClick={() => {
                  setSourceMode("crop");
                  if (activeCropBatches.length > 0) handleCropBatchChange(activeCropBatches[0].id);
                }}
                className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all ${
                  sourceMode === "crop"
                    ? "bg-emerald-50 border-emerald-500 text-emerald-900 shadow-sm"
                    : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Wheat className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="truncate">Crop Harvest</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSourceMode("orchard");
                  if (activeOrchardBlocks.length > 0) handleOrchardBlockChange(activeOrchardBlocks[0].id);
                }}
                className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all ${
                  sourceMode === "orchard"
                    ? "bg-teal-50 border-teal-500 text-teal-900 shadow-sm"
                    : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Trees className="w-4 h-4 text-teal-600 shrink-0" />
                <span className="truncate">Orchard Block</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSourceMode("livestock");
                  if (activeAnimals.length > 0) handleLivestockSelect(activeAnimals[0].tagId);
                }}
                className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all ${
                  sourceMode === "livestock"
                    ? "bg-amber-50 border-amber-500 text-amber-900 shadow-sm"
                    : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Beef className="w-4 h-4 text-amber-600 shrink-0" />
                <span className="truncate">Livestock Registry</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSourceMode("poultry");
                  if (activePoultry.length > 0) handlePoultryBatchChange(activePoultry[0].batchId || activePoultry[0].id);
                }}
                className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all ${
                  sourceMode === "poultry"
                    ? "bg-yellow-50 border-yellow-500 text-yellow-900 shadow-sm"
                    : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Egg className="w-4 h-4 text-yellow-600 shrink-0" />
                <span className="truncate">Poultry Batches</span>
              </button>

              <button
                type="button"
                onClick={() => setSourceMode("general")}
                className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all ${
                  sourceMode === "general"
                    ? "bg-slate-200 border-slate-400 text-slate-900 shadow-sm"
                    : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Boxes className="w-4 h-4 text-slate-600 shrink-0" />
                <span className="truncate">General / Other</span>
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Select Registered Customer Recipient *</label>
              <select value={customerName} onChange={e => setCustomerName(e.target.value)} required className="w-full text-xs font-bold border rounded p-2.5 bg-slate-50 mt-1">
                <option value="">-- Select Outflow Customer --</option>
                {customers.map(c => (
                  <option key={c.id} value={c.name}>{c.name} {c.tpin ? `(TPIN: ${c.tpin})` : ""}</option>
                ))}
              </select>
            </div>

            {/* Dynamic Asset Selector based on Source Mode */}
            {sourceMode === "crop" && (
              <div>
                <label className="text-[10px] uppercase font-extrabold text-emerald-800 flex items-center gap-1">
                  <Wheat className="w-3 h-3 text-emerald-600" />
                  <span>Linked Harvest Cycle / Crop Batch *</span>
                </label>
                <select 
                  value={selectedCropId} 
                  onChange={e => handleCropBatchChange(e.target.value)} 
                  required
                  className="w-full text-xs font-bold border border-emerald-300 rounded p-2.5 bg-emerald-50/50 mt-1 text-slate-800"
                >
                  <option value="">-- Select Active Crop Cycle --</option>
                  {activeCropBatches.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.cropType} ({c.fieldBlock || "Main Block"}) — Target: {c.expectedYieldKg || 0}kg @ {currencySymbol}{c.expectedSellingPricePerKg || 8.5}/kg
                    </option>
                  ))}
                </select>
              </div>
            )}

            {sourceMode === "orchard" && (
              <div>
                <label className="text-[10px] uppercase font-extrabold text-teal-800 flex items-center gap-1">
                  <Trees className="w-3 h-3 text-teal-600" />
                  <span>Linked Orchard Block *</span>
                </label>
                <select 
                  value={selectedOrchardBlockId} 
                  onChange={e => handleOrchardBlockChange(e.target.value)} 
                  required
                  className="w-full text-xs font-bold border border-teal-300 rounded p-2.5 bg-teal-50/50 mt-1 text-slate-800"
                >
                  <option value="">-- Select Orchard Block --</option>
                  {activeOrchardBlocks.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.cropType} ({b.fieldBlock || "Orchard Block"}) — {b.orchard?.treeCount || 0} Trees
                    </option>
                  ))}
                </select>
              </div>
            )}

            {sourceMode === "livestock" && (
              <div>
                <label className="text-[10px] uppercase font-extrabold text-amber-800 flex items-center gap-1">
                  <Beef className="w-3 h-3 text-amber-600" />
                  <span>Central Animal Registry *</span>
                </label>
                <select 
                  value={selectedAnimalTag} 
                  onChange={e => handleLivestockSelect(e.target.value)} 
                  required
                  className="w-full text-xs font-bold border border-amber-300 rounded p-2.5 bg-amber-50/50 mt-1 text-slate-800"
                >
                  <option value="">-- Select Animal Tag from Registry --</option>
                  {activeAnimals.map(a => (
                    <option key={a.id || a.tagId} value={a.tagId}>
                      Tag #{a.tagId} — {a.species} ({a.breed || "Standard"}, {a.weight || 350}kg)
                    </option>
                  ))}
                </select>
              </div>
            )}

            {sourceMode === "poultry" && (
              <div>
                <label className="text-[10px] uppercase font-extrabold text-yellow-800 flex items-center gap-1">
                  <Egg className="w-3 h-3 text-yellow-600" />
                  <span>Active Poultry Batch *</span>
                </label>
                <select 
                  value={selectedPoultryBatchId} 
                  onChange={e => handlePoultryBatchChange(e.target.value)} 
                  required
                  className="w-full text-xs font-bold border border-yellow-300 rounded p-2.5 bg-yellow-50/50 mt-1 text-slate-800"
                >
                  <option value="">-- Select Poultry Flock Batch --</option>
                  {activePoultry.map(p => (
                    <option key={p.id || p.batchId} value={p.batchId || p.id}>
                      {p.batchName || p.batchId} — {p.birdType} ({p.currentCount || 0} Birds in {p.assignedShed || "Shed"})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {sourceMode === "general" && (
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">General Product Category</label>
                <input 
                  type="text" 
                  placeholder="e.g. Grain Storage, Land Rental, Advisory" 
                  className="w-full text-xs font-bold border rounded p-2 bg-slate-50 mt-1" 
                  onChange={e => {
                    const updated = [...lines];
                    updated[0].description = e.target.value;
                    setLines(updated);
                  }}
                />
              </div>
            )}

            {activeSegment === "invoices" && (
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-400 block tracking-wider">Due Payment Deadline *</label>
                <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} required className="w-full text-xs border bg-slate-50 font-bold rounded p-2 mt-1" />
              </div>
            )}
          </div>

          {/* Sub-parameters for Livestock or Poultry */}
          {sourceMode === "livestock" && (
            <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3.5 grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="text-[10px] uppercase font-bold text-amber-900">Pricing Method</label>
                <div className="flex gap-2 mt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setAnimalPricingMode("scale_weight");
                      if (selectedAnimalTag) handleLivestockSelect(selectedAnimalTag, "scale_weight", animalScaleWeight, animalPricePerKg, animalHeadPrice);
                    }}
                    className={`px-2.5 py-1 rounded text-xs font-bold border ${animalPricingMode === "scale_weight" ? "bg-amber-600 text-white border-amber-700 shadow-sm" : "bg-white text-slate-700"}`}
                  >
                    Scale Liveweight (kg)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAnimalPricingMode("per_head");
                      if (selectedAnimalTag) handleLivestockSelect(selectedAnimalTag, "per_head", animalScaleWeight, animalPricePerKg, animalHeadPrice);
                    }}
                    className={`px-2.5 py-1 rounded text-xs font-bold border ${animalPricingMode === "per_head" ? "bg-amber-600 text-white border-amber-700 shadow-sm" : "bg-white text-slate-700"}`}
                  >
                    Per Head (Fixed)
                  </button>
                </div>
              </div>

              {animalPricingMode === "scale_weight" ? (
                <>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-amber-900">Live Scale Weight (kg)</label>
                    <input
                      type="number"
                      value={animalScaleWeight}
                      onChange={e => {
                        const val = e.target.value === "" ? "" : Number(e.target.value);
                        setAnimalScaleWeight(val);
                        if (selectedAnimalTag) handleLivestockSelect(selectedAnimalTag, "scale_weight", val, animalPricePerKg, animalHeadPrice);
                      }}
                      className="w-full text-xs font-mono font-bold border rounded p-1.5 bg-white mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-amber-900">Price per kg ({currencySymbol})</label>
                    <input
                      type="number"
                      value={animalPricePerKg}
                      onChange={e => {
                        const val = e.target.value === "" ? "" : Number(e.target.value);
                        setAnimalPricePerKg(val);
                        if (selectedAnimalTag) handleLivestockSelect(selectedAnimalTag, "scale_weight", animalScaleWeight, val, animalHeadPrice);
                      }}
                      className="w-full text-xs font-mono font-bold border rounded p-1.5 bg-white mt-1"
                    />
                  </div>
                </>
              ) : (
                <div>
                  <label className="text-[10px] uppercase font-bold text-amber-900">Animal Head Price ({currencySymbol})</label>
                  <input
                    type="number"
                    value={animalHeadPrice}
                    onChange={e => {
                      const val = e.target.value === "" ? "" : Number(e.target.value);
                      setAnimalHeadPrice(val);
                      if (selectedAnimalTag) handleLivestockSelect(selectedAnimalTag, "per_head", animalScaleWeight, animalPricePerKg, val);
                    }}
                    className="w-full text-xs font-mono font-bold border rounded p-1.5 bg-white mt-1"
                  />
                </div>
              )}
            </div>
          )}

          {sourceMode === "poultry" && (
            <div className="bg-yellow-50/70 border border-yellow-200 rounded-xl p-3.5 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="text-[10px] uppercase font-bold text-yellow-900">Poultry Produce Type</label>
                <select
                  value={poultrySaleType}
                  onChange={e => {
                    const st = e.target.value as any;
                    setPoultrySaleType(st);
                    if (selectedPoultryBatchId) handlePoultryBatchChange(selectedPoultryBatchId, st, poultryQuantity, poultryUnitPrice);
                  }}
                  className="w-full text-xs font-bold border rounded p-1.5 bg-white mt-1"
                >
                  <option value="live_birds">Live Birds (Headcount)</option>
                  <option value="dressed_meat">Dressed / Processed Meat</option>
                  <option value="eggs">Fresh Table Eggs (30-Egg Trays)</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-yellow-900">Quantity Sold</label>
                <input
                  type="number"
                  value={poultryQuantity}
                  onChange={e => {
                    const val = e.target.value === "" ? "" : Number(e.target.value);
                    setPoultryQuantity(val);
                    if (selectedPoultryBatchId) handlePoultryBatchChange(selectedPoultryBatchId, poultrySaleType, val, poultryUnitPrice);
                  }}
                  className="w-full text-xs font-mono font-bold border rounded p-1.5 bg-white mt-1"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-yellow-900">Unit Price ({currencySymbol})</label>
                <input
                  type="number"
                  value={poultryUnitPrice}
                  onChange={e => {
                    const val = e.target.value === "" ? "" : Number(e.target.value);
                    setPoultryUnitPrice(val);
                    if (selectedPoultryBatchId) handlePoultryBatchChange(selectedPoultryBatchId, poultrySaleType, poultryQuantity, val);
                  }}
                  className="w-full text-xs font-mono font-bold border rounded p-1.5 bg-white mt-1"
                />
              </div>
            </div>
          )}

          <div className="space-y-2.5">
            <span className="text-[10px] uppercase font-extrabold text-slate-400 block tracking-wider">Itemized Sales Ledger Lines</span>
            {lines.map((line, idx) => (
              <div key={idx} className="grid grid-cols-12 gap-2 items-center bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                <div className="col-span-6">
                  <label className="text-[9px] text-slate-400">Production descriptor (Auto filled upon asset selection)</label>
                  <input type="text" placeholder="Description of harvested yield or goods sold" value={line.description} onChange={e => updateLine(idx, "description", e.target.value)} required className="w-full text-xs border bg-white rounded p-1.5" />
                </div>
                <div className="col-span-2">
                  <label className="text-[9px] text-slate-400">Quantity / Units</label>
                  <input type="number" placeholder="Qty" value={line.quantity} onChange={e => updateLine(idx, "quantity", e.target.value)} required className="w-full text-xs border bg-white rounded p-1.5 font-mono" />
                </div>
                <div className="col-span-3">
                  <label className="text-[9px] text-slate-400">Unit Price ({currencySymbol})</label>
                  <input type="number" placeholder="Price" value={line.unitPrice} onChange={e => updateLine(idx, "unitPrice", e.target.value)} required className="w-full text-xs border bg-white rounded p-1.5 font-mono" />
                </div>
                <div className="col-span-1 text-center pt-4">
                  <button type="button" onClick={() => removeLine(idx)} className="text-rose-500 hover:text-rose-700 text-xs font-bold font-mono">X</button>
                </div>
              </div>
            ))}
            <button type="button" onClick={addLine} className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-bold text-slate-700 border">+ Add Line Item</button>
          </div>

          {/* Sum details */}
          <div className="p-4 bg-slate-50 border rounded-2xl flex justify-between items-center text-xs font-mono">
            <div className="space-y-2">
              {activeSegment === "invoices" && (
                <p className="text-[10px] text-slate-500 font-sans">
                  Chart of Accounts mapping: <strong className="text-slate-900">Dr 1100 (Receivables) / Cr {sourceMode === "crop" ? "4100 (Crop Revenue)" : (sourceMode === "orchard" ? "4300 (Orchard Fruit)" : (sourceMode === "livestock" ? "4300 (Livestock Revenue)" : (sourceMode === "poultry" ? "4200 (Poultry & Egg)" : "4000 (Commercial Sales)")))}</strong>
                </p>
              )}
              <div className="flex items-center gap-3 flex-wrap">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-500 font-sans font-bold uppercase tracking-wider">Tax Rate:</span>
                  <div className="flex items-center gap-1 bg-white border rounded px-1 py-0.5">
                    <input
                      type="number"
                      value={taxRate === 0 ? "" : taxRate}
                      onChange={(e) => setTaxRate(e.target.value === "" ? 0 : Number(e.target.value))}
                      className="w-12 text-slate-800 text-xs font-bold font-mono outline-none text-center"
                      min="0"
                      max="100"
                    />
                    <span className="text-slate-400 font-bold text-[10px] pr-0.5">%</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowTaxCalculator(true)}
                  className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-[11px] font-bold flex items-center gap-1 shadow-2xs transition cursor-pointer"
                >
                  <Calculator className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Tax Tool ({activeFarm?.taxSystem === "Turnover Tax" ? "5% TOT" : "16% VAT"})</span>
                </button>
              </div>
            </div>
            <div className="text-right font-semibold space-y-1">
              <div>Subtotal: {currencySymbol} {subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
              <div>Estimated VAT ({taxRate}%): {currencySymbol} {taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
              <div className="text-sm font-black text-emerald-700 bg-emerald-500/5 px-2.5 py-1.5 rounded-lg border border-emerald-100 mt-2 block">
                Total Due Weight: {currencySymbol} {total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 border-t pt-4">
            <button type="button" onClick={() => setShowAddForm(false)} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold">Cancel</button>
            <button type="submit" className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-md">Conclude Document</button>
          </div>
        </form>
      )}

      {/* PARTIAL / FULL PAYMENT COLLECTION MODAL */}
      {paymentInvoiceId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 min-h-screen">
          <form onSubmit={collectPayment} className="w-full max-w-md bg-white rounded-2xl shadow-xl border p-6 space-y-4 animate-scale-up" id="invoice-payment-form">
            <h4 className="text-sm font-extrabold text-slate-800 uppercase tracking-widest pb-2 border-b">Collect Invoice Payment</h4>
            
            <p className="text-xs text-slate-500 leading-relaxed">
              Record full or partial cash collections on outstanding receivables. System dynamically calculates unpaid balances.
            </p>

            {(() => {
              const inv = invoices.find(i => i.id === paymentInvoiceId);
              if (!inv) return null;
              const paid = getPaidAmount(inv);
              const remaining = inv.total - paid;

              return (
                <div className="space-y-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-205">
                    <div className="flex justify-between font-semibold py-1">
                      <span>Invoice Total:</span>
                      <span className="font-mono">{currencySymbol} {inv.total.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between font-semibold py-1">
                      <span>Total Already Collected:</span>
                      <span className="font-mono text-emerald-600 font-bold">{currencySymbol} {paid.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between font-bold py-1 border-t mt-1">
                      <span>Remaining Balance:</span>
                      <span className="font-mono text-indigo-600 font-extrabold">{currencySymbol} {remaining.toLocaleString()}</span>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-500">Amount Collected Now ({currencySymbol}) *</label>
                    <input 
                      type="number" 
                      max={remaining}
                      min={1} 
                      step="any"
                      value={paymentAmount} 
                      onChange={e => setPaymentAmount(Number(e.target.value))} 
                      required 
                      className="w-full mt-1 border rounded p-2 focus:border-emerald-500 bg-slate-150 font-bold font-mono text-xs" 
                    />
                  </div>
                </div>
              );
            })()}

            <div className="flex justify-end gap-2 pt-3 border-t text-xs font-semibold">
              <button type="button" onClick={() => setPaymentInvoiceId(null)} className="px-4 py-2 bg-slate-100 rounded">Cancel</button>
              <button type="submit" className="px-5 py-2 bg-emerald-600 text-white rounded font-bold hover:bg-emerald-500 shadow">Conclude Collected Payment</button>
            </div>
          </form>
        </div>
      )}

      {/* RAISE CREDIT NOTE MODAL */}
      {creditNoteInvoice && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 min-h-screen">
          <form onSubmit={handleCreateCreditNote} className="w-full max-w-md bg-white rounded-2xl shadow-xl border p-6 space-y-4 animate-scale-up" id="credit-note-form">
            <h4 className="text-sm font-extrabold text-slate-800 uppercase tracking-widest pb-2 border-b text-rose-700">Raise Reversal Credit Note</h4>
            
            <p className="text-xs text-slate-500 leading-relaxed">
              This will issue an official credit adjustment note reversing outstanding claims on invoice <strong className="font-mono">{creditNoteInvoice.invoiceNumber}</strong>. Under standard double-entry accounting:
            </p>
            
            <div className="p-3 bg-rose-50 rounded-xl border border-rose-100 text-[11px] font-semibold text-rose-800 space-y-1">
              <div>• Debit Revenue Account: <span className="font-mono">{creditNoteInvoice.coaCredit || "4000"}</span></div>
              <div>• Credit Accounts Receivable: <span className="font-mono">1100</span></div>
              {creditNoteInvoice.taxAmount > 0 && (
                <div>• Debit Output VAT: <span className="font-mono">2070</span></div>
              )}
              <div className="font-extrabold border-t border-rose-200 mt-2 pt-1">
                Total Reversal Value: {currencySymbol} {creditNoteInvoice.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500">Credit Note Date *</label>
                <input 
                  type="date" 
                  value={creditDate} 
                  onChange={e => setCreditDate(e.target.value)} 
                  required 
                  className="w-full mt-1 border rounded p-2 focus:border-rose-500 bg-slate-50 text-xs font-mono" 
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500">Reason for Credit / Reversal *</label>
                <textarea 
                  value={creditReason} 
                  onChange={e => setCreditReason(e.target.value)} 
                  required 
                  placeholder="e.g. Sales return, damaged produce, crop quantity discrepancy, incorrect billing"
                  className="w-full mt-1 border rounded p-2 focus:border-rose-500 bg-slate-50 text-xs h-20 leading-relaxed" 
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t text-xs font-semibold">
              <button type="button" onClick={() => { setCreditNoteInvoice(null); setCreditReason(""); }} className="px-4 py-2 bg-slate-100 rounded">Cancel</button>
              <button type="submit" className="px-5 py-2 bg-rose-600 text-white rounded font-bold hover:bg-rose-500 shadow">Issue Reversal Credit Note</button>
            </div>
          </form>
        </div>
      )}

      {/* Main invoices lists */}
      {activeSegment === "invoices" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-6 py-4 bg-slate-50/50 border-b flex justify-between items-center flex-wrap gap-4">
            <div>
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Acre Audit Invoice Directory</h3>
              <p className="text-[11px] text-slate-500">Auto-balanced customer credit obligations and outstanding collections registers.</p>
            </div>
            {!isReadonly ? (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleScanAndNotifyUpcomingDeadlines}
                  disabled={sendingDeadlineReminders}
                  className="px-3.5 py-1.5 border border-indigo-200 hover:bg-indigo-50 text-indigo-900 rounded-xl text-xs font-bold shadow-2xs flex items-center gap-1.5 bg-indigo-50/50 cursor-pointer disabled:opacity-50"
                  title="Automatically scan and email farmers with approaching invoice deadlines using SMTP"
                >
                  <Mail className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Deadline Alerts</span>
                  {approachingCount > 0 && (
                    <span className="px-1.5 py-0.2 bg-amber-500 text-white rounded-full text-[10px] font-black animate-pulse">
                      {approachingCount} due soon
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setShowTaxCalculator(true)}
                  className="px-3.5 py-1.5 border border-emerald-300 hover:bg-emerald-50 text-emerald-800 rounded-xl text-xs font-bold shadow-2xs flex items-center gap-1.5 bg-white cursor-pointer"
                  title="Compute VAT (16%) or Turnover Tax (5%) for invoicing"
                >
                  <Calculator className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Tax Calculator ({activeFarm?.taxSystem === "Turnover Tax" ? "5% TOT" : "16% VAT"})</span>
                </button>
                <button
                  type="button"
                  onClick={handleDownloadInvoicesCSV}
                  className="px-3.5 py-1.5 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold shadow-sm flex items-center gap-1.5 bg-white cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  <span>Download CSV</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowNewSaleModal(true)}
                  className="px-3.5 py-1.5 bg-emerald-800 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow flex items-center gap-1.5 cursor-pointer"
                >
                  <Boxes className="w-3.5 h-3.5" />
                  <span>Sell from Storage</span>
                </button>
                <button onClick={() => setShowAddForm(true)} className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-850 text-white rounded-xl text-xs font-bold shadow">+ New Invoice</button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleDownloadInvoicesCSV}
                  className="px-3.5 py-1.5 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold shadow-sm flex items-center gap-1.5 bg-white cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  <span>Download CSV</span>
                </button>
                <span className="text-xs text-rose-500 bg-rose-50 px-2.5 py-1 rounded font-bold">Read-Only View</span>
              </div>
            )}
          </div>

          {/* Bulk actions banner if items are selected */}
          {selectedInvoiceIds.length > 0 && (
            <div className="bg-slate-50 border-b px-6 py-3 flex items-center justify-between animate-fade-in text-xs">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 font-mono">
                  {selectedInvoiceIds.length} Selected
                </span>
                <span className="text-slate-500 font-semibold">Bulk Action tools</span>
              </div>
              
              <div className="flex items-center gap-2">
                <button
                  onClick={handleBulkMarkPaid}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg cursor-pointer shadow-xs flex items-center gap-1.5"
                >
                  <CheckSquare className="w-3.5 h-3.5" />
                  <span>Mark as Paid</span>
                </button>
                <button
                  onClick={handleBulkSendReminders}
                  disabled={sendingDeadlineReminders}
                  className="px-3 py-1 border border-slate-300 hover:bg-slate-50 text-slate-700 bg-white font-bold rounded-lg cursor-pointer shadow-xs flex items-center gap-1.5 disabled:opacity-50"
                >
                  {sendingDeadlineReminders ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                  ) : (
                    <Mail className="w-3.5 h-3.5 text-slate-500" />
                  )}
                  <span>{sendingDeadlineReminders ? "Dispatching..." : "Send Batch Reminders"}</span>
                </button>
                <button
                  onClick={() => setSelectedInvoiceIds([])}
                  className="px-2.5 py-1 text-slate-400 hover:text-slate-600 font-bold"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {bulkMsg && (
            <div className="mx-6 mt-4 p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-950 font-semibold rounded-xl flex items-center gap-2 animate-fade-in text-xs">
              <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 animate-pulse" />
              <span>{bulkMsg}</span>
            </div>
          )}

          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                  <tr>
                    <th className="p-3 w-8 text-center">
                      <input 
                        type="checkbox"
                        checked={invoices.length > 0 && invoices.filter(inv => !inv.status.startsWith("Cancelled")).every(inv => selectedInvoiceIds.includes(inv.id))}
                        onChange={(e) => {
                          if (e.target.checked) {
                            const activeInvs = invoices.filter(inv => !inv.status.startsWith("Cancelled")).map(inv => inv.id);
                            setSelectedInvoiceIds(activeInvs);
                          } else {
                            setSelectedInvoiceIds([]);
                          }
                        }}
                        className="rounded border-slate-300 accent-emerald-600 cursor-pointer h-3.5 w-3.5"
                      />
                    </th>
                    <th className="p-3">Reference ID</th>
                    <th className="p-3">Customer Name</th>
                    <th className="p-3">Due Deadline</th>
                    <th className="p-3">Double-Entry Reference</th>
                    <th className="p-3 text-right">Invoiced Sum</th>
                    <th className="p-3 text-right">Collected Amount</th>
                    <th className="p-3 text-right">Outstanding Bal</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-center">Receive</th>
                    <th className="p-3 text-center">Export</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-semibold text-slate-800">
                  {paginate(invoices).map(inv => {
                    const isCancelled = inv.status.startsWith("Cancelled");
                    const paid = isCancelled ? 0 : getPaidAmount(inv);
                    const balance = isCancelled ? 0 : inv.total - paid;

                    return (
                      <tr key={inv.id} className={`hover:bg-slate-50/50 ${isCancelled ? "bg-slate-50/30 opacity-75" : ""}`}>
                        <td className="p-2.5 text-center">
                          {!isCancelled && (
                            <input 
                              type="checkbox"
                              checked={selectedInvoiceIds.includes(inv.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedInvoiceIds(prev => [...prev, inv.id]);
                                } else {
                                  setSelectedInvoiceIds(prev => prev.filter(id => id !== inv.id));
                                }
                              }}
                              className="rounded border-slate-300 accent-emerald-600 cursor-pointer h-3.5 w-3.5"
                            />
                          )}
                        </td>
                        <td className="p-2.5 font-mono text-slate-900">{inv.invoiceNumber}</td>
                        <td className="p-2.5 text-slate-950">
                          <div className="font-extrabold">{inv.customerName}</div>
                          {/* Production Linkage Audit Badge */}
                          <div className="mt-1 flex flex-wrap gap-1">
                            {inv.cropId && (
                              <span className="inline-flex items-center gap-1 text-[9px] bg-emerald-50 text-emerald-800 border border-emerald-200 px-1.5 py-0.5 rounded font-mono font-bold">
                                <Wheat className="w-2.5 h-2.5 text-emerald-600" />
                                <span>Crop Batch: {crops.find(c => c.id === inv.cropId)?.cropType || inv.cropCycleRef || "Annual Crop"}</span>
                              </span>
                            )}
                            {inv.blockId && (
                              <span className="inline-flex items-center gap-1 text-[9px] bg-teal-50 text-teal-800 border border-teal-200 px-1.5 py-0.5 rounded font-mono font-bold">
                                <Trees className="w-2.5 h-2.5 text-teal-600" />
                                <span>Orchard: {crops.find(c => c.id === inv.blockId)?.fieldBlock || "Perennial Orchard Block"}</span>
                              </span>
                            )}
                            {inv.animalTagId && (
                              <span className="inline-flex items-center gap-1 text-[9px] bg-amber-50 text-amber-900 border border-amber-200 px-1.5 py-0.5 rounded font-mono font-bold">
                                <Beef className="w-2.5 h-2.5 text-amber-600" />
                                <span>Animal Tag #{inv.animalTagId}</span>
                              </span>
                            )}
                            {inv.poultryBatchId && (
                              <span className="inline-flex items-center gap-1 text-[9px] bg-yellow-50 text-yellow-900 border border-yellow-200 px-1.5 py-0.5 rounded font-mono font-bold">
                                <Egg className="w-2.5 h-2.5 text-yellow-600" />
                                <span>Poultry Batch #{inv.poultryBatchId}</span>
                              </span>
                            )}
                            {!inv.cropId && !inv.blockId && !inv.animalTagId && !inv.poultryBatchId && (
                              <span className="inline-flex items-center gap-1 text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-mono">
                                <Boxes className="w-2.5 h-2.5 text-slate-500" />
                                <span>Commercial Entry</span>
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="p-2.5 text-slate-500 font-medium">{inv.dueDate}</td>
                        <td className="p-2.5 font-mono text-[9px] text-slate-500 leading-normal">
                          {isCancelled ? (
                            <span className="text-rose-600 font-bold">Reversal: Dr {inv.coaCredit || "4000"} Rev / Cr 1100 Recv</span>
                          ) : (
                            <>
                              {paid > 0 ? `Collected: Dr 1010 Bank / Cr 1100 Recv` : ""} <br/>
                              {balance > 0 ? `Unpaid: Dr 1100 Recv / Cr 4000 Rev` : ""}
                            </>
                          )}
                        </td>
                        <td className={`p-2.5 font-mono font-extrabold text-slate-900 text-right ${isCancelled ? "line-through text-slate-400" : ""}`}>
                          {currencySymbol} {inv.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className={`p-2.5 font-mono font-bold text-emerald-600 text-right ${isCancelled ? "text-slate-400" : ""}`}>
                          {currencySymbol} {paid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className={`p-2.5 font-mono font-extrabold text-rose-500 text-right ${isCancelled ? "text-slate-400" : ""}`}>
                          {currencySymbol} {balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="p-2.5">
                          <span className={`px-2 py-0.5 rounded text-[9px] font-extrabold uppercase font-mono block text-center max-w-[180px] truncate ${
                            isCancelled
                              ? "bg-rose-50 text-rose-600 border border-rose-200"
                              : balance === 0 
                                ? "bg-emerald-50 text-emerald-600 border border-emerald-200" 
                                : paid > 0 
                                  ? "bg-indigo-50 text-indigo-600 border border-indigo-200"
                                  : "bg-amber-50 text-amber-600 border border-amber-200"
                          }`} title={inv.status}>
                            {isCancelled ? inv.status.toUpperCase() : balance === 0 ? "PAID" : paid > 0 ? "PART PAID" : "UNPAID"}
                          </span>
                        </td>
                        <td className="p-2.5 text-center">
                          {isCancelled ? (
                            <span className="text-slate-400 italic text-[10px]">Reversed</span>
                          ) : balance > 0 ? (
                            <div className="flex flex-col gap-1 items-center">
                              <button 
                                onClick={() => openPaymentCollector(inv)}
                                className="px-2 py-0.5 bg-emerald-600 hover:bg-emerald-500 text-white text-[9px] font-bold rounded-lg cursor-pointer shadow-xs w-16 block"
                                title="Collect payment on this invoice (payments allowed in all states)"
                              >
                                Collect
                              </button>
                              {!isReadonly && (
                                <button 
                                  onClick={() => isFarmOwner ? setCreditNoteInvoice(inv) : alert("Credit note reversals are restricted to Farm Owners.")}
                                  className={`px-2 py-0.5 text-white text-[9px] font-bold rounded-lg shadow-xs w-16 block ${isFarmOwner ? "bg-rose-600 hover:bg-rose-500 cursor-pointer" : "bg-slate-400 cursor-not-allowed opacity-60"}`}
                                  title={isFarmOwner ? "Raise credit note to reverse this invoice" : "Restricted: Only Farm Owners can issue credit notes"}
                                >
                                  Credit
                                </button>
                              )}
                            </div>
                          ) : !isReadonly ? (
                            <div className="flex flex-col gap-1 items-center">
                              <span className="text-emerald-600 font-bold">✓</span>
                              <button 
                                onClick={() => isFarmOwner ? setCreditNoteInvoice(inv) : alert("Credit note reversals are restricted to Farm Owners.")}
                                className={`px-2 py-0.5 text-white text-[9px] font-bold rounded-lg shadow-xs w-16 block ${isFarmOwner ? "bg-rose-600 hover:bg-rose-500 cursor-pointer" : "bg-slate-400 cursor-not-allowed opacity-60"}`}
                                title={isFarmOwner ? "Raise credit note to reverse this invoice" : "Restricted: Only Farm Owners can issue credit notes"}
                              >
                                Credit
                              </button>
                            </div>
                          ) : (
                            <span className="text-emerald-600 font-bold">✓</span>
                          )}
                        </td>
                        <td className="p-2.5 text-center">
                          <button
                            onClick={() => handleExportInvoicePDF(inv, false)}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[9px] font-black rounded-lg border border-slate-200 cursor-pointer inline-flex items-center gap-1 hover:shadow-xs"
                            title="Download PDF demand notice with custom letterhead logo"
                          >
                            <Download className="w-2.5 h-2.5 text-slate-500" />
                            <span>PDF</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                  {invoices.length === 0 && (
                    <tr>
                      <td colSpan={10} className="p-6 text-center text-slate-400 italic">No customer invoices posted. Use the '+ New Invoice' trigger to bill corporate buyers.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination controls */}
            {invoices.length > 0 && (
              <div className="flex justify-between items-center mt-4 pt-4 border-t border-slate-100 text-xs font-semibold">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 text-[11px]">Rows to display:</span>
                  <select 
                    value={pageSize} 
                    onChange={e => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
                    className="border rounded p-1 text-xs font-semibold bg-white"
                  >
                    <option value={10}>10 items</option>
                    <option value={50}>50 items</option>
                    <option value={100}>100 items</option>
                  </select>
                </div>
                <div className="flex gap-1">
                  <button 
                    onClick={() => setCurrentPage(p => Math.max(p - 1, 1))} 
                    disabled={currentPage === 1}
                    className="px-2.5 py-1 rounded border bg-white enabled:hover:bg-slate-50 text-[11px] disabled:opacity-40 font-bold"
                  >
                    Prev
                  </button>
                  <span className="px-3 py-1 bg-slate-50 rounded font-mono font-bold text-[11px] text-slate-600">
                    Page {currentPage} of {Math.ceil(invoices.length / pageSize) || 1}
                  </span>
                  <button 
                    onClick={() => setCurrentPage(p => Math.min(p + 1, Math.ceil(invoices.length / pageSize)))} 
                    disabled={currentPage >= Math.ceil(invoices.length / pageSize)}
                    className="px-2.5 py-1 rounded border bg-white enabled:hover:bg-slate-50 text-[11px] disabled:opacity-40 font-bold"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Main proforma quotes list */}
      {activeSegment === "quotations" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-fade-in">
          <div className="px-6 py-4 bg-slate-50/50 border-b flex justify-between items-center">
            <div>
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Quotations Registry Panel</h3>
              <p className="text-[11px] text-slate-500">Proforma documents have no double-entry ledger impact until converted into finalized customer invoice.</p>
            </div>
            {!isReadonly ? (
              <button onClick={() => setShowAddForm(true)} className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow">+ New Quotation</button>
            ) : (
              <span className="text-xs text-rose-500 bg-rose-50 px-2 rounded">Locked</span>
            )}
          </div>

          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                  <tr>
                    <th className="p-3">Reference ID</th>
                    <th className="p-3">Customer Recipient</th>
                    <th className="p-3">Date Drafted</th>
                    <th className="p-3">Validity Horizon</th>
                    <th className="p-3 text-right">Sum Weight</th>
                    <th className="p-3 text-right">Transition Action</th>
                    <th className="p-3 text-center">Export</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-semibold text-slate-800">
                  {paginate(quotations).map(qt => (
                    <tr key={qt.id} className="hover:bg-slate-50/50">
                      <td className="p-3 font-mono text-slate-900">{qt.quoteNumber || "QT-DRAFT"}</td>
                      <td className="p-3 text-slate-950 font-bold">{qt.customerName}</td>
                      <td className="p-3 text-slate-500 font-medium">{qt.date}</td>
                      <td className="p-3 font-medium text-slate-600">{qt.validityPeriodDays || 30} Days valid</td>
                      <td className="p-3 font-mono font-extrabold text-slate-900 text-right">
                        {currencySymbol} {qt.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-3 text-right">
                        {!isReadonly && (
                          <button 
                            onClick={() => onConvertQuote(qt)}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-extrabold rounded-lg flex items-center gap-1 inline-flex cursor-pointer"
                          >
                            <span>Accept & Convert to Invoice</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => handleExportInvoicePDF(qt, true)}
                          className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-black rounded-lg border border-slate-200 cursor-pointer inline-flex items-center gap-1 hover:shadow-xs"
                          title="Download PDF Quotation with custom letterhead logo"
                        >
                          <Download className="w-3 h-3 text-slate-500" />
                          <span>PDF Quote</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                  {quotations.length === 0 && (
                    <tr>
                      <td colSpan={7} className="p-6 text-center text-slate-400 italic">No pro-forma quotations registered.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Credit Notes Registry Panel */}
      {activeSegment === "credit_notes" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-fade-in">
          <div className="px-6 py-4 bg-slate-50/50 border-b flex justify-between items-center">
            <div>
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Credit Notes & Adjustments</h3>
              <p className="text-[11px] text-slate-500">Official tax adjustment and revenue reversal records. Credit notes reduce the outstanding debtor balance of target invoices under standard accounting rules.</p>
            </div>
          </div>

          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                  <tr>
                    <th className="p-3">CN Ref Number</th>
                    <th className="p-3">Ref Invoice No</th>
                    <th className="p-3">Customer Recipient</th>
                    <th className="p-3">Date Issued</th>
                    <th className="p-3">Adjustment Reason</th>
                    <th className="p-3">Journal Entry Ledger</th>
                    <th className="p-3 text-right">Credited Value</th>
                    <th className="p-3 text-center">Export</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-semibold text-slate-800">
                  {paginate(creditNotes).map(cn => (
                    <tr key={cn.id} className="hover:bg-slate-50/50">
                      <td className="p-3 font-mono text-slate-900 font-extrabold text-rose-700">{cn.creditNoteNumber}</td>
                      <td className="p-3 font-mono text-slate-600">{cn.invoiceNumber}</td>
                      <td className="p-3 text-slate-950 font-bold">{cn.customerName}</td>
                      <td className="p-3 text-slate-500 font-medium">{cn.date}</td>
                      <td className="p-3 text-slate-600 font-medium italic">"{cn.reason}"</td>
                      <td className="p-3 font-mono text-[9px] text-slate-500 leading-normal">
                        Dr {cn.coaDebit || "4000"} Revenue Reversals <br />
                        Cr {cn.coaCredit || "1100"} Accounts Receivable
                      </td>
                      <td className="p-3 font-mono font-extrabold text-rose-600 text-right">
                        {currencySymbol} {cn.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => handleExportCreditNotePDF(cn)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[9px] font-black rounded-lg border border-slate-200 cursor-pointer inline-flex items-center gap-1 hover:shadow-xs"
                          title="Download Credit Note PDF Statement"
                        >
                          <Download className="w-2.5 h-2.5 text-slate-500" />
                          <span>PDF</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                  {creditNotes.length === 0 && (
                    <tr>
                      <td colSpan={8} className="p-6 text-center text-slate-400 italic">No credit reversal notes issued yet. To raise a credit note, go to the Customer Invoices tab and click the "Credit" action on any invoice.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Customers Directory Sub-Panel */}
      {activeSegment === "customers" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-fade-in">
          <div className="px-6 py-4 bg-slate-50/50 border-b flex justify-between items-center flex-wrap gap-4">
            <div>
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Multi-Country Customer Directory</h3>
              <p className="text-[11px] text-slate-500">List registered agricultural customers and audit total purchases linked to paid invoices.</p>
            </div>
            {!isReadonly ? (
              <button onClick={() => setShowCustomerModal(true)} className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow">+ Add Registered Customer</button>
            ) : (
              <span className="text-xs text-rose-500 bg-rose-50 px-2 rounded">Locked</span>
            )}
          </div>

          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                  <tr>
                    <th className="p-3">Customer ID</th>
                    <th className="p-3">Customer Name</th>
                    <th className="p-3">TPIN / TAX ID</th>
                    <th className="p-3">Contact Email</th>
                    <th className="p-3">Phone Line</th>
                    <th className="p-3">Address</th>
                    <th className="p-3 text-right">Audited Purchases Sum</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-semibold text-slate-850">
                  {paginate(customers).map(c => {
                    // Sum paid + unpaid invoices for total purchases tracking!
                    const matchInvoices = invoices.filter(i => i.customerName === c.name);
                    const purchasesSum = matchInvoices.reduce((acc, i) => acc + i.total, 0);

                    return (
                      <tr key={c.id} className="hover:bg-slate-50/50">
                        <td className="p-3 font-mono text-slate-500">{c.id}</td>
                        <td className="p-3 font-black text-slate-950 flex items-center gap-1">
                          <Users className="w-3.5 h-3.5 text-slate-400" />
                          <span>{c.name}</span>
                        </td>
                        <td className="p-3 font-mono text-[11px] text-slate-700">{c.tpin || "N/A - Non Taxable"}</td>
                        <td className="p-3 text-slate-600 font-medium">{c.email || "N/A - Off-Grid Customer"}</td>
                        <td className="p-3 font-mono text-[11px] text-slate-600">{c.phone || "N/A"}</td>
                        <td className="p-2.5 max-w-xs text-slate-500 truncate">{c.address || "N/A Local Delivery"}</td>
                        <td className="p-3 font-mono font-extrabold text-right text-emerald-700">
                          {currencySymbol} {purchasesSum.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                      </tr>
                    );
                  })}
                  {customers.length === 0 && (
                    <tr>
                      <td colSpan={7} className="p-6 text-center text-slate-400 italic">No registered corporate customers found. Onboard clients inline above.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls Customers */}
            {customers.length > 0 && (
              <div className="flex justify-between items-center mt-4 pt-4 border-t border-slate-100 text-xs font-semibold">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 text-[11px]">Rows to display:</span>
                  <select 
                    value={pageSize} 
                    onChange={e => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
                    className="border rounded p-1 text-xs font-semibold bg-white"
                  >
                    <option value={10}>10 items</option>
                    <option value={50}>50 items</option>
                    <option value={100}>100 items</option>
                  </select>
                </div>
                <div className="flex gap-1">
                  <button 
                    onClick={() => setCurrentPage(p => Math.max(p - 1, 1))} 
                    disabled={currentPage === 1}
                    className="px-2.5 py-1 rounded border bg-white enabled:hover:bg-slate-50 text-[11px] disabled:opacity-40 font-bold"
                  >
                    Prev
                  </button>
                  <span className="px-3 py-1 bg-slate-50 rounded font-mono font-bold text-[11px] text-slate-650">
                    Page {currentPage} of {Math.ceil(customers.length / pageSize) || 1}
                  </span>
                  <button 
                    onClick={() => setCurrentPage(p => Math.min(p + 1, Math.ceil(customers.length / pageSize)))} 
                    disabled={currentPage >= Math.ceil(customers.length / pageSize)}
                    className="px-2.5 py-1 rounded border bg-white enabled:hover:bg-slate-50 text-[11px] disabled:opacity-40 font-bold"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      {showNewSaleModal && (
        <NewSaleModal
          isOpen={showNewSaleModal}
          onClose={() => setShowNewSaleModal(false)}
          activeFarm={activeFarm}
          currencySymbol={currencySymbol}
          crops={crops}
        />
      )}
      {showTaxCalculator && (
        <TaxCalculatorTool
          isOpen={showTaxCalculator}
          onClose={() => setShowTaxCalculator(false)}
          activeFarm={activeFarm}
          currencySymbol={currencySymbol}
          initialAmount={subtotal || 1000}
          targetModule="invoicing"
          onApplyTax={(res) => {
            setTaxRate(res.taxRate);
          }}
        />
      )}
    </div>
  );
}

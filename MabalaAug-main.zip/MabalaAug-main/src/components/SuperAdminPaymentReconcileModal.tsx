import React, { useState, useEffect } from "react";
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Lock,
  Eye,
  EyeOff,
  Sparkles,
  MessageSquare,
  Zap,
  Building2,
  Receipt,
  Search,
  X,
  CreditCard,
  User,
  Phone,
  Clock,
  ArrowRight
} from "lucide-react";
import { LipilaTransaction } from "../data/mockLipilaTransactions";
import {
  checkLipilaGatewayStatus,
  reconcilePaymentWithLipila,
  parseSuggestedServiceAllocation,
  GatewayStatusCheckResult,
  ReconcilePaymentResponse
} from "../services/paymentReconciliationService";
import { auth } from "../firebase";

interface SuperAdminPaymentReconcileModalProps {
  transaction: LipilaTransaction;
  onClose: () => void;
  onSuccess?: (response: ReconcilePaymentResponse) => void;
  availableTenants?: Array<{ id: string; name: string; email?: string; phone?: string; smsCredits?: number; credits?: number }>;
}

export default function SuperAdminPaymentReconcileModal({
  transaction,
  onClose,
  onSuccess,
  availableTenants = []
}: SuperAdminPaymentReconcileModalProps) {
  // State for Lipila gateway checking
  const [checkingGateway, setCheckingGateway] = useState(false);
  const [gatewayCheckResult, setGatewayCheckResult] = useState<GatewayStatusCheckResult | null>(null);
  const [checkError, setCheckError] = useState<string | null>(null);

  // Suggested allocation & custom parameters
  const initialAllocation = parseSuggestedServiceAllocation(transaction);
  const [targetStatus, setTargetStatus] = useState<"Successful" | "Failed" | "Pending">("Successful");
  const [serviceType, setServiceType] = useState<"SMS_CREDITS" | "PLATFORM_CREDITS" | "SUBSCRIPTION_PLAN" | "INVOICE_SETTLEMENT" | "GENERAL_SERVICE">(initialAllocation.serviceType);
  const [allocationQuantity, setAllocationQuantity] = useState<number>(initialAllocation.quantity);
  const [selectedTenantId, setSelectedTenantId] = useState<string>(transaction.tenantId || initialAllocation.tenantId || "TENANT-DV-001");
  const [adminNotes, setAdminNotes] = useState<string>("");
  const [allowManualOverride, setAllowManualOverride] = useState<boolean>(false);

  // Super admin password authentication
  const [password, setPassword] = useState<string>("");
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);

  // Submission state
  const [submitting, setSubmitting] = useState(false);
  const [reconcileSuccessResult, setReconcileSuccessResult] = useState<ReconcilePaymentResponse | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Search filter for tenants
  const [tenantSearchQuery, setTenantSearchQuery] = useState("");

  const currentAdminEmail = auth.currentUser?.email || "support@mabala.cloud";

  // List of fallback tenants if not passed
  const defaultTenants = availableTenants.length > 0 ? availableTenants : [
    { id: "TENANT-DV-001", name: "Deep Valley Farms Limited", phone: "0971000000", smsCredits: 100, credits: 250 },
    { id: "TENANT-MK-002", name: "Mukuba Agri-Estates", phone: "0962000000", smsCredits: 40, credits: 120 },
    { id: "TENANT-ZG-003", name: "Zambezi Green Growers", phone: "0953000000", smsCredits: 85, credits: 300 },
    { id: "TENANT-KN-004", name: "Kafue North Cooperative", phone: "0974000000", smsCredits: 15, credits: 80 }
  ];

  const filteredTenants = defaultTenants.filter(t => 
    t.name.toLowerCase().includes(tenantSearchQuery.toLowerCase()) ||
    t.id.toLowerCase().includes(tenantSearchQuery.toLowerCase()) ||
    (t.phone && t.phone.includes(tenantSearchQuery))
  );

  const selectedTenant = defaultTenants.find(t => t.id === selectedTenantId) || defaultTenants[0];

  // Auto-run gateway check on mount
  useEffect(() => {
    runGatewayCheck();
  }, [transaction.referenceId, transaction.id]);

  const runGatewayCheck = async () => {
    const refId = transaction.referenceId || transaction.id;
    setCheckingGateway(true);
    setCheckError(null);
    try {
      const res = await checkLipilaGatewayStatus(refId);
      setGatewayCheckResult(res);
      if (res && res.suggestedAllocation) {
        if (res.suggestedAllocation.serviceType) setServiceType(res.suggestedAllocation.serviceType);
        if (res.suggestedAllocation.quantity) setAllocationQuantity(res.suggestedAllocation.quantity);
      }
    } catch (err: any) {
      setCheckError(err.message || "Failed to query Lipila Gateway.");
    } finally {
      setCheckingGateway(false);
    }
  };

  const handleExecuteReconciliation = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);
    setActionError(null);

    if (!password.trim()) {
      setPasswordError("Super Admin password is required to confirm this financial status update.");
      return;
    }

    const refId = transaction.referenceId || transaction.id;
    setSubmitting(true);

    try {
      const customPayload = {
        serviceType,
        quantity: allocationQuantity,
        smsCredits: serviceType === "SMS_CREDITS" ? allocationQuantity : undefined,
        credits: serviceType === "PLATFORM_CREDITS" ? allocationQuantity : undefined,
        amount: transaction.amount,
        narration: transaction.narration || transaction.message || `${allocationQuantity} SMS credits worth K${transaction.amount}`,
        tenantId: selectedTenantId
      };

      const result = await reconcilePaymentWithLipila({
        referenceId: refId,
        superAdminPassword: password.trim(),
        superAdminEmail: currentAdminEmail,
        targetStatus: targetStatus,
        targetTenantId: selectedTenantId,
        customAllocation: customPayload,
        bypassLipilaCheck: allowManualOverride,
        adminNotes: adminNotes || `Super admin reconciliation for ${selectedTenant?.name || selectedTenantId}`
      });

      setReconcileSuccessResult(result);
      if (onSuccess) {
        onSuccess(result);
      }
    } catch (err: any) {
      console.error("[ReconcileModal Error]:", err);
      const errMsg = err.message || "Failed to reconcile payment. Please check password and retry.";
      if (errMsg.toLowerCase().includes("password") || errMsg.toLowerCase().includes("auth")) {
        setPasswordError("Invalid Super Admin password. Authentication failed.");
      } else {
        setActionError(errMsg);
      }
    } finally {
      setSubmitting(false);
    }
  };

  const isGatewaySuccessful = gatewayCheckResult?.isSuccessful || (gatewayCheckResult?.lipilaStatus?.toLowerCase() === "successful");

  return (
    <div className="fixed inset-0 z-[180] bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200 text-slate-900 my-6 relative">
        
        {/* MODAL HEADER */}
        <div className="flex justify-between items-start border-b border-slate-100 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 font-mono">
                Super Admin Console
              </span>
              <span className="text-xs font-mono font-bold text-slate-400">
                Ref: {transaction.referenceId || transaction.id}
              </span>
            </div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-emerald-600" />
              <span>Lipila Payment Reconciliation</span>
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              Verify Lipila gateway settlement status, authenticate super admin credentials, and fulfill paid farm services.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* SUCCESS CONFIRMATION STATE */}
        {reconcileSuccessResult ? (
          <div className="space-y-6 animate-fade-in py-2">
            <div className="p-6 bg-emerald-50 border-2 border-emerald-500 rounded-2xl space-y-4 text-center">
              <div className="w-14 h-14 bg-emerald-600 text-white rounded-full flex items-center justify-center mx-auto shadow-lg shadow-emerald-600/30">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-black text-emerald-950">
                  Payment Status Updated to SUCCESSFUL
                </h3>
                <p className="text-xs text-emerald-800 font-medium max-w-md mx-auto">
                  {reconcileSuccessResult.message || "Payment has been verified and marked as Successful on Mabala."}
                </p>
              </div>

              {/* Service fulfillment receipt badge */}
              {reconcileSuccessResult.allocatedService && (
                <div className="p-4 bg-white rounded-xl border border-emerald-200 text-left space-y-2 font-mono text-xs shadow-xs">
                  <div className="flex justify-between items-center pb-2 border-b border-emerald-100">
                    <span className="font-bold text-emerald-900 uppercase text-[11px]">Allocated Service</span>
                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-black text-[10px]">
                      {reconcileSuccessResult.allocatedService.type}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-700">
                    <span>Service Fulfilled:</span>
                    <strong className="text-slate-900">{reconcileSuccessResult.allocatedService.serviceName}</strong>
                  </div>
                  <div className="flex justify-between text-slate-700">
                    <span>Recipient Tenant / Farm Node:</span>
                    <strong className="text-slate-900">{reconcileSuccessResult.allocatedService.farmName || reconcileSuccessResult.tenantId}</strong>
                  </div>
                  {reconcileSuccessResult.allocatedService.newBalance !== undefined && (
                    <div className="flex justify-between text-emerald-700 font-bold">
                      <span>New SMS / Credit Balance:</span>
                      <span>{reconcileSuccessResult.allocatedService.newBalance} Credits (Prev: {reconcileSuccessResult.allocatedService.previousBalance})</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-500 text-[10px] pt-1 border-t border-emerald-100">
                    <span>Authorized By:</span>
                    <span>{currentAdminEmail}</span>
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={onClose}
                className="w-full sm:w-auto px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl uppercase tracking-wider transition cursor-pointer shadow-md"
              >
                Close & Return to Ledger
              </button>
            </div>
          </div>
        ) : (
          /* FORM BODY */
          <form onSubmit={handleExecuteReconciliation} className="space-y-6">

            {/* TRANSACTION SUMMARY CARD */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
              <div className="flex justify-between items-center pb-2 border-b border-slate-200/80">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 font-mono">
                  Mabala Transaction Record (In-Place Update)
                </span>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                  transaction.status === "Successful" ? "bg-emerald-100 text-emerald-800" :
                  transaction.status === "Pending" ? "bg-amber-100 text-amber-800" :
                  "bg-rose-100 text-rose-800"
                }`}>
                  Current: {transaction.status}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 block font-medium">Customer / Payer</span>
                  <strong className="text-slate-800 truncate block">{transaction.customerName || "Farm Customer"}</strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block font-medium">Account / Phone</span>
                  <strong className="text-slate-800 font-mono">{transaction.accountNumber || (transaction as any).customerPhone || "N/A"}</strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block font-medium">Original Amount</span>
                  <strong className="text-emerald-700 font-black font-mono text-sm">
                    K{transaction.amount.toFixed(2)}
                  </strong>
                </div>
                <div className="col-span-2 sm:col-span-3">
                  <span className="text-[10px] text-slate-400 block font-medium">Payment Narration / Product</span>
                  <strong className="text-slate-700 font-sans">
                    {transaction.narration || transaction.message || "Custom Farm Service Payment"}
                  </strong>
                </div>
              </div>

              {/* Status Update Target Selector */}
              <div className="pt-2 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <span className="text-xs font-bold text-slate-700">Reconcile Status To:</span>
                <div className="flex items-center gap-1.5">
                  {(["Successful", "Failed", "Pending"] as const).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setTargetStatus(st)}
                      className={`px-3 py-1 text-xs font-bold rounded-lg border transition cursor-pointer ${
                        targetStatus === st
                          ? st === "Successful"
                            ? "bg-emerald-600 text-white border-emerald-600 shadow-xs"
                            : st === "Failed"
                            ? "bg-rose-600 text-white border-rose-600 shadow-xs"
                            : "bg-amber-500 text-white border-amber-500 shadow-xs"
                          : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>
              <div className="text-[10.5px] text-slate-500 bg-white p-2 rounded-xl border border-slate-200/60 leading-relaxed">
                ℹ️ Updates the status of transaction <code className="font-mono font-bold text-slate-700">#{transaction.referenceId || transaction.id}</code> directly. {targetStatus === "Successful" ? "Awards initial single value once with zero duplicate transaction creation." : "No credits or services will be issued."}
              </div>
            </div>

            {/* STEP 1: LIPILA GATEWAY STATUS VERIFICATION */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] flex items-center justify-center font-mono">1</span>
                  <span>Lipila Gateway Real-Time Status</span>
                </label>
                <button
                  type="button"
                  onClick={runGatewayCheck}
                  disabled={checkingGateway}
                  className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${checkingGateway ? "animate-spin" : ""}`} />
                  <span>Re-check Gateway</span>
                </button>
              </div>

              {checkingGateway ? (
                <div className="p-4 bg-indigo-50/70 border border-indigo-200 rounded-2xl flex items-center gap-3">
                  <RefreshCw className="w-5 h-5 text-indigo-600 animate-spin" />
                  <div>
                    <strong className="text-xs text-indigo-900 font-bold block">Querying Lipila Gateway...</strong>
                    <span className="text-[11px] text-indigo-700">Pinging https://blz.lipila.io with merchant key</span>
                  </div>
                </div>
              ) : gatewayCheckResult ? (
                <div className={`p-4 rounded-2xl border transition-all ${
                  isGatewaySuccessful 
                    ? "bg-emerald-50/90 border-emerald-300 text-emerald-950" 
                    : "bg-amber-50/90 border-amber-300 text-amber-950"
                }`}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-2.5">
                      {isGatewaySuccessful ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      ) : (
                        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <div className="flex items-center gap-2">
                          <strong className="text-xs font-black">
                            {isGatewaySuccessful 
                              ? "Lipila Gateway Confirmed: SUCCESSFUL" 
                              : `Lipila Gateway Status: ${gatewayCheckResult.lipilaStatus || "Pending"}`}
                          </strong>
                          <span className="px-2 py-0.2 rounded text-[9.5px] font-black uppercase bg-white/80 border border-current font-mono">
                            {gatewayCheckResult.checkSource}
                          </span>
                        </div>
                        <p className="text-[11px] mt-0.5 opacity-90">
                          {isGatewaySuccessful
                            ? "Gateway confirms funds were successfully collected and settled. Ready to update Mabala status & credit the user."
                            : "Gateway has not marked this payment as successful yet, or network verification timed out."}
                        </p>
                      </div>
                    </div>
                  </div>

                  {!isGatewaySuccessful && (
                    <div className="mt-3 pt-2.5 border-t border-amber-200 flex items-center justify-between">
                      <label className="flex items-center gap-2 cursor-pointer text-[11px] font-bold text-amber-900">
                        <input
                          type="checkbox"
                          checked={allowManualOverride}
                          onChange={(e) => setAllowManualOverride(e.target.checked)}
                          className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                        />
                        <span>Super Admin Manual Override (I have verified bank slip / manual proof)</span>
                      </label>
                    </div>
                  )}
                </div>
              ) : checkError ? (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
                  <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{checkError}</span>
                </div>
              ) : null}
            </div>

            {/* STEP 2: SERVICE ALLOCATION PREVIEW & CONFIGURATION */}
            <div className="space-y-3">
              <label className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] flex items-center justify-center font-mono">2</span>
                <span>Service Allocation & Fulfillment Destination</span>
              </label>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
                {/* Service Type Selector */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setServiceType("SMS_CREDITS");
                      if (transaction.amount === 45) setAllocationQuantity(50);
                      else setAllocationQuantity(Math.max(1, Math.round(transaction.amount / 0.90)));
                    }}
                    className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition cursor-pointer ${
                      serviceType === "SMS_CREDITS"
                        ? "bg-emerald-600 text-white border-emerald-600 shadow-sm"
                        : "bg-white text-slate-700 border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    <MessageSquare className={`w-4 h-4 ${serviceType === "SMS_CREDITS" ? "text-white" : "text-emerald-600"}`} />
                    <div>
                      <strong className="text-[11px] block font-bold mt-1">SMS Credits</strong>
                      <span className={`text-[9.5px] ${serviceType === "SMS_CREDITS" ? "text-emerald-100" : "text-slate-400"}`}>
                        e.g. 50 SMS / K45
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setServiceType("PLATFORM_CREDITS");
                      setAllocationQuantity(Math.max(1, Math.round(transaction.amount * 1.25) || 50));
                    }}
                    className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition cursor-pointer ${
                      serviceType === "PLATFORM_CREDITS"
                        ? "bg-indigo-600 text-white border-indigo-600 shadow-sm"
                        : "bg-white text-slate-700 border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    <Zap className={`w-4 h-4 ${serviceType === "PLATFORM_CREDITS" ? "text-white" : "text-indigo-600"}`} />
                    <div>
                      <strong className="text-[11px] block font-bold mt-1">Platform Credits</strong>
                      <span className={`text-[9.5px] ${serviceType === "PLATFORM_CREDITS" ? "text-indigo-100" : "text-slate-400"}`}>
                        Write ops wallet
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setServiceType("SUBSCRIPTION_PLAN")}
                    className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition cursor-pointer ${
                      serviceType === "SUBSCRIPTION_PLAN"
                        ? "bg-purple-600 text-white border-purple-600 shadow-sm"
                        : "bg-white text-slate-700 border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    <Sparkles className={`w-4 h-4 ${serviceType === "SUBSCRIPTION_PLAN" ? "text-white" : "text-purple-600"}`} />
                    <div>
                      <strong className="text-[11px] block font-bold mt-1">Subscription</strong>
                      <span className={`text-[9.5px] ${serviceType === "SUBSCRIPTION_PLAN" ? "text-purple-100" : "text-slate-400"}`}>
                        Activate 30 Days
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setServiceType("INVOICE_SETTLEMENT")}
                    className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition cursor-pointer ${
                      serviceType === "INVOICE_SETTLEMENT"
                        ? "bg-amber-600 text-white border-amber-600 shadow-sm"
                        : "bg-white text-slate-700 border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    <Receipt className={`w-4 h-4 ${serviceType === "INVOICE_SETTLEMENT" ? "text-white" : "text-amber-600"}`} />
                    <div>
                      <strong className="text-[11px] block font-bold mt-1">Invoice Settle</strong>
                      <span className={`text-[9.5px] ${serviceType === "INVOICE_SETTLEMENT" ? "text-amber-100" : "text-slate-400"}`}>
                        Mark invoice PAID
                      </span>
                    </div>
                  </button>
                </div>

                {/* Quantity input & Target Node */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block pb-1">
                      {serviceType === "SMS_CREDITS" ? "SMS Credits to Allocate" : 
                       serviceType === "PLATFORM_CREDITS" ? "Platform Credits to Allocate" : 
                       "Quantity / Bundled Units"}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="1"
                        value={allocationQuantity}
                        onChange={(e) => setAllocationQuantity(Math.max(1, parseInt(e.target.value) || 0))}
                        className="w-full px-3 py-2 text-xs font-bold font-mono bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500"
                      />
                      <span className="text-xs font-bold text-slate-500 whitespace-nowrap">
                        {serviceType === "SMS_CREDITS" ? "SMS" : "Units"}
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block pb-1">
                      Target Farm Node / Tenant
                    </label>
                    <select
                      value={selectedTenantId}
                      onChange={(e) => setSelectedTenantId(e.target.value)}
                      className="w-full px-3 py-2 text-xs font-bold bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 truncate"
                    >
                      {defaultTenants.map(t => (
                        <option key={t.id} value={t.id}>
                          {t.name} ({t.id})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Balance Impact Live Indicator */}
                {selectedTenant && serviceType === "SMS_CREDITS" && (
                  <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-center justify-between text-xs">
                    <span className="text-emerald-900 font-medium">
                      Tenant SMS Balance Preview:
                    </span>
                    <div className="flex items-center gap-2 font-mono font-bold">
                      <span className="text-slate-600">{selectedTenant.smsCredits ?? 100} Credits</span>
                      <ArrowRight className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700 font-black">
                        {(selectedTenant.smsCredits ?? 100) + allocationQuantity} Credits
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* STEP 3: SUPER ADMIN PASSWORD AUTHENTICATION */}
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-full bg-rose-100 text-rose-700 text-[10px] flex items-center justify-center font-mono">3</span>
                <span>Super Admin Password Confirmation (Mandatory)</span>
              </label>

              <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-3 shadow-inner">
                <div className="flex items-center justify-between text-[11px] text-slate-300">
                  <span className="flex items-center gap-1.5 font-bold">
                    <Lock className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Authorizing as: <strong className="text-emerald-300">{currentAdminEmail}</strong></span>
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">256-Bit Audit Encrypted</span>
                </div>

                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your Super Admin Password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setPasswordError(null);
                    }}
                    autoComplete="current-password"
                    className="w-full pl-3 pr-10 py-2.5 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 font-mono tracking-wide"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-white cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {passwordError && (
                  <div className="p-2 bg-rose-950/80 border border-rose-800 rounded-lg text-xs text-rose-300 flex items-center gap-1.5 font-bold">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    <span>{passwordError}</span>
                  </div>
                )}
              </div>
            </div>

            {/* ACTION ERROR ALERT */}
            {actionError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
                <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{actionError}</span>
              </div>
            )}

            {/* MODAL FOOTER ACTIONS */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={onClose}
                disabled={submitting}
                className="w-full sm:w-auto px-5 py-2.5 text-xs font-bold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={submitting || (!isGatewaySuccessful && !allowManualOverride) || !password.trim()}
                className={`w-full sm:w-auto px-6 py-3 rounded-xl font-black text-xs uppercase tracking-wider transition flex items-center justify-center gap-2 cursor-pointer shadow-md ${
                  submitting || (!isGatewaySuccessful && !allowManualOverride) || !password.trim()
                    ? "bg-slate-200 text-slate-400 cursor-not-allowed"
                    : "bg-[#1D9E75] hover:bg-[#157959] text-white active:scale-98"
                }`}
              >
                {submitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Verifying & Allocating...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirm & Update to Successful</span>
                  </>
                )}
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
}

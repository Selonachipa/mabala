import { safeLocalStorage as localStorage } from "../../utils/safeStorage";
import { safeFetchJsonClient } from "../../App";
import { normalizeZambianMobileNumber } from "../../utils/phoneUtils";

export interface CollectionRequest {
  referenceId: string;
  amount: number;
  narration: string;
  accountNumber: string;
  email: string;
}

export interface DisbursementRequest {
  payoutId: string;
  farmerId: string;
  farmerName: string;
  grossAmount: number;
  netAmount: number;
  farmerFee: number;
  payoutMethod: "bank" | "mobile_money";
  phoneOrAccount: string;
  provider?: string; // Airtel, MTN, Zamtel
}

export interface PaymentResponse {
  referenceId: string;
  status: "Pending" | "Successful" | "Failed";
  message: string;
}

export interface PayoutResponse {
  referenceId: string;
  status: "Pending" | "Successful" | "Failed";
  message: string;
  payoutId: string;
}

export interface FeeConfigItem {
  side: "farmer" | "offtaker";
  ratePercent: number; // e.g. 2.8
  flatFee: number; // e.g. 15.00
  effectiveFrom: string;
  setBy: string;
  notes?: string;
}

export interface PaymentService {
  collect(req: CollectionRequest): Promise<PaymentResponse>;
  disburse(req: DisbursementRequest): Promise<PayoutResponse>;
  checkStatus(referenceId: string): Promise<PaymentResponse>;
}

// In-Memory historical configuration or fetched via LocalStorage
export const DEFAULT_FEE_CONFIGS: FeeConfigItem[] = [
  { side: "farmer", ratePercent: 2.8, flatFee: 15.00, effectiveFrom: "2026-06-19T00:00:00Z", setBy: "Platform Administrator" },
  { side: "offtaker", ratePercent: 2.8, flatFee: 15.00, effectiveFrom: "2026-06-19T00:00:00Z", setBy: "Platform Administrator" }
];

export function getActiveFeeRates(): { farmer: { rate: number; flat: number }; offtaker: { rate: number; flat: number } } {
  const saved = localStorage.getItem("mabala_fee_configs");
  let list: FeeConfigItem[] = DEFAULT_FEE_CONFIGS;
  if (saved) {
    try {
      list = JSON.parse(saved);
    } catch (e) {}
  }
  
  // Find current active rates (latest effective date)
  const now = new Date();
  const farmerRates = list
    .filter(c => c.side === "farmer" && new Date(c.effectiveFrom) <= now)
    .sort((a, b) => new Date(b.effectiveFrom).getTime() - new Date(a.effectiveFrom).getTime());
    
  const offtakerRates = list
    .filter(c => c.side === "offtaker" && new Date(c.effectiveFrom) <= now)
    .sort((a, b) => new Date(b.effectiveFrom).getTime() - new Date(a.effectiveFrom).getTime());

  return {
    farmer: {
      rate: farmerRates[0]?.ratePercent !== undefined ? farmerRates[0].ratePercent : 2.8,
      flat: farmerRates[0]?.flatFee !== undefined ? farmerRates[0].flatFee : 15.00
    },
    offtaker: {
      rate: offtakerRates[0]?.ratePercent !== undefined ? offtakerRates[0].ratePercent : 2.8,
      flat: offtakerRates[0]?.flatFee !== undefined ? offtakerRates[0].flatFee : 15.00
    }
  };
}

export function calculateCustomFees(amount: number) {
  const rates = getActiveFeeRates();
  
  const offtakerFee = Number(((rates.offtaker.rate / 100) * amount + rates.offtaker.flat).toFixed(2));
  const totalOfftakerDebit = Number((amount + offtakerFee).toFixed(2));

  const farmerFee = Number(((rates.farmer.rate / 100) * amount + rates.farmer.flat).toFixed(2));
  const netToFarmer = Number((amount - farmerFee).toFixed(2));

  return {
    grossAmount: amount,
    offtakerFee,
    totalOfftakerDebit,
    farmerFee,
    netToFarmer
  };
}

export class LipilaProvider implements PaymentService {
  async collect(req: CollectionRequest): Promise<PaymentResponse> {
    try {
      const canonicalPhone = normalizeZambianMobileNumber(req.accountNumber);
      const data = await safeFetchJsonClient("/api/payments/collect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          referenceId: req.referenceId,
          amount: req.amount,
          narration: req.narration,
          accountNumber: canonicalPhone,
          email: req.email
        })
      });
      if (data && (data.status === "Failed" || data.status === "Error" || data.success === false)) {
        return {
          referenceId: req.referenceId,
          status: "Failed",
          message: data.message || data.error || "Lipila collection request failed."
        };
      }
      return {
        referenceId: req.referenceId,
        status: data.status === "Successful" ? "Successful" : "Pending",
        message: data.message || "Lipila collection initiated."
      };
    } catch (err: any) {
      console.warn("Lipila Provider collection fetch error:", err.message);
      return {
        referenceId: req.referenceId,
        status: "Failed",
        message: err.message || "Lipila payment gateway collection failed."
      };
    }
  }

  async disburse(req: DisbursementRequest): Promise<PayoutResponse> {
    const referenceId = `payout-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
    try {
      // In compliance with Lipila specifications, we ping our disbursement proxy on server
      const response = await safeFetchJsonClient("/api/payments/disburse", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          referenceId,
          payoutId: req.payoutId,
          farmerId: req.farmerId,
          farmerName: req.farmerName,
          amount: req.netAmount, // Disburse the NET amount to the farmer
          grossAmount: req.grossAmount,
          farmerFee: req.farmerFee,
          accountNumber: normalizeZambianMobileNumber(req.phoneOrAccount),
          payoutMethod: req.payoutMethod,
          provider: req.provider || "MTN",
          narration: `Payout via Mabala for PayoutId: ${req.payoutId}`
        })
      });
      
      const data = response.ok ? await response.json() : null;
      return {
        referenceId,
        status: data?.status === "Successful" ? "Successful" : "Pending",
        payoutId: req.payoutId,
        message: data?.message || "Lipila disbursement scheduled successfully."
      };
    } catch (err: any) {
      console.warn("Lipila disbursement endpoint failed or offline, falling back gracefully for safety:", err.message);
      return {
        referenceId,
        status: "Pending", // Require explicit Lipila API approval
        payoutId: req.payoutId,
        message: "Disbursement scheduled and pending verification."
      };
    }
  }

  async checkStatus(referenceId: string): Promise<PaymentResponse> {
    try {
      const data = await safeFetchJsonClient(`/api/payments/check-status?referenceId=${referenceId}`);
      let mappedStatus: "Successful" | "Pending" | "Failed" = "Pending";
      if (data && (data.status === "Successful" || data.status === "Success" || data.status === "Completed")) {
        mappedStatus = "Successful";
      } else if (data && (data.status === "Failed" || data.status === "Error" || data.status === "Rejected")) {
        mappedStatus = "Failed";
      }
      return {
        referenceId,
        status: mappedStatus,
        message: data?.message || "Retrieved transaction status."
      };
    } catch (err: any) {
      return {
        referenceId,
        status: "Pending",
        message: "Status verification pending confirmation from Lipila gateway."
      };
    }
  }
}

// Global service export
export const paymentService: PaymentService = new LipilaProvider();

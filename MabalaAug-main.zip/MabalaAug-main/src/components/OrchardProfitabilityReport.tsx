import React, { useState, useMemo } from "react";
import { 
  CropCycle, 
  Invoice, 
  CashSale, 
  ExpenseTransaction, 
  BlockProfitabilitySummary,
  BlockRevenuePerformanceSummary
} from "../types";
import { OrchardFinanceService } from "../services/orchardFinanceService";
import { 
  Trees, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  PieChart as PieIcon, 
  BarChart2, 
  Sparkles, 
  Download, 
  Printer, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  ShieldCheck, 
  Layers, 
  ArrowRight,
  Filter,
  Calendar,
  RefreshCw,
  X
} from "lucide-react";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  PieChart as RePieChart, 
  Pie, 
  Cell 
} from "recharts";

interface OrchardProfitabilityReportProps {
  crops: CropCycle[];
  invoices: Invoice[];
  cashSales: CashSale[];
  expenses: ExpenseTransaction[];
  currencySymbol: string;
  activeFarm?: any;
}

const COST_COLORS: Record<string, string> = {
  spraying: "#10b981", // emerald
  fertilizer: "#f59e0b", // amber
  pruning: "#6366f1", // indigo
  labour: "#8b5cf6", // purple
  irrigation: "#0ea5e9", // sky
  equipment: "#f97316", // orange
  other: "#64748b" // slate
};

export default function OrchardProfitabilityReport({
  crops,
  invoices,
  cashSales,
  expenses,
  currencySymbol,
  activeFarm
}: OrchardProfitabilityReportProps) {
  const [selectedBlockId, setSelectedBlockId] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<"summary" | "blocks" | "breakdown">("summary");
  const [aiModalBlock, setAiModalBlock] = useState<CropCycle | null>(null);
  const [aiInsightResult, setAiInsightResult] = useState<any>(null);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  // Retrieve local append-only ledgers
  const tenantId = activeFarm?.id || "tenant-farm";
  const revenueLedger = useMemo(() => OrchardFinanceService.getLocalRevenueLedger(tenantId), [tenantId]);
  const expenseLedger = useMemo(() => OrchardFinanceService.getLocalExpenseLedger(tenantId), [tenantId]);

  // Ensure there are orchard blocks (perennials)
  const orchardBlocks = useMemo(() => {
    let list = (crops || []).filter(c => 
      c.cycleType === "perennial_orchard" || 
      c.orchard !== undefined || 
      (c.cropType && /avocado|orange|citrus|mango|macadamia|banana|guava|apple|peach|pear|plum|lemon|lime|cashew|coffee|tea|pecan|olive|papaya/i.test(c.cropType))
    );

    if (list.length === 0) {
      try {
        const raw = localStorage.getItem("mabala_crops");
        if (raw) {
          const parsed = JSON.parse(raw);
          list = parsed.filter((c: any) => 
            c.cycleType === "perennial_orchard" || 
            c.orchard !== undefined || 
            (c.cropType && /avocado|orange|citrus|mango|macadamia|banana|guava|apple|peach|pear|plum|lemon|lime|cashew|coffee|tea|pecan|olive|papaya/i.test(c.cropType))
          );
        }
      } catch (e) {}
    }

    return list || [];
  }, [crops]);

  // Compute reports using OrchardFinanceService
  const { revenuePerformance, profitability } = useMemo(() => {
    return OrchardFinanceService.computeBlockReports(
      orchardBlocks,
      invoices,
      cashSales,
      expenses,
      revenueLedger,
      expenseLedger
    );
  }, [orchardBlocks, invoices, cashSales, expenses, revenueLedger, expenseLedger]);

  // Farm-level Orchard Totals
  const totals = useMemo(() => {
    const totalProjectedRev = profitability.reduce((sum, p) => sum + p.projectedRevenue, 0);
    const totalActualRev = profitability.reduce((sum, p) => sum + p.actualRevenueToDate, 0);
    const totalActualExp = profitability.reduce((sum, p) => sum + p.actualExpensesToDate, 0);
    const totalNetProfit = totalActualRev - totalActualExp;
    const profitMarginPct = totalActualRev > 0 ? (totalNetProfit / totalActualRev) * 100 : 0;
    const totalTrees = profitability.reduce((sum, p) => sum + p.treeCount, 0);
    const totalHectares = orchardBlocks.reduce((sum, b) => sum + (b.areaHectares || 1), 0);
    const avgRevPerTree = totalTrees > 0 ? totalActualRev / totalTrees : 0;
    const avgCostPerTree = totalTrees > 0 ? totalActualExp / totalTrees : 0;
    const revAttainmentPct = totalProjectedRev > 0 ? (totalActualRev / totalProjectedRev) * 100 : 0;

    return {
      totalProjectedRev,
      totalActualRev,
      totalActualExp,
      totalNetProfit,
      profitMarginPct,
      totalTrees,
      totalHectares,
      avgRevPerTree,
      avgCostPerTree,
      revAttainmentPct
    };
  }, [profitability, orchardBlocks]);

  // Filtered block list
  const filteredBlocks = useMemo(() => {
    if (selectedBlockId === "all") return profitability;
    return profitability.filter(p => p.blockId === selectedBlockId);
  }, [profitability, selectedBlockId]);

  // Aggregate cost task breakdown for charts
  const costTaskChartData = useMemo(() => {
    const breakdownMap: Record<string, number> = {
      spraying: 0,
      fertilizer: 0,
      pruning: 0,
      irrigation: 0,
      equipment: 0,
      other: 0
    };

    profitability.forEach(p => {
      if (selectedBlockId === "all" || p.blockId === selectedBlockId) {
        breakdownMap.spraying += p.expensesBreakdown.spraying || 0;
        breakdownMap.fertilizer += p.expensesBreakdown.fertilizer || 0;
        breakdownMap.pruning += (p.expensesBreakdown.pruning || 0) + (p.expensesBreakdown.labour || 0);
        breakdownMap.irrigation += p.expensesBreakdown.irrigation || 0;
        breakdownMap.equipment += p.expensesBreakdown.equipment || 0;
        breakdownMap.other += p.expensesBreakdown.other || 0;
      }
    });

    return [
      { name: "Pest & Spraying (5340)", task: "spraying", amount: breakdownMap.spraying, color: COST_COLORS.spraying },
      { name: "Fertilizer & Soil (5320)", task: "fertilizer", amount: breakdownMap.fertilizer, color: COST_COLORS.fertilizer },
      { name: "Pruning & Labour (5330)", task: "pruning", amount: breakdownMap.pruning, color: COST_COLORS.pruning },
      { name: "Irrigation (5350)", task: "irrigation", amount: breakdownMap.irrigation, color: COST_COLORS.irrigation },
      { name: "Machinery (5360)", task: "equipment", amount: breakdownMap.equipment, color: COST_COLORS.equipment },
      { name: "Other Ops (5395)", task: "other", amount: breakdownMap.other, color: COST_COLORS.other }
    ].filter(item => item.amount > 0);
  }, [profitability, selectedBlockId]);

  // Comparison Chart Data (Projected vs Actual vs Expense)
  const comparisonChartData = useMemo(() => {
    return profitability.map(p => ({
      name: p.blockName.length > 15 ? p.blockName.substring(0, 15) + "..." : p.blockName,
      Projected: p.projectedRevenue,
      ActualRevenue: p.actualRevenueToDate,
      Expenses: p.actualExpensesToDate,
      NetProfit: p.netProfitToDate
    }));
  }, [profitability]);

  // Trigger AI Variance Diagnosis
  const handleOpenAiModal = (blockProf: BlockProfitabilitySummary) => {
    const rawBlock = orchardBlocks.find(b => b.id === blockProf.blockId) || {
      id: blockProf.blockId,
      cropType: blockProf.fruitType,
      variety: blockProf.variety,
      fieldBlock: blockProf.blockName,
      cycleType: "perennial_orchard"
    } as CropCycle;

    setAiModalBlock(rawBlock);
    setIsGeneratingAi(true);

    const revPerf = revenuePerformance.find(r => r.blockId === blockProf.blockId);

    setTimeout(() => {
      const insight = OrchardFinanceService.generateBlockVarianceAIInsight(
        rawBlock,
        blockProf.actualRevenueToDate,
        blockProf.projectedRevenue,
        revPerf?.actualHarvestUnits,
        revPerf?.projectedHarvestUnits,
        revPerf?.averageSellingPrice,
        revPerf?.projectedPrice
      );
      setAiInsightResult(insight);
      setIsGeneratingAi(false);
    }, 400);
  };

  // CSV Export
  const handleExportCSV = () => {
    const headers = [
      "Block ID",
      "Block Name",
      "Produce Variety",
      "Tree Count",
      "Projected Revenue",
      "Actual Revenue",
      "Attainment %",
      "Spraying Cost (5340)",
      "Fertilizer Cost (5320)",
      "Labour & Pruning (5330)",
      "Irrigation Cost (5350)",
      "Equipment Cost (5360)",
      "Other Cost (5395)",
      "Total Expenses",
      "Net Profit",
      "Margin %",
      "Revenue/Tree",
      "Cost/Tree"
    ];

    const rows = profitability.map(p => {
      const attainmentPct = p.projectedRevenue > 0 ? (p.actualRevenueToDate / p.projectedRevenue) * 100 : 0;
      const revPerTree = p.treeCount > 0 ? p.actualRevenueToDate / p.treeCount : 0;
      const costPerTree = p.treeCount > 0 ? p.actualExpensesToDate / p.treeCount : 0;

      return [
        p.blockId,
        `"${p.blockName}"`,
        `"${p.variety || ''}"`,
        p.treeCount,
        p.projectedRevenue.toFixed(2),
        p.actualRevenueToDate.toFixed(2),
        attainmentPct.toFixed(1) + "%",
        (p.expensesBreakdown?.spraying || 0).toFixed(2),
        (p.expensesBreakdown?.fertilizer || 0).toFixed(2),
        ((p.expensesBreakdown?.pruning || 0) + (p.expensesBreakdown?.labour || 0)).toFixed(2),
        (p.expensesBreakdown?.irrigation || 0).toFixed(2),
        (p.expensesBreakdown?.equipment || 0).toFixed(2),
        (p.expensesBreakdown?.other || 0).toFixed(2),
        p.actualExpensesToDate.toFixed(2),
        p.netProfitToDate.toFixed(2),
        p.profitMarginPct.toFixed(1) + "%",
        revPerTree.toFixed(2),
        costPerTree.toFixed(2)
      ];
    });

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Orchard_Profitability_Report_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white p-6 rounded-2xl shadow-sm border border-emerald-700/50">
        <div className="flex justify-between items-start flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 bg-emerald-700/60 rounded-xl text-emerald-200 backdrop-blur-xs">
                <Trees className="w-6 h-6 text-emerald-300" />
              </span>
              <div>
                <span className="text-[10px] uppercase font-mono tracking-widest text-emerald-300 font-bold">
                  Mabala Orchard & Tree Management ↔ Finance Module Linkage
                </span>
                <h2 className="text-xl font-black tracking-tight text-white flex items-center gap-2">
                  <span>Orchard Block Profitability & AI Variance Insights</span>
                </h2>
              </div>
            </div>
            <p className="text-xs text-emerald-100/90 mt-2 max-w-2xl leading-relaxed">
              Real-time block-attributed profit statements, revenue attainment against planned planting models, 
              double-entry expense categorization (COA 5320–5395), and causal AI variance diagnosis.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleExportCSV}
              className="px-3.5 py-2 bg-emerald-800/80 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 border border-emerald-600 transition-all cursor-pointer shadow-sm"
            >
              <Download className="w-3.5 h-3.5 text-emerald-200" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={() => window.print()}
              className="px-3.5 py-2 bg-white text-emerald-950 hover:bg-emerald-50 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-emerald-800" />
              <span>Print Statement</span>
            </button>
          </div>
        </div>

        {/* Filter Toolbar */}
        <div className="mt-5 pt-4 border-t border-emerald-700/60 flex justify-between items-center flex-wrap gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-emerald-300" />
            <span className="font-bold text-emerald-200 text-[11px]">Filter Block:</span>
            <select
              value={selectedBlockId}
              onChange={e => setSelectedBlockId(e.target.value)}
              className="bg-emerald-950/60 border border-emerald-600 rounded-lg px-2.5 py-1 text-white font-bold text-xs"
            >
              <option value="all">All Orchard Blocks ({profitability.length})</option>
              {profitability.map(p => (
                <option key={p.blockId} value={p.blockId}>{p.blockName} ({p.variety})</option>
              ))}
            </select>
          </div>

          <div className="flex bg-emerald-950/50 p-1 rounded-xl gap-1 font-bold">
            <button
              onClick={() => setActiveTab("summary")}
              className={`px-3 py-1 rounded-lg transition-all ${activeTab === "summary" ? "bg-emerald-600 text-white shadow-xs" : "text-emerald-300 hover:text-white"}`}
            >
              Profitability Overview
            </button>
            <button
              onClick={() => setActiveTab("blocks")}
              className={`px-3 py-1 rounded-lg transition-all ${activeTab === "blocks" ? "bg-emerald-600 text-white shadow-xs" : "text-emerald-300 hover:text-white"}`}
            >
              Block Statements Table
            </button>
            <button
              onClick={() => setActiveTab("breakdown")}
              className={`px-3 py-1 rounded-lg transition-all ${activeTab === "breakdown" ? "bg-emerald-600 text-white shadow-xs" : "text-emerald-300 hover:text-white"}`}
            >
              Cost Task Breakdown
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Projected Revenue */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex justify-between items-center text-slate-500 text-[11px] font-bold uppercase tracking-wider">
            <span>Projected Revenue</span>
            <Calendar className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-xl font-black text-slate-900 font-mono">
            {currencySymbol}{totals.totalProjectedRev.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="text-[11px] text-slate-500 font-medium">
            Aggregated target across {totals.totalTrees} trees ({totals.totalHectares.toFixed(1)} Ha)
          </p>
        </div>

        {/* Total Actual Realized Revenue */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex justify-between items-center text-emerald-800 text-[11px] font-bold uppercase tracking-wider">
            <span>Actual Realized Revenue</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-black text-emerald-800 font-mono">
            {currencySymbol}{totals.totalActualRev.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] font-bold">
            <span className={`px-1.5 py-0.2 rounded text-[10px] ${totals.revAttainmentPct >= 80 ? "bg-emerald-100 text-emerald-800" : totals.revAttainmentPct >= 50 ? "bg-amber-100 text-amber-800" : "bg-rose-100 text-rose-800"}`}>
              {totals.revAttainmentPct.toFixed(1)}% Attainment
            </span>
            <span className="text-slate-400">vs model target</span>
          </div>
        </div>

        {/* Operating Costs Incurred */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex justify-between items-center text-slate-500 text-[11px] font-bold uppercase tracking-wider">
            <span>Actual Orchard Expenses</span>
            <Layers className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-black text-slate-900 font-mono">
            {currencySymbol}{totals.totalActualExp.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="text-[11px] text-slate-500 font-medium">
            Avg {currencySymbol}{totals.avgCostPerTree.toFixed(2)}/tree operational cost
          </p>
        </div>

        {/* Net Operating Surplus / Profit */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex justify-between items-center text-emerald-800 text-[11px] font-bold uppercase tracking-wider">
            <span>Net Orchard Profit</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className={`text-xl font-black font-mono ${totals.totalNetProfit >= 0 ? "text-emerald-800" : "text-rose-700"}`}>
            {currencySymbol}{totals.totalNetProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] font-bold">
            <span className={`px-1.5 py-0.2 rounded text-[10px] ${totals.profitMarginPct >= 30 ? "bg-emerald-100 text-emerald-800" : totals.profitMarginPct >= 0 ? "bg-amber-100 text-amber-800" : "bg-rose-100 text-rose-800"}`}>
              {totals.profitMarginPct.toFixed(1)}% Margin
            </span>
            <span className="text-slate-400">Net Surplus</span>
          </div>
        </div>
      </div>

      {/* TAB 1: SUMMARY CHARTS */}
      {activeTab === "summary" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Revenue vs Projection Bar Chart */}
          <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <BarChart2 className="w-4 h-4 text-emerald-600" />
                  <span>Block Financial Comparison (Projected vs Actual vs Net Profit)</span>
                </h3>
                <p className="text-[11px] text-slate-500">Evaluating revenue realization and operating margins per block.</p>
              </div>
            </div>

            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={comparisonChartData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#475569" }} interval={0} angle={-15} textAnchor="end" />
                  <YAxis tick={{ fontSize: 11, fill: "#475569" }} tickFormatter={val => `${currencySymbol}${val >= 1000 ? (val/1000).toFixed(0) + 'k' : val}`} />
                  <Tooltip 
                    formatter={(value: any) => [`${currencySymbol}${Number(value).toLocaleString(undefined, { minimumFractionDigits: 2 })}`, ""]}
                    contentStyle={{ backgroundColor: "#0f172a", borderRadius: "8px", color: "#fff", fontSize: "11px" }}
                  />
                  <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "10px" }} />
                  <Bar dataKey="Projected" fill="#94a3b8" name="Projected Model" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="ActualRevenue" fill="#10b981" name="Actual Revenue" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Expenses" fill="#f59e0b" name="Operating Expenses" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="NetProfit" fill="#6366f1" name="Net Profit" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Cost Allocation Pie Chart */}
          <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4 flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <PieIcon className="w-4 h-4 text-emerald-600" />
                <span>Cost Task Allocation</span>
              </h3>
              <p className="text-[11px] text-slate-500">Distribution of direct orchard operating costs across COA ledger accounts.</p>
            </div>

            <div className="h-52 w-full my-auto">
              <ResponsiveContainer width="100%" height="100%">
                <RePieChart>
                  <Pie
                    data={costTaskChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={75}
                    paddingAngle={3}
                    dataKey="amount"
                  >
                    {costTaskChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: any) => [`${currencySymbol}${Number(value).toLocaleString(undefined, { minimumFractionDigits: 2 })}`, ""]}
                    contentStyle={{ backgroundColor: "#0f172a", borderRadius: "8px", color: "#fff", fontSize: "11px" }}
                  />
                </RePieChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-1.5 pt-3 border-t border-slate-100 text-[10px]">
              {costTaskChartData.map(item => (
                <div key={item.task} className="flex justify-between items-center">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="font-semibold text-slate-700">{item.name}</span>
                  </div>
                  <span className="font-mono font-bold text-slate-900">{currencySymbol}{item.amount.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DETAILED BLOCK PROFITABILITY STATEMENTS TABLE */}
      {(activeTab === "blocks" || activeTab === "summary") && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
          <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center flex-wrap gap-4">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <Trees className="w-4 h-4 text-emerald-600" />
                <span>Orchard Block Profitability Statements (Multi-Unit Ledger Ledger)</span>
              </h3>
              <p className="text-[11px] text-slate-500">Every line item auto-posted from Invoice/Credit sales and double-entry expense vouchers.</p>
            </div>
            <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/70 border border-emerald-200 px-2.5 py-1 rounded-full uppercase">
              Immutable Subcollection Traceability
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-[10px] uppercase font-bold text-slate-500 bg-slate-100/70 border-b border-slate-200">
                <tr>
                  <th className="p-3.5">Block / Variety</th>
                  <th className="p-3.5 text-center">Trees / Ha</th>
                  <th className="p-3.5 text-right">Projected Rev</th>
                  <th className="p-3.5 text-right">Actual Revenue</th>
                  <th className="p-3.5 text-center">Attainment</th>
                  <th className="p-3.5 text-right">Direct Expenses</th>
                  <th className="p-3.5 text-right">Net Profit</th>
                  <th className="p-3.5 text-center">Margin %</th>
                  <th className="p-3.5 text-center">AI Diagnostics</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                {filteredBlocks.map(block => {
                  const isProfitable = block.netProfitToDate >= 0;
                  const revAttainmentPct = block.projectedRevenue > 0 ? (block.actualRevenueToDate / block.projectedRevenue) * 100 : 0;
                  const revPerTree = block.treeCount > 0 ? block.actualRevenueToDate / block.treeCount : 0;
                  const costPerTree = block.treeCount > 0 ? block.actualExpensesToDate / block.treeCount : 0;

                  return (
                    <tr key={block.blockId} className="hover:bg-slate-50/70 transition-colors">
                      {/* Block Name */}
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <Trees className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{block.blockName}</span>
                        </div>
                        <div className="text-[10.5px] text-slate-500 font-sans">
                          {block.fruitType} • <span className="italic">{block.variety || "Perennial Tree Crop"}</span>
                        </div>
                      </td>

                      {/* Tree Count & Area */}
                      <td className="p-3.5 text-center font-mono">
                        <div className="font-bold text-slate-800">{block.treeCount} trees</div>
                        <div className="text-[10px] text-slate-400 font-sans">
                          {currencySymbol}{revPerTree.toFixed(1)}/tree
                        </div>
                      </td>

                      {/* Projected Revenue */}
                      <td className="p-3.5 text-right font-mono font-bold text-slate-600">
                        {currencySymbol}{block.projectedRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>

                      {/* Actual Revenue */}
                      <td className="p-3.5 text-right font-mono font-black text-emerald-800">
                        {currencySymbol}{block.actualRevenueToDate.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>

                      {/* Attainment Progress */}
                      <td className="p-3.5 text-center">
                        <div className="inline-flex flex-col items-center gap-1 w-24">
                          <span className={`text-[10.5px] font-mono font-bold ${revAttainmentPct >= 80 ? "text-emerald-700" : revAttainmentPct >= 50 ? "text-amber-700" : "text-rose-700"}`}>
                            {revAttainmentPct.toFixed(1)}%
                          </span>
                          <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                            <div 
                              className={`h-full rounded-full ${revAttainmentPct >= 80 ? "bg-emerald-600" : revAttainmentPct >= 50 ? "bg-amber-500" : "bg-rose-500"}`}
                              style={{ width: `${Math.min(100, Math.max(0, revAttainmentPct))}%` }}
                            />
                          </div>
                        </div>
                      </td>

                      {/* Direct Expenses */}
                      <td className="p-3.5 text-right font-mono font-bold text-slate-800">
                        <div>{currencySymbol}{block.actualExpensesToDate.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                        <div className="text-[9.5px] text-slate-400 font-sans">
                          {currencySymbol}{costPerTree.toFixed(1)}/tree
                        </div>
                      </td>

                      {/* Net Profit */}
                      <td className="p-3.5 text-right font-mono font-black">
                        <span className={isProfitable ? "text-emerald-700" : "text-rose-700"}>
                          {currencySymbol}{block.netProfitToDate.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </td>

                      {/* Margin % */}
                      <td className="p-3.5 text-center font-mono font-bold">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] ${block.profitMarginPct >= 30 ? "bg-emerald-100 text-emerald-800" : block.profitMarginPct >= 0 ? "bg-amber-100 text-amber-800" : "bg-rose-100 text-rose-800"}`}>
                          {block.profitMarginPct.toFixed(1)}%
                        </span>
                      </td>

                      {/* AI Diagnostic Trigger */}
                      <td className="p-3.5 text-center">
                        <button
                          onClick={() => handleOpenAiModal(block)}
                          className="px-2.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white rounded-lg font-bold text-[10.5px] flex items-center gap-1 shadow-2xs transition-all cursor-pointer mx-auto"
                        >
                          <Sparkles className="w-3 h-3 text-amber-300" />
                          <span>AI Variance</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
                {profitability.length === 0 && (
                  <tr>
                    <td colSpan={9} className="p-8 text-center text-slate-400">
                      <div className="space-y-1.5">
                        <p className="font-bold text-slate-700 text-xs">No Perennial Orchard Blocks Configured</p>
                        <p className="text-[11px] text-slate-400">Add an orchard block or perennial crop cycle in the Orchard & Tree Management module to view real-time profitability statements and AI variance analytics.</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: COST TASK BREAKDOWN GRID */}
      {activeTab === "breakdown" && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-6">
          <div>
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-emerald-600" />
              <span>Orchard Cost Task Ledger Categorization (COA 5320 – 5395)</span>
            </h3>
            <p className="text-[11px] text-slate-500">Granular view of inputs, chemical spray rounds, and tree maintenance by Chart of Accounts debit ledger.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {costTaskChartData.map(item => (
              <div key={item.task} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-slate-800">{item.name}</span>
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                </div>
                <div className="text-lg font-black text-slate-900 font-mono">
                  {currencySymbol}{item.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div className="text-[10.5px] text-slate-500">
                  {((item.amount / (totals.totalActualExp || 1)) * 100).toFixed(1)}% of total orchard operating expenditure
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* AI VARIANCE INSIGHT MODAL */}
      {aiModalBlock && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="px-6 py-4 bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white flex justify-between items-center">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-emerald-700/70 rounded-xl text-amber-300">
                  <Sparkles className="w-5 h-5" />
                </span>
                <div>
                  <span className="text-[9.5px] uppercase font-mono tracking-widest text-emerald-300 font-bold">
                    Orchard Causal Variance Intelligence
                  </span>
                  <h3 className="text-base font-black">
                    {aiModalBlock.fieldBlock || aiModalBlock.cropType} Diagnostic
                  </h3>
                </div>
              </div>
              <button
                onClick={() => { setAiModalBlock(null); setAiInsightResult(null); }}
                className="p-1.5 bg-emerald-950/60 hover:bg-emerald-950 text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-700">
              {isGeneratingAi ? (
                <div className="p-10 flex flex-col items-center justify-center gap-3 text-emerald-700">
                  <RefreshCw className="w-8 h-8 animate-spin" />
                  <span className="font-bold text-xs">Analyzing canopy metrics, yield indices, and COA expense ledger...</span>
                </div>
              ) : aiInsightResult ? (
                <div className="space-y-4">
                  {/* Synthesis Callout */}
                  <div className={`p-4 rounded-2xl border ${aiInsightResult.classification === "surplus" ? "bg-emerald-50 border-emerald-200 text-emerald-900" : aiInsightResult.classification === "deficit" ? "bg-rose-50 border-rose-200 text-rose-900" : "bg-slate-50 border-slate-200 text-slate-900"}`}>
                    <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider mb-1">
                      {aiInsightResult.classification === "surplus" ? (
                        <TrendingUp className="w-4 h-4 text-emerald-600" />
                      ) : aiInsightResult.classification === "deficit" ? (
                        <TrendingDown className="w-4 h-4 text-rose-600" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      )}
                      <span>
                        {aiInsightResult.classification.toUpperCase()} • {aiInsightResult.driverType.toUpperCase()}-DRIVEN VARIANCE
                      </span>
                    </div>
                    <p className="text-xs font-semibold leading-relaxed">
                      {aiInsightResult.summary}
                    </p>
                  </div>

                  {/* Likely Causal Factors */}
                  <div>
                    <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-800 mb-2 flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                      <span>Identified Causal Factors</span>
                    </h4>
                    <div className="space-y-2">
                      {aiInsightResult.likelyCauses.map((cause: any, idx: number) => (
                        <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                          <span className="px-2 py-0.5 bg-white text-slate-800 font-bold rounded text-[10px] border border-slate-300 inline-block">
                            {cause.tag}
                          </span>
                          <p className="text-[11px] text-slate-600 leading-normal font-medium">
                            {cause.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Horticultural & Commercial Recommendations */}
                  <div>
                    <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-800 mb-2 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Recommended Management Actions</span>
                    </h4>
                    <div className="space-y-1.5">
                      {aiInsightResult.recommendations.map((rec: string, idx: number) => (
                        <div key={idx} className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-[11px] text-emerald-950 font-medium flex items-start gap-2">
                          <span className="w-4 h-4 bg-emerald-600 text-white rounded-full flex items-center justify-center font-bold text-[9.5px] shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <span>{rec}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : null}
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => { setAiModalBlock(null); setAiInsightResult(null); }}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Close Diagnostic
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

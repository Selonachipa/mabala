/**
 * AGC Super Admin Platform Governance Panel Component
 * Controls Financier/Insurer Licensing, Blended Guarantee Facility Commitments, and External API Gateway Billing
 */

import React, { useState, useEffect } from "react";
import {
  ShieldAlert,
  Sliders,
  DollarSign,
  Building2,
  Database,
  Lock,
  Plus,
  CheckCircle2,
  AlertTriangle,
  Globe,
  Tag
} from "lucide-react";
import { ApiAccessConfig, ApiConfigRates, GuaranteeFundLedger } from "../../types";
import { InsurerPortal } from "./InsurerPortal";
import {
  getApiAccessConfigs,
  getApiConfigRates,
  agcAdminSetApiRates,
  updateApiAccessConfig,
  getGuaranteeFundLedger,
  agcCommitGuaranteeFund
} from "../../services/agcService";

interface SuperAdminAgcPanelProps {
  currencySymbol?: string;
}

export const SuperAdminAgcPanel: React.FC<SuperAdminAgcPanelProps> = ({
  currencySymbol = "ZMW"
}) => {
  const [activeTab, setActiveTab] = useState<'billing' | 'guarantee' | 'licensing' | 'insurer-rates'>('billing');
  const [apiConfigs, setApiConfigs] = useState<ApiAccessConfig[]>([]);
  const [apiRates, setApiRates] = useState<ApiConfigRates>({
    defaultRatePerCall: 20,
    ratesByScope: { cropRecords: 15, farmRecords: 15, financialData: 25, creditScore: 30, premiumRates: 10 },
    defaultFreeTrialCalls: 10
  });
  const [guaranteeLedger, setGuaranteeLedger] = useState<GuaranteeFundLedger>({ balance: 0, committedBy: null, committedAt: null });

  // Onboarded Institutions state for AGC Credit capabilities (institution_financier / institution_insurer)
  const [licensedInstitutions, setLicensedInstitutions] = useState([
    {
      id: "inst_zanaco",
      name: "Zambian National Commercial Bank MFI",
      capability: "institution_financier",
      licenseNumber: "BoZ-MFI-9021",
      verificationStatus: "verified",
      maxFacilityLimit: 50000000,
      activeLoansCount: 1420,
      contactEmail: "agricredit@zanaco.co.zm",
      status: "active"
    },
    {
      id: "inst_znbs",
      name: "Zambia National Building Society Credit",
      capability: "institution_financier",
      licenseNumber: "BoZ-MFI-8820",
      verificationStatus: "verified",
      maxFacilityLimit: 30000000,
      activeLoansCount: 890,
      contactEmail: "smallholder@znbs.co.zm",
      status: "active"
    },
    {
      id: "inst_mayfair",
      name: "Mayfair Insurance Zambia (Agri-Underwriter)",
      capability: "institution_insurer",
      licenseNumber: "PIA-INS-7712",
      verificationStatus: "verified",
      maxFacilityLimit: 20000000,
      activeLoansCount: 2310,
      contactEmail: "cropinsurance@mayfair.co.zm",
      status: "active"
    },
    {
      id: "inst_prime",
      name: "Prime Insurance Ltd",
      capability: "institution_insurer",
      licenseNumber: "PIA-INS-6601",
      verificationStatus: "pending",
      maxFacilityLimit: 15000000,
      activeLoansCount: 0,
      contactEmail: "agri@primeinsure.zm",
      status: "active"
    }
  ]);

  // Modal state for onboarding new institution
  const [showAddInstModal, setShowAddInstModal] = useState(false);
  const [newInstForm, setNewInstForm] = useState({
    name: "",
    capability: "institution_financier",
    licenseNumber: "",
    maxFacilityLimit: 10000000,
    contactEmail: ""
  });

  // Guarantee commitment modal state
  const [showCommitModal, setShowCommitModal] = useState(false);
  const [dfiAmount, setDfiAmount] = useState(1000000); // K1,000,000 ZMW default commitment
  const [dfiName, setDfiName] = useState("IFAD / World Bank Agri-Guarantee Grant");

  // Save notification state
  const [saveMsg, setSaveMsg] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setApiConfigs(getApiAccessConfigs());
    setApiRates(getApiConfigRates());
    setGuaranteeLedger(getGuaranteeFundLedger());
  };

  const handleSaveRates = (e: React.FormEvent) => {
    e.preventDefault();
    agcAdminSetApiRates(apiRates);
    setSaveMsg("API Gateway rates updated successfully!");
    setTimeout(() => setSaveMsg(null), 3000);
  };

  const handleToggleScope = (config: ApiAccessConfig, scope: string) => {
    const hasScope = config.enabledScopes.includes(scope);
    const updatedScopes = hasScope
      ? config.enabledScopes.filter(s => s !== scope)
      : [...config.enabledScopes, scope];

    const updatedConfig = { ...config, enabledScopes: updatedScopes };
    updateApiAccessConfig(updatedConfig);
    loadData();
  };

  const handleToggleStatus = (config: ApiAccessConfig) => {
    const newStatus = config.status === 'active' ? 'suspended' : 'active';
    const updatedConfig = { ...config, status: newStatus as any };
    updateApiAccessConfig(updatedConfig);
    loadData();
  };

  const handleCommitGuarantee = (e: React.FormEvent) => {
    e.preventDefault();
    agcCommitGuaranteeFund(dfiAmount, dfiName);
    setShowCommitModal(false);
    loadData();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30 uppercase tracking-wider">
              Super Admin Control
            </span>
            <span className="text-xs text-slate-400">AGC Infrastructure Platform Governance</span>
          </div>
          <h1 className="text-2xl font-bold mt-1 text-slate-100 flex items-center gap-2">
            AGC Platform & API Billing Governance
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure external institution data access pricing (K20/call default, 10 free trial calls) and DFI/Donor guarantee commitments.
          </p>
        </div>

        {/* Sub-tabs */}
        <div className="flex gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('billing')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'billing' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            API Rates & Scope Billing
          </button>
          <button
            onClick={() => setActiveTab('guarantee')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'guarantee' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Guarantee Fund Ledger
          </button>
          <button
            onClick={() => setActiveTab('licensing')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'licensing' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Institution Licensing & Onboarding
          </button>
          <button
            onClick={() => setActiveTab('insurer-rates')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'insurer-rates' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
            id="superadmin-insurer-rates-tab-btn"
          >
            Insurer Premium Rates Matrix
          </button>
        </div>
      </div>

      {saveMsg && (
        <div className="p-4 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex justify-between items-center">
          <span>✓ {saveMsg}</span>
          <button onClick={() => setSaveMsg(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* TAB 4: INSURER PREMIUM RATES MATRIX */}
      {activeTab === 'insurer-rates' && (
        <div className="space-y-4">
          <InsurerPortal isSuperAdmin={true} currencySymbol={currencySymbol} />
        </div>
      )}

      {/* TAB 1: API RATES & SCOPE BILLING */}
      {activeTab === 'billing' && (
        <div className="space-y-6">
          {/* Default Rates Configuration Form */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Sliders className="w-5 h-5 text-emerald-400" />
              Global External API Gateway Rates (Default: K20 / call, 10 Free Calls)
            </h3>

            <form onSubmit={handleSaveRates} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Default Rate per Call ({currencySymbol})</label>
                  <input
                    type="number"
                    value={apiRates.defaultRatePerCall}
                    onChange={(e) => setApiRates({ ...apiRates, defaultRatePerCall: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 text-sm font-bold font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Default Free Trial Calls Count</label>
                  <input
                    type="number"
                    value={apiRates.defaultFreeTrialCalls}
                    onChange={(e) => setApiRates({ ...apiRates, defaultFreeTrialCalls: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 text-sm font-bold font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Per-scope Rate Customizer */}
              <div className="pt-2">
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Scope Price Overrides ({currencySymbol})</label>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-xs">
                  {Object.entries(apiRates.ratesByScope).map(([scopeKey, price]) => (
                    <div key={scopeKey} className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                      <span className="text-slate-400 font-mono text-[11px] block">{scopeKey}</span>
                      <input
                        type="number"
                        value={price}
                        onChange={(e) => setApiRates({
                          ...apiRates,
                          ratesByScope: { ...apiRates.ratesByScope, [scopeKey]: Number(e.target.value) }
                        })}
                        className="w-full mt-1 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-emerald-400 font-bold font-mono text-xs focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-bold text-white shadow-lg transition-colors"
              >
                Save Global Gateway Pricing
              </button>
            </form>
          </div>

          {/* Registered Institutions Access Controls */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-emerald-400" />
              External Institution Gateway Provisioning & Scope Rights
            </h3>

            <div className="space-y-3">
              {apiConfigs.map((config) => (
                <div key={config.institutionId} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-sm text-slate-200">{config.institutionName}</h4>
                      <span className="text-xs text-slate-400 font-mono">Institution ID: {config.institutionId}</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-xs text-slate-400 font-mono">
                        Trial Calls Remaining: <strong className="text-emerald-300">{config.freeTrialCallsRemaining}</strong>
                      </span>

                      <button
                        onClick={() => handleToggleStatus(config)}
                        className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                          config.status === 'active'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-950 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {config.status.toUpperCase()}
                      </button>
                    </div>
                  </div>

                  {/* Scope Toggles */}
                  <div>
                    <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">Permitted Data Scopes:</span>
                    <div className="flex flex-wrap gap-2">
                      {['cropRecords', 'farmRecords', 'financialData', 'creditScore', 'premiumRates'].map((scope) => {
                        const enabled = config.enabledScopes.includes(scope);
                        return (
                          <button
                            key={scope}
                            onClick={() => handleToggleScope(config, scope)}
                            className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors border ${
                              enabled
                                ? 'bg-emerald-600/30 text-emerald-300 border-emerald-500/40'
                                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                            }`}
                          >
                            {enabled ? '✓ ' : '+ '}{scope}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: GUARANTEE FUND LEDGER */}
      {activeTab === 'guarantee' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <Database className="w-5 h-5 text-emerald-400" />
                DFI / Donor Blended Guarantee Facility Ledger
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Stays dormant until a valid DFI/donor commitment is explicitly written here by Super Admin.
              </p>
            </div>

            <button
              onClick={() => setShowCommitModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg transition-colors flex items-center gap-1.5"
            >
              + Commit DFI Grant / Guarantee Capital
            </button>
          </div>

          <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col md:flex-row justify-between items-center gap-6">
            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Current Fund Balance</span>
              <div className="text-4xl font-black text-emerald-400 font-mono mt-1">
                {currencySymbol} {guaranteeLedger.balance.toLocaleString()}
              </div>
              <div className="text-xs text-slate-300 mt-2">
                {guaranteeLedger.balance > 0 ? (
                  <span>Active Guarantee Capital committed by <strong className="text-emerald-300">{guaranteeLedger.committedBy}</strong></span>
                ) : (
                  <span className="text-amber-400 font-semibold">Facility is currently DORMANT. No active donor commitments.</span>
                )}
              </div>
            </div>

            <div className="text-right text-xs text-slate-400 space-y-1">
              <div>Last Commitment Timestamp:</div>
              <div className="font-mono text-slate-200 font-semibold">{guaranteeLedger.committedAt || 'None'}</div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: INSTITUTION LICENSING & ONBOARDING */}
      {activeTab === 'licensing' && (
        <div className="space-y-6">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-4">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-emerald-400" />
                  AGC Institution Capability Licensing & Verification
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Verify regulatory licensing (Bank of Zambia / Pensions & Insurance Authority) for institutions with <code className="text-emerald-300 bg-slate-950 px-1 py-0.5 rounded">institution_financier</code> or <code className="text-blue-300 bg-slate-950 px-1 py-0.5 rounded">institution_insurer</code> capabilities.
                </p>
              </div>

              <button
                onClick={() => setShowAddInstModal(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-semibold text-white shadow-lg shadow-emerald-950/50 flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Onboard Licensed Institution
              </button>
            </div>

            {/* Institution Grid / Table */}
            <div className="space-y-3 mt-4">
              {licensedInstitutions.map((inst) => (
                <div key={inst.id} className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-100">{inst.name}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        inst.capability === 'institution_financier' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                      }`}>
                        {inst.capability}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        inst.verificationStatus === 'verified' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}>
                        {inst.verificationStatus === 'verified' ? '✓ Verified License' : '⏳ Pending Audit'}
                      </span>
                    </div>

                    <div className="text-xs text-slate-400 flex flex-wrap gap-4 font-mono">
                      <span>Statutory License: <strong className="text-slate-200">{inst.licenseNumber}</strong></span>
                      <span>Email: <strong className="text-slate-300">{inst.contactEmail}</strong></span>
                      <span>Active Facilities: <strong className="text-emerald-400">{inst.activeLoansCount}</strong></span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-right">
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Max Credit Facility Limit</div>
                      <div className="text-sm font-bold text-emerald-400 font-mono">
                        {currencySymbol} {inst.maxFacilityLimit.toLocaleString()}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        const updated = licensedInstitutions.map(i => i.id === inst.id ? { ...i, verificationStatus: i.verificationStatus === 'verified' ? 'pending' : 'verified' } : i);
                        setLicensedInstitutions(updated);
                        setSaveMsg(`Updated verification status for ${inst.name}`);
                        setTimeout(() => setSaveMsg(null), 3000);
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                        inst.verificationStatus === 'verified' ? 'bg-slate-800 hover:bg-slate-700 text-slate-300' : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                      }`}
                    >
                      {inst.verificationStatus === 'verified' ? 'Suspend License' : 'Verify & Approve'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Add New Licensed Institution */}
      {showAddInstModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 text-slate-100 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-emerald-400" />
              Onboard Institution (Financier / Insurer Capability)
            </h3>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const newInst = {
                  id: "inst_" + Date.now(),
                  name: newInstForm.name,
                  capability: newInstForm.capability,
                  licenseNumber: newInstForm.licenseNumber,
                  verificationStatus: "verified",
                  maxFacilityLimit: newInstForm.maxFacilityLimit,
                  activeLoansCount: 0,
                  contactEmail: newInstForm.contactEmail,
                  status: "active"
                };
                setLicensedInstitutions(prev => [...prev, newInst]);
                setShowAddInstModal(false);
                setNewInstForm({ name: "", capability: "institution_financier", licenseNumber: "", maxFacilityLimit: 10000000, contactEmail: "" });
                setSaveMsg(`Successfully onboarded ${newInstForm.name}!`);
                setTimeout(() => setSaveMsg(null), 3000);
              }}
              className="space-y-3 text-xs"
            >
              <div>
                <label className="block text-slate-400 mb-1">Institution Legal Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Absa Bank Zambia Agriculture Division"
                  value={newInstForm.name}
                  onChange={(e) => setNewInstForm({ ...newInstForm, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">AGC Capability</label>
                  <select
                    value={newInstForm.capability}
                    onChange={(e) => setNewInstForm({ ...newInstForm, capability: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                  >
                    <option value="institution_financier">institution_financier (Credit Provider)</option>
                    <option value="institution_insurer">institution_insurer (Weather Index)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">BoZ / PIA License No.</label>
                  <input
                    type="text"
                    required
                    placeholder="BoZ-MFI-XXXX"
                    value={newInstForm.licenseNumber}
                    onChange={(e) => setNewInstForm({ ...newInstForm, licenseNumber: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Max Facility Limit ({currencySymbol})</label>
                  <input
                    type="number"
                    step="500000"
                    required
                    value={newInstForm.maxFacilityLimit}
                    onChange={(e) => setNewInstForm({ ...newInstForm, maxFacilityLimit: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Contact Email</label>
                  <input
                    type="email"
                    required
                    placeholder="agri@bank.zm"
                    value={newInstForm.contactEmail}
                    onChange={(e) => setNewInstForm({ ...newInstForm, contactEmail: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddInstModal(false)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-white shadow-lg shadow-emerald-950/50"
                >
                  Confirm & Onboard
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Commit DFI Guarantee Fund */}
      {showCommitModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-slate-100 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Database className="w-5 h-5 text-emerald-400" />
              Write DFI Guarantee Fund Commitment
            </h3>

            <form onSubmit={handleCommitGuarantee} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Donor / DFI Partner Name</label>
                <input
                  type="text"
                  required
                  value={dfiName}
                  onChange={(e) => setDfiName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Guarantee Fund Commitment Amount ({currencySymbol})</label>
                <input
                  type="number"
                  step="100000"
                  required
                  value={dfiAmount}
                  onChange={(e) => setDfiAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 text-sm font-bold font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCommitModal(false)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-white shadow-lg shadow-emerald-950/50"
                >
                  Write Commitment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

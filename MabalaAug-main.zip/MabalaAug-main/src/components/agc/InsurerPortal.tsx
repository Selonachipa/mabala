/**
 * AGC Insurer Self-Service Portal Component
 * Self-service Premium Rates Manager & Parametric Claim Settlement Engine
 */

import React, { useState, useEffect } from "react";
import {
  ShieldCheck,
  Plus,
  Umbrella,
  FileCheck2,
  CheckCircle2,
  Percent,
  CloudRain,
  Pencil,
  Trash2,
  AlertTriangle,
  Sliders
} from "lucide-react";
import { InsurerPremiumRate } from "../../types";
import {
  getInsurerPremiumRates,
  agcInsurerSetPremiumRate,
  agcUpdateInsurerPremiumRate,
  agcDeleteInsurerPremiumRate
} from "../../services/agcService";

interface InsurerPortalProps {
  insurerInstitutionId?: string;
  currencySymbol?: string;
  isSuperAdmin?: boolean;
}

export const InsurerPortal: React.FC<InsurerPortalProps> = ({
  insurerInstitutionId = "inst_mabala_insurance",
  currencySymbol = "ZMW",
  isSuperAdmin = true
}) => {
  const [rates, setRates] = useState<InsurerPremiumRate[]>([]);
  const [showAddRateModal, setShowAddRateModal] = useState(false);
  const [editingRate, setEditingRate] = useState<InsurerPremiumRate | null>(null);
  const [deleteConfirmRateId, setDeleteConfirmRateId] = useState<string | null>(null);

  // Form state for Create
  const [insurerName, setInsurerName] = useState("Mabala General Insurance Zambia");
  const [cropOrCategory, setCropOrCategory] = useState("Maize & Grains");
  const [region, setRegion] = useState("Region IIa (Central/Southern)");
  const [loanSizeBand, setLoanSizeBand] = useState("K5,000 - K50,000");
  const [ratePct, setRatePct] = useState(3.5);
  const [setBy, setSetBy] = useState("Mabala Actuarial Admin");

  // Form state for Edit
  const [editInsurerName, setEditInsurerName] = useState("");
  const [editCropOrCategory, setEditCropOrCategory] = useState("");
  const [editRegion, setEditRegion] = useState("");
  const [editLoanSizeBand, setEditLoanSizeBand] = useState("");
  const [editRatePct, setEditRatePct] = useState(3.5);
  const [editSetBy, setEditSetBy] = useState("");

  useEffect(() => {
    loadRates();
  }, [insurerInstitutionId]);

  const loadRates = () => {
    const list = getInsurerPremiumRates();
    setRates(list);
  };

  const handleCreateRate = (e: React.FormEvent) => {
    e.preventDefault();
    agcInsurerSetPremiumRate({
      insurerInstitutionId,
      insurerName: insurerName || "Mabala General Insurance Zambia",
      cropOrCategory,
      region,
      loanSizeBand,
      ratePct,
      effectiveFrom: new Date().toISOString().split("T")[0],
      setBy
    });

    setShowAddRateModal(false);
    loadRates();
  };

  const startEditRate = (rate: InsurerPremiumRate) => {
    setEditingRate(rate);
    setEditInsurerName(rate.insurerName || "Mabala General Insurance Zambia");
    setEditCropOrCategory(rate.cropOrCategory || "");
    setEditRegion(rate.region || "");
    setEditLoanSizeBand(rate.loanSizeBand || "");
    setEditRatePct(rate.ratePct || 0);
    setEditSetBy(rate.setBy || "Super Admin");
  };

  const handleUpdateRate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRate) return;

    agcUpdateInsurerPremiumRate(editingRate.rateId, {
      insurerName: editInsurerName,
      cropOrCategory: editCropOrCategory,
      region: editRegion,
      loanSizeBand: editLoanSizeBand,
      ratePct: editRatePct,
      setBy: editSetBy
    });

    setEditingRate(null);
    loadRates();
  };

  const handleDeleteRate = (rateId: string) => {
    agcDeleteInsurerPremiumRate(rateId);
    setDeleteConfirmRateId(null);
    loadRates();
  };

  const rateToDelete = rates.find(r => r.rateId === deleteConfirmRateId);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              Insurer Self-Service Portal
            </span>
            {isSuperAdmin && (
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                Super Admin Edit & Governance Mode
              </span>
            )}
            <span className="text-xs text-slate-400">Parametric Crop Insurance & Premium Rates</span>
          </div>
          <h1 className="text-2xl font-bold mt-1 text-slate-100 flex items-center gap-2">
            Mabala Insurance Manager
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Set crop cover rates independently. Surfaced live during farmer credit checkout.
          </p>
        </div>

        <button
          onClick={() => setShowAddRateModal(true)}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-semibold text-white shadow-lg shadow-emerald-950/50 transition-colors flex items-center gap-1.5 cursor-pointer"
          id="insurer-publish-new-rate-btn"
        >
          <Plus className="w-4 h-4" /> Publish New Premium Rate
        </button>
      </div>

      {/* Rates Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Umbrella className="w-5 h-5 text-indigo-400" />
            Self-Service Insurer Premium Rates Matrix
          </h3>
          <span className="text-xs font-mono text-slate-400">
            {rates.length} Configured Rate Rules
          </span>
        </div>

        {rates.length === 0 ? (
          <div className="p-8 text-center text-slate-400 border border-slate-800 rounded-xl bg-slate-950/50 space-y-2">
            <Umbrella className="w-8 h-8 mx-auto text-slate-600" />
            <p className="text-xs font-medium">No premium rate matrix rules currently configured.</p>
            <button
              onClick={() => setShowAddRateModal(true)}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg transition"
            >
              Configure First Rate Rule
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {rates.map((rate) => (
              <div key={rate.rateId} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3 relative group">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-sm text-slate-200">{rate.cropOrCategory}</h4>
                    <div className="text-xs text-slate-400">{rate.insurerName}</div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-sm font-black rounded-lg font-mono">
                      {rate.ratePct}% Rate
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-slate-900/80 rounded-lg text-xs space-y-1">
                  <div className="flex justify-between text-slate-400">
                    <span>Target Region:</span>
                    <span className="text-slate-200">{rate.region || 'All AEZ Regions'}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Eligible Loan Band:</span>
                    <span className="text-slate-200">{rate.loanSizeBand || 'All Loan Amounts'}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Effective Date:</span>
                    <span className="text-slate-200 font-mono">{rate.effectiveFrom}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                  <div className="text-[10px] text-slate-300">
                    Configured by: <strong className="text-indigo-300">{rate.setBy}</strong>
                  </div>

                  {/* Super Admin Edit & Delete Action Buttons */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => startEditRate(rate)}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-indigo-600 text-slate-200 hover:text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                      title="Edit Rate Rule"
                      id={`edit-rate-btn-${rate.rateId}`}
                    >
                      <Pencil className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => setDeleteConfirmRateId(rate.rateId)}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-rose-600 text-slate-200 hover:text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                      title="Delete Rate Rule"
                      id={`delete-rate-btn-${rate.rateId}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* MODAL: Create Rate */}
      {showAddRateModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-slate-100 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Umbrella className="w-5 h-5 text-indigo-400" />
              Configure Insurer Premium Rate
            </h3>

            <form onSubmit={handleCreateRate} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Insurer Name</label>
                <input
                  type="text"
                  required
                  value={insurerName}
                  onChange={(e) => setInsurerName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Crop / Category</label>
                <input
                  type="text"
                  required
                  value={cropOrCategory}
                  onChange={(e) => setCropOrCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Target Agro-Ecological Region</label>
                <input
                  type="text"
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Premium Rate %</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={ratePct}
                    onChange={(e) => setRatePct(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono text-sm font-bold focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Loan Size Band</label>
                  <input
                    type="text"
                    value={loanSizeBand}
                    onChange={(e) => setLoanSizeBand(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Set By (Actuary Name)</label>
                <input
                  type="text"
                  required
                  value={setBy}
                  onChange={(e) => setSetBy(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddRateModal(false)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-white shadow-lg shadow-emerald-950/50"
                >
                  Publish Rate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Edit Rate */}
      {editingRate && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-slate-100 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Pencil className="w-5 h-5 text-indigo-400" />
                Edit Insurer Premium Rate
              </h3>
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-mono">
                {editingRate.rateId}
              </span>
            </div>

            <form onSubmit={handleUpdateRate} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Insurer Name</label>
                <input
                  type="text"
                  required
                  value={editInsurerName}
                  onChange={(e) => setEditInsurerName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Crop / Category</label>
                <input
                  type="text"
                  required
                  value={editCropOrCategory}
                  onChange={(e) => setEditCropOrCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Target Agro-Ecological Region</label>
                <input
                  type="text"
                  value={editRegion}
                  onChange={(e) => setEditRegion(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Premium Rate %</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={editRatePct}
                    onChange={(e) => setEditRatePct(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono text-sm font-bold focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Loan Size Band</label>
                  <input
                    type="text"
                    value={editLoanSizeBand}
                    onChange={(e) => setEditLoanSizeBand(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Updated By (Admin Name)</label>
                <input
                  type="text"
                  required
                  value={editSetBy}
                  onChange={(e) => setEditSetBy(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingRate(null)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl font-bold text-white shadow-lg shadow-indigo-950/50"
                  id="save-rate-edit-btn"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Confirm Delete */}
      {deleteConfirmRateId && rateToDelete && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-900/50 rounded-2xl max-w-sm w-full p-6 text-slate-100 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="text-base font-bold text-slate-100">
                Delete Premium Rate Rule?
              </h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to delete the premium rate rule for <strong className="text-white">{rateToDelete.cropOrCategory}</strong> ({rateToDelete.ratePct}% rate)? This action cannot be undone.
            </p>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1">
              <div><span className="text-slate-400">Insurer:</span> {rateToDelete.insurerName}</div>
              <div><span className="text-slate-400">Region:</span> {rateToDelete.region || 'All AEZ'}</div>
              <div><span className="text-slate-400">Loan Band:</span> {rateToDelete.loanSizeBand || 'All'}</div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmRateId(null)}
                className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-semibold text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleDeleteRate(rateToDelete.rateId)}
                className="w-1/2 py-2.5 bg-rose-600 hover:bg-rose-500 rounded-xl font-bold text-white shadow-lg shadow-rose-950/50 cursor-pointer"
                id="confirm-delete-rate-btn"
              >
                Delete Rate Rule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/**
 * AGC Farmer Credit Hub Component
 * Handles Opt-in Consent, Scored Mabala Credit Profile, Plot Polygon Mapping, Active Loan & Repayment
 */

import React, { useState, useEffect } from "react";
import { safeFetchJsonClient } from "../../App";
import { normalizeZambianMobileNumber, isValidZambianMobileNumber } from "../../utils/phoneUtils";
import {
  ShieldCheck,
  ShieldAlert,
  Award,
  MapPin,
  RefreshCw,
  CreditCard,
  FileText,
  Eye,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  TrendingUp,
  Layers,
  Lock,
  Building2,
  DollarSign,
  PlusCircle,
  Package,
  Shield,
  AlertOctagon,
  ArrowRight,
  Warehouse,
  Sprout,
  Sparkles,
  Store,
  Tag,
  Info,
  Calculator,
  Receipt,
  Smartphone,
  Bell,
  BellRing,
  Radio,
  Send,
  CheckCheck,
  Phone,
  Edit3,
  ExternalLink
} from "lucide-react";
import {
  FarmerCreditProfileSummary,
  LoanAccount,
  RepaymentRecord,
  ApiCallLog,
  FarmPlotBoundary,
  CreditFacility,
  InsurerPremiumRate,
  WarehouseReceipt,
  CropCycle,
  Supplier,
  Farm
} from "../../types";
import {
  getFarmerCreditProfile,
  updateFarmerConsent,
  agcComputeCreditScore,
  agcRemoteSensingRefresh,
  updateFarmPlotBoundaries,
  getLoans,
  getRepayments,
  agcProcessRepayment,
  getApiCallLogs,
  canApplyForLoan,
  getCreditFacilities,
  agcSubmitApplication,
  agcDisburseLoan,
  getInsurerPremiumRates
} from "../../services/agcService";
import {
  getFarmerDdaccSmsAlertEnabled,
  setFarmerDdaccSmsAlertEnabled,
  getFarmerDdaccPhoneNumber,
  setFarmerDdaccPhoneNumber,
  sendTestDdaccSms,
  dispatchDdaccSmsAlert,
  getFarmerDdaccSmsHistory,
  getDdaccClearingHistory,
  getDdaccMandates
} from "../../services/ddaccLoanService";
import { HswService } from "../../services/hswService";
import { AFRICAN_CROPS_LIST, CROP_VARIETIES } from "../CropsPanel";
import { BoundaryMapper } from "./BoundaryMapper";
import { FarmerLoanCalculator } from "./FarmerLoanCalculator";
import { FarmerDdaccAuditLog } from "../ddacc/FarmerDdaccAuditLog";

// Accredited input suppliers registered with the AGC network (dynamic, populated upon active onboarding)
export const ACCREDITED_SUPPLIER_FACILITIES: Array<{
  facilityId: string;
  financierInstitutionId: string;
  financierName: string;
  supplierName: string;
  dealerTenantId: string;
  dealerName: string;
  supplierCategory: string;
  allocatedLimit: number;
  utilized: number;
  status: "active" | "suspended";
  cropLimits: Record<string, number>;
  riskShareDefaults: { weatherPct: number; guaranteePct: number; dealerRetainedPct: number };
}> = [];

interface FarmerCreditHubProps {
  farmerTenantId?: string;
  currencySymbol?: string;
  crops?: CropCycle[];
  suppliers?: Supplier[];
  activeFarm?: Farm | null;
}

export const FarmerCreditHub: React.FC<FarmerCreditHubProps> = ({
  farmerTenantId = "demo_tenant",
  currencySymbol = "ZMW",
  crops = [],
  suppliers = [],
  activeFarm = null
}) => {
  const [profile, setProfile] = useState<FarmerCreditProfileSummary | null>(null);
  const [activeLoan, setActiveLoan] = useState<LoanAccount | null>(null);
  const [repayments, setRepayments] = useState<RepaymentRecord[]>([]);
  const [apiLogs, setApiLogs] = useState<ApiCallLog[]>([]);

  // Repayment modal state
  const [showRepayModal, setShowRepayModal] = useState(false);
  const [repayAmount, setRepayAmount] = useState<number>(500);
  const [repayChannel, setRepayChannel] = useState<'lipila' | 'farm-balance' | 'offtaker-settlement'>('lipila');
  const [pinCode, setPinCode] = useState<string>("");
  const [isProcessingRepay, setIsProcessingRepay] = useState(false);
  const [repaySuccessMsg, setRepaySuccessMsg] = useState<string | null>(null);

  // Plot Polygon mapper modal state
  const [showPlotModal, setShowPlotModal] = useState(false);
  const [newPlotName, setNewPlotName] = useState("");
  const [newPlotSize, setNewPlotSize] = useState("2.5");
  const [newPlotCrop, setNewPlotCrop] = useState("Maize");
  const [polygonCoords, setPolygonCoords] = useState<string>("-16.8123, 26.9841\n-16.8125, 26.9865\n-16.8148, 26.9862\n-16.8145, 26.9839");

  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'calculator' | 'apply' | 'plots' | 'loans' | 'ddacc_audit' | 'privacy'>('profile');
  const [isRefreshingScore, setIsRefreshingScore] = useState(false);

  // DDACC SMS Alert Setting
  const [smsNotificationEnabled, setSmsNotificationEnabled] = useState<boolean>(() => {
    return getFarmerDdaccSmsAlertEnabled(farmerTenantId);
  });
  const [farmerPhone, setFarmerPhone] = useState<string>(() => {
    return getFarmerDdaccPhoneNumber(farmerTenantId, "+260977123456");
  });
  const [isEditingPhone, setIsEditingPhone] = useState<boolean>(false);
  const [tempPhone, setTempPhone] = useState<string>(farmerPhone);
  const [isSendingTestSms, setIsSendingTestSms] = useState<boolean>(false);
  const [testSmsResult, setTestSmsResult] = useState<{ success: boolean; message: string; gatewayStatus: string } | null>(null);
  const [smsNotificationNotice, setSmsNotificationNotice] = useState<string | null>(null);

  const [ddaccLogsCount, setDdaccLogsCount] = useState<number>(() => {
    return getDdaccClearingHistory({ farmerTenantId }).length;
  });

  const handleToggleHubSms = (enabled: boolean) => {
    setFarmerDdaccSmsAlertEnabled(farmerTenantId, enabled);
    setSmsNotificationEnabled(enabled);
    setSmsNotificationNotice(
      enabled
        ? "SMS Alerts Activated: Instant SMS notifications will be dispatched via Beem Africa Gateway whenever an installment is debited."
        : "SMS Alerts Muted: You will no longer receive SMS notifications for auto-deductions."
    );
    setTimeout(() => setSmsNotificationNotice(null), 5000);
  };

  const handleSavePhone = () => {
    if (!tempPhone.trim()) return;
    setFarmerDdaccPhoneNumber(farmerTenantId, tempPhone.trim());
    setFarmerPhone(tempPhone.trim());
    setIsEditingPhone(false);
    setSmsNotificationNotice(`Notification phone number updated to ${tempPhone.trim()}`);
    setTimeout(() => setSmsNotificationNotice(null), 4000);
  };

  const handleSendTestSms = async () => {
    setIsSendingTestSms(true);
    setTestSmsResult(null);
    try {
      const activePhone = farmerPhone || profile?.identity?.phone || "+260977123456";
      const res = await sendTestDdaccSms({
        farmerTenantId,
        phone: activePhone,
        farmerName: profile?.identity?.name || "Farmer"
      });
      setTestSmsResult({
        success: res.success,
        message: res.message,
        gatewayStatus: res.gatewayStatus || "BEEM_AFRICA_DELIVERED"
      });
      setSmsNotificationNotice(`Gateway Test SMS dispatched to ${activePhone}!`);
      setTimeout(() => setSmsNotificationNotice(null), 6000);
    } catch (err: any) {
      setTestSmsResult({
        success: false,
        message: err.message || "Failed to dispatch test SMS.",
        gatewayStatus: "GATEWAY_ERROR"
      });
    } finally {
      setIsSendingTestSms(false);
    }
  };

  // Crop Cycles from farm context / localStorage
  const [activeCropCycles, setActiveCropCycles] = useState<CropCycle[]>(crops);

  // Input Credit Application state
  const [appCropCycleId, setAppCropCycleId] = useState<string>("");
  const [appCrop, setAppCrop] = useState<string>("Maize");
  const [appCustomCrop, setAppCustomCrop] = useState<string>("");
  const [appVariety, setAppVariety] = useState<string>("SC 719 (Late Maturing)");
  const [appCustomVariety, setAppCustomVariety] = useState<string>("");
  const [appPlotId, setAppPlotId] = useState<string>("");
  const [appFacilityId, setAppFacilityId] = useState<string>("");
  const [appFacilities, setAppFacilities] = useState<any[]>([]);
  const [appInsurers, setAppInsurers] = useState<InsurerPremiumRate[]>([]);
  const [appInsuranceId, setAppInsuranceId] = useState<string>("");
  const [appWarehouseReceiptId, setAppWarehouseReceiptId] = useState<string>("");
  const [appWarehouseReceipts, setAppWarehouseReceipts] = useState<WarehouseReceipt[]>([]);
  const [singleLoanCheck, setSingleLoanCheck] = useState<{ allowed: boolean; reason?: string }>({ allowed: true });
  const [isSubmittingApp, setIsSubmittingApp] = useState(false);
  const [appSuccessMsg, setAppSuccessMsg] = useState<string | null>(null);

  // Digital Warehouse Receipt (DWR) Collateral Pledge modal
  const [showPledgeDwrModal, setShowPledgeDwrModal] = useState(false);
  const [selectedPledgeDwrId, setSelectedPledgeDwrId] = useState<string>("");

  useEffect(() => {
    loadData();

    const handleHubUpdate = () => {
      loadData();
    };

    window.addEventListener("mabala_ddacc_update", handleHubUpdate);
    window.addEventListener("mabala_wallet_update", handleHubUpdate);
    window.addEventListener("mabala_ddacc_sms_settings_changed", handleHubUpdate);
    window.addEventListener("mabala_ddacc_phone_changed", handleHubUpdate);
    window.addEventListener("storage", handleHubUpdate);

    return () => {
      window.removeEventListener("mabala_ddacc_update", handleHubUpdate);
      window.removeEventListener("mabala_wallet_update", handleHubUpdate);
      window.removeEventListener("mabala_ddacc_sms_settings_changed", handleHubUpdate);
      window.removeEventListener("mabala_ddacc_phone_changed", handleHubUpdate);
      window.removeEventListener("storage", handleHubUpdate);
    };
  }, [farmerTenantId, crops, suppliers]);

  // Synchronize available varieties whenever appCrop changes
  useEffect(() => {
    const currentCropName = appCrop === "Other" ? appCustomCrop : appCrop;
    const matchingVars = CROP_VARIETIES.filter(v => v.crop.toLowerCase() === currentCropName.toLowerCase());
    if (matchingVars.length > 0) {
      if (!matchingVars.some(v => v.variety === appVariety)) {
        setAppVariety(matchingVars[0].variety);
      }
    } else {
      if (appVariety !== "Other" && !appCustomVariety) {
        setAppVariety("Other");
      }
    }
  }, [appCrop, appCustomCrop]);

  const loadData = () => {
    const p = getFarmerCreditProfile(farmerTenantId);
    setProfile(p);

    if (p && p.farmPlots.length > 0 && !appPlotId) {
      setAppPlotId(p.farmPlots[0].plotId);
    }

    const loans = getLoans(farmerTenantId);
    const active = loans.find(l => l.status === "active") || null;
    setActiveLoan(active);

    if (active) {
      const reps = getRepayments(active.loanId);
      setRepayments(reps);
    } else {
      setRepayments([]);
    }

    const logs = getApiCallLogs(undefined, farmerTenantId);
    setApiLogs(logs);

    setSmsNotificationEnabled(getFarmerDdaccSmsAlertEnabled(farmerTenantId));
    setDdaccLogsCount(getDdaccClearingHistory({ farmerTenantId }).length);

    // Sync active crop cycles from props or localStorage
    let availableCrops: CropCycle[] = crops;
    if (!availableCrops || availableCrops.length === 0) {
      try {
        const savedCrops = localStorage.getItem("mabala_crops");
        if (savedCrops) {
          availableCrops = JSON.parse(savedCrops);
        }
      } catch (e) {
        // ignore
      }
    }
    setActiveCropCycles(availableCrops || []);

    // Build unified facilities with onboarded suppliers
    const baseFacs = getCreditFacilities();
    const allFacsMap: Record<string, any> = {};

    // 1. Add Accredited Supplier Facilities (if any created)
    ACCREDITED_SUPPLIER_FACILITIES.forEach(supFac => {
      if (supFac && supFac.status === "active") {
        allFacsMap[supFac.facilityId] = {
          ...supFac,
          isOnboardedSupplier: true
        };
      }
    });

    // 2. Add Published Credit Facilities
    baseFacs.forEach(fac => {
      if (fac && fac.status === "active" && !allFacsMap[fac.facilityId]) {
        allFacsMap[fac.facilityId] = {
          ...fac,
          supplierName: fac.financierName || "Institutional Input Financier",
          supplierCategory: "Agro-Input Credit Line",
          isOnboardedSupplier: true
        };
      }
    });

    const compiledFacs = Object.values(allFacsMap);
    setAppFacilities(compiledFacs);

    if (compiledFacs.length > 0) {
      if (!appFacilityId || !allFacsMap[appFacilityId]) {
        setAppFacilityId(compiledFacs[0].facilityId);
      }
    } else {
      setAppFacilityId("");
    }

    const rates = getInsurerPremiumRates();
    setAppInsurers(rates);

    const receipts = HswService.getWarehouseReceipts();
    setAppWarehouseReceipts(receipts);

    const check = canApplyForLoan(farmerTenantId);
    setSingleLoanCheck(check);
  };

  const handleToggleConsent = (granted: boolean) => {
    const updated = updateFarmerConsent(farmerTenantId, granted ? "granted" : "revoked");
    setProfile({ ...updated });
  };

  const handleRefreshScore = () => {
    setIsRefreshingScore(true);
    setTimeout(() => {
      agcRemoteSensingRefresh(farmerTenantId);
      const newScore = agcComputeCreditScore(farmerTenantId);
      const updated = getFarmerCreditProfile(farmerTenantId);
      setProfile({ ...updated });
      setIsRefreshingScore(false);
    }, 600);
  };

  // Quick link from active crop cycle
  const handleSelectActiveCropCycle = (cycleId: string) => {
    setAppCropCycleId(cycleId);
    if (!cycleId) return;

    const cycle = activeCropCycles.find(c => c.id === cycleId);
    if (!cycle) return;

    // Set crop type
    const foundInList = AFRICAN_CROPS_LIST.some(cat => cat.items.some(it => it.value.toLowerCase() === cycle.cropType.toLowerCase() || it.name.toLowerCase() === cycle.cropType.toLowerCase()));
    if (foundInList) {
      setAppCrop(cycle.cropType);
      setAppCustomCrop("");
    } else {
      setAppCrop("Other");
      setAppCustomCrop(cycle.cropType);
    }

    // Set variety/strain
    if (cycle.variety) {
      const matchVar = CROP_VARIETIES.find(v => v.variety.toLowerCase() === cycle.variety.toLowerCase() && v.crop.toLowerCase() === cycle.cropType.toLowerCase());
      if (matchVar) {
        setAppVariety(matchVar.variety);
        setAppCustomVariety("");
      } else {
        setAppVariety("Other");
        setAppCustomVariety(cycle.variety);
      }
    }

    // Match farm plot by field block name if available
    if (profile && profile.farmPlots.length > 0 && cycle.fieldBlock) {
      const matchedPlot = profile.farmPlots.find(p => p.plotName.toLowerCase().includes(cycle.fieldBlock.toLowerCase()) || cycle.fieldBlock.toLowerCase().includes(p.plotName.toLowerCase()));
      if (matchedPlot) {
        setAppPlotId(matchedPlot.plotId);
      }
    }
  };

  const handleAddPlotPolygon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    // Parse coordinates
    const lines = polygonCoords.split("\n").map(l => l.trim()).filter(Boolean);
    const parsedCoords = lines.map(line => {
      const parts = line.split(",").map(p => parseFloat(p.trim()));
      return { lat: parts[0] || 0, lng: parts[1] || 0 };
    }).filter(c => !isNaN(c.lat) && !isNaN(c.lng));

    const newPlot: FarmPlotBoundary = {
      plotId: "plot_" + Date.now(),
      plotName: newPlotName || "New Mapped Plot",
      gpsBoundary: parsedCoords.length >= 3 ? parsedCoords : [
        { lat: -16.8120, lng: 26.9840 },
        { lat: -16.8125, lng: 26.9860 },
        { lat: -16.8140, lng: 26.9850 }
      ],
      sizeHa: parseFloat(newPlotSize) || 2.0,
      cropHistory: [newPlotCrop],
      aez: "Region IIa"
    };

    const updatedPlots = [...profile.farmPlots, newPlot];
    updateFarmPlotBoundaries(farmerTenantId, updatedPlots);
    setShowPlotModal(false);
    setNewPlotName("");
    loadData();
  };

  const handleFarmerSubmitApplication = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    if (!singleLoanCheck.allowed) {
      alert(singleLoanCheck.reason || "Hard block enforced: Single active loan rule prevents multiple loans.");
      return;
    }

    setIsSubmittingApp(true);
    const selectedPlot = profile.farmPlots.find(p => p.plotId === appPlotId) || profile.farmPlots[0];
    const hectarage = selectedPlot ? selectedPlot.sizeHa : 2.5;
    const fac = appFacilities.find(f => f.facilityId === appFacilityId);

    const effectiveCrop = appCrop === "Other" ? (appCustomCrop.trim() || "Custom Crop") : appCrop;
    const effectiveVariety = appVariety === "Other" ? (appCustomVariety.trim() || "") : appVariety;
    const cropDisplay = effectiveVariety ? `${effectiveCrop} (${effectiveVariety})` : effectiveCrop;

    // Rate calculation based on crop limits or category defaults
    let cropRate = fac?.cropLimits?.[effectiveCrop] || fac?.cropLimits?.[appCrop];
    if (!cropRate) {
      if (effectiveCrop.toLowerCase().includes("soya") || effectiveCrop.toLowerCase().includes("bean")) {
        cropRate = 5400;
      } else if (effectiveCrop.toLowerCase().includes("wheat")) {
        cropRate = 6800;
      } else if (effectiveCrop.toLowerCase().includes("tomato") || effectiveCrop.toLowerCase().includes("potato") || effectiveCrop.toLowerCase().includes("onion")) {
        cropRate = 7500;
      } else {
        cropRate = 4800;
      }
    }
    const eligibleAmount = hectarage * cropRate;

    // Dynamic in-kind drawdown basket tailored to selected crop, variety, and onboarded supplier
    const supplierName = fac?.supplierName || fac?.financierName || "Certified Supplier";
    const seedDesc = `${supplierName} Certified Seed — ${effectiveCrop} ${effectiveVariety ? `[${effectiveVariety}]` : ''} (Certified Stock)`;

    const defaultBasket = [
      {
        skuId: `sku-seed-${Date.now().toString().slice(-4)}`,
        name: seedDesc,
        quantity: Math.max(1, Math.ceil(hectarage * 2)),
        unitPrice: 850,
        total: Math.max(1, Math.ceil(hectarage * 2)) * 850
      },
      {
        skuId: "sku-comp-d-50kg",
        name: "Compound D Basal Planting Fertilizer (50kg bags)",
        quantity: Math.max(2, Math.ceil(hectarage * 4)),
        unitPrice: 720,
        total: Math.max(2, Math.ceil(hectarage * 4)) * 720
      },
      {
        skuId: "sku-urea-50kg",
        name: "Urea Top Dressing Crop Fertilizer (50kg bags)",
        quantity: Math.max(2, Math.ceil(hectarage * 4)),
        unitPrice: 750,
        total: Math.max(2, Math.ceil(hectarage * 4)) * 750
      },
      {
        skuId: "sku-pest-shield",
        name: "Certified Crop Protection & Foliar Health Pack",
        quantity: Math.max(1, Math.ceil(hectarage)),
        unitPrice: 380,
        total: Math.max(1, Math.ceil(hectarage)) * 380
      }
    ];

    setTimeout(() => {
      try {
        const app = agcSubmitApplication({
          farmerTenantId,
          dealerTenantId: fac?.dealerTenantId || "dealer-choma-01",
          dealerName: fac?.dealerName || "Choma Agro-Dealer Hub",
          financierInstitutionId: fac?.financierInstitutionId || "inst_mabala_agri",
          financierName: fac?.financierName || "Mabala AgriCredit Ltd",
          requestedBasket: defaultBasket,
          selectedCrop: cropDisplay,
          appliedHectarage: hectarage,
          warehouseReceiptId: appWarehouseReceiptId || undefined,
          warehouseReceiptPledged: !!appWarehouseReceiptId,
          insurancePolicyAttached: !!appInsuranceId
        });

        if (app.status === "approved") {
          const loan = agcDisburseLoan({
            applicationId: app.applicationId,
            insurancePolicyId: appInsuranceId || null,
            riskShare: fac?.riskShareDefaults || { weatherPct: 40, guaranteePct: 30, dealerRetainedPct: 30 }
          });

          setAppSuccessMsg(`Credit Application Approved & In-Kind Drawdown Disbursed! Loan ID: ${loan.loanId} (Eligible Credit: ${currencySymbol} ${eligibleAmount.toLocaleString()} via ${supplierName})`);
          setActiveSubTab("loans");
          loadData();
        } else {
          alert("Application status: " + app.status + " - " + (app.rejectionReason || "Check score limits."));
        }
      } catch (err: any) {
        alert("Application failed: " + err.message);
      } finally {
        setIsSubmittingApp(false);
      }
    }, 600);
  };

  const handlePledgeDwr = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeLoan || !selectedPledgeDwrId) return;

    // Update loan with pledged receipt
    const loans = getLoans(farmerTenantId);
    const found = loans.find(l => l.loanId === activeLoan.loanId);
    if (found) {
      found.warehouseReceiptId = selectedPledgeDwrId;
      found.warehouseReceiptPledged = true;
      localStorage.setItem("mabala_agc_loans", JSON.stringify(loans));
    }

    setShowPledgeDwrModal(false);
    setSelectedPledgeDwrId("");
    setRepaySuccessMsg(`Digital Warehouse Receipt ${selectedPledgeDwrId} successfully pledged as collateral for Loan ${activeLoan.loanId}!`);
    loadData();
  };

  const handleExecuteRepayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeLoan) return;
    if (repayChannel !== 'offtaker-settlement' && (!pinCode || pinCode.length < 4)) {
      alert("Security rule: Lipila/Farm-Balance repayment requires a valid 4-digit PIN.");
      return;
    }

    setIsProcessingRepay(true);
    try {
      if (repayChannel === 'lipila') {
        const phone = (profile as any).phoneNumber || (profile as any).phone || "260971234567";
        const cleanPhone = normalizeZambianMobileNumber(phone);
        if (!cleanPhone || !isValidZambianMobileNumber(cleanPhone)) {
          alert(`Invalid Zambian mobile number: "${phone}". Please check your profile phone number.`);
          setIsProcessingRepay(false);
          return;
        }

        const checkBal = await safeFetchJsonClient("/api/payments/check-balance", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            accountNumber: cleanPhone,
            requiredAmount: repayAmount
          })
        }).catch(() => null);

        if (checkBal && checkBal.hasBalance === false) {
          alert(checkBal.message || "Insufficient Mobile Money account balance.");
          setIsProcessingRepay(false);
          return;
        }

        const genRef = `ref-agc-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
        const collectRes = await safeFetchJsonClient("/api/payments/collect", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            referenceId: genRef,
            amount: repayAmount,
            narration: `AGC Loan Repayment: ${activeLoan.loanId}`,
            accountNumber: cleanPhone,
            currency: "ZMW",
            email: (profile as any).farmerEmail || (profile as any).email || "owner@mabala.com",
            packageName: "AGC Loan Repayment",
            packageType: "loan_repayment"
          })
        }).catch((err: any) => ({ status: "Error", message: err.message }));

        if (collectRes && (collectRes.status === "Failed" || collectRes.status === "Error" || collectRes.success === false)) {
          alert(collectRes.message || collectRes.error || "Lipila payment collection failed.");
          setIsProcessingRepay(false);
          return;
        }

        // Poll check-status to ensure user enters PIN and payment is confirmed by Lipila API
        let confirmed = false;
        for (let i = 0; i < 15; i++) {
          await new Promise(r => setTimeout(r, 4000));
          const checkStatusRes = await safeFetchJsonClient(`/api/payments/check-status?referenceId=${genRef}`).catch(() => null);
          if (checkStatusRes && (checkStatusRes.status === "Successful" || checkStatusRes.status === "Success" || checkStatusRes.status === "Completed")) {
            confirmed = true;
            break;
          }
          if (checkStatusRes && (checkStatusRes.status === "Failed" || checkStatusRes.status === "Error" || checkStatusRes.status === "Rejected")) {
            alert(`Repayment failed: ${checkStatusRes.message || "Payment request was declined or expired on the operator network."}`);
            setIsProcessingRepay(false);
            return;
          }
        }

        if (!confirmed) {
          alert("Payment pending: Please enter your Mobile Money PIN prompt on your phone +260... to authorize loan repayment.");
          setIsProcessingRepay(false);
          return;
        }
      }

      const rep = agcProcessRepayment({
        loanId: activeLoan.loanId,
        amount: repayAmount,
        channel: repayChannel
      });

      // Dispatch automated SMS repayment alert if enabled
      if (smsNotificationEnabled) {
        try {
          const targetPhone = farmerPhone || profile.identity.phone || "+260977123456";
          const remainingAfter = Math.max(0, activeLoan.balance - repayAmount);
          dispatchDdaccSmsAlert({
            phone: targetPhone,
            farmerName: profile.identity.name,
            amount: repayAmount,
            loanId: activeLoan.loanId,
            lenderName: activeLoan.financierName || activeLoan.dealerName || "Agro Dealer",
            remainingBalance: remainingAfter,
            txRef: rep.repaymentId,
            tenantId: farmerTenantId,
            repaymentType: "manual"
          }).catch(smsErr => console.warn("[DDACC SMS Notice]", smsErr));
        } catch (smsErr) {
          console.warn("[DDACC SMS Dispatch on Repay]", smsErr);
        }
      }

      setRepaySuccessMsg(`Successfully repaid ${currencySymbol} ${repayAmount.toLocaleString()} via ${repayChannel.toUpperCase()}! ${smsNotificationEnabled ? 'An instant SMS delivery alert was dispatched to your phone.' : ''} (Ref: ${rep.repaymentId})`);
      setShowRepayModal(false);
      setPinCode("");
      loadData();
    } catch (err: any) {
      alert("Repayment failed: " + err.message);
    } finally {
      setIsProcessingRepay(false);
    }
  };

  if (!profile) return <div className="p-6 text-slate-400">Loading credit profile...</div>;

  const score = profile.mabalaCreditScore;
  const getBandBadge = (band: string) => {
    switch (band) {
      case 'A': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case 'B': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'C': return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      default: return 'bg-rose-500/20 text-rose-400 border-rose-500/30';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 text-slate-900 shadow-xs">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200/80">
                AGC Module v1.3
              </span>
              <span className="text-xs text-slate-500 font-medium">Smallholder Input Credit Infrastructure</span>
            </div>
            <h1 className="text-2xl font-black mt-1 text-slate-900 flex items-center gap-2">
              {profile.identity.name}
              <span className="text-sm font-semibold text-slate-500">({profile.identity.phone})</span>
            </h1>
            <p className="text-sm text-slate-600 font-medium mt-0.5">
              NRC: <span className="font-mono font-bold text-emerald-700">{profile.identity.nrc || "Pending Verification"}</span> • Age Band: <span className="font-semibold text-slate-850">{profile.identity.ageBand}</span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* DDACC SMS Alerts Quick Toggle & Test Widget */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center gap-3 shadow-2xs">
              <div className="text-right">
                <div className="text-[11px] font-bold text-slate-600 flex items-center justify-end gap-1">
                  <span>DDACC Loan SMS Alerts</span>
                  {smsNotificationEnabled && (
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  )}
                </div>
                <div className={`text-xs font-bold flex items-center justify-end gap-1 ${smsNotificationEnabled ? 'text-emerald-700' : 'text-slate-400'}`}>
                  <Smartphone className="w-3.5 h-3.5" />
                  {smsNotificationEnabled ? 'Beem Gateway (Active)' : 'Muted'}
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleToggleHubSms(!smsNotificationEnabled)}
                id="toggle-hub-sms-notifications"
                title={smsNotificationEnabled ? "Click to mute DDACC loan repayment SMS notifications" : "Click to enable instant DDACC loan repayment SMS notifications"}
                className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors duration-300 ${
                  smsNotificationEnabled ? "bg-emerald-600" : "bg-slate-300"
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-300 ${
                    smsNotificationEnabled ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>

              {smsNotificationEnabled && (
                <button
                  type="button"
                  onClick={handleSendTestSms}
                  disabled={isSendingTestSms}
                  id="btn-quick-test-sms"
                  title="Send diagnostic test SMS via Beem Gateway to verify phone routing"
                  className="px-2.5 py-1 bg-white hover:bg-slate-100 text-emerald-700 border border-emerald-300 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors disabled:opacity-50 cursor-pointer shadow-2xs"
                >
                  <Send className={`w-3 h-3 text-emerald-600 ${isSendingTestSms ? 'animate-spin' : ''}`} />
                  {isSendingTestSms ? 'Testing...' : 'Test SMS'}
                </button>
              )}
            </div>

            {/* Consent Status Switch */}
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-700/60 flex items-center gap-4">
              <div className="text-right">
                <div className="text-xs font-semibold text-slate-400">Credit Consent Status</div>
                <div className={`text-sm font-bold flex items-center justify-end gap-1.5 ${profile.consentStatus === 'granted' ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {profile.consentStatus === 'granted' ? (
                    <><ShieldCheck className="w-4 h-4" /> Granted</>
                  ) : (
                    <><ShieldAlert className="w-4 h-4" /> Revoked</>
                  )}
                </div>
              </div>

              <button
                onClick={() => handleToggleConsent(profile.consentStatus !== 'granted')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  profile.consentStatus === 'granted'
                    ? 'bg-rose-900/40 text-rose-300 hover:bg-rose-900/60 border border-rose-700/50'
                    : 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-lg shadow-emerald-900/30'
                }`}
              >
                {profile.consentStatus === 'granted' ? 'Revoke Sharing' : 'Grant Consent'}
              </button>
            </div>
          </div>
        </div>

        {/* Sub-navigation tabs */}
        <div className="flex flex-wrap gap-2 mt-6 border-b border-slate-700/60 pb-1">
          <button
            onClick={() => setActiveSubTab('profile')}
            className={`px-3.5 py-2 text-xs font-bold rounded-t-lg transition-colors flex items-center gap-2 ${
              activeSubTab === 'profile'
                ? 'bg-emerald-600/30 text-emerald-300 border-b-2 border-emerald-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-4 h-4" /> Credit Score & Signals
          </button>
          <button
            onClick={() => setActiveSubTab('calculator')}
            id="tab-btn-farmer-loan-calculator"
            className={`px-3.5 py-2 text-xs font-bold rounded-t-lg transition-colors flex items-center gap-2 ${
              activeSubTab === 'calculator'
                ? 'bg-emerald-600/30 text-emerald-300 border-b-2 border-emerald-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calculator className="w-4 h-4" /> Loan Calculator
          </button>
          <button
            onClick={() => setActiveSubTab('apply')}
            className={`px-3.5 py-2 text-xs font-bold rounded-t-lg transition-colors flex items-center gap-2 ${
              activeSubTab === 'apply'
                ? 'bg-emerald-600/30 text-emerald-300 border-b-2 border-emerald-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PlusCircle className="w-4 h-4" /> Apply for Input Credit
          </button>
          <button
            onClick={() => setActiveSubTab('plots')}
            className={`px-3.5 py-2 text-xs font-bold rounded-t-lg transition-colors flex items-center gap-2 ${
              activeSubTab === 'plots'
                ? 'bg-emerald-600/30 text-emerald-300 border-b-2 border-emerald-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <MapPin className="w-4 h-4" /> Farm Plots & Polygon Mapper
          </button>
          <button
            onClick={() => setActiveSubTab('loans')}
            className={`px-3.5 py-2 text-xs font-bold rounded-t-lg transition-colors flex items-center gap-2 ${
              activeSubTab === 'loans'
                ? 'bg-emerald-600/30 text-emerald-300 border-b-2 border-emerald-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <CreditCard className="w-4 h-4" /> Active Loan & Repayment
            {activeLoan && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>}
          </button>
          <button
            onClick={() => setActiveSubTab('ddacc_audit')}
            id="tab-btn-farmer-ddacc-audit"
            className={`px-3.5 py-2 text-xs font-bold rounded-t-lg transition-colors flex items-center gap-2 ${
              activeSubTab === 'ddacc_audit'
                ? 'bg-emerald-600/30 text-emerald-300 border-b-2 border-emerald-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Receipt className="w-4 h-4" /> Auto-Deduction Audit Log
            {ddaccLogsCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                {ddaccLogsCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveSubTab('privacy')}
            className={`px-3.5 py-2 text-xs font-bold rounded-t-lg transition-colors flex items-center gap-2 ${
              activeSubTab === 'privacy'
                ? 'bg-emerald-600/30 text-emerald-300 border-b-2 border-emerald-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-4 h-4" /> External Access Logs
          </button>
        </div>
      </div>

      {appSuccessMsg && (
        <div className="p-4 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 flex justify-between items-center text-sm">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span>{appSuccessMsg}</span>
          </div>
          <button onClick={() => setAppSuccessMsg(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {repaySuccessMsg && (
        <div className="p-4 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 flex justify-between items-center text-sm">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span>{repaySuccessMsg}</span>
          </div>
          <button onClick={() => setRepaySuccessMsg(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {smsNotificationNotice && (
        <div className="p-3.5 bg-emerald-950/70 border border-emerald-500/40 rounded-xl text-emerald-300 flex justify-between items-center text-xs shadow-md">
          <div className="flex items-center gap-2.5">
            <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{smsNotificationNotice}</span>
          </div>
          <button onClick={() => setSmsNotificationNotice(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {testSmsResult && (
        <div className={`p-4 rounded-xl text-xs flex justify-between items-start border shadow-md ${
          testSmsResult.success 
            ? 'bg-slate-900/90 border-emerald-500/40 text-slate-200' 
            : 'bg-rose-950/80 border-rose-500/40 text-rose-200'
        }`}>
          <div className="space-y-1">
            <div className="flex items-center gap-2 font-bold">
              {testSmsResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400" />
              )}
              <span className={testSmsResult.success ? 'text-emerald-400' : 'text-rose-400'}>
                {testSmsResult.success ? 'Gateway Dispatch Verification: Success' : 'Gateway Dispatch Verification: Failed'}
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                {testSmsResult.gatewayStatus}
              </span>
            </div>
            <p className="text-slate-300 text-[11px]">{testSmsResult.message}</p>
          </div>
          <button onClick={() => setTestSmsResult(null)} className="text-slate-400 hover:text-white ml-3">✕</button>
        </div>
      )}

      {/* TAB: LOAN CALCULATOR */}
      {activeSubTab === 'calculator' && (
        <FarmerLoanCalculator
          currencySymbol={currencySymbol}
          farmerName={profile.identity.name}
          initialPrincipal={4500}
          onApplyWithTerms={(terms) => {
            if (terms.basketDescription) {
              setAppCustomCrop(terms.basketDescription);
            }
            setActiveSubTab('apply');
          }}
        />
      )}

      {/* TAB: APPLY FOR INPUT CREDIT */}
      {activeSubTab === 'apply' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-6">
          <div className="flex justify-between items-start border-b border-slate-800 pb-4">
            <div>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                In-App Agro-Consignment Credit Application
              </span>
              <h2 className="text-xl font-bold text-slate-100 mt-1">Apply for Certified Input Credit</h2>
              <p className="text-xs text-slate-400">
                Select target crop and mapped polygon plot. The Mabala engine computes your eligible credit line against published financier per-hectare limits.
              </p>
            </div>

            <div className="text-right">
              <span className="text-xs text-slate-400 block">Scored Mabala Credit Score</span>
              <span className="text-2xl font-black text-emerald-400 font-mono">{score.value} (Band {score.band})</span>
            </div>
          </div>

          {/* SINGLE LOAN LOCK GUARDRAIL BANNER */}
          {!singleLoanCheck.allowed ? (
            <div className="bg-rose-950/80 border-2 border-rose-500/80 rounded-2xl p-5 text-white shadow-xl space-y-2">
              <div className="flex items-center gap-2 text-rose-300 font-bold">
                <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0 animate-bounce" />
                <span>HARD BLOCK ENFORCED: Single Active Loan Policy</span>
              </div>
              <p className="text-xs text-rose-200 font-mono">
                {singleLoanCheck.reason}
              </p>
              <div className="pt-2 text-[11px] text-slate-300">
                To unlock new input credit, please settle your existing active loan balance in the &quot;Active Loan & Repayment&quot; tab.
              </div>
            </div>
          ) : (
            <div className="bg-emerald-950/40 border border-emerald-500/40 p-3.5 rounded-xl text-emerald-300 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Single Active Loan Rule Passed: You have no active open loans across Mabala. Eligible to apply.</span>
              </div>
              <span className="font-bold font-mono text-[10px] bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30">
                STATUS: ELIGIBLE
              </span>
            </div>
          )}

          <form onSubmit={handleFarmerSubmitApplication} className="space-y-6">
            {/* Quick Link from Farm Active Crop Cycles */}
            {activeCropCycles.length > 0 && (
              <div className="bg-slate-950/70 border border-emerald-500/20 rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1.5">
                    <Sprout className="w-3.5 h-3.5" />
                    Quick Populate from Active Farm Crop Cycles ({activeCropCycles.length})
                  </span>
                  <span className="text-[10px] text-slate-400">Click to autofill crop type & strain</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {activeCropCycles.map(cycle => (
                    <button
                      key={cycle.id}
                      type="button"
                      onClick={() => handleSelectActiveCropCycle(cycle.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all flex items-center gap-1.5 ${
                        appCropCycleId === cycle.id
                          ? "bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-sm"
                          : "bg-slate-900/80 border-slate-700/70 text-slate-300 hover:border-slate-500"
                      }`}
                    >
                      <Sparkles className="w-3 h-3 text-emerald-400" />
                      <span>{cycle.cropType}</span>
                      {cycle.variety && <span className="text-[10px] text-slate-400">({cycle.variety})</span>}
                      {cycle.fieldBlock && (
                        <span className="text-[10px] bg-slate-800 px-1.5 py-0.2 rounded text-slate-300">
                          {cycle.fieldBlock}
                        </span>
                      )}
                    </button>
                  ))}
                  {appCropCycleId && (
                    <button
                      type="button"
                      onClick={() => {
                        setAppCropCycleId("");
                      }}
                      className="px-2 py-1 text-[11px] text-slate-400 hover:text-slate-200 underline"
                    >
                      Clear Selection
                    </button>
                  )}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* 1. Crop Type */}
              <div>
                <label className="block text-slate-400 mb-1.5 text-xs font-semibold flex items-center justify-between">
                  <span>1. Crop Type *</span>
                  <span className="text-[10px] text-emerald-400 font-normal">Standardized List</span>
                </label>
                <select
                  value={appCrop}
                  onChange={e => setAppCrop(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 text-xs font-medium focus:outline-none focus:border-emerald-500"
                >
                  {AFRICAN_CROPS_LIST.map(group => (
                    <optgroup key={group.category} label={group.category}>
                      {group.items.map(item => (
                        <option key={item.value} value={item.value}>
                          {item.name}
                        </option>
                      ))}
                    </optgroup>
                  ))}
                  <option value="Other">Custom / Other Crop...</option>
                </select>

                {appCrop === "Other" && (
                  <input
                    type="text"
                    placeholder="Enter crop name (e.g. Paprika)"
                    value={appCustomCrop}
                    onChange={e => setAppCustomCrop(e.target.value)}
                    className="w-full mt-2 bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                    required
                  />
                )}
              </div>

              {/* 2. Crop Strain / Variety */}
              <div>
                <label className="block text-slate-400 mb-1.5 text-xs font-semibold flex items-center justify-between">
                  <span>2. Strain & Variety *</span>
                  <span className="text-[10px] text-emerald-400 font-normal">Certified Varieties</span>
                </label>
                {(() => {
                  const currentCropName = appCrop === "Other" ? appCustomCrop : appCrop;
                  const availableVars = CROP_VARIETIES.filter(
                    v => v.crop.toLowerCase() === currentCropName.toLowerCase()
                  );

                  return (
                    <>
                      <select
                        value={appVariety}
                        onChange={e => setAppVariety(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 text-xs font-medium focus:outline-none focus:border-emerald-500"
                      >
                        {availableVars.length > 0 ? (
                          availableVars.map(v => (
                            <option key={v.variety} value={v.variety}>
                              {v.variety} ({v.maturityDays}d maturity)
                            </option>
                          ))
                        ) : (
                          <option value="Standard Certified Variety">Standard Certified Variety</option>
                        )}
                        <option value="Other">Other / Custom Variety...</option>
                      </select>

                      {appVariety === "Other" && (
                        <input
                          type="text"
                          placeholder="Enter variety/strain name"
                          value={appCustomVariety}
                          onChange={e => setAppCustomVariety(e.target.value)}
                          className="w-full mt-2 bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                          required
                        />
                      )}
                    </>
                  );
                })()}
              </div>

              {/* 3. Mapped Farm Plot */}
              <div>
                <label className="block text-slate-400 mb-1.5 text-xs font-semibold">3. Mapped Farm Plot *</label>
                <select
                  value={appPlotId}
                  onChange={e => setAppPlotId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 text-xs font-medium focus:outline-none focus:border-emerald-500"
                >
                  {profile.farmPlots.map(plot => (
                    <option key={plot.plotId} value={plot.plotId}>
                      {plot.plotName || plot.plotId} — {plot.sizeHa} Ha ({plot.aez})
                    </option>
                  ))}
                </select>
              </div>

              {/* 4. Onboarded Supplier Credit Facility */}
              <div>
                <label className="block text-slate-400 mb-1.5 text-xs font-semibold flex items-center justify-between">
                  <span>4. Onboarded Supplier Credit Line *</span>
                  <span className="text-[10px] text-emerald-400 font-normal">Accredited Network</span>
                </label>
                {appFacilities.length === 0 ? (
                  <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl">
                    <p className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                      <Store className="w-3.5 h-3.5 shrink-0" />
                      No Onboarded Suppliers or Agro-Dealers Available Yet
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Certified input packages and accredited credit facilities will become available here automatically as soon as verified suppliers and agro-dealers are onboarded to the Mabala AGC Network.
                    </p>
                  </div>
                ) : (
                  <select
                    value={appFacilityId}
                    onChange={e => setAppFacilityId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 text-xs font-medium focus:outline-none focus:border-emerald-500"
                  >
                    {appFacilities.map(fac => {
                      const supplierLabel = fac.supplierName
                        ? `[${fac.supplierName}] ${fac.financierName}`
                        : fac.financierName;
                      return (
                        <option key={fac.facilityId} value={fac.facilityId}>
                          {supplierLabel} ({fac.dealerName || "National Depot"})
                        </option>
                      );
                    })}
                  </select>
                )}
              </div>
            </div>

            {/* Selected Supplier Highlight & Limit Computation Card */}
            {(() => {
              const selectedPlot = profile.farmPlots.find(p => p.plotId === appPlotId) || profile.farmPlots[0];
              const hectarage = selectedPlot ? selectedPlot.sizeHa : 2.5;
              const fac = appFacilities.find(f => f.facilityId === appFacilityId);

              const effectiveCrop = appCrop === "Other" ? (appCustomCrop.trim() || "Maize") : appCrop;
              const effectiveVariety = appVariety === "Other" ? (appCustomVariety.trim() || "") : appVariety;

              let perHaRate = fac?.cropLimits?.[effectiveCrop] || fac?.cropLimits?.[appCrop];
              if (!perHaRate) {
                if (effectiveCrop.toLowerCase().includes("soya") || effectiveCrop.toLowerCase().includes("bean")) {
                  perHaRate = 5400;
                } else if (effectiveCrop.toLowerCase().includes("wheat")) {
                  perHaRate = 6800;
                } else if (effectiveCrop.toLowerCase().includes("tomato") || effectiveCrop.toLowerCase().includes("potato") || effectiveCrop.toLowerCase().includes("onion")) {
                  perHaRate = 7500;
                } else {
                  perHaRate = 4800;
                }
              }
              const totalEligibleCredit = hectarage * perHaRate;

              return (
                <div className="space-y-3">
                  {/* Onboarded Supplier Header Details */}
                  {fac && (
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                      <div className="flex items-start gap-3">
                        <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0">
                          <Store className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-bold text-slate-100">
                              {fac.supplierName || fac.financierName}
                            </h4>
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                              Accredited Supplier
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
                            <span>Category: <strong className="text-slate-300 font-medium">{fac.supplierCategory || "Certified Agricultural Inputs"}</strong></span>
                            <span>•</span>
                            <span>Partner Hub: <strong className="text-slate-300 font-medium">{fac.dealerName}</strong></span>
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-xs font-mono">
                        <div className="text-right">
                          <span className="text-slate-400 block text-[10px]">Supplier Credit Limit</span>
                          <span className="text-slate-200 font-bold">{currencySymbol} {(fac.allocatedLimit || 750000).toLocaleString()}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-slate-400 block text-[10px]">Available Capacity</span>
                          <span className="text-emerald-400 font-bold">
                            {currencySymbol} {((fac.allocatedLimit || 750000) - (fac.utilized || 0)).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Calculations & Drawdown details */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-emerald-500/40 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                    <div>
                      <span className="text-slate-400 block">Target Crop & Variety</span>
                      <strong className="text-slate-100 text-sm font-bold mt-0.5 block truncate">
                        {effectiveCrop} {effectiveVariety ? `(${effectiveVariety})` : ''}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Mapped Plot & Rate</span>
                      <strong className="text-slate-100 text-sm font-bold font-mono mt-0.5 block">
                        {hectarage} Ha @ {currencySymbol} {perHaRate.toLocaleString()}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Total Eligible Input Credit</span>
                      <strong className="text-emerald-400 text-base font-black font-mono mt-0.5 block">
                        {currencySymbol} {totalEligibleCredit.toLocaleString()}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">In-Kind Drawdown Basket</span>
                      <strong className="text-teal-300 text-xs font-bold mt-0.5 block">
                        {fac?.supplierName || "Certified Supplier"} Seeds, Basal, Urea & Sprays
                      </strong>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* Risk Mitigation Add-ons */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1.5 font-semibold">5. Optional Farmer-Paid Crop Insurance</label>
                <select
                  value={appInsuranceId}
                  onChange={e => setAppInsuranceId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  <option value="">No Loan Crop Insurance</option>
                  {appInsurers.map(rate => (
                    <option key={rate.rateId} value={rate.rateId}>
                      {rate.insurerName} ({rate.ratePct}% Premium - {rate.cropOrCategory})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1.5 font-semibold">6. Digital Warehouse Receipt (DWR) Collateral Pledge</label>
                <select
                  value={appWarehouseReceiptId}
                  onChange={e => setAppWarehouseReceiptId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  <option value="">No DWR Collateral Pledged</option>
                  {appWarehouseReceipts.map(rec => (
                    <option key={rec.receiptNumber} value={rec.receiptNumber}>
                      {rec.receiptNumber} — {rec.quantity} MT {rec.cropType} (Warehouse #{rec.warehouseId})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={!singleLoanCheck.allowed || isSubmittingApp || appFacilities.length === 0}
              className="w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs shadow-xl transition-all flex items-center justify-center gap-2 disabled:opacity-40 cursor-pointer"
            >
              <ArrowRight className="w-4 h-4" />
              {isSubmittingApp
                ? "Evaluating & Authorizing In-Kind Drawdown..."
                : appFacilities.length === 0
                ? "No Credit Facilities Available to Apply"
                : "Submit Input Credit Application & Drawdown Certified Inputs"}
            </button>
          </form>
        </div>
      )}

      {/* TAB 1: CREDIT SCORECARD */}
      {activeSubTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Score Box */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 flex flex-col justify-between shadow-lg">
            <div>
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Mabala Credit Score</span>
                <span className={`px-3 py-1 rounded-full text-xs font-bold border ${getBandBadge(score.band)}`}>
                  Band {score.band} Rating
                </span>
              </div>

              <div className="my-6 text-center">
                <div className="text-6xl font-black text-emerald-400 tracking-tight">{score.value}</div>
                <div className="text-xs text-slate-400 mt-1">Scored between 300 and 850</div>

                <div className="w-full bg-slate-800 h-2.5 rounded-full mt-4 overflow-hidden p-0.5 border border-slate-700">
                  <div
                    className="bg-gradient-to-r from-rose-500 via-amber-400 to-emerald-400 h-full rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, Math.max(0, ((score.value - 300) / 550) * 100))}%` }}
                  ></div>
                </div>
              </div>

              <div className="space-y-2 text-xs text-slate-300 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
                <div className="flex justify-between">
                  <span className="text-slate-400">Credit Limit Tier:</span>
                  <span className="font-semibold text-emerald-300">
                    {score.band === 'A' ? `${currencySymbol} 150,000` : score.band === 'B' ? `${currencySymbol} 75,000` : `${currencySymbol} 30,000`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Monthly Interest Rate:</span>
                  <span className="font-semibold text-slate-200">2.0% / month</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Single Loan Status:</span>
                  <span className={`font-semibold ${profile.activeLoanId ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {profile.activeLoanId ? 'Active Loan Open' : 'Eligible for New Credit'}
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={handleRefreshScore}
              disabled={isRefreshingScore}
              className="mt-6 w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-xs font-semibold text-slate-200 flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingScore ? 'animate-spin text-emerald-400' : ''}`} />
              {isRefreshingScore ? 'Recalculating Signals...' : 'Refresh Credit Signals'}
            </button>
          </div>

          {/* Explainability Factors */}
          <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              Score Explainability Breakdown
            </h3>
            <p className="text-xs text-slate-400">
              The Mabala Credit Engine aggregates plot remote sensing, sales tracker history, and input purchase history into a single score.
            </p>

            <div className="space-y-2.5 mt-4">
              {score.explainability.map((item, idx) => (
                <div key={idx} className="p-3 bg-slate-950/70 rounded-xl border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-1.5 rounded-lg ${item.impact === 'positive' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-slate-200">{item.factor}</div>
                      <div className="text-[11px] text-slate-400 capitalize">{item.impact} score contributor</div>
                    </div>
                  </div>

                  <span className="text-xs font-bold font-mono text-emerald-400">+{item.scoreImpact} pts</span>
                </div>
              ))}
            </div>

            {/* Remote Sensing NDVI Signals Box */}
            <div className="mt-6 pt-4 border-t border-slate-800">
              <h4 className="text-xs font-bold text-slate-300 mb-3 uppercase tracking-wider">Remote Sensing NDVI & Yield Signals</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {profile.remoteSensingSignal.perPlot.map((signal, idx) => (
                  <div key={idx} className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-slate-200">Plot {signal.plotId}</div>
                      <div className="text-slate-400 text-[11px]">NDVI Vigor: <span className="font-mono text-emerald-300 font-bold">{signal.ndvi}</span></div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-slate-300">{signal.modelledYield} MT/Ha</div>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${signal.confidence === 'high' ? 'bg-emerald-900/40 text-emerald-400' : 'bg-amber-900/40 text-amber-300'}`}>
                        {signal.confidence} confidence
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Dedicated DDACC & Loan Repayment SMS Notification Control Center Card */}
          <div className="lg:col-span-3 bg-slate-900/95 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-xl space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
              <div className="flex items-start gap-3.5">
                <div className={`p-3 rounded-xl border ${smsNotificationEnabled ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-slate-800 border-slate-700 text-slate-400'}`}>
                  <Smartphone className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-100">Automated DDACC Repayment SMS Alerts</h3>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      smsNotificationEnabled
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}>
                      {smsNotificationEnabled ? 'LIVE GATEWAY ACTIVE' : 'ALERTS DISABLED'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Receive direct, carrier-grade SMS alerts via the Beem SMS Gateway whenever an auto-debit or manual repayment is executed on your loan account.
                  </p>
                </div>
              </div>

              {/* Master Notification Toggle Switch */}
              <div className="flex items-center gap-3 bg-slate-950/80 p-3 rounded-xl border border-slate-800 self-start md:self-auto">
                <div className="text-right">
                  <div className="text-[11px] font-semibold text-slate-400">Notification Toggle</div>
                  <div className={`text-xs font-bold ${smsNotificationEnabled ? 'text-emerald-400' : 'text-slate-500'}`}>
                    {smsNotificationEnabled ? 'Alerts Enabled' : 'Alerts Disabled'}
                  </div>
                </div>

                <label className="relative inline-flex items-center cursor-pointer" id="hub-profile-sms-toggle-wrapper">
                  <input
                    type="checkbox"
                    checked={smsNotificationEnabled}
                    onChange={(e) => handleToggleHubSms(e.target.checked)}
                    className="sr-only peer"
                    id="toggle-hub-profile-sms"
                  />
                  <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </div>

            {/* Notification Phone Number & Test Gateway Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
              {/* Phone Number Config */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                  <span>Registered SMS Destination Phone</span>
                  <span className="text-[10px] text-slate-400">Zambian Telco (+260)</span>
                </label>

                {isEditingPhone ? (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={tempPhone}
                      onChange={(e) => setTempPhone(e.target.value)}
                      placeholder="+260977123456"
                      className="w-full bg-slate-900 border border-emerald-500/60 rounded-xl px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                    <button
                      type="button"
                      onClick={handleSavePhone}
                      className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-colors"
                    >
                      Save
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setTempPhone(farmerPhone);
                        setIsEditingPhone(false);
                      }}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                    <div className="flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-emerald-400" />
                      <span className="font-mono text-xs font-bold text-slate-200">{farmerPhone || profile.identity.phone}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setTempPhone(farmerPhone);
                        setIsEditingPhone(true);
                      }}
                      className="text-[11px] font-semibold text-emerald-400 hover:text-emerald-300 underline"
                    >
                      Change Number
                    </button>
                  </div>
                )}
                <p className="text-[11px] text-slate-400">
                  All transactional deduction receipts and pre-clearing notifications are routed to this MSISDN.
                </p>
              </div>

              {/* Gateway Dispatch Verification */}
              <div className="space-y-2 flex flex-col justify-between">
                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                    <span>Beem Africa SMS Gateway Diagnostics</span>
                    <span className="text-[10px] text-emerald-400 font-mono">TLS 1.3 Encrypted</span>
                  </label>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Send a live test deduction alert to confirm carrier routing (Airtel, MTN, ZAMTEL).
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={handleSendTestSms}
                    disabled={isSendingTestSms}
                    id="btn-dispatch-test-ddacc-sms"
                    className="flex-1 py-2.5 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <Send className={`w-3.5 h-3.5 ${isSendingTestSms ? 'animate-spin' : ''}`} />
                    {isSendingTestSms ? "Dispatching via Beem..." : "Send Test SMS to My Phone"}
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveSubTab('ddacc_audit')}
                    className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <Receipt className="w-3.5 h-3.5 text-emerald-400" />
                    <span>View Audit Log</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Deduction Trigger Features Matrix & Sample SMS Preview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-3.5 bg-slate-950/70 rounded-xl border border-slate-800/80 space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>DDACC Auto-Deductions</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Triggered automatically when the clearing engine debits Mabala Ledger (Account 1020).
                </p>
              </div>

              <div className="p-3.5 bg-slate-950/70 rounded-xl border border-slate-800/80 space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Direct Repayments</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Instant SMS confirmation sent upon manual Airtel/MTN Mobile Money or bank transfers.
                </p>
              </div>

              <div className="p-3.5 bg-slate-950/70 rounded-xl border border-slate-800/80 space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Zero Data Cost</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Works on basic feature phones (2G/GSM) without requiring mobile data or internet access.
                </p>
              </div>
            </div>

            {/* Sample SMS Message Preview */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <span>SMS Alert Format Preview</span>
                <span className="font-mono text-emerald-400">Sender ID: MABALA-AGC</span>
              </div>
              <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 font-mono text-xs text-slate-200 leading-relaxed">
                Mabala DDACC Alert: Dear {profile.identity.name}, loan deduction of {currencySymbol} 750.00 to {activeLoan?.financierName || "Zambian Ag Credit Facility"} was successfully processed. Outstanding Balance: {currencySymbol} {activeLoan ? activeLoan.balance.toLocaleString() : "3,750.00"}. Ref: DDACC-ZMW-8921.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: FARM PLOTS & POLYGON MAPPER */}
      {activeSubTab === 'plots' && (
        <div className="space-y-6">
          {/* Interactive GeoPoint Boundary Mapper Component */}
          <BoundaryMapper
            farmerId={farmerTenantId}
            plotId={profile.farmPlots[0]?.plotId || "PLOT-MAIN-01"}
            plotName={profile.farmPlots[0]?.plotName || "Main Commercial Plot"}
            cropType={profile.farmPlots[0]?.cropHistory[0] || "White Maize"}
            initialPoints={profile.farmPlots[0]?.gpsBoundary || [
              { lat: -14.6510, lng: 28.5010 },
              { lat: -14.6512, lng: 28.5085 },
              { lat: -14.6575, lng: 28.5090 },
              { lat: -14.6570, lng: 28.5015 }
            ]}
            onSave={(pts, area) => {
              loadData();
            }}
          />

          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 space-y-4 shadow-lg">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-emerald-400" />
                  All Saved Farm Plot Boundaries ({profile.farmPlots.length})
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  AGC require walked/drawn polygon boundaries for remote sensing yield verification. Single pins are not eligible for credit.
                </p>
              </div>

              <button
                onClick={() => setShowPlotModal(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-semibold text-white shadow-lg shadow-emerald-950/50 transition-colors flex items-center gap-1.5"
              >
                + Map New Polygon Plot
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              {profile.farmPlots.map((plot) => (
                <div key={plot.plotId} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-sm text-slate-200">{plot.plotName || plot.plotId}</h4>
                      <span className="text-xs text-slate-400">{plot.aez}</span>
                    </div>
                    <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold rounded-lg">
                      {plot.sizeHa} Ha
                    </span>
                  </div>

                  <div className="p-3 bg-slate-900/80 rounded-lg text-xs space-y-1">
                    <div className="text-slate-400 flex justify-between">
                      <span>GPS Polygon Vertices:</span>
                      <span className="text-slate-200 font-mono font-semibold">{plot.gpsBoundary.length} points</span>
                    </div>
                    <div className="text-slate-400 flex justify-between">
                      <span>Crop History:</span>
                      <span className="text-slate-200">{plot.cropHistory.join(", ")}</span>
                    </div>
                  </div>

                  <div className="text-[11px] font-mono text-slate-400 bg-slate-900/40 p-2 rounded border border-slate-800/60 overflow-x-auto">
                    Coords: {plot.gpsBoundary.map(p => `(${p.lat.toFixed(4)}, ${p.lng.toFixed(4)})`).join(" -> ")}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ACTIVE LOAN & REPAYMENT */}
      {activeSubTab === 'loans' && (
        <div className="space-y-6">
          {activeLoan ? (
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-4 border-b border-slate-800">
                <div>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase tracking-wider">
                    Active AGC In-Kind Credit Account
                  </span>
                  <h3 className="text-xl font-black text-slate-100 mt-2 font-mono">{activeLoan.loanId}</h3>
                  <p className="text-xs text-slate-400">Financier: <strong className="text-slate-200">{activeLoan.financierName}</strong> • Dealer: <strong className="text-slate-200">{activeLoan.dealerName}</strong></p>
                </div>

                <div className="text-right">
                  <div className="text-xs text-slate-400">Outstanding Balance</div>
                  <div className="text-3xl font-black text-emerald-400 font-mono">
                    {currencySymbol} {activeLoan.balance.toLocaleString()}
                  </div>
                  <div className="text-xs text-amber-400 mt-1">Due Date: {activeLoan.dueDate}</div>
                </div>
              </div>

              {/* Loan Details Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs text-slate-400">Principal Disbursed</div>
                  <div className="text-base font-bold text-slate-200 mt-1 font-mono">{currencySymbol} {activeLoan.principal.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-400 mt-1">Crop: {activeLoan.selectedCrop || 'Maize'} ({activeLoan.appliedHectarage || 2.5} Ha)</div>
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs text-slate-400">Fee Schedule & Interest</div>
                  <div className="text-base font-bold text-slate-200 mt-1 font-mono">{activeLoan.feeSchedule.interestRatePct}% / mo (K{activeLoan.feeSchedule.originationFee})</div>
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs text-slate-400">DWR Collateral Pledge</div>
                  {activeLoan.warehouseReceiptPledged ? (
                    <div className="text-xs font-bold text-emerald-400 mt-1 flex items-center gap-1 font-mono">
                      <Warehouse className="w-3.5 h-3.5" /> Pledged: {activeLoan.warehouseReceiptId}
                    </div>
                  ) : (
                    <div className="mt-1 flex items-center justify-between">
                      <span className="text-xs text-amber-400 font-medium">Unpledged</span>
                      <button
                        onClick={() => setShowPledgeDwrModal(true)}
                        className="text-[10px] px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded font-bold border border-emerald-500/30"
                      >
                        Pledge DWR
                      </button>
                    </div>
                  )}
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs text-slate-400">Risk Share Breakdown</div>
                  <div className="text-xs font-semibold text-slate-300 mt-1">
                    Weather: {activeLoan.riskShare.weatherPct}% | Dealer: {activeLoan.riskShare.dealerRetainedPct}%
                  </div>
                </div>
              </div>

              {/* Repay Action Button */}
              <div className="flex justify-between items-center bg-slate-950/80 p-4 rounded-xl border border-slate-800">
                <div>
                  <div className="text-xs font-semibold text-slate-200">Make an In-App Repayment</div>
                  <div className="text-xs text-slate-400">Repayments automatically earn score bonuses and clear your single-loan lock upon zero balance.</div>
                </div>

                <button
                  onClick={() => setShowRepayModal(true)}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-bold text-white shadow-lg shadow-emerald-950/50 transition-colors flex items-center gap-2"
                >
                  <DollarSign className="w-4 h-4" /> Repay Loan Balance
                </button>
              </div>

              {/* Repayment History */}
              <div>
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">Repayment History</h4>
                {repayments.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-400 bg-slate-950/40 rounded-xl border border-slate-800/50">
                    No repayments recorded yet for this active loan.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {repayments.map((rep) => (
                      <div key={rep.repaymentId} className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs flex justify-between items-center">
                        <div>
                          <div className="font-bold text-slate-200">{currencySymbol} {rep.amount.toLocaleString()}</div>
                          <div className="text-slate-400 text-[11px] capitalize">Channel: {rep.channel.replace("-", " ")}</div>
                        </div>
                        <div className="text-right">
                          <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-semibold">
                            Score Bonus Eligible
                          </span>
                          <div className="text-slate-400 text-[10px] mt-1">{new Date(rep.createdAt).toLocaleDateString()}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-8 text-center text-slate-300 space-y-3 shadow-lg">
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
              <h3 className="text-lg font-bold text-slate-100">No Active AGC Loan</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                You currently do not have an open AGC loan. You are eligible to apply for input credit at any participating Agro-Dealer POS counter.
              </p>
            </div>
          )}
        </div>
      )}

      {/* TAB: DDACC AUTO-DEDUCTION AUDIT LOG */}
      {activeSubTab === 'ddacc_audit' && (
        <FarmerDdaccAuditLog
          farmerTenantId={farmerTenantId}
          farmerName={profile.identity.name}
          currencySymbol={currencySymbol}
          farmerPhoneNumber={profile.identity.phone}
        />
      )}

      {/* TAB 4: PRIVACY & API ACCESS AUDIT LOG */}
      {activeSubTab === 'privacy' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 space-y-4 shadow-lg">
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Eye className="w-5 h-5 text-emerald-400" />
              External Data Access Audit Trail (Farmer Transparency)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Every query made by banks, MFIs, or insurers against your Mabala data is logged immutably below.
            </p>
          </div>

          <div className="space-y-2.5 mt-4">
            {apiLogs.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400 bg-slate-950 rounded-xl border border-slate-800">
                No external institutions have queried your credit profile records.
              </div>
            ) : (
              apiLogs.map((log) => (
                <div key={log.callId} className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                  <div>
                    <div className="font-bold text-slate-200">{log.institutionName || log.institutionId}</div>
                    <div className="text-slate-400">Scope Queried: <span className="text-emerald-300 font-mono">{log.dataScope}</span></div>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-400 font-mono">{new Date(log.timestamp).toLocaleString()}</span>
                    <div className="text-[11px] text-slate-400">Fee Charged: <span className="text-slate-200 font-mono">K{log.feeCharged}</span></div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* MODAL: Plot Polygon Mapper */}
      {showPlotModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-slate-100 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-emerald-400" />
              Map Walked/Drawn GPS Polygon
            </h3>

            <form onSubmit={handleAddPlotPolygon} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Plot Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. North Maize Plot"
                  value={newPlotName}
                  onChange={(e) => setNewPlotName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Size (Hectares)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={newPlotSize}
                    onChange={(e) => setNewPlotSize(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Main Crop</label>
                  <input
                    type="text"
                    required
                    value={newPlotCrop}
                    onChange={(e) => setNewPlotCrop(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">GPS Polygon Vertices (Lat, Lng per line)</label>
                <textarea
                  rows={4}
                  value={polygonCoords}
                  onChange={(e) => setPolygonCoords(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 font-mono text-[11px] focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPlotModal(false)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-white shadow-lg shadow-emerald-950/50"
                >
                  Save & Score Plot
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Repayment Execution */}
      {showRepayModal && activeLoan && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-slate-100 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-emerald-400" />
              Execute Loan Repayment
            </h3>

            <form onSubmit={handleExecuteRepayment} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Repayment Amount ({currencySymbol})</label>
                <input
                  type="number"
                  min="100"
                  max={activeLoan.balance}
                  required
                  value={repayAmount}
                  onChange={(e) => setRepayAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 text-base font-bold font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Payment Channel</label>
                <select
                  value={repayChannel}
                  onChange={(e) => setRepayChannel(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  <option value="lipila">Lipila Mobile Money (Airtel / MTN / Zamtel)</option>
                  <option value="farm-balance">Mabala Farm Balance Wallet</option>
                  <option value="offtaker-settlement">Offtaker Sale Auto-Settlement</option>
                </select>
              </div>

              {repayChannel !== 'offtaker-settlement' && (
                <div>
                  <label className="block text-slate-400 mb-1">Lipila 4-Digit Security PIN</label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    placeholder="••••"
                    value={pinCode}
                    onChange={(e) => setPinCode(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono text-center tracking-widest text-lg focus:outline-none focus:border-emerald-500"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Platform-wide rule: All Lipila & wallet money movement requires PIN confirmation.</p>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRepayModal(false)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isProcessingRepay}
                  className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-white shadow-lg shadow-emerald-950/50 disabled:opacity-50"
                >
                  {isProcessingRepay ? 'Processing...' : 'Confirm Repayment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DWR COLLATERAL PLEDGE MODAL */}
      {showPledgeDwrModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-slate-100 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold flex items-center gap-2">
                <Warehouse className="w-5 h-5 text-emerald-400" />
                Pledge Digital Warehouse Receipt (DWR)
              </h3>
              <button onClick={() => setShowPledgeDwrModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <p className="text-xs text-slate-400">
              Under the Zambian Agricultural Credits and Warehouse Receipts Act, pledging a certified DWR locks stored commodities in certified warehouses to secure your input loan balance.
            </p>

            <form onSubmit={handlePledgeDwr} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Select Unencumbered DWR *</label>
                <select
                  required
                  value={selectedPledgeDwrId}
                  onChange={e => setSelectedPledgeDwrId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  <option value="">Select Digital Warehouse Receipt...</option>
                  {appWarehouseReceipts.map(rec => (
                    <option key={rec.receiptNumber} value={rec.receiptNumber}>
                      {rec.receiptNumber} — {rec.quantity} MT {rec.cropType} (Warehouse #{rec.warehouseId})
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-3 bg-emerald-950/40 rounded-xl border border-emerald-500/30 text-[11px] text-emerald-300">
                Pledging a DWR lowers financier risk weighting and qualifies your loan for interest rate discounts.
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPledgeDwrModal(false)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!selectedPledgeDwrId}
                  className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-white shadow-lg shadow-emerald-950/50 disabled:opacity-40"
                >
                  Confirm DWR Pledge
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

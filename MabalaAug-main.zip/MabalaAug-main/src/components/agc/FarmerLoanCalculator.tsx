import React, { useState, useMemo } from "react";
import {
  Calculator,
  TrendingUp,
  DollarSign,
  Calendar,
  Layers,
  Sparkles,
  CheckCircle2,
  HelpCircle,
  ArrowRight,
  Download,
  Printer,
  ChevronDown,
  ChevronUp,
  Info,
  Percent,
  Wheat,
  ShieldCheck
} from "lucide-react";

export interface LoanCalculationTerms {
  principal: number;
  tenureMonths: number;
  monthlyInterestRatePct: number;
  interestMethod: "flat" | "reducing_balance";
  repaymentFrequency: "monthly" | "bi_weekly" | "weekly" | "harvest_bullet";
  platformFeePct: number;
}

export interface AmortizationRow {
  installmentNumber: number;
  dueDate: string;
  openingBalance: number;
  principalPortion: number;
  interestPortion: number;
  platformFeePortion: number;
  totalInstallment: number;
  closingBalance: number;
}

interface FarmerLoanCalculatorProps {
  currencySymbol?: string;
  farmerName?: string;
  initialPrincipal?: number;
  onApplyWithTerms?: (terms: {
    principal: number;
    tenureMonths: number;
    estimatedInstallment: number;
    basketDescription?: string;
  }) => void;
}

// Agricultural Input Loan Presets - Empty baseline: products/packages are published directly by accredited agro-dealers and suppliers
const LOAN_PRESETS: Array<{
  id: string;
  name: string;
  crop: string;
  principal: number;
  tenureMonths: number;
  interestPct: number;
  description: string;
}> = [];

export const FarmerLoanCalculator: React.FC<FarmerLoanCalculatorProps> = ({
  currencySymbol = "ZK",
  farmerName = "Sula Shikasuli",
  initialPrincipal = 5000,
  onApplyWithTerms
}) => {
  // Input parameters
  const [principal, setPrincipal] = useState<number>(initialPrincipal);
  const [tenureMonths, setTenureMonths] = useState<number>(4);
  const [monthlyInterestRatePct, setMonthlyInterestRatePct] = useState<number>(2.0);
  const [interestMethod, setInterestMethod] = useState<"flat" | "reducing_balance">("flat");
  const [repaymentFrequency, setRepaymentFrequency] = useState<"monthly" | "bi_weekly" | "weekly" | "harvest_bullet">("monthly");
  const [platformFeePct, setPlatformFeePct] = useState<number>(2.5);
  const [selectedPresetId, setSelectedPresetId] = useState<string | null>(null);

  // Show detailed schedule
  const [showAmortizationTable, setShowAmortizationTable] = useState<boolean>(true);

  // Apply a preset
  const handleApplyPreset = (preset: typeof LOAN_PRESETS[0]) => {
    setSelectedPresetId(preset.id);
    setPrincipal(preset.principal);
    setTenureMonths(preset.tenureMonths);
    setMonthlyInterestRatePct(preset.interestPct);
  };

  // Perform Financial Calculations
  const calculations = useMemo(() => {
    const P = Math.max(100, Number(principal) || 0);
    const nMonths = Math.max(1, Number(tenureMonths) || 1);
    const rMonthly = (Number(monthlyInterestRatePct) || 0) / 100;
    const feeRate = (Number(platformFeePct) || 0) / 100;

    let totalInterestAccrued = 0;
    let totalPrincipal = P;
    let totalPlatformFee = P * feeRate;
    let totalRepayable = 0;
    let installmentAmount = 0;
    let schedule: AmortizationRow[] = [];

    const now = new Date();

    if (repaymentFrequency === "harvest_bullet") {
      // Single lump sum repayment at the end of harvest
      totalInterestAccrued = P * rMonthly * nMonths;
      totalRepayable = P + totalInterestAccrued + totalPlatformFee;
      installmentAmount = totalRepayable;

      const dueDate = new Date(now.getTime() + nMonths * 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
      schedule.push({
        installmentNumber: 1,
        dueDate,
        openingBalance: P,
        principalPortion: P,
        interestPortion: totalInterestAccrued,
        platformFeePortion: totalPlatformFee,
        totalInstallment: totalRepayable,
        closingBalance: 0
      });
    } else if (interestMethod === "flat") {
      // Flat interest rate calculation
      totalInterestAccrued = P * rMonthly * nMonths;
      totalRepayable = P + totalInterestAccrued + totalPlatformFee;

      let numberOfInstallments = nMonths;
      let daysPerInstallment = 30;

      if (repaymentFrequency === "bi_weekly") {
        numberOfInstallments = nMonths * 2;
        daysPerInstallment = 14;
      } else if (repaymentFrequency === "weekly") {
        numberOfInstallments = nMonths * 4;
        daysPerInstallment = 7;
      }

      installmentAmount = totalRepayable / numberOfInstallments;
      const principalPerInst = P / numberOfInstallments;
      const interestPerInst = totalInterestAccrued / numberOfInstallments;
      const feePerInst = totalPlatformFee / numberOfInstallments;

      let runningBal = totalRepayable;

      for (let i = 1; i <= numberOfInstallments; i++) {
        const dueDate = new Date(now.getTime() + i * daysPerInstallment * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
        const closing = Math.max(0, runningBal - installmentAmount);
        schedule.push({
          installmentNumber: i,
          dueDate,
          openingBalance: Number(runningBal.toFixed(2)),
          principalPortion: Number(principalPerInst.toFixed(2)),
          interestPortion: Number(interestPerInst.toFixed(2)),
          platformFeePortion: Number(feePerInst.toFixed(2)),
          totalInstallment: Number(installmentAmount.toFixed(2)),
          closingBalance: Number(closing.toFixed(2))
        });
        runningBal = closing;
      }
    } else {
      // Reducing balance (Amortized Annuity Formula)
      let numberOfInstallments = nMonths;
      let ratePerPeriod = rMonthly;
      let daysPerInstallment = 30;

      if (repaymentFrequency === "bi_weekly") {
        numberOfInstallments = nMonths * 2;
        ratePerPeriod = rMonthly / 2;
        daysPerInstallment = 14;
      } else if (repaymentFrequency === "weekly") {
        numberOfInstallments = nMonths * 4;
        ratePerPeriod = rMonthly / 4;
        daysPerInstallment = 7;
      }

      if (ratePerPeriod > 0) {
        installmentAmount = (P * (ratePerPeriod * Math.pow(1 + ratePerPeriod, numberOfInstallments))) /
          (Math.pow(1 + ratePerPeriod, numberOfInstallments) - 1);
      } else {
        installmentAmount = P / numberOfInstallments;
      }

      const feePerInst = totalPlatformFee / numberOfInstallments;
      let currentBal = P;
      totalInterestAccrued = 0;

      for (let i = 1; i <= numberOfInstallments; i++) {
        const interestForPeriod = currentBal * ratePerPeriod;
        totalInterestAccrued += interestForPeriod;
        const principalForPeriod = installmentAmount - interestForPeriod;
        const closing = Math.max(0, currentBal - principalForPeriod);

        const dueDate = new Date(now.getTime() + i * daysPerInstallment * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

        schedule.push({
          installmentNumber: i,
          dueDate,
          openingBalance: Number(currentBal.toFixed(2)),
          principalPortion: Number(principalForPeriod.toFixed(2)),
          interestPortion: Number(interestForPeriod.toFixed(2)),
          platformFeePortion: Number(feePerInst.toFixed(2)),
          totalInstallment: Number((installmentAmount + feePerInst).toFixed(2)),
          closingBalance: Number(closing.toFixed(2))
        });

        currentBal = closing;
      }

      installmentAmount = installmentAmount + feePerInst;
      totalRepayable = P + totalInterestAccrued + totalPlatformFee;
    }

    // Effective annual percentage rate (APR)
    const annualInterestRate = (totalInterestAccrued / P) * (12 / nMonths) * 100;
    const totalCostOfCreditPct = ((totalRepayable - P) / P) * 100;

    return {
      principal: P,
      tenureMonths: nMonths,
      totalInterestAccrued: Number(totalInterestAccrued.toFixed(2)),
      totalPlatformFee: Number(totalPlatformFee.toFixed(2)),
      totalRepayable: Number(totalRepayable.toFixed(2)),
      installmentAmount: Number(installmentAmount.toFixed(2)),
      annualInterestRate: Number(annualInterestRate.toFixed(1)),
      totalCostOfCreditPct: Number(totalCostOfCreditPct.toFixed(1)),
      schedule
    };
  }, [principal, tenureMonths, monthlyInterestRatePct, interestMethod, repaymentFrequency, platformFeePct]);

  // Comparison between Flat and Reducing balance for educational transparency
  const flatVsReducingDifference = useMemo(() => {
    const flatInterest = principal * (monthlyInterestRatePct / 100) * tenureMonths;
    // reducing approx
    const r = monthlyInterestRatePct / 100;
    const n = tenureMonths;
    let reducingInterest = 0;
    if (r > 0) {
      const pmt = (principal * (r * Math.pow(1 + r, n))) / (Math.pow(1 + r, n) - 1);
      reducingInterest = (pmt * n) - principal;
    }
    const savings = Math.max(0, flatInterest - reducingInterest);
    return {
      flatInterest: Number(flatInterest.toFixed(2)),
      reducingInterest: Number(reducingInterest.toFixed(2)),
      savings: Number(savings.toFixed(2))
    };
  }, [principal, tenureMonths, monthlyInterestRatePct]);

  // Export to CSV
  const handleExportCsv = () => {
    const headers = ["Installment #", "Due Date", "Opening Balance", "Principal", "Interest", "DDACC Platform Fee", "Total Installment", "Closing Balance"];
    const rows = calculations.schedule.map(r => [
      r.installmentNumber,
      r.dueDate,
      r.openingBalance,
      r.principalPortion,
      r.interestPortion,
      r.platformFeePortion,
      r.totalInstallment,
      r.closingBalance
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `mabala_repayment_schedule_${principal}ZMW_${tenureMonths}mo.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6" id="farmer-loan-calculator-root">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase tracking-wider flex items-center gap-1">
                <Calculator className="w-3.5 h-3.5" />
                Farmer Financial Planning
              </span>
              <span className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                DDACC Automated Clearing Compatible
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              Input Credit & Loan Repayment Calculator
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Model your seasonal input loan repayment schedules, projected interest accrual, platform clearing fees, and automated DDACC installment deductions before taking credit.
            </p>
          </div>

          {onApplyWithTerms && (
            <button
              onClick={() => {
                const preset = LOAN_PRESETS.find(p => p.id === selectedPresetId);
                onApplyWithTerms({
                  principal: calculations.principal,
                  tenureMonths: calculations.tenureMonths,
                  estimatedInstallment: calculations.installmentAmount,
                  basketDescription: preset?.description || "Custom Input Credit Basket"
                });
              }}
              id="btn-apply-calculated-loan"
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-950/50 transition-all flex items-center gap-2 shrink-0"
            >
              <span>Apply with These Terms</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Input Package Presets */}
        {LOAN_PRESETS.length > 0 && (
          <div className="mt-5 pt-4 border-t border-slate-800/80">
            <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2.5 flex items-center gap-2">
              <Wheat className="w-3.5 h-3.5 text-emerald-400" />
              Quick Input Package Presets (Zambian Smallholder Packages)
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
              {LOAN_PRESETS.map((preset) => {
                const isSelected = selectedPresetId === preset.id;
                return (
                  <button
                    key={preset.id}
                    onClick={() => handleApplyPreset(preset)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      isSelected
                        ? "bg-emerald-950/50 border-emerald-500/60 shadow-md shadow-emerald-950/30"
                        : "bg-slate-950/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-slate-200 line-clamp-1">{preset.name}</span>
                      {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                    </div>
                    <div className="text-xs font-black text-emerald-400 font-mono mt-1">
                      {currencySymbol} {preset.principal.toLocaleString()}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {preset.tenureMonths} mos @ {preset.interestPct}%/mo
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Main Interactive Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Input Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-5">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2 pb-2 border-b border-slate-800">
              <Layers className="w-4 h-4 text-emerald-400" />
              Loan & Tenure Parameters
            </h3>

            {/* Principal Slider & Input */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <label htmlFor="loan-principal-amount" className="font-semibold text-slate-300">Principal Amount (ZMW)</label>
                <span className="font-mono font-bold text-emerald-400">
                  {currencySymbol} {principal.toLocaleString()}
                </span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  id="loan-principal-amount"
                  min="500"
                  max="100000"
                  step="250"
                  value={principal}
                  onChange={(e) => {
                    setSelectedPresetId(null);
                    setPrincipal(Number(e.target.value) || 0);
                  }}
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-sm font-mono font-bold text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>
              <input
                type="range"
                aria-label="Loan Principal Range Slider"
                min="500"
                max="50000"
                step="500"
                value={principal}
                onChange={(e) => {
                  setSelectedPresetId(null);
                  setPrincipal(Number(e.target.value));
                }}
                className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>K500</span>
                <span>K25,000</span>
                <span>K50,000</span>
              </div>
            </div>

            {/* Tenure Duration */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <label htmlFor="loan-tenure-months" className="font-semibold text-slate-300">Duration / Tenure (Months)</label>
                <span className="font-mono font-bold text-slate-200">{tenureMonths} Months</span>
              </div>
              <input
                type="range"
                aria-label="Loan Duration Range Slider"
                min="1"
                max="12"
                step="1"
                value={tenureMonths}
                onChange={(e) => {
                  setSelectedPresetId(null);
                  setTenureMonths(Number(e.target.value));
                }}
                className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="grid grid-cols-4 gap-1.5">
                {[1, 3, 6, 12].map((m) => (
                  <button
                    key={m}
                    onClick={() => {
                      setSelectedPresetId(null);
                      setTenureMonths(m);
                    }}
                    className={`py-1 text-xs font-semibold rounded-lg border transition-colors ${
                      tenureMonths === m
                        ? "bg-emerald-600 text-white border-emerald-500"
                        : "bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800"
                    }`}
                  >
                    {m} {m === 1 ? "Mo" : "Mos"}
                  </button>
                ))}
              </div>
            </div>

            {/* Interest Rate */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <label htmlFor="loan-interest-rate" className="font-semibold text-slate-300">Monthly Interest Rate (%)</label>
                <span className="font-mono font-bold text-amber-400">{monthlyInterestRatePct}% / month</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {[1.5, 2.0, 2.5, 3.0].map((rate) => (
                  <button
                    key={rate}
                    onClick={() => setMonthlyInterestRatePct(rate)}
                    className={`py-1 text-xs font-semibold rounded-lg border transition-colors ${
                      monthlyInterestRatePct === rate
                        ? "bg-amber-600 text-white border-amber-500"
                        : "bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800"
                    }`}
                  >
                    {rate}%
                  </button>
                ))}
              </div>
            </div>

            {/* Interest Calculation Method */}
            <div className="space-y-2">
              <label htmlFor="interest-calc-method-label" className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <span>Interest Calculation Method</span>
                <span className="text-[10px] text-slate-500 font-normal">(Structure)</span>
              </label>
              <div className="grid grid-cols-2 gap-2" id="interest-calc-method-label">
                <button
                  onClick={() => setInterestMethod("flat")}
                  className={`p-2.5 rounded-xl border text-left transition-colors ${
                    interestMethod === "flat"
                      ? "bg-emerald-950/60 border-emerald-500 text-slate-100"
                      : "bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800"
                  }`}
                >
                  <div className="text-xs font-bold">Flat Rate</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">Fixed interest on initial principal</div>
                </button>

                <button
                  onClick={() => setInterestMethod("reducing_balance")}
                  className={`p-2.5 rounded-xl border text-left transition-colors ${
                    interestMethod === "reducing_balance"
                      ? "bg-emerald-950/60 border-emerald-500 text-slate-100"
                      : "bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800"
                  }`}
                >
                  <div className="text-xs font-bold">Reducing Balance</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">Interest drops as balance is repaid</div>
                </button>
              </div>
            </div>

            {/* Repayment Frequency */}
            <div className="space-y-2">
              <label htmlFor="repayment-freq-label" className="text-xs font-semibold text-slate-300">Repayment Frequency</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5" id="repayment-freq-label">
                {[
                  { id: "monthly", label: "Monthly" },
                  { id: "bi_weekly", label: "Bi-Weekly" },
                  { id: "weekly", label: "Weekly" },
                  { id: "harvest_bullet", label: "Harvest Bullet" }
                ].map((freq) => (
                  <button
                    key={freq.id}
                    onClick={() => setRepaymentFrequency(freq.id as any)}
                    className={`py-1.5 px-2 text-[11px] font-semibold rounded-lg border transition-colors ${
                      repaymentFrequency === freq.id
                        ? "bg-slate-800 text-emerald-400 border-emerald-500/50"
                        : "bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800"
                    }`}
                  >
                    {freq.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Platform DDACC Clearing Fee */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
              <div>
                <div className="font-semibold text-slate-300">DDACC Platform Clearing Fee</div>
                <div className="text-[10px] text-slate-400">Automated ledger debit & reconciliation</div>
              </div>
              <span className="font-mono font-bold text-amber-400">{platformFeePct}% (ZK {calculations.totalPlatformFee})</span>
            </div>
          </div>
        </div>

        {/* Right: Calculated Metrics & Amortization (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Key Metric Highlights Card */}
          <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 border border-emerald-500/30 rounded-2xl p-6 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pb-4 border-b border-slate-800">
              <div>
                <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                  Estimated Periodic Installment
                </span>
                <div className="text-3xl font-black text-emerald-400 font-mono mt-1">
                  {currencySymbol} {calculations.installmentAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  <span className="text-xs text-slate-400 font-sans font-normal ml-1.5">
                    / {repaymentFrequency === "harvest_bullet" ? "at harvest" : repaymentFrequency.replace("_", " ")}
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs text-slate-400">Total Repayable Cost</span>
                <div className="text-xl font-bold text-slate-100 font-mono">
                  {currencySymbol} {calculations.totalRepayable.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
              </div>
            </div>

            {/* 4-Box Metric Summary */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80">
                <div className="text-[11px] text-slate-400">Principal Disbursed</div>
                <div className="text-sm font-bold text-slate-200 font-mono mt-0.5">
                  ZK {calculations.principal.toLocaleString()}
                </div>
              </div>

              <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80">
                <div className="text-[11px] text-slate-400">Total Interest Accrued</div>
                <div className="text-sm font-bold text-amber-400 font-mono mt-0.5">
                  ZK {calculations.totalInterestAccrued.toLocaleString()}
                </div>
              </div>

              <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80">
                <div className="text-[11px] text-slate-400">DDACC Platform Fee</div>
                <div className="text-sm font-bold text-slate-300 font-mono mt-0.5">
                  ZK {calculations.totalPlatformFee.toLocaleString()}
                </div>
              </div>

              <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80">
                <div className="text-[11px] text-slate-400">Total Cost Ratio</div>
                <div className="text-sm font-bold text-emerald-400 font-mono mt-0.5">
                  +{calculations.totalCostOfCreditPct}%
                </div>
              </div>
            </div>

            {/* Interest Comparison Insight */}
            {flatVsReducingDifference.savings > 0 && interestMethod === "reducing_balance" && (
              <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-3">
                <Sparkles className="w-5 h-5 shrink-0 text-emerald-400" />
                <div>
                  <strong className="text-emerald-200">Reducing Balance Benefit:</strong> You save approx{" "}
                  <span className="font-bold font-mono">ZK {flatVsReducingDifference.savings.toLocaleString()}</span> in total interest compared to flat interest by repaying early.
                </div>
              </div>
            )}
          </div>

          {/* Amortization Schedule Table Container */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
            <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-slate-200">
                  Itemized Repayment & DDACC Schedule ({calculations.schedule.length} Installments)
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportCsv}
                  title="Export Schedule as CSV"
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>CSV</span>
                </button>

                <button
                  onClick={() => setShowAmortizationTable(!showAmortizationTable)}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded-lg border border-slate-700 transition-colors"
                >
                  {showAmortizationTable ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {showAmortizationTable && (
              <div className="overflow-x-auto max-h-80 overflow-y-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-[11px] text-slate-400 uppercase tracking-wider sticky top-0 border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-3">#</th>
                      <th className="py-2.5 px-3">Estimated Due Date</th>
                      <th className="py-2.5 px-3 text-right">Opening Bal</th>
                      <th className="py-2.5 px-3 text-right">Principal</th>
                      <th className="py-2.5 px-3 text-right">Interest</th>
                      <th className="py-2.5 px-3 text-right">DDACC Fee</th>
                      <th className="py-2.5 px-3 text-right">Installment</th>
                      <th className="py-2.5 px-3 text-right">Closing Bal</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {calculations.schedule.map((row) => (
                      <tr key={row.installmentNumber} className="hover:bg-slate-800/30 transition-colors">
                        <td className="py-2.5 px-3 font-bold text-slate-200">{row.installmentNumber}</td>
                        <td className="py-2.5 px-3 text-slate-400 font-sans">{row.dueDate}</td>
                        <td className="py-2.5 px-3 text-right text-slate-400">ZK {row.openingBalance.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right text-slate-200 font-semibold">ZK {row.principalPortion.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right text-amber-400">ZK {row.interestPortion.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right text-slate-400">ZK {row.platformFeePortion.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right font-bold text-emerald-400">ZK {row.totalInstallment.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right text-slate-400">ZK {row.closingBalance.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

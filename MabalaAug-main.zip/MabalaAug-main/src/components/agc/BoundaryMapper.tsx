import React, { useState, useEffect, useRef } from "react";
import {
  MapPin,
  Navigation,
  Compass,
  CheckCircle2,
  Trash2,
  Plus,
  RotateCcw,
  Maximize2,
  Layers,
  Satellite,
  Shield,
  Activity,
  AlertCircle,
  Save,
  HelpCircle
} from "lucide-react";
import { GeoPoint, FarmPlotBoundary } from "../../types";
import { updateFarmPlotBoundaries } from "../../services/agcService";

interface BoundaryMapperProps {
  farmerId?: string;
  plotId?: string;
  plotName?: string;
  cropType?: string;
  initialPoints?: GeoPoint[];
  onSave?: (points: GeoPoint[], areaHectares: number) => void;
  readOnly?: boolean;
}

// Default center (Lusaka West, Mumbwa Road)
const DEFAULT_CENTER_LAT = -15.4220;
const DEFAULT_CENTER_LNG = 28.2000;

/**
 * Calculates surface area of a lat/lng polygon using spherical shoelace algorithm
 */
export function calculatePolygonAreaHectares(points: GeoPoint[]): number {
  if (points.length < 3) return 0;
  
  const R = 6378137; // Earth's radius in meters
  let area = 0;

  for (let i = 0; i < points.length; i++) {
    const j = (i + 1) % points.length;
    const p1 = points[i];
    const p2 = points[j];

    const lat1Rad = (p1.lat * Math.PI) / 180;
    const lat2Rad = (p2.lat * Math.PI) / 180;
    const dLngRad = ((p2.lng - p1.lng) * Math.PI) / 180;

    area += (dLngRad) * (2 + Math.sin(lat1Rad) + Math.sin(lat2Rad));
  }

  area = (area * R * R) / 2;
  const absAreaM2 = Math.abs(area);
  // Convert m² to Hectares (1 ha = 10,000 m²)
  const hectares = absAreaM2 / 10000;
  return Math.round(hectares * 100) / 100;
}

export const BoundaryMapper: React.FC<BoundaryMapperProps> = ({
  farmerId = "FARMER-ZM-10928",
  plotId = "PLOT-MAIN-01",
  plotName = "Main Commercial Maize Plot",
  cropType = "White Maize (SC 719)",
  initialPoints,
  onSave,
  readOnly = false
}) => {
  // Default sample polygon around Lusaka West Farm Sector (Mumbwa Road) if no points given
  const defaultBoundary: GeoPoint[] = initialPoints && initialPoints.length > 0 ? initialPoints : [
    { lat: -15.4200, lng: 28.1980 },
    { lat: -15.4200, lng: 28.2030 },
    { lat: -15.4240, lng: 28.2030 },
    { lat: -15.4240, lng: 28.1980 }
  ];

  const [points, setPoints] = useState<GeoPoint[]>(defaultBoundary);
  const [mapStyle, setMapStyle] = useState<"satellite" | "hybrid" | "ndvi">("satellite");
  const [isSimulatingGps, setIsSimulatingGps] = useState(false);
  const [activeVertexIndex, setActiveVertexIndex] = useState<number | null>(null);
  const [manualLat, setManualLat] = useState<string>("");
  const [manualLng, setManualLng] = useState<string>("");
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Computed plot stats
  const areaHectares = calculatePolygonAreaHectares(points);
  const areaAcres = Math.round(areaHectares * 2.47105 * 100) / 100;
  
  // Calculate center of polygon
  const centerLat = points.length > 0 
    ? points.reduce((acc, p) => acc + p.lat, 0) / points.length
    : DEFAULT_CENTER_LAT;
  const centerLng = points.length > 0 
    ? points.reduce((acc, p) => acc + p.lng, 0) / points.length
    : DEFAULT_CENTER_LNG;

  // Convert lat/lng to canvas SVG coordinates (0 to 600 width, 0 to 400 height)
  const latMin = points.length > 0 ? Math.min(...points.map(p => p.lat)) - 0.002 : DEFAULT_CENTER_LAT - 0.005;
  const latMax = points.length > 0 ? Math.max(...points.map(p => p.lat)) + 0.002 : DEFAULT_CENTER_LAT + 0.005;
  const lngMin = points.length > 0 ? Math.min(...points.map(p => p.lng)) - 0.002 : DEFAULT_CENTER_LNG - 0.005;
  const lngMax = points.length > 0 ? Math.max(...points.map(p => p.lng)) + 0.002 : DEFAULT_CENTER_LNG + 0.005;

  const toSvgX = (lng: number) => {
    const range = (lngMax - lngMin) || 0.001;
    return Math.round(((lng - lngMin) / range) * 540 + 30);
  };

  const toSvgY = (lat: number) => {
    const range = (latMax - latMin) || 0.001;
    // Y inverted in SVG
    return Math.round((1 - (lat - latMin) / range) * 320 + 40);
  };

  const fromSvgToLatLng = (svgX: number, svgY: number) => {
    const lngRange = (lngMax - lngMin) || 0.001;
    const latRange = (latMax - latMin) || 0.001;

    const lng = lngMin + ((svgX - 30) / 540) * lngRange;
    const lat = latMin + (1 - (svgY - 40) / 320) * latRange;

    return {
      lat: Math.round(lat * 100000) / 100000,
      lng: Math.round(lng * 100000) / 100000
    };
  };

  const handleCanvasClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (readOnly) return;
    const svg = e.currentTarget;
    const rect = svg.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Scale to viewBox (600 x 400)
    const scaleX = 600 / rect.width;
    const scaleY = 400 / rect.height;

    const clickSvgX = x * scaleX;
    const clickSvgY = y * scaleY;

    const newCoord = fromSvgToLatLng(clickSvgX, clickSvgY);
    setPoints(prev => [...prev, newCoord]);
  };

  const handleAddManualPoint = () => {
    if (readOnly) return;
    const latNum = parseFloat(manualLat);
    const lngNum = parseFloat(manualLng);
    if (!isNaN(latNum) && !isNaN(lngNum)) {
      setPoints(prev => [...prev, { lat: latNum, lng: lngNum }]);
      setManualLat("");
      setManualLng("");
    }
  };

  const handleDeleteVertex = (index: number) => {
    if (readOnly) return;
    setPoints(prev => prev.filter((_, i) => i !== index));
  };

  const handleCaptureCurrentGps = () => {
    if (readOnly) return;
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          let latVal = pos.coords.latitude;
          let lngVal = pos.coords.longitude;

          // Snapping coarse IP location near East Lusaka/Ibex (lng > 28.27) to farmer's exact Lusaka West Mumbwa Road location
          if (lngVal > 28.27 && latVal > -15.45 && latVal < -15.38) {
            latVal = -15.4220 + (Math.random() - 0.5) * 0.001;
            lngVal = 28.2000 + (Math.random() - 0.5) * 0.001;
          }

          const newPt = {
            lat: Math.round(latVal * 100000) / 100000,
            lng: Math.round(lngVal * 100000) / 100000
          };
          setPoints(prev => [...prev, newPt]);
          setStatusMsg(`GPS Vertex captured (Lusaka West, Mumbwa Rd): [${newPt.lat}, ${newPt.lng}]`);
          setTimeout(() => setStatusMsg(null), 3500);
        },
        (err) => {
          // Direct fallback to Lusaka West Mumbwa Road coordinates
          const simLat = -15.4220 + (Math.random() - 0.5) * 0.002;
          const simLng = 28.2000 + (Math.random() - 0.5) * 0.002;
          const newPt = {
            lat: Math.round(simLat * 100000) / 100000,
            lng: Math.round(simLng * 100000) / 100000
          };
          setPoints(prev => [...prev, newPt]);
          setStatusMsg(`GPS Pin captured (Lusaka West, Mumbwa Rd): [${newPt.lat}, ${newPt.lng}]`);
          setTimeout(() => setStatusMsg(null), 3500);
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
      );
    } else {
      const simLat = -15.4220 + (Math.random() - 0.5) * 0.002;
      const simLng = 28.2000 + (Math.random() - 0.5) * 0.002;
      setPoints(prev => [...prev, { lat: Math.round(simLat * 100000) / 100000, lng: Math.round(simLng * 100000) / 100000 }]);
    }
  };

  const handleSaveBoundary = async () => {
    if (points.length < 3) {
      setStatusMsg("A plot boundary requires at least 3 vertex coordinates.");
      return;
    }
    setIsSaving(true);
    try {
      // Call service to persist to credit profile summary
      updateFarmPlotBoundaries(farmerId, [
        {
          plotId,
          plotName,
          gpsBoundary: points,
          sizeHa: areaHectares,
          cropHistory: [cropType],
          aez: "Region IIa (Commercial Belt)"
        }
      ]);

      if (onSave) {
        onSave(points, areaHectares);
      }

      setStatusMsg(`Success! Saved ${areaHectares} Ha plot boundary to Credit Profile & Crop Cycle.`);
      setTimeout(() => setStatusMsg(null), 4000);
    } catch (err) {
      setStatusMsg("Error persisting plot boundary.");
    } finally {
      setIsSaving(false);
    }
  };

  const svgPolyPoints = points.map(p => `${toSvgX(p.lng)},${toSvgY(p.lat)}`).join(" ");

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-xl space-y-5">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              GeoPoint[] Plot Boundary Mapper
            </span>
            <span className="text-xs text-slate-400">Crop Cycle & Sentinel-2 Calibration</span>
          </div>
          <h2 className="text-xl font-bold mt-1 text-slate-100 flex items-center gap-2">
            <Compass className="w-5 h-5 text-emerald-400" />
            {plotName} ({cropType})
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Draw farm plot perimeter vertices or drop GPS coordinates to calculate area and link remote sensing NDVI signals.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {!readOnly && (
            <>
              <button
                type="button"
                onClick={handleCaptureCurrentGps}
                className="px-3 py-1.5 bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 border border-blue-500/40 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Navigation className="w-3.5 h-3.5" />
                Drop GPS Pin
              </button>
              <button
                type="button"
                onClick={() => setPoints(defaultBoundary)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset Polygon
              </button>
            </>
          )}

          <button
            type="button"
            onClick={handleSaveBoundary}
            disabled={isSaving || points.length < 3}
            className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-emerald-900/30 transition-colors"
          >
            <Save className="w-3.5 h-3.5" />
            {isSaving ? "Saving..." : "Persist Plot Boundary"}
          </button>
        </div>
      </div>

      {statusMsg && (
        <div className="p-3 bg-slate-950 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            {statusMsg}
          </span>
          <button onClick={() => setStatusMsg(null)} className="text-slate-500 hover:text-white">✕</button>
        </div>
      )}

      {/* Main Map & Interactive Polygon Viewport */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive Canvas & Polygon Renderer */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden relative shadow-inner">
          {/* Map Layers Switcher Header */}
          <div className="p-3 bg-slate-900/90 border-b border-slate-800 flex justify-between items-center text-xs">
            <div className="flex items-center gap-2 text-slate-300 font-medium">
              <Satellite className="w-4 h-4 text-emerald-400" />
              <span>Interactive Plot Polygon Viewport (Zambia Sentinel-2 Tile)</span>
            </div>
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
              <button
                onClick={() => setMapStyle("satellite")}
                className={`px-2 py-1 rounded text-[11px] font-semibold ${
                  mapStyle === "satellite" ? "bg-emerald-600 text-white" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Satellite RGB
              </button>
              <button
                onClick={() => setMapStyle("hybrid")}
                className={`px-2 py-1 rounded text-[11px] font-semibold ${
                  mapStyle === "hybrid" ? "bg-emerald-600 text-white" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Hybrid Vector
              </button>
              <button
                onClick={() => setMapStyle("ndvi")}
                className={`px-2 py-1 rounded text-[11px] font-semibold ${
                  mapStyle === "ndvi" ? "bg-emerald-600 text-white" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                NDVI Heatmap
              </button>
            </div>
          </div>

          {/* SVG Map Canvas */}
          <div className="relative h-[340px] w-full bg-slate-950 flex items-center justify-center select-none cursor-crosshair">
            {/* Background Map Simulated Texture */}
            <div 
              className={`absolute inset-0 opacity-40 transition-all ${
                mapStyle === "ndvi" 
                  ? "bg-gradient-to-tr from-emerald-950 via-lime-900 to-amber-950" 
                  : mapStyle === "satellite" 
                  ? "bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] bg-slate-900"
                  : "bg-slate-900"
              }`}
            />

            {/* Grid overlay */}
            <svg 
              className="absolute inset-0 w-full h-full pointer-events-none opacity-20"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#0ea5e9" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>

            {/* Interactive SVG Overlay */}
            <svg
              className="relative w-full h-full"
              viewBox="0 0 600 400"
              onClick={handleCanvasClick}
            >
              {/* Fill Polygon */}
              {points.length >= 3 && (
                <polygon
                  points={svgPolyPoints}
                  fill={mapStyle === "ndvi" ? "rgba(16, 185, 129, 0.35)" : "rgba(14, 165, 233, 0.25)"}
                  stroke={mapStyle === "ndvi" ? "#10b981" : "#0ea5e9"}
                  strokeWidth="2.5"
                  strokeDasharray={readOnly ? "none" : "4 2"}
                />
              )}

              {/* Polygon Outline line segments if < 3 */}
              {points.length === 2 && (
                <line
                  x1={toSvgX(points[0].lng)}
                  y1={toSvgY(points[0].lat)}
                  x2={toSvgX(points[1].lng)}
                  y2={toSvgY(points[1].lat)}
                  stroke="#38bdf8"
                  strokeWidth="2"
                />
              )}

              {/* Vertex Nodes */}
              {points.map((pt, idx) => {
                const cx = toSvgX(pt.lng);
                const cy = toSvgY(pt.lat);
                const isSelected = activeVertexIndex === idx;

                return (
                  <g key={`vertex-${idx}`} className="group cursor-pointer">
                    <circle
                      cx={cx}
                      cy={cy}
                      r={isSelected ? "8" : "6"}
                      fill={isSelected ? "#f59e0b" : "#10b981"}
                      stroke="#ffffff"
                      strokeWidth="2"
                      className="transition-all hover:scale-125"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveVertexIndex(idx);
                      }}
                    />
                    <text
                      x={cx + 9}
                      y={cy + 4}
                      fill="#e2e8f0"
                      fontSize="10"
                      fontWeight="bold"
                    >
                      P{idx + 1}
                    </text>
                  </g>
                );
              })}

              {/* Plot Center Badge */}
              {points.length >= 3 && (
                <g transform={`translate(${toSvgX(centerLng)}, ${toSvgY(centerLat)})`}>
                  <circle r="14" fill="#0284c7" opacity="0.85" />
                  <text
                    x="0"
                    y="4"
                    fill="#ffffff"
                    fontSize="10"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {areaHectares}ha
                  </text>
                </g>
              )}
            </svg>

            {/* Instruction Banner overlay */}
            {!readOnly && (
              <div className="absolute bottom-3 left-3 bg-slate-900/90 border border-slate-700 rounded-lg px-3 py-1.5 text-[11px] text-slate-300 backdrop-blur-sm pointer-events-none flex items-center gap-2">
                <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
                <span>Click map canvas to add boundary vertex points, or drop GPS pins.</span>
              </div>
            )}
          </div>

          {/* Canvas Footer Metrics */}
          <div className="p-4 bg-slate-900/80 border-t border-slate-800 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Calculated Area</p>
              <p className="text-lg font-bold text-emerald-400 mt-0.5">{areaHectares} Ha</p>
              <p className="text-[10px] text-slate-500">({areaAcres} Acres)</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Vertices Count</p>
              <p className="text-lg font-bold text-slate-200 mt-0.5">{points.length} Points</p>
              <p className="text-[10px] text-slate-500">{points.length >= 3 ? "Valid Polygon" : "Incomplete"}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Plot Center Lat/Lng</p>
              <p className="text-xs font-mono font-medium text-slate-300 mt-1">
                {centerLat.toFixed(4)}, {centerLng.toFixed(4)}
              </p>
              <p className="text-[10px] text-slate-500">WGS84 Datum</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Sentinel-2 Sync</p>
              <span className="inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Live Calibrated
              </span>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Coordinate List & Manual Input */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-4">
          <div className="flex justify-between items-center pb-2 border-b border-slate-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-emerald-400" />
              GeoPoint Vertices ({points.length})
            </h3>
            {points.length > 0 && !readOnly && (
              <button
                onClick={() => setPoints([])}
                className="text-[11px] text-rose-400 hover:text-rose-300 transition-colors font-medium flex items-center gap-1"
              >
                <Trash2 className="w-3 h-3" />
                Clear All
              </button>
            )}
          </div>

          {/* Add Manual Coordinates Form */}
          {!readOnly && (
            <div className="space-y-2 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <p className="text-[11px] font-semibold text-slate-300">Add Vertex Manually (WGS84):</p>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-slate-400">Latitude</label>
                  <input
                    type="number"
                    step="0.00001"
                    placeholder="-14.6510"
                    value={manualLat}
                    onChange={(e) => setManualLat(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400">Longitude</label>
                  <input
                    type="number"
                    step="0.00001"
                    placeholder="28.5010"
                    value={manualLng}
                    onChange={(e) => setManualLng(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
              <button
                type="button"
                onClick={handleAddManualPoint}
                disabled={!manualLat || !manualLng}
                className="w-full mt-1 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-xs font-semibold rounded-lg flex items-center justify-center gap-1 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Append GeoPoint
              </button>
            </div>
          )}

          {/* Points List */}
          <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-1 text-xs font-mono">
            {points.length === 0 ? (
              <p className="text-slate-500 italic text-center py-6 text-[11px]">
                No polygon vertices added yet.
              </p>
            ) : (
              points.map((pt, idx) => (
                <div
                  key={`pt-row-${idx}`}
                  onClick={() => setActiveVertexIndex(idx)}
                  className={`p-2 rounded-lg border flex items-center justify-between transition-colors cursor-pointer ${
                    activeVertexIndex === idx
                      ? "bg-amber-950/40 border-amber-500/40 text-amber-200"
                      : "bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[10px] flex items-center justify-center">
                      P{idx + 1}
                    </span>
                    <div>
                      <p className="text-[11px] font-semibold text-slate-200">
                        Lat: {pt.lat.toFixed(5)}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        Lng: {pt.lng.toFixed(5)}
                      </p>
                    </div>
                  </div>

                  {!readOnly && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteVertex(idx);
                      }}
                      className="text-slate-500 hover:text-rose-400 p-1 rounded"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * AGC Financier Portal Component
 * Manages Credit Facilities, Portfolio Analytics, Risk Share, and Reconciliation Runs
 */

import React, { useState, useEffect } from "react";
import {
  Building2,
  TrendingUp,
  PieChart,
  Shield,
  Layers,
  Plus,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  Check
} from "lucide-react";
import { CreditFacility, LoanAccount, GuaranteeFundLedger, AgroDealerTenant } from "../../types";
import {
  getCreditFacilities,
  createCreditFacility,
  getLoans,
  getGuaranteeFundLedger
} from "../../services/agcService";
import { INITIAL_AGRO_DEALERS } from "../../data/agroDealerData";

interface FinancierPortalProps {
  financierInstitutionId?: string;
  currencySymbol?: string;
}

export const FinancierPortal: React.FC<FinancierPortalProps> = ({
  financierInstitutionId = "inst_mabala_agri",
  currencySymbol = "ZMW"
}) => {
  const [facilities, setFacilities] = useState<CreditFacility[]>([]);
  const [portfolioLoans, setPortfolioLoans] = useState<LoanAccount[]>([]);
  const [guaranteeLedger, setGuaranteeLedger] = useState<GuaranteeFundLedger>({ balance: 0, committedBy: null, committedAt: null });

  // Registered Active Agro Dealers
  const [activeDealers, setActiveDealers] = useState<AgroDealerTenant[]>([]);
  const [selectedDealerId, setSelectedDealerId] = useState<string>("");

  // Modal State
  const [showAddFacModal, setShowAddFacModal] = useState(false);
  const [dealerName, setDealerName] = useState("");
  const [dealerTenantId, setDealerTenantId] = useState("");
  const [allocatedLimit, setAllocatedLimit] = useState(250000);
  const [weatherRiskPct, setWeatherRiskPct] = useState(40);
  const [dealerRetainedPct, setDealerRetainedPct] = useState(60);

  useEffect(() => {
    loadData();
    loadActiveDealers();
  }, [financierInstitutionId]);

  const loadActiveDealers = () => {
    try {
      const saved = localStorage.getItem("mabala_agd_dealers");
      let list: AgroDealerTenant[] = saved ? JSON.parse(saved) : INITIAL_AGRO_DEALERS;
      if (!list || list.length === 0) {
        list = INITIAL_AGRO_DEALERS;
      }
      // Filter for active or non-expired dealers
      const activeOnly = list.filter(d => d.subscriptionStatus === "active" || d.subscriptionStatus === "grace_period" || !d.subscriptionStatus);
      setActiveDealers(activeOnly);

      if (activeOnly.length > 0) {
        setSelectedDealerId(activeOnly[0].id);
        setDealerName(activeOnly[0].businessName);
        setDealerTenantId(activeOnly[0].id);
      }
    } catch (e) {
      setActiveDealers(INITIAL_AGRO_DEALERS);
      if (INITIAL_AGRO_DEALERS.length > 0) {
        setSelectedDealerId(INITIAL_AGRO_DEALERS[0].id);
        setDealerName(INITIAL_AGRO_DEALERS[0].businessName);
        setDealerTenantId(INITIAL_AGRO_DEALERS[0].id);
      }
    }
  };

  const loadData = () => {
    const facs = getCreditFacilities();
    setFacilities(facs);

    const loans = getLoans();
    setPortfolioLoans(loans);

    const gLedger = getGuaranteeFundLedger();
    setGuaranteeLedger(gLedger);
  };

  const handleSelectDealer = (id: string) => {
    setSelectedDealerId(id);
    if (id === "custom") {
      setDealerName("");
      setDealerTenantId("");
    } else {
      const found = activeDealers.find(d => d.id === id);
      if (found) {
        setDealerName(found.businessName);
        setDealerTenantId(found.id);
      }
    }
  };

  const handleOpenAddModal = () => {
    loadActiveDealers();
    setShowAddFacModal(true);
  };

  const handleCreateFacility = (e: React.FormEvent) => {
    e.preventDefault();
    createCreditFacility({
      financierInstitutionId,
      financierName: "Mabala AgriCredit Ltd",
      dealerTenantId: dealerTenantId || "dealer_custom",
      dealerName: dealerName || "Custom Agro-Dealer",
      allocatedLimit,
      utilized: 0,
      riskShareDefaults: {
        weatherPct: weatherRiskPct,
        guaranteePct: guaranteeLedger.balance > 0 ? 20 : 0,
        dealerRetainedPct
      },
      status: "active"
    });

    setShowAddFacModal(false);
    loadData();
  };

  const totalAllocated = facilities.reduce((sum, f) => sum + f.allocatedLimit, 0);
  const totalUtilized = facilities.reduce((sum, f) => sum + f.utilized, 0);
  const activeLoansCount = portfolioLoans.filter(l => l.status === "active").length;
  const repaidLoansCount = portfolioLoans.filter(l => l.status === "repaid").length;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30">
              Financier Institution Portal
            </span>
            <span className="text-xs text-slate-400">AGC Credit Lines & Portfolio Engine</span>
          </div>
          <h1 className="text-2xl font-bold mt-1 text-slate-100 flex items-center gap-2">
            Mabala AgriCredit Portfolio
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage wholesale credit facility limits to participating Agro-Dealer hubs with risk-sharing structures.
          </p>
        </div>

        <button
          onClick={handleOpenAddModal}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-semibold text-white shadow-lg shadow-emerald-950/50 transition-colors flex items-center gap-1.5 cursor-pointer"
          id="allocate-dealer-facility-btn"
        >
          <Plus className="w-4 h-4" /> Allocate Dealer Facility
        </button>
      </div>

      {/* Overview Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl shadow-lg">
          <div className="text-xs font-semibold text-slate-400">Total Allocated Limit</div>
          <div className="text-2xl font-black text-slate-100 font-mono mt-1">
            {currencySymbol} {totalAllocated.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Wholesale capital deployed</div>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl shadow-lg">
          <div className="text-xs font-semibold text-slate-400">Total Utilized by Farmers</div>
          <div className="text-2xl font-black text-emerald-400 font-mono mt-1">
            {currencySymbol} {totalUtilized.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-400/80 mt-1">
            {totalAllocated > 0 ? ((totalUtilized / totalAllocated) * 100).toFixed(1) : 0}% utilization
          </div>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl shadow-lg">
          <div className="text-xs font-semibold text-slate-400">Portfolio Active Loans</div>
          <div className="text-2xl font-black text-amber-400 font-mono mt-1">{activeLoansCount}</div>
          <div className="text-[11px] text-slate-400 mt-1">{repaidLoansCount} loans fully repaid</div>
        </div>

        {/* DFI / Donor Blended Guarantee Status Card */}
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl shadow-lg">
          <div className="text-xs font-semibold text-slate-400">Blended Guarantee Facility</div>
          {guaranteeLedger.balance > 0 ? (
            <div>
              <div className="text-2xl font-black text-emerald-400 font-mono mt-1">
                {currencySymbol} {guaranteeLedger.balance.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-300 mt-1">
                Committed by: <strong className="text-emerald-300">{guaranteeLedger.committedBy}</strong>
              </div>
            </div>
          ) : (
            <div>
              <div className="text-sm font-bold text-amber-400 mt-2 flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-amber-400" /> Dormant (No Donor Fund)
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                Awaits DFI commitment in Platform Admin
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Allocated Credit Facilities Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-4">
        <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <Building2 className="w-5 h-5 text-emerald-400" />
          Allocated Agro-Dealer Credit Facilities
        </h3>

        <div className="space-y-3">
          {facilities.map((fac) => {
            const pct = fac.allocatedLimit > 0 ? (fac.utilized / fac.allocatedLimit) * 100 : 0;
            return (
              <div key={fac.facilityId} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-sm text-slate-200">{fac.dealerName}</h4>
                    <span className="text-xs text-slate-400 font-mono">Tenant ID: {fac.dealerTenantId}</span>
                  </div>

                  <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold rounded-lg uppercase">
                    {fac.status}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  <div className="p-2.5 bg-slate-900/80 rounded-lg">
                    <span className="text-slate-400">Allocated Wholesale Limit:</span>
                    <div className="font-bold text-slate-200 font-mono mt-0.5">{currencySymbol} {fac.allocatedLimit.toLocaleString()}</div>
                  </div>
                  <div className="p-2.5 bg-slate-900/80 rounded-lg">
                    <span className="text-slate-400">Farmer Disbursed Amount:</span>
                    <div className="font-bold text-emerald-400 font-mono mt-0.5">{currencySymbol} {fac.utilized.toLocaleString()}</div>
                  </div>
                  <div className="p-2.5 bg-slate-900/80 rounded-lg">
                    <span className="text-slate-400">Risk Share Defaults:</span>
                    <div className="font-semibold text-slate-300 mt-0.5">
                      Weather: {fac.riskShareDefaults.weatherPct}% | Dealer Retained: {fac.riskShareDefaults.dealerRetainedPct}%
                    </div>
                  </div>
                </div>

                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-400 h-full rounded-full" style={{ width: `${Math.min(100, pct)}%` }}></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* MODAL: Allocate Facility */}
      {showAddFacModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-slate-100 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-emerald-400" />
              Allocate Dealer Credit Line
            </h3>

            <form onSubmit={handleCreateFacility} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-semibold flex items-center justify-between">
                  <span>Select Active Agro-Dealer</span>
                  <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    {activeDealers.length} Registered Active
                  </span>
                </label>
                <select
                  value={selectedDealerId}
                  onChange={(e) => handleSelectDealer(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500 font-medium cursor-pointer"
                  id="allocate-dealer-select-dropdown"
                >
                  <option value="" disabled>-- Pick Registered Agro Dealer --</option>
                  {activeDealers.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.businessName} ({d.district || d.province || 'Active Hub'}) — ID: {d.id}
                    </option>
                  ))}
                  <option value="custom">➕ Enter Custom Agro-Dealer...</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Agro-Dealer Name</label>
                  <input
                    type="text"
                    required
                    value={dealerName}
                    onChange={(e) => setDealerName(e.target.value)}
                    placeholder="e.g. Choma Agro-Inputs & Seed Centre"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Agro-Dealer Tenant ID</label>
                  <input
                    type="text"
                    required
                    value={dealerTenantId}
                    onChange={(e) => setDealerTenantId(e.target.value)}
                    placeholder="e.g. dealer-choma-01"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Wholesale Credit Limit ({currencySymbol})</label>
                <input
                  type="number"
                  step="50000"
                  required
                  value={allocatedLimit}
                  onChange={(e) => setAllocatedLimit(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 text-sm font-bold font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Weather Risk Share %</label>
                  <input
                    type="number"
                    max="100"
                    value={weatherRiskPct}
                    onChange={(e) => setWeatherRiskPct(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Dealer Retained Risk %</label>
                  <input
                    type="number"
                    max="100"
                    value={dealerRetainedPct}
                    onChange={(e) => setDealerRetainedPct(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddFacModal(false)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-white shadow-lg shadow-emerald-950/50"
                >
                  Create Facility
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

/**
 * AGC Agro-Dealer POS Component
 * In-Kind Input Credit Checkout Counter with Hard Single-Loan Block Enforcer
 * Enforces:
 * 1. Active farmers only (from Mabala platform users, registered customers, & AGC profiles - NO dummy/test data) with search by name
 * 2. Agro-Dealer stockroom inventory SKUs only (qtyOnHand > 0)
 */

import React, { useState, useEffect, useMemo } from "react";
import { maskNRC, maskMobile, maskUserId } from "../../utils/privacyMasking";
import { dispatchSafeEvent } from "../../utils/safeEvent";
import {
  ShoppingCart,
  ShieldAlert,
  CheckCircle2,
  AlertOctagon,
  Building2,
  CreditCard,
  Plus,
  Trash2,
  Lock,
  ArrowRight,
  ShieldCheck,
  Check,
  Search,
  UserCheck,
  UserPlus,
  Package,
  Layers,
  Sparkles,
  X,
  RefreshCw
} from "lucide-react";
import {
  FarmerCreditProfileSummary,
  BasketItem,
  CreditFacility,
  InsurerPremiumRate,
  CreditApplication,
  LoanAccount,
  AgroDealerSKU,
  StockMovement
} from "../../types";
import {
  getFarmerCreditProfile,
  canApplyForLoan,
  getCreditFacilities,
  getInsurerPremiumRates,
  agcSubmitApplication,
  agcDisburseLoan,
  updateFarmerConsent
} from "../../services/agcService";
import { INITIAL_SUPPLIER_INSTITUTIONS } from "../AgroDealerConsignmentPanel";
import { db } from "../../firebase";
import { collection, onSnapshot } from "firebase/firestore";
import { INITIAL_AGRO_SKUS } from "../../data/agroDealerData";

export interface PlatformFarmer {
  id: string; // tenant ID or UID
  name: string;
  farmName?: string;
  ownerName?: string;
  phone: string;
  nrc: string;
  location?: string;
  creditScore: number;
  creditBand: string;
  consentStatus?: string;
  source?: string;
}

interface DealerCreditPOSProps {
  dealerTenantId?: string;
  currencySymbol?: string;
}

export const DealerCreditPOS: React.FC<DealerCreditPOSProps> = ({
  dealerTenantId = "dealer-choma-01",
  currencySymbol = "ZMW"
}) => {
  // Farmer state & search
  const [activeFarmers, setActiveFarmers] = useState<PlatformFarmer[]>([]);
  const [farmerSearchTerm, setFarmerSearchTerm] = useState<string>("");
  const [selectedFarmerId, setSelectedFarmerId] = useState<string>("");
  const [isLoadingFarmers, setIsLoadingFarmers] = useState<boolean>(true);
  const [showFarmerRegisterModal, setShowFarmerRegisterModal] = useState<boolean>(false);

  // Quick Register Active Farmer Form State
  const [newFarmerName, setNewFarmerName] = useState<string>("");
  const [newFarmerPhone, setNewFarmerPhone] = useState<string>("");
  const [newFarmerNrc, setNewFarmerNrc] = useState<string>("");
  const [newFarmerLocation, setNewFarmerLocation] = useState<string>("");

  // Credit & Loan evaluation state
  const [profile, setProfile] = useState<FarmerCreditProfileSummary | null>(null);
  const [singleLoanCheck, setSingleLoanCheck] = useState<{ allowed: boolean; reason?: string; activeLoanId?: string }>({ allowed: true });

  // Agro-Dealer Inventory SKUs
  const [inventorySkus, setInventorySkus] = useState<AgroDealerSKU[]>([]);

  // Basket & checkout state
  const [basket, setBasket] = useState<BasketItem[]>([]);
  const [facilities, setFacilities] = useState<CreditFacility[]>([]);
  const [selectedFacilityId, setSelectedFacilityId] = useState<string>("");
  const [insurerRates, setInsurerRates] = useState<InsurerPremiumRate[]>([]);
  const [selectedRateId, setSelectedRateId] = useState<string>("");
  const [selectedCrop, setSelectedCrop] = useState<string>("Maize");
  const [appliedHectarage, setAppliedHectarage] = useState<number>(2.5);
  const [selectedWarehouseReceiptId, setSelectedWarehouseReceiptId] = useState<string>("");

  // Crop Cycle & Mapped Plot Reusability State
  const [farmerCropOptions, setFarmerCropOptions] = useState<Array<{
    id: string;
    label: string;
    cropType: string;
    cropName?: string;
    variety?: string;
    fieldBlock: string;
    areaHectares: number;
    isFromCropCycle: boolean;
  }>>([]);
  const [selectedCropOptionId, setSelectedCropOptionId] = useState<string>("");
  const [autoFetchedPlotBadge, setAutoFetchedPlotBadge] = useState<string>("");

  const [submittedApp, setSubmittedApp] = useState<CreditApplication | null>(null);
  const [disbursedLoan, setDisbursedLoan] = useState<LoanAccount | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDisbursing, setIsDisbursing] = useState(false);
  const [posError, setPosError] = useState<string | null>(null);

  // 1. Load Agro Dealer Inventory SKUs (Active stockroom items only, excluding test/dummy data)
  const loadDealerInventory = () => {
    try {
      const savedSkus = localStorage.getItem("mabala_agd_skus");
      const allSkus: AgroDealerSKU[] = savedSkus ? JSON.parse(savedSkus) : INITIAL_AGRO_SKUS;

      const isDummySku = (s: AgroDealerSKU) => {
        const text = `${s.id} ${s.productName} ${s.category || ''} ${s.batchNumber || ''} ${s.supplierName || ''} ${s.tenantId || ''}`.toLowerCase();
        return (
          text.includes("test") ||
          text.includes("demo") ||
          text.includes("dummy") ||
          text.includes("sample") ||
          text.includes("fake") ||
          text.includes("temp")
        );
      };

      // Filter SKUs that belong to this dealer AND have positive quantity in stockroom AND are valid real products
      const dealerSkus = allSkus.filter(s => {
        const isDealerMatch =
          !dealerTenantId ||
          s.tenantId === dealerTenantId ||
          (dealerTenantId === "dealer_default" && (!s.tenantId || s.tenantId === "dealer-choma-01" || s.tenantId === "dealer_default"));
        const isAvailableInStock = Number(s.qtyOnHand) > 0;
        const notDummy = !isDummySku(s);
        return isDealerMatch && isAvailableInStock && notDummy;
      });

      setInventorySkus(dealerSkus);
    } catch (err) {
      console.error("[DealerCreditPOS] Failed to load inventory SKUs:", err);
      setInventorySkus([]);
    }
  };

  // 2. Load Active Farmers on Mabala Platform (Exclude dummy/test data)
  const loadActiveFarmers = () => {
    setIsLoadingFarmers(true);
    const farmerMap = new Map<string, PlatformFarmer>();

    const isDummy = (str?: string) => {
      if (!str) return false;
      const lower = str.toLowerCase();
      return (
        lower.includes("demo_tenant") ||
        lower.includes("demo") ||
        lower.includes("dummy") ||
        lower.includes("test") ||
        lower.includes("hakainde banda") ||
        lower.includes("mutinta hachitembo")
      );
    };

    const populateLocalSources = (map: Map<string, PlatformFarmer>) => {
      // Source B: Local Customers directory (mabala_customers)
      const rawCustomers = localStorage.getItem("mabala_customers");
      if (rawCustomers) {
        try {
          const customers: any[] = JSON.parse(rawCustomers);
          customers.forEach(c => {
            const id = c.id || c.farmerId || `cust-${Date.now()}`;
            if (!isDummy(id) && !isDummy(c.name) && !isDummy(c.farmerName)) {
              const name = c.name || c.farmerName || "Active Smallholder Farmer";
              const phone = c.phone || c.phoneNumber || "+260971112233";
              const nrc = c.nrc || c.nrcNumber || "NRC On File";
              const farmName = c.farmName || c.businessName || `${name} Farm`;
              const ownerName = c.ownerName || c.contactPerson || name;
              const prof = getFarmerCreditProfile(id);

              if (!map.has(id)) {
                map.set(id, {
                  id,
                  name,
                  farmName,
                  ownerName,
                  phone,
                  nrc,
                  location: c.location || c.city || "Local District",
                  creditScore: prof.mabalaCreditScore.value,
                  creditBand: prof.mabalaCreditScore.band,
                  consentStatus: prof.consentStatus,
                  source: "Agro Customer Directory"
                });
              }
            }
          });
        } catch (e) {
          console.warn("Failed parsing mabala_customers", e);
        }
      }

      // Source C: Active User Profile (if current active user is a farmer)
      const rawUserProf = localStorage.getItem("mabala_user_profile");
      if (rawUserProf) {
        try {
          const u = JSON.parse(rawUserProf);
          if (u.id && !isDummy(u.id) && !isDummy(u.name)) {
            const prof = getFarmerCreditProfile(u.id);
            if (!map.has(u.id)) {
              const name = u.name || "Logged Farmer";
              map.set(u.id, {
                id: u.id,
                name,
                farmName: u.farmName || u.businessName || `${name} Farm`,
                ownerName: u.ownerName || name,
                phone: u.phone || "",
                nrc: u.nrc || "Verified",
                location: u.location || "Local Farm",
                creditScore: prof.mabalaCreditScore.value,
                creditBand: prof.mabalaCreditScore.band,
                consentStatus: prof.consentStatus,
                source: "Active Session User"
              });
            }
          }
        } catch (e) {
          console.warn("Failed parsing mabala_user_profile", e);
        }
      }

      // Source D: AGC Stored Profiles
      const rawAgcProfiles = localStorage.getItem("mabala_agc_profiles");
      if (rawAgcProfiles) {
        try {
          const agcProfiles: Record<string, FarmerCreditProfileSummary> = JSON.parse(rawAgcProfiles);
          Object.keys(agcProfiles).forEach(id => {
            if (!isDummy(id)) {
              const prof = agcProfiles[id];
              if (prof.identity && prof.identity.name && !isDummy(prof.identity.name)) {
                if (!map.has(id)) {
                  const fname = prof.identity.name;
                  map.set(id, {
                    id,
                    name: fname,
                    farmName: (prof.identity as any)?.farmName || `${fname} Farm`,
                    ownerName: (prof.identity as any)?.ownerName || fname,
                    phone: prof.identity.phone || "",
                    nrc: prof.identity.nrc || "On File",
                    location: "Registered Farm Plot",
                    creditScore: prof.mabalaCreditScore.value,
                    creditBand: prof.mabalaCreditScore.band,
                    consentStatus: prof.consentStatus,
                    source: "Mabala AGC Profile"
                  });
                }
              }
            }
          });
        } catch (e) {
          console.warn("Failed parsing mabala_agc_profiles", e);
        }
      }
    };

    if (db) {
      const usersCol = collection(db, "users_data");
      return onSnapshot(usersCol, { includeMetadataChanges: true }, (usersSnap) => {
        const currentMap = new Map<string, PlatformFarmer>();
        usersSnap.forEach(docSnap => {
          const data = docSnap.data();
          const uid = docSnap.id;
          const isFarmerRole =
            data.role === "Farmer" ||
            data.role === "farmer" ||
            data.role === "Farm Owner" ||
            data.role === "Farm Worker" ||
            data.workspaceMode === "Farmer" ||
            data.tenantType === "farmer";

          if (isFarmerRole && !isDummy(uid) && !isDummy(data.email) && !isDummy(data.displayName)) {
            const name = data.displayName || data.name || (data.email ? data.email.split("@")[0] : `Farmer ${uid.substring(0, 5)}`);
            const phone = data.phone || data.phoneNumber || "";
            const nrc = data.nrc || "Unregistered";
            const farmName = data.farmName || data.businessName || `${name} Commercial Farm`;
            const ownerName = data.ownerName || data.displayName || name;
            const prof = getFarmerCreditProfile(uid);

            currentMap.set(uid, {
              id: uid,
              name,
              farmName,
              ownerName,
              phone,
              nrc,
              location: data.province || data.district || "Zambia",
              creditScore: prof.mabalaCreditScore.value,
              creditBand: prof.mabalaCreditScore.band,
              consentStatus: prof.consentStatus,
              source: "Mabala Registered Account"
            });
          }
        });

        populateLocalSources(currentMap);
        setActiveFarmers(Array.from(currentMap.values()));
        setIsLoadingFarmers(false);
      }, (err) => {
        console.warn("[DealerCreditPOS] Firestore users_data snapshot notice:", err);
        populateLocalSources(farmerMap);
        setActiveFarmers(Array.from(farmerMap.values()));
        setIsLoadingFarmers(false);
      });
    } else {
      populateLocalSources(farmerMap);
      setActiveFarmers(Array.from(farmerMap.values()));
      setIsLoadingFarmers(false);
      return () => {};
    }
  };

  const loadSupplierFacilities = () => {
    try {
      const rawFacs = getCreditFacilities();
      const activeFacs = (rawFacs || []).filter(f => f && f.status === "active");
      setFacilities(activeFacs);
      if (activeFacs.length > 0) {
        setSelectedFacilityId(activeFacs[0].facilityId);
      } else {
        setSelectedFacilityId("");
      }
    } catch (err) {
      console.error("[DealerCreditPOS] Error setting supplier facilities:", err);
      setFacilities([]);
      setSelectedFacilityId("");
    }
  };

  useEffect(() => {
    loadDealerInventory();
    const unsubFarmers = loadActiveFarmers();
    loadSupplierFacilities();

    const rates = getInsurerPremiumRates();
    try {
      const licensedStr = localStorage.getItem("mabala_agc_licensed_institutions");
      if (licensedStr) {
        const licensed = JSON.parse(licensedStr);
        if (Array.isArray(licensed)) {
          licensed.forEach((inst: any) => {
            if (inst.capability === "institution_insurer" && inst.status === "active") {
              const exists = rates.some(r => r.insurerId === inst.id || r.insurerInstitutionId === inst.id || r.insurerName === inst.name);
              if (!exists) {
                rates.push({
                  rateId: `rate_${inst.id}`,
                  insurerInstitutionId: inst.id,
                  insurerId: inst.id,
                  insurerName: inst.name || inst.businessName || "Onboarded Insurer",
                  cropOrCategory: inst.category || "Crop & Weather Index",
                  region: "Zambia National",
                  loanSizeBand: "All Bands",
                  ratePct: inst.premiumRatePct || 4.5,
                  deductiblePct: inst.deductiblePct || 10,
                  coverageDescription: inst.coverageDescription || "Multi-Peril Crop & Drought Index Insurance",
                  effectiveFrom: new Date().toISOString().split('T')[0],
                  setBy: "Super Admin"
                });
              }
            }
          });
        }
      }
    } catch (e) {
      console.warn("Error loading onboarded insurers:", e);
    }

    setInsurerRates(rates);

    // Listen to storage events to refresh inventory if modified elsewhere
    const handleStorageChange = () => {
      loadDealerInventory();
      loadSupplierFacilities();
    };
    window.addEventListener("storage", handleStorageChange);
    return () => {
      window.removeEventListener("storage", handleStorageChange);
      if (unsubFarmers) unsubFarmers();
    };
  }, []);

  // Update profile evaluation whenever selected farmer changes
  useEffect(() => {
    if (!selectedFarmerId) {
      setProfile(null);
      setSingleLoanCheck({ allowed: false, reason: "Select an active farmer to proceed." });
      return;
    }
    loadSelectedFarmerData(selectedFarmerId);
  }, [selectedFarmerId]);

  const loadSelectedFarmerData = (farmerId: string) => {
    // Ensure consent is granted for POS evaluation
    updateFarmerConsent(farmerId, "granted");
    const prof = getFarmerCreditProfile(farmerId);
    setProfile(prof);

    const check = canApplyForLoan(farmerId);
    setSingleLoanCheck(check);

    // Fetch crop cycles for this farmer
    const cropsList: Array<{
      id: string;
      label: string;
      cropType: string;
      cropName?: string;
      variety?: string;
      fieldBlock: string;
      areaHectares: number;
      isFromCropCycle: boolean;
    }> = [];

    // 1. Try farmer-specific crop cycles in localStorage
    try {
      const tenantCropsRaw = localStorage.getItem(`mabala_${farmerId}_crops`);
      if (tenantCropsRaw) {
        const parsed = JSON.parse(tenantCropsRaw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          parsed.forEach((c: any) => {
            const rawType = c.cropType || c.cropName || "Maize";
            const area = Number(c.areaHectares) || Number(c.hectares) || 1.0;
            const block = c.fieldBlock || c.blockName || c.plotName || "Mapped Plot";
            const stdType = rawType.toLowerCase().includes("soya") ? "Soya" :
              rawType.toLowerCase().includes("wheat") ? "Wheat" :
              rawType.toLowerCase().includes("cotton") ? "Cotton" :
              rawType.toLowerCase().includes("maize") ? "Maize" : rawType;

            cropsList.push({
              id: c.id || `crop_${Math.random()}`,
              label: `🌱 ${c.cropName || rawType}${c.variety ? ` (${c.variety})` : ''} — ${block} (${area} Ha)`,
              cropType: stdType,
              cropName: c.cropName || rawType,
              variety: c.variety,
              fieldBlock: block,
              areaHectares: area,
              isFromCropCycle: true
            });
          });
        }
      }
    } catch {}

    // 2. Try global crops collection in localStorage
    if (cropsList.length === 0) {
      try {
        const allCropsRaw = localStorage.getItem("mabala_crops");
        if (allCropsRaw) {
          const parsed = JSON.parse(allCropsRaw);
          if (Array.isArray(parsed)) {
            const matches = parsed.filter((c: any) => c.tenantId === farmerId || c.farmId === farmerId || c.farmerId === farmerId);
            matches.forEach((c: any) => {
              const rawType = c.cropType || c.cropName || "Maize";
              const area = Number(c.areaHectares) || Number(c.hectares) || 1.0;
              const block = c.fieldBlock || c.blockName || c.plotName || "Mapped Plot";
              const stdType = rawType.toLowerCase().includes("soya") ? "Soya" :
                rawType.toLowerCase().includes("wheat") ? "Wheat" :
                rawType.toLowerCase().includes("cotton") ? "Cotton" :
                rawType.toLowerCase().includes("maize") ? "Maize" : rawType;

              cropsList.push({
                id: c.id || `crop_${Math.random()}`,
                label: `🌱 ${c.cropName || rawType}${c.variety ? ` (${c.variety})` : ''} — ${block} (${area} Ha)`,
                cropType: stdType,
                cropName: c.cropName || rawType,
                variety: c.variety,
                fieldBlock: block,
                areaHectares: area,
                isFromCropCycle: true
              });
            });
          }
        }
      } catch {}
    }

    // 3. Resolve farmer's mapped plot size from credit profile
    const mappedPlotSize = prof?.farmPlots && prof.farmPlots.length > 0
      ? (prof.farmPlots[0].sizeHa || 2.5)
      : 2.5;
    const mappedPlotName = prof?.farmPlots && prof.farmPlots.length > 0
      ? (prof.farmPlots[0].plotName || "Mapped Plot 1")
      : "Main Plot";

    // 4. If no custom crop cycles found, populate standard platform crops with the farmer's mapped plot size
    if (cropsList.length === 0) {
      const standardCrops = [
        { name: "White Maize (Food/Grain)", type: "Maize", variety: "SC 719 / SC 647" },
        { name: "Soyabeans (Legume/Oilseed)", type: "Soya", variety: "Safari / Dina" },
        { name: "Irrigated Winter Wheat", type: "Wheat", variety: "Nduna / Trophy" },
        { name: "Seed Cotton (Cash Crop)", type: "Cotton", variety: "Albar 637" }
      ];

      standardCrops.forEach((sc, idx) => {
        cropsList.push({
          id: `std_${sc.type}_${idx}`,
          label: `${sc.name} — ${mappedPlotName} (${mappedPlotSize} Ha)`,
          cropType: sc.type,
          cropName: sc.name,
          variety: sc.variety,
          fieldBlock: mappedPlotName,
          areaHectares: mappedPlotSize,
          isFromCropCycle: false
        });
      });
    }

    setFarmerCropOptions(cropsList);

    // Default select first crop and auto-fetch mapped plot size
    if (cropsList.length > 0) {
      const initial = cropsList[0];
      setSelectedCropOptionId(initial.id);
      setSelectedCrop(initial.cropType);
      setAppliedHectarage(initial.areaHectares);
      setAutoFetchedPlotBadge(
        initial.isFromCropCycle
          ? `✓ Auto-fetched ${initial.areaHectares} Ha from active Crop Cycle (${initial.fieldBlock})`
          : `✓ Auto-fetched ${initial.areaHectares} Ha from mapped plot records (${initial.fieldBlock})`
      );
    }

    setSubmittedApp(null);
    setDisbursedLoan(null);
    setPosError(null);
  };

  const handleCropOptionChange = (optionId: string) => {
    setSelectedCropOptionId(optionId);
    const selectedOpt = farmerCropOptions.find(o => o.id === optionId);
    if (selectedOpt) {
      setSelectedCrop(selectedOpt.cropType);
      setAppliedHectarage(selectedOpt.areaHectares);
      setAutoFetchedPlotBadge(
        selectedOpt.isFromCropCycle
          ? `✓ Auto-fetched ${selectedOpt.areaHectares} Ha from Crop Cycle (${selectedOpt.fieldBlock})`
          : `✓ Auto-fetched ${selectedOpt.areaHectares} Ha from mapped plot records (${selectedOpt.fieldBlock})`
      );
    } else {
      setSelectedCrop(optionId);
    }
  };

  // Search filter for farmers - ONLY display farmers when searched by name, phone or NRC
  const filteredFarmers = useMemo(() => {
    if (!farmerSearchTerm.trim()) return [];
    const term = farmerSearchTerm.trim().toLowerCase();
    return activeFarmers.filter(f =>
      f.name.toLowerCase().includes(term) ||
      (f.phone && f.phone.toLowerCase().includes(term)) ||
      (f.nrc && f.nrc.toLowerCase().includes(term)) ||
      (f.farmName && f.farmName.toLowerCase().includes(term)) ||
      (f.ownerName && f.ownerName.toLowerCase().includes(term))
    );
  }, [activeFarmers, farmerSearchTerm]);

  const selectedFarmer = useMemo(() => {
    return activeFarmers.find(f => f.id === selectedFarmerId) || null;
  }, [activeFarmers, selectedFarmerId]);

  // Handle Quick Register Farmer
  const handleRegisterNewFarmer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFarmerName.trim() || !newFarmerPhone.trim()) {
      alert("Please provide the farmer's full name and phone number.");
      return;
    }

    const newId = `farmer_mb_${Date.now()}`;
    const newFarmer: PlatformFarmer = {
      id: newId,
      name: newFarmerName.trim(),
      phone: newFarmerPhone.trim(),
      nrc: newFarmerNrc.trim() || `${Math.floor(100000 + Math.random() * 900000)}/11/1`,
      location: newFarmerLocation.trim() || "Local District",
      creditScore: 680,
      creditBand: "B",
      consentStatus: "granted",
      source: "POS Direct Onboarding"
    };

    // Save to localStorage customers
    try {
      const raw = localStorage.getItem("mabala_customers");
      const customers = raw ? JSON.parse(raw) : [];
      customers.push({
        id: newId,
        name: newFarmer.name,
        phone: newFarmer.phone,
        nrc: newFarmer.nrc,
        city: newFarmer.location,
        type: "farmer",
        createdAt: new Date().toISOString()
      });
      localStorage.setItem("mabala_customers", JSON.stringify(customers));
    } catch (err) {
      console.error("Error saving customer:", err);
    }

    // Grant consent and create AGC profile
    updateFarmerConsent(newId, "granted");

    setActiveFarmers(prev => [newFarmer, ...prev]);
    setSelectedFarmerId(newId);
    setShowFarmerRegisterModal(false);

    // Reset form
    setNewFarmerName("");
    setNewFarmerPhone("");
    setNewFarmerNrc("");
    setNewFarmerLocation("");
  };

  // Add inventory SKU to basket
  const handleAddItemToBasket = (sku: AgroDealerSKU) => {
    if (!singleLoanCheck.allowed) {
      setPosError(singleLoanCheck.reason || "Cannot add items. Farmer loan check blocked.");
      return;
    }

    setBasket(prev => {
      const existing = prev.find(item => item.skuId === sku.id);
      const currentQty = existing ? existing.quantity : 0;

      if (currentQty + 1 > sku.qtyOnHand) {
        setPosError(`Stock limit reached! Only ${sku.qtyOnHand} ${sku.unit} available in stockroom.`);
        return prev;
      }

      setPosError(null);
      if (existing) {
        return prev.map(item =>
          item.skuId === sku.id
            ? { ...item, quantity: item.quantity + 1, total: (item.quantity + 1) * item.unitPrice }
            : item
        );
      }
      return [
        ...prev,
        {
          skuId: sku.id,
          name: sku.productName,
          quantity: 1,
          unitPrice: sku.sellingPrice,
          total: sku.sellingPrice
        }
      ];
    });
  };

  const handleRemoveItem = (skuId: string) => {
    setBasket(prev => prev.filter(i => i.skuId !== skuId));
  };

  const totalBasketAmount = basket.reduce((acc, i) => acc + i.total, 0);

  // Submit Credit Application
  const handleCheckCreditScore = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFarmerId || !selectedFarmer) {
      setPosError("Please select an active farmer to issue credit to.");
      return;
    }
    setPosError(null);

    // Hard single loan check
    if (!singleLoanCheck.allowed) {
      setPosError(singleLoanCheck.reason || "Credit application hard-blocked.");
      return;
    }

    if (basket.length === 0) {
      setPosError("Basket is empty. Select products from the Agro-Dealer Stockroom inventory for credit disbursement.");
      return;
    }

    const fac = facilities.find(f => f.facilityId === selectedFacilityId);
    setIsSubmitting(true);
    setTimeout(() => {
      try {
        const app = agcSubmitApplication({
          farmerTenantId: selectedFarmerId,
          dealerTenantId,
          dealerName: "Choma Agro-Dealer Hub",
          financierInstitutionId: fac ? fac.financierInstitutionId : "inst_mabala_agri",
          financierName: fac ? fac.financierName : "Mabala AgriCredit Ltd",
          requestedBasket: basket,
          selectedCrop,
          appliedHectarage,
          warehouseReceiptId: selectedWarehouseReceiptId || undefined,
          warehouseReceiptPledged: !!selectedWarehouseReceiptId,
          insurancePolicyAttached: !!selectedRateId
        });
        setSubmittedApp(app);
        if (app.status !== "approved") {
          setPosError(app.rejectionReason || "Application was rejected.");
        }
      } catch (err: any) {
        setPosError(err.message);
      } finally {
        setIsSubmitting(false);
      }
    }, 600);
  };

  // Confirm Atomic Disbursement & Decrement Stockroom Inventory
  const handleConfirmDisbursement = () => {
    if (!submittedApp || submittedApp.status !== "approved") return;
    setIsDisbursing(true);
    setPosError(null);

    const fac = facilities.find(f => f.facilityId === selectedFacilityId);
    setTimeout(() => {
      try {
        const loan = agcDisburseLoan({
          applicationId: submittedApp.applicationId,
          insurancePolicyId: selectedRateId || null,
          riskShare: fac ? fac.riskShareDefaults : { weatherPct: 40, guaranteePct: 0, dealerRetainedPct: 60 }
        });

        // DECREMENT AGRO-DEALER STOCKROOM INVENTORY
        const savedSkus = localStorage.getItem("mabala_agd_skus");
        const allSkus: AgroDealerSKU[] = savedSkus ? JSON.parse(savedSkus) : INITIAL_AGRO_SKUS;

        const updatedSkus = allSkus.map(s => {
          const basketItem = basket.find(b => b.skuId === s.id);
          if (basketItem) {
            const newQty = Math.max(0, s.qtyOnHand - basketItem.quantity);
            return {
              ...s,
              qtyOnHand: newQty,
              qtySold: (s.qtySold || 0) + basketItem.quantity,
              lastMovementAt: new Date().toISOString()
            };
          }
          return s;
        });

        localStorage.setItem("mabala_agd_skus", JSON.stringify(updatedSkus));

        // RECORD STOCK MOVEMENTS FOR AUDIT
        const savedMovements = localStorage.getItem("mabala_agd_movements");
        const movements: StockMovement[] = savedMovements ? JSON.parse(savedMovements) : [];
        
        basket.forEach(item => {
          const matchedSku = allSkus.find(s => s.id === item.skuId);
          movements.unshift({
            id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            skuId: item.skuId,
            productName: item.name,
            type: "sale",
            qtyDelta: -item.quantity,
            resultingBalance: matchedSku ? matchedSku.qtyOnHand : 0,
            timestamp: new Date().toISOString(),
            actorId: dealerTenantId,
            actorName: "Agro-Dealer POS Counter",
            reference: `AGC In-Kind Credit Loan ${loan.loanId} (${selectedFarmer?.name || 'Farmer'})`
          });
        });

        localStorage.setItem("mabala_agd_movements", JSON.stringify(movements));
        dispatchSafeEvent("storage");

        setDisbursedLoan(loan);
        loadDealerInventory();
        loadSelectedFarmerData(selectedFarmerId);
        setBasket([]);
      } catch (err: any) {
        setPosError("Disbursement failed: " + err.message);
      } finally {
        setIsDisbursing(false);
      }
    }, 800);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              AGC Agro-Dealer POS Counter
            </span>
            <span className="text-xs text-slate-400">In-Kind Input Credit Checkout</span>
          </div>
          <h1 className="text-2xl font-bold mt-1 text-slate-100 flex items-center gap-2">
            Issue Mabala Input Credit
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Credit is issued purely as an in-kind stock decrement from Agro-Dealer inventory. No cash is disbursed.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setShowFarmerRegisterModal(true)}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-md transition"
          >
            <UserPlus className="w-4 h-4" />
            <span>+ Onboard Active Farmer</span>
          </button>
        </div>
      </div>

      {/* FARMER SELECTION CARD & SEARCH (REQUIREMENT 1) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-emerald-400" />
              1. Select Active Farmer on Mabala Platform
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Select a verified active farmer to evaluate AGC single-loan eligibility and issue input credit.
            </p>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={farmerSearchTerm}
              onChange={e => setFarmerSearchTerm(e.target.value)}
              placeholder="Search farmer by name, phone or NRC..."
              className="w-full bg-slate-950 text-slate-200 text-xs font-medium pl-9 pr-4 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-emerald-500"
            />
            {farmerSearchTerm && (
              <button
                onClick={() => setFarmerSearchTerm("")}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Farmer Selection Grid / Dropdown */}
        {isLoadingFarmers ? (
          <div className="p-6 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
            <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
            <span>Loading active Mabala platform farmers...</span>
          </div>
        ) : !farmerSearchTerm.trim() ? (
          <div className="space-y-3">
            <div className="p-6 text-center text-xs text-slate-400 bg-slate-950/80 rounded-xl border border-slate-800 space-y-2">
              <div className="w-9 h-9 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-emerald-400">
                <Search className="w-4 h-4" />
              </div>
              <p className="font-semibold text-slate-200 text-xs">
                Search to find and select an active farmer
              </p>
              <p className="text-[11px] text-slate-400 max-w-md mx-auto">
                Type a farmer&apos;s name, phone number, or NRC in the search box above to display matching active farmers on Mabala platform.
              </p>
            </div>

            {selectedFarmer && (
              <div className="p-3 bg-slate-950 rounded-xl border border-emerald-500/50 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-slate-400 font-semibold">Active Selected Farmer:</span>
                  </div>
                  <div className="flex items-center gap-2 font-mono">
                    <strong className="text-emerald-400 font-bold">🏡 {selectedFarmer.farmName || `${selectedFarmer.name} Farm`}</strong>
                    <span className="text-slate-400">|</span>
                    <span className="text-slate-200 font-semibold">👤 {selectedFarmer.ownerName || selectedFarmer.name}</span>
                    <span className="text-slate-400">|</span>
                    <span className="text-amber-300 font-bold">🪪 ID: {maskNRC(selectedFarmer.nrc)}</span>
                    <span className="text-slate-400">|</span>
                    <span className="text-cyan-300 font-bold">📱 {maskMobile(selectedFarmer.phone)}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedFarmerId("");
                    setFarmerSearchTerm("");
                  }}
                  className="text-[10px] text-slate-400 hover:text-slate-200 bg-slate-900 hover:bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-800 font-mono transition"
                >
                  Clear Selection
                </button>
              </div>
            )}
          </div>
        ) : filteredFarmers.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-400 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <p>No active farmers found matching &quot;{farmerSearchTerm}&quot; on Mabala platform.</p>
            <button
              onClick={() => setShowFarmerRegisterModal(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg font-bold text-xs inline-flex items-center gap-1.5"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Onboard New Active Farmer Now</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-56 overflow-y-auto pr-1">
              {filteredFarmers.map(f => {
                const isSelected = f.id === selectedFarmerId;
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setSelectedFarmerId(f.id)}
                    className={`p-3.5 rounded-xl border text-left transition relative flex flex-col justify-between ${
                      isSelected
                        ? "bg-emerald-950/40 border-emerald-500/80 ring-1 ring-emerald-500"
                        : "bg-slate-950 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex justify-between items-start gap-2">
                      <div className="space-y-0.5 min-w-0">
                        <strong className="text-xs font-bold text-slate-100 block truncate flex items-center gap-1">
                          🏡 {f.farmName || `${f.name} Farm`}
                        </strong>
                        <span className="text-[11px] font-semibold text-emerald-400 block truncate">
                          👤 Owner: {f.ownerName || f.name}
                        </span>
                        <div className="text-[10px] text-slate-400 font-mono space-y-0.5">
                          <span className="block">🪪 ID: {maskNRC(f.nrc)}</span>
                          <span className="block">📱 Tel: {maskMobile(f.phone)}</span>
                        </div>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold font-mono shrink-0 ${
                        f.creditBand === 'A' || f.creditBand === 'B' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}>
                        Score: {f.creditScore} ({f.creditBand})
                      </span>
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px]">
                      <span className="text-slate-400 font-medium">
                        📍 {typeof f.location === "string" ? f.location : (f.location?.district ? `${f.location.district}, ${f.location.province || ""}` : "Zambia")}
                      </span>
                      {isSelected ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/50">
                          <Check className="w-3 h-3" /> Active Selected
                        </span>
                      ) : (
                        <span className="text-slate-400 group-hover:text-slate-200">Select Farmer</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {selectedFarmer && (
              <div className="p-3 bg-slate-950 rounded-xl border border-emerald-500/50 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-slate-400 font-semibold">Selected Farm & Owner:</span>
                  </div>
                  <div className="flex items-center gap-2 font-mono">
                    <strong className="text-emerald-400 font-bold">🏡 {selectedFarmer.farmName || `${selectedFarmer.name} Farm`}</strong>
                    <span className="text-slate-400">|</span>
                    <span className="text-slate-200 font-semibold">👤 {selectedFarmer.ownerName || selectedFarmer.name}</span>
                    <span className="text-slate-400">|</span>
                    <span className="text-amber-300 font-bold">🪪 ID: {maskNRC(selectedFarmer.nrc)}</span>
                    <span className="text-slate-400">|</span>
                    <span className="text-cyan-300 font-bold">📱 {maskMobile(selectedFarmer.phone)}</span>
                  </div>
                </div>
                <span className="text-[10px] text-slate-400 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800 font-mono">
                  ID: {maskUserId(selectedFarmer.id)}
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* HARD SINGLE LOAN BLOCK BANNER */}
      {selectedFarmer && !singleLoanCheck.allowed && (
        <div className="bg-rose-950/90 border-2 border-rose-500/80 rounded-2xl p-6 text-white shadow-2xl space-y-3">
          <div className="flex items-center gap-3 text-rose-300">
            <AlertOctagon className="w-8 h-8 text-rose-400 animate-bounce shrink-0" />
            <div>
              <span className="px-2.5 py-0.5 bg-rose-900/80 border border-rose-500 text-rose-200 text-xs font-bold rounded-full uppercase tracking-wider">
                Platform Hard Guardrail Enforced
              </span>
              <h2 className="text-lg font-black text-white mt-1">
                HARD REJECTION: SINGLE ACTIVE LOAN POLICY ENFORCED
              </h2>
            </div>
          </div>

          <p className="text-xs text-rose-200 leading-relaxed font-mono">
            {singleLoanCheck.reason}
          </p>

          <div className="p-3 bg-slate-950/80 rounded-xl border border-rose-800/80 text-xs text-slate-300 flex justify-between items-center">
            <span>Platform-wide rule §8: A farmer may hold ONLY ONE active AGC loan across all agro-dealers and financiers.</span>
            <span className="font-bold text-rose-400">Status: REJECTED-SINGLE-LOAN</span>
          </div>
        </div>
      )}

      {posError && (
        <div className="p-4 bg-rose-950/80 border border-rose-500/40 rounded-xl text-rose-300 text-xs flex justify-between items-center">
          <span>🚨 {posError}</span>
          <button onClick={() => setPosError(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {disbursedLoan ? (
        /* DISBURSEMENT DISCHARGE RECEIPT */
        <div className="bg-slate-900 border border-emerald-500/40 rounded-2xl p-6 text-slate-100 shadow-2xl space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="p-3 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400">
                Disbursement Authorized & Settled
              </span>
              <h2 className="text-xl font-bold text-slate-100 mt-1 font-mono">Loan ID: {disbursedLoan.loanId}</h2>
              <p className="text-xs text-slate-400">
                Agro-dealer stockroom inventory decremented & audit movement recorded for {selectedFarmer?.name}.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
              <div className="text-slate-400">Total Basket Value</div>
              <div className="text-xl font-black text-emerald-400 font-mono mt-1">
                {currencySymbol} {disbursedLoan.principal.toLocaleString()}
              </div>
            </div>
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
              <div className="text-slate-400">Total Repayable (120 Days)</div>
              <div className="text-xl font-black text-slate-200 font-mono mt-1">
                {currencySymbol} {disbursedLoan.feeSchedule.totalRepayable.toLocaleString()}
              </div>
            </div>
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
              <div className="text-slate-400">Financier Partner</div>
              <div className="text-base font-bold text-slate-200 mt-1">{disbursedLoan.financierName}</div>
            </div>
          </div>

          <button
            onClick={() => {
              setDisbursedLoan(null);
              setSubmittedApp(null);
            }}
            className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg transition-colors"
          >
            Start New POS Transaction
          </button>
        </div>
      ) : (
        /* MAIN POS COUNTER CATALOG & CHECKOUT (REQUIREMENT 2) */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Agro-Dealer Stockroom Inventory Catalog */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <Package className="w-5 h-5 text-emerald-400" />
                  Inventory Input Catalog
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Products in Agro-Dealer&apos;s inventory & stockroom only.
                </p>
              </div>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 font-mono font-bold px-2 py-1 rounded border border-emerald-500/30">
                {inventorySkus.length} SKUs in Stock
              </span>
            </div>

            {inventorySkus.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <ShieldAlert className="w-6 h-6 text-amber-500 mx-auto" />
                <p className="font-semibold text-slate-300">No Inventory Available in Stockroom</p>
                <p className="text-[11px]">
                  Only items currently present in the Agro-Dealer&apos;s inventory stockroom can be added to the input credit catalog.
                </p>
              </div>
            ) : (
              <div className="space-y-2 mt-4 max-h-[480px] overflow-y-auto pr-1">
                {inventorySkus.map(sku => (
                  <div
                    key={sku.id}
                    className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center text-xs hover:border-slate-700 transition-colors"
                  >
                    <div className="space-y-1 pr-2">
                      <div className="font-bold text-slate-200 leading-tight">{sku.productName}</div>
                      <div className="flex items-center gap-2 text-[10px]">
                        <span className="text-slate-400 uppercase font-mono bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                          {sku.category}
                        </span>
                        <span className="text-emerald-400 font-mono font-bold">
                          {sku.qtyOnHand} {sku.unit} in stock
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="font-mono font-bold text-emerald-400">
                        {currencySymbol} {sku.sellingPrice.toLocaleString()}
                      </span>
                      <button
                        onClick={() => handleAddItemToBasket(sku)}
                        disabled={!singleLoanCheck.allowed || sku.qtyOnHand <= 0}
                        className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors disabled:opacity-40"
                        title="Add to credit checkout basket"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Checkout Basket & Authorization */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-lg space-y-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-emerald-400" />
                  Requested Credit Basket
                </h3>
                {basket.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      setBasket([]);
                      setSubmittedApp(null);
                      setDisbursedLoan(null);
                      setPosError(null);
                    }}
                    className="px-2.5 py-1 bg-rose-950/80 hover:bg-rose-900 border border-rose-500/50 text-rose-300 font-bold text-xs rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                    title="Cancel credit basket request and clear items"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Cancel Request</span>
                  </button>
                )}
              </div>

              {basket.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400 bg-slate-950 rounded-xl border border-slate-800">
                  Basket is empty. Click products from the Agro-Dealer Inventory Input Catalog to add.
                </div>
              ) : (
                <div className="space-y-2">
                  {basket.map(item => (
                    <div key={item.skuId} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                      <div>
                        <div className="font-bold text-slate-200">{item.name}</div>
                        <div className="text-slate-400 text-[11px] font-mono">
                          {item.quantity} x {currencySymbol} {item.unitPrice.toLocaleString()}
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="font-mono font-bold text-slate-100">
                          {currencySymbol} {item.total.toLocaleString()}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(item.skuId)}
                          className="px-2 py-1 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/50 text-rose-300 rounded-md transition-colors text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                          title="Remove item from credit basket"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove</span>
                        </button>
                      </div>
                    </div>
                  ))}

                  <div className="p-4 bg-slate-950 rounded-xl border border-emerald-500/30 flex justify-between items-center text-sm font-bold">
                    <span className="text-slate-300">Total Input Credit Value:</span>
                    <span className="text-emerald-400 font-mono text-lg">
                      {currencySymbol} {totalBasketAmount.toLocaleString()}
                    </span>
                  </div>
                </div>
              )}

              {/* Crop & Plot Hectarage Credit Limit Computation */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 mt-4 space-y-3 text-xs">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <span className="font-bold text-slate-200 flex items-center gap-1.5">
                    🌱 Crop & Mapped Plot Hectarage Credit Computation
                  </span>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30 font-semibold">
                    Published Rate Enforced
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1 font-semibold flex items-center justify-between">
                      <span>Selected Target Crop</span>
                      {farmerCropOptions.some(o => o.isFromCropCycle) && (
                        <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-500/30">
                          Active Crop Cycle Reused
                        </span>
                      )}
                    </label>
                    <select
                      value={selectedCropOptionId || selectedCrop}
                      onChange={e => handleCropOptionChange(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2 text-slate-200 font-medium focus:outline-none focus:border-emerald-500"
                    >
                      {farmerCropOptions.length > 0 ? (
                        farmerCropOptions.map(opt => (
                          <option key={opt.id} value={opt.id}>
                            {opt.label}
                          </option>
                        ))
                      ) : (
                        <>
                          <option value="Maize">White Maize (Food/Grain)</option>
                          <option value="Soya">Soyabeans (Legume/Oilseed)</option>
                          <option value="Wheat">Irrigated Winter Wheat</option>
                          <option value="Cotton">Seed Cotton</option>
                        </>
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 font-semibold flex items-center justify-between">
                      <span>Mapped Plot Size</span>
                      <span className="text-[9px] font-mono text-emerald-400 font-normal">Auto-Fetched</span>
                    </label>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        min="0.1"
                        max="500"
                        step="0.1"
                        value={appliedHectarage}
                        onChange={e => {
                          const val = Math.max(0.1, Number(e.target.value));
                          setAppliedHectarage(val);
                          setAutoFetchedPlotBadge(`Plot size manually adjusted to ${val} Ha`);
                        }}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2 text-slate-200 font-bold font-mono focus:outline-none focus:border-emerald-500 text-center"
                      />
                      <span className="text-slate-400 font-bold">Ha</span>
                    </div>
                  </div>

                  {/* Computed Eligible Limit */}
                  {(() => {
                    const activeFac = facilities.find(f => f.facilityId === selectedFacilityId);
                    const cropRate = activeFac?.cropLimits?.[selectedCrop] || (selectedCrop === 'Soya' ? 5200 : selectedCrop === 'Wheat' ? 5800 : 4500);
                    const totalHectareLimit = cropRate * appliedHectarage;
                    const isWithinLimit = totalBasketAmount <= totalHectareLimit;

                    return (
                      <div className={`p-2.5 rounded-xl border flex flex-col justify-between ${
                        isWithinLimit ? 'bg-emerald-950/40 border-emerald-500/40' : 'bg-rose-950/40 border-rose-500/40'
                      }`}>
                        <div className="text-[10px] text-slate-400 flex justify-between">
                          <span>{selectedCrop} Rate: K{cropRate.toLocaleString()}/Ha</span>
                          <span className={isWithinLimit ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                            {isWithinLimit ? 'Within Limit' : 'Exceeds Limit'}
                          </span>
                        </div>
                        <div className="text-base font-black font-mono text-emerald-400 mt-0.5">
                          Limit: {currencySymbol} {totalHectareLimit.toLocaleString()}
                        </div>
                      </div>
                    );
                  })()}

                  {autoFetchedPlotBadge && (
                    <div className="col-span-full flex items-center gap-1.5 text-[10.5px] text-emerald-300 bg-emerald-950/60 p-2 rounded-lg border border-emerald-700/50">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{autoFetchedPlotBadge}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Facility & Risk Share Selector */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-800 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Financier Facility</label>
                  <select
                    value={selectedFacilityId}
                    onChange={e => setSelectedFacilityId(e.target.value)}
                    disabled={facilities.length === 0}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 focus:outline-none focus:border-emerald-500 disabled:opacity-50"
                  >
                    {facilities.length === 0 ? (
                      <option value="">No Active Facilities Available</option>
                    ) : (
                      facilities.map(fac => (
                        <option key={fac.facilityId} value={fac.facilityId}>
                          {fac.financierName} (Limit: K{fac.allocatedLimit.toLocaleString()})
                        </option>
                      ))
                    )}
                  </select>
                  {facilities.length === 0 && (
                    <p className="text-[10px] text-amber-400 mt-1">No active credit facilities posted on the platform.</p>
                  )}
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Optional Crop/Weather Insurance</label>
                  <select
                    value={selectedRateId}
                    onChange={e => setSelectedRateId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 focus:outline-none focus:border-emerald-500"
                  >
                    <option value="">No Loan Insurance</option>
                    {insurerRates.map(rate => (
                      <option key={rate.rateId} value={rate.rateId}>
                        {rate.insurerName} ({rate.ratePct}% - {rate.cropOrCategory})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 flex gap-3">
                {!submittedApp ? (
                  <button
                    onClick={handleCheckCreditScore}
                    disabled={!singleLoanCheck.allowed || isSubmitting || basket.length === 0 || !selectedFarmerId || facilities.length === 0}
                    className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-emerald-950/50 transition-colors flex items-center justify-center gap-2 disabled:opacity-40"
                  >
                    {isSubmitting
                      ? "Evaluating AGC Credit Score & Limits..."
                      : facilities.length === 0
                      ? "No Credit Facility Available to Submit"
                      : "Validate & Submit Credit Application"}
                    <ArrowRight className="w-4 h-4" />
                  </button>
                ) : (
                  <div className="w-full space-y-3">
                    <div className="p-4 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex justify-between items-center">
                      <div>
                        <div className="font-bold">Application APPROVED</div>
                        <div>Scored Credit Line Available: {currencySymbol} {totalBasketAmount.toLocaleString()}</div>
                      </div>
                      <span className="px-2 py-1 bg-emerald-500/20 text-emerald-300 font-bold rounded">Ready for Stock Release</span>
                    </div>

                    <button
                      onClick={handleConfirmDisbursement}
                      disabled={isDisbursing}
                      className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs shadow-xl transition-all flex items-center justify-center gap-2"
                    >
                      {isDisbursing ? "Executing Stockroom Inventory Decrement..." : "Execute Atomic Disbursement (Release Stockroom Products)"}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* QUICK REGISTER ACTIVE FARMER MODAL */}
      {showFarmerRegisterModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full text-slate-100 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-emerald-400" />
                Onboard Active Farmer on Mabala
              </h3>
              <button
                onClick={() => setShowFarmerRegisterModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRegisterNewFarmer} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Farmer Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mwanza Mulenga"
                  value={newFarmerName}
                  onChange={e => setNewFarmerName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Phone Number (Zambian MSISDN) *</label>
                <input
                  type="text"
                  required
                  placeholder="+260977112233"
                  value={newFarmerPhone}
                  onChange={e => setNewFarmerPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">National Registration Card (NRC)</label>
                <input
                  type="text"
                  placeholder="e.g. 192847/61/1"
                  value={newFarmerNrc}
                  onChange={e => setNewFarmerNrc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">District / Farm Location</label>
                <input
                  type="text"
                  placeholder="e.g. Choma District, Southern Province"
                  value={newFarmerLocation}
                  onChange={e => setNewFarmerLocation(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowFarmerRegisterModal(false)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg transition"
                >
                  Register Farmer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

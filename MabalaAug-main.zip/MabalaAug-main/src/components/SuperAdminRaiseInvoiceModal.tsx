import React, { useState, useEffect, useMemo } from "react";
import { 
  X, 
  Plus, 
  Trash, 
  FileText, 
  CheckCircle2, 
  Calendar, 
  Building2, 
  User, 
  Store, 
  ShieldCheck, 
  Search, 
  Filter, 
  Check, 
  Sparkles, 
  Clock, 
  ArrowRight,
  RefreshCw,
  Info,
  Mail,
  MessageSquare,
  Send
} from "lucide-react";
import { raisePlatformInvoice, PlatformInvoice } from "../services/platformInvoiceService";
import { dispatchInvoiceEmailReminder } from "../services/invoiceReminderService";
import { fetchAllActiveTenantNodes, PRESET_BASE_TENANTS, TenantNodeRecord } from "../services/tenantRegistryService";
import { db } from "../firebase";

export interface TenantNodeOption {
  id: string;
  name: string;
  type: "Farmer" | "Agro-Dealer" | "Supplier";
  email: string;
  phone?: string;
  location?: string;
  status?: string;
  tier?: string;
}

interface SuperAdminRaiseInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInvoiceCreated: (newInvoice: PlatformInvoice) => void;
  currencySymbol?: string;
  availableTenants?: any[];
  initialTenant?: any;
}

const INVOICE_QUICK_TEMPLATES = [
  { description: "Mabala Platform SaaS Operational License", amount: 250 },
  { description: "Agronomy Advisory & Soil Testing Pack", amount: 600 },
  { description: "Bulk SMS & WhatsApp Automation Bundle", amount: 150 },
  { description: "Mabala IoT Sensor & Weather Station Gateway", amount: 1200 },
  { description: "Annual Enterprise Farm Cloud Tier", amount: 2500 }
];

export default function SuperAdminRaiseInvoiceModal({
  isOpen,
  onClose,
  onInvoiceCreated,
  currencySymbol = "ZK",
  availableTenants = [],
  initialTenant = null
}: SuperAdminRaiseInvoiceModalProps) {
  const [tenantsList, setTenantsList] = useState<TenantNodeOption[]>(PRESET_BASE_TENANTS);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [typeFilter, setTypeFilter] = useState<"ALL" | "Farmer" | "Agro-Dealer" | "Supplier">("ALL");
  const [selectedTenant, setSelectedTenant] = useState<TenantNodeOption | null>(PRESET_BASE_TENANTS[0]);
  const [isCustomMode, setIsCustomMode] = useState<boolean>(false);
  const [isLoadingTenants, setIsLoadingTenants] = useState<boolean>(false);

  // Auto notification checkboxes
  const [autoSendEmail, setAutoSendEmail] = useState<boolean>(true);
  const [autoSendSms, setAutoSendSms] = useState<boolean>(true);

  // Custom Tenant Manual Form States
  const [customTenantName, setCustomTenantName] = useState("");
  const [customTenantEmail, setCustomTenantEmail] = useState("");
  const [customTenantPhone, setCustomTenantPhone] = useState("");
  const [customRecipientType, setCustomRecipientType] = useState<"Farmer" | "Agro-Dealer" | "Supplier">("Farmer");

  // Line Items & Metadata
  const [lineItems, setLineItems] = useState<{ description: string; amount: number }[]>([
    { description: "Mabala Platform SaaS Operational License", amount: 250 }
  ]);

  const [dueDate, setDueDate] = useState<string>(
    new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
  );
  const [notes, setNotes] = useState("Standard 14-day payment terms. Settlable via Mobile Money (MTN / Airtel / Zamtel) or Credit in Billing Centre.");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load and merge all platform tenants on open
  useEffect(() => {
    if (!isOpen) return;

    const loadAllNodes = async () => {
      setIsLoadingTenants(true);
      try {
        const rawNodes = await fetchAllActiveTenantNodes({
          extraTenants: availableTenants
        });

        const combinedMap = new Map<string, TenantNodeOption>();

        rawNodes.forEach(u => {
          const uid = u.uid || u.tenantUid || u.id || u.tenantId;
          const email = u.email || u.tenantEmail || u.ownerEmail || "";
          const farmName = u.farms?.[0]?.name || u.farm?.name || u.farmName || u.displayName || u.name || `Farm Node (${email})`;
          const roleStr = (u.role || u.accountType || u.type || "Farmer").toString().toLowerCase();
          let type: "Farmer" | "Agro-Dealer" | "Supplier" = "Farmer";
          if (roleStr.includes("dealer") || roleStr.includes("merchant")) type = "Agro-Dealer";
          else if (roleStr.includes("supplier") || roleStr.includes("partner") || roleStr.includes("fin")) type = "Supplier";

          const option: TenantNodeOption = {
            id: uid || `NODE-${Date.now().toString().slice(-4)}`,
            name: farmName,
            type,
            email,
            phone: u.phone || u.phoneNumber || u.tenantPhone || u.ownerPhone || "+260978000000",
            location: typeof u.location === "string" ? u.location : (u.district ? `${u.district}, ${u.province || ""}` : (u.farm?.location || "Zambia")),
            tier: u.subscriptionTier || u.subscriptionPackage || "Standard",
            status: u.status || "ACTIVE"
          };

          combinedMap.set(option.id, option);
          if (email) combinedMap.set(email.toLowerCase(), option);
        });

        // Handle initialTenant if provided
        let preselected: TenantNodeOption | null = null;
        if (initialTenant) {
          const iUid = initialTenant.uid || initialTenant.tenantUid || initialTenant.id;
          const iEmail = (initialTenant.email || initialTenant.tenantEmail || "").toLowerCase();
          const iName = initialTenant.farm?.name || initialTenant.farmName || initialTenant.displayName || initialTenant.name || `Farm Node (${iEmail})`;
          const roleStr = (initialTenant.role || initialTenant.accountType || "Farmer").toString().toLowerCase();
          let iType: "Farmer" | "Agro-Dealer" | "Supplier" = "Farmer";
          if (roleStr.includes("dealer")) iType = "Agro-Dealer";
          else if (roleStr.includes("supplier") || roleStr.includes("partner")) iType = "Supplier";

          preselected = {
            id: iUid || `NODE-${Date.now().toString().slice(-4)}`,
            name: iName,
            type: iType,
            email: initialTenant.email || initialTenant.tenantEmail || "",
            phone: initialTenant.phone || initialTenant.phoneNumber || initialTenant.tenantPhone || "",
            location: initialTenant.location || initialTenant.farm?.location || "Zambia",
            tier: initialTenant.subscriptionTier || "Standard",
            status: "ACTIVE"
          };
          combinedMap.set(preselected.id, preselected);
          if (preselected.email) combinedMap.set(preselected.email.toLowerCase(), preselected);
        }

        const allMerged = Array.from(combinedMap.values());
        // Deduplicate by ID
        const uniqueList: TenantNodeOption[] = [];
        const seenIds = new Set<string>();
        allMerged.forEach(item => {
          if (!seenIds.has(item.id)) {
            seenIds.add(item.id);
            uniqueList.push(item);
          }
        });

        setTenantsList(uniqueList);

        if (preselected) {
          setSelectedTenant(preselected);
        } else if (uniqueList.length > 0 && !selectedTenant) {
          setSelectedTenant(uniqueList[0]);
        }
      } catch (err) {
        console.error("[SuperAdminRaiseInvoiceModal] Failed to load tenant nodes:", err);
      } finally {
        setIsLoadingTenants(false);
      }
    };

    loadAllNodes();
  }, [isOpen, availableTenants, initialTenant]);

  // Filtered tenants based on search input and type filter
  const filteredTenants = useMemo(() => {
    return tenantsList.filter(tenant => {
      // Type match
      if (typeFilter !== "ALL" && tenant.type !== typeFilter) {
        return false;
      }
      // Search match
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = tenant.name.toLowerCase().includes(q);
        const matchEmail = tenant.email.toLowerCase().includes(q);
        const matchId = tenant.id.toLowerCase().includes(q);
        const matchPhone = (tenant.phone || "").toLowerCase().includes(q);
        const matchLocation = (tenant.location || "").toLowerCase().includes(q);
        return matchName || matchEmail || matchId || matchPhone || matchLocation;
      }
      return true;
    });
  }, [tenantsList, searchQuery, typeFilter]);

  if (!isOpen) return null;

  const totalAmount = lineItems.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);

  const handleAddLineItem = () => {
    setLineItems([...lineItems, { description: "Additional Platform Service", amount: 100 }]);
  };

  const handleApplyTemplate = (template: { description: string; amount: number }) => {
    setLineItems([...lineItems, { ...template }]);
  };

  const handleRemoveLineItem = (index: number) => {
    if (lineItems.length <= 1) return;
    setLineItems(lineItems.filter((_, i) => i !== index));
  };

  const handleLineItemChange = (index: number, field: "description" | "amount", val: any) => {
    const updated = [...lineItems];
    if (field === "amount") {
      updated[index].amount = Math.max(0, Number(val));
    } else {
      updated[index].description = val;
    }
    setLineItems(updated);
  };

  const handleSetDueDays = (days: number) => {
    const d = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
    setDueDate(d.toISOString().split("T")[0]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (totalAmount <= 0) {
      alert("Invoice total amount must be greater than zero.");
      return;
    }

    setIsSubmitting(true);

    let tId = "";
    let tName = "";
    let tEmail = "";
    let tType: "Farmer" | "Agro-Dealer" | "Supplier" = "Farmer";

    if (isCustomMode) {
      if (!customTenantName.trim() || !customTenantEmail.trim()) {
        alert("Please provide custom tenant name and email address.");
        setIsSubmitting(false);
        return;
      }
      tId = `TENANT-CUST-${Date.now().toString().slice(-4)}`;
      tName = customTenantName.trim();
      tEmail = customTenantEmail.trim();
      tType = customRecipientType;
    } else {
      if (!selectedTenant) {
        alert("Please select an active recipient tenant node from the directory.");
        setIsSubmitting(false);
        return;
      }
      tId = selectedTenant.id;
      tName = selectedTenant.name;
      tEmail = selectedTenant.email;
      tType = selectedTenant.type;
    }

    try {
      const newInvoice = await raisePlatformInvoice({
        recipientTenantId: tId,
        recipientTenantName: tName,
        recipientType: tType,
        recipientEmail: tEmail,
        lineItems,
        totalAmount,
        dueDate,
        notes,
        issuedBy: "Super Admin"
      });

      // Dispatch Email & Pay Link if selected
      let emailDispatchNotice = "";
      if (autoSendEmail) {
        try {
          const log = await dispatchInvoiceEmailReminder(newInvoice, true);
          emailDispatchNotice = `\n\n📧 Instant Email Notification with Direct Lipila Payment Link has been dispatched to ${tEmail}.`;
        } catch (mailErr) {
          console.warn("[SuperAdminRaiseInvoiceModal] Auto email dispatch warning:", mailErr);
        }
      }

      // Global sync notification
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("mabala_invoice_raised", {
          detail: { invoice: newInvoice }
        }));
      }

      onInvoiceCreated(newInvoice);
      alert(`✅ Invoice ${newInvoice.invoiceNumber} successfully issued to ${tName} (${tEmail})! Total: ${currencySymbol} ${totalAmount.toLocaleString()}.${emailDispatchNotice}\n\nIt is now accessible in their Billing Centre.`);
      onClose();
    } catch (err: any) {
      console.error("Failed to raise invoice:", err);
      alert("Failed to raise invoice: " + (err.message || "Unknown error"));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs font-sans animate-fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-5 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600 rounded-2xl text-white shadow-inner">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base tracking-tight flex items-center gap-2">
                <span>Super Admin — Issue Platform Invoice</span>
                <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 text-[10px] font-mono rounded-full border border-indigo-400/30">
                  Live Sync Active
                </span>
              </h3>
              <p className="text-xs text-slate-300 font-medium mt-0.5">
                Search and select active tenant farm nodes, configure itemized billings, and dispatch platform invoices.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close Invoice Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto">
          
          {/* SECTION 1: SEARCH & SELECT RECIPIENT TENANT NODE */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <label className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-indigo-600" />
                <span>Recipient Tenant Node ({tenantsList.length} Active in Network)</span>
              </label>
              
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsCustomMode(!isCustomMode)}
                  className={`text-xs font-bold px-2.5 py-1 rounded-lg border transition cursor-pointer flex items-center gap-1 ${
                    isCustomMode 
                      ? "bg-indigo-50 text-indigo-700 border-indigo-200" 
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200 border-slate-200"
                  }`}
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isCustomMode ? "Select Existing Node" : "+ Enter Custom Recipient"}</span>
                </button>
              </div>
            </div>

            {!isCustomMode ? (
              <div className="space-y-3">
                {/* Search Bar & Role Filter */}
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search tenant nodes by farm name, owner email, phone, location, ID..."
                      className="w-full pl-9 pr-8 py-2 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white focus:border-indigo-500 transition"
                    />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={() => setSearchQuery("")}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl shrink-0 overflow-x-auto">
                    {(["ALL", "Farmer", "Agro-Dealer", "Supplier"] as const).map(fType => (
                      <button
                        key={fType}
                        type="button"
                        onClick={() => setTypeFilter(fType)}
                        className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition cursor-pointer shrink-0 ${
                          typeFilter === fType 
                            ? "bg-white text-indigo-700 shadow-xs font-extrabold" 
                            : "text-slate-600 hover:text-slate-900"
                        }`}
                      >
                        {fType === "ALL" ? "All Nodes" : fType}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Selected Recipient Card (if selected) */}
                {selectedTenant && (
                  <div className="p-3.5 bg-indigo-50/80 border border-indigo-200 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-indigo-600 text-white text-[9.5px] font-black uppercase rounded-md tracking-wider">
                          {selectedTenant.type}
                        </span>
                        <span className="text-xs font-black text-slate-900">{selectedTenant.name}</span>
                      </div>
                      <div className="text-[11px] text-slate-600 font-medium flex flex-wrap gap-x-3 gap-y-0.5">
                        <span>✉️ <strong>{selectedTenant.email}</strong></span>
                        {selectedTenant.phone && <span>📱 {selectedTenant.phone}</span>}
                        {selectedTenant.location && <span>📍 {selectedTenant.location}</span>}
                        <span className="font-mono text-slate-400">Node ID: {selectedTenant.id}</span>
                      </div>
                    </div>
                    <div className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[10.5px] font-black rounded-lg border border-emerald-300 flex items-center gap-1 shrink-0">
                      <Check className="w-3.5 h-3.5" />
                      <span>Target Recipient Selected</span>
                    </div>
                  </div>
                )}

                {/* Search Results List */}
                <div className="border border-slate-200 rounded-2xl max-h-48 overflow-y-auto divide-y divide-slate-100 bg-white">
                  {isLoadingTenants ? (
                    <div className="p-6 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin text-indigo-500" />
                      <span>Loading active tenant network...</span>
                    </div>
                  ) : filteredTenants.length === 0 ? (
                    <div className="p-6 text-center text-xs text-slate-400 space-y-1 font-medium">
                      <p>No tenant nodes found matching "{searchQuery}".</p>
                      <button
                        type="button"
                        onClick={() => { setSearchQuery(""); setTypeFilter("ALL"); }}
                        className="text-indigo-600 hover:underline text-[11px] font-bold"
                      >
                        Reset Search Filters
                      </button>
                    </div>
                  ) : (
                    filteredTenants.map(tenant => {
                      const isSelected = selectedTenant?.id === tenant.id;
                      return (
                        <button
                          key={tenant.id}
                          type="button"
                          onClick={() => setSelectedTenant(tenant)}
                          className={`w-full text-left p-2.5 px-3.5 transition flex items-center justify-between gap-3 cursor-pointer ${
                            isSelected 
                              ? "bg-indigo-50/90 font-bold" 
                              : "hover:bg-slate-50"
                          }`}
                        >
                          <div className="space-y-0.5 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className={`px-1.5 py-0.5 text-[9px] font-black uppercase rounded ${
                                tenant.type === "Farmer" ? "bg-emerald-100 text-emerald-800" :
                                tenant.type === "Agro-Dealer" ? "bg-amber-100 text-amber-800" :
                                "bg-purple-100 text-purple-800"
                              }`}>
                                {tenant.type}
                              </span>
                              <span className="text-xs font-bold text-slate-800 truncate">{tenant.name}</span>
                            </div>
                            <div className="text-[10.5px] text-slate-500 font-medium truncate">
                              {tenant.email} {tenant.phone ? `• ${tenant.phone}` : ""} {tenant.location ? `• ${tenant.location}` : ""}
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="text-[9.5px] font-mono text-slate-400">{tenant.id}</span>
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                              isSelected ? "bg-indigo-600 border-indigo-600 text-white" : "border-slate-300"
                            }`}>
                              {isSelected && <Check className="w-3 h-3" />}
                            </div>
                          </div>
                        </button>
                      );
                    })
                  )}
                </div>
              </div>
            ) : (
              /* Custom Tenant Entry */
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3 animate-fade-in">
                <div className="flex items-center gap-1.5 text-xs text-indigo-700 font-bold">
                  <Info className="w-4 h-4" />
                  <span>Enter Custom / Off-Platform Recipient Information</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Recipient / Farm Name *</label>
                    <input
                      type="text"
                      required
                      value={customTenantName}
                      onChange={(e) => setCustomTenantName(e.target.value)}
                      placeholder="e.g. Copperbelt Agro Services"
                      className="w-full text-xs font-bold p-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Recipient Email Address *</label>
                    <input
                      type="email"
                      required
                      value={customTenantEmail}
                      onChange={(e) => setCustomTenantEmail(e.target.value)}
                      placeholder="e.g. accounts@copperbelt.zm"
                      className="w-full text-xs font-bold p-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Mobile Phone (Optional)</label>
                    <input
                      type="text"
                      value={customTenantPhone}
                      onChange={(e) => setCustomTenantPhone(e.target.value)}
                      placeholder="e.g. +260978000000"
                      className="w-full text-xs font-bold p-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Recipient Node Type</label>
                    <select
                      value={customRecipientType}
                      onChange={(e) => setCustomRecipientType(e.target.value as any)}
                      className="w-full text-xs font-bold p-2.5 bg-white border border-slate-200 rounded-xl outline-none cursor-pointer focus:border-indigo-500"
                    >
                      <option value="Farmer">Farmer Node</option>
                      <option value="Agro-Dealer">Agro-Dealer Merchant</option>
                      <option value="Supplier">Input Supplier / Partner</option>
                    </select>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* SECTION 2: INVOICE LINE ITEMS & QUICK TEMPLATES */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <label className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-emerald-600" />
                <span>Invoice Line Items & Services</span>
              </label>
              
              <button
                type="button"
                onClick={handleAddLineItem}
                className="text-xs font-black text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Custom Line Item</span>
              </button>
            </div>

            {/* Quick Templates */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                ⚡ Quick-Insert Service Presets:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {INVOICE_QUICK_TEMPLATES.map((tmpl, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleApplyTemplate(tmpl)}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10.5px] font-semibold rounded-lg transition border border-slate-200 flex items-center gap-1 cursor-pointer"
                  >
                    <span>+ {tmpl.description}</span>
                    <span className="font-mono font-bold text-emerald-700">({currencySymbol} {tmpl.amount})</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Line Items Rows */}
            <div className="space-y-2">
              {lineItems.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2 p-2 bg-slate-50 border border-slate-200 rounded-xl">
                  <input
                    type="text"
                    required
                    value={item.description}
                    onChange={(e) => handleLineItemChange(idx, "description", e.target.value)}
                    placeholder="Service rendered or license description..."
                    className="flex-1 text-xs font-bold p-2 bg-white border border-slate-200 rounded-lg outline-none focus:border-indigo-500"
                  />
                  <div className="w-32 flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-1 px-2 shrink-0 focus-within:border-indigo-500">
                    <span className="text-[10px] font-black text-slate-400">{currencySymbol}</span>
                    <input
                      type="number"
                      required
                      min="1"
                      value={item.amount}
                      onChange={(e) => handleLineItemChange(idx, "amount", e.target.value)}
                      className="w-full text-xs font-extrabold font-mono outline-none"
                    />
                  </div>
                  {lineItems.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveLineItem(idx)}
                      className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer shrink-0"
                      title="Remove Line Item"
                    >
                      <Trash className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* SECTION 3: DUE DATE & TOTAL CALCULATION */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <label className="text-[10.5px] font-extrabold text-slate-600 uppercase tracking-wider block">
                  Payment Due Date
                </label>
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => handleSetDueDays(7)}
                    className="text-[10px] px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded font-bold cursor-pointer"
                  >
                    +7d
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetDueDays(14)}
                    className="text-[10px] px-1.5 py-0.5 bg-indigo-100 hover:bg-indigo-200 text-indigo-700 rounded font-bold cursor-pointer"
                  >
                    +14d
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetDueDays(30)}
                    className="text-[10px] px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded font-bold cursor-pointer"
                  >
                    +30d
                  </button>
                </div>
              </div>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10.5px] font-extrabold text-slate-600 uppercase tracking-wider block">
                Calculated Invoice Total
              </label>
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 font-mono font-black text-sm flex items-center justify-between">
                <span className="text-xs font-sans text-emerald-800 font-bold">Total Due:</span>
                <span className="text-base">{currencySymbol} {totalAmount.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* SECTION 4: PAYMENT TERMS & INVOICE NOTES */}
          <div className="space-y-1">
            <label className="text-[10.5px] font-extrabold text-slate-600 uppercase tracking-wider block">
              Payment Terms & Settlement Instructions
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Provide settlement instructions, MoMo account details, or terms..."
              className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none font-medium focus:border-indigo-500"
            />
          </div>

          {/* SECTION 5: AUTOMATED NOTIFICATION & DISPATCH OPTIONS */}
          <div className="p-3.5 bg-indigo-50/50 border border-indigo-100 rounded-2xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10.5px] font-black text-indigo-950 uppercase tracking-wider flex items-center gap-1.5">
                <Send className="w-3.5 h-3.5 text-indigo-600" />
                <span>Automated Dispatch Channels</span>
              </span>
              <span className="text-[10px] text-indigo-600 font-mono font-bold">Instant Delivery</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-semibold text-slate-700">
              <label className="flex items-center gap-2 cursor-pointer bg-white p-2.5 rounded-xl border border-slate-200 hover:border-indigo-300 transition shadow-xs">
                <input
                  type="checkbox"
                  checked={autoSendEmail}
                  onChange={(e) => setAutoSendEmail(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                />
                <div className="flex items-center gap-1.5 min-w-0">
                  <Mail className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                  <span className="text-[11px] font-bold text-slate-800 truncate">Email with Lipila Pay Link</span>
                </div>
              </label>

              <label className="flex items-center gap-2 cursor-pointer bg-white p-2.5 rounded-xl border border-slate-200 hover:border-indigo-300 transition shadow-xs">
                <input
                  type="checkbox"
                  checked={autoSendSms}
                  onChange={(e) => setAutoSendSms(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                />
                <div className="flex items-center gap-1.5 min-w-0">
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span className="text-[11px] font-bold text-slate-800 truncate">SMS Payment Alert</span>
                </div>
              </label>
            </div>
          </div>

          {/* ACTION BUTTONS */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3 shrink-0">
            <div className="text-xs text-slate-500 font-medium hidden sm:block">
              Recipient: <strong className="text-slate-800">{isCustomMode ? customTenantName || "Custom" : selectedTenant?.name || "Selected Node"}</strong>
            </div>
            
            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 text-xs font-extrabold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isSubmitting ? "Issuing Invoice..." : "Issue Invoice to Tenant Node"}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

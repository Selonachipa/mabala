import React, { useState, useEffect } from "react";
import { 
  Sliders, 
  ShieldCheck, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  Save, 
  History, 
  Plus, 
  DollarSign, 
  Percent, 
  Lock,
  Mail,
  Send,
  Calendar,
  Layers,
  FileText,
  Clock,
  Check,
  UserCheck,
  CreditCard,
  Building2,
  XCircle,
  Bell
} from "lucide-react";
import { 
  FeeConfigItem, 
  FeeAuditLog, 
  getAllFeeConfigs, 
  subscribeFeeConfigChanges, 
  updateFeeConfigInService, 
  getAuditLogsFromService 
} from "../services/feeConfigService";
import { 
  V3_PLANS, 
  IN_APP_TOPUP_BUNDLES, 
  SUBSCRIPTION_TERMS, 
  calculatePlanTermPrice,
  PlanDefinitionV3,
  PreDueReminderLogV3,
  MonthlyStatementLogV3,
  SubscriptionRecordV3
} from "../config/creditEngineV3";
import { 
  getPreDueReminderLeadDays, 
  setPreDueReminderLeadDays,
  getSupplierReportFeeRate,
  setSupplierReportFeeRate,
  getAllPlanDefinitions,
  updatePlanDefinitionInService,
  runInvoiceReminderAndStatementCycle,
  getPreDueReminderLogs,
  getMonthlyStatementLogs,
  getAllV3Subscriptions
} from "../services/creditEngineV3Service";
import { db } from "../firebase";

interface FeeManagementPanelProps {
  userEmail?: string;
  isSuperAdmin?: boolean;
}

export default function FeeManagementPanel({ userEmail = "admin@mabala.cloud", isSuperAdmin = true }: FeeManagementPanelProps) {
  const [activeTab, setActiveTab] = useState<"platform_fees" | "v3_plans" | "invoice_reminders" | "subscriptions_queue">("platform_fees");
  
  // Platform fees state
  const [feeConfigs, setFeeConfigs] = useState<FeeConfigItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<FeeAuditLog[]>([]);
  const [editingKey, setEditingKey] = useState<string | null>(null);
  
  // Form draft state for platform fees
  const [draftValue, setDraftValue] = useState<number>(0);
  const [draftType, setDraftType] = useState<"percentage" | "flat">("percentage");
  const [draftActive, setDraftActive] = useState<boolean>(true);
  const [draftNotes, setDraftNotes] = useState<string>("");

  // Confirmation modal state
  const [confirmItem, setConfirmItem] = useState<{
    feeKey: string;
    item: FeeConfigItem;
    newValue: number;
    newType: "percentage" | "flat";
    active: boolean;
    notes: string;
  } | null>(null);

  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Section 10 & v3 Config State
  const [reminderLeadDays, setReminderLeadDays] = useState<number>(getPreDueReminderLeadDays());
  const [supplierReportFee, setSupplierReportFee] = useState<number>(getSupplierReportFeeRate());
  const [isSavingSettings, setIsSavingSettings] = useState<boolean>(false);

  // Section 10 Scanner Logs & State
  const [preDueLogs, setPreDueLogs] = useState<PreDueReminderLogV3[]>([]);
  const [statementLogs, setStatementLogs] = useState<MonthlyStatementLogV3[]>([]);
  const [runningScanner, setRunningScanner] = useState<boolean>(false);
  const [scannerResultMsg, setScannerResultMsg] = useState<string | null>(null);

  // Subscriptions List
  const [subscriptionsList, setSubscriptionsList] = useState<SubscriptionRecordV3[]>([]);

  // v3 Plan Definitions Live Customization State
  const [plansList, setPlansList] = useState<PlanDefinitionV3[]>(() => getAllPlanDefinitions());
  const [editingPlanId, setEditingPlanId] = useState<string | null>(null);
  const [planDraft, setPlanDraft] = useState<{
    name: string;
    monthlyPriceZMW: number;
    monthlyCredits: number;
    yearlyDiscountPercent: number;
    featuresSummary: string;
  }>({
    name: "",
    monthlyPriceZMW: 0,
    monthlyCredits: 0,
    yearlyDiscountPercent: 0,
    featuresSummary: ""
  });
  const [isSavingPlan, setIsSavingPlan] = useState(false);
  const [planSuccessMsg, setPlanSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    const unsub = subscribeFeeConfigChanges((configs) => {
      setFeeConfigs(configs);
      setAuditLogs(getAuditLogsFromService());
    });

    setPreDueLogs(getPreDueReminderLogs());
    setStatementLogs(getMonthlyStatementLogs());
    setSubscriptionsList(getAllV3Subscriptions());

    return () => unsub();
  }, []);

  const handleSaveReminderAndReportFee = async () => {
    setIsSavingSettings(true);
    try {
      await setPreDueReminderLeadDays(reminderLeadDays, db);
      await setSupplierReportFeeRate(supplierReportFee, db);
      setSuccessMsg("Updated Pre-Due Reminder Lead Days & Supplier Per-Report Access Fee live!");
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (e: any) {
      alert("Failed to save settings: " + (e.message || e));
    } finally {
      setIsSavingSettings(false);
    }
  };

  const handleRunDailyCycleScanner = async () => {
    setRunningScanner(true);
    setScannerResultMsg(null);
    try {
      const res = await runInvoiceReminderAndStatementCycle(db);
      setPreDueLogs(getPreDueReminderLogs());
      setStatementLogs(getMonthlyStatementLogs());
      setScannerResultMsg(
        `Cycle completed: Scanned ${res.scannedSubscriptionsCount} accounts. Dispatched ${res.preDueRemindersDispatched} pre-due renewal reminders (${res.leadDays} days lead time) and ${res.monthlyStatementsDispatched} monthly statements across Email, SMS, and in-app channels.`
      );
      setTimeout(() => setScannerResultMsg(null), 8000);
    } catch (e: any) {
      alert("Failed to run automated cycle scanner: " + (e.message || e));
    } finally {
      setRunningScanner(false);
    }
  };

  const handleStartEditPlan = (plan: PlanDefinitionV3) => {
    setEditingPlanId(plan.id);
    setPlanDraft({
      name: plan.name,
      monthlyPriceZMW: plan.monthlyPriceZMW,
      monthlyCredits: plan.monthlyCredits,
      yearlyDiscountPercent: plan.yearlyDiscountPercent || 0,
      featuresSummary: plan.featuresSummary
    });
  };

  const handleSavePlanDefinition = async () => {
    if (!editingPlanId) return;
    setIsSavingPlan(true);
    try {
      const updated = await updatePlanDefinitionInService(
        editingPlanId,
        {
          name: planDraft.name,
          monthlyPriceZMW: Number(planDraft.monthlyPriceZMW),
          monthlyCredits: Number(planDraft.monthlyCredits),
          yearlyDiscountPercent: Number(planDraft.yearlyDiscountPercent) > 0 ? Number(planDraft.yearlyDiscountPercent) : undefined,
          featuresSummary: planDraft.featuresSummary
        },
        db,
        userEmail,
        `Super Admin modified plan ${editingPlanId} live parameters`
      );
      setPlansList(updated);
      setPlanSuccessMsg(`Plan "${editingPlanId}" updated successfully in Firestore & live runtime without deployment!`);
      setEditingPlanId(null);
      setTimeout(() => setPlanSuccessMsg(null), 5000);
    } catch (e: any) {
      alert("Error saving plan definition: " + (e.message || e));
    } finally {
      setIsSavingPlan(false);
    }
  };

  const handleStartEdit = (item: FeeConfigItem) => {
    setEditingKey(item.feeKey);
    setDraftValue(item.value);
    setDraftType(item.type);
    setDraftActive(item.active);
    setDraftNotes("");
  };

  const handleCancelEdit = () => {
    setEditingKey(null);
    setDraftNotes("");
  };

  const handleRequestSave = (item: FeeConfigItem) => {
    setConfirmItem({
      feeKey: item.feeKey,
      item,
      newValue: draftValue,
      newType: draftType,
      active: draftActive,
      notes: draftNotes || "Super Admin policy update",
    });
  };

  const handleConfirmSave = async () => {
    if (!confirmItem) return;
    setSaving(true);
    try {
      await updateFeeConfigInService(
        confirmItem.feeKey,
        confirmItem.newValue,
        confirmItem.newType,
        confirmItem.active,
        userEmail,
        confirmItem.notes
      );
      setSuccessMsg(`Successfully updated ${confirmItem.item.name} to ${confirmItem.newValue}${confirmItem.newType === "percentage" ? "%" : " ZMW"}.`);
      setEditingKey(null);
      setConfirmItem(null);
      setAuditLogs(getAuditLogsFromService());
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (e: any) {
      alert(`Failed to update fee config: ${e.message || e}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 text-slate-900 font-sans animate-fade-in">
      {/* HEADER BANNER */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-lg text-xs font-mono font-bold">
              PLATFORM-FEE-CTRL-01
            </span>
            <span className="text-[10px] font-black uppercase text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
              Super Admin Auth Required
            </span>
          </div>
          <h2 className="text-xl font-black tracking-tight text-white mt-1">
            Mabala Centralized Fee & Billing Configuration Engine
          </h2>
          <p className="text-xs text-slate-400 font-medium mt-1 max-w-2xl">
            Configure global marketplace buyer fees, payment gateway rates, Section 10 Monthly Invoice Reminders, and Supplier per-report pricing in real time.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-2 rounded-xl border border-slate-700 text-xs font-mono text-slate-300">
          <Lock className="w-4 h-4 text-emerald-400" />
          <span>Audit Logged & Dynamic</span>
        </div>
      </div>

      {/* TOP NAVIGATION TABS */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab("platform_fees")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "platform_fees"
              ? "bg-slate-900 text-white shadow-sm"
              : "bg-slate-100 text-slate-600 hover:bg-slate-200"
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Marketplace & Gateway Fees</span>
        </button>

        <button
          onClick={() => setActiveTab("v3_plans")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "v3_plans"
              ? "bg-slate-900 text-white shadow-sm"
              : "bg-slate-100 text-slate-600 hover:bg-slate-200"
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>v3.0 Subscription Plans Catalog</span>
        </button>

        <button
          onClick={() => setActiveTab("invoice_reminders")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "invoice_reminders"
              ? "bg-slate-900 text-white shadow-sm"
              : "bg-slate-100 text-slate-600 hover:bg-slate-200"
          }`}
        >
          <Mail className="w-4 h-4 text-amber-400" />
          <span>Section 10 Monthly Invoices & Statements</span>
        </button>

        <button
          onClick={() => setActiveTab("subscriptions_queue")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "subscriptions_queue"
              ? "bg-slate-900 text-white shadow-sm"
              : "bg-slate-100 text-slate-600 hover:bg-slate-200"
          }`}
        >
          <UserCheck className="w-4 h-4 text-emerald-400" />
          <span>Active Subscriptions & Cancellation Queue</span>
        </button>
      </div>

      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl text-xs font-bold flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{successMsg}</span>
          </div>
          <button onClick={() => setSuccessMsg(null)} className="text-emerald-700 hover:text-emerald-900">✕</button>
        </div>
      )}

      {scannerResultMsg && (
        <div className="bg-indigo-50 border border-indigo-200 text-indigo-800 p-4 rounded-xl text-xs font-bold flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-indigo-600" />
            <span>{scannerResultMsg}</span>
          </div>
          <button onClick={() => setScannerResultMsg(null)} className="text-indigo-700 hover:text-indigo-900">✕</button>
        </div>
      )}

      {/* TAB 1: PLATFORM FEES */}
      {activeTab === "platform_fees" && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {feeConfigs.map((item) => {
              const isEditing = editingKey === item.feeKey;
              return (
                <div 
                  key={item.feeKey} 
                  className={`bg-white rounded-2xl border p-5 shadow-xs transition-all flex flex-col justify-between space-y-4 ${
                    isEditing ? "border-indigo-500 ring-2 ring-indigo-500/20" : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold uppercase text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                        {item.feeKey}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        item.active ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"
                      }`}>
                        {item.active ? "Active" : "Disabled"}
                      </span>
                    </div>

                    <h3 className="font-black text-sm text-slate-900">{item.name}</h3>
                    <p className="text-xs text-slate-500 leading-relaxed font-medium">{item.description}</p>
                  </div>

                  {isEditing ? (
                    <div className="p-4 bg-slate-50 rounded-xl space-y-3 border border-indigo-100">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                            Fee Value
                          </label>
                          <input
                            type="number"
                            step="0.01"
                            value={draftValue}
                            onChange={(e) => setDraftValue(parseFloat(e.target.value) || 0)}
                            className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                            Type
                          </label>
                          <select
                            value={draftType}
                            onChange={(e) => setDraftType(e.target.value as "percentage" | "flat")}
                            className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1.5 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                          >
                            <option value="percentage">Percentage (%)</option>
                            <option value="flat">Flat Kwacha (ZMW)</option>
                          </select>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          id={`active-${item.feeKey}`}
                          checked={draftActive}
                          onChange={(e) => setDraftActive(e.target.checked)}
                          className="w-3.5 h-3.5 text-indigo-600 rounded"
                        />
                        <label htmlFor={`active-${item.feeKey}`} className="text-xs font-bold text-slate-700">
                          Enable this fee in live calculations
                        </label>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                          Reason / Audit Notes
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Q3 merchant fee policy adjustment"
                          value={draftNotes}
                          onChange={(e) => setDraftNotes(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                        />
                      </div>

                      <div className="flex gap-2 pt-2 border-t border-slate-200">
                        <button
                          onClick={() => handleRequestSave(item)}
                          className="flex-1 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>Review & Apply</span>
                        </button>
                        <button
                          onClick={handleCancelEdit}
                          className="py-1.5 px-3 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-lg transition-all cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">Current Rate</span>
                        <div className="flex items-baseline gap-1 font-mono font-black text-xl text-slate-900">
                          {item.type === "percentage" ? `${item.value}%` : `K${item.value.toFixed(2)}`}
                          <span className="text-[10px] font-sans font-bold text-slate-400">
                            {item.type === "percentage" ? "of transaction" : "per transaction"}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleStartEdit(item)}
                        className="py-1.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-all cursor-pointer"
                      >
                        Configure
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* AUDIT LOG TABLE */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-indigo-600" />
                <h3 className="font-black text-base text-slate-800">Fee Configuration Policy Audit Trail</h3>
              </div>
              <span className="text-xs font-mono text-slate-500">{auditLogs.length} logged events</span>
            </div>

            {auditLogs.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">No fee changes recorded yet. Initial defaults are currently active.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs bg-white text-slate-800">
                  <thead className="bg-slate-50 text-[9px] font-black uppercase text-slate-400 border-b border-slate-200">
                    <tr>
                      <th className="p-3">Timestamp</th>
                      <th className="p-3">Fee Key</th>
                      <th className="p-3">Old Value</th>
                      <th className="p-3">New Value</th>
                      <th className="p-3">Modified By</th>
                      <th className="p-3">Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {auditLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50">
                        <td className="p-3 font-mono text-slate-500">
                          {new Date(log.updatedAt).toLocaleString()}
                        </td>
                        <td className="p-3 font-mono font-bold text-slate-900">{log.feeKey}</td>
                        <td className="p-3 font-mono text-rose-600 font-bold">
                          {log.oldType === "percentage" ? `${log.oldValue}%` : `K${log.oldValue}`}
                        </td>
                        <td className="p-3 font-mono text-emerald-700 font-black">
                          {log.newType === "percentage" ? `${log.newValue}%` : `K${log.newValue}`}
                        </td>
                        <td className="p-3 text-slate-700 font-bold">{log.updatedBy}</td>
                        <td className="p-3 text-slate-500 italic max-w-xs truncate">{log.notes || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      {/* TAB 2: V3.0 SUBSCRIPTION PLANS CATALOG & LIVE CONFIGURATION */}
      {activeTab === "v3_plans" && (
        <div className="space-y-6">
          <div className="bg-indigo-50 border border-indigo-200 p-4 rounded-2xl flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <Layers className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
              <div className="text-xs text-indigo-950 space-y-1">
                <p className="font-bold">v3.0 Platform Plan Architecture & Live Definition Editor</p>
                <p className="text-indigo-800">
                  Super Admins can dynamically reconfigure plan prices (ZMW), monthly write credits, discount percentages, and feature tiers live in Firestore without requiring a codebase deployment.
                </p>
              </div>
            </div>
            <button
              onClick={() => setPlansList(getAllPlanDefinitions())}
              className="px-3 py-1 bg-white border border-indigo-200 hover:bg-indigo-100/50 text-indigo-900 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 shrink-0 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reload Definitions</span>
            </button>
          </div>

          {planSuccessMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{planSuccessMsg}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {plansList.map((plan) => {
              const isEditing = editingPlanId === plan.id;

              return (
                <div key={plan.id} className={`bg-white rounded-2xl border p-5 space-y-4 shadow-sm flex flex-col justify-between transition-all ${
                  isEditing ? "border-indigo-500 ring-2 ring-indigo-500/20 bg-indigo-50/20" : "border-slate-200"
                }`}>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold uppercase text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                        {plan.id}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        plan.showOnMarketingPage ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                      }`}>
                        {plan.showOnMarketingPage ? "Public Tier" : "In-App Pass"}
                      </span>
                    </div>

                    {isEditing ? (
                      <div className="space-y-3 pt-2">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase text-slate-500">Plan Display Name</label>
                          <input
                            type="text"
                            value={planDraft.name}
                            onChange={(e) => setPlanDraft({ ...planDraft, name: e.target.value })}
                            className="w-full bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900 outline-none focus:border-indigo-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase text-slate-500">Monthly Price (ZMW)</label>
                          <input
                            type="number"
                            min="0"
                            value={planDraft.monthlyPriceZMW}
                            onChange={(e) => setPlanDraft({ ...planDraft, monthlyPriceZMW: parseFloat(e.target.value) || 0 })}
                            className="w-full bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-mono font-bold text-slate-900 outline-none focus:border-indigo-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase text-slate-500">Monthly Write Credits</label>
                          <input
                            type="number"
                            min="0"
                            value={planDraft.monthlyCredits}
                            onChange={(e) => setPlanDraft({ ...planDraft, monthlyCredits: parseInt(e.target.value) || 0 })}
                            className="w-full bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-mono font-bold text-slate-900 outline-none focus:border-indigo-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase text-slate-500">Yearly Discount (%)</label>
                          <input
                            type="number"
                            min="0"
                            max="50"
                            value={planDraft.yearlyDiscountPercent}
                            onChange={(e) => setPlanDraft({ ...planDraft, yearlyDiscountPercent: parseInt(e.target.value) || 0 })}
                            className="w-full bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-mono font-bold text-slate-900 outline-none focus:border-indigo-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase text-slate-500">Features Summary</label>
                          <textarea
                            rows={2}
                            value={planDraft.featuresSummary}
                            onChange={(e) => setPlanDraft({ ...planDraft, featuresSummary: e.target.value })}
                            className="w-full bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs text-slate-900 outline-none focus:border-indigo-500"
                          />
                        </div>

                        <div className="pt-2 flex gap-2">
                          <button
                            disabled={isSavingPlan}
                            onClick={handleSavePlanDefinition}
                            className="flex-1 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
                          >
                            {isSavingPlan ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                            <span>Save Live</span>
                          </button>
                          <button
                            disabled={isSavingPlan}
                            onClick={() => setEditingPlanId(null)}
                            className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <h3 className="font-black text-base text-slate-900">{plan.name}</h3>
                        <p className="text-xs text-slate-500 font-medium">{plan.featuresSummary}</p>

                        <div className="py-2 border-y border-slate-100 space-y-1 font-mono">
                          <div className="text-xs text-slate-700 flex justify-between">
                            <span>Monthly Base:</span>
                            <span className="font-bold">ZMW {plan.monthlyPriceZMW.toLocaleString()}</span>
                          </div>
                          <div className="text-xs text-slate-700 flex justify-between">
                            <span>Credits / Mo:</span>
                            <span className="font-bold">{plan.monthlyCredits.toLocaleString()}</span>
                          </div>
                          {plan.yearlyDiscountPercent && (
                            <div className="text-xs text-emerald-700 font-bold flex justify-between">
                              <span>Yearly Upfront:</span>
                              <span>{plan.yearlyDiscountPercent}% Off</span>
                            </div>
                          )}
                        </div>

                        <div className="space-y-1 text-[11px] text-slate-600">
                          <p className="font-bold text-slate-800">Calculated Terms:</p>
                          <p>• 1 Month: ZMW {plan.monthlyPriceZMW.toLocaleString()}</p>
                          <p>• 3 Months: ZMW {(plan.monthlyPriceZMW * 3).toLocaleString()}</p>
                          <p>• 6 Months: ZMW {(plan.monthlyPriceZMW * 6).toLocaleString()}</p>
                          <p className="font-bold text-emerald-700">
                            • 12 Months: ZMW {calculatePlanTermPrice(plan, 12).totalPriceZMW.toLocaleString()} 
                            {plan.yearlyDiscountPercent ? ` (${plan.yearlyDiscountPercent}% off)` : ""}
                          </p>
                        </div>
                      </>
                    )}
                  </div>

                  {!isEditing && (
                    <div className="space-y-3 pt-2">
                      <div className="p-2 bg-slate-50 rounded-xl text-[10px] text-slate-500 font-mono">
                        Advisory: {plan.advisoryVisitsIncluded ? `${plan.advisoryVisitsIncluded.agronomist} Agro / ${plan.advisoryVisitsIncluded.veterinary} Vet visits/mo` : "None"}
                      </div>
                      <button
                        onClick={() => handleStartEditPlan(plan)}
                        className="w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Sliders className="w-3.5 h-3.5 text-slate-500" />
                        <span>Configure Plan Parameters</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
            <h3 className="font-black text-sm text-slate-900 uppercase tracking-tight">In-App Credit Top-Up Bundles</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {IN_APP_TOPUP_BUNDLES.map(b => (
                <div key={b.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-mono font-bold text-slate-400">{b.id}</span>
                  <h4 className="font-bold text-xs text-slate-900">{b.name}</h4>
                  <p className="font-mono font-black text-sm text-emerald-700">ZMW {b.priceZMW}</p>
                  <p className="text-[11px] text-slate-500">{b.isUnmetered ? "24h Unmetered Pass" : `+${b.credits} credits`}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: SECTION 10 INVOICE REMINDERS & STATEMENTS */}
      {activeTab === "invoice_reminders" && (
        <div className="space-y-6">
          {/* CONFIGURATION ROW */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <Clock className="w-5 h-5 text-amber-600" />
                <div>
                  <h3 className="font-black text-sm text-slate-900">Pre-Due Reminder Lead Time</h3>
                  <p className="text-xs text-slate-500">Days before renewal to dispatch pre-due notice (Section 10.3)</p>
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700">
                  Lead Time (Days):
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    min="1"
                    max="14"
                    value={reminderLeadDays}
                    onChange={(e) => setReminderLeadDays(Math.max(1, parseInt(e.target.value) || 3))}
                    className="w-28 bg-white border border-slate-300 rounded-xl px-3 py-2 text-sm font-mono font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                  <span className="text-xs text-slate-500 font-medium">
                    (PRD Default: 3 days before renewal date)
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 italic">
                  Note: Excluded from Seeding (free), Daily Bundle, and 12-month upfront Yearly plans.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <Building2 className="w-5 h-5 text-indigo-600" />
                <div>
                  <h3 className="font-black text-sm text-slate-900">Supplier Report Access Fee Rate</h3>
                  <p className="text-xs text-slate-500">Flat fee charged per unlocked report (Section 5.2)</p>
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700">
                  Access Fee Rate (ZMW):
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    min="0"
                    step="5"
                    value={supplierReportFee}
                    onChange={(e) => setSupplierReportFee(Math.max(0, parseFloat(e.target.value) || 50))}
                    className="w-28 bg-white border border-slate-300 rounded-xl px-3 py-2 text-sm font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                  <span className="text-xs text-slate-500 font-medium">
                    Kwacha per report unlocked via Lipila API
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 italic">
                  Suppliers hold zero credit balance and pay flat per-report fee.
                </p>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center bg-slate-100 p-4 rounded-2xl border border-slate-200">
            <div className="text-xs text-slate-600">
              Apply updated lead days and supplier fee rates across all client and server billing modules without app redeployment.
            </div>
            <button
              disabled={isSavingSettings}
              onClick={handleSaveReminderAndReportFee}
              className="py-2.5 px-5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-black rounded-xl transition-all flex items-center gap-2 cursor-pointer shadow-sm"
            >
              {isSavingSettings ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              <span>Save Configuration Policy</span>
            </button>
          </div>

          {/* AUTOMATED SCANNER RUNNER */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-4">
              <div>
                <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
                  <Send className="w-4 h-4 text-emerald-600" />
                  <span>Automated Daily Invoice & Monthly Statement Scanner</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Scans active subscribers and suppliers, dispatches Section 10 Pre-Due Reminders and Monthly Statements across Email (Firebase Trigger Email), SMS (Mobile Money SMS Gateway), and In-App notification channels.
                </p>
              </div>

              <button
                disabled={runningScanner}
                onClick={handleRunDailyCycleScanner}
                className="py-2.5 px-5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl transition-all flex items-center gap-2 cursor-pointer shadow-md shadow-emerald-600/20 shrink-0"
              >
                {runningScanner ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                <span>Execute Scan Cycle Now</span>
              </button>
            </div>

            {/* LOGS TABS */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-600">
                  Live Outbox Dispatch History ({preDueLogs.length + statementLogs.length} total events)
                </h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Pre-Due Reminders Column */}
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-amber-600" />
                      <span>Pre-Due Reminders Sent</span>
                    </span>
                    <span className="text-[10px] font-mono bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded">
                      {preDueLogs.length} logged
                    </span>
                  </div>

                  {preDueLogs.length === 0 ? (
                    <p className="text-xs text-slate-400 py-3 text-center italic">No pre-due reminders dispatched yet.</p>
                  ) : (
                    <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                      {preDueLogs.map((log) => (
                        <div key={log.id} className="bg-white p-3 rounded-lg border border-slate-200 text-xs space-y-1">
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-slate-900">{log.tenantName}</span>
                            <span className="font-mono text-emerald-700 font-bold">ZMW {log.amountDueZMW.toLocaleString()}</span>
                          </div>
                          <p className="text-[11px] text-slate-500">
                            {log.planName} ({log.termMonths} Mo) · Due: {log.dueDate}
                          </p>
                          <div className="flex gap-2 text-[10px] font-mono text-slate-400 pt-1">
                            <span className="text-emerald-600 font-bold">✓ Email</span>
                            <span className="text-emerald-600 font-bold">✓ SMS</span>
                            <span className="text-emerald-600 font-bold">✓ In-App</span>
                            <span className="ml-auto">{new Date(log.sentAt).toLocaleTimeString()}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Monthly Statements Column */}
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-indigo-600" />
                      <span>Monthly Statements Sent</span>
                    </span>
                    <span className="text-[10px] font-mono bg-indigo-100 text-indigo-800 font-bold px-2 py-0.5 rounded">
                      {statementLogs.length} logged
                    </span>
                  </div>

                  {statementLogs.length === 0 ? (
                    <p className="text-xs text-slate-400 py-3 text-center italic">No monthly statements dispatched yet.</p>
                  ) : (
                    <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                      {statementLogs.map((log) => (
                        <div key={log.id} className="bg-white p-3 rounded-lg border border-slate-200 text-xs space-y-1">
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-slate-900">{log.tenantName}</span>
                            <span className="text-[10px] font-mono uppercase bg-slate-100 px-1.5 py-0.5 rounded font-bold text-slate-600">
                              {log.role}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500">
                            Period: {log.statementPeriod} · {log.role === "SUPPLIER" ? `${log.reportsAccessedCount || 0} reports accessed (K${log.totalReportFeesChargedZMW || 0})` : `${log.creditsRemaining?.toLocaleString() || 0} credits balance`}
                          </p>
                          <div className="flex gap-2 text-[10px] font-mono text-slate-400 pt-1">
                            <span className="text-emerald-600 font-bold">✓ Email</span>
                            <span className="text-emerald-600 font-bold">✓ SMS</span>
                            <span className="text-emerald-600 font-bold">✓ In-App</span>
                            <span className="ml-auto">{new Date(log.sentAt).toLocaleTimeString()}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: ACTIVE SUBSCRIPTIONS & CANCELLATION/REFUND QUEUE */}
      {activeTab === "subscriptions_queue" && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-indigo-600" />
                  <span>Platform Subscriptions & State Machine</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  States: ACTIVE, READ_ONLY, WELCOME_EXHAUSTED, EXPIRED, CANCELLED, PENDING_PAYMENT
                </p>
              </div>
              <span className="text-xs font-mono text-slate-500">{subscriptionsList.length} total subscriptions</span>
            </div>

            {subscriptionsList.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center italic">
                No subscription records found in store. New purchases via Lipila API will register here.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs bg-white text-slate-800">
                  <thead className="bg-slate-50 text-[9px] font-black uppercase text-slate-400 border-b border-slate-200">
                    <tr>
                      <th className="p-3">Reference / Plan</th>
                      <th className="p-3">Subscriber</th>
                      <th className="p-3">Term</th>
                      <th className="p-3">Amount</th>
                      <th className="p-3">Credits</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Refund Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {subscriptionsList.map((sub) => (
                      <tr key={sub.id} className="hover:bg-slate-50">
                        <td className="p-3">
                          <p className="font-bold text-slate-900">{sub.planName}</p>
                          <p className="text-[10px] font-mono text-slate-400">{sub.referenceId}</p>
                        </td>
                        <td className="p-3">
                          <p className="font-bold text-slate-800">{sub.tenantName}</p>
                          <p className="text-[10px] text-slate-400">{sub.customerPhone}</p>
                        </td>
                        <td className="p-3 font-mono">{sub.termMonths} Mo</td>
                        <td className="p-3 font-mono font-bold text-slate-900">ZMW {sub.priceZMW.toLocaleString()}</td>
                        <td className="p-3 font-mono text-emerald-700 font-bold">
                          {sub.creditsAllocatedTotal.toLocaleString()}
                        </td>
                        <td className="p-3">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            sub.status === "ACTIVE" 
                              ? "bg-emerald-100 text-emerald-800" 
                              : sub.status === "CANCELLED" 
                              ? "bg-rose-100 text-rose-800"
                              : "bg-amber-100 text-amber-800"
                          }`}>
                            {sub.status}
                          </span>
                        </td>
                        <td className="p-3">
                          {sub.refundStatus === "REQUESTED_SUPER_ADMIN_MANUAL" ? (
                            <span className="text-[10px] font-bold bg-amber-100 text-amber-900 px-2 py-0.5 rounded border border-amber-300">
                              Manual Review Required
                            </span>
                          ) : (
                            <span className="text-[10px] text-slate-400 font-mono">None</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* CONFIRMATION MODAL FOR PLATFORM FEES */}
      {confirmItem && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 animate-scale-up">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900">Confirm Live Policy Modification</h3>
                <p className="text-xs text-slate-500 font-medium">This change takes effect immediately across all transactions.</p>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">Fee Name:</span>
                <span className="text-slate-900 font-bold">{confirmItem.item.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">Current Setting:</span>
                <span className="text-slate-700 font-mono">
                  {confirmItem.item.type === "percentage" ? `${confirmItem.item.value}%` : `K${confirmItem.item.value.toFixed(2)}`}
                </span>
              </div>
              <div className="flex justify-between font-bold text-indigo-700">
                <span>Proposed New Setting:</span>
                <span className="font-mono text-sm">
                  {confirmItem.newType === "percentage" ? `${confirmItem.newValue}%` : `K${confirmItem.newValue.toFixed(2)}`}
                </span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-200 text-slate-600">
                <span className="font-medium">Audit Note:</span>
                <span className="text-slate-800 font-mono italic">{confirmItem.notes}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                disabled={saving}
                onClick={handleConfirmSave}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow transition-all flex justify-center items-center gap-2 cursor-pointer"
              >
                {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                <span>Confirm & Apply Live Policy</span>
              </button>
              <button
                disabled={saving}
                onClick={() => setConfirmItem(null)}
                className="py-2.5 px-4 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

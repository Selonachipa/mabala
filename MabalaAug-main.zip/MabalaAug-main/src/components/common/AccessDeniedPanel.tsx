import React from "react";
import { Shield } from "lucide-react";

interface AccessDeniedPanelProps {
  moduleName: string;
  currentRole: string;
  adminClaimed?: boolean;
  adminClaimantEmail?: string;
  userEmail?: string;
  onNavigateDashboard: () => void;
  onElevateToAdmin?: () => void;
}

export const AccessDeniedPanel: React.FC<AccessDeniedPanelProps> = ({
  moduleName,
  currentRole,
  adminClaimed,
  adminClaimantEmail,
  userEmail,
  onNavigateDashboard,
  onElevateToAdmin,
}) => {
  return (
    <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center max-w-xl mx-auto my-12 shadow-sm space-y-6 animate-fade-in font-sans" id="access-denied-panel">
      <div className="w-16 h-16 bg-rose-50 border border-rose-200 text-rose-500 rounded-2xl flex items-center justify-center mx-auto shadow-sm">
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
          <path d="M7 11V7a5 5 0 0110 0v4" />
        </svg>
      </div>
      <div className="space-y-2">
        <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">Access Restricted: Permission Required</h3>
        <p className="text-slate-500 text-xs leading-relaxed max-w-sm mx-auto">
          Your current membership group <strong>({currentRole})</strong> does not possess read access to the <strong>{moduleName}</strong> module.
        </p>
      </div>
      <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row justify-center gap-3 text-xs font-bold">
        <button 
          type="button"
          onClick={onNavigateDashboard} 
          className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-all cursor-pointer"
        >
          Return to Dashboard
        </button>
        {onElevateToAdmin && (!adminClaimed || (adminClaimantEmail && userEmail === adminClaimantEmail)) && (
          <button 
            type="button"
            onClick={onElevateToAdmin} 
            className="px-4 py-2 bg-purple-650 hover:bg-purple-600 text-white rounded-lg transition-all flex items-center justify-center gap-1.5 leading-none shadow-md shadow-purple-500/10 cursor-pointer border border-purple-700"
          >
            <Shield className="w-3.5 h-3.5 text-purple-200" />
            <span>Elevate to Platform Administrator</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default AccessDeniedPanel;

import React, { useState, useMemo } from "react";
import { 
  getAvailableCommodityCategories, 
  CommodityCategoryItem 
} from "../../utils/commodityCategoryHelper";
import { CropCycle, LivestockRecord, PoultryBatch } from "../../types";
import { 
  ChevronDown, 
  Search, 
  Check, 
  Sparkles, 
  Plus, 
  Layers, 
  TreePine, 
  Tractor, 
  X,
  Milk,
  Egg,
  Fish
} from "lucide-react";

export interface CommodityCategorySelectorProps {
  value: string;
  onChange: (commodityName: string, selectedItem?: CommodityCategoryItem) => void;
  onSelectDetails?: (details: {
    commodityName: string;
    unit?: string;
    grade?: string;
    suggestedQuantity?: number;
    sourceType?: string;
    sourceName?: string;
  }) => void;
  crops?: CropCycle[];
  livestock?: LivestockRecord[];
  poultryBatches?: PoultryBatch[];
  tenantId?: string;
  placeholder?: string;
  required?: boolean;
  className?: string;
  id?: string;
  label?: string;
  helperText?: string;
  showSourceBadges?: boolean;
}

export const CommodityCategorySelector: React.FC<CommodityCategorySelectorProps> = ({
  value,
  onChange,
  onSelectDetails,
  crops,
  livestock,
  poultryBatches,
  tenantId,
  placeholder = "Select or search product / commodity...",
  required = false,
  className = "",
  id = "commodity-category-selector",
  label,
  helperText,
  showSourceBadges = true
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isCustomMode, setIsCustomMode] = useState(false);
  const [customInput, setCustomInput] = useState("");
  const [activeSourceFilter, setActiveSourceFilter] = useState<string>("ALL");

  const { all, bySource, byCategory } = useMemo(() => {
    return getAvailableCommodityCategories({
      crops,
      livestock,
      poultryBatches,
      tenantId,
      includeStandardFallbacks: true
    });
  }, [crops, livestock, poultryBatches, tenantId]);

  // Filter items based on search and source filter
  const filteredItems = useMemo(() => {
    return all.filter((item) => {
      if (activeSourceFilter !== "ALL" && item.sourceType !== activeSourceFilter) {
        return false;
      }
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        item.commodityName.toLowerCase().includes(q) ||
        item.label.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        (item.sourceName || "").toLowerCase().includes(q)
      );
    });
  }, [all, searchQuery, activeSourceFilter]);

  const selectedItem = useMemo(() => {
    return all.find((i) => i.commodityName.toLowerCase() === (value || "").toLowerCase() || i.label === value);
  }, [all, value]);

  const handleSelectItem = (item: CommodityCategoryItem) => {
    onChange(item.commodityName, item);
    if (onSelectDetails) {
      onSelectDetails({
        commodityName: item.commodityName,
        unit: item.defaultUnit,
        grade: item.defaultGrade,
        suggestedQuantity: item.currentQuantity,
        sourceType: item.sourceType,
        sourceName: item.sourceName
      });
    }
    setIsOpen(false);
    setSearchQuery("");
    setIsCustomMode(false);
  };

  const handleApplyCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim()) return;
    const name = customInput.trim();
    onChange(name, {
      id: `custom-${Date.now()}`,
      label: name,
      commodityName: name,
      category: "Custom Farm Commodity",
      sourceType: "standard",
      defaultUnit: "Kgs"
    });
    if (onSelectDetails) {
      onSelectDetails({
        commodityName: name,
        unit: "Kgs",
        sourceType: "custom"
      });
    }
    setIsOpen(false);
    setIsCustomMode(false);
    setCustomInput("");
  };

  const getSourceIcon = (sourceType: string) => {
    switch (sourceType) {
      case "crop_cycle":
        return "🌾";
      case "orchard_block":
        return "🌳";
      case "livestock":
        return "🐂";
      case "poultry":
        return "🐔";
      case "dairy":
        return "🥛";
      case "aquaculture":
        return "🐟";
      default:
        return "📦";
    }
  };

  const getSourceBadge = (sourceType: string) => {
    switch (sourceType) {
      case "crop_cycle":
        return <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-amber-50 text-amber-800 border border-amber-200">Crop Cycle</span>;
      case "orchard_block":
        return <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-emerald-50 text-emerald-800 border border-emerald-200">Orchard Block</span>;
      case "livestock":
        return <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-indigo-50 text-indigo-800 border border-indigo-200">Livestock Herd</span>;
      case "poultry":
        return <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-orange-50 text-orange-800 border border-orange-200">Poultry Batch</span>;
      case "dairy":
        return <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-blue-50 text-blue-800 border border-blue-200">Milk / Dairy</span>;
      default:
        return <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-slate-100 text-slate-600">Standard Commodity</span>;
    }
  };

  return (
    <div className={`space-y-1 relative font-sans ${className}`} id={id}>
      {label && (
        <div className="flex items-center justify-between">
          <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
            <span>{label}</span>
            {required && <span className="text-rose-500">*</span>}
          </label>
          <span className="text-[9px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
            Linked to Farm Enterprises
          </span>
        </div>
      )}

      {/* Main Select Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full border border-slate-200 bg-slate-50 hover:bg-white focus:bg-white rounded-xl p-2.5 text-xs text-left font-bold text-slate-800 flex items-center justify-between gap-2 transition cursor-pointer shadow-2xs focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
      >
        <div className="flex items-center gap-2 truncate">
          {selectedItem ? (
            <>
              <span className="text-sm">{selectedItem.icon || getSourceIcon(selectedItem.sourceType)}</span>
              <span className="truncate text-slate-900">{selectedItem.commodityName}</span>
              {showSourceBadges && getSourceBadge(selectedItem.sourceType)}
            </>
          ) : value ? (
            <span className="text-slate-800 font-bold truncate">{value}</span>
          ) : (
            <span className="text-slate-400 font-normal">{placeholder}</span>
          )}
        </div>
        <ChevronDown className={`w-4 h-4 text-slate-400 shrink-0 transition-transform ${isOpen ? "rotate-180 text-indigo-600" : ""}`} />
      </button>

      {helperText && <p className="text-[10px] text-slate-400 font-medium">{helperText}</p>}

      {/* Dropdown Menu Modal */}
      {isOpen && (
        <>
          {/* Backdrop click to close */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />

          <div className="absolute left-0 right-0 top-full mt-1.5 bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 p-3 space-y-2.5 max-h-[380px] flex flex-col animate-in fade-in zoom-in-95 duration-150">
            {/* Search and Custom Toggle */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search cycles, orchards, livestock, poultry, milk..."
                  className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:bg-white focus:border-indigo-500 font-medium"
                  autoFocus
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery("")}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={() => setIsCustomMode(!isCustomMode)}
                className={`px-2.5 py-1.5 text-[11px] font-bold rounded-xl border transition cursor-pointer flex items-center gap-1 shrink-0 ${
                  isCustomMode
                    ? "bg-indigo-600 text-white border-indigo-600"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200"
                }`}
                title="Enter custom commodity name"
              >
                <Plus className="w-3 h-3" />
                <span>Custom</span>
              </button>
            </div>

            {/* Custom Mode Input Form */}
            {isCustomMode && (
              <form onSubmit={handleApplyCustom} className="p-2.5 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-2">
                <div className="text-[10px] font-black uppercase text-indigo-900">Custom Commodity Name</div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={customInput}
                    onChange={(e) => setCustomInput(e.target.value)}
                    placeholder="e.g. Raw Honey, Sunflower Seed Cake..."
                    className="flex-1 px-2.5 py-1.5 bg-white border border-indigo-300 rounded-lg text-xs font-bold text-slate-900 outline-none"
                    autoFocus
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded-lg hover:bg-indigo-700 cursor-pointer shadow-xs"
                  >
                    Add
                  </button>
                </div>
              </form>
            )}

            {/* Source Category Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[10px] font-bold no-scrollbar">
              <button
                type="button"
                onClick={() => setActiveSourceFilter("ALL")}
                className={`px-2.5 py-1 rounded-lg transition whitespace-nowrap cursor-pointer ${
                  activeSourceFilter === "ALL"
                    ? "bg-slate-900 text-white"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
              >
                All Sources ({all.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveSourceFilter("crop_cycle")}
                className={`px-2.5 py-1 rounded-lg transition whitespace-nowrap cursor-pointer flex items-center gap-1 ${
                  activeSourceFilter === "crop_cycle"
                    ? "bg-amber-600 text-white"
                    : "bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200"
                }`}
              >
                <span>🌾 Crop Cycles</span>
                <span>({bySource.crop_cycle?.length || 0})</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveSourceFilter("orchard_block")}
                className={`px-2.5 py-1 rounded-lg transition whitespace-nowrap cursor-pointer flex items-center gap-1 ${
                  activeSourceFilter === "orchard_block"
                    ? "bg-emerald-600 text-white"
                    : "bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200"
                }`}
              >
                <span>🌳 Orchards</span>
                <span>({bySource.orchard_block?.length || 0})</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveSourceFilter("livestock")}
                className={`px-2.5 py-1 rounded-lg transition whitespace-nowrap cursor-pointer flex items-center gap-1 ${
                  activeSourceFilter === "livestock"
                    ? "bg-indigo-600 text-white"
                    : "bg-indigo-50 text-indigo-800 hover:bg-indigo-100 border border-indigo-200"
                }`}
              >
                <span>🐂 Livestock</span>
                <span>({bySource.livestock?.length || 0})</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveSourceFilter("poultry")}
                className={`px-2.5 py-1 rounded-lg transition whitespace-nowrap cursor-pointer flex items-center gap-1 ${
                  activeSourceFilter === "poultry"
                    ? "bg-orange-600 text-white"
                    : "bg-orange-50 text-orange-800 hover:bg-orange-100 border border-orange-200"
                }`}
              >
                <span>🐔 Poultry</span>
                <span>({bySource.poultry?.length || 0})</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveSourceFilter("dairy")}
                className={`px-2.5 py-1 rounded-lg transition whitespace-nowrap cursor-pointer flex items-center gap-1 ${
                  activeSourceFilter === "dairy"
                    ? "bg-blue-600 text-white"
                    : "bg-blue-50 text-blue-800 hover:bg-blue-100 border border-blue-200"
                }`}
              >
                <span>🥛 Dairy/Milk</span>
                <span>({bySource.dairy?.length || 0})</span>
              </button>
            </div>

            {/* Items List */}
            <div className="overflow-y-auto flex-1 divide-y divide-slate-100 pr-1 space-y-0.5">
              {filteredItems.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400 font-medium space-y-1">
                  <p>No matching product / commodity categories found.</p>
                  <p className="text-[10px] text-indigo-600 font-bold">Use the "Custom" button above to add a new category.</p>
                </div>
              ) : (
                filteredItems.map((item) => {
                  const isSelected = selectedItem?.id === item.id || value === item.commodityName;

                  return (
                    <div
                      key={item.id}
                      onClick={() => handleSelectItem(item)}
                      className={`p-2.5 rounded-xl transition cursor-pointer flex items-center justify-between gap-3 text-xs ${
                        isSelected
                          ? "bg-indigo-50/90 text-indigo-950 font-extrabold border border-indigo-200"
                          : "hover:bg-slate-50 text-slate-800 font-medium"
                      }`}
                    >
                      <div className="flex items-start gap-2.5 min-w-0">
                        <span className="text-base shrink-0 mt-0.5">{item.icon || getSourceIcon(item.sourceType)}</span>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-slate-900">{item.commodityName}</span>
                            {getSourceBadge(item.sourceType)}
                            {item.defaultUnit && (
                              <span className="text-[9.5px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.2 rounded">
                                {item.defaultUnit}
                              </span>
                            )}
                          </div>
                          {item.sourceName && (
                            <div className="text-[10px] text-slate-500 font-sans mt-0.5 truncate">
                              📍 {item.sourceName}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {item.currentQuantity !== undefined && item.currentQuantity > 0 && (
                          <div className="text-right">
                            <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                              {item.currentQuantity.toLocaleString()} {item.defaultUnit.split(" ")[0]}
                            </span>
                          </div>
                        )}
                        {isSelected && <Check className="w-4 h-4 text-indigo-600 shrink-0" />}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default CommodityCategorySelector;

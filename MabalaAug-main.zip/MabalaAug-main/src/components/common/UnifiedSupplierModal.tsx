import React, { useState } from "react";
import { Supplier } from "../../types";
import { 
  Building2, 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  FileText, 
  Sparkles, 
  Check, 
  X, 
  Tag, 
  Briefcase 
} from "lucide-react";

interface UnifiedSupplierModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveSupplier: (supplier: Supplier) => void;
  initialCategory?: string;
  initialName?: string;
  currencySymbol?: string;
  farmId?: string;
  tenantId?: string;
}

export const SUPPLIER_CATEGORIES = [
  { id: "Poultry Feed & Nutrition", label: "Poultry Feed & Nutrition (NutriFeeds, Tiger, etc.)" },
  { id: "Hatchery & Day-Old Chicks", label: "Hatchery & Day-Old Chicks (Hybrid, Ross, Cobb)" },
  { id: "Veterinary Drugs & Vaccines", label: "Veterinary Drugs & Vaccines (Vet Care)" },
  { id: "Brooding Charcoal & Heat", label: "Brooding Charcoal & Fireblocks (Heating)" },
  { id: "Bedding & Sawdust", label: "Bedding & Sawdust Supplies" },
  { id: "Livestock Breeding & Genetics", label: "Livestock Breeding & Stock (Cattle, Pigs, Goats)" },
  { id: "Livestock Feed & Fodder", label: "Livestock Feed & Formulations" },
  { id: "Agronomy Inputs & Seeds", label: "Agronomy Inputs, Fertilizers & Seeds" },
  { id: "Farm Machinery & Equipment", label: "Farm Machinery, Spares & Equipment" },
  { id: "General Supplies & Logistics", label: "General Farm Supplies & Logistics" }
];

export default function UnifiedSupplierModal({
  isOpen,
  onClose,
  onSaveSupplier,
  initialCategory = "Poultry Feed & Nutrition",
  initialName = "",
  farmId = "",
  tenantId = ""
}: UnifiedSupplierModalProps) {
  const [name, setName] = useState<string>(initialName);
  const [category, setCategory] = useState<string>(initialCategory);
  const [contactPerson, setContactPerson] = useState<string>("");
  const [phone, setPhone] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [tpin, setTpin] = useState<string>("");
  const [address, setAddress] = useState<string>("");
  const [notes, setNotes] = useState<string>("");
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Please provide a valid supplier or company name.");
      return;
    }

    const newSupplier: Supplier = {
      id: `SUP-${Date.now()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
      name: name.trim(),
      category: category || "General Supplies & Logistics",
      contactPerson: contactPerson.trim() || "Account Manager",
      phone: phone.trim() || "N/A",
      email: email.trim() || "",
      address: address.trim() || "Lusaka, Zambia",
      tpin: tpin.trim() || "N/A",
      notes: notes.trim(),
      farmId: farmId || undefined,
      tenantId: tenantId || undefined
    };

    onSaveSupplier(newSupplier);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in select-none">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-emerald-800 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center border border-white/20">
              <Building2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-tight">Register New Supplier / Payee</h3>
                <span className="px-2 py-0.5 rounded-full text-[9.5px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  Auto-Syncs Tracker
                </span>
              </div>
              <p className="text-xs text-emerald-200/80">
                Immediately registers supplier into the Professional Payees Tracker and ledger.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-bold">
              {error}
            </div>
          )}

          {/* Supplier Name & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                Company / Supplier Name *
              </label>
              <div className="relative">
                <Building2 className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    setError(null);
                  }}
                  placeholder="e.g. Hybrid Poultry Ltd"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 font-bold text-slate-900 focus:bg-white focus:border-emerald-500 focus:outline-none transition"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                Supplier Category *
              </label>
              <div className="relative">
                <Tag className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 font-bold text-slate-900 focus:bg-white focus:border-emerald-500 focus:outline-none transition cursor-pointer"
                >
                  {SUPPLIER_CATEGORIES.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Contact Person & Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                Contact Person / Sales Rep
              </label>
              <div className="relative">
                <User className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  placeholder="e.g. Kelvin Banda"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 font-medium text-slate-800 focus:bg-white focus:border-emerald-500 focus:outline-none transition"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                Phone Number
              </label>
              <div className="relative">
                <Phone className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. +260 97 1234567"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold text-slate-800 focus:bg-white focus:border-emerald-500 focus:outline-none transition"
                />
              </div>
            </div>
          </div>

          {/* Email & TPIN */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="sales@supplier.co.zm"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:bg-white focus:border-emerald-500 focus:outline-none transition"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
                TPIN / Tax Registration ID
              </label>
              <div className="relative">
                <FileText className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={tpin}
                  onChange={(e) => setTpin(e.target.value)}
                  placeholder="e.g. 1002345678"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 font-mono text-slate-800 focus:bg-white focus:border-emerald-500 focus:outline-none transition"
                />
              </div>
            </div>
          </div>

          {/* Physical Address */}
          <div>
            <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
              Physical Location / Depot Address
            </label>
            <div className="relative">
              <MapPin className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Plot 42, Heavy Industrial Area, Lusaka"
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:bg-white focus:border-emerald-500 focus:outline-none transition"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">
              Payment Terms / Notes
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. 14-day credit terms, delivers to farm gate, minimum 50 bags."
              className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:bg-white focus:border-emerald-500 focus:outline-none transition resize-none"
            />
          </div>

          {/* Auto-posting notice */}
          <div className="p-3 rounded-2xl bg-emerald-50/80 border border-emerald-200/80 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p className="text-[11px] text-emerald-900 leading-relaxed">
              <strong>Seamless Ledger Integration:</strong> When saved, this supplier becomes selectable across all restock modules (Feed, Day-Old Chicks, Vet Drugs, Charcoal/Heating, Livestock) and automatically tracks cumulative accounts payable & purchase histories.
            </p>
          </div>

          {/* Footer Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 font-bold transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Save & Register Supplier</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

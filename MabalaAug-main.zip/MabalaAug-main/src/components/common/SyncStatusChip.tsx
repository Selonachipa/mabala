import React, { useState, useEffect } from "react";
import { 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  HardDrive, 
  ShieldAlert, 
  Layers,
  ChevronDown
} from "lucide-react";
import { db } from "../../firebase";
import { collection, query, limit, onSnapshot } from "firebase/firestore";
import { sessionService, RejectedWriteRecord } from "../../services/sessionService";

interface SyncStatusChipProps {
  onOpenRejectedWrites?: () => void;
  rejectedWritesCount?: number;
  className?: string;
}

export default function SyncStatusChip({
  onOpenRejectedWrites,
  rejectedWritesCount = 0,
  className = ""
}: SyncStatusChipProps) {
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== "undefined" ? navigator.onLine : true
  );
  const [hasPendingWrites, setHasPendingWrites] = useState<boolean>(false);
  const [isFromCache, setIsFromCache] = useState<boolean>(false);
  const [showDetails, setShowDetails] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  const isSessionTerminated = sessionService.isSessionTerminated();

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Monitor Firestore metadata changes (drives hasPendingWrites and fromCache)
  useEffect(() => {
    if (!db || (db as any)._dummy) return;
    try {
      const q = query(collection(db, "offline_sync_test"), limit(1));
      const unsubscribe = onSnapshot(q, { includeMetadataChanges: true }, (snapshot) => {
        const pending = snapshot.metadata.hasPendingWrites;
        const fromCache = snapshot.metadata.fromCache;
        setHasPendingWrites(pending);
        setIsFromCache(fromCache);
        if (!pending && isOnline) {
          setLastSyncTime(new Date());
        }
      }, (err) => {
        // Fallback gracefully
        console.warn("[SyncStatusChip] Listener notice:", err?.message);
      });
      return () => unsubscribe();
    } catch (_) {}
  }, [isOnline]);

  const sessionId = sessionService.getSessionId();
  const truncatedSession = sessionId ? `${sessionId.slice(0, 8)}...` : "None";
  const deviceId = sessionService.getDeviceId();
  const truncatedDevice = deviceId ? `${deviceId.slice(0, 10)}...` : "Local";

  // Determine primary visual chip state
  let chipBg = "bg-emerald-50 border-emerald-300 text-emerald-800 hover:bg-emerald-100/80";
  let chipDot = "bg-emerald-500 animate-pulse";
  let chipIcon = <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />;
  let chipText = "Synced";

  if (isSessionTerminated) {
    chipBg = "bg-rose-50 border-rose-300 text-rose-800 hover:bg-rose-100";
    chipDot = "bg-rose-600";
    chipIcon = <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />;
    chipText = "Session Inactive";
  } else if (!isOnline) {
    chipBg = "bg-sky-50 border-sky-300 text-sky-800 hover:bg-sky-100";
    chipDot = "bg-sky-500";
    chipIcon = <HardDrive className="w-3.5 h-3.5 text-sky-600" />;
    chipText = "Local Cache (Offline)";
  } else if (hasPendingWrites) {
    chipBg = "bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-100";
    chipDot = "bg-amber-500 animate-spin";
    chipIcon = <RefreshCw className="w-3.5 h-3.5 text-amber-600 animate-spin" />;
    chipText = "Syncing...";
  }

  return (
    <div className={`relative inline-flex items-center gap-1.5 ${className}`}>
      {/* Primary Status Chip */}
      <button
        onClick={() => setShowDetails(!showDetails)}
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold tracking-tight border transition-all cursor-pointer shadow-2xs ${chipBg}`}
        title="View Sync & Session Status"
      >
        <span className={`w-2 h-2 rounded-full ${chipDot}`} />
        {chipIcon}
        <span>{chipText}</span>
        <ChevronDown className="w-3 h-3 opacity-60 ml-0.5" />
      </button>

      {/* Stale Writes Alert Pill */}
      {rejectedWritesCount > 0 && (
        <button
          onClick={onOpenRejectedWrites}
          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500 text-white hover:bg-amber-600 border border-amber-600 transition-all cursor-pointer shadow-xs animate-bounce"
          title="Review writes rejected due to session displacement"
        >
          <AlertTriangle className="w-3 h-3" />
          <span>Stale Writes ({rejectedWritesCount})</span>
        </button>
      )}

      {/* Details Dropdown Popover */}
      {showDetails && (
        <>
          <div 
            className="fixed inset-0 z-40" 
            onClick={() => setShowDetails(false)} 
          />
          <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-xl border border-slate-200 z-50 p-4 text-xs text-slate-700 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3">
              <span className="font-bold text-slate-900 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-emerald-600" />
                Offline-First Data Engine
              </span>
              <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded font-mono font-medium">
                v2.4
              </span>
            </div>

            <div className="space-y-2 text-[11px]">
              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="text-slate-500">Connection State:</span>
                <span className={`font-semibold flex items-center gap-1 ${isOnline ? "text-emerald-700" : "text-amber-700"}`}>
                  {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
                  {isOnline ? "Online (Server Connected)" : "Offline (Local Queue Active)"}
                </span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="text-slate-500">Local Cache:</span>
                <span className="font-medium text-slate-800">IndexedDB (Multi-tab)</span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="text-slate-500">Pending Writes:</span>
                <span className={`font-semibold ${hasPendingWrites ? "text-amber-600" : "text-emerald-600"}`}>
                  {hasPendingWrites ? "Syncing changes to cloud" : "0 pending (Fully saved)"}
                </span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="text-slate-500">Device ID:</span>
                <span className="font-mono text-slate-600">{truncatedDevice}</span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="text-slate-500">Active Session:</span>
                <span className="font-mono text-slate-600">{truncatedSession}</span>
              </div>

              <div className="flex justify-between items-center py-1">
                <span className="text-slate-500">Last Synced:</span>
                <span className="text-slate-600 font-mono">{lastSyncTime.toLocaleTimeString()}</span>
              </div>
            </div>

            {rejectedWritesCount > 0 && (
              <div className="mt-3 pt-3 border-t border-slate-100">
                <button
                  onClick={() => {
                    setShowDetails(false);
                    onOpenRejectedWrites?.();
                  }}
                  className="w-full py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  Review Stale Session Writes ({rejectedWritesCount})
                </button>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

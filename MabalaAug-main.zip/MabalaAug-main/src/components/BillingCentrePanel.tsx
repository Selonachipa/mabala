import { safeFormatError } from "../utils/errorUtils";
import React, { useState, useEffect } from "react";
import { safeFetchJsonClient } from "../App";
import { getApp } from "firebase/app";
import { getFunctions, httpsCallable } from "firebase/functions";
import { isConfigured } from "../firebase";
import { 
  Coins, 
  CreditCard, 
  CheckCircle, 
  AlertTriangle, 
  RefreshCw, 
  Building2, 
  FileText, 
  Clock, 
  Zap, 
  Smartphone,
  Check,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Download,
  Mail,
  FileSpreadsheet,
  Printer,
  Receipt
} from "lucide-react";
import { INITIAL_LIPILA_TRANSACTIONS, LipilaTransaction } from "../data/mockLipilaTransactions";
import MabalaReceiptModal from "./MabalaReceiptModal";
import SuperAdminRaiseInvoiceModal from "./SuperAdminRaiseInvoiceModal";
import FarmNodeBillingStatement from "./FarmNodeBillingStatement";
import { fetchPlatformInvoices, markPlatformInvoicePaid, PlatformInvoice } from "../services/platformInvoiceService";
import { normalizeZambianMobileNumber, isValidZambianMobileNumber, formatZambianMobileDisplay } from "../utils/phoneUtils";

interface BillingCentrePanelProps {
  isReadonly: boolean;
  credits: number;
  smsCredits: number;
  subscriptionTier: string;
  userProfile: any;
  activeFarm: any;
  onUpdateActiveFarm: (updatedFields: Partial<any>) => void;
  setCredits: React.Dispatch<React.SetStateAction<number>>;
  setSmsCredits: React.Dispatch<React.SetStateAction<number>>;
  setSubscriptionTier: (tier: string) => void;
  setLipilaCheckout?: React.Dispatch<React.SetStateAction<any>>;
}

export default function BillingCentrePanel({
  isReadonly,
  credits,
  smsCredits,
  subscriptionTier,
  userProfile,
  activeFarm,
  onUpdateActiveFarm,
  setCredits,
  setSmsCredits,
  setSubscriptionTier,
  setLipilaCheckout
}: BillingCentrePanelProps) {
  // Local loading, message and dynamic states
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Profile Form States
  const [farmName, setFarmName] = useState(activeFarm?.name || "");
  const [letterheadTitle, setLetterheadTitle] = useState(activeFarm?.letterheadTitle || "");
  const [letterheadSubtitle, setLetterheadSubtitle] = useState(activeFarm?.letterheadSubtitle || "");
  const [letterheadAddress, setLetterheadAddress] = useState(activeFarm?.letterheadAddress || "");
  const [phone, setPhone] = useState(activeFarm?.phone || "");
  const [email, setEmail] = useState(activeFarm?.email || "");

  // Wallet metrics loaded from backend
  const [backendWallet, setBackendWallet] = useState<{
    smsCreditBalance: number;
    subscriptionTier: string;
    isReadonly: boolean;
    dailyBundleExpiresAt: string | null;
  } | null>(null);

  // Daily bundle countdown state
  const [bundleCountdown, setBundleCountdown] = useState<string | null>(null);

  // Receipt viewing modal state
  const [selectedReceiptTx, setSelectedReceiptTx] = useState<LipilaTransaction | null>(null);

  // Credit Plan Selection state (v3.0 Specification)
  const CREDIT_PACKS = [
    { id: "starter", amount: 50, price: 40, label: "Starter Pack", badge: "K40", description: "Carry forward if unused (K0.80/credit)" },
    { id: "field", amount: 150, price: 100, label: "Field Pack", badge: "K100", popular: true, description: "Carry forward if unused (K0.67/credit)" },
    { id: "season", amount: 400, price: 240, label: "Season Pack", badge: "K240", description: "Carry forward if unused (K0.60/credit)" },
    { id: "bulk", amount: 1000, price: 500, label: "Bulk Pack", badge: "K500", description: "Carry forward if unused (K0.50/credit)" }
  ];
  const [selectedCreditPlanIndex, setSelectedCreditPlanIndex] = useState<number>(1);

  // Active Billing Navigation Tab: "overview" | "statement" | "invoices" | "receipts"
  const [activeBillingTab, setActiveBillingTab] = useState<"overview" | "statement" | "invoices" | "receipts">("statement");

  // Platform Invoices State
  const [platformInvoices, setPlatformInvoices] = useState<PlatformInvoice[]>([]);
  const [showRaiseInvoiceModal, setShowRaiseInvoiceModal] = useState(false);
  const [selectedInvoiceToPay, setSelectedInvoiceToPay] = useState<PlatformInvoice | null>(null);
  const [momoPhone, setMomoPhone] = useState(activeFarm?.phone || phone || userProfile?.phone || "");
  const [momoProvider, setMomoProvider] = useState<"MTN" | "Airtel" | "Zamtel">("MTN");
  const [momoSubmitting, setMomoSubmitting] = useState(false);
  const [extraTxList, setExtraTxList] = useState<LipilaTransaction[]>([]);

  // Load Platform Invoices on mount
  useEffect(() => {
    fetchPlatformInvoices().then(invoices => {
      setPlatformInvoices(invoices);
    });
  }, []);

  const handleExecuteInvoiceMoMoPayment = async () => {
    if (!selectedInvoiceToPay) return;
    setMomoSubmitting(true);
    setErrorMsg("");

    try {
      const cleanPhone = normalizeZambianMobileNumber(momoPhone);
      if (!cleanPhone || !isValidZambianMobileNumber(cleanPhone)) {
        setErrorMsg(`Invalid Zambian mobile number: "${momoPhone}". Please enter a valid 10-digit number (e.g. 0977344556) or 12-digit number starting with 260.`);
        setMomoSubmitting(false);
        return;
      }

      // 1. Balance check via production Lipila API
      const checkBalRes = await safeFetchJsonClient("/api/payments/check-balance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          accountNumber: cleanPhone,
          requiredAmount: selectedInvoiceToPay.totalAmount
        })
      }).catch(() => null);

      if (checkBalRes && checkBalRes.hasBalance === false) {
        setErrorMsg(checkBalRes.message || `Insufficient Mobile Money balance on ${formatZambianMobileDisplay(cleanPhone)}. Please top up and try again.`);
        setMomoSubmitting(false);
        return;
      }

      // 2. Initiate live Lipila collection
      const refId = `REF-INV-${Date.now().toString().slice(-6)}`;
      const collectRes = await safeFetchJsonClient("/api/payments/collect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          referenceId: refId,
          amount: selectedInvoiceToPay.totalAmount,
          narration: `Platform Invoice ${selectedInvoiceToPay.invoiceNumber}: ${selectedInvoiceToPay.lineItems[0]?.description || 'Services Rendered'}`,
          accountNumber: cleanPhone,
          currency: "ZMW",
          email: userProfile?.email || "owner@mabala.com",
          packageName: `Platform Invoice #${selectedInvoiceToPay.invoiceNumber}`,
          packageType: "invoice_settlement"
        })
      }).catch((err: any) => ({ status: "Error", message: err.message }));

      if (collectRes && (collectRes.status === "Failed" || collectRes.status === "Error" || collectRes.success === false)) {
        setErrorMsg(collectRes.message || collectRes.error || "Lipila payment request failed. Please check your mobile money balance and try again.");
        setMomoSubmitting(false);
        return;
      }

      // Verify PIN authorization from Lipila API
      let confirmed = false;
      for (let i = 0; i < 15; i++) {
        await new Promise(r => setTimeout(r, 4000));
        const checkStatusRes = await safeFetchJsonClient(`/api/payments/check-status?referenceId=${refId}`).catch(() => null);
        if (checkStatusRes && (checkStatusRes.status === "Successful" || checkStatusRes.status === "Success" || checkStatusRes.status === "Completed")) {
          confirmed = true;
          break;
        }
        if (checkStatusRes && (checkStatusRes.status === "Failed" || checkStatusRes.status === "Error" || checkStatusRes.status === "Rejected")) {
          setErrorMsg(checkStatusRes.message || "Payment request was declined or expired on the operator network.");
          setMomoSubmitting(false);
          return;
        }
      }

      if (!confirmed) {
        setErrorMsg("Payment pending: Please enter your Mobile Money PIN on your phone +260... to complete invoice payment.");
        setMomoSubmitting(false);
        return;
      }

      const txId = collectRes.referenceId || `MBL-INV-${Date.now().toString().slice(-6)}`;
      await markPlatformInvoicePaid(selectedInvoiceToPay.id, txId);

      const principal = selectedInvoiceToPay.totalAmount;
      const lipilaFee = Number((principal * 0.015).toFixed(2));
      const platformFee = Number((principal * 0.02).toFixed(2));

      const newTx: LipilaTransaction = {
        id: txId,
        referenceId: refId,
        createdAt: new Date().toISOString(),
        amount: principal,
        currency: "ZMW",
        status: "Successful",
        customerName: selectedInvoiceToPay.recipientTenantName || activeFarm?.name || "Registered Tenant Node",
        accountNumber: cleanPhone,
        narration: `Platform Invoice ${selectedInvoiceToPay.invoiceNumber}: ${selectedInvoiceToPay.lineItems[0]?.description || 'Services Rendered'}`,
        provider: momoProvider,
        paymentMethod: `Lipila MoMo (${momoProvider})`,
        tenantId: activeFarm?.id || selectedInvoiceToPay.recipientTenantId || "TENANT-001",
        fees: {
          chargeAmount: lipilaFee + platformFee,
          feePercentage: 3.5,
          principalAmount: principal,
          lipilaFee: lipilaFee,
          platformFee: platformFee,
          feeBreakdown: {
            principalAmount: principal,
            principal: principal,
            lipilaComponent: lipilaFee,
            platformComponent: platformFee,
            totalFee: lipilaFee + platformFee
          }
        }
      };

      try {
        const stored = localStorage.getItem("mabala_lipila_user_transactions");
        const existing = stored ? JSON.parse(stored) : [];
        localStorage.setItem("mabala_lipila_user_transactions", JSON.stringify([newTx, ...existing]));
      } catch (e) {}

      setExtraTxList(prev => [newTx, ...prev]);
      setPlatformInvoices(prev =>
        prev.map(inv => inv.id === selectedInvoiceToPay.id ? { ...inv, status: "PAID", paidAt: new Date().toISOString(), lipilaTransactionId: txId } : inv)
      );

      setSuccessMsg(`Invoice ${selectedInvoiceToPay.invoiceNumber} settled via Lipila MoMo! Receipt captured below.`);
      setSelectedInvoiceToPay(null);
    } catch (err: any) {
      console.error("Failed to process payment:", err);
      setErrorMsg(err.message || "Failed to settle invoice via Lipila. Please try again.");
    } finally {
      setMomoSubmitting(false);
    }
  };

  // Filter transactions so non-Super Admin users (Farmer, Agro dealer, Supplier) ONLY see records for their own tenant/account
  const filteredTransactions = React.useMemo(() => {
    let localTxs: LipilaTransaction[] = [];
    try {
      const stored = localStorage.getItem("mabala_lipila_user_transactions");
      if (stored) localTxs = JSON.parse(stored);
    } catch (e) {}

    const combined = [...extraTxList, ...localTxs, ...INITIAL_LIPILA_TRANSACTIONS];
    const uniqueMap = new Map<string, LipilaTransaction>();
    combined.forEach(t => uniqueMap.set(t.id, t));
    const all = Array.from(uniqueMap.values());

    const isSuperAdmin = userProfile?.role === "super_admin" || userProfile?.role === "Platform Administrator";
    if (isSuperAdmin) return all;

    const loggedEmail = (userProfile?.email || email || "").toLowerCase();
    const loggedName = (userProfile?.displayName || farmName || activeFarm?.name || "").toLowerCase();
    const loggedUid = (userProfile?.uid || "").toLowerCase();

    const userSpecific = all.filter(tx => {
      const cName = (tx.customerName || "").toLowerCase();
      const acct = (tx.accountNumber || "").toLowerCase();
      const tId = (tx.tenantId || "").toLowerCase();
      const owner = (tx.accountInfo?.owner || "").toLowerCase();

      if (loggedEmail && (acct.includes(loggedEmail) || cName.includes(loggedEmail))) return true;
      if (loggedUid && (tId === loggedUid || tId === activeFarm?.id?.toLowerCase())) return true;
      if (loggedName && loggedName.length > 2 && (cName.includes(loggedName) || owner.includes(loggedName))) return true;

      return false;
    });

    if (userSpecific.length > 0) return userSpecific;

    // Fallback filter by tenant ID or owner email match to ensure tenant isolation
    return all.filter(tx => tx.tenantId === (activeFarm?.id || "TENANT-001"));
  }, [INITIAL_LIPILA_TRANSACTIONS, userProfile, email, farmName, activeFarm]);

  // Setup Firebase Callable client if configured
  const getCallable = (name: string) => {
    if (!isConfigured) return null;
    try {
      const functions = getFunctions(getApp());
      return httpsCallable(functions, name);
    } catch (e) {
      console.warn(`[BillingCentre] Failed to initialize callable "${name}":`, e);
      return null;
    }
  };

  const loadBillingData = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      if (isConfigured) {
        try {
          const getWalletDetailsFn = getCallable("getWalletDetails");
          if (getWalletDetailsFn) {
            const tenantId = userProfile?.uid || authTenantId();
            const result: any = await getWalletDetailsFn({ tenantId });
            if (result?.data?.success) {
              setBackendWallet({
                smsCreditBalance: result.data.smsCreditBalance,
                subscriptionTier: result.data.subscriptionTier,
                isReadonly: result.data.isReadonly,
                dailyBundleExpiresAt: result.data.dailyBundleExpiresAt || null
              });
              // Keep local state in sync
              setSmsCredits(result.data.smsCreditBalance);
              setSubscriptionTier(result.data.subscriptionTier);
            }
          }
        } catch (walletErr) {
          console.log("[BillingCentre] Wallet function unavailable, using local state:", walletErr);
        }

        try {
          const getFarmProfileFn = getCallable("getFarmProfile");
          if (getFarmProfileFn) {
            const tenantId = userProfile?.uid || authTenantId();
            const profileResult: any = await getFarmProfileFn({ tenantId });
            if (profileResult?.data?.success && profileResult?.data?.profile) {
              const p = profileResult.data.profile;
              setFarmName(p.name || "");
              setLetterheadTitle(p.letterheadTitle || "");
              setLetterheadSubtitle(p.letterheadSubtitle || "");
              setLetterheadAddress(p.letterheadAddress || "");
              setPhone(p.phone || "");
              setEmail(p.email || "");
            }
          }
        } catch (profileErr) {
          console.log("[BillingCentre] Farm profile function unavailable, using local state:", profileErr);
        }
      }

      // Populate local state defaults if not set by cloud functions
      const fallbackFarmName = (userProfile as any)?.farmName || localStorage.getItem("mabala_registered_farm_name") || localStorage.getItem("mabala_farm_name") || activeFarm?.name || activeFarm?.letterheadTitle || "Sunrise Agro Farm";
      setFarmName(prev => prev || activeFarm?.name || fallbackFarmName);
      setLetterheadTitle(prev => prev || activeFarm?.letterheadTitle || activeFarm?.name || fallbackFarmName);
      setLetterheadSubtitle(prev => prev || activeFarm?.letterheadSubtitle || "Corporate Agricultural Operations");
      setLetterheadAddress(prev => prev || activeFarm?.letterheadAddress || activeFarm?.address || localStorage.getItem("mabala_farm_address") || "");
      setPhone(prev => prev || activeFarm?.phone || userProfile?.phone || localStorage.getItem("mabala_farm_phone") || "");
      setEmail(prev => prev || activeFarm?.email || userProfile?.email || localStorage.getItem("mabala_farm_email") || "");

      // Setup local countdown for testing if unmetered bundle is simulated
      const simulatedExpiry = localStorage.getItem("mabala_simulated_bundle_expiry");
      if (simulatedExpiry) {
        setBackendWallet(prev => prev ? prev : {
          smsCreditBalance: smsCredits,
          subscriptionTier: subscriptionTier,
          isReadonly: isReadonly,
          dailyBundleExpiresAt: simulatedExpiry
        });
      }
    } catch (err: any) {
      console.warn("[BillingCentre] Load fallback handled:", err);
    } finally {
      setLoading(false);
    }
  };

  const authTenantId = () => {
    return userProfile?.uid || "tenant-owner-123";
  };

  useEffect(() => {
    loadBillingData();
  }, [activeFarm, credits, smsCredits, subscriptionTier]);

  // Listen for real-time reconciliation events from Super Admin
  useEffect(() => {
    const handleReconcileUpdate = (e: any) => {
      const detail = e.detail;
      if (detail?.allocatedService?.quantity && detail.allocatedService.type === "SMS_CREDITS") {
        setSmsCredits((prev) => prev + detail.allocatedService.quantity);
        setSuccessMsg(`Super Admin reconciled payment! Allocated ${detail.allocatedService.quantity} SMS credits.`);
      } else if (detail?.allocatedService?.type === "PLATFORM_CREDITS") {
        setCredits((prev) => prev + (detail.allocatedService.quantity || 50));
        setSuccessMsg(`Super Admin reconciled payment! Allocated ${detail.allocatedService.quantity} platform credits.`);
      }
      loadBillingData();
    };

    window.addEventListener("mabala_lipila_reconciled", handleReconcileUpdate);
    window.addEventListener("mabala_sms_updated", handleReconcileUpdate);
    return () => {
      window.removeEventListener("mabala_lipila_reconciled", handleReconcileUpdate);
      window.removeEventListener("mabala_sms_updated", handleReconcileUpdate);
    };
  }, []);

  // Handle countdown interval for daily bundle
  useEffect(() => {
    const updateCountdown = () => {
      const expiryStr = backendWallet?.dailyBundleExpiresAt || localStorage.getItem("mabala_simulated_bundle_expiry");
      if (!expiryStr) {
        setBundleCountdown(null);
        return;
      }
      const expiry = new Date(expiryStr);
      const diff = expiry.getTime() - Date.now();
      if (diff <= 0) {
        setBundleCountdown(null);
        localStorage.removeItem("mabala_simulated_bundle_expiry");
        return;
      }
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const secs = Math.floor((diff % (1000 * 60)) / 1000);
      setBundleCountdown(`${hours}h ${mins}m ${secs}s`);
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [backendWallet]);

  // Actions
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    const payload = {
      name: farmName,
      letterheadTitle,
      letterheadSubtitle,
      letterheadAddress,
      phone,
      email
    };

    try {
      if (isConfigured) {
        const updateFarmProfileFn = getCallable("updateFarmProfile");
        if (updateFarmProfileFn) {
          const tenantId = userProfile?.uid || authTenantId();
          await updateFarmProfileFn({ tenantId, profileData: payload });
        }
      }
      
      // Keep frontend state in sync
      onUpdateActiveFarm(payload);
      setSuccessMsg("Farm Profile and custom letterhead updated successfully in secure database.");
    } catch (err: any) {
      console.error("[BillingCentre] Update profile error:", err);
      setErrorMsg(err.message || "Failed to persist profile updates.");
    } finally {
      setSubmitting(false);
    }
  };

  const handlePurchaseCredits = async (amount: number, zmw: number) => {
    if (setLipilaCheckout) {
      setLipilaCheckout({
        type: "credits",
        name: `+${amount} Credits Block`,
        price: zmw,
        currency: "ZMW",
        creditsToAward: amount,
        description: `Top up wallet with +${amount} Mabala transaction credits using Lipila Mobile Money.`
      });
      return;
    }
    // Local fallback
    setSubmitting(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      if (isConfigured) {
        const purchaseCreditsFn = getCallable("purchaseCredits");
        if (purchaseCreditsFn) {
          const tenantId = userProfile?.uid || authTenantId();
          const result: any = await purchaseCreditsFn({
            tenantId,
            amount,
            amountPaidZmw: zmw
          });
          if (result?.data?.success) {
            setCredits(result.data.newBalance);
            setSuccessMsg(`Successfully processed Lipila Momoney payment. Added ${amount} SMS write credits!`);
          }
        }
      } else {
        // Fallback simulated operation
        setCredits(prev => prev + amount);
        setSuccessMsg(`[MOCK GATEWAY] Successfully processed Lipila payment of ZMW ${zmw}. Added ${amount} credits to your wallet.`);
      }
    } catch (err: any) {
      console.error("[BillingCentre] Purchase credit error:", err);
      setErrorMsg(err.message || "Lipila payment simulation failed.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleActivateDailyBundle = async () => {
    if (setLipilaCheckout) {
      setLipilaCheckout({
        type: "credits",
        id: "daily-unmetered-bundle",
        name: "K25 Daily Unmetered Access Bundle",
        price: 25.00,
        currency: "ZMW",
        creditsToAward: 0,
        is_unmetered_access: true,
        duration_hours: 24,
        description: "24 hours of unlimited write operations on Mabala Cloud with zero credit deduction."
      });
      return;
    }
    // Local fallback
    setSubmitting(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      if (isConfigured) {
        const activateDailyBundleFn = getCallable("activateDailyBundle");
        if (activateDailyBundleFn) {
          const tenantId = userProfile?.uid || authTenantId();
          const result: any = await activateDailyBundleFn({
            tenantId,
            costZmw: 25
          });
          if (result?.data?.success) {
            setSuccessMsg("Mabala daily bundle activated successfully! Enjoy 24 hours of unmetered write access.");
            loadBillingData();
          }
        }
      } else {
        // Fallback simulation: Set local storage countdown to 24 hours from now
        const simulatedExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
        localStorage.setItem("mabala_simulated_bundle_expiry", simulatedExpiry);
        localStorage.setItem("mabala_daily_bundle_expires_at", simulatedExpiry);
        
        setBackendWallet(prev => prev ? {
          ...prev,
          dailyBundleExpiresAt: simulatedExpiry,
          isReadonly: false
        } : {
          smsCreditBalance: smsCredits,
          subscriptionTier: subscriptionTier,
          isReadonly: false,
          dailyBundleExpiresAt: simulatedExpiry
        });
        
        setSuccessMsg("[MOCK GATEWAY] Lipila payment of ZMW 25.00 processed successfully. Daily unmetered bundle activated!");
      }
    } catch (err: any) {
      console.error("[BillingCentre] Activate bundle error:", err);
      setErrorMsg(err.message || "Daily bundle activation failed.");
    } finally {
      setSubmitting(false);
    }
  };

  const activeModeLabel = () => {
    if (bundleCountdown) return "FREE BUNDLE ACTIVE";
    if (isReadonly) return "READ ONLY";
    return subscriptionTier === "FREE" ? "FREE OPERATIONS TIER" : "ACTIVE SUBSCRIBER";
  };

  return (
    <div className="space-y-8 animate-fade-in font-sans" id="billing-centre-tab">
      
      {/* 1. TOP STATS HEADER CARD */}
      <div className="bg-slate-900 rounded-3xl border border-slate-800 p-8 text-white relative overflow-hidden shadow-xl">
        <div className="absolute right-0 top-0 w-64 h-64 bg-emerald-600 rounded-full blur-[120px] opacity-25" />
        <div className="absolute left-1/3 bottom-0 w-48 h-48 bg-indigo-600 rounded-full blur-[100px] opacity-15" />
        
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6 z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className={`px-2.5 py-1 text-[9.5px] font-mono tracking-widest font-black uppercase rounded-lg shadow-md border ${
                bundleCountdown 
                  ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" 
                  : isReadonly 
                    ? "bg-rose-500/10 border-rose-500/30 text-rose-400 animate-pulse" 
                    : "bg-blue-500/10 border-blue-500/30 text-blue-400"
              }`}>
                {activeModeLabel()}
              </span>
              {bundleCountdown && (
                <span className="text-[11px] font-mono font-bold text-amber-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  Time Left: {bundleCountdown}
                </span>
              )}
            </div>
            
            <h2 className="text-2xl font-black tracking-tight text-white uppercase">Mabala Billing Centre</h2>
            <p className="text-slate-400 text-xs font-semibold leading-relaxed max-w-xl">
              Manage your agricultural cloud resource ledger, customise automated transactional documents, and top up your write credits instantly using the secure Lipila local Mobile Money portal.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActiveBillingTab("statement")}
              className={`py-3 px-5 rounded-xl font-black text-xs uppercase transition-all shadow-md flex items-center gap-2 cursor-pointer border ${
                activeBillingTab === "statement"
                  ? "bg-emerald-600 text-white border-emerald-400 ring-2 ring-emerald-400/50"
                  : "bg-slate-800 hover:bg-slate-750 text-emerald-400 border-slate-700"
              }`}
              title="View Invoiced and Paid Amounts Statement (PDF/Email)"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-300" />
              <span>Official Statement</span>
            </button>
            <button
              onClick={loadBillingData}
              disabled={loading || submitting}
              className="p-3 bg-slate-800 border border-slate-700 hover:bg-slate-750 text-slate-300 rounded-xl transition-all cursor-pointer shadow-md disabled:opacity-50"
              title="Synchronize Ledger with Firebase Security Network"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            </button>
            <button
              onClick={handleActivateDailyBundle}
              disabled={submitting || !!bundleCountdown}
              className={`py-3 px-6 rounded-xl font-bold text-xs uppercase transition-all shadow-md flex items-center gap-2 cursor-pointer ${
                bundleCountdown
                  ? "bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 cursor-not-allowed"
                  : "bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:from-amber-600 hover:to-orange-600 active:scale-95 border border-amber-400"
              }`}
            >
              <Zap className="w-4 h-4 shrink-0" />
              <span>{bundleCountdown ? "Daily Bundle Active" : "Activate Daily Bundle • K25.00"}</span>
            </button>
          </div>
        </div>

        {/* 2. CORE METRICS SUBSECTION */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8 pt-8 border-t border-slate-800/80 relative z-10">
          <div className="bg-slate-950/40 border border-slate-800/60 p-5 rounded-2xl space-y-1.5 shadow-inner">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest font-mono">Operations Balance</span>
            <div className="text-3xl font-black text-white font-mono">{credits.toLocaleString()}</div>
            <p className="text-[11px] text-slate-400 font-medium">Standard write operations remaining in your workspace.</p>
          </div>

          <div className="bg-slate-950/40 border border-slate-800/60 p-5 rounded-2xl space-y-1.5 shadow-inner">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest font-mono">Dedicated SMS Balance</span>
            <div className="text-3xl font-black text-white font-mono">{smsCredits.toLocaleString()}</div>
            <p className="text-[11px] text-slate-400 font-medium">Credits allocated for direct SMS weather and off-taker alerts.</p>
          </div>

          <div className="bg-slate-950/40 border border-slate-800/60 p-5 rounded-2xl space-y-1.5 shadow-inner">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest font-mono">Connection Status</span>
            <div className="flex items-center gap-2 text-xl font-bold pt-1">
              <span className={`w-2.5 h-2.5 rounded-full ${isConfigured ? "bg-emerald-500" : "bg-amber-400"}`} />
              <span className="text-white text-base truncate font-mono uppercase tracking-wider">
                {isConfigured ? "Secure Firebase Live" : "Simulator Mode"}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium leading-tight pt-1">
              {isConfigured 
                ? "Connected to Live Google Cloud platform databases." 
                : "Credentials unconfigured. Running in client-side secure playground mode."}
            </p>
          </div>
        </div>
      </div>

      {/* DYNAMIC FORM FEEDBACK ALERTS */}
      {errorMsg && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl text-xs font-semibold flex items-center gap-2.5 shadow-sm animate-shake">
          <AlertTriangle className="w-5 h-5 shrink-0 text-rose-600" />
          <span>{safeFormatError(errorMsg)}</span>
        </div>
      )}
      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl text-xs font-semibold flex items-center gap-2.5 shadow-sm">
          <CheckCircle className="w-5 h-5 shrink-0 text-emerald-600" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* 2. SUB-NAVIGATION TABS */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 bg-slate-100 rounded-2xl border border-slate-200 shadow-2xs">
        <button
          type="button"
          onClick={() => setActiveBillingTab("statement")}
          className={`flex-1 min-w-[180px] py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeBillingTab === "statement"
              ? "bg-[#1D9E75] text-white shadow-md"
              : "text-slate-700 hover:text-slate-900 hover:bg-slate-200/70"
          }`}
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
          <span>Billing Statement</span>
          <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${
            activeBillingTab === "statement" ? "bg-[#147a5a] text-white" : "bg-emerald-100 text-emerald-800"
          }`}>
            Invoiced vs Paid
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveBillingTab("overview")}
          className={`flex-1 min-w-[160px] py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeBillingTab === "overview"
              ? "bg-slate-900 text-white shadow-md"
              : "text-slate-700 hover:text-slate-900 hover:bg-slate-200/70"
          }`}
        >
          <Coins className="w-4 h-4 text-amber-400" />
          <span>Credits & Top-Ups</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveBillingTab("invoices")}
          className={`flex-1 min-w-[160px] py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeBillingTab === "invoices"
              ? "bg-slate-900 text-white shadow-md"
              : "text-slate-700 hover:text-slate-900 hover:bg-slate-200/70"
          }`}
        >
          <Clock className="w-4 h-4 text-indigo-400" />
          <span>Platform Invoices</span>
          {platformInvoices.filter(i => i.status !== "PAID").length > 0 && (
            <span className="px-1.5 py-0.5 rounded-full text-[9px] font-black bg-amber-500 text-white">
              {platformInvoices.filter(i => i.status !== "PAID").length} Due
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveBillingTab("receipts")}
          className={`flex-1 min-w-[160px] py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeBillingTab === "receipts"
              ? "bg-slate-900 text-white shadow-md"
              : "text-slate-700 hover:text-slate-900 hover:bg-slate-200/70"
          }`}
        >
          <Receipt className="w-4 h-4 text-purple-400" />
          <span>Receipts Ledger</span>
        </button>
      </div>

      {/* VIEW: OFFICIAL AUDITED STATEMENT */}
      {activeBillingTab === "statement" && (
        <FarmNodeBillingStatement
          tenantId={userProfile?.uid || userProfile?.tenantId || "TENANT-001"}
          userProfile={userProfile}
          activeFarm={activeFarm}
        />
      )}

      {/* VIEW: OVERVIEW & CREDIT PACKS */}
      {activeBillingTab === "overview" && (
        <div className="space-y-8 animate-fade-in">
          {/* Quick statement callout banner */}
          <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-emerald-950 p-6 rounded-3xl border border-emerald-900/40 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-[10px] font-black uppercase rounded-md tracking-wider">
                  Audited Node Ledger
                </span>
                <span className="text-xs text-slate-300 font-semibold font-mono">
                  {activeFarm?.name || "Active Farm Node"}
                </span>
              </div>
              <h3 className="text-base font-extrabold text-white">Full Invoiced & Paid Statement Available</h3>
              <p className="text-xs text-slate-400 max-w-xl">
                Review complete financial history across Subscriptions, AI Credit Top-Ups, SMS Broadcast Bundles, and Platform Invoices. Export to Excel/CSV, Print/PDF, or dispatch via Hostinger SMTP to registered email.
              </p>
            </div>
            <button
              onClick={() => setActiveBillingTab("statement")}
              className="py-2.5 px-5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center gap-2 shrink-0 cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
              <span>Open Statement</span>
            </button>
          </div>

          {/* 3. COLUMNS WRAPPER */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* LEFT COLUMN: LETTERHEAD CONFIGURATION & VISUAL PREVIEW */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-6">
            <div>
              <h3 className="text-sm font-extrabold text-slate-850 uppercase tracking-widest pb-2 border-b">Farm Letterhead Configuration</h3>
              <p className="text-[11.5px] text-slate-500 mt-1.5 leading-relaxed font-medium">
                Customize your corporate identity headers. This content dynamically injects into automated invoice PDF renders, receipts, and professional veterinary letterheads.
              </p>
            </div>

            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500">Farm Legal Name</label>
                  <input
                    type="text"
                    required
                    value={farmName}
                    onChange={(e) => setFarmName(e.target.value)}
                    className="w-full text-xs font-bold border rounded-lg px-3 py-2 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500">Letterhead Title</label>
                  <input
                    type="text"
                    required
                    value={letterheadTitle}
                    onChange={(e) => setLetterheadTitle(e.target.value)}
                    className="w-full text-xs font-bold border rounded-lg px-3 py-2 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500">Letterhead Tagline / Subtitle</label>
                <input
                  type="text"
                  required
                  value={letterheadSubtitle}
                  onChange={(e) => setLetterheadSubtitle(e.target.value)}
                  className="w-full text-xs font-bold border rounded-lg px-3 py-2 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800"
                  placeholder="e.g. Certified Organic Crops & Seed Supply"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500">Corporate Address Line</label>
                <input
                  type="text"
                  required
                  value={letterheadAddress}
                  onChange={(e) => setLetterheadAddress(e.target.value)}
                  className="w-full text-xs font-bold border rounded-lg px-3 py-2 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500">Primary Contact Phone</label>
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full text-xs font-bold border rounded-lg px-3 py-2 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500">Accounts Email Address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full text-xs font-bold border rounded-lg px-3 py-2 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs uppercase rounded-xl border border-slate-750 shadow-md transition-all active:scale-98 cursor-pointer disabled:opacity-50"
                >
                  {submitting ? "Saving Changes..." : "✓ Update Letterhead Credentials"}
                </button>
              </div>
            </form>
          </div>

          {/* VISUAL LETTERHEAD RENDERING CANVAS PREVIEW */}
          <div className="bg-slate-100 p-6 rounded-2xl border border-slate-200 border-dashed space-y-4">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest font-mono">Live Visual Document Header Preview</span>
            
            <div className="bg-white border p-6 rounded-xl shadow-sm relative overflow-hidden font-serif min-h-[140px] flex flex-col justify-between">
              {/* Decorative top header line */}
              <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-emerald-600 via-indigo-600 to-indigo-700" />
              
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="font-extrabold text-[15px] text-slate-900 tracking-tight leading-tight font-serif uppercase">
                    {letterheadTitle || "Sunrise Agro Farm Ltd."}
                  </div>
                  <div className="font-sans text-[10px] font-bold text-slate-400 italic">
                    {letterheadSubtitle || "Industrial Grain & Agri-Tech Distribution"}
                  </div>
                </div>

                <div className="text-right font-sans text-[9px] text-slate-400 space-y-0.5">
                  <p className="font-bold text-slate-500">{letterheadAddress || "Plot 24, Mumbwa Road, Lusaka"}</p>
                  <p><strong>Tel:</strong> {phone || "+260 97 8070734"}</p>
                  <p><strong>Email:</strong> {email || "accounts@sunriseagro.cloud"}</p>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 font-sans flex justify-between items-center text-[8.5px] text-slate-400 font-bold uppercase tracking-widest">
                <span>Ref: INV-2026-0001</span>
                <span>Date: {new Date().toISOString().split("T")[0]}</span>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: REPLENISH TRANS-ACTIONS CREDIT BLOCKS */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-6">
            <div>
              <h3 className="text-sm font-extrabold text-slate-850 uppercase tracking-widest pb-2 border-b">Replenish Transaction Credits</h3>
              <p className="text-[11.5px] text-slate-500 mt-1.5 leading-relaxed font-medium">
                Choose a capacity package to purchase more credits instantly. Standard and custom packs are routed via our Lipila Mobile Money integration with zero payment friction.
              </p>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500 block">
                  Select Credit Capacity Package
                </label>
                <select
                  value={selectedCreditPlanIndex}
                  onChange={(e) => setSelectedCreditPlanIndex(Number(e.target.value))}
                  className="w-full text-xs font-extrabold border rounded-xl p-3 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800 cursor-pointer shadow-2xs"
                >
                  {CREDIT_PACKS.map((pack, idx) => (
                    <option key={pack.id} value={idx}>
                      {pack.label} — {pack.badge} ({pack.amount.toLocaleString()} Credits) {pack.popular ? "★ Best Value" : ""}
                    </option>
                  ))}
                </select>
              </div>

              {/* Selected Plan Details & Proceed to Pay Action */}
              {(() => {
                const pack = CREDIT_PACKS[selectedCreditPlanIndex] || CREDIT_PACKS[0];
                return (
                  <div className={`border rounded-2xl p-5 space-y-4 transition-all ${
                    pack.popular ? "border-indigo-500 bg-indigo-50/20 shadow-sm" : "border-slate-200 bg-slate-50/50"
                  }`}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <strong className="text-sm font-extrabold text-slate-900">{pack.label}</strong>
                          {pack.popular && (
                            <span className="bg-indigo-600 text-white font-black text-[7.5px] uppercase tracking-widest px-2 py-0.5 rounded-full shadow-xs">
                              Best Value
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-600 font-medium leading-relaxed">
                          Allocates <strong>{pack.amount.toLocaleString()}</strong> transactional write operations directly to your farm's wallet ledger.
                        </p>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-[10px] font-extrabold text-slate-400 block uppercase tracking-wider">Price</span>
                        <span className="text-lg font-black text-slate-900 font-mono">{pack.badge}</span>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-200/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                      <div className="text-[11px] text-slate-500 font-medium flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Instant Lipila MoMo PIN Disbursement</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handlePurchaseCredits(pack.amount, pack.price)}
                        disabled={submitting}
                        className="w-full sm:w-auto py-2.5 px-5 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-xl border border-slate-750 shadow-md hover:shadow-lg transition-all active:scale-95 shrink-0 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                      >
                        <span>Proceed to Pay {pack.badge}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>

          {/* SAAS VALUE HIGHLIGHT PANEL */}
          <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 space-y-4 text-white relative overflow-hidden shadow-lg">
            <div className="absolute right-0 top-0 w-32 h-32 bg-indigo-500 rounded-full blur-[60px] opacity-10" />
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
              <strong className="text-xs uppercase tracking-wider text-slate-200">Standard Operations Costs</strong>
            </div>

            <div className="space-y-2 text-[11px] text-slate-400 leading-relaxed font-semibold">
              <p>Mabala uses a modular, credit-first model where write actions deduct standard operations credits:</p>
              <ul className="space-y-1.5 list-disc pl-4 pt-1">
                <li>Creating farm records, invoices, crop cycles or payroll entries: <strong>1 Credit</strong></li>
                <li>Processing double-entry ledger charts or biological valuation updates: <strong>2 Credits</strong></li>
                <li>Executing platform data backups or restoring archived logs: <strong>0 Credits</strong></li>
              </ul>
              <p className="text-[10.5px] text-slate-500 font-bold pt-1.5 border-t border-slate-800">
                Credits never expire and roll over. Free plans start with 100 gratis operations credits.
              </p>
            </div>
          </div>
        </div>
      </div>
      </div>
      )}

      {/* VIEW: PLATFORM INVOICES */}
      {(activeBillingTab === "invoices" || activeBillingTab === "overview") && (
      <>
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4 font-sans">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-500" />
              <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">
                Pending Platform Invoices
              </h3>
            </div>
            <p className="text-[11.5px] text-slate-500 mt-1 font-medium">
              Invoices raised by Super Admin for platform operational services, licensing, or supply node management. Settlable via Lipila MoMo.
            </p>
          </div>

          {(userProfile?.role === "super_admin" || userProfile?.role === "Platform Administrator") && (
            <button
              type="button"
              onClick={() => setShowRaiseInvoiceModal(true)}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl shadow-sm hover:shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4 text-indigo-400" />
              <span>Raise Platform Invoice</span>
            </button>
          )}
        </div>

        {platformInvoices.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
            <p className="text-xs font-bold text-slate-700">No Pending Invoices</p>
            <p className="text-[11px] text-slate-400 font-medium">All platform services and tenant accounts are fully settled.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {platformInvoices.map((inv) => {
              const isPaid = inv.status === "PAID";
              return (
                <div
                  key={inv.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    isPaid ? "bg-slate-50/60 border-slate-200 opacity-80" : "bg-amber-50/30 border-amber-200/80 hover:border-amber-300 shadow-xs"
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <span className="text-[10px] font-extrabold font-mono text-slate-500 uppercase block">{inv.invoiceNumber}</span>
                      <h4 className="text-xs font-extrabold text-slate-900">{inv.recipientTenantName} ({inv.recipientType})</h4>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider ${
                      isPaid ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800 border border-amber-300"
                    }`}>
                      {inv.status}
                    </span>
                  </div>

                  <div className="space-y-1 my-3 bg-white p-2.5 rounded-xl border border-slate-100 text-[11px]">
                    {inv.lineItems.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-slate-700">
                        <span className="font-medium truncate max-w-[200px]">{item.description}</span>
                        <span className="font-mono font-bold">ZK {item.amount.toLocaleString()}</span>
                      </div>
                    ))}
                    <div className="pt-1.5 border-t border-slate-100 flex justify-between font-black text-slate-900">
                      <span>Total Amount:</span>
                      <span className="font-mono text-emerald-700 text-xs">ZK {inv.totalAmount.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
                    <span>Due: {inv.dueDate}</span>
                    {!isPaid ? (
                      <button
                        type="button"
                        onClick={() => setSelectedInvoiceToPay(inv)}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-lg shadow-2xs transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <Smartphone className="w-3.5 h-3.5" />
                        <span>Pay via Lipila MoMo</span>
                      </button>
                    ) : (
                      <span className="text-emerald-600 font-extrabold flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Paid Ref: {(inv as any).lipilaTransactionId || inv.id}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* LIPILA MOMO PAYMENT MODAL FOR INVOICE */}
      {selectedInvoiceToPay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs font-sans">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-100 rounded-xl text-emerald-700">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">Settle Invoice via Lipila MoMo</h3>
                  <p className="text-[10px] text-slate-500 font-bold">{selectedInvoiceToPay.invoiceNumber}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedInvoiceToPay(null)}
                className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">Invoice Total:</span>
                <span className="font-mono font-black text-slate-900">ZK {selectedInvoiceToPay.totalAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">Recipient Tenant:</span>
                <span className="font-bold text-slate-800">{selectedInvoiceToPay.recipientTenantName}</span>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">
                  Mobile Money Provider
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(["MTN", "Airtel", "Zamtel"] as const).map(p => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setMomoProvider(p)}
                      className={`py-2 text-xs font-extrabold rounded-xl border cursor-pointer transition-all ${
                        momoProvider === p ? "bg-slate-900 text-white border-slate-900 shadow-xs" : "bg-slate-50 text-slate-700 border-slate-200"
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">
                  Mobile Money Phone Number
                </label>
                <input
                  type="tel"
                  value={momoPhone}
                  onChange={(e) => setMomoPhone(e.target.value)}
                  placeholder="e.g. 0971234567"
                  className="w-full text-xs font-bold p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                />
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedInvoiceToPay(null)}
                className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={momoSubmitting}
                onClick={handleExecuteInvoiceMoMoPayment}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <CheckCircle className="w-4 h-4 text-emerald-200" />
                <span>{momoSubmitting ? "Processing MoMo Prompt..." : `Confirm & Pay ZK ${selectedInvoiceToPay.totalAmount}`}</span>
              </button>
            </div>
          </div>
        </div>
      )}
      </>
      )}

      <SuperAdminRaiseInvoiceModal
        isOpen={showRaiseInvoiceModal}
        onClose={() => setShowRaiseInvoiceModal(false)}
        onInvoiceCreated={(newInv) => {
          setPlatformInvoices(prev => [newInv, ...prev]);
        }}
      />

      {/* VIEW: TRANSACTION RECEIPTS */}
      {(activeBillingTab === "receipts" || activeBillingTab === "overview") && (
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4 font-sans">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-sm font-extrabold text-slate-850 uppercase tracking-widest flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#1D9E75]" />
              <span>Corporate Billing, Receipts & Statements</span>
            </h3>
            <p className="text-[11.5px] text-slate-500 mt-1 font-medium">
              Self-service portal to view and download official Mabala branded receipts for subscription renewals, credit purchases, and agronomist consultations.
            </p>
          </div>
          <span className="px-3 py-1 bg-emerald-50 text-[#1D9E75] rounded-full text-[10px] font-black uppercase border border-emerald-200">
            Lipila Gateway Verified
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-800">
            <thead className="bg-slate-50 font-black text-[9px] text-slate-400 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3">Receipt No</th>
                <th className="p-3">Reference ID</th>
                <th className="p-3">Description</th>
                <th className="p-3">Channel / Provider</th>
                <th className="p-3">Itemized Fee Reconciliation</th>
                <th className="p-3">Total Amount</th>
                <th className="p-3">Status</th>
                <th className="p-3">Date</th>
                <th className="p-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredTransactions.map((tx) => {
                const lipilaComp = tx.fees?.lipilaFee || tx.fees?.feeBreakdown?.lipilaComponent || 0;
                const platformComp = tx.fees?.platformFee || tx.fees?.feeBreakdown?.platformComponent || (tx.fees?.chargeAmount ? tx.fees.chargeAmount - lipilaComp : 0);
                const principal = tx.fees?.principalAmount || tx.amount;

                return (
                  <tr key={tx.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-3 font-mono font-bold text-slate-900">{tx.id}</td>
                    <td className="p-3 font-mono text-[11px] text-slate-600">{tx.referenceId}</td>
                    <td className="p-3 font-bold text-slate-800 max-w-xs truncate">{tx.narration}</td>
                    <td className="p-3 font-bold text-slate-600">
                      <div>{tx.provider}</div>
                      <div className="text-[9.5px] text-indigo-600 font-mono font-medium">{tx.paymentMethod}</div>
                    </td>
                    <td className="p-3 text-[10.5px] font-mono">
                      <div className="text-slate-700 font-bold">Base: ZMW {principal.toFixed(2)}</div>
                      <div className="text-indigo-600 font-medium text-[9.5px]">Lipila Fee: ZMW {lipilaComp.toFixed(2)}</div>
                      <div className="text-purple-600 font-medium text-[9.5px]">Platform Fee ({tx.fees?.feePercentage || 3.5}%): ZMW {platformComp.toFixed(2)}</div>
                    </td>
                    <td className="p-3 font-mono font-black text-slate-900">
                      K{tx.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                        tx.status === "Successful" ? "bg-emerald-50 text-emerald-800 border border-emerald-200" :
                        tx.status === "Pending" ? "bg-amber-50 text-amber-800 border border-amber-200" :
                        "bg-rose-50 text-rose-800 border border-rose-200"
                      }`}>
                        {tx.status}
                      </span>
                    </td>
                    <td className="p-3 font-mono text-[11px] text-slate-500">
                      {new Date(tx.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-3 text-center">
                      <button
                        disabled={tx.status !== "Successful"}
                        onClick={() => setSelectedReceiptTx(tx)}
                        className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1 mx-auto cursor-pointer ${
                          tx.status === "Successful"
                            ? "bg-[#1D9E75] hover:bg-[#157959] text-white shadow-xs"
                            : "bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200"
                        }`}
                      >
                        <Download className="w-3.5 h-3.5" /> Receipt
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      )}

      {/* RENDER BRANDED RECEIPT MODAL IF SELECTED */}
      {selectedReceiptTx && (
        <MabalaReceiptModal
          transaction={selectedReceiptTx}
          onClose={() => setSelectedReceiptTx(null)}
        />
      )}
    </div>
  );
}

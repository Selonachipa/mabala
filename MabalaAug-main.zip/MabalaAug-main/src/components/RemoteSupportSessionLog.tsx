import React, { useState, useEffect } from "react";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";
import { 
  ShieldCheck, 
  RefreshCw, 
  Search, 
  Terminal, 
  UserCheck, 
  Clock, 
  Lock, 
  Building2,
  FileSpreadsheet
} from "lucide-react";

export interface RemoteSupportAuditEntry {
  id: string;
  initiatedBy?: string;
  superAdminEmail?: string;
  superAdminId?: string;
  targetTenantId?: string;
  actionType?: string;
  actingAs?: string;
  timestamp?: string;
  details?: {
    farmNodeId?: string;
    farmNodeName?: string;
    startedAt?: string;
    endedAt?: string;
    durationMinutes?: number;
    action?: string;
    module?: string;
    record?: string;
    detail?: string;
    description?: string;
    [key: string]: any;
  };
}

export default function RemoteSupportSessionLog() {
  const [logs, setLogs] = useState<RemoteSupportAuditEntry[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [actionFilter, setActionFilter] = useState<string>("all");

  useEffect(() => {
    if (!db) return;
    setLoading(true);
    const auditsRef = collection(db, "super_admin_audit");
    const unsubscribe = onSnapshot(auditsRef, { includeMetadataChanges: true }, (snap) => {
      const list: RemoteSupportAuditEntry[] = [];
      snap.forEach((docSnap) => {
        const data = docSnap.data() as RemoteSupportAuditEntry;
        list.push({
          ...data,
          id: docSnap.id
        });
      });
      list.sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());
      setLogs(list);
      setLoading(false);
    }, (err) => {
      console.warn("Failed to subscribe to super_admin_audit logs:", err);
      setLoading(false);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const fetchLogs = () => {
    setLoading(true);
    setTimeout(() => setLoading(false), 400);
  };

  const calculateDuration = (log: RemoteSupportAuditEntry): string => {
    if (log.details?.durationMinutes !== undefined) {
      return `${log.details.durationMinutes} min${log.details.durationMinutes === 1 ? '' : 's'}`;
    }
    if (log.details?.startedAt && log.details?.endedAt) {
      const start = new Date(log.details.startedAt).getTime();
      const end = new Date(log.details.endedAt).getTime();
      const diffMins = Math.round((end - start) / 60000);
      return `${Math.max(1, diffMins)} mins`;
    }
    if (log.actionType === "farm_node_entry") {
      return "Active (60m max)";
    }
    return "Instantaneous";
  };

  const filteredLogs = logs.filter((log) => {
    const search = searchTerm.toLowerCase();
    const matchesSearch = 
      (log.initiatedBy && log.initiatedBy.toLowerCase().includes(search)) ||
      (log.superAdminEmail && log.superAdminEmail.toLowerCase().includes(search)) ||
      (log.targetTenantId && log.targetTenantId.toLowerCase().includes(search)) ||
      (log.details?.farmNodeName && log.details.farmNodeName.toLowerCase().includes(search)) ||
      (log.details?.detail && log.details.detail.toLowerCase().includes(search));

    const matchesAction = actionFilter === "all" || log.actionType === actionFilter;

    return matchesSearch && matchesAction;
  });

  const exportCSV = () => {
    const headers = ["Timestamp", "Initiated By", "Target Tenant ID", "Action Type", "Duration", "Details"];
    const rows = filteredLogs.map((l) => [
      l.timestamp || "",
      l.initiatedBy || l.superAdminEmail || "",
      l.targetTenantId || l.details?.farmNodeId || "",
      l.actionType || "",
      calculateDuration(l),
      `"${(l.details?.detail || l.details?.description || JSON.stringify(l.details || {})).replace(/"/g, '""')}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `remote_support_session_logs_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 font-sans">
      {/* Header Banner */}
      <div className="bg-slate-900 text-white rounded-xl p-5 border border-slate-800 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-red-400" />
            <h3 className="text-base font-extrabold text-white">Remote Support Session Log</h3>
            <span className="bg-red-500/20 text-red-300 text-[10px] font-mono font-bold px-2 py-0.5 rounded border border-red-500/30 uppercase tracking-wider">
              super_admin_audit
            </span>
          </div>
          <p className="text-xs text-slate-300 font-medium mt-1">
            Central immutable audit register tracking operator access, impersonation sessions, target tenants, and session duration.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={fetchLogs}
            disabled={loading}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 border border-slate-700 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin text-indigo-400" : ""}`} />
            Refresh
          </button>
          <button
            onClick={exportCSV}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            Export CSV
          </button>
        </div>
      </div>

      {/* Controls Bar */}
      <div className="bg-white border rounded-xl p-3 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by operator, tenant ID, or details..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border rounded-lg text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <span className="text-xs text-slate-500 font-bold">Action Type:</span>
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            className="bg-slate-50 border rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Actions</option>
            <option value="farm_node_entry">Farm Node Entry</option>
            <option value="farm_node_exit">Farm Node Exit</option>
            <option value="access_node_write">Access Node Write</option>
            <option value="RECONCILIATION_REPAIR">Reconciliation Repair</option>
          </select>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white border rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b text-slate-600 uppercase font-mono text-[10px] tracking-wider">
              <tr>
                <th className="p-3 font-bold">Initiated By (Operator)</th>
                <th className="p-3 font-bold">Target Tenant ID</th>
                <th className="p-3 font-bold">Action / Session Type</th>
                <th className="p-3 font-bold">Session Duration</th>
                <th className="p-3 font-bold">Timestamp</th>
                <th className="p-3 font-bold text-right">Details & Audit Scope</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500 font-mono italic">
                    Fetching Remote Support Session logs from Firestore...
                  </td>
                </tr>
              ) : filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400 italic">
                    No remote support session logs match your criteria.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => {
                  const operator = log.initiatedBy || log.superAdminEmail || "superadmin@mabala.cloud";
                  const tenantId = log.targetTenantId || log.details?.farmNodeId || "N/A";
                  const durationStr = calculateDuration(log);

                  return (
                    <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-3">
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <UserCheck className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                          {operator}
                        </div>
                        {log.superAdminId && (
                          <span className="text-[10px] text-slate-400 font-mono block">
                            UID: {log.superAdminId}
                          </span>
                        )}
                      </td>

                      <td className="p-3">
                        <div className="font-mono text-xs font-bold text-slate-800 flex items-center gap-1">
                          <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          {tenantId}
                        </div>
                        {log.details?.farmNodeName && (
                          <span className="text-[10.5px] text-indigo-700 font-semibold block">
                            {log.details.farmNodeName}
                          </span>
                        )}
                      </td>

                      <td className="p-3">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[10.5px] font-mono font-bold uppercase border ${
                          log.actionType === "farm_node_entry" 
                            ? "bg-amber-50 text-amber-800 border-amber-200"
                            : log.actionType === "farm_node_exit"
                            ? "bg-slate-100 text-slate-700 border-slate-200"
                            : "bg-indigo-50 text-indigo-800 border-indigo-200"
                        }`}>
                          <Terminal className="w-3 h-3 shrink-0" />
                          {log.actionType || "Support Session"}
                        </span>
                      </td>

                      <td className="p-3 font-mono text-xs font-bold text-slate-700">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                          {durationStr}
                        </div>
                      </td>

                      <td className="p-3 font-mono text-[11px] text-slate-600 whitespace-nowrap">
                        {log.timestamp ? log.timestamp.replace("T", " ").slice(0, 19) : "N/A"}
                      </td>

                      <td className="p-3 text-right">
                        <div className="font-medium text-slate-800 text-xs">
                          {log.details?.action && <span className="font-bold text-indigo-900 mr-1">[{log.details.action}]</span>}
                          {log.details?.detail || log.details?.description || "Remote support operation logged"}
                        </div>
                        <span className="inline-flex items-center gap-1 text-[9.5px] font-mono text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded mt-1 border border-slate-200">
                          <Lock className="w-2.5 h-2.5 text-slate-400" />
                          actingAs: {log.actingAs || "super_admin_access_node"}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

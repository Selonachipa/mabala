import React, { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { 
  MapPin, 
  Layers, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Eye, 
  Sprout, 
  Compass,
  Link as LinkIcon,
  Ruler,
  Info,
  Calendar,
  Layers3,
  Sparkles,
  ArrowRight,
  X
} from "lucide-react";
import { GeoPoint, CropCycle } from "../types";
import { AFRICAN_CROPS_LIST } from "./CropsPanel";

// Fix standard Leaflet default marker icons for Vite bundler
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

export interface MappedFieldBlock {
  id: string;
  name: string;
  cropType: string;
  variety: string;
  cycleStatus: "Nursery" | "Vegetative" | "Flowering" | "Harvesting" | "Completed" | "Planning" | "Active" | "Harvested" | "Sold";
  points: GeoPoint[];
  soilType?: string;
  expectedYieldKg?: number;
  plantingDate?: string;
  expectedHarvestDate?: string;
  healthIndex?: number; // e.g. NDVI 0.84
  healthStatus?: "Optimal Vigour" | "Moderate Growth" | "Water Stress Alert" | "Pest Watch";
  
  // Explicit size specifications in meters, hectares, or acres
  sizeValue?: number;
  sizeUnit?: "meters" | "hectares" | "acres";
  sizeInHectares?: number;
  sizeInMeters?: number;
  sizeInAcres?: number;
  lengthMeters?: number;
  widthMeters?: number;
  linkedCropCycleIds?: string[];
}

interface LeafletFieldMapProps {
  initialBlocks?: MappedFieldBlock[];
  cropCycles?: CropCycle[];
  onSaveBlocks?: (blocks: MappedFieldBlock[]) => void;
  onUpdateCropCycleBlock?: (cropCycleId: string, blockName: string) => void;
  currencySymbol?: string;
  farmLocation?: { lat: number; lng: number; source?: string };
  selectedParcelId?: string | null;
  onSelectParcel?: (id: string | null) => void;
}

// Color schemes for Crop Type and Cycle Status
const CROP_TYPE_COLORS: Record<string, { fill: string; stroke: string; label: string }> = {
  "Maize": { fill: "#f59e0b", stroke: "#b45309", label: "Maize (Amber)" },
  "Soybeans": { fill: "#10b981", stroke: "#047857", label: "Soybeans (Emerald)" },
  "Wheat": { fill: "#d97706", stroke: "#78350f", label: "Wheat (Gold)" },
  "Tomato": { fill: "#ef4444", stroke: "#b91c1c", label: "Tomato (Red)" },
  "Cabbage": { fill: "#22c55e", stroke: "#15803d", label: "Cabbage (Green)" },
  "Onion": { fill: "#a855f7", stroke: "#6b21a8", label: "Onion (Purple)" },
  "Irish Potatoes": { fill: "#eab308", stroke: "#854d0e", label: "Potatoes (Yellow)" },
  "Cassava": { fill: "#8b5cf6", stroke: "#5b21b6", label: "Cassava (Violet)" },
  "Default": { fill: "#3b82f6", stroke: "#1d4ed8", label: "Other / Mixed (Blue)" },
};

export const getCropTypeColor = (cropType: string) => {
  if (!cropType) return CROP_TYPE_COLORS["Default"];
  if (CROP_TYPE_COLORS[cropType]) return CROP_TYPE_COLORS[cropType];

  const lower = cropType.toLowerCase();
  if (lower.includes("maize") || lower.includes("corn")) return { fill: "#f59e0b", stroke: "#b45309", label: `${cropType} (Amber)` };
  if (lower.includes("soy") || lower.includes("soya")) return { fill: "#10b981", stroke: "#047857", label: `${cropType} (Emerald)` };
  if (lower.includes("wheat") || lower.includes("barley") || lower.includes("oat")) return { fill: "#d97706", stroke: "#78350f", label: `${cropType} (Gold)` };
  if (lower.includes("tomat") || lower.includes("pepper") || lower.includes("paper") || lower.includes("chili") || lower.includes("chilli") || lower.includes("eggplant") || lower.includes("impwa")) return { fill: "#ef4444", stroke: "#b91c1c", label: `${cropType} (Red)` };
  if (lower.includes("cabbage") || lower.includes("rape") || lower.includes("spinach") || lower.includes("kale") || lower.includes("bondwe") || lower.includes("mupilu") || lower.includes("chibwabwa") || lower.includes("greens") || lower.includes("lettuce") || lower.includes("lettac") || lower.includes("okra") || lower.includes("cucumber")) return { fill: "#22c55e", stroke: "#15803d", label: `${cropType} (Green)` };
  if (lower.includes("onion") || lower.includes("garlic")) return { fill: "#a855f7", stroke: "#6b21a8", label: `${cropType} (Purple)` };
  if (lower.includes("potato") || lower.includes("cassava") || lower.includes("carrot") || lower.includes("beet")) return { fill: "#eab308", stroke: "#854d0e", label: `${cropType} (Yellow/Bronze)` };
  if (lower.includes("watermelon") || lower.includes("melon")) return { fill: "#f43f5e", stroke: "#be123c", label: `${cropType} (Pink)` };
  if (lower.includes("bean") || lower.includes("pea") || lower.includes("groundnut") || lower.includes("peanut")) return { fill: "#059669", stroke: "#047857", label: `${cropType} (Emerald)` };
  if (lower.includes("sunflower")) return { fill: "#eab308", stroke: "#a16207", label: `${cropType} (Gold)` };

  return CROP_TYPE_COLORS["Default"];
};

const CYCLE_STATUS_COLORS: Record<string, { fill: string; stroke: string; label: string }> = {
  "Nursery": { fill: "#0284c7", stroke: "#0369a1", label: "Nursery / Planting" },
  "Planning": { fill: "#0284c7", stroke: "#0369a1", label: "Planning" },
  "Vegetative": { fill: "#16a34a", stroke: "#15803d", label: "Vegetative Growth" },
  "Active": { fill: "#16a34a", stroke: "#15803d", label: "Active Growth" },
  "Flowering": { fill: "#9333ea", stroke: "#6b21a8", label: "Flowering / Podding" },
  "Harvesting": { fill: "#ea580c", stroke: "#c2410c", label: "Harvesting Ready" },
  "Harvested": { fill: "#059669", stroke: "#047857", label: "Harvested" },
  "Completed": { fill: "#64748b", stroke: "#334155", label: "Completed / Fallow" },
  "Sold": { fill: "#475569", stroke: "#1e293b", label: "Sold" },
};

const HEALTH_STATUS_COLORS: Record<string, { fill: string; stroke: string; label: string }> = {
  "Optimal Vigour": { fill: "#10b981", stroke: "#047857", label: "Optimal Vigour (NDVI > 0.80)" },
  "Moderate Growth": { fill: "#f59e0b", stroke: "#b45309", label: "Moderate Growth (NDVI 0.65 - 0.80)" },
  "Water Stress Alert": { fill: "#ef4444", stroke: "#b91c1c", label: "Water Stress Alert (NDVI < 0.65)" },
  "Pest Watch": { fill: "#a855f7", stroke: "#6b21a8", label: "Pest / Disease Watch" },
};

/**
 * Calculates surface area of a lat/lng polygon using spherical shoelace algorithm
 */
export function calculateAreaHectares(points: GeoPoint[]): number {
  if (points.length < 3) return 0;
  const R = 6378137;
  let area = 0;
  for (let i = 0; i < points.length; i++) {
    const j = (i + 1) % points.length;
    const p1 = points[i];
    const p2 = points[j];
    const lat1Rad = (p1.lat * Math.PI) / 180;
    const lat2Rad = (p2.lat * Math.PI) / 180;
    const dLngRad = ((p2.lng - p1.lng) * Math.PI) / 180;
    area += dLngRad * (2 + Math.sin(lat1Rad) + Math.sin(lat2Rad));
  }
  area = (area * R * R) / 2;
  const hectares = Math.abs(area) / 10000;
  return Math.round(hectares * 100) / 100;
}

/**
 * Converts size value between meters (m²), hectares (ha), and acres (ac)
 */
export function convertSizeToHectares(value: number, unit: "meters" | "hectares" | "acres"): {
  hectares: number;
  meters: number;
  acres: number;
} {
  const safeVal = Math.max(0, isNaN(value) ? 0 : value);
  let ha = 0;
  if (unit === "meters") {
    ha = safeVal / 10000;
  } else if (unit === "acres") {
    ha = safeVal / 2.47105381;
  } else {
    ha = safeVal;
  }
  
  const meters = Math.round(ha * 10000);
  const acres = Math.round(ha * 2.47105381 * 100) / 100;
  const hectaresFormatted = ha < 0.01 && ha > 0 ? Number(ha.toFixed(4)) : Math.round(ha * 100) / 100;
  
  return { hectares: hectaresFormatted, meters, acres };
}

/**
 * Generates a georeferenced rectangular polygon for length & width in meters at farm center
 */
export function generateRectangularPolygonForDimensions(
  center: { lat: number; lng: number },
  lengthMeters: number,
  widthMeters: number,
  offsetIndex: number = 0
): GeoPoint[] {
  const safeL = Math.max(1, lengthMeters || 100);
  const safeW = Math.max(1, widthMeters || 100);
  const latDeg = safeL / 111000;
  const lngDeg = safeW / (111000 * Math.cos((center.lat * Math.PI) / 180));

  const col = offsetIndex % 3;
  const row = Math.floor(offsetIndex / 3);

  const baseLat = center.lat + (row - 0.5) * (latDeg * 1.3);
  const baseLng = center.lng + (col - 1.0) * (lngDeg * 1.3);

  return [
    { lat: Number(baseLat.toFixed(6)), lng: Number(baseLng.toFixed(6)) },
    { lat: Number(baseLat.toFixed(6)), lng: Number((baseLng + lngDeg).toFixed(6)) },
    { lat: Number((baseLat + latDeg).toFixed(6)), lng: Number((baseLng + lngDeg).toFixed(6)) },
    { lat: Number((baseLat + latDeg).toFixed(6)), lng: Number(baseLng.toFixed(6)) }
  ];
}

/**
 * Generates a georeferenced square polygon for a given area in hectares at farm center
 */
export function generateSquarePolygonForArea(
  center: { lat: number; lng: number },
  areaHectares: number,
  offsetIndex: number = 0
): GeoPoint[] {
  const safeHa = Math.max(0.1, areaHectares || 1);
  const sideM = Math.sqrt(safeHa * 10000); // meters
  const latDeg = sideM / 111000;
  const lngDeg = sideM / (111000 * Math.cos((center.lat * Math.PI) / 180));

  // Small grid shift so multiple generated blocks do not overlap directly
  const col = offsetIndex % 3;
  const row = Math.floor(offsetIndex / 3);

  const baseLat = center.lat + (row - 0.5) * (latDeg * 1.3);
  const baseLng = center.lng + (col - 1.0) * (lngDeg * 1.3);

  return [
    { lat: Number(baseLat.toFixed(6)), lng: Number(baseLng.toFixed(6)) },
    { lat: Number(baseLat.toFixed(6)), lng: Number((baseLng + lngDeg).toFixed(6)) },
    { lat: Number((baseLat + latDeg).toFixed(6)), lng: Number((baseLng + lngDeg).toFixed(6)) },
    { lat: Number((baseLat + latDeg).toFixed(6)), lng: Number(baseLng.toFixed(6)) }
  ];
}

// Default initial field blocks for clean presentation
const DEFAULT_INITIAL_BLOCKS: MappedFieldBlock[] = [
  {
    id: "BLOCK-001",
    name: "Pivot 1 - North Block",
    cropType: "Maize",
    variety: "SC 719",
    cycleStatus: "Vegetative",
    soilType: "Sandy Clay Loam",
    expectedYieldKg: 45000,
    plantingDate: "2026-10-15",
    healthStatus: "Optimal Vigour",
    sizeValue: 10,
    sizeUnit: "hectares",
    sizeInHectares: 10,
    sizeInMeters: 100000,
    sizeInAcres: 24.71,
    points: [
      { lat: -14.6520, lng: 28.5050 },
      { lat: -14.6520, lng: 28.5085 },
      { lat: -14.6550, lng: 28.5085 },
      { lat: -14.6550, lng: 28.5050 }
    ]
  },
  {
    id: "BLOCK-002",
    name: "Block B - Soybean Field",
    cropType: "Soybeans",
    variety: "Sofu 1",
    cycleStatus: "Vegetative",
    soilType: "Loam",
    expectedYieldKg: 18000,
    plantingDate: "2026-11-01",
    healthStatus: "Optimal Vigour",
    sizeValue: 6,
    sizeUnit: "hectares",
    sizeInHectares: 6,
    sizeInMeters: 60000,
    sizeInAcres: 14.83,
    points: [
      { lat: -14.6560, lng: 28.5050 },
      { lat: -14.6560, lng: 28.5080 },
      { lat: -14.6580, lng: 28.5080 },
      { lat: -14.6580, lng: 28.5050 }
    ]
  }
];

// Function to read saved farm location from local storage
const getInitialCalibratedLocation = (fallbackLat?: number, fallbackLng?: number) => {
  try {
    const saved = localStorage.getItem("mabala_farm_location");
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.lat && parsed.lng) {
        return { lat: Number(parsed.lat), lng: Number(parsed.lng) };
      }
    }
  } catch (e) {}
  return { lat: fallbackLat ?? -15.4220, lng: fallbackLng ?? 28.2000 };
};

export default function LeafletFieldMap({
  initialBlocks = DEFAULT_INITIAL_BLOCKS,
  cropCycles = [],
  onSaveBlocks,
  onUpdateCropCycleBlock,
  currencySymbol = "ZK",
  farmLocation,
  selectedParcelId,
  onSelectParcel
}: LeafletFieldMapProps) {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const polygonGroupRef = useRef<L.LayerGroup | null>(null);
  const drawGroupRef = useRef<L.LayerGroup | null>(null);

  const initialLoc = getInitialCalibratedLocation(farmLocation?.lat, farmLocation?.lng);
  const [calibratedLat, setCalibratedLat] = useState<number>(initialLoc.lat);
  const [calibratedLng, setCalibratedLng] = useState<number>(initialLoc.lng);
  const [isCalibratingLocation, setIsCalibratingLocation] = useState<boolean>(false);
  const [calibrationSavedNotice, setCalibrationSavedNotice] = useState<boolean>(false);
  const calibrationMarkerRef = useRef<L.Marker | null>(null);

  const [blocks, setBlocks] = useState<MappedFieldBlock[]>(initialBlocks);
  const [colorMode, setColorMode] = useState<"cropType" | "cycleStatus" | "cropHealth">("cropType");
  const [tileLayerType, setTileLayerType] = useState<"osm" | "satellite" | "topo">("satellite");
  const [selectedBlockId, setSelectedBlockId] = useState<string | null>(selectedParcelId || null);
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [gpsLocation, setGpsLocation] = useState<{ lat: number; lng: number } | null>({ lat: initialLoc.lat, lng: initialLoc.lng });

  // Sync selectedBlockId with props
  useEffect(() => {
    if (selectedParcelId !== undefined) {
      setSelectedBlockId(selectedParcelId);
    }
  }, [selectedParcelId]);

  // Sync initialBlocks if prop updates
  useEffect(() => {
    if (initialBlocks && initialBlocks.length > 0) {
      setBlocks(initialBlocks);
    }
  }, [initialBlocks]);

  const locateUserGPS = () => {
    if (!navigator.geolocation) {
      alert("Geolocation service is not supported by your browser environment.");
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        let lat = pos.coords.latitude;
        let lng = pos.coords.longitude;
        let isCorrected = false;

        // Snapping/Refining coarse browser IP geolocation from East Lusaka/Ibex (lng > 28.27) to farmer's exact Lusaka West Mumbwa Road location
        if (lng > 28.27 && lat > -15.45 && lat < -15.38) {
          lat = -15.4220;
          lng = 28.2000;
          isCorrected = true;
        }

        setGpsLocation({ lat, lng });
        const map = mapInstanceRef.current;
        if (map) {
          map.setView([lat, lng], 16);
          L.marker([lat, lng])
            .addTo(map)
            .bindPopup(`<div style="font-size: 11px; font-weight: bold; padding: 2px;">📍 Current GPS Location (${isCorrected ? "Lusaka West - Refined" : "Exact Coordinates"})<br/><span style="color:#059669; font-weight:800; font-size:10px;">Lusaka West, Mumbwa Road</span><br/><span style="color:#64748b; font-size:10px;">${lat.toFixed(5)}, ${lng.toFixed(5)}</span></div>`)
            .openPopup();
        }
      },
      (err) => {
        setIsLocating(false);
        // Direct fallback to Lusaka West on Mumbwa Road
        const lat = -15.4220;
        const lng = 28.2000;
        setGpsLocation({ lat, lng });
        const map = mapInstanceRef.current;
        if (map) {
          map.setView([lat, lng], 16);
          L.marker([lat, lng])
            .addTo(map)
            .bindPopup(`<div style="font-size: 11px; font-weight: bold;">📍 Refined GPS Location<br/><span style="color:#059669; font-weight:800; font-size:10px;">Lusaka West, Mumbwa Road</span><br/><span style="color:#64748b; font-size:10px;">-15.42200, 28.20000</span></div>`)
            .openPopup();
        }
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  };

  const handleRefineToLusakaWest = () => {
    const lat = -15.4220;
    const lng = 28.2000;
    setGpsLocation({ lat, lng });
    const map = mapInstanceRef.current;
    if (map) {
      map.setView([lat, lng], 16);
      L.marker([lat, lng])
        .addTo(map)
        .bindPopup(`<div style="font-size: 11px; font-weight: bold;">📍 Calibrated Farmer Position<br/><span style="color:#059669; font-weight:800; font-size:10px;">Lusaka West, Mumbwa Road</span><br/><span style="color:#64748b; font-size:10px;">-15.42200, 28.20000</span></div>`)
        .openPopup();
    }
  };

  // Modal and Drawing states for creating/mapping new field blocks
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [newBlockName, setNewBlockName] = useState<string>("");
  const [dimensionMode, setDimensionMode] = useState<"length_width" | "direct_area">("length_width");
  const [lengthMeters, setLengthMeters] = useState<string>("200");
  const [widthMeters, setWidthMeters] = useState<string>("150");
  const [newSizeValue, setNewSizeValue] = useState<string>("3");
  const [newSizeUnit, setNewSizeUnit] = useState<"meters" | "hectares" | "acres">("hectares");
  const [newCropType, setNewCropType] = useState<string>("Maize");
  const [newVariety, setNewVariety] = useState<string>("SC 719");
  const [newSoilType, setNewSoilType] = useState<string>("Sandy Clay Loam");
  const [newStatus, setNewStatus] = useState<"Nursery" | "Vegetative" | "Flowering" | "Harvesting" | "Completed">("Vegetative");
  const [selectedCropCycleId, setSelectedCropCycleId] = useState<string>("");
  const [mappingMethod, setMappingMethod] = useState<"auto_fit" | "manual_draw">("auto_fit");

  // Polygon manual drawing state
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [drawPoints, setDrawPoints] = useState<GeoPoint[]>([]);

  // Compute map center
  const allPts = blocks.flatMap(b => b.points);
  const defaultLat = farmLocation?.lat ?? -15.4220;
  const defaultLng = farmLocation?.lng ?? 28.2000;
  const centerLat = gpsLocation?.lat ?? (allPts.length > 0 ? allPts.reduce((acc, p) => acc + p.lat, 0) / allPts.length : defaultLat);
  const centerLng = gpsLocation?.lng ?? (allPts.length > 0 ? allPts.reduce((acc, p) => acc + p.lng, 0) / allPts.length : defaultLng);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [centerLat, centerLng],
        zoom: 14,
        zoomControl: false
      });

      L.control.zoom({ position: "topright" }).addTo(map);

      polygonGroupRef.current = L.layerGroup().addTo(map);
      drawGroupRef.current = L.layerGroup().addTo(map);

      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Update Base Tile Layer
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    map.eachLayer((layer) => {
      if (layer instanceof L.TileLayer) {
        map.removeLayer(layer);
      }
    });

    let tileUrl = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
    let attribution = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>';

    if (tileLayerType === "satellite") {
      tileUrl = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
      attribution = "Tiles &copy; Esri &mdash; Esri, USDA, USGS, GeoEye";
    } else if (tileLayerType === "topo") {
      tileUrl = "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png";
      attribution = "Map data: &copy; OpenStreetMap | Style: OpenTopoMap";
    }

    L.tileLayer(tileUrl, { attribution, maxZoom: 19 }).addTo(map);
  }, [tileLayerType]);

  // Render Polygons on Map when blocks or colorMode change
  useEffect(() => {
    const map = mapInstanceRef.current;
    const polygonGroup = polygonGroupRef.current;
    if (!map || !polygonGroup) return;

    polygonGroup.clearLayers();

    blocks.forEach((block) => {
      if (block.points.length < 3) return;

      const latLngs: L.LatLngExpression[] = block.points.map(p => [p.lat, p.lng]);

      let styleConfig = { fill: "#3b82f6", stroke: "#1d4ed8" };
      if (colorMode === "cropType") {
        styleConfig = getCropTypeColor(block.cropType);
      } else if (colorMode === "cycleStatus") {
        styleConfig = CYCLE_STATUS_COLORS[block.cycleStatus] || CYCLE_STATUS_COLORS["Vegetative"];
      } else if (colorMode === "cropHealth") {
        const hKey = block.healthStatus || "Optimal Vigour";
        styleConfig = HEALTH_STATUS_COLORS[hKey] || HEALTH_STATUS_COLORS["Optimal Vigour"];
      }

      const isSelected = selectedBlockId === block.id;

      const polygon = L.polygon(latLngs, {
        color: isSelected ? "#f59e0b" : styleConfig.stroke,
        weight: isSelected ? 4 : 2.5,
        fillColor: styleConfig.fill,
        fillOpacity: isSelected ? 0.65 : 0.45,
        dashArray: isSelected ? "6, 6" : undefined
      });

      const areaHa = block.sizeInHectares || calculateAreaHectares(block.points);
      const areaAc = block.sizeInAcres || Math.round(areaHa * 2.47105 * 100) / 100;
      const areaM2 = block.sizeInMeters || Math.round(areaHa * 10000);

      // Find linked crop cycles
      const linkedCrops = cropCycles.filter(c => 
        c.fieldBlock?.toLowerCase() === block.name.toLowerCase() ||
        block.linkedCropCycleIds?.includes(c.id) ||
        c.cropType?.toLowerCase() === block.cropType?.toLowerCase()
      );

      const popupContent = `
        <div style="font-family: system-ui, sans-serif; font-size: 12px; color: #0f172a; padding: 4px; min-width: 200px;">
          <div style="font-weight: 800; font-size: 13px; color: #1e1b4b; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 6px; display: flex; justify-content: space-between; align-items: center;">
            <span>${block.name}</span>
            <span style="font-size: 10px; font-family: monospace; background: #f1f5f9; padding: 2px 6px; border-radius: 4px;">${block.id}</span>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
            <span style="color: #64748b;">Crop Type:</span>
            <strong style="color: #0f172a;">${block.cropType} (${block.variety})</strong>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
            <span style="color: #64748b;">Cycle Status:</span>
            <strong style="color: ${styleConfig.stroke};">${block.cycleStatus}</strong>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
            <span style="color: #64748b;">Block Size:</span>
            <strong style="color: #047857;">${areaHa} Ha (${areaM2.toLocaleString()} m² / ${areaAc} Ac)</strong>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
            <span style="color: #64748b;">Linked Crops:</span>
            <strong style="color: #4f46e5;">${linkedCrops.length} Active Cycle${linkedCrops.length === 1 ? '' : 's'}</strong>
          </div>
          ${block.soilType ? `
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
              <span style="color: #64748b;">Soil Type:</span>
              <strong style="color: #854d0e;">${block.soilType}</strong>
            </div>
          ` : ''}
        </div>
      `;

      polygon.bindPopup(popupContent);
      polygon.on("click", () => {
        setSelectedBlockId(block.id);
        if (onSelectParcel) onSelectParcel(block.id);
      });

      polygonGroup.addLayer(polygon);

      // Add a small center marker label
      const center = polygon.getBounds().getCenter();
      const markerHtml = `
        <div style="background-color: rgba(15, 23, 42, 0.90); color: white; padding: 3px 8px; border-radius: 8px; font-size: 10px; font-weight: 800; border: 1.5px solid ${styleConfig.stroke}; white-space: nowrap; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.3);">
          📍 ${block.name} (${areaHa} Ha)
        </div>
      `;
      const customIcon = L.divIcon({
        html: markerHtml,
        className: 'custom-leaflet-label',
        iconSize: [110, 24],
        iconAnchor: [55, 12]
      });
      const marker = L.marker(center, { icon: customIcon });
      polygonGroup.addLayer(marker);
    });
  }, [blocks, colorMode, selectedBlockId, cropCycles]);

  // Click Handler for Map Drawing
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const handleMapClick = (e: L.LeafletMouseEvent) => {
      if (!isDrawing) return;
      const newPt: GeoPoint = { lat: Math.round(e.latlng.lat * 100000) / 100000, lng: Math.round(e.latlng.lng * 100000) / 100000 };
      setDrawPoints(prev => [...prev, newPt]);
    };

    map.on("click", handleMapClick);
    return () => {
      map.off("click", handleMapClick);
    };
  }, [isDrawing]);

  // Update Drawing Layer on Map
  useEffect(() => {
    const map = mapInstanceRef.current;
    const drawGroup = drawGroupRef.current;
    if (!map || !drawGroup) return;

    drawGroup.clearLayers();

    if (drawPoints.length > 0) {
      drawPoints.forEach((pt, idx) => {
        const marker = L.circleMarker([pt.lat, pt.lng], {
          radius: 6,
          color: "#f59e0b",
          fillColor: "#ffffff",
          fillOpacity: 1,
          weight: 2
        });
        marker.bindTooltip(`Point #${idx + 1}`, { permanent: false, direction: "top" });
        drawGroup.addLayer(marker);
      });

      if (drawPoints.length >= 2) {
        const latLngs: L.LatLngExpression[] = drawPoints.map(p => [p.lat, p.lng]);
        const polyline = L.polyline(latLngs, { color: "#f59e0b", weight: 3, dashArray: "4, 4" });
        drawGroup.addLayer(polyline);

        if (drawPoints.length >= 3) {
          const polygon = L.polygon(latLngs, { color: "#f59e0b", fillColor: "#fbbf24", fillOpacity: 0.35, weight: 2 });
          drawGroup.addLayer(polygon);
        }
      }
    }
  }, [drawPoints]);

  // Calibration Marker Effect for Exact Satellite Roof/Compound Pinning
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (isCalibratingLocation) {
      if (tileLayerType !== "satellite") {
        setTileLayerType("satellite");
      }

      const calibIcon = L.divIcon({
        className: "custom-calib-pin-icon",
        html: `
          <div style="background-color: #0f172a; color: white; padding: 6px 12px; border-radius: 20px; font-size: 11px; font-weight: 900; border: 2.5px solid #10b981; box-shadow: 0 10px 25px rgba(0,0,0,0.6); display: flex; align-items: center; gap: 6px; cursor: move; white-space: nowrap;">
            <span style="font-size: 16px;">🏠</span>
            <span style="color: #6ee7b7; font-family: monospace;">(${calibratedLat.toFixed(5)}, ${calibratedLng.toFixed(5)})</span>
          </div>
        `,
        iconSize: [180, 32],
        iconAnchor: [90, 16]
      });

      if (!calibrationMarkerRef.current) {
        const marker = L.marker([calibratedLat, calibratedLng], {
          icon: calibIcon,
          draggable: true,
          zIndexOffset: 2000
        }).addTo(map);

        marker.on("dragend", (e: any) => {
          const latLng = e.target.getLatLng();
          setCalibratedLat(Number(latLng.lat.toFixed(6)));
          setCalibratedLng(Number(latLng.lng.toFixed(6)));
        });

        calibrationMarkerRef.current = marker;
      } else {
        calibrationMarkerRef.current.setIcon(calibIcon);
        calibrationMarkerRef.current.setLatLng([calibratedLat, calibratedLng]);
      }

      const handleCalibMapClick = (e: L.LeafletMouseEvent) => {
        if (isDrawing) return;
        const lat = Number(e.latlng.lat.toFixed(6));
        const lng = Number(e.latlng.lng.toFixed(6));
        setCalibratedLat(lat);
        setCalibratedLng(lng);
      };

      map.on("click", handleCalibMapClick);
      return () => {
        map.off("click", handleCalibMapClick);
      };
    } else {
      if (calibrationMarkerRef.current) {
        calibrationMarkerRef.current.remove();
        calibrationMarkerRef.current = null;
      }
    }
  }, [isCalibratingLocation, calibratedLat, calibratedLng, isDrawing, tileLayerType]);

  const handleNudge = (dLat: number, dLng: number) => {
    const newLat = Number((calibratedLat + dLat).toFixed(6));
    const newLng = Number((calibratedLng + dLng).toFixed(6));
    setCalibratedLat(newLat);
    setCalibratedLng(newLng);
    if (mapInstanceRef.current) {
      mapInstanceRef.current.panTo([newLat, newLng]);
    }
  };

  const handleSaveCalibratedLocation = () => {
    const lat = Number(calibratedLat.toFixed(6));
    const lng = Number(calibratedLng.toFixed(6));

    // Calculate offset shift delta for existing mapped field blocks
    const oldLat = gpsLocation?.lat || farmLocation?.lat || -15.4220;
    const oldLng = gpsLocation?.lng || farmLocation?.lng || 28.2000;
    const deltaLat = lat - oldLat;
    const deltaLng = lng - oldLng;

    if (Math.abs(deltaLat) > 0.000001 || Math.abs(deltaLng) > 0.000001) {
      const shiftedBlocks = blocks.map(block => ({
        ...block,
        points: block.points.map(p => ({
          lat: Number((p.lat + deltaLat).toFixed(6)),
          lng: Number((p.lng + deltaLng).toFixed(6))
        }))
      }));
      setBlocks(shiftedBlocks);
      if (onSaveBlocks) onSaveBlocks(shiftedBlocks);
    }

    setGpsLocation({ lat, lng });

    // Persist to localStorage
    localStorage.setItem("mabala_farm_location", JSON.stringify({
      lat,
      lng,
      source: "user_satellite_pin",
      updatedAt: new Date().toISOString()
    }));

    try {
      const cachedFarms = localStorage.getItem("mabala_farms");
      if (cachedFarms) {
        const parsed = JSON.parse(cachedFarms);
        if (Array.isArray(parsed)) {
          parsed.forEach(f => {
            f.farmLocation = { lat, lng, source: "user_satellite_pin" };
            f.latitude = lat;
            f.longitude = lng;
          });
          localStorage.setItem("mabala_farms", JSON.stringify(parsed));
        }
      }
    } catch (e) {}

    // Dispatch global custom event
    window.dispatchEvent(new CustomEvent("mabala_location_updated", {
      detail: { lat, lng }
    }));

    const map = mapInstanceRef.current;
    if (map) {
      map.setView([lat, lng], 18);
    }

    setIsCalibratingLocation(false);
    setCalibrationSavedNotice(true);
    setTimeout(() => setCalibrationSavedNotice(false), 5000);
  };

  const currentDrawAreaHa = calculateAreaHectares(drawPoints);

  // Live conversion calculations for the new block modal
  const lenVal = parseFloat(lengthMeters) || 0;
  const widVal = parseFloat(widthMeters) || 0;
  const calculatedM2 = dimensionMode === "length_width" ? lenVal * widVal : 0;

  const numSizeVal = dimensionMode === "length_width" ? calculatedM2 : (parseFloat(newSizeValue) || 0);
  const effectiveUnit = dimensionMode === "length_width" ? "meters" : newSizeUnit;
  const sizeConversion = convertSizeToHectares(numSizeVal, effectiveUnit);

  const handleOpenAddModal = () => {
    setShowAddModal(true);
    setNewBlockName(`Block ${String.fromCharCode(65 + blocks.length)}`);
    setDimensionMode("length_width");
    setLengthMeters("200");
    setWidthMeters("150");
    setNewSizeValue("3");
    setNewSizeUnit("hectares");
    setMappingMethod("auto_fit");
    setIsDrawing(false);
    setDrawPoints([]);
  };

  const handleSaveNewBlock = () => {
    if (!newBlockName.trim()) {
      alert("Please enter a valid Field Block Name.");
      return;
    }

    if (sizeConversion.hectares <= 0) {
      alert("Please enter valid block dimensions (length & width or total surface size) greater than 0.");
      return;
    }

    let finalPoints: GeoPoint[] = [];

    if (mappingMethod === "manual_draw" && drawPoints.length >= 3) {
      finalPoints = [...drawPoints];
    } else if (dimensionMode === "length_width" && lenVal > 0 && widVal > 0) {
      finalPoints = generateRectangularPolygonForDimensions({ lat: centerLat, lng: centerLng }, lenVal, widVal, blocks.length);
    } else {
      // Auto-fit square polygon based on converted size in hectares
      finalPoints = generateSquarePolygonForArea({ lat: centerLat, lng: centerLng }, sizeConversion.hectares, blocks.length);
    }

    // Selected Crop Cycle details
    const linkedCrop = cropCycles.find(c => c.id === selectedCropCycleId);

    const createdBlock: MappedFieldBlock = {
      id: `BLOCK-${Date.now().toString().slice(-4)}`,
      name: newBlockName.trim(),
      cropType: linkedCrop ? (linkedCrop.cropName || linkedCrop.cropType) : newCropType,
      variety: linkedCrop ? (linkedCrop.variety || "Standard") : newVariety,
      cycleStatus: linkedCrop ? (linkedCrop.status as any) : newStatus,
      soilType: newSoilType,
      sizeValue: dimensionMode === "length_width" ? calculatedM2 : numSizeVal,
      sizeUnit: dimensionMode === "length_width" ? "meters" : newSizeUnit,
      sizeInHectares: sizeConversion.hectares,
      sizeInMeters: sizeConversion.meters,
      sizeInAcres: sizeConversion.acres,
      lengthMeters: dimensionMode === "length_width" ? lenVal : undefined,
      widthMeters: dimensionMode === "length_width" ? widVal : undefined,
      expectedYieldKg: linkedCrop ? (linkedCrop.expectedYieldKg || Math.round(sizeConversion.hectares * 4500)) : Math.round(sizeConversion.hectares * 4500),
      plantingDate: linkedCrop ? linkedCrop.plantingDate : new Date().toISOString().split("T")[0],
      expectedHarvestDate: linkedCrop ? linkedCrop.expectedHarvestDate : undefined,
      healthStatus: "Optimal Vigour",
      points: finalPoints,
      linkedCropCycleIds: selectedCropCycleId ? [selectedCropCycleId] : []
    };

    const updatedBlocks = [...blocks, createdBlock];
    setBlocks(updatedBlocks);
    if (onSaveBlocks) onSaveBlocks(updatedBlocks);

    // If a crop cycle was selected, link it bidirectionally
    if (selectedCropCycleId && onUpdateCropCycleBlock) {
      onUpdateCropCycleBlock(selectedCropCycleId, createdBlock.name);
    }

    // Reset modal & drawing state
    setShowAddModal(false);
    setIsDrawing(false);
    setDrawPoints([]);
    setSelectedBlockId(createdBlock.id);
    if (onSelectParcel) onSelectParcel(createdBlock.id);

    // Pan map view to new block
    const map = mapInstanceRef.current;
    if (map && finalPoints.length > 0) {
      const bounds = L.latLngBounds(finalPoints.map(p => [p.lat, p.lng]));
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  };

  const handleDeleteBlock = (id: string) => {
    if (!window.confirm("Are you sure you want to remove this field block polygon from the map?")) return;
    const updated = blocks.filter(b => b.id !== id);
    setBlocks(updated);
    if (selectedBlockId === id) setSelectedBlockId(null);
    if (onSaveBlocks) onSaveBlocks(updated);
  };

  // Currently selected block object
  const activeBlock = blocks.find(b => b.id === selectedBlockId);

  // Crop cycles linked to active block
  const activeBlockCropCycles = activeBlock ? cropCycles.filter(c => 
    c.fieldBlock?.toLowerCase() === activeBlock.name.toLowerCase() ||
    activeBlock.linkedCropCycleIds?.includes(c.id) ||
    (c.cropType?.toLowerCase() === activeBlock.cropType?.toLowerCase() && c.fieldBlock?.toLowerCase() === activeBlock.name.toLowerCase())
  ) : [];

  // Compute total mapped statistics
  const totalMappedHa = blocks.reduce((acc, b) => acc + (b.sizeInHectares || calculateAreaHectares(b.points)), 0);
  const totalMappedAc = Math.round(totalMappedHa * 2.47105 * 100) / 100;
  const totalMappedM2 = Math.round(totalMappedHa * 10000);
  const totalTargetYieldMT = blocks.reduce((acc, b) => acc + ((b.expectedYieldKg || 0) / 1000), 0);

  return (
    <div className="space-y-4">
      {/* Top Banner Toolbar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
            <Compass className="w-5 h-5 text-indigo-600" />
            Interactive Plot Polygon Field Mapper (Leaflet GIS)
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Simplify mapping: enter field name & size in meters, hectares, or acres to auto-generate & link crop cycles.
          </p>
        </div>

        {/* Action Controls & Legend Switchers */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold flex-wrap gap-1">
            <button
              type="button"
              onClick={() => setColorMode("cropType")}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                colorMode === "cropType" ? "bg-white text-indigo-700 shadow-xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              🌱 Crop Type
            </button>
            <button
              type="button"
              onClick={() => setColorMode("cycleStatus")}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                colorMode === "cycleStatus" ? "bg-white text-emerald-700 shadow-xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              🔄 Cycle Status
            </button>
            <button
              type="button"
              onClick={() => setColorMode("cropHealth")}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                colorMode === "cropHealth" ? "bg-white text-emerald-600 shadow-xs font-extrabold" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              🛰️ NDVI Health
            </button>
          </div>

          {/* GPS Locate Button */}
          <button
            type="button"
            onClick={locateUserGPS}
            disabled={isLocating}
            className="bg-slate-800 hover:bg-slate-700 text-white font-extrabold text-xs px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            title="Locate via device GPS"
          >
            <MapPin className="w-3.5 h-3.5 text-amber-400" />
            <span>{isLocating ? "Locating..." : "📍 GPS Position"}</span>
          </button>

          <button
            type="button"
            onClick={handleRefineToLusakaWest}
            className="bg-emerald-800 hover:bg-emerald-900 text-white font-extrabold text-xs px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
            title="Refine GPS to exact Lusaka West (Mumbwa Road) farm coordinates"
          >
            <Compass className="w-3.5 h-3.5 text-emerald-200" />
            <span>🎯 Refine to Lusaka West</span>
          </button>

          {/* Pin House Roof Calibration Button */}
          <button
            type="button"
            onClick={() => {
              const nextState = !isCalibratingLocation;
              setIsCalibratingLocation(nextState);
              if (nextState && mapInstanceRef.current) {
                mapInstanceRef.current.setView([calibratedLat, calibratedLng], 18);
              }
            }}
            className={`px-3 py-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 shadow-xs ${
              isCalibratingLocation
                ? "bg-amber-400 text-slate-950 ring-2 ring-amber-300 animate-pulse font-black"
                : "bg-emerald-600 hover:bg-emerald-500 text-white"
            }`}
            title="Click to place or drag a pin on your green roof compound or building"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-200" />
            <span>{isCalibratingLocation ? "🎯 Dragging Roof Pin..." : "📍 Pin House/Building on Map"}</span>
          </button>

          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold">
            <button
              type="button"
              onClick={() => setTileLayerType("satellite")}
              className={`px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${
                tileLayerType === "satellite" ? "bg-slate-900 text-white shadow-xs" : "text-slate-600"
              }`}
            >
              Satellite
            </button>
            <button
              type="button"
              onClick={() => setTileLayerType("osm")}
              className={`px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${
                tileLayerType === "osm" ? "bg-slate-900 text-white shadow-xs" : "text-slate-600"
              }`}
            >
              Streets
            </button>
          </div>

          {/* Map New Field Block Primary Button */}
          <button
            type="button"
            onClick={handleOpenAddModal}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4 text-white" />
            <span>Map New Field Block</span>
          </button>
        </div>
      </div>

      {/* Main Map Canvas Container with Overlays */}
      <div className="relative rounded-3xl overflow-hidden border border-slate-300 shadow-lg bg-slate-900 h-[520px] w-full">
        <div ref={mapContainerRef} className="h-full w-full z-0" />

        {/* Saved Location Confirmation Toast */}
        {calibrationSavedNotice && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-emerald-950/95 text-white backdrop-blur-md px-5 py-3 rounded-2xl border border-emerald-400 shadow-2xl z-[600] flex items-center gap-3 text-xs font-black animate-in fade-in slide-in-from-top-4 duration-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <div className="text-emerald-300 text-xs">Exact Compound Location Saved & Calibrated!</div>
              <div className="text-[10.5px] text-slate-300 font-medium font-mono">
                Lat: {calibratedLat.toFixed(6)} | Lng: {calibratedLng.toFixed(6)} (Weather & Map synced)
              </div>
            </div>
          </div>
        )}

        {/* Floating Calibration HUD Overlay Bar */}
        {isCalibratingLocation && (
          <div className="absolute top-3 left-3 right-3 sm:left-1/2 sm:-translate-x-1/2 sm:max-w-xl bg-slate-950/95 text-white backdrop-blur-md p-3.5 rounded-2xl border border-emerald-500/80 shadow-2xl z-[500] space-y-3 animate-in fade-in zoom-in duration-200">
            <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <span className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-lg text-sm">🏠</span>
                <div>
                  <h4 className="font-extrabold text-xs text-emerald-300 flex items-center gap-1.5">
                    <span>Exact Compound Satellite Calibration</span>
                    <span className="bg-emerald-500/20 text-emerald-300 text-[9.5px] px-2 py-0.5 rounded-full font-mono font-bold">DRAG OR CLICK MAP</span>
                  </h4>
                  <p className="text-[10.5px] text-slate-300 font-medium mt-0.5">
                    Click anywhere on the satellite view or drag the 🏠 green roof marker onto your exact house/building roof.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCalibratingLocation(false)}
                className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Live Coordinates Readout & Direct Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              <div className="flex items-center gap-2 bg-slate-900/90 p-2 rounded-xl border border-slate-800">
                <span className="font-bold text-slate-400 text-[10px] uppercase tracking-wider">Lat:</span>
                <input
                  type="number"
                  step="0.00001"
                  value={calibratedLat}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    if (!isNaN(v)) setCalibratedLat(v);
                  }}
                  className="w-full bg-slate-950 px-2 py-1 rounded-lg text-emerald-300 font-mono font-black outline-none focus:ring-1 focus:ring-emerald-500 text-xs"
                />
              </div>
              <div className="flex items-center gap-2 bg-slate-900/90 p-2 rounded-xl border border-slate-800">
                <span className="font-bold text-slate-400 text-[10px] uppercase tracking-wider">Lng:</span>
                <input
                  type="number"
                  step="0.00001"
                  value={calibratedLng}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    if (!isNaN(v)) setCalibratedLng(v);
                  }}
                  className="w-full bg-slate-950 px-2 py-1 rounded-lg text-emerald-300 font-mono font-black outline-none focus:ring-1 focus:ring-emerald-500 text-xs"
                />
              </div>
            </div>

            {/* Micro Fine-Tuning Directional Nudge Pad */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
              <div className="flex items-center gap-1 text-[10px]">
                <span className="text-slate-400 font-bold hidden sm:inline mr-1">Nudge (~5m):</span>
                <button
                  type="button"
                  onClick={() => handleNudge(0.00005, 0)}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 active:scale-95 rounded-lg border border-slate-700 text-slate-200 font-extrabold cursor-pointer transition"
                >
                  ⬆ N
                </button>
                <button
                  type="button"
                  onClick={() => handleNudge(-0.00005, 0)}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 active:scale-95 rounded-lg border border-slate-700 text-slate-200 font-extrabold cursor-pointer transition"
                >
                  ⬇ S
                </button>
                <button
                  type="button"
                  onClick={() => handleNudge(0, -0.00005)}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 active:scale-95 rounded-lg border border-slate-700 text-slate-200 font-extrabold cursor-pointer transition"
                >
                  ⬅ W
                </button>
                <button
                  type="button"
                  onClick={() => handleNudge(0, 0.00005)}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 active:scale-95 rounded-lg border border-slate-700 text-slate-200 font-extrabold cursor-pointer transition"
                >
                  ➔ E
                </button>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsCalibratingLocation(false)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveCalibratedLocation}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Save & Align Farm Plots</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Floating Drawing Instructions Bar when in Manual Drawing Mode */}
        {isDrawing && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-slate-900/95 text-white backdrop-blur-md px-5 py-2.5 rounded-full border border-amber-500/80 shadow-2xl z-[400] flex items-center gap-3 text-xs font-semibold animate-pulse">
            <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Click satellite points to draw custom field boundary: <strong>{drawPoints.length} vertices placed</strong> ({currentDrawAreaHa} Ha)</span>
            <div className="flex gap-1.5">
              {drawPoints.length > 0 && (
                <button
                  type="button"
                  onClick={() => setDrawPoints(prev => prev.slice(0, -1))}
                  className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 rounded text-[10px] text-amber-300 font-mono"
                >
                  Undo
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  if (drawPoints.length < 3) {
                    alert("Please plot at least 3 points to enclose a field block.");
                    return;
                  }
                  setShowAddModal(true);
                  setMappingMethod("manual_draw");
                }}
                disabled={drawPoints.length < 3}
                className="px-2.5 py-0.5 bg-emerald-600 text-white rounded text-[10px] font-bold disabled:opacity-40"
              >
                Save Drawing ({currentDrawAreaHa} Ha)
              </button>
            </div>
          </div>
        )}

        {/* Floating Legend Overlay Box */}
        <div className="absolute bottom-4 left-4 bg-slate-900/90 text-white backdrop-blur-md p-3.5 rounded-2xl border border-slate-700/80 shadow-2xl z-[400] max-w-xs space-y-2 text-[11px]">
          <div className="flex justify-between items-center font-bold border-b border-slate-700/80 pb-1.5 text-xs">
            <span className="text-amber-400 flex items-center gap-1">
              <Layers className="w-3.5 h-3.5" />
              {colorMode === "cropType" ? "Crop Category Color Key" : "Cycle Status Key"}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">{blocks.length} Blocks</span>
          </div>

          <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
            {colorMode === "cropType" ? (
              Object.entries(CROP_TYPE_COLORS).map(([key, val]) => (
                <div key={key} className="flex items-center justify-between text-[10.5px]">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full shrink-0 border" style={{ backgroundColor: val.fill, borderColor: val.stroke }} />
                    <span className="text-slate-200">{key}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {blocks.filter(b => b.cropType === key).length}
                  </span>
                </div>
              ))
            ) : (
              Object.entries(CYCLE_STATUS_COLORS).map(([key, val]) => (
                <div key={key} className="flex items-center justify-between text-[10.5px]">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full shrink-0 border" style={{ backgroundColor: val.fill, borderColor: val.stroke }} />
                    <span className="text-slate-200">{key}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {blocks.filter(b => b.cycleStatus === key).length}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Floating Total Mapped Area Stats Box */}
        <div className="absolute top-4 left-4 bg-slate-900/90 text-white backdrop-blur-md p-3.5 rounded-2xl border border-slate-700/80 shadow-xl z-[400] text-xs font-mono space-y-1">
          <div className="text-[10px] text-slate-400 uppercase font-extrabold tracking-wider flex items-center gap-1">
            <Ruler className="w-3 h-3 text-emerald-400" /> Total Mapped Surface
          </div>
          <div className="text-sm font-black text-emerald-400 flex items-baseline gap-1.5">
            <span>{totalMappedHa} Ha</span>
            <span className="text-[10.5px] text-slate-300 font-medium">({totalMappedM2.toLocaleString()} m² • {totalMappedAc} Ac)</span>
          </div>
          <div className="text-[10px] text-indigo-300 font-sans font-semibold pt-0.5 border-t border-slate-800">
            Target Yield: {totalTargetYieldMT.toFixed(1)} MT
          </div>
        </div>
      </div>

      {/* Field Block Ledger & Contained Crop Cycles View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Mapped Field Blocks Table */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <Sprout className="w-4 h-4 text-emerald-600" />
              <span>Mapped Field Blocks ({blocks.length})</span>
            </h4>
            <span className="text-xs font-mono text-slate-500 font-bold">
              Total Mapped Area: {totalMappedHa} Ha
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-black uppercase text-slate-500">
                  <th className="py-2.5 px-3">Field Block</th>
                  <th className="py-2.5 px-3">Crop Variety</th>
                  <th className="py-2.5 px-3">Dimensions (m² / Ha / Ac)</th>
                  <th className="py-2.5 px-3">Contained Crop Cycles</th>
                  <th className="py-2.5 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {blocks.map((block) => {
                  const areaHa = block.sizeInHectares || calculateAreaHectares(block.points);
                  const areaAc = block.sizeInAcres || Math.round(areaHa * 2.47105 * 100) / 100;
                  const areaM2 = block.sizeInMeters || Math.round(areaHa * 10000);
                  const cropColor = getCropTypeColor(block.cropType);
                  const statusColor = CYCLE_STATUS_COLORS[block.cycleStatus] || CYCLE_STATUS_COLORS["Vegetative"];
                  const isSelected = selectedBlockId === block.id;

                  // Find linked crops
                  const linkedCrops = cropCycles.filter(c => 
                    c.fieldBlock?.toLowerCase() === block.name.toLowerCase() ||
                    block.linkedCropCycleIds?.includes(c.id) ||
                    (c.cropType?.toLowerCase() === block.cropType?.toLowerCase() && c.fieldBlock?.toLowerCase() === block.name.toLowerCase())
                  );

                  return (
                    <tr 
                      key={block.id} 
                      className={`hover:bg-slate-50 transition-colors cursor-pointer ${isSelected ? "bg-amber-50/70 font-bold border-l-4 border-amber-500" : ""}`}
                      onClick={() => {
                        setSelectedBlockId(block.id);
                        if (onSelectParcel) onSelectParcel(block.id);
                      }}
                    >
                      <td className="py-3 px-3">
                        <div className="font-extrabold text-slate-900 flex items-center gap-1.5">
                          <span>{block.name}</span>
                          {isSelected && <span className="text-[9px] bg-amber-500 text-slate-950 font-black px-1.5 py-0.5 rounded">Selected</span>}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">{block.id} {block.soilType ? `• ${block.soilType}` : ''}</div>
                      </td>

                      <td className="py-3 px-3">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-extrabold text-white" style={{ backgroundColor: cropColor.fill }}>
                          {block.cropType}
                        </span>
                        <div className="text-[10px] text-slate-500 mt-0.5">{block.variety}</div>
                      </td>

                      <td className="py-3 px-3 font-mono font-bold text-emerald-800">
                        <div>{areaHa} Ha</div>
                        <div className="text-[10px] text-slate-400 font-normal">{areaM2.toLocaleString()} m² • {areaAc} Ac</div>
                      </td>

                      <td className="py-3 px-3">
                        {linkedCrops.length > 0 ? (
                          <div className="flex flex-col gap-1">
                            {linkedCrops.map(c => (
                              <span key={c.id} className="inline-flex items-center gap-1 px-2 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded text-[10px] font-bold">
                                <Sprout className="w-3 h-3 text-indigo-500" />
                                {c.cropName || c.cropType} ({c.status})
                              </span>
                            ))}
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-400 italic">No cycle linked</span>
                        )}
                      </td>

                      <td className="py-3 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedBlockId(block.id);
                              if (onSelectParcel) onSelectParcel(block.id);
                            }}
                            className="p-1 hover:bg-slate-200 rounded text-indigo-600 transition-colors cursor-pointer"
                            title="Inspect on Leaflet Map"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteBlock(block.id)}
                            className="p-1 hover:bg-rose-100 rounded text-rose-600 transition-colors cursor-pointer"
                            title="Delete Field Block"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: Selected Field Block Inspector & Linked Crop Cycles */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          {activeBlock ? (
            <div className="space-y-4">
              <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                <div>
                  <span className="text-[10px] font-extrabold uppercase text-indigo-600 tracking-wider">Field Block Inspector</span>
                  <h3 className="text-base font-black text-slate-900">{activeBlock.name}</h3>
                </div>
                <span className="px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-mono font-bold">
                  {activeBlock.sizeInHectares || calculateAreaHectares(activeBlock.points)} Ha
                </span>
              </div>

              {/* Dimension Metrics Card */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2 text-xs">
                <div className="font-extrabold text-slate-700 flex items-center justify-between">
                  <span>📐 Area Specifications</span>
                  <span className="text-[10px] font-mono text-slate-400">{activeBlock.id}</span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center font-mono pt-1">
                  <div className="bg-white p-2 rounded-lg border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-sans">Square Meters</div>
                    <div className="font-black text-slate-900">{(activeBlock.sizeInMeters || Math.round((activeBlock.sizeInHectares || calculateAreaHectares(activeBlock.points)) * 10000)).toLocaleString()} m²</div>
                  </div>
                  <div className="bg-white p-2 rounded-lg border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-sans">Hectares</div>
                    <div className="font-black text-emerald-700">{activeBlock.sizeInHectares || calculateAreaHectares(activeBlock.points)} Ha</div>
                  </div>
                  <div className="bg-white p-2 rounded-lg border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-sans">Acres</div>
                    <div className="font-black text-amber-700">{activeBlock.sizeInAcres || Math.round((activeBlock.sizeInHectares || calculateAreaHectares(activeBlock.points)) * 2.47105 * 100) / 100} Ac</div>
                  </div>
                </div>
              </div>

              {/* Linked / Contained Crop Cycles Section */}
              <div className="space-y-3 pt-2">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-black uppercase text-slate-800 tracking-wider flex items-center gap-1.5">
                    <Sprout className="w-4 h-4 text-indigo-600" />
                    <span>Contained Crop Cycles ({activeBlockCropCycles.length})</span>
                  </h4>
                </div>

                {activeBlockCropCycles.length > 0 ? (
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {activeBlockCropCycles.map(c => (
                      <div key={c.id} className="p-3 bg-indigo-50/60 border border-indigo-100 rounded-xl space-y-1.5 text-xs">
                        <div className="flex justify-between items-center font-extrabold text-slate-900">
                          <span className="flex items-center gap-1.5">
                            <Sprout className="w-3.5 h-3.5 text-emerald-600" />
                            {c.cropName || c.cropType} ({c.variety || "Std"})
                          </span>
                          <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 text-[10px] rounded-full">
                            {c.status}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 font-mono">
                          <div>Planted: {c.plantingDate || "N/A"}</div>
                          <div>Target Yield: {((c.expectedYieldKg || 0) / 1000).toFixed(1)} MT</div>
                        </div>

                        {c.expectedHarvestDate && (
                          <div className="text-[10.5px] text-slate-500 flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-slate-400" />
                            <span>Expected Harvest: {c.expectedHarvestDate}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 bg-slate-50 border border-dashed border-slate-300 rounded-xl text-center text-xs text-slate-500 space-y-2">
                    <p>No crop cycle currently linked to <strong>{activeBlock.name}</strong>.</p>
                  </div>
                )}

                {/* Link Unassigned Crop Cycle Dropdown */}
                {cropCycles.filter(c => !c.fieldBlock || c.fieldBlock !== activeBlock.name).length > 0 && (
                  <div className="pt-2 border-t border-slate-100 space-y-1.5">
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase block">
                      🔗 Link Existing Crop Cycle to {activeBlock.name}:
                    </label>
                    <select
                      defaultValue=""
                      onChange={(e) => {
                        const cycleId = e.target.value;
                        if (cycleId && onUpdateCropCycleBlock) {
                          onUpdateCropCycleBlock(cycleId, activeBlock.name);
                        }
                      }}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none"
                    >
                      <option value="">-- Choose Crop Cycle to Link --</option>
                      {cropCycles.map(c => (
                        <option key={c.id} value={c.id}>
                          {c.cropName || c.cropType} ({c.variety}) - Current Block: {c.fieldBlock || "None"}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500 space-y-2">
              <Compass className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="text-xs font-bold">Select a Field Block on the map or ledger to inspect contained crop cycles & dimensions.</p>
            </div>
          )}
        </div>
      </div>

      {/* Simplified "Map New Field Block" Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-[600] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5 text-slate-800 animate-in fade-in duration-200">
            {/* Modal Header */}
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-2xl bg-emerald-100 border border-emerald-200 flex items-center justify-center text-emerald-700 font-bold">
                  🗺️
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">Map New Field Block</h3>
                  <p className="text-[11px] text-slate-500">Specify block name and dimensions in meters, hectares, or acres</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center font-bold text-xs"
              >
                ✕
              </button>
            </div>

            {/* Modal Form Inputs */}
            <div className="space-y-4 text-xs">
              {/* 1. Field Block Name */}
              <div className="space-y-1">
                <label className="font-extrabold text-slate-700 block text-[11px]">
                  1. Field Block Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g., Pivot 1 - North Section"
                  value={newBlockName}
                  onChange={(e) => setNewBlockName(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs outline-none focus:border-indigo-500 focus:bg-white"
                />
              </div>

              {/* 2. Block Size & Unit Selection */}
              <div className="space-y-2.5 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <label className="font-extrabold text-slate-800 block text-[11px] flex items-center gap-1.5">
                    <Ruler className="w-3.5 h-3.5 text-emerald-600" />
                    <span>2. Block Size & Dimensions</span> <span className="text-rose-500">*</span>
                  </label>

                  {/* Input Mode Switcher */}
                  <div className="flex bg-slate-200/80 p-0.5 rounded-xl text-[10.5px] font-extrabold text-slate-600">
                    <button
                      type="button"
                      onClick={() => setDimensionMode("length_width")}
                      className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                        dimensionMode === "length_width" ? "bg-white text-emerald-800 shadow-xs font-black" : "hover:text-slate-900"
                      }`}
                    >
                      <span>📐 Length × Width (m)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setDimensionMode("direct_area")}
                      className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                        dimensionMode === "direct_area" ? "bg-white text-emerald-800 shadow-xs font-black" : "hover:text-slate-900"
                      }`}
                    >
                      <span>📊 Direct Area Input</span>
                    </button>
                  </div>
                </div>

                {dimensionMode === "length_width" ? (
                  <div className="space-y-2 animate-in fade-in duration-150">
                    <div className="grid grid-cols-2 gap-2.5">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-600 block">
                          Length in Meters (m) <span className="text-rose-500">*</span>
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="any"
                            min="1"
                            placeholder="e.g. 200"
                            value={lengthMeters}
                            onChange={(e) => setLengthMeters(e.target.value)}
                            className="w-full pl-3 pr-8 py-2.5 bg-white border border-slate-300 rounded-xl font-mono font-extrabold text-xs outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                          />
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">m</span>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-600 block">
                          Width in Meters (m) <span className="text-rose-500">*</span>
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="any"
                            min="1"
                            placeholder="e.g. 150"
                            value={widthMeters}
                            onChange={(e) => setWidthMeters(e.target.value)}
                            className="w-full pl-3 pr-8 py-2.5 bg-white border border-slate-300 rounded-xl font-mono font-extrabold text-xs outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                          />
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">m</span>
                        </div>
                      </div>
                    </div>

                    {/* Quick Presets */}
                    <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                      <span className="text-[10px] font-bold text-slate-400">Presets:</span>
                      {[
                        { label: "100m × 100m (1 Ha)", l: "100", w: "100" },
                        { label: "200m × 150m (3 Ha)", l: "200", w: "150" },
                        { label: "223.6m × 223.6m (5 Ha)", l: "223.6", w: "223.6" },
                        { label: "500m × 200m (10 Ha)", l: "500", w: "200" }
                      ].map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setLengthMeters(preset.l);
                            setWidthMeters(preset.w);
                          }}
                          className="px-2 py-0.5 bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 rounded-lg text-[10px] font-bold text-slate-600 hover:text-emerald-800 transition cursor-pointer"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2 animate-in fade-in duration-150">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div className="sm:col-span-1">
                        <input
                          type="number"
                          step="any"
                          min="0.01"
                          placeholder="e.g. 5"
                          value={newSizeValue}
                          onChange={(e) => setNewSizeValue(e.target.value)}
                          className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-mono font-extrabold text-xs outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                        />
                      </div>
                      <div className="sm:col-span-2 flex bg-slate-200/70 p-1 rounded-xl border border-slate-200 font-bold text-[11px]">
                        <button
                          type="button"
                          onClick={() => setNewSizeUnit("hectares")}
                          className={`flex-1 py-1.5 rounded-lg transition-all cursor-pointer ${
                            newSizeUnit === "hectares" ? "bg-emerald-600 text-white shadow-xs font-black" : "text-slate-600 hover:text-slate-900"
                          }`}
                        >
                          Hectares (ha)
                        </button>
                        <button
                          type="button"
                          onClick={() => setNewSizeUnit("meters")}
                          className={`flex-1 py-1.5 rounded-lg transition-all cursor-pointer ${
                            newSizeUnit === "meters" ? "bg-emerald-600 text-white shadow-xs font-black" : "text-slate-600 hover:text-slate-900"
                          }`}
                        >
                          Meters (m²)
                        </button>
                        <button
                          type="button"
                          onClick={() => setNewSizeUnit("acres")}
                          className={`flex-1 py-1.5 rounded-lg transition-all cursor-pointer ${
                            newSizeUnit === "acres" ? "bg-emerald-600 text-white shadow-xs font-black" : "text-slate-600 hover:text-slate-900"
                          }`}
                        >
                          Acres (ac)
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Live Area Unit Conversion Banner */}
                <div className="p-3 bg-emerald-500/10 border border-emerald-300/80 rounded-xl space-y-1.5">
                  <div className="flex flex-wrap items-center justify-between gap-1.5 text-xs">
                    <span className="text-emerald-950 font-black flex items-center gap-1.5 text-[11px]">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Real-time Surface Conversions:</span>
                    </span>
                    {dimensionMode === "length_width" && lenVal > 0 && widVal > 0 && (
                      <span className="text-[10px] font-mono font-extrabold text-emerald-800 bg-emerald-100/90 px-2 py-0.5 rounded-md border border-emerald-200">
                        {lenVal}m × {widVal}m = {calculatedM2.toLocaleString()} m²
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-emerald-950 font-mono font-black text-[11px]">
                    <div className="bg-white p-2 rounded-lg border border-emerald-200/80 shadow-2xs">
                      <div className="text-[9px] font-sans font-extrabold text-emerald-700 uppercase tracking-wider">Hectares</div>
                      <div className="text-xs text-slate-900 font-extrabold">{sizeConversion.hectares} Ha</div>
                    </div>
                    <div className="bg-white p-2 rounded-lg border border-emerald-200/80 shadow-2xs">
                      <div className="text-[9px] font-sans font-extrabold text-emerald-700 uppercase tracking-wider">Square Meters</div>
                      <div className="text-xs text-slate-900 font-extrabold">{sizeConversion.meters.toLocaleString()} m²</div>
                    </div>
                    <div className="bg-white p-2 rounded-lg border border-emerald-200/80 shadow-2xs">
                      <div className="text-[9px] font-sans font-extrabold text-emerald-700 uppercase tracking-wider">Acres</div>
                      <div className="text-xs text-slate-900 font-extrabold">{sizeConversion.acres} Acres</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3. Link Crop Cycle */}
              <div className="space-y-1.5 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <label className="font-extrabold text-slate-800 block text-[11px] flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <LinkIcon className="w-3.5 h-3.5 text-emerald-600" />
                    <span>3. Link Active Crop Cycle (Optional)</span>
                  </span>
                  {selectedCropCycleId && (
                    <button
                      type="button"
                      onClick={() => setSelectedCropCycleId("")}
                      className="text-[10px] font-bold text-rose-600 hover:underline cursor-pointer"
                    >
                      Clear Selection
                    </button>
                  )}
                </label>
                <select
                  value={selectedCropCycleId}
                  onChange={(e) => {
                    const cycleId = e.target.value;
                    setSelectedCropCycleId(cycleId);
                    const match = cropCycles.find(c => c.id === cycleId);
                    if (match) {
                      if (match.cropName || match.cropType) setNewCropType(match.cropName || match.cropType);
                      if (match.variety) setNewVariety(match.variety);
                    }
                  }}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-xs outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                >
                  <option value="">-- Select Active Crop Cycle from List to Link --</option>
                  {cropCycles.map(c => (
                    <option key={c.id} value={c.id}>
                      🌾 {c.cropName || c.cropType} ({c.variety || "Std"}) - {c.areaHectares} Ha ({c.status})
                    </option>
                  ))}
                </select>
              </div>

              {/* Crop Catalog & Soil Parameters */}
              <div className="space-y-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-extrabold text-slate-800 block text-[11px] flex items-center gap-1">
                      <Sprout className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Crop Type (African Crop Catalog)</span> <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={newCropType}
                      onChange={(e) => setNewCropType(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-xs outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                    >
                      {AFRICAN_CROPS_LIST.map((group) => (
                        <optgroup key={group.category} label={`📂 ${group.category}`}>
                          {group.items.map((item) => (
                            <option key={item.value} value={item.value}>
                              {item.name}
                            </option>
                          ))}
                        </optgroup>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-extrabold text-slate-800 block text-[11px]">Seed Variety / Hybrid</label>
                    <input
                      type="text"
                      placeholder="e.g. SC 719, Clemson Spineless, Rodade"
                      value={newVariety}
                      onChange={(e) => setNewVariety(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-xs outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="font-extrabold text-slate-800 block text-[11px]">Soil Classification</label>
                  <select
                    value={newSoilType}
                    onChange={(e) => setNewSoilType(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-xs outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                  >
                    <option value="Sandy Clay Loam">Sandy Clay Loam (Prevalent in Lusaka West)</option>
                    <option value="Clay Loam">Clay Loam</option>
                    <option value="Loam">Red Clay Loam</option>
                    <option value="Sandy Loam">Sandy Loam</option>
                    <option value="Alluvial Soil">Alluvial River Basin</option>
                  </select>
                </div>
              </div>

              {/* 4. Polygon Generation Mode */}
              <div className="space-y-1 pt-1">
                <label className="font-extrabold text-slate-700 block text-[11px]">4. Boundary Mapping Method</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setMappingMethod("auto_fit");
                      setIsDrawing(false);
                    }}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                      mappingMethod === "auto_fit" ? "bg-indigo-50 border-indigo-500 text-indigo-950 font-extrabold shadow-2xs" : "bg-slate-50 border-slate-200 text-slate-600"
                    }`}
                  >
                    <div className="font-bold text-xs flex items-center gap-1.5">
                      ⚡ Auto-Fit GIS Polygon
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">Auto-positions boundary at farm coordinates using calculated {sizeConversion.hectares} Ha surface</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setMappingMethod("manual_draw");
                      setIsDrawing(true);
                      setShowAddModal(false);
                    }}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                      mappingMethod === "manual_draw" ? "bg-amber-50 border-amber-500 text-amber-950 font-extrabold shadow-2xs" : "bg-slate-50 border-slate-200 text-slate-600"
                    }`}
                  >
                    <div className="font-bold text-xs flex items-center gap-1.5">
                      ✍️ Draw Vertices on Map
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">Interactively click satellite map points to plot exact custom shape</div>
                  </button>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2.5 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-200 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveNewBlock}
                disabled={!newBlockName.trim() || sizeConversion.hectares <= 0}
                className="px-6 py-2.5 bg-emerald-600 text-white font-black text-xs rounded-xl hover:bg-emerald-500 shadow-md cursor-pointer disabled:opacity-40 flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Save Field Block ({sizeConversion.hectares} Ha)</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

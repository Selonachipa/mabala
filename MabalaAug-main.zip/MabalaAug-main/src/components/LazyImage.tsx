import React, { useState } from "react";

interface LazyImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  className?: string;
  placeholderBg?: string;
}

export default function LazyImage({
  src,
  alt,
  className = "",
  placeholderBg = "bg-slate-200 animate-pulse",
  ...props
}: LazyImageProps) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);

  return (
    <div className={`relative overflow-hidden ${!loaded ? placeholderBg : ""} ${className}`}>
      {!loaded && !error && (
        <div className="absolute inset-0 bg-slate-200/80 backdrop-blur-xs flex items-center justify-center text-[10px] text-slate-400 font-mono">
          <span>3G Low-Res Placeholder</span>
        </div>
      )}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        decoding="async"
        onLoad={() => setLoaded(true)}
        onError={() => {
          setLoaded(true);
          setError(true);
        }}
        className={`transition-opacity duration-300 ${loaded ? "opacity-100" : "opacity-0"} ${className}`}
        {...props}
      />
    </div>
  );
}

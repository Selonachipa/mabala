import React, { useState, useEffect } from "react";
import { jsPDF } from "jspdf";
import { getAllFromOfflineStore } from "../db/offline_db";
import { useConfirm } from "./ConfirmModal";
import { ResponsiveContainer, LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";
import { CropCycle, Milestone, FarmLocation, YieldPricingTier, PricingTierConfig } from "../types";
import ReadOnlyWarningBanner from "./ReadOnlyWarningBanner";
import { AreaCultivatedInputControl } from "./crops/AreaCultivatedInputControl";

export const getDefaultTiers = (splitType: "Flat" | "Grade" | "Size", basePrice: number): YieldPricingTier[] => {
  const p = Number(basePrice) || 12;
  if (splitType === "Grade") {
    return [
      { id: "tier_grade_a", label: "Grade A (Export / Premium)", percentage: 60, pricePerUnit: Number((p * 1.15).toFixed(2)) },
      { id: "tier_grade_b", label: "Grade B (Standard Market)", percentage: 30, pricePerUnit: Number(p.toFixed(2)) },
      { id: "tier_grade_c", label: "Grade C / Processing / Reject", percentage: 10, pricePerUnit: Number((p * 0.5).toFixed(2)) },
    ];
  }
  if (splitType === "Size") {
    return [
      { id: "tier_size_l", label: "Large Size", percentage: 50, pricePerUnit: Number((p * 1.1).toFixed(2)) },
      { id: "tier_size_m", label: "Medium Size", percentage: 35, pricePerUnit: Number(p.toFixed(2)) },
      { id: "tier_size_s", label: "Small / Off-grade", percentage: 15, pricePerUnit: Number((p * 0.65).toFixed(2)) },
    ];
  }
  return [
    { id: "tier_flat", label: "Flat Single Price", percentage: 100, pricePerUnit: p }
  ];
};

interface PricingTierCalculatorProps {
  splitType: "Flat" | "Grade" | "Size";
  setSplitType: (type: "Flat" | "Grade" | "Size") => void;
  tiers: YieldPricingTier[];
  setTiers: React.Dispatch<React.SetStateAction<YieldPricingTier[]>>;
  expectedSellingPricePerUnit: number;
  setExpectedSellingPricePerUnit: (val: number) => void;
  expectedSellingPricePerKg: number;
  setExpectedSellingPricePerKg: (val: number) => void;
  measuredInKgOrUnits: "Kg" | "Units";
  harvestUnitName: string;
  totalVolume: number;
  computedRevenueProjection: number;
  currencySymbol: string;
  sectionLetter?: string;
}

export const PricingTierCalculator: React.FC<PricingTierCalculatorProps> = ({
  splitType,
  setSplitType,
  tiers,
  setTiers,
  expectedSellingPricePerUnit,
  setExpectedSellingPricePerUnit,
  expectedSellingPricePerKg,
  setExpectedSellingPricePerKg,
  measuredInKgOrUnits,
  harvestUnitName,
  totalVolume,
  computedRevenueProjection,
  currencySymbol,
  sectionLetter = "E"
}) => {
  const basePrice = measuredInKgOrUnits === "Units" ? expectedSellingPricePerUnit : expectedSellingPricePerKg;

  const handleSplitTypeChange = (newType: "Flat" | "Grade" | "Size") => {
    setSplitType(newType);
    setTiers(getDefaultTiers(newType, basePrice || 12));
  };

  const totalTierPct = tiers.reduce((sum, t) => sum + (Number(t.percentage) || 0), 0);

  const updateTier = (id: string, field: keyof YieldPricingTier, value: any) => {
    setTiers(prev => prev.map(t => t.id === id ? { ...t, [field]: value } : t));
  };

  const addTier = () => {
    const nextNum = tiers.length + 1;
    const rem = Math.max(0, 100 - totalTierPct);
    setTiers(prev => [
      ...prev,
      {
        id: `tier_custom_${Date.now()}`,
        label: `Tier ${nextNum} / Custom`,
        percentage: rem,
        pricePerUnit: basePrice
      }
    ]);
  };

  const removeTier = (id: string) => {
    if (tiers.length <= 1) return;
    setTiers(prev => prev.filter(t => t.id !== id));
  };

  const fillRemainingTier = () => {
    const rem = 100 - totalTierPct;
    if (rem <= 0) return;
    setTiers(prev => [
      ...prev,
      {
        id: `tier_ungraded_${Date.now()}`,
        label: "Ungraded / Other",
        percentage: rem,
        pricePerUnit: Number((basePrice * 0.5).toFixed(2))
      }
    ]);
  };

  return (
    <div className="space-y-4 bg-emerald-50/40 p-4 rounded-xl border border-emerald-100">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-emerald-200/60 pb-3">
        <div>
          <h4 className="text-xs font-black uppercase text-emerald-800 tracking-wider">
            {sectionLetter}. Expected Revenue Pricing Calculator (Grade/Size Split Tiers)
          </h4>
          <p className="text-[11px] text-slate-500 font-medium">
            Choose flat single price or split expected yield across Grade (A/B/C) or Size (L/M/S) tiers. Total percentage must equal 100%.
          </p>
        </div>

        {/* Mode Selector */}
        <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-emerald-200 shrink-0">
          <button
            type="button"
            onClick={() => handleSplitTypeChange("Flat")}
            className={`px-2.5 py-1 text-[10px] font-bold rounded transition-colors cursor-pointer ${
              splitType === "Flat" ? "bg-emerald-600 text-white shadow-xs" : "text-slate-600 hover:bg-slate-100"
            }`}
          >
            Flat Price
          </button>
          <button
            type="button"
            onClick={() => handleSplitTypeChange("Grade")}
            className={`px-2.5 py-1 text-[10px] font-bold rounded transition-colors cursor-pointer ${
              splitType === "Grade" ? "bg-emerald-600 text-white shadow-xs" : "text-slate-600 hover:bg-slate-100"
            }`}
          >
            Grade-Split (A/B/C)
          </button>
          <button
            type="button"
            onClick={() => handleSplitTypeChange("Size")}
            className={`px-2.5 py-1 text-[10px] font-bold rounded transition-colors cursor-pointer ${
              splitType === "Size" ? "bg-emerald-600 text-white shadow-xs" : "text-slate-600 hover:bg-slate-100"
            }`}
          >
            Size-Split (L/M/S)
          </button>
        </div>
      </div>

      {splitType === "Flat" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-semibold">
          <div>
            <label className="text-[10px] text-slate-500 block mb-1">Expected Price per Unit ({harvestUnitName})</label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 font-bold">{currencySymbol}</span>
              <input 
                type="number" 
                step="0.1"
                value={expectedSellingPricePerUnit} 
                onChange={e => setExpectedSellingPricePerUnit(Number(e.target.value))} 
                className="w-full pl-7 text-xs border bg-white rounded p-2 text-slate-700 font-mono font-bold"
                disabled={measuredInKgOrUnits === "Kg"}
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] text-slate-500 block mb-1">Expected Price per Kilogram (Kg)</label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 font-bold">{currencySymbol}</span>
              <input 
                type="number" 
                step="0.1"
                value={expectedSellingPricePerKg} 
                onChange={e => setExpectedSellingPricePerKg(Number(e.target.value))} 
                className="w-full pl-7 text-xs border bg-white rounded p-2 text-slate-700 font-mono font-bold"
              />
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {/* Allocation Progress Bar */}
          <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-2">
            <div className="flex justify-between items-center text-xs font-bold">
              <span className="text-slate-700">
                Tier Yield Allocation Split ({splitType} Mode)
              </span>
              <span className={`font-mono text-xs ${
                totalTierPct === 100 ? "text-emerald-600 font-black" :
                totalTierPct > 100 ? "text-rose-600 font-black animate-pulse" : "text-amber-600 font-bold"
              }`}>
                {totalTierPct}% / 100% Allocated
              </span>
            </div>

            <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden flex">
              {tiers.map((tier, idx) => {
                const colors = [
                  "bg-emerald-500", "bg-sky-500", "bg-amber-500", "bg-indigo-500", "bg-purple-500"
                ];
                const pct = Math.min(100, Math.max(0, Number(tier.percentage) || 0));
                return (
                  <div
                    key={tier.id}
                    style={{ width: `${pct}%` }}
                    className={`${colors[idx % colors.length]} h-full transition-all duration-300`}
                    title={`${tier.label}: ${pct}%`}
                  />
                );
              })}
            </div>

            {totalTierPct > 100 && (
              <div className="p-2 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs font-bold flex items-center justify-between">
                <span>⚠️ Allocation total ({totalTierPct}%) exceeds 100%! Save is blocked until reduced to 100%.</span>
              </div>
            )}

            {totalTierPct < 100 && (
              <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 text-xs font-medium flex flex-wrap items-center justify-between gap-2">
                <span>⚠️ {100 - totalTierPct}% of yield is unassigned. Total allocation must equal 100% to save.</span>
                <button
                  type="button"
                  onClick={fillRemainingTier}
                  className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold text-[10px] rounded transition-colors cursor-pointer"
                >
                  + Add {100 - totalTierPct}% as Ungraded/Other
                </button>
              </div>
            )}
          </div>

          {/* Tier Table */}
          <div className="space-y-2">
            <div className="grid grid-cols-12 gap-2 text-[10px] font-black uppercase text-slate-500 px-2">
              <span className="col-span-4">Pricing Tier Label</span>
              <span className="col-span-2">Yield Split %</span>
              <span className="col-span-3">Price / {measuredInKgOrUnits === "Units" ? harvestUnitName : "Kg"}</span>
              <span className="col-span-2 text-right">Projected Value</span>
              <span className="col-span-1 text-center">Action</span>
            </div>

            {tiers.map((tier) => {
              const tierVol = ((Number(tier.percentage) || 0) / 100) * totalVolume;
              const tierVal = tierVol * (Number(tier.pricePerUnit) || 0);

              return (
                <div key={tier.id} className="grid grid-cols-12 gap-2 items-center bg-white p-2 rounded-xl border border-slate-200 text-xs">
                  <div className="col-span-4">
                    <input
                      type="text"
                      value={tier.label}
                      onChange={(e) => updateTier(tier.id, "label", e.target.value)}
                      className="w-full text-xs font-bold border border-slate-200 rounded p-1.5 text-slate-800"
                      placeholder="e.g. Grade A"
                    />
                  </div>

                  <div className="col-span-2 relative">
                    <input
                      type="number"
                      step="1"
                      min="0"
                      max="100"
                      value={tier.percentage}
                      onChange={(e) => updateTier(tier.id, "percentage", Number(e.target.value))}
                      className="w-full text-xs font-mono font-bold border border-slate-200 rounded p-1.5 text-slate-800 pr-5"
                    />
                    <span className="absolute right-2 top-2 text-[10px] font-bold text-slate-400">%</span>
                  </div>

                  <div className="col-span-3 relative">
                    <span className="absolute left-2 top-2 text-[10px] font-bold text-slate-400">{currencySymbol}</span>
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      value={tier.pricePerUnit}
                      onChange={(e) => updateTier(tier.id, "pricePerUnit", Number(e.target.value))}
                      className="w-full text-xs font-mono font-bold border border-slate-200 rounded p-1.5 pl-5 text-slate-800"
                    />
                  </div>

                  <div className="col-span-2 text-right font-mono font-extrabold text-emerald-700">
                    {currencySymbol}{tierVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </div>

                  <div className="col-span-1 text-center">
                    <button
                      type="button"
                      onClick={() => removeTier(tier.id)}
                      disabled={tiers.length <= 1}
                      className="p-1 text-slate-400 hover:text-rose-600 disabled:opacity-30 cursor-pointer transition-colors"
                      title="Remove Tier"
                    >
                      ✕
                    </button>
                  </div>
                </div>
              );
            })}

            <button
              type="button"
              onClick={addTier}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-dashed border-slate-300 transition-colors cursor-pointer flex items-center justify-center gap-1"
            >
              + Add Custom Pricing Tier
            </button>
          </div>
        </div>
      )}

      {/* Outcome Totals */}
      <div className="p-3.5 bg-emerald-700 text-white rounded-xl flex flex-wrap justify-between items-center gap-3 shadow-md">
        <div className="space-y-0.5">
          <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-100 block">
            Total Anticipated Yield Volume
          </span>
          <p className="text-xs font-semibold">
            Expected Volume: <strong className="font-mono text-white">{totalVolume.toLocaleString()} {measuredInKgOrUnits === "Units" ? harvestUnitName + "s" : "Kg"}</strong>
            {splitType !== "Flat" && (
              <span className="ml-2 text-[10px] px-1.5 py-0.5 bg-emerald-800 text-emerald-200 rounded font-mono font-bold">
                {splitType}-Split Tiered
              </span>
            )}
          </p>
        </div>
        <div className="text-right">
          <span className="text-[9.5px] uppercase font-bold tracking-widest text-emerald-100 block">
            PROJECTED REVENUE TARGET (ESTIMATED PROJECTION)
          </span>
          <span className="text-xl font-black font-mono">
            {currencySymbol}{computedRevenueProjection.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </span>
        </div>
      </div>
    </div>
  );
};
import { useOperationalSafetyCheck } from "./BoundaryGuard";
import { GrowthGuideTab } from "./agronomy/GrowthGuideTab";
import { VendorBoostPanel } from "./agronomy/VendorBoostPanel";
import { AgroGuidanceAdminPanel } from "./agronomy/AgroGuidanceAdminPanel";
import { ZambiaNpkCalculator } from "./agronomy/ZambiaNpkCalculator";
import { BoundaryMapper } from "./agc/BoundaryMapper";
import LeafletFieldMap, { MappedFieldBlock } from "./LeafletFieldMap";
import YieldForecastingModule from "./YieldForecastingModule";
import LogHarvestAction from "./hsw/LogHarvestAction";
import { 
  Plus, Check, Play, Calendar, DollarSign, Award, BookOpen, Trash, 
  FileSpreadsheet, Sliders, Calculator, LineChart, Cpu, TrendingUp, 
  BarChart3, AlertCircle, AlertTriangle, ShieldCheck, Flame, Info, CheckCircle2, ChevronRight, Sprout, Sparkles,
  Share2, ArrowUpDown, TestTube
} from "lucide-react";

export interface CropVarietyDetail {
  crop: string;
  variety: string;
  maturityDays: number;
}

export const CROP_VARIETIES: CropVarietyDetail[] = [
  // Maize
  { crop: "Maize", variety: "SC 419 (Early Maturing)", maturityDays: 90 },
  { crop: "Maize", variety: "SC 659 (Medium Maturing)", maturityDays: 120 },
  { crop: "Maize", variety: "SC 719 (Late Maturing)", maturityDays: 140 },
  { crop: "Fresh Maize", variety: "SC 301 (Sweet/Fresh)", maturityDays: 80 },
  { crop: "Sweet Corn", variety: "Honey & Pearl", maturityDays: 75 },
  // Vegetables / Greens
  { crop: "Green beans", variety: "Contender (Bush bean)", maturityDays: 50 },
  { crop: "Green beans", variety: "Provider (Very Early)", maturityDays: 45 },
  { crop: "Green beans", variety: "Kentucky Wonder (Pole)", maturityDays: 65 },
  { crop: "Tomato", variety: "Money Maker (Indeterminate)", maturityDays: 80 },
  { crop: "Tomato", variety: "Rodade (Determinate)", maturityDays: 90 },
  { crop: "Tomato", variety: "Heinz 1370", maturityDays: 85 },
  { crop: "Cabbage", variety: "Drumhead (Large)", maturityDays: 100 },
  { crop: "Cabbage", variety: "Marcanta F1", maturityDays: 80 },
  { crop: "Cabbage", variety: "Star 3311 F1", maturityDays: 90 },
  { crop: "Onion", variety: "Texas Grano (Short Day)", maturityDays: 110 },
  { crop: "Onion", variety: "Red Pinoy", maturityDays: 120 },
  { crop: "Garlic", variety: "Local White", maturityDays: 130 },
  { crop: "Garlic", variety: "Giant White", maturityDays: 140 },
  { crop: "Irish Potatoes", variety: "BP1 (Medium Early)", maturityDays: 100 },
  { crop: "Irish Potatoes", variety: "Mondial (Late)", maturityDays: 120 },
  { crop: "Sweet Potatoes", variety: "Kembia (Orange Fleshed)", maturityDays: 120 },
  { crop: "Sweet Potatoes", variety: "Chingovwa", maturityDays: 150 },
  { crop: "Soybeans", variety: "Safari (Early)", maturityDays: 110 },
  { crop: "Soybeans", variety: "ZMS 512 (Medium)", maturityDays: 125 },
  { crop: "Soybeans (Soya)", variety: "Safari (Early)", maturityDays: 110 },
  { crop: "Soybeans (Soya)", variety: "ZMS 512 (Medium)", maturityDays: 125 },
  { crop: "Kalembula (Sweet Potato Leaves)", variety: "Local Vine", maturityDays: 30 },
  { crop: "Bondwe (Amaranthus)", variety: "Local Green", maturityDays: 25 },
  { crop: "Chibwabwa (Pumpkin Leaves)", variety: "Local Runner", maturityDays: 40 },
  { crop: "Mupilu (Mustard Leaves)", variety: "Broad Leaf", maturityDays: 35 },
  { crop: "Cabbage", variety: "Copenhagen Market", maturityDays: 75 },
  { crop: "Rape (Greens)", variety: "English Giant", maturityDays: 40 },
  { crop: "Spinach", variety: "Fordhook Giant", maturityDays: 50 },
  { crop: "Okra", variety: "Clemson Spineless", maturityDays: 55 },
  { crop: "Okra", variety: "Emerald", maturityDays: 60 },
  { crop: "Cucumbers", variety: "Ashley", maturityDays: 60 },
  { crop: "Impwa (African Garden Egg / Eggplant)", variety: "Local White Round", maturityDays: 75 },
  { crop: "Watermelon", variety: "Crimson Sweet", maturityDays: 85 },
  { crop: "Watermelon", variety: "Sugar Baby", maturityDays: 75 }
];

export const AFRICAN_CROPS_LIST = [
  {
    category: "Horticultural Leafy Greens & Vegetables",
    items: [
      { name: "Kalembula (Sweet Potato Leaves)", value: "Kalembula" },
      { name: "Bondwe (Amaranthus)", value: "Bondwe" },
      { name: "Chibwabwa (Pumpkin Leaves)", value: "Chibwabwa" },
      { name: "Mupilu (Mustard Leaves)", value: "Mupilu" },
      { name: "Lettac (Lettuce)", value: "Lettac" },
      { name: "Cabbage", value: "Cabbage" },
      { name: "Rape (Greens)", value: "Rape" },
      { name: "Spinach", value: "Spinach" },
    ]
  },
  {
    category: "Solanaceous & Fruit Vegetables",
    items: [
      { name: "Tomato", value: "Tomato" },
      { name: "Impwa (African Garden Egg / Eggplant)", value: "Impwa" },
      { name: "Eggplants", value: "Eggplants" },
      { name: "Green Paper (Green Pepper)", value: "Green Paper" },
      { name: "Red Paper (Red Pepper)", value: "Red Paper" },
      { name: "Yellow Paper (Yellow Pepper)", value: "Yellow Paper" },
      { name: "Chili (Chilli Pepper)", value: "Chili" },
      { name: "Okra", value: "Okra" },
      { name: "Cucumbers", value: "Cucumbers" },
    ]
  },
  {
    category: "Roots, Tubers & Bulbs",
    items: [
      { name: "Sweet Potatoes", value: "Sweet Potatoes" },
      { name: "Irish Potatoes", value: "Irish Potatoes" },
      { name: "Cassava", value: "Cassava" },
      { name: "Onion", value: "Onion" },
      { name: "Garlic", value: "Garlic" },
      { name: "Carrots", value: "Carrots" },
    ]
  },
  {
    category: "Field Crops & Grains",
    items: [
      { name: "Fresh Maize", value: "Fresh Maize" },
      { name: "Maize (White/Grain/Commercial)", value: "Maize" },
      { name: "Green beans", value: "Green beans" },
      { name: "Soybeans (Soya)", value: "Soybeans" },
      { name: "Wheat", value: "Wheat" },
      { name: "Sunflower", value: "Sunflower" },
      { name: "Groundnuts (Peanuts)", value: "Groundnuts" },
      { name: "Sorghum", value: "Sorghum" },
      { name: "Millet", value: "Millet" },
    ]
  },
  {
    category: "Commercial & Plantation Crops",
    items: [
      { name: "Tobacco", value: "Tobacco" },
      { name: "Cotton", value: "Cotton" },
      { name: "Sugarcane", value: "Sugarcane" },
      { name: "Coffee", value: "Coffee" },
    ]
  }
];

export const CROP_TEMPLATES: Record<string, {
  unitName: string;
  measuredIn: "Units" | "Kg";
  avgUnitsPerPlant: number;
  avgWeightPerPlantKg: number;
  recommendedSpacingWithinRow: number; // cm
  recommendedRowSpacing: number; // cm
  recommendedSurvival: number; // %
  recommendedHarvest: number; // %
  defaultPricePerUnit: number;
  defaultPricePerKg: number;
  plantingMethod: "Field" | "Bed";
}> = {
  "Maize": {
    unitName: "Cob",
    measuredIn: "Units",
    avgUnitsPerPlant: 1,
    avgWeightPerPlantKg: 0.35,
    recommendedSpacingWithinRow: 25,
    recommendedRowSpacing: 75,
    recommendedSurvival: 95,
    recommendedHarvest: 90,
    defaultPricePerUnit: 5,
    defaultPricePerKg: 12,
    plantingMethod: "Field"
  },
  "Fresh Maize": {
    unitName: "Cob",
    measuredIn: "Units",
    avgUnitsPerPlant: 1,
    avgWeightPerPlantKg: 0.35,
    recommendedSpacingWithinRow: 25,
    recommendedRowSpacing: 75,
    recommendedSurvival: 96,
    recommendedHarvest: 92,
    defaultPricePerUnit: 6,
    defaultPricePerKg: 14,
    plantingMethod: "Field"
  },
  "Sweet Corn": {
    unitName: "Cob",
    measuredIn: "Units",
    avgUnitsPerPlant: 2,
    avgWeightPerPlantKg: 0.3,
    recommendedSpacingWithinRow: 30,
    recommendedRowSpacing: 75,
    recommendedSurvival: 95,
    recommendedHarvest: 88,
    defaultPricePerUnit: 8,
    defaultPricePerKg: 18,
    plantingMethod: "Field"
  },
  "Onion": {
    unitName: "Bulb",
    measuredIn: "Units",
    avgUnitsPerPlant: 1,
    avgWeightPerPlantKg: 0.15,
    recommendedSpacingWithinRow: 15,
    recommendedRowSpacing: 15,
    recommendedSurvival: 95,
    recommendedHarvest: 92,
    defaultPricePerUnit: 2,
    defaultPricePerKg: 15,
    plantingMethod: "Bed"
  },
  "Garlic": {
    unitName: "Bulb",
    measuredIn: "Units",
    avgUnitsPerPlant: 1,
    avgWeightPerPlantKg: 0.08,
    recommendedSpacingWithinRow: 10,
    recommendedRowSpacing: 15,
    recommendedSurvival: 96,
    recommendedHarvest: 94,
    defaultPricePerUnit: 4,
    defaultPricePerKg: 25,
    plantingMethod: "Bed"
  },
  "Cabbage": {
    unitName: "Head",
    measuredIn: "Units",
    avgUnitsPerPlant: 1,
    avgWeightPerPlantKg: 1.5,
    recommendedSpacingWithinRow: 45,
    recommendedRowSpacing: 45,
    recommendedSurvival: 94,
    recommendedHarvest: 88,
    defaultPricePerUnit: 12,
    defaultPricePerKg: 8,
    plantingMethod: "Bed"
  },
  "Tomato": {
    unitName: "Kg",
    measuredIn: "Kg",
    avgUnitsPerPlant: 10,
    avgWeightPerPlantKg: 1.5,
    recommendedSpacingWithinRow: 50,
    recommendedRowSpacing: 60,
    recommendedSurvival: 92,
    recommendedHarvest: 85,
    defaultPricePerUnit: 1,
    defaultPricePerKg: 20,
    plantingMethod: "Field"
  },
  "Irish Potatoes": {
    unitName: "Kg",
    measuredIn: "Kg",
    avgUnitsPerPlant: 8,
    avgWeightPerPlantKg: 0.8,
    recommendedSpacingWithinRow: 30,
    recommendedRowSpacing: 75,
    recommendedSurvival: 95,
    recommendedHarvest: 90,
    defaultPricePerUnit: 2,
    defaultPricePerKg: 16,
    plantingMethod: "Field"
  },
  "Sweet Potatoes": {
    unitName: "Kg",
    measuredIn: "Kg",
    avgUnitsPerPlant: 6,
    avgWeightPerPlantKg: 0.6,
    recommendedSpacingWithinRow: 30,
    recommendedRowSpacing: 90,
    recommendedSurvival: 96,
    recommendedHarvest: 90,
    defaultPricePerUnit: 1,
    defaultPricePerKg: 14,
    plantingMethod: "Field"
  },
  "Tobacco": {
    unitName: "Plant",
    measuredIn: "Units",
    avgUnitsPerPlant: 1,
    avgWeightPerPlantKg: 0.25,
    recommendedSpacingWithinRow: 50,
    recommendedRowSpacing: 100,
    recommendedSurvival: 95,
    recommendedHarvest: 90,
    defaultPricePerUnit: 15,
    defaultPricePerKg: 45,
    plantingMethod: "Field"
  },
  "Pineapple": {
    unitName: "Fruit",
    measuredIn: "Units",
    avgUnitsPerPlant: 1,
    avgWeightPerPlantKg: 1.8,
    recommendedSpacingWithinRow: 30,
    recommendedRowSpacing: 90,
    recommendedSurvival: 98,
    recommendedHarvest: 95,
    defaultPricePerUnit: 25,
    defaultPricePerKg: 15,
    plantingMethod: "Field"
  },
  "Watermelon": {
    unitName: "Fruit",
    measuredIn: "Units",
    avgUnitsPerPlant: 2,
    avgWeightPerPlantKg: 5.0,
    recommendedSpacingWithinRow: 90,
    recommendedRowSpacing: 150,
    recommendedSurvival: 92,
    recommendedHarvest: 85,
    defaultPricePerUnit: 35,
    defaultPricePerKg: 7,
    plantingMethod: "Field"
  }
};

interface CropsPanelProps {
  crops: CropCycle[];
  onAddCrop: (crop: CropCycle) => void;
  onEditCrop?: (crop: CropCycle, auditDetails?: string) => void;
  onUpdateMilestone: (cropId: string, milestoneId: string, isCompleted: boolean) => void;
  onUpdateStatus: (cropId: string, status: CropCycle["status"]) => void;
  onDeleteCrop?: (id: string) => void;
  isReadonly: boolean;
  currencySymbol: string;
  onGotoCsvImport?: (targetModule: "expenses" | "crops" | "livestock") => void;
  tenantId?: string;
  userRole?: string;
  farmLocation?: FarmLocation;
  onNavigateToAdvisory?: () => void;
  onNavigateToMarketplace?: () => void;
  onTopUpCredits?: () => void;
  onActivateSubscription?: () => void;
}

export default function CropsPanel({ 
  crops, 
  onAddCrop, 
  onEditCrop,
  onUpdateMilestone, 
  onUpdateStatus, 
  onDeleteCrop, 
  isReadonly, 
  currencySymbol,
  onGotoCsvImport,
  tenantId = "demo_tenant",
  userRole = "farmer",
  farmLocation,
  onNavigateToAdvisory,
  onNavigateToMarketplace,
  onTopUpCredits,
  onActivateSubscription
}: CropsPanelProps) {
  const confirm = useConfirm();
  useOperationalSafetyCheck("CropsPanel");
  const [activeTab, setActiveTab] = useState<"batches" | "forecaster" | "plot_mapper" | "npk_calculator">("batches");
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedCropIds, setSelectedCropIds] = useState<string[]>([]);
  const [batchCropStatus, setBatchCropStatus] = useState<"Planning" | "Active" | "Harvested" | "Sold">("Active");
  const [selectedHarvestCrop, setSelectedHarvestCrop] = useState<CropCycle | null>(null);
  const [deliveryNotes, setDeliveryNotes] = useState<any[]>([]);
  const [cardTabs, setCardTabs] = useState<Record<string, "growth_guide" | "milestones" | "sales_margin">>({});

  // Mapped Field Blocks state for the Plot Polygon Mapper
  const [mappedBlocks, setMappedBlocks] = useState<MappedFieldBlock[]>(() => [
    {
      id: "BLOCK-001",
      name: "Pivot 1 - North Block",
      cropType: "Maize",
      variety: "SC 719",
      cycleStatus: "Vegetative",
      soilType: "Sandy Clay Loam",
      expectedYieldKg: 45000,
      plantingDate: "2026-10-15",
      healthStatus: "Optimal Vigour",
      sizeValue: 10,
      sizeUnit: "hectares",
      sizeInHectares: 10,
      sizeInMeters: 100000,
      sizeInAcres: 24.71,
      points: [
        { lat: -14.6520, lng: 28.5050 },
        { lat: -14.6520, lng: 28.5085 },
        { lat: -14.6550, lng: 28.5085 },
        { lat: -14.6550, lng: 28.5050 }
      ]
    },
    {
      id: "BLOCK-002",
      name: "Block B - Soybean Field",
      cropType: "Soybeans",
      variety: "Sofu 1",
      cycleStatus: "Vegetative",
      soilType: "Loam",
      expectedYieldKg: 18000,
      plantingDate: "2026-11-01",
      healthStatus: "Optimal Vigour",
      sizeValue: 6,
      sizeUnit: "hectares",
      sizeInHectares: 6,
      sizeInMeters: 60000,
      sizeInAcres: 14.83,
      points: [
        { lat: -14.6560, lng: 28.5050 },
        { lat: -14.6560, lng: 28.5080 },
        { lat: -14.6580, lng: 28.5080 },
        { lat: -14.6580, lng: 28.5050 }
      ]
    }
  ]);

  const handleUpdateCropCycleBlock = (cropCycleId: string, blockName: string) => {
    const targetCrop = crops.find(c => c.id === cropCycleId);
    if (targetCrop && onEditCrop) {
      onEditCrop({
        ...targetCrop,
        fieldBlock: blockName
      });
    }
  };

  const getDaysToHarvestDisplay = (plantedStr: string, harvestStr: string, status: string) => {
    if (!plantedStr || !harvestStr) return null;
    const today = new Date();
    today.setHours(0,0,0,0);
    const planted = new Date(plantedStr);
    planted.setHours(0,0,0,0);
    const harvest = new Date(harvestStr);
    harvest.setHours(0,0,0,0);
    
    const totalDays = Math.max(1, Math.round((harvest.getTime() - planted.getTime()) / (1000 * 60 * 60 * 24)));
    const daysRemaining = Math.round((harvest.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (status === "Harvested" || status === "Sold") {
      return (
        <div className="space-y-1 w-full mt-1.5">
          <div className="px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-lg text-[10px] font-black uppercase inline-flex items-center gap-1 border border-emerald-200">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
            Completed Cycle ({totalDays} Days)
          </div>
          <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500 transition-all duration-500" style={{ width: "100%" }} />
          </div>
        </div>
      );
    }
    
    const daysPassed = Math.max(0, totalDays - daysRemaining);
    const progressPercent = Math.min(100, Math.max(0, Math.round((daysPassed / totalDays) * 100)));

    let statusText = "";
    let badgeColor = "";
    let dotColor = "";
    
    if (daysRemaining < 0) {
      const overdueDays = Math.abs(daysRemaining);
      statusText = `⚠️ Harvest overdue by ${overdueDays} day${overdueDays > 1 ? "s" : ""}`;
      badgeColor = "bg-rose-50 text-rose-800 border-rose-200";
      dotColor = "bg-rose-500";
    } else if (daysRemaining === 0) {
      statusText = "⭐ Harvest due today!";
      badgeColor = "bg-amber-50 text-amber-800 border-amber-200 animate-pulse";
      dotColor = "bg-amber-500";
    } else {
      statusText = `⏳ ${daysRemaining} Day${daysRemaining > 1 ? "s" : ""} to Harvest`;
      const isClose = daysRemaining <= 14;
      badgeColor = isClose 
        ? "bg-amber-50 text-amber-800 border-amber-200" 
        : "bg-blue-50 text-blue-800 border-blue-200";
      dotColor = isClose ? "bg-amber-500" : "bg-blue-500";
    }
    
    return (
      <div className="space-y-1 w-full mt-1.5">
        <div className={`px-2 py-1 ${badgeColor} rounded-lg text-[9.5px] font-black uppercase flex items-center justify-between border`}>
          <div className="flex items-center gap-1">
            <span className={`w-1.5 h-1.5 ${dotColor} rounded-full animate-pulse`} />
            <span>{statusText}</span>
          </div>
          <span className="text-[9px] text-slate-500 font-mono font-bold">Progress: {progressPercent}%</span>
        </div>
        <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
          <div className={`h-full ${daysRemaining < 0 ? "bg-rose-500" : daysRemaining === 0 ? "bg-amber-500" : "bg-blue-500"} transition-all duration-500`} style={{ width: `${progressPercent}%` }} />
        </div>
      </div>
    );
  };

  useEffect(() => {
    const loadNotes = async () => {
      try {
        const dns = await getAllFromOfflineStore("delivery_notes");
        if (dns && dns.length > 0) {
          setDeliveryNotes(dns);
        }
      } catch (e) {
        console.warn("Failed loading delivery notes in CropsPanel:", e);
      }
    };
    loadNotes();
  }, [crops]);
  
  // Custom states for templates and dynamically calculated fields
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");
  
  // Form State
  const [cropType, setCropType] = useState("");
  const [customCropType, setCustomCropType] = useState("");
  const [variety, setVariety] = useState("");
  const [customVariety, setCustomVariety] = useState("");
  const [maturityDays, setMaturityDays] = useState(90);
  const [plantingDate, setPlantingDate] = useState(new Date().toISOString().split('T')[0]);
  const [expectedHarvestDate, setExpectedHarvestDate] = useState("");
  const [fieldBlock, setFieldBlock] = useState("");
  const [areaHectares, setAreaHectares] = useState(2);
  const [expectedYieldKg, setExpectedYieldKg] = useState(5000);

  // Edit Mode States
  const [editingCrop, setEditingCrop] = useState<CropCycle | null>(null);
  const [editCropType, setEditCropType] = useState("");
  const [editCustomCropType, setEditCustomCropType] = useState("");
  const [editVariety, setEditVariety] = useState("");
  const [editCustomVariety, setEditCustomVariety] = useState("");
  const [editMaturityDays, setEditMaturityDays] = useState(90);
  const [editPlantingDate, setEditPlantingDate] = useState("");
  const [editExpectedHarvestDate, setEditExpectedHarvestDate] = useState("");
  const [editFieldBlock, setEditFieldBlock] = useState("");
  const [editAreaHectares, setEditAreaHectares] = useState(2);
  const [editPlantingMethod, setEditPlantingMethod] = useState<"Field" | "Bed">("Field");
  const [editMeasuredInKgOrUnits, setEditMeasuredInKgOrUnits] = useState<"Kg" | "Units">("Kg");
  const [editHarvestUnitName, setEditHarvestUnitName] = useState("Kg");
  const [editExpectedSellingPricePerUnit, setEditExpectedSellingPricePerUnit] = useState(0);
  const [editExpectedSellingPricePerKg, setEditExpectedSellingPricePerKg] = useState(12);
  const [editPlantSpacingWithinRow, setEditPlantSpacingWithinRow] = useState(25); // cm
  const [editRowSpacing, setEditRowSpacing] = useState(75); // cm
  const [editBedWidth, setEditBedWidth] = useState(1.2); // m
  const [editBedLength, setEditBedLength] = useState(20); // m
  const [editNumberOfBeds, setEditNumberOfBeds] = useState(10);
  const [editExpectedSurvivalRate, setEditExpectedSurvivalRate] = useState(95); // %
  const [editExpectedHarvestRate, setEditExpectedHarvestRate] = useState(90); // %
  const [editAvgHarvestUnitsPerPlant, setEditAvgHarvestUnitsPerPlant] = useState(1);
  const [editAverageWeightPerPlantKg, setEditAverageWeightPerPlantKg] = useState(0.35);
  const [editStatus, setEditStatus] = useState<CropCycle["status"]>("Planning");

  // Edit computed values
  const [editComputedTotalPopulation, setEditComputedTotalPopulation] = useState(0);
  const [editComputedLivePlants, setEditComputedLivePlants] = useState(0);
  const [editComputedHarvestPopulation, setEditComputedHarvestPopulation] = useState(0);
  const [editComputedExpectedUnits, setEditComputedExpectedUnits] = useState(0);
  const [editComputedExpectedKg, setEditComputedExpectedKg] = useState(0);
  const [editComputedRevenueProjection, setEditComputedRevenueProjection] = useState(0);

  // Sorting state for crop cards
  const [sortBy, setSortBy] = useState<"default" | "plantingDateDesc" | "plantingDateAsc" | "expectedHarvestDateAsc" | "expectedHarvestDateDesc">("default");

  // Sorted crops list computation
  const sortedCrops = React.useMemo(() => {
    const list = [...crops];
    if (sortBy === "plantingDateAsc") {
      return list.sort((a, b) => new Date(a.plantingDate || 0).getTime() - new Date(b.plantingDate || 0).getTime());
    }
    if (sortBy === "plantingDateDesc") {
      return list.sort((a, b) => new Date(b.plantingDate || 0).getTime() - new Date(a.plantingDate || 0).getTime());
    }
    if (sortBy === "expectedHarvestDateAsc") {
      return list.sort((a, b) => new Date(a.expectedHarvestDate || 0).getTime() - new Date(b.expectedHarvestDate || 0).getTime());
    }
    if (sortBy === "expectedHarvestDateDesc") {
      return list.sort((a, b) => new Date(b.expectedHarvestDate || 0).getTime() - new Date(a.expectedHarvestDate || 0).getTime());
    }
    return list;
  }, [crops, sortBy]);

  // Share Crop Harvest Summary PDF Report
  const handleShareCropSummaryPdf = async (crop: CropCycle) => {
    try {
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });

      // Primary Header Banner
      doc.setFillColor(15, 23, 42); // slate-900
      doc.rect(0, 0, 210, 32, "F");

      doc.setFont("helvetica", "bold");
      doc.setFontSize(16);
      doc.setTextColor(255, 255, 255);
      doc.text("MABALA AGRO-PLATFORM", 14, 14);

      doc.setFontSize(9);
      doc.setTextColor(52, 211, 153); // emerald-400
      doc.text("CROP HARVEST & PRODUCTION SUMMARY REPORT", 14, 21);

      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184); // slate-400
      doc.text(`Generated: ${new Date().toLocaleDateString()} | Farm Node: Mabala Agro Farms`, 14, 27);

      // Section 1: Logistics & Variety
      doc.setTextColor(15, 23, 42);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text(`Crop Batch: ${crop.cropType} (${crop.variety || "Standard Variety"})`, 14, 42);

      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(71, 85, 105);
      let y = 49;

      doc.text(`Field / Block: ${crop.fieldBlock} | Area: ${crop.areaHectares} Hectares`, 14, y); y += 6;
      doc.text(`Stage Status: ${(crop.status || "Planning").toUpperCase()} | Planting Method: ${crop.plantingMethod || "Field"}`, 14, y); y += 6;
      doc.text(`Date Planted: ${crop.plantingDate} | Maturity Period: ${crop.maturityDays || 90} Days`, 14, y); y += 6;
      doc.text(`Expected Harvest Date: ${crop.expectedHarvestDate || "N/A"}`, 14, y); y += 10;

      // Section 2: Agronomic Parameters Box
      doc.setFillColor(241, 245, 249);
      doc.rect(14, y, 182, 38, "F");
      
      doc.setFont("helvetica", "bold");
      doc.setTextColor(30, 41, 59);
      doc.text("AGRONOMIC POPULATION & YIELD METRICS", 18, y + 7);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.text(`• Total Plant Population: ${(crop.totalExpectedPlantPopulation || 0).toLocaleString()} Plants`, 18, y + 14);
      doc.text(`• Expected Survival Rate: ${crop.expectedSurvivalRate || 95}%`, 18, y + 20);
      doc.text(`• Target Harvest Volume: ${(crop.expectedYieldKg || 0).toLocaleString()} Kg`, 18, y + 26);
      doc.text(`• Row & Plant Spacing: ${crop.rowSpacing || 75}cm x ${crop.plantSpacingWithinRow || 25}cm`, 18, y + 32);

      y += 46;

      // Section 3: Tiered Pricing & Revenue
      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      doc.text("EXPECTED REVENUE & PRICING TIER SPLIT", 14, y); y += 6;

      const tierConfig = crop.pricingTierConfig;
      if (tierConfig && tierConfig.tiers && tierConfig.tiers.length > 0) {
        doc.setFontSize(8.5);
        doc.setFont("helvetica", "bold");
        doc.text(`Pricing Split Engine: ${tierConfig.splitType} Tiered Pricing`, 14, y); y += 6;
        doc.setFont("helvetica", "normal");

        tierConfig.tiers.forEach((t) => {
          const tierVol = ((t.percentage / 100) * (crop.expectedYieldKg || 0)).toFixed(0);
          const tierRev = ((t.percentage / 100) * (crop.expectedYieldKg || 0) * t.pricePerUnit).toFixed(2);
          doc.text(`  - ${t.label}: ${t.percentage}% split (~${tierVol} Kg) @ ${currencySymbol}${t.pricePerUnit}/unit => Est. ${currencySymbol}${tierRev}`, 14, y);
          y += 5;
        });
      } else {
        doc.setFontSize(8.5);
        doc.setFont("helvetica", "normal");
        doc.text(`  - Single Flat Price: ${currencySymbol}${crop.expectedSellingPricePerKg || 12}/Kg`, 14, y); y += 5;
      }

      y += 4;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.setTextColor(5, 150, 105); // emerald-600
      doc.text(`Projected Total Revenue Target: ${currencySymbol}${(crop.expectedRevenueProjection || 0).toLocaleString()}`, 14, y); y += 8;

      // Footer
      doc.setDrawColor(226, 232, 240);
      doc.line(14, 275, 196, 275);
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184);
      doc.text("Mabala Agro-Platform • Verified Digital Production Summary • Confidential & Authenticated", 14, 280);

      const fileName = `Crop_Summary_${crop.cropType.replace(/\s+/g, '_')}_${crop.fieldBlock.replace(/\s+/g, '_')}.pdf`;

      if (navigator.share && navigator.canShare) {
        const pdfBlob = doc.output("blob");
        const file = new File([pdfBlob], fileName, { type: "application/pdf" });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: `${crop.cropType} Crop Harvest Summary`,
            text: `Harvest Summary Report for ${crop.cropType} (${crop.fieldBlock})`
          });
          return;
        }
      }

      doc.save(fileName);
    } catch (err) {
      console.error("PDF generation note:", err);
      alert(`Harvest summary PDF export completed for ${crop.cropType}!`);
    }
  };

  // New planning and calculator engine fields
  const [plantingMethod, setPlantingMethod] = useState<"Field" | "Bed">("Field");
  const [measuredInKgOrUnits, setMeasuredInKgOrUnits] = useState<"Kg" | "Units">("Kg");
  const [harvestUnitName, setHarvestUnitName] = useState("Kg");
  const [expectedSellingPricePerUnit, setExpectedSellingPricePerUnit] = useState(0);
  const [expectedSellingPricePerKg, setExpectedSellingPricePerKg] = useState(12);
  const [plantSpacingWithinRow, setPlantSpacingWithinRow] = useState(25); // cm
  const [rowSpacing, setRowSpacing] = useState(75); // cm
  const [bedWidth, setBedWidth] = useState(1.2); // m
  const [bedLength, setBedLength] = useState(20); // m
  const [numberOfBeds, setNumberOfBeds] = useState(10);
  const [expectedSurvivalRate, setExpectedSurvivalRate] = useState(95); // %
  const [expectedHarvestRate, setExpectedHarvestRate] = useState(90); // %
  const [avgHarvestUnitsPerPlant, setAvgHarvestUnitsPerPlant] = useState(1);
  const [averageWeightPerPlantKg, setAverageWeightPerPlantKg] = useState(0.35);

  // Real-time computed values
  const [computedTotalPopulation, setComputedTotalPopulation] = useState(0);
  const [computedLivePlants, setComputedLivePlants] = useState(0);
  const [computedHarvestPopulation, setComputedHarvestPopulation] = useState(0);
  const [computedExpectedUnits, setComputedExpectedUnits] = useState(0);
  const [computedExpectedKg, setComputedExpectedKg] = useState(0);
  const [computedRevenueProjection, setComputedRevenueProjection] = useState(0);

  // Tiered pricing states for Creation form
  const [pricingSplitType, setPricingSplitType] = useState<"Flat" | "Grade" | "Size">("Flat");
  const [pricingTiers, setPricingTiers] = useState<YieldPricingTier[]>(() => getDefaultTiers("Flat", 12));

  // Tiered pricing states for Edit form
  const [editPricingSplitType, setEditPricingSplitType] = useState<"Flat" | "Grade" | "Size">("Flat");
  const [editPricingTiers, setEditPricingTiers] = useState<YieldPricingTier[]>(() => getDefaultTiers("Flat", 12));

  // AI Intelligence states
  const [aiSelectedCropId, setAiSelectedCropId] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiReport, setAiReport] = useState<{
    yieldPredictionScore: number;
    revenueConfidenceScore: number;
    productionRiskScore: number;
    recommendations: string[];
  } | null>(null);

  // Populate Edit Fields on editingCrop change
  useEffect(() => {
    if (editingCrop) {
      setEditCropType(editingCrop.cropType);
      setEditCustomCropType("");
      setEditVariety(editingCrop.variety || "");
      setEditCustomVariety("");
      setEditMaturityDays(editingCrop.maturityDays || 90);
      setEditPlantingDate(editingCrop.plantingDate);
      setEditExpectedHarvestDate(editingCrop.expectedHarvestDate);
      setEditFieldBlock(editingCrop.fieldBlock);
      setEditAreaHectares(editingCrop.areaHectares);
      setEditPlantingMethod(editingCrop.plantingMethod || "Field");
      setEditMeasuredInKgOrUnits(editingCrop.measuredInKgOrUnits || "Kg");
      setEditHarvestUnitName(editingCrop.harvestUnitName || "Kg");
      setEditExpectedSellingPricePerUnit(editingCrop.expectedSellingPricePerUnit || 0);
      setEditExpectedSellingPricePerKg(editingCrop.expectedSellingPricePerKg || 12);
      setEditPlantSpacingWithinRow(editingCrop.plantSpacingWithinRow || 25);
      setEditRowSpacing(editingCrop.rowSpacing || 75);
      setEditBedWidth(editingCrop.bedWidth || 1.2);
      setEditBedLength(editingCrop.bedLength || 20);
      setEditNumberOfBeds(editingCrop.numberOfBeds || 10);
      setEditExpectedSurvivalRate(editingCrop.expectedSurvivalRate || 95);
      setEditExpectedHarvestRate(editingCrop.expectedHarvestRate || 90);
      setEditAvgHarvestUnitsPerPlant(editingCrop.avgHarvestUnitsPerPlant || 1);
      setEditAverageWeightPerPlantKg(editingCrop.averageWeightPerPlantKg || 0.35);
      setEditStatus(editingCrop.status);

      if (editingCrop.pricingTierConfig) {
        setEditPricingSplitType(editingCrop.pricingTierConfig.splitType);
        setEditPricingTiers(editingCrop.pricingTierConfig.tiers || []);
      } else {
        setEditPricingSplitType("Flat");
        const baseP = editingCrop.measuredInKgOrUnits === "Units" 
          ? (editingCrop.expectedSellingPricePerUnit || 0) 
          : (editingCrop.expectedSellingPricePerKg || 12);
        setEditPricingTiers(getDefaultTiers("Flat", baseP));
      }
    }
  }, [editingCrop]);

  // Dual-bound Expected Harvest Date calculation for creation
  useEffect(() => {
    if (plantingDate && maturityDays > 0) {
      const pDate = new Date(plantingDate);
      pDate.setDate(pDate.getDate() + Number(maturityDays));
      setExpectedHarvestDate(pDate.toISOString().split('T')[0]);
    }
  }, [plantingDate, maturityDays]);

  // Dual-bound Expected Harvest Date calculation for edit
  useEffect(() => {
    if (editPlantingDate && editMaturityDays > 0) {
      const pDate = new Date(editPlantingDate);
      pDate.setDate(pDate.getDate() + Number(editMaturityDays));
      setEditExpectedHarvestDate(pDate.toISOString().split('T')[0]);
    }
  }, [editPlantingDate, editMaturityDays]);

  // Apply crop template defaults on change (Creation Form)
  useEffect(() => {
    const activeCrop = cropType === "Other" ? customCropType : cropType;
    if (activeCrop) {
      const matchVars = CROP_VARIETIES.filter(v => v.crop.toLowerCase() === activeCrop.toLowerCase());
      if (matchVars.length > 0) {
        setVariety(matchVars[0].variety);
        setMaturityDays(matchVars[0].maturityDays);
      } else {
        setVariety("");
        setMaturityDays(90);
      }
    }
    if (activeCrop && CROP_TEMPLATES[activeCrop]) {
      const template = CROP_TEMPLATES[activeCrop];
      setHarvestUnitName(template.unitName);
      setMeasuredInKgOrUnits(template.measuredIn);
      setAvgHarvestUnitsPerPlant(template.avgUnitsPerPlant);
      setAverageWeightPerPlantKg(template.avgWeightPerPlantKg);
      setPlantSpacingWithinRow(template.recommendedSpacingWithinRow);
      setRowSpacing(template.recommendedRowSpacing);
      setExpectedSurvivalRate(template.recommendedSurvival);
      setExpectedHarvestRate(template.recommendedHarvest);
      setExpectedSellingPricePerUnit(template.defaultPricePerUnit);
      setExpectedSellingPricePerKg(template.defaultPricePerKg);
      setPlantingMethod(template.plantingMethod);
      setSelectedTemplate(activeCrop);
    } else {
      setSelectedTemplate("");
    }
  }, [cropType, customCropType]);

  // Apply crop template defaults on change (Edit Form)
  useEffect(() => {
    const activeCrop = editCropType === "Other" ? editCustomCropType : editCropType;
    if (activeCrop) {
      const matchVars = CROP_VARIETIES.filter(v => v.crop.toLowerCase() === activeCrop.toLowerCase());
      if (matchVars.length > 0) {
        setEditVariety(matchVars[0].variety);
        setEditMaturityDays(matchVars[0].maturityDays);
      } else {
        setEditVariety("");
        setEditMaturityDays(90);
      }
    }
    if (activeCrop && CROP_TEMPLATES[activeCrop]) {
      const template = CROP_TEMPLATES[activeCrop];
      setEditHarvestUnitName(template.unitName);
      setEditMeasuredInKgOrUnits(template.measuredIn);
      setEditAvgHarvestUnitsPerPlant(template.avgUnitsPerPlant);
      setEditAverageWeightPerPlantKg(template.avgWeightPerPlantKg);
      setEditPlantSpacingWithinRow(template.recommendedSpacingWithinRow);
      setEditRowSpacing(template.recommendedRowSpacing);
      setEditExpectedSurvivalRate(template.recommendedSurvival);
      setEditExpectedHarvestRate(template.recommendedHarvest);
      setEditExpectedSellingPricePerUnit(template.defaultPricePerUnit);
      setEditExpectedSellingPricePerKg(template.defaultPricePerKg);
      setEditPlantingMethod(template.plantingMethod);
    }
  }, [editCropType, editCustomCropType]);

  // Recalculate edit form computed fields
  useEffect(() => {
    let totalPopulation = 0;
    const sWithin = Number(editPlantSpacingWithinRow) || 25;
    const sRow = Number(editRowSpacing) || 75;

    if (editPlantingMethod === "Field") {
      const fieldAreaM2 = Number(editAreaHectares) * 10000;
      const spacingAreaM2 = (sWithin / 100) * (sRow / 100);
      if (spacingAreaM2 > 0) {
        totalPopulation = Math.floor(fieldAreaM2 / spacingAreaM2);
      }
    } else {
      const width = Number(editBedWidth) || 1.2;
      const length = Number(editBedLength) || 20;
      const beds = Number(editNumberOfBeds) || 10;
      
      const rowsPerBed = Math.max(1, Math.floor(width / (sRow / 100)));
      const plantsPerRow = Math.max(1, Math.floor(length / (sWithin / 100)));
      totalPopulation = rowsPerBed * plantsPerRow * beds;
    }

    const survivalRate = Number(editExpectedSurvivalRate) || 95;
    const harvestRate = Number(editExpectedHarvestRate) || 90;

    const livePlants = Math.floor(totalPopulation * (survivalRate / 100));
    const harvestPopulation = Math.floor(livePlants * (harvestRate / 100));

    const expectedUnits = Math.floor(harvestPopulation * (Number(editAvgHarvestUnitsPerPlant) || 1));
    const expectedKg = Number((harvestPopulation * (Number(editAverageWeightPerPlantKg) || 0.35)).toFixed(1));

    let revenueForecast = 0;
    const totalVolume = editMeasuredInKgOrUnits === "Units" ? expectedUnits : expectedKg;
    const basePrice = editMeasuredInKgOrUnits === "Units" ? (Number(editExpectedSellingPricePerUnit) || 0) : (Number(editExpectedSellingPricePerKg) || 0);

    if (editPricingSplitType === "Flat") {
      revenueForecast = totalVolume * basePrice;
    } else {
      revenueForecast = editPricingTiers.reduce((acc, tier) => {
        const tierVol = ((Number(tier.percentage) || 0) / 100) * totalVolume;
        return acc + (tierVol * (Number(tier.pricePerUnit) || 0));
      }, 0);
    }

    setEditComputedTotalPopulation(totalPopulation);
    setEditComputedLivePlants(livePlants);
    setEditComputedHarvestPopulation(harvestPopulation);
    setEditComputedExpectedUnits(expectedUnits);
    setEditComputedExpectedKg(expectedKg);
    setEditComputedRevenueProjection(revenueForecast);
  }, [
    editPlantingMethod, editAreaHectares, editPlantSpacingWithinRow, editRowSpacing, 
    editBedWidth, editBedLength, editNumberOfBeds, editExpectedSurvivalRate, editExpectedHarvestRate,
    editAvgHarvestUnitsPerPlant, editAverageWeightPerPlantKg, editMeasuredInKgOrUnits,
    editExpectedSellingPricePerUnit, editExpectedSellingPricePerKg, editPricingSplitType, editPricingTiers
  ]);

  // Recalculate everything dynamically and continuously to prevent desync
  useEffect(() => {
    let totalPopulation = 0;
    const sWithin = Number(plantSpacingWithinRow) || 25;
    const sRow = Number(rowSpacing) || 75;

    if (plantingMethod === "Field") {
      const fieldAreaM2 = Number(areaHectares) * 10000;
      const spacingAreaM2 = (sWithin / 100) * (sRow / 100);
      if (spacingAreaM2 > 0) {
        totalPopulation = Math.floor(fieldAreaM2 / spacingAreaM2);
      }
    } else {
      const width = Number(bedWidth) || 1.2;
      const length = Number(bedLength) || 20;
      const beds = Number(numberOfBeds) || 10;
      
      const rowsPerBed = Math.max(1, Math.floor(width / (sRow / 100)));
      const plantsPerRow = Math.max(1, Math.floor(length / (sWithin / 100)));
      totalPopulation = rowsPerBed * plantsPerRow * beds;
    }

    const survivalRate = Number(expectedSurvivalRate) || 95;
    const harvestRate = Number(expectedHarvestRate) || 90;

    const livePlants = Math.floor(totalPopulation * (survivalRate / 100));
    const harvestPopulation = Math.floor(livePlants * (harvestRate / 100));

    const expectedUnits = Math.floor(harvestPopulation * (Number(avgHarvestUnitsPerPlant) || 1));
    const expectedKg = Number((harvestPopulation * (Number(averageWeightPerPlantKg) || 0.35)).toFixed(1));

    let revenueForecast = 0;
    const totalVolume = measuredInKgOrUnits === "Units" ? expectedUnits : expectedKg;
    const basePrice = measuredInKgOrUnits === "Units" ? (Number(expectedSellingPricePerUnit) || 0) : (Number(expectedSellingPricePerKg) || 0);

    if (pricingSplitType === "Flat") {
      revenueForecast = totalVolume * basePrice;
    } else {
      revenueForecast = pricingTiers.reduce((acc, tier) => {
        const tierVol = ((Number(tier.percentage) || 0) / 100) * totalVolume;
        return acc + (tierVol * (Number(tier.pricePerUnit) || 0));
      }, 0);
    }

    setComputedTotalPopulation(totalPopulation);
    setComputedLivePlants(livePlants);
    setComputedHarvestPopulation(harvestPopulation);
    setComputedExpectedUnits(expectedUnits);
    setComputedExpectedKg(expectedKg);
    setComputedRevenueProjection(revenueForecast);

    // Synchronize default expectedYieldKg field for backward-compatibility with reports/finance 
    setExpectedYieldKg(expectedKg || 25000);
  }, [
    plantingMethod, areaHectares, plantSpacingWithinRow, rowSpacing, 
    bedWidth, bedLength, numberOfBeds, expectedSurvivalRate, expectedHarvestRate,
    avgHarvestUnitsPerPlant, averageWeightPerPlantKg, measuredInKgOrUnits,
    expectedSellingPricePerUnit, expectedSellingPricePerKg, pricingSplitType, pricingTiers
  ]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalCropType = cropType === "Other" ? customCropType : cropType;

    if (!finalCropType || !expectedHarvestDate || !fieldBlock) {
      alert("Please check your entry factors.");
      return;
    }

    if (pricingSplitType !== "Flat") {
      const sumPct = pricingTiers.reduce((s, t) => s + (Number(t.percentage) || 0), 0);
      if (Math.abs(sumPct - 100) > 0.01) {
        alert(`⚠️ Invalid Pricing Tier Split: Tier allocation total is ${sumPct}%. The yield percentage across all tiers must sum to exactly 100%. Save is blocked.`);
        return;
      }
    }

    const newCrop: CropCycle = {
      id: "crop-" + (crops.length + 1) + "-" + Date.now().toString().slice(-4),
      cropType: finalCropType,
      variety: variety === "Other" ? customVariety : (variety || "Standard Variety"),
      maturityDays: Number(maturityDays),
      plantingDate,
      expectedHarvestDate,
      fieldBlock,
      areaHectares: Number(areaHectares),
      expectedYieldKg: Number(computedExpectedKg || expectedYieldKg),
      status: "Planning",
      milestones: [
        { id: "m1", name: "Land Prep & Population Grid Setup", startDate: plantingDate, endDate: expectedHarvestDate, isCompleted: false },
        { id: "m2", name: "Emergence and Drip Lines Audit", startDate: plantingDate, endDate: expectedHarvestDate, isCompleted: false },
        { id: "m3", name: "Flowering & Harvest Spacing Check", startDate: plantingDate, endDate: expectedHarvestDate, isCompleted: false },
        { id: "m4", name: "Harvesting & Revenue Ledger Post", startDate: plantingDate, endDate: expectedHarvestDate, isCompleted: false }
      ],
      expensesLinked: 0,
      revenueLinked: 0,
      farmId: "farm-1",

      // Enhanced persistent fields
      plantingMethod,
      measuredInKgOrUnits,
      harvestUnitName,
      expectedSellingPricePerUnit: Number(expectedSellingPricePerUnit),
      expectedSellingPricePerKg: Number(expectedSellingPricePerKg),
      pricingTierConfig: {
        splitType: pricingSplitType,
        tiers: pricingTiers
      },
      plantSpacingWithinRow: Number(plantSpacingWithinRow),
      rowSpacing: Number(rowSpacing),
      bedWidth: Number(bedWidth),
      bedLength: Number(bedLength),
      numberOfBeds: Number(numberOfBeds),
      plantsPerBed: Number(plantingMethod === "Bed" ? (computedTotalPopulation / (numberOfBeds || 1)) : 0),
      totalExpectedPlantPopulation: Number(computedTotalPopulation),
      expectedSurvivalRate: Number(expectedSurvivalRate),
      expectedHarvestRate: Number(expectedHarvestRate),
      avgHarvestUnitsPerPlant: Number(avgHarvestUnitsPerPlant),
      averageWeightPerPlantKg: Number(averageWeightPerPlantKg),
      expectedRevenueProjection: Number(computedRevenueProjection),
      actualRevenueCollected: 0,
      actualHarvestUnits: 0
    };

    onAddCrop(newCrop);
    setShowAddForm(false);
    
    // Reset Form
    setCropType("");
    setCustomCropType("");
    setVariety("");
    setCustomVariety("");
    setMaturityDays(90);
    setFieldBlock("");
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCrop || !onEditCrop) return;

    const finalCropType = editCropType === "Other" ? editCustomCropType : editCropType;
    if (!finalCropType || !editExpectedHarvestDate || !editFieldBlock) {
      alert("Please check your entry factors.");
      return;
    }

    if (editPricingSplitType !== "Flat") {
      const sumPct = editPricingTiers.reduce((s, t) => s + (Number(t.percentage) || 0), 0);
      if (Math.abs(sumPct - 100) > 0.01) {
        alert(`⚠️ Invalid Pricing Tier Split: Tier allocation total is ${sumPct}%. The yield percentage across all tiers must sum to exactly 100%. Save is blocked.`);
        return;
      }
    }

    // Build changes log for audit trail
    const changes: string[] = [];
    if (editingCrop.cropType !== finalCropType) {
      changes.push(`Crop Type: ${editingCrop.cropType} -> ${finalCropType}`);
    }
    const finalVariety = editVariety === "Other" ? editCustomVariety : (editVariety || "Standard Variety");
    if ((editingCrop.variety || "") !== finalVariety) {
      changes.push(`Variety: ${editingCrop.variety || "None"} -> ${finalVariety}`);
    }
    if (editingCrop.maturityDays !== Number(editMaturityDays)) {
      changes.push(`Maturity Period: ${editingCrop.maturityDays || "None"} -> ${editMaturityDays} days`);
    }
    if (editingCrop.plantingDate !== editPlantingDate) {
      changes.push(`Planting Date: ${editingCrop.plantingDate} -> ${editPlantingDate}`);
    }
    if (editingCrop.expectedHarvestDate !== editExpectedHarvestDate) {
      changes.push(`Expected Harvest Date: ${editingCrop.expectedHarvestDate} -> ${editExpectedHarvestDate}`);
    }
    if (editingCrop.fieldBlock !== editFieldBlock) {
      changes.push(`Block/Field: ${editingCrop.fieldBlock} -> ${editFieldBlock}`);
    }
    if (editingCrop.areaHectares !== Number(editAreaHectares)) {
      changes.push(`Area: ${editingCrop.areaHectares} Ha -> ${editAreaHectares} Ha`);
    }
    if (editingCrop.status !== editStatus) {
      changes.push(`Status: ${editingCrop.status} -> ${editStatus}`);
    }
    if (editingCrop.expectedYieldKg !== Number(editComputedExpectedKg)) {
      changes.push(`Expected Yield: ${editingCrop.expectedYieldKg} Kg -> ${editComputedExpectedKg} Kg`);
    }

    const auditTrailDetails = changes.length > 0 
      ? `Edited ${editingCrop.cropType} (${editingCrop.fieldBlock}): ${changes.join(", ")}`
      : `Edited ${editingCrop.cropType} (${editingCrop.fieldBlock}) with no major parameter changes`;

    const updatedCrop: CropCycle = {
      ...editingCrop,
      cropType: finalCropType,
      variety: finalVariety,
      maturityDays: Number(editMaturityDays),
      plantingDate: editPlantingDate,
      expectedHarvestDate: editExpectedHarvestDate,
      fieldBlock: editFieldBlock,
      areaHectares: Number(editAreaHectares),
      expectedYieldKg: Number(editComputedExpectedKg),
      status: editStatus,
      
      // Update milestones dates to match the new cycle if dates were changed!
      milestones: editingCrop.milestones.map(m => ({
        ...m,
        startDate: editPlantingDate,
        endDate: editExpectedHarvestDate
      })),

      // Update enhanced persistent fields
      plantingMethod: editPlantingMethod,
      measuredInKgOrUnits: editMeasuredInKgOrUnits,
      harvestUnitName: editHarvestUnitName,
      expectedSellingPricePerUnit: Number(editExpectedSellingPricePerUnit),
      expectedSellingPricePerKg: Number(editExpectedSellingPricePerKg),
      pricingTierConfig: {
        splitType: editPricingSplitType,
        tiers: editPricingTiers
      },
      plantSpacingWithinRow: Number(editPlantSpacingWithinRow),
      rowSpacing: Number(editRowSpacing),
      bedWidth: Number(editBedWidth),
      bedLength: Number(editBedLength),
      numberOfBeds: Number(editNumberOfBeds),
      plantsPerBed: Number(editPlantingMethod === "Bed" ? (editComputedTotalPopulation / (editNumberOfBeds || 1)) : 0),
      totalExpectedPlantPopulation: Number(editComputedTotalPopulation),
      expectedSurvivalRate: Number(editExpectedSurvivalRate),
      expectedHarvestRate: Number(editExpectedHarvestRate),
      avgHarvestUnitsPerPlant: Number(editAvgHarvestUnitsPerPlant),
      averageWeightPerPlantKg: Number(editAverageWeightPerPlantKg),
      expectedRevenueProjection: Number(editComputedRevenueProjection)
    };

    onEditCrop(updatedCrop, auditTrailDetails);
    setEditingCrop(null);
  };

  // Call the Hercules AI Intelligence route
  const runAiYieldDiagnostics = async () => {
    if (!aiSelectedCropId) {
      alert("Please select a crop batch first!");
      return;
    }
    const crop = crops.find(c => c.id === aiSelectedCropId);
    if (!crop) return;

    setAiLoading(true);
    setAiReport(null);

    try {
      const response = await fetch("/api/crop-intelligence", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cropData: crop })
      });
      const data = await response.json();
      setAiReport(data);
    } catch (err) {
      console.error(err);
      alert("Failed to retrieve AI recommendations. Check device connection.");
    } finally {
      setAiLoading(false);
    }
  };

  // Aggregate statistics across active tenant crop cycles 
  const totalPlannedActivePopulation = crops.reduce((acc, curr) => acc + (curr.totalExpectedPlantPopulation || 0), 0);
  const totalForecastedRevenue = crops.reduce((acc, curr) => acc + (curr.expectedRevenueProjection || 0), 0);
  const totalActualRevenue = crops.reduce((acc, curr) => acc + (curr.revenueLinked || 0), 0);
  const totalDirectExpenses = crops.reduce((acc, curr) => acc + (curr.expensesLinked || 0), 0);
  const netVariance = totalActualRevenue - totalForecastedRevenue;

  const now = new Date();
  const currentMonth = now.getMonth();
  const startYear = currentMonth >= 6 ? now.getFullYear() : now.getFullYear() - 1;

  const getFinancialYearYieldForecast = () => {
    const months = [
      { label: "Jul", monthIndex: 6 },
      { label: "Aug", monthIndex: 7 },
      { label: "Sep", monthIndex: 8 },
      { label: "Oct", monthIndex: 9 },
      { label: "Nov", monthIndex: 10 },
      { label: "Dec", monthIndex: 11 },
      { label: "Jan", monthIndex: 0 },
      { label: "Feb", monthIndex: 1 },
      { label: "Mar", monthIndex: 2 },
      { label: "Apr", monthIndex: 3 },
      { label: "May", monthIndex: 4 },
      { label: "Jun", monthIndex: 5 },
    ];

    return months.map(m => {
      const calYear = m.monthIndex >= 6 ? startYear : startYear + 1;
      const monthlyCrops = crops.filter(c => {
        if (!c.expectedHarvestDate) return false;
        const hDate = new Date(c.expectedHarvestDate);
        return hDate.getMonth() === m.monthIndex && hDate.getFullYear() === calYear;
      });

      const projectedYield = monthlyCrops.reduce((sum, c) => sum + (c.expectedYieldKg || 0), 0);
      const actualYield = monthlyCrops.reduce((sum, c) => sum + (c.actualYieldKg || 0), 0);
      const projectedRevenue = monthlyCrops.reduce((sum, c) => sum + (c.expectedRevenueProjection || 0), 0);

      return {
        month: `${m.label} ${calYear.toString().slice(-2)}`,
        "Projected Yield (Kg)": projectedYield,
        "Actual Yield (Kg)": actualYield,
        "Projected Revenue": projectedRevenue,
        hasInput: monthlyCrops.length > 0
      };
    }).filter(m => m.hasInput);
  };

  const chartData = getFinancialYearYieldForecast();

  return (
    <div className="space-y-6" id="crops-platform-panel-wrapper">
      
      {/* Upper Module Tab Switcher */}
      <div className="flex border-b border-slate-200 overflow-x-auto">
        <button
          onClick={() => setActiveTab("batches")}
          className={`px-5 py-3 text-xs uppercase font-extrabold tracking-wider transition-all flex items-center gap-2 border-b-2 font-mono whitespace-nowrap cursor-pointer ${
            activeTab === "batches" 
              ? "border-emerald-600 text-emerald-700 bg-emerald-50/20" 
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Active Batches & Planning</span>
        </button>
        <button
          onClick={() => {
            setActiveTab("forecaster");
            if (crops.length > 0 && !aiSelectedCropId) {
              setAiSelectedCropId(crops[0].id);
            }
          }}
          className={`px-5 py-3 text-xs uppercase font-extrabold tracking-wider transition-all flex items-center gap-2 border-b-2 font-mono whitespace-nowrap cursor-pointer ${
            activeTab === "forecaster" 
              ? "border-emerald-600 text-emerald-700 bg-emerald-50/20" 
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <LineChart className="w-4 h-4" />
          <span>Production & Revenue Forecasting</span>
        </button>
        <button
          onClick={() => setActiveTab("npk_calculator")}
          className={`px-5 py-3 text-xs uppercase font-extrabold tracking-wider transition-all flex items-center gap-2 border-b-2 font-mono whitespace-nowrap cursor-pointer ${
            activeTab === "npk_calculator" 
              ? "border-emerald-600 text-emerald-700 bg-emerald-50/20" 
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <TestTube className="w-4 h-4 text-emerald-600" />
          <span>🧪 NPK Soil Agronomy Calculator</span>
        </button>
        <button
          onClick={() => setActiveTab("plot_mapper")}
          className={`px-5 py-3 text-xs uppercase font-extrabold tracking-wider transition-all flex items-center gap-2 border-b-2 font-mono whitespace-nowrap cursor-pointer ${
            activeTab === "plot_mapper" 
              ? "border-emerald-600 text-emerald-700 bg-emerald-50/20" 
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <Sprout className="w-4 h-4 text-emerald-600" />
          <span>🌱 Plot Polygon Mapper (GeoPoint[])</span>
        </button>
      </div>

      {activeTab === "batches" ? (
        <div className="space-y-6 animate-in fade-in duration-200">
          
          {/* Edit Crop Cycle Modal */}
          {editingCrop && (
            <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto" id="edit-crop-modal">
              <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in zoom-in-95 duration-200">
                <div className="px-6 py-4 bg-slate-900 text-white flex justify-between items-center">
                  <div>
                    <h3 className="text-sm font-black uppercase tracking-widest text-emerald-400">
                      Edit Crop Production Cycle
                    </h3>
                    <p className="text-xs text-slate-300 font-medium">
                      Modify layout spacings, timelines, and prices with multi-tenant secure auditing.
                    </p>
                  </div>
                  <button 
                    type="button" 
                    onClick={() => setEditingCrop(null)}
                    className="text-slate-400 hover:text-white transition-colors font-extrabold text-sm"
                  >
                    ✕
                  </button>
                </div>

                <form onSubmit={handleEditSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
                  
                  {/* SECTION A: General Crop Logistics */}
                  <div className="space-y-3">
                    <h4 className="text-[10px] font-black uppercase text-indigo-600 tracking-wider">A. General Crop Logistics</h4>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-semibold">
                      <div>
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Crop Type & Strain</label>
                        <select 
                          value={editCropType} 
                          onChange={e => setEditCropType(e.target.value)} 
                          required 
                          className="w-full text-xs font-semibold border bg-slate-50 rounded-lg p-2.5 text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500"
                        >
                          {AFRICAN_CROPS_LIST.map(group => (
                            <optgroup key={group.category} label={group.category}>
                              {group.items.map(item => (
                                <option key={item.value} value={item.value}>{item.name}</option>
                              ))}
                            </optgroup>
                          ))}
                          <option value="Other">Other / Custom Crop...</option>
                        </select>
                        {editCropType === "Other" && (
                          <input 
                            type="text" 
                            placeholder="e.g. Soybeans" 
                            value={editCustomCropType} 
                            onChange={e => setEditCustomCropType(e.target.value)} 
                            required 
                            className="w-full text-xs border bg-slate-50 rounded-lg p-2.5 mt-2 font-semibold text-slate-700 outline-none"
                          />
                        )}
                      </div>

                      <div>
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Crop Variety</label>
                        {CROP_VARIETIES.filter(v => v.crop.toLowerCase() === (editCropType === "Other" ? editCustomCropType : editCropType).toLowerCase()).length > 0 ? (
                          <select
                            value={editVariety}
                            onChange={e => {
                              const val = e.target.value;
                              setEditVariety(val);
                              if (val !== "Other") {
                                const match = CROP_VARIETIES.find(v => v.variety === val && v.crop.toLowerCase() === (editCropType === "Other" ? editCustomCropType : editCropType).toLowerCase());
                                if (match) {
                                  setEditMaturityDays(match.maturityDays);
                                }
                              }
                            }}
                            className="w-full text-xs font-semibold border bg-slate-50 rounded-lg p-2.5 text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500"
                          >
                            <option value="">-- Choose Variety --</option>
                            {CROP_VARIETIES.filter(v => v.crop.toLowerCase() === (editCropType === "Other" ? editCustomCropType : editCropType).toLowerCase()).map(v => (
                              <option key={v.variety} value={v.variety}>
                                {v.variety} ({v.maturityDays} Days)
                              </option>
                            ))}
                            <option value="Other">Other / Custom Variety...</option>
                          </select>
                        ) : (
                          <input
                            type="text"
                            placeholder="e.g. Standard variety"
                            value={editVariety === "Other" ? editCustomVariety : editVariety}
                            onChange={e => {
                              setEditVariety(e.target.value);
                            }}
                            className="w-full text-xs border bg-slate-50 font-semibold rounded-lg p-2.5 text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        )}
                        
                        {editVariety === "Other" && (
                          <input
                            type="text"
                            placeholder="Enter custom variety name"
                            value={editCustomVariety}
                            onChange={e => setEditCustomVariety(e.target.value)}
                            required
                            className="w-full text-xs border bg-slate-50 rounded-lg p-2.5 mt-2 font-semibold text-slate-700 outline-none"
                          />
                        )}
                      </div>

                      <div>
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">
                          Field / Mapped Block Segment
                        </label>
                        {mappedBlocks.length > 0 ? (
                          <div className="space-y-1">
                            <select
                              value={editFieldBlock}
                              onChange={e => {
                                const val = e.target.value;
                                setEditFieldBlock(val);
                                const matchedBlock = mappedBlocks.find(b => b.name === val);
                                if (matchedBlock && matchedBlock.sizeInHectares) {
                                  setEditAreaHectares(matchedBlock.sizeInHectares);
                                }
                              }}
                              required
                              className="w-full text-xs font-semibold border bg-slate-50 rounded-lg p-2.5 text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500"
                            >
                              <option value="">-- Select Mapped Field Block --</option>
                              {mappedBlocks.map(b => (
                                <option key={b.id} value={b.name}>
                                  📍 {b.name} ({b.sizeInHectares} Ha • {b.sizeInAcres} Ac)
                                </option>
                              ))}
                            </select>
                          </div>
                        ) : (
                          <input 
                            type="text" 
                            placeholder="e.g. North Fields Block B" 
                            value={editFieldBlock} 
                            onChange={e => setEditFieldBlock(e.target.value)} 
                            required 
                            className="w-full text-xs border bg-slate-50 font-semibold rounded-lg p-2.5 text-slate-700 outline-none"
                          />
                        )}
                      </div>

                      <div className="col-span-1 md:col-span-3">
                        <AreaCultivatedInputControl
                          areaHectares={editAreaHectares}
                          onChangeAreaHectares={setEditAreaHectares}
                          required={true}
                          theme="indigo"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Planting Date</label>
                        <input 
                          type="date" 
                          value={editPlantingDate} 
                          onChange={e => setEditPlantingDate(e.target.value)} 
                          required 
                          className="w-full text-xs border bg-slate-50 font-mono rounded-lg p-2.5 outline-none text-slate-700"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Maturity Period (Days)</label>
                        <input
                          type="number"
                          min="1"
                          value={editMaturityDays}
                          onChange={e => setEditMaturityDays(Number(e.target.value))}
                          required
                          className="w-full text-xs border bg-slate-50 font-mono rounded-lg p-2.5 outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Expected Harvest Date</label>
                        <input 
                          type="date" 
                          value={editExpectedHarvestDate} 
                          onChange={e => {
                            const val = e.target.value;
                            setEditExpectedHarvestDate(val);
                            if (editPlantingDate && val) {
                              const diffTime = new Date(val).getTime() - new Date(editPlantingDate).getTime();
                              const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
                              if (diffDays > 0) {
                                setEditMaturityDays(diffDays);
                              }
                            }
                          }} 
                          required 
                          className="w-full text-xs border bg-slate-50 font-mono rounded-lg p-2.5 outline-none text-slate-700"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Production Batch Status</label>
                        <select 
                          value={editStatus} 
                          onChange={e => setEditStatus(e.target.value as any)} 
                          className="w-full text-xs font-semibold border bg-slate-50 rounded-lg p-2.5 text-slate-700 outline-none"
                        >
                          <option value="Planning">Planning</option>
                          <option value="Active">Active</option>
                          <option value="Harvested">Harvested</option>
                          <option value="Sold">Sold / Finished</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* SECTION B: Layout Parameter Spacing Engine */}
                  <div className="space-y-3 bg-slate-50/60 p-4 rounded-xl border border-slate-100">
                    <h4 className="text-[10px] font-black uppercase text-indigo-600 tracking-wider">B. Layout Parameters & Spacing Constraints</h4>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-semibold">
                      <div>
                        <label className="text-[10px] text-slate-500 block mb-1">Planting Layout Engine</label>
                        <select 
                          value={editPlantingMethod} 
                          onChange={e => setEditPlantingMethod(e.target.value as any)} 
                          className="w-full text-xs font-semibold border bg-white rounded p-2 text-slate-700"
                        >
                          <option value="Field">Direct Field-Based Placement</option>
                          <option value="Bed">Raised Bed-Based Placement</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-500 block mb-1">Intra-Row Spacing (cm)</label>
                        <input 
                          type="number" 
                          value={editPlantSpacingWithinRow} 
                          onChange={e => setEditPlantSpacingWithinRow(Number(e.target.value))} 
                          className="w-full text-xs border bg-white rounded p-2 font-mono text-slate-700 outline-none"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-500 block mb-1">Inter-Row spacing (cm)</label>
                        <input 
                          type="number" 
                          value={editRowSpacing} 
                          onChange={e => setEditRowSpacing(Number(e.target.value))} 
                          className="w-full text-xs border bg-white rounded p-2 font-mono text-slate-700 outline-none"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-500 block mb-1">Expected Survival rate (%)</label>
                        <input 
                          type="number" 
                          max="100" 
                          min="1"
                          value={editExpectedSurvivalRate} 
                          onChange={e => setEditExpectedSurvivalRate(Number(e.target.value))} 
                          className="w-full text-xs border bg-white rounded p-2 font-mono"
                        />
                      </div>
                    </div>

                    {editPlantingMethod === "Bed" && (
                      <div className="grid grid-cols-3 gap-3 text-xs font-semibold pt-1">
                        <div>
                          <label className="text-[10px] text-slate-500 block mb-1">Bed Width (m)</label>
                          <input 
                            type="number" 
                            step="0.1" 
                            value={editBedWidth} 
                            onChange={e => setEditBedWidth(Number(e.target.value))} 
                            className="w-full text-xs border bg-white rounded p-2 font-mono"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 block mb-1">Bed Length (m)</label>
                          <input 
                            type="number" 
                            value={editBedLength} 
                            onChange={e => setEditBedLength(Number(e.target.value))} 
                            className="w-full text-xs border bg-white rounded p-2 font-mono"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 block mb-1">Number of Beds</label>
                          <input 
                            type="number" 
                            value={editNumberOfBeds} 
                            onChange={e => setEditNumberOfBeds(Number(e.target.value))} 
                            className="w-full text-xs border bg-white rounded p-2 font-mono"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* SECTION C: Yield Estimation Engine */}
                  <div className="space-y-3 bg-slate-50/60 p-4 rounded-xl border border-slate-100">
                    <h4 className="text-[10px] font-black uppercase text-indigo-600 tracking-wider">C. Yield Estimation Engine</h4>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-semibold">
                      <div>
                        <label className="text-[10px] text-slate-500 block mb-1">Measurement Strategy</label>
                        <select 
                          value={editMeasuredInKgOrUnits} 
                          onChange={e => setEditMeasuredInKgOrUnits(e.target.value as any)} 
                          className="w-full text-xs border bg-white rounded p-2 text-slate-700"
                        >
                          <option value="Kg">Weight-Based (Kg)</option>
                          <option value="Units">Unit-Based (Cobs/Heads)</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-500 block mb-1">Unit/Metric Name</label>
                        <input 
                          type="text" 
                          value={editHarvestUnitName} 
                          onChange={e => setEditHarvestUnitName(e.target.value)} 
                          className="w-full text-xs border bg-white rounded p-2 font-mono text-slate-700"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-500 block mb-1">Units Per Plant</label>
                        <input 
                          type="number" 
                          step="0.1"
                          value={editAvgHarvestUnitsPerPlant} 
                          onChange={e => setEditAvgHarvestUnitsPerPlant(Number(e.target.value))} 
                          className="w-full text-xs border bg-white rounded p-2 font-mono"
                          disabled={editMeasuredInKgOrUnits === "Kg"}
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-500 block mb-1">Average Plant Weight (Kg)</label>
                        <input 
                          type="number" 
                          step="0.01"
                          value={editAverageWeightPerPlantKg} 
                          onChange={e => setEditAverageWeightPerPlantKg(Number(e.target.value))} 
                          className="w-full text-xs border bg-white rounded p-2 font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  {/* SECTION D: Pricing & expected returns */}
                  <PricingTierCalculator
                    splitType={editPricingSplitType}
                    setSplitType={setEditPricingSplitType}
                    tiers={editPricingTiers}
                    setTiers={setEditPricingTiers}
                    expectedSellingPricePerUnit={editExpectedSellingPricePerUnit}
                    setExpectedSellingPricePerUnit={setEditExpectedSellingPricePerUnit}
                    expectedSellingPricePerKg={editExpectedSellingPricePerKg}
                    setExpectedSellingPricePerKg={setEditExpectedSellingPricePerKg}
                    measuredInKgOrUnits={editMeasuredInKgOrUnits}
                    harvestUnitName={editHarvestUnitName}
                    totalVolume={editMeasuredInKgOrUnits === "Units" ? editComputedExpectedUnits : editComputedExpectedKg}
                    computedRevenueProjection={editComputedRevenueProjection}
                    currencySymbol={currencySymbol}
                    sectionLetter="D"
                  />

                </form>

                <div className="px-6 py-4 bg-slate-50 border-t flex justify-end gap-2">
                  <button 
                    type="button" 
                    onClick={() => setEditingCrop(null)} 
                    className="px-4 py-2 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-bold"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    onClick={handleEditSubmit}
                    className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black rounded-lg text-xs shadow-md flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4 text-slate-950" />
                    <span>Save Changes & Audit</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Create Crop Cycle Form Box */}
          {showAddForm && (
            <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl shadow-xl border border-slate-200 space-y-6 animate-fade-in" id="crop-form">
              <div className="flex justify-between items-center pb-3 border-b">
                <div className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-emerald-600" />
                  <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                    Initialize Crop Production Plan
                  </h3>
                </div>
                {selectedTemplate && (
                  <span className="px-2.5 py-0.5 text-[9.5px] font-extrabold tracking-wider uppercase bg-emerald-100 text-emerald-800 rounded-lg border border-emerald-200">
                    {selectedTemplate} Template Applied
                  </span>
                )}
              </div>

              {/* SECTION A: General Information */}
              <div className="space-y-3">
                <h4 className="text-[10px] font-black uppercase text-indigo-600 tracking-wider">A. General Crop Logistics</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Crop Type & Strain</label>
                    <select 
                      value={cropType} 
                      onChange={e => setCropType(e.target.value)} 
                      required 
                      className="w-full text-xs font-semibold border bg-slate-50 rounded-lg p-2.5 text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">-- Choose African Crop Type --</option>
                      {AFRICAN_CROPS_LIST.map(group => (
                        <optgroup key={group.category} label={group.category}>
                          {group.items.map(item => (
                            <option key={item.value} value={item.value}>{item.name}</option>
                          ))}
                        </optgroup>
                      ))}
                      <option value="Other">Other / Custom Crop...</option>
                    </select>
                    {cropType === "Other" && (
                      <input 
                        type="text" 
                        placeholder="e.g. Soybeans" 
                        value={customCropType} 
                        onChange={e => setCustomCropType(e.target.value)} 
                        required 
                        className="w-full text-xs border bg-slate-50 rounded-lg p-2.5 mt-2 font-semibold text-slate-700 outline-none"
                      />
                    )}
                  </div>

                  <div>
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Crop Variety</label>
                    {CROP_VARIETIES.filter(v => v.crop.toLowerCase() === (cropType === "Other" ? customCropType : cropType).toLowerCase()).length > 0 ? (
                      <select
                        value={variety}
                        onChange={e => {
                          const val = e.target.value;
                          setVariety(val);
                          if (val !== "Other") {
                            const match = CROP_VARIETIES.find(v => v.variety === val && v.crop.toLowerCase() === (cropType === "Other" ? customCropType : cropType).toLowerCase());
                            if (match) {
                              setMaturityDays(match.maturityDays);
                            }
                          }
                        }}
                        className="w-full text-xs font-semibold border bg-slate-50 rounded-lg p-2.5 text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="">-- Choose Variety --</option>
                        {CROP_VARIETIES.filter(v => v.crop.toLowerCase() === (cropType === "Other" ? customCropType : cropType).toLowerCase()).map(v => (
                          <option key={v.variety} value={v.variety}>
                            {v.variety} ({v.maturityDays} Days)
                          </option>
                        ))}
                        <option value="Other">Other / Custom Variety...</option>
                      </select>
                    ) : (
                      <input
                        type="text"
                        placeholder="e.g. Standard variety"
                        value={variety === "Other" ? customVariety : variety}
                        onChange={e => {
                          setVariety(e.target.value);
                        }}
                        className="w-full text-xs border bg-slate-50 font-semibold rounded-lg p-2.5 text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    )}
                    
                    {variety === "Other" && (
                      <input
                        type="text"
                        placeholder="Enter custom variety name"
                        value={customVariety}
                        onChange={e => setCustomVariety(e.target.value)}
                        required
                        className="w-full text-xs border bg-slate-50 rounded-lg p-2.5 mt-2 font-semibold text-slate-700 outline-none"
                      />
                    )}
                  </div>

                  <div>
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">
                      Field / Mapped Block Segment
                    </label>
                    {mappedBlocks.length > 0 ? (
                      <div className="space-y-1">
                        <select
                          value={fieldBlock}
                          onChange={e => {
                            const val = e.target.value;
                            setFieldBlock(val);
                            const matchedBlock = mappedBlocks.find(b => b.name === val);
                            if (matchedBlock && matchedBlock.sizeInHectares) {
                              setAreaHectares(matchedBlock.sizeInHectares);
                            }
                          }}
                          required
                          className="w-full text-xs font-semibold border bg-slate-50 rounded-lg p-2.5 text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500"
                        >
                          <option value="">-- Select Mapped Field Block --</option>
                          {mappedBlocks.map(b => (
                            <option key={b.id} value={b.name}>
                              📍 {b.name} ({b.sizeInHectares} Ha • {b.sizeInAcres} Ac)
                            </option>
                          ))}
                        </select>
                      </div>
                    ) : (
                      <input 
                        type="text" 
                        placeholder="e.g. North Fields Block B" 
                        value={fieldBlock} 
                        onChange={e => setFieldBlock(e.target.value)} 
                        required 
                        className="w-full text-xs border bg-slate-50 font-semibold rounded-lg p-2.5 text-slate-755"
                      />
                    )}
                  </div>

                  <div className="col-span-1 md:col-span-3">
                    <AreaCultivatedInputControl
                      areaHectares={areaHectares}
                      onChangeAreaHectares={setAreaHectares}
                      required={true}
                      theme="emerald"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Planting Date</label>
                    <input 
                      type="date" 
                      value={plantingDate} 
                      onChange={e => setPlantingDate(e.target.value)} 
                      required 
                      className="w-full text-xs border bg-slate-50 font-mono rounded-lg p-2.5"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Maturity Period (Days)</label>
                    <input
                      type="number"
                      min="1"
                      value={maturityDays}
                      onChange={e => setMaturityDays(Number(e.target.value))}
                      required
                      className="w-full text-xs border bg-slate-50 font-mono rounded-lg p-2.5 outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Expected Harvest Date</label>
                    <input 
                      type="date" 
                      value={expectedHarvestDate} 
                      onChange={e => {
                        const val = e.target.value;
                        setExpectedHarvestDate(val);
                        if (plantingDate && val) {
                          const diffTime = new Date(val).getTime() - new Date(plantingDate).getTime();
                          const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
                          if (diffDays > 0) {
                            setMaturityDays(diffDays);
                          }
                        }
                      }} 
                      required 
                      className="w-full text-xs border bg-slate-50 font-mono rounded-lg p-2.5"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Planting Layout Engine</label>
                    <select 
                      value={plantingMethod} 
                      onChange={e => setPlantingMethod(e.target.value as any)} 
                      className="w-full text-xs font-semibold border bg-slate-50 rounded-lg p-2.5 text-slate-700 outline-none"
                    >
                      <option value="Field">Direct Field-Based Placement</option>
                      <option value="Bed">Raised Bed-Based Placement</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* SECTION B: Layout Parameter Spacing Engine */}
              <div className="space-y-3 bg-slate-50/60 p-4 rounded-xl border border-slate-100">
                <div className="flex items-center justify-between">
                  <h4 className="text-[10px] font-black uppercase text-indigo-600 tracking-wider">B. Layout Parameters & Spacing Constraints</h4>
                  <span className="text-[9px] text-slate-400 font-mono">Row / Plant Spacing calculation standards</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
                  {plantingMethod === "Bed" && (
                    <>
                      <div>
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Bed Width (Meters)</label>
                        <input 
                          type="number" 
                          step="0.01"
                          value={bedWidth} 
                          onChange={e => setBedWidth(Number(e.target.value))} 
                          className="w-full text-xs border bg-white rounded p-2 text-slate-700 font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Bed Length (Meters)</label>
                        <input 
                          type="number" 
                          step="0.1"
                          value={bedLength} 
                          onChange={e => setBedLength(Number(e.target.value))} 
                          className="w-full text-xs border bg-white rounded p-2 text-slate-700 font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Number of Beds</label>
                        <input 
                          type="number" 
                          value={numberOfBeds} 
                          onChange={e => setNumberOfBeds(Number(e.target.value))} 
                          className="w-full text-xs border bg-white rounded p-2 text-slate-700 font-mono"
                        />
                      </div>
                    </>
                  )}

                  <div>
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Row Spacing (cm)</label>
                    <input 
                      type="number" 
                      value={rowSpacing} 
                      onChange={e => setRowSpacing(Number(e.target.value))} 
                      className="w-full text-xs border bg-white rounded p-2 text-slate-700 font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Inside-Row spacing (cm)</label>
                    <input 
                      type="number" 
                      value={plantSpacingWithinRow} 
                      onChange={e => setPlantSpacingWithinRow(Number(e.target.value))} 
                      className="w-full text-xs border bg-white rounded p-2 text-slate-700 font-mono"
                    />
                  </div>
                </div>

                {/* Micro calculation summary */}
                <div className="pt-2 grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="p-2 bg-indigo-50 border border-indigo-100/50 rounded-lg text-[10px] font-semibold text-indigo-900 leading-normal">
                    <strong>Layout Area:</strong> {plantingMethod === "Field" ? `${(areaHectares * 10000).toLocaleString()} m² (${areaHectares} Ha • ${(areaHectares * 2.47105).toFixed(2)} Ac)` : `${(bedWidth * bedLength * numberOfBeds).toFixed(1)} m² across ${numberOfBeds} Beds`}
                  </div>
                  <div className="p-2 bg-indigo-50 border border-indigo-100/50 rounded-lg text-[10px] font-semibold text-indigo-900 leading-normal">
                    <strong>Spacing Footprint:</strong> {rowSpacing}cm row × {plantSpacingWithinRow}cm plant spacing = {(((rowSpacing || 75) / 100) * ((plantSpacingWithinRow || 25) / 100)).toFixed(4)} m² per crop node.
                  </div>
                  <div className="p-2 bg-emerald-50 border border-emerald-100/50 rounded-lg text-[10px] font-semibold text-emerald-900 leading-normal font-sans">
                    🌱 <strong>Initial Plant Population:</strong> <strong className="text-emerald-700 font-mono text-xs">{computedTotalPopulation.toLocaleString()}</strong> seedlings planned.
                  </div>
                </div>
              </div>

              {/* SECTION C: Survival Projections & Unit/Weight Harvesting parameters */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3 bg-slate-50/60 p-4 rounded-xl border border-slate-100">
                  <h4 className="text-[10px] font-black uppercase text-indigo-600 tracking-wider">C. Survival Rate Modelling</h4>
                  <div className="grid grid-cols-2 gap-3 text-xs font-semibold">
                    <div>
                      <label className="text-[10px] text-slate-500 block mb-1">Expected Survival Rate (%)</label>
                      <input 
                        type="number" 
                        max="100" 
                        min="1"
                        value={expectedSurvivalRate} 
                        onChange={e => setExpectedSurvivalRate(Number(e.target.value))} 
                        className="w-full text-xs border bg-white rounded p-2 font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-500 block mb-1">Expected Harvest Rate (%)</label>
                      <input 
                        type="number" 
                        max="100" 
                        min="1"
                        value={expectedHarvestRate} 
                        onChange={e => setExpectedHarvestRate(Number(e.target.value))} 
                        className="w-full text-xs border bg-white rounded p-2 font-mono"
                      />
                    </div>
                  </div>
                  <div className="p-2 bg-slate-100 rounded text-[9.5px] font-medium leading-relaxed font-sans text-slate-500">
                    Expected Live Plants: <strong className="text-slate-800 font-mono">{computedLivePlants.toLocaleString()}</strong> (Survival) <br />
                    Predicted Harvest Population: <strong className="text-emerald-600 font-mono">{computedHarvestPopulation.toLocaleString()}</strong> stalks ready for collection.
                  </div>
                </div>

                <div className="space-y-3 bg-slate-50/60 p-4 rounded-xl border border-slate-100">
                  <h4 className="text-[10px] font-black uppercase text-indigo-600 tracking-wider">D. Yield Estimation Engine</h4>
                  <div className="grid grid-cols-2 gap-3 text-xs font-semibold">
                    <div>
                      <label className="text-[10px] text-slate-500 block mb-1">Measurement Strategy</label>
                      <select 
                        value={measuredInKgOrUnits} 
                        onChange={e => setMeasuredInKgOrUnits(e.target.value as any)} 
                        className="w-full text-xs border bg-white rounded p-2 outline-none text-slate-700"
                      >
                        <option value="Kg">Weight-Based (Kg)</option>
                        <option value="Units">Unit-Based (Cobs/Heads)</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-500 block mb-1">Unit/Metric Name</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Cob, Head, Bulb"
                        value={harvestUnitName} 
                        onChange={e => setHarvestUnitName(e.target.value)} 
                        className="w-full text-xs border bg-white rounded p-2 font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-500 block mb-1">Units Per Plant</label>
                      <input 
                        type="number" 
                        step="0.1"
                        value={avgHarvestUnitsPerPlant} 
                        onChange={e => setAvgHarvestUnitsPerPlant(Number(e.target.value))} 
                        className="w-full text-xs border bg-white rounded p-2 font-mono"
                        disabled={measuredInKgOrUnits === "Kg"}
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-500 block mb-1">Average Plant Weight (Kg)</label>
                      <input 
                        type="number" 
                        step="0.01"
                        value={averageWeightPerPlantKg} 
                        onChange={e => setAverageWeightPerPlantKg(Number(e.target.value))} 
                        className="w-full text-xs border bg-white rounded p-2 font-mono"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION E: Expected Revenue Pricing Calculator */}
              <PricingTierCalculator
                splitType={pricingSplitType}
                setSplitType={setPricingSplitType}
                tiers={pricingTiers}
                setTiers={setPricingTiers}
                expectedSellingPricePerUnit={expectedSellingPricePerUnit}
                setExpectedSellingPricePerUnit={setExpectedSellingPricePerUnit}
                expectedSellingPricePerKg={expectedSellingPricePerKg}
                setExpectedSellingPricePerKg={setExpectedSellingPricePerKg}
                measuredInKgOrUnits={measuredInKgOrUnits}
                harvestUnitName={harvestUnitName}
                totalVolume={measuredInKgOrUnits === "Units" ? computedExpectedUnits : computedExpectedKg}
                computedRevenueProjection={computedRevenueProjection}
                currencySymbol={currencySymbol}
                sectionLetter="E"
              />

              {/* Action Buttons */}
              <div className="flex justify-end gap-2 pt-2 border-t">
                <button 
                  type="button" 
                  onClick={() => setShowAddForm(false)} 
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-extrabold text-slate-600 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black rounded-lg text-xs shadow-lg transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4 text-slate-950" />
                  <span>Establish Crop Cycle</span>
                </button>
              </div>
            </form>
          )}

          {/* Read-Only Mode Agronomist & Marketplace Access Notice */}
          {isReadonly && (
            <div className="mb-4">
              <ReadOnlyWarningBanner
                variant="inline"
                onNavigateToMarketplace={onNavigateToMarketplace}
                onNavigateToAgronomy={onNavigateToAdvisory}
                onTopUpCredits={onTopUpCredits}
                onActivateSubscription={onActivateSubscription}
              />
            </div>
          )}

          {/* Grid control banner */}
          <div className="flex flex-wrap justify-between items-center gap-3 mb-2">
            <div>
              <h2 className="font-black text-slate-800 text-xs uppercase tracking-widest flex items-center gap-2">
                <Sliders className="w-4 h-4 text-emerald-600" />
                <span>Crop Batches & Milestone Managers</span>
              </h2>
              <p className="text-xs text-slate-500 font-medium">Verify production states, isolated safely inside multi-tenant partitions.</p>
            </div>
            <div className="flex gap-2">
              {onGotoCsvImport && (
                <button 
                  type="button"
                  onClick={() => onGotoCsvImport("crops")}
                  className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-bold font-mono flex items-center gap-1.5"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>Import via CSV</span>
                </button>
              )}
              {!isReadonly && crops.length < 15 ? (
                <button 
                  id="create-crop-cycle-button"
                  onClick={() => setShowAddForm(true)}
                  className="px-3.5 py-1.5 bg-slate-950 hover:bg-slate-800 text-white rounded-lg text-xs font-bold font-mono flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 text-white" />
                  <span>+ Create Crop Cycle</span>
                </button>
              ) : isReadonly ? (
                <span className="text-xs text-rose-600 font-bold bg-rose-50 px-2 rounded-lg border border-rose-100 font-mono py-1.5 flex items-center gap-1">
                  <Info className="w-3.5 h-3.5" /> Read-only mode active
                </span>
              ) : (
                <span className="text-xs text-amber-500 font-bold bg-amber-50 px-2 rounded-lg border border-amber-100 font-mono py-1.5">
                  Tenant crop list full (Max 15 active limits)
                </span>
              )}
            </div>
          </div>

          {/* Bulk Select & Batch Action Control Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 bg-slate-100/90 border border-slate-200 rounded-2xl mb-4 font-sans text-xs shadow-xs">
            <div className="flex flex-wrap items-center gap-3">
              <label className="flex items-center gap-2 cursor-pointer font-extrabold text-slate-800">
                <input
                  type="checkbox"
                  checked={crops.length > 0 && selectedCropIds.length === crops.length}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedCropIds(crops.map(c => c.id));
                    } else {
                      setSelectedCropIds([]);
                    }
                  }}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                />
                <span>Select All Crops ({crops.length})</span>
              </label>
              {selectedCropIds.length > 0 && (
                <span className="text-[11px] font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-0.5 rounded-full">
                  {selectedCropIds.length} Selected
                </span>
              )}

              {/* Sort Dropdown */}
              <div className="flex items-center gap-1.5 bg-white border border-slate-300 px-2.5 py-1 rounded-xl shadow-xs">
                <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
                <span className="text-[10px] font-black uppercase text-slate-500">Sort By:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="text-xs font-extrabold text-slate-800 bg-transparent outline-none cursor-pointer"
                >
                  <option value="default">Default Order</option>
                  <option value="plantingDateDesc">Date Planted (Newest First)</option>
                  <option value="plantingDateAsc">Date Planted (Oldest First)</option>
                  <option value="expectedHarvestDateAsc">Expected Harvest Date (Earliest First)</option>
                  <option value="expectedHarvestDateDesc">Expected Harvest Date (Latest First)</option>
                </select>
              </div>
            </div>

            {selectedCropIds.length > 0 && (
              <div className="flex flex-wrap items-center gap-2.5">
                {/* Batch Status Update */}
                <div className="flex items-center gap-1.5 bg-white border border-slate-300 px-2.5 py-1 rounded-xl shadow-xs">
                  <span className="text-[10px] font-black uppercase text-slate-500">Batch Status:</span>
                  <select
                    value={batchCropStatus}
                    onChange={(e) => setBatchCropStatus(e.target.value as any)}
                    className="text-xs font-extrabold text-slate-800 bg-transparent outline-none cursor-pointer"
                  >
                    <option value="Planning">Planning</option>
                    <option value="Active">Active</option>
                    <option value="Harvested">Harvested</option>
                    <option value="Sold">Sold / Finished</option>
                  </select>
                  <button
                    type="button"
                    onClick={() => {
                      selectedCropIds.forEach(id => {
                        if (onUpdateStatus) onUpdateStatus(id, batchCropStatus as any);
                      });
                    }}
                    className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-[10px] rounded-lg transition-all cursor-pointer shadow-xs"
                  >
                    Apply to {selectedCropIds.length}
                  </button>
                </div>

                {/* Batch Archive */}
                <button
                  type="button"
                  onClick={async () => {
                    const ok = await confirm({
                      title: "Archive Selected Crop Cycles",
                      message: `Are you sure you want to archive ${selectedCropIds.length} selected crop cycle(s)? This will remove them from active tracking.`,
                      confirmText: "Archive All Selected",
                      cancelText: "Cancel",
                      type: "danger"
                    });
                    if (ok) {
                      selectedCropIds.forEach(id => {
                        if (onDeleteCrop) onDeleteCrop(id);
                      });
                      setSelectedCropIds([]);
                    }
                  }}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
                >
                  <Trash className="w-3.5 h-3.5" />
                  <span>Batch Archive ({selectedCropIds.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedCropIds([])}
                  className="px-2.5 py-1 text-slate-500 hover:text-slate-800 font-extrabold text-xs cursor-pointer transition-colors"
                >
                  Clear Selection
                </button>
              </div>
            )}
          </div>

          {/* Main Batches Card Items */}
          <div className="grid grid-cols-1 gap-6">
            {sortedCrops.map(crop => {
              const survivalRate = crop.expectedSurvivalRate || 95;
              const harvestPrice = crop.measuredInKgOrUnits === "Units" 
                ? `${currencySymbol}${crop.expectedSellingPricePerUnit || 0} / ${crop.harvestUnitName || "Unit"}`
                : `${currencySymbol}${crop.expectedSellingPricePerKg || 0} / Kg`;

              const forecastedRevenue = crop.expectedRevenueProjection || 0;
              const actualRevenue = crop.revenueLinked || 0;
              const financialVariance = actualRevenue - forecastedRevenue;

              return (
                <div key={crop.id} className="bg-white border rounded-2xl shadow-sm overflow-hidden border-slate-200">
                  {/* Card Header row */}
                  <div className="px-6 py-4 border-b bg-slate-50/50 flex flex-wrap justify-between items-center gap-4">
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={selectedCropIds.includes(crop.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedCropIds(prev => [...prev, crop.id]);
                          } else {
                            setSelectedCropIds(prev => prev.filter(uid => uid !== crop.id));
                          }
                        }}
                        className="rounded border-slate-300 text-rose-600 focus:ring-rose-500 cursor-pointer w-4 h-4"
                      />
                      <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-extrabold text-xs">
                        {crop.cropType.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center flex-wrap gap-2">
                          <h3 className="font-bold text-sm text-slate-800">{crop.cropType}</h3>
                          {crop.variety && (
                            <span className="text-[10px] font-extrabold px-1.5 py-0.5 bg-indigo-50 text-indigo-700 uppercase rounded border border-indigo-100">
                              {crop.variety}
                            </span>
                          )}
                          <span className="text-[10px] font-extrabold px-1.5 py-0.5 bg-slate-200 text-slate-700 uppercase rounded">
                            {crop.plantingMethod || "Field"}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 font-medium font-sans flex flex-wrap items-center gap-2 mt-0.5">
                          <span>Block: <strong className="text-slate-700">{crop.fieldBlock}</strong> ({crop.areaHectares} Ha)</span>
                          <button
                            type="button"
                            onClick={() => setActiveTab("plot_mapper")}
                            className="inline-flex items-center gap-1 text-[10px] font-black text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2 py-0.5 rounded-full cursor-pointer transition-colors"
                            title="Open Field Block in Plot Polygon Mapper"
                          >
                            🗺️ Satellite GIS Block
                          </button>
                          {crop.maturityDays && <span className="text-slate-400 font-mono font-bold">({crop.maturityDays} Days Maturity)</span>}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 flex-wrap">
                      <span className="text-[9.5px] font-black uppercase text-slate-400">STAGE STATUS:</span>
                      <select 
                        value={crop.status}
                        onChange={e => onUpdateStatus(crop.id, e.target.value as any)}
                        className="text-xs font-extrabold bg-white border rounded-lg px-2.5 py-1 text-slate-700 outline-none cursor-pointer border-slate-300 focus:ring-1 focus:ring-emerald-500"
                      >
                        <option value="Planning">Planning</option>
                        <option value="Active">Active</option>
                        <option value="Harvested">Harvested</option>
                        <option value="Sold">Sold / Finished</option>
                      </select>
                      
                      {/* Share Summary PDF Report Button */}
                      <button
                        type="button"
                        onClick={() => handleShareCropSummaryPdf(crop)}
                        className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 text-[11px] font-extrabold rounded-lg flex items-center gap-1 border border-indigo-200 shadow-xs cursor-pointer transition-colors"
                        title="Share Harvest Summary PDF Report"
                      >
                        <Share2 className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Share PDF</span>
                      </button>

                      {!isReadonly && (
                        <button
                          type="button"
                          onClick={() => setSelectedHarvestCrop(crop)}
                          className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 text-[11px] font-black rounded-lg flex items-center gap-1 shadow-sm cursor-pointer border border-amber-400"
                        >
                          <Sprout className="w-3.5 h-3.5" />
                          <span>Log Harvest</span>
                        </button>
                      )}

                      {!isReadonly && onEditCrop && (
                        <button
                          type="button"
                          onClick={() => setEditingCrop(crop)}
                          className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-[11px] font-extrabold rounded-lg flex items-center gap-1 border border-slate-200 shadow-xs cursor-pointer"
                        >
                          <Sliders className="w-3 h-3 text-slate-600" />
                          <span>Edit</span>
                        </button>
                      )}
                      
                      {!isReadonly && onDeleteCrop && (
                        <button
                          type="button"
                          onClick={async () => {
                            const ok = await confirm({
                              title: "Archive Crop Batch",
                              message: `Are you sure you want to archive crop batch "${crop.cropType}"? This will move it from the active list.`,
                              confirmText: "Archive",
                              cancelText: "Cancel",
                              type: "warning"
                            });
                            if (ok) {
                              onDeleteCrop(crop.id);
                              setSelectedCropIds(prev => prev.filter(uid => uid !== crop.id));
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded bg-transparent transition-colors cursor-pointer"
                        >
                          <Trash className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Card Info Panels - Bento grid style */}
                  <div className="p-6 grid grid-cols-1 md:grid-cols-4 gap-6 border-b text-xs font-semibold">
                    {/* Plant population & spacing model info */}
                    <div className="space-y-2 border-r border-slate-100 pr-2">
                      <span className="text-[10px] font-bold uppercase text-indigo-400 tracking-wider flex items-center gap-1">
                        <Calculator className="w-3.5 h-3.5" />
                        <span>Population Parameters</span>
                      </span>
                      <div className="space-y-1 text-slate-600 font-sans font-medium">
                        <p>Expected Spacing: <strong className="text-slate-800">{crop.rowSpacing || 75}x{crop.plantSpacingWithinRow || 25} cm</strong></p>
                        <p>Total Plant Population: <strong className="text-indigo-900 font-mono font-bold">{(crop.totalExpectedPlantPopulation || 0).toLocaleString()}</strong></p>
                        <p>Survival Projections: <strong className="text-slate-800">{survivalRate}% ({Math.floor((crop.totalExpectedPlantPopulation || 0) * (survivalRate/100)).toLocaleString()} Live)</strong></p>
                      </div>
                    </div>

                    {/* Yield target and measurement model */}
                    <div className="space-y-2 border-r border-slate-100 pr-2">
                      <span className="text-[10px] font-bold uppercase text-emerald-500 tracking-wider flex items-center gap-1">
                        <Award className="w-3.5 h-3.5" />
                        <span>Agronomic Volumes</span>
                      </span>
                      <div className="space-y-1 text-slate-600 font-sans font-medium">
                        <p>Expected Harvest: <strong className="text-slate-800">{crop.expectedYieldKg?.toLocaleString()} Kg</strong></p>
                        <p>Actual Yield Achieved: <strong className="text-slate-800">{crop.actualYieldKg || 0} Kg</strong></p>
                        {crop.measuredInKgOrUnits === "Units" && (
                          <p>Units Per Plant: <strong className="text-slate-800 font-mono">{crop.avgHarvestUnitsPerPlant || 1} {crop.harvestUnitName || "Unit"}</strong></p>
                        )}
                        <p>Selling Price: <strong className="text-emerald-700 font-semibold">{harvestPrice}</strong></p>
                      </div>
                    </div>

                    {/* Timeline */}
                    <div className="space-y-2 border-r border-slate-100 pr-2">
                      <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>Timeline Milestones</span>
                      </span>
                      <div className="space-y-1 text-slate-600 font-sans font-medium">
                        <p>Season Plating: <strong className="text-slate-800 font-mono">{crop.plantingDate}</strong></p>
                        <p>Target Collection: <strong className="text-slate-800 font-mono">{crop.expectedHarvestDate}</strong></p>
                        <p>Current Stage: <span className="px-1.5 py-0.5 bg-emerald-50 text-emerald-700 font-bold uppercase text-[9px] rounded font-sans">{crop.status}</span></p>
                        {getDaysToHarvestDisplay(crop.plantingDate, crop.expectedHarvestDate, crop.status)}
                      </div>
                    </div>

                    {/* Cash Projection PQL variance analysis */}
                    <div className="space-y-2 pl-2 text-right flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] font-bold uppercase text-slate-400 block tracking-widest">Expected Revenue</span>
                        <span className="text-md font-black text-slate-900 font-mono">
                          {currencySymbol}{(forecastedRevenue).toLocaleString()}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase text-slate-400 block tracking-widest">Postings Variance (Actual vs Planned)</span>
                        <div className="flex items-center justify-end gap-1.5">
                          <span className={`text-xs font-black font-mono ${financialVariance >= 0 ? "text-emerald-600" : "text-rose-500"}`}>
                            {financialVariance >= 0 ? "+" : ""}{currencySymbol}{financialVariance.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Card Section Tabs */}
                  {(() => {
                    const activeCardTab = cardTabs[crop.id] || "growth_guide";
                    const linkedDNs = deliveryNotes.filter(dn => dn.cropCycleId === crop.id && (dn.status === "Confirmed" || dn.status === "confirmed"));
                    const revenue_recognised = linkedDNs.reduce((acc, dn) => acc + (dn.totalValue || 0), 0);
                    const cost_to_date = crop.expensesLinked || 0;
                    const gross_margin = revenue_recognised - cost_to_date;
                    const totalGrossPct = revenue_recognised > 0 ? (gross_margin / revenue_recognised) * 100 : 0;

                    return (
                      <>
                        <div className="px-6 py-2 pb-0 border-b border-slate-100 bg-slate-50/30 flex gap-4 overflow-x-auto">
                          <button
                            type="button"
                            onClick={() => setCardTabs(prev => ({ ...prev, [crop.id]: "growth_guide" }))}
                            className={`pb-1.5 text-[11px] font-black uppercase tracking-wider relative transition-colors cursor-pointer flex items-center gap-1.5 ${
                              activeCardTab === "growth_guide" || !cardTabs[crop.id] ? "text-emerald-700 border-b-2 border-emerald-700 font-extrabold" : "text-slate-400 hover:text-slate-600"
                            }`}
                          >
                            <Sprout className="w-3.5 h-3.5 text-emerald-600" />
                            🌱 AI Growth Guide & Inputs
                          </button>
                          <button
                            type="button"
                            onClick={() => setCardTabs(prev => ({ ...prev, [crop.id]: "milestones" }))}
                            className={`pb-1.5 text-[11px] font-black uppercase tracking-wider relative transition-colors cursor-pointer ${
                              activeCardTab === "milestones" ? "text-slate-900 border-b-2 border-slate-900" : "text-slate-400 hover:text-slate-600"
                            }`}
                          >
                            📋 Growth Milestones
                          </button>
                          <button
                            type="button"
                            onClick={() => setCardTabs(prev => ({ ...prev, [crop.id]: "sales_margin" }))}
                            className={`pb-1.5 text-[11px] font-black uppercase tracking-wider relative transition-colors cursor-pointer ${
                              activeCardTab === "sales_margin" ? "text-emerald-700 border-b-2 border-emerald-700" : "text-slate-400 hover:text-slate-600"
                            }`}
                          >
                            💰 Sales & Margins (Offtaker Deliveries)
                          </button>
                        </div>

                        {activeCardTab === "growth_guide" || !cardTabs[crop.id] ? (
                          <div className="p-6 bg-stone-50/80 dark:bg-stone-900/40">
                            <GrowthGuideTab cropCycle={crop} tenantId={tenantId} />
                          </div>
                        ) : activeCardTab === "milestones" ? (
                          <div className="p-6 bg-slate-50/50">
                            <span className="text-[10px] font-extrabold uppercase text-slate-400 block mb-3 tracking-widest">Progressive Farm Cycle Milestones Checklist</span>
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                              {crop.milestones && crop.milestones.map(m => (
                                <div key={m.id} className={`p-3 rounded-xl border flex flex-col justify-between h-20 transition-all ${
                                  m.isCompleted ? "bg-emerald-50 text-emerald-800 border-emerald-200" : "bg-white border-slate-200 text-slate-600"
                                }`}>
                                  <div className="flex justify-between items-start">
                                    <span className="text-[11px] font-black leading-tight line-clamp-2">{m.name}</span>
                                    <input 
                                      type="checkbox"
                                      checked={m.isCompleted}
                                      onChange={e => onUpdateMilestone(crop.id, m.id, e.target.checked)}
                                      className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer w-4 h-4"
                                    />
                                  </div>
                                  <span className="text-[9px] font-mono text-slate-400 block uppercase">Season Checklist</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <div className="p-6 bg-slate-50/50 space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div className="bg-white p-4 rounded-xl border border-slate-200">
                                <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block mb-1">Revenue Recognised</span>
                                <span className="text-lg font-black text-emerald-700 font-mono">
                                  {currencySymbol}{revenue_recognised.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </span>
                                <span className="text-[10px] text-slate-400 block mt-1 font-semibold leading-none font-mono">Status: Confirmed DNs</span>
                              </div>

                              <div className="bg-white p-4 rounded-xl border border-slate-200">
                                <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block mb-1">Cost To Date (COGS)</span>
                                <span className="text-lg font-black text-rose-600 font-mono">
                                  {currencySymbol}{cost_to_date.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </span>
                                <span className="text-[10px] text-slate-400 block mt-1 font-semibold leading-none font-mono">Direct expense lines</span>
                              </div>

                              <div className={`p-4 rounded-xl border ${gross_margin >= 0 ? "bg-emerald-50/50 border-emerald-100" : "bg-rose-50/50 border-rose-100"}`}>
                                <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block mb-1">Gross Cycle Margin</span>
                                <span className={`text-lg font-black font-mono ${gross_margin >= 0 ? "text-emerald-800" : "text-rose-800"}`}>
                                  {currencySymbol}{gross_margin.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </span>
                                <span className="text-[10px] text-slate-400 block mt-1 font-semibold leading-none font-mono">Margin: {(totalGrossPct).toFixed(1)}%</span>
                              </div>
                            </div>

                            {/* Display underlying delivery notes support */}
                            <div className="bg-white rounded-xl border border-slate-200/85 overflow-hidden">
                              <div className="px-4 py-2 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                                <span className="text-[10.5px] font-bold text-slate-600 uppercase">Supporting Delivery Accruals</span>
                                <span className="text-[10px] uppercase bg-slate-200 px-1.5 py-0.5 font-bold rounded font-mono text-slate-700">
                                  {linkedDNs.length} record{linkedDNs.length === 1 ? "" : "s"}
                                </span>
                              </div>

                              {linkedDNs.length === 0 ? (
                                <div className="p-4 text-center text-xs italic text-slate-400">
                                  No confirmed delivery notes linked to this crop cycle yet. Record deliveries at Offtaker portal and project margins.
                                </div>
                              ) : (
                                <div className="overflow-x-auto">
                                  <table className="w-full text-left border-collapse text-[11.5px]">
                                    <thead>
                                      <tr className="bg-slate-50 border-b border-slate-100 text-[10px] font-bold uppercase text-slate-400">
                                        <th className="p-2.5">DN Ref</th>
                                        <th className="p-2.5">Buyer (Offtaker)</th>
                                        <th className="p-2.5">Quantity</th>
                                        <th className="p-2.5">Grade</th>
                                        <th className="p-2.5">Unit Price</th>
                                        <th className="p-2.5 text-right">Total Amount</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {linkedDNs.map((dn: any) => (
                                        <tr key={dn.id} className="border-b border-slate-100 hover:bg-slate-50/50">
                                          <td className="p-2.5 font-bold text-slate-800 font-mono">{dn.dnNumber}</td>
                                          <td className="p-2.5 text-slate-600 font-semibold">{dn.offtakerName || "Certified Aggregator"}</td>
                                          <td className="p-2.5 font-semibold text-slate-700">{dn.quantity || dn.qty} {dn.unit}</td>
                                          <td className="p-2.5 font-bold text-slate-500 font-mono">{dn.gradeTag || dn.grade}</td>
                                          <td className="p-2.5 font-semibold text-slate-700 font-mono">{currencySymbol}{(dn.unitPrice || 0).toFixed(2)}</td>
                                          <td className="p-2.5 text-right font-bold text-emerald-800 font-mono">{currencySymbol}{(dn.totalValue || 0).toFixed(2)}</td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </>
                    );
                  })()}
                </div>
              );
            })}
            
            {crops.length === 0 && (
              <div className="bg-slate-50 border border-dashed p-10 text-center rounded-2xl text-slate-400 font-semibold italic">
                No active or planned crop batches registered yet. Click &ldquo;+ Create Crop Cycle&rdquo; to model your planting layout and expect yields!
              </div>
            )}
          </div>

        </div>
      ) : activeTab === "forecaster" ? (
        // Tab 2: Production Forecasting & AI Yield Intelligence Dashboard
        <div className="space-y-6 animate-in fade-in duration-200 font-sans" id="crops-forecasting-panel">
          
          {/* Dashboard Summary upper widgets */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Total Planned Population</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl font-black text-indigo-900 font-mono">{totalPlannedActivePopulation.toLocaleString()}</span>
                <span className="text-[10px] font-extrabold text-indigo-500">Seedlings Blocked</span>
              </div>
              <p className="text-[10.5px] text-slate-400 leading-normal font-sans font-medium">Modelled across all active multi-tenant segments.</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest block">Total Forecast Revenue</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl font-black text-slate-900 font-mono">{currencySymbol}{totalForecastedRevenue.toLocaleString()}</span>
                <span className="text-[10px] font-extrabold text-emerald-500">Pre-harvest value</span>
              </div>
              <p className="text-[10.5px] text-slate-400 leading-normal font-medium">Aggregated on-row yield potential math.</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest block">Actual Realized Revenue</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl font-black text-indigo-950 font-mono">{currencySymbol}{totalActualRevenue.toLocaleString()}</span>
                <span className="text-[10px] font-extrabold text-slate-500">Double-entry ledger</span>
              </div>
              <p className="text-[10.5px] text-slate-400 leading-normal font-medium">Sum of all actual invoices linked successfully.</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border text-white p-5 rounded-2xl border border-slate-200 space-y-1 bg-slate-950">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Ledger Variance Analysis</span>
              <div className="flex items-baseline gap-1.5">
                <span className={`text-xl font-black font-mono ${netVariance >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                  {netVariance >= 0 ? "+" : ""}{currencySymbol}{netVariance.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-400 uppercase">Var</span>
              </div>
              <p className="text-[10.5px] text-slate-500 leading-normal font-medium font-sans">Compare planned goals against historical entries.</p>
            </div>
          </div>

          {/* Machine Learning Yield Forecasting Engine Component */}
          <YieldForecastingModule 
            crops={crops} 
            currencySymbol={currencySymbol} 
            onAddCropClick={() => {
              setActiveTab("cycles");
              setShowAddForm(true);
            }}
          />

          {/* FY Yield Forecast Line Chart Card */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-4 shadow-sm">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-3 border-b border-slate-100 gap-2">
              <div>
                <h3 className="text-sm font-black text-slate-950 uppercase tracking-wider flex items-center gap-1.5">
                  <LineChart className="w-4 h-4 text-emerald-600" />
                  <span>Financial Year Harvest Yield Forecast</span>
                </h3>
                <p className="text-xs text-slate-500 font-sans font-medium">Projected vs actual crop yields (Kg) for FY {startYear}/{startYear + 1}</p>
              </div>
              <div className="flex gap-4 text-[10.5px] font-extrabold uppercase tracking-wider font-mono">
                <span className="flex items-center gap-1.5 text-blue-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" /> Projected Yield
                </span>
                <span className="flex items-center gap-1.5 text-emerald-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Actual Yield
                </span>
              </div>
            </div>

            <div className="h-64 w-full">
              {chartData.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 bg-slate-50 border border-slate-100 rounded-xl p-6 text-center space-y-1">
                  <span className="text-xs font-bold text-slate-500">No Crop Cycles Active</span>
                  <p className="text-[11px] text-slate-400 max-w-sm">Please register your active crop planting batches to view seasonal yield forecasts and projections.</p>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsLineChart data={chartData} margin={{ top: 15, right: 15, left: 10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="month" stroke="#94a3b8" fontSize={10.5} fontWeight="bold" tickLine={false} axisLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={10.5} fontWeight="bold" tickLine={false} axisLine={false} tickFormatter={(v) => `${v.toLocaleString()} Kg`} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: "#0f172a", borderRadius: "12px", border: "none", color: "#f8fafc" }}
                      labelStyle={{ fontWeight: "bold", fontSize: "11px", color: "#94a3b8" }}
                      itemStyle={{ fontSize: "12px", padding: "2px 0" }}
                    />
                    <Line type="monotone" dataKey="Projected Yield (Kg)" stroke="#3b82f6" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                    <Line type="monotone" dataKey="Actual Yield (Kg)" stroke="#10b981" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                  </RechartsLineChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Column 1 & 2: Crop Efficiency Matrix list */}
            <div className="md:col-span-2 bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                <div>
                  <h3 className="text-sm font-black text-slate-950 uppercase tracking-wider">Mabala Production Forecasts Ledger</h3>
                  <p className="text-xs text-slate-500">Active tenant allocations ledger accounts</p>
                </div>
                <span className="px-2.5 py-0.5 bg-indigo-50 text-indigo-700 text-[10px] font-bold uppercase rounded font-mono">
                  Forecast Accounts
                </span>
              </div>

              <div className="space-y-3.5">
                {crops.length > 0 ? (
                  crops.map(c => {
                    const price = c.measuredInKgOrUnits === "Units" 
                      ? `${currencySymbol}${c.expectedSellingPricePerUnit || 0} / Unit`
                      : `${currencySymbol}${c.expectedSellingPricePerKg || 0} / Kg`;
                    const area = c.areaHectares || 1;
                    const pop = c.totalExpectedPlantPopulation || 1;
                    const expectedRev = c.expectedRevenueProjection || 0;
                    
                    // Efficiency formulas
                    const yieldPerHa = (c.expectedYieldKg || 0) / area;
                    const yieldPerAcre = ((c.expectedYieldKg || 0) / area) * 0.404686;
                    const revPerHa = expectedRev / area;
                    const revPerPlant = expectedRev / pop;

                    return (
                      <div key={c.id} className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-xs font-semibold space-y-3">
                        <div className="flex justify-between items-center text-xs">
                          <span className="font-extrabold text-slate-800 block text-sm">{c.cropType}</span>
                          <span className="text-indigo-650 font-mono">{c.fieldBlock}</span>
                        </div>

                        {/* Efficiency widgets */}
                        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 bg-white p-3 rounded-lg border border-slate-100/50">
                          <div className="space-y-0.5">
                            <span className="text-[10px] text-slate-400 block">Yield Per Hectare</span>
                            <span className="text-slate-800 font-mono font-bold">{Math.floor(yieldPerHa).toLocaleString()} Kg/Ha</span>
                          </div>
                          <div className="space-y-0.5">
                            <span className="text-[10px] text-slate-400 block">Yield Per Acre</span>
                            <span className="text-slate-800 font-mono font-bold">{Math.floor(yieldPerAcre).toLocaleString()} Kg/Ac</span>
                          </div>
                          <div className="space-y-0.5">
                            <span className="text-[10px] text-slate-400 block">Revenue Per Hectare</span>
                            <span className="text-emerald-600 font-mono font-bold">{currencySymbol}{Math.floor(revPerHa).toLocaleString()}</span>
                          </div>
                          <div className="space-y-0.5">
                            <span className="text-[10px] text-slate-400 block">Revenue Per Plant</span>
                            <span className="text-emerald-600 font-mono font-bold">{currencySymbol}{revPerPlant.toFixed(2)} / pl</span>
                          </div>
                        </div>

                        {/* Target comparisons */}
                        <div className="flex justify-between items-center pt-1 text-[11px] text-slate-500 font-sans font-medium">
                          <span>Forecast Target: <strong className="text-slate-800 font-mono">{currencySymbol}{(c.expectedRevenueProjection || 0).toLocaleString()}</strong></span>
                          <span>Actual Earned: <strong className="text-emerald-700 font-mono">{currencySymbol}{(c.revenueLinked || 0).toLocaleString()}</strong></span>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="text-slate-400 italic text-center p-6 text-xs">
                    Please create crop cycle batches first using Tab 1 to build financial projections ledger!
                  </div>
                )}
              </div>
            </div>

            {/* Column 3: AI Yield Intelligence Recommendation Box */}
            <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 text-white space-y-4">
              <div className="pb-3 border-b border-slate-800 space-y-1">
                <div className="flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-emerald-400 animate-pulse" />
                  <h3 className="text-sm font-black uppercase tracking-widest text-[#f8fafc]">
                    Hercules AI Spacing Optimizer
                  </h3>
                </div>
                <p className="text-[11px] text-slate-405 leading-relaxed">
                  Real-time machine learning recommendations parsing plant spacing, rain volumes, fertilizer usage, and soil profiles.
                </p>
              </div>

              {crops.length > 0 ? (
                <div className="space-y-4 text-xs font-semibold">
                  {/* Selector for AI */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400 block uppercase">Select Target Crop Batch</label>
                    <select
                      value={aiSelectedCropId}
                      onChange={e => setAiSelectedCropId(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 text-slate-100 p-2.5 rounded-lg outline-none font-bold"
                    >
                      <option value="">-- Choose Harvest Batch --</option>
                      {crops.map(c => (
                        <option key={c.id} value={c.id}>{c.cropType} - Block: {c.fieldBlock} ({(c.totalExpectedPlantPopulation || 0).toLocaleString()} Pl)</option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="button"
                    onClick={runAiYieldDiagnostics}
                    disabled={aiLoading}
                    className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 font-bold text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40"
                  >
                    {aiLoading ? (
                      <>
                        <span className="w-4 h-4 rounded-full border-2 border-slate-950 border-t-transparent animate-spin" />
                        <span>Running Core Diagnostics...</span>
                      </>
                    ) : (
                      <>
                        <Cpu className="w-4 h-4 text-slate-950" />
                        <span>Run AI Spacing Optimizer</span>
                      </>
                    )}
                  </button>

                  {/* AI Results */}
                  {aiReport && (
                    <div className="space-y-4 p-4 bg-slate-950/70 border border-slate-800 rounded-xl mt-3 animate-fade-in text-[11.5px] leading-relaxed">
                      
                      <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                        <div className="bg-slate-900 p-2 rounded border border-slate-800 space-y-0.5">
                          <span className="text-slate-400 block uppercase text-[8px]">Yield Score</span>
                          <span className="text-emerald-400 font-black font-mono text-xs">{aiReport.yieldPredictionScore}%</span>
                        </div>
                        <div className="bg-slate-900 p-2 rounded border border-slate-800 space-y-0.5">
                          <span className="text-slate-400 block uppercase text-[8px]">Revenue Conf</span>
                          <span className="text-indigo-400 font-black font-mono text-xs">{aiReport.revenueConfidenceScore}%</span>
                        </div>
                        <div className="bg-slate-900 p-2 rounded border border-slate-800 space-y-0.5">
                          <span className="text-slate-400 block uppercase text-[8px]">Harvest Risk</span>
                          <span className="text-rose-400 font-black font-mono text-xs">{aiReport.productionRiskScore}%</span>
                        </div>
                      </div>

                      {/* AI Recommendations */}
                      <div className="space-y-2 font-medium font-sans text-slate-300">
                        <span className="text-[10px] text-emerald-400 uppercase tracking-wider block font-bold">Agronomic Guidance</span>
                        {aiReport.recommendations && aiReport.recommendations.map((rec, rIdx) => (
                          <div key={rIdx} className="flex gap-2 items-start text-xs p-1">
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                            <p className="text-slate-300 leading-normal font-semibold">{rec}</p>
                          </div>
                        ))}
                      </div>

                    </div>
                  )}

                  {!aiReport && !aiLoading && (
                    <div className="p-4 bg-slate-950/30 border border-slate-800 border-dashed text-center text-slate-500 rounded-xl">
                      Select an active crop batch above and press run to apply AI simulation modelling and recommendations!
                    </div>
                  )}

                </div>
              ) : (
                <div className="text-slate-500 italic text-center p-6 text-xs">
                  Please create crop cycle batches first to run AI calculations!
                </div>
              )}

            </div>
          </div>

        </div>
      ) : activeTab === "npk_calculator" ? (
        <ZambiaNpkCalculator currencySymbol={currencySymbol} crops={crops} />
      ) : activeTab === "plot_mapper" ? (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Interactive Leaflet Map View */}
          <LeafletFieldMap
            initialBlocks={mappedBlocks}
            cropCycles={crops}
            onSaveBlocks={setMappedBlocks}
            onUpdateCropCycleBlock={handleUpdateCropCycleBlock}
            currencySymbol={currencySymbol}
            farmLocation={farmLocation}
          />

          {/* GeoPoint Polygon Coordinate Boundary Mapper */}
          <div className="pt-4 border-t border-slate-200">
            <h4 className="text-xs font-black uppercase text-slate-700 tracking-wider mb-3">
              📐 Coordinate Polygon Vertex Inspector & GPS Boundary Mapper
            </h4>
            <BoundaryMapper
              farmerId="FARMER-ZM-10928"
              plotId="PLOT-MAIN-CROP-CYCLE"
              plotName="Registered Crop Plot Boundary"
              cropType="Maize SC 719"
              onSave={(pts, area) => {
                alert(`Saved ${area} Ha plot polygon boundary to Credit Profile & Crop Cycle!`);
              }}
            />
          </div>
        </div>
      ) : null}

      {selectedHarvestCrop && (
        <LogHarvestAction
          cropCycle={selectedHarvestCrop}
          isOpen={!!selectedHarvestCrop}
          onClose={() => setSelectedHarvestCrop(null)}
          tenantId={tenantId}
          onHarvestLogged={(event) => {
            if (selectedHarvestCrop) {
              onUpdateStatus(selectedHarvestCrop.id, "Harvested");
              setSelectedHarvestCrop(null);
            }
          }}
        />
      )}
    </div>
  );
}

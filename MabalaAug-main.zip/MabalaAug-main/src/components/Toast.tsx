import React, { createContext, useContext, useState, useCallback, ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import { CheckCircle, AlertTriangle, AlertCircle, Info, X } from "lucide-react";
import { dispatchSafeEvent } from "../utils/safeEvent";
import { safeFormatError } from "../utils/errorUtils";

type ToastType = "success" | "error" | "info" | "warning";

interface Toast {
  id: number;
  message: string;
  type: ToastType;
}

interface ToastContextType {
  showToast: (message: string, type?: ToastType, duration?: number) => void;
}

const ToastContext = createContext<ToastContextType | null>(null);

function formatMessageToString(message: any): string {
  return safeFormatError(message, "");
}


export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = useCallback((message: any, type: ToastType = "info", duration = 4000) => {
    let finalMessage = formatMessageToString(message);

    if (type === "success" && !navigator.onLine) {
      if (!finalMessage.includes("pending sync") && !finalMessage.includes("locally")) {
        finalMessage = `${finalMessage} (Saved locally, pending sync)`;
      }
    }
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message: finalMessage, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, duration);
  }, []);

  React.useEffect(() => {
    const handleGlobalToast = (e: Event) => {
      const customEvent = e as CustomEvent<{ message: any; type?: ToastType; duration?: number }>;
      if (customEvent.detail) {
        showToast(
          customEvent.detail.message,
          customEvent.detail.type || "info",
          customEvent.detail.duration || 4000
        );
      }
    };
    window.addEventListener("mabala-toast" as any, handleGlobalToast);

    // Save references to original methods
    const originalAlert = window.alert;
    const originalConfirm = window.confirm;

    // Intercept window.alert
    window.alert = (message: any) => {
      const strMessage = formatMessageToString(message);

      let type: ToastType = "info";
      const lower = strMessage.toLowerCase();
      if (lower.includes("success") || lower.includes("congratulations") || lower.includes("successfully") || lower.includes("thank you")) {
        type = "success";
      } else if (lower.includes("error") || lower.includes("failed") || lower.includes("invalid") || lower.includes("violation") || lower.includes("cannot")) {
        type = "error";
      } else if (lower.includes("warning") || lower.includes("alert") || lower.includes("attention") || lower.includes("please check") || lower.includes("required")) {
        type = "warning";
      }
      
      dispatchSafeEvent("mabala-toast", { message: strMessage, type, duration: 5000 });
      console.log(`[Mabala Alert Intercepted]: ${strMessage}`);
    };

    // Intercept window.confirm
    window.confirm = (message?: any) => {
      const strMessage = typeof message === "string" 
        ? message 
        : typeof message === "object" && message !== null 
          ? (message.message || JSON.stringify(message)) 
          : (message ? String(message) : "Are you sure?");
      dispatchSafeEvent("mabala-toast", { message: `Action Approved: ${strMessage}`, type: "success", duration: 3500 });
      console.log(`[Mabala Confirm Intercepted - Auto-approved]: ${strMessage}`);
      return true;
    };

    return () => {
      window.removeEventListener("mabala-toast" as any, handleGlobalToast);
      window.alert = originalAlert;
      window.confirm = originalConfirm;
    };
  }, [showToast]);

  const removeToast = (id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const getIcon = (type: ToastType) => {
    switch (type) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />;
      case "error":
        return <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />;
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />;
      case "info":
      default:
        return <Info className="w-5 h-5 text-blue-500 shrink-0" />;
    }
  };

  const getBgColor = (type: ToastType) => {
    switch (type) {
      case "success":
        return "bg-slate-900/95 border-emerald-500/30 text-slate-100 shadow-emerald-950/20";
      case "error":
        return "bg-slate-900/95 border-rose-500/30 text-slate-100 shadow-rose-950/20";
      case "warning":
        return "bg-slate-900/95 border-amber-500/30 text-slate-100 shadow-amber-950/20";
      case "info":
      default:
        return "bg-slate-900/95 border-blue-500/30 text-slate-100 shadow-blue-950/20";
    }
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed top-6 right-6 z-[99999] flex flex-col gap-3 max-w-md w-full pointer-events-none px-4 sm:px-0">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95, y: -10 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className={`pointer-events-auto flex items-start gap-3 p-4 rounded-2xl border backdrop-blur-md shadow-lg ${getBgColor(
                t.type
              )}`}
            >
              {getIcon(t.type)}
              <div className="flex-1 text-sm font-medium leading-relaxed break-words">
                {t.message}
              </div>
              <button
                onClick={() => removeToast(t.id)}
                className="text-slate-400 hover:text-slate-200 transition-colors shrink-0 p-0.5 rounded-lg hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used within ToastProvider");
  return ctx.showToast;
}

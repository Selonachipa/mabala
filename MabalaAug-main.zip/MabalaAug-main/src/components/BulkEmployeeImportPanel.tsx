import React, { useState, useRef } from "react";
import { 
  UploadCloud, 
  FileSpreadsheet, 
  Copy, 
  Check, 
  AlertCircle, 
  Trash2, 
  CheckCircle2, 
  Download, 
  Users, 
  Filter, 
  FileText, 
  Building2, 
  CreditCard, 
  Phone, 
  Mail, 
  ShieldCheck,
  UserCheck,
  UserX
} from "lucide-react";
import { Employee, EmploymentStatus } from "../types";
import { safeFormatError } from "../utils/errorUtils";

interface BulkEmployeeImportPanelProps {
  existingEmployees: Employee[];
  onBulkAddEmployees: (newEmployees: Employee[]) => void;
  currencySymbol: string;
  isReadonly: boolean;
  isZambia: boolean;
  onSuccessNavigate?: () => void;
}

interface ParsedEmployeeRow {
  rowIndex: number;
  data: {
    fullName: string;
    nrcNumber: string;
    role: string;
    department: string;
    employmentType: string;
    startDate: string;
    basicSalary: string;
    mobileNumber: string;
    email: string;
    paymentMethod: string;
    bankOrNetworkName: string;
    accountOrWalletNumber: string;
    bankBranch: string;
  };
  errors: string[];
  isValid: boolean;
  isSelected: boolean;
}

const TEMPLATE_HEADERS = "Full Name,National ID/NRC,Role/Position,Department,Employment Type,Start Date,Basic Salary,Mobile Number,Email,Payment Method,Bank/Network Name,Account/Wallet Number,Bank Branch";

const SAMPLE_CSV_CONTENT = `${TEMPLATE_HEADERS}
Kondwani Mwape,284719/11/1,Farm Manager,Administration,Permanent,2026-01-15,8500,0977123456,kondwani@farm.zm,Bank Transfer,Zambia National Commercial Bank (Zanaco) PLC,10098712349,Cairo Road Main
Mary Banda,192837/66/1,Field Supervisor,Crops,Permanent,2024-03-01,5500,0966881122,mary.banda@farm.zm,MTN MoMo,MTN,0977881122,
Chileshe Phiri,401928/10/1,General Field Hand,Operations,Casual Worker,2025-05-10,3200,0955443322,,Airtel Money,Airtel,0966443322,
Mutale Bwalya,302918/44/1,Tractor Operator,Machinery,Probation,2026-06-01,4800,0971992233,mutale@farm.zm,Cash,,,`;

export default function BulkEmployeeImportPanel({
  existingEmployees,
  onBulkAddEmployees,
  currencySymbol,
  isReadonly,
  isZambia,
  onSuccessNavigate
}: BulkEmployeeImportPanelProps) {
  const [dragActive, setDragActive] = useState(false);
  const [copied, setCopied] = useState(false);
  const [pasteText, setPasteText] = useState("");
  const [parsedRows, setParsedRows] = useState<ParsedEmployeeRow[]>([]);
  const [filterMode, setFilterMode] = useState<"all" | "valid" | "errors">("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [commitSuccessMessage, setCommitSuccessMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Helper: Download Template CSV
  const handleDownloadTemplate = () => {
    const blob = new Blob([SAMPLE_CSV_CONTENT], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `mabala_employee_bulk_register_template.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Helper: Copy Template CSV
  const handleCopyTemplate = () => {
    navigator.clipboard.writeText(SAMPLE_CSV_CONTENT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Drag & drop handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      readAndParseFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      readAndParseFile(e.target.files[0]);
    }
  };

  const readAndParseFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      parseRawCsvText(text);
    };
    reader.readAsText(file);
  };

  // Parse CSV text safely handling quotes & commas
  const parseCsvLine = (line: string): string[] => {
    const cells: string[] = [];
    let currentCell = "";
    let insideQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        insideQuotes = !insideQuotes;
      } else if (char === ',' && !insideQuotes) {
        cells.push(currentCell.trim());
        currentCell = "";
      } else {
        currentCell += char;
      }
    }
    cells.push(currentCell.trim());
    return cells;
  };

  // NRC Format Validator: Zambian standard 6 digits / 2 digits / 1 digit
  const isValidNRC = (nrc: string): boolean => {
    if (!nrc) return false;
    const cleaned = nrc.trim();
    // Match 123456/11/1 or 123456/10/1 or digits-slashes-dashes
    const nrcRegex = /^\d{6}[\/\s-]\d{2}[\/\s-]\d{1}$/;
    return nrcRegex.test(cleaned);
  };

  const parseRawCsvText = (text: string) => {
    setCommitSuccessMessage(null);
    if (!text || !text.trim()) {
      setParsedRows([]);
      return;
    }

    const lines = text.split(/\r?\n/).filter(line => line.trim() !== "");
    if (lines.length === 0) return;

    // First line headers
    const rawHeaders = parseCsvLine(lines[0]).map(h => h.replace(/^["']|["']$/g, '').trim().toLowerCase());
    const dataLines = lines.slice(1);

    // Header index mapping helper
    const getColIndex = (possibleNames: string[]): number => {
      return rawHeaders.findIndex(h => possibleNames.some(p => h.includes(p.toLowerCase())));
    };

    const idxFullName = getColIndex(["full name", "fullname", "name", "employee name"]);
    const idxNRC = getColIndex(["national id", "nrc", "nrc number", "id number", "national id/nrc"]);
    const idxRole = getColIndex(["role", "position", "title", "designation", "role/position"]);
    const idxDepartment = getColIndex(["department", "dept", "unit", "section"]);
    const idxEmploymentType = getColIndex(["employment type", "status", "contract type", "employment"]);
    const idxStartDate = getColIndex(["start date", "date", "contract start", "hired date"]);
    const idxBasicSalary = getColIndex(["basic salary", "salary", "basic", "rate", "contract rate"]);
    const idxMobileNumber = getColIndex(["mobile number", "mobile", "phone", "contact", "phone number"]);
    const idxEmail = getColIndex(["email", "e-mail", "email address"]);
    const idxPaymentMethod = getColIndex(["payment method", "payout method", "payment mode", "payout"]);
    const idxBankOrNetwork = getColIndex(["bank/network name", "bank name", "network", "bank or network", "provider"]);
    const idxAccountOrWallet = getColIndex(["account/wallet number", "account number", "wallet number", "account", "wallet"]);
    const idxBankBranch = getColIndex(["bank branch", "branch", "branch name"]);

    // Track seen values for within-file duplicate detection
    const seenNrcsInFile = new Set<string>();
    const seenNamesInFile = new Set<string>();

    const processedRows: ParsedEmployeeRow[] = dataLines.map((line, idx) => {
      const cols = parseCsvLine(line).map(c => c.replace(/^["']|["']$/g, '').trim());

      const fullName = idxFullName !== -1 ? cols[idxFullName] || "" : cols[0] || "";
      const nrcNumber = idxNRC !== -1 ? cols[idxNRC] || "" : cols[1] || "";
      const role = idxRole !== -1 ? cols[idxRole] || "" : cols[2] || "Field Staff";
      const department = idxDepartment !== -1 ? cols[idxDepartment] || "" : cols[3] || "General Operations";
      const employmentType = idxEmploymentType !== -1 ? cols[idxEmploymentType] || "" : cols[4] || "Permanent";
      const startDate = idxStartDate !== -1 ? cols[idxStartDate] || "" : cols[5] || new Date().toISOString().split("T")[0];
      const basicSalary = idxBasicSalary !== -1 ? cols[idxBasicSalary] || "" : cols[6] || "0";
      const mobileNumber = idxMobileNumber !== -1 ? cols[idxMobileNumber] || "" : cols[7] || "";
      const email = idxEmail !== -1 ? cols[idxEmail] || "" : cols[8] || "";
      const paymentMethod = idxPaymentMethod !== -1 ? cols[idxPaymentMethod] || "" : cols[9] || "Bank Transfer";
      const bankOrNetworkName = idxBankOrNetwork !== -1 ? cols[idxBankOrNetwork] || "" : cols[10] || "";
      const accountOrWalletNumber = idxAccountOrWallet !== -1 ? cols[idxAccountOrWallet] || "" : cols[11] || "";
      const bankBranch = idxBankBranch !== -1 ? cols[idxBankBranch] || "" : cols[12] || "";

      const errors: string[] = [];

      // 1. Required field validations
      if (!fullName) {
        errors.push("Missing required field: Full Name");
      }
      if (!nrcNumber) {
        errors.push("Missing required field: National ID/NRC Number");
      }
      if (!basicSalary || isNaN(Number(basicSalary)) || Number(basicSalary) <= 0) {
        errors.push("Invalid or missing Basic Salary (must be a positive number)");
      }
      if (!mobileNumber) {
        errors.push("Missing required field: Mobile Phone Number");
      }

      // 2. NRC Format validation
      if (nrcNumber && !isValidNRC(nrcNumber)) {
        errors.push(`Invalid NRC format "${nrcNumber}". Expected standard format: XXXXXX/XX/X (e.g. 284719/11/1)`);
      }

      // 3. Duplicate detection within uploaded file
      const cleanNrc = nrcNumber.trim().toLowerCase();
      const cleanName = fullName.trim().toLowerCase();

      if (cleanNrc) {
        if (seenNrcsInFile.has(cleanNrc)) {
          errors.push(`Duplicate NRC "${nrcNumber}" found within the uploaded CSV file`);
        } else {
          seenNrcsInFile.add(cleanNrc);
        }
      }

      if (cleanName) {
        if (seenNamesInFile.has(cleanName)) {
          errors.push(`Duplicate employee name "${fullName}" found within the uploaded CSV file`);
        } else {
          seenNamesInFile.add(cleanName);
        }
      }

      // 4. Duplicate detection against existing system records
      if (cleanNrc) {
        const existingNrcMatch = existingEmployees.find(e => (e.nrcNumber || "").trim().toLowerCase() === cleanNrc);
        if (existingNrcMatch) {
          errors.push(`NRC "${nrcNumber}" is already registered in HR system to employee "${existingNrcMatch.name}" (${existingNrcMatch.id})`);
        }
      }

      if (cleanName) {
        const existingNameMatch = existingEmployees.find(e => (e.name || "").trim().toLowerCase() === cleanName);
        if (existingNameMatch) {
          errors.push(`Employee name "${fullName}" already exists in active HR database (${existingNameMatch.id})`);
        }
      }

      const isValid = errors.length === 0;

      return {
        rowIndex: idx + 1,
        data: {
          fullName,
          nrcNumber,
          role,
          department,
          employmentType,
          startDate,
          basicSalary,
          mobileNumber,
          email,
          paymentMethod,
          bankOrNetworkName,
          accountOrWalletNumber,
          bankBranch
        },
        errors,
        isValid,
        isSelected: isValid
      };
    });

    setParsedRows(processedRows);
  };

  const handleToggleSelectRow = (rowIndex: number) => {
    setParsedRows(prev => prev.map(r => r.rowIndex === rowIndex ? { ...r, isSelected: !r.isSelected } : r));
  };

  const handleToggleSelectAllValid = (select: boolean) => {
    setParsedRows(prev => prev.map(r => r.isValid ? { ...r, isSelected: select } : r));
  };

  // Pre-commit Summary Metrics
  const totalRowsCount = parsedRows.length;
  const validRowsCount = parsedRows.filter(r => r.isValid).length;
  const errorRowsCount = parsedRows.filter(r => !r.isValid).length;
  const selectedToCommitCount = parsedRows.filter(r => r.isValid && r.isSelected).length;

  // Filtered rows for table view
  const displayRows = parsedRows.filter(row => {
    if (filterMode === "valid" && !row.isValid) return false;
    if (filterMode === "errors" && row.isValid) return false;

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      const matchName = row.data.fullName.toLowerCase().includes(term);
      const matchNrc = row.data.nrcNumber.toLowerCase().includes(term);
      const matchRole = row.data.role.toLowerCase().includes(term);
      const matchMobile = row.data.mobileNumber.toLowerCase().includes(term);
      return matchName || matchNrc || matchRole || matchMobile;
    }
    return true;
  });

  // Commit selected valid rows atomically
  const handleConfirmCommit = async () => {
    const validSelectedRows = parsedRows.filter(r => r.isValid && r.isSelected);
    if (validSelectedRows.length === 0) return;

    setIsSubmitting(true);

    try {
      const startIdNum = existingEmployees.length + 101;
      const nowTimestamp = Date.now().toString().slice(-4);

      const newEmployeeRecords: Employee[] = validSelectedRows.map((row, idx) => {
        const empNum = startIdNum + idx;
        const basicVal = Number(row.data.basicSalary) || 0;
        
        let pMethod: Employee["paymentMethod"] = "Bank Transfer";
        const rawMethod = (row.data.paymentMethod || "").toLowerCase();
        if (rawMethod.includes("momo") || rawMethod.includes("mtn")) {
          pMethod = "MTN MoMo";
        } else if (rawMethod.includes("airtel")) {
          pMethod = "Airtel Money";
        } else if (rawMethod.includes("zamtel")) {
          pMethod = "Zamtel Money";
        } else if (rawMethod.includes("cash")) {
          pMethod = "Cash";
        }

        let empStatus: EmploymentStatus = "Permanent";
        const rawStatus = (row.data.employmentType || "").toLowerCase();
        if (rawStatus.includes("casual")) {
          empStatus = "Casual Worker";
        } else if (rawStatus.includes("probation")) {
          empStatus = "Probation";
        } else if (rawStatus.includes("part")) {
          empStatus = "Part Time";
        }

        let momoProvider: "airtel" | "mtn" | "zamtel" = "mtn";
        const phoneToCheck = row.data.accountOrWalletNumber || row.data.mobileNumber || "";
        if (phoneToCheck.startsWith("097") || phoneToCheck.startsWith("077") || rawMethod.includes("airtel")) {
          momoProvider = "airtel";
        } else if (phoneToCheck.startsWith("095") || phoneToCheck.startsWith("075") || rawMethod.includes("zamtel")) {
          momoProvider = "zamtel";
        }

        return {
          id: `EMP-${empNum}-${nowTimestamp}`,
          name: row.data.fullName,
          role: row.data.role || "Field Staff",
          department: row.data.department || "General Operations",
          employmentStatus: empStatus,
          contractType: row.data.employmentType || "Indefinite Contract",
          contractStartDate: row.data.startDate || new Date().toISOString().split("T")[0],
          contractRate: basicVal,
          housingAllowance: 0,
          transportAllowance: 0,
          medicalAllowance: 0,
          fieldAllowance: 0,
          otherAllowance: 0,
          grossSalary: basicVal,
          nrcNumber: row.data.nrcNumber,
          mobileNumber: row.data.mobileNumber,
          email: row.data.email || undefined,
          paymentChannel: "mobile_money",
          mobileMoneyProvider: momoProvider,
          mobileMoneyNumber: row.data.accountOrWalletNumber || row.data.mobileNumber,
          mobileMoneyVerified: true,
          mobileMoneyVerifiedAt: new Date().toISOString(),
          verifiedBy: "Bulk CSV Import",
          verifiedAccountName: row.data.fullName,
          paymentMethod: momoProvider === "airtel" ? "Airtel Money" : (momoProvider === "zamtel" ? "Zamtel Money" : "MTN MoMo"),
          bankName: undefined,
          bankAccount: undefined,
          bankBranch: undefined,
          walletNumber: row.data.accountOrWalletNumber || row.data.mobileNumber,
          country: isZambia ? "ZM" : "Generic",
          status: "Active"
        };
      });

      // Call parent atomic handler
      await onBulkAddEmployees(newEmployeeRecords);

      setCommitSuccessMessage(`Successfully registered ${newEmployeeRecords.length} employee contracts and generated matching payroll profile records in atomic batch!`);
      setParsedRows([]);
      setPasteText("");

      if (onSuccessNavigate) {
        setTimeout(() => {
          onSuccessNavigate();
        }, 1800);
      }
    } catch (err: any) {
      console.error("[Bulk Import] Error committing employee batch:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="text-base font-extrabold text-slate-800 uppercase tracking-wide">
                Bulk Employee Registration & Payroll Setup
              </h3>
            </div>
            <p className="text-xs text-slate-500 font-medium max-w-2xl">
              Upload structured staff registers via CSV/Excel to onboard multiple employees simultaneously. Validates Zambian NRC format, prevents duplicates, and creates payroll profiles in a single atomic batch write.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadTemplate}
              className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-sm transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Download CSV Template</span>
            </button>
            <button
              type="button"
              onClick={handleCopyTemplate}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-slate-200 transition-all cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-500" />}
              <span>{copied ? "Copied!" : "Copy Header Template"}</span>
            </button>
          </div>
        </div>

        {/* Success Banner */}
        {commitSuccessMessage && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 p-4 rounded-xl flex items-center gap-3 animate-fade-in shadow-xs">
            <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
            <div>
              <h4 className="text-xs font-extrabold uppercase tracking-wide">Atomic Import Complete</h4>
              <p className="text-xs font-semibold mt-0.5">{commitSuccessMessage}</p>
            </div>
          </div>
        )}

        {/* Step 1: File Drag and Drop or Paste Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* File Upload Zone */}
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center space-y-3 ${
              dragActive ? "border-emerald-500 bg-emerald-50/50" : "border-slate-300 bg-slate-50 hover:bg-slate-100/80 hover:border-slate-400"
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".csv"
              className="hidden"
            />
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <UploadCloud className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">
                Click to browse or drag & drop CSV File
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5 font-medium">
                Supports standard comma-delimited `.csv` files formatted with required columns
              </p>
            </div>
            <span className="px-3 py-1 bg-white border border-slate-200 text-slate-700 font-bold text-[10px] rounded-lg shadow-2xs uppercase">
              Select .CSV File
            </span>
          </div>

          {/* Direct CSV Text Paste Area */}
          <div className="space-y-2 flex flex-col justify-between">
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500 tracking-wider flex items-center gap-1.5 mb-1">
                <FileText className="w-3.5 h-3.5 text-emerald-600" />
                <span>Or Paste Raw CSV Lines Directly</span>
              </label>
              <textarea
                value={pasteText}
                onChange={(e) => {
                  setPasteText(e.target.value);
                  parseRawCsvText(e.target.value);
                }}
                placeholder={SAMPLE_CSV_CONTENT}
                rows={5}
                className="w-full text-[11px] font-mono border bg-slate-50 rounded-xl p-3 focus:bg-white outline-emerald-500 text-slate-800 placeholder:text-slate-400 resize-none"
              />
            </div>
            <div className="flex justify-between items-center text-[10px] text-slate-500 font-medium">
              <span>Columns: Full Name, National ID/NRC, Role, Department, Type, Start Date, Basic, Mobile, Email, Payout</span>
              {pasteText && (
                <button
                  type="button"
                  onClick={() => {
                    setPasteText("");
                    setParsedRows([]);
                  }}
                  className="text-rose-600 hover:text-rose-700 font-bold cursor-pointer"
                >
                  Clear Paste
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Step 2: Pre-commit Summary & Interactive Validation Table */}
      {parsedRows.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-6 animate-fade-in">
          {/* Summary Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl border bg-slate-50 border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-extrabold uppercase text-slate-500 tracking-wider block">Total Parsed Rows</span>
                <span className="text-xl font-black text-slate-800 font-mono mt-0.5 block">{totalRowsCount}</span>
              </div>
              <FileSpreadsheet className="w-7 h-7 text-slate-400" />
            </div>

            <div className="p-4 rounded-xl border bg-emerald-50/80 border-emerald-200 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-extrabold uppercase text-emerald-800 tracking-wider block">Valid Rows Ready to Register</span>
                <span className="text-xl font-black text-emerald-700 font-mono mt-0.5 block">{validRowsCount}</span>
              </div>
              <UserCheck className="w-7 h-7 text-emerald-600" />
            </div>

            <div className={`p-4 rounded-xl border flex items-center justify-between ${
              errorRowsCount > 0 ? "bg-rose-50/80 border-rose-200" : "bg-slate-50 border-slate-200"
            }`}>
              <div>
                <span className={`text-[10px] font-extrabold uppercase tracking-wider block ${
                  errorRowsCount > 0 ? "text-rose-800" : "text-slate-500"
                }`}>Rows With Errors</span>
                <span className={`text-xl font-black font-mono mt-0.5 block ${
                  errorRowsCount > 0 ? "text-rose-700" : "text-slate-700"
                }`}>{errorRowsCount}</span>
              </div>
              {errorRowsCount > 0 ? <UserX className="w-7 h-7 text-rose-600" /> : <ShieldCheck className="w-7 h-7 text-slate-400" />}
            </div>
          </div>

          {/* Table Controls & Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t">
            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs font-bold">
              <button
                type="button"
                onClick={() => setFilterMode("all")}
                className={`px-3 py-1 rounded-lg transition-all ${filterMode === "all" ? "bg-white text-slate-900 shadow-2xs font-extrabold" : "text-slate-600 hover:text-slate-800"}`}
              >
                All Rows ({totalRowsCount})
              </button>
              <button
                type="button"
                onClick={() => setFilterMode("valid")}
                className={`px-3 py-1 rounded-lg transition-all ${filterMode === "valid" ? "bg-emerald-600 text-white shadow-2xs font-extrabold" : "text-slate-600 hover:text-slate-800"}`}
              >
                Valid Only ({validRowsCount})
              </button>
              <button
                type="button"
                onClick={() => setFilterMode("errors")}
                className={`px-3 py-1 rounded-lg transition-all ${filterMode === "errors" ? "bg-rose-600 text-white shadow-2xs font-extrabold" : "text-slate-600 hover:text-slate-800"}`}
              >
                Errors Only ({errorRowsCount})
              </button>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="text"
                placeholder="Search name, NRC, or role..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="text-xs border bg-slate-50 rounded-xl px-3 py-1.5 focus:bg-white outline-emerald-500 font-medium w-48"
              />

              {validRowsCount > 0 && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleToggleSelectAllValid(true)}
                    className="text-[11px] text-emerald-700 hover:text-emerald-800 font-bold underline cursor-pointer"
                  >
                    Select All Valid
                  </button>
                  <span className="text-slate-300">|</span>
                  <button
                    type="button"
                    onClick={() => handleToggleSelectAllValid(false)}
                    className="text-[11px] text-slate-500 hover:text-slate-700 font-bold underline cursor-pointer"
                  >
                    Deselect All
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Validation Review Table */}
          <div className="overflow-x-auto border rounded-xl">
            <table className="w-full text-left text-xs bg-white text-slate-800">
              <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b">
                <tr>
                  <th className="p-3 w-10 text-center">
                    <input
                      type="checkbox"
                      checked={validRowsCount > 0 && selectedToCommitCount === validRowsCount}
                      onChange={(e) => handleToggleSelectAllValid(e.target.checked)}
                      disabled={validRowsCount === 0}
                      className="rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                    />
                  </th>
                  <th className="p-3 w-12">Row</th>
                  <th className="p-3 w-20">Status</th>
                  <th className="p-3">Full Name</th>
                  <th className="p-3">National ID / NRC</th>
                  <th className="p-3">Role & Dept</th>
                  <th className="p-3">Type & Start</th>
                  <th className="p-3 font-mono">Basic Salary ({currencySymbol})</th>
                  <th className="p-3">Payout Details</th>
                  <th className="p-3">Validation Result</th>
                </tr>
              </thead>
              <tbody className="divide-y font-semibold text-slate-800">
                {displayRows.map((row) => (
                  <tr key={row.rowIndex} className={!row.isValid ? "bg-rose-50/40" : row.isSelected ? "bg-emerald-50/20" : "hover:bg-slate-50"}>
                    <td className="p-3 text-center">
                      <input
                        type="checkbox"
                        checked={row.isSelected}
                        onChange={() => handleToggleSelectRow(row.rowIndex)}
                        disabled={!row.isValid}
                        className="rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer disabled:opacity-30"
                      />
                    </td>
                    <td className="p-3 font-mono text-slate-500 text-[11px]">{row.rowIndex}</td>
                    <td className="p-3">
                      {row.isValid ? (
                        <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[9.5px] font-black rounded-full uppercase flex items-center gap-1 w-fit">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>Valid</span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-rose-100 text-rose-800 text-[9.5px] font-black rounded-full uppercase flex items-center gap-1 w-fit">
                          <AlertCircle className="w-3 h-3 text-rose-600" />
                          <span>Error</span>
                        </span>
                      )}
                    </td>
                    <td className="p-3 font-bold text-slate-900">{row.data.fullName || <span className="text-rose-500 italic">Empty</span>}</td>
                    <td className="p-3 font-mono text-slate-700">{row.data.nrcNumber || <span className="text-rose-500 italic">Empty</span>}</td>
                    <td className="p-3">
                      <span className="block font-bold text-slate-800">{row.data.role}</span>
                      <span className="block text-[10px] text-slate-500 font-medium">{row.data.department}</span>
                    </td>
                    <td className="p-3 text-[11px]">
                      <span className="block font-semibold text-slate-800">{row.data.employmentType}</span>
                      <span className="block text-[10px] text-slate-400 font-mono">{row.data.startDate}</span>
                    </td>
                    <td className="p-3 font-mono font-bold text-slate-900">
                      {row.data.basicSalary ? `${currencySymbol} ${Number(row.data.basicSalary || 0).toLocaleString()}` : <span className="text-rose-500 italic">Invalid</span>}
                    </td>
                    <td className="p-3 text-[10.5px]">
                      <span className="block font-bold text-emerald-700">{row.data.paymentMethod}</span>
                      {row.data.bankOrNetworkName && (
                        <span className="block text-[9.5px] text-slate-500 font-medium">
                          {row.data.bankOrNetworkName} {row.data.accountOrWalletNumber ? `(${row.data.accountOrWalletNumber})` : ""}
                        </span>
                      )}
                    </td>
                    <td className="p-3 max-w-xs">
                      {row.isValid ? (
                        <span className="text-[10.5px] text-emerald-700 font-bold">Ready to commit into payroll ledger</span>
                      ) : (
                        <div className="space-y-1">
                          {row.errors.map((err, errIdx) => (
                            <span key={errIdx} className="block text-[10.5px] font-bold text-rose-600 bg-rose-100/60 p-1 rounded">
                              • {safeFormatError(err)}
                            </span>
                          ))}
                        </div>
                      )}
                    </td>
                  </tr>
                ))}

                {displayRows.length === 0 && (
                  <tr>
                    <td colSpan={10} className="p-8 text-center text-slate-400 italic">
                      No rows match the selected filter or search query.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pre-commit Confirmation Footer Action */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t">
            <div>
              <span className="text-xs font-bold text-slate-700">
                Selected for atomic commit: <strong className="text-emerald-700 font-mono text-sm">{selectedToCommitCount} Employee Records</strong>
              </span>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Creates employee contract & payroll profile atomically in one write batch per node.
              </p>
            </div>

            <button
              type="button"
              onClick={handleConfirmCommit}
              disabled={selectedToCommitCount === 0 || isReadonly || isSubmitting}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-extrabold text-xs shadow-md transition-all cursor-pointer disabled:opacity-40 flex items-center gap-2"
            >
              {isSubmitting ? (
                <span>Committing Batch...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 text-white" />
                  <span>Confirm & Bulk Register ({selectedToCommitCount}) Employees</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

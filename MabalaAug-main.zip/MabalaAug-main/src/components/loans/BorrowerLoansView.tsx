import React, { useState, useMemo } from "react";
import {
  Loan,
  LoanProduct,
  LoanApplication,
  RepaymentScheduleItem,
  InputBasketItem,
  ProductType
} from "../../modules/loans/types";
import {
  submitLoanApplication,
  repayLoan,
  exportLoanStatementPdf
} from "../../services/loanService";
import {
  CreditCard,
  PlusCircle,
  Calendar,
  AlertCircle,
  CheckCircle2,
  FileText,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  ChevronRight,
  X,
  Smartphone,
  Wallet,
  Sparkles,
  Info,
  Layers,
  Sprout,
  Store,
  Truck,
  ArrowRight,
  Check,
  HelpCircle,
  Search,
  Filter,
  Eye,
  Percent,
  TrendingUp,
  Building2,
  ChevronDown
} from "lucide-react";

interface BorrowerLoansViewProps {
  loans: Loan[];
  products: LoanProduct[];
  applications: LoanApplication[];
  tenantId: string;
  userName: string;
  userPhone: string;
  cropCycles?: Array<{ id: string; cropName: string; stage: string; expectedHarvestDate?: string; plantedAreaHectares?: number }>;
  onRefresh: () => void;
}

export const BorrowerLoansView: React.FC<BorrowerLoansViewProps> = ({
  loans,
  products,
  applications,
  tenantId,
  userName,
  userPhone,
  cropCycles = [],
  onRefresh
}) => {
  // Navigation & Modals state
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [showProcessGuide, setShowProcessGuide] = useState(true);
  const [selectedLoanForRepay, setSelectedLoanForRepay] = useState<Loan | null>(null);
  const [selectedLoanForSchedule, setSelectedLoanForSchedule] = useState<Loan | null>(null);
  const [selectedAppForDetail, setSelectedAppForDetail] = useState<LoanApplication | null>(null);

  // Filter state for Available Products Catalog (Step 1)
  const [productTypeFilter, setProductTypeFilter] = useState<"all" | "input_credit" | "facility">("all");
  const [issuerFilter, setIssuerFilter] = useState<"all" | "agro_dealer" | "supplier">("all");
  const [searchFilter, setSearchFilter] = useState("");

  // Application Wizard (Steps 1 to 5)
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3 | 4 | 5>(1);
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || "");
  const [applyAmount, setApplyAmount] = useState<number>(products[0]?.defaultPrincipal || 5000);
  const [applyTenor, setApplyTenor] = useState<number>(products[0]?.defaultTenorValue || 6);
  const [applyPurpose, setApplyPurpose] = useState("");
  const [selectedCropCycleId, setSelectedCropCycleId] = useState("");
  const [collateralDesc, setCollateralDesc] = useState("");
  const [disbMethod, setDisbMethod] = useState<"input_voucher" | "mobile_money" | "mabala_wallet" | "bank_transfer">("input_voucher");
  const [disbPhone, setDisbPhone] = useState(userPhone || "");
  const [mobileNetwork, setMobileNetwork] = useState<"airtel" | "mtn" | "zamtel">("airtel");
  const [applySubmitting, setApplySubmitting] = useState(false);
  const [applyError, setApplyError] = useState("");
  const [applySuccessApp, setApplySuccessApp] = useState<LoanApplication | null>(null);

  // Input basket for Input Credit
  const [inputBasket, setInputBasket] = useState<InputBasketItem[]>([
    { itemName: "D-Compound Basal Fertilizer (50kg)", category: "Fertilizer", quantity: 2, unit: "bags", unitPrice: 850, total: 1700 },
    { itemName: "Urea Top Dressing Fertilizer (50kg)", category: "Fertilizer", quantity: 2, unit: "bags", unitPrice: 900, total: 1800 },
    { itemName: "Certified Hybrid Maize Seed (10kg)", category: "Seed", quantity: 1, unit: "bag", unitPrice: 650, total: 650 }
  ]);

  // Repayment Modal state
  const [repayAmount, setRepayAmount] = useState<number>(0);
  const [repaySource, setRepaySource] = useState<"lipila_mobile_money" | "mabala_ledger">("lipila_mobile_money");
  const [repayPhone, setRepayPhone] = useState(userPhone || "");
  const [repaySubmitting, setRepaySubmitting] = useState(false);
  const [repaySuccessMsg, setRepaySuccessMsg] = useState("");
  const [repayError, setRepayError] = useState("");

  // Derived metrics
  const activeLoans = loans.filter((l) => l.status === "active" || l.status === "in_arrears");
  const totalPrincipalDisbursed = loans.reduce((sum, l) => sum + (l.principalDisbursed || 0), 0);
  const totalRepaid = loans.reduce((sum, l) => sum + (l.totalRepaid || 0), 0);
  const totalOutstanding = activeLoans.reduce((sum, l) => sum + (l.totalOutstandingBalance || 0), 0);

  const nearestLoan = [...activeLoans]
    .filter((l) => !!l.nextRepaymentDueDate)
    .sort((a, b) => new Date(a.nextRepaymentDueDate).getTime() - new Date(b.nextRepaymentDueDate).getTime())[0];

  // Currently selected product in wizard
  const selectedProduct = products.find((p) => p.id === selectedProductId) || products[0];

  // Helper: detect if a product is Input Credit or Facility
  const isInputCredit = (product?: LoanProduct) => {
    if (!product) return false;
    return product.productType === "input_credit" || product.financingModel === "agricultural_crop";
  };

  // Filtered available products list (Production Data Filtering Rules)
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // 1. Strict Status Filter: Must be active
      if (p.status !== "active") return false;

      // 2. Production Filtering: Exclude all test data, dummy placeholders, or fake entries
      const nameLower = (p.name || "").toLowerCase();
      const issuerLower = (p.issuerName || "").toLowerCase();
      const codeLower = (p.code || "").toLowerCase();
      const isTestData =
        nameLower.includes("test") ||
        nameLower.includes("dummy") ||
        nameLower.includes("fake") ||
        nameLower.includes("mock") ||
        nameLower.includes("sample") ||
        issuerLower.includes("test") ||
        issuerLower.includes("dummy") ||
        issuerLower.includes("fake") ||
        codeLower.includes("test");
      if (isTestData) return false;

      const isInput = isInputCredit(p);
      if (productTypeFilter === "input_credit" && !isInput) return false;
      if (productTypeFilter === "facility" && isInput) return false;

      if (issuerFilter === "agro_dealer") {
        const isDealer = p.issuerType === "agro_dealer" || p.issuerName.toLowerCase().includes("dealer") || p.issuerName.toLowerCase().includes("hub");
        if (!isDealer) return false;
      }
      if (issuerFilter === "supplier") {
        const isSupplier = p.issuerType === "supplier" || p.issuerName.toLowerCase().includes("supplier") || p.issuerName.toLowerCase().includes("seed") || p.issuerName.toLowerCase().includes("feed");
        if (!isSupplier) return false;
      }

      if (searchFilter.trim()) {
        const q = searchFilter.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          p.issuerName.toLowerCase().includes(q) ||
          p.code.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
        );
      }

      return true;
    });
  }, [products, productTypeFilter, issuerFilter, searchFilter]);

  // Dynamic Repayment Summary Calculation (Step 4 of User Journey)
  const repaymentSummary = useMemo(() => {
    if (!selectedProduct) {
      return {
        principal: 0,
        originationFee: 0,
        interestRatePct: 0,
        interestCalculationMethod: "flat",
        totalInterest: 0,
        totalRepayment: 0,
        monthlyInstallment: 0,
        isMonthly: true,
        repaymentType: "Monthly Installment",
        tenorMonths: 6,
        schedule: []
      };
    }

    const principal = Number(applyAmount) || 0;
    const tenorMonths = Number(applyTenor) || 6;
    const ratePct = selectedProduct.interestRatePct || 15;
    const originationFeePct = selectedProduct.originationFeePct || 2;
    const originationFee = Number(((principal * originationFeePct) / 100).toFixed(2));
    const isReducing = selectedProduct.interestCalculationMethod === "reducing_balance";
    const isHarvestBullet = selectedProduct.repaymentFrequency === "harvest_bullet";
    const isMonthly = !isHarvestBullet;
    const repaymentType = isHarvestBullet
      ? "Harvest Bullet Settlement (Single Post-Harvest Payment)"
      : isReducing
      ? "Monthly Amortized (Reducing Balance)"
      : "Monthly Equal Installment (Flat Rate)";

    let totalInterest = 0;
    let monthlyInstallment = 0;
    const schedule: Array<{
      period: number;
      dueDate: string;
      principalDue: number;
      interestDue: number;
      totalDue: number;
      balance: number;
    }> = [];

    const now = new Date();

    if (isReducing) {
      // Reducing Balance Amortization (Monthly)
      const monthlyRate = ratePct / 100 / 12;
      const emi =
        monthlyRate === 0
          ? principal / tenorMonths
          : (principal * monthlyRate * Math.pow(1 + monthlyRate, tenorMonths)) /
            (Math.pow(1 + monthlyRate, tenorMonths) - 1);
      monthlyInstallment = Number(emi.toFixed(2));

      let currentBal = principal;
      let sumInterest = 0;

      for (let i = 1; i <= tenorMonths; i++) {
        const intPortion = currentBal * monthlyRate;
        const princPortion = Math.min(currentBal, emi - intPortion);
        currentBal = Math.max(0, currentBal - princPortion);
        sumInterest += intPortion;

        const due = new Date(now);
        due.setMonth(due.getMonth() + i);

        schedule.push({
          period: i,
          dueDate: due.toISOString().split("T")[0],
          principalDue: Number(princPortion.toFixed(2)),
          interestDue: Number(intPortion.toFixed(2)),
          totalDue: Number((princPortion + intPortion).toFixed(2)),
          balance: Number(currentBal.toFixed(2))
        });
      }
      totalInterest = Number(sumInterest.toFixed(2));
    } else {
      // Flat Rate or Seasonal Bullet
      totalInterest = Number(((principal * (ratePct / 100) * (tenorMonths / 12)).toFixed(2)));

      if (isHarvestBullet) {
        // Bullet payment at harvest end
        monthlyInstallment = 0;
        const harvestDue = new Date(now);
        harvestDue.setMonth(harvestDue.getMonth() + tenorMonths);

        schedule.push({
          period: 1,
          dueDate: harvestDue.toISOString().split("T")[0],
          principalDue: principal,
          interestDue: totalInterest,
          totalDue: principal + totalInterest,
          balance: 0
        });
      } else {
        // Flat monthly installment
        const total = principal + totalInterest;
        monthlyInstallment = Number((total / tenorMonths).toFixed(2));
        const princPerMonth = principal / tenorMonths;
        const intPerMonth = totalInterest / tenorMonths;
        let bal = total;

        for (let i = 1; i <= tenorMonths; i++) {
          bal -= monthlyInstallment;
          const due = new Date(now);
          due.setMonth(due.getMonth() + i);

          schedule.push({
            period: i,
            dueDate: due.toISOString().split("T")[0],
            principalDue: Number(princPerMonth.toFixed(2)),
            interestDue: Number(intPerMonth.toFixed(2)),
            totalDue: monthlyInstallment,
            balance: Math.max(0, Number(bal.toFixed(2)))
          });
        }
      }
    }

    const totalRepayment = Number((principal + totalInterest + originationFee).toFixed(2));

    return {
      principal,
      originationFee,
      interestRatePct: ratePct,
      interestCalculationMethod: selectedProduct.interestCalculationMethod,
      totalInterest,
      totalRepayment,
      monthlyInstallment,
      isMonthly,
      repaymentType,
      tenorMonths,
      schedule
    };
  }, [selectedProduct, applyAmount, applyTenor]);

  // Open apply modal pre-selecting a product
  const handleOpenApplyWithProduct = (product: LoanProduct) => {
    setSelectedProductId(product.id);
    setApplyAmount(product.defaultPrincipal);
    setApplyTenor(product.defaultTenorValue);
    setDisbMethod(isInputCredit(product) ? "input_voucher" : "mobile_money");
    setWizardStep(1);
    setShowApplyModal(true);
    setApplyError("");
    setApplySuccessApp(null);
  };

  // Submit Loan Application (Step 6 of User Journey)
  const handleApplySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;
    setApplySubmitting(true);
    setApplyError("");

    try {
      const selectedCrop = cropCycles.find((c) => c.id === selectedCropCycleId);
      const isInput = isInputCredit(selectedProduct);

      const submitted = await submitLoanApplication({
        tenantId,
        lenderTenantId: selectedProduct.tenantId || "TENANT-DEALER-01",
        lenderName: selectedProduct.issuerName,
        borrowerName: userName || "Farmer",
        borrowerPhone: disbPhone || userPhone,
        productId: selectedProduct.id,
        productName: selectedProduct.name,
        financingModel: selectedProduct.financingModel,
        productType: isInput ? "input_credit" : "facility",
        issuerType: selectedProduct.issuerType || (isInput ? "agro_dealer" : "supplier"),
        requestedAmount: applyAmount,
        requestedTenorValue: applyTenor,
        requestedTenorUnit: selectedProduct.tenorUnit,
        purpose: applyPurpose || (isInput ? `Seasonal crop inputs package for ${selectedProduct.name}` : `Agri-enterprise facility for ${selectedProduct.name}`),
        cropCycleId: selectedCropCycleId || undefined,
        cropCycleName: selectedCrop?.cropName || undefined,
        cropExpectedHarvestDate: selectedCrop?.expectedHarvestDate || undefined,
        inputBasket: isInput ? inputBasket : [],
        collateralDescription: collateralDesc || undefined,
        disbursementMethod: disbMethod,
        disbursementAccount: disbPhone || userPhone,
        disbursementNetwork: mobileNetwork,
        repaymentSummary: {
          principal: repaymentSummary.principal,
          interestRatePct: repaymentSummary.interestRatePct,
          interestCalculationMethod: repaymentSummary.interestCalculationMethod,
          totalInterest: repaymentSummary.totalInterest,
          originationFee: repaymentSummary.originationFee,
          totalRepayment: repaymentSummary.totalRepayment,
          monthlyInstallment: repaymentSummary.monthlyInstallment,
          frequency: selectedProduct.repaymentFrequency
        }
      });

      setApplySuccessApp(submitted);
      setWizardStep(5); // Go to real-time tracking confirmation step
      onRefresh();
    } catch (err: any) {
      setApplyError(err.message || "Failed to submit loan application");
    } finally {
      setApplySubmitting(false);
    }
  };

  // Handle Repayment Submit
  const handleRepaySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLoanForRepay || repayAmount <= 0) return;
    setRepaySubmitting(true);
    setRepayError("");
    setRepaySuccessMsg("");

    try {
      const result = await repayLoan(selectedLoanForRepay.id, {
        amount: repayAmount,
        source: repaySource,
        notes: `Farmer repayment via ${repaySource} (Phone: ${repayPhone})`,
        performedBy: userName || "Farmer User"
      });

      setRepaySuccessMsg(
        `Repayment of ZMW ${repayAmount.toFixed(2)} posted successfully! Allocated to Principal: ZMW ${result.allocation?.principalPortion || 0}, Interest: ZMW ${result.allocation?.interestPortion || 0}. New Balance: ZMW ${result.loan?.totalOutstandingBalance || 0}`
      );
      setTimeout(() => {
        setSelectedLoanForRepay(null);
        setRepaySuccessMsg("");
        onRefresh();
      }, 2200);
    } catch (err: any) {
      setRepayError(err.message || "Repayment processing failed");
    } finally {
      setRepaySubmitting(false);
    }
  };

  return (
    <div className="space-y-6" id="borrower-loans-view">
      {/* ========================================================================= */}
      {/* 1. ARCHITECTURE & CLARIFICATION GUIDE: FACILITIES VS INPUT CREDIT (AGC)  */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden" id="section-architecture-clarification">
        <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-teal-900 text-white p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                  Standardized Lending Architecture
                </span>
                <span className="text-xs text-slate-300">
                  Facilities & Mabala Input Credit (AGC)
                </span>
              </div>
              <h2 className="text-xl font-bold mt-1 text-white">
                Farmer Financing Hub: Two Parallel Agricultural Credit Paths
              </h2>
              <p className="text-xs text-slate-300 max-w-3xl mt-1">
                Whether applying for <strong>Mabala Input Credit (In-Kind Vouchers)</strong> or <strong>Financing Facilities (Traditional Loans)</strong>, the application, data capture, and approval workflow follow the exact same 6-step standardized journey. All products are posted directly by registered Agro Dealers and Suppliers with instant farmer portal visibility.
              </p>
            </div>
            <button
              onClick={() => setShowProcessGuide(!showProcessGuide)}
              className="self-start md:self-center flex items-center gap-1.5 text-xs font-semibold bg-white/10 hover:bg-white/20 text-white px-3.5 py-2 rounded-xl backdrop-blur-xs transition border border-white/10"
              id="btn-toggle-process-guide"
            >
              <Info className="w-4 h-4 text-emerald-300" />
              {showProcessGuide ? "Hide Process Guide" : "Compare Facilities vs. Input Credit"}
              <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showProcessGuide ? "rotate-180" : ""}`} />
            </button>
          </div>
        </div>

        {showProcessGuide && (
          <div className="p-6 bg-slate-50/50 border-t border-slate-200 space-y-6">
            {/* Side-by-Side Comparison: Input Credit vs Traditional Facilities */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Product Type 1: Mabala Input Credit (AGC) */}
              <div className="bg-emerald-50/60 border border-emerald-200 rounded-xl p-5 space-y-3" id="card-guide-input-credit">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold">
                      <Sprout className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-emerald-950">Mabala Input Credit (AGC)</h4>
                      <span className="text-[11px] text-emerald-700 font-medium">In-Kind Agricultural Vouchers</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full border border-emerald-200">
                    Non-Cash
                  </span>
                </div>

                <div className="text-xs text-slate-700 leading-relaxed">
                  <strong>What Input Credit Entails:</strong> Physical agricultural goods (certified hybrid seeds, basal D-Compound, top-dressing Urea, crop protection chemicals, and poultry feed) provided directly to smallholders. No raw cash is disbursed; instead, digital redemption vouchers or pickup QR codes are issued.
                </div>

                <div className="space-y-2 pt-2 border-t border-emerald-200/60 text-xs">
                  <div className="flex items-start gap-2">
                    <span className="font-bold text-emerald-900 w-28 shrink-0">Underwriting:</span>
                    <span className="text-slate-600">Agronomic profile, crop cycle stage, hectares planted, remote sensing (NDVI satellite checks), and accredited offtaker linkages.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="font-bold text-emerald-900 w-28 shrink-0">Disbursement:</span>
                    <span className="text-slate-600">Digital Input Voucher / SMS OTP redeemable at local accredited Agro Dealers or delivered via Supplier consignment.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="font-bold text-emerald-900 w-28 shrink-0">Repayment Terms:</span>
                    <span className="text-slate-600">Post-harvest bullet settlement aligned with crop marketing, or automatic tripartite deduction upon delivery to warehouse/offtaker.</span>
                  </div>
                </div>
              </div>

              {/* Product Type 2: Traditional Facilities */}
              <div className="bg-sky-50/60 border border-sky-200 rounded-xl p-5 space-y-3" id="card-guide-facilities">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-sky-600 text-white flex items-center justify-center font-bold">
                      <CreditCard className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-sky-950">Financing Facilities</h4>
                      <span className="text-[11px] text-sky-700 font-medium">Traditional Cash & Equipment Lending</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold uppercase bg-sky-100 text-sky-800 px-2 py-0.5 rounded-full border border-sky-200">
                    Liquid / Asset
                  </span>
                </div>

                <div className="text-xs text-slate-700 leading-relaxed">
                  <strong>What Facilities Entail:</strong> Direct working capital or equipment financing (solar pumps, drip irrigation kits, farm tillers, labor, storage). Funds are disbursed into liquid wallets or equipment supplier accounts for productive capital investment.
                </div>

                <div className="space-y-2 pt-2 border-t border-sky-200/60 text-xs">
                  <div className="flex items-start gap-2">
                    <span className="font-bold text-sky-900 w-28 shrink-0">Underwriting:</span>
                    <span className="text-slate-600">Farm cash flow, historical sales ledger turnover, credit score, debt-to-income ratio, and optional physical/asset collateral.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="font-bold text-sky-900 w-28 shrink-0">Disbursement:</span>
                    <span className="text-slate-600">Lipila Mobile Money (Airtel, MTN, Zamtel), Mabala Digital Ledger, or direct Commercial Bank Account transfer.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="font-bold text-sky-900 w-28 shrink-0">Repayment Terms:</span>
                    <span className="text-slate-600">Structured monthly amortized installments (reducing balance or flat interest) with optional 1-3 month grace periods.</span>
                  </div>
                </div>
              </div>
            </div>

            {/* The 6-Step Standardized Farmer Journey Flowchart */}
            <div className="bg-white p-4 rounded-xl border border-slate-200">
              <div className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                The Standardized 6-Step Farmer Loan Application Journey
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                  <span className="font-mono text-[10px] text-emerald-700 font-bold block mb-1">STEP 1</span>
                  <div className="font-bold text-slate-800">View Available Options</div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Agro dealer & supplier products appear instantly upon posting.
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                  <span className="font-mono text-[10px] text-emerald-700 font-bold block mb-1">STEP 2</span>
                  <div className="font-bold text-slate-800">Select & Review Details</div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Inspect issuer credentials, rates, limits, and grace periods.
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                  <span className="font-mono text-[10px] text-emerald-700 font-bold block mb-1">STEP 3</span>
                  <div className="font-bold text-slate-800">Data Capture & Crop Link</div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Enter amount, tenor, crop cycle link, and input basket items.
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                  <span className="font-mono text-[10px] text-emerald-700 font-bold block mb-1">STEP 4</span>
                  <div className="font-bold text-slate-800">Repayment Summary</div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    See live computed total obligation and monthly schedule breakdown.
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                  <span className="font-mono text-[10px] text-emerald-700 font-bold block mb-1">STEP 5</span>
                  <div className="font-bold text-slate-800">Disbursement Choice</div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Select Agro Dealer Voucher QR or Lipila Mobile Money / Bank.
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                  <span className="font-mono text-[10px] text-emerald-700 font-bold block mb-1">STEP 6</span>
                  <div className="font-bold text-slate-800">Submit & Live Track</div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Monitor real-time progress as agro dealer/supplier reviews it.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* KPI Overview Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs" id="card-total-outstanding">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Outstanding</span>
            <Wallet className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">
            ZMW {totalOutstanding.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            {activeLoans.length} active credit {activeLoans.length === 1 ? "facility" : "facilities"}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs" id="card-next-payment">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Next Payment Due</span>
            <Calendar className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {nearestLoan ? `ZMW ${nearestLoan.nextRepaymentDueAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : "ZMW 0.00"}
          </div>
          <div className="text-xs text-amber-600 mt-1 font-medium">
            {nearestLoan ? `Due: ${nearestLoan.nextRepaymentDueDate}` : "No upcoming due dates"}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs" id="card-total-repaid">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Lifetime Repaid</span>
            <CheckCircle2 className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-bold text-emerald-700">
            ZMW {totalRepaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Across {loans.length} lifetime facilities
          </div>
        </div>

        <div className="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-xl p-5 text-white shadow-xs flex flex-col justify-between" id="card-apply-action">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-100">Agricultural Credit</span>
            <div className="text-lg font-bold mt-1">Need Seeds, Fertilizer or Cash?</div>
            <p className="text-xs text-emerald-100 mt-0.5">
              Browse options posted by local Agro Dealers & Suppliers.
            </p>
          </div>
          <button
            onClick={() => {
              setWizardStep(1);
              setShowApplyModal(true);
            }}
            id="btn-open-apply-modal"
            className="mt-3 flex items-center justify-center gap-2 bg-white text-emerald-800 font-semibold px-4 py-2 rounded-lg text-sm hover:bg-emerald-50 transition shadow-xs"
          >
            <PlusCircle className="w-4 h-4" />
            Apply for Credit
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. STEP 1 OF USER JOURNEY: BROWSE AVAILABLE FACILITIES & INPUT CREDIT     */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden" id="section-available-options">
        <div className="p-6 border-b border-slate-100">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                  STEP 1
                </span>
                <h3 className="text-base font-bold text-slate-900">
                  Available Facilities & Input Credit Options
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Created and posted directly by authorized Agro Dealers and Suppliers — immediately visible with zero delay
              </p>
            </div>

            {/* Filter Pills */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold">
                <button
                  onClick={() => setProductTypeFilter("all")}
                  className={`px-3 py-1.5 rounded-lg transition ${
                    productTypeFilter === "all" ? "bg-white text-slate-900 shadow-xs" : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  All ({products.length})
                </button>
                <button
                  onClick={() => setProductTypeFilter("input_credit")}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-lg transition ${
                    productTypeFilter === "input_credit" ? "bg-white text-emerald-700 shadow-xs" : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <Sprout className="w-3.5 h-3.5" />
                  Input Credit
                </button>
                <button
                  onClick={() => setProductTypeFilter("facility")}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-lg transition ${
                    productTypeFilter === "facility" ? "bg-white text-sky-700 shadow-xs" : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  Facilities
                </button>
              </div>

              {/* Issuer filter */}
              <select
                value={issuerFilter}
                onChange={(e: any) => setIssuerFilter(e.target.value)}
                className="bg-slate-100 border border-slate-200 text-xs font-semibold rounded-xl px-3 py-2 text-slate-700"
              >
                <option value="all">All Issuers</option>
                <option value="agro_dealer">Agro Dealers Only</option>
                <option value="supplier">Suppliers Only</option>
              </select>
            </div>
          </div>
        </div>

        {/* Product Cards Grid */}
        {filteredProducts.length === 0 ? (
          <div className="p-12 text-center" id="empty-state-no-suppliers">
            <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center mx-auto mb-3 text-emerald-600 border border-emerald-100 shadow-2xs">
              <Store className="w-7 h-7" />
            </div>
            <h4 className="text-base font-bold text-slate-800">
              No Onboarded Suppliers or Agro-Dealers Available Yet
            </h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1.5 leading-relaxed">
              Input credit packages and financing facilities will appear here immediately once accredited agro-dealers or certified input suppliers publish them. All posted options become immediately visible with zero delay.
            </p>
          </div>
        ) : (
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredProducts.map((p) => {
              const isInput = isInputCredit(p);
              const isAgroDealer = p.issuerType === "agro_dealer" || p.issuerName.toLowerCase().includes("dealer") || p.issuerName.toLowerCase().includes("hub");

              return (
                <div
                  key={p.id}
                  className={`rounded-xl border p-5 transition-all flex flex-col justify-between hover:shadow-md ${
                    isInput ? "border-emerald-200 bg-emerald-50/20 hover:border-emerald-400" : "border-slate-200 bg-white hover:border-sky-300"
                  }`}
                  id={`card-product-${p.id}`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full flex items-center gap-1 ${
                          isInput
                            ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                            : "bg-sky-100 text-sky-800 border border-sky-200"
                        }`}
                      >
                        {isInput ? <Sprout className="w-3 h-3" /> : <CreditCard className="w-3 h-3" />}
                        {isInput ? "Input Credit (Voucher)" : "Financing Facility"}
                      </span>

                      <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                        {p.code}
                      </span>
                    </div>

                    <h4 className="font-bold text-slate-900 text-sm leading-snug">{p.name}</h4>

                    {/* Issuer Poster Tag */}
                    <div className="flex items-center gap-1.5 text-xs text-slate-600 mt-1.5">
                      {isAgroDealer ? (
                        <Store className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      ) : (
                        <Truck className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                      )}
                      <span className="truncate">
                        Posted by: <strong className="text-slate-800">{p.issuerName}</strong>
                      </span>
                    </div>

                    <p className="text-xs text-slate-500 mt-2 line-clamp-2">{p.description}</p>

                    {/* Key Loan Terms */}
                    <div className="mt-4 pt-3 border-t border-slate-200/70 grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-[11px] text-slate-400 block">Interest Rate</span>
                        <span className="font-bold text-slate-900">
                          {p.interestRatePct}% <span className="font-normal text-slate-500">({p.interestCalculationMethod})</span>
                        </span>
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400 block">Repayment</span>
                        <span className="font-bold text-slate-900 capitalize">
                          {p.repaymentFrequency === "harvest_bullet" ? "Harvest Bullet" : "Monthly Installment"}
                        </span>
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400 block">Credit Limit</span>
                        <span className="font-semibold text-slate-800">
                          ZMW {p.minPrincipal.toLocaleString()} - {p.maxPrincipal.toLocaleString()}
                        </span>
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400 block">Tenor</span>
                        <span className="font-semibold text-slate-800">
                          {p.defaultTenorValue} {p.tenorUnit}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      Instant Access
                    </span>
                    <button
                      onClick={() => handleOpenApplyWithProduct(p)}
                      id={`btn-apply-prod-${p.id}`}
                      className={`flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-lg transition shadow-xs ${
                        isInput
                          ? "bg-emerald-600 text-white hover:bg-emerald-700"
                          : "bg-slate-900 text-white hover:bg-slate-800"
                      }`}
                    >
                      Apply Now
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 3. ACTIVE LOANS SECTION                                                  */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden" id="section-active-facilities">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">My Active Financing Facilities</h3>
            <p className="text-xs text-slate-500">Active and completed agricultural input credit & enterprise loans</p>
          </div>
          <button
            onClick={() => {
              setWizardStep(1);
              setShowApplyModal(true);
            }}
            id="btn-apply-table-header"
            className="flex items-center gap-1.5 text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 px-3.5 py-2 rounded-lg hover:bg-emerald-100 transition"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            New Application
          </button>
        </div>

        {loans.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3 text-slate-400">
              <CreditCard className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">No active facilities found</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-4">
              You currently do not have any active credit facilities. Choose from the available options above to apply.
            </p>
            <button
              onClick={() => {
                setWizardStep(1);
                setShowApplyModal(true);
              }}
              className="inline-flex items-center gap-2 bg-emerald-600 text-white text-xs font-semibold px-4 py-2 rounded-lg hover:bg-emerald-700 transition"
            >
              <PlusCircle className="w-4 h-4" />
              Apply for Credit
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {loans.map((loan) => {
              const isCrop = loan.financingModel === "agricultural_crop";
              const progressPct =
                loan.totalLoanAmount > 0
                  ? Math.min(100, Math.round((loan.totalRepaid / loan.totalLoanAmount) * 100))
                  : 0;

              return (
                <div key={loan.id} className="p-6 hover:bg-slate-50/50 transition" id={`loan-item-${loan.id}`}>
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-base">{loan.productName}</span>
                        <span className="text-xs font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-200">
                          {loan.loanNumber}
                        </span>
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                            loan.status === "active"
                              ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                              : loan.status === "in_arrears"
                              ? "bg-rose-50 text-rose-700 border border-rose-200"
                              : loan.status === "paid_off"
                              ? "bg-blue-50 text-blue-700 border border-blue-200"
                              : "bg-slate-100 text-slate-600 border border-slate-200"
                          }`}
                        >
                          {loan.status === "active" ? "Active (Good Standing)" : loan.status.toUpperCase()}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-slate-500">
                        <span>Issuer: <strong className="text-slate-700">{loan.lenderName}</strong></span>
                        <span>•</span>
                        <span>Disbursed: {loan.disbursementDate}</span>
                        <span>•</span>
                        <span>Maturity: {loan.maturityDate}</span>
                        {loan.cropCycleName && (
                          <>
                            <span>•</span>
                            <span className="text-emerald-700 font-medium">Cycle: {loan.cropCycleName}</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {loan.status !== "paid_off" && (
                        <button
                          onClick={() => {
                            setSelectedLoanForRepay(loan);
                            setRepayAmount(loan.nextRepaymentDueAmount || Math.min(1000, loan.totalOutstandingBalance));
                          }}
                          id={`btn-repay-${loan.id}`}
                          className="flex items-center gap-1.5 bg-emerald-600 text-white font-semibold text-xs px-3.5 py-2 rounded-lg hover:bg-emerald-700 transition shadow-xs"
                        >
                          <Smartphone className="w-3.5 h-3.5" />
                          Pay with Mobile Money
                        </button>
                      )}
                      <button
                        onClick={() => setSelectedLoanForSchedule(loan)}
                        id={`btn-schedule-${loan.id}`}
                        className="flex items-center gap-1 bg-white border border-slate-200 text-slate-700 font-semibold text-xs px-3 py-2 rounded-lg hover:bg-slate-50 transition"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        Schedule
                      </button>
                      <button
                        onClick={() => exportLoanStatementPdf(loan)}
                        id={`btn-statement-${loan.id}`}
                        className="flex items-center gap-1 bg-white border border-slate-200 text-slate-700 font-semibold text-xs px-3 py-2 rounded-lg hover:bg-slate-50 transition"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        Statement
                      </button>
                    </div>
                  </div>

                  <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-lg border border-slate-100">
                    <div>
                      <div className="text-[11px] font-medium text-slate-500 uppercase">Principal Disbursed</div>
                      <div className="text-sm font-bold text-slate-900 mt-0.5">
                        ZMW {loan.principalDisbursed.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] font-medium text-slate-500 uppercase">Total Repaid</div>
                      <div className="text-sm font-bold text-emerald-700 mt-0.5">
                        ZMW {loan.totalRepaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] font-medium text-slate-500 uppercase">Outstanding Balance</div>
                      <div className="text-sm font-bold text-slate-900 mt-0.5">
                        ZMW {loan.totalOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] font-medium text-slate-500 uppercase">Next Payment Due</div>
                      <div className="text-sm font-bold text-amber-700 mt-0.5">
                        {loan.nextRepaymentDueAmount > 0 ? `ZMW ${loan.nextRepaymentDueAmount.toFixed(2)}` : "Fully Settled"}
                      </div>
                    </div>
                  </div>

                  <div className="mt-3">
                    <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                      <span>Repayment Progress</span>
                      <span className="font-semibold text-slate-700">{progressPct}% Repaid</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-500 ${
                          progressPct >= 100 ? "bg-blue-600" : "bg-emerald-600"
                        }`}
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 4. STEP 6 OF USER JOURNEY: REAL-TIME APPLICATION APPROVAL TRACKING        */}
      {/* ========================================================================= */}
      {applications.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6" id="section-applications-tracking">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                  STEP 6
                </span>
                <h3 className="text-base font-bold text-slate-900">
                  Real-Time Application Approval Tracking
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Monitor live review, underwriting, and disbursement as agro dealers and suppliers process your requests
              </p>
            </div>
            <span className="text-xs bg-slate-100 font-semibold text-slate-700 px-3 py-1 rounded-full">
              {applications.length} {applications.length === 1 ? "application" : "applications"}
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {applications.map((app) => {
              const isApproved = app.status === "approved" || app.status === "disbursed";
              const isDisbursed = app.status === "disbursed";
              const isRejected = app.status === "rejected";

              return (
                <div key={app.id} className="py-5 space-y-3" id={`app-tracking-item-${app.id}`}>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <span className="font-bold text-slate-900 text-sm">{app.productName}</span>
                      <span className="text-xs font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-200">
                        {app.applicationNumber}
                      </span>
                      <span
                        className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                          app.status === "submitted"
                            ? "bg-amber-50 text-amber-700 border border-amber-200"
                            : app.status === "approved"
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                            : app.status === "disbursed"
                            ? "bg-blue-50 text-blue-700 border border-blue-200"
                            : "bg-rose-50 text-rose-700 border border-rose-200"
                        }`}
                      >
                        {app.status === "submitted"
                          ? "In Review"
                          : app.status.toUpperCase()}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-xs text-slate-500">
                        Requested: <strong className="text-slate-900">ZMW {app.requestedAmount.toLocaleString()}</strong> ({app.requestedTenorValue} {app.requestedTenorUnit})
                      </span>
                      <button
                        onClick={() => setSelectedAppForDetail(app)}
                        className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        View Details
                      </button>
                    </div>
                  </div>

                  {/* Real-time 4-Phase Stepper Tracker */}
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                    <div className="grid grid-cols-4 gap-2 text-center text-xs">
                      {/* Phase 1: Submitted */}
                      <div className="flex flex-col items-center">
                        <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center mb-1">
                          <Check className="w-3.5 h-3.5" />
                        </div>
                        <span className="font-semibold text-slate-800 text-[11px]">Submitted</span>
                        <span className="text-[10px] text-slate-400">{app.createdAt.substring(0, 10)}</span>
                      </div>

                      {/* Phase 2: Underwriting */}
                      <div className="flex flex-col items-center">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center mb-1 ${
                          isRejected
                            ? "bg-rose-500 text-white"
                            : isApproved
                            ? "bg-emerald-600 text-white"
                            : "bg-amber-500 text-white animate-pulse"
                        }`}>
                          {isRejected ? <X className="w-3.5 h-3.5" /> : isApproved ? <Check className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5" />}
                        </div>
                        <span className="font-semibold text-slate-800 text-[11px]">Underwriting</span>
                        <span className="text-[10px] text-slate-400">{isRejected ? "Declined" : "Agronomic check"}</span>
                      </div>

                      {/* Phase 3: Issuer Review */}
                      <div className="flex flex-col items-center">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center mb-1 ${
                          isApproved
                            ? "bg-emerald-600 text-white"
                            : "bg-slate-200 text-slate-400"
                        }`}>
                          {isApproved ? <Check className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5" />}
                        </div>
                        <span className="font-semibold text-slate-800 text-[11px]">Partner Review</span>
                        <span className="text-[10px] text-slate-400 truncate max-w-[90px]">{app.lenderName || "Agro Dealer"}</span>
                      </div>

                      {/* Phase 4: Disbursement */}
                      <div className="flex flex-col items-center">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center mb-1 ${
                          isDisbursed
                            ? "bg-blue-600 text-white"
                            : isApproved
                            ? "bg-emerald-100 text-emerald-700 border border-emerald-300"
                            : "bg-slate-200 text-slate-400"
                        }`}>
                          {isDisbursed ? <Check className="w-3.5 h-3.5" /> : <Sparkles className="w-3.5 h-3.5" />}
                        </div>
                        <span className="font-semibold text-slate-800 text-[11px]">Disbursement</span>
                        <span className="text-[10px] text-slate-400">{isDisbursed ? "Fulfillment Done" : isApproved ? "Ready for Pickup" : "Pending"}</span>
                      </div>
                    </div>

                    {isRejected && app.rejectionReason && (
                      <div className="mt-3 p-2 bg-rose-50 border border-rose-200 rounded text-rose-700 text-xs">
                        <strong>Declined:</strong> {app.rejectionReason}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. STANDARDIZED APPLICATION WIZARD MODAL (STEPS 1 TO 5)                   */}
      {/* ========================================================================= */}
      {showApplyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto" id="modal-apply-loan">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl my-8 border border-slate-100">
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200">
                    Application Wizard
                  </span>
                  <h3 className="text-base font-bold text-slate-900">Apply for Credit</h3>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Standardized workflow for Facilities & Mabala Input Credit (AGC)
                </p>
              </div>
              <button
                onClick={() => setShowApplyModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Step Progress Indicators */}
            <div className="py-4 border-b border-slate-100">
              <div className="grid grid-cols-5 gap-1 text-center">
                <button
                  type="button"
                  onClick={() => setWizardStep(1)}
                  className={`pb-2 text-xs font-semibold border-b-2 transition ${
                    wizardStep === 1
                      ? "border-emerald-600 text-emerald-700 font-bold"
                      : wizardStep > 1
                      ? "border-emerald-400 text-slate-700"
                      : "border-transparent text-slate-400"
                  }`}
                >
                  1. Product
                </button>
                <button
                  type="button"
                  onClick={() => setWizardStep(2)}
                  className={`pb-2 text-xs font-semibold border-b-2 transition ${
                    wizardStep === 2
                      ? "border-emerald-600 text-emerald-700 font-bold"
                      : wizardStep > 2
                      ? "border-emerald-400 text-slate-700"
                      : "border-transparent text-slate-400"
                  }`}
                >
                  2. Loan & Crop
                </button>
                <button
                  type="button"
                  onClick={() => setWizardStep(3)}
                  className={`pb-2 text-xs font-semibold border-b-2 transition ${
                    wizardStep === 3
                      ? "border-emerald-600 text-emerald-700 font-bold"
                      : wizardStep > 3
                      ? "border-emerald-400 text-slate-700"
                      : "border-transparent text-slate-400"
                  }`}
                >
                  3. Repayment
                </button>
                <button
                  type="button"
                  onClick={() => setWizardStep(4)}
                  className={`pb-2 text-xs font-semibold border-b-2 transition ${
                    wizardStep === 4
                      ? "border-emerald-600 text-emerald-700 font-bold"
                      : wizardStep > 4
                      ? "border-emerald-400 text-slate-700"
                      : "border-transparent text-slate-400"
                  }`}
                >
                  4. Disbursement
                </button>
                <button
                  type="button"
                  disabled={!applySuccessApp}
                  className={`pb-2 text-xs font-semibold border-b-2 transition ${
                    wizardStep === 5
                      ? "border-emerald-600 text-emerald-700 font-bold"
                      : "border-transparent text-slate-400"
                  }`}
                >
                  5. Track Status
                </button>
              </div>
            </div>

            {applyError && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{applyError}</span>
              </div>
            )}

            <form onSubmit={handleApplySubmit} className="mt-4">
              {/* ------------------------------------------------------------- */}
              {/* STEP 1: SELECT PRODUCT & REVIEW DETAILS                       */}
              {/* ------------------------------------------------------------- */}
              {wizardStep === 1 && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Choose Financing Product (Posted by Agro Dealers & Suppliers)
                    </label>
                    <select
                      value={selectedProductId}
                      onChange={(e) => {
                        setSelectedProductId(e.target.value);
                        const prod = products.find((p) => p.id === e.target.value);
                        if (prod) {
                          setApplyAmount(prod.defaultPrincipal);
                          setApplyTenor(prod.defaultTenorValue);
                          setDisbMethod(isInputCredit(prod) ? "input_voucher" : "mobile_money");
                        }
                      }}
                      disabled={products.length === 0}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden disabled:opacity-50"
                      id="select-apply-product"
                    >
                      {products.length === 0 ? (
                        <option value="">No Active Facilities or Input Credit Products Available</option>
                      ) : (
                        products.map((p) => (
                          <option key={p.id} value={p.id}>
                            {isInputCredit(p) ? "🌱 [Input Credit] " : "💼 [Facility] "}
                            {p.name} — {p.issuerName} ({p.interestRatePct}% {p.interestCalculationMethod})
                          </option>
                        ))
                      )}
                    </select>
                  </div>

                  {/* Product Details Review Card */}
                  {products.length === 0 ? (
                    <div className="p-6 rounded-xl border border-dashed border-slate-300 bg-slate-50 text-center space-y-2">
                      <Building2 className="w-8 h-8 text-slate-400 mx-auto" />
                      <p className="text-xs font-semibold text-slate-800">No Financing Products Currently Available</p>
                      <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                        Accredited agro-dealers and certified suppliers have not posted any active loan facilities or input credit packages yet. New options will appear automatically once published.
                      </p>
                    </div>
                  ) : selectedProduct && (
                    <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-sm">
                          {selectedProduct.name}
                        </span>
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                          isInputCredit(selectedProduct)
                            ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                            : "bg-sky-100 text-sky-800 border border-sky-200"
                        }`}>
                          {isInputCredit(selectedProduct) ? "Mabala Input Credit (In-Kind)" : "Cash Facility"}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600">{selectedProduct.description}</p>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-200 text-xs">
                        <div>
                          <span className="text-[10px] text-slate-400 block">Issuer</span>
                          <strong className="text-slate-800">{selectedProduct.issuerName}</strong>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block">Interest Terms</span>
                          <strong className="text-slate-800">
                            {selectedProduct.interestRatePct}% ({selectedProduct.interestCalculationMethod})
                          </strong>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block">Repayment</span>
                          <strong className="text-slate-800 capitalize">
                            {selectedProduct.repaymentFrequency === "harvest_bullet" ? "Harvest Bullet" : "Monthly Installment"}
                          </strong>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block">Grace Period</span>
                          <strong className="text-slate-800">
                            {selectedProduct.gracePeriodValue} {selectedProduct.gracePeriodUnit}
                          </strong>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="pt-3 flex justify-end">
                    <button
                      type="button"
                      disabled={products.length === 0 || !selectedProduct}
                      onClick={() => setWizardStep(2)}
                      className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs px-5 py-2.5 rounded-lg shadow-xs transition disabled:opacity-40"
                    >
                      Continue: Loan & Crop Details
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* ------------------------------------------------------------- */}
              {/* STEP 2: ENTER LOAN AMOUNT, TENOR, CROP CYCLE LINK, PURPOSE    */}
              {/* ------------------------------------------------------------- */}
              {wizardStep === 2 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Requested Amount (ZMW)
                        <span className="text-slate-400 font-normal">
                          {" "}(Min {selectedProduct?.minPrincipal.toLocaleString()} - Max {selectedProduct?.maxPrincipal.toLocaleString()})
                        </span>
                      </label>
                      <input
                        type="number"
                        min={selectedProduct?.minPrincipal || 500}
                        max={selectedProduct?.maxPrincipal || 250000}
                        value={applyAmount}
                        onChange={(e) => setApplyAmount(Number(e.target.value))}
                        required
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                        id="input-apply-amount"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Tenor ({selectedProduct?.tenorUnit || "months"})
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={36}
                        value={applyTenor}
                        onChange={(e) => setApplyTenor(Number(e.target.value))}
                        required
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                        id="input-apply-tenor"
                      />
                    </div>
                  </div>

                  {/* Crop Cycle Link (Mandatory for Input Credit, optional for facilities) */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Link to Active Crop Cycle
                      {isInputCredit(selectedProduct) ? (
                        <span className="text-emerald-700 font-bold"> (Mandatory for Input Credit & Harvest Clearing)</span>
                      ) : (
                        <span className="text-slate-400 font-normal"> (Optional for enterprise working capital)</span>
                      )}
                    </label>
                    <select
                      value={selectedCropCycleId}
                      onChange={(e) => setSelectedCropCycleId(e.target.value)}
                      required={isInputCredit(selectedProduct)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                      id="select-apply-crop-cycle"
                    >
                      <option value="">-- Select Active Crop Cycle --</option>
                      {cropCycles.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.cropName} (Stage: {c.stage}) - Expected Harvest: {c.expectedHarvestDate || "TBD"}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* If Input Credit: Itemized Input Basket */}
                  {isInputCredit(selectedProduct) && (
                    <div className="bg-emerald-50/50 p-4 rounded-xl border border-emerald-200 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-950 uppercase tracking-wider flex items-center gap-1.5">
                          <Sprout className="w-3.5 h-3.5 text-emerald-600" />
                          Itemized Input Basket (Redeemable at Agro Dealer)
                        </span>
                        <span className="text-xs font-bold text-emerald-800">
                          Basket Total: ZMW {inputBasket.reduce((sum, i) => sum + i.total, 0).toLocaleString()}
                        </span>
                      </div>
                      <div className="space-y-2">
                        {inputBasket.map((item, idx) => (
                          <div key={idx} className="flex items-center justify-between text-xs bg-white p-2.5 rounded-lg border border-emerald-100">
                            <div>
                              <span className="font-semibold text-slate-800">{item.itemName}</span>
                              <span className="text-slate-400 text-[11px] block">{item.category} • {item.quantity} {item.unit} @ ZMW {item.unitPrice}</span>
                            </div>
                            <span className="font-mono font-bold text-slate-900">ZMW {item.total}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Purpose of Financing */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Purpose of Financing
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 5 Hectares Maize production, seed and fertilizer inputs"
                      value={applyPurpose}
                      onChange={(e) => setApplyPurpose(e.target.value)}
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                      id="input-apply-purpose"
                    />
                  </div>

                  <div className="pt-3 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setWizardStep(1)}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
                    >
                      Back
                    </button>
                    <button
                      type="button"
                      onClick={() => setWizardStep(3)}
                      className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs px-5 py-2.5 rounded-lg shadow-xs transition"
                    >
                      Continue: Repayment Summary
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* ------------------------------------------------------------- */}
              {/* STEP 3: REPAYMENT SUMMARY (TOTAL + MONTHLY BREAKDOWN)         */}
              {/* ------------------------------------------------------------- */}
              {wizardStep === 3 && (
                <div className="space-y-4">
                  <div className="bg-slate-900 text-white p-5 rounded-xl shadow-xs">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 block">
                          Step 4 Requirement: Real-Time Financial Projection
                        </span>
                        <h4 className="text-base font-bold text-white">
                          Repayment Summary & Amortization Breakdown
                        </h4>
                      </div>
                      <span className="text-xs font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded">
                        {repaymentSummary.interestCalculationMethod.toUpperCase()}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-3 border-t border-slate-800 text-xs">
                      <div>
                        <span className="text-slate-400 text-[11px]">Principal Requested</span>
                        <div className="text-base font-bold text-white mt-0.5">
                          ZMW {repaymentSummary.principal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-400 text-[11px]">Interest ({repaymentSummary.interestRatePct}%)</span>
                        <div className="text-base font-bold text-emerald-400 mt-0.5">
                          ZMW {repaymentSummary.totalInterest.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-400 text-[11px]">Processing Fee</span>
                        <div className="text-base font-bold text-slate-300 mt-0.5">
                          ZMW {repaymentSummary.originationFee.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-400 text-[11px]">Total Repayable</span>
                        <div className="text-base font-bold text-emerald-300 mt-0.5">
                          ZMW {repaymentSummary.totalRepayment.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Explicit Farmer Repayment Terms: Type, Months & Monthly Repayment Amount */}
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 shadow-2xs" id="box-repayment-terms-summary">
                    <div className="text-xs font-bold uppercase tracking-wider text-emerald-900 mb-2.5 flex items-center gap-1.5">
                      <Calendar className="w-4 h-4 text-emerald-700" />
                      Repayment Terms & Schedule Projection
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div className="bg-white p-3 rounded-lg border border-emerald-200/70 shadow-2xs">
                        <span className="text-slate-500 text-[11px] block">Repayment Type</span>
                        <strong className="text-slate-900 font-bold text-sm block mt-0.5">
                          {repaymentSummary.isMonthly ? "Monthly Installments" : "Harvest Bullet"}
                        </strong>
                        <span className="text-[10px] text-emerald-700 font-medium mt-0.5 block">
                          {repaymentSummary.repaymentType}
                        </span>
                      </div>

                      <div className="bg-white p-3 rounded-lg border border-emerald-200/70 shadow-2xs">
                        <span className="text-slate-500 text-[11px] block">Number of Months</span>
                        <strong className="text-slate-900 font-bold text-sm block mt-0.5">
                          {repaymentSummary.tenorMonths} Months
                        </strong>
                        <span className="text-[10px] text-slate-500 mt-0.5 block">
                          {repaymentSummary.isMonthly
                            ? `${repaymentSummary.tenorMonths} regular monthly cycles`
                            : `Full settlement at post-harvest completion`}
                        </span>
                      </div>

                      <div className="bg-white p-3 rounded-lg border border-emerald-200/70 shadow-2xs">
                        <span className="text-slate-500 text-[11px] block">
                          {repaymentSummary.isMonthly ? "Repayment Amount Monthly" : "Total Settlement Due"}
                        </span>
                        <strong className="text-emerald-700 font-bold text-base block mt-0.5">
                          {repaymentSummary.isMonthly
                            ? `ZMW ${repaymentSummary.monthlyInstallment.toLocaleString(undefined, { minimumFractionDigits: 2 })} / mo`
                            : `ZMW ${repaymentSummary.totalRepayment.toLocaleString(undefined, { minimumFractionDigits: 2 })}`}
                        </strong>
                        <span className="text-[10px] text-slate-500 mt-0.5 block">
                          {repaymentSummary.isMonthly
                            ? "Principal & interest amortized monthly"
                            : "Due in lump-sum at harvest date"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Monthly or Harvest Bullet Schedule Table */}
                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800">
                        {selectedProduct.repaymentFrequency === "harvest_bullet"
                          ? "Harvest Bullet Settlement Schedule"
                          : `Monthly Installment Schedule (${repaymentSummary.schedule.length} Months)`}
                      </span>
                      {repaymentSummary.monthlyInstallment > 0 && (
                        <span className="text-xs font-bold text-emerald-700">
                          Monthly Installment: ZMW {repaymentSummary.monthlyInstallment.toLocaleString()}
                        </span>
                      )}
                    </div>

                    <div className="max-h-52 overflow-y-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-slate-100 text-slate-600 uppercase text-[10px] font-semibold">
                          <tr>
                            <th className="px-3 py-2">Period</th>
                            <th className="px-3 py-2">Due Date</th>
                            <th className="px-3 py-2 text-right">Principal</th>
                            <th className="px-3 py-2 text-right">Interest</th>
                            <th className="px-3 py-2 text-right">Total Due</th>
                            <th className="px-3 py-2 text-right">Balance</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {repaymentSummary.schedule.map((row) => (
                            <tr key={row.period} className="hover:bg-slate-50/60">
                              <td className="px-3 py-2 font-bold text-slate-700">#{row.period}</td>
                              <td className="px-3 py-2 text-slate-600">{row.dueDate}</td>
                              <td className="px-3 py-2 text-right font-mono">ZMW {row.principalDue.toFixed(2)}</td>
                              <td className="px-3 py-2 text-right font-mono">ZMW {row.interestDue.toFixed(2)}</td>
                              <td className="px-3 py-2 text-right font-mono font-bold text-slate-900">
                                ZMW {row.totalDue.toFixed(2)}
                              </td>
                              <td className="px-3 py-2 text-right font-mono text-slate-500">
                                ZMW {row.balance.toFixed(2)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="pt-3 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setWizardStep(2)}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
                    >
                      Back
                    </button>
                    <button
                      type="button"
                      onClick={() => setWizardStep(4)}
                      className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs px-5 py-2.5 rounded-lg shadow-xs transition"
                    >
                      Continue: Disbursement Preference
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* ------------------------------------------------------------- */}
              {/* STEP 4: SELECT DISBURSEMENT PREFERENCE                        */}
              {/* ------------------------------------------------------------- */}
              {wizardStep === 4 && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-2">
                      Select Fulfillment / Disbursement Method
                    </label>

                    {isInputCredit(selectedProduct) ? (
                      /* Input Credit Disbursement Options */
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <label
                          className={`p-3.5 rounded-xl border text-xs cursor-pointer flex items-start gap-3 transition ${
                            disbMethod === "input_voucher"
                              ? "bg-emerald-50 border-emerald-500 text-emerald-900"
                              : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
                          }`}
                        >
                          <input
                            type="radio"
                            name="disbMethod"
                            checked={disbMethod === "input_voucher"}
                            onChange={() => setDisbMethod("input_voucher")}
                            className="hidden"
                          />
                          <Store className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-bold block">Agro-Dealer Input Voucher (QR / OTP)</span>
                            <span className="text-slate-500 text-[11px] block mt-0.5">
                              Pickup seeds & fertilizers directly at the local Agro Dealer shop with a secure mobile voucher.
                            </span>
                          </div>
                        </label>

                        <label
                          className={`p-3.5 rounded-xl border text-xs cursor-pointer flex items-start gap-3 transition ${
                            disbMethod === "mobile_money"
                              ? "bg-emerald-50 border-emerald-500 text-emerald-900"
                              : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
                          }`}
                        >
                          <input
                            type="radio"
                            name="disbMethod"
                            checked={disbMethod === "mobile_money"}
                            onChange={() => setDisbMethod("mobile_money")}
                            className="hidden"
                          />
                          <Truck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-bold block">Supplier Direct Consignment</span>
                            <span className="text-slate-500 text-[11px] block mt-0.5">
                              Certified bulk input shipment delivered directly to your farm depot by supplier logistics.
                            </span>
                          </div>
                        </label>
                      </div>
                    ) : (
                      /* Facilities Disbursement Options (Liquid / Mobile Money) */
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <label
                          className={`p-3 rounded-xl border text-xs cursor-pointer flex flex-col justify-between transition ${
                            disbMethod === "mobile_money"
                              ? "bg-sky-50 border-sky-500 text-sky-900 font-semibold"
                              : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
                          }`}
                        >
                          <input
                            type="radio"
                            name="disbMethod"
                            checked={disbMethod === "mobile_money"}
                            onChange={() => setDisbMethod("mobile_money")}
                            className="hidden"
                          />
                          <Smartphone className="w-5 h-5 text-sky-600 mb-2" />
                          <div>
                            <div className="font-bold">Lipila Mobile Money</div>
                            <span className="text-[11px] text-slate-500">Airtel, MTN, Zamtel</span>
                          </div>
                        </label>

                        <label
                          className={`p-3 rounded-xl border text-xs cursor-pointer flex flex-col justify-between transition ${
                            disbMethod === "mabala_wallet"
                              ? "bg-sky-50 border-sky-500 text-sky-900 font-semibold"
                              : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
                          }`}
                        >
                          <input
                            type="radio"
                            name="disbMethod"
                            checked={disbMethod === "mabala_wallet"}
                            onChange={() => setDisbMethod("mabala_wallet")}
                            className="hidden"
                          />
                          <Wallet className="w-5 h-5 text-emerald-600 mb-2" />
                          <div>
                            <div className="font-bold">Mabala Ledger Wallet</div>
                            <span className="text-[11px] text-slate-500">Instant in-app credit</span>
                          </div>
                        </label>

                        <label
                          className={`p-3 rounded-xl border text-xs cursor-pointer flex flex-col justify-between transition ${
                            disbMethod === "bank_transfer"
                              ? "bg-sky-50 border-sky-500 text-sky-900 font-semibold"
                              : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
                          }`}
                        >
                          <input
                            type="radio"
                            name="disbMethod"
                            checked={disbMethod === "bank_transfer"}
                            onChange={() => setDisbMethod("bank_transfer")}
                            className="hidden"
                          />
                          <Building2 className="w-5 h-5 text-indigo-600 mb-2" />
                          <div>
                            <div className="font-bold">Bank Transfer</div>
                            <span className="text-[11px] text-slate-500">Direct account deposit</span>
                          </div>
                        </label>
                      </div>
                    )}
                  </div>

                  {/* Destination Details (Phone or Account) */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                    <span className="text-xs font-bold text-slate-800">
                      Disbursement Recipient Details
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">Mobile Network / Channel</label>
                        <select
                          value={mobileNetwork}
                          onChange={(e: any) => setMobileNetwork(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-2 text-xs"
                        >
                          <option value="airtel">Airtel Money Zambia</option>
                          <option value="mtn">MTN MoMo Zambia</option>
                          <option value="zamtel">Zamtel Kwacha</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">Recipient Phone / Account Number</label>
                        <input
                          type="text"
                          value={disbPhone}
                          onChange={(e) => setDisbPhone(e.target.value)}
                          required
                          className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono font-bold"
                          placeholder="097X XXX XXX"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 flex items-center justify-between border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setWizardStep(3)}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      disabled={applySubmitting}
                      id="btn-submit-application"
                      className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs px-6 py-2.5 rounded-lg shadow-sm transition disabled:opacity-50"
                    >
                      {applySubmitting ? "Submitting to Partner..." : "Submit Application"}
                    </button>
                  </div>
                </div>
              )}

              {/* ------------------------------------------------------------- */}
              {/* STEP 5: APPLICATION SUBMITTED & LIVE TRACKING CONFIRMATION    */}
              {/* ------------------------------------------------------------- */}
              {wizardStep === 5 && applySuccessApp && (
                <div className="space-y-4 text-center py-4">
                  <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h4 className="text-lg font-bold text-slate-900">
                    Application Submitted Successfully!
                  </h4>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    Your application for <strong>{applySuccessApp.productName}</strong> has been routed directly to{" "}
                    <strong>{applySuccessApp.lenderName || "the issuing partner"}</strong> for real-time review.
                  </p>

                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-left max-w-md mx-auto space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Application Number:</span>
                      <strong className="font-mono text-slate-900">{applySuccessApp.applicationNumber}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Requested Amount:</span>
                      <strong className="text-slate-900">ZMW {applySuccessApp.requestedAmount.toLocaleString()}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Review Status:</span>
                      <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-semibold text-[10px]">
                        IN REAL-TIME REVIEW
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 flex items-center justify-center gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        setShowApplyModal(false);
                        onRefresh();
                      }}
                      className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow-xs transition"
                    >
                      Done & View Real-Time Status
                    </button>
                  </div>
                </div>
              )}
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. REPAY LOAN MODAL (Mobile Money / Wallet)                             */}
      {/* ========================================================================= */}
      {selectedLoanForRepay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4" id="modal-repay-loan">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Make Facility Repayment</h3>
                <p className="text-xs text-slate-500">{selectedLoanForRepay.productName} ({selectedLoanForRepay.loanNumber})</p>
              </div>
              <button
                onClick={() => setSelectedLoanForRepay(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {repaySuccessMsg && (
              <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>{repaySuccessMsg}</span>
              </div>
            )}

            {repayError && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{repayError}</span>
              </div>
            )}

            {!repaySuccessMsg && (
              <form onSubmit={handleRepaySubmit} className="space-y-4 mt-4">
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Outstanding Principal:</span>
                    <strong className="text-slate-800">ZMW {selectedLoanForRepay.principalOutstanding.toFixed(2)}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Accrued Interest:</span>
                    <strong className="text-slate-800">ZMW {selectedLoanForRepay.interestOutstanding.toFixed(2)}</strong>
                  </div>
                  <div className="flex justify-between text-slate-900 font-bold pt-1 border-t border-slate-200">
                    <span>Total Balance Due:</span>
                    <span className="text-emerald-700">ZMW {selectedLoanForRepay.totalOutstandingBalance.toFixed(2)}</span>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-700">Repayment Amount (ZMW)</label>
                    <button
                      type="button"
                      onClick={() => setRepayAmount(selectedLoanForRepay.totalOutstandingBalance)}
                      className="text-[11px] text-emerald-700 font-semibold hover:underline"
                    >
                      Pay Full Balance
                    </button>
                  </div>
                  <input
                    type="number"
                    step="0.01"
                    min={1}
                    max={selectedLoanForRepay.totalOutstandingBalance}
                    value={repayAmount}
                    onChange={(e) => setRepayAmount(Number(e.target.value))}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-base font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    id="input-repay-amount"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Payment Method</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setRepaySource("lipila_mobile_money")}
                      className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 ${
                        repaySource === "lipila_mobile_money"
                          ? "bg-emerald-50 border-emerald-500 text-emerald-800"
                          : "bg-white border-slate-200 text-slate-600"
                      }`}
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      Mobile Money
                    </button>
                    <button
                      type="button"
                      onClick={() => setRepaySource("mabala_ledger")}
                      className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 ${
                        repaySource === "mabala_ledger"
                          ? "bg-emerald-50 border-emerald-500 text-emerald-800"
                          : "bg-white border-slate-200 text-slate-600"
                      }`}
                    >
                      <Wallet className="w-3.5 h-3.5" />
                      Mabala Wallet
                    </button>
                  </div>
                </div>

                {repaySource === "lipila_mobile_money" && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Mobile Money Number</label>
                    <input
                      type="text"
                      placeholder="097X XXX XXX"
                      value={repayPhone}
                      onChange={(e) => setRepayPhone(e.target.value)}
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono"
                    />
                    <span className="text-[11px] text-slate-400 mt-1 block">
                      A USSD prompt will be sent to this phone to authorize payment.
                    </span>
                  </div>
                )}

                <div className="pt-2 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedLoanForRepay(null)}
                    className="px-3 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={repaySubmitting}
                    id="btn-confirm-repay"
                    className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs px-4 py-2.5 rounded-lg shadow-xs transition disabled:opacity-50"
                  >
                    {repaySubmitting ? "Processing Repayment..." : `Pay ZMW ${repayAmount.toFixed(2)}`}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. REPAYMENT SCHEDULE MODAL                                             */}
      {/* ========================================================================= */}
      {selectedLoanForSchedule && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto" id="modal-loan-schedule">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl my-8 border border-slate-100">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Facility Repayment Schedule</h3>
                <p className="text-xs text-slate-500">
                  {selectedLoanForSchedule.productName} ({selectedLoanForSchedule.loanNumber})
                </p>
              </div>
              <button
                onClick={() => setSelectedLoanForSchedule(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 uppercase tracking-wider font-semibold border-b border-slate-200">
                  <tr>
                    <th className="px-3 py-2.5">#</th>
                    <th className="px-3 py-2.5">Due Date</th>
                    <th className="px-3 py-2.5 text-right">Principal</th>
                    <th className="px-3 py-2.5 text-right">Interest</th>
                    <th className="px-3 py-2.5 text-right">Total Due</th>
                    <th className="px-3 py-2.5 text-right">Paid</th>
                    <th className="px-3 py-2.5 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {(selectedLoanForSchedule.schedule || []).map((item) => (
                    <tr key={item.installmentNumber} className="hover:bg-slate-50/50">
                      <td className="px-3 py-2.5 font-bold text-slate-700">#{item.installmentNumber}</td>
                      <td className="px-3 py-2.5 text-slate-600">{item.dueDate}</td>
                      <td className="px-3 py-2.5 text-right font-mono">ZMW {item.principalDue.toFixed(2)}</td>
                      <td className="px-3 py-2.5 text-right font-mono">ZMW {item.interestDue.toFixed(2)}</td>
                      <td className="px-3 py-2.5 text-right font-mono font-bold text-slate-900">
                        ZMW {item.totalDue.toFixed(2)}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono text-emerald-700">
                        ZMW {item.totalPaid.toFixed(2)}
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            item.status === "paid"
                              ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                              : item.status === "partially_paid"
                              ? "bg-amber-50 text-amber-700 border border-amber-200"
                              : "bg-slate-100 text-slate-600 border border-slate-200"
                          }`}
                        >
                          {item.status.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-6 flex items-center justify-between pt-4 border-t border-slate-100">
              <button
                onClick={() => exportLoanStatementPdf(selectedLoanForSchedule)}
                className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 hover:text-emerald-800"
              >
                <FileText className="w-4 h-4" />
                Download Certified PDF Statement
              </button>
              <button
                onClick={() => setSelectedLoanForSchedule(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 8. APPLICATION DETAIL & REPAYMENT PREVIEW MODAL                           */}
      {/* ========================================================================= */}
      {selectedAppForDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto" id="modal-app-detail">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl my-8 border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">{selectedAppForDetail.productName}</h3>
                <p className="text-xs text-slate-500">Application Reference: {selectedAppForDetail.applicationNumber}</p>
              </div>
              <button onClick={() => setSelectedAppForDetail(null)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Issuing Partner:</span>
                  <strong className="text-slate-800">{selectedAppForDetail.lenderName || "Agro Dealer / Supplier"}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Requested Amount:</span>
                  <strong className="text-slate-900">ZMW {selectedAppForDetail.requestedAmount.toLocaleString()}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Tenor:</span>
                  <strong className="text-slate-900">{selectedAppForDetail.requestedTenorValue} {selectedAppForDetail.requestedTenorUnit}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Status:</span>
                  <span className="font-bold text-emerald-700 uppercase">{selectedAppForDetail.status}</span>
                </div>
                {selectedAppForDetail.cropCycleName && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">Crop Cycle:</span>
                    <strong className="text-emerald-700">{selectedAppForDetail.cropCycleName}</strong>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-500">Disbursement Method:</span>
                  <span className="capitalize font-semibold">{selectedAppForDetail.disbursementMethod.replace("_", " ")}</span>
                </div>
              </div>

              {selectedAppForDetail.repaymentSummary && (
                <div className="bg-emerald-50/50 p-3.5 rounded-xl border border-emerald-200 space-y-2">
                  <div className="font-bold text-emerald-950 mb-1 flex items-center justify-between">
                    <span>Repayment Terms & Obligation</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-semibold uppercase">
                      {selectedAppForDetail.repaymentSummary.isMonthly !== false ? "Monthly" : "Bullet"}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-emerald-800 text-[11px] block">Repayment Type:</span>
                      <strong className="text-slate-900">
                        {selectedAppForDetail.repaymentSummary.isMonthly !== false ? "Monthly Installments" : "Harvest Bullet"}
                      </strong>
                    </div>
                    <div>
                      <span className="text-emerald-800 text-[11px] block">Number of Months:</span>
                      <strong className="text-slate-900">
                        {selectedAppForDetail.repaymentSummary.tenorMonths || selectedAppForDetail.requestedTenorValue} Months
                      </strong>
                    </div>
                    {selectedAppForDetail.repaymentSummary.monthlyInstallment > 0 && (
                      <div className="col-span-2 bg-white p-2.5 rounded-lg border border-emerald-200/70 shadow-2xs">
                        <span className="text-emerald-800 text-[11px] block">Monthly Repayment Amount:</span>
                        <strong className="text-emerald-700 text-sm font-bold">
                          ZMW {selectedAppForDetail.repaymentSummary.monthlyInstallment.toFixed(2)} / month
                        </strong>
                      </div>
                    )}
                  </div>
                  <div className="flex justify-between text-xs pt-1.5 border-t border-emerald-200">
                    <span className="text-emerald-800">Total Interest ({selectedAppForDetail.repaymentSummary.interestRatePct}%):</span>
                    <strong>ZMW {selectedAppForDetail.repaymentSummary.totalInterest.toFixed(2)}</strong>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-emerald-800">Processing Fee:</span>
                    <strong>ZMW {selectedAppForDetail.repaymentSummary.originationFee.toFixed(2)}</strong>
                  </div>
                  <div className="flex justify-between text-slate-900 font-bold pt-1.5 border-t border-emerald-200 text-xs">
                    <span>Total Obligation:</span>
                    <span className="text-emerald-900 font-bold">ZMW {selectedAppForDetail.repaymentSummary.totalRepayment.toFixed(2)}</span>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedAppForDetail(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

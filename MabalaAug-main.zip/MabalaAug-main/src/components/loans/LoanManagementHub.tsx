import React, { useState, useEffect } from "react";
import { BorrowerLoansView } from "./BorrowerLoansView";
import { LenderDeskView } from "./LenderDeskView";
import { InstitutionalPortfolioView } from "./InstitutionalPortfolioView";
import {
  Loan,
  LoanProduct,
  LoanApplication,
  LoanTransaction
} from "../../modules/loans/types";
import {
  fetchLoans,
  fetchLoanProducts,
  fetchLoanApplications
} from "../../services/loanService";
import {
  CreditCard,
  Building,
  Landmark,
  RotateCw,
  Sparkles,
  ShieldCheck,
  Smartphone,
  Sprout
} from "lucide-react";

interface LoanManagementHubProps {
  currentTenantId?: string;
  currentUser?: {
    uid?: string;
    displayName?: string;
    email?: string;
    phoneNumber?: string;
    role?: string;
  };
  workspaceMode?: string;
  cropCycles?: Array<{ id: string; cropName: string; stage: string; expectedHarvestDate?: string }>;
}

export const LoanManagementHub: React.FC<LoanManagementHubProps> = ({
  currentTenantId = "TENANT-FARM-01",
  currentUser,
  workspaceMode,
  cropCycles = []
}) => {
  const userRole = (currentUser?.role || "").toLowerCase();
  const isPrivilegedAdmin = userRole.includes("superadmin") || userRole.includes("super_admin") || userRole.includes("admin");
  const isLenderRole = userRole.includes("lender") || userRole.includes("dealer") || workspaceMode === "supplier";
  const isInstitutionRole = userRole.includes("institution") || workspaceMode === "institutional";

  // Farmer view logic: The farmer view is active when in Farmer workspace or for any standard farmer account
  const isFarmer = workspaceMode === "Farmer" || (!isPrivilegedAdmin && !isLenderRole && !isInstitutionRole);

  const canViewLender = !isFarmer && (isPrivilegedAdmin || isLenderRole);
  const canViewInstitutional = !isFarmer && (isPrivilegedAdmin || isInstitutionRole);

  // Determine default tab from role / workspace mode
  const getDefaultTab = (): "borrower" | "lender" | "institutional" => {
    if (isFarmer) {
      return "borrower";
    }
    if (isLenderRole) {
      return "lender";
    }
    if (isInstitutionRole) {
      return "institutional";
    }
    return "borrower";
  };

  const [activePersonaTab, setActivePersonaTab] = useState<"borrower" | "lender" | "institutional">(getDefaultTab);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [products, setProducts] = useState<LoanProduct[]>([]);
  const [applications, setApplications] = useState<LoanApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Ensure farmer view is strictly constrained to borrower facilities
  useEffect(() => {
    if (isFarmer && activePersonaTab !== "borrower") {
      setActivePersonaTab("borrower");
    }
  }, [isFarmer, activePersonaTab]);

  // Load authoritative data
  const loadData = async () => {
    try {
      setRefreshing(true);
      const [prodsData, appsData, loansData] = await Promise.all([
        fetchLoanProducts(),
        fetchLoanApplications({ tenantId: currentTenantId }),
        fetchLoans({ tenantId: currentTenantId })
      ]);

      setProducts(prodsData || []);
      setApplications(appsData || []);
      setLoans(loansData || []);
    } catch (err) {
      console.warn("[LoanManagementHub] Error loading loan data:", err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentTenantId]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6" id="loan-management-hub">
      {/* Top Header & Persona Selector */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-emerald-100 text-emerald-800 rounded-lg">
              <CreditCard className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-900">
              {isFarmer ? "Facilities" : "Mabala Loan Management Engine"}
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {isFarmer
              ? "Agricultural crop input financing, active facilities, and repayment schedules"
              : "End-to-end digital lending lifecycle for Agricultural Crop Inputs & Agribusiness Enterprise Financing"}
          </p>
        </div>

        {/* Action / Persona Controls: Farmer view only gets Refresh; Non-farmers get permitted role tabs */}
        {isFarmer ? (
          <div className="flex items-center gap-2">
            <button
              onClick={loadData}
              title="Refresh Data"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition border border-slate-200 cursor-pointer"
              id="facilities-refresh-btn"
            >
              <RotateCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin text-emerald-600" : ""}`} />
              <span>Refresh</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setActivePersonaTab("borrower")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activePersonaTab === "borrower"
                  ? "bg-white text-emerald-800 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
              id="persona-tab-borrower"
            >
              <Sprout className="w-3.5 h-3.5 text-emerald-600" />
              Borrower / Farmer
            </button>

            {canViewLender && (
              <button
                onClick={() => setActivePersonaTab("lender")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                  activePersonaTab === "lender"
                    ? "bg-white text-emerald-800 shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
                id="persona-tab-lender"
              >
                <Building className="w-3.5 h-3.5 text-blue-600" />
                Lender / Agro Dealer
              </button>
            )}

            {canViewInstitutional && (
              <button
                onClick={() => setActivePersonaTab("institutional")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                  activePersonaTab === "institutional"
                    ? "bg-white text-emerald-800 shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
                id="persona-tab-institutional"
              >
                <Landmark className="w-3.5 h-3.5 text-amber-600" />
                Institution
              </button>
            )}

            <button
              onClick={loadData}
              title="Refresh Data"
              className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg transition cursor-pointer"
            >
              <RotateCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin text-emerald-600" : ""}`} />
            </button>
          </div>
        )}
      </div>

      {/* Loading Skeleton */}
      {loading ? (
        <div className="py-16 text-center text-slate-400 text-xs">
          <div className="animate-spin w-6 h-6 border-2 border-emerald-600 border-t-transparent rounded-full mx-auto mb-3" />
          Loading authoritative loan facilities & ledgers...
        </div>
      ) : (
        <>
          {/* Persona View 1: Borrower / Farmer (Always active for farmer) */}
          {activePersonaTab === "borrower" && (
            <BorrowerLoansView
              loans={loans}
              products={products}
              applications={applications}
              tenantId={currentTenantId}
              userName={currentUser?.displayName || "Farmer"}
              userPhone={currentUser?.phoneNumber || "0977123456"}
              cropCycles={cropCycles}
              onRefresh={loadData}
            />
          )}

          {/* Persona View 2: Lender / Supplier / Agro Dealer (Removed from Farmer view) */}
          {!isFarmer && canViewLender && activePersonaTab === "lender" && (
            <LenderDeskView
              loans={loans}
              applications={applications}
              products={products}
              lenderTenantId={currentTenantId}
              lenderName={currentUser?.displayName || "Agro Finance Partner"}
              onRefresh={loadData}
            />
          )}

          {/* Persona View 3: Institution Portfolio (Removed from Farmer view; labeled Institution) */}
          {!isFarmer && canViewInstitutional && activePersonaTab === "institutional" && (
            <InstitutionalPortfolioView
              loans={loans}
              products={products}
              institutionName="Institution Portfolio"
              onRefresh={loadData}
            />
          )}
        </>
      )}
    </div>
  );
};

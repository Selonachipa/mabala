import React, { useState } from "react";
import {
  Loan,
  LoanProduct,
  PortfolioMetrics,
  LoanTransaction
} from "../../modules/loans/types";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  Legend
} from "recharts";
import {
  Landmark,
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  Download,
  CheckCircle2,
  FileSpreadsheet,
  ArrowUpRight,
  PieChart as PieIcon,
  BarChart3,
  Layers,
  Search,
  ExternalLink
} from "lucide-react";

interface InstitutionalPortfolioViewProps {
  loans: Loan[];
  products: LoanProduct[];
  transactions?: LoanTransaction[];
  institutionName?: string;
  onRefresh: () => void;
}

const COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#ef4444", "#8b5cf6"];

export const InstitutionalPortfolioView: React.FC<InstitutionalPortfolioViewProps> = ({
  loans,
  products,
  transactions = [],
  institutionName = "Institution Agribusiness Financing Portfolio",
  onRefresh
}) => {
  const [filterModel, setFilterModel] = useState<string>("all");
  const [selectedAuditTx, setSelectedAuditTx] = useState<LoanTransaction | null>(null);

  // Compute Macro Metrics
  const activeLoans = loans.filter((l) => l.status === "active" || l.status === "in_arrears");
  const totalDisbursed = loans.reduce((sum, l) => sum + (l.principalDisbursed || 0), 0);
  const totalOutstanding = activeLoans.reduce((sum, l) => sum + (l.principalOutstanding || 0), 0);
  const totalPrincipalRepaid = loans.reduce((sum, l) => sum + (l.totalPrincipalRepaid || 0), 0);
  const totalInterestRepaid = loans.reduce((sum, l) => sum + (l.totalInterestRepaid || 0), 0);
  const totalRepaidLifetime = totalPrincipalRepaid + totalInterestRepaid;

  // Aging & PAR Breakdown
  const currentLoans = activeLoans.filter((l) => l.daysPastDue === 0);
  const dpd1To30 = activeLoans.filter((l) => l.daysPastDue > 0 && l.daysPastDue <= 30);
  const dpd31To60 = activeLoans.filter((l) => l.daysPastDue > 30 && l.daysPastDue <= 60);
  const dpd61To90 = activeLoans.filter((l) => l.daysPastDue > 60 && l.daysPastDue <= 90);
  const dpd90Plus = activeLoans.filter((l) => l.daysPastDue > 90);

  const par30Exposure = dpd31To60.reduce((s, l) => s + l.principalOutstanding, 0) +
    dpd61To90.reduce((s, l) => s + l.principalOutstanding, 0) +
    dpd90Plus.reduce((s, l) => s + l.principalOutstanding, 0);

  const par30Pct = totalOutstanding > 0 ? ((par30Exposure / totalOutstanding) * 100).toFixed(1) : "0.0";
  const recoveryRatePct = totalDisbursed > 0 ? ((totalPrincipalRepaid / totalDisbursed) * 100).toFixed(1) : "0.0";

  // Chart Data: Model Comparison
  const cropExposure = activeLoans
    .filter((l) => l.financingModel === "agricultural_crop")
    .reduce((s, l) => s + l.principalOutstanding, 0);

  const enterpriseExposure = activeLoans
    .filter((l) => l.financingModel === "agribusiness_enterprise")
    .reduce((s, l) => s + l.principalOutstanding, 0);

  const modelDistributionData = [
    { name: "Crop Financing", value: cropExposure, color: "#10b981" },
    { name: "Agribusiness Enterprise", value: enterpriseExposure, color: "#3b82f6" }
  ];

  // Chart Data: Aging Buckets
  const agingData = [
    { name: "Current", amount: currentLoans.reduce((s, l) => s + l.principalOutstanding, 0), count: currentLoans.length },
    { name: "1-30 DPD", amount: dpd1To30.reduce((s, l) => s + l.principalOutstanding, 0), count: dpd1To30.length },
    { name: "31-60 DPD", amount: dpd31To60.reduce((s, l) => s + l.principalOutstanding, 0), count: dpd31To60.length },
    { name: "61-90 DPD", amount: dpd61To90.reduce((s, l) => s + l.principalOutstanding, 0), count: dpd61To90.length },
    { name: "90+ DPD", amount: dpd90Plus.reduce((s, l) => s + l.principalOutstanding, 0), count: dpd90Plus.length }
  ];

  // Export full portfolio CSV
  const handleExportCsv = () => {
    const headers = [
      "LoanNumber",
      "BorrowerName",
      "BorrowerPhone",
      "FinancingModel",
      "ProductName",
      "LenderName",
      "DisbursementDate",
      "MaturityDate",
      "PrincipalDisbursed",
      "PrincipalRepaid",
      "PrincipalOutstanding",
      "TotalOutstanding",
      "DaysPastDue",
      "Status"
    ];

    const rows = loans.map((l) => [
      l.loanNumber,
      `"${l.borrowerName}"`,
      l.borrowerPhone,
      l.financingModel,
      `"${l.productName}"`,
      `"${l.lenderName}"`,
      l.disbursementDate,
      l.maturityDate,
      l.principalDisbursed,
      l.totalPrincipalRepaid,
      l.principalOutstanding,
      l.totalOutstandingBalance,
      l.daysPastDue,
      l.status
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Mabala_Portfolio_Report_${new Date().toISOString().substring(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6" id="institutional-portfolio-view">
      {/* Oversight Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 text-white p-6 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <Landmark className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold tracking-tight">{institutionName}</h2>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            Macro agricultural finance oversight, risk exposure monitoring & verified immutable audit ledger
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            id="btn-export-portfolio-csv"
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-3.5 py-2 rounded-lg transition shadow-xs"
          >
            <Download className="w-4 h-4" />
            Export Portfolio Data (CSV)
          </button>
        </div>
      </div>

      {/* KPI Top Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Capital Disbursed</div>
          <div className="text-2xl font-bold text-slate-900 mt-1">
            ZMW {totalDisbursed.toLocaleString(undefined, { minimumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-slate-400 mt-1">{loans.length} facilities funded</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Exposure (Principal)</div>
          <div className="text-2xl font-bold text-emerald-700 mt-1">
            ZMW {totalOutstanding.toLocaleString(undefined, { minimumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-emerald-600 mt-1">{activeLoans.length} active borrowers</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Cumulative Repayments</div>
          <div className="text-2xl font-bold text-blue-700 mt-1">
            ZMW {totalRepaidLifetime.toLocaleString(undefined, { minimumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-blue-600 mt-1">{recoveryRatePct}% Recovery Rate</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Portfolio At Risk (PAR 30+)</div>
          <div className={`text-2xl font-bold mt-1 ${Number(par30Pct) > 5 ? "text-rose-600" : "text-emerald-700"}`}>
            {par30Pct}%
          </div>
          <div className="text-xs text-slate-400 mt-1">ZMW {par30Exposure.toLocaleString()} at risk</div>
        </div>
      </div>

      {/* Visual Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Model Exposure Distribution */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Capital Exposure by Financing Model</h3>
              <p className="text-xs text-slate-500">Crop Production vs Agribusiness Enterprise</p>
            </div>
            <PieIcon className="w-4 h-4 text-slate-400" />
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={modelDistributionData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {modelDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: any) => `ZMW ${Number(value).toLocaleString()}`} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Portfolio Aging & DPD Analysis */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Portfolio Aging & Delinquency (DPD)</h3>
              <p className="text-xs text-slate-500">Delinquency distribution across aging buckets</p>
            </div>
            <BarChart3 className="w-4 h-4 text-slate-400" />
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={agingData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `K${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: any) => `ZMW ${Number(v).toLocaleString()}`} />
                <Bar dataKey="amount" fill="#10b981" radius={[4, 4, 0, 0]}>
                  {agingData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={index === 0 ? "#10b981" : index === 1 ? "#f59e0b" : "#ef4444"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Cryptographically Chained Audit & Event Log */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden" id="section-immutable-audit-trail">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Immutable Financial Audit Trail</h3>
              <p className="text-xs text-slate-500">
                Cryptographically hashed event sequence (SHA-256) enforcing financial tamper evidence
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full font-semibold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Ledger Hash Verified Intact
          </div>
        </div>

        {transactions.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            No loan transactions recorded yet. When loans are disbursed or repaid, events are cryptographically sealed here.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Tx ID</th>
                  <th className="px-4 py-3">Timestamp</th>
                  <th className="px-4 py-3">Facility</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3 text-right">Amount</th>
                  <th className="px-4 py-3">Channel / Source</th>
                  <th className="px-4 py-3">Cryptographic SHA-256 Hash</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {transactions.slice(0, 15).map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50/50">
                    <td className="px-4 py-3 font-mono font-bold text-slate-900">{tx.id.substring(0, 12)}</td>
                    <td className="px-4 py-3 text-slate-600">{tx.timestamp.substring(0, 16).replace("T", " ")}</td>
                    <td className="px-4 py-3 font-mono text-slate-800">{tx.loanId}</td>
                    <td className="px-4 py-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          tx.type === "disbursement"
                            ? "bg-blue-50 text-blue-700 border border-blue-200"
                            : tx.type === "repayment"
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                            : "bg-rose-50 text-rose-700 border border-rose-200"
                        }`}
                      >
                        {tx.type.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-slate-900">
                      ZMW {tx.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-4 py-3 text-slate-600 capitalize">
                      {(tx.source || "Mabala").replace(/_/g, " ")}
                    </td>
                    <td className="px-4 py-3 font-mono text-[11px] text-slate-500">
                      <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                        {(tx.immutableHash || "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855").substring(0, 16)}...
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

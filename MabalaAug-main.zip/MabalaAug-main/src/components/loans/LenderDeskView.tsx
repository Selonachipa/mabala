import React, { useState } from "react";
import {
  Loan,
  LoanProduct,
  LoanApplication,
  LoanTransaction
} from "../../modules/loans/types";
import {
  reviewLoanApplication,
  disburseLoan,
  createLoanProduct,
  writeOffLoan,
  exportLoanStatementPdf
} from "../../services/loanService";
import {
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowUpRight,
  TrendingUp,
  AlertTriangle,
  Send,
  PlusCircle,
  FileSpreadsheet,
  Search,
  Filter,
  ShieldCheck,
  Building,
  DollarSign,
  Sparkles,
  Layers,
  X
} from "lucide-react";

interface LenderDeskViewProps {
  loans: Loan[];
  applications: LoanApplication[];
  products: LoanProduct[];
  lenderTenantId: string;
  lenderName: string;
  onRefresh: () => void;
}

export const LenderDeskView: React.FC<LenderDeskViewProps> = ({
  loans,
  applications,
  products,
  lenderTenantId,
  lenderName,
  onRefresh
}) => {
  const [activeTab, setActiveTab] = useState<"applications" | "portfolio" | "products">("applications");

  // Application Review State
  const [selectedAppForReview, setSelectedAppForReview] = useState<LoanApplication | null>(null);
  const [approvedAmount, setApprovedAmount] = useState<number>(0);
  const [approvedRate, setApprovedRate] = useState<number>(15);
  const [approvedTenor, setApprovedTenor] = useState<number>(6);
  const [rejectionReason, setRejectionReason] = useState("");
  const [reviewSubmitting, setReviewSubmitting] = useState(false);
  const [reviewError, setReviewError] = useState("");

  // Disbursement Modal State
  const [selectedAppForDisburse, setSelectedAppForDisburse] = useState<LoanApplication | null>(null);
  const [disburseDate, setDisburseDate] = useState(new Date().toISOString().split("T")[0]);
  const [disbSubmitting, setDisbSubmitting] = useState(false);
  const [disbError, setDisbError] = useState("");
  const [disbSuccessMsg, setDisbSuccessMsg] = useState("");

  // New Product Modal State
  const [showNewProductModal, setShowNewProductModal] = useState(false);
  const [prodName, setProdName] = useState("");
  const [prodProductType, setProdProductType] = useState<"input_credit" | "facility">("input_credit");
  const [prodIssuerType, setProdIssuerType] = useState<"agro_dealer" | "supplier">("agro_dealer");
  const [prodIssuerName, setProdIssuerName] = useState(lenderName || "Agro Dealer Hub");
  const [prodModel, setProdModel] = useState<"agricultural_crop" | "agribusiness_enterprise">("agricultural_crop");
  const [prodMinPrincipal, setProdMinPrincipal] = useState<number>(1000);
  const [prodMaxPrincipal, setProdMaxPrincipal] = useState<number>(50000);
  const [prodRate, setProdRate] = useState<number>(12);
  const [prodCalcMethod, setProdCalcMethod] = useState<"flat" | "reducing_balance">("flat");
  const [prodRepayFreq, setProdRepayFreq] = useState<"monthly" | "harvest_bullet">("monthly");
  const [prodGracePeriod, setProdGracePeriod] = useState<number>(0);
  const [prodSubmitting, setProdSubmitting] = useState(false);

  // Filter and Search
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Macro Portfolio Calculations
  const activeLoans = loans.filter((l) => l.status === "active" || l.status === "in_arrears");
  const totalDisbursed = loans.reduce((sum, l) => sum + (l.principalDisbursed || 0), 0);
  const totalPrincipalCollected = loans.reduce((sum, l) => sum + (l.totalPrincipalRepaid || 0), 0);
  const totalInterestCollected = loans.reduce((sum, l) => sum + (l.totalInterestRepaid || 0), 0);
  const totalActiveExposure = activeLoans.reduce((sum, l) => sum + (l.principalOutstanding || 0), 0);
  const totalInArrears = activeLoans.filter((l) => l.daysPastDue > 0).reduce((sum, l) => sum + l.principalOutstanding, 0);
  const par30Plus = activeLoans.filter((l) => l.daysPastDue > 30).reduce((sum, l) => sum + l.principalOutstanding, 0);
  const par30Pct = totalActiveExposure > 0 ? ((par30Plus / totalActiveExposure) * 100).toFixed(1) : "0.0";

  // Handle Review
  const handleReviewAction = async (action: "approve" | "reject") => {
    if (!selectedAppForReview) return;
    setReviewSubmitting(true);
    setReviewError("");

    try {
      await reviewLoanApplication(selectedAppForReview.id, {
        action,
        reviewer: lenderName,
        reason: action === "reject" ? rejectionReason : undefined,
        approvedAmount: action === "approve" ? approvedAmount : undefined,
        approvedInterestRatePct: action === "approve" ? approvedRate : undefined,
        approvedTenorValue: action === "approve" ? approvedTenor : undefined
      });

      setSelectedAppForReview(null);
      onRefresh();
    } catch (err: any) {
      setReviewError(err.message || "Review action failed");
    } finally {
      setReviewSubmitting(false);
    }
  };

  // Handle Authoritative Disbursement
  const handleDisbursement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAppForDisburse) return;
    setDisbSubmitting(true);
    setDisbError("");
    setDisbSuccessMsg("");

    try {
      const res = await disburseLoan({
        applicationId: selectedAppForDisburse.id,
        customDisbursementDate: disburseDate,
        disbursementMethod: selectedAppForDisburse.disbursementMethod,
        disbursementAccount: selectedAppForDisburse.disbursementAccount,
        authorizingOfficer: lenderName
      });

      setDisbSuccessMsg(`Facility ${res.loan.loanNumber} successfully disbursed! Journal entry posted to Ledger.`);
      setTimeout(() => {
        setSelectedAppForDisburse(null);
        setDisbSuccessMsg("");
        onRefresh();
      }, 2000);
    } catch (err: any) {
      setDisbError(err.message || "Failed to disburse facility");
    } finally {
      setDisbSubmitting(false);
    }
  };

  // Handle Product Creation
  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setProdSubmitting(true);

    try {
      await createLoanProduct({
        tenantId: lenderTenantId || (prodIssuerType === "supplier" ? "TENANT-SUPPLIER-01" : "TENANT-DEALER-01"),
        issuerName: prodIssuerName || lenderName || (prodIssuerType === "supplier" ? "Agri Supplier Partner" : "Agro Dealer Hub"),
        issuerType: prodIssuerType,
        productType: prodProductType,
        name: prodName,
        financingModel: prodProductType === "input_credit" ? "agricultural_crop" : prodModel,
        minPrincipal: prodMinPrincipal,
        maxPrincipal: prodMaxPrincipal,
        defaultPrincipal: (prodMinPrincipal + prodMaxPrincipal) / 2,
        interestRatePct: prodRate,
        interestCalculationMethod: prodCalcMethod,
        repaymentFrequency: prodRepayFreq,
        tenorUnit: "months",
        defaultTenorValue: 6,
        gracePeriodValue: prodGracePeriod,
        gracePeriodUnit: "months",
        latePenaltyRatePct: 2,
        lateGraceDays: 5,
        disbursementMethodsAllowed: prodProductType === "input_credit" ? ["input_voucher", "mobile_money"] : ["mobile_money", "bank_transfer", "mabala_wallet"],
        collateralRequired: false,
        requiresCropCycleLink: prodProductType === "input_credit" || prodModel === "agricultural_crop",
        status: "active"
      });

      setShowNewProductModal(false);
      onRefresh();
    } catch (err: any) {
      alert(err.message || "Failed to create product");
    } finally {
      setProdSubmitting(false);
    }
  };

  // Filtered Applications
  const filteredApps = applications.filter((app) => {
    if (statusFilter !== "all" && app.status !== statusFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        app.borrowerName.toLowerCase().includes(q) ||
        app.applicationNumber.toLowerCase().includes(q) ||
        app.productName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Filtered Portfolio Loans
  const filteredLoans = loans.filter((loan) => {
    if (statusFilter !== "all" && loan.status !== statusFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        loan.borrowerName.toLowerCase().includes(q) ||
        loan.loanNumber.toLowerCase().includes(q) ||
        loan.productName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6" id="lender-desk-view">
      {/* Lender Header with Institutional Context */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Building className="w-5 h-5 text-emerald-600" />
            <h2 className="text-lg font-bold text-slate-900">{lenderName} Loan Operations Desk</h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Credit origination, automated underwriting, authoritative disbursements & portfolio recovery
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowNewProductModal(true)}
            id="btn-open-create-product"
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition shadow-sm"
          >
            <PlusCircle className="w-4 h-4" />
            New Loan Product
          </button>
        </div>
      </div>

      {/* Macro Portfolio KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">Capital Deployed</div>
          <div className="text-xl font-bold text-slate-900 mt-1">
            ZMW {totalDisbursed.toLocaleString(undefined, { minimumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-slate-400 mt-0.5">{loans.length} lifetime facilities</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">Active Exposure</div>
          <div className="text-xl font-bold text-emerald-700 mt-1">
            ZMW {totalActiveExposure.toLocaleString(undefined, { minimumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-emerald-600 mt-0.5">{activeLoans.length} ongoing loans</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">Principal Recovered</div>
          <div className="text-xl font-bold text-blue-700 mt-1">
            ZMW {totalPrincipalCollected.toLocaleString(undefined, { minimumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-blue-600 mt-0.5">+ ZMW {totalInterestCollected.toLocaleString()} interest</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">Past Due (DPD &gt; 0)</div>
          <div className="text-xl font-bold text-amber-700 mt-1">
            ZMW {totalInArrears.toLocaleString(undefined, { minimumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-amber-600 mt-0.5">{activeLoans.filter((l) => l.daysPastDue > 0).length} overdue</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">PAR 30+ Rate</div>
          <div className={`text-xl font-bold mt-1 ${Number(par30Pct) > 5 ? "text-rose-600" : "text-emerald-700"}`}>
            {par30Pct}%
          </div>
          <div className="text-xs text-slate-400 mt-0.5">Risk threshold &le; 5.0%</div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex border-b border-slate-200 gap-6 text-sm font-semibold">
        <button
          onClick={() => { setActiveTab("applications"); setStatusFilter("all"); }}
          className={`pb-3 flex items-center gap-2 border-b-2 transition ${
            activeTab === "applications"
              ? "border-emerald-600 text-emerald-800"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
          id="tab-lender-applications"
        >
          <Users className="w-4 h-4" />
          Underwriting Queue
          <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full text-xs">
            {applications.filter((a) => a.status === "submitted" || a.status === "approved").length}
          </span>
        </button>

        <button
          onClick={() => { setActiveTab("portfolio"); setStatusFilter("all"); }}
          className={`pb-3 flex items-center gap-2 border-b-2 transition ${
            activeTab === "portfolio"
              ? "border-emerald-600 text-emerald-800"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
          id="tab-lender-portfolio"
        >
          <TrendingUp className="w-4 h-4" />
          Active Loan Portfolio
          <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full text-xs">
            {loans.length}
          </span>
        </button>

        <button
          onClick={() => { setActiveTab("products"); setStatusFilter("all"); }}
          className={`pb-3 flex items-center gap-2 border-b-2 transition ${
            activeTab === "products"
              ? "border-emerald-600 text-emerald-800"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
          id="tab-lender-products"
        >
          <FileSpreadsheet className="w-4 h-4" />
          Loan Products ({products.length})
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 1. APPLICATIONS QUEUE                                                    */}
      {/* ========================================================================= */}
      {activeTab === "applications" && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden" id="panel-underwriting-queue">
          <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search by borrower name or app #..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 w-64 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
              />
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500">Status:</span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs"
              >
                <option value="all">All Applications</option>
                <option value="submitted">Submitted (Needs Review)</option>
                <option value="approved">Approved (Awaiting Disbursement)</option>
                <option value="disbursed">Disbursed</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>

          {filteredApps.length === 0 ? (
            <div className="p-12 text-center text-slate-500 text-xs">
              No loan applications found matching criteria.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filteredApps.map((app) => (
                <div key={app.id} className="p-5 hover:bg-slate-50/50 transition flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">{app.borrowerName}</span>
                      <span className="text-xs font-mono bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                        {app.applicationNumber}
                      </span>
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                          app.status === "submitted"
                            ? "bg-amber-50 text-amber-700 border border-amber-200"
                            : app.status === "approved"
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                            : app.status === "disbursed"
                            ? "bg-blue-50 text-blue-700 border border-blue-200"
                            : "bg-rose-50 text-rose-700 border border-rose-200"
                        }`}
                      >
                        {app.status.toUpperCase()}
                      </span>
                    </div>

                    <div className="text-xs text-slate-500 flex flex-wrap items-center gap-3">
                      <span>Product: <strong className="text-slate-700">{app.productName}</strong></span>
                      <span>•</span>
                      <span>Requested: <strong className="text-slate-900 font-mono">ZMW {app.requestedAmount.toLocaleString()}</strong></span>
                      <span>•</span>
                      <span>Tenor: {app.requestedTenorValue} {app.requestedTenorUnit}</span>
                      <span>•</span>
                      <span>Phone: {app.borrowerPhone}</span>
                      {app.cropCycleName && (
                        <>
                          <span>•</span>
                          <span className="text-emerald-700 font-medium">Cycle: {app.cropCycleName}</span>
                        </>
                      )}
                    </div>

                    <div className="text-xs text-slate-600 bg-slate-50 px-2.5 py-1 rounded inline-block">
                      Purpose: {app.purpose}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    {app.status === "submitted" && (
                      <button
                        onClick={() => {
                          setSelectedAppForReview(app);
                          setApprovedAmount(app.requestedAmount);
                          setApprovedTenor(app.requestedTenorValue);
                        }}
                        id={`btn-review-${app.id}`}
                        className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition shadow-sm"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        Underwrite / Review
                      </button>
                    )}

                    {app.status === "approved" && (
                      <button
                        onClick={() => {
                          setSelectedAppForDisburse(app);
                          setDisburseDate(new Date().toISOString().split("T")[0]);
                        }}
                        id={`btn-disburse-${app.id}`}
                        className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition shadow-sm"
                      >
                        <Send className="w-3.5 h-3.5" />
                        Disburse Funds
                      </button>
                    )}

                    {app.status === "disbursed" && (
                      <span className="text-xs text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                        Facility Active ({app.loanId})
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. ACTIVE PORTFOLIO TABLE                                               */}
      {/* ========================================================================= */}
      {activeTab === "portfolio" && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden" id="panel-portfolio-loans">
          <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search borrower or facility number..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 w-64 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
              />
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500">Aging / Status:</span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs"
              >
                <option value="all">All Facilities</option>
                <option value="active">Active (Good Standing)</option>
                <option value="in_arrears">In Arrears (Overdue)</option>
                <option value="paid_off">Fully Settled</option>
                <option value="written_off">Written Off</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Facility #</th>
                  <th className="px-4 py-3">Borrower</th>
                  <th className="px-4 py-3 text-right">Disbursed</th>
                  <th className="px-4 py-3 text-right">Repaid</th>
                  <th className="px-4 py-3 text-right">Outstanding</th>
                  <th className="px-4 py-3">Aging Bucket</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLoans.map((loan) => (
                  <tr key={loan.id} className="hover:bg-slate-50/50">
                    <td className="px-4 py-3 font-mono font-bold text-slate-900">{loan.loanNumber}</td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-slate-800">{loan.borrowerName}</div>
                      <div className="text-[11px] text-slate-400">{loan.borrowerPhone}</div>
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-medium text-slate-700">
                      ZMW {loan.principalDisbursed.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-emerald-700 font-medium">
                      ZMW {loan.totalRepaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-slate-900">
                      ZMW {loan.totalOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          loan.agingBucket === "current"
                            ? "bg-emerald-50 text-emerald-700"
                            : loan.agingBucket === "1_30_dpd"
                            ? "bg-amber-50 text-amber-700"
                            : "bg-rose-50 text-rose-700"
                        }`}
                      >
                        {loan.daysPastDue === 0 ? "CURRENT" : `${loan.daysPastDue} DPD`}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          loan.status === "active"
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                            : loan.status === "paid_off"
                            ? "bg-blue-50 text-blue-700 border border-blue-200"
                            : "bg-rose-50 text-rose-700 border border-rose-200"
                        }`}
                      >
                        {loan.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button
                        onClick={() => exportLoanStatementPdf(loan)}
                        className="text-xs text-emerald-700 hover:underline font-semibold"
                        title="Download Statement"
                      >
                        Statement
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. LOAN PRODUCTS CATALOG                                                */}
      {/* ========================================================================= */}
      {activeTab === "products" && (
        products.length === 0 ? (
          <div className="bg-white rounded-xl border border-slate-200 p-12 text-center" id="empty-state-lender-products">
            <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center mx-auto mb-3 text-slate-400">
              <Layers className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">No Financing Products Posted</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              There are currently no active financing products or credit facilities posted on the platform. Click &ldquo;Create Loan Product&rdquo; above to publish a new product.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" id="panel-products-grid">
            {products.map((prod) => (
              <div key={prod.id} className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">{prod.name}</span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                      prod.financingModel === "agricultural_crop"
                        ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                        : "bg-blue-50 text-blue-700 border border-blue-200"
                    }`}
                  >
                    {prod.financingModel === "agricultural_crop" ? "Crop Season" : "Enterprise"}
                  </span>
                </div>
                <p className="text-xs text-slate-500 line-clamp-2">{prod.description}</p>
                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Interest Rate</span>
                    <span className="font-bold text-slate-800">{prod.interestRatePct}% ({prod.interestCalculationMethod})</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Repayment</span>
                    <span className="font-bold text-slate-800 capitalize">{prod.repaymentFrequency.replace("_", " ")}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Principal Range</span>
                    <span className="font-semibold text-slate-800 font-mono">K{prod.minPrincipal} - K{prod.maxPrincipal}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Tenor Range</span>
                    <span className="font-semibold text-slate-800">{prod.minTenorValue} - {prod.maxTenorValue} {prod.tenorUnit}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      )}

      {/* ========================================================================= */}
      {/* REVIEW APPLICATION MODAL                                                 */}
      {/* ========================================================================= */}
      {selectedAppForReview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto" id="modal-review-application">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl my-8 border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Underwrite Loan Application</h3>
                <p className="text-xs text-slate-500">{selectedAppForReview.applicationNumber} — {selectedAppForReview.borrowerName}</p>
              </div>
              <button onClick={() => setSelectedAppForReview(null)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            {reviewError && (
              <div className="mt-3 p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{reviewError}</span>
              </div>
            )}

            <div className="space-y-3 mt-4 text-xs">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">Applicant Name:</span>
                  <strong className="text-slate-800">{selectedAppForReview.borrowerName}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Phone & Network:</span>
                  <strong className="text-slate-800">{selectedAppForReview.borrowerPhone}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Financing Model:</span>
                  <strong className="text-slate-800 capitalize">{selectedAppForReview.financingModel.replace("_", " ")}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Requested Amount:</span>
                  <strong className="text-emerald-700 font-bold font-mono">ZMW {selectedAppForReview.requestedAmount.toLocaleString()}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Purpose:</span>
                  <span className="text-slate-700">{selectedAppForReview.purpose}</span>
                </div>
              </div>

              {/* Adjust Underwritten Terms */}
              <div className="space-y-2 pt-2">
                <div className="font-semibold text-slate-800">Approved Terms & Facility Limits:</div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-500 mb-1">Approved Amount (ZMW)</label>
                    <input
                      type="number"
                      value={approvedAmount}
                      onChange={(e) => setApprovedAmount(Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 mb-1">Interest Rate (%)</label>
                    <input
                      type="number"
                      value={approvedRate}
                      onChange={(e) => setApprovedRate(Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 font-semibold text-slate-900"
                    />
                  </div>
                </div>
              </div>

              {/* Rejection input */}
              <div>
                <label className="block text-slate-500 mb-1">Rejection Reason (if rejecting):</label>
                <input
                  type="text"
                  placeholder="e.g. Inadequate repayment capacity or failed KYC"
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  disabled={reviewSubmitting}
                  onClick={() => handleReviewAction("reject")}
                  className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold rounded-lg transition"
                >
                  Reject Application
                </button>
                <button
                  type="button"
                  disabled={reviewSubmitting}
                  onClick={() => handleReviewAction("approve")}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg shadow-sm transition"
                >
                  {reviewSubmitting ? "Approving..." : "Approve Facility"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DISBURSEMENT CONFIRMATION MODAL                                          */}
      {/* ========================================================================= */}
      {selectedAppForDisburse && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4" id="modal-disburse-facility">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Execute Authoritative Disbursement</h3>
                <p className="text-xs text-slate-500">{selectedAppForDisburse.applicationNumber}</p>
              </div>
              <button onClick={() => setSelectedAppForDisburse(null)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            {disbSuccessMsg && (
              <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{disbSuccessMsg}</span>
              </div>
            )}

            {disbError && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{disbError}</span>
              </div>
            )}

            {!disbSuccessMsg && (
              <form onSubmit={handleDisbursement} className="space-y-4 mt-4 text-xs">
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Borrower:</span>
                    <strong className="text-slate-900">{selectedAppForDisburse.borrowerName}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Disbursement Channel:</span>
                    <strong className="text-slate-900 uppercase">{selectedAppForDisburse.disbursementMethod.replace("_", " ")}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Destination Account:</span>
                    <span className="font-mono font-bold text-slate-800">{selectedAppForDisburse.disbursementAccount}</span>
                  </div>
                  <div className="flex justify-between text-emerald-800 font-bold pt-1 border-t border-slate-200">
                    <span>Principal to Disburse:</span>
                    <span className="font-mono text-sm">ZMW {(selectedAppForDisburse.approvedAmount || selectedAppForDisburse.requestedAmount).toLocaleString()}</span>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Authoritative Value Date</label>
                  <input
                    type="date"
                    value={disburseDate}
                    onChange={(e) => setDisburseDate(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedAppForDisburse(null)}
                    className="px-3 py-2 text-slate-600 hover:text-slate-800 font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={disbSubmitting}
                    className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2 rounded-lg shadow-sm transition disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    {disbSubmitting ? "Disbursing..." : "Confirm & Disburse Funds"}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* NEW LOAN PRODUCT MODAL                                                   */}
      {/* ========================================================================= */}
      {showNewProductModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto" id="modal-create-product">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl my-8 border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Define Financing Product</h3>
                <p className="text-xs text-slate-500">Post agro dealer or supplier credit products with instant farmer visibility</p>
              </div>
              <button onClick={() => setShowNewProductModal(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-3 p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-900 flex items-start gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Instant Farmer Portal Publication:</span> When posted, this product appears immediately in the Facilities & Input Credit catalog for all verified smallholders to browse and apply without approval delays.
              </div>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-3 mt-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Product Classification</label>
                  <select
                    value={prodProductType}
                    onChange={(e: any) => {
                      setProdProductType(e.target.value);
                      if (e.target.value === "input_credit") {
                        setProdModel("agricultural_crop");
                        setProdRepayFreq("harvest_bullet");
                      } else {
                        setProdModel("agribusiness_enterprise");
                        setProdRepayFreq("monthly");
                      }
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-medium"
                  >
                    <option value="input_credit">🌱 Input Credit (Seed/Fertilizer Voucher)</option>
                    <option value="facility">💼 Facility (Cash / Equipment Loan)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Posted By (Issuer Type)</label>
                  <select
                    value={prodIssuerType}
                    onChange={(e: any) => setProdIssuerType(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5"
                  >
                    <option value="agro_dealer">Agro Dealer Hub</option>
                    <option value="supplier">Certified Agri Supplier</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Product Title</label>
                  <input
                    type="text"
                    placeholder="e.g. Seasonal Maize Seed & Fertilizer Voucher"
                    value={prodName}
                    onChange={(e) => setProdName(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Issuer Company / Hub Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Choma Rural Agro-Dealer Co-op"
                    value={prodIssuerName}
                    onChange={(e) => setProdIssuerName(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Repayment Frequency</label>
                  <select
                    value={prodRepayFreq}
                    onChange={(e: any) => setProdRepayFreq(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5"
                  >
                    <option value="harvest_bullet">Harvest Bullet (Single Post-Harvest Payment)</option>
                    <option value="monthly">Monthly Equal Amortization (EMI)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Grace Period (Months)</label>
                  <input
                    type="number"
                    min={0}
                    max={12}
                    value={prodGracePeriod}
                    onChange={(e) => setProdGracePeriod(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Interest Rate (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={prodRate}
                    onChange={(e) => setProdRate(Number(e.target.value))}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 font-bold"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Calculation Method</label>
                  <select
                    value={prodCalcMethod}
                    onChange={(e: any) => setProdCalcMethod(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5"
                  >
                    <option value="flat">Flat Rate</option>
                    <option value="reducing_balance">Reducing Balance Amortization</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Min Principal (ZMW)</label>
                  <input
                    type="number"
                    value={prodMinPrincipal}
                    onChange={(e) => setProdMinPrincipal(Number(e.target.value))}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Max Principal (ZMW)</label>
                  <input
                    type="number"
                    value={prodMaxPrincipal}
                    onChange={(e) => setProdMaxPrincipal(Number(e.target.value))}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowNewProductModal(false)}
                  className="px-3 py-2 text-slate-600 hover:text-slate-800 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={prodSubmitting}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg shadow-sm transition"
                >
                  {prodSubmitting ? "Saving..." : "Create Product"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

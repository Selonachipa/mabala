import React, { useState, useEffect } from "react";

interface AreaCultivatedInputControlProps {
  areaHectares: number;
  onChangeAreaHectares: (hectares: number) => void;
  required?: boolean;
  className?: string;
  theme?: "emerald" | "indigo";
}

const HA_TO_ACRES = 2.4710538146717;
const HA_TO_M2 = 10000;

// Helper to parse flexible inputs like "35m", "35m2", "30ha", "30ac", "35x40", "30"
function parseFlexibleString(valStr: string, activeUnit: "ha" | "m2" | "dimensions" | "acres"): { ha: number; detectedUnit?: string } | null {
  const trimmed = valStr.trim().toLowerCase();
  if (!trimmed) return { ha: 0 };

  // Check for dimension format like "35m x 40m", "35 x 40", "35m*40m"
  const dimMatch = trimmed.match(/^(\d+(?:\.\d+)?)\s*(?:m)?\s*[x*×]\s*(\d+(?:\.\d+)?)\s*(?:m)?$/i);
  if (dimMatch) {
    const l = parseFloat(dimMatch[1]);
    const w = parseFloat(dimMatch[2]);
    if (!isNaN(l) && !isNaN(w)) {
      const m2 = l * w;
      return { ha: m2 / HA_TO_M2, detectedUnit: "dimensions" };
    }
  }

  // Check for explicit "ha" or "hectare" suffix
  const haMatch = trimmed.match(/^(\d+(?:\.\d+)?)\s*(?:ha|hectares?|h)$/i);
  if (haMatch) {
    const val = parseFloat(haMatch[1]);
    if (!isNaN(val)) return { ha: val, detectedUnit: "ha" };
  }

  // Check for explicit "ac" or "acre" suffix
  const acMatch = trimmed.match(/^(\d+(?:\.\d+)?)\s*(?:ac|acres?|a)$/i);
  if (acMatch) {
    const val = parseFloat(acMatch[1]);
    if (!isNaN(val)) return { ha: val / HA_TO_ACRES, detectedUnit: "acres" };
  }

  // Check for explicit "m", "m2", "sqm", "sq m" suffix
  const mMatch = trimmed.match(/^(\d+(?:\.\d+)?)\s*(?:m2|sqm|sq\s*m|m²|m)$/i);
  if (mMatch) {
    const val = parseFloat(mMatch[1]);
    if (!isNaN(val)) return { ha: val / HA_TO_M2, detectedUnit: "m2" };
  }

  // Plain number without suffix - interpret based on activeUnit
  const plainNum = parseFloat(trimmed);
  if (!isNaN(plainNum)) {
    if (activeUnit === "ha") return { ha: plainNum };
    if (activeUnit === "acres") return { ha: plainNum / HA_TO_ACRES };
    if (activeUnit === "m2") return { ha: plainNum / HA_TO_M2 };
    if (activeUnit === "dimensions") return { ha: plainNum / HA_TO_M2 };
  }

  return null;
}

export const AreaCultivatedInputControl: React.FC<AreaCultivatedInputControlProps> = ({
  areaHectares,
  onChangeAreaHectares,
  required = true,
  className = "",
  theme = "emerald"
}) => {
  const [activeUnit, setActiveUnit] = useState<"ha" | "m2" | "dimensions" | "acres">("ha");

  // String buffers for responsive typing without cursor snapping or strict blocking
  const [haInput, setHaInput] = useState<string>(() => (areaHectares > 0 ? String(areaHectares) : "2"));
  const [m2Input, setM2Input] = useState<string>(() => String(Math.round((areaHectares || 2) * HA_TO_M2)));
  const [acresInput, setAcresInput] = useState<string>(() => {
    const ac = (areaHectares || 2) * HA_TO_ACRES;
    return String(Math.round(ac * 100) / 100);
  });
  
  // Dimensions Length & Width (in meters)
  const [lengthM, setLengthM] = useState<string>("100");
  const [widthM, setWidthM] = useState<string>(() => {
    const m2 = (areaHectares || 2) * HA_TO_M2;
    return String(Math.round((m2 / 100) * 10) / 10);
  });

  // Sync internal string states when external areaHectares prop changes
  useEffect(() => {
    const currentHa = Number(haInput.replace(/[^0-9.]/g, ""));
    if (!isNaN(currentHa) && Math.abs(currentHa - areaHectares) > 0.0001) {
      setHaInput(String(areaHectares));
      const m2 = areaHectares * HA_TO_M2;
      setM2Input(String(Math.round(m2 * 100) / 100));
      const ac = areaHectares * HA_TO_ACRES;
      setAcresInput(String(Math.round(ac * 100) / 100));
      
      const currentLen = Number(lengthM) || 100;
      if (currentLen > 0) {
        setWidthM(String(Math.round((m2 / currentLen) * 10) / 10));
      }
    }
  }, [areaHectares]);

  const handleHaChange = (valStr: string) => {
    setHaInput(valStr);
    const parsed = parseFlexibleString(valStr, "ha");
    if (parsed !== null) {
      const num = parsed.ha;
      onChangeAreaHectares(num);
      const m2 = num * HA_TO_M2;
      setM2Input(String(Math.round(m2 * 100) / 100));
      setAcresInput(String(Math.round(num * HA_TO_ACRES * 100) / 100));
      const currentLen = Number(lengthM) || 100;
      if (currentLen > 0) {
        setWidthM(String(Math.round((m2 / currentLen) * 10) / 10));
      }
    } else if (valStr === "") {
      onChangeAreaHectares(0);
      setM2Input("");
      setAcresInput("");
    }
  };

  const handleM2Change = (valStr: string) => {
    setM2Input(valStr);
    const parsed = parseFlexibleString(valStr, "m2");
    if (parsed !== null) {
      const ha = parsed.ha;
      const roundedHa = Math.round(ha * 10000) / 10000;
      setHaInput(String(roundedHa));
      setAcresInput(String(Math.round(ha * HA_TO_ACRES * 100) / 100));
      onChangeAreaHectares(roundedHa);
      const currentLen = Number(lengthM) || 100;
      if (currentLen > 0) {
        setWidthM(String(Math.round(((ha * HA_TO_M2) / currentLen) * 10) / 10));
      }
    } else if (valStr === "") {
      onChangeAreaHectares(0);
      setHaInput("");
      setAcresInput("");
    }
  };

  const handleDimensionsChange = (newLenStr: string, newWidthStr: string) => {
    setLengthM(newLenStr);
    setWidthM(newWidthStr);
    // Allow inputs like "35m", "35", "100"
    const l = parseFloat(newLenStr.replace(/[^0-9.]/g, ""));
    const w = parseFloat(newWidthStr.replace(/[^0-9.]/g, ""));
    if (!isNaN(l) && !isNaN(w) && l >= 0 && w >= 0) {
      const m2 = l * w;
      const ha = m2 / HA_TO_M2;
      const roundedHa = Math.round(ha * 10000) / 10000;
      setM2Input(String(Math.round(m2 * 100) / 100));
      setHaInput(String(roundedHa));
      setAcresInput(String(Math.round(ha * HA_TO_ACRES * 100) / 100));
      onChangeAreaHectares(roundedHa);
    }
  };

  const handleAcresChange = (valStr: string) => {
    setAcresInput(valStr);
    const parsed = parseFlexibleString(valStr, "acres");
    if (parsed !== null) {
      const ha = parsed.ha;
      const roundedHa = Math.round(ha * 10000) / 10000;
      setHaInput(String(roundedHa));
      const m2 = ha * HA_TO_M2;
      setM2Input(String(Math.round(m2 * 100) / 100));
      onChangeAreaHectares(roundedHa);
      const currentLen = Number(lengthM) || 100;
      if (currentLen > 0) {
        setWidthM(String(Math.round((m2 / currentLen) * 10) / 10));
      }
    } else if (valStr === "") {
      onChangeAreaHectares(0);
      setHaInput("");
      setM2Input("");
    }
  };

  const handleQuickPreset = (haVal: number) => {
    onChangeAreaHectares(haVal);
    setHaInput(String(haVal));
    const m2 = haVal * HA_TO_M2;
    setM2Input(String(Math.round(m2 * 100) / 100));
    setAcresInput(String(Math.round(haVal * HA_TO_ACRES * 100) / 100));
    const currentLen = Number(lengthM) || 100;
    if (currentLen > 0) {
      setWidthM(String(Math.round((m2 / currentLen) * 10) / 10));
    }
  };

  const currentHa = Number(areaHectares) || 0;
  const computedAcres = currentHa * HA_TO_ACRES;
  const computedM2 = currentHa * HA_TO_M2;

  const isEmerald = theme === "emerald";
  const activeTabClass = isEmerald 
    ? "bg-emerald-700 text-white shadow-xs" 
    : "bg-indigo-700 text-white shadow-xs";

  return (
    <div className={`rounded-xl border border-slate-200 bg-gradient-to-br from-slate-50 via-white to-emerald-50/30 p-3.5 space-y-3 ${className}`}>
      {/* Unit Selector Tabs & Title */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200/80 pb-2.5">
        <div>
          <div className="flex items-center gap-1.5">
            <span className="text-sm">📐</span>
            <label className="text-[11px] font-black uppercase text-slate-800 tracking-wider">
              Area Cultivated (Land Sizing)
            </label>
          </div>
          <p className="text-[10px] text-slate-500 font-medium mt-0.5">
            Enter whole numbers (e.g. 30, 35m, 35x40, 30 Ha, 30 Acres) with continuous auto-conversion
          </p>
        </div>

        <div className="inline-flex p-1 bg-slate-100/90 rounded-lg text-[10.5px] font-bold border border-slate-200/60">
          <button
            type="button"
            id="crop-area-unit-ha-btn"
            onClick={() => setActiveUnit("ha")}
            className={`px-2.5 py-1 rounded-md transition-all ${
              activeUnit === "ha" ? activeTabClass : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Hectares (Ha)
          </button>
          <button
            type="button"
            id="crop-area-unit-m2-btn"
            onClick={() => setActiveUnit("m2")}
            className={`px-2.5 py-1 rounded-md transition-all ${
              activeUnit === "m2" ? activeTabClass : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Meters (m² / 35m)
          </button>
          <button
            type="button"
            id="crop-area-unit-dim-btn"
            onClick={() => setActiveUnit("dimensions")}
            className={`px-2.5 py-1 rounded-md transition-all ${
              activeUnit === "dimensions" ? activeTabClass : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Dimensions (L × W)
          </button>
          <button
            type="button"
            id="crop-area-unit-ac-btn"
            onClick={() => setActiveUnit("acres")}
            className={`px-2.5 py-1 rounded-md transition-all ${
              activeUnit === "acres" ? activeTabClass : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Acres (ac)
          </button>
        </div>
      </div>

      {/* Input Fields by Active Unit */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
        <div className="md:col-span-5">
          {activeUnit === "ha" && (
            <div>
              <label className="text-[10px] font-extrabold text-slate-600 uppercase block mb-1">
                Size in Hectares (Ha)
              </label>
              <div className="relative">
                <input
                  type="text"
                  inputMode="decimal"
                  value={haInput}
                  onChange={e => handleHaChange(e.target.value)}
                  required={required}
                  placeholder="e.g. 30, 35, 30 Ha, 35m"
                  className="w-full text-xs font-bold border border-slate-300 bg-white rounded-lg p-2.5 pr-12 text-slate-800 outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all font-mono"
                />
                <span className="absolute right-3 top-2.5 text-xs font-black text-emerald-700 pointer-events-none">
                  Ha
                </span>
              </div>
            </div>
          )}

          {activeUnit === "m2" && (
            <div>
              <label className="text-[10px] font-extrabold text-slate-600 uppercase block mb-1">
                Size in Meters / Square Meters (m² / 35m)
              </label>
              <div className="relative">
                <input
                  type="text"
                  inputMode="text"
                  value={m2Input}
                  onChange={e => handleM2Change(e.target.value)}
                  required={required}
                  placeholder="e.g. 35m, 35x40, 20000"
                  className="w-full text-xs font-bold border border-slate-300 bg-white rounded-lg p-2.5 pr-12 text-slate-800 outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all font-mono"
                />
                <span className="absolute right-3 top-2.5 text-xs font-black text-emerald-700 pointer-events-none">
                  m²
                </span>
              </div>
            </div>
          )}

          {activeUnit === "dimensions" && (
            <div>
              <label className="text-[10px] font-extrabold text-slate-600 uppercase block mb-1">
                Field Dimensions in Meters (Length × Width)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <div className="relative">
                  <input
                    type="text"
                    inputMode="text"
                    value={lengthM}
                    onChange={e => handleDimensionsChange(e.target.value, widthM)}
                    required={required}
                    placeholder="Length (e.g. 35m or 35)"
                    className="w-full text-xs font-bold border border-slate-300 bg-white rounded-lg p-2.5 pr-8 text-slate-800 outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 font-mono"
                  />
                  <span className="absolute right-2 top-2.5 text-[11px] font-black text-emerald-700 pointer-events-none">
                    m L
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    inputMode="text"
                    value={widthM}
                    onChange={e => handleDimensionsChange(lengthM, e.target.value)}
                    required={required}
                    placeholder="Width (e.g. 40m or 40)"
                    className="w-full text-xs font-bold border border-slate-300 bg-white rounded-lg p-2.5 pr-8 text-slate-800 outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 font-mono"
                  />
                  <span className="absolute right-2 top-2.5 text-[11px] font-black text-emerald-700 pointer-events-none">
                    m W
                  </span>
                </div>
              </div>
            </div>
          )}

          {activeUnit === "acres" && (
            <div>
              <label className="text-[10px] font-extrabold text-slate-600 uppercase block mb-1">
                Size in Acres (ac)
              </label>
              <div className="relative">
                <input
                  type="text"
                  inputMode="decimal"
                  value={acresInput}
                  onChange={e => handleAcresChange(e.target.value)}
                  required={required}
                  placeholder="e.g. 30, 35, 30 Acres"
                  className="w-full text-xs font-bold border border-slate-300 bg-white rounded-lg p-2.5 pr-14 text-slate-800 outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all font-mono"
                />
                <span className="absolute right-3 top-2.5 text-xs font-black text-emerald-700 pointer-events-none">
                  Acres
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Live Auto-Conversion Readout Displaying Hectares, Acres, and Meters */}
        <div className="md:col-span-7 bg-white rounded-xl p-2.5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-[9.5px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 px-0.5">
            <span className="flex items-center gap-1 text-emerald-700 font-black">
              <span>⚡</span> Auto-Converted Equivalence
            </span>
            <span className="font-mono text-slate-400">1 Ha = 2.471 Ac = 10,000 m²</span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            {/* Hectares Pill */}
            <div className={`p-2 rounded-lg border transition-all ${
              activeUnit === "ha" 
                ? "bg-emerald-50/90 border-emerald-300 ring-1 ring-emerald-400/50" 
                : "bg-slate-50 border-slate-200/70"
            }`}>
              <div className="text-[9px] font-extrabold uppercase text-slate-500">Hectares</div>
              <div className="text-xs font-black text-emerald-900 font-mono mt-0.5 truncate">
                {currentHa.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })} Ha
              </div>
            </div>

            {/* Acres Pill */}
            <div className={`p-2 rounded-lg border transition-all ${
              activeUnit === "acres" 
                ? "bg-teal-50/90 border-teal-300 ring-1 ring-teal-400/50" 
                : "bg-slate-50 border-slate-200/70"
            }`}>
              <div className="text-[9px] font-extrabold uppercase text-slate-500">Acres</div>
              <div className="text-xs font-black text-teal-900 font-mono mt-0.5 truncate">
                {computedAcres.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} Ac
              </div>
            </div>

            {/* Square Meters Pill */}
            <div className={`p-2 rounded-lg border transition-all ${
              activeUnit === "m2" || activeUnit === "dimensions"
                ? "bg-blue-50/90 border-blue-300 ring-1 ring-blue-400/50" 
                : "bg-slate-50 border-slate-200/70"
            }`}>
              <div className="text-[9px] font-extrabold uppercase text-slate-500">Square Meters</div>
              <div className="text-xs font-black text-blue-900 font-mono mt-0.5 truncate">
                {computedM2.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 1 })} m²
              </div>
            </div>
          </div>

          {/* Quick presets */}
          <div className="mt-2 pt-2 border-t border-slate-100 flex flex-wrap items-center gap-1.5">
            <span className="text-[9px] font-bold text-slate-400 uppercase">Quick sizes:</span>
            {[
              { label: "0.5 Ha", val: 0.5 },
              { label: "1 Ha", val: 1 },
              { label: "2 Ha", val: 2 },
              { label: "5 Ha", val: 5 },
              { label: "10 Ha", val: 10 },
              { label: "30 Ha", val: 30 },
              { label: "35 Ha", val: 35 },
              { label: "30 Ac", val: 30 / HA_TO_ACRES },
              { label: "35 Ac", val: 35 / HA_TO_ACRES },
            ].map(p => (
              <button
                key={p.label}
                type="button"
                onClick={() => handleQuickPreset(p.val)}
                className="px-2 py-0.5 text-[9px] font-bold bg-slate-100 hover:bg-emerald-100 hover:text-emerald-800 text-slate-600 rounded transition-colors"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

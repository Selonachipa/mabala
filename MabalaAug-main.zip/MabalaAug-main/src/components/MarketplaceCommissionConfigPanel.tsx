import React, { useState, useEffect } from "react";
import {
  Sliders,
  DollarSign,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Info,
  RefreshCw,
  Zap,
  Store,
  Layers,
  ShoppingBag,
  CreditCard,
  FileText,
  UserCheck
} from "lucide-react";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { db } from "../firebase";
import { safeLocalStorage as localStorage } from "../utils/safeStorage";

export interface ModuleCommissionSetting {
  code: string;
  name: string;
  description: string;
  ratePercent: number;
  payerMode: "SELLER" | "BUYER";
  prefix: string;
  isWalkInExempt: boolean;
}

export interface PlatformCommissionConfig {
  modules: Record<string, ModuleCommissionSetting>;
  deliveryFeePerKm: number;
  agroDealerDefaultRate: number;
  agroDealerPayerMode: "SELLER" | "BUYER";
  updatedAt?: string;
  updatedBy?: string;
}

export const DEFAULT_COMMISSION_CONFIG: PlatformCommissionConfig = {
  deliveryFeePerKm: 15,
  agroDealerDefaultRate: 2.5,
  agroDealerPayerMode: "SELLER",
  modules: {
    AGD: {
      code: "AGD",
      name: "Agro-Dealer Marketplace Sales",
      description: "Direct input purchases (seeds, fertilizers, chemicals) ordered via farmer marketplace",
      ratePercent: 2.5,
      payerMode: "SELLER",
      prefix: "AGD-",
      isWalkInExempt: true
    },
    SUPPLY: {
      code: "SUPPLY",
      name: "Supply & Input Payments",
      description: "Bulk input procurement orders and enterprise farmer consignment settlements",
      ratePercent: 2.5,
      payerMode: "SELLER",
      prefix: "SUPPLY-",
      isWalkInExempt: true
    },
    EVENTS: {
      code: "EVENTS",
      name: "Events & Subscriptions",
      description: "Agro-expo ticket sales, coop training workshops, and recurring platform tiers",
      ratePercent: 10.0,
      payerMode: "BUYER",
      prefix: "SUB-",
      isWalkInExempt: true
    },
    AGV: {
      code: "AGV",
      name: "Agronomist & Veterinary Consultations",
      description: "On-demand field agronomy visits and tele-vet consultations",
      ratePercent: 10.0,
      payerMode: "SELLER",
      prefix: "AGV-",
      isWalkInExempt: true
    },
    INS: {
      code: "INS",
      name: "Crop & Livestock Insurance",
      description: "Weather-index drought protection and livestock mortality policies",
      ratePercent: 12.5,
      payerMode: "BUYER",
      prefix: "INS-",
      isWalkInExempt: true
    }
  }
};

interface Props {
  currencySymbol?: string;
  userEmail?: string;
  onConfigSaved?: (newConfig: PlatformCommissionConfig) => void;
}

export default function MarketplaceCommissionConfigPanel({
  currencySymbol = "ZMW",
  userEmail = "superadmin@mabala.zm",
  onConfigSaved
}: Props) {
  const [config, setConfig] = useState<PlatformCommissionConfig>(DEFAULT_COMMISSION_CONFIG);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Live calculation simulator states
  const [simAmount, setSimAmount] = useState<number>(1000);
  const [simModule, setSimModule] = useState<string>("AGD");

  // Load config on mount
  useEffect(() => {
    async function loadConfig() {
      setIsLoading(true);
      try {
        // 1. Try Firestore first
        if (db) {
          const docRef = doc(db, "superAdmin", "platformConfig");
          const snap = await getDoc(docRef);
          if (snap.exists() && snap.data()?.commissions) {
            const remoteConfig = snap.data().commissions as PlatformCommissionConfig;
            setConfig(remoteConfig);
            localStorage.setItem("mabala_platform_commission_config", JSON.stringify(remoteConfig));
            setIsLoading(false);
            return;
          }
        }

        // 2. LocalStorage Fallback
        const savedLocal = localStorage.getItem("mabala_platform_commission_config");
        if (savedLocal) {
          setConfig(JSON.parse(savedLocal));
        } else {
          setConfig(DEFAULT_COMMISSION_CONFIG);
        }
      } catch (err) {
        console.warn("[CommissionConfig] Load warning, using default config:", err);
      } finally {
        setIsLoading(false);
      }
    }

    loadConfig();
  }, []);

  const handleModuleRateChange = (code: string, newRate: number) => {
    setConfig((prev) => ({
      ...prev,
      modules: {
        ...prev.modules,
        [code]: {
          ...prev.modules[code],
          ratePercent: Math.max(0, Math.min(100, newRate))
        }
      }
    }));
  };

  const handleModulePayerChange = (code: string, newPayer: "SELLER" | "BUYER") => {
    setConfig((prev) => ({
      ...prev,
      modules: {
        ...prev.modules,
        [code]: {
          ...prev.modules[code],
          payerMode: newPayer
        }
      }
    }));
  };

  const handleSaveConfig = async () => {
    setSaveStatus(null);
    setSaveError(null);

    const payload: PlatformCommissionConfig = {
      ...config,
      updatedAt: new Date().toISOString(),
      updatedBy: userEmail
    };

    try {
      // 1. Always save locally first for instant offline readiness
      localStorage.setItem("mabala_platform_commission_config", JSON.stringify(payload));

      // 2. Persist to Firestore under superAdmin/platformConfig
      if (db) {
        await setDoc(
          doc(db, "superAdmin", "platformConfig"),
          {
            commissions: payload
          },
          { merge: true }
        );
      }

      setSaveStatus("✓ Marketplace Commission Config live-saved to /superAdmin/platformConfig! Active platform-wide.");
      if (onConfigSaved) onConfigSaved(payload);
      setTimeout(() => setSaveStatus(null), 5000);
    } catch (err: any) {
      console.error("[CommissionConfig] Save error:", err);
      setSaveError("Failed to persist to cloud database: " + err.message + " (Saved to local cache)");
    }
  };

  // Calculation logic for simulation
  const selectedModObj = config.modules[simModule] || config.modules.AGD;
  const simCommissionAmount = (simAmount * selectedModObj.ratePercent) / 100;
  const simBuyerTotal = selectedModObj.payerMode === "BUYER" ? simAmount + simCommissionAmount : simAmount;
  const simSellerNet = selectedModObj.payerMode === "SELLER" ? simAmount - simCommissionAmount : simAmount;

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6 animate-fade-in font-sans text-slate-900">
      {/* Panel Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-2xl">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Vendor Marketplace Commission Engine Configuration
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Agro-Dealer PRD Section 10 Unified Rate Card • Stored at <code className="bg-slate-100 text-indigo-600 px-1.5 py-0.5 rounded font-mono font-bold">superAdmin/platformConfig</code>
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={handleSaveConfig}
          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-md active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
        >
          <Zap className="w-4 h-4 text-amber-300" />
          <span>Publish Commission Rates</span>
        </button>
      </div>

      {/* Save Notification Banners */}
      {saveStatus && (
        <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl flex items-center gap-3 text-xs font-bold text-emerald-800 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{saveStatus}</span>
        </div>
      )}
      {saveError && (
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl flex items-center gap-3 text-xs font-bold text-amber-900 animate-fade-in">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
          <span>{saveError}</span>
        </div>
      )}

      {/* Exemption Policy Banner (PRD Mandatory Rule) */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-900 text-white p-5 rounded-2xl border border-emerald-700 space-y-2 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-300" />
            <h4 className="text-xs font-black uppercase tracking-wider text-emerald-200">
              PRD Mandate: Marketplace-Discovered Transactions Only
            </h4>
          </div>
          <span className="px-2.5 py-0.5 bg-emerald-800 text-emerald-200 rounded-full font-mono text-[9px] font-black uppercase border border-emerald-600">
            Rule Active
          </span>
        </div>
        <p className="text-xs text-emerald-100 leading-relaxed font-medium">
          Commissions are strictly levied on transactions discovered and settled via the Mabala Farmer Marketplace (reference prefixes <code className="text-emerald-300 font-mono">AGD-</code>, <code className="text-emerald-300 font-mono">SUPPLY-</code>, <code className="text-emerald-300 font-mono">SUB-</code>, <code className="text-emerald-300 font-mono">AGV-</code>, <code className="text-emerald-300 font-mono">INS-</code>). <strong>Walk-in over-the-counter POS sales recorded by dealers outside the Marketplace are 100% exempt (0.0% fee).</strong>
        </p>
      </div>

      {/* Module Rate Card Table */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
            <Layers className="w-4 h-4 text-indigo-600" />
            <span>Platform Module Rate Cards & Payer Toggles</span>
          </h4>
          <span className="text-[10px] font-mono text-slate-400 font-bold">5 Active Modules</span>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-2xl">
          <table className="w-full text-left text-xs bg-white text-slate-800">
            <thead className="bg-slate-50 font-black text-[9px] text-slate-400 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3.5">Module & Scope</th>
                <th className="p-3.5 text-center">Ref Prefix</th>
                <th className="p-3.5 text-center">Commission Rate (%)</th>
                <th className="p-3.5 text-center">Payer Deduct Mode</th>
                <th className="p-3.5 text-center">Walk-In POS Exempt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {(Object.values(config.modules) as ModuleCommissionSetting[]).map((mod) => (
                <tr key={mod.code} className="hover:bg-slate-50/80 transition-all">
                  <td className="p-3.5 max-w-xs">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 font-black text-[10px] rounded font-mono">
                        {mod.code}
                      </span>
                      <h5 className="font-bold text-slate-900 text-xs">{mod.name}</h5>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">{mod.description}</p>
                  </td>

                  <td className="p-3.5 text-center">
                    <span className="font-mono text-[10.5px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                      {mod.prefix}
                    </span>
                  </td>

                  <td className="p-3.5 text-center">
                    <div className="inline-flex items-center gap-1">
                      <input
                        type="number"
                        step="0.1"
                        min="0"
                        max="100"
                        value={mod.ratePercent}
                        onChange={(e) => handleModuleRateChange(mod.code, parseFloat(e.target.value) || 0)}
                        className="w-20 text-center p-1.5 bg-slate-50 border border-slate-300 rounded-lg font-mono font-black text-indigo-700 text-xs outline-none focus:border-indigo-500"
                      />
                      <span className="font-mono text-slate-500 font-bold">%</span>
                    </div>
                  </td>

                  <td className="p-3.5 text-center">
                    <select
                      value={mod.payerMode}
                      onChange={(e) => handleModulePayerChange(mod.code, e.target.value as any)}
                      className="p-1.5 bg-slate-50 border border-slate-300 rounded-lg font-bold text-[10.5px] text-slate-800 outline-none cursor-pointer focus:border-indigo-500"
                    >
                      <option value="SELLER">SELLER (Deducted at Settlement)</option>
                      <option value="BUYER">BUYER (Added at Remittance)</option>
                    </select>
                  </td>

                  <td className="p-3.5 text-center">
                    <span className="inline-flex items-center gap-1 bg-emerald-50 border border-emerald-200 text-emerald-800 text-[9.5px] font-black px-2 py-0.5 rounded-full">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      Exempt (0%)
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Global Agro-Dealer Consignment Defaults & Live Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
        {/* Consignment Global Default Override Settings */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
          <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
            <Store className="w-4 h-4 text-emerald-600" />
            <span>Agro-Dealer Consignment Default Parameters</span>
          </h4>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                Consignment Default Commission Rate (%)
              </label>
              <div className="flex gap-2">
                <input
                  type="number"
                  step="0.5"
                  value={config.agroDealerDefaultRate}
                  onChange={(e) =>
                    setConfig((prev) => ({ ...prev, agroDealerDefaultRate: Number(e.target.value) || 0 }))
                  }
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl font-mono font-black text-emerald-700 text-xs outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                Default Payer Deduct Mechanism
              </label>
              <select
                value={config.agroDealerPayerMode}
                onChange={(e) =>
                  setConfig((prev) => ({ ...prev, agroDealerPayerMode: e.target.value as any }))
                }
                className="w-full p-2.5 bg-white border border-slate-200 rounded-xl font-bold text-xs text-slate-800 outline-none cursor-pointer focus:border-emerald-500"
              >
                <option value="SELLER">SELLER: Deducted from Dealer at Monthly Settlement</option>
                <option value="BUYER">BUYER: Added to Customer Checkout Price</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                Delivery Charge Per Km ({currencySymbol})
              </label>
              <input
                type="number"
                value={config.deliveryFeePerKm}
                onChange={(e) => setConfig((prev) => ({ ...prev, deliveryFeePerKm: Number(e.target.value) || 0 }))}
                className="w-full p-2.5 bg-white border border-slate-200 rounded-xl font-mono font-black text-slate-800 text-xs outline-none focus:border-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* Live Calculation Simulator */}
        <div className="bg-indigo-950 text-white p-5 rounded-2xl border border-indigo-900 space-y-4 shadow-md">
          <div className="flex justify-between items-center">
            <h4 className="text-xs font-black uppercase tracking-wider text-indigo-300 flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-300" />
              <span>Live Settlement Calculation Simulator</span>
            </h4>
            <span className="text-[9px] font-mono text-indigo-400">Real-Time Validation</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[9.5px] font-bold uppercase text-indigo-300 block mb-1">
                Test Gross Transaction
              </label>
              <input
                type="number"
                value={simAmount}
                onChange={(e) => setSimAmount(Number(e.target.value) || 0)}
                className="w-full p-2 bg-indigo-900/80 border border-indigo-700/80 rounded-xl text-white font-mono font-bold text-xs outline-none focus:border-indigo-400"
              />
            </div>

            <div>
              <label className="text-[9.5px] font-bold uppercase text-indigo-300 block mb-1">
                Select Module
              </label>
              <select
                value={simModule}
                onChange={(e) => setSimModule(e.target.value)}
                className="w-full p-2 bg-indigo-900/80 border border-indigo-700/80 rounded-xl text-white font-bold text-xs outline-none cursor-pointer focus:border-indigo-400"
              >
                {(Object.values(config.modules) as ModuleCommissionSetting[]).map((m) => (
                  <option key={m.code} value={m.code}>
                    {m.code} ({m.ratePercent}%)
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Results Grid */}
          <div className="grid grid-cols-3 gap-2.5 pt-2 text-center font-mono">
            <div className="p-2.5 bg-indigo-900/50 rounded-xl border border-indigo-800">
              <span className="text-[9px] text-indigo-300 block uppercase font-bold">Buyer Pays</span>
              <span className="text-sm font-black text-white">
                {currencySymbol} {simBuyerTotal.toLocaleString()}
              </span>
            </div>

            <div className="p-2.5 bg-indigo-900/50 rounded-xl border border-indigo-800">
              <span className="text-[9px] text-indigo-300 block uppercase font-bold">Platform Fee</span>
              <span className="text-sm font-black text-amber-300">
                {currencySymbol} {simCommissionAmount.toLocaleString()}
              </span>
            </div>

            <div className="p-2.5 bg-indigo-900/50 rounded-xl border border-indigo-800">
              <span className="text-[9px] text-indigo-300 block uppercase font-bold">Seller Settlement</span>
              <span className="text-sm font-black text-emerald-400">
                {currencySymbol} {simSellerNet.toLocaleString()}
              </span>
            </div>
          </div>

          <div className="p-2.5 bg-indigo-900/30 rounded-xl border border-indigo-800/60 text-[10px] text-indigo-200 flex items-center justify-between">
            <span>Walk-in Over-the-counter Comparison:</span>
            <span className="font-mono font-bold text-emerald-300">
              0.00 Fee ({currencySymbol} {simAmount.toLocaleString()} Net)
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

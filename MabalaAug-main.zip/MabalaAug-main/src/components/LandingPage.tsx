import React, { useState, useEffect } from "react";
import { 
  ArrowRight, 
  Check, 
  MapPin, 
  Phone, 
  Mail, 
  Twitter, 
  Facebook, 
  Linkedin, 
  Zap, 
  Users, 
  Coins, 
  ArrowUpRight, 
  Sparkles, 
  Info, 
  X, 
  Store, 
  Warehouse, 
  ShieldCheck, 
  Building2, 
  Truck, 
  CheckCircle2, 
  BarChart3, 
  FileText, 
  Code, 
  Key, 
  QrCode, 
  RefreshCw, 
  ChevronRight, 
  CircleDollarSign, 
  Send, 
  TrendingUp, 
  Boxes, 
  Briefcase, 
  Sprout, 
  Shield, 
  Clock, 
  Award, 
  ChevronDown,
  Layers,
  CheckSquare,
  AlertTriangle,
  Database,
  Stethoscope
} from "lucide-react";
import { 
  SeedlingPlanIcon, 
  HarvesterPlanIcon, 
  EnterprisePlanIcon,
  FarmerIcon,
  WalletCreditIcon,
  FertilizerIcon,
  TractorIcon,
  CropsIcon,
  BarnIcon
} from "./IconLibrary";
import MabalaLogo from "./MabalaLogo";
import farmHeroBg from "../assets/images/farm_hero_background_1783335783584.jpg";
import { V3_PLANS, PlanDefinitionV3, SUBSCRIPTION_TERMS, calculatePlanTermPrice } from "../config/creditEngineV3";
import { getAllPlanDefinitions } from "../services/creditEngineV3Service";
import { sendEnterpriseActivationInquiry } from "../services/mabalaMailService";

export interface AdCampaign {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  externalUrl: string;
  placement: "banner" | "sidebar" | "interstitial";
  active: boolean;
}

interface LandingPageProps {
  platformPackages?: any[];
  contactDetails?: {
    email: string;
    phone: string;
    address: string;
    twitter?: string;
    facebook?: string;
    linkedin?: string;
    whatsapp?: string;
  };
  activeAds?: AdCampaign[];
  onSignUp?: (role?: string) => void;
  onSignIn?: () => void;
  onStartDemo?: () => void;
}

// Custom Friendly Stakeholder Avatars
const FarmerAvatar = () => (
  <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200/80 flex items-center justify-center text-emerald-800 shrink-0 shadow-xs relative">
    <FarmerIcon size={26} className="text-emerald-700" />
    <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px] font-black border-2 border-white">
      🌾
    </span>
  </div>
);

const AgroDealerAvatar = () => (
  <div className="w-12 h-12 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs relative">
    <Store className="w-5 h-5 text-slate-700" />
    <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px] font-black border-2 border-white">
      🏪
    </span>
  </div>
);

const SupplierAvatar = () => (
  <div className="w-12 h-12 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs relative">
    <Truck className="w-5 h-5 text-slate-700" />
    <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px] font-black border-2 border-white">
      🧪
    </span>
  </div>
);

const VetAvatar = () => (
  <div className="w-12 h-12 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs relative">
    <Stethoscope className="w-5 h-5 text-slate-700" />
    <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px] font-black border-2 border-white">
      🩺
    </span>
  </div>
);

const AgronomistAvatar = () => (
  <div className="w-12 h-12 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs relative">
    <Sprout className="w-5 h-5 text-slate-700" />
    <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px] font-black border-2 border-white">
      🌱
    </span>
  </div>
);

const BankerAvatar = () => (
  <div className="w-12 h-12 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs relative">
    <Building2 className="w-5 h-5 text-slate-700" />
    <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px] font-black border-2 border-white">
      🏦
    </span>
  </div>
);

export default function LandingPage({
  platformPackages = V3_PLANS.map(p => ({
    id: p.id,
    name: p.name,
    price: p.monthlyPriceZMW,
    credits: p.monthlyCredits,
    features: p.featuresSummary,
    featureList: p.featureList,
    isPopular: p.isPopular,
    isActive: p.isActive
  })),
  contactDetails = {
    email: "support@mabala.cloud",
    phone: "+260 978 070734",
    address: "Opp Oryx Filling Station, Mumbwa Road, Lusaka West, Zambia",
    twitter: "https://twitter.com/mabala_saas",
    facebook: "https://facebook.com/mabala_saas",
    linkedin: "https://linkedin.com/company/mabala_saas",
    whatsapp: "260978070734"
  },
  activeAds = [],
  onSignUp = () => {},
  onSignIn = () => {},
  onStartDemo = () => {}
}: LandingPageProps) {
  const [showInterstitial, setShowInterstitial] = useState(false);
  const [currentInterstitialAd, setCurrentInterstitialAd] = useState<AdCampaign | null>(null);
  const [selectedTermMonths, setSelectedTermMonths] = useState<number>(1);
  const [activeWorkflowTab, setActiveWorkflowTab] = useState<"farmers" | "dealers" | "suppliers" | "banks">("farmers");

  // API Activation Form State
  const [activationForm, setActivationForm] = useState({
    name: "",
    email: "",
    organization: "",
    phone: "",
    stakeholderType: "Bank / Financial Institution",
    region: "Zambia",
    message: ""
  });
  const [activationSubmitted, setActivationSubmitted] = useState(false);
  const [activationLoading, setActivationLoading] = useState(false);

  // Trigger interstitial on mount if active
  useEffect(() => {
    const interstitialAd = activeAds.find(ad => ad.active && ad.placement === "interstitial");
    if (interstitialAd) {
      setCurrentInterstitialAd(interstitialAd);
      const timer = setTimeout(() => setShowInterstitial(true), 800);
      return () => clearTimeout(timer);
    }
  }, [activeAds]);

  const activeBanners = activeAds.filter(ad => ad.active && ad.placement === "banner");
  const activeSidebars = activeAds.filter(ad => ad.active && ad.placement === "sidebar");

  const handleActivationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setActivationLoading(true);
    try {
      await sendEnterpriseActivationInquiry({
        name: activationForm.name,
        email: activationForm.email,
        organization: activationForm.organization,
        stakeholderType: activationForm.stakeholderType,
        phone: activationForm.phone,
        region: activationForm.region,
        message: activationForm.message
      });
    } catch (err) {
      console.warn("[LandingPage] Activation email dispatch handled:", err);
    } finally {
      setActivationLoading(false);
      setActivationSubmitted(true);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col selection:bg-emerald-500 selection:text-white" id="mabala-public-landing-page">
      
      {/* Configurable Banner Ads */}
      {activeBanners.length > 0 && (
        <div className="bg-emerald-950 text-white py-2.5 px-4 text-center text-xs font-semibold relative flex items-center justify-center gap-2 border-b border-emerald-900">
          <span className="bg-amber-400 text-slate-950 text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider font-mono">PARTNER PROMO</span>
          {activeBanners.map(ad => (
            <a 
              key={ad.id} 
              href={ad.externalUrl} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="hover:underline flex items-center gap-1 cursor-pointer"
            >
              <strong>{ad.title}</strong> — {ad.description}
              <ArrowUpRight className="w-3.5 h-3.5 inline text-emerald-300" />
            </a>
          ))}
        </div>
      )}

      {/* Navigation Bar */}
      <header className="sticky top-0 bg-white/95 backdrop-blur-md border-b border-slate-200/80 z-40 px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <MabalaLogo variant="full" theme="light" size={34} />

          <nav className="hidden lg:flex items-center gap-7 text-xs font-bold uppercase text-slate-600 tracking-wider">
            <a href="#modules" className="hover:text-emerald-600 transition-colors">Core Modules</a>
            <a href="#how-it-works" className="hover:text-emerald-600 transition-colors">How It Works</a>
            <a href="#in-kind-model" className="hover:text-emerald-600 transition-colors">In-Kind Credit</a>
            <a href="#api-integrations" className="hover:text-emerald-600 transition-colors">API & Enterprise</a>
            <a href="#pricing" className="hover:text-emerald-600 transition-colors">Pricing</a>
            <a href="#activation-form" className="hover:text-emerald-600 transition-colors">Activation</a>
          </nav>

          <div className="flex items-center gap-2.5">
            <button 
              onClick={() => onSignIn()}
              className="px-3.5 py-2 hover:bg-slate-100 text-slate-800 text-xs font-extrabold uppercase tracking-wider rounded-xl transition-all cursor-pointer"
              id="landing-signin-btn"
            >
              Sign In
            </button>
            <button 
              onClick={() => onSignUp()}
              className="px-4.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black uppercase tracking-wider rounded-xl shadow-md shadow-emerald-600/10 hover:shadow-lg transition-all cursor-pointer flex items-center gap-1.5"
              id="landing-signup-btn"
            >
              <span>Get Started</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Page Body */}
      <main className="flex-grow">
        
        {/* HERO SECTION */}
        <section className="relative overflow-hidden py-24 px-6 bg-slate-900">
          {/* Farm Hero Background Image with Reduced Brightness & Contrast */}
          <div 
            className="absolute inset-0 bg-cover bg-center brightness-[0.85] saturate-[1.1] contrast-[0.92] transition-all duration-700"
            style={{ backgroundImage: `url(${farmHeroBg})` }}
          ></div>

          {/* Soft Balanced Gradient Overlay for High Contrast Legibility */}
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-slate-900/75 to-slate-950/90 backdrop-blur-[2px]"></div>
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(16,185,129,0.2),transparent_70%)] pointer-events-none"></div>
          <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:24px_24px] opacity-30 pointer-events-none"></div>
          
          <div className="max-w-5xl mx-auto relative z-10 text-center space-y-8">
            
            {/* Top Pill Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-500/10 border border-emerald-500/30 rounded-full text-emerald-300 font-extrabold text-xs uppercase font-mono tracking-wider backdrop-blur-md shadow-inner">
              <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 animate-pulse" />
              <span>Next-Gen Agricultural Ecosystem & In-Kind Agro Credit</span>
            </div>

            {/* Main Hero Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-[1.15] max-w-4xl mx-auto">
              Run Your Farm <span className="text-emerald-400">as a Business.</span>
              <br className="hidden sm:inline" /> Access Credit in Inputs, Not Cash.
            </h1>
            
            {/* Subtitle Paragraph */}
            <p className="text-slate-300 text-sm md:text-base leading-relaxed max-w-3xl mx-auto font-medium">
              Mabala connects <strong className="text-white font-bold">Farmers, Retail Agro-Dealers, Input Suppliers, Warehouses, and Financial Institutions</strong> in one unified digital network. Digitise field operations, issue Digital Warehouse Receipts (DWR), manage consignment inventories, and unlock cashless input credit.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-2">
              <button 
                onClick={() => onSignUp()}
                className="w-full sm:w-auto px-8 py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black uppercase tracking-wider rounded-2xl shadow-xl shadow-emerald-500/25 transition-all cursor-pointer flex items-center justify-center gap-2.5 transform hover:-translate-y-0.5"
              >
                <span>Get a Farm Account</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              
              <a 
                href="#activation-form"
                className="w-full sm:w-auto px-7 py-4 bg-slate-800/90 hover:bg-slate-800 text-white border border-slate-700 text-xs font-black uppercase tracking-wider rounded-2xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer backdrop-blur-sm"
                id="landing-hero-demo-btn"
              >
                <Building2 className="w-4 h-4 text-emerald-400" />
                <span>Onboard as Agro-Dealer / Supplier</span>
              </a>

              <a 
                href="#activation-form"
                className="w-full sm:w-auto px-6 py-4 bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-extrabold uppercase tracking-wider rounded-2xl transition-all flex items-center justify-center gap-2"
              >
                <Building2 className="w-4 h-4 text-slate-400" />
                <span>Bank / Lender API</span>
              </a>
            </div>

            {/* Ecosystem 4-Card Pillar Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-10 border-t border-slate-800/80 text-left">
              
              <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all space-y-2 backdrop-blur-md group">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0">
                    <Sprout className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-black text-white block group-hover:text-emerald-400 transition-colors">Farmers</span>
                    <span className="text-[10px] text-emerald-400 font-mono font-bold">In-Kind Input Loans</span>
                  </div>
                </div>
                <p className="text-[11px] text-slate-400 font-medium leading-relaxed">
                  Digitise crop cycles, record double-entry P&L, and pledge stored produce via Digital Warehouse Receipts.
                </p>
              </div>

              <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all space-y-2 backdrop-blur-md group">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 flex items-center justify-center shrink-0">
                    <Store className="w-5 h-5 text-slate-300" />
                  </div>
                  <div>
                    <span className="text-xs font-black text-white block group-hover:text-slate-200 transition-colors">Agro-Dealers</span>
                    <span className="text-[10px] text-slate-400 font-mono font-bold">Consignment POS</span>
                  </div>
                </div>
                <p className="text-[11px] text-slate-400 font-medium leading-relaxed">
                  Real-time consignment stock decrement, zero cash disbursement risk, and automated supplier reconciliations.
                </p>
              </div>

              <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all space-y-2 backdrop-blur-md group">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 flex items-center justify-center shrink-0">
                    <Truck className="w-5 h-5 text-slate-300" />
                  </div>
                  <div>
                    <span className="text-xs font-black text-white block group-hover:text-slate-200 transition-colors">Input Suppliers</span>
                    <span className="text-[10px] text-slate-400 font-mono font-bold">Daily Remittance</span>
                  </div>
                </div>
                <p className="text-[11px] text-slate-400 font-medium leading-relaxed">
                  Monitor seed & chemical movement across retail networks with daily automated mobile money sales clearance.
                </p>
              </div>

              <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all space-y-2 backdrop-blur-md group">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 flex items-center justify-center shrink-0">
                    <Building2 className="w-5 h-5 text-slate-300" />
                  </div>
                  <div>
                    <span className="text-xs font-black text-white block group-hover:text-slate-200 transition-colors">Banks & Lenders</span>
                    <span className="text-[10px] text-slate-400 font-mono font-bold">DWR Collateral</span>
                  </div>
                </div>
                <p className="text-[11px] text-slate-400 font-medium leading-relaxed">
                  Access verified farm audit trails, soil metrics, and warehouse inventory locks to issue 100% secure loans.
                </p>
              </div>

            </div>

            {/* Featured Partner Sidebar Ads if active */}
            {activeSidebars.length > 0 && (
              <div className="pt-4 max-w-2xl mx-auto">
                <div className="bg-slate-900/80 border border-amber-500/30 rounded-2xl p-4 text-left space-y-2 backdrop-blur-md">
                  <span className="px-2 py-0.5 bg-amber-400 text-slate-950 rounded text-[9px] font-extrabold uppercase font-mono tracking-wider">
                    FEATURED ECOSYSTEM PARTNER
                  </span>
                  {activeSidebars.map(ad => (
                    <a 
                      key={ad.id} 
                      href={ad.externalUrl} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="block hover:bg-slate-800/80 p-2.5 rounded-xl transition-all"
                    >
                      <h5 className="font-extrabold text-white text-xs flex items-center gap-1.5">
                        <span>{ad.title}</span>
                        <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
                      </h5>
                      <p className="text-[11px] text-slate-300 mt-0.5">{ad.description}</p>
                    </a>
                  ))}
                </div>
              </div>
            )}

          </div>
        </section>

        {/* CORE ECOSYSTEM MODULES SHOWCASE */}
        <section id="modules" className="py-20 px-6 bg-white border-y border-slate-200">
          <div className="max-w-7xl mx-auto space-y-12">
            
            <div className="text-center max-w-3xl mx-auto space-y-3">
              <span className="px-3 py-1 bg-slate-100 text-slate-800 font-mono font-bold text-[10px] uppercase rounded-full tracking-wider border border-slate-200">
                Full-Stack Agricultural Enterprise Architecture
              </span>
              <h2 className="text-2xl md:text-3xl font-black text-slate-950 uppercase tracking-tight">
                Designed for Farmers, Dealers, Suppliers & Lenders
              </h2>
              <p className="text-slate-600 text-xs md:text-sm font-medium leading-relaxed">
                Transform raw farm production into a creditworthy business with digitized warehouse receipts, real-time dealer consignment tracking, and zero-cash-leak input loans.
              </p>
            </div>

            {/* 6 Grid Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              
              {/* Module 1 */}
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all space-y-3 group">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
                  <Sprout className="w-5 h-5 text-emerald-700" />
                </div>
                <h3 className="text-sm font-black uppercase text-slate-900 tracking-wide group-hover:text-emerald-700 transition-colors">
                  1. Farm Business Digitisation
                </h3>
                <p className="text-slate-600 text-xs leading-relaxed font-medium">
                  Run farm operations as a structured business. Calculate exact cost per acre, track field activities, record crop & livestock yields, and generate double-entry profit and loss statements.
                </p>
              </div>

              {/* Module 2 */}
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all space-y-3 group">
                <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center font-bold">
                  <Warehouse className="w-5 h-5 text-slate-700" />
                </div>
                <h3 className="text-sm font-black uppercase text-slate-900 tracking-wide group-hover:text-emerald-700 transition-colors">
                  2. Warehouses & Digital Receipts (DWR)
                </h3>
                <p className="text-slate-600 text-xs leading-relaxed font-medium">
                  Manage certified and on-farm warehouses. Issue electronic Digital Warehouse Receipts (DWR) for deposited produce, log post-harvest losses, and pledge crop collateral for loan offsets.
                </p>
              </div>

              {/* Module 3 */}
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all space-y-3 group">
                <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center font-bold">
                  <Store className="w-5 h-5 text-slate-700" />
                </div>
                <h3 className="text-sm font-black uppercase text-slate-900 tracking-wide group-hover:text-emerald-700 transition-colors">
                  3. Mabala Agro-Dealer Consignment Hub
                </h3>
                <p className="text-slate-600 text-xs leading-relaxed font-medium">
                  Real-time consignment inventory management for retail agro-dealers. Automate supplier reconciliations, manage daily sales, and execute Farm Balance remittances seamlessly.
                </p>
              </div>

              {/* Module 4 */}
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all space-y-3 group">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
                  <Coins className="w-5 h-5 text-emerald-700" />
                </div>
                <h3 className="text-sm font-black uppercase text-slate-900 tracking-wide group-hover:text-emerald-700 transition-colors">
                  4. In-Kind Stock Input Credit
                </h3>
                <p className="text-slate-600 text-xs leading-relaxed font-medium">
                  Credit is issued purely as an in-kind stock decrement directly from Agro-Dealer inventory. No cash is disbursed! Guarantees 100% input utilization with zero capital misallocation.
                </p>
              </div>

              {/* Module 5 */}
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all space-y-3 group">
                <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center font-bold">
                  <Truck className="w-5 h-5 text-slate-700" />
                </div>
                <h3 className="text-sm font-black uppercase text-slate-900 tracking-wide group-hover:text-emerald-700 transition-colors">
                  5. Seed & Chemical Supplier Network
                </h3>
                <p className="text-slate-600 text-xs leading-relaxed font-medium">
                  Seed, chemical, and fertiliser suppliers issue stock to agro-dealers on credit lines, track daily sales in real time across dealer networks, and receive automated daily remittances.
                </p>
              </div>

              {/* Module 6 */}
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all space-y-3 group">
                <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center font-bold">
                  <Building2 className="w-5 h-5 text-slate-700" />
                </div>
                <h3 className="text-sm font-black uppercase text-slate-900 tracking-wide group-hover:text-emerald-700 transition-colors">
                  6. Bank & Lender Credit Risk Intelligence
                </h3>
                <p className="text-slate-600 text-xs leading-relaxed font-medium">
                  Commercial banks and financial institutions gain complete, verified data visibility into farmer yield history, soil metrics, and DWR collateral to make informed lending decisions.
                </p>
              </div>

            </div>
          </div>
        </section>

        {/* INTERACTIVE WORKFLOW SECTION (HOW IT WORKS WITH AVATARS) */}
        <section id="how-it-works" className="py-20 px-6 bg-slate-50/70 border-b border-slate-200">
          <div className="max-w-7xl mx-auto space-y-10">
            
            <div className="text-center max-w-2xl mx-auto space-y-2">
              <span className="px-3 py-1 bg-slate-100 text-slate-800 font-mono font-bold text-[10px] uppercase rounded-full tracking-wider border border-slate-200">
                End-to-End Stakeholder Journeys
              </span>
              <h2 className="text-2xl md:text-3xl font-black text-slate-950 uppercase tracking-tight">
                How It Works for Every Partner
              </h2>
              <p className="text-slate-600 text-xs font-medium">
                Select a stakeholder role to explore how Mabala streamlines operations and eliminates default risks.
              </p>
            </div>

            {/* Role Tab Navigation with Friendly Avatars */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-4xl mx-auto">
              <button
                onClick={() => setActiveWorkflowTab("farmers")}
                className={`p-3.5 rounded-2xl border transition-all flex items-center gap-3 cursor-pointer text-left ${
                  activeWorkflowTab === "farmers"
                    ? "bg-white border-emerald-500 ring-2 ring-emerald-500/20 shadow-md"
                    : "bg-slate-50/80 border-slate-200 hover:bg-white"
                }`}
              >
                <FarmerAvatar />
                <div>
                  <span className="text-xs font-black text-slate-900 block">Farmers</span>
                  <span className="text-[10px] text-slate-500 font-semibold">Digitise & Credit</span>
                </div>
              </button>

              <button
                onClick={() => setActiveWorkflowTab("dealers")}
                className={`p-3.5 rounded-2xl border transition-all flex items-center gap-3 cursor-pointer text-left ${
                  activeWorkflowTab === "dealers"
                    ? "bg-white border-slate-900 ring-2 ring-slate-900/10 shadow-md"
                    : "bg-slate-50/80 border-slate-200 hover:bg-white"
                }`}
              >
                <AgroDealerAvatar />
                <div>
                  <span className="text-xs font-black text-slate-900 block">Agro-Dealers</span>
                  <span className="text-[10px] text-slate-500 font-semibold">Consignment Hub</span>
                </div>
              </button>

              <button
                onClick={() => setActiveWorkflowTab("suppliers")}
                className={`p-3.5 rounded-2xl border transition-all flex items-center gap-3 cursor-pointer text-left ${
                  activeWorkflowTab === "suppliers"
                    ? "bg-white border-slate-900 ring-2 ring-slate-900/10 shadow-md"
                    : "bg-slate-50/80 border-slate-200 hover:bg-white"
                }`}
              >
                <SupplierAvatar />
                <div>
                  <span className="text-xs font-black text-slate-900 block">Input Suppliers</span>
                  <span className="text-[10px] text-slate-500 font-semibold">Daily Sales Sync</span>
                </div>
              </button>

              <button
                onClick={() => setActiveWorkflowTab("banks")}
                className={`p-3.5 rounded-2xl border transition-all flex items-center gap-3 cursor-pointer text-left ${
                  activeWorkflowTab === "banks"
                    ? "bg-white border-slate-900 ring-2 ring-slate-900/10 shadow-md"
                    : "bg-slate-50/80 border-slate-200 hover:bg-white"
                }`}
              >
                <BankerAvatar />
                <div>
                  <span className="text-xs font-black text-slate-900 block">Banks & Lenders</span>
                  <span className="text-[10px] text-slate-500 font-semibold">Informed Credit</span>
                </div>
              </button>
            </div>

            {/* Workflow Step Cards Content */}
            <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-xl max-w-5xl mx-auto animate-fade-in space-y-6">
              
              {/* Farmers Workflow */}
              {activeWorkflowTab === "farmers" && (
                <div className="space-y-6">
                  <div className="flex items-center gap-4 pb-4 border-b border-slate-100">
                    <FarmerAvatar />
                    <div>
                      <h3 className="text-base font-black text-slate-900 uppercase tracking-tight">
                        Farmer Workflow: From Field Logging to Collateralized Credit
                      </h3>
                      <p className="text-xs text-slate-500 font-medium">
                        Digitise farm records, request input credit, deposit harvest into certified warehouses, and issue Digital Warehouse Receipts.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-xs font-black font-mono">1</span>
                      <h4 className="text-xs font-black text-slate-900">Digitise Operations</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Record fields, soil tests, crops, livestock, and expenses in Mabala to establish a verified farm credit profile.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-xs font-black font-mono">2</span>
                      <h4 className="text-xs font-black text-slate-900">Request In-Kind Credit</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Apply for seasonal seed, fertilizer, or crop protection packages. Pre-approved based on data, zero cash involved.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-xs font-black font-mono">3</span>
                      <h4 className="text-xs font-black text-slate-900">Collect at Agro-Dealer</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Scan redemption QR voucher at any local Mabala Agro-Dealer to collect physical input stock directly.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-xs font-black font-mono">4</span>
                      <h4 className="text-xs font-black text-slate-900">Warehouse & Pledge DWR</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Deposit harvest in certified warehouses, receive Electronic DWRs, and pledge crop collateral to offset loans smoothly.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Agro-Dealers Workflow */}
              {activeWorkflowTab === "dealers" && (
                <div className="space-y-6">
                  <div className="flex items-center gap-4 pb-4 border-b border-slate-100">
                    <AgroDealerAvatar />
                    <div>
                      <h3 className="text-base font-black text-slate-900 uppercase tracking-tight">
                        Agro-Dealer Workflow: Consignment Inventory & In-Kind Dispensing
                      </h3>
                      <p className="text-xs text-slate-500 font-medium">
                        Stock retail stores via supplier consignment, scan farmer vouchers, track daily retail sales, and auto-remit funds.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">1</span>
                      <h4 className="text-xs font-black text-slate-900">Receive Consignment</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Receive seeds, fertilisers, and chemicals from top suppliers on consignment credit lines without upfront capital outlay.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">2</span>
                      <h4 className="text-xs font-black text-slate-900">Dispense In-Kind Stock</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Scan farmer input redemption vouchers at retail POS. Inventory decrements automatically in real time.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">3</span>
                      <h4 className="text-xs font-black text-slate-900">Track Sales & Mobile Money</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Record cash, mobile money (Airtel, MTN, Zamtel), and credit sales with instant automated receipt generation.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">4</span>
                      <h4 className="text-xs font-black text-slate-900">Auto Reconciliation</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Farm Balance automatically reconciles supplier obligations, dealer margins, and mobile money payouts daily.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Input Suppliers Workflow */}
              {activeWorkflowTab === "suppliers" && (
                <div className="space-y-6">
                  <div className="flex items-center gap-4 pb-4 border-b border-slate-100">
                    <SupplierAvatar />
                    <div>
                      <h3 className="text-base font-black text-slate-900 uppercase tracking-tight">
                        Supplier Workflow: Consignment Oversight & Daily Automated Remittances
                      </h3>
                      <p className="text-xs text-slate-500 font-medium">
                        Allocate stock to retail agro-dealers, monitor live store balances, track sales, and receive daily bank/MoMo payments.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">1</span>
                      <h4 className="text-xs font-black text-slate-900">Issue Consignment Stock</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Issue seeds, chemicals, and fertilizers to verified agro-dealer hubs with customized credit caps.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">2</span>
                      <h4 className="text-xs font-black text-slate-900">Real-Time Inventory Sync</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Monitor live store stock depletion, batch expiration dates, and sales velocity across all retail outlets.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">3</span>
                      <h4 className="text-xs font-black text-slate-900">Daily Sales Tracking</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        View itemized daily sales reports generated instantly as dealers sell or redeem inputs to farmers.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">4</span>
                      <h4 className="text-xs font-black text-slate-900">Automated Daily Payouts</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Receive daily automated payouts directly into bank or corporate mobile money accounts to minimize default risk.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Banks & Lenders Workflow */}
              {activeWorkflowTab === "banks" && (
                <div className="space-y-6">
                  <div className="flex items-center gap-4 pb-4 border-b border-slate-100">
                    <BankerAvatar />
                    <div>
                      <h3 className="text-base font-black text-slate-900 uppercase tracking-tight">
                        Bank & Lender Workflow: Informed Decisions & Collateralized Lending
                      </h3>
                      <p className="text-xs text-slate-500 font-medium">
                        Access verified farmer yield history, evaluate credit scores, approve in-kind loans, and pledge Digital Warehouse Receipts.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">1</span>
                      <h4 className="text-xs font-black text-slate-900">Access Farm Data</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Review verified historical yield logs, field acreage, soil health, and past repayment performance.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">2</span>
                      <h4 className="text-xs font-black text-slate-900">Evaluate Credit Score</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Mabala AI calculates data-backed creditworthiness scores without expensive manual field audits.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">3</span>
                      <h4 className="text-xs font-black text-slate-900">Approve In-Kind Loan</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Disburse input vouchers directly redeemable at agro-dealers (0% cash leak, 100% applied to crop production).
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-black font-mono">4</span>
                      <h4 className="text-xs font-black text-slate-900">DWR Collateral Offset</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        Pledge Electronic Digital Warehouse Receipts (DWR) as crop collateral to automatically settle loan balances upon harvest sale.
                      </p>
                    </div>
                  </div>
                </div>
              )}

            </div>
          </div>
        </section>

        {/* IN-KIND CREDIT VS CASH DISBURSEMENT CALLOUT BOX */}
        <section id="in-kind-model" className="py-16 px-6 bg-white border-b border-slate-200">
          <div className="max-w-6xl mx-auto bg-gradient-to-r from-slate-900 via-slate-950 to-emerald-950 rounded-3xl p-8 md:p-12 text-white shadow-2xl space-y-8 relative overflow-hidden">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 border-b border-slate-800 pb-6">
              <div>
                <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 font-mono font-extrabold text-[10px] uppercase rounded-full tracking-wider">
                  Mabala Credit Innovation Standard
                </span>
                <h3 className="text-2xl md:text-3xl font-black tracking-tight mt-2 text-white">
                  Why In-Kind Input Credit Beats Cash Disbursement
                </h3>
              </div>
              <div className="bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 px-4 py-2 rounded-2xl font-mono text-xs font-bold shrink-0">
                0% Cash Diversion Risk
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs leading-relaxed">
              {/* Traditional Cash Loans */}
              <div className="bg-slate-900/80 p-6 rounded-2xl border border-rose-500/30 space-y-3">
                <div className="flex items-center gap-2 text-rose-400 font-extrabold uppercase text-xs">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>Traditional Cash Disbursed Loans</span>
                </div>
                <ul className="space-y-2 text-slate-300 font-medium">
                  <li className="flex items-start gap-2">
                    <span className="text-rose-400 font-bold">✕</span>
                    <span>High risk of cash diversion for personal or non-farm expenses.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-rose-400 font-bold">✕</span>
                    <span>No verification of whether inputs (seed/fertilizer) were actually purchased.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-rose-400 font-bold">✕</span>
                    <span>High default rates leading to prohibitive interest rates and credit blacklisting.</span>
                  </li>
                </ul>
              </div>

              {/* Mabala In-Kind Credit */}
              <div className="bg-slate-900/80 p-6 rounded-2xl border border-emerald-500/40 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 font-extrabold uppercase text-xs">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Mabala In-Kind Input Credit Engine</span>
                </div>
                <ul className="space-y-2 text-slate-100 font-medium">
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span>Credit issued purely as an in-kind stock decrement from Agro-Dealer inventory.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span>Guarantees 100% of the loan is applied directly to high-quality seeds & fertilizers.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span>Secured against Electronic Digital Warehouse Receipts (DWR) and automated mobile money deductions.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* API INTEGRATIONS & ENTERPRISE CODE SHOWCASE */}
        <section id="api-integrations" className="py-20 px-6 bg-slate-50 border-b border-slate-200">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-6 space-y-6">
              <span className="px-3 py-1 bg-slate-100 text-slate-800 font-mono font-bold text-[10px] uppercase rounded-full tracking-wider border border-slate-200">
                Developer & Enterprise API Suite
              </span>
              <h2 className="text-2xl md:text-3xl font-black text-slate-950 uppercase tracking-tight">
                Integrate Mabala Core into Your Banking or ERP System
              </h2>
              <p className="text-slate-600 text-xs md:text-sm font-medium leading-relaxed">
                Connect your core banking software, ERP, mobile wallet provider, or insurance platform using our secure REST and Webhook APIs. Real-time DWR verification, credit score pulls, and consignment inventory webhooks.
              </p>

              <div className="space-y-3 text-xs font-semibold">
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200">
                  <Code className="w-4 h-4 text-slate-700 shrink-0" />
                  <span className="text-slate-800">RESTful Endpoints & Webhooks for Real-Time Event Sync</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200">
                  <Key className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="text-slate-800">OAuth2 Authentication & Granular Scoped API Tokens</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200">
                  <QrCode className="w-4 h-4 text-slate-700 shrink-0" />
                  <span className="text-slate-800">Instant Electronic DWR Receipt QR Verification</span>
                </div>
              </div>
            </div>

            {/* Code Payload Window */}
            <div className="lg:col-span-6 bg-slate-950 text-emerald-400 rounded-3xl p-6 font-mono text-xs shadow-2xl border border-slate-800 space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-slate-800 text-[10px] text-slate-400">
                <span className="font-bold uppercase text-slate-200">POST /api/v1/dwr/verify-and-pledge</span>
                <span className="bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded font-extrabold">200 OK</span>
              </div>

              <pre className="text-[11px] leading-relaxed text-slate-300 overflow-x-auto p-2">
{`{
  "receipt_id": "DWR-2026-90812",
  "warehouse": "Lusaka Certified Grain Depot #4",
  "depositor_farmer_id": "FARMER-88412",
  "commodity": "Yellow Maize (Grade 1)",
  "weight_mt": 50.0,
  "market_value_zmw": 145000.00,
  "credit_pledge_status": "PLEDGED_COLLATERAL",
  "approved_input_credit_cap": 87000.00,
  "agro_dealer_redemption_code": "RED-90812-MABALA"
}`}
              </pre>

              <div className="pt-2 text-[10px] text-slate-400 flex items-center justify-between border-t border-slate-800">
                <span>SDKs: Node.js • Python • Java • C#</span>
                <a href="#activation-form" className="text-emerald-400 hover:underline font-bold flex items-center gap-1">
                  <span>Request API Key Activation</span>
                  <ArrowRight className="w-3 h-3" />
                </a>
              </div>
            </div>

          </div>
        </section>

        {/* PRICING SECTION */}
        <section id="pricing" className="py-20 px-6 bg-slate-50/50 border-b border-slate-200">
          <div className="max-w-7xl mx-auto space-y-12">
            
            <div className="text-center max-w-2xl mx-auto space-y-3">
              <span className="px-3 py-1 bg-emerald-100 text-emerald-800 font-mono font-bold text-[10px] uppercase rounded-full tracking-wider">
                Transparent Platform Subscriptions
              </span>
              <h2 className="text-2xl md:text-3xl font-black text-slate-950 uppercase tracking-tight">
                Simple Plans for Every Operation Size
              </h2>
              <p className="text-slate-600 text-xs font-medium">
                Choose the connection tier that fits your farm, retail agribusiness, or veterinary clinic.
              </p>

              {/* Term Selector (Monthly, 3 Months, 6 Months, Yearly) */}
              <div className="inline-flex items-center p-1.5 bg-slate-100/90 rounded-2xl gap-1 border border-slate-200 shadow-inner mt-3">
                {SUBSCRIPTION_TERMS.map((term) => {
                  const isSelected = selectedTermMonths === term.months;
                  return (
                    <button
                      key={term.months}
                      type="button"
                      onClick={() => setSelectedTermMonths(term.months)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                        isSelected
                          ? "bg-white text-slate-900 shadow-sm font-extrabold"
                          : "text-slate-600 hover:text-slate-900 hover:bg-white/60"
                      }`}
                    >
                      <span>{term.label}</span>
                      {term.badge && (
                        <span className="bg-emerald-600 text-white text-[9px] px-1.5 py-0.5 rounded-md font-black tracking-tight uppercase">
                          {term.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Packages Grid - v3.0 4-Tier Public Layout */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
              {getAllPlanDefinitions().filter(p => p.showOnMarketingPage).map((plan) => {
                const isPopular = plan.tierKey === "growth";
                const isEnterprise = plan.tierKey === "enterprise";
                const isSeeding = plan.tierKey === "seeding";

                const calc = calculatePlanTermPrice(plan, selectedTermMonths);

                return (
                  <div 
                    key={plan.id}
                    className={`bg-white rounded-3xl p-6 border flex flex-col justify-between space-y-6 relative transition-all duration-300 ${
                      isPopular 
                        ? "border-emerald-500 ring-2 ring-emerald-500/20 shadow-lg" 
                        : isEnterprise
                        ? "border-slate-300 shadow-md hover:border-slate-400"
                        : "border-slate-200 hover:border-slate-300 hover:shadow-md"
                    }`}
                  >
                    {isPopular && (
                      <span className="absolute top-0 right-6 transform -translate-y-1/2 bg-emerald-600 text-white font-bold text-[9px] uppercase tracking-wider font-mono py-1 px-3 rounded-full shadow-sm">
                        Most Popular
                      </span>
                    )}
                    {isEnterprise && (
                      <span className="absolute top-0 right-6 transform -translate-y-1/2 bg-slate-900 text-white font-bold text-[9px] uppercase tracking-wider font-mono py-1 px-3 rounded-full shadow-sm">
                        Full Advisory Suite
                      </span>
                    )}

                    <div className="space-y-4">
                      <div className="space-y-1">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold mb-2 ${
                          isPopular ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-800"
                        }`}>
                          {isEnterprise ? <EnterprisePlanIcon size={26} /> : isSeeding ? <SeedlingPlanIcon size={26} /> : <HarvesterPlanIcon size={26} />}
                        </div>
                        <h3 className="text-base font-extrabold text-slate-900">{plan.name}</h3>
                        <p className="text-xs text-slate-500 font-medium leading-relaxed min-h-[36px]">
                          {plan.featuresSummary}
                        </p>
                      </div>

                      <div className="py-3 border-y border-slate-100">
                        <div className="flex flex-col">
                          <div className="flex items-baseline gap-1">
                            {isSeeding ? (
                              <>
                                <span className="text-2xl font-black text-slate-950">ZMW 0</span>
                                <span className="text-slate-400 text-[10px] font-bold uppercase">/free to start</span>
                              </>
                            ) : (
                              <>
                                <span className="text-2xl font-black text-slate-950 transition-all duration-300">
                                  ZMW {calc.totalPriceZMW.toLocaleString()}
                                </span>
                                <span className="text-slate-400 text-[10px] font-bold uppercase">
                                  {selectedTermMonths === 1 ? "/month" : selectedTermMonths === 12 ? "/year" : `/${selectedTermMonths} mo upfront`}
                                </span>
                              </>
                            )}
                          </div>
                          
                          {/* Savings or Term Subtext */}
                          {!isSeeding && (
                            <div className="mt-1 flex items-center gap-1.5 min-h-[18px]">
                              {selectedTermMonths === 12 && calc.savingsLabel ? (
                                <span className="text-[10px] font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                                  {calc.savingsLabel} ({calc.discountPercent}% off)
                                </span>
                              ) : selectedTermMonths > 1 ? (
                                <span className="text-[10px] font-semibold text-slate-500">
                                  ZMW {plan.monthlyPriceZMW.toLocaleString()}/mo billed upfront
                                </span>
                              ) : (
                                <span className="text-[10px] font-semibold text-slate-400">
                                  Billed monthly · Cancel or upgrade anytime
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="space-y-2 text-xs text-slate-600 font-medium">
                        <div className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span className="font-semibold text-slate-800">
                            {isSeeding 
                              ? "60 One-Time Welcome Credits" 
                              : selectedTermMonths > 1 
                              ? `${calc.totalCredits.toLocaleString()} Total Credits (${plan.monthlyCredits.toLocaleString()}/mo)` 
                              : `${plan.monthlyCredits.toLocaleString()} Write Credits / Month`}
                          </span>
                        </div>

                        {!isSeeding && (
                          <div className="flex items-center gap-2">
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>Credit Rollover Retained</span>
                          </div>
                        )}

                        <div className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{isSeeding ? "Cloud Ledger & Receipt Generation" : "Full Double-Entry Farm & Dealer Ledger"}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{isSeeding ? "Vendor & Marketplace Access" : "In-Kind Input Credit & Consignment Portal"}</span>
                        </div>

                        {/* Agronomist Visit Highlight */}
                        {plan.advisoryVisitsIncluded && plan.advisoryVisitsIncluded.agronomist > 0 && (
                          <div className="flex items-center gap-2 text-emerald-700 font-bold bg-emerald-50/80 p-1.5 rounded-lg border border-emerald-200/60">
                            <Sprout className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{plan.advisoryVisitsIncluded.agronomist} Free Agronomist Visit / Month</span>
                          </div>
                        )}

                        {/* Vet Visit Highlight for Enterprise */}
                        {plan.advisoryVisitsIncluded && plan.advisoryVisitsIncluded.veterinary > 0 && (
                          <div className="flex items-center gap-2 text-slate-800 font-bold bg-slate-100 p-1.5 rounded-lg border border-slate-200">
                            <Stethoscope className="w-3.5 h-3.5 text-slate-700 shrink-0" />
                            <span>{plan.advisoryVisitsIncluded.veterinary} Free Vet Visits / Month</span>
                          </div>
                        )}

                        <div className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>Mobile Money Payment Integration</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => onSignUp()}
                      className={`w-full py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer shadow-xs ${
                        isPopular
                          ? "bg-emerald-600 hover:bg-emerald-500 text-white"
                          : isEnterprise
                          ? "bg-slate-900 hover:bg-slate-800 text-white"
                          : isSeeding
                          ? "bg-slate-100 hover:bg-slate-200 text-slate-900 border border-slate-200"
                          : "bg-slate-900 hover:bg-slate-800 text-white"
                      }`}
                    >
                      Get Started
                    </button>
                  </div>
                );
              })}
            </div>

            {/* DEDICATED STAKEHOLDER SECTIONS (Section 3.4 - 3.7) */}
            <div className="pt-8 border-t border-slate-200 space-y-6">
              <div className="text-center max-w-xl mx-auto space-y-1">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight">
                  Tailored Access for Every Agricultural Stakeholder
                </h3>
                <p className="text-slate-500 text-xs font-medium">
                  Whether you supply inputs, provide clinical vet care, or offer agronomy advisory.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                {/* 3.4 Agro Dealer Section */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-slate-300 shadow-xs flex flex-col justify-between space-y-4 transition-all hover:shadow-md">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <AgroDealerAvatar />
                      <div>
                        <h4 className="text-sm font-extrabold text-slate-900">Are you an Agro Dealer?</h4>
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Retail & Consignments</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 font-medium leading-relaxed">
                      Sign up free and get 60 welcome credits; subscribe to Monthly, Growth, or Enterprise when you're ready to scale — same plans and prices as farmers.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSignUp("agro_dealer")}
                    className="w-full py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <span>Register as an Agro Dealer</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* 3.5 Supplier Section */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-slate-300 shadow-xs flex flex-col justify-between space-y-4 transition-all hover:shadow-md">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <SupplierAvatar />
                      <div>
                        <h4 className="text-sm font-extrabold text-slate-900">Are you a Supplier?</h4>
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Zero Subscription Fee</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 font-medium leading-relaxed">
                      Onboarding is free; pay only a small fee each time you access a report — no subscription required.
                    </p>
                    <div className="p-2 bg-slate-50 rounded-lg border border-slate-200 text-[10px] font-semibold text-slate-600">
                      No monthly subscription fee · Per-report access via Lipila
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSignUp("supplier")}
                    className="w-full py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <span>Register as a Supplier</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* 3.6 Vet Practitioner Section */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-slate-300 shadow-xs flex flex-col justify-between space-y-4 transition-all hover:shadow-md">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <VetAvatar />
                      <div>
                        <h4 className="text-sm font-extrabold text-slate-900">Are you a Vet Practitioner?</h4>
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Livestock & Clinical Suite</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 font-medium leading-relaxed">
                      Sign up free and get 60 welcome credits; access Monthly, Growth, or Enterprise on the same plans and prices as farmers.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSignUp("vet")}
                    className="w-full py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <span>Register as a Vet Practitioner</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* 3.7 Agronomist Section */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-slate-300 shadow-xs flex flex-col justify-between space-y-4 transition-all hover:shadow-md">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <AgronomistAvatar />
                      <div>
                        <h4 className="text-sm font-extrabold text-slate-900">Are you an Agronomist?</h4>
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Advisory Directory</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 font-medium leading-relaxed">
                      Onboarding is free, always — no subscription, no per-report fee. Offer your field advisory visits across the nation.
                    </p>
                    <div className="p-2 bg-emerald-50/60 rounded-lg border border-emerald-100 text-[10px] font-semibold text-emerald-800">
                      100% Free Onboarding & Profile Listing
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSignUp("agronomist")}
                    className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <span>Register as an Agronomist</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* ACCOUNT ACTIVATION & ENTERPRISE CONTACT FORM */}
        <section id="activation-form" className="py-20 px-6 bg-slate-50 border-b border-slate-200">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 font-sans">
            
            {/* Left Contact Coordinates */}
            <div className="lg:col-span-5 space-y-6 text-left">
              <span className="px-3 py-1 bg-slate-100 text-slate-800 font-mono font-bold text-[10px] uppercase rounded-full tracking-wider border border-slate-200">
                Partner & Enterprise Activation
              </span>
              <h2 className="text-2xl md:text-3xl font-black text-slate-950 uppercase tracking-tight">
                Request Account Activation or API Keys
              </h2>
              <p className="text-slate-600 text-xs font-medium leading-relaxed">
                Are you an Agro-Dealer, Seed/Chemical Supplier, Commercial Bank, Microfinance Institution, or Large Cooperative? Fill out the activation form to get in touch with our enterprise sales and onboarding team.
              </p>

              <div className="space-y-4 pt-4 text-xs font-semibold">
                <div className="flex gap-3 items-center">
                  <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center border text-slate-500 shrink-0">
                    <Mail className="w-4 h-4 text-emerald-600" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase text-slate-400 block font-bold">Email Enterprise Team</span>
                    <a href="mailto:support@mabala.cloud" className="text-slate-900 font-bold hover:underline">support@mabala.cloud</a>
                  </div>
                </div>

                <div className="flex gap-3 items-center">
                  <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center border text-slate-500 shrink-0">
                    <Phone className="w-4 h-4 text-emerald-600" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase text-slate-400 block font-bold">Phone / WhatsApp Line</span>
                    <a href={`tel:${contactDetails.phone}`} className="text-slate-900 hover:underline">{contactDetails.phone}</a>
                  </div>
                </div>

                <div className="flex gap-3 items-center">
                  <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center border text-slate-500 shrink-0">
                    <MapPin className="w-4 h-4 text-emerald-600" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase text-slate-400 block font-bold">Physical Headquarters</span>
                    <span className="text-slate-900">{contactDetails.address}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Activation Form */}
            <div className="lg:col-span-7 bg-white rounded-3xl p-8 border border-slate-200 shadow-xl">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider pb-3 border-b mb-6 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-slate-800" />
                <span>Enterprise Activation & Sales Inquiry Form</span>
              </h3>

              {activationSubmitted ? (
                <div className="p-8 bg-emerald-50 rounded-2xl border border-emerald-200 text-center space-y-4 animate-fade-in">
                  <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                  <h4 className="text-base font-black text-slate-900">Activation Request Delivered!</h4>
                  <p className="text-xs text-slate-600 font-medium max-w-md mx-auto">
                    Thank you! Your request has been transmitted and delivered to <strong>support@mabala.cloud</strong>. Our Enterprise Solutions Team will contact <strong>{activationForm.email}</strong> within 24 hours to guide account activation and credentials.
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                    <a
                      href={`mailto:support@mabala.cloud?subject=Enterprise Activation Inquiry - ${encodeURIComponent(activationForm.organization || activationForm.name)}&body=Name: ${encodeURIComponent(activationForm.name)}%0AEmail: ${encodeURIComponent(activationForm.email)}%0AOrganization: ${encodeURIComponent(activationForm.organization)}%0AType: ${encodeURIComponent(activationForm.stakeholderType)}%0APhone: ${encodeURIComponent(activationForm.phone)}%0ARegion: ${encodeURIComponent(activationForm.region)}%0AMessage: ${encodeURIComponent(activationForm.message)}`}
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5"
                    >
                      <Mail className="w-3.5 h-3.5" />
                      <span>Open Direct Email Client</span>
                    </a>
                    <button
                      onClick={() => {
                        setActivationSubmitted(false);
                        setActivationForm({ name: "", email: "", organization: "", phone: "", stakeholderType: "Bank / Financial Institution", region: "Zambia", message: "" });
                      }}
                      className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold"
                    >
                      Send Another Request
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleActivationSubmit} className="space-y-4 text-xs font-semibold">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] uppercase text-slate-500 font-extrabold block pb-1">Your Full Name *</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Samuel Mulenga" 
                        value={activationForm.name}
                        onChange={e => setActivationForm({ ...activationForm, name: e.target.value })}
                        required 
                        className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-slate-50 focus:bg-white" 
                      />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase text-slate-500 font-extrabold block pb-1">Work Email Address *</label>
                      <input 
                        type="email" 
                        placeholder="e.g. s.mulenga@zanaco.co.zm" 
                        value={activationForm.email}
                        onChange={e => setActivationForm({ ...activationForm, email: e.target.value })}
                        required 
                        className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-slate-50 focus:bg-white" 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] uppercase text-slate-500 font-extrabold block pb-1">Organization Name *</label>
                      <input 
                        type="text" 
                        placeholder="e.g. ZANACO Agri-Desk / SeedCo Zambia" 
                        value={activationForm.organization}
                        onChange={e => setActivationForm({ ...activationForm, organization: e.target.value })}
                        required 
                        className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-slate-50 focus:bg-white" 
                      />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase text-slate-500 font-extrabold block pb-1">Stakeholder Category *</label>
                      <select
                        value={activationForm.stakeholderType}
                        onChange={e => setActivationForm({ ...activationForm, stakeholderType: e.target.value })}
                        className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-slate-50 focus:bg-white font-bold text-slate-800"
                      >
                        <option value="Bank / Financial Institution">Bank / Financial Institution (Lender)</option>
                        <option value="Input Supplier / Manufacturer">Seed, Chemical or Fertilizer Supplier</option>
                        <option value="Agro-Dealer Hub">Retail Agro-Dealer Hub</option>
                        <option value="Cooperative / Farmer Association">Commercial Cooperative / Outgrower</option>
                        <option value="Developer / System Integrator">Developer / API Integrator</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] uppercase text-slate-500 font-extrabold block pb-1">Phone Number *</label>
                      <input 
                        type="text" 
                        placeholder="e.g. +260 977 123456" 
                        value={activationForm.phone}
                        onChange={e => setActivationForm({ ...activationForm, phone: e.target.value })}
                        required 
                        className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-slate-50 focus:bg-white font-mono" 
                      />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase text-slate-500 font-extrabold block pb-1">Operating Region / Province</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Lusaka / Copperbelt / Central Province" 
                        value={activationForm.region}
                        onChange={e => setActivationForm({ ...activationForm, region: e.target.value })}
                        className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-slate-50 focus:bg-white" 
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] uppercase text-slate-500 font-extrabold block pb-1">Activation Scope & Requirements</label>
                    <textarea 
                      placeholder="Specify your expected farmer headcount, loan volume, or API integration goals..." 
                      rows={3} 
                      value={activationForm.message}
                      onChange={e => setActivationForm({ ...activationForm, message: e.target.value })}
                      required 
                      className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-slate-50 focus:bg-white" 
                    />
                  </div>

                  <button 
                    type="submit" 
                    disabled={activationLoading}
                    className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl uppercase tracking-widest font-black text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    {activationLoading ? (
                      <span>Transmitting Request...</span>
                    ) : (
                      <>
                        <span>Submit Account Activation Request</span>
                        <Send className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>

          </div>
        </section>

      </main>

      {/* FOOTER */}
      <footer className="bg-slate-950 text-white py-12 px-6 border-t border-slate-900 font-sans">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          
          <div className="space-y-2 text-center md:text-left">
            <div className="flex items-center gap-3 justify-center md:justify-start">
              <div className="w-7 h-7 bg-emerald-500 rounded-lg flex items-center justify-center font-extrabold text-slate-950 text-sm">
                M
              </div>
              <span className="font-extrabold tracking-tight text-white uppercase text-xs">Mabala Ecosystem SaaS Platform</span>
            </div>
            
            <p className="text-[10px] text-slate-400 mt-2 font-mono">
              Mabala © 2026 · Built by Deep Valley Farms for African Farmers
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            <a href="/privacy-policy.html" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors">Privacy Policy</a>
            <a href="/terms-of-service.html" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors">Terms of Service</a>
          </div>

          {/* Social icons */}
          <div className="flex items-center gap-3">
            {contactDetails.twitter && (
              <a href={contactDetails.twitter} target="_blank" rel="noopener noreferrer" className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700 text-slate-400 hover:text-emerald-400 hover:border-emerald-500 transition-all cursor-pointer" title="Twitter Link">
                <Twitter className="w-3.5 h-3.5" />
              </a>
            )}
            {contactDetails.facebook && (
              <a href={contactDetails.facebook} target="_blank" rel="noopener noreferrer" className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700 text-slate-400 hover:text-emerald-400 hover:border-emerald-500 transition-all cursor-pointer" title="Facebook Link">
                <Facebook className="w-3.5 h-3.5" />
              </a>
            )}
            {contactDetails.linkedin && (
              <a href={contactDetails.linkedin} target="_blank" rel="noopener noreferrer" className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700 text-slate-400 hover:text-emerald-400 hover:border-emerald-500 transition-all cursor-pointer" title="LinkedIn Link">
                <Linkedin className="w-3.5 h-3.5" />
              </a>
            )}
          </div>

        </div>
      </footer>

      {/* AD INTERSTITIAL OVERLAY MODAL */}
      {showInterstitial && currentInterstitialAd && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden relative font-sans text-slate-800 animate-fade-in">
            
            <button 
              onClick={() => setShowInterstitial(false)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center hover:text-slate-900 transition-colors cursor-pointer z-10"
              title="Close advertisement"
            >
              <X className="w-4 h-4" />
            </button>

            {currentInterstitialAd.imageUrl && (
              <div className="relative h-60 bg-slate-900">
                <img 
                  src={currentInterstitialAd.imageUrl} 
                  alt={currentInterstitialAd.title} 
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover" 
                />
                <div className="absolute top-4 left-4 p-1 px-2.5 bg-amber-400 text-slate-950 font-bold text-[9px] uppercase rounded-full font-mono tracking-wider">
                  Featured Partner Offer
                </div>
              </div>
            )}

            <div className="p-6 space-y-4">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">Special Announcement:</span>
              <h3 className="text-lg font-black text-slate-950 uppercase tracking-tight">{currentInterstitialAd.title}</h3>
              <p className="text-slate-600 text-xs font-medium leading-relaxed">
                {currentInterstitialAd.description}
              </p>

              <div className="flex gap-2.5 pt-2 text-xs font-semibold">
                <button 
                  onClick={() => setShowInterstitial(false)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl uppercase tracking-wider text-[10px] font-black transition-colors cursor-pointer"
                >
                  Skip for now
                </button>
                <a 
                  href={currentInterstitialAd.externalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl uppercase tracking-wider text-[10px] font-black transition-colors cursor-pointer flex items-center justify-center gap-1"
                >
                  <span>Explore promotion</span>
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}

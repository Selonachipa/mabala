import React, { useState, useEffect, useCallback, useMemo } from "react";
import { 
  Building2, 
  Layers, 
  GitCompare, 
  Calendar, 
  RefreshCw, 
  Download, 
  SlidersHorizontal, 
  Sparkles, 
  FileText, 
  Database, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  DollarSign, 
  LineChart as LineChartIcon,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Zap,
  Info
} from "lucide-react";
import { 
  FbiGranularity, 
  FbiPeriod, 
  FbiNodeRollup, 
  FbiTenantRollup, 
  FbiViewMode, 
  FbiKpiRegistryItem,
  FbiDomainKey
} from "../../types/fbi";
import { 
  getFbiNodeRollup, 
  getFbiTenantRollup, 
  refreshFbiRollupOnDemand, 
  getFbiKpiRegistry, 
  saveFbiKpiRegistryItem 
} from "../../services/fbiService";
import { resolvePeriodDates, computeRealNodeRollup, buildConsolidatedTenantRollup } from "../../services/fbiEngine";
import { FarmNodeSwitcher } from "./FarmNodeSwitcher";
import { FbiOverviewTab } from "./FbiOverviewTab";
import { FbiNodeComparisonView } from "./FbiNodeComparisonView";
import { FbiDomainDrilldownView } from "./FbiDomainDrilldownView";
import { FbiPeriodComparisonTab } from "./FbiPeriodComparisonTab";
import { FbiKpiRegistryModal } from "./FbiKpiRegistryModal";
import { FbiPlatformBenchmarksTab } from "./FbiPlatformBenchmarksTab";

import { getWalletBalances } from "../../services/walletService";

interface FarmIntelligenceDashboardProps {
  farms?: Array<{ id: string; name: string; currency?: string; currencySymbol?: string; address?: string }>;
  activeFarm?: any;
  tenantId?: string;
  userRole?: string;
  isSuperAdmin?: boolean;
  canAccessCrossNode?: boolean;
  onDeductCredits?: (amount: number, reason: string) => Promise<boolean>;
  creditBalance?: number;
  sales?: any[];
  invoices?: any[];
  otherRevenues?: any[];
  expenses?: any[];
  crops?: any[];
  livestock?: any[];
  poultry?: any[];
  fishBatches?: any[];
  employees?: any[];
  payslips?: any[];
  inventory?: any[];
  assets?: any[];
  investments?: any[];
  loans?: any[];
  plots?: any[];
  tasks?: any[];
  customers?: any[];
  suppliers?: any[];
  feedLogs?: any[];
}

export const FarmIntelligenceDashboard: React.FC<FarmIntelligenceDashboardProps> = ({
  farms = [],
  activeFarm,
  tenantId = "TENANT-001",
  userRole = "Farmer",
  isSuperAdmin = false,
  canAccessCrossNode = true,
  onDeductCredits,
  creditBalance = 100,
  sales = [],
  invoices = [],
  otherRevenues = [],
  expenses = [],
  crops = [],
  livestock = [],
  poultry = [],
  fishBatches = [],
  employees = [],
  payslips = [],
  inventory = [],
  assets = [],
  investments = [],
  loans = [],
  plots = [],
  tasks = [],
  customers = [],
  suppliers = [],
  feedLogs = []
}) => {
  // 1. Core State
  const [selectedFarmId, setSelectedFarmId] = useState<string>(activeFarm?.id || (farms[0]?.id || "farm-1"));
  const [viewMode, setViewMode] = useState<FbiViewMode>(farms.length > 1 ? "single_node" : "single_node");
  const [granularity, setGranularity] = useState<FbiGranularity>("monthly");
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [activeTab, setActiveTab] = useState<"overview" | "compare" | "drilldown" | "period_comparison" | "benchmarks">("overview");

  const [selectedDrilldownDomain, setSelectedDrilldownDomain] = useState<FbiDomainKey>("revenue");
  const [kpiRegistry, setKpiRegistry] = useState<FbiKpiRegistryItem[]>([]);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [isRegistryModalOpen, setIsRegistryModalOpen] = useState<boolean>(false);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: "success" | "error" | "info"; text: string } | null>(null);

  const activeFarmObj = farms.find(f => f.id === selectedFarmId) || activeFarm || farms[0] || { id: "farm-1", name: "Main Farm Node", currency: "ZMW" };
  const currency = activeFarmObj?.currency || "ZMW";

  const period = resolvePeriodDates(granularity, currentDate);

  const liveContext = useMemo(() => {
    const effectiveNodeId = selectedFarmId || activeFarmObj?.id || tenantId || "TENANT-001";
    const nodeWallet = getWalletBalances(effectiveNodeId);

    return {
      sales,
      invoices,
      otherRevenues,
      expenses,
      crops,
      livestock,
      poultry,
      fish: fishBatches,
      fishBatches,
      employees,
      payslips,
      inventory,
      assets,
      investments,
      loans,
      plots,
      tasks,
      customers,
      suppliers,
      feedLogs,
      activeFarm: activeFarmObj,
      walletBalances: nodeWallet
    };
  }, [
    sales,
    invoices,
    otherRevenues,
    expenses,
    crops,
    livestock,
    poultry,
    fishBatches,
    employees,
    payslips,
    inventory,
    assets,
    investments,
    loans,
    plots,
    tasks,
    customers,
    suppliers,
    feedLogs,
    selectedFarmId,
    activeFarmObj,
    tenantId
  ]);

  const [nodeRollup, setNodeRollup] = useState<FbiNodeRollup>(() => 
    computeRealNodeRollup(tenantId, selectedFarmId, activeFarmObj.name, period, liveContext)
  );

  const [tenantRollup, setTenantRollup] = useState<FbiTenantRollup | null>(() => {
    const nodes = farms.length > 0 ? farms : [{ id: selectedFarmId, name: activeFarmObj.name }];
    const rollups = nodes.map(n => computeRealNodeRollup(tenantId, n.id, n.name, period, liveContext));
    return buildConsolidatedTenantRollup(tenantId, rollups, period);
  });

  // 2. Fetch Data
  const loadRollupData = useCallback(async () => {
    try {
      // Synchronously compute immediate accurate state from live captured context
      const immediateNode = computeRealNodeRollup(tenantId, selectedFarmId, activeFarmObj.name, period, liveContext);
      setNodeRollup(immediateNode);

      const nodes = farms.length > 0 ? farms : [{ id: selectedFarmId, name: activeFarmObj.name }];
      const rollups = nodes.map(n => computeRealNodeRollup(tenantId, n.id, n.name, period, liveContext));
      const immediateTenant = buildConsolidatedTenantRollup(tenantId, rollups, period);
      setTenantRollup(immediateTenant);

      if (viewMode === "single_node") {
        const nr = await getFbiNodeRollup(tenantId, selectedFarmId, activeFarmObj.name, granularity, currentDate, liveContext);
        if (nr) setNodeRollup(nr);
      } else {
        const tr = await getFbiTenantRollup(tenantId, farms.map(f => ({ id: f.id, name: f.name })), granularity, currentDate, liveContext);
        if (tr) setTenantRollup(tr);
      }
    } catch (err: any) {
      console.warn("[FBI Dashboard] Error loading rollup:", err);
      // Fallback compute locally
      const nr = computeRealNodeRollup(tenantId, selectedFarmId, activeFarmObj.name, period, liveContext);
      setNodeRollup(nr);
    } finally {
      setIsLoading(false);
    }
  }, [
    tenantId,
    selectedFarmId,
    activeFarmObj.name,
    viewMode,
    granularity,
    period.key,
    farms.length
  ]);

  useEffect(() => {
    loadRollupData();
  }, [loadRollupData]);

  useEffect(() => {
    getFbiKpiRegistry().then(setKpiRegistry).catch(() => {});
  }, []);

  // Synchronize active farm when parent prop changes
  useEffect(() => {
    if (activeFarm?.id && activeFarm.id !== selectedFarmId) {
      setSelectedFarmId(activeFarm.id);
    }
  }, [activeFarm?.id]);

  // Handle viewMode switch into compare
  useEffect(() => {
    if (viewMode === "compare_nodes") {
      setActiveTab("compare");
    } else if (activeTab === "compare" && viewMode !== "compare_nodes") {
      setActiveTab("overview");
    }
  }, [viewMode]);

  // 3. Navigation Controls for Dates
  const handleShiftPeriod = (direction: -1 | 1) => {
    const nextDate = new Date(currentDate);
    if (granularity === "daily") {
      nextDate.setDate(nextDate.getDate() + direction);
    } else if (granularity === "weekly") {
      nextDate.setDate(nextDate.getDate() + (direction * 7));
    } else if (granularity === "monthly") {
      nextDate.setMonth(nextDate.getMonth() + direction);
    } else if (granularity === "yearly") {
      nextDate.setFullYear(nextDate.getFullYear() + direction);
    }
    setCurrentDate(nextDate);
  };

  // 4. On-demand refresh with credit metering
  const handleRefreshNow = async () => {
    try {
      setIsRefreshing(true);
      setFeedbackMsg(null);

      // Meter credits if onDeductCredits callback is supplied
      if (onDeductCredits) {
        const ok = await onDeductCredits(5, "FBI On-Demand Rollup Calculation");
        if (!ok) {
          setFeedbackMsg({ type: "error", text: "Insufficient credit balance for on-demand calculation (Requires 5 credits)." });
          setIsRefreshing(false);
          return;
        }
      }

      await refreshFbiRollupOnDemand(tenantId, selectedFarmId, granularity, viewMode === "consolidated");
      setFeedbackMsg({ type: "success", text: "On-demand rollup recalculation completed successfully!" });
      await loadRollupData();
    } catch (err: any) {
      setFeedbackMsg({ type: "error", text: err.message || "Recalculation failed" });
    } finally {
      setIsRefreshing(false);
    }
  };

  // 5. PDF & CSV Export Handlers
  const handleExportCsv = () => {
    const activeDomains = viewMode === "consolidated" ? tenantRollup?.domains : nodeRollup?.domains;
    if (!activeDomains) return;

    const rows = [
      ["Mabala Farm Intelligence (FBI) Report"],
      ["Target", viewMode === "consolidated" ? "All Farm Nodes (Consolidated)" : activeFarmObj.name],
      ["Period", period.label || period.key],
      ["Granularity", granularity.toUpperCase()],
      ["Generated At", new Date().toISOString()],
      [""],
      ["Domain", "Metric", "Value", "Unit"],
      ["Revenue", "Total Gross Revenue", activeDomains.revenue.total, currency],
      ["Revenue", "Cash Sales", activeDomains.revenue.cashSales || 0, currency],
      ["Revenue", "Invoiced Sales", activeDomains.revenue.invoiceSales || 0, currency],
      ["Expenses", "Total Operating Expenses", activeDomains.expenses.total, currency],
      ["Expenses", "Cost per Hectare", activeDomains.expenses.costPerHectare, `${currency}/ha`],
      ["Profitability", "Net Operating Profit", activeDomains.profitability.netProfit, currency],
      ["Profitability", "Net Profit Margin", `${activeDomains.profitability.netMarginPct}%`, "%"],
      ["Crop Agronomy", "Total Harvest Output", activeDomains.cropProduction.totalYieldKg, "kg"],
      ["Crop Agronomy", "Yield per Hectare", activeDomains.cropProduction.yieldPerHectare, "kg/ha"],
      ["Livestock", "Headcount", activeDomains.livestockProduction.headCount, "head"],
      ["Livestock", "Feed Conversion Ratio (FCR)", activeDomains.livestockProduction.fcr, "ratio"],
      ["Feeding", "Total Feed Expenditure", activeDomains.feedingCosts.totalCost, currency],
      ["Land Utilization", "Utilization Rate", `${activeDomains.landUtilization.utilizationRatePct}%`, "%"],
      ["Cash Wallet", "Closing Liquid Balance", activeDomains.cashWallet.endingBalance, currency]
    ];

    const csvContent = "data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `FBI_${activeFarmObj.name.replace(/\s+/g, "_")}_${period.key}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setFeedbackMsg({ type: "info", text: "FBI Intelligence CSV data exported successfully." });
  };

  const handleExportPdf = () => {
    window.print();
  };

  const currentDomains = viewMode === "consolidated" ? tenantRollup?.domains : nodeRollup?.domains;
  const currentInsight = viewMode === "consolidated" ? tenantRollup?.fbiInsight : nodeRollup?.fbiInsight;
  const lastComputedAt = (viewMode === "consolidated" ? tenantRollup?.computedAt : nodeRollup?.computedAt) || new Date().toISOString();

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 text-slate-900">
      {/* 1. Header & Main Title Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-xs">
        <div className="space-y-2">
          <div className="flex items-center gap-2.5">
            <span className="p-2.5 rounded-2xl bg-emerald-50 text-emerald-800 border border-emerald-200/80">
              <Sparkles className="w-6 h-6 text-emerald-600" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                  Farm Intelligence (FBI)
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200/80 font-mono">
                  v2.4 Pro
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5 font-medium">
                Multi-domain operational & financial analytics, cross-farm benchmarking, and AI driver attribution.
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls in Header */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Farm Node Switcher (Persistent selector for multi-node tenants) */}
          <FarmNodeSwitcher
            farms={farms}
            activeFarmId={selectedFarmId}
            onSelectFarmId={(id) => {
              setSelectedFarmId(id);
              setViewMode("single_node");
            }}
            viewMode={viewMode}
            onChangeViewMode={(mode) => setViewMode(mode)}
            canAccessCrossNode={canAccessCrossNode || isSuperAdmin}
          />

          {/* On-demand refresh button */}
          <button
            type="button"
            onClick={handleRefreshNow}
            disabled={isRefreshing}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-750 border border-slate-200 transition-all shadow-2xs disabled:opacity-50 cursor-pointer"
            title="Recalculate rollup from source ledgers (Credit metered)"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-emerald-600 ${isRefreshing ? "animate-spin" : ""}`} />
            <span>{isRefreshing ? "Computing..." : "Refresh Now"}</span>
          </button>

          {/* Export Actions */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={handleExportCsv}
              className="p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-white transition-all cursor-pointer"
              title="Export CSV"
            >
              <Download className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleExportPdf}
              className="p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-white transition-all cursor-pointer"
              title="Print / Save PDF Report"
            >
              <FileText className="w-4 h-4" />
            </button>
          </div>

          {/* KPI Registry Button for Super Admin & Config */}
          <button
            type="button"
            onClick={() => setIsRegistryModalOpen(true)}
            className="p-2 rounded-xl text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 border border-slate-200 transition-all cursor-pointer"
            title="Open KPI Registry Metadata"
          >
            <Database className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. Granularity & Period Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-xs">
        {/* Granularity Picker */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200/80">
          {(["daily", "weekly", "monthly", "yearly"] as FbiGranularity[]).map((gran) => (
            <button
              key={gran}
              type="button"
              onClick={() => setGranularity(gran)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-all cursor-pointer ${
                granularity === gran
                  ? "bg-white text-emerald-700 shadow-2xs border border-slate-200"
                  : "text-slate-500 hover:text-slate-900"
              }`}
            >
              {gran}
            </button>
          ))}
        </div>

        {/* Date / Period Navigator */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => handleShiftPeriod(-1)}
            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-all cursor-pointer shadow-2xs"
            title="Previous Period"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800 min-w-[170px] justify-center shadow-2xs">
            <Calendar className="w-3.5 h-3.5 text-emerald-600" />
            <span>{period.label || period.key}</span>
          </div>

          <button
            type="button"
            onClick={() => handleShiftPeriod(1)}
            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-all cursor-pointer shadow-2xs"
            title="Next Period"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => setCurrentDate(new Date())}
            className="px-2.5 py-1.5 rounded-lg text-xs font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200 cursor-pointer shadow-2xs"
          >
            Today
          </button>
        </div>

        {/* "As of" computed timestamp badge */}
        <div className="flex items-center gap-1.5 text-xs text-slate-500 font-mono">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>As of: {new Date(lastComputedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}, {new Date(lastComputedAt).toLocaleDateString("en-GB", { day: "numeric", month: "short" })}</span>
        </div>
      </div>

      {/* Feedback message banner */}
      {feedbackMsg && (
        <div className={`p-3.5 rounded-2xl text-xs font-bold flex items-center justify-between gap-2 shadow-xs ${
          feedbackMsg.type === "success" 
            ? "bg-emerald-50 text-emerald-800 border border-emerald-200" 
            : feedbackMsg.type === "error"
              ? "bg-rose-50 text-rose-800 border border-rose-200"
              : "bg-blue-50 text-blue-800 border border-blue-200"
        }`}>
          <div className="flex items-center gap-2">
            {feedbackMsg.type === "success" ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-rose-600" />}
            <span>{feedbackMsg.text}</span>
          </div>
          <button onClick={() => setFeedbackMsg(null)} className="text-slate-400 hover:text-slate-700 cursor-pointer">✕</button>
        </div>
      )}

      {/* 3. Module Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2">
        <button
          type="button"
          onClick={() => setActiveTab("overview")}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === "overview"
              ? "bg-emerald-600 text-white shadow-xs"
              : "bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200/80"
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Executive Overview</span>
        </button>

        {/* Node Comparison Tab (Enabled if > 1 farm node or viewMode compare) */}
        {farms.length > 1 && (canAccessCrossNode || isSuperAdmin) && (
          <button
            type="button"
            onClick={() => {
              setActiveTab("compare");
              setViewMode("compare_nodes");
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === "compare"
                ? "bg-indigo-600 text-white shadow-xs"
                : "bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200/80"
            }`}
          >
            <GitCompare className="w-4 h-4" />
            <span>Node-vs-Node Comparison</span>
          </button>
        )}

        <button
          type="button"
          onClick={() => setActiveTab("drilldown")}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === "drilldown"
              ? "bg-emerald-600 text-white shadow-xs"
              : "bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200/80"
          }`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span>12-Domain Drill-Down</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("period_comparison")}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === "period_comparison"
              ? "bg-emerald-600 text-white shadow-xs"
              : "bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200/80"
          }`}
        >
          <LineChartIcon className="w-4 h-4" />
          <span>Period Comparison (MoM/YoY)</span>
        </button>

        {isSuperAdmin && (
          <button
            type="button"
            onClick={() => setActiveTab("benchmarks")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === "benchmarks"
                ? "bg-purple-600 text-white shadow-xs"
                : "bg-white text-purple-700 hover:text-purple-900 hover:bg-purple-50 border border-purple-200"
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Super Admin Benchmarks</span>
          </button>
        )}
      </div>

      {/* 4. Tab Content Views */}
      {isLoading ? (
        <div className="bg-slate-900 p-12 rounded-3xl border border-slate-800 text-center space-y-3">
          <div className="w-8 h-8 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-400 font-medium">Aggregating FBI Intelligence domains from ledger rollups...</p>
        </div>
      ) : (
        <>
          {activeTab === "overview" && currentDomains && (
            <FbiOverviewTab
              domains={currentDomains}
              insight={currentInsight}
              viewMode={viewMode}
              targetName={viewMode === "consolidated" ? "All Farm Nodes (Consolidated)" : activeFarmObj.name}
              currency={currency}
              onNavigateDomain={(domKey) => {
                setSelectedDrilldownDomain(domKey as FbiDomainKey);
                setActiveTab("drilldown");
              }}
            />
          )}

          {activeTab === "compare" && tenantRollup && (
            <FbiNodeComparisonView
              tenantRollup={tenantRollup}
              currency={currency}
            />
          )}

          {activeTab === "drilldown" && currentDomains && (
            <FbiDomainDrilldownView
              domains={currentDomains}
              currency={currency}
              initialDomain={selectedDrilldownDomain}
              onCreditMeterAction={async (actionName) => {
                // credit-metering notice
              }}
            />
          )}

          {activeTab === "period_comparison" && currentDomains && (
            <FbiPeriodComparisonTab
              currentDomains={currentDomains}
              periodLabel={period.label || period.key}
              currency={currency}
            />
          )}

          {activeTab === "benchmarks" && (
            <FbiPlatformBenchmarksTab
              isSuperAdmin={isSuperAdmin}
              currency={currency}
            />
          )}
        </>
      )}

      {/* 5. KPI Registry Modal */}
      <FbiKpiRegistryModal
        isOpen={isRegistryModalOpen}
        onClose={() => setIsRegistryModalOpen(false)}
        kpis={kpiRegistry}
        onSaveKpi={async (kpi) => {
          await saveFbiKpiRegistryItem(kpi);
          const updated = await getFbiKpiRegistry();
          setKpiRegistry(updated);
        }}
        isSuperAdmin={isSuperAdmin}
      />
    </div>
  );
};

import React, { useState, useEffect } from "react";
import { 
  ShieldCheck, 
  Lock, 
  BarChart2, 
  TrendingUp, 
  Layers, 
  Info,
  AlertCircle
} from "lucide-react";
import { FbiPlatformRollup } from "../../types/fbi";
import { getFbiPlatformBenchmarks } from "../../services/fbiService";

interface FbiPlatformBenchmarksTabProps {
  isSuperAdmin?: boolean;
}

export const FbiPlatformBenchmarksTab: React.FC<FbiPlatformBenchmarksTabProps> = ({
  isSuperAdmin = false
}) => {
  const [benchmarks, setBenchmarks] = useState<FbiPlatformRollup | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function load() {
      setIsLoading(true);
      try {
        const data = await getFbiPlatformBenchmarks("monthly");
        if (data) {
          setBenchmarks(data);
        }
      } catch (_) {}
      setIsLoading(false);
    }
    load();
  }, []);

  if (!isSuperAdmin) {
    return (
      <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 text-center space-y-3">
        <Lock className="w-10 h-10 text-rose-400 mx-auto" />
        <h3 className="text-base font-bold text-slate-200">Restricted Super Admin Benchmarks</h3>
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          Cross-tenant benchmarking is exclusively isolated to Super Admin accounts via <code className="font-mono text-slate-300">platform/admin_views/fbi_platform_rollups</code> with strict PII masking.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 1. Super Admin Security & Privacy Badge */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-700">
              PII-Masked Platform Benchmarks
            </span>
          </div>
          <h3 className="text-base font-black text-slate-900">
            Cross-Tenant Agronomic & Financial Quartiles
          </h3>
          <p className="text-xs text-slate-500 font-medium">
            Aggregated strictly across all registered active Mabala farm nodes without exposing individual tenant identities.
          </p>
        </div>

        <div className="flex items-center gap-3 text-right">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Active Tenants</span>
            <span className="text-base font-black text-slate-900 font-mono">{benchmarks?.totalActiveTenants || 0}</span>
          </div>
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Total Farm Nodes</span>
            <span className="text-base font-black text-indigo-700 font-mono">{benchmarks?.totalActiveNodes || 0}</span>
          </div>
        </div>
      </div>

      {/* 2. Industry Quartile Distributions */}
      {benchmarks ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Net Margin Percentiles */}
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-slate-100">Net Profit Margin Quartiles</h4>
              <span className="text-xs font-mono font-bold text-emerald-400">
                Median: {benchmarks.benchmarkMargins?.median || 0}%
              </span>
            </div>

            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-300">
                  <span>25th Percentile (Bottom Quartile)</span>
                  <span className="font-mono">{benchmarks.benchmarkMargins?.p25 || 0}%</span>
                </div>
                <div className="bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                  <div className="bg-rose-500 h-full rounded-full" style={{ width: `${Math.min(100, (benchmarks.benchmarkMargins?.p25 || 0) * 2)}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-300">
                  <span>50th Percentile (Industry Median)</span>
                  <span className="font-mono text-emerald-400 font-bold">{benchmarks.benchmarkMargins?.median || 0}%</span>
                </div>
                <div className="bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${Math.min(100, (benchmarks.benchmarkMargins?.median || 0) * 2)}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-300">
                  <span>75th Percentile (Top Performers)</span>
                  <span className="font-mono text-indigo-400 font-bold">{benchmarks.benchmarkMargins?.p75 || 0}%</span>
                </div>
                <div className="bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                  <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${Math.min(100, (benchmarks.benchmarkMargins?.p75 || 0) * 2)}%` }} />
                </div>
              </div>
            </div>
          </div>

          {/* Crop Yield Quartiles */}
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
            <h4 className="text-sm font-bold text-slate-100">Crop Yield Benchmarks (kg/ha)</h4>
            <div className="space-y-3">
              {Object.keys(benchmarks.benchmarkYields || {}).length === 0 ? (
                <div className="bg-slate-950/70 p-6 rounded-xl border border-slate-800/80 text-center text-xs text-slate-400">
                  No cross-tenant crop harvest records aggregated for this period yet.
                </div>
              ) : (
                Object.entries(benchmarks.benchmarkYields).map(([crop, dist]: [string, any]) => (
                  <div key={crop} className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 space-y-1.5">
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-slate-200">{crop}</span>
                      <span className="font-mono text-emerald-400 font-semibold">{dist.median?.toLocaleString()} {dist.unit} (Median)</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                      <span>P25: {dist.p25?.toLocaleString()}</span>
                      <span>Median: {dist.median?.toLocaleString()}</span>
                      <span>P75: {dist.p75?.toLocaleString()}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-900 p-12 rounded-2xl border border-slate-800 text-center space-y-3">
          <AlertCircle className="w-8 h-8 text-slate-500 mx-auto" />
          <h4 className="text-sm font-bold text-slate-300">No Platform Benchmark Records Available</h4>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Cross-tenant benchmarking requires active tenant records in Firestore to aggregate statistical quartiles.
          </p>
        </div>
      )}
    </div>
  );
};

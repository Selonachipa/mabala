import React, { useState } from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  ArrowRight, 
  Sparkles, 
  DollarSign, 
  Receipt, 
  Scale, 
  Sprout, 
  Wheat 
} from "lucide-react";
import { FbiDomains } from "../../types/fbi";

interface FbiPeriodComparisonTabProps {
  currentDomains: FbiDomains;
  periodLabel: string;
  currency?: string;
}

export const FbiPeriodComparisonTab: React.FC<FbiPeriodComparisonTabProps> = ({
  currentDomains,
  periodLabel,
  currency = "ZMW"
}) => {
  const [comparisonMode, setComparisonMode] = useState<"prior_period" | "yoy">("prior_period");

  const rev = currentDomains.revenue;
  const exp = currentDomains.expenses;
  const prof = currentDomains.profitability;
  const crop = currentDomains.cropProduction;
  const live = currentDomains.livestockProduction;
  const feed = currentDomains.feedingCosts;

  // Derive simulated prior period values based on delta percentages
  const getPriorVal = (current: number, deltaPct: number) => {
    if (deltaPct === -100) return current;
    const base = current / (1 + (deltaPct / 100));
    return Math.round(base);
  };

  const deltaMultiplier = comparisonMode === "yoy" ? 1.4 : 1.0;

  const comparisonRows = [
    {
      domain: "Total Gross Revenue",
      icon: DollarSign,
      current: rev.total,
      delta: comparisonMode === "yoy" ? rev.deltaYoyPct : rev.deltaPriorPeriodPct,
      isCurrency: true,
      higherIsBetter: true
    },
    {
      domain: "Operating Expenses (OpEx)",
      icon: Receipt,
      current: exp.total,
      delta: comparisonMode === "yoy" ? exp.deltaYoyPct : exp.deltaPriorPeriodPct,
      isCurrency: true,
      higherIsBetter: false
    },
    {
      domain: "Net Operating Margin",
      icon: Scale,
      current: prof.netProfit,
      delta: comparisonMode === "yoy" ? prof.deltaYoyPct : prof.deltaPriorPeriodPct,
      isCurrency: true,
      higherIsBetter: true
    },
    {
      domain: "Crop Harvest (kg)",
      icon: Sprout,
      current: crop.totalYieldKg,
      delta: comparisonMode === "yoy" ? crop.deltaYoyPct : crop.deltaPriorPeriodPct,
      isCurrency: false,
      unit: "kg",
      higherIsBetter: true
    },
    {
      domain: "Total Feed Expenditure",
      icon: Wheat,
      current: feed.totalCost,
      delta: comparisonMode === "yoy" ? feed.deltaYoyPct : feed.deltaPriorPeriodPct,
      isCurrency: true,
      higherIsBetter: false
    }
  ];

  return (
    <div className="space-y-6">
      {/* 1. Comparison Mode Toggle Banner */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <Calendar className="w-4 h-4" />
            </span>
            <h3 className="text-base font-bold text-slate-100">
              Period-over-Period Variance Analysis
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Compare active performance against the immediately preceding period or Year-over-Year (YoY) historical baseline.
          </p>
        </div>

        {/* Toggle Buttons */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => setComparisonMode("prior_period")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              comparisonMode === "prior_period"
                ? "bg-emerald-600 text-white shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Prior Period (MoM/WoW)
          </button>
          <button
            type="button"
            onClick={() => setComparisonMode("yoy")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              comparisonMode === "yoy"
                ? "bg-indigo-600 text-white shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Year-over-Year (YoY)
          </button>
        </div>
      </div>

      {/* 2. Comparison Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="p-4">Key Performance Domain</th>
                <th className="p-4 text-right">Prior Benchmark</th>
                <th className="p-4 text-right">Current ({periodLabel})</th>
                <th className="p-4 text-right">Variance / Delta</th>
                <th className="p-4 text-center">Trend Indicator</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {comparisonRows.map((row, idx) => {
                const priorVal = getPriorVal(row.current, row.delta);
                const isPositive = row.delta >= 0;
                const isFavorable = row.higherIsBetter ? isPositive : !isPositive;

                return (
                  <tr key={idx} className="hover:bg-slate-800/30">
                    <td className="p-4 font-semibold text-slate-200 flex items-center gap-2">
                      <row.icon className="w-4 h-4 text-emerald-400" />
                      <span>{row.domain}</span>
                    </td>

                    <td className="p-4 text-right font-mono text-slate-400">
                      {row.isCurrency ? `${currency} ${priorVal.toLocaleString()}` : `${priorVal.toLocaleString()} ${row.unit || ""}`}
                    </td>

                    <td className="p-4 text-right font-mono font-bold text-slate-100">
                      {row.isCurrency ? `${currency} ${Math.round(row.current).toLocaleString()}` : `${Math.round(row.current).toLocaleString()} ${row.unit || ""}`}
                    </td>

                    <td className="p-4 text-right font-mono font-bold">
                      <span className={`px-2 py-0.5 rounded-full text-xs ${
                        isFavorable ? "bg-emerald-500/15 text-emerald-400" : "bg-rose-500/15 text-rose-400"
                      }`}>
                        {row.delta >= 0 ? "+" : ""}{row.delta.toFixed(1)}%
                      </span>
                    </td>

                    <td className="p-4 text-center">
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-300">
                        {isPositive ? (
                          <TrendingUp className={`w-4 h-4 ${isFavorable ? "text-emerald-400" : "text-amber-400"}`} />
                        ) : (
                          <TrendingDown className={`w-4 h-4 ${isFavorable ? "text-emerald-400" : "text-rose-400"}`} />
                        )}
                        <span>{isFavorable ? "Favorable" : "Unfavorable"}</span>
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

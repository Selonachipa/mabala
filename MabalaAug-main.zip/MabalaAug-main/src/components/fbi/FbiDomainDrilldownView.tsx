import React, { useState } from "react";
import { 
  DollarSign, 
  Receipt, 
  Sprout, 
  Tractor, 
  Wheat, 
  Users, 
  ShieldCheck, 
  Layers, 
  Landmark, 
  CreditCard, 
  Wallet, 
  Scale,
  Search,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  Percent,
  CheckCircle2,
  SlidersHorizontal,
  ChevronRight
} from "lucide-react";
import { FbiDomains, FbiDomainKey } from "../../types/fbi";

interface FbiDomainDrilldownViewProps {
  domains: FbiDomains;
  currency?: string;
  initialDomain?: FbiDomainKey;
  onCreditMeterAction?: (actionName: string) => void;
}

interface DomainConfig {
  key: FbiDomainKey;
  label: string;
  icon: any;
  color: string;
  metricLabel: string;
  description: string;
}

export const FBI_DOMAINS_CONFIG: DomainConfig[] = [
  { key: "revenue", label: "1. Revenue Streams", icon: DollarSign, color: "emerald", metricLabel: "Total Gross Revenue", description: "Cash sales, invoices, offtaker deliveries, and retail receipts." },
  { key: "expenses", label: "2. Operating Costs (OpEx)", icon: Receipt, color: "amber", metricLabel: "Total Operating Expenses", description: "Feed, labour, agro-chemicals, maintenance, and logistics." },
  { key: "cropProduction", label: "3. Crop Agronomy & Yield", icon: Sprout, color: "teal", metricLabel: "Total Harvest Output", description: "Yield per hectare, post-harvest losses, and crop cycle output." },
  { key: "livestockProduction", label: "4. Livestock & Flock", icon: Tractor, color: "cyan", metricLabel: "Herd / Flock Population", description: "Animal liveweight, mortality rate %, and average daily gain." },
  { key: "feedingCosts", label: "5. Feed & Nutrition", icon: Wheat, color: "yellow", metricLabel: "Total Feeding Costs", description: "Feed conversion ratio (FCR) and cost per kg gain." },
  { key: "labourCosts", label: "6. Labour & Payroll", icon: Users, color: "indigo", metricLabel: "Total Wage Expenditure", description: "Permanent staff, casual day-workers, and cost per hectare." },
  { key: "fertilizerChemicalCosts", label: "7. Crop Protection & Nutrients", icon: ShieldCheck, color: "emerald", metricLabel: "Crop Input Expenditures", description: "Fertilizer, seed dressing, fungicides, and chemical pesticides." },
  { key: "landUtilization", label: "8. Land Utilization", icon: Layers, color: "teal", metricLabel: "Cultivated Farm Area", description: "Active horticultural beds, orchards, pasture, and infrastructure." },
  { key: "investments", label: "9. Capital Investments (CapEx)", icon: Landmark, color: "purple", metricLabel: "Total Fixed Additions", description: "Irrigation, solar pumps, machinery, and biological asset growth." },
  { key: "creditFinancing", label: "10. Credit & Financing", icon: CreditCard, color: "rose", metricLabel: "Outstanding Loan Balance", description: "Mabala AGC credit, agro-dealer consignment notes, and debt service." },
  { key: "cashWallet", label: "11. Cash & MoMo Wallets", icon: Wallet, color: "blue", metricLabel: "Closing Liquid Cash", description: "Airtel Money, MTN MoMo, cash drawers, and net operational flow." },
  { key: "profitability", label: "12. Profitability & Margins", icon: Scale, color: "emerald", metricLabel: "Net Operating Margin", description: "Gross margin %, net profit, EBITDA, and return on assets." }
];

export const FbiDomainDrilldownView: React.FC<FbiDomainDrilldownViewProps> = ({
  domains,
  currency = "ZMW",
  initialDomain = "revenue",
  onCreditMeterAction
}) => {
  const [selectedDomainKey, setSelectedDomainKey] = useState<FbiDomainKey>(initialDomain);
  const [searchFilter, setSearchFilter] = useState<string>("");

  const activeConfig = FBI_DOMAINS_CONFIG.find(d => d.key === selectedDomainKey) || FBI_DOMAINS_CONFIG[0];
  const activeDomainData = domains?.[selectedDomainKey] || {
    total: 0,
    deltaPriorPeriodPct: 0,
    deltaYoyPct: 0,
    byDimension: {},
    unit: "ZMW"
  };

  const handleSelectDomain = (key: FbiDomainKey) => {
    setSelectedDomainKey(key);
    if (onCreditMeterAction) {
      onCreditMeterAction(`FBI Domain Drilldown: ${key}`);
    }
  };

  const dimensionEntries = Object.entries(activeDomainData?.byDimension || {})
    .filter(([key]) => key.toLowerCase().includes(searchFilter.toLowerCase()))
    .sort((a, b) => Number(b[1]) - Number(a[1]));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* 1. Left Sidebar: 12 Domains Selector */}
      <div className="lg:col-span-4 space-y-2">
        <div className="bg-slate-900 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Intelligence Domains (12)
            </h4>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
            Slice & Dice
          </span>
        </div>

        <div className="space-y-1.5 max-h-[750px] overflow-y-auto pr-1">
          {FBI_DOMAINS_CONFIG.map((item) => {
            const isSelected = selectedDomainKey === item.key;
            const Icon = item.icon;
            const domainVal = domains[item.key]?.total || 0;

            return (
              <button
                key={item.key}
                type="button"
                onClick={() => handleSelectDomain(item.key)}
                className={`w-full p-3.5 rounded-xl border text-left transition-all flex items-center justify-between group ${
                  isSelected
                    ? "bg-slate-800/90 border-emerald-500 shadow-md text-white"
                    : "bg-slate-900/60 border-slate-800/80 text-slate-300 hover:bg-slate-800/40 hover:border-slate-700"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${
                    isSelected ? "bg-emerald-500/20 text-emerald-400" : "bg-slate-800 text-slate-400 group-hover:text-slate-200"
                  }`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold leading-snug">{item.label}</div>
                    <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                      {item.key === "profitability" 
                        ? `${(domains.profitability.netMarginPct || 0)}% Net Margin`
                        : item.key === "cropProduction"
                          ? `${domains.cropProduction.totalYieldKg.toLocaleString()} kg`
                          : item.key === "livestockProduction"
                            ? `${domains.livestockProduction.headCount} head`
                            : item.key === "landUtilization"
                              ? `${domains.landUtilization.utilizationRatePct}% utilized`
                              : `${currency} ${Math.round(domainVal).toLocaleString()}`
                      }
                    </div>
                  </div>
                </div>

                <ChevronRight className={`w-4 h-4 transition-transform ${
                  isSelected ? "text-emerald-400 translate-x-0.5" : "text-slate-600 group-hover:text-slate-400"
                }`} />
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Right Column: Granular Dimensional Breakdown */}
      <div className="lg:col-span-8 space-y-6">
        {/* Domain Header Card */}
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-emerald-500/15 text-emerald-400">
                  <activeConfig.icon className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-base font-bold text-slate-100">{activeConfig.label}</h3>
                  <p className="text-xs text-slate-400">{activeConfig.description}</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/90 text-right min-w-[180px]">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                {activeConfig.metricLabel}
              </span>
              <span className="text-xl font-black text-slate-100 font-mono">
                {selectedDomainKey === "profitability"
                  ? `${domains.profitability.netMarginPct}%`
                  : selectedDomainKey === "cropProduction"
                    ? `${domains.cropProduction.totalYieldKg.toLocaleString()} kg`
                    : selectedDomainKey === "livestockProduction"
                      ? `${domains.livestockProduction.headCount} head`
                      : selectedDomainKey === "landUtilization"
                        ? `${domains.landUtilization.utilizationRatePct}%`
                        : `${currency} ${Math.round(activeDomainData.total).toLocaleString()}`
                }
              </span>
              <div className="mt-1 flex items-center justify-end gap-1 text-[11px]">
                <span className={`font-semibold ${activeDomainData.deltaPriorPeriodPct >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                  {activeDomainData.deltaPriorPeriodPct >= 0 ? "+" : ""}{activeDomainData.deltaPriorPeriodPct}%
                </span>
                <span className="text-slate-500">vs prior period</span>
              </div>
            </div>
          </div>
        </div>

        {/* Dimension Breakdown Table */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-sm overflow-hidden space-y-4">
          <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h4 className="text-sm font-bold text-slate-100">
                Dimensional Slicing & Allocation Breakdown
              </h4>
              <p className="text-xs text-slate-400">
                Granular contribution by crop cycle, block, batch, species, or expense classification.
              </p>
            </div>

            {/* Search filter input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Filter dimensions..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="bg-slate-950 text-xs text-slate-200 pl-8 pr-3 py-1.5 rounded-lg border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500 w-48"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-4">Enterprise / Slicing Dimension</th>
                  <th className="p-4 text-right">Value / Total</th>
                  <th className="p-4 text-right">% Contribution</th>
                  <th className="p-4 w-44">Visual Share</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {dimensionEntries.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="p-8 text-center text-slate-500 text-xs">
                      No dimensions match "{searchFilter}"
                    </td>
                  </tr>
                ) : (
                  dimensionEntries.map(([dimensionName, val], idx) => {
                    const numVal = Number(val) || 0;
                    const totalVal = Math.max(1, activeDomainData.total);
                    const pct = Math.min(100, Math.round((numVal / totalVal) * 100));

                    return (
                      <tr key={idx} className="hover:bg-slate-800/30">
                        <td className="p-4 font-semibold text-slate-200">
                          {dimensionName}
                        </td>
                        <td className="p-4 text-right font-mono font-bold text-slate-100">
                          {selectedDomainKey === "cropProduction"
                            ? `${numVal.toLocaleString()} kg`
                            : selectedDomainKey === "livestockProduction"
                              ? `${numVal.toLocaleString()} head`
                              : `${currency} ${numVal.toLocaleString()}`
                          }
                        </td>
                        <td className="p-4 text-right font-mono text-emerald-400 font-bold">
                          {pct}%
                        </td>
                        <td className="p-4">
                          <div className="bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                            <div 
                              className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

import React from "react";
import { Building2, Layers, GitCompare, ChevronDown } from "lucide-react";
import { FbiViewMode } from "../../types/fbi";

interface FarmNodeItem {
  id: string;
  name: string;
  location?: any;
}

interface FarmNodeSwitcherProps {
  farms: FarmNodeItem[];
  activeFarmId: string;
  onSelectFarmId: (id: string) => void;
  viewMode: FbiViewMode;
  onChangeViewMode: (mode: FbiViewMode) => void;
  canAccessCrossNode: boolean;
}

export const FarmNodeSwitcher: React.FC<FarmNodeSwitcherProps> = ({
  farms,
  activeFarmId,
  onSelectFarmId,
  viewMode,
  onChangeViewMode,
  canAccessCrossNode
}) => {
  // If tenant has only 1 farm node, do not render switcher
  if (!farms || farms.length <= 1) {
    return null;
  }

  const activeFarm = farms.find(f => f.id === activeFarmId) || farms[0];

  return (
    <div className="flex flex-wrap items-center gap-2 bg-slate-100 p-1.5 rounded-2xl border border-slate-200 shadow-2xs">
      {/* View Mode Segmented Controls */}
      <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200/80">
        <button
          type="button"
          onClick={() => onChangeViewMode("single_node")}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            viewMode === "single_node"
              ? "bg-emerald-600 text-white shadow-xs"
              : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Single Farm Node</span>
        </button>

        {canAccessCrossNode && (
          <>
            <button
              type="button"
              onClick={() => onChangeViewMode("consolidated")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                viewMode === "consolidated"
                  ? "bg-emerald-600 text-white shadow-xs"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>All Nodes (Consolidated)</span>
            </button>

            <button
              type="button"
              onClick={() => onChangeViewMode("compare_nodes")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                viewMode === "compare_nodes"
                  ? "bg-indigo-600 text-white shadow-xs"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              <GitCompare className="w-3.5 h-3.5" />
              <span>Compare Farm Nodes</span>
            </button>
          </>
        )}
      </div>

      {/* Node Dropdown selector when in single_node mode */}
      {viewMode === "single_node" && (
        <div className="relative inline-block">
          <select
            value={activeFarmId}
            onChange={(e) => onSelectFarmId(e.target.value)}
            className="appearance-none bg-white text-slate-800 text-xs font-bold pl-3 pr-8 py-1.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer shadow-2xs"
          >
            {farms.map(f => (
              <option key={f.id} value={f.id}>
                📍 {f.name}
              </option>
            ))}
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
      )}
    </div>
  );
};

import React, { useState } from "react";
import { 
  GitCompare, 
  Building2, 
  TrendingUp, 
  TrendingDown, 
  Trophy, 
  AlertCircle, 
  ArrowRight,
  Sprout,
  DollarSign,
  Receipt,
  Scale,
  Percent,
  Wheat,
  Users
} from "lucide-react";
import { FbiTenantRollup, FbiFarmNodeComparisonItem } from "../../types/fbi";

interface FbiNodeComparisonViewProps {
  tenantRollup: FbiTenantRollup;
  currency?: string;
}

export const FbiNodeComparisonView: React.FC<FbiNodeComparisonViewProps> = ({
  tenantRollup,
  currency = "ZMW"
}) => {
  const byFarmNode = tenantRollup.byFarmNode || {};
  const nodes: FbiFarmNodeComparisonItem[] = Object.values(byFarmNode);

  // If user only selected 2 specific nodes or compare all
  const [selectedNodeIds, setSelectedNodeIds] = useState<string[]>(() => nodes.map(n => n.farmNodeId));

  if (nodes.length < 2) {
    return (
      <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 text-center space-y-3">
        <GitCompare className="w-12 h-12 text-slate-600 mx-auto" />
        <h3 className="text-base font-bold text-slate-200">Insufficient Farm Nodes for Comparison</h3>
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          Node comparison requires at least two registered farm nodes under this tenant account. Currently {nodes.length} node is available.
        </p>
      </div>
    );
  }

  // Find top performers for highlight badges
  const topRevenueNode = [...nodes].sort((a, b) => b.revenue - a.revenue)[0];
  const topMarginNode = [...nodes].sort((a, b) => b.netMarginPct - a.netMarginPct)[0];
  const topYieldNode = [...nodes].sort((a, b) => b.cropYieldKg - a.cropYieldKg)[0];
  const topFcrNode = [...nodes].filter(n => n.fcr > 0).sort((a, b) => a.fcr - b.fcr)[0]; // lower FCR is better

  const activeComparedNodes = nodes.filter(n => selectedNodeIds.includes(n.farmNodeId));

  return (
    <div className="space-y-6">
      {/* 1. Comparison Header & Leaderboards */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400">
                <GitCompare className="w-4 h-4" />
              </span>
              <h3 className="text-base font-bold text-slate-100">
                Multi-Farm Node KPI Comparison
              </h3>
            </div>
            <p className="text-xs text-slate-400">
              Side-by-side performance benchmarks compiled from tenant-level rollups for {tenantRollup.period.label || tenantRollup.period.key}.
            </p>
          </div>

          {/* Node Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs text-slate-400 font-medium mr-1">Include:</span>
            {nodes.map(n => {
              const isSelected = selectedNodeIds.includes(n.farmNodeId);
              return (
                <button
                  key={n.farmNodeId}
                  type="button"
                  onClick={() => {
                    if (isSelected && selectedNodeIds.length > 2) {
                      setSelectedNodeIds(selectedNodeIds.filter(id => id !== n.farmNodeId));
                    } else if (!isSelected) {
                      setSelectedNodeIds([...selectedNodeIds, n.farmNodeId]);
                    }
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    isSelected
                      ? "bg-indigo-600/30 text-indigo-300 border border-indigo-500/50"
                      : "bg-slate-800/80 text-slate-500 border border-slate-700/50 hover:text-slate-300"
                  }`}
                >
                  <Building2 className="w-3 h-3" />
                  <span>{n.farmNodeName}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Highlight Leaderboard Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          {/* Top Revenue */}
          <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Highest Revenue Node</span>
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="text-sm font-bold text-slate-100 truncate">
              {topRevenueNode?.farmNodeName}
            </div>
            <div className="text-xs font-mono font-bold text-emerald-400">
              {currency} {Math.round(topRevenueNode?.revenue || 0).toLocaleString()}
            </div>
          </div>

          {/* Top Margin */}
          <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Best Net Margin</span>
              <Trophy className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-sm font-bold text-slate-100 truncate">
              {topMarginNode?.farmNodeName}
            </div>
            <div className="text-xs font-mono font-bold text-indigo-400">
              {topMarginNode?.netMarginPct}% Net Margin
            </div>
          </div>

          {/* Top Crop Yield */}
          <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Highest Crop Output</span>
              <Trophy className="w-3.5 h-3.5 text-teal-400" />
            </div>
            <div className="text-sm font-bold text-slate-100 truncate">
              {topYieldNode?.farmNodeName}
            </div>
            <div className="text-xs font-mono font-bold text-teal-400">
              {(topYieldNode?.cropYieldKg || 0).toLocaleString()} kg output
            </div>
          </div>

          {/* Best FCR */}
          <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Optimal Livestock FCR</span>
              <Trophy className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div className="text-sm font-bold text-slate-100 truncate">
              {topFcrNode?.farmNodeName || "N/A"}
            </div>
            <div className="text-xs font-mono font-bold text-cyan-400">
              {topFcrNode ? `${topFcrNode.fcr.toFixed(2)} FCR` : "No active herd"}
            </div>
          </div>
        </div>
      </div>

      {/* 2. Side-by-Side KPI Matrix Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h4 className="text-sm font-bold text-slate-100">
            Node-vs-Node Metric Benchmark Matrix
          </h4>
          <span className="text-xs text-slate-400 font-mono">
            Comparing {activeComparedNodes.length} Farm Nodes
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="p-4 w-64">Metric / Dimension</th>
                {activeComparedNodes.map(n => (
                  <th key={n.farmNodeId} className="p-4 text-slate-200">
                    <div className="flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{n.farmNodeName}</span>
                    </div>
                  </th>
                ))}
                <th className="p-4 text-slate-400">Node Variance / Spread</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-800/60 font-medium">
              {/* Financial Section */}
              <tr className="bg-slate-950/30">
                <td colSpan={activeComparedNodes.length + 2} className="px-4 py-2 text-[11px] font-bold text-indigo-400 uppercase tracking-wider">
                  Financial Performance & Margins
                </td>
              </tr>

              {/* Total Revenue */}
              <tr className="hover:bg-slate-800/30">
                <td className="p-4 font-semibold text-slate-200 flex items-center gap-2">
                  <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Total Revenue</span>
                </td>
                {activeComparedNodes.map(n => (
                  <td key={n.farmNodeId} className="p-4 font-mono font-bold text-slate-100">
                    {currency} {Math.round(n.revenue).toLocaleString()}
                  </td>
                ))}
                <td className="p-4 text-slate-400 font-mono text-[11px]">
                  {Math.round(Math.max(...activeComparedNodes.map(n => n.revenue)) - Math.min(...activeComparedNodes.map(n => n.revenue))).toLocaleString()} {currency} diff
                </td>
              </tr>

              {/* Operating Expenses */}
              <tr className="hover:bg-slate-800/30">
                <td className="p-4 font-semibold text-slate-200 flex items-center gap-2">
                  <Receipt className="w-3.5 h-3.5 text-amber-400" />
                  <span>Operating Expenses (OpEx)</span>
                </td>
                {activeComparedNodes.map(n => (
                  <td key={n.farmNodeId} className="p-4 font-mono text-slate-300">
                    {currency} {Math.round(n.expenses).toLocaleString()}
                  </td>
                ))}
                <td className="p-4 text-slate-400 font-mono text-[11px]">
                  {Math.round(Math.max(...activeComparedNodes.map(n => n.expenses)) - Math.min(...activeComparedNodes.map(n => n.expenses))).toLocaleString()} {currency} diff
                </td>
              </tr>

              {/* Net Profit */}
              <tr className="hover:bg-slate-800/30">
                <td className="p-4 font-semibold text-slate-200 flex items-center gap-2">
                  <Scale className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Net Operating Profit</span>
                </td>
                {activeComparedNodes.map(n => (
                  <td key={n.farmNodeId} className="p-4 font-mono font-bold">
                    <span className={n.netProfit >= 0 ? "text-emerald-400" : "text-rose-400"}>
                      {currency} {Math.round(n.netProfit).toLocaleString()}
                    </span>
                  </td>
                ))}
                <td className="p-4 text-slate-400 font-mono text-[11px]">
                  —
                </td>
              </tr>

              {/* Net Margin % */}
              <tr className="hover:bg-slate-800/30">
                <td className="p-4 font-semibold text-slate-200 flex items-center gap-2">
                  <Percent className="w-3.5 h-3.5 text-purple-400" />
                  <span>Net Margin (%)</span>
                </td>
                {activeComparedNodes.map(n => (
                  <td key={n.farmNodeId} className="p-4">
                    <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-slate-800 text-slate-200">
                      {n.netMarginPct}%
                    </span>
                  </td>
                ))}
                <td className="p-4 text-slate-400 font-mono text-[11px]">
                  {(Math.max(...activeComparedNodes.map(n => n.netMarginPct)) - Math.min(...activeComparedNodes.map(n => n.netMarginPct))).toFixed(1)}% spread
                </td>
              </tr>

              {/* Agronomy & Production Section */}
              <tr className="bg-slate-950/30">
                <td colSpan={activeComparedNodes.length + 2} className="px-4 py-2 text-[11px] font-bold text-emerald-400 uppercase tracking-wider">
                  Crop & Livestock Agronomy
                </td>
              </tr>

              {/* Total Yield */}
              <tr className="hover:bg-slate-800/30">
                <td className="p-4 font-semibold text-slate-200 flex items-center gap-2">
                  <Sprout className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Crop Harvest (kg)</span>
                </td>
                {activeComparedNodes.map(n => (
                  <td key={n.farmNodeId} className="p-4 font-mono text-slate-200">
                    {n.cropYieldKg.toLocaleString()} kg
                  </td>
                ))}
                <td className="p-4 text-slate-400 font-mono text-[11px]">
                  {(Math.max(...activeComparedNodes.map(n => n.cropYieldKg)) - Math.min(...activeComparedNodes.map(n => n.cropYieldKg))).toLocaleString()} kg diff
                </td>
              </tr>

              {/* Livestock FCR */}
              <tr className="hover:bg-slate-800/30">
                <td className="p-4 font-semibold text-slate-200 flex items-center gap-2">
                  <Wheat className="w-3.5 h-3.5 text-yellow-400" />
                  <span>Feed Conversion Ratio (FCR)</span>
                </td>
                {activeComparedNodes.map(n => (
                  <td key={n.farmNodeId} className="p-4 font-mono font-semibold">
                    <span className={n.fcr > 0 && n.fcr <= 1.65 ? "text-emerald-400" : "text-amber-400"}>
                      {n.fcr > 0 ? n.fcr.toFixed(2) : "N/A"}
                    </span>
                  </td>
                ))}
                <td className="p-4 text-slate-400 font-mono text-[11px]">
                  —
                </td>
              </tr>

              {/* Land Utilization Rate */}
              <tr className="hover:bg-slate-800/30">
                <td className="p-4 font-semibold text-slate-200 flex items-center gap-2">
                  <Scale className="w-3.5 h-3.5 text-teal-400" />
                  <span>Land Utilization Rate</span>
                </td>
                {activeComparedNodes.map(n => (
                  <td key={n.farmNodeId} className="p-4 font-mono text-teal-400 font-bold">
                    {n.landUtilizationPct.toFixed(1)}%
                  </td>
                ))}
                <td className="p-4 text-slate-400 font-mono text-[11px]">
                  {(Math.max(...activeComparedNodes.map(n => n.landUtilizationPct)) - Math.min(...activeComparedNodes.map(n => n.landUtilizationPct))).toFixed(1)}% spread
                </td>
              </tr>

              {/* Cost / Hectare */}
              <tr className="hover:bg-slate-800/30">
                <td className="p-4 font-semibold text-slate-200 flex items-center gap-2">
                  <Receipt className="w-3.5 h-3.5 text-slate-400" />
                  <span>Cost per Hectare</span>
                </td>
                {activeComparedNodes.map(n => (
                  <td key={n.farmNodeId} className="p-4 font-mono text-slate-300">
                    {currency} {n.costPerHectare.toLocaleString()}/ha
                  </td>
                ))}
                <td className="p-4 text-slate-400 font-mono text-[11px]">
                  —
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. Deep Enterprise Comparison Panels */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {activeComparedNodes.slice(0, 2).map(node => (
          <div key={node.farmNodeId} className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-sm space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-indigo-400" />
                <h4 className="text-sm font-bold text-slate-100">{node.farmNodeName} Enterprises</h4>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-400">
                {currency} {Math.round(node.revenue).toLocaleString()}
              </span>
            </div>

            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-400">Key Revenue Contributors</span>
              {Object.entries(node.domains?.revenue?.byDimension || {}).slice(0, 3).map(([key, val], i) => (
                <div key={i} className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-200 font-medium">{key}</span>
                  <span className="font-mono text-emerald-400 font-semibold">{currency} {val.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

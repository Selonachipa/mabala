import React, { useState } from "react";
import { 
  Plus, 
  X, 
  Settings, 
  Layers, 
  Check, 
  AlertCircle, 
  Database, 
  Sparkles,
  Sliders
} from "lucide-react";
import { FbiKpiRegistryItem, FbiDomainKey } from "../../types/fbi";
import { FBI_DOMAINS_CONFIG } from "./FbiDomainDrilldownView";

interface FbiKpiRegistryModalProps {
  isOpen: boolean;
  onClose: () => void;
  kpis: FbiKpiRegistryItem[];
  onSaveKpi: (kpi: FbiKpiRegistryItem) => Promise<void>;
  isSuperAdmin: boolean;
}

export const FbiKpiRegistryModal: React.FC<FbiKpiRegistryModalProps> = ({
  isOpen,
  onClose,
  kpis,
  onSaveKpi,
  isSuperAdmin
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState<Partial<FbiKpiRegistryItem>>({
    domain: "revenue",
    aggregation: "sum",
    unit: "ZMW",
    sliceableBy: ["cropCycleId", "blockId"],
    requiresRollupVersion: "reportCentre"
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.kpiId || !formData.label || !formData.domain || !formData.unit) {
      setStatusMsg({ type: "error", text: "Please provide KPI ID, Domain, Label, and Unit." });
      return;
    }

    try {
      setIsSubmitting(true);
      setStatusMsg(null);
      await onSaveKpi(formData as FbiKpiRegistryItem);
      setStatusMsg({ type: "success", text: `KPI '${formData.label}' registered successfully in platform registry!` });
      setIsAdding(false);
      setFormData({
        domain: "revenue",
        aggregation: "sum",
        unit: "ZMW",
        sliceableBy: ["cropCycleId", "blockId"],
        requiresRollupVersion: "reportCentre"
      });
    } catch (err: any) {
      setStatusMsg({ type: "error", text: err.message || "Failed to register KPI" });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">
                FBI Platform KPI Registry
              </h3>
              <p className="text-xs text-slate-400">
                Metadata catalog defining pluggable KPI definitions across all farm domains (Super-Admin managed).
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {statusMsg && (
            <div className={`p-3.5 rounded-xl text-xs font-medium flex items-center gap-2 ${
              statusMsg.type === "success" 
                ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30" 
                : "bg-rose-500/15 text-rose-300 border border-rose-500/30"
            }`}>
              {statusMsg.type === "success" ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              <span>{statusMsg.text}</span>
            </div>
          )}

          {/* Action Bar */}
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300">
              Registered KPIs ({kpis.length})
            </span>
            {isSuperAdmin && (
              <button
                type="button"
                onClick={() => setIsAdding(!isAdding)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isAdding ? "Cancel" : "Register New KPI"}</span>
              </button>
            )}
          </div>

          {/* Add KPI Form */}
          {isAdding && (
            <form onSubmit={handleSubmit} className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                Register New Farm KPI
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium text-slate-400 block mb-1">KPI Identifier (Unique ID)</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. soil_moisture_index"
                    value={formData.kpiId || ""}
                    onChange={e => setFormData({ ...formData, kpiId: e.target.value })}
                    className="w-full bg-slate-900 text-xs text-slate-200 px-3 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-400 block mb-1">Display Label</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Soil Moisture Index"
                    value={formData.label || ""}
                    onChange={e => setFormData({ ...formData, label: e.target.value })}
                    className="w-full bg-slate-900 text-xs text-slate-200 px-3 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-400 block mb-1">Domain Classification</label>
                  <select
                    value={formData.domain}
                    onChange={e => setFormData({ ...formData, domain: e.target.value as FbiDomainKey })}
                    className="w-full bg-slate-900 text-xs text-slate-200 px-3 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    {FBI_DOMAINS_CONFIG.map(d => (
                      <option key={d.key} value={d.key}>{d.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-400 block mb-1">Measurement Unit</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. ZMW, kg/ha, %, ratio"
                    value={formData.unit || ""}
                    onChange={e => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full bg-slate-900 text-xs text-slate-200 px-3 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-400 block mb-1">Aggregation Method</label>
                  <select
                    value={formData.aggregation}
                    onChange={e => setFormData({ ...formData, aggregation: e.target.value as any })}
                    className="w-full bg-slate-900 text-xs text-slate-200 px-3 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="sum">Sum (Additive)</option>
                    <option value="avg">Average (Mean)</option>
                    <option value="ratio">Ratio / Calculated</option>
                    <option value="latest">Latest Snapshot</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-400 block mb-1">Source Path Expression</label>
                  <input
                    type="text"
                    placeholder="farm_nodes/{farmNodeId}/crop_cycles"
                    value={formData.sourcePath || ""}
                    onChange={e => setFormData({ ...formData, sourcePath: e.target.value })}
                    className="w-full bg-slate-900 text-xs text-slate-200 px-3 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-400 block mb-1">Description / Formula Context</label>
                <textarea
                  rows={2}
                  placeholder="Explains how this KPI is measured and used in farm decision making..."
                  value={formData.description || ""}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-slate-900 text-xs text-slate-200 px-3 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-50"
                >
                  {isSubmitting ? "Saving..." : "Save KPI to Registry"}
                </button>
              </div>
            </form>
          )}

          {/* KPI List Table */}
          <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3.5">KPI Label & ID</th>
                  <th className="p-3.5">Domain</th>
                  <th className="p-3.5">Unit</th>
                  <th className="p-3.5">Aggregation</th>
                  <th className="p-3.5">Sliceable Dimensions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium text-slate-300">
                {kpis.map((kpi) => (
                  <tr key={kpi.kpiId} className="hover:bg-slate-900/40">
                    <td className="p-3.5">
                      <div className="font-semibold text-slate-100">{kpi.label}</div>
                      <div className="text-[11px] text-slate-500 font-mono">{kpi.kpiId}</div>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-mono bg-slate-800 text-emerald-400">
                        {kpi.domain}
                      </span>
                    </td>
                    <td className="p-3.5 font-mono font-bold text-slate-200">
                      {kpi.unit}
                    </td>
                    <td className="p-3.5 capitalize text-slate-400">
                      {kpi.aggregation}
                    </td>
                    <td className="p-3.5">
                      <div className="flex flex-wrap gap-1">
                        {kpi.sliceableBy?.map((dim, i) => (
                          <span key={i} className="px-1.5 py-0.2 rounded text-[10px] bg-slate-900 border border-slate-800 text-slate-400 font-mono">
                            {dim}
                          </span>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/50 flex items-center justify-between text-xs text-slate-400">
          <span>Schema path: <code className="font-mono text-slate-300">platform/config/fbi_kpi_registry</code></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

import React from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Receipt, 
  Sprout, 
  Tractor, 
  Wheat, 
  Users, 
  ShieldCheck, 
  Sparkles, 
  ArrowUpRight, 
  ArrowDownRight,
  Info,
  Scale,
  PieChart as PieChartIcon
} from "lucide-react";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  AreaChart, 
  Area 
} from "recharts";
import { FbiDomains, FbiInsight, FbiViewMode } from "../../types/fbi";

interface FbiOverviewTabProps {
  domains: FbiDomains;
  insight?: FbiInsight;
  viewMode: FbiViewMode;
  targetName: string;
  currency?: string;
  onNavigateDomain: (domainKey: string) => void;
}

export const FbiOverviewTab: React.FC<FbiOverviewTabProps> = ({
  domains,
  insight,
  viewMode,
  targetName,
  currency = "ZMW",
  onNavigateDomain
}) => {
  const rev = domains.revenue;
  const exp = domains.expenses;
  const prof = domains.profitability;
  const crop = domains.cropProduction;
  const live = domains.livestockProduction;
  const feed = domains.feedingCosts;
  const land = domains.landUtilization;
  const cash = domains.cashWallet;

  // Chart data for revenue vs expenses structure strictly derived from dynamic account ledger domains
  const opexAmount = exp.opex > 0 ? exp.opex : Math.max(0, exp.total - (exp.capex || 0));
  const capexAmount = exp.capex > 0 ? exp.capex : 0;

  const financialFlowData = [
    { name: "Gross Revenue", amount: rev.total, fill: "#10b981" },
    { name: "OpEx (Costs)", amount: opexAmount, fill: "#f59e0b" },
    { name: "CapEx (Inv)", amount: capexAmount, fill: "#6366f1" },
    { name: "Net Margin", amount: Math.max(0, prof.netProfit), fill: "#3b82f6" }
  ];

  // Domain Cost Breakdown strictly derived from actual domain costs
  const feedCost = feed.totalCost || 0;
  const inputCost = domains.fertilizerChemicalCosts.total || 0;
  const labourCost = domains.labourCosts.total || 0;
  const maintCost = Math.max(0, exp.total - (feedCost + inputCost + labourCost));

  const costBreakdownData = [
    { name: "Feed", value: feedCost },
    { name: "Inputs", value: inputCost },
    { name: "Labour", value: labourCost },
    { name: "Maint & Ops", value: maintCost }
  ];

  return (
    <div className="space-y-6">
      {/* 1. AI Insight Commentary Card */}
      {insight && (
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 p-6 border border-emerald-500/30 shadow-xl">
          <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
            <div className="space-y-2 max-w-3xl">
              <div className="flex items-center gap-2">
                <span className="flex items-center justify-center p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                  <Sparkles className="w-4 h-4" />
                </span>
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                  FBI Intelligence Briefing • {targetName}
                </span>
                <span className="text-[11px] text-slate-400 font-mono">
                  as of {new Date(insight.generatedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-100 tracking-tight">
                {insight.headline}
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                {insight.summary}
              </p>
            </div>

            {/* Recommendations Pill Badge */}
            {insight.recommendations && insight.recommendations.length > 0 && (
              <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 lg:w-80 flex-shrink-0 space-y-2">
                <div className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Actionable Priorities</span>
                </div>
                <ul className="space-y-1.5">
                  {insight.recommendations.slice(0, 2).map((rec, i) => (
                    <li key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                      <span className="text-emerald-400 font-bold">•</span>
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Drivers List */}
          {insight.drivers && insight.drivers.length > 0 && (
            <div className="mt-5 pt-4 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-3 gap-3">
              {insight.drivers.map((driver, idx) => (
                <div key={idx} className="bg-slate-950/50 p-3 rounded-xl border border-slate-800/60 flex items-start gap-2.5">
                  <div className={`p-1.5 rounded-lg flex-shrink-0 mt-0.5 ${
                    driver.impact === "positive" 
                      ? "bg-emerald-500/15 text-emerald-400" 
                      : driver.impact === "negative" 
                        ? "bg-rose-500/15 text-rose-400" 
                        : "bg-blue-500/15 text-blue-400"
                  }`}>
                    {driver.impact === "positive" ? (
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    ) : driver.impact === "negative" ? (
                      <ArrowDownRight className="w-3.5 h-3.5" />
                    ) : (
                      <Scale className="w-3.5 h-3.5" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-200">{driver.dimension}</span>
                      {driver.attributionPct !== undefined && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded-full font-mono bg-slate-800 text-slate-300">
                          {driver.attributionPct}% impact
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                      {driver.detail}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 2. Executive KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Revenue */}
        <div 
          onClick={() => onNavigateDomain("revenue")}
          className="bg-slate-900 p-5 rounded-2xl border border-slate-800 hover:border-emerald-500/50 transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Revenue</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:scale-110 transition-transform">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-100 font-mono">
              {currency} {Math.round(rev.total).toLocaleString()}
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <div className={`flex items-center gap-1 font-semibold ${rev.deltaPriorPeriodPct >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
              {rev.deltaPriorPeriodPct >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
              <span>{rev.deltaPriorPeriodPct >= 0 ? "+" : ""}{rev.deltaPriorPeriodPct}% vs prior</span>
            </div>
            <span className="text-slate-500 text-[11px]">YoY: +{rev.deltaYoyPct}%</span>
          </div>
        </div>

        {/* Operating Expenses */}
        <div 
          onClick={() => onNavigateDomain("expenses")}
          className="bg-slate-900 p-5 rounded-2xl border border-slate-800 hover:border-amber-500/50 transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Operating Costs</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:scale-110 transition-transform">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-100 font-mono">
              {currency} {Math.round(exp.total).toLocaleString()}
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <div className={`flex items-center gap-1 font-semibold ${exp.deltaPriorPeriodPct <= 0 ? "text-emerald-400" : "text-amber-400"}`}>
              {exp.deltaPriorPeriodPct <= 0 ? <TrendingDown className="w-3.5 h-3.5" /> : <TrendingUp className="w-3.5 h-3.5" />}
              <span>{exp.deltaPriorPeriodPct >= 0 ? "+" : ""}{exp.deltaPriorPeriodPct}% vs prior</span>
            </div>
            <span className="text-slate-500 text-[11px]">{currency} {exp.costPerHectare}/ha</span>
          </div>
        </div>

        {/* Net Profit & Margin */}
        <div 
          onClick={() => onNavigateDomain("profitability")}
          className="bg-slate-900 p-5 rounded-2xl border border-slate-800 hover:border-indigo-500/50 transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Net Operating Profit</span>
            <div className={`p-2 rounded-xl ${prof.netProfit >= 0 ? "bg-indigo-500/10 text-indigo-400" : "bg-rose-500/10 text-rose-400"} group-hover:scale-110 transition-transform`}>
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className={`text-2xl font-black font-mono ${prof.netProfit >= 0 ? "text-slate-100" : "text-rose-400"}`}>
              {currency} {Math.round(prof.netProfit).toLocaleString()}
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300">
              {prof.netMarginPct}% Net Margin
            </span>
            <span className="text-slate-400 text-[11px]">Gross: {prof.grossMarginPct}%</span>
          </div>
        </div>

        {/* Crop Yield / Hectare */}
        <div 
          onClick={() => onNavigateDomain("cropProduction")}
          className="bg-slate-900 p-5 rounded-2xl border border-slate-800 hover:border-emerald-500/50 transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Crop Harvest Output</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:scale-110 transition-transform">
              <Sprout className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-100 font-mono">
              {crop.totalYieldKg.toLocaleString()} <span className="text-sm font-normal text-slate-400">kg</span>
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className="text-emerald-400 font-semibold font-mono">
              {crop.yieldPerHectare.toLocaleString()} kg/ha
            </span>
            <span className="text-slate-400 text-[11px]">{crop.activeHectares} ha active</span>
          </div>
        </div>

        {/* Livestock Headcount & FCR */}
        <div 
          onClick={() => onNavigateDomain("livestockProduction")}
          className="bg-slate-900 p-5 rounded-2xl border border-slate-800 hover:border-cyan-500/50 transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Flock / Herd Efficiency</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 group-hover:scale-110 transition-transform">
              <Tractor className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-100 font-mono">
              {live.fcr > 0 ? live.fcr.toFixed(2) : "1.62"} <span className="text-sm font-normal text-slate-400">FCR</span>
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className="text-cyan-400 font-semibold">
              {live.headCount.toLocaleString()} head
            </span>
            <span className="text-slate-400 text-[11px]">{live.mortalityRatePct}% mortality</span>
          </div>
        </div>

        {/* Feed Cost Efficiency */}
        <div 
          onClick={() => onNavigateDomain("feedingCosts")}
          className="bg-slate-900 p-5 rounded-2xl border border-slate-800 hover:border-yellow-500/50 transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Feed Cost / kg Gain</span>
            <div className="p-2 rounded-xl bg-yellow-500/10 text-yellow-400 group-hover:scale-110 transition-transform">
              <Wheat className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-100 font-mono">
              {currency} {feed.feedCostPerKgGain.toFixed(2)} <span className="text-sm font-normal text-slate-400">/kg</span>
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className="text-slate-300 font-mono text-[11px]">
              Total: {currency} {Math.round(feed.totalCost).toLocaleString()}
            </span>
            <span className="text-yellow-400 text-[11px]">Commercial: 75%</span>
          </div>
        </div>

        {/* Land Utilization */}
        <div 
          onClick={() => onNavigateDomain("landUtilization")}
          className="bg-slate-900 p-5 rounded-2xl border border-slate-800 hover:border-teal-500/50 transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Land Utilization</span>
            <div className="p-2 rounded-xl bg-teal-500/10 text-teal-400 group-hover:scale-110 transition-transform">
              <Sprout className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-100 font-mono">
              {land.utilizationRatePct.toFixed(1)}%
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className="text-teal-400 font-semibold">
              {land.cultivatedHectares} ha cultivated
            </span>
            <span className="text-slate-400 text-[11px]">of {land.totalHectares} ha</span>
          </div>
        </div>

        {/* Cash & Wallet Balance */}
        <div 
          onClick={() => onNavigateDomain("cashWallet")}
          className="bg-slate-900 p-5 rounded-2xl border border-slate-800 hover:border-purple-500/50 transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Liquid Cash & MoMo</span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 group-hover:scale-110 transition-transform">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-100 font-mono">
              {currency} {Math.round(cash.endingBalance).toLocaleString()}
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className={`font-semibold ${cash.netCashFlow >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
              {cash.netCashFlow >= 0 ? "+" : ""}{currency} {Math.round(cash.netCashFlow).toLocaleString()} flow
            </span>
            <span className="text-slate-400 text-[11px]">Closing</span>
          </div>
        </div>
      </div>

      {/* 3. Operational Visuals & Dimensional Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Financial Flow Chart */}
        <div className="lg:col-span-7 bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-slate-100">Financial Structure & Margins</h4>
              <p className="text-xs text-slate-400">Revenue, Operational Expenditure, CapEx, and Retained Earnings</p>
            </div>
            <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Gross Margin: {prof.grossMarginPct}%
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={financialFlowData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickFormatter={(val) => `${Math.round(val / 1000)}k`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "12px", color: "#f8fafc" }}
                  formatter={(val: any) => [`${currency} ${Number(val).toLocaleString()}`, "Value"]}
                />
                <Bar dataKey="amount" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right: Revenue by Enterprise / Crop Cycle */}
        <div className="lg:col-span-5 bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-slate-100">Revenue by Crop Cycle & Batch</h4>
              <p className="text-xs text-slate-400">Contribution from active agricultural enterprises</p>
            </div>
            <button 
              onClick={() => onNavigateDomain("revenue")}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {Object.entries(rev.byDimension || {}).slice(0, 4).map(([enterprise, amount], i) => {
              const numAmount = Number(amount) || 0;
              const pct = rev.total > 0 ? Math.round((numAmount / rev.total) * 100) : 0;
              return (
                <div key={i} className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-200 truncate max-w-[200px]">{enterprise}</span>
                    <span className="font-mono text-emerald-400 font-bold">{currency} {numAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div 
                        className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                        style={{ width: `${Math.min(100, pct)}%` }}
                      />
                    </div>
                    <span className="text-[11px] font-mono text-slate-400 w-8 text-right">{pct}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

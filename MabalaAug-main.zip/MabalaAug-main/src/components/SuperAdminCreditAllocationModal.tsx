import { safeFormatError } from "../utils/errorUtils";
import React, { useState, useEffect } from "react";
import {
  Coins,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Zap,
  Calendar,
  Layers,
  ArrowRight,
  Loader2,
  X,
  Plus,
  Minus,
  RotateCcw,
  Tag,
  CreditCard,
  Building,
  User,
  Clock,
  MessageSquare,
  Smartphone,
  PhoneCall
} from "lucide-react";
import { doc, setDoc, getDoc, collection } from "firebase/firestore";
import { db, auth } from "../firebase";

export interface SuperAdminCreditAllocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUser: {
    uid: string;
    email: string;
    name?: string;
    fullName?: string;
    phone?: string;
    phoneNumber?: string;
    role?: string;
    accountType?: string;
    credits?: number;
    smsCredits?: number;
    subscriptionPackage?: string;
    subscriptionTier?: string;
    subscriptionStatus?: string;
    subscriptionExpiresAt?: string;
    farms?: any[];
    [key: string]: any;
  } | null;
  allUsers?: any[];
  currentUserEmail?: string;
  currencySymbol?: string;
  initialTab?: "credits" | "subscription" | "sms";
  onAllocationComplete?: (updatedData: {
    uid: string;
    credits: number;
    smsCredits?: number;
    subscriptionPackage: string;
    subscriptionExpiresAt?: string;
  }) => void;
  onAllocationSuccess?: () => void;
}

const SUBSCRIPTION_PACKAGES = [
  {
    id: "UNCHANGED",
    name: "Keep Current Tier (No Change)",
    bundledCredits: 0,
    badge: "Current",
    desc: "Leave tenant's existing subscription package unchanged."
  },
  {
    id: "Seeding Tier",
    name: "Seeding Tier (Free Forever)",
    bundledCredits: 60,
    badge: "60 CR Welcome",
    desc: "Free Forever starter tier with 60 welcome write action credits on signup."
  },
  {
    id: "Daily Bundle",
    name: "Daily Bundle (24h Unmetered)",
    bundledCredits: 0,
    badge: "24h Unmetered",
    desc: "24-hour unmetered full write operations pass (bypasses credit deductions)."
  },
  {
    id: "Monthly Plan",
    name: "Monthly Plan",
    bundledCredits: 1500,
    badge: "1,500 CR/mo",
    desc: "Full farm & dealer ledger, input credit portal, storage sync, 1,500 credits/mo (ZK 180/mo)."
  },
  {
    id: "Growth Plan",
    name: "Growth Plan",
    bundledCredits: 12000,
    badge: "12,000 CR/mo",
    desc: "Includes 1 free agronomist visit/month + Consignment Hub access, 12,000 credits/mo (ZK 650/mo)."
  },
  {
    id: "Enterprise Plan",
    name: "Enterprise Plan",
    bundledCredits: 120000,
    badge: "120,000 CR/mo",
    desc: "2 free agronomist + 2 free vet visits/month, multi-warehouse, API suite, 120,000 credits/mo (ZK 2,500/mo)."
  }
];

const PRESET_CREDIT_AMOUNTS = [60, 250, 750, 1500, 2000, 5000, 12000, 50000, 120000];
const PRESET_SMS_AMOUNTS = [50, 100, 250, 500, 1000, 2500, 5000, 10000];

const QUICK_REASONS = [
  "Super Admin Promotional Grant",
  "SMS Communication Pack Allotment",
  "Subscription Package Upgrade / Renewal",
  "Customer Support Issue Compensation",
  "Pilot / Demonstration Account Setup",
  "Manual Bank Transfer / MoMo Clearance",
  "Zero-Rate Baseline Balance Reset"
];

export const SuperAdminCreditAllocationModal: React.FC<SuperAdminCreditAllocationModalProps> = ({
  isOpen,
  onClose,
  targetUser,
  allUsers,
  currentUserEmail,
  currencySymbol = "ZMW",
  initialTab = "credits",
  onAllocationComplete,
  onAllocationSuccess
}) => {
  if (!isOpen || !targetUser) return null;

  const currentCredits = Number(targetUser.credits ?? 0);
  const currentSmsCredits = Number(targetUser.smsCredits ?? 0);
  const currentPlan = targetUser.subscriptionPackage || targetUser.subscriptionTier || "Free Forever";
  const tenantEmail = targetUser.email || "No Email";
  const tenantName = targetUser.name || targetUser.fullName || targetUser.farms?.[0]?.name || tenantEmail.split("@")[0];
  const tenantPhone = targetUser.phone || targetUser.phoneNumber || targetUser.contactPhone || "Not Provided";
  const tenantRole = targetUser.role || "Farmer";

  // Form states
  const [activeTab, setActiveTab] = useState<"credits" | "sms" | "subscription">(initialTab || "credits");
  
  // Write Credits states
  const [creditActionType, setCreditActionType] = useState<"allocate" | "deduct" | "set" | "none">("none");
  const [creditAmount, setCreditAmount] = useState<number>(500);
  
  // SMS Credits states
  const [smsActionType, setSmsActionType] = useState<"allocate" | "deduct" | "set" | "zero_rate" | "none">("allocate");
  const [smsAmount, setSmsAmount] = useState<number>(250);

  // Subscription states
  const [selectedPlanId, setSelectedPlanId] = useState<string>("UNCHANGED");
  const [customPlanName, setCustomPlanName] = useState<string>("");
  const [subscriptionDurationDays, setSubscriptionDurationDays] = useState<number>(30);
  const [subscriptionStatus, setSubscriptionStatus] = useState<string>("ACTIVE");
  const [autoApplyBundledCredits, setAutoApplyBundledCredits] = useState<boolean>(true);
  const [legalReason, setLegalReason] = useState<string>("Super Admin SMS / System Credit Grant");
  
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Reset tab on open if specified
  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
      if (initialTab === "sms") {
        setSmsActionType("allocate");
        setCreditActionType("none");
        setLegalReason("Super Admin Promotional SMS Grant");
      }
    }
  }, [initialTab, isOpen]);

  // Calculate prospective new balance for write credits
  const selectedPlanObj = SUBSCRIPTION_PACKAGES.find(p => p.id === selectedPlanId);
  const effectivePlanName = selectedPlanId === "CUSTOM" ? customPlanName : (selectedPlanId === "UNCHANGED" ? currentPlan : selectedPlanObj?.name || selectedPlanId);
  const bundledBonus = (selectedPlanId !== "UNCHANGED" && autoApplyBundledCredits) ? (selectedPlanObj?.bundledCredits || 0) : 0;

  let calculatedNewCredits = currentCredits;
  if (creditActionType === "allocate") {
    calculatedNewCredits = currentCredits + creditAmount + bundledBonus;
  } else if (creditActionType === "deduct") {
    calculatedNewCredits = Math.max(0, currentCredits - creditAmount);
  } else if (creditActionType === "set") {
    calculatedNewCredits = Math.max(0, creditAmount + bundledBonus);
  } else if (creditActionType === "none") {
    calculatedNewCredits = currentCredits + bundledBonus;
  }

  // Calculate prospective new balance for SMS credits
  let calculatedNewSmsCredits = currentSmsCredits;
  if (smsActionType === "allocate") {
    calculatedNewSmsCredits = currentSmsCredits + smsAmount;
  } else if (smsActionType === "deduct") {
    calculatedNewSmsCredits = Math.max(0, currentSmsCredits - smsAmount);
  } else if (smsActionType === "set") {
    calculatedNewSmsCredits = Math.max(0, smsAmount);
  } else if (smsActionType === "zero_rate") {
    calculatedNewSmsCredits = 0;
  } else if (smsActionType === "none") {
    calculatedNewSmsCredits = currentSmsCredits;
  }

  const handleExecuteAllocation = async () => {
    if (!legalReason.trim()) {
      setErrorMessage("A mandatory legal audit justification reason is required.");
      return;
    }
    if (selectedPlanId === "CUSTOM" && !customPlanName.trim()) {
      setErrorMessage("Please specify the custom plan name.");
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    const superAdminUid = auth.currentUser?.uid || "icIoBG4eN5VOw2BvhNiFUnUqmsX2";
    const superAdminEmail = auth.currentUser?.email || "support@mabala.cloud";
    const tenantUid = targetUser.uid || targetUser.tenantUid || targetUser.id || targetUser.tenantId || (targetUser.email ? "USER_" + targetUser.email.replace(/[^a-zA-Z0-9]/g, "_") : "TENANT_UNKNOWN");
    const tenantEmail = targetUser.email || targetUser.tenantEmail || targetUser.ownerEmail || "";

    try {
      // 1. Calculate expiry date if plan changed
      let expiryIso: string | undefined = targetUser.subscriptionExpiresAt;
      if (selectedPlanId !== "UNCHANGED") {
        const expDate = new Date(Date.now() + subscriptionDurationDays * 24 * 60 * 60 * 1000);
        expiryIso = expDate.toISOString();
      }

      // Credit balances are owned by the farm node and changed atomically by
      // the authenticated backend callable. Do not write absolute balances
      // from this stale browser snapshot.
      const { getFunctions, httpsCallable } = await import("firebase/functions");
      const { getApp } = await import("firebase/app");
      const allocateCredits = httpsCallable(getFunctions(getApp()), "allocateCredits");
      const requestId = `admin-${superAdminUid}-${tenantUid}-${Date.now()}`;
      const platformResult: any = await allocateCredits({
        tenantId: tenantUid,
        creditType: "platform",
        amount: creditActionType === "none" ? bundledBonus : creditAmount,
        adjustmentType: creditActionType === "none" ? "allocate" : creditActionType,
        reason: legalReason,
        idempotencyKey: `${requestId}-platform`,
        subscriptionPackage: selectedPlanId === "UNCHANGED" ? undefined : effectivePlanName,
        subscriptionDurationDays,
        subscriptionStatus
      });
      let authoritativePlatform = Number(platformResult.data?.platformBalance ?? platformResult.data?.newBalance ?? calculatedNewCredits);
      let authoritativeSms = currentSmsCredits;
      if (smsActionType !== "none") {
        const smsResult: any = await allocateCredits({
          tenantId: tenantUid,
          creditType: "sms",
          amount: smsActionType === "zero_rate" ? 0 : smsAmount,
          adjustmentType: smsActionType === "zero_rate" ? "set" : smsActionType,
          reason: legalReason,
          idempotencyKey: `${requestId}-sms`
        });
        authoritativeSms = Number(smsResult.data?.smsBalance ?? smsResult.data?.newBalance ?? calculatedNewSmsCredits);
      }
      onAllocationComplete?.({
        uid: tenantUid,
        credits: authoritativePlatform,
        smsCredits: authoritativeSms,
        subscriptionPackage: effectivePlanName,
        subscriptionExpiresAt: expiryIso
      });
      onAllocationSuccess?.();
      setShowConfirmModal(false);
      onClose();
      return;

      // 2. Direct Firestore update for instantaneous synchronization
      const userUpdates: Record<string, any> = {
        credits: calculatedNewCredits,
        smsCredits: calculatedNewSmsCredits,
        updatedAt: new Date().toISOString()
      };

      if (selectedPlanId !== "UNCHANGED") {
        userUpdates.subscriptionPackage = effectivePlanName;
        userUpdates.subscriptionTier = effectivePlanName;
        userUpdates.subscriptionPlan = effectivePlanName;
        userUpdates.subscriptionStatus = subscriptionStatus;
        userUpdates.subscriptionExpiresAt = expiryIso;
        userUpdates.planExpiryDate = expiryIso;
        userUpdates.isPassActive = effectivePlanName === "Daily Bundle";
      }

      if (db && tenantUid) {
        // Update users_data directly by document reference
        await setDoc(doc(db, "users_data", tenantUid), userUpdates, { merge: true });

        // Also update users collection document if separate auth user document exists
        try {
          await setDoc(doc(db, "users", tenantUid), userUpdates, { merge: true });
        } catch (_) {}

        // Update tenants/{tenantUid}/wallet/credits
        try {
          const walletRef = doc(db, "tenants", tenantUid, "wallet", "credits");
          let prevLifetime = currentCredits;
          try {
            const wSnap = await getDoc(walletRef);
            if (wSnap.exists()) {
              prevLifetime = wSnap.data()?.lifetimeIssued ?? currentCredits;
            }
          } catch (e) {}

          const issuedDelta = (creditActionType === "allocate" ? creditAmount : 0) + bundledBonus;
          await setDoc(walletRef, {
            currentBalance: calculatedNewCredits,
            smsCredits: calculatedNewSmsCredits,
            smsCreditBalance: calculatedNewSmsCredits,
            lifetimeIssued: prevLifetime + issuedDelta,
            planAllotment: calculatedNewCredits,
            planName: effectivePlanName,
            updatedAt: new Date().toISOString()
          }, { merge: true });
        } catch (wErr) {
          console.warn("[SuperAdminModal] Wallet update warning:", wErr);
        }

        // Update tenants/{tenantUid}/wallet/sms
        try {
          await setDoc(doc(db, "tenants", tenantUid, "wallet", "sms"), {
            currentBalance: calculatedNewSmsCredits,
            balance: calculatedNewSmsCredits,
            updatedAt: new Date().toISOString()
          }, { merge: true });
        } catch (wErr) {
          console.warn("[SuperAdminModal] SMS wallet update warning:", wErr);
        }

        // Add to creditLedger if write credits changed
        if (creditActionType !== "none" || bundledBonus > 0) {
          try {
            const ledgerId = "ledger-admin-" + Date.now();
            const creditDelta = calculatedNewCredits - currentCredits;
            await setDoc(doc(db, "tenants", tenantUid, "creditLedger", ledgerId), {
              id: ledgerId,
              type: creditDelta >= 0 ? "credit_grant" : "deduction",
              amount: Math.abs(creditDelta),
              balanceAfter: calculatedNewCredits,
              description: `Super Admin: ${legalReason} (Plan: ${effectivePlanName})`,
              authorizedBy: superAdminEmail,
              timestamp: new Date().toISOString()
            });
          } catch (lErr) {
            console.warn("[SuperAdminModal] Ledger append warning:", lErr);
          }
        }

        // Add to sms_ledger if SMS credits changed
        if (smsActionType !== "none") {
          try {
            const smsLedgerId = "sms-ledger-" + Date.now();
            const smsDelta = calculatedNewSmsCredits - currentSmsCredits;
            await setDoc(doc(db, "tenants", tenantUid, "sms_ledger", smsLedgerId), {
              id: smsLedgerId,
              type: smsDelta >= 0 ? "top_up" : "deduction",
              amount: smsDelta,
              balanceAfter: calculatedNewSmsCredits,
              reference: `SUPERADMIN_ALLOC_${Date.now()}`,
              note: `Super Admin SMS Adjustment: ${legalReason}`,
              authorizedBy: superAdminEmail,
              createdAt: new Date().toISOString()
            });
          } catch (slErr) {
            console.warn("[SuperAdminModal] SMS ledger append warning:", slErr);
          }
        }

        // Add to super_admin_audit
        try {
          const auditId = "audit-alloc-" + Date.now();
          await setDoc(doc(db, "super_admin_audit", auditId), {
            id: auditId,
            superAdminId: superAdminUid,
            superAdminEmail: superAdminEmail,
            actionType: "credit_and_sms_allocation",
            targetTenantId: tenantUid,
            details: {
              targetEmail: tenantEmail,
              creditActionType,
              creditAmount,
              smsActionType,
              smsAmount,
              previousCredits: currentCredits,
              newCredits: calculatedNewCredits,
              previousSmsCredits: currentSmsCredits,
              newSmsCredits: calculatedNewSmsCredits,
              previousPackage: currentPlan,
              newPackage: effectivePlanName,
              subscriptionStatus,
              subscriptionExpiresAt: expiryIso,
              reason: legalReason,
              timestamp: new Date().toISOString()
            },
            timestamp: new Date().toISOString()
          });
        } catch (aErr) {
          console.warn("[SuperAdminModal] Audit append warning:", aErr);
        }
      }

      // 3. Dispatch to server backend API for persistent multi-cluster redundancy
      try {
        let token = "";
        try {
          if (auth.currentUser) {
            token = await auth.currentUser.getIdToken();
          }
        } catch (tErr) {}

        await fetch("/api/admin/allocate-credits-and-subscription", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {})
          },
          body: JSON.stringify({
            tenantId: tenantUid,
            tenantEmail,
            creditAdjustmentType: creditActionType,
            creditAmount,
            targetBalance: calculatedNewCredits,
            exactNewCredits: calculatedNewCredits,
            baselineCredits: currentCredits,
            smsCreditAdjustmentType: smsActionType,
            smsCreditAmount: smsAmount,
            targetSmsBalance: calculatedNewSmsCredits,
            smsCredits: calculatedNewSmsCredits,
            subscriptionPackage: selectedPlanId === "UNCHANGED" ? undefined : effectivePlanName,
            subscriptionDurationDays,
            subscriptionStatus,
            autoApplyPlanCredits: autoApplyBundledCredits,
            reason: legalReason,
            superAdminEmail,
            superAdminUid
          })
        });

        // Also call dedicated farm-nodes SMS allocation endpoint if SMS changed
        if (smsActionType !== "none") {
          await fetch("/api/admin/farm-nodes/allocate-sms-credits", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              ...(token ? { Authorization: `Bearer ${token}` } : {})
            },
            body: JSON.stringify({
              tenantId: tenantUid,
              amount: smsAmount,
              type: smsActionType,
              reference: `SUPERADMIN_ALLOC_${Date.now()}`,
              note: legalReason,
              superAdminEmail,
              superAdminUid
            })
          });
        }
      } catch (srvErr) {
        console.warn("[SuperAdminModal] Server API fallback notice:", srvErr);
      }

      // Broadcast update across local tabs & app context
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("mabala_sms_update", { detail: { smsCredits: calculatedNewSmsCredits, tenantId: tenantUid } }));
      }

      // Complete allocation & update UI state
      if (onAllocationComplete) {
        onAllocationComplete({
          uid: tenantUid,
          credits: calculatedNewCredits,
          smsCredits: calculatedNewSmsCredits,
          subscriptionPackage: effectivePlanName,
          subscriptionExpiresAt: expiryIso
        });
      }
      if (onAllocationSuccess) {
        onAllocationSuccess();
      }

      setShowConfirmModal(false);
      onClose();
    } catch (err: any) {
      console.error("[SuperAdminModal] Allocation failure:", err);
      setErrorMessage(err.message || "Failed to complete credit and SMS allocation.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-[99999] flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in font-sans">
      <div className="bg-slate-900 text-slate-100 rounded-2xl border border-slate-800 shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden my-auto">
        
        {/* MODAL HEADER */}
        <div className="p-5 bg-gradient-to-r from-slate-900 via-slate-850 to-indigo-950/40 border-b border-slate-800 flex items-start justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full text-[9.5px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-amber-400" /> Super Admin Authority
              </span>
              <span className="text-[10px] font-mono text-slate-400">UID: {targetUser.uid.slice(0, 10)}...</span>
            </div>
            <h2 className="text-lg font-black text-white tracking-tight flex items-center gap-2">
              <Coins className="w-5 h-5 text-emerald-400" />
              Allocate Farm Node Credits & SMS Balances
            </h2>
            <p className="text-xs text-slate-400 font-medium">
              Allocate write action credits, grant SMS balances, and manage SaaS tiers for any farm node.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TENANT SUMMARY HERO BAR */}
        <div className="px-5 py-3 bg-slate-950/70 border-b border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Target Farm Node</span>
            <span className="font-bold text-slate-200 truncate block">{tenantName}</span>
            <span className="text-[10px] text-slate-400 font-mono truncate block">{tenantEmail}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Current Role</span>
            <span className="px-2 py-0.5 bg-indigo-950 text-indigo-300 border border-indigo-800 rounded text-[10px] font-black uppercase inline-block mt-0.5">
              {tenantRole}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Current Balances</span>
            <span className="font-mono font-black text-emerald-400 text-xs block">
              🪙 {currentCredits.toLocaleString()} Write CR
            </span>
            <span className="font-mono font-black text-indigo-400 text-xs block">
              📱 {currentSmsCredits.toLocaleString()} SMS CR
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Subscription Plan</span>
            <span className="font-bold text-amber-300 text-xs block truncate">
              🎖️ {currentPlan}
            </span>
            <span className="text-[9.5px] text-emerald-400 font-medium">
              Status: {targetUser.subscriptionStatus || "ACTIVE"}
            </span>
          </div>
        </div>

        {/* ERROR MESSAGE IF ANY */}
        {errorMessage && (
          <div className="mx-5 mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-bold flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{safeFormatError(errorMessage)}</span>
          </div>
        )}

        {/* TAB CONTROLS */}
        <div className="px-5 pt-3 flex gap-2 border-b border-slate-800">
          <button
            onClick={() => setActiveTab("credits")}
            className={`pb-2.5 px-3 text-xs font-black uppercase tracking-wider flex items-center gap-1.5 border-b-2 transition cursor-pointer ${
              activeTab === "credits"
                ? "border-emerald-500 text-emerald-400"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Coins className="w-3.5 h-3.5" /> Operations Write Credits
          </button>
          <button
            onClick={() => setActiveTab("sms")}
            className={`pb-2.5 px-3 text-xs font-black uppercase tracking-wider flex items-center gap-1.5 border-b-2 transition cursor-pointer ${
              activeTab === "sms"
                ? "border-indigo-500 text-indigo-400"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" /> SMS Credits Allocation
          </button>
          <button
            onClick={() => setActiveTab("subscription")}
            className={`pb-2.5 px-3 text-xs font-black uppercase tracking-wider flex items-center gap-1.5 border-b-2 transition cursor-pointer ${
              activeTab === "subscription"
                ? "border-amber-500 text-amber-400"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Layers className="w-3.5 h-3.5" /> Subscription Plan Tier
          </button>
        </div>

        {/* MODAL BODY (SCROLLABLE) */}
        <div className="p-5 space-y-5 overflow-y-auto flex-1 text-xs">
          
          {/* TAB 1: OPERATIONS CREDITS ADJUSTMENT */}
          {activeTab === "credits" && (
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-1.5">
                  1. Credit Adjustment Action
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setCreditActionType("allocate")}
                    className={`p-2.5 rounded-xl border text-xs font-black uppercase transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      creditActionType === "allocate"
                        ? "bg-emerald-600/20 border-emerald-500 text-emerald-300 ring-1 ring-emerald-500"
                        : "bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <Plus className="w-3.5 h-3.5 text-emerald-400" /> Grant / Add (+)
                  </button>

                  <button
                    type="button"
                    onClick={() => setCreditActionType("deduct")}
                    className={`p-2.5 rounded-xl border text-xs font-black uppercase transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      creditActionType === "deduct"
                        ? "bg-rose-600/20 border-rose-500 text-rose-300 ring-1 ring-rose-500"
                        : "bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <Minus className="w-3.5 h-3.5 text-rose-400" /> Deduct (-)
                  </button>

                  <button
                    type="button"
                    onClick={() => setCreditActionType("set")}
                    className={`p-2.5 rounded-xl border text-xs font-black uppercase transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      creditActionType === "set"
                        ? "bg-sky-600/20 border-sky-500 text-sky-300 ring-1 ring-sky-500"
                        : "bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <Zap className="w-3.5 h-3.5 text-sky-400" /> Set Exact (=)
                  </button>

                  <button
                    type="button"
                    onClick={() => setCreditActionType("none")}
                    className={`p-2.5 rounded-xl border text-xs font-black uppercase transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      creditActionType === "none"
                        ? "bg-slate-700 border-slate-500 text-white ring-1 ring-slate-400"
                        : "bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> No Change
                  </button>
                </div>
              </div>

              {creditActionType !== "none" && (
                <div className="space-y-3 bg-slate-850 p-4 rounded-xl border border-slate-800">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                      2. Adjustment Amount (Write Action Credits)
                    </label>
                    <span className="text-[10px] font-mono text-emerald-400">
                      Rate: 1 ZMW = 2.5 Credits
                    </span>
                  </div>

                  <div className="relative">
                    <input
                      type="number"
                      min={1}
                      value={creditAmount}
                      onChange={e => setCreditAmount(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-base font-bold focus:outline-none focus:border-emerald-500"
                    />
                    <span className="absolute right-3.5 top-3 text-xs font-bold text-slate-400 font-mono">
                      CREDITS
                    </span>
                  </div>

                  {/* PRESET QUICK BUTTONS */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {PRESET_CREDIT_AMOUNTS.map(amt => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setCreditAmount(amt)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition cursor-pointer ${
                          creditAmount === amt
                            ? "bg-emerald-500 text-slate-950 shadow"
                            : "bg-slate-800 text-slate-300 hover:bg-slate-750 hover:text-white border border-slate-700"
                        }`}
                      >
                        +{amt >= 1000 ? `${amt / 1000}k` : amt}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: SMS CREDITS ALLOCATION */}
          {activeTab === "sms" && (
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-1.5">
                  1. SMS Credit Action
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  <button
                    type="button"
                    onClick={() => setSmsActionType("allocate")}
                    className={`p-2.5 rounded-xl border text-xs font-black uppercase transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      smsActionType === "allocate"
                        ? "bg-indigo-600/20 border-indigo-500 text-indigo-300 ring-1 ring-indigo-500"
                        : "bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <Plus className="w-3.5 h-3.5 text-indigo-400" /> Allocate (+)
                  </button>

                  <button
                    type="button"
                    onClick={() => setSmsActionType("deduct")}
                    className={`p-2.5 rounded-xl border text-xs font-black uppercase transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      smsActionType === "deduct"
                        ? "bg-rose-600/20 border-rose-500 text-rose-300 ring-1 ring-rose-500"
                        : "bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <Minus className="w-3.5 h-3.5 text-rose-400" /> Deduct (-)
                  </button>

                  <button
                    type="button"
                    onClick={() => setSmsActionType("set")}
                    className={`p-2.5 rounded-xl border text-xs font-black uppercase transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      smsActionType === "set"
                        ? "bg-sky-600/20 border-sky-500 text-sky-300 ring-1 ring-sky-500"
                        : "bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <Zap className="w-3.5 h-3.5 text-sky-400" /> Set Exact (=)
                  </button>

                  <button
                    type="button"
                    onClick={() => setSmsActionType("zero_rate")}
                    className={`p-2.5 rounded-xl border text-xs font-black uppercase transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      smsActionType === "zero_rate"
                        ? "bg-amber-600/20 border-amber-500 text-amber-300 ring-1 ring-amber-500"
                        : "bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-amber-400" /> Zero-Rate (0)
                  </button>

                  <button
                    type="button"
                    onClick={() => setSmsActionType("none")}
                    className={`p-2.5 rounded-xl border text-xs font-black uppercase transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      smsActionType === "none"
                        ? "bg-slate-700 border-slate-500 text-white ring-1 ring-slate-400"
                        : "bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <span>No Change</span>
                  </button>
                </div>
              </div>

              {smsActionType !== "none" && smsActionType !== "zero_rate" && (
                <div className="space-y-3 bg-slate-850 p-4 rounded-xl border border-slate-800">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                      2. SMS Credit Amount
                    </label>
                    <span className="text-[10px] font-mono text-indigo-400">
                      Base Rate: ZMW 0.90 / SMS (Beem Gateway)
                    </span>
                  </div>

                  <div className="relative">
                    <input
                      type="number"
                      min={1}
                      value={smsAmount}
                      onChange={e => setSmsAmount(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-base font-bold focus:outline-none focus:border-indigo-500"
                    />
                    <span className="absolute right-3.5 top-3 text-xs font-bold text-indigo-400 font-mono">
                      SMS CREDITS
                    </span>
                  </div>

                  {/* PRESET QUICK BUTTONS FOR SMS */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {PRESET_SMS_AMOUNTS.map(amt => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setSmsAmount(amt)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition cursor-pointer ${
                          smsAmount === amt
                            ? "bg-indigo-600 text-white shadow"
                            : "bg-slate-800 text-slate-300 hover:bg-slate-750 hover:text-white border border-slate-700"
                        }`}
                      >
                        +{amt >= 1000 ? `${amt / 1000}k` : amt} SMS
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {smsActionType === "zero_rate" && (
                <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 space-y-1">
                  <div className="flex items-center gap-1.5 font-black text-xs">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span>Zero-Rate Warning</span>
                  </div>
                  <p className="text-[11px] text-amber-200/90 leading-relaxed">
                    Executing this will immediately reset this farm node&apos;s SMS credit balance from <strong className="text-white">{currentSmsCredits}</strong> to <strong className="text-white">0 SMS Credits</strong>.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: SUBSCRIPTION PACKAGE TIER */}
          {activeTab === "subscription" && (
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-1.5">
                  Select SaaS Subscription Package
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {SUBSCRIPTION_PACKAGES.map(pkg => (
                    <div
                      key={pkg.id}
                      onClick={() => setSelectedPlanId(pkg.id)}
                      className={`p-3 rounded-xl border transition cursor-pointer space-y-1 ${
                        selectedPlanId === pkg.id
                          ? "bg-indigo-950/60 border-indigo-500 ring-1 ring-indigo-500"
                          : "bg-slate-850 border-slate-800 hover:border-slate-700 text-slate-300"
                      }`}
                    >
                      <div className="flex justify-between items-start gap-1">
                        <span className="font-black text-white text-xs">{pkg.name}</span>
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 shrink-0">
                          {pkg.badge}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight">{pkg.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              {selectedPlanId !== "UNCHANGED" && (
                <div className="bg-slate-850 p-4 rounded-xl border border-slate-800 space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-1">
                        Subscription Duration
                      </label>
                      <select
                        value={subscriptionDurationDays}
                        onChange={e => setSubscriptionDurationDays(Number(e.target.value))}
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs font-bold outline-none focus:border-indigo-500 cursor-pointer"
                      >
                        <option value={1}>1 Day (24 Hours - Daily Pass)</option>
                        <option value={30}>1 Month (30 Days)</option>
                        <option value={90}>3 Months (90 Days / Quarter)</option>
                        <option value={180}>6 Months (180 Days / Half Year)</option>
                        <option value={365}>1 Year (365 Days / Annual)</option>
                        <option value={3650}>Lifetime / Permanent Exemption</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-1">
                        Subscription Status Flag
                      </label>
                      <select
                        value={subscriptionStatus}
                        onChange={e => setSubscriptionStatus(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs font-bold outline-none focus:border-indigo-500 cursor-pointer"
                      >
                        <option value="ACTIVE">ACTIVE (Fully Functional)</option>
                        <option value="TRIAL">TRIAL (Promotional Period)</option>
                        <option value="PAID_UPFRONT">PAID_UPFRONT (Manual Invoice Settled)</option>
                        <option value="EXEMPT">EXEMPT (VIP / Strategic Partner)</option>
                      </select>
                    </div>
                  </div>

                  {selectedPlanObj && selectedPlanObj.bundledCredits > 0 && (
                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-200 cursor-pointer pt-1">
                      <input
                        type="checkbox"
                        checked={autoApplyBundledCredits}
                        onChange={e => setAutoApplyBundledCredits(e.target.checked)}
                        className="w-4 h-4 text-emerald-500 rounded bg-slate-900 border-slate-700 focus:ring-emerald-500"
                      />
                      <span>
                        Also credit plan&apos;s bundled credits (<strong>+{selectedPlanObj.bundledCredits.toLocaleString()} CR</strong>) directly into wallet balance
                      </span>
                    </label>
                  )}
                </div>
              )}
            </div>
          )}

          {/* LEGAL AUDIT JUSTIFICATION (ALWAYS VISIBLE) */}
          <div className="bg-slate-850 p-4 rounded-xl border border-slate-800 space-y-2.5">
            <div className="flex justify-between items-center">
              <label className="text-[10px] font-black uppercase tracking-wider text-amber-400 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> Legal Audit Justification (Mandatory)
              </label>
              <span className="text-[9.5px] text-slate-500 font-mono">Logged to super_admin_audit</span>
            </div>

            <input
              type="text"
              required
              placeholder="e.g. Granted promotional SMS credits for harvest campaign dispatch..."
              value={legalReason}
              onChange={e => setLegalReason(e.target.value)}
              className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs font-medium focus:outline-none focus:border-indigo-500"
            />

            <div className="flex flex-wrap gap-1.5 pt-1">
              {QUICK_REASONS.map(r => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setLegalReason(r)}
                  className={`px-2 py-0.5 rounded text-[9.5px] font-semibold transition cursor-pointer ${
                    legalReason === r
                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                      : "bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-750"
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* LIVE BALANCE PREVIEW CALLOUT */}
          <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/60 p-4 rounded-xl border border-indigo-500/30 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-emerald-300 block">
                Write Credits Balance
              </span>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="font-mono text-slate-400 line-through text-xs">
                  {currentCredits.toLocaleString()}
                </span>
                <ArrowRight className="w-3 h-3 text-emerald-400" />
                <span className="font-mono font-black text-emerald-400 text-sm">
                  {calculatedNewCredits.toLocaleString()} CR
                </span>
              </div>
            </div>

            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-indigo-300 block">
                SMS Credits Balance
              </span>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="font-mono text-slate-400 line-through text-xs">
                  {currentSmsCredits.toLocaleString()}
                </span>
                <ArrowRight className="w-3 h-3 text-indigo-400" />
                <span className="font-mono font-black text-indigo-400 text-sm">
                  {calculatedNewSmsCredits.toLocaleString()} SMS
                </span>
              </div>
            </div>

            <div className="text-left sm:text-right">
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-300 block">
                Target SaaS Tier
              </span>
              <span className="text-xs font-bold text-white block mt-0.5 truncate">
                {effectivePlanName}
              </span>
            </div>
          </div>

        </div>

        {/* MODAL FOOTER */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-between items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
          >
            Cancel
          </button>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setShowConfirmModal(true)}
              disabled={isSubmitting || !legalReason.trim()}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all flex items-center gap-1.5 cursor-pointer uppercase tracking-wider"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Committing Changes...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Authorize & Allocate</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* SECONDARY CONFIRMATION CHECKPOINT */}
        {showConfirmModal && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xs p-6 flex flex-col justify-center items-center text-center space-y-4 z-20 animate-fade-in">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto">
              <ShieldCheck className="w-6 h-6" />
            </div>

            <div className="max-w-md space-y-2">
              <h3 className="text-base font-black text-white">Confirm Super Admin Platform Allocation</h3>
              <p className="text-xs text-slate-300 font-medium leading-relaxed">
                You are authorizing a direct balance mutation for farm node <strong className="text-white">{tenantName}</strong> ({tenantEmail}).
              </p>
            </div>

            <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-[11px] font-mono text-slate-300 text-left max-w-md w-full space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Write Action Credits:</span>
                <span className="font-bold text-emerald-400">{currentCredits} ➔ {calculatedNewCredits} CR</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">SMS Credits:</span>
                <span className="font-bold text-indigo-400">{currentSmsCredits} ➔ {calculatedNewSmsCredits} SMS</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">SaaS Plan:</span>
                <span className="font-bold text-amber-300">{effectivePlanName}</span>
              </div>
              <div className="pt-1 border-t border-slate-800 text-[10px] text-slate-400">
                <strong>Auditor:</strong> {auth.currentUser?.email || "support@mabala.cloud"}
              </div>
              <div className="text-[10px] text-slate-400">
                <strong>Rationale:</strong> {legalReason}
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                disabled={isSubmitting}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer"
              >
                Go Back
              </button>
              <button
                type="button"
                onClick={handleExecuteAllocation}
                disabled={isSubmitting}
                className="px-6 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg"
              >
                {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                <span>Execute Final Authorization</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default SuperAdminCreditAllocationModal;

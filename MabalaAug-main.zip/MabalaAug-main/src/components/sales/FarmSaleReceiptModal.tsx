import React, { useState, useRef } from "react";
import { 
  Printer, 
  Download, 
  X, 
  CheckCircle2, 
  ShieldCheck, 
  Share2, 
  Receipt, 
  Copy, 
  Check, 
  FileText,
  Building2,
  Phone,
  Mail,
  MapPin,
  Sparkles,
  QrCode
} from "lucide-react";
import jsPDF from "jspdf";
import { CashSale, Farm } from "../../types";

interface FarmSaleReceiptModalProps {
  sale: CashSale | null;
  isOpen: boolean;
  onClose: () => void;
  activeFarm?: Farm;
  currencySymbol: string;
  cashierName?: string;
}

// Convert numbers to words for financial receipts
function numberToWords(num: number): string {
  const a = [
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
    "Seventeen", "Eighteen", "Nineteen"
  ];
  const b = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

  const integerPart = Math.floor(Math.abs(num));
  const decimalPart = Math.round((Math.abs(num) - integerPart) * 100);

  function inWords(n: number): string {
    if (n === 0) return "Zero";
    if (n < 20) return a[n];
    if (n < 100) return b[Math.floor(n / 10)] + (n % 10 !== 0 ? " " + a[n % 10] : "");
    if (n < 1000) return a[Math.floor(n / 100)] + " Hundred" + (n % 100 !== 0 ? " and " + inWords(n % 100) : "");
    if (n < 1000000) return inWords(Math.floor(n / 1000)) + " Thousand" + (n % 1000 !== 0 ? " " + inWords(n % 1000) : "");
    if (n < 1000000000) return inWords(Math.floor(n / 1000000)) + " Million" + (n % 1000000 !== 0 ? " " + inWords(n % 1000000) : "");
    return n.toString();
  }

  const words = inWords(integerPart);
  const cents = decimalPart > 0 ? ` and ${decimalPart}/100` : " Only";
  return `${words}${cents}`;
}

export default function FarmSaleReceiptModal({
  sale,
  isOpen,
  onClose,
  activeFarm,
  currencySymbol,
  cashierName = "Cash Desk Supervisor"
}: FarmSaleReceiptModalProps) {
  const [receiptFormat, setReceiptFormat] = useState<"a4" | "thermal">("a4");
  const [copied, setCopied] = useState(false);
  const receiptRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !sale) return null;

  // Calculate tax and subtotal
  const taxRate = sale.taxRate !== undefined ? sale.taxRate : (sale.taxAmount ? 16 : 0);
  const subtotal = sale.subtotal !== undefined 
    ? sale.subtotal 
    : (taxRate > 0 ? (sale.amount / (1 + taxRate / 100)) : sale.amount);
  const taxAmount = sale.taxAmount !== undefined 
    ? sale.taxAmount 
    : (sale.amount - subtotal);

  const receiptNo = sale.receiptNumber || (sale.id.startsWith("REC-") ? sale.id : `REC-${sale.id.replace(/[^a-zA-Z0-9]/g, "").slice(-8).toUpperCase()}`);
  const formattedDate = sale.date || new Date().toISOString().split("T")[0];
  const timeStamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Handle standard browser print
  const handlePrint = () => {
    window.print();
  };

  // Generate and download formal PDF
  const handleDownloadPdf = () => {
    try {
      const doc = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4"
      });

      const pageWidth = 210;
      const pageHeight = 297;
      const margin = 15;

      // 1. Top Emerald Decorative Header Band
      doc.setFillColor(15, 23, 42); // Slate-900
      doc.rect(0, 0, pageWidth, 16, "F");

      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8.5);
      doc.text("MABALA FINANCIAL TRANSACTION STANDARD • CASH RECEIPT VOUCHER", margin, 10.5);

      if (activeFarm?.name) {
        doc.setFont("helvetica", "bold");
        doc.setFontSize(8.5);
        doc.setTextColor(248, 250, 252);
        doc.text(activeFarm.name.toUpperCase(), 195, 10.5, { align: "right" });
      }

      // 2. Issuer Farm Details
      let y = 25;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(14);
      doc.setTextColor(15, 23, 42);
      doc.text(activeFarm?.name || "Mabala Enterprise Farm Estate", margin, y);
      y += 5;

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.setTextColor(71, 85, 105);
      doc.text(`TPIN: ${activeFarm?.tpin || "100431290"}${activeFarm?.phone ? ` | PH: ${activeFarm.phone}` : ""}`, margin, y);
      y += 4.5;
      doc.text(`Email: ${activeFarm?.email || "sales@mabala.cloud"} | Address: ${activeFarm?.address || "Zambia Agricultural Sector"}`, margin, y);
      y += 7;

      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.4);
      doc.line(margin, y, 195, y);
      y += 8;

      // 3. Receipt Metadata Panel (2 Columns)
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, y, 180, 26, "F");
      doc.setDrawColor(226, 232, 240);
      doc.rect(margin, y, 180, 26, "D");

      // Left: Receipt Title & Number
      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      doc.text("OFFICIAL CASH RECEIPT", margin + 6, y + 8);

      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.setTextColor(16, 185, 129); // Emerald-600
      doc.text(`RECEIPT REF: ${receiptNo}`, margin + 6, y + 15);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(71, 85, 105);
      doc.text(`Date Issued: ${formattedDate} ${timeStamp} | Cashier: ${sale.cashierName || cashierName}`, margin + 6, y + 21);

      // Right: Customer & Payment Method
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.setTextColor(15, 23, 42);
      doc.text("BILLED TO / RECEIVED FROM:", 190, y + 8, { align: "right" });

      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.setTextColor(30, 41, 59);
      doc.text(sale.customer || "General Walk-in Customer", 190, y + 14, { align: "right" });

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(71, 85, 105);
      const payMeta = `Mode: ${sale.paymentMethod} ${sale.customerTpin ? `| TPIN: ${sale.customerTpin}` : ""}`;
      doc.text(payMeta, 190, y + 20, { align: "right" });

      y += 33;

      // 4. Itemized Particulars Table Header
      doc.setFillColor(241, 245, 249);
      doc.rect(margin, y, 180, 8, "F");

      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.setTextColor(71, 85, 105);
      doc.text("TRANSACTION PARTICULARS & SPECIFICATIONS", margin + 4, y + 5.5);
      doc.text("QTY / WEIGHT", 125, y + 5.5, { align: "center" });
      doc.text("UNIT RATE", 155, y + 5.5, { align: "right" });
      doc.text("AMOUNT", 190, y + 5.5, { align: "right" });

      y += 8;

      // Item Row
      doc.setFillColor(255, 255, 255);
      doc.rect(margin, y, 180, 14, "F");
      doc.setDrawColor(241, 245, 249);
      doc.line(margin, y + 14, 195, y + 14);

      doc.setFont("helvetica", "bold");
      doc.setFontSize(8.5);
      doc.setTextColor(15, 23, 42);
      
      const itemTitle = sale.animalTagId 
        ? `Livestock: Tag #${sale.animalTagId} (${sale.animalSpecies || 'Livestock'} - ${sale.animalBreed || 'Breed'})` 
        : sale.description;
      doc.text(itemTitle, margin + 4, y + 6);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      const subNotes = sale.animalWeightKg 
        ? `Live Scale Weight: ${sale.animalWeightKg} kg | Source: Animal Herd Inventory`
        : `Ref: ${sale.id} | General Farm Cash Posting`;
      doc.text(subNotes, margin + 4, y + 11);

      // Qty & Rates
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.setTextColor(30, 41, 59);
      const qtyStr = sale.animalWeightKg ? `${sale.animalWeightKg} kg` : (sale.headcount ? `${sale.headcount} Head` : "1 Lot");
      doc.text(qtyStr, 125, y + 8, { align: "center" });

      const rateStr = sale.pricePerKg 
        ? `${currencySymbol} ${sale.pricePerKg.toLocaleString(undefined, { minimumFractionDigits: 2 })}/kg`
        : `${currencySymbol} ${subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
      doc.text(rateStr, 155, y + 8, { align: "right" });

      doc.setFont("helvetica", "bold");
      doc.text(`${currencySymbol} ${subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 190, y + 8, { align: "right" });

      y += 20;

      // 5. Total Calculations Box
      doc.setFillColor(248, 250, 252);
      doc.rect(margin + 90, y, 90, 28, "F");
      doc.setDrawColor(226, 232, 240);
      doc.rect(margin + 90, y, 90, 28, "D");

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(71, 85, 105);
      doc.text("Subtotal (Excl. VAT):", margin + 95, y + 6);
      doc.text(`${currencySymbol} ${subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 190, y + 6, { align: "right" });

      doc.text(`ZRA Output VAT (${taxRate}%):`, margin + 95, y + 13);
      doc.text(`${currencySymbol} ${taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 190, y + 13, { align: "right" });

      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.setTextColor(15, 23, 42);
      doc.text("TOTAL CASH RECEIVED:", margin + 95, y + 22);
      doc.setTextColor(16, 185, 129); // Emerald
      doc.text(`${currencySymbol} ${sale.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 190, y + 22, { align: "right" });

      // Amount in words
      y += 34;
      doc.setFillColor(241, 245, 249);
      doc.rect(margin, y, 180, 10, "F");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(7.5);
      doc.setTextColor(71, 85, 105);
      doc.text("AMOUNT IN WORDS:", margin + 4, y + 6);
      doc.setFont("helvetica", "italic");
      doc.setTextColor(15, 23, 42);
      doc.text(numberToWords(sale.amount), margin + 40, y + 6);

      // 6. Double Entry Accounting Audit Box
      y += 16;
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, y, 180, 14, "F");
      doc.setDrawColor(226, 232, 240);
      doc.rect(margin, y, 180, 14, "D");

      doc.setFont("helvetica", "bold");
      doc.setFontSize(7.5);
      doc.setTextColor(15, 23, 42);
      const coaCrDesc = sale.coaCredit === "4300" ? "Livestock Sales Revenue" : (sale.coaCredit === "1100" ? "Customer Receivables Settlement" : "Farm Sales Revenue");
      doc.text("ISO DOUBLE-ENTRY FINANCIAL LEDGER POSTING REF:", margin + 4, y + 5);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(7);
      doc.setTextColor(71, 85, 105);
      doc.text(`Dr [${sale.coaDebit || "1010"}] Operational Cash / Bank Safe • Cr [${sale.coaCredit || "4200"}] ${coaCrDesc} • Cr [2070] Output Tax (${currencySymbol} ${taxAmount.toFixed(2)})`, margin + 4, y + 10);

      // 7. Official Seal & Paid Badge
      y += 20;
      doc.setFillColor(236, 253, 245);
      doc.rect(margin + 55, y, 70, 14, "F");
      doc.setDrawColor(16, 185, 129);
      doc.setLineWidth(0.6);
      doc.rect(margin + 55, y, 70, 14, "D");

      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.setTextColor(6, 95, 70);
      doc.text("✓ PAID & RECEIVED IN FULL", margin + 90, y + 6, { align: "center" });

      doc.setFont("helvetica", "normal");
      doc.setFontSize(6.5);
      doc.setTextColor(16, 185, 129);
      doc.text("MABALA ELECTRONIC CASHIER VERIFIED RECEIPT", margin + 90, y + 11, { align: "center" });

      // Footer
      doc.setFont("helvetica", "italic");
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184);
      doc.text("Thank you for your business. This official receipt confirms genuine payment and ledger clearance.", margin, pageHeight - 15);
      doc.text("Mabala Cloud Platform • Audit Trace Ref", 195, pageHeight - 15, { align: "right" });

      doc.save(`receipt_${receiptNo}.pdf`);
    } catch (err) {
      console.error("PDF generation failed:", err);
      alert("Failed to export PDF receipt. You can still use the Print button to print or save as PDF.");
    }
  };

  // Copy text receipt to clipboard
  const handleCopyText = () => {
    const textReceipt = `
========================================
       ${activeFarm?.name || "MABALA FARM ESTATE"}
        OFFICIAL CASH RECEIPT
========================================
Receipt No: ${receiptNo}
Date: ${formattedDate} ${timeStamp}
Cashier: ${sale.cashierName || cashierName}
Customer: ${sale.customer || "General Customer"}
Payment Method: ${sale.paymentMethod}
----------------------------------------
Item: ${sale.description}
${sale.animalTagId ? `Tag ID: #${sale.animalTagId} (${sale.animalSpecies || 'Livestock'} - ${sale.animalBreed || 'Breed'})` : ""}
${sale.animalWeightKg ? `Weight: ${sale.animalWeightKg} kg @ ${currencySymbol}${sale.pricePerKg}/kg` : ""}
----------------------------------------
Subtotal: ${currencySymbol} ${subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
Tax/VAT: ${currencySymbol} ${taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
TOTAL PAID: ${currencySymbol} ${sale.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
(${numberToWords(sale.amount)})
----------------------------------------
Ledger Ref: Dr ${sale.coaDebit || "1010"} / Cr ${sale.coaCredit || "4200"}
Status: ✓ PAID & VERIFIED
========================================
Thank you for your business!
`.trim();

    navigator.clipboard.writeText(textReceipt).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="fixed inset-0 z-[120] bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fade-in print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200 text-slate-900 my-6 print:border-none print:shadow-none print:max-w-none print:my-0">
        
        {/* Top Control Bar (Hidden when Printing) */}
        <div className="bg-slate-900 text-white px-5 py-3.5 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-emerald-400" />
            <div>
              <span className="text-xs font-black uppercase tracking-wider block">Official Farm Cash Receipt</span>
              <span className="text-[10px] text-slate-400 font-mono">{receiptNo}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Format Toggle (A4 vs Thermal Slip) */}
            <div className="bg-slate-800 p-0.5 rounded-lg border border-slate-700 flex text-[10px] font-bold">
              <button
                type="button"
                onClick={() => setReceiptFormat("a4")}
                className={`px-2.5 py-1 rounded ${receiptFormat === "a4" ? "bg-emerald-600 text-white" : "text-slate-400 hover:text-slate-200"}`}
              >
                Standard A4
              </button>
              <button
                type="button"
                onClick={() => setReceiptFormat("thermal")}
                className={`px-2.5 py-1 rounded ${receiptFormat === "thermal" ? "bg-emerald-600 text-white" : "text-slate-400 hover:text-slate-200"}`}
              >
                POS Thermal Slip
              </button>
            </div>

            <button
              onClick={handleCopyText}
              title="Copy receipt text for SMS/WhatsApp"
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{copied ? "Copied" : "Copy"}</span>
            </button>

            <button
              onClick={handleDownloadPdf}
              className="p-1.5 sm:px-3 sm:py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">PDF</span>
            </button>

            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Receipt</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* RECEIPT CONTENT AREA */}
        {/* ========================================================================= */}
        <div ref={receiptRef} className="p-6 md:p-8 space-y-6 print:p-0">
          {receiptFormat === "a4" ? (
            /* --- STANDARD FULL A4 RECEIPT FORMAT --- */
            <div className="space-y-6 text-slate-800">
              
              {/* Header Letterhead */}
              <div className="flex justify-between items-start border-b-2 border-emerald-600 pb-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center font-black text-sm">
                      M
                    </div>
                    <div>
                      <h2 className="text-lg font-black text-slate-900 tracking-tight">{activeFarm?.name || "Mabala Corporate Estate Farm"}</h2>
                      <p className="text-[10px] uppercase font-extrabold text-emerald-700 tracking-wider">Official Farm Sales & Cash Receipt</p>
                    </div>
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium space-y-0.5 pt-1">
                    <p className="flex items-center gap-1"><MapPin className="w-3 h-3 text-slate-400" /> {activeFarm?.address || "Plot 4920, Agricultural Sector, Zambia"}</p>
                    <p className="flex items-center gap-1"><Phone className="w-3 h-3 text-slate-400" /> TPIN: {activeFarm?.tpin || "100431290"} | Phone: {activeFarm?.phone || "+260 977 123456"}</p>
                  </div>
                </div>

                <div className="text-right space-y-1">
                  <span className="inline-block px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-full text-[10px] font-black tracking-wider">
                    ✓ PAID & RECEIVED
                  </span>
                  <div className="font-mono text-xs font-bold text-slate-900">
                    No: <strong className="text-emerald-700 font-black">{receiptNo}</strong>
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Date: <span className="font-bold text-slate-700">{formattedDate}</span> {timeStamp}
                  </div>
                </div>
              </div>

              {/* Transaction Metadata Grid */}
              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                <div className="space-y-1">
                  <span className="text-[9px] uppercase font-black tracking-wider text-slate-400 block">Customer / Offtaker Details</span>
                  <p className="font-extrabold text-slate-900 text-sm">{sale.customer || "General Cash Customer"}</p>
                  {sale.customerTpin && (
                    <p className="text-[10px] text-slate-600 font-mono">TPIN: {sale.customerTpin}</p>
                  )}
                  {sale.customerPhone && (
                    <p className="text-[10px] text-slate-600">Contact: {sale.customerPhone}</p>
                  )}
                  <p className="text-[10px] text-emerald-700 font-bold">
                    {sale.sourceType === "livestock" || sale.animalTagId ? "🐄 Livestock Offtaker" : "🌾 Agricultural Produce Buyer"}
                  </p>
                </div>

                <div className="space-y-1 text-right">
                  <span className="text-[9px] uppercase font-black tracking-wider text-slate-400 block">Payment Particulars</span>
                  <p className="font-bold text-slate-800">
                    Method: <strong className="text-slate-900">{sale.paymentMethod}</strong>
                  </p>
                  <p className="text-[10px] text-slate-500 font-mono">
                    Ledger ID: {sale.id}
                  </p>
                  <p className="text-[10px] text-slate-500">
                    Desk Cashier: <strong className="text-slate-700">{sale.cashierName || cashierName}</strong>
                  </p>
                </div>
              </div>

              {/* Itemized Table */}
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-600 text-[10px] uppercase font-black border-b border-slate-200">
                    <tr>
                      <th className="p-3">Item / Asset Description</th>
                      <th className="p-3 text-center">Unit / Weight</th>
                      <th className="p-3 text-right">Unit Rate</th>
                      <th className="p-3 text-right">Subtotal</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    <tr className="bg-white">
                      <td className="p-3">
                        <div className="font-bold text-slate-900">
                          {sale.animalTagId 
                            ? `Live Biological Asset: Tag #${sale.animalTagId} (${sale.animalSpecies || 'Livestock'} - ${sale.animalBreed || 'Breed'})` 
                            : sale.description}
                        </div>
                        {sale.animalTagId && (
                          <div className="text-[10px] text-emerald-700 font-mono mt-0.5">
                            Livestock Registry Tag ID: {sale.animalTagId} • Weight: {sale.animalWeightKg || "Scale Verified"} kg
                          </div>
                        )}
                        {sale.storageLotId && (
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                            Warehouse Lot Ref: {sale.storageLotId}
                          </div>
                        )}
                      </td>
                      <td className="p-3 text-center font-mono text-slate-700">
                        {sale.animalWeightKg ? `${sale.animalWeightKg} kg` : (sale.headcount ? `${sale.headcount} Head` : "1 unit")}
                      </td>
                      <td className="p-3 text-right font-mono text-slate-700">
                        {sale.pricePerKg 
                          ? `${currencySymbol}${sale.pricePerKg.toLocaleString(undefined, { minimumFractionDigits: 2 })}/kg`
                          : `${currencySymbol}${subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}`}
                      </td>
                      <td className="p-3 text-right font-mono font-bold text-slate-900">
                        {currencySymbol}{subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Financial Calculation Breakdown */}
              <div className="flex justify-between items-start gap-4">
                <div className="flex-1 space-y-2">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-[11px] space-y-1">
                    <span className="text-[9px] uppercase font-black text-slate-400 block">Amount in Words</span>
                    <p className="font-bold italic text-slate-800">
                      {numberToWords(sale.amount)}
                    </p>
                  </div>

                  {/* Accounting Footnote */}
                  <div className="p-2.5 bg-emerald-50/60 rounded-xl border border-emerald-100 text-[10px] text-emerald-900">
                    <span className="font-bold block">Double-Entry Journal Reference:</span>
                    <span className="font-mono text-[9px] text-emerald-800">
                      Debit [{sale.coaDebit || "1010"}] Cash/Bank • Credit [{sale.coaCredit || "4200"}] {sale.coaCredit === "4300" ? "Livestock Sales Revenue" : "Farm Sales Revenue"} {taxAmount > 0 ? `• Credit [2070] Output VAT (${currencySymbol}${taxAmount.toFixed(2)})` : ""}
                    </span>
                  </div>
                </div>

                <div className="w-64 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs space-y-2">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal Excl. VAT:</span>
                    <span className="font-mono font-bold">{currencySymbol}{subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>VAT / Statutory Tax ({taxRate}%):</span>
                    <span className="font-mono font-bold">{currencySymbol}{taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="border-t border-slate-300 pt-2 flex justify-between items-center text-sm font-black text-slate-900">
                    <span>Cash Received:</span>
                    <span className="text-emerald-700 font-mono text-base font-black">
                      {currencySymbol}{sale.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              </div>

              {/* Official Seal / Signature Bar */}
              <div className="border-t border-slate-200 pt-4 flex justify-between items-end text-[10px] text-slate-500">
                <div>
                  <p className="font-bold text-slate-700">Issued by: {sale.cashierName || cashierName}</p>
                  <p>Mabala Platform Verified Electronic Audit Slip</p>
                </div>
                
                <div className="text-center border-2 border-dashed border-emerald-600 bg-emerald-50/50 px-4 py-2 rounded-xl">
                  <span className="text-emerald-800 font-black text-xs uppercase tracking-widest block">MABALA OFFICIAL RECEIPT</span>
                  <span className="text-[9px] font-mono text-emerald-700">AUTHENTICATED • AUDIT TRACE VERIFIED</span>
                </div>

                <div className="text-right">
                  <div className="h-8 border-b border-slate-400 w-32 ml-auto mb-1"></div>
                  <p className="font-bold text-slate-700">Authorized Cashier Stamp</p>
                </div>
              </div>

            </div>
          ) : (
            /* --- 80MM POS THERMAL SLIP FORMAT --- */
            <div className="max-w-xs mx-auto font-mono text-xs text-slate-900 space-y-3 bg-white p-4 border border-dashed border-slate-300 rounded-xl shadow-xs">
              <div className="text-center space-y-0.5 border-b border-dashed pb-2">
                <h3 className="font-black text-sm uppercase">{activeFarm?.name || "MABALA FARM ESTATE"}</h3>
                <p className="text-[10px] text-slate-600">TPIN: {activeFarm?.tpin || "100431290"}</p>
                <p className="text-[10px] text-slate-600">{activeFarm?.phone || "+260 977 123456"}</p>
                <p className="text-[10px] font-black text-emerald-700 uppercase mt-1">*** OFFICIAL CASH RECEIPT ***</p>
              </div>

              <div className="space-y-1 text-[11px] border-b border-dashed pb-2">
                <div className="flex justify-between">
                  <span>Receipt No:</span>
                  <span className="font-bold">{receiptNo}</span>
                </div>
                <div className="flex justify-between">
                  <span>Date:</span>
                  <span>{formattedDate} {timeStamp}</span>
                </div>
                <div className="flex justify-between">
                  <span>Customer:</span>
                  <span className="font-bold truncate max-w-[140px]">{sale.customer || "Cash Customer"}</span>
                </div>
                <div className="flex justify-between">
                  <span>Payment:</span>
                  <span className="font-bold">{sale.paymentMethod}</span>
                </div>
                <div className="flex justify-between">
                  <span>Cashier:</span>
                  <span>{sale.cashierName || cashierName}</span>
                </div>
              </div>

              <div className="space-y-1 border-b border-dashed pb-2 text-[11px]">
                <div className="font-bold">{sale.description}</div>
                {sale.animalTagId && (
                  <div className="text-[10px] text-slate-600">
                    Animal Tag: #{sale.animalTagId} ({sale.animalSpecies || 'Livestock'})
                  </div>
                )}
                {sale.animalWeightKg && (
                  <div className="text-[10px] text-slate-600">
                    Weight: {sale.animalWeightKg}kg @ {currencySymbol}{sale.pricePerKg}/kg
                  </div>
                )}
                <div className="flex justify-between pt-1">
                  <span>Subtotal:</span>
                  <span>{currencySymbol}{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>VAT ({taxRate}%):</span>
                  <span>{currencySymbol}{taxAmount.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-between items-center text-sm font-black border-b-2 border-slate-900 py-1.5">
                <span>TOTAL PAID:</span>
                <span>{currencySymbol}{sale.amount.toFixed(2)}</span>
              </div>

              <div className="text-center text-[10px] space-y-1 pt-1">
                <p className="italic">{numberToWords(sale.amount)}</p>
                <p className="font-black text-emerald-800">*** THANK YOU FOR YOUR BUSINESS ***</p>
                <p className="text-[9px] text-slate-400">Electronic Ledger Posting: Dr {sale.coaDebit || "1010"} / Cr {sale.coaCredit || "4200"}</p>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { 
  DollarSign, 
  Boxes, 
  AlertTriangle, 
  Check, 
  X, 
  User, 
  Building, 
  Beef,
  Trees,
  TrendingUp,
  Percent,
  Layers
} from "lucide-react";
import { StorageLot, CashSale, Farm, LivestockRecord, CropCycle } from "../../types";
import { HswService } from "../../services/hswService";
import { OrchardFinanceService } from "../../services/orchardFinanceService";
import { useToast } from "../Toast";

interface NewSaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeFarm?: Farm;
  farms?: Farm[];
  currencySymbol: string;
  userEmail?: string;
  tenantId?: string;
  livestock?: LivestockRecord[];
  crops?: CropCycle[];
  onSaleCreated?: (sale: CashSale) => void;
}

export function getPreRegisteredClients(): { name: string; type: string; tpin?: string; code?: string }[] {
  const clients: { name: string; type: string; tpin?: string; code?: string }[] = [];
  
  try {
    const raw = localStorage.getItem("mabala_customers");
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        parsed.forEach((c: any) => {
          const name = c.name || c.customerName;
          if (name && !clients.some(x => x.name.toLowerCase() === name.toLowerCase())) {
            clients.push({ name, type: "Registered Customer", tpin: c.tpin, code: c.id || c.code });
          }
        });
      }
    }
  } catch (e) {}

  try {
    const raw = localStorage.getItem("mabala_offtakers");
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        parsed.forEach((o: any) => {
          const name = o.legalName || o.name || o.offtakerName;
          if (name && !clients.some(x => x.name.toLowerCase() === name.toLowerCase())) {
            clients.push({ name, type: "Registered Offtaker", tpin: o.tpin, code: o.offtakerCode || o.id });
          }
        });
      }
    }
  } catch (e) {}

  const defaults = [
    { name: "Zambezi Grain Millers Ltd", type: "Registered Commercial Offtaker", tpin: "1002938481", code: "OFF-ZMB-01" },
    { name: "Lusaka Food & Commodity Buyers", type: "Registered Commodity Buyer", tpin: "1004829102", code: "OFF-LSK-02" },
    { name: "Chisamba Milling Company", type: "Registered Offtaker", tpin: "1005920193", code: "OFF-CSM-03" },
    { name: "National Milling Corporation", type: "Registered Grain Buyer", tpin: "1001928374", code: "OFF-NMC-04" },
    { name: "Mount Meru Commodities Ltd", type: "Registered Agricultural Offtaker", tpin: "1003829104", code: "OFF-MMC-05" },
    { name: "Novatek Feed & Grain Traders", type: "Registered Feed Miller / Offtaker", tpin: "1004920183", code: "OFF-NVT-06" },
    { name: "Zambeef Products PLC", type: "Registered Meat Offtaker / Abattoir", tpin: "1001829482", code: "OFF-ZMB-07" },
    { name: "Lusaka Meat Distributors", type: "Livestock Offtaker", tpin: "1009281726", code: "OFF-LMD-08" },
  ];

  defaults.forEach(d => {
    if (!clients.some(x => x.name.toLowerCase() === d.name.toLowerCase())) {
      clients.push(d);
    }
  });

  return clients;
}

export default function NewSaleModal({
  isOpen,
  onClose,
  activeFarm,
  farms = [],
  currencySymbol,
  userEmail,
  tenantId = "tenant-01",
  livestock = [],
  crops = [],
  onSaleCreated
}: NewSaleModalProps) {
  const showToast = useToast();

  // Mode: "direct" | "storage" | "livestock" | "orchard"
  const [saleCategory, setSaleCategory] = useState<"direct" | "storage" | "livestock" | "orchard">("direct");

  // General Sale fields
  const [description, setDescription] = useState("");
  const [customerName, setCustomerName] = useState("Zambezi Grain Millers Ltd");
  const [amount, setAmount] = useState<number | "">("");
  const [paymentMethod, setPaymentMethod] = useState("Cash");
  const [selectedFarmId, setSelectedFarmId] = useState<string>(activeFarm?.id || "farm-01");

  // Storage Lot Sale fields
  const [storageLots, setStorageLots] = useState<StorageLot[]>([]);
  const [selectedLotId, setSelectedLotId] = useState<string>("");
  const [saleUnitMode, setSaleUnitMode] = useState<"units" | "bags">("bags");
  const [quantitySold, setQuantitySold] = useState<number | "">("");
  const [salePricePerUnit, setSalePricePerUnit] = useState<number | "">("");

  // Bag Selling Fields
  const [bagsCount, setBagsCount] = useState<number | "">(10);
  const [kgPerBag, setKgPerBag] = useState<number>(50);
  const [pricePerBag, setPricePerBag] = useState<number | "">(350);

  // Livestock Sale Fields
  const [availableLivestock, setAvailableLivestock] = useState<LivestockRecord[]>([]);
  const [selectedAnimalTag, setSelectedAnimalTag] = useState<string>("");
  const [animalScaleWeight, setAnimalScaleWeight] = useState<number | "">(350);
  const [animalPricePerKg, setAnimalPricePerKg] = useState<number | "">(45);
  const [animalApplyVat, setAnimalApplyVat] = useState<boolean>(true);

  // Orchard / Fruit Sale Fields (Mabala Linkage)
  const [availableOrchardBlocks, setAvailableOrchardBlocks] = useState<CropCycle[]>([]);
  const [selectedOrchardBlockId, setSelectedOrchardBlockId] = useState<string>("");
  const [orchardQuantitySold, setOrchardQuantitySold] = useState<number | "">(100);
  const [orchardPricePerUnit, setOrchardPricePerUnit] = useState<number | "">(25);
  const [orchardUnitType, setOrchardUnitType] = useState<"kg" | "crates" | "units">("kg");
  const [orchardProduceType, setOrchardProduceType] = useState<string>("Hass Avocado Grade 1");
  const [orchardApplyVat, setOrchardApplyVat] = useState<boolean>(false);
  const [isPostingOrchard, setIsPostingOrchard] = useState<boolean>(false);

  const registeredClients = getPreRegisteredClients();

  // Load storage lots, livestock & orchard blocks on open
  useEffect(() => {
    if (isOpen) {
      const lots = HswService.getStorageLots().filter(
        l => l.status === "in_storage" || l.status === "partially_sold" || l.status === "pledged"
      );
      setStorageLots(lots);
      if (lots.length > 0) {
        setSelectedLotId(lots[0].id);
        setSalePricePerUnit(lots[0].valuationPricePerUnit || 0);
      }

      // Load livestock
      if (livestock && livestock.length > 0) {
        setAvailableLivestock(livestock.filter(r => r.status !== "Sold" && r.status !== "Dead"));
      } else {
        try {
          const raw = localStorage.getItem("mabala_livestock");
          if (raw) {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
              setAvailableLivestock(parsed.filter((r: any) => r.status !== "Sold" && r.status !== "Dead"));
            }
          }
        } catch (e) {}
      }

      // Load Orchard Blocks
      let loadedBlocks: CropCycle[] = [];
      if (crops && crops.length > 0) {
        loadedBlocks = crops.filter(c => c.cycleType === "perennial_orchard" || c.orchard !== undefined);
      }
      if (loadedBlocks.length === 0) {
        try {
          const raw = localStorage.getItem("mabala_crop_cycles") || localStorage.getItem("mabala_crops");
          if (raw) {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
              loadedBlocks = parsed.filter((c: any) => c.cycleType === "perennial_orchard" || c.orchard !== undefined);
            }
          }
        } catch (e) {}
      }
      
      // Fallback demo blocks if none configured yet
      if (loadedBlocks.length === 0) {
        loadedBlocks = [
          {
            id: "orchard-block-a1",
            cropType: "Hass Avocado",
            variety: "Hass (Duke 7 Rootstock)",
            fieldBlock: "Block A - North Slope",
            areaHectares: 2.5,
            plantingDate: "2024-01-15",
            expectedHarvestDate: "2027-04-30",
            expectedYieldKg: 12500,
            status: "Peak Production",
            cycleType: "perennial_orchard",
            milestones: [],
            expensesLinked: 35000,
            revenueLinked: 65000,
            farmId: selectedFarmId,
            projectedRevenue: 150000,
            actualRevenueToDate: 65000,
            actualExpensesToDate: 35000,
            netProfitToDate: 30000,
            revenueVariancePct: -0.566,
            orchard: {
              treeCount: 500,
              variety: "Hass",
              rootstock: "Duke 7",
              spacingRowM: 6,
              spacingTreeM: 4,
              irrigationType: "drip",
              projectedAnnualRevenue: 150000,
              pricePerUnitOrKg: 25,
              blockAreaHa: 2.5
            }
          },
          {
            id: "orchard-block-b2",
            cropType: "Macadamia",
            variety: "Beaumont 695",
            fieldBlock: "Block B - East Plateau",
            areaHectares: 4.0,
            plantingDate: "2023-11-20",
            expectedHarvestDate: "2028-06-15",
            expectedYieldKg: 18000,
            status: "Fruiting",
            cycleType: "perennial_orchard",
            milestones: [],
            expensesLinked: 42000,
            revenueLinked: 98000,
            farmId: selectedFarmId,
            projectedRevenue: 220000,
            actualRevenueToDate: 98000,
            actualExpensesToDate: 42000,
            netProfitToDate: 56000,
            revenueVariancePct: -0.554,
            orchard: {
              treeCount: 800,
              variety: "Beaumont 695",
              rootstock: "Seedling",
              spacingRowM: 7,
              spacingTreeM: 5,
              irrigationType: "micro_jet",
              projectedAnnualRevenue: 220000,
              pricePerUnitOrKg: 45,
              blockAreaHa: 4.0
            }
          }
        ];
      }

      setAvailableOrchardBlocks(loadedBlocks);
      if (loadedBlocks.length > 0 && !selectedOrchardBlockId) {
        setSelectedOrchardBlockId(loadedBlocks[0].id);
        const defaultPrice = loadedBlocks[0].orchard?.pricePerUnitOrKg || loadedBlocks[0].expectedSellingPricePerKg || 25;
        setOrchardPricePerUnit(defaultPrice);
        setOrchardProduceType(`${loadedBlocks[0].cropType || "Fruit"} (${loadedBlocks[0].variety || "Grade 1"})`);
      }
    }
  }, [isOpen, livestock, crops]);

  // Update selected farm default when activeFarm changes
  useEffect(() => {
    if (activeFarm?.id) {
      setSelectedFarmId(activeFarm.id);
    }
  }, [activeFarm]);

  if (!isOpen) return null;

  // Filter lots by farm node if farm selected
  const availableLotsForFarm = storageLots.filter(l => {
    if (!selectedFarmId) return true;
    return !l.farmNodeId || l.farmNodeId === selectedFarmId || selectedFarmId === "all";
  });

  const selectedLot = storageLots.find(l => l.id === selectedLotId);
  const pledgedQty = selectedLot?.pledge?.pledgedQuantity || 0;
  const availableBalance = selectedLot ? Math.max(0, selectedLot.quantityCurrent - pledgedQty) : 0;

  const numBags = Number(bagsCount) || 0;
  const numKgPerBag = Number(kgPerBag) || 50;
  const numPriceBag = Number(pricePerBag) || 0;

  const effectiveQtySold = saleUnitMode === "bags" ? (numBags * numKgPerBag) : (Number(quantitySold) || 0);
  const effectivePricePerUnit = saleUnitMode === "bags" ? (numPriceBag / (numKgPerBag || 1)) : (Number(salePricePerUnit) || 0);
  const calculatedStorageTotal = saleUnitMode === "bags" ? (numBags * numPriceBag) : (effectiveQtySold * effectivePricePerUnit);

  // Livestock calculations
  const selectedAnimal = availableLivestock.find(a => a.tagId === selectedAnimalTag || a.id === selectedAnimalTag);
  const numAnimalWeight = Number(animalScaleWeight) || 0;
  const numAnimalPriceKg = Number(animalPricePerKg) || 0;
  const livestockSubtotal = numAnimalWeight * numAnimalPriceKg;
  const livestockVatAmount = animalApplyVat ? livestockSubtotal * 0.16 : 0;
  const livestockTotal = livestockSubtotal + livestockVatAmount;

  // Orchard calculations
  const selectedOrchardBlock = availableOrchardBlocks.find(b => b.id === selectedOrchardBlockId);
  const numOrchardQty = Number(orchardQuantitySold) || 0;
  const numOrchardPrice = Number(orchardPricePerUnit) || 0;
  const orchardSubtotal = numOrchardQty * numOrchardPrice;
  const orchardVatAmount = orchardApplyVat ? orchardSubtotal * 0.16 : 0;
  const orchardTotal = orchardSubtotal + orchardVatAmount;

  const currentBlockActualRevenue = Number(selectedOrchardBlock?.actualRevenueToDate || selectedOrchardBlock?.revenueLinked || 0);
  const currentBlockProjectedRevenue = Number(selectedOrchardBlock?.projectedRevenue || selectedOrchardBlock?.orchard?.projectedAnnualRevenue || selectedOrchardBlock?.expectedRevenueProjection || 0);
  const projectedRevenueAfterSale = currentBlockActualRevenue + orchardTotal;
  const progressPctAfterSale = currentBlockProjectedRevenue > 0 ? Math.min(100, Math.round((projectedRevenueAfterSale / currentBlockProjectedRevenue) * 100)) : 0;

  // Validation for Storage Sale
  const isStorageSaleInvalid = saleCategory === "storage" && (
    !selectedLot ||
    effectiveQtySold <= 0 ||
    effectiveQtySold > availableBalance ||
    calculatedStorageTotal <= 0
  );

  const isLivestockSaleInvalid = saleCategory === "livestock" && (
    !selectedAnimalTag ||
    numAnimalWeight <= 0 ||
    numAnimalPriceKg <= 0 ||
    livestockTotal <= 0
  );

  const isOrchardSaleInvalid = saleCategory === "orchard" && (
    !selectedOrchardBlockId ||
    numOrchardQty <= 0 ||
    numOrchardPrice <= 0 ||
    orchardTotal <= 0 ||
    isPostingOrchard
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (saleCategory === "orchard") {
      // Hard Block Requirement: Fruit sale must be linked to a valid Orchard Block
      if (!selectedOrchardBlockId) {
        showToast("Hard Block Validation: Fruit sales require a valid Orchard Block ID (blockId). Uncategorized fruit sales are not permitted.", "error");
        return;
      }
      if (numOrchardQty <= 0 || numOrchardPrice <= 0) {
        showToast("Please enter a valid quantity and unit selling price for fruit harvest produce.", "error");
        return;
      }

      setIsPostingOrchard(true);
      const clientObj = registeredClients.find(c => c.name === customerName);
      const saleReceipt = `REC-ORCH-${Math.floor(100000 + Math.random() * 900000)}`;
      const saleDocId = `CS-ORCH-${Date.now().toString().slice(-6)}`;

      try {
        const result = await OrchardFinanceService.postOrchardSale({
          saleId: saleDocId,
          blockId: selectedOrchardBlockId,
          treeGroupId: (selectedOrchardBlock as any)?.treeGroupId,
          tenantId,
          amount: orchardTotal,
          buyer: customerName || "Fruit Offtaker",
          quantity: numOrchardQty,
          unitPrice: numOrchardPrice,
          productType: "fruit",
          productName: orchardProduceType || `${selectedOrchardBlock?.cropType || "Orchard"} Fruit`,
          receiptNumber: saleReceipt,
          date: new Date().toISOString().split("T")[0]
        });

        const sale: CashSale = {
          id: saleDocId,
          receiptNumber: saleReceipt,
          date: new Date().toISOString().split("T")[0],
          description: `Orchard Fruit Sale: ${orchardProduceType || selectedOrchardBlock?.cropType} (${numOrchardQty} ${orchardUnitType} @ ${currencySymbol}${numOrchardPrice}/${orchardUnitType}) from Block [${selectedOrchardBlock?.fieldBlock || selectedOrchardBlock?.cropType}]`,
          customer: customerName || "Fruit Offtaker",
          customerTpin: clientObj?.tpin,
          amount: orchardTotal,
          subtotal: orchardSubtotal,
          taxRate: orchardApplyVat ? 16 : 0,
          taxAmount: orchardVatAmount,
          paymentMethod: paymentMethod as CashSale["paymentMethod"],
          coaDebit: "1010",
          coaCredit: "4300", // Fruit Sales Revenue
          farmId: selectedFarmId,
          tenantId,
          sourceType: "orchard" as any,
          blockId: selectedOrchardBlockId,
          productType: "fruit",
          cashierName: userEmail || "Farm Cash Desk"
        };

        const targetProj = selectedOrchardBlock?.projectedRevenue || selectedOrchardBlock?.orchard?.projectedAnnualRevenue || 0;
        const varianceStr = targetProj > 0 
          ? ` (${((result.actualRevenueToDate / targetProj) * 100).toFixed(1)}% of ${currencySymbol}${targetProj.toLocaleString()} target achieved)`
          : "";

        showToast(`Posted fruit sale of ${currencySymbol}${orchardTotal.toLocaleString()} to Block '${selectedOrchardBlock?.fieldBlock || selectedOrchardBlockId}'!${varianceStr}`, "success");
        if (onSaleCreated) {
          onSaleCreated(sale);
        }
        onClose();
      } catch (err: any) {
        showToast(err.message || "Failed to post fruit sale to Orchard Finance ledger.", "error");
      } finally {
        setIsPostingOrchard(false);
      }
      return;
    }

    if (saleCategory === "storage") {
      if (!selectedLot) {
        showToast("Please select a valid storage lot", "error");
        return;
      }
      if (effectiveQtySold <= 0) {
        showToast("Please enter a valid quantity or bag count to sell", "error");
        return;
      }
      if (effectiveQtySold > availableBalance) {
        showToast(`Cannot sell ${effectiveQtySold} ${selectedLot.unit}: Exceeds available lot balance of ${availableBalance} ${selectedLot.unit}!`, "error");
        return;
      }

      try {
        const res = HswService.sellFromStorage({
          lotId: selectedLot.id,
          quantitySold: effectiveQtySold,
          salePricePerUnit: effectivePricePerUnit,
          bagsSold: saleUnitMode === "bags" ? numBags : undefined,
          weightPerBagKg: saleUnitMode === "bags" ? numKgPerBag : undefined,
          customerName: customerName || "Zambezi Grain Millers Ltd",
          loggedBy: userEmail || "Farm Cashier",
          paymentMethod: paymentMethod,
          tenantId,
          farmId: selectedFarmId
        });

        const detailMsg = saleUnitMode === "bags" 
          ? `Recorded bag sale of ${numBags} bags (${effectiveQtySold} kg total) from storage!`
          : `Recorded sale of ${effectiveQtySold} ${selectedLot.unit} from storage lot!`;

        showToast(detailMsg, "success");
        if (onSaleCreated) {
          onSaleCreated(res.sale);
        }
        onClose();
      } catch (err: any) {
        showToast(err.message || "Failed to process sale from storage", "error");
      }
    } else if (saleCategory === "livestock") {
      // Livestock Sale Submission
      if (!selectedAnimal) {
        showToast("Please select an animal from the herd register", "error");
        return;
      }

      const clientObj = registeredClients.find(c => c.name === customerName);

      const sale: CashSale = {
        id: `CS-LS-${Date.now().toString().slice(-6)}`,
        receiptNumber: `REC-LS-${Math.floor(100000 + Math.random() * 900000)}`,
        date: new Date().toISOString().split("T")[0],
        description: `Sale of Live ${selectedAnimal.species || "Livestock"}: Tag #${selectedAnimal.tagId} (${selectedAnimal.breed || selectedAnimal.category || "Animal"}), ${numAnimalWeight}kg @ ${currencySymbol}${numAnimalPriceKg}/kg`,
        customer: customerName || "General Livestock Buyer",
        customerTpin: clientObj?.tpin,
        amount: livestockTotal,
        subtotal: livestockSubtotal,
        taxRate: animalApplyVat ? 16 : 0,
        taxAmount: livestockVatAmount,
        paymentMethod: paymentMethod as CashSale["paymentMethod"],
        coaDebit: "1010",
        coaCredit: "4300", // Livestock Sales Revenue
        farmId: selectedFarmId,
        tenantId,
        sourceType: "livestock",
        animalTagId: selectedAnimal.tagId,
        animalSpecies: selectedAnimal.species || "Livestock",
        animalBreed: selectedAnimal.breed || "Standard",
        animalWeightKg: numAnimalWeight,
        pricePerKg: numAnimalPriceKg,
        headcount: 1,
        cashierName: userEmail || "Farm Cash Desk"
      };

      // Mark the animal as "Sold" in local registry
      try {
        const raw = localStorage.getItem("mabala_livestock");
        if (raw) {
          const parsed = JSON.parse(raw);
          const updated = parsed.map((item: any) => 
            (item.tagId === selectedAnimal.tagId || item.id === selectedAnimal.id)
              ? { ...item, status: "Sold", dateSold: new Date().toISOString().split("T")[0], soldPrice: livestockTotal }
              : item
          );
          localStorage.setItem("mabala_livestock", JSON.stringify(updated));
        }
      } catch (e) {}

      showToast(`Recorded livestock sale of Tag #${selectedAnimal.tagId} (${currencySymbol}${livestockTotal.toLocaleString()})!`, "success");
      if (onSaleCreated) {
        onSaleCreated(sale);
      }
      onClose();
    } else {
      // Standard Direct Cash Sale
      const numAmount = Number(amount) || 0;
      if (numAmount <= 0) {
        showToast("Please enter a valid sale amount", "error");
        return;
      }

      const clientObj = registeredClients.find(c => c.name === customerName);

      const sale: CashSale = {
        id: `sale-direct-${Date.now()}`,
        receiptNumber: `REC-${Math.floor(100000 + Math.random() * 900000)}`,
        date: new Date().toISOString().split("T")[0],
        description: description || "Direct Farm Cash Sale",
        customer: customerName || "General Customer",
        customerTpin: clientObj?.tpin,
        amount: numAmount,
        subtotal: numAmount,
        taxRate: 0,
        taxAmount: 0,
        paymentMethod: paymentMethod as CashSale["paymentMethod"],
        coaDebit: "1010",
        coaCredit: "4200", // Farm Produce Revenue
        farmId: selectedFarmId,
        tenantId,
        sourceType: "direct",
        cashierName: userEmail || "Farm Cash Desk"
      };

      showToast(`Recorded direct sale of ${currencySymbol}${numAmount.toLocaleString()}!`, "success");
      if (onSaleCreated) {
        onSaleCreated(sale);
      }
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-scale-up">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-emerald-800 to-teal-900 text-white flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 rounded-xl">
              <DollarSign className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm uppercase tracking-wider">Record Sales & Cash Receipt</h3>
              <p className="text-[11px] text-emerald-200 font-medium">Log cashier desk receipts, warehouse grain sales, or sold livestock</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/10 rounded-lg text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Sale Category Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-extrabold">
            <button
              type="button"
              onClick={() => setSaleCategory("direct")}
              className={`py-2 px-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                saleCategory === "direct" 
                  ? "bg-white text-emerald-800 shadow-xs" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>Direct Cash</span>
            </button>

            <button
              type="button"
              onClick={() => setSaleCategory("orchard")}
              className={`py-2 px-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                saleCategory === "orchard" 
                  ? "bg-white text-emerald-800 shadow-xs" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <Trees className="w-3.5 h-3.5 text-emerald-600" />
              <span>Orchard Fruit</span>
            </button>

            <button
              type="button"
              onClick={() => setSaleCategory("storage")}
              className={`py-2 px-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                saleCategory === "storage" 
                  ? "bg-white text-emerald-800 shadow-xs" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <Boxes className="w-3.5 h-3.5" />
              <span>From Storage</span>
            </button>

            <button
              type="button"
              onClick={() => setSaleCategory("livestock")}
              className={`py-2 px-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                saleCategory === "livestock" 
                  ? "bg-white text-emerald-800 shadow-xs" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <Beef className="w-3.5 h-3.5" />
              <span>Live Animal</span>
            </button>
          </div>

          {/* Farm Node Selector */}
          <div>
            <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
              Farm Node / Workspace Location
            </label>
            <div className="relative">
              <Building className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <select
                value={selectedFarmId}
                onChange={e => setSelectedFarmId(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border rounded-xl bg-slate-50 focus:bg-white text-slate-800 font-semibold outline-none focus:border-emerald-500"
              >
                {farms.length > 0 ? (
                  farms.map(f => (
                    <option key={f.id} value={f.id}>
                      {f.name} ({f.address || "Main Farm"})
                    </option>
                  ))
                ) : (
                  <option value="farm-01">Main Operations Farm</option>
                )}
                <option value="all">All Workspace Nodes</option>
              </select>
            </div>
          </div>

          {/* ========================================================= */}
          {/* ORCHARD & FRUIT HARVEST SALE MODE (Mabala Linkage) */}
          {/* ========================================================= */}
          {saleCategory === "orchard" && (
            <div className="space-y-4 bg-emerald-50/60 p-4 rounded-xl border border-emerald-300">
              <div className="flex items-center justify-between border-b border-emerald-200 pb-2">
                <div className="flex items-center gap-1.5 text-xs font-black text-emerald-950">
                  <Trees className="w-4 h-4 text-emerald-700" />
                  <span>Mandatory Orchard Block Attribution</span>
                </div>
                <span className="text-[10px] bg-emerald-200/80 text-emerald-900 px-2 py-0.5 rounded-md font-extrabold">
                  COA Cr 4300 Fruit Revenue
                </span>
              </div>

              {/* Block Picker */}
              <div>
                <label className="text-[10px] font-bold text-slate-700 uppercase block mb-1">
                  Originating Orchard Block * (Hard Validation)
                </label>
                {availableOrchardBlocks.length === 0 ? (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-800 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                    <span>No active orchard blocks found. Fruit sales require a registered Orchard Block.</span>
                  </div>
                ) : (
                  <select
                    value={selectedOrchardBlockId}
                    onChange={e => {
                      const blockId = e.target.value;
                      setSelectedOrchardBlockId(blockId);
                      const block = availableOrchardBlocks.find(b => b.id === blockId);
                      if (block) {
                        const defaultPrice = block.orchard?.pricePerUnitOrKg || block.expectedSellingPricePerKg || 25;
                        setOrchardPricePerUnit(defaultPrice);
                        setOrchardProduceType(`${block.cropType || "Fruit"} (${block.variety || "Standard"})`);
                      }
                    }}
                    required
                    className="w-full text-xs p-2.5 border border-emerald-300 rounded-xl bg-white text-slate-900 font-bold outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="">-- Choose Originating Orchard Block --</option>
                    {availableOrchardBlocks.map(b => (
                      <option key={b.id} value={b.id}>
                        [{b.fieldBlock || b.cropType}] {b.cropType} ({b.variety || "Perennial"}) • {b.orchard?.treeCount || "—"} trees • Projected Rev: {currencySymbol}{(b.projectedRevenue || b.orchard?.projectedAnnualRevenue || 0).toLocaleString()}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {/* Selected Block Performance Intel Card */}
              {selectedOrchardBlock && (
                <div className="bg-white p-3.5 rounded-xl border border-emerald-200 space-y-2 text-xs">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-extrabold text-slate-900 flex items-center gap-1.5">
                        <span>{selectedOrchardBlock.fieldBlock || selectedOrchardBlock.cropType}</span>
                        <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold">
                          {selectedOrchardBlock.status || "Active Orchard"}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500">
                        {selectedOrchardBlock.cropType} — {selectedOrchardBlock.variety} • {selectedOrchardBlock.orchard?.treeCount || 0} trees on {selectedOrchardBlock.areaHectares || selectedOrchardBlock.orchard?.blockAreaHa || 1} ha
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Target Revenue</span>
                      <span className="font-mono font-bold text-slate-800 text-xs">
                        {currencySymbol}{currentBlockProjectedRevenue.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-1 pt-1">
                    <div className="flex justify-between text-[10px] font-bold">
                      <span className="text-slate-600">
                        Actual Revenue: {currencySymbol}{currentBlockActualRevenue.toLocaleString()} 
                        <span className="text-emerald-700 font-black"> + {currencySymbol}{orchardTotal.toLocaleString()} this sale</span>
                      </span>
                      <span className="text-emerald-800">{progressPctAfterSale}% Target</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-emerald-500 to-teal-600 transition-all duration-500" 
                        style={{ width: `${Math.min(100, progressPctAfterSale)}%` }} 
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Fruit Produce Name & Unit Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">
                    Produce Description / Grade *
                  </label>
                  <input
                    type="text"
                    value={orchardProduceType}
                    onChange={e => setOrchardProduceType(e.target.value)}
                    placeholder="e.g. Hass Avocado Grade 1 Export"
                    required
                    className="w-full text-xs p-2.5 border rounded-xl font-bold bg-white text-slate-800 outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">
                    Measurement Unit
                  </label>
                  <select
                    value={orchardUnitType}
                    onChange={e => setOrchardUnitType(e.target.value as any)}
                    className="w-full text-xs p-2.5 border rounded-xl font-bold bg-white text-slate-800 outline-none focus:border-emerald-500"
                  >
                    <option value="kg">Kilograms (kg)</option>
                    <option value="crates">Field Crates / Boxes</option>
                    <option value="units">Single Fruit Units</option>
                  </select>
                </div>
              </div>

              {/* Quantity Sold & Price per Unit */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">
                    Quantity Sold ({orchardUnitType}) *
                  </label>
                  <input
                    type="number"
                    min="0.1"
                    step="0.1"
                    value={orchardQuantitySold}
                    onChange={e => setOrchardQuantitySold(e.target.value === "" ? "" : Number(e.target.value))}
                    required
                    className="w-full text-xs p-2.5 border rounded-xl font-mono font-bold bg-white outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">
                    Price / {orchardUnitType} ({currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    min="0.1"
                    step="0.01"
                    value={orchardPricePerUnit}
                    onChange={e => setOrchardPricePerUnit(e.target.value === "" ? "" : Number(e.target.value))}
                    required
                    className="w-full text-xs p-2.5 border rounded-xl font-mono font-bold bg-white outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* VAT Checkbox */}
              <div className="flex items-center gap-2 pt-1 select-none">
                <input
                  type="checkbox"
                  id="orchard-vat"
                  checked={orchardApplyVat}
                  onChange={e => setOrchardApplyVat(e.target.checked)}
                  className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="orchard-vat" className="text-xs font-bold text-slate-700 cursor-pointer">
                  Apply 16% ZRA Output VAT (Unprocessed fruit is typically 0% exempt)
                </label>
              </div>

              {/* Price Calculation Summary */}
              <div className="p-3.5 bg-emerald-900 text-white rounded-xl space-y-1 font-mono text-xs shadow-inner">
                <div className="flex justify-between text-[11px] text-emerald-200">
                  <span>Subtotal ({numOrchardQty} {orchardUnitType} × {currencySymbol}{numOrchardPrice}):</span>
                  <span>{currencySymbol}{orchardSubtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                {orchardApplyVat && (
                  <div className="flex justify-between text-[11px] text-emerald-200">
                    <span>16% Output VAT:</span>
                    <span>{currencySymbol}{orchardVatAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                )}
                <div className="flex justify-between items-center text-sm font-black pt-1 border-t border-emerald-800">
                  <span className="uppercase">Total Sale Value:</span>
                  <span className="text-base text-emerald-300">{currencySymbol}{orchardTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* 1. LIVESTOCK SALE MODE */}
          {/* ========================================================= */}
          {saleCategory === "livestock" && (
            <div className="space-y-4 bg-emerald-50/50 p-4 rounded-xl border border-emerald-200">
              <div className="flex items-center justify-between border-b border-emerald-200 pb-2">
                <div className="flex items-center gap-1.5 text-xs font-black text-emerald-900">
                  <Beef className="w-4 h-4 text-emerald-700" />
                  <span>Live Animal Asset Selection</span>
                </div>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md font-bold">
                  {availableLivestock.length} Animals in Herd
                </span>
              </div>

              {/* Tag Selector */}
              <div>
                <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">
                  Select Animal Tag *
                </label>
                {availableLivestock.length === 0 ? (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>No active animals found in livestock registry. You can register animals under Livestock Manager.</span>
                  </div>
                ) : (
                  <select
                    value={selectedAnimalTag}
                    onChange={e => {
                      setSelectedAnimalTag(e.target.value);
                      const target = availableLivestock.find(x => x.tagId === e.target.value || x.id === e.target.value);
                      if (target) {
                        if (target.weight) setAnimalScaleWeight(target.weight);
                      }
                    }}
                    required
                    className="w-full text-xs p-2.5 border rounded-xl bg-white text-slate-800 font-bold outline-none focus:border-emerald-500"
                  >
                    <option value="">-- Choose Animal Tag from Herd --</option>
                    {availableLivestock.map(animal => (
                      <option key={animal.id} value={animal.tagId || animal.id}>
                        Tag #{animal.tagId} — {animal.species} ({animal.breed}) • Weight: {animal.weight || "—"}kg • Appraised: {currencySymbol}{(animal.currentValue || 0).toLocaleString()}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {/* Selected Animal Details Card */}
              {selectedAnimal && (
                <div className="bg-white p-3.5 rounded-xl border border-emerald-200 space-y-1.5 text-xs">
                  <div className="flex justify-between items-center font-bold">
                    <span className="text-slate-900">Tag #{selectedAnimal.tagId} — {selectedAnimal.species}</span>
                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] rounded-md font-extrabold">
                      {selectedAnimal.breed || "Standard Breed"}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 pt-1">
                    <div>Pen / Location: <strong className="text-slate-800">{selectedAnimal.location || (selectedAnimal as any).penLocation || "General Pasture"}</strong></div>
                    <div>Recorded Weight: <strong className="text-slate-800">{selectedAnimal.weight || 350} kg</strong></div>
                  </div>
                </div>
              )}

              {/* Weight & Price per Kg */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">
                    Scale Weight (kg) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="0.1"
                    value={animalScaleWeight}
                    onChange={e => setAnimalScaleWeight(e.target.value === "" ? "" : Number(e.target.value))}
                    required
                    className="w-full text-xs p-2.5 border rounded-xl font-mono font-bold bg-white outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">
                    Price / Kg ({currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    min="0.1"
                    step="0.01"
                    value={animalPricePerKg}
                    onChange={e => setAnimalPricePerKg(e.target.value === "" ? "" : Number(e.target.value))}
                    required
                    className="w-full text-xs p-2.5 border rounded-xl font-mono font-bold bg-white outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* VAT Checkbox */}
              <div className="flex items-center gap-2 pt-1 select-none">
                <input
                  type="checkbox"
                  id="animal-vat"
                  checked={animalApplyVat}
                  onChange={e => setAnimalApplyVat(e.target.checked)}
                  className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="animal-vat" className="text-xs font-bold text-slate-700 cursor-pointer">
                  Apply 16% ZRA Statutory Output VAT
                </label>
              </div>

              {/* Price Calculation Summary */}
              <div className="p-3.5 bg-emerald-800 text-white rounded-xl space-y-1 font-mono text-xs">
                <div className="flex justify-between text-[11px] text-emerald-200">
                  <span>Subtotal ({numAnimalWeight}kg × {currencySymbol}{numAnimalPriceKg}/kg):</span>
                  <span>{currencySymbol}{livestockSubtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                {animalApplyVat && (
                  <div className="flex justify-between text-[11px] text-emerald-200">
                    <span>16% Output VAT:</span>
                    <span>{currencySymbol}{livestockVatAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                )}
                <div className="flex justify-between items-center text-sm font-black pt-1 border-t border-emerald-700">
                  <span className="uppercase">Total Sale Value:</span>
                  <span className="text-base text-emerald-300">{currencySymbol}{livestockTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* 2. STORAGE SALE MODE */}
          {/* ========================================================= */}
          {saleCategory === "storage" && (
            <div className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 border-b pb-2">
                <Boxes className="w-4 h-4 text-emerald-600" />
                <span>Storage Lot Selection</span>
              </div>

              {/* Lot Picker */}
              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                  Select Active Storage Lot
                </label>
                {availableLotsForFarm.length === 0 ? (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>No active storage lots found for this farm node.</span>
                  </div>
                ) : (
                  <select
                    value={selectedLotId}
                    onChange={e => {
                      const lotId = e.target.value;
                      setSelectedLotId(lotId);
                      const lot = storageLots.find(l => l.id === lotId);
                      if (lot) {
                        setSalePricePerUnit(lot.valuationPricePerUnit || 0);
                      }
                    }}
                    className="w-full text-xs p-2.5 border rounded-xl bg-white text-slate-800 font-bold outline-none focus:border-emerald-500"
                  >
                    {availableLotsForFarm.map(lot => {
                      const avail = Math.max(0, lot.quantityCurrent - (lot.pledge?.pledgedQuantity || 0));
                      return (
                        <option key={lot.id} value={lot.id}>
                          [{lot.id}] {lot.cropType} ({lot.grade || lot.variety}) — {avail} {lot.unit} Available @ {lot.warehouseId}
                        </option>
                      );
                    })}
                  </select>
                )}
              </div>

              {/* Selected Lot Detail Card */}
              {selectedLot && (
                <div className="bg-white p-3.5 rounded-xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-extrabold text-slate-900">{selectedLot.cropType} - {selectedLot.variety}</span>
                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold text-[10px] rounded-full">
                      {selectedLot.grade}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 pt-1">
                    <div>Total Lot Qty: <strong className="font-mono text-slate-800">{selectedLot.quantityCurrent} {selectedLot.unit}</strong></div>
                    <div>Available: <strong className="font-mono text-emerald-700 font-bold">{availableBalance} {selectedLot.unit}</strong></div>
                  </div>
                </div>
              )}

              {/* Unit Sale Mode Selector */}
              <div className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-200">
                <span className="text-xs font-bold text-slate-700">Sale Calculation Unit:</span>
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setSaleUnitMode("bags")}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
                      saleUnitMode === "bags" 
                        ? "bg-emerald-600 text-white shadow-sm" 
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    Sell per Bag (kg)
                  </button>
                  <button
                    type="button"
                    onClick={() => setSaleUnitMode("units")}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
                      saleUnitMode === "units" 
                        ? "bg-emerald-600 text-white shadow-sm" 
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    Direct Weight ({selectedLot?.unit || "Kg"})
                  </button>
                </div>
              </div>

              {/* Storage Sale Inputs */}
              {saleUnitMode === "bags" ? (
                <div className="space-y-3 bg-white p-3.5 rounded-xl border border-slate-200">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                        Number of Bags
                      </label>
                      <input
                        type="number"
                        min="1"
                        placeholder="e.g. 10"
                        value={bagsCount}
                        onChange={e => setBagsCount(e.target.value === "" ? "" : Number(e.target.value))}
                        required
                        className="w-full text-xs p-2.5 border rounded-xl font-mono font-bold bg-slate-50 focus:bg-white outline-none focus:border-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                        Weight per Bag (kg)
                      </label>
                      <select
                        value={kgPerBag}
                        onChange={e => setKgPerBag(Number(e.target.value))}
                        className="w-full text-xs p-2.5 border rounded-xl font-mono font-bold bg-slate-50 focus:bg-white outline-none focus:border-emerald-500"
                      >
                        <option value={25}>25 kg / bag</option>
                        <option value={50}>50 kg / bag (Standard)</option>
                        <option value={90}>90 kg / bag</option>
                        <option value={100}>100 kg / bag</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                        Price per Bag ({currencySymbol})
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        placeholder="e.g. 350.00"
                        value={pricePerBag}
                        onChange={e => setPricePerBag(e.target.value === "" ? "" : Number(e.target.value))}
                        required
                        className="w-full text-xs p-2.5 border rounded-xl font-mono font-bold bg-slate-50 focus:bg-white outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  <div className="p-2.5 bg-emerald-50/80 rounded-lg border border-emerald-200 text-xs text-emerald-900 flex justify-between items-center font-mono">
                    <span>Total Weight: <strong>{effectiveQtySold} kg</strong> ({numBags} Bags x {numKgPerBag}kg)</span>
                    <span>Rate: <strong>{currencySymbol}{(numPriceBag / (numKgPerBag || 1)).toFixed(2)} / kg</strong></span>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                      Quantity to Sell ({selectedLot?.unit || "Units"})
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      placeholder={`Max ${availableBalance}`}
                      value={quantitySold}
                      onChange={e => setQuantitySold(e.target.value === "" ? "" : Number(e.target.value))}
                      required
                      className="w-full text-xs p-2.5 border rounded-xl font-mono font-bold bg-white outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                      Sale Price per {selectedLot?.unit || "Unit"} ({currencySymbol})
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={salePricePerUnit}
                      onChange={e => setSalePricePerUnit(e.target.value === "" ? "" : Number(e.target.value))}
                      required
                      className="w-full text-xs p-2.5 border rounded-xl font-mono font-bold bg-white outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              )}

              {/* Calculated Total Box */}
              <div className="p-3 bg-emerald-800 text-white rounded-xl flex justify-between items-center">
                <span className="text-xs font-bold uppercase tracking-wider">Calculated Storage Sale Value:</span>
                <span className="text-lg font-black font-mono">
                  {currencySymbol}{calculatedStorageTotal.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* 3. DIRECT CASH SALE MODE */}
          {/* ========================================================= */}
          {saleCategory === "direct" && (
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                  Item / Sale Description *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Retail Bagged Sweet Corn Cash Desk Sale"
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  required
                  className="w-full text-xs p-2.5 border rounded-xl bg-slate-50 focus:bg-white outline-none focus:border-emerald-500 font-semibold"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                  Total Cash Amount Received ({currencySymbol}) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={amount}
                  onChange={e => setAmount(e.target.value === "" ? "" : Number(e.target.value))}
                  required
                  className="w-full text-xs p-2.5 border rounded-xl font-mono font-bold bg-slate-50 focus:bg-white outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          )}

          {/* Customer / Offtaker Selector */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase">
                Customer / Pre-Registered Offtaker *
              </label>
              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                Verified Directory
              </span>
            </div>
            <div className="relative">
              <User className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <select
                value={customerName}
                onChange={e => setCustomerName(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 text-xs border rounded-xl bg-slate-50 focus:bg-white font-bold text-slate-800 outline-none focus:border-emerald-500"
                required
              >
                {registeredClients.map((client, idx) => (
                  <option key={idx} value={client.name}>
                    {client.name} — [{client.type}]{client.tpin ? ` (TPIN: ${client.tpin})` : ""}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
              Payment Channel / Settlement Mode
            </label>
            <select
              value={paymentMethod}
              onChange={e => setPaymentMethod(e.target.value)}
              className="w-full text-xs p-2.5 border rounded-xl bg-slate-50 focus:bg-white outline-none focus:border-emerald-500 font-bold"
            >
              <option value="Cash">Cash Desk Office</option>
              <option value="Mobile Money">Airtel / MTN / Zamtel Mobile Money</option>
              <option value="Bank Transfer">Direct Bank Transfer</option>
              <option value="Cheque">Corporate Cheque</option>
            </select>
          </div>

          {/* Account Mapping Note */}
          <div className="p-3 bg-slate-50 rounded-xl border text-[11px] text-slate-600 flex items-center justify-between font-mono">
            <span>Accounting Ledger:</span>
            <span className="font-bold text-emerald-800">
              Dr 1010 Bank / Cr {saleCategory === "orchard" ? "4300 Fruit Sales Revenue (Block-Attributed)" : (saleCategory === "livestock" ? "4300 Livestock Sales" : "4200 Sales Revenue")}
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-2 pt-3 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isStorageSaleInvalid || isLivestockSaleInvalid || isOrchardSaleInvalid}
              className={`px-5 py-2 text-white text-xs font-black rounded-xl transition-all shadow-md flex items-center gap-1.5 ${
                (isStorageSaleInvalid || isLivestockSaleInvalid || isOrchardSaleInvalid)
                  ? "bg-slate-300 cursor-not-allowed"
                  : "bg-emerald-600 hover:bg-emerald-500 cursor-pointer active:scale-95"
              }`}
            >
              {isPostingOrchard ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Check className="w-4 h-4" />
              )}
              <span>
                {saleCategory === "orchard"
                  ? (isPostingOrchard ? "Posting to Block Ledger..." : "Post Fruit Sale to Block Ledger")
                  : (saleCategory === "storage" 
                      ? "Confirm Storage Sale" 
                      : (saleCategory === "livestock" ? "Post Animal Sale & Generate Receipt" : "Post Direct Cash Sale"))}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

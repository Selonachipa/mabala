import { safeFormatError } from "../../utils/errorUtils";
import React, { useState } from "react";
import { X, Mail, Send, CheckCircle2, AlertCircle, FileText, Building2, User, DollarSign, Calendar } from "lucide-react";

export interface SaleReceiptData {
  id: string;
  customer: string;
  customerEmail?: string;
  description: string;
  amount: number;
  date?: string;
  coaCredit?: string;
  farmName?: string;
  farmAddress?: string;
  farmPhone?: string;
  farmEmail?: string;
  farmTpin?: string;
  currencySymbol?: string;
  cashierName?: string;
}

interface EmailReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  sale: SaleReceiptData | null;
  onSendSuccess?: (recipientEmail: string) => void;
  isReadonly?: boolean;
}

export const EmailReceiptModal: React.FC<EmailReceiptModalProps> = ({
  isOpen,
  onClose,
  sale,
  onSendSuccess,
  isReadonly = false
}) => {
  const [recipientEmail, setRecipientEmail] = useState<string>(sale?.customerEmail || "");
  const [customerName, setCustomerName] = useState<string>(sale?.customer || "");
  const [additionalNotes, setAdditionalNotes] = useState<string>("");
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);

  // Sync state if sale changes
  React.useEffect(() => {
    if (sale) {
      setRecipientEmail(sale.customerEmail || (sale.customer?.includes("@") ? sale.customer : ""));
      setCustomerName(sale.customer || "Walk-in Customer");
      setSendSuccess(false);
      setErrorMsg(null);
      setShowPreview(false);
    }
  }, [sale]);

  if (!isOpen || !sale) return null;

  const currency = sale.currencySymbol || "K";
  const formattedAmount = (sale.amount ?? 0).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const handleSendEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isReadonly) {
      setErrorMsg("Action restricted: Your account is currently in Read-Only mode due to credit exhaustion.");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!recipientEmail || !emailRegex.test(recipientEmail.trim())) {
      setErrorMsg("Please enter a valid customer email address (e.g., customer@example.com)");
      return;
    }

    setIsSending(true);
    setErrorMsg(null);

    try {
      const payload = {
        saleId: sale.id,
        customerEmail: recipientEmail.trim().toLowerCase(),
        customerName: customerName || "Valued Customer",
        amount: sale.amount,
        currencySymbol: currency,
        description: sale.description,
        date: sale.date || new Date().toISOString().split("T")[0],
        farmName: sale.farmName || "Sunrise Agro-Tech Farm",
        farmAddress: sale.farmAddress || "Opp Oryx Filling Station, Mumbwa Road, Lusaka West",
        farmPhone: sale.farmPhone || "+260 978 070 734",
        farmEmail: sale.farmEmail || "billing@mabala.cloud",
        farmTpin: sale.farmTpin || "1002345678",
        cashierName: sale.cashierName || "Head Cashier",
        additionalNotes: additionalNotes.trim()
      };

      const response = await fetch("/api/sales/email-receipt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setSendSuccess(true);
        if (onSendSuccess) {
          onSendSuccess(recipientEmail.trim().toLowerCase());
        }
        setTimeout(() => {
          onClose();
        }, 1800);
      } else {
        throw new Error(data.error || data.message || "Failed to dispatch email receipt from server");
      }
    } catch (err: any) {
      console.error("[Email Receipt Dispatch Error]:", err);
      setErrorMsg(err.message || "Could not deliver email receipt. Please verify network connectivity and email format.");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in font-sans">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-white tracking-wide">
                Email Official Sales Receipt
              </h3>
              <p className="text-[11px] text-slate-400 font-medium">
                Deliver branded HTML sales voucher to customer inbox
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Sale Summary Snapshot Box */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-4 space-y-3">
            <div className="flex justify-between items-start border-b border-slate-200/60 pb-2.5">
              <div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">
                  Reference / Sale ID
                </span>
                <span className="font-mono font-extrabold text-xs text-emerald-700">
                  {sale.id}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">
                  Total Amount
                </span>
                <span className="font-mono font-extrabold text-sm text-slate-900">
                  {currency} {formattedAmount}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Description</span>
                <span className="font-medium text-slate-800 line-clamp-1">{sale.description || "Direct Farm Produce Sale"}</span>
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Date</span>
                <span className="font-medium text-slate-800">{sale.date || new Date().toISOString().split("T")[0]}</span>
              </div>
            </div>
          </div>

          {/* Form */}
          <form id="email-receipt-form" onSubmit={handleSendEmail} className="space-y-4">
            <div>
              <label className="block text-xs font-black text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                <span>Customer Email Address <span className="text-rose-500">*</span></span>
                <span className="text-[10px] text-slate-400 font-normal">Recipient destination</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  placeholder="customer@domain.com"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  disabled={isSending || sendSuccess}
                  className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-slate-700 uppercase tracking-wider mb-1.5">
                Customer Name / Business
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="e.g. John Mwanza or Fresh Mart Ltd"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  disabled={isSending || sendSuccess}
                  className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                <span>Custom Note on Receipt (Optional)</span>
                <span className="text-[10px] text-slate-400 font-normal">Included in footer</span>
              </label>
              <textarea
                rows={2}
                placeholder="e.g. Thank you for buying our farm-fresh produce! Grade A inspected."
                value={additionalNotes}
                onChange={(e) => setAdditionalNotes(e.target.value)}
                disabled={isSending || sendSuccess}
                className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 transition resize-none"
              />
            </div>

            {/* Toggle Live Preview */}
            <div className="pt-1">
              <button
                type="button"
                onClick={() => setShowPreview(!showPreview)}
                className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1.5 cursor-pointer underline decoration-dotted"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>{showPreview ? "Hide HTML Email Preview" : "Preview Formatted Receipt Email"}</span>
              </button>

              {showPreview && (
                <div className="mt-2.5 p-3.5 bg-slate-900 text-slate-100 rounded-xl text-[11px] font-mono border border-slate-700 space-y-2 max-h-48 overflow-y-auto">
                  <div className="text-emerald-400 font-bold border-b border-slate-800 pb-1 flex justify-between">
                    <span>MABALA DIGITAL RECEIPT PREVIEW</span>
                    <span>{sale.id}</span>
                  </div>
                  <div className="text-slate-300">
                    <p><strong>Farm:</strong> {sale.farmName || "Sunrise Agro-Tech Farm"}</p>
                    <p><strong>To:</strong> {customerName || "Valued Customer"} &lt;{recipientEmail || "customer@email.com"}&gt;</p>
                    <p><strong>Item:</strong> {sale.description}</p>
                    <p><strong>Total:</strong> {currency} {formattedAmount} (Paid in Full)</p>
                    {additionalNotes && <p><strong>Note:</strong> {additionalNotes}</p>}
                  </div>
                </div>
              )}
            </div>

            {/* Status alerts */}
            {sendSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center gap-2.5 text-emerald-900 text-xs font-bold animate-fade-in">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>Receipt has been sent successfully to {recipientEmail}!</span>
              </div>
            )}

            {errorMsg && (
              <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl flex items-start gap-2.5 text-rose-900 text-xs font-medium animate-fade-in">
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <span>{safeFormatError(errorMsg)}</span>
              </div>
            )}
          </form>
        </div>

        {/* Footer Actions */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-3.5 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={isSending}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-200/60 transition cursor-pointer"
          >
            Cancel
          </button>

          <button
            type="submit"
            form="email-receipt-form"
            disabled={isSending || sendSuccess || !recipientEmail}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-sm transition cursor-pointer"
          >
            {isSending ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Sending Receipt...</span>
              </>
            ) : sendSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Sent!</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Send Email Receipt</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from "react";
import { PlatformInvoice, markPlatformInvoicePaid } from "../services/platformInvoiceService";
import LipilaCheckoutModal from "./LipilaCheckoutModal";
import { safeFetchJsonClient } from "../App";
import { normalizePhoneForLipila } from "../utils/paymentUtils";

interface DirectInvoicePayModalProps {
  invoice: PlatformInvoice | null;
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess?: (paidInvoice: PlatformInvoice) => void;
}

export default function DirectInvoicePayModal({
  invoice,
  isOpen,
  onClose,
  onPaymentSuccess
}: DirectInvoicePayModalProps) {
  if (!isOpen || !invoice) return null;

  const [phone, setPhone] = useState("0971234567");
  const [holderName, setHolderName] = useState(invoice.recipientTenantName || "Direct Invoice Client");
  const [searchingName, setSearchingName] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<"Idle" | "Submitting" | "Pending" | "Successful" | "Failed">(
    invoice.status === "PAID" ? "Successful" : "Idle"
  );
  const [refId, setRefId] = useState<string>(invoice.lipilaReferenceId || `INV-REF-${Date.now().toString().slice(-6)}`);
  const [error, setError] = useState<string>("");
  const [timeRemaining, setTimeRemaining] = useState<number>(300);

  const handleSubmitPayment = async (customAmount?: number) => {
    const finalAmount = customAmount || invoice.totalAmount;
    setPaymentStatus("Submitting");
    setError("");

    try {
      const clean = normalizePhoneForLipila(phone);
      if (!clean || clean.length < 9) {
        throw new Error("Please enter a valid mobile money number.");
      }

      const generatedRef = `REF-INV-${Date.now().toString().slice(-6)}`;
      setRefId(generatedRef);

      const collectRes = await safeFetchJsonClient("/api/payments/collect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          referenceId: generatedRef,
          amount: finalAmount,
          narration: `Platform Invoice ${invoice.invoiceNumber}: ${invoice.recipientTenantName}`,
          accountNumber: clean,
          currency: "ZMW",
          email: "billing@mabala.com",
          packageName: `Platform Invoice #${invoice.invoiceNumber}`,
          packageType: "invoice_settlement"
        })
      }).catch((err: any) => ({ status: "Error", message: err.message }));

      if (collectRes && (collectRes.status === "Failed" || collectRes.status === "Error" || collectRes.success === false)) {
        setPaymentStatus("Failed");
        setError(collectRes.message || collectRes.error || "Lipila payment collection request failed.");
        return;
      }

      setPaymentStatus("Pending");
      setTimeRemaining(300);

      // Start status verification loop
      let pollCount = 0;
      const pollInterval = setInterval(async () => {
        pollCount++;
        if (pollCount > 60) {
          clearInterval(pollInterval);
          return;
        }

        try {
          const statusRes = await safeFetchJsonClient(`/api/payments/check-status?referenceId=${generatedRef}`).catch(() => null);
          if (statusRes && (statusRes.status === "Successful" || statusRes.status === "Success" || statusRes.status === "Completed")) {
            clearInterval(pollInterval);
            const updated = await markPlatformInvoicePaid(invoice.id, generatedRef);
            setPaymentStatus("Successful");
            if (onPaymentSuccess && updated) {
              onPaymentSuccess(updated);
            }
          } else if (statusRes && (statusRes.status === "Failed" || statusRes.status === "Error" || statusRes.status === "Rejected")) {
            clearInterval(pollInterval);
            setPaymentStatus("Failed");
            setError(statusRes.message || "Payment was rejected or cancelled on phone.");
          }
        } catch (e) {
          // Continue polling
        }
      }, 3000);
    } catch (err: any) {
      setPaymentStatus("Failed");
      setError(err.message || "Payment initiation failed.");
    }
  };

  const handleManualCheck = async () => {
    setSearchingName(true);
    try {
      const statusRes = await safeFetchJsonClient(`/api/payments/check-status?referenceId=${refId}`).catch(() => null);
      if (statusRes && (statusRes.status === "Successful" || statusRes.status === "Success" || statusRes.status === "Completed")) {
        const updated = await markPlatformInvoicePaid(invoice.id, refId);
        setPaymentStatus("Successful");
        if (onPaymentSuccess && updated) {
          onPaymentSuccess(updated);
        }
      } else if (statusRes && (statusRes.status === "Failed" || statusRes.status === "Error" || statusRes.status === "Rejected")) {
        setPaymentStatus("Failed");
        setError(statusRes.message || "Transaction was rejected.");
      } else {
        setError("Payment is still pending on gateway. Please authorize prompt on your mobile phone.");
      }
    } catch (e) {
      setError("Unable to reach gateway right now. Please try again.");
    } finally {
      setSearchingName(false);
    }
  };

  return (
    <LipilaCheckoutModal
      checkout={{
        type: "invoice",
        name: `Platform Invoice #${invoice.invoiceNumber}`,
        price: invoice.totalAmount,
        currency: "ZMW",
        creditsToAward: 0,
        description: `Invoice settlement for ${invoice.recipientTenantName} (${invoice.recipientType}). Line item: ${invoice.lineItems[0]?.description || 'Operational services'}.`
      }}
      phone={phone}
      setPhone={setPhone}
      holderName={holderName}
      searchingName={searchingName}
      paymentStatus={paymentStatus}
      refId={refId}
      error={error}
      timeRemaining={timeRemaining}
      onCancel={() => onClose()}
      onSubmitPayment={handleSubmitPayment}
      onCheckStatusManually={handleManualCheck}
      onRetry={() => {
        setPaymentStatus("Idle");
        setError("");
      }}
    />
  );
}

import React, { useState, useEffect } from "react";
import { 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle2, 
  HardDrive, 
  Layers, 
  X, 
  CloudUpload, 
  ShieldCheck,
  RotateCw
} from "lucide-react";
import { db } from "../firebase";
import { collection, onSnapshot, query, limit } from "firebase/firestore";
import { offlineQueueService } from "../services/offlineQueueService";

interface ConnectivityIndicatorProps {
  onOpenSyncCenter?: () => void;
  className?: string;
  hasSyncError?: boolean;
  syncErrorMessage?: string | null;
  onRetrySync?: () => void;
}

export default function ConnectivityIndicator({ 
  onOpenSyncCenter, 
  className = "",
  hasSyncError = false,
  syncErrorMessage = null,
  onRetrySync
}: ConnectivityIndicatorProps) {
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== "undefined" ? navigator.onLine : true
  );
  const [hasPendingWrites, setHasPendingWrites] = useState<boolean>(false);
  const [isFromCache, setIsFromCache] = useState<boolean>(true);
  const [queueCount, setQueueCount] = useState<number>(0);
  const [isFlushing, setIsFlushing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  const [showDetailPopover, setShowDetailPopover] = useState<boolean>(false);
  const [localError, setLocalError] = useState<string | null>(null);

  // Monitor browser online/offline status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setLocalError(null);
    };
    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Monitor offline queue service for pending mutations
  useEffect(() => {
    const unsubscribe = offlineQueueService.subscribe((state) => {
      setQueueCount(state.pendingCount);
      setIsFlushing(state.isFlushing);
      if (state.items.some(i => i.status === "failed")) {
        const failedItem = state.items.find(i => i.status === "failed");
        setLocalError(failedItem?.lastError || "Mutation failed to commit to cloud");
      } else {
        setLocalError(null);
      }
    });
    return unsubscribe;
  }, []);

  // Monitor Firestore metadata for pending writes and cache state
  useEffect(() => {
    if (!db || (db as any)._dummy) return;
    try {
      const q = query(collection(db, "offline_sync_test"), limit(1));
      const unsubscribe = onSnapshot(q, { includeMetadataChanges: true }, (snapshot) => {
        const pending = snapshot.metadata.hasPendingWrites;
        const fromCache = snapshot.metadata.fromCache;
        setHasPendingWrites(pending);
        setIsFromCache(fromCache);
        if (!pending && isOnline) {
          setLastSyncTime(new Date());
        }
      }, (err) => {
        console.warn("[ConnectivityIndicator] Firestore snapshot state notice:", err?.message);
        if (isOnline) {
          setLocalError(err?.message || "Firestore listener disconnected");
        }
      });
      return () => unsubscribe();
    } catch (e) {
      // Graceful fallback
    }
  }, [isOnline]);

  const activeError = hasSyncError ? (syncErrorMessage || "Sync failed") : localError;
  const isSyncInProgress = isFlushing || hasPendingWrites || queueCount > 0;

  // Determine current sync display state
  // Exact States required:
  // 1. Synced
  // 2. Syncing…
  // 3. Offline — changes saved on this device
  // 4. Sync failed — tap for details
  let stateVariant: "offline" | "failed" | "syncing" | "synced" = "synced";
  let badgeLabel = "Synced";

  if (!isOnline) {
    stateVariant = "offline";
    badgeLabel = "Offline — changes saved on this device";
  } else if (activeError) {
    stateVariant = "failed";
    badgeLabel = "Sync failed — tap for details";
  } else if (isSyncInProgress) {
    stateVariant = "syncing";
    badgeLabel = "Syncing…";
  } else {
    stateVariant = "synced";
    badgeLabel = "Synced";
  }

  const handleBadgeClick = () => {
    setShowDetailPopover(true);
  };

  const handleManualTrigger = async () => {
    if (onRetrySync) {
      onRetrySync();
    }
    try {
      await offlineQueueService.flushQueue(async () => true);
      setLocalError(null);
    } catch (err: any) {
      setLocalError(err.message || "Manual retry failed");
    }
  };

  return (
    <>
      <button
        type="button"
        id="mabala-persistent-sync-status-indicator"
        onClick={handleBadgeClick}
        title={
          stateVariant === "offline"
            ? "Offline: All reads served instantly from persistent local cache. Changes are safely preserved and will auto-sync on reconnect."
            : stateVariant === "failed"
            ? `Sync error: ${activeError}. Tap to view diagnostics and retry.`
            : stateVariant === "syncing"
            ? "Syncing: Local mutations are reconciling with Cloud Firestore in the background."
            : "Synced: All data is current with Cloud Firestore."
        }
        className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-xs select-none ${
          stateVariant === "offline"
            ? "bg-amber-500/10 border-amber-500/30 text-amber-700 hover:bg-amber-500/20"
            : stateVariant === "failed"
            ? "bg-rose-500/10 border-rose-500/30 text-rose-700 hover:bg-rose-500/20 animate-pulse"
            : stateVariant === "syncing"
            ? "bg-sky-500/10 border-sky-500/30 text-sky-700 hover:bg-sky-500/20"
            : "bg-emerald-500/10 border-emerald-500/30 text-emerald-700 hover:bg-emerald-500/20"
        } ${className}`}
      >
        {stateVariant === "offline" ? (
          <>
            <WifiOff className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="font-mono text-[11px] font-black tracking-tight">{badgeLabel}</span>
          </>
        ) : stateVariant === "failed" ? (
          <>
            <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
            <span className="font-mono text-[11px] font-black tracking-tight">{badgeLabel}</span>
          </>
        ) : stateVariant === "syncing" ? (
          <>
            <RefreshCw className="w-3.5 h-3.5 text-sky-600 animate-spin shrink-0" />
            <span className="font-mono text-[11px] font-black tracking-tight">{badgeLabel}</span>
          </>
        ) : (
          <>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0 inline-block" />
            <span className="font-mono text-[11px] font-black tracking-tight">{badgeLabel}</span>
          </>
        )}
      </button>

      {/* DETAILED DIAGNOSTICS MODAL / POPOVER */}
      {showDetailPopover && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in select-none">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden flex flex-col">
            {/* Header */}
            <div className={`p-4 text-white flex items-center justify-between ${
              stateVariant === "offline"
                ? "bg-amber-600"
                : stateVariant === "failed"
                ? "bg-rose-600"
                : stateVariant === "syncing"
                ? "bg-sky-600"
                : "bg-emerald-700"
            }`}>
              <div className="flex items-center gap-2.5">
                {stateVariant === "offline" ? (
                  <WifiOff className="w-5 h-5 text-amber-200" />
                ) : stateVariant === "failed" ? (
                  <AlertTriangle className="w-5 h-5 text-rose-200" />
                ) : stateVariant === "syncing" ? (
                  <RefreshCw className="w-5 h-5 text-sky-200 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-5 h-5 text-emerald-200" />
                )}
                <div>
                  <h3 className="text-sm font-black tracking-tight leading-tight">
                    {stateVariant === "offline"
                      ? "Offline — Local Storage Mode"
                      : stateVariant === "failed"
                      ? "Sync Issue Detected"
                      : stateVariant === "syncing"
                      ? "Reconciling with Cloud Firestore"
                      : "Cloud Sync Engine Active"}
                  </h3>
                  <span className="text-[10px] text-white/80 font-mono">
                    Instant Data Display • Local-First Architecture
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowDetailPopover(false)}
                className="p-1.5 rounded-xl text-white/80 hover:text-white hover:bg-white/20 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Diagnostic Details Body */}
            <div className="p-4 space-y-3 text-xs text-slate-600">
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase text-slate-400 font-mono">Network Connectivity</span>
                  <span className={`px-2 py-0.5 rounded-full font-mono text-[10px] font-black ${
                    isOnline ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                  }`}>
                    {isOnline ? "ONLINE (Connected)" : "OFFLINE (Disconnected)"}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase text-slate-400 font-mono">Storage Engine</span>
                  <span className="text-[11px] font-bold text-slate-800 font-mono">
                    Persistent IndexedDB Cache
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase text-slate-400 font-mono">Unsent / Pending Mutations</span>
                  <span className={`font-mono text-xs font-black ${
                    queueCount > 0 || hasPendingWrites ? "text-sky-600" : "text-emerald-600"
                  }`}>
                    {queueCount > 0 ? `${queueCount} queued mutations` : hasPendingWrites ? "Writing in background" : "0 pending (clean)"}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase text-slate-400 font-mono">Last Synchronized</span>
                  <span className="text-[11px] text-slate-600 font-mono">
                    {lastSyncTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                  </span>
                </div>
              </div>

              {activeError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-2xl text-[11px] space-y-1">
                  <div className="font-bold flex items-center gap-1.5 text-rose-900">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                    <span>Error Description</span>
                  </div>
                  <p className="font-mono text-[10.5px] leading-relaxed break-words">{activeError}</p>
                </div>
              )}

              <div className="p-3 bg-emerald-50/60 border border-emerald-200/60 rounded-2xl text-[11px] text-emerald-900 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-emerald-950">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Zero Data Loss Guarantee</span>
                </div>
                <p className="leading-relaxed text-[10.5px]">
                  All livestock records, expenses, poultry batches, and crop logs are written to your device's persistent storage instantly. Writes queue safely and automatically flush when connectivity is restored.
                </p>
              </div>
            </div>

            {/* Footer Actions */}
            <div className="p-3 bg-slate-50 border-t border-slate-200/80 flex items-center justify-between gap-2">
              {onOpenSyncCenter && (
                <button
                  type="button"
                  onClick={() => {
                    setShowDetailPopover(false);
                    onOpenSyncCenter();
                  }}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold border border-slate-200 shadow-2xs transition cursor-pointer flex items-center gap-1.5"
                >
                  <Layers className="w-3.5 h-3.5 text-slate-500" />
                  <span>Full Sync Panel</span>
                </button>
              )}

              <div className="flex items-center gap-2 ml-auto">
                <button
                  type="button"
                  onClick={() => setShowDetailPopover(false)}
                  className="px-3 py-1.5 text-slate-600 hover:text-slate-900 text-xs font-bold transition cursor-pointer"
                >
                  Close
                </button>
                {isOnline && (
                  <button
                    type="button"
                    onClick={handleManualTrigger}
                    className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                    <span>Retry Sync</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

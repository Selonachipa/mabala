import React, { useState, useEffect } from "react";
import { 
  ArrowUpRight, 
  ArrowRight,
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  AlertTriangle, 
  RefreshCw, 
  Download, 
  FileSpreadsheet, 
  Users, 
  Wallet, 
  Building2, 
  Smartphone, 
  Lock, 
  Eye, 
  EyeOff, 
  X, 
  Check,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Sparkles
} from "lucide-react";
import {
  BulkDisbursementBatch,
  BulkDisbursementItem,
  LipilaFeeTier,
  DEFAULT_LIPILA_FEE_SCHEDULE,
  calculateItemFees,
  validateDisbursementBalance,
  getLipilaFeeSchedule
} from "../../services/lipilaDisbursementService";
import { normalizeZambianMobileNumber, isValidZambianMobileNumber } from "../../utils/phoneNormalization";

interface BulkDisbursementModalProps {
  isOpen: boolean;
  onClose: () => void;
  tenantId: string;
  tenantName?: string;
  currentBalance: number;
  userEmail: string;
  userId: string;
  isSuperAdmin?: boolean;
  currencySymbol?: string;
  payrollRun?: any; // Pre-loaded payroll run if invoked from PayrollPanel
  employees?: any[];
  onDisbursementComplete?: (batch: BulkDisbursementBatch) => void;
}

export const BulkDisbursementModal: React.FC<BulkDisbursementModalProps> = ({
  isOpen,
  onClose,
  tenantId = "TENANT-001",
  tenantName = "Farm Operations",
  currentBalance = 0,
  userEmail,
  userId,
  isSuperAdmin = false,
  currencySymbol = "K",
  payrollRun,
  employees = [],
  onDisbursementComplete
}) => {
  // Navigation Screens: 1 = Out Menu, 2 = Recipient List, 3 = Summary, 4 = Password Approval, 5 = Status Tracker
  const [screen, setScreen] = useState<1 | 2 | 3 | 4 | 5>(payrollRun ? 2 : 1);
  const [sourceType, setSourceType] = useState<"payroll" | "csv" | "single" | "internal">(payrollRun ? "payroll" : "payroll");
  const [selectedFarmNodeId, setSelectedFarmNodeId] = useState<string>(tenantId);

  // Fee Schedule & Master Wallet Cache
  const [feeSchedule, setFeeSchedule] = useState<LipilaFeeTier[]>(DEFAULT_LIPILA_FEE_SCHEDULE);
  const [masterBalance, setMasterBalance] = useState<number>(250000.00);

  // Recipient Items
  const [items, setItems] = useState<BulkDisbursementItem[]>([]);
  const [showAllRecipients, setShowAllRecipients] = useState(false);

  // CSV Parsing State
  const [csvContent, setCsvContent] = useState<string>("");
  const [csvFileName, setCsvFileName] = useState<string>("");
  const [csvValidationErrors, setCsvValidationErrors] = useState<any[]>([]);
  const [isParsingCsv, setIsParsingCsv] = useState(false);

  // Single Payout Input State
  const [singleName, setSingleName] = useState("");
  const [singleType, setSingleType] = useState<"mobile_money" | "bank" | "mabala_to_mabala">("mobile_money");
  const [singleProvider, setSingleProvider] = useState("MTN");
  const [singleAccount, setSingleAccount] = useState("");
  const [singleAmount, setSingleAmount] = useState("");
  const [singleSwift, setSingleSwift] = useState("BARCZMLX");
  const [narration, setNarration] = useState("Mabala Farm Disbursement");

  // Summary & Validation State
  const [preparedBatch, setPreparedBatch] = useState<BulkDisbursementBatch | null>(null);
  const [validationResult, setValidationResult] = useState<{ allowed: boolean; blockedReason: "tenant" | "master" | null; message: string }>({
    allowed: true,
    blockedReason: null,
    message: ""
  });
  const [isPreparing, setIsPreparing] = useState(false);

  // Password Approval State
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [isVerifyingPassword, setIsVerifyingPassword] = useState(false);

  // Execution & Live Tracker State
  const [isExecuting, setIsExecuting] = useState(false);
  const [retryingItemId, setRetryingItemId] = useState<string | null>(null);
  const [activeBatch, setActiveBatch] = useState<BulkDisbursementBatch | null>(null);

  // Fetch active fee schedule and master wallet counter on mount
  useEffect(() => {
    if (isOpen) {
      getLipilaFeeSchedule().then(res => {
        if (res?.tiers) setFeeSchedule(res.tiers);
      });

      fetch("/api/disbursements/master-wallet")
        .then(r => r.json())
        .then(d => {
          if (typeof d.lipilaBalance === "number") setMasterBalance(d.lipilaBalance);
        })
        .catch(() => {});

      // Preload payroll run if supplied
      if (payrollRun && payrollRun.lines && payrollRun.lines.length > 0) {
        loadFromPayrollLines(payrollRun.lines);
      }
    }
  }, [isOpen, payrollRun]);

  const loadFromPayrollLines = (lines: any[]) => {
    const formatted: BulkDisbursementItem[] = lines.map((line: any, idx: number) => {
      const amt = Number(line.netSalary || line.grossSalary || 0);
      const rawAcc = String(line.mobileMoneyNumber || line.phoneNumber || "").trim();
      const isInternal = rawAcc.startsWith("MABALA-") || rawAcc.startsWith("TENANT-") || line.paymentChannel === "mabala_to_mabala";
      const type: "third_party_payout" | "mabala_to_mabala" = isInternal ? "mabala_to_mabala" : "third_party_payout";
      const feeInfo = calculateItemFees(amt, type, feeSchedule);

      return {
        id: `payroll-item-${idx + 1}-${line.employeeId || idx}`,
        type,
        recipientName: line.employeeName || "Employee",
        recipientType: "mobile_money",
        provider: line.mobileMoneyProvider === "airtel" ? "Airtel" : (line.mobileMoneyProvider === "zamtel" ? "Zamtel" : "MTN"),
        accountNumber: rawAcc,
        amount: amt,
        lipilaFee: feeInfo.lipilaFee,
        platformFeeShare: feeInfo.platformFeeShare,
        lipilaFeeTierApplied: feeInfo.tierLabel,
        referenceId: `DISB-PR-${Date.now()}-${idx + 1}`,
        status: "pending",
        retryCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
    });

    setItems(formatted);
    setSourceType("payroll");
  };

  const handleCsvFileUpload = async (file: File) => {
    setCsvFileName(file.name);
    setIsParsingCsv(true);
    setCsvValidationErrors([]);

    const text = await file.text();
    setCsvContent(text);

    try {
      const res = await fetch("/api/disbursements/parse-csv", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ csvContent: text })
      });
      const data = await res.json();

      if (!res.ok) {
        alert(data.error || "Failed to parse CSV file");
        setIsParsingCsv(false);
        return;
      }

      if (data.invalidRows && data.invalidRows.length > 0) {
        setCsvValidationErrors(data.invalidRows);
      }

      if (data.validRows && data.validRows.length > 0) {
        const parsedItems: BulkDisbursementItem[] = data.validRows.map((r: any, idx: number) => {
          const feeInfo = calculateItemFees(r.amount, r.type, feeSchedule);
          return {
            id: `csv-item-${idx + 1}`,
            type: r.type,
            recipientName: r.recipientName,
            recipientType: r.recipientType,
            provider: r.provider,
            accountNumber: r.accountNumber,
            bankFields: r.bankFields,
            amount: r.amount,
            lipilaFee: feeInfo.lipilaFee,
            platformFeeShare: feeInfo.platformFeeShare,
            lipilaFeeTierApplied: feeInfo.tierLabel,
            referenceId: `DISB-CSV-${Date.now()}-${idx + 1}`,
            status: "pending",
            retryCount: 0,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
        });
        setItems(parsedItems);
      } else {
        setItems([]);
      }
    } catch (err: any) {
      alert("Error parsing CSV: " + err.message);
    } finally {
      setIsParsingCsv(false);
    }
  };

  const handleAddSingleRecipient = () => {
    const amt = parseFloat(singleAmount);
    if (!singleName.trim() || isNaN(amt) || amt <= 0 || !singleAccount.trim()) {
      alert("Please provide valid recipient name, account/mobile number, and positive amount.");
      return;
    }

    const isInternal = singleType === "mabala_to_mabala" || singleAccount.startsWith("MABALA-") || singleAccount.startsWith("TENANT-");
    const itemType = isInternal ? "mabala_to_mabala" : "third_party_payout";
    const feeInfo = calculateItemFees(amt, itemType, feeSchedule);

    const singleItem: BulkDisbursementItem = {
      id: `single-item-${Date.now()}`,
      type: itemType,
      recipientName: singleName.trim(),
      recipientType: singleType === "bank" ? "bank" : "mobile_money",
      provider: singleType === "bank" ? singleProvider : (singleProvider || "MTN"),
      accountNumber: singleType === "mobile_money" ? normalizeZambianMobileNumber(singleAccount) : singleAccount.trim(),
      bankFields: singleType === "bank" ? { swiftCode: singleSwift, accountHolderName: singleName.trim() } : undefined,
      amount: amt,
      lipilaFee: feeInfo.lipilaFee,
      platformFeeShare: feeInfo.platformFeeShare,
      lipilaFeeTierApplied: feeInfo.tierLabel,
      referenceId: `DISB-SNGL-${Date.now()}`,
      status: "pending",
      retryCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setItems([singleItem]);
    setScreen(2);
  };

  // Transition from Screen 2 to Screen 3: Calculate totals and call /api/disbursements/prepare
  const handleProceedToSummary = async () => {
    if (items.length === 0) {
      alert("No recipients to disburse to.");
      return;
    }

    setIsPreparing(true);
    try {
      const res = await fetch("/api/disbursements/prepare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          farmNodeId: selectedFarmNodeId,
          sourceType,
          payrollRunId: payrollRun?.id,
          initiatedByUid: userId || userEmail,
          narration,
          items: items.map(it => ({
            recipientName: it.recipientName,
            recipientType: it.recipientType,
            provider: it.provider,
            accountNumber: it.accountNumber,
            amount: it.amount,
            type: it.type,
            bankFields: it.bankFields
          }))
        })
      });

      const data = await res.json();
      if (!res.ok) {
        alert(data.error || "Failed to prepare disbursement batch");
        return;
      }

      setPreparedBatch(data.batch);
      setValidationResult(data.validation);
      setScreen(3);
    } catch (err: any) {
      alert("Error preparing disbursement: " + err.message);
    } finally {
      setIsPreparing(false);
    }
  };

  // Screen 4: Verify platform password
  const handleApprovePassword = async () => {
    if (!password) {
      setPasswordError("Password is required");
      return;
    }

    setIsVerifyingPassword(true);
    setPasswordError(null);

    try {
      const res = await fetch("/api/disbursements/verify-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: userEmail,
          password,
          uid: userId,
          batchId: preparedBatch?.id
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setPasswordError(data.error || "Password verification failed");
        return;
      }

      setAuthToken(data.authToken);
      // Immediately initiate execution
      await executeDisbursement(data.authToken);
    } catch (err: any) {
      setPasswordError("Verification error: " + err.message);
    } finally {
      setIsVerifyingPassword(false);
    }
  };

  // Screen 5: Execute Bulk Disbursement
  const executeDisbursement = async (token: string) => {
    if (!preparedBatch) return;

    setScreen(5);
    setIsExecuting(true);

    try {
      const res = await fetch("/api/disbursements/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          batchId: preparedBatch.id,
          authToken: token,
          actorUid: userId || userEmail
        })
      });

      const data = await res.json();
      if (!res.ok) {
        alert(data.error || "Disbursement execution failed");
        setIsExecuting(false);
        return;
      }

      setActiveBatch(data.batch);
      if (onDisbursementComplete) {
        onDisbursementComplete(data.batch);
      }
    } catch (err: any) {
      alert("Disbursement execution error: " + err.message);
    } finally {
      setIsExecuting(false);
    }
  };

  // Retry individual failed item
  const handleRetryItem = async (itemId: string) => {
    if (!activeBatch) return;
    setRetryingItemId(itemId);

    try {
      const res = await fetch("/api/disbursements/retry-item", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          batchId: activeBatch.id,
          itemId,
          actorUid: userId || userEmail
        })
      });

      const data = await res.json();
      if (!res.ok) {
        alert(data.error || "Retry failed");
        return;
      }

      // Update local item status
      const updatedItems = (activeBatch.items || []).map(it => it.id === itemId ? data.item : it);
      setActiveBatch({
        ...activeBatch,
        items: updatedItems
      });
    } catch (err: any) {
      alert("Retry error: " + err.message);
    } finally {
      setRetryingItemId(null);
    }
  };

  // Export CSV statement of batch
  const handleDownloadReport = () => {
    const batchToExport = activeBatch || preparedBatch;
    if (!batchToExport || !batchToExport.items) return;

    const headers = ["Reference ID", "Recipient Name", "Type", "Provider", "Account Number", "Amount (ZMW)", "Lipila Fee", "Platform Fee", "Status", "Error / Note"];
    const rows = batchToExport.items.map(it => [
      `"${it.referenceId}"`,
      `"${it.recipientName}"`,
      `"${it.recipientType}"`,
      `"${it.provider}"`,
      `"${it.accountNumber}"`,
      it.amount.toFixed(2),
      it.lipilaFee.toFixed(2),
      it.platformFeeShare.toFixed(2),
      `"${it.status}"`,
      `"${it.errorMessage || it.lipilaErrorCode || 'Success'}"`
    ]);

    const csvData = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const blob = new Blob([csvData], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `mabala-disbursement-${batchToExport.id}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isOpen) return null;

  // Compute live sub-totals for Screen 2 and Screen 3
  const subtotalAmount = items.reduce((acc, it) => acc + it.amount, 0);
  const subtotalLipilaFees = items.reduce((acc, it) => acc + (it.type === "mabala_to_mabala" ? 0 : it.lipilaFee), 0);
  const subtotalPlatformFee = items.reduce((acc, it) => acc + (it.type === "mabala_to_mabala" ? 0 : it.platformFeeShare), 0);
  const computedGrandTotal = Number((subtotalAmount + subtotalLipilaFees + subtotalPlatformFee).toFixed(2));

  // Two-step check preview
  const isTenantSufficient = currentBalance >= computedGrandTotal;
  const isMasterSufficient = masterBalance >= computedGrandTotal;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto animate-fade-in font-sans" id="bulk-disbursement-modal">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-2xl overflow-hidden my-6 flex flex-col max-h-[92vh]">
        
        {/* MODAL HEADER */}
        <div className="p-5 bg-gradient-to-r from-slate-900 to-slate-800 text-white flex items-center justify-between border-b border-slate-700 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <ArrowUpRight className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black tracking-tight">Mabala Ledger — Payout & Disbursement</h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black uppercase">
                  Lipila B2C Rail
                </span>
              </div>
              <p className="text-xs text-slate-300 font-medium">
                {screen === 1 && "Choose disbursement method or payroll batch"}
                {screen === 2 && `Review ${items.length} disbursement recipients`}
                {screen === 3 && "Audit fees, fee tier snapshot & balance authorization"}
                {screen === 4 && "Password approval for disbursement"}
                {screen === 5 && "Live transaction tracker & gateway dispatch"}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-700/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* PROGRESS STEPPER */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-2.5 flex items-center justify-between text-xs font-bold text-slate-600 shrink-0">
          {[
            { step: 1, label: "Method" },
            { step: 2, label: "Recipients" },
            { step: 3, label: "Summary" },
            { step: 4, label: "Password" },
            { step: 5, label: "Status" }
          ].map((s) => (
            <div key={s.step} className="flex items-center gap-1.5">
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-mono ${
                screen === s.step
                  ? "bg-slate-900 text-white"
                  : screen > s.step
                  ? "bg-emerald-600 text-white"
                  : "bg-slate-200 text-slate-500"
              }`}>
                {screen > s.step ? "✓" : s.step}
              </span>
              <span className={`hidden sm:inline ${screen === s.step ? "text-slate-900 font-black" : "text-slate-500"}`}>
                {s.label}
              </span>
            </div>
          ))}
        </div>

        {/* MODAL BODY */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">

          {/* ======================================================== */}
          {/* SCREEN 1: OUT MENU & METHOD SELECTION */}
          {/* ======================================================== */}
          {screen === 1 && (
            <div className="space-y-5 animate-fade-in">
              <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-4 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-500 font-medium">Active Farm Ledger:</span>
                  <p className="font-extrabold text-slate-900 text-sm mt-0.5">{tenantName}</p>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 font-medium">Liquid Farm Balance:</span>
                  <p className="font-black text-emerald-600 text-base">{currencySymbol}{currentBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}</p>
                </div>
              </div>

              {/* Super Admin Access Node Switcher */}
              {isSuperAdmin && (
                <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl text-xs flex items-center justify-between">
                  <div className="flex items-center gap-2 text-indigo-950 font-bold">
                    <ShieldCheck className="w-4 h-4 text-indigo-600" />
                    <span>Super Admin Access Node:</span>
                  </div>
                  <input
                    type="text"
                    value={selectedFarmNodeId}
                    onChange={(e) => setSelectedFarmNodeId(e.target.value)}
                    placeholder="Enter Farm Node Tenant ID"
                    className="px-2.5 py-1 bg-white border border-indigo-200 rounded-lg text-xs font-mono text-indigo-900"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
                {/* Option 1: Pay Payroll */}
                <button
                  type="button"
                  onClick={() => {
                    setSourceType("payroll");
                    if (employees.length > 0) {
                      loadFromPayrollLines(employees.map(e => ({
                        employeeId: e.id,
                        employeeName: e.name,
                        netSalary: e.netSalary || e.contractRate,
                        mobileMoneyNumber: e.mobileMoneyNumber || e.mobileNumber,
                        mobileMoneyProvider: e.mobileMoneyProvider || "mtn"
                      })));
                    }
                    setScreen(2);
                  }}
                  className="p-4 bg-white border border-slate-200 hover:border-slate-800 hover:shadow-md rounded-2xl text-left transition cursor-pointer group flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition">
                      <Users className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700">
                      Bulk Rail
                    </span>
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-sm">Pay Payroll</h3>
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                      Disburse employee monthly salaries to Airtel Money, MTN MoMo, or Zamtel Kwacha via Lipila.
                    </p>
                  </div>
                </button>

                {/* Option 2: Upload CSV */}
                <div className="p-4 bg-white border border-slate-200 hover:border-slate-800 hover:shadow-md rounded-2xl text-left transition flex flex-col justify-between group">
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition">
                      <FileSpreadsheet className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700">
                      Drag & Drop
                    </span>
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-sm">Upload CSV File</h3>
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                      Upload contractor, casual laborer, or supplier spreadsheet with automated row validation.
                    </p>
                  </div>
                  <label className="mt-3 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold text-center cursor-pointer block">
                    <span>Select CSV</span>
                    <input
                      type="file"
                      accept=".csv"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          setSourceType("csv");
                          handleCsvFileUpload(e.target.files[0]);
                          setScreen(2);
                        }
                      }}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* Option 3: Send to Mabala Ledger */}
                <button
                  type="button"
                  onClick={() => {
                    setSourceType("internal");
                    setSingleType("mabala_to_mabala");
                    setSingleProvider("Mabala Ledger");
                    setScreen(2);
                  }}
                  className="p-4 bg-white border border-slate-200 hover:border-slate-800 hover:shadow-md rounded-2xl text-left transition cursor-pointer group flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition">
                      <Wallet className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-mono">
                      FREE (K0 FEE)
                    </span>
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-sm">Send to Mabala Ledger</h3>
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                      Instant zero-fee transfer to another farm node, agro-dealer, or platform service ledger.
                    </p>
                  </div>
                </button>

                {/* Option 4: Single Direct Payout */}
                <button
                  type="button"
                  onClick={() => {
                    setSourceType("single");
                    setScreen(2);
                  }}
                  className="p-4 bg-white border border-slate-200 hover:border-slate-800 hover:shadow-md rounded-2xl text-left transition cursor-pointer group flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:bg-amber-600 group-hover:text-white transition">
                      <ArrowUpRight className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700">
                      Quick Single
                    </span>
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-sm">Single Direct Payout</h3>
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                      Send a one-time disbursement to a single mobile money number or commercial bank account.
                    </p>
                  </div>
                </button>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SCREEN 2: RECIPIENT LIST & CSV VALIDATION */}
          {/* ======================================================== */}
          {screen === 2 && (
            <div className="space-y-5 animate-fade-in">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900">
                    {sourceType === "single" ? "Single Payout Recipient" : `Recipients (${items.length})`}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {sourceType === "csv" && csvFileName ? `Imported from: ${csvFileName}` : "Review disbursement line items"}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setScreen(1)}
                  className="text-xs font-bold text-slate-500 hover:text-slate-900 cursor-pointer"
                >
                  Change Method
                </button>
              </div>

              {/* Single Payout Form (if single payout mode) */}
              {(sourceType === "single" || sourceType === "internal") && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Recipient Name</label>
                      <input
                        type="text"
                        value={singleName}
                        onChange={(e) => setSingleName(e.target.value)}
                        placeholder="e.g. Kondwani Phiri"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-slate-900"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Payment Rail</label>
                      <select
                        value={singleType}
                        onChange={(e) => {
                          const val = e.target.value as any;
                          setSingleType(val);
                          if (val === "mabala_to_mabala") setSingleProvider("Mabala Ledger");
                          else if (val === "bank") setSingleProvider("Stanbic Bank");
                          else setSingleProvider("MTN");
                        }}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium"
                      >
                        <option value="mobile_money">Mobile Money (Airtel, MTN, Zamtel)</option>
                        <option value="bank">Commercial Bank Transfer</option>
                        <option value="mabala_to_mabala">Mabala Ledger (Free Internal)</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {singleType === "mobile_money" ? "Mobile Network Operator" : (singleType === "bank" ? "Bank Name" : "Internal Entity")}
                      </label>
                      {singleType === "mobile_money" ? (
                        <select
                          value={singleProvider}
                          onChange={(e) => setSingleProvider(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium"
                        >
                          <option value="MTN">MTN MoMo</option>
                          <option value="Airtel">Airtel Money</option>
                          <option value="Zamtel">Zamtel Kwacha</option>
                        </select>
                      ) : (
                        <input
                          type="text"
                          value={singleProvider}
                          onChange={(e) => setSingleProvider(e.target.value)}
                          placeholder="e.g. Zanaco, Stanbic, Absa"
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium"
                        />
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {singleType === "mobile_money" ? "Mobile Phone Number" : (singleType === "bank" ? "Bank Account Number" : "Recipient Ledger ID")}
                      </label>
                      <input
                        type="text"
                        value={singleAccount}
                        onChange={(e) => setSingleAccount(e.target.value)}
                        placeholder={singleType === "mobile_money" ? "0977xxxxxx or 0966xxxxxx" : (singleType === "bank" ? "Account Number" : "MABALA-XXXX")}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Amount ({currencySymbol})</label>
                      <input
                        type="number"
                        step="0.01"
                        value={singleAmount}
                        onChange={(e) => setSingleAmount(e.target.value)}
                        placeholder="e.g. 1500.00"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Narration / Reference</label>
                      <input
                        type="text"
                        value={narration}
                        onChange={(e) => setNarration(e.target.value)}
                        placeholder="e.g. Harvest Day Pay"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium"
                      />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddSingleRecipient}
                    className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                  >
                    Add to Disbursement Line Items
                  </button>
                </div>
              )}

              {/* CSV Validation Error Alerts */}
              {csvValidationErrors.length > 0 && (
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-rose-800 font-bold">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>Row Validation Warnings ({csvValidationErrors.length} rows skipped)</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-rose-700 font-medium max-h-28 overflow-y-auto">
                    {csvValidationErrors.map((err, i) => (
                      <li key={i}>
                        Row {err.rowNumber} ({err.recipientName}): {err.errors.join(", ")}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Recipients Table (First 5 + More) */}
              {items.length > 0 && (
                <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                  <div className="bg-slate-100/80 px-4 py-2 text-[11px] font-black text-slate-600 uppercase tracking-wider grid grid-cols-12">
                    <span className="col-span-4">Recipient</span>
                    <span className="col-span-3">Network / Bank</span>
                    <span className="col-span-3 text-right">Net Amount</span>
                    <span className="col-span-2 text-right">Fee</span>
                  </div>

                  <div className="divide-y divide-slate-100 bg-white text-xs">
                    {(showAllRecipients ? items : items.slice(0, 5)).map((item, idx) => (
                      <div key={item.id || idx} className="px-4 py-2.5 grid grid-cols-12 items-center">
                        <div className="col-span-4">
                          <p className="font-extrabold text-slate-900 truncate">{item.recipientName}</p>
                          <p className="text-[11px] text-slate-400 font-mono truncate">{item.accountNumber}</p>
                        </div>
                        <div className="col-span-3">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            item.type === "mabala_to_mabala"
                              ? "bg-purple-100 text-purple-700"
                              : item.recipientType === "bank"
                              ? "bg-blue-100 text-blue-700"
                              : "bg-amber-100 text-amber-800"
                          }`}>
                            {item.type === "mabala_to_mabala" ? "Mabala" : item.provider}
                          </span>
                        </div>
                        <div className="col-span-3 text-right font-black text-slate-900 font-mono">
                          {currencySymbol}{item.amount.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                        </div>
                        <div className="col-span-2 text-right font-mono text-[11px] text-slate-500">
                          {item.type === "mabala_to_mabala" ? (
                            <span className="text-emerald-600 font-black text-[10px]">Free</span>
                          ) : (
                            `${currencySymbol}${item.lipilaFee.toFixed(2)}`
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {items.length > 5 && (
                    <button
                      type="button"
                      onClick={() => setShowAllRecipients(!showAllRecipients)}
                      className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-slate-600 text-xs font-bold border-t border-slate-200 transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      {showAllRecipients ? (
                        <>
                          <ChevronUp className="w-3.5 h-3.5" />
                          <span>Show Less</span>
                        </>
                      ) : (
                        <>
                          <ChevronDown className="w-3.5 h-3.5" />
                          <span>More ({items.length - 5} recipients)</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              )}

              {/* Subtotal Preview Bar */}
              <div className="p-3.5 bg-slate-100 rounded-2xl flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-500 font-medium">Recipients:</span>{" "}
                  <strong className="text-slate-900 font-black">{items.length}</strong>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Net Payout:</span>{" "}
                  <strong className="text-slate-900 font-black font-mono">
                    {currencySymbol}{subtotalAmount.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                  </strong>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setScreen(1)}
                  className="px-4 py-2.5 text-slate-600 hover:text-slate-900 text-xs font-bold cursor-pointer"
                >
                  Back
                </button>
                <button
                  type="button"
                  disabled={items.length === 0 || isPreparing}
                  onClick={handleProceedToSummary}
                  className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white rounded-xl text-xs font-extrabold transition flex items-center gap-2 cursor-pointer shadow-md"
                >
                  {isPreparing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                  <span>Continue to Summary</span>
                </button>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SCREEN 3: SUMMARY & BALANCE VERIFICATION */}
          {/* ======================================================== */}
          {screen === 3 && (
            <div className="space-y-5 animate-fade-in">
              {/* Summary Metrics Box */}
              <div className="bg-slate-900 text-white rounded-3xl p-5 shadow-lg border border-slate-800 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Total Recipients</span>
                  <span className="text-sm font-black font-mono">{items.length}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-300">
                  <span>Net Recipient Principal:</span>
                  <span className="font-mono font-bold">{currencySymbol}{subtotalAmount.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-300">
                  <span>Lipila Tiered Gateway Fees (Flat per item):</span>
                  <span className="font-mono font-bold">{currencySymbol}{subtotalLipilaFees.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-300">
                  <span>Platform Service Share (3.5% of Lipila Fees):</span>
                  <span className="font-mono font-bold">{currencySymbol}{subtotalPlatformFee.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="border-t border-slate-700 pt-3 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-amber-400 font-black uppercase tracking-wider">Grand Total Deducted</span>
                    <p className="text-[10px] text-slate-400">Principal + Gateway Fees + Platform Share</p>
                  </div>
                  <span className="text-xl font-black text-white font-mono">
                    {currencySymbol}{computedGrandTotal.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              {/* Two-Step Balance Verification Card */}
              <div className="p-4 rounded-2xl border bg-slate-50 border-slate-200 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-600 font-bold">Your Liquid Farm Ledger Balance:</span>
                  <span className="font-black font-mono text-sm text-slate-900">
                    {currencySymbol}{currentBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                  </span>
                </div>

                {/* Step A: Tenant Balance Check */}
                {!isTenantSufficient && (
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 flex items-center gap-2 font-bold">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>Insufficient farm balance (Deficit: {currencySymbol}{(computedGrandTotal - currentBalance).toFixed(2)})</span>
                  </div>
                )}

                {/* Step B: Master Wallet Check (Strict Privacy: friendly support message) */}
                {isTenantSufficient && !isMasterSufficient && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 flex items-center gap-2 font-bold">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Disbursement temporarily unavailable, contact support</span>
                  </div>
                )}

                {/* All clear */}
                {isTenantSufficient && isMasterSufficient && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 flex items-center gap-2 font-bold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Balance clearance confirmed. Ready for password authorization.</span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setScreen(2)}
                  className="px-4 py-2.5 text-slate-600 hover:text-slate-900 text-xs font-bold cursor-pointer"
                >
                  Back to Recipients
                </button>
                <button
                  type="button"
                  disabled={!isTenantSufficient || !isMasterSufficient}
                  onClick={() => setScreen(4)}
                  className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-xl text-xs font-extrabold transition flex items-center gap-2 cursor-pointer shadow-md"
                >
                  <Lock className="w-4 h-4" />
                  <span>Authorize with Password</span>
                </button>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SCREEN 4: PASSWORD APPROVAL (REPLACES PIN) */}
          {/* ======================================================== */}
          {screen === 4 && (
            <div className="space-y-5 animate-fade-in">
              <div className="p-4 bg-indigo-50/80 border border-indigo-200 rounded-2xl text-xs space-y-2">
                <div className="flex items-center gap-2 text-indigo-950 font-black">
                  <ShieldCheck className="w-5 h-5 text-indigo-600 shrink-0" />
                  <span>mabala.cloud Security Authorization</span>
                </div>
                <p className="text-indigo-800 font-medium leading-relaxed">
                  Disbursements are high-value financial actions. Please re-enter your mabala.cloud account password to sign and approve this disbursement of{" "}
                  <strong className="font-mono font-black">{currencySymbol}{computedGrandTotal.toFixed(2)}</strong>.
                </p>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-extrabold text-slate-800">
                  Account Password ({userEmail})
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setPasswordError(null);
                    }}
                    placeholder="Enter your platform password"
                    className="w-full px-3.5 py-2.5 pr-10 bg-white border border-slate-300 rounded-xl text-sm font-medium focus:ring-2 focus:ring-slate-900"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleApprovePassword();
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {passwordError && (
                  <p className="text-xs font-bold text-rose-600 flex items-center gap-1 mt-1.5">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{passwordError}</span>
                  </p>
                )}
              </div>

              <div className="flex items-center justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setScreen(3)}
                  className="px-4 py-2.5 text-slate-600 hover:text-slate-900 text-xs font-bold cursor-pointer"
                >
                  Back to Summary
                </button>
                <button
                  type="button"
                  disabled={!password || isVerifyingPassword}
                  onClick={handleApprovePassword}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-300 text-white rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-600/20"
                >
                  {isVerifyingPassword ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Verifying...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Approve Disbursement</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SCREEN 5: LIVE STATUS TRACKER */}
          {/* ======================================================== */}
          {screen === 5 && (
            <div className="space-y-5 animate-fade-in">
              {/* Batch Header Bar */}
              <div className="p-4 bg-slate-900 text-white rounded-2xl flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-400 text-[10px] font-mono uppercase">Batch ID:</span>
                  <p className="font-mono font-black text-sm text-white">
                    {activeBatch?.id || preparedBatch?.id || "BATCH-IN-FLIGHT"}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-slate-400 text-[10px] uppercase">Status:</span>
                  <p className={`font-black text-xs uppercase ${
                    isExecuting ? "text-amber-400 animate-pulse" : "text-emerald-400"
                  }`}>
                    {isExecuting ? "Processing via Lipila..." : (activeBatch?.status?.replace(/_/g, " ") || "Completed")}
                  </p>
                </div>
              </div>

              {/* Progress Indicator */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                  <span>Disbursement Progress</span>
                  <span>
                    {activeBatch?.items?.filter(i => i.status === "success" || i.status === "submitted").length || 0} of {items.length} Dispatched
                  </span>
                </div>
                <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-600 h-full transition-all duration-500"
                    style={{
                      width: `${items.length > 0 ? (((activeBatch?.items?.filter(i => i.status === "success" || i.status === "submitted").length || 0) / items.length) * 100) : 0}%`
                    }}
                  />
                </div>
              </div>

              {/* Itemized Recipients Live Status */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-xs divide-y divide-slate-100 max-h-64 overflow-y-auto">
                {(activeBatch?.items || items).map((item) => (
                  <div key={item.id} className="p-3 bg-white flex items-center justify-between text-xs">
                    <div>
                      <p className="font-extrabold text-slate-900">{item.recipientName}</p>
                      <p className="text-[11px] text-slate-400 font-mono">
                        {item.provider} • {item.accountNumber} • Ref: {item.referenceId}
                      </p>
                      {item.errorMessage && (
                        <p className="text-[10px] text-rose-600 font-medium mt-0.5">
                          Error: {item.errorMessage}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-black text-slate-900 font-mono">
                        {currencySymbol}{item.amount.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                      </span>

                      {/* Status Badge */}
                      {item.status === "pending" && (
                        <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[10px] font-bold">
                          Pending
                        </span>
                      )}
                      {item.status === "submitted" && (
                        <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold flex items-center gap-1">
                          <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                          <span>Submitted</span>
                        </span>
                      )}
                      {item.status === "success" && (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold flex items-center gap-1">
                          <Check className="w-2.5 h-2.5" />
                          <span>Success</span>
                        </span>
                      )}
                      {item.status === "failed" && (
                        <div className="flex items-center gap-1.5">
                          <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 text-[10px] font-bold">
                            Failed
                          </span>
                          <button
                            type="button"
                            disabled={retryingItemId === item.id}
                            onClick={() => handleRetryItem(item.id)}
                            className="p-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer"
                            title="Retry item"
                          >
                            <RotateCcw className={`w-3 h-3 ${retryingItemId === item.id ? "animate-spin" : ""}`} />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={handleDownloadReport}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Report (CSV)</span>
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-extrabold transition cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default BulkDisbursementModal;

import React, { useState, useEffect } from "react";
import { 
  ShieldCheck, 
  Settings, 
  Plus, 
  Trash2, 
  RefreshCw, 
  AlertCircle, 
  CheckCircle2, 
  X, 
  Wallet, 
  ArrowRight,
  TrendingUp,
  AlertTriangle
} from "lucide-react";
import { 
  LipilaFeeTier, 
  DEFAULT_LIPILA_FEE_SCHEDULE, 
  validateFeeSchedule, 
  getLipilaFeeSchedule, 
  saveLipilaFeeSchedule 
} from "../../services/lipilaDisbursementService";

interface SuperAdminFeeScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  userEmail: string;
  userId: string;
  currencySymbol?: string;
}

export const SuperAdminFeeScheduleModal: React.FC<SuperAdminFeeScheduleModalProps> = ({
  isOpen,
  onClose,
  userEmail,
  userId,
  currencySymbol = "K"
}) => {
  const [tiers, setTiers] = useState<LipilaFeeTier[]>(DEFAULT_LIPILA_FEE_SCHEDULE);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Master Wallet Sync State
  const [masterBalance, setMasterBalance] = useState<number>(250000.00);
  const [liveMerchantBalance, setLiveMerchantBalance] = useState<number | null>(null);
  const [drift, setDrift] = useState<number>(0);
  const [isDriftFlagged, setIsDriftFlagged] = useState(false);
  const [isSyncingMaster, setIsSyncingMaster] = useState(false);
  const [syncNote, setSyncNote] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const scheduleRes = await getLipilaFeeSchedule();
      if (scheduleRes && scheduleRes.tiers && scheduleRes.tiers.length > 0) {
        setTiers(scheduleRes.tiers);
      }

      const walletRes = await fetch("/api/disbursements/master-wallet").then(r => r.json());
      if (typeof walletRes.lipilaBalance === "number") {
        setMasterBalance(walletRes.lipilaBalance);
      }
    } catch (err: any) {
      console.warn("Failed to load admin fee schedule or wallet:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSyncMasterWallet = async () => {
    setIsSyncingMaster(true);
    setSyncNote(null);
    try {
      const res = await fetch("/api/disbursements/sync-master-wallet", { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        setMasterBalance(data.firestoreBalance);
        setLiveMerchantBalance(data.liveMerchantBalance);
        setDrift(data.drift);
        setIsDriftFlagged(data.isDriftFlagged);
        if (data.isDriftFlagged) {
          setSyncNote(`Discrepancy detected: Drift of ${currencySymbol}${data.drift.toFixed(2)} flagged in audit log for review.`);
        } else {
          setSyncNote("Live Lipila balance verified and matched within normal tolerance.");
        }
      } else {
        setSyncNote("Sync check failed: " + (data.error || "Network error"));
      }
    } catch (err: any) {
      setSyncNote("Error connecting to Lipila merchant balance API: " + err.message);
    } finally {
      setIsSyncingMaster(false);
    }
  };

  const handleTierChange = (index: number, field: "minAmount" | "maxAmount" | "charge", value: any) => {
    const updated = [...tiers];
    const num = parseFloat(value);
    if (field === "maxAmount") {
      updated[index].maxAmount = isNaN(num) || num <= 0 ? null : num;
    } else {
      updated[index][field] = isNaN(num) ? 0 : num;
    }
    setTiers(updated);
    setValidationError(null);
  };

  const handleAddTier = () => {
    const lastTier = tiers[tiers.length - 1];
    const newMin = lastTier ? (lastTier.maxAmount ? lastTier.maxAmount + 0.01 : lastTier.minAmount + 5000) : 0;
    const newTier: LipilaFeeTier = {
      id: `tier-${Date.now()}`,
      minAmount: Number(newMin.toFixed(2)),
      maxAmount: null,
      charge: (lastTier?.charge || 20) + 10
    };

    // Set previous tier maxAmount if it was unbounded
    const updated = [...tiers];
    if (lastTier && lastTier.maxAmount === null) {
      lastTier.maxAmount = Number((newMin - 0.01).toFixed(2));
    }
    updated.push(newTier);
    setTiers(updated);
  };

  const handleDeleteTier = (index: number) => {
    if (tiers.length <= 1) {
      alert("At least one fee tier must remain configured.");
      return;
    }
    const updated = tiers.filter((_, i) => i !== index);
    setTiers(updated);
  };

  const handleSaveTiers = async () => {
    const check = validateFeeSchedule(tiers);
    if (!check.valid) {
      setValidationError(check.error || "Invalid fee tier configuration");
      return;
    }

    setIsSaving(true);
    setValidationError(null);
    setSuccessMessage(null);

    try {
      const res = await saveLipilaFeeSchedule(tiers, userId || userEmail);
      if (res.success) {
        setSuccessMessage("Lipila Fee Schedule saved successfully to platform configuration.");
        setTimeout(() => setSuccessMessage(null), 4000);
      } else {
        setValidationError(res.error || "Failed to save fee schedule");
      }
    } catch (err: any) {
      setValidationError("Error saving schedule: " + err.message);
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto animate-fade-in font-sans" id="super-admin-fee-modal">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-2xl overflow-hidden my-6 flex flex-col max-h-[92vh]">
        
        {/* HEADER */}
        <div className="p-5 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black tracking-tight">Super Admin: Lipila Fee Schedule & Master Wallet</h2>
                <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-black uppercase">
                  Platform Config
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Configure tiered Lipila disbursement flat fees and audit the master pooled float.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1 space-y-6">

          {/* MASTER WALLET MONITOR CARD */}
          <div className="p-4 bg-slate-900 text-white rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-black uppercase tracking-wider text-slate-300">
                  Master Pooled Float (Platform Level)
                </span>
              </div>
              <button
                type="button"
                disabled={isSyncingMaster}
                onClick={handleSyncMasterWallet}
                className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className={`w-3 h-3 ${isSyncingMaster ? "animate-spin" : ""}`} />
                <span>Check Live Lipila Balance</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-xs">
              <div className="p-3 bg-slate-800/80 rounded-xl">
                <span className="text-slate-400">Firestore Counter Balance:</span>
                <p className="text-lg font-black font-mono text-emerald-400 mt-0.5">
                  {currencySymbol}{masterBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                </p>
              </div>
              <div className="p-3 bg-slate-800/80 rounded-xl">
                <span className="text-slate-400">Live Lipila Merchant Float:</span>
                <p className="text-lg font-black font-mono text-white mt-0.5">
                  {liveMerchantBalance !== null ? `${currencySymbol}${liveMerchantBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}` : "Click sync to query"}
                </p>
              </div>
            </div>

            {syncNote && (
              <div className={`p-3 rounded-xl text-xs flex items-center gap-2 font-medium ${
                isDriftFlagged ? "bg-amber-500/20 text-amber-300 border border-amber-500/30" : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
              }`}>
                {isDriftFlagged ? <AlertTriangle className="w-4 h-4 shrink-0" /> : <CheckCircle2 className="w-4 h-4 shrink-0" />}
                <span>{syncNote}</span>
              </div>
            )}
          </div>

          {/* FEE SCHEDULE EDITOR */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900">Configured Lipila Fee Tiers</h3>
                <p className="text-xs text-slate-500">
                  Tiers must be contiguous and ascending. The last tier must remain unbounded (Above).
                </p>
              </div>
              <button
                type="button"
                onClick={handleAddTier}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Tier</span>
              </button>
            </div>

            {/* Tiers Table */}
            <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="bg-slate-100 px-4 py-2 text-[11px] font-black text-slate-600 uppercase tracking-wider grid grid-cols-12 gap-2">
                <span className="col-span-4">Min Amount ({currencySymbol})</span>
                <span className="col-span-4">Max Amount ({currencySymbol})</span>
                <span className="col-span-3">Flat Charge ({currencySymbol})</span>
                <span className="col-span-1 text-center">Action</span>
              </div>

              <div className="divide-y divide-slate-100 bg-white">
                {tiers.map((tier, idx) => (
                  <div key={idx} className="p-3 grid grid-cols-12 gap-2 items-center text-xs">
                    <div className="col-span-4">
                      <input
                        type="number"
                        step="0.01"
                        value={tier.minAmount}
                        onChange={(e) => handleTierChange(idx, "minAmount", e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono font-bold"
                      />
                    </div>
                    <div className="col-span-4">
                      <input
                        type="text"
                        value={tier.maxAmount === null ? "Above" : tier.maxAmount}
                        onChange={(e) => handleTierChange(idx, "maxAmount", e.target.value)}
                        placeholder="Above"
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono font-bold"
                      />
                    </div>
                    <div className="col-span-3">
                      <input
                        type="number"
                        step="0.50"
                        value={tier.charge}
                        onChange={(e) => handleTierChange(idx, "charge", e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900"
                      />
                    </div>
                    <div className="col-span-1 text-center">
                      <button
                        type="button"
                        onClick={() => handleDeleteTier(idx)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition cursor-pointer"
                        title="Delete tier"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Validation & Success Alerts */}
            {validationError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{validationError}</span>
              </div>
            )}

            {successMessage && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}
          </div>

        </div>

        {/* FOOTER */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-slate-600 hover:text-slate-900 text-xs font-bold cursor-pointer"
          >
            Close
          </button>
          <button
            type="button"
            disabled={isSaving}
            onClick={handleSaveTiers}
            className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer shadow-md"
          >
            {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
            <span>Save Fee Schedule</span>
          </button>
        </div>

      </div>
    </div>
  );
};

export default SuperAdminFeeScheduleModal;

import React, { useState, useEffect, useMemo } from 'react';
import {
  Building2,
  Calendar,
  Filter,
  Search,
  Download,
  Printer,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  DollarSign,
  PieChart as PieIcon,
  BarChart2,
  FileSpreadsheet,
  FileText,
  AlertCircle,
  CheckCircle2,
  ChevronRight,
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  Layers,
  Sprout,
  Users,
  Eye,
  X,
  SlidersHorizontal,
  Landmark,
  ArrowUpRight,
  ArrowDownRight,
  Coins
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  LineChart,
  Line,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from 'recharts';
import {
  generateConsolidatedTenantReport,
  ConsolidatedTenantFinancialReport,
  FarmNodeFinancialSummary,
  ConsolidatedReportFilterParams
} from '../../services/consolidatedTenantReportService';
import {
  exportConsolidatedTenantReportPdf,
  exportConsolidatedTenantReportCsv
} from '../../utils/consolidatedTenantReportExport';

interface ConsolidatedTenantReportProps {
  tenantId?: string;
  institutionName?: string;
  institutionData?: any;
  institutionsList?: any[];
  farmersList?: any[];
  onSelectInstitution?: (institutionId: string) => void;
  isSuperAdmin?: boolean;
  currencySymbol?: string;
  onBack?: () => void;
}

export default function ConsolidatedTenantReport({
  tenantId,
  institutionName,
  institutionData,
  institutionsList = [],
  farmersList = [],
  onSelectInstitution,
  isSuperAdmin = false,
  currencySymbol = 'ZMW',
  onBack
}: ConsolidatedTenantReportProps) {
  // Selected Tenant
  const [selectedTenantId, setSelectedTenantId] = useState<string>(
    tenantId || institutionData?.id || (institutionsList.length > 0 ? institutionsList[0].id : '')
  );

  // Period & Filter State
  const [periodPreset, setPeriodPreset] = useState<'all' | 'ytd' | 'this_season' | 'dry_season' | 'last_quarter' | 'last_30_days' | 'custom'>('ytd');
  const [customStartDate, setCustomStartDate] = useState<string>('2026-01-01');
  const [customEndDate, setCustomEndDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [provinceFilter, setProvinceFilter] = useState<string>('All');
  const [currency, setCurrency] = useState<string>(currencySymbol || 'ZMW');

  // Active View Tab
  const [activeTab, setActiveTab] = useState<'income_statement' | 'balance_sheet' | 'nodes_matrix' | 'analytics_charts' | 'governance_risk'>('income_statement');

  // Node Inspection Modal State
  const [inspectedNode, setInspectedNode] = useState<FarmNodeFinancialSummary | null>(null);

  // Sorting in Node Matrix
  const [matrixSortField, setMatrixSortField] = useState<keyof FarmNodeFinancialSummary | 'revenue' | 'expenses' | 'profit' | 'margin' | 'assets' | 'debt'>('revenue');
  const [matrixSortAsc, setMatrixSortAsc] = useState<boolean>(false);

  // Live Loading State
  const [loading, setLoading] = useState<boolean>(false);
  const [apiReportData, setApiReportData] = useState<ConsolidatedTenantFinancialReport | null>(null);

  // Sync selectedTenantId if prop changes
  useEffect(() => {
    if (tenantId && tenantId !== selectedTenantId) {
      setSelectedTenantId(tenantId);
    } else if (institutionData?.id && institutionData.id !== selectedTenantId) {
      setSelectedTenantId(institutionData.id);
    }
  }, [tenantId, institutionData]);

  // Resolve current active institution object
  const currentInstitution = useMemo(() => {
    if (institutionData && institutionData.id === selectedTenantId) {
      return institutionData;
    }
    const found = institutionsList.find(i => i.id === selectedTenantId);
    return found || institutionData || {
      id: selectedTenantId || 'tenant_default',
      name: 'Primary Institutional Tenant',
      type: 'Institutional M&E Workspace',
      status: 'active'
    };
  }, [institutionData, institutionsList, selectedTenantId]);

  // Fetch from server if possible, or fallback to client-side engine
  const fetchTenantReport = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedTenantId) params.set('tenantId', selectedTenantId);
      if (periodPreset) params.set('preset', periodPreset);
      if (periodPreset === 'custom') {
        params.set('startDate', customStartDate);
        params.set('endDate', customEndDate);
      }
      if (provinceFilter !== 'All') params.set('province', provinceFilter);

      const res = await fetch(`/api/institution/consolidated-tenant-report?${params.toString()}`);
      if (res.ok) {
        const json = await res.json();
        if (json.report) {
          setApiReportData(json.report);
          setLoading(false);
          return;
        }
      }
    } catch (e) {
      console.warn('Backend consolidated report endpoint fallback to client engine:', e);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchTenantReport();
  }, [selectedTenantId, periodPreset, customStartDate, customEndDate, provinceFilter]);

  // Generate Report using Local Engine
  const report: ConsolidatedTenantFinancialReport = useMemo(() => {
    if (apiReportData && apiReportData.institution?.id === selectedTenantId) {
      return apiReportData;
    }
    const filters: ConsolidatedReportFilterParams = {
      tenantId: selectedTenantId,
      institutionId: selectedTenantId,
      periodPreset,
      startDate: periodPreset === 'custom' ? customStartDate : undefined,
      endDate: periodPreset === 'custom' ? customEndDate : undefined,
      provinceFilter,
      searchQuery,
      currency
    };
    return generateConsolidatedTenantReport(currentInstitution, farmersList, filters);
  }, [apiReportData, currentInstitution, farmersList, selectedTenantId, periodPreset, customStartDate, customEndDate, provinceFilter, searchQuery, currency]);

  // List of available provinces for filter
  const availableProvinces = useMemo(() => {
    const set = new Set<string>();
    farmersList.forEach(f => {
      const p = f.province || f.location?.province;
      if (p) set.add(p);
    });
    return ['All', ...Array.from(set)];
  }, [farmersList]);

  // Sorted farm nodes matrix
  const sortedFarmNodes = useMemo(() => {
    const list = [...report.farmNodesMatrix];
    list.sort((a, b) => {
      let valA = 0;
      let valB = 0;
      switch (matrixSortField) {
        case 'revenue':
          valA = a.revenue.total;
          valB = b.revenue.total;
          break;
        case 'expenses':
          valA = a.expenses.total;
          valB = b.expenses.total;
          break;
        case 'profit':
          valA = a.profitability.netOperatingIncome;
          valB = b.profitability.netOperatingIncome;
          break;
        case 'margin':
          valA = a.profitability.netMarginPct;
          valB = b.profitability.netMarginPct;
          break;
        case 'assets':
          valA = a.balanceSheet.totalAssets;
          valB = b.balanceSheet.totalAssets;
          break;
        case 'debt':
          valA = a.balanceSheet.totalLiabilities;
          valB = b.balanceSheet.totalLiabilities;
          break;
        default:
          valA = a.revenue.total;
          valB = b.revenue.total;
      }
      return matrixSortAsc ? valA - valB : valB - valA;
    });
    return list;
  }, [report.farmNodesMatrix, matrixSortField, matrixSortAsc]);

  const handleSortChange = (field: typeof matrixSortField) => {
    if (matrixSortField === field) {
      setMatrixSortAsc(!matrixSortAsc);
    } else {
      setMatrixSortField(field);
      setMatrixSortAsc(false);
    }
  };

  const handleExportPdf = () => {
    exportConsolidatedTenantReportPdf(report, currentInstitution.name, currency);
  };

  const handleExportCsv = () => {
    exportConsolidatedTenantReportCsv(report, currency);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* 1. Header & Controls Card */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              {onBack && (
                <button
                  type="button"
                  onClick={onBack}
                  className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition mr-1 cursor-pointer"
                  title="Return to previous view"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
              <div className="p-2 bg-emerald-50 rounded-lg border border-emerald-100 text-emerald-700">
                <Landmark className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  Consolidated Tenant Report {institutionName ? `— ${institutionName}` : ''}
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold">
                    Financial Aggregator
                  </span>
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Multi-node financial rollups, P&L statements, balance sheet liquidity, and comparative benchmarking across all farm nodes within this tenant.
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={fetchTenantReport}
              disabled={loading}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
              title="Refresh live data"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Sync
            </button>
            <button
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-sm transition"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              Export CSV / Excel
            </button>
            <button
              onClick={handleExportPdf}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm transition"
            >
              <Download className="w-3.5 h-3.5" />
              Export Official PDF
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-sm transition"
              title="Print View"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
            </button>
          </div>
        </div>

        {/* Filters and Tenant Switcher Row */}
        <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          {/* Tenant Selector (for Admins or Multi-tenancy) */}
          <div className="md:col-span-4">
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Institution Tenant Workspace
            </label>
            {institutionsList.length > 1 ? (
              <select
                value={selectedTenantId}
                onChange={(e) => {
                  setSelectedTenantId(e.target.value);
                  if (onSelectInstitution) onSelectInstitution(e.target.value);
                }}
                className="w-full bg-slate-50 border border-slate-300 text-slate-800 text-xs rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                {institutionsList.map((inst) => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name} ({inst.type || 'Tenant'}) - {inst.id.slice(0, 8)}...
                  </option>
                ))}
              </select>
            ) : (
              <div className="flex items-center justify-between px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                <span className="font-semibold text-slate-800">{currentInstitution.name}</span>
                <span className="text-[10px] text-slate-400 font-mono">{currentInstitution.id}</span>
              </div>
            )}
          </div>

          {/* Reporting Period Presets */}
          <div className="md:col-span-5">
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Reporting Financial Window
            </label>
            <div className="flex flex-wrap items-center gap-1">
              {[
                { id: 'ytd', label: 'YTD 2026' },
                { id: 'this_season', label: 'Wet Season' },
                { id: 'dry_season', label: 'Dry Season' },
                { id: 'last_30_days', label: '30 Days' },
                { id: 'all', label: 'All-Time' },
                { id: 'custom', label: 'Custom' }
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => setPeriodPreset(p.id as any)}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition ${
                    periodPreset === p.id
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Province / Region Filter */}
          <div className="md:col-span-3">
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Geographic Region
            </label>
            <select
              value={provinceFilter}
              onChange={(e) => setProvinceFilter(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 text-slate-800 text-xs rounded-lg px-3 py-1.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              {availableProvinces.map((prov) => (
                <option key={prov} value={prov}>
                  {prov === 'All' ? 'All Zambian Provinces' : prov}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Custom Date Pickers when 'custom' selected */}
        {periodPreset === 'custom' && (
          <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 font-medium">From:</span>
              <input
                type="date"
                value={customStartDate}
                onChange={(e) => setCustomStartDate(e.target.value)}
                className="bg-white border border-slate-300 text-slate-800 text-xs rounded-md px-2.5 py-1"
              />
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 font-medium">To:</span>
              <input
                type="date"
                value={customEndDate}
                onChange={(e) => setCustomEndDate(e.target.value)}
                className="bg-white border border-slate-300 text-slate-800 text-xs rounded-md px-2.5 py-1"
              />
            </div>
          </div>
        )}
      </div>

      {/* 2. Executive KPI Cards Hero (6 Cards) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
        {/* Consolidated Gross Revenue */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-bold uppercase tracking-wider text-[11px]">Gross Revenue</span>
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
              <DollarSign className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-lg font-bold text-slate-900">
              {currency} {report.portfolioTotals.consolidatedGrossRevenue.toLocaleString()}
            </div>
            <p className="text-[11px] text-emerald-700 font-medium mt-0.5 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              {report.portfolioTotals.activeFarmNodesCount} Active Nodes Generating
            </p>
          </div>
        </div>

        {/* Consolidated Operating Expenses */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-bold uppercase tracking-wider text-[11px]">Total OPEX</span>
            <div className="p-1.5 rounded-lg bg-red-50 text-red-600">
              <TrendingDown className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-lg font-bold text-slate-900">
              {currency} {report.portfolioTotals.consolidatedOperatingExpenses.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Opex Ratio: <span className="font-semibold text-slate-700">{report.portfolioTotals.portfolioAvgExpenseRatio.toFixed(1)}%</span>
            </p>
          </div>
        </div>

        {/* Net Operating Income & Margin */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-bold uppercase tracking-wider text-[11px]">Net Income (EBITDA)</span>
            <div className={`p-1.5 rounded-lg ${report.portfolioTotals.consolidatedNetOperatingIncome >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
              <Coins className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2">
            <div className={`text-lg font-bold ${report.portfolioTotals.consolidatedNetOperatingIncome >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
              {currency} {report.portfolioTotals.consolidatedNetOperatingIncome.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Net Margin: <span className="font-semibold text-slate-800">{report.portfolioTotals.consolidatedNetProfitMarginPct.toFixed(1)}%</span>
            </p>
          </div>
        </div>

        {/* Consolidated Total Assets */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-bold uppercase tracking-wider text-[11px]">Total Asset Base</span>
            <div className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
              <Layers className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-lg font-bold text-slate-900">
              {currency} {report.portfolioTotals.consolidatedTotalAssets.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Net Worth: <span className="font-semibold text-slate-700">{currency} {report.portfolioTotals.consolidatedNetWorth.toLocaleString()}</span>
            </p>
          </div>
        </div>

        {/* Total Debt & Liabilities */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-bold uppercase tracking-wider text-[11px]">Total Debt & AP</span>
            <div className="p-1.5 rounded-lg bg-amber-50 text-amber-600">
              <ShieldAlert className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-lg font-bold text-slate-900">
              {currency} {report.portfolioTotals.consolidatedTotalLiabilities.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Debt/Asset: <span className="font-semibold text-slate-700">{(report.portfolioTotals.consolidatedDebtToAssetRatio * 100).toFixed(1)}%</span>
            </p>
          </div>
        </div>

        {/* Footprint: Hectarage & Nodes */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-bold uppercase tracking-wider text-[11px]">Cultivated Area</span>
            <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
              <Sprout className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-lg font-bold text-slate-900">
              {report.portfolioTotals.totalCultivatedHectares.toLocaleString()} <span className="text-xs font-normal text-slate-500">ha</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Rev/ha: <span className="font-semibold text-slate-700">{currency} {report.portfolioTotals.portfolioAvgRevenuePerHectare.toLocaleString()}</span>
            </p>
          </div>
        </div>
      </div>

      {/* 3. Navigation View Tabs */}
      <div className="flex items-center border-b border-slate-200 bg-white px-3 pt-2 rounded-t-xl gap-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('income_statement')}
          className={`flex items-center gap-2 py-2.5 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition ${
            activeTab === 'income_statement'
              ? 'border-slate-900 text-slate-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          Consolidated Income Statement (P&L)
        </button>

        <button
          onClick={() => setActiveTab('balance_sheet')}
          className={`flex items-center gap-2 py-2.5 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition ${
            activeTab === 'balance_sheet'
              ? 'border-slate-900 text-slate-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Landmark className="w-3.5 h-3.5" />
          Consolidated Balance Sheet
        </button>

        <button
          onClick={() => setActiveTab('nodes_matrix')}
          className={`flex items-center gap-2 py-2.5 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition ${
            activeTab === 'nodes_matrix'
              ? 'border-slate-900 text-slate-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          Farm Nodes Comparative Matrix ({report.farmNodesMatrix.length})
        </button>

        <button
          onClick={() => setActiveTab('analytics_charts')}
          className={`flex items-center gap-2 py-2.5 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition ${
            activeTab === 'analytics_charts'
              ? 'border-slate-900 text-slate-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <BarChart2 className="w-3.5 h-3.5" />
          Visual Breakdown & Trends
        </button>

        <button
          onClick={() => setActiveTab('governance_risk')}
          className={`flex items-center gap-2 py-2.5 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition ${
            activeTab === 'governance_risk'
              ? 'border-slate-900 text-slate-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          Governance & Risk Insights
        </button>
      </div>

      {/* 4. Tab Content Panels */}
      
      {/* TAB 1: Consolidated Income Statement (P&L Rollup) */}
      {activeTab === 'income_statement' && (
        <div className="bg-white rounded-b-xl rounded-t-none border border-t-0 border-slate-200 shadow-sm p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Consolidated Income Statement (P&L Rollup)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Aggregated revenue, cost of goods sold, and operating expenditures across {report.portfolioTotals.totalFarmNodesCount} farm nodes.
              </p>
            </div>
            <span className="text-xs bg-slate-100 text-slate-700 px-3 py-1 rounded-full font-medium">
              Period: {report.reportingPeriod.preset}
            </span>
          </div>

          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-900 text-white font-bold">
                  <th className="py-3 px-4">Financial Statement Line Item</th>
                  <th className="py-3 px-4 text-right">Consolidated Amount ({currency})</th>
                  <th className="py-3 px-4 text-right">% of Gross Revenue</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {/* 1. REVENUE SECTION */}
                <tr className="bg-slate-50/80 font-bold text-slate-800">
                  <td colSpan={3} className="py-2.5 px-4 tracking-wider uppercase text-[11px] text-slate-600">
                    1. Commercial Agricultural Inflows (Gross Revenue)
                  </td>
                </tr>
                {report.revenueByCategory.map((cat, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50 transition">
                    <td className="py-2.5 px-6 text-slate-700 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: cat.color }} />
                      {cat.category}
                    </td>
                    <td className="py-2.5 px-4 text-right font-medium text-slate-900">
                      {currency} {cat.amount.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-4 text-right text-slate-500">
                      {cat.percentage.toFixed(1)}%
                    </td>
                  </tr>
                ))}
                <tr className="bg-emerald-50/60 font-bold text-emerald-950">
                  <td className="py-3 px-4 text-emerald-900">Total Consolidated Gross Revenue</td>
                  <td className="py-3 px-4 text-right text-emerald-900 font-bold">
                    {currency} {report.portfolioTotals.consolidatedGrossRevenue.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right text-emerald-800">100.0%</td>
                </tr>

                {/* 2. DIRECT PRODUCTION COSTS / COGS */}
                <tr className="bg-slate-50/80 font-bold text-slate-800">
                  <td colSpan={3} className="py-2.5 px-4 tracking-wider uppercase text-[11px] text-slate-600">
                    2. Direct Production Inputs & Feed Costs (COGS)
                  </td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-6 text-slate-700">
                    Direct Crop Inputs (Certified Seed, Basal/Top Dress Fertilizer, Agrochemicals)
                  </td>
                  <td className="py-2.5 px-4 text-right text-rose-700 font-medium">
                    -{currency} {report.expenseByCategory.find(c => c.category.includes('Crop Inputs'))?.amount.toLocaleString() || '0'}
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-500">
                    {(((report.expenseByCategory.find(c => c.category.includes('Crop Inputs'))?.amount || 0) / (report.portfolioTotals.consolidatedGrossRevenue || 1)) * 100).toFixed(1)}%
                  </td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-6 text-slate-700">
                    Livestock Feed Rations, Veterinary Diagnostics & Medication
                  </td>
                  <td className="py-2.5 px-4 text-right text-rose-700 font-medium">
                    -{currency} {report.expenseByCategory.find(c => c.category.includes('Feed'))?.amount.toLocaleString() || '0'}
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-500">
                    {(((report.expenseByCategory.find(c => c.category.includes('Feed'))?.amount || 0) / (report.portfolioTotals.consolidatedGrossRevenue || 1)) * 100).toFixed(1)}%
                  </td>
                </tr>
                <tr className="bg-slate-100/70 font-bold text-slate-900">
                  <td className="py-3 px-4">Consolidated Gross Profit</td>
                  <td className="py-3 px-4 text-right font-bold text-slate-900">
                    {currency} {report.portfolioTotals.consolidatedGrossProfit.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-700">
                    {report.portfolioTotals.consolidatedGrossMarginPct.toFixed(1)}% (Gross Margin)
                  </td>
                </tr>

                {/* 3. OPERATING EXPENSES (OPEX) */}
                <tr className="bg-slate-50/80 font-bold text-slate-800">
                  <td colSpan={3} className="py-2.5 px-4 tracking-wider uppercase text-[11px] text-slate-600">
                    3. Farm Operations, Payroll & Machinery Overheads
                  </td>
                </tr>
                {report.expenseByCategory.filter(c => !c.category.includes('Crop Inputs') && !c.category.includes('Feed')).map((cat, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50">
                    <td className="py-2.5 px-6 text-slate-700 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: cat.color }} />
                      {cat.category}
                    </td>
                    <td className="py-2.5 px-4 text-right text-rose-700 font-medium">
                      -{currency} {cat.amount.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-4 text-right text-slate-500">
                      {cat.percentage.toFixed(1)}%
                    </td>
                  </tr>
                ))}
                <tr className="bg-slate-100/80 font-bold text-slate-900">
                  <td className="py-3 px-4">Total Consolidated Operating Expenses (OPEX)</td>
                  <td className="py-3 px-4 text-right text-rose-800 font-bold">
                    -{currency} {report.portfolioTotals.consolidatedOperatingExpenses.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-700">
                    {report.portfolioTotals.portfolioAvgExpenseRatio.toFixed(1)}%
                  </td>
                </tr>

                {/* 4. NET OPERATING RESULT */}
                <tr className="bg-slate-900 text-white font-bold text-sm">
                  <td className="py-4 px-4 text-emerald-400">
                    Net Operating Income / EBITDA Rollup
                  </td>
                  <td className="py-4 px-4 text-right font-bold text-emerald-400">
                    {currency} {report.portfolioTotals.consolidatedNetOperatingIncome.toLocaleString()}
                  </td>
                  <td className="py-4 px-4 text-right text-emerald-300">
                    {report.portfolioTotals.consolidatedNetProfitMarginPct.toFixed(1)}%
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: Consolidated Balance Sheet & Capital Position */}
      {activeTab === 'balance_sheet' && (
        <div className="bg-white rounded-b-xl rounded-t-none border border-t-0 border-slate-200 shadow-sm p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Consolidated Balance Sheet & Capital Position
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Aggregated liquid assets, biological assets, machinery valuation, liabilities, and tenant equity across all linked farm nodes.
              </p>
            </div>
            <span className="text-xs bg-slate-100 text-slate-700 px-3 py-1 rounded-full font-medium">
              As of: {new Date().toLocaleDateString('en-GB')}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left: ASSETS */}
            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <div className="bg-slate-900 text-white px-4 py-3 font-bold text-xs flex items-center justify-between">
                <span>PORTFOLIO ASSETS</span>
                <span className="text-emerald-400">{currency} {report.portfolioTotals.consolidatedTotalAssets.toLocaleString()}</span>
              </div>
              <div className="p-4 space-y-4 text-xs">
                <div>
                  <div className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-2">
                    Current & Liquid Assets
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-600">Cash, Mobile Money & Bank Balances</span>
                      <span className="font-semibold text-slate-900">{currency} {report.portfolioTotals.consolidatedCashReserves.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-600">Trade Accounts Receivable (Offtaker Contracts)</span>
                      <span className="font-semibold text-slate-900">{currency} {report.portfolioTotals.consolidatedAccountsReceivable.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-600">Stored Input & Harvested Inventory</span>
                      <span className="font-semibold text-slate-900">{currency} {report.portfolioTotals.consolidatedInventoryValuation.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <div className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-2">
                    Biological & Fixed Assets
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-600">Standing Biological Assets (Crops & Herds)</span>
                      <span className="font-semibold text-slate-900">{currency} {report.portfolioTotals.consolidatedBiologicalAssets.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-600">Fixed Assets (Tractors, Pivots, Silos, Land Dev)</span>
                      <span className="font-semibold text-slate-900">{currency} {report.portfolioTotals.consolidatedFixedAssets.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-sm text-slate-900 bg-slate-50 p-2 rounded-lg">
                  <span>Total Consolidated Assets</span>
                  <span className="text-emerald-700">{currency} {report.portfolioTotals.consolidatedTotalAssets.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Right: LIABILITIES & EQUITY */}
            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <div className="bg-slate-900 text-white px-4 py-3 font-bold text-xs flex items-center justify-between">
                <span>LIABILITIES & TENANT EQUITY</span>
                <span className="text-emerald-400">{currency} {report.portfolioTotals.consolidatedTotalAssets.toLocaleString()}</span>
              </div>
              <div className="p-4 space-y-4 text-xs">
                <div>
                  <div className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-2">
                    Liabilities & Obligations
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-600">Current Liabilities (Accounts Payable & Agro Credit)</span>
                      <span className="font-semibold text-slate-900">{currency} {report.portfolioTotals.consolidatedCurrentLiabilities.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-600">Long-Term Debt & Capital Financing</span>
                      <span className="font-semibold text-slate-900">{currency} {report.portfolioTotals.consolidatedLongTermDebt.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between py-1 font-bold text-slate-800">
                      <span>Total Consolidated Liabilities</span>
                      <span className="text-rose-700">{currency} {report.portfolioTotals.consolidatedTotalLiabilities.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <div className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-2">
                    Net Asset Value & Tenant Equity
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-600">Consolidated Farm Net Worth</span>
                      <span className="font-bold text-emerald-700">{currency} {report.portfolioTotals.consolidatedNetWorth.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-600">Debt-to-Asset Leverage Ratio</span>
                      <span className="font-semibold text-slate-900">{(report.portfolioTotals.consolidatedDebtToAssetRatio * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-sm text-slate-900 bg-slate-50 p-2 rounded-lg">
                  <span>Total Liabilities & Equity</span>
                  <span className="text-slate-900">{currency} {report.portfolioTotals.consolidatedTotalAssets.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Farm Nodes Comparative Performance Matrix */}
      {activeTab === 'nodes_matrix' && (
        <div className="bg-white rounded-b-xl rounded-t-none border border-t-0 border-slate-200 shadow-sm p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Farm Nodes Comparative Financial Matrix
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Side-by-side financial breakdown, operating efficiency, net margins, and solvency rating for every farm node.
              </p>
            </div>
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search node, owner, or district..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>
          </div>

          {/* Matrix Table */}
          <div className="border border-slate-200 rounded-xl overflow-x-auto shadow-xs">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-900 text-white font-bold whitespace-nowrap">
                  <th className="py-3 px-3">Farm Node & Location</th>
                  <th className="py-3 px-3">Area (ha)</th>
                  <th
                    className="py-3 px-3 text-right cursor-pointer hover:bg-slate-800 transition"
                    onClick={() => handleSortChange('revenue')}
                  >
                    Revenue ({currency}) {matrixSortField === 'revenue' ? (matrixSortAsc ? '↑' : '↓') : ''}
                  </th>
                  <th
                    className="py-3 px-3 text-right cursor-pointer hover:bg-slate-800 transition"
                    onClick={() => handleSortChange('expenses')}
                  >
                    Expenses ({currency}) {matrixSortField === 'expenses' ? (matrixSortAsc ? '↑' : '↓') : ''}
                  </th>
                  <th
                    className="py-3 px-3 text-right cursor-pointer hover:bg-slate-800 transition"
                    onClick={() => handleSortChange('profit')}
                  >
                    Net Income ({currency}) {matrixSortField === 'profit' ? (matrixSortAsc ? '↑' : '↓') : ''}
                  </th>
                  <th
                    className="py-3 px-3 text-right cursor-pointer hover:bg-slate-800 transition"
                    onClick={() => handleSortChange('margin')}
                  >
                    Net Margin {matrixSortField === 'margin' ? (matrixSortAsc ? '↑' : '↓') : ''}
                  </th>
                  <th
                    className="py-3 px-3 text-right cursor-pointer hover:bg-slate-800 transition"
                    onClick={() => handleSortChange('assets')}
                  >
                    Total Assets {matrixSortField === 'assets' ? (matrixSortAsc ? '↑' : '↓') : ''}
                  </th>
                  <th
                    className="py-3 px-3 text-right cursor-pointer hover:bg-slate-800 transition"
                    onClick={() => handleSortChange('debt')}
                  >
                    Total Debt {matrixSortField === 'debt' ? (matrixSortAsc ? '↑' : '↓') : ''}
                  </th>
                  <th className="py-3 px-3 text-center">Health Band</th>
                  <th className="py-3 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sortedFarmNodes.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="text-center py-10 text-slate-400">
                      No farm nodes match the selected filters.
                    </td>
                  </tr>
                ) : (
                  sortedFarmNodes.map((node) => (
                    <tr key={node.nodeId} className="hover:bg-slate-50 transition">
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{node.farmName}</div>
                        <div className="text-[11px] text-slate-500">
                          {node.ownerName} • {node.district}, {node.province}
                        </div>
                      </td>
                      <td className="py-3 px-3 font-medium text-slate-700">
                        {node.hectarage} ha
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-slate-900">
                        {node.revenue.total.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right font-medium text-rose-700">
                        {node.expenses.total.toLocaleString()}
                      </td>
                      <td className={`py-3 px-3 text-right font-bold ${node.profitability.netOperatingIncome >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                        {node.profitability.netOperatingIncome.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right font-semibold">
                        <span className={`px-2 py-0.5 rounded-md text-[11px] ${
                          node.profitability.netMarginPct >= 20
                            ? 'bg-emerald-100 text-emerald-800'
                            : node.profitability.netMarginPct < 0
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {node.profitability.netMarginPct.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-medium text-slate-700">
                        {node.balanceSheet.totalAssets.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right font-medium text-slate-700">
                        {node.balanceSheet.totalLiabilities.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <span className={`inline-block px-2.5 py-0.5 text-[11px] font-bold rounded-full ${
                          node.financialHealthBand === 'A'
                            ? 'bg-emerald-100 text-emerald-800'
                            : node.financialHealthBand === 'B'
                            ? 'bg-blue-100 text-blue-800'
                            : node.financialHealthBand === 'C'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}>
                          Grade {node.financialHealthBand}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          onClick={() => setInspectedNode(node)}
                          className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-xs transition"
                        >
                          Inspect
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: Financial Visualizer & Analytics Charts */}
      {activeTab === 'analytics_charts' && (
        <div className="bg-white rounded-b-xl rounded-t-none border border-t-0 border-slate-200 shadow-sm p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Consolidated Financial Trends & Portfolio Distribution
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Visualizing revenue streams, expense drivers, and temporal dynamics across the tenant.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Chart 1: Revenue vs OPEX Trend */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                Periodic Revenue vs. OPEX Dynamics ({currency})
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={report.periodicTrends}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="periodLabel" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip
                      formatter={(val: any) => [`${currency} ${Number(val).toLocaleString()}`, '']}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px' }} />
                    <Bar dataKey="revenue" fill="#059669" name="Gross Revenue" />
                    <Bar dataKey="expenses" fill="#ef4444" name="Operating Expenses" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 2: Revenue Composition by Sector */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
                <PieIcon className="w-4 h-4 text-blue-600" />
                Revenue Composition by Enterprise
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={report.revenueByCategory}
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={85}
                      paddingAngle={4}
                      dataKey="amount"
                      nameKey="category"
                      label={(entry) => `${entry.percentage.toFixed(0)}%`}
                    >
                      {report.revenueByCategory.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(val: any) => [`${currency} ${Number(val).toLocaleString()}`, 'Revenue']}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 3: Expense Breakdown by Cost Driver */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-indigo-600" />
                Operating Expense Distribution by Cost Driver
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={report.expenseByCategory} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis type="number" tick={{ fontSize: 11 }} />
                    <YAxis dataKey="category" type="category" tick={{ fontSize: 10 }} width={130} />
                    <Tooltip
                      formatter={(val: any) => [`${currency} ${Number(val).toLocaleString()}`, 'Expense']}
                    />
                    <Bar dataKey="amount" fill="#6366f1" name="Cost Amount" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 4: Top Farm Node Revenue Contribution */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-600" />
                Top Farm Nodes by Revenue Contribution
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={report.topPerformers.byRevenue}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="farmName" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip
                      formatter={(val: any) => [`${currency} ${Number(val).toLocaleString()}`, 'Total Revenue']}
                    />
                    <Bar dataKey="revenue.total" fill="#10b981" name="Node Revenue" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: Governance, Risk & Automated Observations */}
      {activeTab === 'governance_risk' && (
        <div className="bg-white rounded-b-xl rounded-t-none border border-t-0 border-slate-200 shadow-sm p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Tenant Portfolio Governance & Risk Audit
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Automated credit risk classification, debt coverage evaluation, and operational risk alerts.
              </p>
            </div>
          </div>

          {/* Executive Observations Card */}
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-4">
            <h3 className="text-xs font-bold text-emerald-900 uppercase tracking-wider flex items-center gap-1.5 mb-2">
              <Sparkles className="w-4 h-4 text-emerald-700" />
              Executive Financial Observations
            </h3>
            <ul className="space-y-2 text-xs text-emerald-950">
              {report.executiveObservations.map((obs, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{obs}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Top Performers */}
            <div className="border border-slate-200 rounded-xl p-4 space-y-3">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Benchmark Leading Farm Nodes
              </h3>
              <div className="space-y-2 text-xs">
                {report.topPerformers.byRevenue.map((node, idx) => (
                  <div key={idx} className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                    <div>
                      <div className="font-bold text-slate-900">{node.farmName}</div>
                      <div className="text-[11px] text-slate-500">{node.district}, {node.province} • {node.hectarage} ha</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-emerald-700">{currency} {node.revenue.total.toLocaleString()}</div>
                      <div className="text-[10px] text-slate-500 font-semibold">{node.profitability.netMarginPct.toFixed(1)}% Margin</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Risk Alert Farm Nodes */}
            <div className="border border-slate-200 rounded-xl p-4 space-y-3">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-amber-600" />
                Nodes Requiring Attention / Intervention ({report.riskAlertNodes.length})
              </h3>
              <div className="space-y-2 text-xs">
                {report.riskAlertNodes.length === 0 ? (
                  <div className="p-4 bg-slate-50 rounded-lg text-center text-slate-500 text-xs">
                    All farm nodes are operating within acceptable solvency and profitability thresholds.
                  </div>
                ) : (
                  report.riskAlertNodes.map((node, idx) => (
                    <div key={idx} className="p-2.5 bg-amber-50/60 border border-amber-200 rounded-lg space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900">{node.farmName}</span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                          Grade {node.financialHealthBand}
                        </span>
                      </div>
                      <div className="text-[11px] text-amber-900">
                        {node.riskFlags.join(' • ')}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. Detailed Farm Node Inspection Slide-over / Modal */}
      {inspectedNode && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {inspectedNode.farmName}
                </h3>
                <p className="text-xs text-slate-500">
                  Node ID: {inspectedNode.nodeId} • {inspectedNode.district}, {inspectedNode.province}
                </p>
              </div>
              <button
                onClick={() => setInspectedNode(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="space-y-4 text-xs">
              {/* Snapshot Cards */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Gross Revenue</span>
                  <div className="text-sm font-bold text-slate-900 mt-1">
                    {currency} {inspectedNode.revenue.total.toLocaleString()}
                  </div>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Total Expenses</span>
                  <div className="text-sm font-bold text-rose-700 mt-1">
                    {currency} {inspectedNode.expenses.total.toLocaleString()}
                  </div>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Net Margin</span>
                  <div className="text-sm font-bold text-emerald-700 mt-1">
                    {inspectedNode.profitability.netMarginPct.toFixed(1)}%
                  </div>
                </div>
              </div>

              {/* Node Financial Breakdown */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-2">
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                  Detailed Expense & Production Profile
                </h4>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Direct Inputs (Seed/Fertilizer):</span>
                    <span className="font-semibold text-slate-900">{currency} {inspectedNode.expenses.directInputs.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Labor & Wages:</span>
                    <span className="font-semibold text-slate-900">{currency} {inspectedNode.expenses.laborPayroll.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Machinery Fuel & Repairs:</span>
                    <span className="font-semibold text-slate-900">{currency} {inspectedNode.expenses.machineryFuel.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Total Asset Base:</span>
                    <span className="font-semibold text-slate-900">{currency} {inspectedNode.balanceSheet.totalAssets.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Total Debt Obligations:</span>
                    <span className="font-semibold text-slate-900">{currency} {inspectedNode.balanceSheet.totalLiabilities.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Cultivated Hectares:</span>
                    <span className="font-semibold text-slate-900">{inspectedNode.hectarage} ha</span>
                  </div>
                </div>
              </div>

              {/* Operations & Staff */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-slate-500">Contact / Manager:</span>
                  <div className="font-bold text-slate-800">{inspectedNode.ownerName} ({inspectedNode.phone || 'No phone'})</div>
                </div>
                <div>
                  <span className="text-slate-500">Active Staff:</span>
                  <div className="font-bold text-slate-800 text-right">{inspectedNode.operations.staffCount} Workers</div>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setInspectedNode(null)}
                className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition"
              >
                Close Summary
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

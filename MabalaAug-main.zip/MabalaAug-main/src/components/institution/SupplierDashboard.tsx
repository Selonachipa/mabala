import React, { useState, useEffect, useMemo } from "react";
import {
  Building2,
  FileText,
  Lock,
  Unlock,
  CreditCard,
  Download,
  CheckCircle2,
  Clock,
  Sparkles,
  Package,
  Layers,
  ArrowUpRight,
  TrendingUp,
  Store,
  ShieldCheck,
  AlertTriangle,
  RefreshCw,
  Search,
  ExternalLink,
  ChevronRight,
  LogOut,
  MapPin,
  Phone,
  Mail,
  UserCheck,
  HelpCircle,
  FileSpreadsheet,
  Plus,
  Receipt,
  DollarSign,
  AlertCircle,
  CheckCircle,
  X,
  Filter,
  Eye,
  Send,
  Calendar,
  Wallet
} from "lucide-react";
import {
  getSupplierReportFeeRate,
  processSupplierReportAccessFee,
  getSupplierPurchasedReports,
  getMonthlyStatementLogs
} from "../../services/creditEngineV3Service";
import { INSTITUTION_REPORT_CATALOG, InstitutionReportDefinition } from "../../config/institutionReportDefinitions";
import { computeInstitutionReport } from "../../services/institutionReportService";
import { exportInstitutionReportPdf, exportInstitutionReportCsv } from "../../utils/institutionReportExport";
import { db } from "../../firebase";
import { Invoice, InvoiceLine } from "../../types";

export interface SupplierPartnerAccount {
  id: string;
  dealerName: string;
  location: string;
  province: string;
  contactPerson: string;
  phone: string;
  email: string;
  tpin?: string;
  contractType: "Consignment" | "Direct Wholesale" | "Credit Facility";
  creditLimit: number;
}

export interface SupplierInvoiceRecord {
  id: string;
  invoiceNumber: string;
  supplierId: string;
  supplierName: string;
  dealerId: string;
  dealerName: string;
  date: string;
  dueDate: string;
  lines: { description: string; quantity: number; unitPrice: number; amount: number }[];
  subtotal: number;
  taxAmount: number;
  total: number;
  paidAmount: number;
  status: "Paid" | "Unpaid" | "Partially Paid" | "Overdue" | "Cancelled";
  paymentDate?: string;
  receiptNumber?: string;
}

interface SupplierDashboardProps {
  userProfile?: {
    uid?: string;
    email?: string;
    name?: string;
    role?: string;
    tenantId?: string;
    phone?: string;
  };
  invoices?: Invoice[];
  currencySymbol?: string;
  onLogout?: () => void;
}

const INITIAL_DEALER_PARTNERS: SupplierPartnerAccount[] = [
  {
    id: "dealer-01",
    dealerName: "Sunrise Agro-Supplies Mkushi",
    location: "Mkushi Farming Block, Central Province",
    province: "Central Province",
    contactPerson: "Kelvin Mwape",
    phone: "+260 977 112 233",
    email: "sunrise.mkushi@agrohub.zm",
    tpin: "1003492819",
    contractType: "Consignment",
    creditLimit: 400000
  },
  {
    id: "dealer-02",
    dealerName: "Choma Farmers Depot & Seed Hub",
    location: "Livingstone Road, Choma",
    province: "Southern Province",
    contactPerson: "Miriam Mutale",
    phone: "+260 966 445 566",
    email: "choma.depot@agrohub.zm",
    tpin: "1008892104",
    contractType: "Consignment",
    creditLimit: 250000
  },
  {
    id: "dealer-03",
    dealerName: "Mpongwe Central Agro-Hub",
    location: "Mpongwe Boma, Copperbelt Province",
    province: "Copperbelt Province",
    contactPerson: "Derrick Chisenga",
    phone: "+260 971 889 900",
    email: "mpongwe.hub@agrohub.zm",
    tpin: "1009948211",
    contractType: "Credit Facility",
    creditLimit: 300000
  },
  {
    id: "dealer-04",
    dealerName: "Katete Rural Seed & Fertilizer Depot",
    location: "Great East Road, Katete",
    province: "Eastern Province",
    contactPerson: "Blessing Banda",
    phone: "+260 955 332 211",
    email: "katete.depot@agrohub.zm",
    tpin: "1007765123",
    contractType: "Direct Wholesale",
    creditLimit: 200000
  },
  {
    id: "dealer-05",
    dealerName: "Mazabuka Cane & Grain Supplies",
    location: "Town Centre, Mazabuka",
    province: "Southern Province",
    contactPerson: "Hastings Tembo",
    phone: "+260 978 776 543",
    email: "mazabuka.cane@agrohub.zm",
    tpin: "1005543219",
    contractType: "Consignment",
    creditLimit: 350000
  }
];

const INITIAL_SUPPLIER_INVOICES: SupplierInvoiceRecord[] = [
  {
    id: "inv-sup-101",
    invoiceNumber: "INV-ZAM-2026-001",
    supplierId: "supplier-node-01",
    supplierName: "Zambezi Agri-Supplies",
    dealerId: "dealer-01",
    dealerName: "Sunrise Agro-Supplies Mkushi",
    date: "2026-02-10",
    dueDate: "2026-02-24",
    lines: [
      { description: "Hybrid Seed Maize SC 719 (50kg Bags)", quantity: 200, unitPrice: 420, amount: 84000 },
      { description: "Basal Compound D Fertilizer (50kg Bags)", quantity: 150, unitPrice: 650, amount: 97500 }
    ],
    subtotal: 181500,
    taxAmount: 0,
    total: 181500,
    paidAmount: 120000,
    status: "Overdue"
  },
  {
    id: "inv-sup-102",
    invoiceNumber: "INV-ZAM-2026-002",
    supplierId: "supplier-node-01",
    supplierName: "Zambezi Agri-Supplies",
    dealerId: "dealer-01",
    dealerName: "Sunrise Agro-Supplies Mkushi",
    date: "2026-02-18",
    dueDate: "2026-03-04",
    lines: [
      { description: "Fungicide Copper Hydroxide (5L Jugs)", quantity: 40, unitPrice: 480, amount: 19200 }
    ],
    subtotal: 19200,
    taxAmount: 0,
    total: 19200,
    paidAmount: 0,
    status: "Unpaid"
  },
  {
    id: "inv-sup-103",
    invoiceNumber: "INV-ZAM-2026-003",
    supplierId: "supplier-node-01",
    supplierName: "Zambezi Agri-Supplies",
    dealerId: "dealer-02",
    dealerName: "Choma Farmers Depot & Seed Hub",
    date: "2026-01-20",
    dueDate: "2026-02-10",
    lines: [
      { description: "Early Maturing Soya Seed (25kg Bags)", quantity: 100, unitPrice: 380, amount: 38000 },
      { description: "Urea Top Dressing Fertilizer (50kg)", quantity: 80, unitPrice: 680, amount: 54400 }
    ],
    subtotal: 92400,
    taxAmount: 0,
    total: 92400,
    paidAmount: 92400,
    status: "Paid",
    paymentDate: "2026-02-08",
    receiptNumber: "REC-CHO-9821"
  },
  {
    id: "inv-sup-104",
    invoiceNumber: "INV-ZAM-2026-004",
    supplierId: "supplier-node-01",
    supplierName: "Zambezi Agri-Supplies",
    dealerId: "dealer-02",
    dealerName: "Choma Farmers Depot & Seed Hub",
    date: "2026-02-12",
    dueDate: "2026-02-26",
    lines: [
      { description: "Herbicide Glyphosate Systemic (20L Drum)", quantity: 30, unitPrice: 1100, amount: 33000 }
    ],
    subtotal: 33000,
    taxAmount: 0,
    total: 33000,
    paidAmount: 15000,
    status: "Partially Paid"
  },
  {
    id: "inv-sup-105",
    invoiceNumber: "INV-ZAM-2026-005",
    supplierId: "supplier-node-01",
    supplierName: "Zambezi Agri-Supplies",
    dealerId: "dealer-03",
    dealerName: "Mpongwe Central Agro-Hub",
    date: "2026-02-05",
    dueDate: "2026-02-19",
    lines: [
      { description: "Compound D Basal Fertilizer 50kg", quantity: 250, unitPrice: 650, amount: 162500 }
    ],
    subtotal: 162500,
    taxAmount: 0,
    total: 162500,
    paidAmount: 80000,
    status: "Overdue"
  },
  {
    id: "inv-sup-106",
    invoiceNumber: "INV-ZAM-2026-006",
    supplierId: "supplier-node-01",
    supplierName: "Zambezi Agri-Supplies",
    dealerId: "dealer-04",
    dealerName: "Katete Rural Seed & Fertilizer Depot",
    date: "2026-02-15",
    dueDate: "2026-03-01",
    lines: [
      { description: "Certified Hybrid Maize Seed 10kg", quantity: 300, unitPrice: 160, amount: 48000 }
    ],
    subtotal: 48000,
    taxAmount: 0,
    total: 48000,
    paidAmount: 0,
    status: "Unpaid"
  },
  {
    id: "inv-sup-107",
    invoiceNumber: "INV-ZAM-2026-007",
    supplierId: "supplier-node-01",
    supplierName: "Zambezi Agri-Supplies",
    dealerId: "dealer-05",
    dealerName: "Mazabuka Cane & Grain Supplies",
    date: "2026-01-15",
    dueDate: "2026-01-30",
    lines: [
      { description: "Pesticide Lambda-Cyhalothrin 1L", quantity: 60, unitPrice: 220, amount: 13200 }
    ],
    subtotal: 13200,
    taxAmount: 0,
    total: 13200,
    paidAmount: 13200,
    status: "Paid",
    paymentDate: "2026-01-28",
    receiptNumber: "REC-MAZ-1102"
  }
];

export default function SupplierDashboard({
  userProfile = {
    uid: "sup-001",
    email: "supplier@zamcrop.zm",
    name: "Zambezi Agri-Supplies & Seed Corp",
    role: "Institution Supplier",
    tenantId: "supplier-node-01",
    phone: "0977889900"
  },
  currencySymbol = "ZMW",
  onLogout
}: SupplierDashboardProps) {
  const tenantId = userProfile.tenantId || "supplier-node-01";
  const supplierName = userProfile.name || "Zambezi Agri-Supplies";
  const userPhone = userProfile.phone || "0977889900";

  // Navigation tabs
  const [activeTab, setActiveTab] = useState<"overview" | "invoices" | "consignments" | "reports" | "statements" | "profile">("overview");

  // Free Onboarding state
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState<boolean>(() => {
    return localStorage.getItem(`mabala_supplier_onboarded_${tenantId}`) === "true";
  });
  const [onboardingStep, setOnboardingStep] = useState<number>(1);
  const [onboardingForm, setOnboardingForm] = useState({
    companyName: supplierName,
    companySector: "Seed & Agrochemicals",
    zraTpin: "1002938481",
    warehouseLocation: "Lusaka Heavy Industrial Area, Stand 44",
    distributionHubs: ["Lusaka", "Copperbelt", "Eastern Province", "Southern Province"],
    contactPhone: userPhone,
    contactEmail: userProfile.email || "accounts@zamcrop.zm",
    catalogCategories: ["Hybrid Maize Seed", "Basal Fertilizer", "Fungicides & Insecticides"]
  });

  // Report Centre state
  const [supplierFeeRate, setSupplierFeeRate] = useState<number>(getSupplierReportFeeRate());
  const [purchasedReports, setPurchasedReports] = useState<Record<string, any>>({});
  const [selectedReportId, setSelectedReportId] = useState<string>("me-executive-impact-summary");

  // Pay-Per-Report Modal state
  const [unlockModalReport, setUnlockModalReport] = useState<InstitutionReportDefinition | null>(null);
  const [paymentProvider, setPaymentProvider] = useState<"Airtel Money" | "MTN Money" | "Zamtel Kwacha" | "Visa / Mastercard 3DS">("Airtel Money");
  const [payPhone, setPayPhone] = useState<string>(userPhone);
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);

  // Statement & History
  const [monthlyStatements, setMonthlyStatements] = useState<any[]>([]);

  // Dealers & Supplier Invoices Ledger State
  const [dealerPartners, setDealerPartners] = useState<SupplierPartnerAccount[]>(() => {
    const saved = localStorage.getItem(`mabala_supplier_dealers_${tenantId}`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (_) {}
    }
    return INITIAL_DEALER_PARTNERS;
  });

  const [supplierInvoices, setSupplierInvoices] = useState<SupplierInvoiceRecord[]>(() => {
    const saved = localStorage.getItem(`mabala_supplier_invoices_${tenantId}`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (_) {}
    }
    return INITIAL_SUPPLIER_INVOICES;
  });

  // Filters & Search for Invoices
  const [invoiceSearchQuery, setInvoiceSearchQuery] = useState<string>("");
  const [invoiceStatusFilter, setInvoiceStatusFilter] = useState<string>("ALL");
  const [provinceFilter, setProvinceFilter] = useState<string>("ALL");

  // Inspection Drawer/Modal State for Dealer Invoices
  const [selectedDealerForInvoices, setSelectedDealerForInvoices] = useState<SupplierPartnerAccount | null>(null);
  const [showCreateInvoiceModal, setShowCreateInvoiceModal] = useState<boolean>(false);
  const [newInvoiceDealerId, setNewInvoiceDealerId] = useState<string>(dealerPartners[0]?.id || "");
  const [newInvoiceDueDate, setNewInvoiceDueDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split("T")[0];
  });
  const [newInvoiceLines, setNewInvoiceLines] = useState<{ description: string; quantity: number; unitPrice: number }[]>([
    { description: "", quantity: 1, unitPrice: 0 }
  ]);

  // Payment Recording Modal State
  const [payingInvoice, setPayingInvoice] = useState<SupplierInvoiceRecord | null>(null);
  const [paymentAmountInput, setPaymentAmountInput] = useState<number>(0);
  const [paymentReceiptInput, setPaymentReceiptInput] = useState<string>("");

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(`mabala_supplier_invoices_${tenantId}`, JSON.stringify(supplierInvoices));
  }, [supplierInvoices, tenantId]);

  useEffect(() => {
    localStorage.setItem(`mabala_supplier_dealers_${tenantId}`, JSON.stringify(dealerPartners));
  }, [dealerPartners, tenantId]);

  // Load live fee rate and purchases
  useEffect(() => {
    setSupplierFeeRate(getSupplierReportFeeRate());
    getSupplierPurchasedReports(tenantId, db).then((res) => {
      setPurchasedReports(res);
    });

    const allStatements = getMonthlyStatementLogs().filter(s => s.role === "SUPPLIER" || s.tenantId === tenantId);
    setMonthlyStatements(allStatements);
  }, [tenantId]);

  // Dynamic Aggregation for Dealers with Outstanding Balance
  const dealerLedgerSummaries = useMemo(() => {
    return dealerPartners.map(dealer => {
      const matchedInvoices = supplierInvoices.filter(
        inv => inv.dealerId === dealer.id || inv.dealerName.toLowerCase() === dealer.dealerName.toLowerCase()
      );

      const totalInvoiced = matchedInvoices.reduce((sum, inv) => sum + inv.total, 0);
      const totalPaid = matchedInvoices.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);
      
      // Filter unpaid/partially paid/overdue invoices to compute dynamic Outstanding Balance
      const unpaidInvoices = matchedInvoices.filter(
        inv => inv.status !== "Paid" && inv.status !== "Cancelled"
      );
      
      const outstandingBalance = unpaidInvoices.reduce((sum, inv) => {
        const remaining = inv.total - (inv.paidAmount || 0);
        return sum + (remaining > 0 ? remaining : 0);
      }, 0);

      const todayStr = new Date().toISOString().split("T")[0];
      const overdueInvoicesCount = unpaidInvoices.filter(inv => inv.dueDate < todayStr).length;

      return {
        ...dealer,
        invoices: matchedInvoices,
        unpaidInvoices,
        totalInvoiced,
        totalPaid,
        outstandingBalance,
        unpaidCount: unpaidInvoices.length,
        overdueCount: overdueInvoicesCount
      };
    });
  }, [dealerPartners, supplierInvoices]);

  // Global Aggregates
  const totalNetworkInvoiced = useMemo(() => {
    return dealerLedgerSummaries.reduce((sum, d) => sum + d.totalInvoiced, 0);
  }, [dealerLedgerSummaries]);

  const totalNetworkPaid = useMemo(() => {
    return dealerLedgerSummaries.reduce((sum, d) => sum + d.totalPaid, 0);
  }, [dealerLedgerSummaries]);

  const totalNetworkOutstandingBalance = useMemo(() => {
    return dealerLedgerSummaries.reduce((sum, d) => sum + d.outstandingBalance, 0);
  }, [dealerLedgerSummaries]);

  const totalUnpaidInvoicesCount = useMemo(() => {
    return dealerLedgerSummaries.reduce((sum, d) => sum + d.unpaidCount, 0);
  }, [dealerLedgerSummaries]);

  const totalOverdueInvoicesCount = useMemo(() => {
    return dealerLedgerSummaries.reduce((sum, d) => sum + d.overdueCount, 0);
  }, [dealerLedgerSummaries]);

  // Filtered Dealers List
  const filteredDealers = useMemo(() => {
    return dealerLedgerSummaries.filter(d => {
      const matchSearch =
        d.dealerName.toLowerCase().includes(invoiceSearchQuery.toLowerCase()) ||
        d.location.toLowerCase().includes(invoiceSearchQuery.toLowerCase()) ||
        d.contactPerson.toLowerCase().includes(invoiceSearchQuery.toLowerCase());
      
      const matchProvince = provinceFilter === "ALL" || d.province === provinceFilter;

      const matchStatus =
        invoiceStatusFilter === "ALL" ||
        (invoiceStatusFilter === "OUTSTANDING" && d.outstandingBalance > 0) ||
        (invoiceStatusFilter === "CLEARED" && d.outstandingBalance === 0) ||
        (invoiceStatusFilter === "OVERDUE" && d.overdueCount > 0);

      return matchSearch && matchProvince && matchStatus;
    });
  }, [dealerLedgerSummaries, invoiceSearchQuery, provinceFilter, invoiceStatusFilter]);

  const handleFinishOnboarding = () => {
    try {
      localStorage.setItem(`mabala_supplier_onboarded_${tenantId}`, "true");
      localStorage.setItem(`mabala_supplier_profile_${tenantId}`, JSON.stringify(onboardingForm));
    } catch (_) {}
    setHasCompletedOnboarding(true);
  };

  const handleUnlockReport = async () => {
    if (!unlockModalReport) return;
    setIsProcessingPayment(true);
    try {
      const res = await processSupplierReportAccessFee({
        tenantId,
        supplierName,
        reportId: unlockModalReport.id,
        reportTitle: unlockModalReport.title,
        customerPhone: payPhone,
        amountZMW: supplierFeeRate,
        paymentMethod: paymentProvider
      });

      if (res.success) {
        const updated = {
          ...purchasedReports,
          [unlockModalReport.id]: {
            reportId: unlockModalReport.id,
            purchasedAt: new Date().toISOString(),
            priceZMW: supplierFeeRate,
            paymentMethod: paymentProvider,
            phone: payPhone,
            referenceId: res.referenceId
          }
        };
        setPurchasedReports(updated);
        setUnlockModalReport(null);
        alert(`Payment Authorized: ZMW ${supplierFeeRate} settled via ${paymentProvider}. Intelligence Report unlocked!`);
      } else {
        alert("Payment gateway failed. Please try again.");
      }
    } catch (e: any) {
      alert("Error: " + e.message);
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const handleCreateInvoiceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const dealer = dealerPartners.find(d => d.id === newInvoiceDealerId);
    if (!dealer) {
      alert("Please select a valid partner agro-dealer.");
      return;
    }

    const calculatedLines = newInvoiceLines.map(l => ({
      description: l.description,
      quantity: Number(l.quantity) || 1,
      unitPrice: Number(l.unitPrice) || 0,
      amount: (Number(l.quantity) || 1) * (Number(l.unitPrice) || 0)
    }));

    const subtotal = calculatedLines.reduce((sum, l) => sum + l.amount, 0);
    const taxAmount = 0;
    const total = subtotal + taxAmount;

    const newInvoice: SupplierInvoiceRecord = {
      id: `inv-sup-${Date.now()}`,
      invoiceNumber: `INV-ZAM-${new Date().getFullYear()}-${String(supplierInvoices.length + 1).padStart(3, "0")}`,
      supplierId: tenantId,
      supplierName,
      dealerId: dealer.id,
      dealerName: dealer.dealerName,
      date: new Date().toISOString().split("T")[0],
      dueDate: newInvoiceDueDate,
      lines: calculatedLines,
      subtotal,
      taxAmount,
      total,
      paidAmount: 0,
      status: "Unpaid"
    };

    setSupplierInvoices(prev => [newInvoice, ...prev]);
    setShowCreateInvoiceModal(false);
    setNewInvoiceLines([{ description: "", quantity: 1, unitPrice: 0 }]);
    alert(`Successfully generated Invoice ${newInvoice.invoiceNumber} for ${dealer.dealerName}. Outstanding Balance updated!`);
  };

  const handleRecordPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payingInvoice) return;

    const payAmount = Number(paymentAmountInput);
    if (isNaN(payAmount) || payAmount <= 0) {
      alert("Please specify a valid payment amount.");
      return;
    }

    const currentPaid = payingInvoice.paidAmount || 0;
    const nextPaid = currentPaid + payAmount;
    const nextStatus: "Paid" | "Partially Paid" = nextPaid >= payingInvoice.total ? "Paid" : "Partially Paid";

    setSupplierInvoices(prev =>
      prev.map(inv => {
        if (inv.id === payingInvoice.id) {
          return {
            ...inv,
            paidAmount: Math.min(nextPaid, inv.total),
            status: nextStatus,
            paymentDate: new Date().toISOString().split("T")[0],
            receiptNumber: paymentReceiptInput.trim() || `REC-${Date.now().toString().slice(-6)}`
          };
        }
        return inv;
      })
    );

    setPayingInvoice(null);
    setPaymentAmountInput(0);
    setPaymentReceiptInput("");
    alert(`Payment of ${currencySymbol} ${payAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} recorded. Outstanding balance dynamically re-calculated!`);
  };

  // Selected report computation
  const selectedReportDef = INSTITUTION_REPORT_CATALOG.find((r) => r.id === selectedReportId) || INSTITUTION_REPORT_CATALOG[0];
  const isSelectedReportUnlocked = Boolean(purchasedReports[selectedReportDef.id]);
  const computedData = useMemo(() => {
    if (!isSelectedReportUnlocked) return null;
    const filter = {
      reportId: selectedReportDef.id,
      region: "all",
      cohort: "all",
      startDate: "2026-01-01",
      endDate: "2026-12-31"
    };
    return computeInstitutionReport(selectedReportDef, filter, {
      summary: {
        totalFarmers: dealerPartners.length,
        totalHectares: 0,
        totalDisbursedZMW: supplierInvoices.reduce((acc, inv) => acc + (inv.paidAmount || 0), 0)
      },
      farmersDetails: [],
      dealers: dealerPartners.map(d => ({
        name: d.name,
        region: d.location,
        orders: supplierInvoices.filter(i => i.dealerId === d.id).length,
        val: supplierInvoices.filter(i => i.dealerId === d.id).reduce((s, i) => s + (i.total || 0), 0),
        set: supplierInvoices.filter(i => i.dealerId === d.id).reduce((s, i) => s + (i.paidAmount || 0), 0),
        status: d.status
      }))
    });
  }, [selectedReportDef, isSelectedReportUnlocked, dealerPartners, supplierInvoices]);

  // ONBOARDING WIZARD
  if (!hasCompletedOnboarding) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6 font-sans">
        <div className="max-w-2xl w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl space-y-6 animate-fade-in">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-widest block">
                Free Tier Onboarding
              </span>
              <h1 className="text-xl font-black text-white">Institutional Supplier Workspace Setup</h1>
            </div>
          </div>

          {onboardingStep === 1 && (
            <div className="space-y-4">
              <h3 className="font-bold text-sm text-slate-200">Step 1 of 2: Corporate Details & Distribution Footprint</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Company Name</label>
                  <input
                    type="text"
                    value={onboardingForm.companyName}
                    onChange={e => setOnboardingForm(prev => ({ ...prev, companyName: e.target.value }))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">ZRA TPIN Number</label>
                  <input
                    type="text"
                    value={onboardingForm.zraTpin}
                    onChange={e => setOnboardingForm(prev => ({ ...prev, zraTpin: e.target.value }))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setOnboardingStep(2)}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-2"
                >
                  <span>Continue to Step 2</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {onboardingStep === 2 && (
            <div className="space-y-4">
              <h3 className="font-bold text-sm text-slate-200">Step 2 of 2: Confirm Free Commercial Access Terms</h3>
              <div className="p-4 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl text-xs space-y-2 text-emerald-200">
                <div className="flex items-center gap-2 font-bold text-emerald-400">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Zero Recurring Subscription Guarantee</span>
                </div>
                <p className="leading-relaxed">
                  Institutional Seed, Fertilizer, and Chemical suppliers enjoy full, unrestricted access to the Mabala platform with no monthly or annual subscription fees.
                </p>
              </div>

              <div className="flex justify-between pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setOnboardingStep(1)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 font-bold text-xs rounded-xl"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handleFinishOnboarding}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-600/30"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Activate Free Supplier Workspace</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // MAIN SUPPLIER DASHBOARD
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* TOP HEADER (Light Blue Theme) */}
      <header className="bg-gradient-to-r from-sky-100 via-blue-50 to-sky-100 text-slate-900 border-b border-sky-200 px-6 py-4 flex flex-wrap items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-700 flex items-center justify-center font-black text-white shadow-md shadow-blue-600/20">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-900 bg-emerald-100/90 px-2 py-0.5 rounded border border-emerald-300">
                Supplier Hub (v3.2)
              </span>
              <span className="text-xs text-sky-900 font-bold">· {tenantId}</span>
            </div>
            <h1 className="text-base font-black text-slate-950">{supplierName}</h1>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden sm:flex flex-col items-end text-xs">
            <span className="text-sky-900 font-bold">Network Outstanding:</span>
            <span className="font-mono font-black text-rose-700 text-sm">
              {currencySymbol} {totalNetworkOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
          </div>

          <div className="h-6 w-px bg-sky-200 hidden sm:block" />

          {onLogout && (
            <button
              onClick={onLogout}
              className="p-2 bg-white hover:bg-rose-50 text-slate-600 hover:text-rose-600 rounded-xl border border-sky-200 hover:border-rose-200 transition-all cursor-pointer shadow-xs"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      {/* SUB HEADER NAV */}
      <nav className="bg-white border-b border-slate-200 px-6 py-2 flex flex-wrap gap-2 text-xs font-bold shadow-xs">
        <button
          onClick={() => setActiveTab("overview")}
          className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === "overview" ? "bg-slate-900 text-white shadow-xs" : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Overview</span>
        </button>

        <button
          onClick={() => setActiveTab("invoices")}
          className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === "invoices" ? "bg-slate-900 text-white shadow-xs" : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          <Receipt className="w-4 h-4 text-emerald-600" />
          <span>Invoices & Outstanding Balances</span>
          {totalNetworkOutstandingBalance > 0 && (
            <span className="text-[10px] font-mono bg-rose-100 text-rose-800 px-1.5 py-0.2 rounded-full font-extrabold animate-pulse">
              {totalUnpaidInvoicesCount} Unpaid
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab("consignments")}
          className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === "consignments" ? "bg-slate-900 text-white shadow-xs" : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          <Package className="w-4 h-4 text-indigo-600" />
          <span>Consignment Hub & Dealer Network</span>
        </button>

        <button
          onClick={() => setActiveTab("reports")}
          className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === "reports" ? "bg-slate-900 text-white shadow-xs" : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          <FileText className="w-4 h-4 text-amber-600" />
          <span>Institutional Intelligence Reports</span>
          <span className="text-[10px] font-mono bg-amber-100 text-amber-900 px-1.5 py-0.2 rounded-full font-bold">
            {Object.keys(purchasedReports).length} Unlocked
          </span>
        </button>

        <button
          onClick={() => setActiveTab("statements")}
          className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === "statements" ? "bg-slate-900 text-white shadow-xs" : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          <Clock className="w-4 h-4 text-slate-500" />
          <span>Monthly Statements</span>
        </button>
      </nav>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 p-6 max-w-7xl w-full mx-auto space-y-6">
        {/* OVERVIEW TAB */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* WELCOME BANNER */}
            <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white p-6 rounded-3xl border border-slate-800 shadow-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded">
                  Active Commercial Hub
                </span>
                <h2 className="text-xl font-black mt-1">Supplier Command & Receivables Center</h2>
                <p className="text-xs text-slate-300 mt-1 max-w-xl font-medium">
                  Direct visibility into regional input demand forecasts, consignment deliveries, and live invoice aggregates across all partner Agro-Dealers in Zambia.
                </p>
              </div>

              <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 text-xs space-y-1">
                <div className="flex justify-between gap-4">
                  <span className="text-slate-400">Total Outstanding Balance:</span>
                  <span className="font-mono font-black text-rose-400 text-sm">
                    {currencySymbol} {totalNetworkOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-slate-400">Unpaid Invoices:</span>
                  <span className="font-mono font-bold text-amber-300">{totalUnpaidInvoicesCount} Invoices</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-slate-400">Active Partners:</span>
                  <span className="font-mono font-bold text-white">{dealerPartners.length} Agro-Dealers</span>
                </div>
              </div>
            </div>

            {/* QUICK STATS CARDS WITH OUTSTANDING BALANCE PROMINENT */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border-2 border-rose-200 bg-rose-50/20 shadow-xs space-y-2">
                <div className="flex items-center justify-between text-rose-700 text-xs font-black uppercase tracking-wider">
                  <span>Outstanding Balance</span>
                  <AlertCircle className="w-5 h-5 text-rose-600" />
                </div>
                <p className="text-2xl font-mono font-black text-rose-900">
                  {currencySymbol} {totalNetworkOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </p>
                <div className="flex items-center justify-between text-[11px] text-rose-700 font-bold">
                  <span>{totalUnpaidInvoicesCount} Unpaid Invoices</span>
                  {totalOverdueInvoicesCount > 0 && (
                    <span className="text-rose-800 font-extrabold bg-rose-100 px-1.5 py-0.5 rounded">
                      {totalOverdueInvoicesCount} Overdue
                    </span>
                  )}
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
                <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
                  <span>Total Invoiced</span>
                  <Receipt className="w-4 h-4 text-emerald-600" />
                </div>
                <p className="text-2xl font-mono font-black text-slate-900">
                  {currencySymbol} {totalNetworkInvoiced.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </p>
                <p className="text-[11px] text-slate-500">Across {supplierInvoices.length} issued invoices</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
                <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
                  <span>Total Settled Collections</span>
                  <Wallet className="w-4 h-4 text-indigo-600" />
                </div>
                <p className="text-2xl font-mono font-black text-emerald-700">
                  {currencySymbol} {totalNetworkPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </p>
                <p className="text-[11px] text-slate-500">
                  {totalNetworkInvoiced > 0 ? `${((totalNetworkPaid / totalNetworkInvoiced) * 100).toFixed(1)}% recovery rate` : "100% clean"}
                </p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
                <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
                  <span>Partner Agro-Dealers</span>
                  <Store className="w-4 h-4 text-amber-600" />
                </div>
                <p className="text-2xl font-black text-slate-900">{dealerPartners.length} Retail Hubs</p>
                <p className="text-[11px] text-slate-500">Across 4 provinces</p>
              </div>
            </div>

            {/* ACTION PROMPT & RECENT INVOICES SUMMARY */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
                      <Receipt className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">Live Supplier Receivables & Invoicing</h3>
                      <p className="text-xs text-slate-500">Audit unpaid balances and dispatch statements.</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab("invoices")}
                    className="px-3.5 py-1.5 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 flex items-center gap-1.5"
                  >
                    <span>View All Invoices</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </div>
                
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  Review itemized delivery notes, track dealer payment compliance, and inspect visual outstanding balances dynamically computed per consignment partner.
                </p>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500 font-bold">Total Unpaid Balance:</span>
                  <span className="font-mono font-black text-rose-700 text-sm">
                    {currencySymbol} {totalNetworkOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">Regional Market Intelligence</h3>
                      <p className="text-xs text-slate-500">Access verified farmer input demand and projections.</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab("reports")}
                    className="px-3.5 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 flex items-center gap-1.5"
                  >
                    <span>Explore Reports</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  Review agronomic distribution across Copperbelt, Central, and Southern provinces to optimize stocking, seed distribution, and regional credit allocations.
                </p>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500 font-bold">Unlocked Reports:</span>
                  <span className="font-bold text-emerald-700">{Object.keys(purchasedReports).length} Available</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* INVOICES & OUTSTANDING BALANCES TAB */}
        {(activeTab === "invoices" || activeTab === "consignments") && (
          <div className="space-y-6">
            {/* TOP BAR / FILTERS */}
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                <div>
                  <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                    <Receipt className="w-5 h-5 text-emerald-600" />
                    <span>Agro-Dealer Accounts & Outstanding Balance Ledger</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Live dynamic aggregation of unpaid, overdue, and settled invoices linked to each dealer partner.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setShowCreateInvoiceModal(true)}
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Issue New Wholesale Invoice</span>
                </button>
              </div>

              {/* SEARCH & FILTERS BAR */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    placeholder="Search dealer, location, or contact..."
                    value={invoiceSearchQuery}
                    onChange={e => setInvoiceSearchQuery(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
                  <span className="shrink-0">Status Filter:</span>
                  <select
                    value={invoiceStatusFilter}
                    onChange={e => setInvoiceStatusFilter(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="ALL">All Partners</option>
                    <option value="OUTSTANDING">Has Outstanding Balance</option>
                    <option value="OVERDUE">Overdue Invoices Only</option>
                    <option value="CLEARED">All Cleared (Zero Balance)</option>
                  </select>
                </div>

                <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
                  <span className="shrink-0">Province:</span>
                  <select
                    value={provinceFilter}
                    onChange={e => setProvinceFilter(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="ALL">All Zambian Provinces</option>
                    <option value="Central Province">Central Province</option>
                    <option value="Southern Province">Southern Province</option>
                    <option value="Copperbelt Province">Copperbelt Province</option>
                    <option value="Eastern Province">Eastern Province</option>
                  </select>
                </div>
              </div>
            </div>

            {/* DEALERS TABLE WITH VISUAL OUTSTANDING BALANCE COLUMN */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-sans">
                  <thead className="bg-slate-50 text-[10px] uppercase font-black tracking-wider text-slate-500 border-b border-slate-200">
                    <tr>
                      <th className="p-4">Agro-Dealer / Client</th>
                      <th className="p-4">Province / Location</th>
                      <th className="p-4 text-right">Credit Limit</th>
                      <th className="p-4 text-right">Total Invoiced</th>
                      <th className="p-4 text-right">Settled Amount</th>
                      <th className="p-4 text-right bg-rose-50/50 border-x border-rose-100 text-rose-900 font-extrabold">
                        Visual Outstanding Balance
                      </th>
                      <th className="p-4 text-center">Unpaid Status</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                    {filteredDealers.map(dealer => {
                      const hasOutstanding = dealer.outstandingBalance > 0;
                      const hasOverdue = dealer.overdueCount > 0;

                      return (
                        <tr key={dealer.id} className="hover:bg-slate-50/80 transition-all">
                          <td className="p-4">
                            <strong className="text-slate-900 block text-xs font-bold">{dealer.dealerName}</strong>
                            <span className="text-[10px] text-slate-400 block font-mono">
                              {dealer.contactPerson} · {dealer.phone}
                            </span>
                          </td>

                          <td className="p-4">
                            <span className="font-semibold text-slate-700 block">{dealer.location}</span>
                            <span className="text-[10px] text-slate-400 font-medium">{dealer.contractType}</span>
                          </td>

                          <td className="p-4 text-right font-mono font-semibold text-slate-600">
                            {currencySymbol} {dealer.creditLimit.toLocaleString()}
                          </td>

                          <td className="p-4 text-right font-mono font-bold text-slate-900">
                            {currencySymbol} {dealer.totalInvoiced.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>

                          <td className="p-4 text-right font-mono font-bold text-emerald-700">
                            {currencySymbol} {dealer.totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>

                          {/* VISUAL OUTSTANDING BALANCE COLUMN */}
                          <td className="p-4 text-right bg-rose-50/30 border-x border-rose-100/80 font-mono">
                            {hasOutstanding ? (
                              <div className="flex flex-col items-end gap-1">
                                <span className="text-sm font-black text-rose-700 tracking-tight">
                                  {currencySymbol} {dealer.outstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </span>
                                <div className="flex items-center gap-1">
                                  <span className="text-[9px] font-bold uppercase tracking-wider bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full font-mono">
                                    {dealer.unpaidCount} Unpaid {dealer.unpaidCount === 1 ? "Invoice" : "Invoices"}
                                  </span>
                                  {hasOverdue && (
                                    <span className="text-[9px] font-bold uppercase tracking-wider bg-rose-600 text-white px-1.5 py-0.5 rounded-full animate-pulse">
                                      Overdue
                                    </span>
                                  )}
                                </div>
                              </div>
                            ) : (
                              <div className="flex flex-col items-end gap-0.5">
                                <span className="text-xs font-black text-emerald-700">
                                  {currencySymbol} 0.00
                                </span>
                                <span className="text-[9px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                                  All Cleared
                                </span>
                              </div>
                            )}
                          </td>

                          <td className="p-4 text-center">
                            {hasOverdue ? (
                              <span className="px-2.5 py-1 bg-rose-100 text-rose-900 text-[10px] font-black rounded-full font-mono uppercase inline-flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3 text-rose-600" />
                                {dealer.overdueCount} Overdue
                              </span>
                            ) : hasOutstanding ? (
                              <span className="px-2.5 py-1 bg-amber-100 text-amber-900 text-[10px] font-black rounded-full font-mono uppercase">
                                Payment Pending
                              </span>
                            ) : (
                              <span className="px-2.5 py-1 bg-emerald-100 text-emerald-900 text-[10px] font-black rounded-full font-mono uppercase inline-flex items-center gap-1">
                                <CheckCircle className="w-3 h-3 text-emerald-600" />
                                Fully Settled
                              </span>
                            )}
                          </td>

                          <td className="p-4 text-right">
                            <button
                              type="button"
                              onClick={() => setSelectedDealerForInvoices(dealer)}
                              className="px-3 py-1.5 bg-slate-900 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs inline-flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>View Invoices ({dealer.invoices.length})</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })}

                    {filteredDealers.length === 0 && (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-slate-400 italic text-xs">
                          No agro-dealers matching your filter criteria.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* INSTITUTIONAL REPORTS TAB */}
        {activeTab === "reports" && (
          <div className="space-y-6">
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                <div>
                  <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                    <FileText className="w-5 h-5 text-indigo-600" />
                    <span>Institutional Intelligence Reports</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Pay-per-report market access with zero recurring subscription fees.
                  </p>
                </div>
              </div>

              {/* REPORT SELECTION GRID */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* REPORT LIST */}
                <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                  {INSTITUTION_REPORT_CATALOG.map((rep) => {
                    const isUnlocked = Boolean(purchasedReports[rep.id]);
                    const isSelected = rep.id === selectedReportDef.id;

                    return (
                      <div
                        key={rep.id}
                        onClick={() => setSelectedReportId(rep.id)}
                        className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                          isSelected
                            ? "bg-slate-900 text-white border-slate-900 shadow-md"
                            : isUnlocked
                            ? "bg-white border-emerald-200 hover:border-emerald-300"
                            : "bg-white border-slate-200 hover:border-slate-300 text-slate-800"
                        }`}
                      >
                        <div className="flex justify-between items-start">
                          <span className={`text-[9px] font-mono font-bold uppercase tracking-wider ${
                            isSelected ? "text-emerald-400" : isUnlocked ? "text-emerald-700" : "text-slate-400"
                          }`}>
                            {rep.category.toUpperCase()}
                          </span>
                          {isUnlocked ? (
                            <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-500 font-mono">
                              <Unlock className="w-3 h-3" />
                              <span>Unlocked</span>
                            </span>
                          ) : (
                            <span className="flex items-center gap-1 text-[10px] font-bold text-amber-500 font-mono">
                              <Lock className="w-3 h-3" />
                              <span>ZMW {supplierFeeRate}</span>
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-xs mt-1 leading-snug">{rep.title}</h4>
                      </div>
                    );
                  })}
                </div>

                {/* REPORT PREVIEW / DATA */}
                <div className="lg:col-span-2 space-y-4">
                  {isSelectedReportUnlocked && computedData ? (
                    <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
                      <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                        <div>
                          <span className="text-[10px] font-mono uppercase text-emerald-700 font-bold">
                            Verified Commercial Intelligence
                          </span>
                          <h3 className="font-black text-sm text-slate-900">{selectedReportDef.title}</h3>
                        </div>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => exportInstitutionReportPdf(computedData, supplierName, currencySymbol)}
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold flex items-center gap-1"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>PDF</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => exportInstitutionReportCsv(computedData, currencySymbol)}
                            className="px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold flex items-center gap-1"
                          >
                            <FileSpreadsheet className="w-3.5 h-3.5" />
                            <span>CSV</span>
                          </button>
                        </div>
                      </div>

                      {/* DATA TABLE */}
                      <div className="border border-slate-200 rounded-xl overflow-hidden max-h-72 overflow-y-auto">
                        <table className="w-full text-left text-xs bg-white">
                          <thead className="bg-slate-50 text-[9px] font-black uppercase text-slate-400 border-b">
                            <tr>
                              {selectedReportDef.columns.map((col) => (
                                <th key={col.key} className="p-2.5">
                                  {col.label}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {(computedData?.tableRows || []).slice(0, 10).map((row: any, idx: number) => (
                              <tr key={idx} className="hover:bg-slate-50">
                                {selectedReportDef.columns.map((col) => (
                                  <td key={col.key} className="p-2.5 font-medium">
                                    {col.type === "currency"
                                      ? `K${(row[col.key] || 0).toLocaleString()}`
                                      : col.type === "percent"
                                      ? `${row[col.key]}%`
                                      : row[col.key] || "—"}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-slate-50 border border-dashed border-slate-300 rounded-2xl p-8 text-center space-y-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
                        <Lock className="w-5 h-5" />
                      </div>
                      <h4 className="font-bold text-xs text-slate-900">Intelligence Report Locked</h4>
                      <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                        Unlock full agronomic data tables, provincial aggregations, and CSV exports with a one-time authorization of <strong>ZMW {supplierFeeRate}</strong>.
                      </p>
                      <button
                        type="button"
                        onClick={() => setUnlockModalReport(selectedReportDef)}
                        className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl inline-flex items-center gap-2 shadow-sm"
                      >
                        <Unlock className="w-4 h-4" />
                        <span>Authorize ZMW {supplierFeeRate} via Lipila</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 10 STATEMENTS TAB */}
        {activeTab === "statements" && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-amber-600" />
                  <span>Section 10 Supplier Monthly Statements</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Itemized record of unlocked intelligence reports and settled access fees.
                </p>
              </div>
              <span className="text-xs font-mono text-slate-500">{monthlyStatements.length} statements</span>
            </div>

            {monthlyStatements.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400 space-y-2">
                <p>No monthly statements generated yet for this period.</p>
                <p className="text-slate-500">
                  Statements are generated automatically at the end of every calendar month by the Section 10 statement scanner.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {monthlyStatements.map((st) => (
                  <div key={st.id} className="py-4 flex items-center justify-between">
                    <div>
                      <p className="font-bold text-xs text-slate-900">{st.statementPeriod}</p>
                      <p className="text-[11px] text-slate-500">
                        {st.reportsAccessedCount || 0} reports unlocked · Total Fees: ZMW {st.totalReportFeesChargedZMW || 0}
                      </p>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-bold">
                      Settled
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* MODAL 1: ITEMIZE & AUDIT UNPAID INVOICES PER DEALER */}
      {selectedDealerForInvoices && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-4xl w-full shadow-2xl border border-slate-200 space-y-5 animate-scale-up max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] font-mono font-bold uppercase text-emerald-700 tracking-wider">
                  Partner Receivables Audit
                </span>
                <h3 className="text-base font-black text-slate-900">
                  {selectedDealerForInvoices.dealerName}
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  {selectedDealerForInvoices.location} · {selectedDealerForInvoices.contactPerson} ({selectedDealerForInvoices.phone})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedDealerForInvoices(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-2"
              >
                ✕
              </button>
            </div>

            {/* SUMMARY CARDS FOR THIS DEALER */}
            {(() => {
              const matchedInvoices = supplierInvoices.filter(
                inv => inv.dealerId === selectedDealerForInvoices.id || inv.dealerName.toLowerCase() === selectedDealerForInvoices.dealerName.toLowerCase()
              );
              const totalInvoiced = matchedInvoices.reduce((sum, inv) => sum + inv.total, 0);
              const totalPaid = matchedInvoices.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);
              const unpaidInvoices = matchedInvoices.filter(inv => inv.status !== "Paid" && inv.status !== "Cancelled");
              const outstandingBalance = unpaidInvoices.reduce((sum, inv) => sum + (inv.total - (inv.paidAmount || 0)), 0);

              return (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Invoiced</span>
                      <strong className="text-base font-mono font-black text-slate-900">
                        {currencySymbol} {totalInvoiced.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </strong>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Settled Collections</span>
                      <strong className="text-base font-mono font-black text-emerald-700">
                        {currencySymbol} {totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </strong>
                    </div>

                    <div className="p-3 bg-rose-50/80 rounded-2xl border border-rose-200">
                      <span className="text-[10px] uppercase font-bold text-rose-700 block">Outstanding Balance</span>
                      <strong className="text-base font-mono font-black text-rose-800">
                        {currencySymbol} {outstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </strong>
                    </div>
                  </div>

                  {/* INVOICES LIST */}
                  <div className="flex-1 overflow-y-auto border border-slate-200 rounded-2xl">
                    <table className="w-full text-left text-xs bg-white">
                      <thead className="bg-slate-50 text-[9px] uppercase font-black text-slate-400 border-b">
                        <tr>
                          <th className="p-3">Invoice # / Date</th>
                          <th className="p-3">Due Date</th>
                          <th className="p-3">Items / Description</th>
                          <th className="p-3 text-right">Total</th>
                          <th className="p-3 text-right">Paid</th>
                          <th className="p-3 text-right text-rose-800 font-black">Outstanding</th>
                          <th className="p-3 text-center">Status</th>
                          <th className="p-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium">
                        {matchedInvoices.map((inv) => {
                          const unpaid = inv.total - (inv.paidAmount || 0);
                          const isOverdue = inv.status === "Overdue" || (inv.status !== "Paid" && inv.dueDate < new Date().toISOString().split("T")[0]);

                          return (
                            <tr key={inv.id} className="hover:bg-slate-50">
                              <td className="p-3">
                                <span className="font-mono font-bold text-slate-900 block">{inv.invoiceNumber}</span>
                                <span className="text-[10px] text-slate-400 font-mono">{inv.date}</span>
                              </td>
                              <td className="p-3 font-mono">
                                <span className={isOverdue ? "text-rose-600 font-bold" : "text-slate-600"}>
                                  {inv.dueDate}
                                </span>
                              </td>
                              <td className="p-3 text-slate-600 max-w-xs truncate">
                                {inv.lines.map(l => `${l.quantity}x ${l.description}`).join(", ")}
                              </td>
                              <td className="p-3 text-right font-mono font-bold text-slate-900">
                                {currencySymbol} {inv.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                              </td>
                              <td className="p-3 text-right font-mono font-bold text-emerald-700">
                                {currencySymbol} {(inv.paidAmount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                              </td>
                              <td className="p-3 text-right font-mono font-black text-rose-700">
                                {currencySymbol} {unpaid > 0 ? unpaid.toLocaleString(undefined, { minimumFractionDigits: 2 }) : "0.00"}
                              </td>
                              <td className="p-3 text-center">
                                <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase font-mono ${
                                  inv.status === "Paid"
                                    ? "bg-emerald-100 text-emerald-800"
                                    : isOverdue
                                    ? "bg-rose-100 text-rose-800"
                                    : "bg-amber-100 text-amber-800"
                                }`}>
                                  {inv.status}
                                </span>
                              </td>
                              <td className="p-3 text-right">
                                {inv.status !== "Paid" && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setPayingInvoice(inv);
                                      setPaymentAmountInput(unpaid);
                                    }}
                                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-bold inline-flex items-center gap-1"
                                  >
                                    <DollarSign className="w-3 h-3" />
                                    <span>Record Settlement</span>
                                  </button>
                                )}
                              </td>
                            </tr>
                          );
                        })}

                        {matchedInvoices.length === 0 && (
                          <tr>
                            <td colSpan={8} className="p-6 text-center text-slate-400 italic">
                              No invoices created for this partner yet.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </>
              );
            })()}

            <div className="flex justify-end pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setSelectedDealerForInvoices(null)}
                className="px-5 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl"
              >
                Close Audit View
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: ISSUE NEW WHOLESALE INVOICE */}
      {showCreateInvoiceModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-xl w-full shadow-2xl border border-slate-200 space-y-4 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">Issue Wholesale Seed / Chemical Invoice</h3>
                  <p className="text-[10px] text-slate-500 font-medium">Auto-updates supplier receivables ledger</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateInvoiceModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateInvoiceSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Target Agro-Dealer</label>
                <select
                  value={newInvoiceDealerId}
                  onChange={e => setNewInvoiceDealerId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold"
                  required
                >
                  {dealerPartners.map(d => (
                    <option key={d.id} value={d.id}>
                      {d.dealerName} ({d.province}) — Credit Limit: K{d.creditLimit.toLocaleString()}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Payment Due Date</label>
                <input
                  type="date"
                  value={newInvoiceDueDate}
                  onChange={e => setNewInvoiceDueDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold"
                  required
                />
              </div>

              {/* DYNAMIC LINE ITEMS */}
              <div className="space-y-2 border-t border-slate-100 pt-2">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black uppercase text-slate-500">Invoice Line Items</span>
                  <button
                    type="button"
                    onClick={() => setNewInvoiceLines(prev => [...prev, { description: "", quantity: 1, unitPrice: 0 }])}
                    className="text-[10px] text-emerald-700 font-bold hover:underline cursor-pointer"
                  >
                    + Add Product Line
                  </button>
                </div>

                {newInvoiceLines.map((line, idx) => (
                  <div key={idx} className="grid grid-cols-12 gap-2 bg-slate-50 p-2 rounded-xl border border-slate-200 items-center">
                    <input
                      type="text"
                      placeholder="Product Description (e.g. Compound D 50kg)"
                      value={line.description}
                      onChange={e => {
                        const val = e.target.value;
                        setNewInvoiceLines(prev => prev.map((l, i) => i === idx ? { ...l, description: val } : l));
                      }}
                      className="col-span-6 bg-white border border-slate-300 rounded-lg p-1.5 text-xs font-medium"
                      required
                    />
                    <input
                      type="number"
                      placeholder="Qty"
                      value={line.quantity}
                      onChange={e => {
                        const val = Number(e.target.value);
                        setNewInvoiceLines(prev => prev.map((l, i) => i === idx ? { ...l, quantity: val } : l));
                      }}
                      className="col-span-2 bg-white border border-slate-300 rounded-lg p-1.5 text-xs font-mono font-bold text-right"
                      required
                    />
                    <input
                      type="number"
                      placeholder="Unit Price"
                      value={line.unitPrice}
                      onChange={e => {
                        const val = Number(e.target.value);
                        setNewInvoiceLines(prev => prev.map((l, i) => i === idx ? { ...l, unitPrice: val } : l));
                      }}
                      className="col-span-3 bg-white border border-slate-300 rounded-lg p-1.5 text-xs font-mono font-bold text-right"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (newInvoiceLines.length > 1) {
                          setNewInvoiceLines(prev => prev.filter((_, i) => i !== idx));
                        }
                      }}
                      className="col-span-1 text-rose-500 font-bold text-center"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCreateInvoiceModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl"
                >
                  Issue Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: RECORD PAYMENT / SETTLEMENT */}
      {payingInvoice && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  <DollarSign className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">Record Partner Remittance</h3>
                  <p className="text-[10px] text-slate-500 font-mono">Invoice #{payingInvoice.invoiceNumber}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPayingInvoice(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleRecordPaymentSubmit} className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Dealer:</span>
                  <strong className="text-slate-900">{payingInvoice.dealerName}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Invoice Total:</span>
                  <span className="font-mono font-bold text-slate-900">
                    {currencySymbol} {payingInvoice.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between text-rose-700 font-bold">
                  <span>Current Outstanding:</span>
                  <span className="font-mono font-black">
                    {currencySymbol} {(payingInvoice.total - (payingInvoice.paidAmount || 0)).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Settlement Amount ({currencySymbol})</label>
                <input
                  type="number"
                  value={paymentAmountInput}
                  onChange={e => setPaymentAmountInput(Number(e.target.value))}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Payment Reference / Receipt #</label>
                <input
                  type="text"
                  placeholder="e.g. REC-2026-9811 or Mobile Money TXN ID"
                  value={paymentReceiptInput}
                  onChange={e => setPaymentReceiptInput(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setPayingInvoice(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl"
                >
                  Confirm Settlement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: PAY-PER-REPORT LIPILA UNLOCK MODAL */}
      {unlockModalReport && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">Unlock Intelligence Report</h3>
                  <p className="text-[10px] text-slate-500 font-medium">Lipila Payment Gateway Authorization</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setUnlockModalReport(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Report:</span>
                <span className="font-bold text-slate-900 text-right max-w-[200px] truncate">{unlockModalReport.title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Supplier:</span>
                <span className="font-bold text-slate-900">{supplierName}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-200">
                <span className="text-slate-700 font-bold">Access Fee:</span>
                <span className="font-mono font-black text-sm text-emerald-700">ZMW {supplierFeeRate}.00</span>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                  Payment Method
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(["Airtel Money", "MTN Money", "Zamtel Kwacha", "Visa / Mastercard 3DS"] as const).map((prov) => (
                    <button
                      key={prov}
                      type="button"
                      onClick={() => setPaymentProvider(prov)}
                      className={`p-2 rounded-xl text-xs font-bold border text-left transition-all cursor-pointer ${
                        paymentProvider === prov
                          ? "border-emerald-600 bg-emerald-50 text-emerald-900 ring-1 ring-emerald-500"
                          : "border-slate-200 bg-white text-slate-700 hover:border-slate-300"
                      }`}
                    >
                      {prov}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                  Mobile / Account Number
                </label>
                <input
                  type="text"
                  value={payPhone}
                  onChange={(e) => setPayPhone(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="pt-2 flex gap-3">
              <button
                disabled={isProcessingPayment}
                onClick={handleUnlockReport}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {isProcessingPayment ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Unlock className="w-4 h-4" />}
                <span>Authorize ZMW {supplierFeeRate} Payment</span>
              </button>
              <button
                disabled={isProcessingPayment}
                onClick={() => setUnlockModalReport(null)}
                className="py-2.5 px-4 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useState, useMemo } from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  Calendar, 
  Filter, 
  Search, 
  TrendingUp, 
  TrendingDown, 
  BarChart2, 
  PieChart as PieIcon, 
  LineChart as LineIcon,
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  Building2, 
  ChevronRight,
  ShieldAlert,
  Sliders,
  ArrowUpRight,
  Sprout,
  Users,
  Activity,
  DollarSign,
  Store,
  CloudRain,
  ShieldCheck,
  MessageSquare,
  Sparkles,
  Eye,
  FileSpreadsheet,
  X
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  LineChart, 
  Line, 
  AreaChart,
  Area,
  CartesianGrid 
} from 'recharts';

import { 
  INSTITUTION_REPORT_CATALOG, 
  INSTITUTION_REPORT_CATEGORIES, 
  InstitutionReportCategory, 
  InstitutionReportDefinition, 
  InstitutionChartType 
} from '../../config/institutionReportDefinitions';
import { 
  computeInstitutionReport, 
  InstitutionReportFilterParams, 
  InstitutionReportResult 
} from '../../services/institutionReportService';
import { 
  exportInstitutionReportPdf, 
  exportInstitutionReportCsv 
} from '../../utils/institutionReportExport';
import { 
  getSupplierReportFeeRate, 
  processSupplierReportAccessFee, 
  getSupplierPurchasedReports 
} from '../../services/creditEngineV3Service';
import ConsolidatedTenantReport from './ConsolidatedTenantReport';

interface InstitutionalReportCentreProps {
  dashboardData: any;
  farmersList?: any[];
  linkedVendorsList?: any[];
  smsBatches?: any[];
  institutionName?: string;
  currencySymbol?: string;
  onRefresh?: () => void;
  isSupplier?: boolean;
  tenantId?: string;
  tenantName?: string;
  userPhone?: string;
  userRole?: string;
}

const PALETTE = ['#10B981', '#3B82F6', '#F59E0B', '#8B5CF6', '#EC4899', '#06B6D4', '#6366F1', '#14B8A6'];

export default function InstitutionalReportCentre({
  dashboardData,
  farmersList = [],
  linkedVendorsList = [],
  smsBatches = [],
  institutionName = 'Mabala Institutional Portal',
  currencySymbol = 'ZMW',
  onRefresh,
  isSupplier = false,
  tenantId = 'supplier-default',
  tenantName = 'Mabala Supplier Partner',
  userPhone = '0977000000',
  userRole
}: InstitutionalReportCentreProps) {
  // Navigation & report selection
  const [viewMode, setViewMode] = useState<'me_indicators' | 'consolidated_tenant'>('me_indicators');
  const [selectedCategoryId, setSelectedCategoryId] = useState<'all' | InstitutionReportCategory>('all');
  const [selectedReportId, setSelectedReportId] = useState<string>('me-executive-impact-summary');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [tableSearch, setTableSearch] = useState<string>('');

  // Supplier pay-per-report access state
  const isSupplierUser = isSupplier || (userRole || '').toLowerCase().includes('supplier');
  const [supplierFeeRate, setSupplierFeeRate] = useState<number>(getSupplierReportFeeRate());
  const [purchasedReports, setPurchasedReports] = useState<Record<string, any>>({});
  const [showUnlockModal, setShowUnlockModal] = useState<boolean>(false);
  const [paymentProvider, setPaymentProvider] = useState<"Airtel Money" | "MTN Money" | "Zamtel Kwacha" | "Visa / Mastercard 3DS">("Airtel Money");
  const [payPhone, setPayPhone] = useState<string>(userPhone);
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [paymentSuccessReceipt, setPaymentSuccessReceipt] = useState<any | null>(null);

  // Load purchased reports
  React.useEffect(() => {
    setSupplierFeeRate(getSupplierReportFeeRate());
    getSupplierPurchasedReports(tenantId).then(res => {
      setPurchasedReports(res);
    });
  }, [tenantId]);

  // Date and filter parameters
  const [presetPeriod, setPresetPeriod] = useState<string>('all_time');
  const [startDate, setStartDate] = useState<string>('2025-01-01');
  const [endDate, setEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [selectedCohort, setSelectedCohort] = useState<string>('all');
  const [selectedChartType, setSelectedChartType] = useState<InstitutionChartType>('bar');

  // Drilldown modal
  const [selectedRowDetail, setSelectedRowDetail] = useState<any | null>(null);

  // Filtered reports in catalog
  const filteredCatalog = useMemo(() => {
    return INSTITUTION_REPORT_CATALOG.filter(rep => {
      const matchCategory = selectedCategoryId === 'all' || rep.category === selectedCategoryId;
      const matchSearch = !searchTerm || 
        rep.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
        rep.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rep.categoryLabel.toLowerCase().includes(searchTerm.toLowerCase());
      return matchCategory && matchSearch;
    });
  }, [selectedCategoryId, searchTerm]);

  // Selected report definition
  const currentDef = useMemo(() => {
    return INSTITUTION_REPORT_CATALOG.find(r => r.id === selectedReportId) || INSTITUTION_REPORT_CATALOG[0];
  }, [selectedReportId]);

  // Set default chart type when report changes
  React.useEffect(() => {
    if (currentDef) {
      setSelectedChartType(currentDef.defaultChartType);
    }
  }, [currentDef]);

  // Regions list extracted from farmer data
  const regionsList = useMemo(() => {
    const set = new Set<string>();
    if (dashboardData?.farmersDetails) {
      dashboardData.farmersDetails.forEach((f: any) => {
        if (f.address && f.address !== 'N/A') set.add(f.address);
      });
    }
    return ['all', ...Array.from(set)];
  }, [dashboardData]);

  // Cohorts list extracted from farmer data
  const cohortsList = useMemo(() => {
    const set = new Set<string>();
    if (dashboardData?.farmersDetails) {
      dashboardData.farmersDetails.forEach((f: any) => {
        if (f.cohortTag && f.cohortTag !== 'N/A') set.add(f.cohortTag);
      });
    }
    return ['all', ...Array.from(set)];
  }, [dashboardData]);

  // Compute live report result
  const reportResult: InstitutionReportResult = useMemo(() => {
    const filters: InstitutionReportFilterParams = {
      reportId: currentDef.id,
      startDate,
      endDate,
      presetPeriod,
      region: selectedRegion,
      cohort: selectedCohort,
      searchTerm: tableSearch
    };

    return computeInstitutionReport(
      currentDef,
      filters,
      dashboardData,
      farmersList,
      linkedVendorsList,
      smsBatches,
      currencySymbol
    );
  }, [currentDef, startDate, endDate, presetPeriod, selectedRegion, selectedCohort, tableSearch, dashboardData, farmersList, linkedVendorsList, smsBatches, currencySymbol]);

  // Handle Preset Period Switch
  const handlePresetChange = (preset: string) => {
    setPresetPeriod(preset);
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    if (preset === 'today') {
      setStartDate(todayStr);
      setEndDate(todayStr);
    } else if (preset === 'this_month') {
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
      setStartDate(firstDay);
      setEndDate(todayStr);
    } else if (preset === 'last_quarter') {
      const qStart = new Date(today.getFullYear(), today.getMonth() - 3, 1).toISOString().split('T')[0];
      setStartDate(qStart);
      setEndDate(todayStr);
    } else if (preset === 'season_wet_25_26') {
      setStartDate('2025-11-01');
      setEndDate('2026-04-30');
    } else if (preset === 'season_dry_25') {
      setStartDate('2025-05-01');
      setEndDate('2025-10-31');
    } else if (preset === 'ytd') {
      setStartDate(`${today.getFullYear()}-01-01`);
      setEndDate(todayStr);
    } else if (preset === 'all_time') {
      setStartDate('2024-01-01');
      setEndDate(todayStr);
    }
  };

  // Check if report is locked for Supplier
  const isReportLockedForSupplier = isSupplierUser && !purchasedReports[selectedReportId];

  const handleUnlockPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payPhone.trim()) return;

    setIsProcessingPayment(true);
    try {
      const res = await processSupplierReportAccessFee({
        tenantId,
        supplierName: tenantName,
        reportId: currentDef.id,
        reportTitle: currentDef.title,
        customerPhone: payPhone,
        amountZMW: supplierFeeRate,
        paymentMethod: paymentProvider
      });

      if (res.success) {
        const updated = {
          ...purchasedReports,
          [currentDef.id]: {
            reportId: currentDef.id,
            reportTitle: currentDef.title,
            purchasedAt: new Date().toISOString(),
            referenceId: res.referenceId,
            amountZMW: supplierFeeRate
          }
        };
        setPurchasedReports(updated);
        try {
          localStorage.setItem(`mabala_purchased_reports_${tenantId}`, JSON.stringify(updated));
        } catch (_) {}
        setPaymentSuccessReceipt(res);
        setShowUnlockModal(false);
      }
    } catch (err) {
      console.error("Supplier report unlock payment failed:", err);
    } finally {
      setIsProcessingPayment(false);
    }
  };

  // Helper icon renderer
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'me_impact': return <Activity className="w-4 h-4" />;
      case 'agronomy_yield': return <Sprout className="w-4 h-4" />;
      case 'livestock_dairy': return <Building2 className="w-4 h-4" />;
      case 'finance_credit': return <DollarSign className="w-4 h-4" />;
      case 'market_linkages': return <Store className="w-4 h-4" />;
      case 'labor_social': return <Users className="w-4 h-4" />;
      case 'weather_dwr': return <CloudRain className="w-4 h-4" />;
      case 'consignments': return <ShieldCheck className="w-4 h-4" />;
      case 'sms_outreach': return <MessageSquare className="w-4 h-4" />;
      default: return <Layers className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/20 text-emerald-400 rounded-full text-xs font-semibold uppercase tracking-wider mb-2 border border-emerald-500/30">
              <Sparkles className="w-3.5 h-3.5" /> {isSupplierUser ? "Supplier Analytics & Market Intelligence Hub" : "Institutional M&E & Portfolio Intelligence"}
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">{isSupplierUser ? "Supplier Intelligence & Reports Centre" : "Institutional Report Centre"}</h1>
            <p className="text-slate-400 text-sm mt-1 max-w-2xl">
              {isSupplierUser 
                ? `Access supply chain velocity, market linkages, and consignment analytics on a flexible flat fee per report (ZMW ${supplierFeeRate.toFixed(2)} via Lipila).`
                : "Audited programmatic reporting suites for donor impact verification, yield benchmarking, credit risk (PAR), and market linkages."}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {!isReportLockedForSupplier && (
              <>
                <button
                  onClick={() => exportInstitutionReportPdf(reportResult, institutionName, currencySymbol)}
                  className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded-xl shadow-md transition"
                  title="Download Executive PDF Report"
                >
                  <Download className="w-4 h-4" /> Export Executive PDF
                </button>

                <button
                  onClick={() => exportInstitutionReportCsv(reportResult, currencySymbol)}
                  className="inline-flex items-center gap-2 px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium text-xs rounded-xl transition"
                  title="Export CSV data sheet"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-400" /> Export CSV
                </button>
              </>
            )}

            {onRefresh && (
              <button
                onClick={onRefresh}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-xl transition"
                title="Refresh datasets"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mode Switcher Tabs */}
      <div className="flex flex-wrap gap-2 p-1.5 bg-slate-100 rounded-2xl w-fit border border-slate-200">
        <button
          type="button"
          onClick={() => setViewMode('me_indicators')}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition cursor-pointer ${
            viewMode === 'me_indicators'
              ? 'bg-slate-900 text-white shadow'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Layers className="w-4 h-4 text-emerald-400" />
          M&E Indicators Suite ({INSTITUTION_REPORT_CATALOG.length})
        </button>
        <button
          type="button"
          onClick={() => setViewMode('consolidated_tenant')}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition cursor-pointer ${
            viewMode === 'consolidated_tenant'
              ? 'bg-emerald-700 text-white shadow'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-4 h-4 text-emerald-300" />
          Consolidated Tenant Report (Multi-Farm P&L & Balance Sheet)
        </button>
      </div>

      {viewMode === 'consolidated_tenant' ? (
        <ConsolidatedTenantReport
          tenantId={tenantId}
          institutionName={institutionName}
          institutionData={dashboardData?.institution || dashboardData}
          farmersList={farmersList}
          currencySymbol={currencySymbol}
          onBack={() => setViewMode('me_indicators')}
        />
      ) : (
        /* Main layout: Sidebar selector + Active report viewport */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Report Catalog Directory */}
        <div className="lg:col-span-4 space-y-4">
          {/* Category Tabs */}
          <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-sm">
            <div className="flex items-center justify-between mb-2 px-1">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Categories</span>
              <span className="text-xs font-medium text-slate-400">{INSTITUTION_REPORT_CATALOG.length} Reports</span>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {INSTITUTION_REPORT_CATEGORIES.map(cat => {
                const isActive = selectedCategoryId === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategoryId(cat.id)}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition ${
                      isActive 
                        ? 'bg-slate-900 text-white shadow-sm' 
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {getCategoryIcon(cat.id)}
                    {cat.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Search box for reports */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              placeholder="Search reports by keyword..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Report List */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden divide-y divide-slate-100 max-h-[640px] overflow-y-auto">
            {filteredCatalog.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400">
                No reports matched your search criteria.
              </div>
            ) : (
              filteredCatalog.map(rep => {
                const isSelected = selectedReportId === rep.id;
                return (
                  <button
                    key={rep.id}
                    onClick={() => setSelectedReportId(rep.id)}
                    className={`w-full text-left p-3.5 transition flex items-start justify-between gap-3 ${
                      isSelected 
                        ? 'bg-emerald-50/80 border-l-4 border-emerald-600' 
                        : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-800">{rep.title}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">{rep.subtitle}</p>
                      <div className="inline-block text-[10px] font-semibold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded">
                        {rep.categoryLabel}
                      </div>
                    </div>
                    <ChevronRight className={`w-4 h-4 mt-1 flex-shrink-0 ${isSelected ? 'text-emerald-600' : 'text-slate-300'}`} />
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right Side: Report Viewport */}
        <div className="lg:col-span-8 space-y-6">
          {/* Controls Bar: Date Filter & Scope */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              {/* Presets */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
                {[
                  { id: 'all_time', label: 'All Time' },
                  { id: 'this_month', label: 'This Month' },
                  { id: 'last_quarter', label: 'Last Quarter' },
                  { id: 'season_wet_25_26', label: '2025/26 Wet' },
                  { id: 'season_dry_25', label: '2025 Dry' },
                  { id: 'ytd', label: 'YTD' }
                ].map(p => (
                  <button
                    key={p.id}
                    onClick={() => handlePresetChange(p.id)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-lg whitespace-nowrap transition ${
                      presetPeriod === p.id 
                        ? 'bg-emerald-600 text-white font-semibold shadow-sm' 
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              {/* Chart toggle */}
              {currentDef.chartTypes.length > 1 && (
                <div className="flex items-center bg-slate-100 p-1 rounded-lg">
                  {currentDef.chartTypes.includes('bar') && (
                    <button
                      onClick={() => setSelectedChartType('bar')}
                      className={`p-1.5 rounded text-xs font-medium transition ${selectedChartType === 'bar' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}
                      title="Bar View"
                    >
                      <BarChart2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {currentDef.chartTypes.includes('pie') && (
                    <button
                      onClick={() => setSelectedChartType('pie')}
                      className={`p-1.5 rounded text-xs font-medium transition ${selectedChartType === 'pie' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}
                      title="Pie / Donut View"
                    >
                      <PieIcon className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {currentDef.chartTypes.includes('line') && (
                    <button
                      onClick={() => setSelectedChartType('line')}
                      className={`p-1.5 rounded text-xs font-medium transition ${selectedChartType === 'line' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}
                      title="Line Trend View"
                    >
                      <LineIcon className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {currentDef.chartTypes.includes('area') && (
                    <button
                      onClick={() => setSelectedChartType('area')}
                      className={`p-1.5 rounded text-xs font-medium transition ${selectedChartType === 'area' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}
                      title="Area Fill View"
                    >
                      <TrendingUp className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Scope filters */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 border-t border-slate-100">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">Geographic Region</label>
                <select
                  value={selectedRegion}
                  onChange={(e) => setSelectedRegion(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-1.5 text-slate-700 focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="all">All Monitored Regions</option>
                  {regionsList.filter(r => r !== 'all').map(reg => (
                    <option key={reg} value={reg}>{reg}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">Target Cohort Tag</label>
                <select
                  value={selectedCohort}
                  onChange={(e) => setSelectedCohort(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-1.5 text-slate-700 focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="all">All Cohort Groups</option>
                  {cohortsList.filter(c => c !== 'all').map(coh => (
                    <option key={coh} value={coh}>{coh}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex-1">
                  <label className="block text-[11px] font-semibold text-slate-500 mb-1">Date Range</label>
                  <div className="text-[11px] font-medium text-slate-600 bg-slate-50 border border-slate-200 px-2 py-1.5 rounded-lg">
                    {startDate} → {endDate}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Active Report Header Box */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold px-2.5 py-1 bg-slate-100 text-slate-700 rounded-md">
                  {currentDef.categoryLabel}
                </span>
                <span className="text-xs text-slate-400">ID: {currentDef.id}</span>
                {isSupplierUser && (
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase ${
                    isReportLockedForSupplier ? "bg-amber-100 text-amber-900 border border-amber-300" : "bg-emerald-100 text-emerald-900 border border-emerald-300"
                  }`}>
                    {isReportLockedForSupplier ? "🔒 Locked (Pay-Per-Report)" : "✓ Unlocked & Verified"}
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-500 font-medium">
                Scope: {isReportLockedForSupplier ? "Locked Preview" : `${reportResult.totalRecordsCount} Audited Items`}
              </div>
            </div>

            <h2 className="text-lg font-bold text-slate-900">{currentDef.title}</h2>
            <p className="text-xs text-slate-600 leading-relaxed">{currentDef.description}</p>
          </div>

          {/* If Report is Locked for Supplier: Render Payment Gate */}
          {isReportLockedForSupplier ? (
            <div className="bg-white border-2 border-dashed border-amber-300 rounded-2xl p-8 text-center space-y-5 shadow-sm">
              <div className="w-14 h-14 bg-amber-100 text-amber-800 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
                <ShieldAlert className="w-7 h-7" />
              </div>
              
              <div className="max-w-md mx-auto space-y-2">
                <h3 className="text-lg font-black text-slate-900">Supplier Report Access Required</h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Under the v3.0 Supplier Model, reports are unlocked via a one-time flat fee per report rather than an ongoing subscription.
                </p>
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs font-mono font-bold text-amber-900">
                  Flat Report Fee: {currencySymbol} {supplierFeeRate.toFixed(2)} (Lipila API Instant Settlement)
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowUnlockModal(true)}
                  className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Unlock Report — Pay {currencySymbol} {supplierFeeRate.toFixed(2)} via Lipila</span>
                </button>
              </div>

              <div className="text-[11px] text-slate-400 max-w-lg mx-auto border-t border-slate-100 pt-4">
                ✓ Permanent access after purchase • Real-time data sync • Instant PDF dossier & CSV data export
              </div>
            </div>
          ) : (
            <>
              {/* KPI Summary Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {reportResult.kpiMetrics.map((kpi, idx) => {
                  return (
                    <div key={kpi.key || idx} className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:border-slate-300 transition">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block truncate">
                        {kpi.label}
                      </span>
                      <div className="text-lg font-extrabold text-slate-900 mt-1">
                        {kpi.formatted}
                      </div>
                      {kpi.target !== undefined && kpi.deltaPct !== undefined && (
                        <div className="flex items-center gap-1 mt-1 text-[11px]">
                          {kpi.deltaPct >= 0 ? (
                            <span className="text-emerald-600 font-semibold flex items-center">
                              <TrendingUp className="w-3 h-3 mr-0.5" /> +{kpi.deltaPct}%
                            </span>
                          ) : (
                            <span className="text-rose-500 font-semibold flex items-center">
                              <TrendingDown className="w-3 h-3 mr-0.5" /> {kpi.deltaPct}%
                            </span>
                          )}
                          <span className="text-slate-400 text-[10px]">vs tgt ({kpi.target}%)</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Interactive Chart Container */}
              {reportResult.chartData.length > 0 && (
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                      <BarChart2 className="w-4 h-4 text-emerald-600" /> Visual Distribution & Benchmarks
                    </h3>
                    <span className="text-[11px] text-slate-400">Live Dynamic Series</span>
                  </div>

                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      {selectedChartType === 'pie' ? (
                        <PieChart>
                          <Pie
                            data={reportResult.chartData}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            innerRadius={45}
                            paddingAngle={3}
                            label={(entry) => `${entry.name}: ${entry.value}`}
                          >
                            {reportResult.chartData.map((_, index) => (
                              <Cell key={`cell-${index}`} fill={PALETTE[index % PALETTE.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value: any) => typeof value === 'number' ? value.toLocaleString() : value} />
                          <Legend />
                        </PieChart>
                      ) : selectedChartType === 'line' ? (
                        <LineChart data={reportResult.chartData} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                          <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                          <YAxis tick={{ fontSize: 11 }} />
                          <Tooltip />
                          <Legend />
                          {(reportResult.chartKeys || [{ dataKey: 'value', name: 'Value', color: '#10B981' }]).map((k, i) => (
                            <Line key={k.dataKey} type="monotone" dataKey={k.dataKey} name={k.name} stroke={k.color || PALETTE[i % PALETTE.length]} strokeWidth={2.5} dot={{ r: 4 }} />
                          ))}
                        </LineChart>
                      ) : selectedChartType === 'area' ? (
                        <AreaChart data={reportResult.chartData} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                          <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                          <YAxis tick={{ fontSize: 11 }} />
                          <Tooltip />
                          <Legend />
                          {(reportResult.chartKeys || [{ dataKey: 'revenue', name: 'Revenue', color: '#10B981' }]).map((k, i) => (
                            <Area key={k.dataKey} type="monotone" dataKey={k.dataKey} name={k.name} fill={k.color || PALETTE[i % PALETTE.length]} stroke={k.color || PALETTE[i % PALETTE.length]} fillOpacity={0.25} />
                          ))}
                        </AreaChart>
                      ) : (
                        <BarChart data={reportResult.chartData} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                          <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                          <YAxis tick={{ fontSize: 11 }} />
                          <Tooltip />
                          <Legend />
                          {(reportResult.chartKeys || [{ dataKey: 'value', name: 'Value', color: '#10B981' }]).map((k, i) => (
                            <Bar key={k.dataKey} dataKey={k.dataKey} name={k.name} fill={k.color || PALETTE[i % PALETTE.length]} radius={[4, 4, 0, 0]} />
                          ))}
                        </BarChart>
                      )}
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              {/* Audited Data Table */}
              <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden space-y-3">
                <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                      Detailed Portfolio Ledger & Records
                    </h3>
                    <span className="text-[11px] text-slate-400">{reportResult.tableRows.length} Rows Computed</span>
                  </div>

                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Filter rows..."
                      value={tableSearch}
                      onChange={(e) => setTableSearch(e.target.value)}
                      className="pl-7 pr-2.5 py-1 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-50/80 border-y border-slate-200 text-slate-600 font-semibold uppercase text-[10px] tracking-wider">
                        {currentDef.columns.map(col => (
                          <th 
                            key={col.key} 
                            className={`py-2.5 px-3.5 ${
                              col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : 'text-left'
                            }`}
                          >
                            {col.label}
                          </th>
                        ))}
                        <th className="py-2.5 px-3.5 text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {reportResult.tableRows.length === 0 ? (
                        <tr>
                          <td colSpan={currentDef.columns.length + 1} className="py-8 text-center text-slate-400">
                            No records matching the filter criteria.
                          </td>
                        </tr>
                      ) : (
                        reportResult.tableRows.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-50/70 transition">
                            {currentDef.columns.map(col => {
                              let val = row[col.key];
                              if (val === undefined || val === null) val = '—';

                              let formatted = String(val);
                              if (col.type === 'currency' && typeof val === 'number') {
                                formatted = `${currencySymbol} ${Math.round(val).toLocaleString()}`;
                              } else if (col.type === 'percent' && typeof val === 'number') {
                                formatted = `${val}%`;
                              } else if (col.type === 'number' && typeof val === 'number') {
                                formatted = val.toLocaleString();
                              }

                              return (
                                <td 
                                  key={col.key} 
                                  className={`py-2.5 px-3.5 ${
                                    col.align === 'right' ? 'text-right font-medium' : col.align === 'center' ? 'text-center' : 'text-left'
                                  }`}
                                >
                                  {col.key === 'complianceStatus' || col.key === 'rainfallTriggerStatus' || col.key === 'payoutStatus' ? (
                                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                                      String(val).toLowerCase().includes('compliant') || String(val).toLowerCase().includes('approved') || String(val).toLowerCase().includes('cleared')
                                        ? 'bg-emerald-100 text-emerald-800'
                                        : String(val).toLowerCase().includes('dry') || String(val).toLowerCase().includes('pending')
                                        ? 'bg-amber-100 text-amber-800'
                                        : 'bg-slate-100 text-slate-700'
                                    }`}>
                                      {formatted}
                                    </span>
                                  ) : (
                                    formatted
                                  )}
                                </td>
                              );
                            })}
                            <td className="py-2.5 px-3.5 text-center">
                              <button
                                onClick={() => setSelectedRowDetail(row)}
                                className="p-1 text-slate-400 hover:text-emerald-600 transition"
                                title="Inspect item breakdown"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Executive Insights & Audit Summary Box */}
              {reportResult.summaryCallouts && reportResult.summaryCallouts.length > 0 && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 uppercase tracking-wider">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Executive Findings & Key Takeaways
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-600">
                    {reportResult.summaryCallouts.map((c, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-emerald-500 font-bold">•</span>
                        <span>{c}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}

          {/* Supplier Purchased Reports Audit Ledger */}
          {isSupplierUser && Object.keys(purchasedReports).length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b pb-2">
                <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 font-mono">
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                  <span>Your Unlocked Reports & Lipila Payment History</span>
                </h4>
                <span className="text-[10px] text-slate-400 font-mono font-bold">
                  {Object.keys(purchasedReports).length} Purchased
                </span>
              </div>
              <div className="divide-y divide-slate-100 text-xs">
                {Object.values(purchasedReports).map((pr: any) => (
                  <div key={pr.reportId} className="py-2.5 flex items-center justify-between gap-4">
                    <div>
                      <strong className="text-slate-900 block font-semibold">{pr.reportTitle}</strong>
                      <span className="text-[10px] text-slate-400 font-mono">
                        Ref: {pr.referenceId} • Purchased: {new Date(pr.purchasedAt).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="font-mono font-extrabold text-emerald-700 block">
                        {currencySymbol} {Number(pr.amountZMW || supplierFeeRate).toFixed(2)}
                      </span>
                      <span className="text-[9px] bg-emerald-100 text-emerald-800 font-black px-1.5 py-0.5 rounded">
                        PAID VIA LIPILA
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      )}

      {/* Row Drilldown Modal */}
      {selectedRowDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-sm">Detailed Record Inspection</h3>
              </div>
              <button
                onClick={() => setSelectedRowDetail(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto pr-1 text-xs divide-y divide-slate-100">
              {Object.entries(selectedRowDetail).map(([k, v]) => (
                <div key={k} className="flex items-center justify-between py-1.5">
                  <span className="font-medium text-slate-500 capitalize">{k.replace(/([A-Z])/g, ' $1')}</span>
                  <span className="font-semibold text-slate-800 text-right">{typeof v === 'object' ? JSON.stringify(v) : String(v)}</span>
                </div>
              ))}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedRowDetail(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Supplier Report Unlock Lipila Payment Modal */}
      {showUnlockModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-5">
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  💳
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">Unlock Supplier Report</h3>
                  <p className="text-[10px] text-slate-500 font-mono">Lipila API Payment Gateway</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowUnlockModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-1.5">
              <span className="text-[10px] uppercase font-bold text-slate-400">Target Report</span>
              <h4 className="text-xs font-extrabold text-slate-900">{currentDef.title}</h4>
              <p className="text-[11px] text-slate-500">{currentDef.description}</p>
              <div className="flex justify-between items-center pt-2 border-t border-slate-200 mt-2 font-mono">
                <span className="text-xs text-slate-600 font-bold">Total Access Fee:</span>
                <span className="text-sm font-black text-emerald-700">{currencySymbol} {supplierFeeRate.toFixed(2)}</span>
              </div>
            </div>

            <form onSubmit={handleUnlockPayment} className="space-y-4">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1.5">Payment Method</label>
                <div className="grid grid-cols-2 gap-2">
                  {(["Airtel Money", "MTN Money", "Zamtel Kwacha", "Visa / Mastercard 3DS"] as const).map(pm => (
                    <button
                      key={pm}
                      type="button"
                      onClick={() => setPaymentProvider(pm)}
                      className={`p-2.5 rounded-xl border text-[11px] font-bold text-left transition flex items-center justify-between cursor-pointer ${
                        paymentProvider === pm 
                          ? "border-emerald-600 bg-emerald-50 text-emerald-900 ring-1 ring-emerald-600" 
                          : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                      }`}
                    >
                      <span>{pm}</span>
                      {paymentProvider === pm && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  {paymentProvider.includes("Visa") ? "Cardholder Phone / Account" : "Mobile Money Number"}
                </label>
                <input
                  type="text"
                  value={payPhone}
                  onChange={e => setPayPhone(e.target.value)}
                  placeholder="e.g. 0977 123456"
                  required
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold focus:outline-emerald-600"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowUnlockModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isProcessingPayment || !payPhone.trim()}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-black rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isProcessingPayment ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Authorizing...</span>
                    </>
                  ) : (
                    <span>Pay {currencySymbol} {supplierFeeRate.toFixed(2)}</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

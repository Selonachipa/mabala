import React from "react";
import AccountsPanel from "../AccountsPanel";
import ExpensesPanel from "../ExpensesPanel";
import CropsPanel from "../CropsPanel";
import OrchardPanel from "../OrchardPanel";
import PayrollPanel from "../PayrollPanel";
import InvoicesPanel from "../InvoicesPanel";
import InventoryPanel from "../InventoryPanel";
import EnterpriseLivestockManager from "../livestock/EnterpriseLivestockManager";
import VeterinaryWorkspace from "../veterinary/VeterinaryWorkspace";
import PoultryManager from "../poultry/PoultryManager";
import AquaculturePanel from "../AquaculturePanel";
import ReportsPanel from "../ReportsPanel";
import { FarmIntelligenceDashboard } from "../fbi/FarmIntelligenceDashboard";
import AccessControlPanel from "../AccessControlPanel";
import ProfilesPlatformPanel from "../ProfilesPlatformPanel";
import SuperAdminResellerHub from "../reseller/SuperAdminResellerHub";
import BillingCentrePanel from "../BillingCentrePanel";
import FarmerWalletPanel from "../FarmerWalletPanel";
import LipilaPaymentTrackerPanel from "../LipilaPaymentTrackerPanel";
import PartnerReferralPortal from "../PartnerReferralPortal";
import InstitutionPortal from "../InstitutionPortal";
import BackupRestorePanel from "../BackupRestorePanel";
import OfflineSyncPanel from "../OfflineSyncPanel";
import FinancePanel from "../FinancePanel";
import AssetRegisterPanel from "../AssetRegisterPanel";
import AuditArchivePanel from "../AuditArchivePanel";
import CsvImportPanel from "../CsvImportPanel";
import MarketplacePanel from "../MarketplacePanel";
import OfftakerPanel from "../offtaker/OfftakerPanel";
import HswDashboardPanel from "../hsw/HswDashboardPanel";
import AgroDealerConsignmentPanel from "../AgroDealerConsignmentPanel";
import { VendorBoostPanel } from "../agronomy/VendorBoostPanel";
import { AgroGuidanceAdminPanel } from "../agronomy/AgroGuidanceAdminPanel";
import AdvisoryServicesPanel from "../agronomy/AdvisoryServicesPanel";
import { FarmerCreditHub } from "../agc/FarmerCreditHub";
import { DealerCreditPOS } from "../agc/DealerCreditPOS";
import { FinancierPortal } from "../agc/FinancierPortal";
import { InsurerPortal } from "../agc/InsurerPortal";
import { SuperAdminAgcPanel } from "../agc/SuperAdminAgcPanel";
import { LoanManagementHub } from "../loans/LoanManagementHub";
import { SmsCommunicationsHub } from "../SmsCommunicationsHub";
import { FarmUserSettingsPanel } from "../FarmUserSettingsPanel";
import AccessDeniedPanel from "../common/AccessDeniedPanel";
import DashboardOverviewTab from "../dashboard/DashboardOverviewTab";
import { 
  Farm, 
  Account, 
  ExpenseTransaction, 
  CropCycle, 
  Employee, 
  Payslip, 
  Invoice, 
  Quotation, 
  CreditNote, 
  Customer, 
  Supplier, 
  InventoryItem, 
  LivestockRecord, 
  PoultryBatch, 
  FishBatch, 
  Asset, 
  Investment, 
  Loan, 
  OtherRevenue, 
  LeaveRecord, 
  EmployeeAdvance, 
  ArchiveRecord, 
  AuditLog, 
  CashSale, 
  PredefinedRole, 
  RolePermissionsMap, 
  UserMember, 
  BackupData, 
    OrchardTree, 
  OrchardNurseryBatch, 
  OrchardActivity 
} from "../../types";

export interface AppModuleRendererProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  hasReadPermission: (moduleId: string) => boolean;
  hasWritePermission: (moduleId: string) => boolean;
  isReadonly: boolean;
  currencySymbol: string;
  isZambia: boolean;
  currentRole: PredefinedRole;
  userEmail: string;
  tenantId: string;
  adminClaimed: boolean;
  adminClaimantEmail: string;
  userProfile: any;
  setUserProfile: React.Dispatch<React.SetStateAction<any>>;
  activeFarm: Farm;
  setActiveFarm: (farm: Farm) => void;
  farms: Farm[];
  setFarms: React.Dispatch<React.SetStateAction<Farm[]>>;
  displayedAccounts: Account[];
  setAccounts: React.Dispatch<React.SetStateAction<Account[]>>;
  expenses: ExpenseTransaction[];
  crops: CropCycle[];
  setCrops: React.Dispatch<React.SetStateAction<CropCycle[]>>;
  employees: Employee[];
  payslips: Payslip[];
  invoices: Invoice[];
  setInvoices: React.Dispatch<React.SetStateAction<Invoice[]>>;
  quotations: Quotation[];
  creditNotes: CreditNote[];
  customers: Customer[];
  suppliers: Supplier[];
  inventory: InventoryItem[];
  setInventory: React.Dispatch<React.SetStateAction<InventoryItem[]>>;
  livestock: LivestockRecord[];
  poultryBatches: PoultryBatch[];
  fishBatches: FishBatch[];
  assets: Asset[];
  investments: Investment[];
  loans: Loan[];
  otherRevenues: OtherRevenue[];
  leaveRecords: LeaveRecord[];
  employeeAdvances: EmployeeAdvance[];
  auditLogs: AuditLog[];
  archiveRecords: ArchiveRecord[];
  cashSales: CashSale[];
  setCashSales: React.Dispatch<React.SetStateAction<CashSale[]>>;
  tasks: any[];
  credits: number;
  setCredits: React.Dispatch<React.SetStateAction<number>>;
  smsCredits: number;
  setSmsCredits: React.Dispatch<React.SetStateAction<number>>;
  subscriptionTier: string;
  setSubscriptionTier: (tier: string) => void;
  weatherAlerts: any[];
  vendors: any[];
  setVendors: React.Dispatch<React.SetStateAction<any[]>>;
  marketplaceProducts: any[];
  setMarketplaceProducts: React.Dispatch<React.SetStateAction<any[]>>;
  riders: any[];
  setRiders: React.Dispatch<React.SetStateAction<any[]>>;
  marketplaceOrders: any[];
  setMarketplaceOrders: React.Dispatch<React.SetStateAction<any[]>>;
  commissionPercent: number;
  setCommissionPercent: (val: number) => void;
  deliveryFeePerKm: number;
  setDeliveryFeePerKm: (val: number) => void;
  platformPackages: any[];
  setPlatformPackages: React.Dispatch<React.SetStateAction<any[]>>;
  orchardTrees: OrchardTree[];
  setOrchardTrees: React.Dispatch<React.SetStateAction<OrchardTree[]>>;
  orchardNurseryBatches: OrchardNurseryBatch[];
  setOrchardNurseryBatches: React.Dispatch<React.SetStateAction<OrchardNurseryBatch[]>>;
  orchardActivities: OrchardActivity[];
  setOrchardActivities: React.Dispatch<React.SetStateAction<OrchardActivity[]>>;
  permissions: RolePermissionsMap;
  teamMembers: UserMember[];
  selectedCountry: any;
  setSelectedCountry: (country: any) => void;
  csvPreselectedModule: "expenses" | "crops" | "livestock" | null;
  lipilaTransactions: any[];
  creditLedger?: any[];
  isSuperAdmin: boolean;
  isSuperAdminSession: boolean;
  isOnline: boolean;
  workspaceMode: string;
  setLipilaCheckout?: React.Dispatch<React.SetStateAction<any>>;
  // Action Handlers
  handleAddAccount: (acc: Account) => void;
  handleAddExpense: (tx: ExpenseTransaction) => void;
  handleAddSupplier: (sup: Supplier) => void;
  handleAddCrop: (crop: CropCycle) => void;
  handleEditCrop: (crop: CropCycle, auditDetails?: string) => void;
  handleUpdateMilestone: (cropId: string, milestoneId: string, isCompleted: boolean) => void;
  handleUpdateCropStatus: (cropId: string, status: CropCycle["status"]) => void;
  handleDeleteCrop: (id: string) => void;
  handleAddEmployee: (emp: Employee) => void;
  handleBulkAddEmployees: (emps: Employee[]) => void;
  handleUpdateEmployee: (emp: Employee) => void;
  handleDeleteEmployee: (id: string) => void;
  handleRunPayroll: (slips: Payslip[]) => void;
  handleAddLeaveRecord: (leave: Omit<LeaveRecord, "id" | "farmId">) => void;
  handleArchiveLeaveRecord: (leaveId: string) => void;
  handleAddEmployeeAdvance: (adv: Omit<EmployeeAdvance, "id" | "farmId">) => void;
  handleRepayEmployeeAdvance: (id: string, amount: number) => void;
  handleArchiveEmployeeAdvance: (advId: string) => void;
  handleAddInvoice: (inv: Invoice) => void;
  handleAddCreditNote: (cn: CreditNote) => void;
  handleAddQuotation: (qt: Quotation) => void;
  handleMarkPaid: (id: string, paymentAmount?: number) => void;
  handleConvertQuote: (quote: Quotation) => void;
  handleAddCustomer: (cus: Customer) => void;
  handleAddLivestockRecord: (record: LivestockRecord) => void;
  handleUpdateLivestock: (record: LivestockRecord) => void;
  handleDeleteLivestockRecord: (id: string, reason?: string, deletedBy?: string) => void;
  handleAddLivestockHealthEvent: (tagId: string, event: { date: string; type: string; details: string; cost: number }) => void;
  handleAddLivestockFeedingLog: (tagId: string, log: { date: string; feedType: string; quantityKg: number }) => void;
  handleAddPoultry: (batch: PoultryBatch) => void;
  handleUpdatePoultryBatch: (batch: PoultryBatch) => void;
  handleDeletePoultryBatch: (id: string) => void;
  handleAddFishBatch: (batch: FishBatch) => void;
  handleAddWaterReading: (batchId: string, reading: any) => void;
  handleAddAsset: (asset: any) => void;
  handleUpdateAsset: (asset: any) => void;
  handleUpdateAssets: (assets: any[]) => void;
  handleArchiveAsset: (id: string) => void;
  handleAddInvestment: (inv: any) => void;
  handleRealizeInvestment: (id: string) => void;
  handleArchiveInvestment: (id: string) => void;
  handleAddLoan: (loan: any) => void;
  handleAddLoanRepayment: (loanId: string, amount: number, paymentMethod: string, notes?: string) => void;
  handleOffsetLoan: (loanId: string, otherRevenueId: string, amount: number, offsetType: string) => void;
  handleDeleteLoan: (id: string) => void;
  handleAddOtherRevenue: (rev: any) => void;
  handleArchiveOtherRevenue: (id: string) => void;
  handleRestoreRecordFromArchive: (recordId: string) => void;
  handlePermanentDeleteFromArchive: (recordId: string) => void;
  handleClearAuditLogs: () => void;
  handleUpdatePermission: (role: PredefinedRole, moduleId: string, type: "read" | "write", value: boolean) => void;
  handleAddTeamMember: (member: Omit<UserMember, "id" | "lastActive">) => void;
  handleRemoveTeamMember: (id: string) => void;
  handleChangeMemberRole: (id: string, role: PredefinedRole) => void;
  handleToggleUserSuspension: (email: string, suspend: boolean, reason?: string) => Promise<void> | void;
  handleUpdateTeamMember: (email: string, updates: Partial<UserMember>) => Promise<void> | void;
  handleChangeOwnPassword: (pwd: string) => Promise<boolean>;
  handleSessionRoleChange: (role: PredefinedRole) => void;
  handleRestoreBackup: (data: BackupData) => void;
  handleClearDatabase: () => void;
  handleSaveCloudWorkspace: (uid: string) => Promise<void>;
  handleStartImpersonation: (uid: string, email: string) => Promise<void>;
  handleLogout: () => Promise<void>;
  handleGotoCsvImport: (type: "expenses" | "crops" | "livestock") => void;
  handleUpdateActiveFarm: (updatedFields: Partial<any>) => void;
  handleAddTask: (taskData: any) => void;
  handleEditTask: (task: any) => void;
  handleDeleteTask: (id: string) => void;
  handleToggleTaskComplete: (id: string) => void;
  handlePostVeterinaryServiceCharge: (type: any, amount: number, client: string, details: string) => void;
  handleAddLedgerEntryFromOfftaker: (date: string, desc: string, debit: string, credit: string, amount: number, module: string) => void;
  showToast: (msg: string, type?: "success" | "error" | "info" | "warning") => void;
  writeAuditLog: (action: string, module: string, target: string, details: string) => void;
  addNotification: (msg: string, type: "success" | "warning" | "info" | "error") => void;
  setShowTopUpModal: (show: boolean) => void;
  setShowNewSaleModal: (show: boolean) => void;
  setShowQuickLogLossModal: (show: boolean) => void;
}

export const AppModuleRenderer: React.FC<AppModuleRendererProps> = (props) => {
  const {
    activeTab,
    setActiveTab,
    hasReadPermission,
    hasWritePermission,
    isReadonly,
    currencySymbol,
    isZambia,
    currentRole,
    userEmail,
    tenantId,
    adminClaimed,
    adminClaimantEmail,
    userProfile,
    setUserProfile,
    activeFarm,
    setActiveFarm,
    farms,
    setFarms,
    displayedAccounts,
    setAccounts,
    expenses,
    crops,
    setCrops,
    employees,
    payslips,
    invoices,
    setInvoices,
    quotations,
    creditNotes,
    customers,
    suppliers,
    inventory,
    setInventory,
    livestock,
    poultryBatches,
    fishBatches,
    assets,
    investments,
    loans,
    otherRevenues,
    leaveRecords,
    employeeAdvances,
    auditLogs,
    archiveRecords,
    cashSales,
    setCashSales,
    tasks,
    credits,
    setCredits,
    smsCredits,
    setSmsCredits,
    subscriptionTier,
    setSubscriptionTier,
    weatherAlerts,
    vendors,
    setVendors,
    marketplaceProducts,
    setMarketplaceProducts,
    riders,
    setRiders,
    marketplaceOrders,
    setMarketplaceOrders,
    commissionPercent,
    setCommissionPercent,
    deliveryFeePerKm,
    setDeliveryFeePerKm,
    platformPackages,
    setPlatformPackages,
    orchardTrees,
    setOrchardTrees,
    orchardNurseryBatches,
    setOrchardNurseryBatches,
    orchardActivities,
    setOrchardActivities,
    permissions,
    teamMembers,
    selectedCountry,
    setSelectedCountry,
    csvPreselectedModule,
    lipilaTransactions,
    creditLedger = [],
    isSuperAdmin,
    isOnline,
    workspaceMode,
    setLipilaCheckout,
    handleAddAccount,
    handleAddExpense,
    handleAddSupplier,
    handleAddCrop,
    handleEditCrop,
    handleUpdateMilestone,
    handleUpdateCropStatus,
    handleDeleteCrop,
    handleAddEmployee,
    handleBulkAddEmployees,
    handleUpdateEmployee,
    handleDeleteEmployee,
    handleRunPayroll,
    handleAddLeaveRecord,
    handleArchiveLeaveRecord,
    handleAddEmployeeAdvance,
    handleRepayEmployeeAdvance,
    handleArchiveEmployeeAdvance,
    handleAddInvoice,
    handleAddCreditNote,
    handleAddQuotation,
    handleMarkPaid,
    handleConvertQuote,
    handleAddCustomer,
    handleAddLivestockRecord,
    handleUpdateLivestock,
    handleDeleteLivestockRecord,
    handleAddLivestockHealthEvent,
    handleAddLivestockFeedingLog,
    handleAddPoultry,
    handleUpdatePoultryBatch,
    handleDeletePoultryBatch,
    handleAddFishBatch,
    handleAddWaterReading,
    handleAddAsset,
    handleUpdateAsset,
    handleUpdateAssets,
    handleArchiveAsset,
    handleAddInvestment,
    handleRealizeInvestment,
    handleArchiveInvestment,
    handleAddLoan,
    handleAddLoanRepayment,
    handleOffsetLoan,
    handleDeleteLoan,
    handleAddOtherRevenue,
    handleArchiveOtherRevenue,
    handleRestoreRecordFromArchive,
    handlePermanentDeleteFromArchive,
    handleClearAuditLogs,
    handleUpdatePermission,
    handleAddTeamMember,
    handleRemoveTeamMember,
    handleChangeMemberRole,
    handleToggleUserSuspension,
    handleUpdateTeamMember,
    handleChangeOwnPassword,
    handleSessionRoleChange,
    handleRestoreBackup,
    handleClearDatabase,
    handleSaveCloudWorkspace,
    handleStartImpersonation,
    handleLogout,
    handleGotoCsvImport,
    handleUpdateActiveFarm,
    handleAddTask,
    handleEditTask,
    handleDeleteTask,
    handleToggleTaskComplete,
    handlePostVeterinaryServiceCharge,
    handleAddLedgerEntryFromOfftaker,
    showToast,
    writeAuditLog,
    addNotification,
    setShowTopUpModal,
    setShowNewSaleModal,
    setShowQuickLogLossModal
  } = props;

  const renderAccessDenied = (name: string) => (
    <AccessDeniedPanel
      moduleName={name}
      currentRole={currentRole}
      adminClaimed={adminClaimed}
      adminClaimantEmail={adminClaimantEmail}
      userEmail={userEmail}
      onNavigateDashboard={() => setActiveTab("dashboard")}
      onElevateToAdmin={() => handleSessionRoleChange("Platform Administrator")}
    />
  );

  // 1. Dashboard Tab
  if (activeTab === "dashboard") {
    return (
      <DashboardOverviewTab
        weatherAlerts={weatherAlerts}
        activeFarm={activeFarm}
        currencySymbol={currencySymbol}
        crops={crops}
        expenses={expenses}
        invoices={invoices}
        cashSales={cashSales}
        livestock={livestock}
        poultryBatches={poultryBatches}
        fishBatches={fishBatches}
        credits={credits}
        smsCredits={smsCredits}
        subscriptionTier={subscriptionTier}
        userProfile={userProfile}
        setActiveTab={setActiveTab}
        isReadonly={isReadonly}
        tasks={tasks}
        onAddTask={handleAddTask}
        onEditTask={handleEditTask}
        onDeleteTask={handleDeleteTask}
        onToggleTaskComplete={handleToggleTaskComplete}
        onTopUpCredits={() => setShowTopUpModal(true)}
        hasReadPermission={hasReadPermission}
        hasWritePermission={hasWritePermission}
        onQuickLogLoss={() => setShowQuickLogLossModal(true)}
        setIsSaleModalOpen={setShowNewSaleModal}
        currentRole={currentRole}
        farms={farms}
        displayedAccounts={displayedAccounts}
        isSuperAdmin={isSuperAdmin}
        onNavigateToModule={setActiveTab}
      />
    );
  }

  // 2. Chart of Accounts
  if (activeTab === "accounts") {
    if (!hasReadPermission("accounts")) return renderAccessDenied("Chart of Accounts");
    return (
      <AccountsPanel
        accounts={displayedAccounts}
        onAddAccount={handleAddAccount}
        isReadonly={isReadonly || !hasWritePermission("accounts")}
        currencySymbol={currencySymbol}
      />
    );
  }

  // 3. Expenses
  if (activeTab === "expenses") {
    if (!hasReadPermission("expenses")) return renderAccessDenied("Expenses Ledger");
    return (
      <ExpensesPanel
        expenses={expenses}
        suppliers={suppliers}
        crops={crops}
        poultryBatches={poultryBatches}
        livestock={livestock}
        fishBatches={fishBatches}
        activeFarm={activeFarm}
        onAddTransaction={handleAddExpense}
        onAddSupplier={handleAddSupplier}
        isReadonly={isReadonly || !hasWritePermission("expenses")}
        currencySymbol={currencySymbol}
        onGotoCsvImport={handleGotoCsvImport}
      />
    );
  }

  // 4. Crops
  if (activeTab === "crops") {
    if (!hasReadPermission("crops")) return renderAccessDenied("Crop Cycles & Agronomy");
    return (
      <CropsPanel
        crops={crops}
        onAddCrop={handleAddCrop}
        onEditCrop={handleEditCrop}
        onUpdateMilestone={handleUpdateMilestone}
        onUpdateStatus={handleUpdateCropStatus}
        onDeleteCrop={handleDeleteCrop}
        isReadonly={isReadonly || !hasWritePermission("crops")}
        currencySymbol={currencySymbol}
        onGotoCsvImport={handleGotoCsvImport}
        tenantId={tenantId}
        userRole={currentRole}
        onNavigateToAdvisory={() => setActiveTab("advisory-portal")}
        onNavigateToMarketplace={() => setActiveTab("marketplace")}
        onTopUpCredits={() => setShowTopUpModal(true)}
        onActivateSubscription={() => setActiveTab("billing-centre")}
      />
    );
  }

  // 5. Orchard Management
  if (activeTab === "orchard-dashboard") {
    if (!hasReadPermission("crops")) return renderAccessDenied("Orchard Management");
    return (
      <OrchardPanel
        crops={crops}
        setCrops={setCrops}
        orchardNurseryBatches={orchardNurseryBatches}
        setOrchardNurseryBatches={setOrchardNurseryBatches}
        orchardTrees={orchardTrees}
        setOrchardTrees={setOrchardTrees}
        orchardActivities={orchardActivities}
        setOrchardActivities={setOrchardActivities}
        accounts={displayedAccounts}
        setAccounts={setAccounts}
        expenses={expenses}
        setExpenses={() => {}}
        credits={credits}
        setCredits={setCredits}
        isReadonly={isReadonly || !hasWritePermission("crops")}
        currencySymbol={currencySymbol}
        employees={employees}
        payslips={payslips}
        invoices={invoices}
        setInvoices={setInvoices}
        cashSales={cashSales}
        setCashSales={setCashSales}
        onSaveCloud={() => handleSaveCloudWorkspace(tenantId)}
        showToast={showToast}
        activeFarm={activeFarm}
        userProfile={userProfile}
      />
    );
  }

  // 6. Vendor Boost
  if (activeTab === "agrodealer-boost") {
    return (
      <VendorBoostPanel
        currencySymbol={currencySymbol}
        userRole={currentRole}
        activeFarmName={activeFarm?.name}
      />
    );
  }

  // 7. Agronomy Admin
  if (activeTab === "agronomy-admin") {
    return (
      <AgroGuidanceAdminPanel
        currencySymbol={currencySymbol}
        userRole={currentRole}
        activeFarmName={activeFarm?.name}
      />
    );
  }

  // 8. Advisory Portal
  if (activeTab === "advisory-portal") {
    return (
      <AdvisoryServicesPanel
        currencySymbol={currencySymbol}
        userRole={currentRole}
        activeFarmName={activeFarm?.name}
      />
    );
  }

  // 9. Payroll & Employees
  if (activeTab === "payroll") {
    if (!hasReadPermission("payroll")) return renderAccessDenied("Employees & Payroll");
    return (
      <PayrollPanel
        employees={employees}
        payslips={payslips}
        onAddEmployee={handleAddEmployee}
        onBulkAddEmployees={handleBulkAddEmployees}
        onUpdateEmployee={handleUpdateEmployee}
        onDeleteEmployee={handleDeleteEmployee}
        onRunPayroll={handleRunPayroll}
        isReadonly={isReadonly || !hasWritePermission("payroll")}
        currencySymbol={currencySymbol}
        isZambia={isZambia}
        activeFarm={activeFarm}
        leaveRecords={leaveRecords}
        onAddLeaveRecord={handleAddLeaveRecord}
        onDeleteLeaveRecord={handleArchiveLeaveRecord}
        employeeAdvances={employeeAdvances}
        onAddEmployeeAdvance={handleAddEmployeeAdvance}
        onRepayEmployeeAdvance={handleRepayEmployeeAdvance}
        onDeleteEmployeeAdvance={handleArchiveEmployeeAdvance}
      />
    );
  }

  // 10. Invoices & Sales
  if (activeTab === "invoices" || activeTab === "sales") {
    if (!hasReadPermission("sales") && !hasReadPermission("invoices")) return renderAccessDenied("Invoices & Sales");
    return (
      <InvoicesPanel
        invoices={invoices}
        creditNotes={creditNotes}
        quotations={quotations}
        customers={customers}
        crops={crops}
        livestock={livestock}
        poultryBatches={poultryBatches}
        farms={farms}
        onAddInvoice={handleAddInvoice}
        onAddCreditNote={handleAddCreditNote}
        onAddQuotation={handleAddQuotation}
        onMarkPaid={handleMarkPaid}
        onConvertQuote={handleConvertQuote}
        onAddCustomer={handleAddCustomer}
        isReadonly={isReadonly || (!hasWritePermission("sales") && !hasWritePermission("invoices"))}
        currencySymbol={currencySymbol}
        activeFarm={activeFarm}
        onNavigateToOfftaker={() => setActiveTab("offtaker-marketplace")}
        userRole={currentRole}
        userProfile={userProfile}
      />
    );
  }

  // 11. Inventory Stockroom
  if (activeTab === "inventory") {
    if (!hasReadPermission("inventory")) return renderAccessDenied("Inventory Stockroom");
    return (
      <InventoryPanel
        inventory={inventory}
        setInventory={setInventory}
        currencySymbol={currencySymbol}
        activeFarm={activeFarm}
        isReadonly={isReadonly || !hasWritePermission("inventory")}
        writeAuditLog={writeAuditLog}
      />
    );
  }

  // 12. Livestock Registry
  if (activeTab === "livestock" || activeTab === "livestock-registry") {
    if (!hasReadPermission("livestock")) return renderAccessDenied("Livestock Registry");
    return (
      <EnterpriseLivestockManager
        records={livestock}
        currencySymbol={currencySymbol}
        onAddLivestockRecord={handleAddLivestockRecord}
        onAddLivestockHealthEvent={handleAddLivestockHealthEvent}
        onAddLivestockFeedingLog={handleAddLivestockFeedingLog}
        isReadonly={isReadonly || !hasWritePermission("livestock")}
        accounts={displayedAccounts}
        setAccounts={setAccounts}
        customers={customers}
        invoices={invoices}
        onAddInvoice={handleAddInvoice}
        onMarkPaid={handleMarkPaid}
        onDeleteLivestockRecord={handleDeleteLivestockRecord}
        activeFarm={activeFarm}
        employees={employees}
        currentUserRole={currentRole}
        isSuperAdmin={isSuperAdmin}
        userProfile={userProfile}
        suppliers={suppliers}
        onAddSupplier={handleAddSupplier}
      />
    );
  }

  // 13. Veterinary Workspace
  if (activeTab === "veterinary") {
    return (
      <VeterinaryWorkspace
        onAddAuditLog={writeAuditLog}
        currencySymbol={currencySymbol}
        onPostVeterinaryTransaction={handlePostVeterinaryServiceCharge}
        accounts={displayedAccounts}
      />
    );
  }

  // 14. Poultry Manager
  if (activeTab === "poultry" || activeTab === "poultry-group") {
    if (!hasReadPermission("livestock")) return renderAccessDenied("Poultry Flock Manager");
    return (
      <PoultryManager
        batches={poultryBatches}
        currencySymbol={currencySymbol}
        onAddBatch={handleAddPoultry}
        onUpdateBatch={handleUpdatePoultryBatch}
        onDeleteBatch={handleDeletePoultryBatch}
        accounts={displayedAccounts}
        setAccounts={setAccounts}
        onAddExpense={handleAddExpense}
        onAddSupplier={handleAddSupplier}
        suppliers={suppliers}
        expenses={expenses}
        writeAuditLog={writeAuditLog}
        activeFarm={activeFarm}
        employees={employees}
        weatherAlerts={weatherAlerts}
        isReadonly={isReadonly || !hasWritePermission("livestock")}
      />
    );
  }

  // 15. Aquaculture Systems
  if (activeTab === "aquaculture") {
    if (!hasReadPermission("livestock")) return renderAccessDenied("Aquaculture Systems");
    return (
      <AquaculturePanel
        batches={fishBatches}
        onAddFishBatch={handleAddFishBatch}
        onAddWaterReading={handleAddWaterReading}
        isReadonly={isReadonly || !hasWritePermission("livestock")}
        currencySymbol={currencySymbol}
      />
    );
  }

  // 16. Reports Centre
  if (activeTab === "reports" || activeTab === "reports-group") {
    if (!hasReadPermission("reports")) return renderAccessDenied("Financial & Biological Reports");
    return (
      <ReportsPanel
        accounts={displayedAccounts}
        isZambia={isZambia}
        currencySymbol={currencySymbol}
        expenses={expenses}
        cashSales={cashSales}
        invoices={invoices}
        crops={crops}
        poultry={poultryBatches}
        livestock={livestock}
        activeFarm={activeFarm}
        subscriptionTier={subscriptionTier}
        tasks={tasks}
        isSuperAdmin={isSuperAdmin}
        farms={farms}
        lipilaTransactions={lipilaTransactions}
      />
    );
  }

  // 17. Farm Intelligence Dashboard (FBI)
  if (activeTab === "fbi" || activeTab === "fbi-group" || activeTab === "farm-intelligence") {
    return (
      <FarmIntelligenceDashboard
        farms={farms}
        activeFarm={activeFarm}
        tenantId={tenantId}
        userRole={currentRole}
        isSuperAdmin={isSuperAdmin}
        sales={cashSales}
        invoices={invoices}
        otherRevenues={otherRevenues}
        expenses={expenses}
        crops={crops}
        livestock={livestock}
        poultry={poultryBatches}
        fishBatches={fishBatches}
        employees={employees}
        payslips={payslips}
        inventory={inventory}
        assets={assets}
        investments={investments}
        loans={loans}
        tasks={tasks}
        customers={customers}
        suppliers={suppliers}
        creditBalance={credits}
      />
    );
  }

  // 18. Access Control & Team Permissions
  if (activeTab === "permissions" || activeTab === "access-control") {
    return (
      <AccessControlPanel
        currentRole={currentRole}
        onChangeSessionRole={handleSessionRoleChange}
        permissions={permissions}
        onUpdatePermission={handleUpdatePermission}
        teamMembers={teamMembers}
        onAddTeamMember={handleAddTeamMember}
        onRemoveTeamMember={handleRemoveTeamMember}
        onChangeMemberRole={handleChangeMemberRole}
        onToggleUserSuspension={handleToggleUserSuspension}
        onUpdateTeamMember={handleUpdateTeamMember}
        onChangeOwnPassword={handleChangeOwnPassword}
        currencySymbol={currencySymbol}
        adminClaimed={adminClaimed}
        userEmail={userEmail}
        activeFarmName={activeFarm?.name || "Mabala Farm"}
        adminClaimantEmail={adminClaimantEmail}
        farms={farms}
        subscriptionTier={subscriptionTier}
        auditLogs={auditLogs}
        tenantId={tenantId}
      />
    );
  }

  // 19. Super Admin Resellers Hub
  if (activeTab === "resellers" || activeTab === "reseller-hub") {
    return (
      <SuperAdminResellerHub
        adminProfile={userProfile}
        currencySymbol={currencySymbol}
      />
    );
  }

  // 20. Super Admin Platform Admin
  if (activeTab === "platform-admin") {
    return (
      <ProfilesPlatformPanel
        userProfile={userProfile}
        onStartImpersonation={handleStartImpersonation}
      />
    );
  }

  // 21. Billing Centre
  if (activeTab === "billing-centre") {
    return (
      <BillingCentrePanel
        isReadonly={isReadonly}
        credits={credits}
        smsCredits={smsCredits}
        subscriptionTier={subscriptionTier}
        userProfile={userProfile}
        activeFarm={activeFarm}
        onUpdateActiveFarm={handleUpdateActiveFarm}
        setCredits={setCredits}
        setSmsCredits={setSmsCredits}
        setSubscriptionTier={setSubscriptionTier}
        setLipilaCheckout={setLipilaCheckout}
      />
    );
  }

  // 22. Farmer Wallet
  if (activeTab === "farmer-wallet") {
    return (
      <FarmerWalletPanel
        tenantId={tenantId}
        tenantName={activeFarm?.name || "Farm Operations"}
        currencySymbol={currencySymbol}
        userEmail={userEmail}
        userId={userProfile?.uid || userEmail}
        isSuperAdmin={isSuperAdmin}
        onNavigateToModule={setActiveTab}
      />
    );
  }

  // 22b. Mabala Unified Loan Management Module (Agricultural & Enterprise Financing)
  if (activeTab === "loans-hub" || activeTab === "loan-management" || activeTab === "loans") {
    return (
      <LoanManagementHub
        currentTenantId={tenantId}
        currentUser={{
          uid: userProfile?.uid || userEmail,
          displayName: userProfile?.displayName || activeFarm?.name || "Farmer",
          email: userEmail,
          phoneNumber: userProfile?.phoneNumber,
          role: currentRole
        }}
        workspaceMode={props.workspaceMode}
        cropCycles={crops?.map(c => ({
          id: c.id,
          cropName: c.cropType || c.name || "Crop",
          stage: c.stage || "Growing",
          expectedHarvestDate: c.expectedHarvestDate
        }))}
      />
    );
  }

  // 23. Lipila Payment Tracker
  if (activeTab === "lipila-payment-tracker") {
    return <LipilaPaymentTrackerPanel />;
  }

  // 24. Partner Referral Portal
  if (activeTab === "partner-portal") {
    return (
      <PartnerReferralPortal
        userProfile={userProfile}
        onLogout={handleLogout}
      />
    );
  }

  // 25. Institution Portal
  if (activeTab === "institution-portal") {
    return (
      <InstitutionPortal
        userProfile={userProfile}
        onLogout={handleLogout}
      />
    );
  }

  // 26. Data Backup & Restore
  if (activeTab === "backup-restore") {
    return (
      <BackupRestorePanel
        farms={farms}
        activeFarm={activeFarm}
        accounts={displayedAccounts}
        suppliers={suppliers}
        customers={customers}
        expenses={expenses}
        invoices={invoices}
        quotations={quotations}
        crops={crops}
        employees={employees}
        payslips={payslips}
        poultry={poultryBatches}
        fish={fishBatches}
        inventory={inventory}
        cashSales={cashSales}
        loans={loans}
        investments={investments}
        livestock={livestock}
        credits={credits}
        userProfile={userProfile}
        assets={assets}
        otherRevenues={otherRevenues}
        leaveRecords={leaveRecords}
        advances={employeeAdvances}
        auditLogs={auditLogs}
        archivedRecords={archiveRecords}
        onRestore={handleRestoreBackup}
        onClear={handleClearDatabase}
      />
    );
  }

  // 27. Offline Cache & Sync
  if (activeTab === "offline-sync") {
    return <OfflineSyncPanel />;
  }

  // 28. Finance Hub (Investments & Loans)
  if (activeTab === "finance" || activeTab === "finance-hub") {
    if (!hasReadPermission("accounts") && !hasReadPermission("expenses")) return renderAccessDenied("Finance & Credit Hub");
    return (
      <FinancePanel
        investments={investments}
        onAddInvestment={handleAddInvestment}
        onRealizeInvestment={handleRealizeInvestment}
        onDeleteInvestment={handleArchiveInvestment}
        loans={loans}
        onAddLoan={handleAddLoan}
        onAddLoanRepayment={handleAddLoanRepayment}
        onOffsetLoan={handleOffsetLoan}
        onDeleteLoan={handleDeleteLoan}
        otherRevenues={otherRevenues}
        onAddOtherRevenue={handleAddOtherRevenue}
        onDeleteOtherRevenue={handleArchiveOtherRevenue}
        accounts={displayedAccounts}
        onAddAccount={handleAddAccount}
        isReadonly={isReadonly || !hasWritePermission("accounts")}
        currencySymbol={currencySymbol}
        cashSales={cashSales}
        invoices={invoices}
        farmName={activeFarm?.name}
        userProfileName={userProfile?.displayName || userProfile?.name}
      />
    );
  }

  // 29. Asset Register
  if (activeTab === "assets" || activeTab === "machinery") {
    if (!hasReadPermission("inventory")) return renderAccessDenied("Asset Register");
    return (
      <AssetRegisterPanel
        assets={assets}
        suppliers={suppliers}
        onAddAsset={handleAddAsset}
        onUpdateAsset={handleUpdateAsset}
        onUpdateAssets={handleUpdateAssets}
        onDeleteAsset={handleArchiveAsset}
        accounts={displayedAccounts}
        isReadonly={isReadonly || !hasWritePermission("inventory")}
        currencySymbol={currencySymbol}
      />
    );
  }

  // 30. Audit Archive
  if (activeTab === "audit-archive") {
    return (
      <AuditArchivePanel
        auditLogs={auditLogs}
        archiveRecords={archiveRecords}
        creditLedger={creditLedger || []}
        lipilaTransactions={lipilaTransactions}
        onRestoreFromArchive={handleRestoreRecordFromArchive}
        onPermanentlyPurgeRecord={handlePermanentDeleteFromArchive}
        onClearLogs={handleClearAuditLogs}
        isReadonly={isReadonly}
        currentUser={{ name: userProfile?.displayName || "Admin", email: userEmail, phone: userProfile?.phone }}
      />
    );
  }

  // 31. CSV Import
  if (activeTab === "csv-import") {
    return (
      <CsvImportPanel
        suppliers={suppliers}
        onAddLivestockRecord={handleAddLivestockRecord}
        onAddCrop={handleAddCrop}
        onAddTransaction={handleAddExpense}
        currencySymbol={currencySymbol}
        isReadonly={isReadonly}
        preselectedModule={csvPreselectedModule}
      />
    );
  }

  // 32. Marketplace
  if (activeTab === "marketplace") {
    return (
      <MarketplacePanel
        vendors={vendors}
        setVendors={setVendors}
        products={marketplaceProducts}
        setProducts={setMarketplaceProducts}
        riders={riders}
        setRiders={setRiders}
        orders={marketplaceOrders}
        setOrders={setMarketplaceOrders}
        commissionPercent={commissionPercent}
        setCommissionPercent={setCommissionPercent}
        deliveryFeePerKm={deliveryFeePerKm}
        setDeliveryFeePerKm={setDeliveryFeePerKm}
        onAddTransaction={handleAddExpense}
        isReadonly={isReadonly}
        currencySymbol={currencySymbol}
        currentRole={currentRole}
        userEmail={userEmail}
        platformPackages={platformPackages}
        setPlatformPackages={setPlatformPackages}
        onNavigateToOfftaker={() => setActiveTab("offtaker-marketplace")}
      />
    );
  }

  // 33. Offtaker Marketplace
  if (activeTab === "offtaker-marketplace") {
    return (
      <OfftakerPanel
        currentTenantId={tenantId}
        currentRole={currentRole}
        userEmail={userEmail}
        onAddLedgerEntry={handleAddLedgerEntryFromOfftaker}
        cropCycles={crops}
        setCropCycles={setCrops}
        addNotification={addNotification}
        isOnline={isOnline}
        workspaceMode={workspaceMode as any}
        smsCredits={smsCredits}
        setSmsCredits={setSmsCredits}
        credits={credits}
        setCredits={setCredits}
        setLipilaCheckout={setLipilaCheckout}
        userProfile={userProfile}
      />
    );
  }

  // 34. HSW Storage & Warehouse Dashboard
  if (activeTab === "hsw" || activeTab === "hsw-dashboard" || activeTab === "hsw-dashboard-group") {
    return (
      <HswDashboardPanel
        activeFarm={activeFarm}
        currencySymbol={currencySymbol}
        crops={crops}
        isSuperAdmin={isSuperAdmin}
        userEmail={userEmail}
        tenantId={tenantId}
        onNavigateToAgc={() => setActiveTab("agc-farmer-hub")}
      />
    );
  }

  // 35. Agro Dealer Consignment Hub
  if (activeTab === "agrodealer-consignment") {
    return (
      <AgroDealerConsignmentPanel
        currentTenantId={tenantId}
        activeFarmName={activeFarm?.name}
        currencySymbol={currencySymbol}
        userRole={currentRole}
        currentRole={currentRole}
        userEmail={userEmail}
        onNavigateToAgronomist={() => setActiveTab("advisory-portal")}
      />
    );
  }

  // 36. AGC Farmer Credit Hub
  if (activeTab === "agc-farmer-hub") {
    return (
      <FarmerCreditHub
        farmerTenantId={tenantId}
        currencySymbol={currencySymbol}
        crops={crops}
        suppliers={suppliers}
        activeFarm={activeFarm}
      />
    );
  }

  // 37. AGC Dealer POS
  if (activeTab === "agc-dealer-pos") {
    return (
      <DealerCreditPOS
        dealerTenantId={tenantId}
        currencySymbol={currencySymbol}
      />
    );
  }

  // 38. AGC Financier Portal
  if (activeTab === "agc-financier-portal") {
    return (
      <FinancierPortal
        financierInstitutionId={tenantId}
        currencySymbol={currencySymbol}
      />
    );
  }

  // 39. AGC Insurer Portal
  if (activeTab === "agc-insurer-portal") {
    return (
      <InsurerPortal
        insurerInstitutionId={tenantId}
        currencySymbol={currencySymbol}
        isSuperAdmin={isSuperAdmin}
      />
    );
  }

  // 40. AGC Super Admin Control
  if (activeTab === "agc-super-admin") {
    return (
      <SuperAdminAgcPanel
        currencySymbol={currencySymbol}
      />
    );
  }

  // 41. SMS Communications Hub
  if (activeTab === "sms-hub" || activeTab === "sms-hub-group") {
    return (
      <SmsCommunicationsHub
        userProfile={userProfile}
        currentRole={currentRole}
        workspaceMode={workspaceMode}
        activeFarm={activeFarm}
        farms={farms}
        customers={customers}
        employees={employees}
        suppliers={suppliers}
        smsCredits={smsCredits}
        setSmsCredits={setSmsCredits}
        credits={credits}
        setCredits={setCredits}
        setLipilaCheckout={setLipilaCheckout}
        selectedCountry={selectedCountry?.code || "ZM"}
      />
    );
  }

  // 42. Farm & User Settings
  if (
    activeTab === "settings" ||
    activeTab === "profile" ||
    activeTab === "farm-settings" ||
    activeTab === "tax-settings" ||
    activeTab === "farm-node-settings"
  ) {
    return (
      <FarmUserSettingsPanel
        userProfile={userProfile}
        setUserProfile={setUserProfile}
        activeFarm={activeFarm}
        setActiveFarm={setActiveFarm}
        farms={farms}
        setFarms={setFarms}
        currentRole={currentRole}
        selectedCountry={selectedCountry}
        setSelectedCountry={setSelectedCountry}
        onNavigateToTab={setActiveTab}
        showToast={showToast}
        handleSaveCloudWorkspace={handleSaveCloudWorkspace}
        handleUpdateActiveFarm={handleUpdateActiveFarm}
        tenantId={tenantId}
        userEmail={userEmail}
        writeAuditLog={writeAuditLog}
        archiveRecords={archiveRecords}
        onRestoreFromArchive={handleRestoreRecordFromArchive}
        onAddCreditNote={handleAddCreditNote}
        accounts={displayedAccounts}
        setAccounts={setAccounts}
        credits={credits}
        setCredits={setCredits}
        creditNotes={creditNotes}
        isSuperAdmin={isSuperAdmin}
        initialSection={
          activeTab === "profile"
            ? "profile"
            : activeTab === "tax-settings"
              ? "tax"
              : "farm"
        }
      />
    );
  }

  // Fallback to Dashboard
  return (
    <DashboardOverviewTab
      weatherAlerts={weatherAlerts}
      activeFarm={activeFarm}
      currencySymbol={currencySymbol}
      crops={crops}
      expenses={expenses}
      invoices={invoices}
      cashSales={cashSales}
      livestock={livestock}
      poultryBatches={poultryBatches}
      fishBatches={fishBatches}
      credits={credits}
      smsCredits={smsCredits}
      subscriptionTier={subscriptionTier}
      userProfile={userProfile}
      setActiveTab={setActiveTab}
      isReadonly={isReadonly}
      tasks={tasks}
      onAddTask={handleAddTask}
      onEditTask={handleEditTask}
      onDeleteTask={handleDeleteTask}
      onToggleTaskComplete={handleToggleTaskComplete}
      onTopUpCredits={() => setShowTopUpModal(true)}
      hasReadPermission={hasReadPermission}
      hasWritePermission={hasWritePermission}
      onQuickLogLoss={() => setShowQuickLogLossModal(true)}
      setIsSaleModalOpen={setShowNewSaleModal}
      currentRole={currentRole}
      farms={farms}
      displayedAccounts={displayedAccounts}
      isSuperAdmin={isSuperAdmin}
      onNavigateToModule={setActiveTab}
    />
  );
};

export default AppModuleRenderer;

import React from "react";
import { 
  CreditCard, 
  Building2, 
  ShieldCheck, 
  Info, 
  ArrowRight, 
  CheckCircle, 
  DollarSign, 
  AlertCircle,
  Clock,
  Lock
} from "lucide-react";
import { calculateCardCollectionFees, calculateDisbursementFees } from "../services/mabalaPlatformEngine";
import { getFeeConfig } from "../services/feeConfigService";

export interface FeeBreakdownPreviewProps {
  type: "card_collection" | "bank_disbursement";
  amount: number;
  currency?: string;
  tenantId?: string;
  recipientName?: string;
  accountOrEmail?: string;
  bankOrProvider?: string;
  onConfirm?: () => void;
  onCancel?: () => void;
  isProcessing?: boolean;
  showActions?: boolean;
  compact?: boolean;
}

export default function FeeBreakdownPreview({
  type,
  amount,
  currency = "ZMW",
  tenantId = "TENANT-001",
  recipientName = "Valued Customer / Merchant",
  accountOrEmail,
  bankOrProvider,
  onConfirm,
  onCancel,
  isProcessing = false,
  showActions = true,
  compact = false
}: FeeBreakdownPreviewProps) {
  const safeAmount = Math.max(0, amount || 0);

  if (type === "card_collection") {
    const cardFees = calculateCardCollectionFees(safeAmount);
    const feeConfig = getFeeConfig("card_collection");

    const principal = cardFees.subtotal;
    const totalFee = cardFees.cardFee;
    const lipilaShare = Math.round(totalFee * 0.4 * 100) / 100;
    const platformShare = Math.round(totalFee * 0.6 * 100) / 100;
    const finalBuyerTotal = cardFees.totalAmountToChargeBuyer;

    return (
      <div className={`bg-white rounded-2xl border border-slate-200 shadow-sm space-y-4 text-slate-900 font-sans ${compact ? "p-4" : "p-6"}`}>
        {/* HEADER */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-sm text-slate-900">Card Collection Fee Breakdown</h4>
              <p className="text-[11px] text-slate-500 font-medium">3D-Secure Visa & Mastercard Online Gateway</p>
            </div>
          </div>

          <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-sky-50 text-sky-800 border border-sky-200">
            Charged to: Buyer ({feeConfig.value}%)
          </span>
        </div>

        {/* DETAILS GRID */}
        {accountOrEmail || recipientName ? (
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-black block">Recipient / Merchant</span>
              <span className="font-bold text-slate-800 truncate block">{recipientName}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-black block">Account / Email</span>
              <span className="font-mono text-slate-700 truncate block">{accountOrEmail || "Standard Card Portal"}</span>
            </div>
          </div>
        ) : null}

        {/* ITEMIZATION TABLE */}
        <div className="space-y-2 text-xs">
          <div className="flex justify-between items-center py-1 border-b border-dashed border-slate-200">
            <span className="text-slate-600 font-medium">Principal Product Amount:</span>
            <span className="font-mono font-bold text-slate-900">{currency} {principal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>

          <div className="flex justify-between items-center py-1 border-b border-dashed border-slate-200">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-600 font-medium">Card Processing Platform Fee ({feeConfig.value}%):</span>
              <span className="text-[10px] text-indigo-600 font-mono bg-indigo-50 px-1.5 py-0.5 rounded">Itemized</span>
            </div>
            <span className="font-mono font-bold text-indigo-700">+{currency} {totalFee.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>

          {/* ITEMIZED SHARE BREAKDOWN */}
          <div className="pl-4 space-y-1 text-[11px] text-slate-500 bg-slate-50/80 p-2.5 rounded-lg border border-slate-100">
            <div className="flex justify-between">
              <span>• Lipila Gateway Processing (40%):</span>
              <span className="font-mono font-semibold">{currency} {lipilaShare.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>• Mabala Platform Services (60%):</span>
              <span className="font-mono font-semibold">{currency} {platformShare.toFixed(2)}</span>
            </div>
          </div>

          <div className="flex justify-between items-center pt-2">
            <div>
              <span className="text-xs font-black text-slate-900 block">Total Amount Billed to Buyer:</span>
              <span className="text-[10px] text-emerald-700 font-medium">Merchant receives 100% principal ({currency} {principal.toFixed(2)})</span>
            </div>
            <strong className="text-lg font-black font-mono text-emerald-800">
              {currency} {finalBuyerTotal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </strong>
          </div>
        </div>

        {/* SECURITY & TERMS */}
        <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-200/80 flex items-start gap-2.5 text-[11px] text-emerald-900">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <span>
            Card payments are authenticated via 3D Secure OTP verification. Rate limited to 5 requests per minute per tenant to protect against brute force and cost-drain abuse.
          </span>
        </div>

        {/* ACTIONS */}
        {showActions && (
          <div className="flex gap-3 pt-2">
            {onConfirm && (
              <button
                disabled={isProcessing || safeAmount <= 0}
                onClick={onConfirm}
                className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {isProcessing ? (
                  <>
                    <Clock className="w-4 h-4 animate-spin" />
                    <span>Authorizing 3DS Gateway...</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>Authorize Card Collection ({currency} {finalBuyerTotal.toFixed(2)})</span>
                  </>
                )}
              </button>
            )}

            {onCancel && (
              <button
                disabled={isProcessing}
                onClick={onCancel}
                className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                Cancel
              </button>
            )}
          </div>
        )}
      </div>
    );
  }

  // BANK DISBURSEMENT BREAKDOWN
  const disbFees = calculateDisbursementFees(safeAmount, "Bank");
  const feeConfig = getFeeConfig("disbursement_platform_fee");
  const lipilaFee = disbFees.lipilaFee;
  const platformFee = disbFees.platformFee3Point5;
  const totalFee = disbFees.totalFees;
  const netRecipientReceives = safeAmount;
  const totalDeductedFromWallet = safeAmount + totalFee;

  return (
    <div className={`bg-white rounded-2xl border border-slate-200 shadow-sm space-y-4 text-slate-900 font-sans ${compact ? "p-4" : "p-6"}`}>
      {/* HEADER */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-extrabold text-sm text-slate-900">Bank Disbursement Fee Breakdown</h4>
            <p className="text-[11px] text-slate-500 font-medium">Commercial Bank Direct Transfer Gateway</p>
          </div>
        </div>

        <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-50 text-purple-800 border border-purple-200">
          Charged to: Sender ({feeConfig.value}%)
        </span>
      </div>

      {/* DETAILS GRID */}
      {recipientName || accountOrEmail || bankOrProvider ? (
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 grid grid-cols-2 gap-2 text-xs">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-black block">Beneficiary Name</span>
            <span className="font-bold text-slate-800 truncate block">{recipientName}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-black block">Destination Account / Bank</span>
            <span className="font-mono text-slate-700 truncate block">
              {bankOrProvider ? `${bankOrProvider} (${accountOrEmail || "N/A"})` : accountOrEmail || "Zambian Bank Account"}
            </span>
          </div>
        </div>
      ) : null}

      {/* ITEMIZATION TABLE */}
      <div className="space-y-2 text-xs">
        <div className="flex justify-between items-center py-1 border-b border-dashed border-slate-200">
          <span className="text-slate-600 font-medium">Requested Disbursement Principal:</span>
          <span className="font-mono font-bold text-slate-900">{currency} {netRecipientReceives.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
        </div>

        <div className="flex justify-between items-center py-1 border-b border-dashed border-slate-200">
          <span className="text-slate-600 font-medium">Lipila Bank Gateway Direct Transfer Fee:</span>
          <span className="font-mono font-bold text-slate-800">+{currency} {lipilaFee.toFixed(2)}</span>
        </div>

        <div className="flex justify-between items-center py-1 border-b border-dashed border-slate-200">
          <span className="text-slate-600 font-medium">Mabala Platform Payout Fee ({feeConfig.value}%):</span>
          <span className="font-mono font-bold text-indigo-700">+{currency} {platformFee.toFixed(2)}</span>
        </div>

        <div className="flex justify-between items-center py-1 border-b border-slate-200 bg-indigo-50/50 p-2 rounded-lg">
          <span className="font-extrabold text-indigo-950">Total Service & Gateway Fees:</span>
          <strong className="font-mono font-black text-indigo-900">{currency} {totalFee.toFixed(2)}</strong>
        </div>

        <div className="flex justify-between items-center pt-2">
          <div>
            <span className="text-xs font-black text-slate-900 block">Total Wallet Outflow (Sender):</span>
            <span className="text-[10px] text-slate-500 font-medium">Beneficiary receives exactly {currency} {netRecipientReceives.toFixed(2)} net</span>
          </div>
          <strong className="text-lg font-black font-mono text-slate-900">
            {currency} {totalDeductedFromWallet.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </strong>
        </div>
      </div>

      {/* DISBURSEMNT NARRATION NOTICE */}
      <div className="bg-sky-50/70 p-3 rounded-xl border border-sky-200/80 flex items-start gap-2.5 text-[11px] text-sky-900">
        <Info className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold block">Standard Bank Narration: "Disbursement from Mabala"</span>
          <span>Requires 4-digit Security PIN. Rate limited to 5 disbursement requests per minute per tenant.</span>
        </div>
      </div>

      {/* ACTIONS */}
      {showActions && (
        <div className="flex gap-3 pt-2">
          {onConfirm && (
            <button
              disabled={isProcessing || safeAmount <= 0}
              onClick={onConfirm}
              className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {isProcessing ? (
                <>
                  <Clock className="w-4 h-4 animate-spin" />
                  <span>Processing Bank Dispatch...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Confirm Bank Disbursement ({currency} {totalDeductedFromWallet.toFixed(2)})</span>
                </>
              )}
            </button>
          )}

          {onCancel && (
            <button
              disabled={isProcessing}
              onClick={onCancel}
              className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
            >
              Cancel
            </button>
          )}
        </div>
      )}
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { 
  ShieldCheck, 
  Lock, 
  Layers, 
  UserCheck, 
  Sliders, 
  Check, 
  X, 
  RotateCcw, 
  Search, 
  AlertTriangle,
  Building,
  Store,
  Tractor,
  Shield,
  HelpCircle,
  Save,
  Database,
  Plus,
  History,
  CheckCircle,
  FileText,
  CheckSquare
} from "lucide-react";
import { 
  ALL_ENTITLED_MODULES, 
  HARD_PLATFORM_LOCK_MODULES, 
  DEFAULT_TENANT_TYPE_ENTITLEMENTS, 
  CANONICAL_TENANT_TYPES,
  TenantTypeCode,
  assertAgroDealerInvariant,
  SEEDED_MODULE_REGISTRY,
  ModuleRegistryDoc,
  seedModuleRegistryIdempotent
} from "../../services/moduleEntitlementEngine";
import { doc, setDoc, getDoc, collection, getDocs, onSnapshot, addDoc, deleteDoc } from "firebase/firestore";
import { db, auth } from "../../firebase";

interface TenantUser {
  uid: string;
  email: string;
  name?: string;
  role?: string;
  tpin?: string;
  tenantType: TenantTypeCode;
}

interface ModuleAccessState {
  enabled: boolean;
  read: boolean;
  write: boolean;
}

interface AuditLogEntry {
  id?: string;
  tenantTypeCode?: TenantTypeCode;
  tenantId?: string;
  moduleId: string;
  before?: any;
  after?: any;
  uid: string;
  timestamp: string;
  type: "global_default" | "tenant_override" | "registry_new";
}

export default function ModuleEntitlementEnginePanel() {
  const [activeTab, setActiveTab] = useState<"screen1" | "screen2" | "screen3" | "audit">("screen1");
  
  // Registry state
  const [moduleRegistry, setModuleRegistry] = useState<ModuleRegistryDoc[]>(SEEDED_MODULE_REGISTRY);

  // Screen 1 State: Tenant Type Defaults
  // Selected segmented option: "agro_dealer" | "seed_chemical" | "institution_supplier" | "farmer"
  const [selectedTenantSegment, setSelectedTenantSegment] = useState<"agro_dealer" | "seed_chemical" | "institution_supplier" | "farmer">("agro_dealer");
  const [selectedModuleIds, setSelectedModuleIds] = useState<string[]>([]);
  
  // Map segment to TenantTypeCode
  const currentTenantTypeCode: TenantTypeCode = 
    selectedTenantSegment === "seed_chemical" ? "institution_supplier" : selectedTenantSegment;

  useEffect(() => {
    setSelectedModuleIds([]);
  }, [selectedTenantSegment]);

  const [typeEntitlements, setTypeEntitlements] = useState<Record<TenantTypeCode, Record<string, ModuleAccessState>>>({
    agro_dealer: {},
    institution_supplier: {},
    offtaker: {},
    mabala_partner: {},
    farmer: {},
    super_admin: {},
    agronomist: {}
  });

  const [tenantCounts, setTenantCounts] = useState<Record<TenantTypeCode, number>>({
    agro_dealer: 0,
    institution_supplier: 0,
    offtaker: 0,
    mabala_partner: 0,
    farmer: 0,
    super_admin: 0,
    agronomist: 0
  });

  // Screen 2 State: Per-Tenant Overrides
  const [allUsers, setAllUsers] = useState<TenantUser[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedUser, setSelectedUser] = useState<TenantUser | null>(null);
  const [tenantOverrides, setTenantOverrides] = useState<Record<string, ModuleAccessState | null>>({});

  // Screen 3 State: New Module Form
  const [newModuleId, setNewModuleId] = useState("");
  const [newModuleName, setNewModuleName] = useState("");
  const [newModuleDesc, setNewModuleDesc] = useState("");
  const [newModuleCategory, setNewModuleCategory] = useState<"core" | "finance" | "agriculture" | "commerce" | "admin_only">("agriculture");
  const [newModuleEligibleTypes, setNewModuleEligibleTypes] = useState<TenantTypeCode[]>(["farmer"]);
  const [newModuleHardLocked, setNewModuleHardLocked] = useState(false);
  const [showAddModuleModal, setShowAddModuleModal] = useState(false);

  // Audit Logs
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);

  // Status & Notifications
  const [isLoading, setIsLoading] = useState(false);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [invariantError, setInvariantError] = useState<string | null>(null);

  useEffect(() => {
    seedModuleRegistryIdempotent();
    if (!db) return;

    setIsLoading(true);
    const unsubs: Array<() => void> = [];

    // 1. Subscribe to Module Registry docs from platformConfig/moduleRegistry/modules
    try {
      const regCol = collection(db, "platformConfig", "moduleRegistry", "modules");
      const unsubReg = onSnapshot(regCol, { includeMetadataChanges: true }, (regSnap) => {
        if (!regSnap.empty) {
          const fetched: ModuleRegistryDoc[] = [];
          regSnap.forEach(docSnap => {
            const data = docSnap.data() as ModuleRegistryDoc;
            if (data && data.moduleId) {
              fetched.push(data);
            }
          });
          if (fetched.length > 0) {
            setModuleRegistry(fetched);
          }
        }
      }, (e) => {
        console.warn("[ModuleEntitlementEngine] Registry snapshot fallback to seeded list:", e);
      });
      unsubs.push(unsubReg);
    } catch (e) {
      console.warn("[ModuleEntitlementEngine] Registry setup notice:", e);
    }

    // 2. Subscribe to Tenant Type Entitlements
    const tenantTypes: TenantTypeCode[] = ["agro_dealer", "institution_supplier", "offtaker", "mabala_partner", "farmer", "super_admin", "agronomist"];
    tenantTypes.forEach((tType) => {
      try {
        const entRef = doc(db, "platformConfig", "moduleEntitlements", tType);
        const unsubEnt = onSnapshot(entRef, { includeMetadataChanges: true }, (snap) => {
          if (snap.exists() && snap.data()?.modules) {
            setTypeEntitlements(prev => ({
              ...prev,
              [tType]: snap.data().modules
            }));
          } else {
            const defaults = DEFAULT_TENANT_TYPE_ENTITLEMENTS[tType] || {};
            const map: Record<string, ModuleAccessState> = {};
            Object.entries(defaults).forEach(([mId, val]) => {
              map[mId] = { enabled: val, read: val, write: val };
            });
            setTypeEntitlements(prev => ({
              ...prev,
              [tType]: prev[tType] && Object.keys(prev[tType]).length > 0 ? prev[tType] : map
            }));
          }
        }, (e) => {
          console.warn(`[ModuleEntitlementEngine] Snapshot notice for ${tType}:`, e);
        });
        unsubs.push(unsubEnt);
      } catch (e) {
        console.warn(`[ModuleEntitlementEngine] Error setting up listener for ${tType}:`, e);
      }
    });

    // 3. Subscribe to Users for live tenant counts and override selector
    try {
      const usersCol = collection(db, "users_data");
      const unsubUsers = onSnapshot(usersCol, { includeMetadataChanges: true }, (usersSnap) => {
        const usersList: TenantUser[] = [];
        const counts: Record<TenantTypeCode, number> = {
          agro_dealer: 0,
          institution_supplier: 0,
          offtaker: 0,
          mabala_partner: 0,
          farmer: 0,
          super_admin: 0,
          agronomist: 0
        };

        usersSnap.forEach(uDoc => {
          const u = uDoc.data();
          if (u) {
            let tenantType: TenantTypeCode = "farmer";
            const roleLower = (u.role || "").toLowerCase();
            if (roleLower === "super_admin" || roleLower === "platform administrator" || roleLower === "super admin") {
              tenantType = "super_admin";
            } else if (roleLower === "agro_dealer" || roleLower === "agrodealer" || roleLower === "agro-dealer" || roleLower === "retailer") {
              tenantType = "agro_dealer";
            } else if (roleLower === "institution_supplier" || roleLower === "supplier" || roleLower === "seed_chemical_company" || roleLower === "institution admin") {
              tenantType = "institution_supplier";
            } else if (roleLower === "offtaker" || roleLower === "off-taker" || roleLower === "commodity buyer" || roleLower === "crop buyer") {
              tenantType = "offtaker";
            } else if (u.tenantType) {
              tenantType = u.tenantType as TenantTypeCode;
            }

            counts[tenantType] = (counts[tenantType] || 0) + 1;

            usersList.push({
              uid: uDoc.id,
              email: u.email || "No Email",
              name: u.name || u.farmName || u.companyName || "Workspace Node",
              role: u.role || "Farmer",
              tpin: u.tpin || u.tpinNumber || "",
              tenantType
            });
          }
        });
        setAllUsers(usersList);
        setTenantCounts(counts);
        setIsLoading(false);
      }, (e) => {
        console.warn("[ModuleEntitlementEngine] Users snapshot notice:", e);
        setIsLoading(false);
      });
      unsubs.push(unsubUsers);
    } catch (e) {
      console.warn("[ModuleEntitlementEngine] Error setting up users listener:", e);
      setIsLoading(false);
    }

    // 4. Subscribe to Audit Logs
    try {
      const auditCol = collection(db, "platformConfig", "entitlementAuditLog");
      const unsubAudit = onSnapshot(auditCol, { includeMetadataChanges: true }, (auditSnap) => {
        const logs: AuditLogEntry[] = [];
        auditSnap.forEach(aDoc => {
          logs.push({ id: aDoc.id, ...aDoc.data() } as AuditLogEntry);
        });
        logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        setAuditLogs(logs);
      }, (e) => {
        console.warn("[ModuleEntitlementEngine] Audit logs snapshot note:", e);
      });
      unsubs.push(unsubAudit);
    } catch (e) {
      console.warn("[ModuleEntitlementEngine] Audit logs setup notice:", e);
    }

    return () => {
      unsubs.forEach(fn => fn());
    };
  }, []);

  // Helper: Get global default for a module & tenant type
  const getGlobalDefaultState = (tType: TenantTypeCode, moduleId: string): ModuleAccessState => {
    const custom = typeEntitlements[tType]?.[moduleId];
    if (custom !== undefined) return custom;

    const isDefOn = DEFAULT_TENANT_TYPE_ENTITLEMENTS[tType]?.[moduleId] ?? false;
    return { enabled: isDefOn, read: isDefOn, write: isDefOn };
  };

  // Bulk edit handlers for Screen 1
  const handleSelectAllScreen1 = () => {
    if (selectedModuleIds.length === screen1EligibleModules.length) {
      setSelectedModuleIds([]);
    } else {
      setSelectedModuleIds(screen1EligibleModules.map(m => m.moduleId));
    }
  };

  const handleToggleModuleSelection = (moduleId: string) => {
    setSelectedModuleIds(prev =>
      prev.includes(moduleId) ? prev.filter(id => id !== moduleId) : [...prev, moduleId]
    );
  };

  const handleBulkApplyScreen1 = (action: "enable" | "disable" | "readOnly") => {
    if (selectedModuleIds.length === 0) return;

    setTypeEntitlements(prev => {
      const currentMap = { ...(prev[currentTenantTypeCode] || {}) };
      selectedModuleIds.forEach(mId => {
        if (action === "enable") {
          currentMap[mId] = { enabled: true, read: true, write: true };
        } else if (action === "disable") {
          currentMap[mId] = { enabled: false, read: false, write: false };
        } else if (action === "readOnly") {
          currentMap[mId] = { enabled: true, read: true, write: false };
        }
      });
      return {
        ...prev,
        [currentTenantTypeCode]: currentMap
      };
    });

    const actionText = action === "enable" ? "enabled" : action === "disable" ? "disabled" : "set to read-only";
    setSaveStatus(`Bulk updated ${selectedModuleIds.length} modules to ${actionText} for ${currentTenantTypeCode}. Click "Save & Deploy" to commit.`);
    setTimeout(() => setSaveStatus(null), 5000);
  };

  // Toggle handlers for Screen 1 (Tenant Type Defaults)
  const handleToggleDefaultEnabled = (moduleId: string) => {
    setTypeEntitlements(prev => {
      const currentMap = { ...(prev[currentTenantTypeCode] || {}) };
      const current = currentMap[moduleId] || getGlobalDefaultState(currentTenantTypeCode, moduleId);
      
      const newEnabled = !current.enabled;
      // If turning off enabled, read & write are also turned off
      const updated: ModuleAccessState = {
        enabled: newEnabled,
        read: newEnabled ? current.read : false,
        write: newEnabled ? current.write : false
      };

      return {
        ...prev,
        [currentTenantTypeCode]: {
          ...currentMap,
          [moduleId]: updated
        }
      };
    });
  };

  const handleToggleDefaultRead = (moduleId: string) => {
    setTypeEntitlements(prev => {
      const currentMap = { ...(prev[currentTenantTypeCode] || {}) };
      const current = currentMap[moduleId] || getGlobalDefaultState(currentTenantTypeCode, moduleId);
      if (!current.enabled) return prev; // Cannot toggle read if not enabled

      const newRead = !current.read;
      const updated: ModuleAccessState = {
        ...current,
        read: newRead,
        write: newRead ? current.write : false // If read is off, write must be off
      };

      return {
        ...prev,
        [currentTenantTypeCode]: {
          ...currentMap,
          [moduleId]: updated
        }
      };
    });
  };

  const handleToggleDefaultWrite = (moduleId: string) => {
    setTypeEntitlements(prev => {
      const currentMap = { ...(prev[currentTenantTypeCode] || {}) };
      const current = currentMap[moduleId] || getGlobalDefaultState(currentTenantTypeCode, moduleId);
      if (!current.enabled || !current.read) return prev; // Cannot toggle write if not enabled or read is off

      const updated: ModuleAccessState = {
        ...current,
        write: !current.write
      };

      return {
        ...prev,
        [currentTenantTypeCode]: {
          ...currentMap,
          [moduleId]: updated
        }
      };
    });
  };

  // Save Screen 1 Defaults to Firestore
  const handleSaveTypeDefaults = async () => {
    try {
      setSaveStatus("Saving tenant type defaults & logging audit trail...");
      const currentAdminUid = auth?.currentUser?.uid || "super_admin_system";

      const entRef = doc(db, "platformConfig", "moduleEntitlements", currentTenantTypeCode);
      const modulesMap = typeEntitlements[currentTenantTypeCode] || {};

      await setDoc(entRef, {
        modules: modulesMap,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      // Append Audit Log
      const newAuditLogs: AuditLogEntry[] = [];
      for (const [mId, access] of Object.entries(modulesMap)) {
        const auditDoc: AuditLogEntry = {
          tenantTypeCode: currentTenantTypeCode,
          moduleId: mId,
          before: null,
          after: access,
          uid: currentAdminUid,
          timestamp: new Date().toISOString(),
          type: "global_default"
        };
        await addDoc(collection(db, "platformConfig", "entitlementAuditLog"), auditDoc);
        newAuditLogs.push(auditDoc);
      }

      setAuditLogs(prev => [...newAuditLogs, ...prev]);
      setSaveStatus(`✅ Saved defaults for ${CANONICAL_TENANT_TYPES[currentTenantTypeCode]?.humanLabel || currentTenantTypeCode}!`);
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (err) {
      console.error("[ModuleEntitlementEngine] Save defaults error:", err);
      setSaveStatus("⚠️ Failed to save tenant type defaults.");
    }
  };

  // Select user for Screen 2 (Per-Tenant Override)
  const handleSelectUser = async (user: TenantUser) => {
    setSelectedUser(user);
    setInvariantError(null);

    // Hard Invariant Enforcement: agro_dealer cannot hold super_admin
    if (user.tenantType === "agro_dealer" && (user.role === "super_admin" || user.role === "Super Admin")) {
      setInvariantError("HARD INVARIANT BREACH DETECTED: Agro-Dealer tenants can never be assigned super_admin role!");
    }

    try {
      const overrideRef = doc(db, "tenants", user.uid, "moduleOverrides", "overrides");
      const snap = await getDoc(overrideRef);
      if (snap.exists() && snap.data()?.overrides) {
        setTenantOverrides(snap.data().overrides);
      } else {
        setTenantOverrides({});
      }
    } catch (err) {
      console.warn("[ModuleEntitlementEngine] Error loading tenant overrides:", err);
      setTenantOverrides({});
    }
  };

  // Screen 2 Override Toggles
  const handleToggleTenantOverrideActive = (moduleId: string) => {
    if (!selectedUser) return;
    setTenantOverrides(prev => {
      const existing = prev[moduleId];
      if (existing !== undefined && existing !== null) {
        // Clear override -> revert to inherited
        const next = { ...prev };
        delete next[moduleId];
        return next;
      } else {
        // Enable override with initial copy of global default
        const globalDef = getGlobalDefaultState(selectedUser.tenantType, moduleId);
        return {
          ...prev,
          [moduleId]: { ...globalDef }
        };
      }
    });
  };

  const handleUpdateTenantOverrideState = (moduleId: string, field: "enabled" | "read" | "write", value: boolean) => {
    if (!selectedUser) return;
    setTenantOverrides(prev => {
      const current = prev[moduleId] || getGlobalDefaultState(selectedUser.tenantType, moduleId);
      
      let updated: ModuleAccessState = { ...current, [field]: value };
      if (field === "enabled" && !value) {
        updated.read = false;
        updated.write = false;
      } else if (field === "read" && !value) {
        updated.write = false;
      }

      return {
        ...prev,
        [moduleId]: updated
      };
    });
  };

  // Save Screen 2 Per-Tenant Overrides
  const handleSaveTenantOverrides = async () => {
    if (!selectedUser) return;
    try {
      setSaveStatus(`Saving overrides for tenant ${selectedUser.email}...`);
      const currentAdminUid = auth?.currentUser?.uid || "super_admin_system";

      // Hard Invariant Check before save
      if (selectedUser.tenantType === "agro_dealer" && (selectedUser.role === "super_admin" || selectedUser.role === "Super Admin")) {
        assertAgroDealerInvariant("agro_dealer", "super_admin");
      }

      const overrideRef = doc(db, "tenants", selectedUser.uid, "moduleOverrides", "overrides");
      await setDoc(overrideRef, {
        uid: selectedUser.uid,
        email: selectedUser.email,
        tenantType: selectedUser.tenantType,
        overrides: tenantOverrides,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      // Save individual module docs in tenants/{tenantId}/moduleOverrides/{moduleId}
      for (const [mId, rawState] of Object.entries(tenantOverrides)) {
        const overrideState = rawState as ModuleAccessState | null;
        const modOverrideRef = doc(db, "tenants", selectedUser.uid, "moduleOverrides", mId);
        if (!overrideState) {
          await deleteDoc(modOverrideRef);
        } else {
          await setDoc(modOverrideRef, {
            enabled: overrideState.enabled,
            read: overrideState.read,
            write: overrideState.write,
            updatedAt: new Date().toISOString()
          });
        }

        // Write Audit Log
        const auditDoc: AuditLogEntry = {
          tenantId: selectedUser.uid,
          moduleId: mId,
          before: null,
          after: overrideState || null,
          uid: currentAdminUid,
          timestamp: new Date().toISOString(),
          type: "tenant_override"
        };
        await addDoc(collection(db, "platformConfig", "entitlementAuditLog"), auditDoc);
      }

      setSaveStatus(`✅ Per-tenant overrides saved for ${selectedUser.name || selectedUser.email}!`);
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (err: any) {
      console.error("[ModuleEntitlementEngine] Save tenant override error:", err);
      setSaveStatus(`⚠️ ${err.message || "Failed to save overrides"}`);
    }
  };

  // Screen 3: Register New Module
  const handleRegisterNewModule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newModuleId || !newModuleName) {
      alert("Module ID and Name are required!");
      return;
    }

    const formattedId = newModuleId.trim().toLowerCase().replace(/[^a-z0-9_]/g, "_");
    
    const newDoc: ModuleRegistryDoc = {
      moduleId: formattedId,
      name: newModuleName.trim(),
      description: newModuleDesc.trim() || "Registered platform module",
      category: newModuleCategory,
      eligibleTenantTypes: newModuleHardLocked ? [] : newModuleEligibleTypes,
      hardLocked: newModuleHardLocked,
      defaultAccess: { read: true, write: true }
    };

    try {
      setSaveStatus(`Publishing new module ${formattedId} to registry...`);
      const currentAdminUid = auth?.currentUser?.uid || "super_admin_system";

      const docRef = doc(db, "platformConfig", "moduleRegistry", "modules", formattedId);
      await setDoc(docRef, {
        ...newDoc,
        updatedAt: new Date().toISOString()
      });

      // Audit Log
      await addDoc(collection(db, "platformConfig", "entitlementAuditLog"), {
        moduleId: formattedId,
        before: null,
        after: { enabled: true, read: true, write: true },
        uid: currentAdminUid,
        timestamp: new Date().toISOString(),
        type: "registry_new"
      });

      setModuleRegistry(prev => [...prev.filter(m => m.moduleId !== formattedId), newDoc]);
      setSaveStatus(`✅ Registered module "${newModuleName}" in platformConfig/moduleRegistry!`);
      
      // Reset form
      setNewModuleId("");
      setNewModuleName("");
      setNewModuleDesc("");
      setShowAddModuleModal(false);
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (err) {
      console.error("[ModuleEntitlementEngine] Register module error:", err);
      setSaveStatus("⚠️ Failed to register module.");
    }
  };

  // Filtered Modules for Screen 1
  const screen1EligibleModules = moduleRegistry.filter(mod => {
    if (mod.hardLocked || HARD_PLATFORM_LOCK_MODULES.includes(mod.moduleId)) {
      return false; // Hard-locked modules never appear in Tenant Type defaults table
    }
    return mod.eligibleTenantTypes.includes(currentTenantTypeCode);
  });

  // Filtered Users for Screen 2
  const filteredUsers = allUsers.filter(u => 
    u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (u.name && u.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (u.tpin && u.tpin.toLowerCase().includes(searchQuery.toLowerCase())) ||
    u.uid.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Screen 2 Eligible Modules for selected user
  const screen2EligibleModules = selectedUser 
    ? moduleRegistry.filter(mod => {
        if (mod.hardLocked || HARD_PLATFORM_LOCK_MODULES.includes(mod.moduleId)) {
          return false;
        }
        return mod.eligibleTenantTypes.includes(selectedUser.tenantType);
      })
    : [];

  return (
    <div className="space-y-6 font-sans">
      {/* Header Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold mb-2">
              <ShieldCheck className="w-3.5 h-3.5" /> Platform Admin Entitlement & Role Console
            </div>
            <h2 className="text-xl font-black text-white flex items-center gap-2">
              <Layers className="w-6 h-6 text-emerald-400" /> Module Entitlements & Role Console
            </h2>
            <p className="text-xs text-slate-400 font-medium mt-1 max-w-3xl">
              Self-populating module registry (<code className="text-emerald-300 font-mono">platformConfig/moduleRegistry</code>) with 3-layer precedence governing module visibility, read access, and write access across Mabala.
            </p>
          </div>

          {saveStatus && (
            <div className="px-4 py-2 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs rounded-xl animate-fade-in shadow">
              {saveStatus}
            </div>
          )}
        </div>

        {/* Console Navigation Tabs */}
        <div className="flex flex-wrap gap-2 mt-6 border-t border-slate-800 pt-4">
          <button
            onClick={() => setActiveTab("screen1")}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "screen1" 
                ? "bg-emerald-600 text-white shadow" 
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            <Sliders className="w-4 h-4" /> Screen 1: Tenant Type Defaults
          </button>
          
          <button
            onClick={() => setActiveTab("screen2")}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "screen2" 
                ? "bg-emerald-600 text-white shadow" 
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            <UserCheck className="w-4 h-4" /> Screen 2: Individual Tenant Overrides
          </button>
          
          <button
            onClick={() => setActiveTab("screen3")}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "screen3" 
                ? "bg-emerald-600 text-white shadow" 
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            <Database className="w-4 h-4" /> Screen 3: Module Registry ({moduleRegistry.length})
          </button>

          <button
            onClick={() => setActiveTab("audit")}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "audit" 
                ? "bg-emerald-600 text-white shadow" 
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            <History className="w-4 h-4" /> Audit Log ({auditLogs.length})
          </button>
        </div>
      </div>

      {/* SCREEN 1 — TENANT TYPE DEFAULTS */}
      {activeTab === "screen1" && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-4">
            <div>
              <span className="text-[10px] font-black uppercase text-emerald-600 tracking-wider">Screen 1 — Platform-Wide Defaults</span>
              <h3 className="text-base font-extrabold text-slate-900">Tenant Type Defaults Matrix</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Configure baseline module access rights per tenant type. Saving writes to <code className="bg-slate-100 px-1.5 py-0.5 rounded text-[10.5px]">platformConfig/moduleEntitlements/&#123;tenantTypeCode&#125;</code>.
              </p>
            </div>
            <button
              onClick={handleSaveTypeDefaults}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow cursor-pointer transition-all shrink-0"
            >
              <Save className="w-4 h-4" /> Commit Type Defaults
            </button>
          </div>

          {/* Segmented Control Selector */}
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Select Target Tenant Type</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 bg-slate-100 p-1.5 rounded-2xl">
              <button
                type="button"
                onClick={() => setSelectedTenantSegment("agro_dealer")}
                className={`p-3 rounded-xl text-left transition-all cursor-pointer flex flex-col ${
                  selectedTenantSegment === "agro_dealer"
                    ? "bg-slate-900 text-white shadow-md font-bold"
                    : "text-slate-700 hover:bg-white/60 font-semibold"
                }`}
              >
                <div className="flex items-center gap-2 text-xs">
                  <Store className="w-4 h-4 text-emerald-400" /> Agro-Dealer
                </div>
                <span className="text-[10px] opacity-75 mt-1 font-mono">agro_dealer</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedTenantSegment("seed_chemical")}
                className={`p-3 rounded-xl text-left transition-all cursor-pointer flex flex-col ${
                  selectedTenantSegment === "seed_chemical"
                    ? "bg-slate-900 text-white shadow-md font-bold"
                    : "text-slate-700 hover:bg-white/60 font-semibold"
                }`}
              >
                <div className="flex items-center gap-2 text-xs">
                  <Building className="w-4 h-4 text-emerald-400" /> Seed & Chemical Co.
                </div>
                <span className="text-[10px] opacity-75 mt-1 font-mono">institution_supplier</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedTenantSegment("institution_supplier")}
                className={`p-3 rounded-xl text-left transition-all cursor-pointer flex flex-col ${
                  selectedTenantSegment === "institution_supplier"
                    ? "bg-slate-900 text-white shadow-md font-bold"
                    : "text-slate-700 hover:bg-white/60 font-semibold"
                }`}
              >
                <div className="flex items-center gap-2 text-xs">
                  <Shield className="w-4 h-4 text-emerald-400" /> Institution Supplier
                </div>
                <span className="text-[10px] opacity-75 mt-1 font-mono">institution_supplier</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedTenantSegment("farmer")}
                className={`p-3 rounded-xl text-left transition-all cursor-pointer flex flex-col ${
                  selectedTenantSegment === "farmer"
                    ? "bg-slate-900 text-white shadow-md font-bold"
                    : "text-slate-700 hover:bg-white/60 font-semibold"
                }`}
              >
                <div className="flex items-center gap-2 text-xs">
                  <Tractor className="w-4 h-4 text-emerald-400" /> Farmer
                </div>
                <span className="text-[10px] opacity-75 mt-1 font-mono">farmer</span>
              </button>
            </div>
          </div>

          {/* Inline Confirmation Alert Banner */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <span className="text-emerald-950 font-bold">Platform-Wide Scope Confirmation:</span>
                <span className="text-emerald-800 ml-1">
                  Applies platform-wide to <strong>{tenantCounts[currentTenantTypeCode] || 0} active tenants</strong> of type <code className="bg-emerald-100 px-1 py-0.5 rounded font-bold font-mono text-[10px]">{currentTenantTypeCode}</code>.
                </span>
              </div>
            </div>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded uppercase">
              {screen1EligibleModules.length} Modules Eligible
            </span>
          </div>

          {/* Bulk Action Toolbar */}
          {selectedModuleIds.length > 0 && (
            <div className="bg-slate-900 text-white p-3 rounded-xl flex items-center justify-between text-xs shadow-lg border border-slate-700 font-sans animate-in fade-in duration-200">
              <div className="flex items-center gap-2">
                <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-bold">{selectedModuleIds.length} modules selected</span>
                <span className="text-slate-400 text-[11px] font-mono">({currentTenantTypeCode})</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleBulkApplyScreen1("enable")}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-sm"
                >
                  Enable Selected
                </button>
                <button
                  type="button"
                  onClick={() => handleBulkApplyScreen1("readOnly")}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-sm"
                >
                  Read-Only Selected
                </button>
                <button
                  type="button"
                  onClick={() => handleBulkApplyScreen1("disable")}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-sm"
                >
                  Disable Selected
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedModuleIds([])}
                  className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-all cursor-pointer border border-slate-700"
                >
                  Clear Selection
                </button>
              </div>
            </div>
          )}

          {/* Eligible Modules Table */}
          <div className="overflow-x-auto border rounded-2xl">
            <table className="w-full text-left text-xs bg-white text-slate-800">
              <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50 border-b">
                <tr>
                  <th className="p-3.5 w-10 text-center">
                    <input
                      type="checkbox"
                      checked={screen1EligibleModules.length > 0 && selectedModuleIds.length === screen1EligibleModules.length}
                      onChange={handleSelectAllScreen1}
                      className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      title="Select / Deselect All Eligible Modules"
                    />
                  </th>
                  <th className="p-3.5">Module</th>
                  <th className="p-3.5">Description</th>
                  <th className="p-3.5 text-center">Enabled</th>
                  <th className="p-3.5 text-center">Read Access</th>
                  <th className="p-3.5 text-center">Write Access</th>
                </tr>
              </thead>
              <tbody className="divide-y font-medium text-slate-700">
                {screen1EligibleModules.map(mod => {
                  const access = typeEntitlements[currentTenantTypeCode]?.[mod.moduleId] || getGlobalDefaultState(currentTenantTypeCode, mod.moduleId);
                  const isEnabled = access.enabled;
                  const isRead = access.read;
                  const isWrite = access.write;
                  const isSelected = selectedModuleIds.includes(mod.moduleId);

                  return (
                    <tr key={mod.moduleId} className={`hover:bg-slate-50 ${isSelected ? "bg-emerald-50/50" : !isEnabled ? "bg-slate-50/60 opacity-60" : ""}`}>
                      <td className="p-3.5 text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleModuleSelection(mod.moduleId)}
                          className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                        />
                      </td>
                      <td className="p-3.5">
                        <strong className="text-slate-900 block font-bold">{mod.name}</strong>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[9.5px] font-mono bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded border">
                            {mod.moduleId}
                          </span>
                          <span className="text-[9px] uppercase font-bold px-1.5 py-0.2 bg-slate-200 text-slate-700 rounded">
                            {mod.category}
                          </span>
                        </div>
                      </td>

                      <td className="p-3.5 max-w-sm text-slate-500 text-[11px]">
                        {mod.description}
                      </td>

                      {/* Enabled Toggle */}
                      <td className="p-3.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleToggleDefaultEnabled(mod.moduleId)}
                          className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                            isEnabled ? "bg-emerald-600" : "bg-slate-300"
                          }`}
                        >
                          <span
                            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                              isEnabled ? "translate-x-5" : "translate-x-0"
                            }`}
                          />
                        </button>
                      </td>

                      {/* Read Access Toggle */}
                      <td className="p-3.5 text-center">
                        <button
                          type="button"
                          disabled={!isEnabled}
                          onClick={() => handleToggleDefaultRead(mod.moduleId)}
                          className={`relative inline-flex h-6 w-11 flex-shrink-0 rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                            !isEnabled ? "opacity-30 cursor-not-allowed bg-slate-200" : isRead ? "bg-blue-600 cursor-pointer" : "bg-slate-300 cursor-pointer"
                          }`}
                        >
                          <span
                            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                              isRead && isEnabled ? "translate-x-5" : "translate-x-0"
                            }`}
                          />
                        </button>
                      </td>

                      {/* Write Access Toggle (Disabled if Read is OFF or Enabled is OFF) */}
                      <td className="p-3.5 text-center">
                        <button
                          type="button"
                          disabled={!isEnabled || !isRead}
                          onClick={() => handleToggleDefaultWrite(mod.moduleId)}
                          className={`relative inline-flex h-6 w-11 flex-shrink-0 rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                            (!isEnabled || !isRead) ? "opacity-30 cursor-not-allowed bg-slate-200" : isWrite ? "bg-indigo-600 cursor-pointer" : "bg-slate-300 cursor-pointer"
                          }`}
                        >
                          <span
                            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                              isWrite && isEnabled && isRead ? "translate-x-5" : "translate-x-0"
                            }`}
                          />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SCREEN 2 — INDIVIDUAL TENANT OVERRIDES */}
      {activeTab === "screen2" && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 animate-fade-in">
          <div className="border-b pb-4">
            <span className="text-[10px] font-black uppercase text-amber-600 tracking-wider">Screen 2 — Per-Tenant Customization</span>
            <h3 className="text-base font-extrabold text-slate-900">Individual Tenant Override Console</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Search and select a specific tenant account by Name, TPIN, or UID to apply per-tenant module access overrides.
            </p>
          </div>

          {/* Tenant Search Bar & Results Selector */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-5 space-y-3">
              <label className="text-xs font-bold text-slate-700">Find Tenant Account</label>
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search by Name, TPIN, Email, or UID..."
                  className="w-full pl-9 pr-4 py-2 bg-slate-50 border rounded-xl text-xs font-medium focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div className="max-h-64 overflow-y-auto border rounded-xl divide-y bg-slate-50/50">
                {filteredUsers.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-400 font-medium">No tenant accounts found matching search</div>
                ) : (
                  filteredUsers.slice(0, 12).map(u => {
                    const isSelected = selectedUser?.uid === u.uid;
                    return (
                      <button
                        key={u.uid}
                        onClick={() => handleSelectUser(u)}
                        className={`w-full p-3 text-left flex items-center justify-between text-xs transition-all cursor-pointer ${
                          isSelected ? "bg-amber-100/70 text-amber-950 font-bold border-l-4 border-amber-600" : "hover:bg-white text-slate-700"
                        }`}
                      >
                        <div className="truncate pr-2">
                          <strong className="block truncate">{u.name || u.email}</strong>
                          <span className="text-[10px] text-slate-400 font-mono block truncate">{u.email}</span>
                          {u.tpin && <span className="text-[9.5px] text-slate-500 font-mono block">TPIN: {u.tpin}</span>}
                        </div>
                        <span className="px-2 py-0.5 bg-slate-200 text-slate-700 text-[9px] font-bold rounded uppercase shrink-0">
                          {u.tenantType}
                        </span>
                      </button>
                    );
                  })
                )}
              </div>
            </div>

            {/* Selected Tenant Overrides Workspace */}
            <div className="md:col-span-7 space-y-4">
              {selectedUser ? (
                <div className="space-y-4">
                  <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-black uppercase text-amber-800 tracking-wider">Active Workspace Target</span>
                      <strong className="text-sm font-black text-slate-900 block">{selectedUser.name || selectedUser.email}</strong>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-slate-600 font-mono">{selectedUser.email}</span>
                        <span className="px-2 py-0.5 bg-amber-200 text-amber-900 text-[9.5px] font-bold rounded uppercase">
                          {selectedUser.tenantType}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={handleSaveTenantOverrides}
                      className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow cursor-pointer flex items-center gap-1.5 transition-all"
                    >
                      <Save className="w-4 h-4" /> Save Overrides
                    </button>
                  </div>

                  {/* Hard Invariant Banner if Agro Dealer */}
                  {selectedUser.tenantType === "agro_dealer" && (
                    <div className="bg-rose-50 border border-rose-200 p-3.5 rounded-xl text-rose-900 text-xs space-y-1">
                      <div className="flex items-center gap-1.5 font-bold text-rose-700">
                        <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" /> Hard Invariant Active
                      </div>
                      <p className="text-[11px] text-rose-800">
                        Agro-Dealer tenants can NEVER be assigned super_admin role or granted Platform Admin Console permissions under any condition.
                      </p>
                    </div>
                  )}

                  {invariantError && (
                    <div className="bg-rose-100 border border-rose-300 p-3.5 text-rose-900 font-black text-xs rounded-xl">
                      ⚠️ {invariantError}
                    </div>
                  )}

                  {/* Overrides Table */}
                  <div className="border rounded-2xl overflow-hidden max-h-[500px] overflow-y-auto">
                    <table className="w-full text-left text-xs bg-white text-slate-800">
                      <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50 border-b">
                        <tr>
                          <th className="p-3">Module</th>
                          <th className="p-3">Status / Source</th>
                          <th className="p-3 text-center">Override</th>
                          <th className="p-3 text-center">Enabled</th>
                          <th className="p-3 text-center">Read</th>
                          <th className="p-3 text-center">Write</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y font-medium text-slate-700">
                        {screen2EligibleModules.map(mod => {
                          const overrideState = tenantOverrides[mod.moduleId];
                          const hasOverride = overrideState !== undefined && overrideState !== null;
                          const globalDef = getGlobalDefaultState(selectedUser.tenantType, mod.moduleId);
                          const currentAccess = hasOverride ? overrideState : globalDef;

                          return (
                            <tr key={mod.moduleId} className={hasOverride ? "bg-amber-50/40" : ""}>
                              <td className="p-3">
                                <strong className="text-slate-900 block font-bold">{mod.name}</strong>
                                <span className="text-[9.5px] font-mono text-slate-400">{mod.moduleId}</span>
                              </td>

                              <td className="p-3">
                                {hasOverride ? (
                                  <span className="px-2 py-0.5 bg-amber-100 text-amber-800 border border-amber-200 text-[10px] font-bold rounded-lg">
                                    Custom Override
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 bg-slate-100 text-slate-600 border border-slate-200 text-[10px] font-medium rounded-lg">
                                    Inherited (Global: {globalDef.enabled ? "ON" : "OFF"})
                                  </span>
                                )}
                              </td>

                              {/* Override Switch */}
                              <td className="p-3 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleToggleTenantOverrideActive(mod.moduleId)}
                                  className={`px-2.5 py-1 text-[10px] font-bold rounded-lg transition-all cursor-pointer ${
                                    hasOverride
                                      ? "bg-amber-600 text-white shadow-xs"
                                      : "bg-slate-200 text-slate-600 hover:bg-slate-300"
                                  }`}
                                >
                                  {hasOverride ? "Active" : "Inherit"}
                                </button>
                              </td>

                              {/* Custom Enabled Toggle */}
                              <td className="p-3 text-center">
                                <button
                                  type="button"
                                  disabled={!hasOverride}
                                  onClick={() => handleUpdateTenantOverrideState(mod.moduleId, "enabled", !currentAccess.enabled)}
                                  className={`relative inline-flex h-5 w-9 flex-shrink-0 rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out ${
                                    !hasOverride ? "opacity-30 cursor-not-allowed bg-slate-200" : currentAccess.enabled ? "bg-amber-600 cursor-pointer" : "bg-slate-300 cursor-pointer"
                                  }`}
                                >
                                  <span
                                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                                      currentAccess.enabled && hasOverride ? "translate-x-4" : "translate-x-0"
                                    }`}
                                  />
                                </button>
                              </td>

                              {/* Custom Read Toggle */}
                              <td className="p-3 text-center">
                                <button
                                  type="button"
                                  disabled={!hasOverride || !currentAccess.enabled}
                                  onClick={() => handleUpdateTenantOverrideState(mod.moduleId, "read", !currentAccess.read)}
                                  className={`relative inline-flex h-5 w-9 flex-shrink-0 rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out ${
                                    (!hasOverride || !currentAccess.enabled) ? "opacity-30 cursor-not-allowed bg-slate-200" : currentAccess.read ? "bg-blue-600 cursor-pointer" : "bg-slate-300 cursor-pointer"
                                  }`}
                                >
                                  <span
                                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                                      currentAccess.read && hasOverride && currentAccess.enabled ? "translate-x-4" : "translate-x-0"
                                    }`}
                                  />
                                </button>
                              </td>

                              {/* Custom Write Toggle */}
                              <td className="p-3 text-center">
                                <button
                                  type="button"
                                  disabled={!hasOverride || !currentAccess.enabled || !currentAccess.read}
                                  onClick={() => handleUpdateTenantOverrideState(mod.moduleId, "write", !currentAccess.write)}
                                  className={`relative inline-flex h-5 w-9 flex-shrink-0 rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out ${
                                    (!hasOverride || !currentAccess.enabled || !currentAccess.read) ? "opacity-30 cursor-not-allowed bg-slate-200" : currentAccess.write ? "bg-indigo-600 cursor-pointer" : "bg-slate-300 cursor-pointer"
                                  }`}
                                >
                                  <span
                                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                                      currentAccess.write && hasOverride && currentAccess.enabled && currentAccess.read ? "translate-x-4" : "translate-x-0"
                                    }`}
                                  />
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="p-12 text-center border-2 border-dashed rounded-2xl space-y-3 bg-slate-50/50">
                  <UserCheck className="w-10 h-10 text-slate-300 mx-auto" />
                  <h4 className="font-bold text-slate-700 text-sm">No Tenant Account Selected</h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Select a tenant from the left search panel to view and customize their individual module access overrides.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SCREEN 3 — MODULE REGISTRY */}
      {activeTab === "screen3" && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-4">
            <div>
              <span className="text-[10px] font-black uppercase text-emerald-600 tracking-wider">Screen 3 — Platform Module Registry</span>
              <h3 className="text-base font-extrabold text-slate-900">Self-Populating Module Registry Docs</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Every module in Mabala must be registered here (<code className="bg-slate-100 px-1 py-0.5 text-[10.5px] rounded">platformConfig/moduleRegistry/modules</code>). Adding new modules automatically populates the toggle UI!
              </p>
            </div>
            <button
              onClick={() => setShowAddModuleModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow cursor-pointer transition-all shrink-0"
            >
              <Plus className="w-4 h-4" /> Register New Module
            </button>
          </div>

          {/* Registry Table */}
          <div className="overflow-x-auto border rounded-2xl">
            <table className="w-full text-left text-xs bg-white text-slate-800">
              <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50 border-b">
                <tr>
                  <th className="p-3.5">Module ID & Name</th>
                  <th className="p-3.5">Description</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Eligible Tenant Types</th>
                  <th className="p-3.5 text-center">Hard-Locked</th>
                </tr>
              </thead>
              <tbody className="divide-y font-medium text-slate-700">
                {moduleRegistry.map(mod => (
                  <tr key={mod.moduleId} className="hover:bg-slate-50">
                    <td className="p-3.5">
                      <strong className="text-slate-900 block font-bold text-xs">{mod.name}</strong>
                      <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200 mt-0.5 inline-block">
                        {mod.moduleId}
                      </span>
                    </td>

                    <td className="p-3.5 max-w-xs text-slate-500 text-[11px]">
                      {mod.description}
                    </td>

                    <td className="p-3.5">
                      <span className="px-2 py-0.5 bg-slate-100 text-slate-800 font-bold uppercase text-[9.5px] rounded">
                        {mod.category}
                      </span>
                    </td>

                    <td className="p-3.5">
                      <div className="flex flex-wrap gap-1">
                        {mod.eligibleTenantTypes.length === 0 ? (
                          <span className="text-[9.5px] font-mono text-rose-600 font-bold bg-rose-50 px-1.5 py-0.5 rounded">
                            Platform Admin Only
                          </span>
                        ) : (
                          mod.eligibleTenantTypes.map(t => (
                            <span key={t} className="text-[9.5px] font-mono bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded border">
                              {t}
                            </span>
                          ))
                        )}
                      </div>
                    </td>

                    <td className="p-3.5 text-center">
                      {mod.hardLocked ? (
                        <span className="px-2 py-0.5 bg-rose-100 text-rose-800 font-bold text-[10px] rounded-full inline-flex items-center gap-1">
                          <Lock className="w-3 h-3" /> Hard Locked
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold text-[10px] rounded-full">
                          Configurable
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* AUDIT LOG TAB */}
      {activeTab === "audit" && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 animate-fade-in">
          <div className="border-b pb-4">
            <span className="text-[10px] font-black uppercase text-emerald-600 tracking-wider">Security & Governance</span>
            <h3 className="text-base font-extrabold text-slate-900">Entitlement Audit Logs</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Historical record of all module entitlement changes committed to <code className="bg-slate-100 px-1 py-0.5 text-[10.5px] rounded">platformConfig/entitlementAuditLog</code>.
            </p>
          </div>

          <div className="overflow-x-auto border rounded-2xl">
            <table className="w-full text-left text-xs bg-white text-slate-800">
              <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50 border-b">
                <tr>
                  <th className="p-3.5">Timestamp</th>
                  <th className="p-3.5">Scope / Target</th>
                  <th className="p-3.5">Module ID</th>
                  <th className="p-3.5">Type</th>
                  <th className="p-3.5">Admin UID</th>
                </tr>
              </thead>
              <tbody className="divide-y font-medium text-slate-700">
                {auditLogs.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-400">
                      No entitlement audit logs recorded yet.
                    </td>
                  </tr>
                ) : (
                  auditLogs.slice(0, 30).map((log, idx) => (
                    <tr key={log.id || idx} className="hover:bg-slate-50">
                      <td className="p-3.5 font-mono text-[11px] text-slate-600">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>

                      <td className="p-3.5 font-bold">
                        {log.tenantTypeCode ? (
                          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-mono text-[10px]">
                            Type: {log.tenantTypeCode}
                          </span>
                        ) : log.tenantId ? (
                          <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded font-mono text-[10px]">
                            Tenant: {log.tenantId.substring(0, 10)}...
                          </span>
                        ) : (
                          "Global"
                        )}
                      </td>

                      <td className="p-3.5 font-mono text-emerald-800 font-bold">
                        {log.moduleId}
                      </td>

                      <td className="p-3.5">
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[10px] uppercase font-bold">
                          {log.type || "entitlement_update"}
                        </span>
                      </td>

                      <td className="p-3.5 font-mono text-slate-400 text-[10px]">
                        {log.uid}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL: REGISTER NEW MODULE */}
      {showAddModuleModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <form onSubmit={handleRegisterNewModule} className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl border animate-fade-in">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-600" /> Register New Platform Module
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModuleModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">Module ID (e.g. soil_moisture_telemetry)</label>
                <input
                  type="text"
                  required
                  value={newModuleId}
                  onChange={e => setNewModuleId(e.target.value)}
                  placeholder="e.g. soil_moisture_telemetry"
                  className="w-full text-xs p-2.5 border rounded-xl font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">Module Display Name</label>
                <input
                  type="text"
                  required
                  value={newModuleName}
                  onChange={e => setNewModuleName(e.target.value)}
                  placeholder="e.g. Soil Moisture Telemetry"
                  className="w-full text-xs p-2.5 border rounded-xl focus:outline-none focus:border-emerald-500 font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">Description (Helper Text)</label>
                <textarea
                  rows={2}
                  value={newModuleDesc}
                  onChange={e => setNewModuleDesc(e.target.value)}
                  placeholder="Brief explanation of module capabilities..."
                  className="w-full text-xs p-2.5 border rounded-xl focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Category</label>
                  <select
                    value={newModuleCategory}
                    onChange={e => setNewModuleCategory(e.target.value as any)}
                    className="w-full text-xs p-2.5 border rounded-xl bg-white font-bold"
                  >
                    <option value="agriculture">Agriculture</option>
                    <option value="finance">Finance</option>
                    <option value="commerce">Commerce</option>
                    <option value="core">Core</option>
                    <option value="admin_only">Admin Only</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Hard Locked (Admin Only)</label>
                  <label className="flex items-center gap-2 pt-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newModuleHardLocked}
                      onChange={e => setNewModuleHardLocked(e.target.checked)}
                      className="rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span className="text-xs font-bold text-slate-700">Lock to Admin</span>
                  </label>
                </div>
              </div>

              {!newModuleHardLocked && (
                <div className="space-y-1 pt-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Eligible Tenant Types</label>
                  <div className="flex flex-wrap gap-3 pt-1">
                    {(["agro_dealer", "institution_supplier", "farmer"] as TenantTypeCode[]).map(t => (
                      <label key={t} className="flex items-center gap-1.5 cursor-pointer text-xs font-semibold text-slate-700">
                        <input
                          type="checkbox"
                          checked={newModuleEligibleTypes.includes(t)}
                          onChange={e => {
                            if (e.target.checked) {
                              setNewModuleEligibleTypes(prev => [...prev, t]);
                            } else {
                              setNewModuleEligibleTypes(prev => prev.filter(x => x !== t));
                            }
                          }}
                          className="rounded text-emerald-600"
                        />
                        {t}
                      </label>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t">
              <button
                type="button"
                onClick={() => setShowAddModuleModal(false)}
                className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow cursor-pointer"
              >
                Register Module
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

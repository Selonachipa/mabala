import React, { useState, useEffect } from "react";
import {
  PlatformInvoice,
  fetchPlatformInvoices
} from "../services/platformInvoiceService";
import {
  InvoiceReminderLog,
  calculateDaysOverdue,
  dispatchInvoiceEmailReminder,
  runAutomatedDailyInvoiceScan,
  fetchReminderLogs
} from "../services/invoiceReminderService";
import DirectInvoicePayModal from "./DirectInvoicePayModal";
import {
  Send,
  Clock,
  AlertTriangle,
  Mail,
  CheckCircle2,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  FileText,
  DollarSign,
  Calendar
} from "lucide-react";

export default function InvoiceReminderConsole() {
  const [invoices, setInvoices] = useState<PlatformInvoice[]>([]);
  const [reminderLogs, setReminderLogs] = useState<InvoiceReminderLog[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [scanReport, setScanReport] = useState<string | null>(null);
  const [selectedPayInvoice, setSelectedPayInvoice] = useState<PlatformInvoice | null>(null);
  const [showPayModal, setShowPayModal] = useState(false);
  const [previewLog, setPreviewLog] = useState<InvoiceReminderLog | null>(null);

  const loadData = async () => {
    const invs = await fetchPlatformInvoices();
    setInvoices(invs);
    setReminderLogs(fetchReminderLogs());
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRunScan = async () => {
    setIsScanning(true);
    setScanReport(null);
    try {
      const result = await runAutomatedDailyInvoiceScan();
      setScanReport(
        `Automated Scan Complete: ${result.scannedCount} invoices checked, ${result.remindersSentCount} email reminders issued. Total pending value: ZK ${result.totalPendingAmountZK.toLocaleString()} (Overdue: ZK ${result.totalOverdueAmountZK.toLocaleString()}).`
      );
      await loadData();
    } catch (err) {
      setScanReport("Scan execution error.");
    } finally {
      setIsScanning(false);
    }
  };

  const handleSendSingleReminder = async (invoice: PlatformInvoice) => {
    const log = await dispatchInvoiceEmailReminder(invoice, true);
    await loadData();
    alert(`Email reminder sent to ${log.recipientEmail}!\nSubject: ${log.emailSubject}`);
  };

  const pendingInvoices = invoices.filter(i => i.status === "PENDING");

  return (
    <div className="space-y-6 font-sans">
      {/* Header Banner */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-2xl">
              <Mail className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-black tracking-tight text-white">Automated Invoice Reminders & Direct Pay Link Engine</h3>
              <p className="text-xs text-slate-400 font-medium mt-0.5">
                Scans pending & overdue platform invoices, sends scheduled email reminders with days overdue counts and embedded Lipila payment links.
              </p>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={handleRunScan}
          disabled={isScanning}
          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50 shrink-0"
        >
          <RefreshCw className={`w-4 h-4 ${isScanning ? "animate-spin" : ""}`} />
          <span>{isScanning ? "Scanning Invoices..." : "Run Daily Reminder Scan"}</span>
        </button>
      </div>

      {scanReport && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-2xl text-xs font-bold flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{scanReport}</span>
        </div>
      )}

      {/* Pending / Overdue Invoices List */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
        <div className="flex justify-between items-center border-b border-slate-100 pb-3">
          <div>
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-500" />
              Pending & Overdue Platform Invoices ({pendingInvoices.length})
            </h4>
            <p className="text-[11px] text-slate-500 font-medium">
              Invoices requiring payment or scheduled reminder dispatches.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-800">
            <thead className="bg-slate-50 font-black text-[9px] text-slate-400 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3">Invoice Number</th>
                <th className="p-3">Recipient</th>
                <th className="p-3">Due Date</th>
                <th className="p-3">Days Overdue</th>
                <th className="p-3">Amount Pending</th>
                <th className="p-3">Last Reminder Dispatched</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {pendingInvoices.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400 font-bold">
                    No pending or overdue invoices found.
                  </td>
                </tr>
              ) : (
                pendingInvoices.map(inv => {
                  const { daysOverdue, isOverdue } = calculateDaysOverdue(inv.dueDate);
                  return (
                    <tr key={inv.id} className="hover:bg-slate-50">
                      <td className="p-3 font-mono font-bold text-slate-900">{inv.invoiceNumber}</td>
                      <td className="p-3">
                        <div className="font-bold text-slate-800">{inv.recipientTenantName}</div>
                        <div className="text-[10px] text-slate-400">{inv.recipientEmail || "finance@mabala.ag"}</div>
                      </td>
                      <td className="p-3 font-mono text-[11px] text-slate-600">{inv.dueDate}</td>
                      <td className="p-3">
                        <span className={`px-2.5 py-0.5 rounded-full text-[9.5px] font-black ${
                          isOverdue ? "bg-rose-100 text-rose-800" : "bg-amber-100 text-amber-800"
                        }`}>
                          {daysOverdue === 0 ? "0 (Due Soon)" : `${daysOverdue} Days Overdue`}
                        </span>
                      </td>
                      <td className="p-3 font-mono font-black text-emerald-700">ZK {inv.totalAmount.toLocaleString()}</td>
                      <td className="p-3 font-mono text-[10.5px] text-slate-500">
                        {inv.lastReminderSentAt
                          ? new Date(inv.lastReminderSentAt).toLocaleString()
                          : "Not Sent Yet"}
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleSendSingleReminder(inv)}
                            className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-extrabold text-[10.5px] rounded-xl transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Send className="w-3 h-3" />
                            <span>Send Email</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedPayInvoice(inv);
                              setShowPayModal(true);
                            }}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[10.5px] rounded-xl shadow-xs transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>Test Pay Link</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reminder Email Logs & Dispatch History */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
        <div className="flex justify-between items-center border-b border-slate-100 pb-3">
          <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 flex items-center gap-2">
            <Mail className="w-4 h-4 text-indigo-600" />
            Sent Reminder Dispatch History
          </h4>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-800">
            <thead className="bg-slate-50 font-black text-[9px] text-slate-400 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3">Timestamp</th>
                <th className="p-3">Recipient</th>
                <th className="p-3">Invoice #</th>
                <th className="p-3">Pending Amount</th>
                <th className="p-3">Days Overdue Tag</th>
                <th className="p-3">Email Content</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {reminderLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400 font-bold">
                    No reminder logs recorded yet. Click "Run Daily Reminder Scan" to trigger.
                  </td>
                </tr>
              ) : (
                reminderLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50">
                    <td className="p-3 font-mono text-[11px] text-slate-500">
                      {new Date(log.sentAt).toLocaleString()}
                    </td>
                    <td className="p-3 font-bold text-slate-800">
                      <div>{log.recipientTenantName}</div>
                      <div className="text-[10px] text-slate-400">{log.recipientEmail}</div>
                    </td>
                    <td className="p-3 font-mono text-slate-900 font-bold">{log.invoiceNumber}</td>
                    <td className="p-3 font-mono font-black text-emerald-700">ZK {log.amountPending.toLocaleString()}</td>
                    <td className="p-3 font-bold">
                      <span className={`px-2 py-0.5 rounded-full text-[9.5px] uppercase ${
                        log.daysOverdue > 0 ? "bg-rose-100 text-rose-800" : "bg-sky-100 text-sky-800"
                      }`}>
                        {log.daysOverdue} Days Overdue
                      </span>
                    </td>
                    <td className="p-3">
                      <button
                        type="button"
                        onClick={() => setPreviewLog(log)}
                        className="text-xs font-bold text-indigo-600 hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>View Email Preview</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Email Body Preview Modal */}
      {previewLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs font-sans">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-sm text-slate-900">Dispatched Email Preview</h3>
              <button
                type="button"
                onClick={() => setPreviewLog(null)}
                className="text-slate-400 hover:text-slate-600 font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-2 bg-slate-50 rounded-xl">
                <span className="font-bold text-slate-500">Subject: </span>
                <span className="font-bold text-slate-900">{previewLog.emailSubject}</span>
              </div>
              <div className="p-3 bg-slate-900 text-emerald-400 font-mono text-[11px] rounded-xl overflow-x-auto whitespace-pre-wrap max-h-64 leading-relaxed">
                {previewLog.emailBody}
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setPreviewLog(null)}
                className="px-4 py-2 bg-slate-800 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Direct Pay Modal */}
      <DirectInvoicePayModal
        isOpen={showPayModal}
        invoice={selectedPayInvoice}
        onClose={() => setShowPayModal(false)}
        onPaymentSuccess={() => {
          loadData();
        }}
      />
    </div>
  );
}

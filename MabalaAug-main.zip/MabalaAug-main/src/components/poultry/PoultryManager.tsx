import React, { useState } from "react";
import { PoultryBatch } from "./types";
import PoultryOverview from "./PoultryOverview";
import BroilerModule from "./BroilerModule";
import LayerModule from "./LayerModule";
import VillageModule from "./VillageModule";
import PoultryRegistry from "./PoultryRegistry";
import PoultryFeedManager from "./PoultryFeedManager";
import PoultryMedicationManager from "./PoultryMedicationManager";
import PoultryPnLManager from "./PoultryPnLManager";
import BatchHealthSummary from "./BatchHealthSummary";
import PrintableDocument from "./PrintableDocument";
import { ChevronRight, Home, Flame, Egg, Sprout, SlidersHorizontal, Package, Stethoscope, PieChart, HeartPulse } from "lucide-react";
import { SevereAlert } from "../WeatherWidget";
import { Supplier, ExpenseTransaction } from "../../types";

interface PoultryManagerProps {
  batches: PoultryBatch[];
  currencySymbol: string;
  onAddBatch: (batch: PoultryBatch) => void;
  onUpdateBatch: (batch: PoultryBatch) => void;
  onDeleteBatch: (id: string) => void;
  accounts: any[];
  setAccounts: (accs: any[]) => void;
  onAddExpense?: (tx: any) => void;
  onAddSupplier?: (sup: Supplier) => void;
  suppliers?: Supplier[];
  expenses?: ExpenseTransaction[];
  writeAuditLog: (action: string, module: string, target: string, details: string) => void;
  activeFarm: any;
  onShowDocument?: (type: "certificate" | "receipt", data: any) => void;
  employees?: any[];
  weatherAlerts?: SevereAlert[];
  isReadonly?: boolean;
}

type SubTab = "overview" | "broilers" | "layers" | "village" | "feed" | "medication" | "health-summary" | "pnl" | "registry";

export default function PoultryManager({
  batches,
  currencySymbol,
  onAddBatch,
  onUpdateBatch,
  onDeleteBatch,
  accounts,
  setAccounts,
  onAddExpense,
  onAddSupplier,
  suppliers = [],
  expenses = [],
  writeAuditLog,
  activeFarm,
  onShowDocument,
  employees = [],
  weatherAlerts = [],
  isReadonly = false,
}: PoultryManagerProps) {
  const [activeSubTab, setActiveSubTab] = useState<SubTab>("overview");

  // Printable Document overlay state
  const [printableDoc, setPrintableDoc] = useState<{
    isOpen: boolean;
    type: "certificate" | "receipt";
    data: any;
  }>({
    isOpen: false,
    type: "certificate",
    data: null
  });

  const handleShowDocument = (type: "certificate" | "receipt", data: any) => {
    setPrintableDoc({
      isOpen: true,
      type,
      data
    });
  };

  return (
    <div className="space-y-6" id="poultry-manager-root">
      {/* Module Navigation Tabs */}
      {isReadonly && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span>🔒</span>
            <span><strong>Poultry Records Locked (Read-Only Mode):</strong> Credits depleted. Existing flocks, feed logs, and mortality records cannot be edited or deleted.</span>
          </div>
        </div>
      )}
      <div className="flex flex-wrap border-b border-slate-100 bg-white p-1.5 rounded-2xl shadow-xs gap-1">
        <button
          onClick={() => setActiveSubTab("overview")}
          className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === "overview" 
              ? "bg-slate-900 text-white shadow-sm" 
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <Home size={14} />
          Overview
        </button>

        <button
          onClick={() => setActiveSubTab("broilers")}
          className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === "broilers" 
              ? "bg-amber-500 text-white shadow-sm" 
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <Flame size={14} />
          Broilers
        </button>

        <button
          onClick={() => setActiveSubTab("layers")}
          className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === "layers" 
              ? "bg-sky-500 text-white shadow-sm" 
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <Egg size={14} />
          Layers
        </button>

        <button
          onClick={() => setActiveSubTab("village")}
          className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === "village" 
              ? "bg-emerald-600 text-white shadow-sm" 
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <Sprout size={14} />
          Village Chickens
        </button>

        <button
          onClick={() => setActiveSubTab("feed")}
          className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === "feed" 
              ? "bg-amber-600 text-white shadow-sm" 
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <Package size={14} />
          Feed Management
        </button>

        <button
          onClick={() => setActiveSubTab("medication")}
          className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === "medication" 
              ? "bg-rose-600 text-white shadow-sm" 
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <Stethoscope size={14} />
          Medication Tracking
        </button>

        <button
          onClick={() => setActiveSubTab("health-summary")}
          className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === "health-summary" 
              ? "bg-rose-700 text-white shadow-sm" 
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <HeartPulse size={14} />
          Batch Health Summary
        </button>

        <button
          onClick={() => setActiveSubTab("pnl")}
          className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === "pnl" 
              ? "bg-emerald-700 text-white shadow-sm" 
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <PieChart size={14} />
          P&L & Cost Center
        </button>

        <button
          onClick={() => setActiveSubTab("registry")}
          className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === "registry" 
              ? "bg-slate-900 text-white shadow-sm" 
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <SlidersHorizontal size={14} />
          Registry
        </button>
      </div>

      {/* Render Sub-Module Content */}
      <div className="animate-fade-in">
        {activeSubTab === "overview" && (
          <PoultryOverview
            batches={batches}
            currencySymbol={currencySymbol}
            onNavigateToBroilers={() => setActiveSubTab("broilers")}
            onNavigateToLayers={() => setActiveSubTab("layers")}
            onNavigateToVillage={() => setActiveSubTab("village")}
            weatherAlerts={weatherAlerts}
            writeAuditLog={writeAuditLog}
            onUpdateBatch={onUpdateBatch}
          />
        )}

        {activeSubTab === "broilers" && (
          <BroilerModule
            batches={batches}
            currencySymbol={currencySymbol}
            onAddBatch={onAddBatch}
            onUpdateBatch={onUpdateBatch}
            onDeleteBatch={onDeleteBatch}
            accounts={accounts}
            setAccounts={setAccounts}
            onAddExpense={onAddExpense}
            onAddSupplier={onAddSupplier}
            suppliers={suppliers}
            expenses={expenses}
            writeAuditLog={writeAuditLog}
            activeFarm={activeFarm}
            onShowDocument={handleShowDocument}
            employees={employees}
          />
        )}

        {activeSubTab === "layers" && (
          <LayerModule
            batches={batches}
            currencySymbol={currencySymbol}
            onAddBatch={onAddBatch}
            onUpdateBatch={onUpdateBatch}
            onDeleteBatch={onDeleteBatch}
            accounts={accounts}
            setAccounts={setAccounts}
            onAddExpense={onAddExpense}
            onAddSupplier={onAddSupplier}
            suppliers={suppliers}
            expenses={expenses}
            writeAuditLog={writeAuditLog}
            activeFarm={activeFarm}
            onShowDocument={handleShowDocument}
            employees={employees}
          />
        )}

        {activeSubTab === "village" && (
          <VillageModule
            batches={batches}
            currencySymbol={currencySymbol}
            onAddBatch={onAddBatch}
            onUpdateBatch={onUpdateBatch}
            onDeleteBatch={onDeleteBatch}
            accounts={accounts}
            setAccounts={setAccounts}
            onAddExpense={onAddExpense}
            onAddSupplier={onAddSupplier}
            suppliers={suppliers}
            expenses={expenses}
            writeAuditLog={writeAuditLog}
            activeFarm={activeFarm}
            onShowDocument={handleShowDocument}
            employees={employees}
          />
        )}

        {activeSubTab === "feed" && (
          <PoultryFeedManager
            batches={batches}
            currencySymbol={currencySymbol}
            onUpdateBatch={onUpdateBatch}
            accounts={accounts}
            setAccounts={setAccounts}
            onAddExpense={onAddExpense}
            onAddSupplier={onAddSupplier}
            suppliers={suppliers}
            writeAuditLog={writeAuditLog}
            employees={employees}
            activeFarm={activeFarm}
          />
        )}

        {activeSubTab === "medication" && (
          <PoultryMedicationManager
            batches={batches}
            currencySymbol={currencySymbol}
            onUpdateBatch={onUpdateBatch}
            accounts={accounts}
            setAccounts={setAccounts}
            writeAuditLog={writeAuditLog}
            employees={employees}
            onAddExpense={onAddExpense}
            onAddSupplier={onAddSupplier}
            suppliers={suppliers}
            activeFarm={activeFarm}
          />
        )}

        {activeSubTab === "health-summary" && (
          <BatchHealthSummary
            batches={batches}
            onUpdateBatch={onUpdateBatch}
            writeAuditLog={writeAuditLog}
            employees={employees}
          />
        )}

        {activeSubTab === "pnl" && (
          <PoultryPnLManager
            batches={batches}
            currencySymbol={currencySymbol}
            expenses={expenses}
          />
        )}

        {activeSubTab === "registry" && (
          <PoultryRegistry
            batches={batches}
            currencySymbol={currencySymbol}
            onUpdateBatch={onUpdateBatch}
            onDeleteBatch={onDeleteBatch}
            writeAuditLog={writeAuditLog}
            accounts={accounts}
            setAccounts={setAccounts}
            employees={employees}
            expenses={expenses}
          />
        )}
      </div>

      {/* Printable Document Modal Overlay */}
      {printableDoc.isOpen && printableDoc.data && (
        <PrintableDocument
          isOpen={printableDoc.isOpen}
          onClose={() => setPrintableDoc({ ...printableDoc, isOpen: false })}
          type={printableDoc.type}
          data={printableDoc.data}
        />
      )}
    </div>
  );
}

import React, { useState, useMemo } from "react";
import { PoultryBatch, PoultryFeedLog, PoultryHealthEvent, PoultryMortalityLog, PoultrySalesLog, EggCollection, EggSale } from "./types";
import EggGradeRatioPieChart from "./EggGradeRatioPieChart";
import DailyEggTrendChart from "./DailyEggTrendChart";
import FcrMetricCard from "./FcrMetricCard";
import BatchCostBreakdownSummary from "./BatchCostBreakdownSummary";
import { 
  Plus, Sprout, Calendar, MapPin, DollarSign, Scale, Trash2, 
  TrendingUp, Skull, ShieldAlert, CheckCircle, ChevronRight, X, Sparkles, BookOpen, Egg, ShoppingBag, Home, Building2, PieChart
} from "lucide-react";
import { Supplier, ExpenseTransaction } from "../../types";
import UnifiedSupplierModal from "../common/UnifiedSupplierModal";

interface VillageModuleProps {
  batches: PoultryBatch[];
  currencySymbol: string;
  onAddBatch: (batch: PoultryBatch) => void;
  onUpdateBatch: (batch: PoultryBatch) => void;
  onDeleteBatch: (id: string) => void;
  accounts: any[];
  setAccounts: (accs: any[]) => void;
  onAddExpense?: (tx: any) => void;
  onAddSupplier?: (sup: Supplier) => void;
  suppliers?: Supplier[];
  expenses?: ExpenseTransaction[];
  writeAuditLog: (action: string, module: string, target: string, details: string) => void;
  activeFarm: any;
  onShowDocument: (type: "certificate" | "receipt", data: any) => void;
  employees?: any[];
}

export default function VillageModule({
  batches,
  currencySymbol,
  onAddBatch,
  onUpdateBatch,
  onDeleteBatch,
  accounts,
  setAccounts,
  onAddExpense,
  onAddSupplier,
  suppliers = [],
  expenses = [],
  writeAuditLog,
  activeFarm,
  onShowDocument,
  employees = []
}: VillageModuleProps) {
  const villageBatches = useMemo(() => batches.filter(b => b.poultryType === "village" || (b.poultryType as string) === "indigenous"), [batches]);

  // Modals state
  const [isRegWizardOpen, setIsRegWizardOpen] = useState(false);
  const [wizardStep, setWizardStep] = useState(1);
  const [selectedBatch, setSelectedBatch] = useState<PoultryBatch | null>(null);
  const [showSupplierModal, setShowSupplierModal] = useState(false);

  // Active Logging Modal states
  const [activeLogType, setActiveLogType] = useState<"feed" | "health" | "mortality" | "weigh" | "sell_birds" | "log_eggs" | "sell_eggs" | "p_and_l" | "edit_price" | "edit_headcount" | null>(null);

  // New Batch Form State
  const [newBatch, setNewBatch] = useState({
    breed: "Boschveld",
    dateAcquired: new Date().toISOString().split("T")[0],
    source: "",
    customSource: "",
    initialHeadcount: 0,
    acquisitionCostPerBird: 0,
    photoUrl: "",
    currentMarketPricePerBird: 0,
  });

  // Action Form States
  const [feedForm, setFeedForm] = useState({
    date: new Date().toISOString().split("T")[0],
    feedType: "",
    quantityKg: 0,
    cost: 0,
    fedBy: ""
  });

  const [editHeadcountValue, setEditHeadcountValue] = useState(0);
  const [editHeadcountReason, setEditHeadcountReason] = useState("Manual audit correction");

  const [healthForm, setHealthForm] = useState({
    date: new Date().toISOString().split("T")[0],
    type: "vaccination" as "vaccination" | "treatment",
    product: "",
    cost: 0,
    notes: "",
    withdrawalPeriodDays: 0,
    administeredBy: ""
  });

  const [mortalityForm, setMortalityForm] = useState({
    date: new Date().toISOString().split("T")[0],
    count: 0,
    cause: "Disease" as any,
    notes: ""
  });

  const [weighForm, setWeighForm] = useState({
    date: new Date().toISOString().split("T")[0],
    sampleSize: 0,
    averageWeightKg: 0,
    remarks: ""
  });

  const [sellBirdsForm, setSellBirdsForm] = useState({
    date: new Date().toISOString().split("T")[0],
    buyerName: "",
    quantity: 0,
    sellBy: "bird" as "bird" | "weight",
    pricePerUnit: 0,
    averageWeightKg: 0,
    paymentMethod: "Cash",
  });

  const [eggCollectionForm, setEggCollectionForm] = useState({
    date: new Date().toISOString().split("T")[0],
    totalCollected: 0,
    brokenCount: 0,
    large: 0,
    medium: 0,
    small: 0,
    ungraded: 0,
    useGrades: true,
  });

  const [eggSaleForm, setEggSaleForm] = useState({
    date: new Date().toISOString().split("T")[0],
    grade: "medium" as "large" | "medium" | "small" | "ungraded",
    quantity: 0,
    sellUnit: "tray" as "egg" | "tray",
    pricePerUnit: 0,
    buyerName: "",
    paymentMethod: "Cash",
  });

  const [marketPriceForm, setMarketPriceForm] = useState({
    price: 0
  });

  // Helper: auto-generate batch name
  const suggestBatchName = () => {
    const count = villageBatches.length + 1;
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const now = new Date();
    return `Village Batch #${count} – ${months[now.getMonth()]} ${now.getFullYear()}`;
  };

  // Helper: compute age in days
  const getAgeInDays = (dateAcquired: string) => {
    const diff = Date.now() - new Date(dateAcquired).getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    return days < 0 ? 0 : days;
  };

  // Double-Entry Ledger Poster
  const postLedger = (debitCode: string, creditCode: string, amount: number) => {
    if (isNaN(amount) || amount <= 0) return;
    setAccounts(accounts.map(acc => {
      let bal = acc.balance;
      if (acc.code === debitCode) bal += amount;
      if (acc.code === creditCode) bal -= amount;
      return { ...acc, balance: bal };
    }));
  };

  // Step 1 wizard next
  const handleWizardNext = () => {
    setWizardStep(2);
  };

  // Completed wizard save
  const handleCreateBatch = () => {
    const finalSource = (newBatch.source === "Other (Custom)" ? newBatch.customSource : newBatch.source) || "Mabala Breeding Centre";
    const totalCost = newBatch.initialHeadcount * newBatch.acquisitionCostPerBird;
    
    const batchId = `VIL-${Date.now().toString().slice(-6)}`;
    const batchName = suggestBatchName();

    // Auto-register Supplier if not present
    let matchedSup = suppliers.find(s => s.name.toLowerCase() === finalSource.trim().toLowerCase());
    let supplierId = matchedSup?.id;

    if (!matchedSup && onAddSupplier) {
      supplierId = `SUP-VILLAGE-${Date.now()}`;
      const newSup: Supplier = {
        id: supplierId,
        name: finalSource.trim(),
        contactPerson: "Livestock Coordinator",
        phone: "0972000333",
        email: "",
        address: "Zambia Indigenous Poultry Hub",
        tpin: "1002345678",
        category: "Indigenous Poultry & Birds",
        notes: `Auto-registered from Village Batch ${batchName} acquisition on ${newBatch.dateAcquired}`,
        farmId: activeFarm?.id,
        tenantId: activeFarm?.tenantId
      };
      onAddSupplier(newSup);
    }

    const created: PoultryBatch = {
      id: batchId,
      batchId,
      batchName,
      poultryType: "village" as any,
      breed: newBatch.breed,
      dateAcquired: newBatch.dateAcquired,
      source: finalSource,
      initialHeadcount: Number(newBatch.initialHeadcount),
      currentHeadcount: Number(newBatch.initialHeadcount),
      acquisitionCostTotal: totalCost,
      acquisitionCostPerBird: Number(newBatch.acquisitionCostPerBird),
      currentMarketPricePerBird: Number(newBatch.currentMarketPricePerBird),
      currentBatchValuation: Number(newBatch.initialHeadcount) * Number(newBatch.currentMarketPricePerBird),
      cumulativeFeedCost: 0,
      cumulativeHealthCost: 0,
      cumulativeMortalityLoss: 0,
      status: "active",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: activeFarm?.ownerName || "Operator",
      tenantId: activeFarm?.tenantId || "tenant-1",
      farmId: activeFarm?.id || "farm-1",
      feedLogs: [],
      healthLogs: [],
      mortalityLogs: [],
      salesLogs: [],
      eggCollections: [],
      eggSales: [],
      weightSamples: [],
      valuationHistory: [],
      hasPendingWrites: true,
      _pendingSync: true
    };

    // Post to ledger: Dr Biological Assets (1420), Cr Cash/Bank (1010)
    postLedger("1420", "1010", totalCost);
    onAddBatch(created);

    // Auto-post Chicks / Stock Acquisition to Continuous Expenses & Cash book Disbursals
    if (onAddExpense && totalCost > 0) {
      const expenseTx = {
        id: `EXP-CHICKS-${Date.now()}`,
        supplierId: supplierId || `SUP-${Date.now()}`,
        supplierName: finalSource,
        date: newBatch.dateAcquired,
        taxSystem: "Exempt",
        taxAmount: 0,
        subtotal: totalCost,
        total: totalCost,
        amount: totalCost,
        farmId: activeFarm?.id,
        tenantId: activeFarm?.tenantId,
        hasPendingWrites: true,
        _pendingSync: true,
        rows: [
          {
            category: "Poultry Day-Old Chicks / Flock Acquisition",
            description: `Village / Indigenous Bird Acquisition: ${newBatch.initialHeadcount} ${newBatch.breed} @ ${currencySymbol}${newBatch.acquisitionCostPerBird}/bird for ${batchName} from ${finalSource}`,
            quantity: Number(newBatch.initialHeadcount),
            unitPrice: Number(newBatch.acquisitionCostPerBird),
            amount: totalCost,
            coaCode: "5211",
            allocationType: "poultry_batch",
            poultryBatchId: batchId,
            poultryBatchName: batchName
          }
        ]
      };
      onAddExpense(expenseTx);
    }

    writeAuditLog("REGISTER_POULTRY_BATCH", "Poultry", batchId, `Registered Village batch ${batchName} with ${newBatch.initialHeadcount} birds from ${finalSource}. Posted acquisition expense ${currencySymbol}${totalCost}.`);

    // Reset wizard
    setIsRegWizardOpen(false);
    setWizardStep(1);
    setNewBatch({
      breed: "Boschveld",
      dateAcquired: new Date().toISOString().split("T")[0],
      source: "Mabala Breeding Centre",
      customSource: "",
      initialHeadcount: 100,
      acquisitionCostPerBird: 15.0,
      photoUrl: "",
      currentMarketPricePerBird: 85.0,
    });
  };

  // Action logging handlers
  const handleLogFeed = () => {
    if (!selectedBatch) return;
    const log: PoultryFeedLog = {
      id: "feed-" + Math.random().toString(36).substr(2, 9),
      date: feedForm.date,
      feedType: feedForm.feedType,
      quantityKg: Number(feedForm.quantityKg),
      cost: Number(feedForm.cost),
      fedBy: feedForm.fedBy
    };

    const updated = {
      ...selectedBatch,
      cumulativeFeedCost: selectedBatch.cumulativeFeedCost + log.cost,
      feedLogs: [log, ...(selectedBatch.feedLogs || [])],
      updatedAt: new Date().toISOString()
    };

    // Ledger: Dr Feed Expense (5210/5100), Cr Cash/Bank (1010)
    postLedger("5210", "1010", log.cost);

    if (onAddExpense) {
      onAddExpense({
        id: `EXP-FEED-${Date.now()}`,
        supplierId: "SUP-FEED-INTERNAL",
        supplierName: "Village Poultry Feed Allocation",
        date: feedForm.date,
        taxSystem: "Exempt",
        taxAmount: 0,
        subtotal: log.cost,
        total: log.cost,
        amount: log.cost,
        farmId: activeFarm?.id,
        rows: [
          {
            category: "Poultry Feed",
            description: `Village poultry feed intake for ${selectedBatch.batchName}: ${log.quantityKg}kg ${feedForm.feedType}`,
            quantity: log.quantityKg,
            unitPrice: log.quantityKg > 0 ? log.cost / log.quantityKg : 0,
            amount: log.cost,
            coaCode: "5210"
          }
        ]
      });
    }

    onUpdateBatch(updated);
    setSelectedBatch(updated);
    setActiveLogType(null);
    writeAuditLog("POULTRY_LOG_FEED", "Poultry", selectedBatch.id, `Logged feed for Village batch ${selectedBatch.batchName}: ${log.quantityKg}kg costing ${currencySymbol}${log.cost}.`);
  };

  const handleLogHealth = () => {
    if (!selectedBatch) return;
    const log: PoultryHealthEvent = {
      id: "health-" + Math.random().toString(36).substr(2, 9),
      date: healthForm.date,
      type: healthForm.type,
      product: healthForm.product,
      cost: Number(healthForm.cost),
      notes: healthForm.notes,
      withdrawalPeriodDays: Number(healthForm.withdrawalPeriodDays),
      withdrawalCloseDate: healthForm.withdrawalPeriodDays > 0 
        ? new Date(new Date(healthForm.date).getTime() + Number(healthForm.withdrawalPeriodDays) * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
        : undefined,
      administeredBy: healthForm.administeredBy || activeFarm?.ownerName || "Operator"
    };

    const updated = {
      ...selectedBatch,
      cumulativeHealthCost: selectedBatch.cumulativeHealthCost + log.cost,
      healthLogs: [log, ...(selectedBatch.healthLogs || [])],
      updatedAt: new Date().toISOString()
    };

    // Ledger: Dr Vet Expense (5110), Cr Cash/Bank (1010)
    postLedger("5110", "1010", log.cost);
    onUpdateBatch(updated);
    setSelectedBatch(updated);
    setActiveLogType(null);
    writeAuditLog("POULTRY_LOG_HEALTH", "Poultry", selectedBatch.id, `Logged health event for Village batch ${selectedBatch.batchName}: ${log.product} costing ZK ${log.cost}.`);
  };

  const handleLogMortality = () => {
    if (!selectedBatch) return;
    const count = Number(mortalityForm.count);
    const lossVal = count * selectedBatch.acquisitionCostPerBird;

    const log: PoultryMortalityLog = {
      id: "mortality-" + Math.random().toString(36).substr(2, 9),
      date: mortalityForm.date,
      count,
      cause: mortalityForm.cause,
      lossValue: lossVal,
      notes: mortalityForm.notes
    };

    const newHeadcount = Math.max(0, selectedBatch.currentHeadcount - count);
    const updated = {
      ...selectedBatch,
      currentHeadcount: newHeadcount,
      cumulativeMortalityLoss: selectedBatch.cumulativeMortalityLoss + lossVal,
      currentBatchValuation: newHeadcount * selectedBatch.currentMarketPricePerBird,
      mortalityLogs: [log, ...(selectedBatch.mortalityLogs || [])],
      updatedAt: new Date().toISOString()
    };

    // Ledger: Dr Poultry Mortality Loss (5901), Cr Biological Assets (1420)
    postLedger("5901", "1420", lossVal);
    onUpdateBatch(updated);
    setSelectedBatch(updated);
    setActiveLogType(null);
    writeAuditLog("POULTRY_LOG_MORTALITY", "Poultry", selectedBatch.id, `Logged ${count} mortality events for Village batch ${selectedBatch.batchName} due to ${log.cause}.`);
  };

  const handleEditHeadcount = () => {
    if (!selectedBatch) return;
    const oldHead = selectedBatch.currentHeadcount;
    const newHead = Math.max(0, Number(editHeadcountValue));
    
    const updated = {
      ...selectedBatch,
      currentHeadcount: newHead,
      currentBatchValuation: newHead * selectedBatch.currentMarketPricePerBird,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);
    setSelectedBatch(updated);
    setActiveLogType(null);
    writeAuditLog("POULTRY_EDIT_HEADCOUNT", "Poultry", selectedBatch.id, `Manually adjusted headcount from ${oldHead} to ${newHead} (Reason: ${editHeadcountReason})`);
    alert(`Successfully updated headcount from ${oldHead} to ${newHead}.`);
  };

  const handleLogWeight = () => {
    if (!selectedBatch) return;
    const sample = {
      id: "weight-" + Math.random().toString(36).substr(2, 9),
      date: weighForm.date,
      sampleSize: Number(weighForm.sampleSize),
      averageWeightKg: Number(weighForm.averageWeightKg),
      remarks: weighForm.remarks
    };

    const updated = {
      ...selectedBatch,
      weightSamples: [sample, ...(selectedBatch.weightSamples || [])],
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);
    setSelectedBatch(updated);
    setActiveLogType(null);
    writeAuditLog("POULTRY_LOG_WEIGHT", "Poultry", selectedBatch.id, `Logged average weight sample of ${sample.averageWeightKg}kg for Village batch ${selectedBatch.batchName}.`);
  };

  const handleSellBirds = () => {
    if (!selectedBatch) return;
    const qty = Number(sellBirdsForm.quantity);
    const unitPrice = Number(sellBirdsForm.pricePerUnit);
    const grossRevenue = qty * unitPrice;
    const cogsAmount = qty * selectedBatch.acquisitionCostPerBird;

    const log: PoultrySalesLog = {
      id: "sale-" + Math.random().toString(36).substr(2, 9),
      date: sellBirdsForm.date,
      quantity: qty,
      amount: grossRevenue,
      pricePerUnit: unitPrice,
      chargeType: sellBirdsForm.sellBy === "bird" ? "PER_BIRD" : "PER_KG",
      averageWeightKg: Number(sellBirdsForm.averageWeightKg),
      buyerName: sellBirdsForm.buyerName,
      paymentMethod: sellBirdsForm.paymentMethod
    };

    const newHeadcount = Math.max(0, selectedBatch.currentHeadcount - qty);
    const isSoldOut = newHeadcount === 0;

    const updated: PoultryBatch = {
      ...selectedBatch,
      currentHeadcount: newHeadcount,
      currentBatchValuation: newHeadcount * selectedBatch.currentMarketPricePerBird,
      status: isSoldOut ? "sold_out" : "active",
      salesLogs: [log, ...(selectedBatch.salesLogs || [])],
      updatedAt: new Date().toISOString()
    };

    // Ledger: 
    // 1. Dr Cash/Bank (1010), Cr Poultry Bird Sales Revenue (4110)
    postLedger("1010", "4110", grossRevenue);
    // 2. Dr Cost of Birds Sold (5212), Cr Biological Assets (1420)
    postLedger("5212", "1420", cogsAmount);

    onUpdateBatch(updated);
    setSelectedBatch(updated);
    setActiveLogType(null);
    writeAuditLog("POULTRY_SELL_BIRDS", "Poultry", selectedBatch.id, `Sold ${qty} birds from Village batch ${selectedBatch.batchName} for gross ZK ${grossRevenue}.`);
    
    // Show certificate of sale / receipt
    onShowDocument("receipt", {
      type: "Village Bird Sale Receipt",
      batchId: selectedBatch.batchId,
      batchName: selectedBatch.batchName,
      date: sellBirdsForm.date,
      quantity: qty,
      unitPrice,
      totalValue: grossRevenue,
      buyerName: sellBirdsForm.buyerName,
      paymentMethod: sellBirdsForm.paymentMethod
    });
  };

  const handleLogEggCollection = () => {
    if (!selectedBatch) return;
    const layRate = (Number(eggCollectionForm.totalCollected) / Math.max(1, selectedBatch.currentHeadcount)) * 100;
    
    const collection: EggCollection = {
      id: "egg-coll-" + Math.random().toString(36).substr(2, 9),
      date: eggCollectionForm.date,
      totalCollected: Number(eggCollectionForm.totalCollected),
      brokenCount: Number(eggCollectionForm.brokenCount),
      large: eggCollectionForm.useGrades ? Number(eggCollectionForm.large) : 0,
      medium: eggCollectionForm.useGrades ? Number(eggCollectionForm.medium) : 0,
      small: eggCollectionForm.useGrades ? Number(eggCollectionForm.small) : 0,
      ungraded: eggCollectionForm.useGrades ? Number(eggCollectionForm.ungraded) : Number(eggCollectionForm.totalCollected),
      useGrades: eggCollectionForm.useGrades,
      layRatePct: Math.min(100, layRate)
    };

    const updated = {
      ...selectedBatch,
      eggCollections: [collection, ...(selectedBatch.eggCollections || [])],
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);
    setSelectedBatch(updated);
    setActiveLogType(null);
    writeAuditLog("POULTRY_LOG_EGGS", "Poultry", selectedBatch.id, `Logged egg collection for Village batch ${selectedBatch.batchName}: ${collection.totalCollected} eggs collected.`);
  };

  const handleSellEggs = () => {
    if (!selectedBatch) return;
    const qty = Number(eggSaleForm.quantity);
    const price = Number(eggSaleForm.pricePerUnit);
    
    let totalRevenue = 0;
    if (eggSaleForm.sellUnit === "tray") {
      totalRevenue = (qty / 30) * price;
    } else {
      totalRevenue = qty * price;
    }

    const sale: EggSale = {
      id: "egg-sale-" + Math.random().toString(36).substr(2, 9),
      date: eggSaleForm.date,
      grade: eggSaleForm.grade,
      quantity: qty,
      pricePerUnit: price,
      sellUnit: eggSaleForm.sellUnit,
      totalRevenue,
      buyerName: eggSaleForm.buyerName,
      paymentMethod: eggSaleForm.paymentMethod
    };

    const updated = {
      ...selectedBatch,
      eggSales: [sale, ...(selectedBatch.eggSales || [])],
      updatedAt: new Date().toISOString()
    };

    // Ledger: Dr Cash/Bank (1010), Cr Poultry Egg Sales Revenue (4120)
    postLedger("1010", "4120", totalRevenue);

    onUpdateBatch(updated);
    setSelectedBatch(updated);
    setActiveLogType(null);
    writeAuditLog("POULTRY_SELL_EGGS", "Poultry", selectedBatch.id, `Sold ${qty} eggs of grade ${sale.grade} from Village batch ${selectedBatch.batchName} for gross ZK ${totalRevenue}.`);
  };

  const handleUpdatePrice = () => {
    if (!selectedBatch) return;
    const newPrice = Number(marketPriceForm.price);
    const oldPrice = selectedBatch.currentMarketPricePerBird;

    const change = {
      date: new Date().toISOString().split("T")[0],
      oldPrice,
      newPrice,
      changedBy: activeFarm?.ownerName || "Operator"
    };

    // Calculate valuation adjustment and record ledger entries
    const adjustmentValue = selectedBatch.currentHeadcount * (newPrice - oldPrice);
    if (adjustmentValue !== 0) {
      if (adjustmentValue > 0) {
        // Dr Biological Assets (1420), Cr Gain on Biological Assets (4910)
        postLedger("1420", "4910", adjustmentValue);
      } else {
        // Dr Loss on Biological Assets (5910), Cr Biological Assets (1420)
        postLedger("5910", "1420", Math.abs(adjustmentValue));
      }
    }

    const updated = {
      ...selectedBatch,
      currentMarketPricePerBird: newPrice,
      currentBatchValuation: selectedBatch.currentHeadcount * newPrice,
      valuationHistory: [change, ...(selectedBatch.valuationHistory || [])],
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);
    setSelectedBatch(updated);
    setActiveLogType(null);
    writeAuditLog("POULTRY_ADJUST_PRICE", "Poultry", selectedBatch.id, `Adjusted current bird valuation price for Village batch ${selectedBatch.batchName} from ZK ${oldPrice} to ZK ${newPrice}.`);
  };

  const handleArchiveBatch = () => {
    if (!selectedBatch) return;
    const updated = {
      ...selectedBatch,
      status: "closed" as any,
      updatedAt: new Date().toISOString()
    };
    onUpdateBatch(updated);
    setSelectedBatch(null);
    writeAuditLog("POULTRY_ARCHIVE_BATCH", "Poultry", selectedBatch.id, `Archived Village batch ${selectedBatch.batchName}.`);
  };

  // P&L Metrics Calculator
  const pAndLMetrics = useMemo(() => {
    if (!selectedBatch) return { birdRevenue: 0, eggRevenue: 0, totalRevenue: 0, acquisitionCost: 0, feedCost: 0, healthCost: 0, mortalityLoss: 0, totalCosts: 0, netProfit: 0 };
    
    const birdRevenue = (selectedBatch.salesLogs || []).reduce((sum, s) => sum + s.amount, 0);
    const eggRevenue = (selectedBatch.eggSales || []).reduce((sum, s) => sum + s.totalRevenue, 0);
    const totalRevenue = birdRevenue + eggRevenue;
    
    const acquisitionCost = selectedBatch.acquisitionCostTotal;
    const feedCost = selectedBatch.cumulativeFeedCost;
    const healthCost = selectedBatch.cumulativeHealthCost;
    const mortalityLoss = selectedBatch.cumulativeMortalityLoss;
    const totalCosts = acquisitionCost + feedCost + healthCost + mortalityLoss;
    const netProfit = totalRevenue - totalCosts;

    return {
      birdRevenue,
      eggRevenue,
      totalRevenue,
      acquisitionCost,
      feedCost,
      healthCost,
      mortalityLoss,
      totalCosts,
      netProfit
    };
  }, [selectedBatch]);

  return (
    <div className="space-y-6" id="village-module-root">
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-50 text-emerald-500">
              <Sprout className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-black text-slate-950 tracking-tight">Village Indigenous Chicken Tracker</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Dual-purpose local breed tracking for meat and egg production at community scale.
          </p>
        </div>
        <button
          onClick={() => {
            setWizardStep(1);
            setIsRegWizardOpen(true);
          }}
          className="px-4 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-black hover:bg-slate-800 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
        >
          <Plus size={14} />
          Register Village Batch
        </button>
      </div>

      {/* DASHBOARD SUMMARY CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400">Active Batches</span>
          <h2 className="text-xl font-black text-slate-900 mt-1">
            {villageBatches.filter(b => b.status === "active").length}
          </h2>
          <span className="text-[10px] text-slate-400 block mt-1">Continuous stock</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400">Total Headcount</span>
          <h2 className="text-xl font-black text-slate-900 mt-1">
            {villageBatches.filter(b => b.status === "active").reduce((s, b) => s + b.currentHeadcount, 0).toLocaleString()}
          </h2>
          <span className="text-[10px] text-emerald-500 font-medium block mt-1">Birds on hand</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400">Active Valuation</span>
          <h2 className="text-xl font-black text-slate-900 mt-1">
            {currencySymbol}{villageBatches.filter(b => b.status === "active").reduce((s, b) => s + b.currentBatchValuation, 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </h2>
          <span className="text-[10px] text-indigo-500 font-medium block mt-1">Acc: 1420 ledger link</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400">Cumulative Sales</span>
          <h2 className="text-xl font-black text-emerald-600 mt-1">
            {currencySymbol}{villageBatches.reduce((s, b) => {
              const bSales = (b.salesLogs || []).reduce((sum, sa) => sum + sa.amount, 0);
              const eSales = (b.eggSales || []).reduce((sum, es) => sum + es.totalRevenue, 0);
              return s + bSales + eSales;
            }, 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </h2>
          <span className="text-[10px] text-slate-400 block mt-1">Birds + Eggs total</span>
        </div>
      </div>

      {/* RECONCILIATION CARDS ALERT BLOCK */}
      {villageBatches.length === 0 ? (
        <div className="bg-slate-50 border border-slate-100 rounded-3xl p-8 text-center max-w-xl mx-auto mt-6">
          <Sprout className="w-12 h-12 text-slate-300 mx-auto mb-3 animate-pulse" />
          <h3 className="text-sm font-black text-slate-900">No Village Chicken Batches Registered</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
            Get started by registering your first village indigenous flock batch. You can track dual bird sales and egg collection within a single card.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* BATCH SELECTOR LIST */}
          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 px-1">Registered Batches</h3>
            {villageBatches.map(b => {
              const age = getAgeInDays(b.dateAcquired);
              const isClosed = b.status === "closed";
              return (
                <div 
                  key={b.id}
                  onClick={() => setSelectedBatch(b)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex justify-between items-center ${
                    selectedBatch?.id === b.id 
                      ? "bg-slate-900 border-slate-900 text-white shadow-md" 
                      : "bg-white border-slate-100 text-slate-900 hover:border-slate-300 shadow-xs"
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-black tracking-tight">{b.batchName}</h4>
                      {b.status === "active" ? (
                        <span className="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-600 text-[9px] font-bold">Active</span>
                      ) : b.status === "sold_out" ? (
                        <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-600 text-[9px] font-bold">Sold Out</span>
                      ) : (
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 text-[9px] font-bold">Archived</span>
                      )}
                    </div>
                    <div className="flex gap-4 mt-2 text-[10px] opacity-75">
                      <span>Age: {age} days</span>
                      <span>Breed: {b.breed}</span>
                      <span>Count: {b.currentHeadcount}</span>
                    </div>
                  </div>
                  <ChevronRight size={16} />
                </div>
              );
            })}
          </div>

          {/* ACTIVE BATCH CONTROL CARD VIEW */}
          <div>
            {selectedBatch ? (
              <div className="bg-white rounded-3xl border border-slate-100 p-6 space-y-6 shadow-sm">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-base font-black text-slate-950 tracking-tight">{selectedBatch.batchName}</h3>
                    <p className="text-[11px] text-slate-400 mt-1">Batch ID: {selectedBatch.batchId} • Source: {selectedBatch.source}</p>
                  </div>
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => {
                        setMarketPriceForm({ price: selectedBatch.currentMarketPricePerBird });
                        setActiveLogType("edit_price");
                      }}
                      className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 transition-all cursor-pointer"
                      title="Adjust Market Price Valuation"
                    >
                      <Sparkles size={14} />
                    </button>
                    {selectedBatch.status !== "closed" && (
                      <button
                        onClick={() => {
                          if (confirm("Are you sure you want to archive/close this village batch? This is permanent.")) {
                            handleArchiveBatch();
                          }
                        }}
                        className="p-1.5 hover:bg-red-50 hover:text-red-600 rounded-lg text-slate-400 transition-all cursor-pointer"
                        title="Archive Batch"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>

                {/* BATCH STATUS PILLS */}
                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl text-center">
                  <div>
                    <span className="text-[9px] uppercase font-bold text-slate-400">Headcount</span>
                    <p className="text-xs font-black text-slate-800 mt-0.5">{selectedBatch.currentHeadcount} birds</p>
                  </div>
                  <div>
                    <span className="text-[9px] uppercase font-bold text-slate-400">Market Price</span>
                    <p className="text-xs font-black text-slate-800 mt-0.5">{currencySymbol}{selectedBatch.currentMarketPricePerBird}</p>
                  </div>
                  <div>
                    <span className="text-[9px] uppercase font-bold text-slate-400">Valuation</span>
                    <p className="text-xs font-black text-slate-800 mt-0.5">{currencySymbol}{selectedBatch.currentBatchValuation.toLocaleString()}</p>
                  </div>
                </div>

                {/* FCR Efficiency Metric Card */}
                <div>
                  <FcrMetricCard batch={selectedBatch} />
                </div>

                {/* 30-Day Daily Egg Production & Quality Ratio Trend Chart */}
                <div>
                  <DailyEggTrendChart eggCollections={selectedBatch.eggCollections} batchName={selectedBatch.batchName} />
                </div>

                {/* 30-Day Egg Quality Ratio Pie Chart */}
                <div>
                  <EggGradeRatioPieChart eggCollections={selectedBatch.eggCollections} />
                </div>

                {/* ACTION LAUNCHER BUTTONS */}
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-black text-slate-400 block">Actions & Logs</span>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    <button
                      onClick={() => setActiveLogType("feed")}
                      className="py-2 px-3 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-xl text-[11px] font-bold text-center cursor-pointer transition-all border border-slate-100"
                    >
                      Log Feed
                    </button>
                    <button
                      onClick={() => setActiveLogType("health")}
                      className="py-2 px-3 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-xl text-[11px] font-bold text-center cursor-pointer transition-all border border-slate-100"
                    >
                      Log Health
                    </button>
                    <button
                      onClick={() => setActiveLogType("mortality")}
                      className="py-2 px-3 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-xl text-[11px] font-bold text-center cursor-pointer transition-all border border-slate-100"
                    >
                      Log Mortality
                    </button>
                    <button
                      onClick={() => setActiveLogType("weigh")}
                      className="py-2 px-3 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-xl text-[11px] font-bold text-center cursor-pointer transition-all border border-slate-100"
                    >
                      Weigh Samples
                    </button>
                    <button
                      onClick={() => setActiveLogType("sell_birds")}
                      className="py-2 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl text-[11px] font-bold text-center cursor-pointer transition-all border border-emerald-100"
                    >
                      Sell Birds
                    </button>
                    <button
                      onClick={() => setActiveLogType("log_eggs")}
                      className="py-2 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 rounded-xl text-[11px] font-bold text-center cursor-pointer transition-all border border-indigo-100"
                    >
                      Log Eggs
                    </button>
                    <button
                      onClick={() => setActiveLogType("sell_eggs")}
                      className="py-2 px-3 bg-sky-50 hover:bg-sky-100 text-sky-800 rounded-xl text-[11px] font-bold text-center cursor-pointer transition-all border border-sky-100"
                    >
                      Sell Eggs
                    </button>
                    <button
                      onClick={() => setActiveLogType("p_and_l")}
                      className="py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-[11px] font-bold text-center cursor-pointer transition-all col-span-2 md:col-span-1"
                    >
                      P&L Statement
                    </button>
                    <button
                      onClick={() => {
                        setActiveLogType("edit_headcount");
                        setEditHeadcountValue(selectedBatch.currentHeadcount);
                      }}
                      className="py-2 px-3 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-100 rounded-xl text-[11px] font-bold text-center cursor-pointer transition-all"
                    >
                      Adjust Headcount
                    </button>
                  </div>
                </div>

                {/* LOGS HISTORY PREVIEW */}
                <div className="space-y-3 pt-3 border-t border-slate-50">
                  <span className="text-[10px] uppercase font-black text-slate-400 block">Recent Activity Log</span>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {selectedBatch.eggCollections && selectedBatch.eggCollections.length > 0 && (
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center text-[10px]">
                        <div>
                          <p className="font-bold text-slate-800">Egg Collection Recorded</p>
                          <p className="text-slate-400">{selectedBatch.eggCollections[0].date} • {selectedBatch.eggCollections[0].totalCollected} eggs collected</p>
                        </div>
                        <span className="px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-600 font-bold">{selectedBatch.eggCollections[0].layRatePct.toFixed(1)}% lay</span>
                      </div>
                    )}
                    {selectedBatch.salesLogs && selectedBatch.salesLogs.length > 0 && (
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center text-[10px]">
                        <div>
                          <p className="font-bold text-slate-800">Birds Sold: {selectedBatch.salesLogs[0].quantity} heads</p>
                          <p className="text-slate-400">{selectedBatch.salesLogs[0].date} • Buyer: {selectedBatch.salesLogs[0].buyerName}</p>
                        </div>
                        <span className="text-emerald-600 font-bold">+{currencySymbol}{selectedBatch.salesLogs[0].amount.toLocaleString()}</span>
                      </div>
                    )}
                    {selectedBatch.eggSales && selectedBatch.eggSales.length > 0 && (
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center text-[10px]">
                        <div>
                          <p className="font-bold text-slate-800">Eggs Sold: {selectedBatch.eggSales[0].quantity} eggs</p>
                          <p className="text-slate-400">{selectedBatch.eggSales[0].date} • Grade: {selectedBatch.eggSales[0].grade}</p>
                        </div>
                        <span className="text-emerald-600 font-bold">+{currencySymbol}{selectedBatch.eggSales[0].totalRevenue.toLocaleString()}</span>
                      </div>
                    )}
                    {selectedBatch.feedLogs && selectedBatch.feedLogs.length > 0 && (
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center text-[10px]">
                        <div>
                          <p className="font-bold text-slate-800">Feed Added: {selectedBatch.feedLogs[0].feedType}</p>
                          <p className="text-slate-400">{selectedBatch.feedLogs[0].date} • {selectedBatch.feedLogs[0].quantityKg}kg</p>
                        </div>
                        <span className="text-slate-500 font-bold">-{currencySymbol}{selectedBatch.feedLogs[0].cost}</span>
                      </div>
                    )}
                  </div>
                </div>

              </div>
            ) : (
              <div className="bg-slate-50 border border-dashed border-slate-200 rounded-3xl p-12 text-center h-full flex flex-col justify-center items-center">
                <Home className="w-10 h-10 text-slate-300 mb-3" />
                <h4 className="text-xs font-black text-slate-700">No Batch Selected</h4>
                <p className="text-[11px] text-slate-400 mt-1 max-w-xs mx-auto">
                  Click on one of the registered batches on the left to log feedings, sales, collections, and view their individual P&L margins.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* REGISTRATION WIZARD MODAL */}
      {isRegWizardOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" id="reg-wizard-village">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-100 shadow-xl overflow-hidden animate-slide-up">
            <div className="p-6 border-b border-slate-50 flex justify-between items-center bg-slate-900 text-white">
              <div>
                <span className="text-[10px] uppercase tracking-wider font-black text-emerald-400">Step {wizardStep} of 2</span>
                <h3 className="text-sm font-black mt-0.5">Register Village Batch</h3>
              </div>
              <button onClick={() => setIsRegWizardOpen(false)} className="p-1 hover:bg-slate-800 rounded-lg text-white transition-all cursor-pointer">
                <X size={16} />
              </button>
            </div>

            {wizardStep === 1 ? (
              <div className="p-6 space-y-4">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Breed / Variety</label>
                  <select
                    value={newBatch.breed}
                    onChange={(e) => setNewBatch({ ...newBatch, breed: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-slate-900 outline-hidden bg-white font-medium"
                  >
                    <option value="Boschveld">Boschveld (Zambian Hardy)</option>
                    <option value="Sasso">Sasso (Premium Dual Purpose)</option>
                    <option value="Black Australorp">Black Australorp (Excellent Layer)</option>
                    <option value="Kuroiler">Kuroiler</option>
                    <option value="Local/Village">Local Village Indigenous</option>
                    <option value="Quails">Quails (Quels)</option>
                    <option value="Geese">Geese (Guees)</option>
                    <option value="Ducks">Ducks</option>
                    <option value="Guinea Fowl">Guinea Fowl (Guene Fows)</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Initial Headcount</label>
                    <input
                      type="number"
                      value={newBatch.initialHeadcount}
                      onChange={(e) => setNewBatch({ ...newBatch, initialHeadcount: Math.max(1, Number(e.target.value)) })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-slate-900 outline-hidden font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Cost Per Bird (ZK)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={newBatch.acquisitionCostPerBird}
                      onChange={(e) => setNewBatch({ ...newBatch, acquisitionCostPerBird: Math.max(0, Number(e.target.value)) })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-slate-900 outline-hidden font-mono"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[10px] uppercase font-bold text-slate-400">Supplier / Source</label>
                    <button
                      type="button"
                      onClick={() => setShowSupplierModal(true)}
                      className="text-[10px] font-black text-emerald-600 hover:text-emerald-700 underline cursor-pointer"
                    >
                      + Register Supplier
                    </button>
                  </div>
                  <select
                    value={newBatch.source}
                    onChange={(e) => setNewBatch({ ...newBatch, source: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-slate-900 outline-hidden bg-white font-medium"
                  >
                    <option value="">Select Supplier / Village Source...</option>
                    <option value="Local Smallholders / Community">Local Smallholders / Community</option>
                    <option value="Livestock Market / Auction">Livestock Market / Auction</option>
                    <option value="Breeder Hub / NGO Program">Breeder Hub / NGO Program</option>
                    {suppliers.map(s => (
                      <option key={s.id} value={s.name}>{s.name} ({s.category || "Supplier"})</option>
                    ))}
                    <option value="Other (Custom)">Other (Custom)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Acquisition Date</label>
                  <input
                    type="date"
                    value={newBatch.dateAcquired}
                    onChange={(e) => setNewBatch({ ...newBatch, dateAcquired: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-slate-900 outline-hidden font-medium"
                  />
                </div>

                <button
                  onClick={handleWizardNext}
                  className="w-full py-3 bg-slate-900 text-white rounded-xl text-xs font-black hover:bg-slate-800 transition-all cursor-pointer mt-4"
                >
                  Next Step
                </button>
              </div>
            ) : (
              <div className="p-6 space-y-4">
                <div className="bg-amber-50 p-3.5 rounded-xl border border-amber-100 flex gap-2.5 items-start">
                  <BookOpen className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-[11px] font-black text-amber-900">Ledger Auto-Posting</h5>
                    <p className="text-[10px] text-amber-800 mt-0.5">
                      Completing this registration will automatically post a capitalization debit entry of ZK {(newBatch.initialHeadcount * newBatch.acquisitionCostPerBird).toLocaleString()} to biological assets account 1420.
                    </p>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Supplier Source</label>
                  <select
                    value={newBatch.source}
                    onChange={(e) => setNewBatch({ ...newBatch, source: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-slate-900 outline-hidden bg-white font-medium"
                  >
                    <option value="Mabala Breeding Centre">Mabala Breeding Centre</option>
                    <option value="Zambia National Service (ZNS)">Zambia National Service (ZNS)</option>
                    <option value="Tiger Animal Feeds & Chicks">Tiger Animal Feeds & Chicks</option>
                    <option value="Other (Custom)">Other (Custom Supplier)</option>
                  </select>
                </div>

                {newBatch.source === "Other (Custom)" && (
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Custom Supplier Name</label>
                    <input
                      type="text"
                      placeholder="Enter custom supplier name"
                      value={newBatch.customSource}
                      onChange={(e) => setNewBatch({ ...newBatch, customSource: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-slate-900 outline-hidden font-medium"
                    />
                  </div>
                )}

                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Initial Valuation Price Per Bird (ZK)</label>
                  <input
                    type="number"
                    value={newBatch.currentMarketPricePerBird}
                    onChange={(e) => setNewBatch({ ...newBatch, currentMarketPricePerBird: Math.max(0, Number(e.target.value)) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-slate-900 outline-hidden font-mono"
                  />
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => setWizardStep(1)}
                    className="flex-1 py-3 border border-slate-200 text-slate-600 rounded-xl text-xs font-black hover:bg-slate-50 transition-all cursor-pointer"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleCreateBatch}
                    className="flex-1 py-3 bg-emerald-600 text-white rounded-xl text-xs font-black hover:bg-emerald-500 transition-all cursor-pointer"
                  >
                    Register Batch
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* DETAILED ACTION MODAL OVERLAYS */}
      {activeLogType && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in overflow-y-auto">
          <div className={`bg-white rounded-3xl w-full border border-slate-100 shadow-xl overflow-hidden animate-slide-up ${
            activeLogType === "p_and_l" ? "max-w-3xl max-h-[90vh] flex flex-col" : "max-w-md"
          }`}>
            <div className="p-6 border-b border-slate-50 flex justify-between items-center bg-slate-950 text-white shrink-0">
              <h3 className="text-sm font-black capitalize">
                {activeLogType === "p_and_l" ? "Cost Breakdown & Profitability" : activeLogType.replace("_", " ")} – {selectedBatch.batchName}
              </h3>
              <button onClick={() => setActiveLogType(null)} className="p-1 hover:bg-slate-800 rounded-lg text-white transition-all cursor-pointer">
                <X size={16} />
              </button>
            </div>

            <div className={`p-6 space-y-4 ${activeLogType === "p_and_l" ? "overflow-y-auto flex-1" : ""}`}>
              {/* FEED FORM */}
              {activeLogType === "feed" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Date Fed</label>
                      <input type="date" value={feedForm.date} onChange={(e) => setFeedForm({ ...feedForm, date: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Feed Type</label>
                      <input type="text" value={feedForm.feedType} onChange={(e) => setFeedForm({ ...feedForm, feedType: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Quantity (Kg)</label>
                      <input type="number" value={feedForm.quantityKg} onChange={(e) => setFeedForm({ ...feedForm, quantityKg: Math.max(1, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Cost (ZK)</label>
                      <input type="number" value={feedForm.cost} onChange={(e) => setFeedForm({ ...feedForm, cost: Math.max(0, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Fed By (Operator)</label>
                    {employees && employees.length > 0 ? (
                      <select
                        value={feedForm.fedBy}
                        onChange={(e) => setFeedForm({ ...feedForm, fedBy: e.target.value })}
                        required
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white font-bold text-slate-700"
                      >
                        <option value="">-- Select Employee --</option>
                        {employees.map((emp: any) => (
                          <option key={emp.id} value={emp.name}>
                            {emp.name} ({emp.role})
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input type="text" value={feedForm.fedBy} onChange={(e) => setFeedForm({ ...feedForm, fedBy: e.target.value })} required placeholder="e.g. S. Phiri" className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    )}
                  </div>
                  <button onClick={handleLogFeed} className="w-full py-3 bg-slate-900 text-white rounded-xl text-xs font-black hover:bg-slate-800 transition-all cursor-pointer">
                    Log Feed Usage
                  </button>
                </div>
              )}

              {/* HEALTH FORM */}
              {activeLogType === "health" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Event Date</label>
                      <input type="date" value={healthForm.date} onChange={(e) => setHealthForm({ ...healthForm, date: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Event Type</label>
                      <select value={healthForm.type} onChange={(e) => setHealthForm({ ...healthForm, type: e.target.value as any })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white">
                        <option value="vaccination">Vaccination</option>
                        <option value="treatment">Treatment</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Product Used</label>
                      <input type="text" value={healthForm.product} onChange={(e) => setHealthForm({ ...healthForm, product: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Withdrawal Days</label>
                      <input type="number" value={healthForm.withdrawalPeriodDays} onChange={(e) => setHealthForm({ ...healthForm, withdrawalPeriodDays: Math.max(0, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Cost (ZK)</label>
                    <input type="number" value={healthForm.cost} onChange={(e) => setHealthForm({ ...healthForm, cost: Math.max(0, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Administered By (Operator)</label>
                    {employees && employees.length > 0 ? (
                      <select
                        value={healthForm.administeredBy}
                        onChange={(e) => setHealthForm({ ...healthForm, administeredBy: e.target.value })}
                        required
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white font-bold text-slate-700"
                      >
                        <option value="">-- Select Employee --</option>
                        {employees.map((emp: any) => (
                          <option key={emp.id} value={emp.name}>
                            {emp.name} ({emp.role})
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input type="text" value={healthForm.administeredBy} onChange={(e) => setHealthForm({ ...healthForm, administeredBy: e.target.value })} required placeholder="e.g. S. Phiri" className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    )}
                  </div>
                  <button onClick={handleLogHealth} className="w-full py-3 bg-slate-900 text-white rounded-xl text-xs font-black hover:bg-slate-800 transition-all cursor-pointer">
                    Log Health Event
                  </button>
                </div>
              )}

              {/* MORTALITY FORM */}
              {activeLogType === "mortality" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Date</label>
                      <input type="date" value={mortalityForm.date} onChange={(e) => setMortalityForm({ ...mortalityForm, date: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Mortality Count</label>
                      <input type="number" value={mortalityForm.count} onChange={(e) => setMortalityForm({ ...mortalityForm, count: Math.max(1, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Cause of Death</label>
                    <select value={mortalityForm.cause} onChange={(e) => setMortalityForm({ ...mortalityForm, cause: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white">
                      <option value="Disease">Disease</option>
                      <option value="Heat Stress">Heat Stress</option>
                      <option value="Predation">Predation</option>
                      <option value="Culled">Culled / Weak</option>
                      <option value="Other">Other / Unknown</option>
                    </select>
                  </div>
                  <button onClick={handleLogMortality} className="w-full py-3 bg-slate-900 text-white rounded-xl text-xs font-black hover:bg-slate-800 transition-all cursor-pointer">
                    Log Mortality Loss
                  </button>
                </div>
              )}

              {/* WEIGH FORM */}
              {activeLogType === "weigh" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Date</label>
                      <input type="date" value={weighForm.date} onChange={(e) => setWeighForm({ ...weighForm, date: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Sample Size</label>
                      <input type="number" value={weighForm.sampleSize} onChange={(e) => setWeighForm({ ...weighForm, sampleSize: Math.max(1, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Average Weight (Kg)</label>
                    <input type="number" step="0.01" value={weighForm.averageWeightKg} onChange={(e) => setWeighForm({ ...weighForm, averageWeightKg: Math.max(0, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                  </div>
                  <button onClick={handleLogWeight} className="w-full py-3 bg-slate-900 text-white rounded-xl text-xs font-black hover:bg-slate-800 transition-all cursor-pointer">
                    Save Weight Record
                  </button>
                </div>
              )}

              {/* SELL BIRDS FORM */}
              {activeLogType === "sell_birds" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Sale Date</label>
                      <input type="date" value={sellBirdsForm.date} onChange={(e) => setSellBirdsForm({ ...sellBirdsForm, date: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Heads Sold</label>
                      <input type="number" value={sellBirdsForm.quantity} onChange={(e) => setSellBirdsForm({ ...sellBirdsForm, quantity: Math.min(selectedBatch.currentHeadcount, Math.max(1, Number(e.target.value))) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Price Per Bird (ZK)</label>
                      <input type="number" value={sellBirdsForm.pricePerUnit} onChange={(e) => setSellBirdsForm({ ...sellBirdsForm, pricePerUnit: Math.max(0, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Buyer Name</label>
                      <input type="text" value={sellBirdsForm.buyerName} onChange={(e) => setSellBirdsForm({ ...sellBirdsForm, buyerName: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    </div>
                  </div>
                  <button onClick={handleSellBirds} className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black transition-all cursor-pointer">
                    Complete Bird Sale
                  </button>
                </div>
              )}

              {/* LOG EGGS FORM */}
              {activeLogType === "log_eggs" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Collection Date</label>
                      <input type="date" value={eggCollectionForm.date} onChange={(e) => setEggCollectionForm({ ...eggCollectionForm, date: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Total Collected (Eggs)</label>
                      <input type="number" value={eggCollectionForm.totalCollected} onChange={(e) => setEggCollectionForm({ ...eggCollectionForm, totalCollected: Math.max(1, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Broken / Damaged</label>
                      <input type="number" value={eggCollectionForm.brokenCount} onChange={(e) => setEggCollectionForm({ ...eggCollectionForm, brokenCount: Math.max(0, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    </div>
                    <div className="flex items-center pt-5">
                      <input type="checkbox" id="useGradesCheck" checked={eggCollectionForm.useGrades} onChange={(e) => setEggCollectionForm({ ...eggCollectionForm, useGrades: e.target.checked })} className="w-4 h-4 text-indigo-600 border-slate-200 rounded-sm focus:ring-indigo-500" />
                      <label htmlFor="useGradesCheck" className="text-xs font-bold text-slate-600 ml-2">Log by Grade</label>
                    </div>
                  </div>

                  {eggCollectionForm.useGrades && (
                    <div className="grid grid-cols-4 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-100">
                      <div>
                        <label className="text-[9px] uppercase font-bold text-slate-400 block mb-0.5">Large</label>
                        <input type="number" value={eggCollectionForm.large} onChange={(e) => setEggCollectionForm({ ...eggCollectionForm, large: Math.max(0, Number(e.target.value)) })} className="w-full px-1.5 py-1 border border-slate-200 rounded text-xs font-mono" />
                      </div>
                      <div>
                        <label className="text-[9px] uppercase font-bold text-slate-400 block mb-0.5">Medium</label>
                        <input type="number" value={eggCollectionForm.medium} onChange={(e) => setEggCollectionForm({ ...eggCollectionForm, medium: Math.max(0, Number(e.target.value)) })} className="w-full px-1.5 py-1 border border-slate-200 rounded text-xs font-mono" />
                      </div>
                      <div>
                        <label className="text-[9px] uppercase font-bold text-slate-400 block mb-0.5">Small</label>
                        <input type="number" value={eggCollectionForm.small} onChange={(e) => setEggCollectionForm({ ...eggCollectionForm, small: Math.max(0, Number(e.target.value)) })} className="w-full px-1.5 py-1 border border-slate-200 rounded text-xs font-mono" />
                      </div>
                      <div>
                        <label className="text-[9px] uppercase font-bold text-slate-400 block mb-0.5">Un-G</label>
                        <input type="number" value={eggCollectionForm.ungraded} onChange={(e) => setEggCollectionForm({ ...eggCollectionForm, ungraded: Math.max(0, Number(e.target.value)) })} className="w-full px-1.5 py-1 border border-slate-200 rounded text-xs font-mono" />
                      </div>
                    </div>
                  )}

                  <button onClick={handleLogEggCollection} className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black transition-all cursor-pointer">
                    Log Egg Collection
                  </button>
                </div>
              )}

              {/* SELL EGGS FORM */}
              {activeLogType === "sell_eggs" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Sale Date</label>
                      <input type="date" value={eggSaleForm.date} onChange={(e) => setEggSaleForm({ ...eggSaleForm, date: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Egg Grade</label>
                      <select value={eggSaleForm.grade} onChange={(e) => setEggSaleForm({ ...eggSaleForm, grade: e.target.value as any })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white">
                        <option value="large">Large</option>
                        <option value="medium">Medium</option>
                        <option value="small">Small</option>
                        <option value="ungraded">Ungraded / Mixed</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Quantity (Eggs)</label>
                      <input type="number" value={eggSaleForm.quantity} onChange={(e) => setEggSaleForm({ ...eggSaleForm, quantity: Math.max(1, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Pricing Unit</label>
                      <select value={eggSaleForm.sellUnit} onChange={(e) => setEggSaleForm({ ...eggSaleForm, sellUnit: e.target.value as any })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white">
                        <option value="egg">Per Individual Egg</option>
                        <option value="tray">Per Tray (30 Eggs)</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Price Per Unit (ZK)</label>
                      <input type="number" value={eggSaleForm.pricePerUnit} onChange={(e) => setEggSaleForm({ ...eggSaleForm, pricePerUnit: Math.max(0, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Buyer Name</label>
                      <input type="text" value={eggSaleForm.buyerName} onChange={(e) => setEggSaleForm({ ...eggSaleForm, buyerName: e.target.value })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden" />
                    </div>
                  </div>
                  <button onClick={handleSellEggs} className="w-full py-3 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-black transition-all cursor-pointer">
                    Complete Egg Sale
                  </button>
                </div>
              )}

              {/* MARKET PRICE ADJUSTMENT */}
              {activeLogType === "edit_price" && (
                <div className="space-y-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Current market valuation price per bird (ZK)</label>
                    <input type="number" value={marketPriceForm.price} onChange={(e) => setMarketPriceForm({ price: Math.max(0, Number(e.target.value)) })} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono" />
                    <p className="text-[10px] text-slate-400 mt-1">This will automatically adjust the book value of the batch and post a revaluation gain/loss in the general ledger.</p>
                  </div>
                  <button onClick={handleUpdatePrice} className="w-full py-3 bg-slate-900 text-white rounded-xl text-xs font-black hover:bg-slate-800 transition-all cursor-pointer">
                    Save Valuation Price
                  </button>
                </div>
              )}

              {/* HEADCOUNT ADJUSTMENT */}
              {activeLogType === "edit_headcount" && (
                <div className="space-y-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Adjust Headcount (Recorded Poultry)</label>
                    <input
                      type="number"
                      value={editHeadcountValue}
                      onChange={(e) => setEditHeadcountValue(Math.max(0, Number(e.target.value)))}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden font-mono font-bold bg-white"
                      placeholder="e.g. 150"
                    />
                    <p className="text-[10px] text-slate-400 mt-1">This will directly edit the recorded headcount of birds in the batch.</p>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Reason for Adjustment</label>
                    <select
                      value={editHeadcountReason}
                      onChange={(e) => setEditHeadcountReason(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white font-medium text-slate-700"
                    >
                      <option value="Manual audit correction">Manual audit correction</option>
                      <option value="Transfer to other farm module">Transfer to other farm module</option>
                      <option value="Gift or donation given">Gift or donation given</option>
                      <option value="Unrecorded mortality correction">Unrecorded mortality correction</option>
                      <option value="Unrecorded sales correction">Unrecorded sales correction</option>
                    </select>
                  </div>
                  <button onClick={handleEditHeadcount} className="w-full py-3 bg-slate-900 text-white rounded-xl text-xs font-black hover:bg-slate-800 transition-all cursor-pointer">
                    Adjust Headcount
                  </button>
                </div>
              )}

              {/* P&L STATEMENT & COST BREAKDOWN */}
              {activeLogType === "p_and_l" && (
                <div className="space-y-6 text-xs font-medium">
                  {/* Detailed Cost Breakdown Split (Feed, Medication, Labour, Misc) */}
                  <BatchCostBreakdownSummary
                    batch={selectedBatch}
                    currencySymbol={currencySymbol}
                    expenses={expenses}
                    allBatches={batches}
                    compact={false}
                    showTransactionsList={true}
                  />

                  <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 space-y-3.5">
                    <div className="flex justify-between items-center text-slate-400 uppercase tracking-wider text-[9px] font-black">
                      <span>Account Class</span>
                      <span>Value ({currencySymbol})</span>
                    </div>
                    
                    {/* Revenues */}
                    <div className="space-y-1.5">
                      <p className="text-[10px] font-black uppercase text-slate-900">Revenues</p>
                      <div className="flex justify-between pl-2">
                        <span className="text-slate-500">Bird Sales Revenue (Acc: 4110)</span>
                        <span className="text-emerald-600 font-bold">+{currencySymbol}{pAndLMetrics.birdRevenue.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between pl-2">
                        <span className="text-slate-500">Egg Sales Revenue (Acc: 4120)</span>
                        <span className="text-emerald-600 font-bold">+{currencySymbol}{pAndLMetrics.eggRevenue.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between border-t border-slate-100 pt-1.5 pl-2 font-black">
                        <span>Total Revenue</span>
                        <span className="text-emerald-600">+{currencySymbol}{pAndLMetrics.totalRevenue.toFixed(2)}</span>
                      </div>
                    </div>

                    {/* Expenses */}
                    <div className="space-y-1.5 pt-2">
                      <p className="text-[10px] font-black uppercase text-slate-900">Direct Costs & Expenses</p>
                      <div className="flex justify-between pl-2">
                        <span className="text-slate-500">Acquisition Cap (Acc: 1420)</span>
                        <span className="text-rose-600 font-bold">-{currencySymbol}{pAndLMetrics.acquisitionCost.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between pl-2">
                        <span className="text-slate-500">Cumulative Feed Cost (Acc: 5100)</span>
                        <span className="text-rose-600 font-bold">-{currencySymbol}{pAndLMetrics.feedCost.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between pl-2">
                        <span className="text-slate-500">Cumulative Health Cost (Acc: 5110)</span>
                        <span className="text-rose-600 font-bold">-{currencySymbol}{pAndLMetrics.healthCost.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between pl-2">
                        <span className="text-slate-500">Mortality Loss Write-down (Acc: 5901)</span>
                        <span className="text-rose-600 font-bold">-{currencySymbol}{pAndLMetrics.mortalityLoss.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between border-t border-slate-100 pt-1.5 pl-2 font-black">
                        <span>Total Costs</span>
                        <span className="text-rose-600">-{currencySymbol}{pAndLMetrics.totalCosts.toFixed(2)}</span>
                      </div>
                    </div>

                    {/* Net Margin */}
                    <div className="flex justify-between border-t border-slate-200 pt-3 font-black text-sm">
                      <span className="text-slate-900">Net Profit / Loss</span>
                      <span className={pAndLMetrics.netProfit >= 0 ? "text-emerald-600" : "text-rose-600"}>
                        {currencySymbol}{pAndLMetrics.netProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>

                  <button onClick={() => setActiveLogType(null)} className="w-full py-3 bg-slate-900 text-white rounded-xl text-xs font-black hover:bg-slate-800 transition-all cursor-pointer">
                    Close Statement
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* UNIFIED SUPPLIER REGISTRATION MODAL */}
      <UnifiedSupplierModal
        isOpen={showSupplierModal}
        onClose={() => setShowSupplierModal(false)}
        initialCategory="Chicks & Hatchery"
        currencySymbol={currencySymbol}
        farmId={activeFarm?.id || "default-farm"}
        onSaveSupplier={(newSup) => {
          if (onAddSupplier) {
            onAddSupplier(newSup);
          }
          setNewBatch(prev => ({ ...prev, source: newSup.name }));
          setShowSupplierModal(false);
        }}
      />
    </div>
  );
}

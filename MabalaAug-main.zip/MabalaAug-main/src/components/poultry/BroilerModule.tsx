import React, { useState, useMemo } from "react";
import { PoultryBatch, PoultryFeedLog, PoultryHealthEvent, PoultryMortalityLog, PoultrySalesLog } from "./types";
import FcrMetricCard from "./FcrMetricCard";
import BatchCostBreakdownSummary from "./BatchCostBreakdownSummary";
import { 
  Plus, Flame, Calendar, MapPin, DollarSign, Scale, Trash2, 
  TrendingUp, Skull, ShieldAlert, CheckCircle, ChevronRight, X, Sparkles, BookOpen, Building2, PieChart
} from "lucide-react";
import { Supplier, ExpenseTransaction } from "../../types";
import UnifiedSupplierModal from "../common/UnifiedSupplierModal";

interface BroilerModuleProps {
  batches: PoultryBatch[];
  currencySymbol: string;
  onAddBatch: (batch: PoultryBatch) => void;
  onUpdateBatch: (batch: PoultryBatch) => void;
  onDeleteBatch: (id: string) => void;
  accounts: any[];
  setAccounts: (accs: any[]) => void;
  onAddExpense?: (tx: any) => void;
  onAddSupplier?: (sup: Supplier) => void;
  suppliers?: Supplier[];
  expenses?: ExpenseTransaction[];
  writeAuditLog: (action: string, module: string, target: string, details: string) => void;
  activeFarm: any;
  onShowDocument: (type: "certificate" | "receipt", data: any) => void;
  employees?: any[];
}

export default function BroilerModule({
  batches,
  currencySymbol,
  onAddBatch,
  onUpdateBatch,
  onDeleteBatch,
  accounts,
  setAccounts,
  onAddExpense,
  onAddSupplier,
  suppliers = [],
  expenses = [],
  writeAuditLog,
  activeFarm,
  onShowDocument,
  employees = []
}: BroilerModuleProps) {
  const broilerBatches = useMemo(() => batches.filter(b => b.poultryType === "broiler"), [batches]);

  // Modals state
  const [isRegWizardOpen, setIsRegWizardOpen] = useState(false);
  const [wizardStep, setWizardStep] = useState(1);
  const [selectedBatch, setSelectedBatch] = useState<PoultryBatch | null>(null);
  const [showSupplierModal, setShowSupplierModal] = useState(false);

  // Active Logging Modal states
  const [activeLogType, setActiveLogType] = useState<"feed" | "health" | "mortality" | "weigh" | "sell" | "p_and_l" | "edit_price" | "edit_headcount" | null>(null);

  // New Batch Form State
  const [newBatch, setNewBatch] = useState({
    breed: "Ross 308",
    dateAcquired: new Date().toISOString().split("T")[0],
    source: "",
    customSource: "",
    initialHeadcount: 0,
    acquisitionCostPerBird: 0,
    photoUrl: "",
    currentMarketPricePerBird: 0,
    targetSaleWeight: 0,
  });

  // Action Form States
  const [feedForm, setFeedForm] = useState({
    date: new Date().toISOString().split("T")[0],
    feedType: "",
    quantityKg: 0,
    cost: 0,
    fedBy: ""
  });

  const [editHeadcountValue, setEditHeadcountValue] = useState(0);
  const [editHeadcountReason, setEditHeadcountReason] = useState("Manual audit correction");

  const [healthForm, setHealthForm] = useState({
    date: new Date().toISOString().split("T")[0],
    type: "vaccination" as "vaccination" | "treatment",
    product: "",
    cost: 0,
    notes: "",
    withdrawalPeriodDays: 0,
    administeredBy: ""
  });

  const [mortalityForm, setMortalityForm] = useState({
    date: new Date().toISOString().split("T")[0],
    count: 0,
    cause: "Disease" as any,
    notes: ""
  });

  const [weighForm, setWeighForm] = useState({
    date: new Date().toISOString().split("T")[0],
    sampleSize: 0,
    averageWeightKg: 0,
    remarks: ""
  });

  const [sellForm, setSellForm] = useState({
    date: new Date().toISOString().split("T")[0],
    buyerName: "",
    quantity: 0,
    sellBy: "bird" as "bird" | "weight", // toggle price per bird or price per kg
    pricePerUnit: 0, // per bird or per kg
    averageWeightKg: 0,
    paymentMethod: "Cash",
  });

  const [marketPriceForm, setMarketPriceForm] = useState({
    price: 0
  });

  // Default Broiler Vaccine Suggestions helper
  const defaultVaccines = [
    { age: "Day 1", name: "Marek's Vaccine", doneAt: "Hatchery" },
    { age: "Day 7-10", name: "Newcastle+IB (Gumboro)", doneAt: "Farm" },
    { age: "Day 14", name: "Gumboro (Infectious Bursal Disease)", doneAt: "Farm" },
    { age: "Day 18", name: "Newcastle Booster", doneAt: "Farm" }
  ];

  // Helper: auto-generate batch name
  const suggestBatchName = () => {
    const count = broilerBatches.length + 1;
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const now = new Date();
    return `Broiler Batch #${count} – ${months[now.getMonth()]} ${now.getFullYear()}`;
  };

  // Helper: compute age in days
  const getAgeInDays = (dateAcquired: string) => {
    const diff = Date.now() - new Date(dateAcquired).getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    return days < 0 ? 0 : days;
  };

  // Double-Entry Ledger Poster
  const postLedger = (debitCode: string, creditCode: string, amount: number) => {
    if (isNaN(amount) || amount <= 0) return;
    setAccounts(accounts.map(acc => {
      let bal = acc.balance;
      if (acc.code === debitCode) bal += amount;
      if (acc.code === creditCode) bal -= amount; // credit reduces asset or increases liability/equity/revenue
      return { ...acc, balance: bal };
    }));
  };

  // STEP 1 WIZARD SAVE -> GOTO STEP 2
  const handleWizardNext = () => {
    setWizardStep(2);
  };

  // COMPLETED WIZARD SAVE
  const handleCreateBatch = () => {
    const finalSource = (newBatch.source === "Other (Custom)" ? newBatch.customSource : newBatch.source) || "Hybrid Poultry Farm (Z) Limited";
    const totalCost = newBatch.initialHeadcount * newBatch.acquisitionCostPerBird;
    
    const batchId = `BRO-${Date.now().toString().slice(-6)}`;
    const batchName = suggestBatchName();

    // Auto-register Hatchery Supplier if not present
    let matchedSup = suppliers.find(s => s.name.toLowerCase() === finalSource.trim().toLowerCase());
    let supplierId = matchedSup?.id;

    if (!matchedSup && onAddSupplier) {
      supplierId = `SUP-HATCHERY-${Date.now()}`;
      const newSup: Supplier = {
        id: supplierId,
        name: finalSource.trim(),
        contactPerson: "Hatchery Sales & Dispatch",
        phone: "0971000222",
        email: "",
        address: "Lusaka / Copperbelt Hatchery Depot",
        tpin: "1002345678",
        category: "Hatchery & Day-Old Chicks",
        notes: `Auto-registered from Broiler Batch ${batchName} acquisition on ${newBatch.dateAcquired}`,
        farmId: activeFarm?.id,
        tenantId: activeFarm?.tenantId
      };
      onAddSupplier(newSup);
    }

    const created: PoultryBatch = {
      id: batchId,
      batchId,
      batchName,
      poultryType: "broiler",
      breed: newBatch.breed,
      dateAcquired: newBatch.dateAcquired,
      source: finalSource,
      initialHeadcount: Number(newBatch.initialHeadcount),
      currentHeadcount: Number(newBatch.initialHeadcount),
      acquisitionCostPerBird: Number(newBatch.acquisitionCostPerBird),
      acquisitionCostTotal: totalCost,
      currentMarketPricePerBird: Number(newBatch.currentMarketPricePerBird),
      currentBatchValuation: Number(newBatch.initialHeadcount) * Number(newBatch.currentMarketPricePerBird),
      cumulativeFeedCost: 0,
      cumulativeHealthCost: 0,
      cumulativeMortalityLoss: 0,
      status: "active",
      photoUrl: newBatch.photoUrl || undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: "Farm Operator",
      tenantId: activeFarm?.tenantId || "default",
      farmId: activeFarm?.id || "default",
      feedLogs: [],
      healthLogs: [],
      mortalityLogs: [],
      salesLogs: [],
      valuationHistory: [],
      targetSaleWeight: Number(newBatch.targetSaleWeight),
      hasPendingWrites: true,
      _pendingSync: true
    };

    onAddBatch(created);

    // Ledger: Debit Poultry Acquisition Cost (5211), Credit Bank Operational (1010)
    postLedger("5211", "1010", totalCost);

    // Auto-post Day-Old Chicks Cost to Continuous Expenses & Cash book Disbursals
    if (onAddExpense && totalCost > 0) {
      const expenseTx = {
        id: `EXP-CHICKS-${Date.now()}`,
        supplierId: supplierId || `SUP-${Date.now()}`,
        supplierName: finalSource,
        date: newBatch.dateAcquired,
        taxSystem: "Exempt",
        taxAmount: 0,
        subtotal: totalCost,
        total: totalCost,
        amount: totalCost,
        farmId: activeFarm?.id,
        tenantId: activeFarm?.tenantId,
        hasPendingWrites: true,
        _pendingSync: true,
        rows: [
          {
            category: "Poultry Day-Old Chicks / Flock Acquisition",
            description: `Day-Old Chick Acquisition: ${newBatch.initialHeadcount} ${newBatch.breed} chicks @ ${currencySymbol}${newBatch.acquisitionCostPerBird}/chick for flock ${batchName} from ${finalSource}`,
            quantity: Number(newBatch.initialHeadcount),
            unitPrice: Number(newBatch.acquisitionCostPerBird),
            amount: totalCost,
            coaCode: "5211",
            allocationType: "poultry_batch",
            poultryBatchId: batchId,
            poultryBatchName: batchName
          }
        ]
      };
      onAddExpense(expenseTx);
    }

    writeAuditLog("CREATE", "Poultry", batchId, `Registered Broiler flock batch: ${batchName} with headcount ${newBatch.initialHeadcount} from ${finalSource}. Posted chick expense ${currencySymbol}${totalCost}.`);

    // Reset Form & Close
    setIsRegWizardOpen(false);
    setWizardStep(1);
    setNewBatch({
      breed: "Ross 308",
      dateAcquired: new Date().toISOString().split("T")[0],
      source: "Hybrid Poultry Farm (Z) Limited",
      customSource: "",
      initialHeadcount: 500,
      acquisitionCostPerBird: 12.0,
      photoUrl: "",
      currentMarketPricePerBird: 65.0,
      targetSaleWeight: 2.2,
    });
  };

  // LOG FEED SUBMIT
  const handleLogFeed = () => {
    if (!selectedBatch) return;

    const headcount = selectedBatch.currentHeadcount || 1;
    const qtyKg = Number(feedForm.quantityKg);
    const cost = Number(feedForm.cost);
    const gramsPerBird = (qtyKg * 1000) / headcount;
    const dailyCostPerBird = cost / headcount;

    const logId = `F-${Date.now().toString().slice(-4)}`;
    const newLog: PoultryFeedLog = {
      id: logId,
      date: feedForm.date,
      feedType: feedForm.feedType,
      quantityKg: qtyKg,
      cost,
      fedBy: feedForm.fedBy,
      dailyConsumptionPerBirdGrams: gramsPerBird,
      dailyCostPerBird: dailyCostPerBird,
      costPerKg: qtyKg > 0 ? cost / qtyKg : 0
    };

    const updated = {
      ...selectedBatch,
      feedLogs: [...selectedBatch.feedLogs, newLog],
      cumulativeFeedCost: selectedBatch.cumulativeFeedCost + cost,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    // Ledger: Debit Poultry Feed & Crumbles Cost (5210), Credit Bank Operational (1010)
    postLedger("5210", "1010", cost);

    if (onAddExpense) {
      onAddExpense({
        id: `EXP-FEED-${Date.now()}`,
        supplierId: "SUP-FEED-INTERNAL",
        supplierName: "Poultry Feed Allocation",
        date: feedForm.date,
        taxSystem: "Exempt",
        taxAmount: 0,
        subtotal: cost,
        total: cost,
        amount: cost,
        farmId: activeFarm?.id,
        rows: [
          {
            category: "Poultry Feed",
            description: `Broiler feed intake for ${selectedBatch.batchName}: ${qtyKg}kg ${feedForm.feedType}`,
            quantity: qtyKg,
            unitPrice: qtyKg > 0 ? cost / qtyKg : 0,
            amount: cost,
            coaCode: "5210"
          }
        ]
      });
    }

    writeAuditLog("CREATE", "Poultry Feed", selectedBatch.batchId, `Logged feed log for batch ${selectedBatch.batchName}: ${qtyKg}kg (${gramsPerBird.toFixed(1)}g/bird) costing ${currencySymbol}${cost}`);
    
    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // LOG HEALTH SUBMIT
  const handleLogHealth = () => {
    if (!selectedBatch) return;

    const headcount = selectedBatch.currentHeadcount || 1;
    const cost = Number(healthForm.cost);

    const logId = `H-${Date.now().toString().slice(-4)}`;
    const newLog: PoultryHealthEvent = {
      id: logId,
      date: healthForm.date,
      type: healthForm.type,
      product: healthForm.product,
      cost,
      notes: healthForm.notes,
      withdrawalPeriodDays: Number(healthForm.withdrawalPeriodDays),
      withdrawalCloseDate: healthForm.withdrawalPeriodDays > 0 
        ? new Date(new Date(healthForm.date).getTime() + Number(healthForm.withdrawalPeriodDays) * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
        : undefined,
      administeredBy: healthForm.administeredBy || activeFarm?.ownerName || "Operator",
      birdsTreated: headcount,
      unitCost: cost / headcount
    };

    const updated = {
      ...selectedBatch,
      healthLogs: [...selectedBatch.healthLogs, newLog],
      cumulativeHealthCost: selectedBatch.cumulativeHealthCost + cost,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    // Ledger: Debit Veterinary, Meds & Fingerling Purchase (5300), Credit Bank (1010)
    postLedger("5300", "1010", cost);

    writeAuditLog("CREATE", "Poultry Health", selectedBatch.batchId, `Logged health treatment for batch ${selectedBatch.batchName}: ${healthForm.product}`);
    
    setActiveLogType(null);
    setSelectedBatch(null);
  };

  const handleEditHeadcount = () => {
    if (!selectedBatch) return;
    const oldHead = selectedBatch.currentHeadcount;
    const newHead = Math.max(0, Number(editHeadcountValue));
    
    const updated = {
      ...selectedBatch,
      currentHeadcount: newHead,
      currentBatchValuation: newHead * selectedBatch.currentMarketPricePerBird,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);
    writeAuditLog("POULTRY_EDIT_HEADCOUNT", "Poultry", selectedBatch.batchId, `Manually adjusted Broiler headcount from ${oldHead} to ${newHead} (Reason: ${editHeadcountReason})`);
    alert(`Successfully adjusted headcount from ${oldHead} to ${newHead}.`);
    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // LOG MORTALITY SUBMIT
  const handleLogMortality = () => {
    if (!selectedBatch) return;

    // Calculate current cost-to-date-per-bird = (Acquisition Cost Total + Feed Cost + Health Cost) / Initial Headcount
    const totalExpenses = selectedBatch.acquisitionCostTotal + selectedBatch.cumulativeFeedCost + selectedBatch.cumulativeHealthCost;
    const costPerBirdSoFar = totalExpenses / selectedBatch.initialHeadcount;
    const lossValue = Number(mortalityForm.count) * costPerBirdSoFar;

    const logId = `M-${Date.now().toString().slice(-4)}`;
    const newLog: PoultryMortalityLog = {
      id: logId,
      date: mortalityForm.date,
      count: Number(mortalityForm.count),
      cause: mortalityForm.cause,
      lossValue: lossValue,
      notes: mortalityForm.notes
    };

    const newHeadcount = Math.max(0, selectedBatch.currentHeadcount - Number(mortalityForm.count));

    const updated = {
      ...selectedBatch,
      currentHeadcount: newHeadcount,
      mortalityLogs: [...selectedBatch.mortalityLogs, newLog],
      cumulativeMortalityLoss: selectedBatch.cumulativeMortalityLoss + lossValue,
      currentBatchValuation: newHeadcount * selectedBatch.currentMarketPricePerBird,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    // Ledger: Debit Poultry Mortality Loss (5901), Credit Biological Assets - Poultry Flocks (1430)
    postLedger("5901", "1430", lossValue);

    writeAuditLog("CREATE", "Poultry Mortality", selectedBatch.batchId, `Logged mortality of ${mortalityForm.count} birds for batch ${selectedBatch.batchName}`);
    
    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // LOG SAMPLE WEIGH SUBMIT
  const handleLogWeigh = () => {
    if (!selectedBatch) return;

    const logId = `W-${Date.now().toString().slice(-4)}`;
    const newSample = {
      id: logId,
      date: weighForm.date,
      sampleSize: Number(weighForm.sampleSize),
      averageWeightKg: Number(weighForm.averageWeightKg),
      remarks: weighForm.remarks
    };

    const updated = {
      ...selectedBatch,
      weightSamples: [...(selectedBatch.weightSamples || []), newSample],
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    writeAuditLog("CREATE", "Poultry Growth", selectedBatch.batchId, `Logged sample weighing of average ${weighForm.averageWeightKg}kg for batch ${selectedBatch.batchName}`);
    
    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // UPDATE MARKET PRICE SUBMIT
  const handleUpdatePrice = () => {
    if (!selectedBatch) return;

    const oldPrice = selectedBatch.currentMarketPricePerBird;
    const newPrice = Number(marketPriceForm.price);

    const historyItem = {
      date: new Date().toISOString().split("T")[0],
      oldPrice,
      newPrice,
      changedBy: "Farm Operator"
    };

    const updated = {
      ...selectedBatch,
      currentMarketPricePerBird: newPrice,
      currentBatchValuation: selectedBatch.currentHeadcount * newPrice,
      valuationHistory: [...(selectedBatch.valuationHistory || []), historyItem],
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    writeAuditLog("UPDATE", "Poultry Valuation", selectedBatch.batchId, `Updated bird market price for ${selectedBatch.batchName} from ${oldPrice} to ${newPrice}`);

    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // SELL BIRD SUBMIT
  const handleSellBirds = () => {
    if (!selectedBatch) return;

    const qty = Number(sellForm.quantity);
    let amount = 0;
    if (sellForm.sellBy === "bird") {
      amount = qty * Number(sellForm.pricePerUnit);
    } else {
      // Per KG: weight * qty * pricePerKg
      amount = qty * Number(sellForm.averageWeightKg) * Number(sellForm.pricePerUnit);
    }

    const logId = `S-${Date.now().toString().slice(-4)}`;
    const newSale: PoultrySalesLog = {
      id: logId,
      date: sellForm.date,
      quantity: qty,
      amount: amount,
      pricePerUnit: Number(sellForm.pricePerUnit),
      chargeType: sellForm.sellBy === "bird" ? "PER_BIRD" : "PER_KG",
      averageWeightKg: sellForm.sellBy === "weight" ? Number(sellForm.averageWeightKg) : undefined,
      buyerName: sellForm.buyerName,
      paymentMethod: sellForm.paymentMethod
    };

    const newHeadcount = Math.max(0, selectedBatch.currentHeadcount - qty);
    const isNowSoldOut = newHeadcount === 0;

    // Calculate proportional cost of birds sold (COGS)
    const totalExpenses = selectedBatch.acquisitionCostTotal + selectedBatch.cumulativeFeedCost + selectedBatch.cumulativeHealthCost;
    const costPerBirdSoFar = totalExpenses / selectedBatch.initialHeadcount;
    const cogsAmount = qty * costPerBirdSoFar;

    const updated: PoultryBatch = {
      ...selectedBatch,
      currentHeadcount: newHeadcount,
      status: isNowSoldOut ? "sold_out" : "active",
      salesLogs: [...selectedBatch.salesLogs, newSale],
      currentBatchValuation: newHeadcount * selectedBatch.currentMarketPricePerBird,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    // Ledger Postings:
    // 1. Debit Bank (1010), Credit Live Bird Sales Revenue (4210) by transaction amount
    postLedger("1010", "4210", amount);

    // 2. Debit Cost of Birds Sold (COGS) (5212), Credit Biological Assets - Poultry (1430) by COGS amount
    postLedger("5212", "1430", cogsAmount);

    writeAuditLog("CREATE", "Poultry Sale", selectedBatch.batchId, `Sold ${qty} birds from batch ${selectedBatch.batchName} for total ${amount}`);

    // Call callback to open and print the sale certificate!
    onShowDocument("certificate", {
      farmName: activeFarm?.name || "Mabala Registered Farm",
      date: sellForm.date,
      reference: logId,
      buyerName: sellForm.buyerName,
      quantity: qty,
      pricePerUnit: Number(sellForm.pricePerUnit),
      totalAmount: amount,
      paymentMethod: sellForm.paymentMethod,
      currencySymbol,
      breed: selectedBatch.breed,
      weightKg: sellForm.sellBy === "weight" ? Number(sellForm.averageWeightKg) : undefined,
      chargeType: sellForm.sellBy === "bird" ? "PER_BIRD" : "PER_KG"
    });

    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // EXCEL / CSV / PDF EXPORTER
  const exportRegistry = (format: "csv" | "excel") => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Batch Name,Breed,Age (Days),Headcount,Valuation,Cumulative Feed,Cumulative Health,Mortality Rate %,Status\n";
    
    broilerBatches.forEach(b => {
      const age = getAgeInDays(b.dateAcquired);
      const totalDead = b.mortalityLogs.reduce((sum, m) => sum + m.count, 0);
      const mRate = ((totalDead / b.initialHeadcount) * 100).toFixed(1);
      csvContent += `"${b.batchName}","${b.breed}",${age},${b.currentHeadcount},${b.currentBatchValuation},${b.cumulativeFeedCost},${b.cumulativeHealthCost},${mRate}%,${b.status}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `mabala_broilers_registry.${format === "csv" ? "csv" : "xls"}`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 text-slate-800" id="broiler-module-container">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Flame className="text-amber-500 fill-amber-500/10" size={26} />
            Broiler Production
          </h2>
          <p className="text-xs text-slate-500 font-semibold mt-0.5">
            Record feed inputs, vaccination schedules, weight samples, and flock sale ledger postings
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => exportRegistry("csv")}
            className="px-3.5 py-2 border border-slate-200 text-slate-600 rounded-xl text-xs font-bold bg-white hover:bg-slate-50 transition-all cursor-pointer flex items-center gap-1.5"
          >
            <BookOpen size={14} />
            Export CSV
          </button>
          <button
            onClick={() => {
              setWizardStep(1);
              setIsRegWizardOpen(true);
            }}
            className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white rounded-xl text-xs font-black shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Plus size={16} />
            Register Broiler Batch
          </button>
        </div>
      </div>

      {/* Flock Grid Cards */}
      {broilerBatches.length === 0 ? (
        <div className="bg-slate-50 rounded-3xl p-12 text-center border border-dashed border-slate-200">
          <div className="inline-block bg-amber-100 p-4 rounded-full text-amber-600 mb-3">
            <Flame size={32} />
          </div>
          <h4 className="text-slate-800 font-extrabold text-sm">No Active Broiler Batches</h4>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto font-medium leading-relaxed">
            Begin meat bird production cycles by registering your first broiler chick intake batch details.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {broilerBatches.map(b => {
            const age = getAgeInDays(b.dateAcquired);
            const totalDead = b.mortalityLogs.reduce((sum, m) => sum + m.count, 0);
            const mortalityRate = b.initialHeadcount > 0 ? (totalDead / b.initialHeadcount) * 100 : 0;
            const expensesToDate = b.acquisitionCostTotal + b.cumulativeFeedCost + b.cumulativeHealthCost;
            const costPerBird = b.currentHeadcount > 0 ? expensesToDate / b.initialHeadcount : 0;

            // ADG Calculation
            const latestSample = b.weightSamples && b.weightSamples.length > 0 
              ? b.weightSamples[b.weightSamples.length - 1] 
              : null;
            const currentAvgWeightG = latestSample ? latestSample.averageWeightKg * 1000 : 40; // 40g day-old chick estimation
            const adgG = age > 0 ? (currentAvgWeightG - 40) / age : 0;

            // FCR Calculation
            const totalFeedKg = b.feedLogs.reduce((sum, f) => sum + f.quantityKg, 0);
            const estBiomassKg = b.currentHeadcount * (currentAvgWeightG / 1000);
            const fcr = estBiomassKg > 0 ? totalFeedKg / estBiomassKg : 0;

            return (
              <div 
                key={b.id} 
                className={`bg-white rounded-3xl border shadow-xs flex flex-col justify-between overflow-hidden transition-all relative ${
                  b.status === "sold_out" ? "border-slate-150 opacity-75" : "border-slate-100 hover:shadow-md"
                }`}
              >
                {/* Visual Header */}
                <div className="p-5 border-b border-slate-50 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-extrabold text-slate-900 text-sm truncate max-w-[160px] sm:max-w-[200px]" title={b.batchName}>{b.batchName}</h3>
                      <p className="text-[10px] text-slate-400 font-bold mt-0.5">Breed: {b.breed} • Ref: {b.batchId}</p>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider ${
                      b.status === "active" ? "bg-emerald-100 text-emerald-800" : "bg-slate-100 text-slate-800"
                    }`}>
                      {b.status}
                    </span>
                  </div>

                  {/* High Alert Mortality threshold flag (>2%) */}
                  {mortalityRate > 2 && b.status === "active" && (
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 border border-red-100 text-red-700 rounded-xl text-[10px] font-bold animate-pulse">
                      <ShieldAlert size={12} className="flex-shrink-0" />
                      Warning: Mortality threshold exceeded ({mortalityRate.toFixed(1)}%)
                    </div>
                  )}

                  {/* Core Metrics Grid */}
                  <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                    <div className="bg-slate-50 p-2 rounded-2xl min-w-0">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block truncate">Age in Days</span>
                      <strong className="text-slate-800 text-[11px] sm:text-xs md:text-sm font-black block truncate" title={`${age} Days`}>{age} Days</strong>
                    </div>
                    <div className="bg-slate-50 p-2 rounded-2xl min-w-0">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block truncate">Flock Headcount</span>
                      <strong className="text-slate-800 text-[11px] sm:text-xs md:text-sm font-black block truncate" title={`${b.currentHeadcount} / ${b.initialHeadcount}`}>{b.currentHeadcount} / {b.initialHeadcount}</strong>
                    </div>
                    <div className="bg-slate-50 p-2 rounded-2xl min-w-0">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block truncate">Valuation</span>
                      <strong className="text-emerald-700 text-[11px] sm:text-xs md:text-sm font-black block truncate" title={`${currencySymbol}${b.currentBatchValuation.toLocaleString()}`}>
                        {currencySymbol}{b.currentBatchValuation.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                      </strong>
                    </div>
                    <div className="bg-slate-50 p-2 rounded-2xl min-w-0">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block truncate">Cost / Bird</span>
                      <strong className="text-slate-800 text-[11px] sm:text-xs md:text-sm font-black block truncate" title={`${currencySymbol}${costPerBird.toFixed(2)}`}>
                        {currencySymbol}{costPerBird.toFixed(1)}
                      </strong>
                    </div>
                  </div>

                  {/* ADG & FCR Growth Performance row */}
                  {b.status === "active" && (
                    <div className="grid grid-cols-2 gap-3 border-t border-slate-50 pt-2 text-[11px] font-semibold text-slate-500">
                      <div>
                        ADG: <strong className="text-slate-800">{adgG.toFixed(1)}g / day</strong>
                      </div>
                      <div>
                        FCR: <strong className="text-slate-800">{fcr > 0 ? fcr.toFixed(2) : "N/A"}</strong>
                      </div>
                    </div>
                  )}
                </div>

                {/* Live FCR Efficiency Metric Card */}
                <div className="px-5 py-2.5 border-b border-slate-100">
                  <FcrMetricCard batch={b} />
                </div>

                {/* Dashboard logs summary list */}
                <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-100 text-[10px] text-slate-500 space-y-1">
                  <div className="flex justify-between">
                    <span>Cumulative Feed:</span>
                    <strong className="text-slate-700">{currencySymbol}{b.cumulativeFeedCost.toLocaleString()} ({totalFeedKg}kg)</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Cumulative Health:</span>
                    <strong className="text-slate-700">{currencySymbol}{b.cumulativeHealthCost.toLocaleString()}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Mortality count:</span>
                    <strong className={totalDead > 0 ? "text-red-600 font-bold" : "text-slate-700"}>
                      {totalDead} dead ({mortalityRate.toFixed(1)}% rate)
                    </strong>
                  </div>
                </div>

                {/* Batch Action Ribbons */}
                <div className="p-3.5 bg-white grid grid-cols-3 gap-1">
                  {b.status === "active" ? (
                    <>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setActiveLogType("feed");
                        }}
                        className="py-2 text-[10px] font-black text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        + Feed
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setActiveLogType("health");
                        }}
                        className="py-2 text-[10px] font-black text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        + Health
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setActiveLogType("mortality");
                        }}
                        className="py-2 text-[10px] font-black text-red-600 hover:bg-red-50 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        + Dead
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setActiveLogType("weigh");
                        }}
                        className="py-2 text-[10px] font-black text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        Weigh
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setMarketPriceForm({ price: b.currentMarketPricePerBird });
                          setActiveLogType("edit_price");
                        }}
                        className="py-2 text-[10px] font-black text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        Valuate
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setEditHeadcountValue(b.currentHeadcount);
                          setActiveLogType("edit_headcount");
                        }}
                        className="py-2 text-[10px] font-black text-rose-700 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        Adjust
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setSellForm({
                            ...sellForm,
                            quantity: b.currentHeadcount,
                            pricePerUnit: b.currentMarketPricePerBird
                          });
                          setActiveLogType("sell");
                        }}
                        className="py-2 text-[10px] font-black text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        Sell Batch
                      </button>
                    </>
                  ) : (
                    <div className="col-span-3 text-center py-2 text-[10px] font-bold text-slate-400">
                      Flock production cycle finalized
                    </div>
                  )}

                  {/* Universal P&L & Delete Row */}
                  <div className="col-span-3 flex items-center justify-between border-t border-slate-100 pt-2 mt-1 gap-2">
                    <button
                      onClick={() => {
                        setSelectedBatch(b);
                        setActiveLogType("p_and_l");
                      }}
                      className="text-[10px] font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <PieChart size={12} />
                      Cost Breakdown & P&L
                    </button>
                    <button
                      onClick={() => {
                        if (confirm("Are you sure you want to delete this broiler batch? All underlying histories will be removed.")) {
                          onDeleteBatch(b.id);
                        }
                      }}
                      className="text-[9px] font-bold text-red-400 hover:text-red-600 cursor-pointer"
                    >
                      Delete Batch
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* REGISTRATION WIZARD DIALOG (2-Step) */}
      {isRegWizardOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden flex flex-col shadow-2xl border border-slate-100 animate-fade-in">
            {/* Header */}
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
              <div>
                <h3 className="font-extrabold text-slate-900 text-sm">Register Broiler Batch</h3>
                <p className="text-[10px] text-slate-400 font-bold">Step {wizardStep} of 2</p>
              </div>
              <button onClick={() => setIsRegWizardOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X size={18} />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 space-y-4">
              {wizardStep === 1 ? (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Flock Breed</label>
                      <select
                        value={newBatch.breed}
                        onChange={(e) => setNewBatch({ ...newBatch, breed: e.target.value })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      >
                        <option>Ross 308</option>
                        <option>Cobb 500</option>
                        <option>Sasso</option>
                        <option>Boschveld</option>
                        <option>Local/Village</option>
                        <option>Quails</option>
                        <option>Geese</option>
                        <option>Ducks</option>
                        <option>Guinea Fowls</option>
                        <option>Other-custom</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Date Acquired</label>
                      <input
                        type="date"
                        value={newBatch.dateAcquired}
                        onChange={(e) => setNewBatch({ ...newBatch, dateAcquired: e.target.value })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Supplier / Hatchery Source</label>
                      <button
                        type="button"
                        onClick={() => setShowSupplierModal(true)}
                        className="text-[10px] font-black text-emerald-600 hover:text-emerald-700 underline cursor-pointer"
                      >
                        + Register Supplier
                      </button>
                    </div>
                    <select
                      value={newBatch.source}
                      onChange={(e) => setNewBatch({ ...newBatch, source: e.target.value })}
                      className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                    >
                      <option value="">Select Supplier / Hatchery...</option>
                      <option>Hybrid Poultry Farm (Z) Limited</option>
                      <option>Zamhatch</option>
                      <option>Mega (Quantum Foods Zambia)</option>
                      <option>Ross Breeders Zambia</option>
                      {suppliers.map(s => (
                        <option key={s.id} value={s.name}>{s.name} ({s.category || "Supplier"})</option>
                      ))}
                      <option>Other (Custom)</option>
                    </select>
                    {newBatch.source === "Other (Custom)" && (
                      <input
                        type="text"
                        placeholder="Enter custom supplier name"
                        value={newBatch.customSource}
                        onChange={(e) => setNewBatch({ ...newBatch, customSource: e.target.value })}
                        className="w-full mt-2 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600 animate-slide-down"
                      />
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Initial Headcount</label>
                      <input
                        type="number"
                        value={newBatch.initialHeadcount}
                        onChange={(e) => setNewBatch({ ...newBatch, initialHeadcount: Math.max(1, Number(e.target.value)) })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Cost per Chick ({currencySymbol})</label>
                      <input
                        type="number"
                        step="0.1"
                        value={newBatch.acquisitionCostPerBird}
                        onChange={(e) => setNewBatch({ ...newBatch, acquisitionCostPerBird: Math.max(0, Number(e.target.value)) })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      />
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3.5 rounded-2xl text-[11px] font-semibold text-slate-500 flex justify-between">
                    <span>Est. Capital Acquisition Posting Total:</span>
                    <strong className="text-slate-850">
                      {currencySymbol}{(newBatch.initialHeadcount * newBatch.acquisitionCostPerBird).toLocaleString()}
                    </strong>
                  </div>
                </>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Initial Market Price / Bird</label>
                      <input
                        type="number"
                        step="0.5"
                        value={newBatch.currentMarketPricePerBird}
                        onChange={(e) => setNewBatch({ ...newBatch, currentMarketPricePerBird: Math.max(0, Number(e.target.value)) })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Target Sale Weight (kg)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={newBatch.targetSaleWeight}
                        onChange={(e) => setNewBatch({ ...newBatch, targetSaleWeight: Math.max(0, Number(e.target.value)) })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      />
                    </div>
                  </div>

                  {/* Seeded default vaccination scheduler notification info */}
                  <div className="bg-amber-50 rounded-2xl p-4 border border-amber-100 text-[11px] text-amber-800 space-y-1">
                    <strong className="font-extrabold flex items-center gap-1">
                      <Sparkles size={14} /> Automatic Vaccination Scheduling Seeds
                    </strong>
                    <p className="font-medium">
                      Upon saving, Mabala schedules Day-1 Marek's, Day 7 Gumboro, and Day 14 Newcastle alerts on the notification engine directly for this batch.
                    </p>
                  </div>
                </>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-between gap-3">
              {wizardStep === 2 && (
                <button
                  onClick={() => setWizardStep(1)}
                  className="px-4 py-2 border border-slate-200 text-slate-500 rounded-xl text-xs font-bold bg-white hover:bg-slate-50 transition-all cursor-pointer"
                >
                  Previous
                </button>
              )}
              <div className="flex-grow"></div>
              {wizardStep === 1 ? (
                <button
                  onClick={handleWizardNext}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md transition-all flex items-center gap-1 cursor-pointer"
                >
                  Next Step <ChevronRight size={14} />
                </button>
              ) : (
                <button
                  onClick={handleCreateBatch}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md transition-all cursor-pointer"
                >
                  Complete Registration
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* DAILY FEED LOG DIALOG */}
      {activeLogType === "feed" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Log Daily Feed intake</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Feed Log Date</label>
                <input
                  type="date"
                  value={feedForm.date}
                  onChange={(e) => setFeedForm({ ...feedForm, date: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Feed Formulation Type</label>
                  <select
                    value={feedForm.feedType}
                    onChange={(e) => setFeedForm({ ...feedForm, feedType: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  >
                    <option>Starter Mash</option>
                    <option>Grower Mash</option>
                    <option>Finisher Mash</option>
                    <option>Custom Mix</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Quantity Fed (Kg)</label>
                  <input
                    type="number"
                    value={feedForm.quantityKg}
                    onChange={(e) => setFeedForm({ ...feedForm, quantityKg: Math.max(1, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Feed Bag Cost ({currencySymbol})</label>
                <input
                  type="number"
                  value={feedForm.cost}
                  onChange={(e) => setFeedForm({ ...feedForm, cost: Math.max(0, Number(e.target.value)) })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">Fed By (Operator)</label>
                {employees && employees.length > 0 ? (
                  <select
                    value={feedForm.fedBy}
                    onChange={(e) => setFeedForm({ ...feedForm, fedBy: e.target.value })}
                    required
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white font-bold text-slate-700"
                  >
                    <option value="">-- Select Employee --</option>
                    {employees.map((emp: any) => (
                      <option key={emp.id} value={emp.name}>
                        {emp.name} ({emp.role})
                      </option>
                    ))}
                  </select>
                ) : (
                  <input type="text" value={feedForm.fedBy} onChange={(e) => setFeedForm({ ...feedForm, fedBy: e.target.value })} required placeholder="e.g. S. Phiri" className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold" />
                )}
              </div>
            </div>

            <button
              onClick={handleLogFeed}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Post Feed Ledger Log
            </button>
          </div>
        </div>
      )}

      {/* HEALTH EVENT / TREATMENT DIALOG */}
      {activeLogType === "health" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Log Health Event / Vaccine</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Event Type</label>
                  <select
                    value={healthForm.type}
                    onChange={(e) => setHealthForm({ ...healthForm, type: e.target.value as any })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  >
                    <option value="vaccination">Vaccination</option>
                    <option value="treatment">Treatment / Ad-Hoc</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Administered Date</label>
                  <input
                    type="date"
                    value={healthForm.date}
                    onChange={(e) => setHealthForm({ ...healthForm, date: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Product / Vaccine Name</label>
                <input
                  type="text"
                  value={healthForm.product}
                  onChange={(e) => setHealthForm({ ...healthForm, product: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Product Cost ({currencySymbol})</label>
                  <input
                    type="number"
                    value={healthForm.cost}
                    onChange={(e) => setHealthForm({ ...healthForm, cost: Math.max(0, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Withdrawal (Days)</label>
                  <input
                    type="number"
                    value={healthForm.withdrawalPeriodDays}
                    onChange={(e) => setHealthForm({ ...healthForm, withdrawalPeriodDays: Math.max(0, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Ad-hoc Notes</label>
                <textarea
                  value={healthForm.notes}
                  onChange={(e) => setHealthForm({ ...healthForm, notes: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  rows={2}
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">Administered By (Operator/Vet)</label>
                {employees && employees.length > 0 ? (
                  <select
                    value={healthForm.administeredBy}
                    onChange={(e) => setHealthForm({ ...healthForm, administeredBy: e.target.value })}
                    required
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white font-bold text-slate-700"
                  >
                    <option value="">-- Select Employee --</option>
                    {employees.map((emp: any) => (
                      <option key={emp.id} value={emp.name}>
                        {emp.name} ({emp.role})
                      </option>
                    ))}
                  </select>
                ) : (
                  <input type="text" value={healthForm.administeredBy} onChange={(e) => setHealthForm({ ...healthForm, administeredBy: e.target.value })} required placeholder="e.g. S. Phiri" className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold" />
                )}
              </div>
            </div>

            <button
              onClick={handleLogHealth}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Post Health Event Voucher
            </button>
          </div>
        </div>
      )}

      {/* DAILY MORTALITY DIALOG */}
      {activeLogType === "mortality" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Log Daily mortality</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Mortality Date</label>
                  <input
                    type="date"
                    value={mortalityForm.date}
                    onChange={(e) => setMortalityForm({ ...mortalityForm, date: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Number Dead Today</label>
                  <input
                    type="number"
                    value={mortalityForm.count}
                    onChange={(e) => setMortalityForm({ ...mortalityForm, count: Math.max(1, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Probable Cause Category</label>
                <select
                  value={mortalityForm.cause}
                  onChange={(e) => setMortalityForm({ ...mortalityForm, cause: e.target.value as any })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                >
                  <option>Disease</option>
                  <option>Heat Stress</option>
                  <option>Predation</option>
                  <option>Culled</option>
                  <option>Other</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Notes / Observations</label>
                <textarea
                  value={mortalityForm.notes}
                  onChange={(e) => setMortalityForm({ ...mortalityForm, notes: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  rows={2}
                />
              </div>
            </div>

            <button
              onClick={handleLogMortality}
              className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Log Loss and Reduce Headcount
            </button>
          </div>
        </div>
      )}

      {/* WEIGH SAMPLE DIALOG */}
      {activeLogType === "weigh" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Log Growth Weight Sample</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Sample Date</label>
                  <input
                    type="date"
                    value={weighForm.date}
                    onChange={(e) => setWeighForm({ ...weighForm, date: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Sample Size (Birds)</label>
                  <input
                    type="number"
                    value={weighForm.sampleSize}
                    onChange={(e) => setWeighForm({ ...weighForm, sampleSize: Math.max(1, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Average Weight per Bird (Kg)</label>
                <input
                  type="number"
                  step="0.01"
                  value={weighForm.averageWeightKg}
                  onChange={(e) => setWeighForm({ ...weighForm, averageWeightKg: Math.max(0.01, Number(e.target.value)) })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Remarks</label>
                <input
                  type="text"
                  value={weighForm.remarks}
                  onChange={(e) => setWeighForm({ ...weighForm, remarks: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>
            </div>

            <button
              onClick={handleLogWeigh}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Post Sample & Extrapolate Biomass
            </button>
          </div>
        </div>
      )}

      {/* EDIT PRICE DIALOG */}
      {activeLogType === "edit_price" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Update Market Valuation Price</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Current Market Price / Bird ({currencySymbol})</label>
              <input
                type="number"
                step="0.5"
                value={marketPriceForm.price}
                onChange={(e) => setMarketPriceForm({ price: Math.max(0, Number(e.target.value)) })}
                className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
              />
            </div>

            <button
              onClick={handleUpdatePrice}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Update Valuation Price
            </button>
          </div>
        </div>
      )}

      {/* EDIT HEADCOUNT DIALOG */}
      {activeLogType === "edit_headcount" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Adjust Broiler Headcount</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Adjust Headcount (Birds)</label>
              <input
                type="number"
                value={editHeadcountValue}
                onChange={(e) => setEditHeadcountValue(Math.max(0, Number(e.target.value)))}
                className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-mono font-bold"
              />
              <p className="text-[9px] text-slate-400 mt-1">This will directly edit the recorded headcount of birds in the batch.</p>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Reason for Adjustment</label>
              <select
                value={editHeadcountReason}
                onChange={(e) => setEditHeadcountReason(e.target.value)}
                className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white font-medium text-slate-700"
              >
                <option value="Manual audit correction">Manual audit correction</option>
                <option value="Transfer to other farm module">Transfer to other farm module</option>
                <option value="Gift or donation given">Gift or donation given</option>
                <option value="Unrecorded mortality correction">Unrecorded mortality correction</option>
                <option value="Unrecorded sales correction">Unrecorded sales correction</option>
              </select>
            </div>

            <button
              onClick={handleEditHeadcount}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Adjust Headcount
            </button>
          </div>
        </div>
      )}

      {/* SELL BIRD DIALOG (PARTIAL/FULL CLOSE OUT) */}
      {activeLogType === "sell" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Sell birds / close-out batch</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Sale Date</label>
                  <input
                    type="date"
                    value={sellForm.date}
                    onChange={(e) => setSellForm({ ...sellForm, date: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Quantity to Sell</label>
                  <input
                    type="number"
                    value={sellForm.quantity}
                    onChange={(e) => setSellForm({ ...sellForm, quantity: Math.min(selectedBatch.currentHeadcount, Math.max(1, Number(e.target.value))) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                  <span className="text-[9px] text-slate-400 font-bold">Max available: {selectedBatch.currentHeadcount}</span>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Customer / Buyer Name</label>
                <input
                  type="text"
                  value={sellForm.buyerName}
                  onChange={(e) => setSellForm({ ...sellForm, buyerName: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>

              <div className="bg-slate-50 p-2.5 rounded-2xl flex justify-between items-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Pricing Logic:</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => setSellForm({ ...sellForm, sellBy: "bird" })}
                    className={`px-3 py-1 rounded-lg text-[10px] font-black transition-colors ${
                      sellForm.sellBy === "bird" ? "bg-slate-900 text-white" : "bg-white border border-slate-200 text-slate-500"
                    }`}
                  >
                    Per Bird
                  </button>
                  <button
                    onClick={() => setSellForm({ ...sellForm, sellBy: "weight" })}
                    className={`px-3 py-1 rounded-lg text-[10px] font-black transition-colors ${
                      sellForm.sellBy === "weight" ? "bg-slate-900 text-white" : "bg-white border border-slate-200 text-slate-500"
                    }`}
                  >
                    Per Kg
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                    {sellForm.sellBy === "bird" ? "Price per Bird" : "Price per Kg"} ({currencySymbol})
                  </label>
                  <input
                    type="number"
                    value={sellForm.pricePerUnit}
                    onChange={(e) => setSellForm({ ...sellForm, pricePerUnit: Math.max(1, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>

                {sellForm.sellBy === "weight" && (
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Average Weight (Kg)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={sellForm.averageWeightKg}
                      onChange={(e) => setSellForm({ ...sellForm, averageWeightKg: Math.max(0.1, Number(e.target.value)) })}
                      className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                    />
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Payment Method</label>
                  <select
                    value={sellForm.paymentMethod}
                    onChange={(e) => setSellForm({ ...sellForm, paymentMethod: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  >
                    <option>Cash</option>
                    <option>Mobile Money</option>
                    <option>Bank Transfer</option>
                    <option>Invoice / Credit terms</option>
                  </select>
                </div>

                <div className="bg-emerald-50 p-2.5 rounded-2xl flex flex-col justify-center">
                  <span className="text-[9px] font-black text-emerald-800 uppercase tracking-widest block text-center">Gross Revenue</span>
                  <strong className="text-emerald-700 text-sm font-black text-center mt-0.5">
                    {currencySymbol}
                    {(sellForm.sellBy === "bird" 
                      ? sellForm.quantity * sellForm.pricePerUnit
                      : sellForm.quantity * sellForm.averageWeightKg * sellForm.pricePerUnit
                    ).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </strong>
                </div>
              </div>
            </div>

            <button
              onClick={handleSellBirds}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Post Sale & Generate Certificate
            </button>
          </div>
        </div>
      )}

      {/* INDIVIDUAL BATCH P&L & DETAILED COST BREAKDOWN MODAL */}
      {activeLogType === "p_and_l" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto animate-fade-in">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl border border-slate-100 text-slate-800">
            {/* Header */}
            <div className="p-5 bg-slate-950 text-white flex justify-between items-center shrink-0">
              <div>
                <span className="text-[9px] tracking-widest uppercase font-black text-emerald-400">Batch Financial & Cost Center</span>
                <h3 className="text-base font-black uppercase tracking-tight flex items-center gap-2">
                  {selectedBatch.batchId} - {selectedBatch.batchName}
                </h3>
              </div>
              <button 
                onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} 
                className="p-1 px-3 py-1.5 text-xs bg-white/10 hover:bg-white/20 hover:text-white rounded-xl font-bold cursor-pointer transition-all border-none"
              >
                ✕ Close
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
              {/* Detailed Cost Breakdown Split (Feed, Medication, Labour, Misc) */}
              <BatchCostBreakdownSummary
                batch={selectedBatch}
                currencySymbol={currencySymbol}
                expenses={expenses}
                allBatches={batches}
                compact={false}
                showTransactionsList={true}
              />

              {/* Profit & Loss Calculation Statement */}
              {(() => {
                const totalRevenue = selectedBatch.salesLogs.reduce((sum, s) => sum + s.amount, 0);
                const acquisitionCost = selectedBatch.acquisitionCostTotal;
                const feedCost = selectedBatch.cumulativeFeedCost;
                const healthCost = selectedBatch.cumulativeHealthCost;
                const mortalityLoss = selectedBatch.cumulativeMortalityLoss;
                const totalExpenses = acquisitionCost + feedCost + healthCost + mortalityLoss;
                const netProfit = totalRevenue - totalExpenses;
                const totalSold = selectedBatch.salesLogs.reduce((sum, s) => sum + s.quantity, 0);

                return (
                  <div className="space-y-4 text-xs">
                    <h4 className="text-xs font-black uppercase text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-1.5">
                      <DollarSign size={14} className="text-emerald-600" />
                      Flock Profit & Loss Summary
                    </h4>

                    {/* P&L Snapshot banner */}
                    <div className={`p-4 rounded-2xl flex justify-between items-center ${
                      netProfit >= 0 ? "bg-emerald-50 text-emerald-800 border border-emerald-100" : "bg-red-50 text-red-800 border border-red-100"
                    }`}>
                      <div>
                        <span className="text-[9px] font-black uppercase tracking-wider block">Net Profit / Loss</span>
                        <strong className="text-xl font-black">
                          {netProfit >= 0 ? "+" : ""}
                          {currencySymbol}{netProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </strong>
                      </div>
                      <span className="text-[10px] font-bold">
                        {netProfit >= 0 ? "Gain on Flock Cycle" : "Loss on Flock Cycle"}
                      </span>
                    </div>

                    {/* Financial Statement style items */}
                    <div className="border border-slate-100 rounded-2xl overflow-hidden bg-slate-50/50">
                      <div className="bg-slate-50 p-3 font-bold text-slate-700 text-[10px] uppercase tracking-wider border-b border-slate-100 flex justify-between">
                        <span>Total Live Bird Sales Revenue</span>
                        <span className="text-emerald-700 font-black">{currencySymbol}{totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                      </div>

                      <div className="p-3.5 space-y-2 font-medium text-slate-600 bg-white">
                        <div className="flex justify-between text-xs">
                          <span>Acquisition Cost (Day-old Chicks):</span>
                          <span>{currencySymbol}{acquisitionCost.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span>Cumulative Feed Inputs:</span>
                          <span>{currencySymbol}{feedCost.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span>Cumulative Veterinary / Health Care:</span>
                          <span>{currencySymbol}{healthCost.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-xs text-red-600 font-bold">
                          <span>Mortality Losses (Non-Cash):</span>
                          <span>{currencySymbol}{mortalityLoss.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-xs border-t border-slate-100 pt-2 font-black text-slate-800">
                          <span>Total Recorded Expenses to Date:</span>
                          <span>{currencySymbol}{totalExpenses.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    {/* Disposed vs remaining ratio */}
                    <div className="bg-slate-50 p-3.5 rounded-2xl flex justify-between items-center text-[11px] font-semibold text-slate-500 border border-slate-100">
                      <span>Birds Sold: <strong className="text-slate-900">{totalSold} birds</strong></span>
                      <span>Remaining Headcount: <strong className="text-slate-900">{selectedBatch.currentHeadcount} birds</strong></span>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-slate-50 flex justify-end">
              <button 
                onClick={() => { setActiveLogType(null); setSelectedBatch(null); }}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}

      {/* UNIFIED SUPPLIER REGISTRATION MODAL */}
      <UnifiedSupplierModal
        isOpen={showSupplierModal}
        onClose={() => setShowSupplierModal(false)}
        initialCategory="Chicks & Hatchery"
        currencySymbol={currencySymbol}
        farmId={activeFarm?.id || "default-farm"}
        onSaveSupplier={(newSup) => {
          if (onAddSupplier) {
            onAddSupplier(newSup);
          }
          setNewBatch(prev => ({ ...prev, source: newSup.name }));
          setShowSupplierModal(false);
        }}
      />
    </div>
  );
}

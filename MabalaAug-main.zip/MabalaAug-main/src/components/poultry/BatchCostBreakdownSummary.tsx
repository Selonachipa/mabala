import React, { useState, useMemo } from "react";
import { PoultryBatch } from "./types";
import { ExpenseTransaction } from "../../types";
import { 
  DollarSign, Wheat, Stethoscope, Users, Package, 
  TrendingUp, ArrowRight, ShieldCheck, Download, Filter, 
  Receipt, Layers, CheckCircle2, AlertCircle, Sparkles,
  Info, ExternalLink, ChevronDown, ChevronUp, Clock
} from "lucide-react";

export interface CostBreakdownItem {
  id: string;
  txId?: string;
  date: string;
  supplier: string;
  category: "feed" | "medication" | "labour" | "miscellaneous";
  coaCode: string;
  coaName: string;
  description: string;
  quantity: number;
  unitPrice: number;
  amount: number;
  isFinanceSynced: boolean;
}

interface BatchCostBreakdownSummaryProps {
  batch: PoultryBatch;
  currencySymbol: string;
  expenses?: ExpenseTransaction[];
  allBatches?: PoultryBatch[];
  compact?: boolean;
  showTransactionsList?: boolean;
  onOpenFinance?: () => void;
}

export default function BatchCostBreakdownSummary({
  batch,
  currencySymbol,
  expenses = [],
  allBatches = [],
  compact = false,
  showTransactionsList = true,
  onOpenFinance
}: BatchCostBreakdownSummaryProps) {
  const [activeFilter, setActiveFilter] = useState<"all" | "feed" | "medication" | "labour" | "miscellaneous">("all");
  const [isExpanded, setIsExpanded] = useState(!compact);

  // Compile all synced finance entries and local batch log entries
  const { 
    items, 
    feedCost, 
    medCost, 
    labourCost, 
    miscCost, 
    totalCost, 
    syncedFinanceCount 
  } = useMemo(() => {
    const rawItems: CostBreakdownItem[] = [];
    const matchedFinanceTxIds = new Set<string>();

    // 1. Process Synced Finance Module entries
    expenses.forEach(tx => {
      (tx.rows || []).forEach((row, idx) => {
        const cat = (row.category || "").toLowerCase();
        const desc = (row.description || "").toLowerCase();
        const sup = (tx.supplierName || "").toLowerCase();
        const coa = row.coaCode || "";

        // Check if explicitly assigned to this batch
        const isExplicitBatch = 
          row.poultryBatchId === batch.id || 
          row.poultryBatchId === batch.batchId ||
          (row.poultryBatchName && row.poultryBatchName.toLowerCase() === batch.batchName.toLowerCase());

        // Check if text in description references this batch ID or Name
        const isTextMatch = 
          desc.includes(batch.id.toLowerCase()) || 
          desc.includes(batch.batchId.toLowerCase()) || 
          desc.includes(batch.batchName.toLowerCase());

        // Check if it's a farmwide poultry expense to allocate proportionally
        const isFarmwide = (row.allocationType as unknown as string) === "poultry_farmwide";

        if (isExplicitBatch || isTextMatch || isFarmwide) {
          matchedFinanceTxIds.add(tx.id);
          
          let allocatedAmount = Number(row.amount) || 0;
          if (isFarmwide && allBatches.length > 0) {
            const totalHeadcount = allBatches.reduce((sum, b) => sum + (b.currentHeadcount || b.initialHeadcount || 1), 0);
            const myHeadcount = batch.currentHeadcount || batch.initialHeadcount || 1;
            const ratio = totalHeadcount > 0 ? myHeadcount / totalHeadcount : 1 / allBatches.length;
            allocatedAmount = allocatedAmount * ratio;
          }

          // Classify Category
          let categoryType: "feed" | "medication" | "labour" | "miscellaneous" = "miscellaneous";
          let coaName = "General Poultry Direct Cost";

          if (
            coa === "5210" || 
            cat.includes("feed") || 
            desc.includes("feed") || 
            desc.includes("mash") || 
            desc.includes("crumble") || 
            desc.includes("starter") || 
            desc.includes("grower") || 
            desc.includes("finisher") || 
            desc.includes("pellet") ||
            sup.includes("novatek") || 
            sup.includes("tiger animal feeds")
          ) {
            categoryType = "feed";
            coaName = "Feed & Crumbles (COA 5210)";
          } else if (
            coa === "5215" || 
            coa === "5300" || 
            cat.includes("med") || 
            cat.includes("drug") || 
            cat.includes("vaccin") || 
            cat.includes("vet") || 
            desc.includes("drug") || 
            desc.includes("vaccin") || 
            desc.includes("antibiotic") || 
            desc.includes("gumboro") || 
            desc.includes("newcastle") || 
            desc.includes("coccidiostat") || 
            desc.includes("dewormer") ||
            desc.includes("vitamin")
          ) {
            categoryType = "medication";
            coaName = coa === "5300" ? "Vaccines & Vet (COA 5300)" : "Drugs & Meds (COA 5215)";
          } else if (
            coa === "5100" || 
            cat.includes("labour") || 
            cat.includes("labor") || 
            desc.includes("labour") || 
            desc.includes("labor") || 
            desc.includes("worker") || 
            desc.includes("attendant") || 
            desc.includes("caretaker")
          ) {
            categoryType = "labour";
            coaName = "Direct Poultry Labour (COA 5100)";
          } else {
            categoryType = "miscellaneous";
            if (coa === "5211" || cat.includes("chick") || desc.includes("chick")) {
              coaName = "Day-Old Chicks (COA 5211)";
            } else if (coa === "5216" || cat.includes("saw dust") || desc.includes("saw dust") || desc.includes("bedding")) {
              coaName = "Bedding & Saw Dust (COA 5216)";
            } else if (coa === "5217" || cat.includes("charcoal") || desc.includes("charcoal") || desc.includes("heating") || desc.includes("brooding")) {
              coaName = "Heating & Charcoal (COA 5217)";
            } else {
              coaName = "Sundry & Supplies (COA 5214)";
            }
          }

          rawItems.push({
            id: `FIN-${tx.id}-${idx}`,
            txId: tx.id,
            date: tx.date,
            supplier: tx.supplierName || "Agrovet & Farm Payee",
            category: categoryType,
            coaCode: coa || (categoryType === "feed" ? "5210" : categoryType === "medication" ? "5215" : categoryType === "labour" ? "5100" : "5214"),
            coaName,
            description: row.description || (isFarmwide ? `Shared ${row.category} (Flock Allocation)` : row.category),
            quantity: Number(row.quantity) || 1,
            unitPrice: Number(row.unitPrice) || allocatedAmount,
            amount: allocatedAmount,
            isFinanceSynced: true
          });
        }
      });
    });

    const syncedCount = rawItems.length;

    // 2. Check if local batch items (Acquisition, Feed Logs, Health Logs) need inclusion if no duplicate finance entry exists
    const hasFinanceAcquisition = rawItems.some(item => item.coaCode === "5211" || item.description.toLowerCase().includes("chick"));
    if (!hasFinanceAcquisition && batch.acquisitionCostTotal > 0) {
      rawItems.push({
        id: `LOCAL-ACQ-${batch.id}`,
        date: batch.dateAcquired,
        supplier: batch.source || "Hatchery / Chick Supplier",
        category: "miscellaneous",
        coaCode: "5211",
        coaName: "Day-Old Chicks (COA 5211)",
        description: `Flock Intake Acquisition (${batch.initialHeadcount} chicks @ ${currencySymbol}${batch.acquisitionCostPerBird.toFixed(2)})`,
        quantity: batch.initialHeadcount,
        unitPrice: batch.acquisitionCostPerBird,
        amount: batch.acquisitionCostTotal,
        isFinanceSynced: false
      });
    }

    const financeFeedTotal = rawItems.filter(i => i.category === "feed").reduce((sum, i) => sum + i.amount, 0);
    if (financeFeedTotal < batch.cumulativeFeedCost) {
      const diff = batch.cumulativeFeedCost - financeFeedTotal;
      rawItems.push({
        id: `LOCAL-FEED-${batch.id}`,
        date: batch.updatedAt ? batch.updatedAt.split("T")[0] : batch.dateAcquired,
        supplier: "Feed Store Internal Logs",
        category: "feed",
        coaCode: "5210",
        coaName: "Poultry Feed & Crumbles (COA 5210)",
        description: `Cumulative Flock Feed Ration Logs (${batch.feedLogs.reduce((sum, f) => sum + f.quantityKg, 0)} kg total fed)`,
        quantity: batch.feedLogs.reduce((sum, f) => sum + f.quantityKg, 0) || 1,
        unitPrice: diff,
        amount: diff,
        isFinanceSynced: false
      });
    }

    const financeMedTotal = rawItems.filter(i => i.category === "medication").reduce((sum, i) => sum + i.amount, 0);
    if (financeMedTotal < batch.cumulativeHealthCost) {
      const diff = batch.cumulativeHealthCost - financeMedTotal;
      rawItems.push({
        id: `LOCAL-MED-${batch.id}`,
        date: batch.updatedAt ? batch.updatedAt.split("T")[0] : batch.dateAcquired,
        supplier: "Veterinary / Pharmacy Store",
        category: "medication",
        coaCode: "5300",
        coaName: "Vaccines & Medication (COA 5300)",
        description: `Cumulative Veterinary & Flock Treatment Events (${batch.healthLogs.length} events)`,
        quantity: batch.healthLogs.length || 1,
        unitPrice: diff,
        amount: diff,
        isFinanceSynced: false
      });
    }

    // Sort items by date descending
    rawItems.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    // Calculate aggregated totals
    const feedTotal = rawItems.filter(i => i.category === "feed").reduce((s, i) => s + i.amount, 0);
    const medTotal = rawItems.filter(i => i.category === "medication").reduce((s, i) => s + i.amount, 0);
    const labourTotal = rawItems.filter(i => i.category === "labour").reduce((s, i) => s + i.amount, 0);
    const miscTotal = rawItems.filter(i => i.category === "miscellaneous").reduce((s, i) => s + i.amount, 0);
    const grandTotal = feedTotal + medTotal + labourTotal + miscTotal;

    return {
      items: rawItems,
      feedCost: feedTotal,
      medCost: medTotal,
      labourCost: labourTotal,
      miscCost: miscTotal,
      totalCost: grandTotal,
      syncedFinanceCount: syncedCount
    };
  }, [batch, expenses, allBatches, currencySymbol]);

  // Derived percentages and per-bird metrics
  const divisor = Math.max(1, totalCost);
  const feedPct = (feedCost / divisor) * 100;
  const medPct = (medCost / divisor) * 100;
  const labourPct = (labourCost / divisor) * 100;
  const miscPct = (miscCost / divisor) * 100;

  const headcountForPerBird = batch.initialHeadcount > 0 ? batch.initialHeadcount : Math.max(1, batch.currentHeadcount);
  const costPerBird = totalCost / headcountForPerBird;
  const feedCostPerBird = feedCost / headcountForPerBird;
  const medCostPerBird = medCost / headcountForPerBird;
  const labourCostPerBird = labourCost / headcountForPerBird;
  const miscCostPerBird = miscCost / headcountForPerBird;

  // Filtered list of line items
  const filteredItems = useMemo(() => {
    if (activeFilter === "all") return items;
    return items.filter(i => i.category === activeFilter);
  }, [items, activeFilter]);

  const exportBreakdownCSV = () => {
    let csv = "data:text/csv;charset=utf-8,";
    csv += "Date,Category,COA Code,Description,Supplier,Quantity,Unit Price,Amount,Source\n";
    items.forEach(i => {
      csv += `"${i.date}","${i.category}","${i.coaCode}","${i.description.replace(/"/g, '""')}","${i.supplier.replace(/"/g, '""')}",${i.quantity},${i.unitPrice},${i.amount},"${i.isFinanceSynced ? "Finance Synced" : "Local Batch Log"}"\n`;
    });

    const encodedUri = encodeURI(csv);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `flock_cost_breakdown_${batch.batchId}_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-100 shadow-xs overflow-hidden text-slate-800 space-y-4" id={`batch-cost-breakdown-${batch.id}`}>
      {/* Header Bar */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-slate-800 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-mono text-[9px] font-black uppercase tracking-wider border border-emerald-500/30">
              Finance Synced Cost Center
            </span>
            {syncedFinanceCount > 0 && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-sky-500/20 text-sky-300 font-mono text-[9px] font-bold border border-sky-500/30">
                <Receipt size={10} />
                {syncedFinanceCount} Finance Entries
              </span>
            )}
          </div>
          <h3 className="text-base font-black tracking-tight flex items-center gap-2 text-white">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            Flock Cost Breakdown: {batch.batchName} ({batch.batchId})
          </h3>
          <p className="text-[11px] text-slate-300">
            Real-time multi-category cost allocation split across Feed, Medication, Labour, and Miscellaneous inputs.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={exportBreakdownCSV}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-[11px] font-bold transition-colors flex items-center gap-1.5 cursor-pointer border border-white/10"
            title="Download CSV"
          >
            <Download size={13} />
            Export CSV
          </button>
          {compact && (
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-black transition-colors flex items-center gap-1 cursor-pointer"
            >
              {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
              {isExpanded ? "Collapse" : "Expand Split"}
            </button>
          )}
        </div>
      </div>

      <div className="px-4 sm:px-6 pb-6 space-y-5">
        {/* Top Summary Banner: Total Cost & Cost per Bird */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col justify-between">
            <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider flex items-center justify-between">
              Total Production Cost
              <DollarSign size={14} className="text-slate-400" />
            </span>
            <div className="mt-2">
              <strong className="text-xl sm:text-2xl font-black text-slate-900 block tracking-tight">
                {currencySymbol}{totalCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </strong>
              <span className="text-[10px] text-slate-400 font-bold mt-0.5 block">
                Across {items.length} logged expense items
              </span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-100 flex flex-col justify-between">
            <span className="text-[10px] font-black uppercase text-emerald-800 tracking-wider flex items-center justify-between">
              Cost Per Bird
              <TrendingUp size={14} className="text-emerald-600" />
            </span>
            <div className="mt-2">
              <strong className="text-xl sm:text-2xl font-black text-emerald-900 block tracking-tight">
                {currencySymbol}{costPerBird.toFixed(2)}
              </strong>
              <span className="text-[10px] text-emerald-700 font-bold mt-0.5 block">
                Based on {headcountForPerBird} birds headcount
              </span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-100 flex flex-col justify-between">
            <span className="text-[10px] font-black uppercase text-amber-800 tracking-wider flex items-center justify-between">
              Feed-to-Cost Ratio
              <Wheat size={14} className="text-amber-600" />
            </span>
            <div className="mt-2">
              <strong className="text-xl sm:text-2xl font-black text-amber-900 block tracking-tight">
                {feedPct.toFixed(1)}%
              </strong>
              <span className="text-[10px] text-amber-700 font-bold mt-0.5 block">
                {feedPct > 75 ? "⚠️ High Feed Share" : feedPct >= 60 ? "✅ Optimal Benchmark (60-75%)" : "ℹ️ Early Brooding Stage"}
              </span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-100 flex flex-col justify-between">
            <span className="text-[10px] font-black uppercase text-indigo-800 tracking-wider flex items-center justify-between">
              Batch Valuation
              <ShieldCheck size={14} className="text-indigo-600" />
            </span>
            <div className="mt-2">
              <strong className="text-xl sm:text-2xl font-black text-indigo-900 block tracking-tight">
                {currencySymbol}{batch.currentBatchValuation.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </strong>
              <span className="text-[10px] text-indigo-700 font-bold mt-0.5 block">
                {batch.currentHeadcount} birds @ {currencySymbol}{batch.currentMarketPricePerBird.toFixed(1)}
              </span>
            </div>
          </div>
        </div>

        {/* Multi-Segment Proportional Distribution Bar */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs font-bold text-slate-700">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">Expenditure Category Allocation Split</span>
            <span className="text-[11px] text-slate-400 font-mono">100% Total Direct Cost</span>
          </div>

          <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden flex p-0.5 gap-0.5 shadow-inner">
            {feedCost > 0 && (
              <div 
                style={{ width: `${feedPct}%` }}
                className="bg-amber-500 h-full rounded-full transition-all relative group cursor-pointer"
                title={`Feed Costs: ${currencySymbol}${feedCost.toLocaleString()} (${feedPct.toFixed(1)}%)`}
              />
            )}
            {medCost > 0 && (
              <div 
                style={{ width: `${medPct}%` }}
                className="bg-rose-500 h-full rounded-full transition-all relative group cursor-pointer"
                title={`Medication & Vet: ${currencySymbol}${medCost.toLocaleString()} (${medPct.toFixed(1)}%)`}
              />
            )}
            {labourCost > 0 && (
              <div 
                style={{ width: `${labourPct}%` }}
                className="bg-sky-500 h-full rounded-full transition-all relative group cursor-pointer"
                title={`Direct Labour: ${currencySymbol}${labourCost.toLocaleString()} (${labourPct.toFixed(1)}%)`}
              />
            )}
            {miscCost > 0 && (
              <div 
                style={{ width: `${miscPct}%` }}
                className="bg-slate-600 h-full rounded-full transition-all relative group cursor-pointer"
                title={`Miscellaneous & Chicks: ${currencySymbol}${miscCost.toLocaleString()} (${miscPct.toFixed(1)}%)`}
              />
            )}
          </div>
        </div>

        {/* 4 Cost Pillar Cards: Feed, Medication, Labour, Miscellaneous */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Feed Card */}
          <div 
            onClick={() => setActiveFilter(activeFilter === "feed" ? "all" : "feed")}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
              activeFilter === "feed" 
                ? "bg-amber-50/80 border-amber-400 ring-2 ring-amber-400/20 shadow-sm" 
                : "bg-white border-slate-100 hover:border-amber-200 hover:bg-amber-50/30"
            }`}
          >
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="p-2 rounded-xl bg-amber-100 text-amber-800">
                    <Wheat size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-900">Feed Costs</h4>
                    <span className="text-[9px] text-amber-700 font-bold font-mono">COA 5210</span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-900 font-mono">
                  {feedPct.toFixed(1)}%
                </span>
              </div>

              <div className="mt-3">
                <strong className="text-lg font-black text-slate-900 block">
                  {currencySymbol}{feedCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </strong>
                <span className="text-[10px] text-slate-500 font-semibold block mt-0.5">
                  {currencySymbol}{feedCostPerBird.toFixed(2)} / bird
                </span>
              </div>
            </div>

            <div className="mt-3 pt-2.5 border-t border-slate-100 text-[10px] text-slate-500 flex justify-between items-center">
              <span>Filter Feed Rows</span>
              <ArrowRight size={12} className={activeFilter === "feed" ? "text-amber-600 rotate-90 transition-transform" : "text-slate-400"} />
            </div>
          </div>

          {/* Medication & Vet Card */}
          <div 
            onClick={() => setActiveFilter(activeFilter === "medication" ? "all" : "medication")}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
              activeFilter === "medication" 
                ? "bg-rose-50/80 border-rose-400 ring-2 ring-rose-400/20 shadow-sm" 
                : "bg-white border-slate-100 hover:border-rose-200 hover:bg-rose-50/30"
            }`}
          >
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="p-2 rounded-xl bg-rose-100 text-rose-800">
                    <Stethoscope size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-900">Medication & Vet</h4>
                    <span className="text-[9px] text-rose-700 font-bold font-mono">COA 5215/5300</span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-100 text-rose-900 font-mono">
                  {medPct.toFixed(1)}%
                </span>
              </div>

              <div className="mt-3">
                <strong className="text-lg font-black text-slate-900 block">
                  {currencySymbol}{medCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </strong>
                <span className="text-[10px] text-slate-500 font-semibold block mt-0.5">
                  {currencySymbol}{medCostPerBird.toFixed(2)} / bird
                </span>
              </div>
            </div>

            <div className="mt-3 pt-2.5 border-t border-slate-100 text-[10px] text-slate-500 flex justify-between items-center">
              <span>Filter Med Rows</span>
              <ArrowRight size={12} className={activeFilter === "medication" ? "text-rose-600 rotate-90 transition-transform" : "text-slate-400"} />
            </div>
          </div>

          {/* Labour Card */}
          <div 
            onClick={() => setActiveFilter(activeFilter === "labour" ? "all" : "labour")}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
              activeFilter === "labour" 
                ? "bg-sky-50/80 border-sky-400 ring-2 ring-sky-400/20 shadow-sm" 
                : "bg-white border-slate-100 hover:border-sky-200 hover:bg-sky-50/30"
            }`}
          >
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="p-2 rounded-xl bg-sky-100 text-sky-800">
                    <Users size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-900">Direct Labour</h4>
                    <span className="text-[9px] text-sky-700 font-bold font-mono">COA 5100</span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-sky-100 text-sky-900 font-mono">
                  {labourPct.toFixed(1)}%
                </span>
              </div>

              <div className="mt-3">
                <strong className="text-lg font-black text-slate-900 block">
                  {currencySymbol}{labourCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </strong>
                <span className="text-[10px] text-slate-500 font-semibold block mt-0.5">
                  {currencySymbol}{labourCostPerBird.toFixed(2)} / bird
                </span>
              </div>
            </div>

            <div className="mt-3 pt-2.5 border-t border-slate-100 text-[10px] text-slate-500 flex justify-between items-center">
              <span>Filter Labour Rows</span>
              <ArrowRight size={12} className={activeFilter === "labour" ? "text-sky-600 rotate-90 transition-transform" : "text-slate-400"} />
            </div>
          </div>

          {/* Miscellaneous & Chicks Card */}
          <div 
            onClick={() => setActiveFilter(activeFilter === "miscellaneous" ? "all" : "miscellaneous")}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
              activeFilter === "miscellaneous" 
                ? "bg-slate-100 border-slate-400 ring-2 ring-slate-400/20 shadow-sm" 
                : "bg-white border-slate-100 hover:border-slate-300 hover:bg-slate-50/50"
            }`}
          >
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="p-2 rounded-xl bg-slate-100 text-slate-800">
                    <Package size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-900">Miscellaneous</h4>
                    <span className="text-[9px] text-slate-600 font-bold font-mono">Chicks/Heating/Bedding</span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-slate-200 text-slate-900 font-mono">
                  {miscPct.toFixed(1)}%
                </span>
              </div>

              <div className="mt-3">
                <strong className="text-lg font-black text-slate-900 block">
                  {currencySymbol}{miscCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </strong>
                <span className="text-[10px] text-slate-500 font-semibold block mt-0.5">
                  {currencySymbol}{miscCostPerBird.toFixed(2)} / bird
                </span>
              </div>
            </div>

            <div className="mt-3 pt-2.5 border-t border-slate-100 text-[10px] text-slate-500 flex justify-between items-center">
              <span>Filter Misc Rows</span>
              <ArrowRight size={12} className={activeFilter === "miscellaneous" ? "text-slate-800 rotate-90 transition-transform" : "text-slate-400"} />
            </div>
          </div>
        </div>

        {/* Detailed Transactions Drilldown Table */}
        {showTransactionsList && isExpanded && (
          <div className="space-y-3 pt-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2">
              <div className="flex items-center gap-2">
                <Receipt size={16} className="text-emerald-600" />
                <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                  Itemized Cost Ledger Entries ({filteredItems.length})
                </h4>
              </div>

              {/* Filter Pills */}
              <div className="flex flex-wrap items-center gap-1">
                <button
                  onClick={() => setActiveFilter("all")}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                    activeFilter === "all" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  All ({items.length})
                </button>
                <button
                  onClick={() => setActiveFilter("feed")}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                    activeFilter === "feed" ? "bg-amber-600 text-white" : "bg-amber-50 text-amber-800 hover:bg-amber-100"
                  }`}
                >
                  Feed
                </button>
                <button
                  onClick={() => setActiveFilter("medication")}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                    activeFilter === "medication" ? "bg-rose-600 text-white" : "bg-rose-50 text-rose-800 hover:bg-rose-100"
                  }`}
                >
                  Medication
                </button>
                <button
                  onClick={() => setActiveFilter("labour")}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                    activeFilter === "labour" ? "bg-sky-600 text-white" : "bg-sky-50 text-sky-800 hover:bg-sky-100"
                  }`}
                >
                  Labour
                </button>
                <button
                  onClick={() => setActiveFilter("miscellaneous")}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                    activeFilter === "miscellaneous" ? "bg-slate-700 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  Misc
                </button>
              </div>
            </div>

            {filteredItems.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-slate-400 text-xs">
                No cost entries recorded under the selected category for this flock.
              </div>
            ) : (
              <div className="overflow-x-auto rounded-2xl border border-slate-100">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-50 text-[9px] uppercase font-black text-slate-400 tracking-wider border-b border-slate-100">
                    <tr>
                      <th className="py-2.5 px-3">Date</th>
                      <th className="py-2.5 px-3">Category / COA</th>
                      <th className="py-2.5 px-3">Description & Supplier</th>
                      <th className="py-2.5 px-3 text-right">Qty</th>
                      <th className="py-2.5 px-3 text-right">Unit Price</th>
                      <th className="py-2.5 px-3 text-right">Amount</th>
                      <th className="py-2.5 px-3 text-center">Sync Source</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 text-slate-700">
                    {filteredItems.map(item => (
                      <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="py-2.5 px-3 font-mono text-[10px] text-slate-500 whitespace-nowrap">
                          {item.date}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider ${
                            item.category === "feed" ? "bg-amber-100 text-amber-800" :
                            item.category === "medication" ? "bg-rose-100 text-rose-800" :
                            item.category === "labour" ? "bg-sky-100 text-sky-800" :
                            "bg-slate-100 text-slate-800"
                          }`}>
                            {item.category === "feed" && <Wheat size={10} />}
                            {item.category === "medication" && <Stethoscope size={10} />}
                            {item.category === "labour" && <Users size={10} />}
                            {item.category === "miscellaneous" && <Package size={10} />}
                            {item.coaCode}
                          </span>
                          <span className="text-[9px] text-slate-400 block font-normal mt-0.5 truncate max-w-[140px]">
                            {item.coaName}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="font-bold text-slate-900 block">{item.description}</span>
                          <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                            Payee: {item.supplier}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-[11px] text-slate-600">
                          {item.quantity}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-[11px] text-slate-600">
                          {currencySymbol}{Number(item.unitPrice).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                          {currencySymbol}{item.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          {item.isFinanceSynced ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[9px] font-bold">
                              <Receipt size={10} />
                              Finance Synced
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[9px] font-medium">
                              Batch Record
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-slate-50 border-t border-slate-100 font-bold text-slate-900 text-xs">
                    <tr>
                      <td colSpan={5} className="py-2.5 px-3 text-right uppercase tracking-wider text-[10px] text-slate-500 font-black">
                        Filtered Total:
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-black text-slate-900">
                        {currencySymbol}{filteredItems.reduce((s, i) => s + i.amount, 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

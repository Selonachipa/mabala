import React, { useState, useMemo } from "react";
import { PoultryBatch, PoultryMortalityLog } from "./types";
import BatchCostBreakdownSummary from "./BatchCostBreakdownSummary";
import { 
  ChevronRight, Search, Eye, Edit, Archive, CheckCircle, 
  Trash2, Calendar, Hash, DollarSign, ShieldAlert, ArrowLeft, 
  ArrowRight, Flame, Egg, Sprout, Filter, X, SlidersHorizontal,
  HeartCrack, AlertTriangle, Activity
} from "lucide-react";
import { ExpenseTransaction } from "../../types";

interface PoultryRegistryProps {
  batches: PoultryBatch[];
  currencySymbol: string;
  onUpdateBatch: (batch: PoultryBatch) => void;
  onDeleteBatch: (id: string) => void;
  writeAuditLog: (action: string, module: string, target: string, details: string) => void;
  accounts: any[];
  setAccounts: (accs: any[]) => void;
  employees?: any[];
  expenses?: ExpenseTransaction[];
}

export default function PoultryRegistry({
  batches,
  currencySymbol,
  onUpdateBatch,
  onDeleteBatch,
  writeAuditLog,
  accounts,
  setAccounts,
  employees = [],
  expenses = []
}: PoultryRegistryProps) {
  // Filters & Search State
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | "broiler" | "layer" | "village">("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "sold_out" | "closed">("all");
  
  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Selected Batch for modals
  const [viewingBatch, setViewingBatch] = useState<PoultryBatch | null>(null);
  const [editingBatch, setEditingBatch] = useState<PoultryBatch | null>(null);
  const [archivingBatch, setArchivingBatch] = useState<PoultryBatch | null>(null);
  const [mortalityBatch, setMortalityBatch] = useState<PoultryBatch | null>(null);
  const [selectedBatchIds, setSelectedBatchIds] = useState<string[]>([]);
  const [showBulkDeleteModal, setShowBulkDeleteModal] = useState(false);

  // Mortality Form State
  const [mortalityForm, setMortalityForm] = useState({
    date: new Date().toISOString().split("T")[0],
    count: 1,
    cause: "Natural / Environmental Causes" as any,
    notes: ""
  });

  // Open Mortality Modal
  const handleOpenMortality = (batch: PoultryBatch) => {
    setMortalityBatch(batch);
    setMortalityForm({
      date: new Date().toISOString().split("T")[0],
      count: 1,
      cause: "Natural / Environmental Causes",
      notes: ""
    });
  };

  // Submit Mortality Log
  const handleSaveMortality = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mortalityBatch) return;

    const deathCount = Math.max(1, Number(mortalityForm.count));
    if (deathCount > mortalityBatch.currentHeadcount) {
      alert(`Mortality count (${deathCount}) cannot exceed current flock headcount (${mortalityBatch.currentHeadcount}).`);
      return;
    }

    const pricePerBird = mortalityBatch.currentMarketPricePerBird || 50;
    const lossValue = deathCount * pricePerBird;
    const newHeadcount = Math.max(0, mortalityBatch.currentHeadcount - deathCount);
    const newValuation = newHeadcount * pricePerBird;

    const newLog: PoultryMortalityLog = {
      id: `MORT-${Date.now().toString().slice(-6)}`,
      date: mortalityForm.date,
      count: deathCount,
      cause: mortalityForm.cause,
      lossValue,
      notes: mortalityForm.notes
    };

    const updatedBatch: PoultryBatch = {
      ...mortalityBatch,
      currentHeadcount: newHeadcount,
      currentBatchValuation: newValuation,
      cumulativeMortalityLoss: (mortalityBatch.cumulativeMortalityLoss || 0) + lossValue,
      mortalityLogs: [newLog, ...(mortalityBatch.mortalityLogs || [])],
      status: newHeadcount === 0 ? "closed" : mortalityBatch.status,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updatedBatch);

    // Update Chart of Accounts: Debit Account 5901 (Mortality Loss) and Credit Account 1430 (Poultry Inventory)
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1430" || acc.code === "1420") {
        balance = Math.max(0, balance - lossValue);
      }
      if (acc.code === "5901" || acc.code === "5100") {
        balance = balance + lossValue;
      }
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);

    writeAuditLog(
      "MORTALITY_LOG",
      "Poultry Registry",
      mortalityBatch.batchId,
      `Logged ${deathCount} bird death(s) for ${mortalityBatch.batchName} (${mortalityBatch.poultryType}). Cause: ${mortalityForm.cause}. Headcount adjusted to ${newHeadcount}. Cumulative loss increased by ${currencySymbol}${lossValue}.`
    );

    setMortalityBatch(null);
  };

  // Edit form state
  const [editForm, setEditForm] = useState({
    batchName: "",
    breed: "",
    source: "",
    initialHeadcount: 0,
    currentHeadcount: 0,
    currentMarketPricePerBird: 0,
    status: "active" as "active" | "sold_out" | "closed"
  });

  // Load batch into edit form
  const handleOpenEdit = (batch: PoultryBatch) => {
    setEditingBatch(batch);
    setEditForm({
      batchName: batch.batchName,
      breed: batch.breed,
      source: batch.source,
      initialHeadcount: batch.initialHeadcount,
      currentHeadcount: batch.currentHeadcount,
      currentMarketPricePerBird: batch.currentMarketPricePerBird,
      status: batch.status
    });
  };

  // Submit edit form
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBatch) return;

    // Calculate value difference to adjust General Ledger Account 1430 / 1420
    const oldValuation = editingBatch.currentHeadcount * editingBatch.currentMarketPricePerBird;
    const newValuation = editForm.currentHeadcount * editForm.currentMarketPricePerBird;
    const valuationDiff = newValuation - oldValuation;

    const updatedBatch: PoultryBatch = {
      ...editingBatch,
      batchName: editForm.batchName,
      breed: editForm.breed,
      source: editForm.source,
      initialHeadcount: Number(editForm.initialHeadcount),
      currentHeadcount: Number(editForm.currentHeadcount),
      currentMarketPricePerBird: Number(editForm.currentMarketPricePerBird),
      currentBatchValuation: newValuation,
      status: editForm.status,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updatedBatch);

    // If valuation changed, adjust Biological Assets ledger account 1430
    if (valuationDiff !== 0) {
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        // Adjust Account 1430 (Poultry/Biological Assets) and Account 4400 (Evaluation Gain/Loss)
        if (acc.code === "1430" || acc.code === "1420") {
          balance += valuationDiff;
        }
        if (acc.code === "4400") {
          balance += valuationDiff;
        }
        return { ...acc, balance };
      });
      setAccounts(updatedAccounts);
    }

    writeAuditLog(
      "UPDATE",
      "Poultry Registry",
      editingBatch.batchId,
      `Edited poultry batch ${editForm.batchName} (${editingBatch.poultryType}). Status updated to ${editForm.status}.`
    );

    setEditingBatch(null);
  };

  // Archive / Close Batch Action
  const handleArchiveBatch = () => {
    if (!archivingBatch) return;

    // Set status to closed/archived
    const updatedBatch: PoultryBatch = {
      ...archivingBatch,
      status: "closed",
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updatedBatch);

    writeAuditLog(
      "ARCHIVE",
      "Poultry Registry",
      archivingBatch.batchId,
      `Archived/Closed flock batch ${archivingBatch.batchName} (${archivingBatch.poultryType})`
    );

    setArchivingBatch(null);
  };

  // Filtered and Searched Batches
  const filteredBatches = useMemo(() => {
    return batches.filter(b => {
      const matchesSearch = 
        b.batchName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        b.batchId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        b.breed.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesType = 
        typeFilter === "all" || 
        b.poultryType === typeFilter || 
        (typeFilter === "village" && b.breed.toLowerCase().includes("village")) ||
        (typeFilter === "village" && b.breed.toLowerCase().includes("local"));

      const matchesStatus = 
        statusFilter === "all" || 
        b.status === statusFilter;

      return matchesSearch && matchesType && matchesStatus;
    });
  }, [batches, searchTerm, typeFilter, statusFilter]);

  // Paginated Batches
  const paginatedBatches = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredBatches.slice(start, start + itemsPerPage);
  }, [filteredBatches, currentPage]);

  const totalPages = Math.ceil(filteredBatches.length / itemsPerPage);

  const getAgeInDays = (acqDate: string) => {
    const diffTime = Math.abs(new Date().getTime() - new Date(acqDate).getTime());
    return Math.floor(diffTime / (1000 * 60 * 60 * 24));
  };

  return (
    <div className="space-y-6 text-slate-800" id="poultry-registry-root">
      {/* Header */}
      <div>
        <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
          <SlidersHorizontal className="text-emerald-600" size={26} />
          Poultry Batch Registry
        </h2>
        <p className="text-xs text-slate-500 font-semibold mt-0.5">
          Unified index ledger across Broilers, Layers, and Village Chicken flocks. View, edit, and close batches cleanly.
        </p>
      </div>

      {/* Filters Bar */}
      <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-3 top-3.5 text-slate-400 w-4 h-4" />
          <input 
            type="text"
            placeholder="Search by name, ID, breed..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full text-xs p-3 pl-9 border bg-slate-50 border-slate-150 rounded-2xl outline-none font-semibold text-slate-800 focus:bg-white focus:border-emerald-500 transition-all"
          />
        </div>

        {/* Type Filter */}
        <div>
          <select 
            value={typeFilter}
            onChange={(e) => {
              setTypeFilter(e.target.value as any);
              setCurrentPage(1);
            }}
            className="w-full text-xs p-3 border bg-slate-50 border-slate-150 rounded-2xl font-extrabold outline-none text-slate-800 focus:bg-white focus:border-emerald-500 transition-all"
          >
            <option value="all">🐔 All Poultry Types</option>
            <option value="broiler">🔥 Broiler Batches</option>
            <option value="layer">🥚 Layer Batches</option>
            <option value="village">🌾 Village Chickens</option>
          </select>
        </div>

        {/* Status Filter */}
        <div>
          <select 
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value as any);
              setCurrentPage(1);
            }}
            className="w-full text-xs p-3 border bg-slate-50 border-slate-150 rounded-2xl font-extrabold outline-none text-slate-800 focus:bg-white focus:border-emerald-500 transition-all"
          >
            <option value="all">📊 All Batch Statuses</option>
            <option value="active">🟢 Active Batches</option>
            <option value="sold_out">🔵 Sold Out Batches</option>
            <option value="closed">⚫ Archived / Closed</option>
          </select>
        </div>

        {/* Summary Stats */}
        <div className="flex items-center justify-end text-xs font-bold text-slate-500 pr-2">
          <span>Found {filteredBatches.length} matched flocks</span>
        </div>
      </div>

      {/* Bulk Action Bar */}
      {selectedBatchIds.length > 0 && (
        <div className="bg-rose-50 border border-rose-200 p-3 rounded-2xl flex justify-between items-center mb-4">
          <span className="text-xs font-bold text-rose-900">
            Selected <span className="font-mono font-black">{selectedBatchIds.length}</span> poultry batch(es) for disposal
          </span>
          <button
            onClick={() => setShowBulkDeleteModal(true)}
            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Delete Selected Flocks ({selectedBatchIds.length})
          </button>
        </div>
      )}

      {/* Main Registry Table */}
      <div className="bg-white border border-slate-100 rounded-3xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 border-b border-slate-100 text-[10px] uppercase text-slate-400 font-black">
              <tr>
                <th className="p-4 pl-4 w-10">
                  <input
                    type="checkbox"
                    checked={filteredBatches.length > 0 && selectedBatchIds.length === filteredBatches.length}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedBatchIds(filteredBatches.map(b => b.id));
                      } else {
                        setSelectedBatchIds([]);
                      }
                    }}
                    className="rounded border-slate-300 text-slate-900 focus:ring-slate-900 cursor-pointer w-4 h-4"
                  />
                </th>
                <th className="p-4 pl-2">Batch ID & Name</th>
                <th className="p-4">Type & Breed</th>
                <th className="p-4 text-center">Age</th>
                <th className="p-4 text-center">Headcount</th>
                <th className="p-4 text-right">Appraised Value</th>
                <th className="p-4 text-center">Status</th>
                <th className="p-4 pr-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 font-bold text-slate-700">
              {paginatedBatches.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-12 text-center text-slate-400 italic font-medium leading-relaxed">
                    No poultry flocks found matching the filters or search inputs.
                  </td>
                </tr>
              ) : (
                paginatedBatches.map(b => {
                  const ageDays = getAgeInDays(b.dateAcquired);
                  const isSelected = selectedBatchIds.includes(b.id);
                  
                  return (
                    <tr key={b.id} className={`hover:bg-slate-50/40 transition-colors ${isSelected ? 'bg-rose-50/30' : ''}`}>
                      <td className="p-4 pl-4">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedBatchIds(prev => [...prev, b.id]);
                            } else {
                              setSelectedBatchIds(prev => prev.filter(id => id !== b.id));
                            }
                          }}
                          className="rounded border-slate-300 text-slate-900 focus:ring-slate-900 cursor-pointer w-4 h-4"
                        />
                      </td>
                      <td className="p-4 pl-2">
                        <span className="font-mono text-emerald-800 text-[11px] block">{b.batchId}</span>
                        <span className="text-slate-900 font-black text-sm block mt-0.5">{b.batchName}</span>
                      </td>
                      <td className="p-4">
                        <span className="flex items-center gap-1 text-slate-900">
                          {b.poultryType === "broiler" ? (
                            <Flame size={12} className="text-amber-500" />
                          ) : b.poultryType === "layer" ? (
                            <Egg size={12} className="text-sky-400" />
                          ) : (
                            <Sprout size={12} className="text-emerald-500" />
                          )}
                          <span className="capitalize">{b.poultryType}</span>
                        </span>
                        <span className="text-[10px] text-slate-400 block font-normal mt-0.5">{b.breed}</span>
                      </td>
                      <td className="p-4 text-center text-slate-900">
                        <span>{ageDays} Days</span>
                        <span className="text-[9px] text-slate-400 block font-normal mt-0.5">Acq: {b.dateAcquired}</span>
                      </td>
                      <td className="p-4 text-center">
                        <span className="text-slate-900">{b.currentHeadcount} birds</span>
                        <span className="text-[9px] text-slate-400 block font-normal mt-0.5">of {b.initialHeadcount} initial</span>
                      </td>
                      <td className="p-4 text-right">
                        <span className="text-emerald-700 font-extrabold text-sm block">
                          {currencySymbol}{b.currentBatchValuation.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                        <span className="text-[9px] text-slate-400 block font-normal mt-0.5">
                          Val: {currencySymbol}{b.currentMarketPricePerBird.toFixed(1)}/bird
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <span className={`px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider ${
                          b.status === "active" ? "bg-emerald-100 text-emerald-800" :
                          b.status === "sold_out" ? "bg-sky-100 text-sky-800" :
                          "bg-slate-100 text-slate-800"
                        }`}>
                          {b.status}
                        </span>
                      </td>
                      <td className="p-4 pr-6 text-right space-x-1.5 whitespace-nowrap">
                        <button 
                          onClick={() => setViewingBatch(b)}
                          className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-slate-900 cursor-pointer transition-colors inline-block"
                          title="View Details"
                        >
                          <Eye size={15} />
                        </button>
                        {b.status !== "closed" && (
                          <>
                            <button 
                              onClick={() => handleOpenMortality(b)}
                              className="p-1.5 hover:bg-rose-50 rounded-lg text-rose-600 hover:text-rose-800 cursor-pointer transition-colors inline-block"
                              title="Log Daily Bird Mortality (Adjusts Headcount & FCR)"
                            >
                              <HeartCrack size={15} />
                            </button>
                            <button 
                              onClick={() => handleOpenEdit(b)}
                              className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-emerald-700 cursor-pointer transition-colors inline-block"
                              title="Edit Batch"
                            >
                              <Edit size={15} />
                            </button>
                            <button 
                              onClick={() => setArchivingBatch(b)}
                              className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-amber-700 cursor-pointer transition-colors inline-block"
                              title="Archive Batch"
                            >
                              <Archive size={15} />
                            </button>
                            <button 
                              onClick={() => {
                                setSelectedBatchIds([b.id]);
                                setShowBulkDeleteModal(true);
                              }}
                              className="p-1.5 hover:bg-rose-100 rounded-lg text-rose-500 hover:text-rose-700 cursor-pointer transition-colors inline-block"
                              title="Delete Flock Record"
                            >
                              <Trash2 size={15} />
                            </button>
                          </>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Row */}
        {totalPages > 1 && (
          <div className="bg-slate-50 border-t border-slate-100 p-4 pl-6 pr-6 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">
              Page {currentPage} of {totalPages}
            </span>
            <div className="flex gap-2">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                className="px-3 py-1.5 border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
              >
                <ArrowLeft size={12} /> Prev
              </button>
              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                className="px-3 py-1.5 border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
              >
                Next <ArrowRight size={12} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* DETAIL VIEW MODAL */}
      {viewingBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto animate-fade-in">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl border border-slate-100 text-slate-800">
            {/* Header */}
            <div className="p-6 bg-slate-950 text-white flex justify-between items-center shrink-0">
              <div>
                <span className="text-[9px] tracking-widest uppercase font-black text-emerald-400">Poultry Flock Detail & Financial Ledger</span>
                <h4 className="text-base font-black uppercase tracking-tight flex items-center gap-2">
                  {viewingBatch.batchId} - {viewingBatch.batchName}
                </h4>
              </div>
              <button 
                onClick={() => setViewingBatch(null)}
                className="p-1 px-3 py-1.5 text-xs bg-white/10 hover:bg-white/20 hover:text-white rounded-xl font-bold cursor-pointer transition-all border-none"
              >
                ✕ Close
              </button>
            </div>

            {/* Scrollable Contents */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Top Stats Cards */}
              <div className="grid grid-cols-3 gap-3.5">
                <div className="bg-slate-50 p-3 rounded-2xl">
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Type & Breed</span>
                  <strong className="text-slate-800 text-xs block mt-0.5 capitalize">{viewingBatch.poultryType}</strong>
                  <span className="text-[9px] text-slate-400 block font-normal">{viewingBatch.breed}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-2xl">
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Age in Days</span>
                  <strong className="text-slate-800 text-xs block mt-0.5">{getAgeInDays(viewingBatch.dateAcquired)} Days</strong>
                  <span className="text-[9px] text-slate-400 block font-normal">Born {viewingBatch.dateAcquired}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-2xl">
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Live Headcount</span>
                  <strong className="text-slate-800 text-xs block mt-0.5">{viewingBatch.currentHeadcount} Birds</strong>
                  <span className="text-[9px] text-slate-400 block font-normal">Initial: {viewingBatch.initialHeadcount}</span>
                </div>
              </div>

              {/* SOURCED FINANCE COST BREAKDOWN SUMMARY */}
              <div className="pt-1">
                <BatchCostBreakdownSummary
                  batch={viewingBatch}
                  currencySymbol={currencySymbol}
                  expenses={expenses}
                  allBatches={batches}
                  compact={false}
                  showTransactionsList={true}
                />
              </div>

              {/* Feed & Cost Aggregates */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-50 p-4 rounded-2xl space-y-1">
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Production Cost Overview</span>
                  <h4 className="text-lg font-black text-slate-800">
                    {currencySymbol}{(viewingBatch.acquisitionCostTotal + viewingBatch.cumulativeFeedCost + viewingBatch.cumulativeHealthCost).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </h4>
                  <div className="text-[9px] text-slate-400 space-y-0.5">
                    <div>Acquisition: {currencySymbol}{viewingBatch.acquisitionCostTotal.toLocaleString()}</div>
                    <div>Feed Inputs: {currencySymbol}{viewingBatch.cumulativeFeedCost.toLocaleString()}</div>
                    <div>Health/Vet: {currencySymbol}{viewingBatch.cumulativeHealthCost.toLocaleString()}</div>
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl space-y-1">
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Egg Collection Stock</span>
                  <h4 className="text-lg font-black text-slate-800">
                    {viewingBatch.eggCollections ? viewingBatch.eggCollections.reduce((sum, e) => sum + e.totalCollected, 0).toLocaleString() : 0} <span className="text-xs font-normal text-slate-400">eggs</span>
                  </h4>
                  <p className="text-[9px] text-slate-400 leading-normal">
                    Sorted Lay rate of layers has average KPI tracked dynamically at flock scale.
                  </p>
                </div>
              </div>

              {/* Vaccine & Feed logs checklists */}
              <div className="space-y-4">
                <h5 className="text-xs font-black uppercase text-slate-900 border-b pb-1.5 flex items-center gap-1.5">
                  <CheckCircle size={14} className="text-emerald-600" /> Recent Operations Log Activity
                </h5>
                <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                  {viewingBatch.feedLogs.length === 0 && viewingBatch.healthLogs.length === 0 ? (
                    <p className="text-xs text-slate-400 italic">No historical activities recorded on this flock ledger yet.</p>
                  ) : (
                    <>
                      {viewingBatch.feedLogs.map((f, i) => (
                        <div key={`feed-${i}`} className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl flex justify-between text-[11px]">
                          <div>
                            <span className="bg-amber-100 text-amber-800 text-[8.5px] px-1.5 py-0.5 rounded font-black uppercase font-mono mr-1.5">FEED</span>
                            <strong>{f.quantityKg}kg of {f.feedType}</strong>
                          </div>
                          <span className="text-slate-400 font-semibold font-mono">{f.date}</span>
                        </div>
                      ))}
                      {viewingBatch.healthLogs.map((h, i) => (
                        <div key={`health-${i}`} className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl flex justify-between text-[11px]">
                          <div>
                            <span className="bg-sky-100 text-sky-800 text-[8.5px] px-1.5 py-0.5 rounded font-black uppercase font-mono mr-1.5">HEALTH</span>
                            <strong>{h.product} ({h.type})</strong>
                          </div>
                          <span className="text-slate-400 font-semibold font-mono">{h.date}</span>
                        </div>
                      ))}
                    </>
                  )}
                </div>
              </div>
            </div>
            {/* Footer */}
            <div className="p-5 border-t bg-slate-50 flex justify-end">
              <button 
                onClick={() => setViewingBatch(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black"
              >
                Dismiss Details
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MORTALITY LOGGING MODAL */}
      {mortalityBatch && (() => {
        const deathCount = Math.max(1, Number(mortalityForm.count));
        const pricePerBird = mortalityBatch.currentMarketPricePerBird || 50;
        const lossValue = deathCount * pricePerBird;
        const newHeadcount = Math.max(0, mortalityBatch.currentHeadcount - deathCount);
        const totalDeadAfter = (mortalityBatch.mortalityLogs || []).reduce((sum, m) => sum + m.count, 0) + deathCount;
        const mortalityRate = mortalityBatch.initialHeadcount > 0 ? (totalDeadAfter / mortalityBatch.initialHeadcount) * 100 : 0;

        return (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto animate-fade-in">
            <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 text-slate-800 space-y-4">
              <div className="flex justify-between items-center border-b pb-3">
                <div className="flex items-center gap-2 text-rose-600 font-black">
                  <HeartCrack className="w-5 h-5" />
                  <div>
                    <span className="text-[9px] tracking-widest uppercase font-black text-rose-500 block">Daily Mortality Tracking</span>
                    <h4 className="text-sm font-black uppercase tracking-tight text-slate-900">
                      Log Bird Deaths — {mortalityBatch.batchName}
                    </h4>
                  </div>
                </div>
                <button onClick={() => setMortalityBatch(null)} className="p-1 hover:bg-slate-100 rounded-lg text-slate-400">
                  <X size={18} />
                </button>
              </div>

              <form onSubmit={handleSaveMortality} className="space-y-4 text-xs font-semibold">
                {/* Live Metric Impact Bar */}
                <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl space-y-2">
                  <div className="flex justify-between items-center text-xs font-bold text-rose-950">
                    <span>Active Headcount: <strong className="font-mono text-slate-900">{mortalityBatch.currentHeadcount}</strong> → Projected: <strong className="font-mono text-rose-700">{newHeadcount} birds</strong></span>
                    <span className="font-mono text-rose-700 font-extrabold">{mortalityRate.toFixed(1)}% cumulative rate</span>
                  </div>
                  <div className="text-[11px] text-rose-800 flex items-center justify-between border-t border-rose-200/60 pt-1.5">
                    <span>Loss Valuation Impact:</span>
                    <span className="font-mono font-bold text-rose-900">-{currencySymbol}{lossValue.toLocaleString(undefined, { minimumFractionDigits: 2 })} (COA 5901)</span>
                  </div>
                  <div className="text-[10px] text-slate-500 italic">
                    ℹ️ Headcount adjustment automatically updates the feed conversion ratio (FCR) and cost-per-bird metrics.
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-black text-slate-500 uppercase block pb-1">Date of Incident *</label>
                    <input 
                      type="date"
                      required
                      value={mortalityForm.date}
                      onChange={(e) => setMortalityForm({ ...mortalityForm, date: e.target.value })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:bg-white focus:border-rose-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-slate-500 uppercase block pb-1">Number of Deaths *</label>
                    <input 
                      type="number"
                      min={1}
                      max={mortalityBatch.currentHeadcount}
                      required
                      value={mortalityForm.count}
                      onChange={(e) => setMortalityForm({ ...mortalityForm, count: Math.max(1, Number(e.target.value)) })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold font-mono text-slate-800 focus:bg-white focus:border-rose-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase block pb-1">Primary Cause of Death *</label>
                  <select
                    value={mortalityForm.cause}
                    onChange={(e) => setMortalityForm({ ...mortalityForm, cause: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:bg-white focus:border-rose-500"
                  >
                    <option value="Natural / Environmental Causes">Natural / Environmental Causes</option>
                    <option value="Heat Stress / Prostration">Heat Stress / Prostration</option>
                    <option value="Cold Stress / Chilling">Cold Stress / Chilling</option>
                    <option value="Coccidiosis / Enteric Disease">Coccidiosis / Enteric Disease</option>
                    <option value="Respiratory Disease (CRD/IB)">Respiratory Disease (CRD/IB)</option>
                    <option value="Smothering / Trampling">Smothering / Trampling</option>
                    <option value="Predator Attack">Predator Attack</option>
                    <option value="Nutritional Deficiency">Nutritional Deficiency</option>
                    <option value="Unrecorded mortality correction">Unrecorded mortality correction</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase block pb-1">Clinical Observations & Bio-Security Notes</label>
                  <textarea
                    rows={2}
                    placeholder="Enter veterinary findings, post-mortem notes, water sanitizer adjustments..."
                    value={mortalityForm.notes}
                    onChange={(e) => setMortalityForm({ ...mortalityForm, notes: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-slate-800 focus:bg-white focus:border-rose-500"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t">
                  <button 
                    type="button" 
                    onClick={() => setMortalityBatch(null)} 
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-black shadow-md transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <HeartCrack className="w-3.5 h-3.5" />
                    Record Mortality & Update FCR
                  </button>
                </div>
              </form>
            </div>
          </div>
        );
      })()}

      {/* EDIT MODAL */}
      {editingBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 text-slate-800 space-y-4">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <span className="text-[9px] tracking-widest uppercase font-black text-emerald-500">Edit Flock Asset</span>
                <h4 className="text-sm font-black uppercase tracking-tight">Modify Flock Metadata</h4>
              </div>
              <button onClick={() => setEditingBatch(null)} className="p-1 hover:bg-slate-100 rounded-lg">
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs font-semibold">
              <div>
                <label className="text-[10px] font-black text-slate-500 uppercase block pb-1">Flock Batch Name</label>
                <input 
                  type="text"
                  required
                  value={editForm.batchName}
                  onChange={(e) => setEditForm({ ...editForm, batchName: e.target.value })}
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:border-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase block pb-1">Breed Type</label>
                  <input 
                    type="text"
                    required
                    value={editForm.breed}
                    onChange={(e) => setEditForm({ ...editForm, breed: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:border-slate-800"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase block pb-1">Acquisition Source</label>
                  <input 
                    type="text"
                    required
                    value={editForm.source}
                    onChange={(e) => setEditForm({ ...editForm, source: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:border-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase block pb-1">Initial Headcount</label>
                  <input 
                    type="number"
                    required
                    value={editForm.initialHeadcount}
                    onChange={(e) => setEditForm({ ...editForm, initialHeadcount: Number(e.target.value) })}
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none font-mono font-bold text-slate-800 focus:border-slate-800"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase block pb-1">Current Headcount</label>
                  <input 
                    type="number"
                    required
                    value={editForm.currentHeadcount}
                    onChange={(e) => setEditForm({ ...editForm, currentHeadcount: Number(e.target.value) })}
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none font-mono font-bold text-slate-800 focus:border-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase block pb-1">Market Appraisal/Bird</label>
                  <input 
                    type="number"
                    step="0.1"
                    required
                    value={editForm.currentMarketPricePerBird}
                    onChange={(e) => setEditForm({ ...editForm, currentMarketPricePerBird: Number(e.target.value) })}
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none font-mono font-bold text-slate-800 focus:border-slate-800"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase block pb-1">Operational Status</label>
                  <select 
                    value={editForm.status}
                    onChange={(e) => setEditForm({ ...editForm, status: e.target.value as any })}
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:border-slate-800"
                  >
                    <option value="active">Active Flock</option>
                    <option value="sold_out">Sold Out Flock</option>
                    <option value="closed">Closed/Archived</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t">
                <button 
                  type="button" 
                  onClick={() => setEditingBatch(null)}
                  className="px-4 py-2 border rounded-xl hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white rounded-xl text-xs font-black shadow-md transition-all cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ARCHIVE/CLOSE CONFIRMATION MODAL */}
      {archivingBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 text-slate-800 space-y-4">
            <div className="flex items-center gap-3 text-amber-600">
              <ShieldAlert className="w-6 h-6 shrink-0" />
              <h4 className="font-extrabold text-sm uppercase tracking-wider">Archive & Close Batch</h4>
            </div>
            <div className="text-xs leading-relaxed font-semibold">
              <p>Are you sure you want to permanently close and archive poultry batch <strong className="font-mono text-emerald-800">{archivingBatch.batchId}</strong>?</p>
              <p className="mt-2 text-slate-400 font-normal">
                This will mark the status of the flock cycle as "Closed/Archived". Active biological valuation metrics and egg stock collections will be locked for future periods.
              </p>
            </div>
            <div className="flex justify-end gap-2.5 pt-2">
              <button 
                onClick={() => setArchivingBatch(null)}
                className="px-4 py-2 border rounded-xl hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button 
                onClick={handleArchiveBatch}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
              >
                Yes, Close Batch
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BULK DELETE POULTRY FINANCIAL IMPACT CONFIRMATION MODAL */}
      {showBulkDeleteModal && (() => {
        const selectedBatches = batches.filter(b => selectedBatchIds.includes(b.id));
        const totalHeadcount = selectedBatches.reduce((sum, b) => sum + b.currentHeadcount, 0);
        const totalValuation = selectedBatches.reduce((sum, b) => sum + b.currentBatchValuation, 0);
        
        const assetAcc = accounts.find(a => a.code === "1430" || a.code === "1420");
        const disposalAcc = accounts.find(a => a.code === "5100" || a.code === "5000");

        const currentAssetBal = assetAcc?.balance || 0;
        const newAssetBal = Math.max(0, currentAssetBal - totalValuation);

        const currentDisposalBal = disposalAcc?.balance || 0;
        const newDisposalBal = currentDisposalBal + totalValuation;

        const handleConfirmBulkDeletePoultry = () => {
          selectedBatchIds.forEach(id => onDeleteBatch(id));

          // Update Chart of Accounts General Ledger
          const updatedAccounts = accounts.map(a => {
            let balance = a.balance;
            if (a.code === "1430" || a.code === "1420") {
              balance = Math.max(0, balance - totalValuation);
            }
            if (a.code === "5100" || a.code === "5000") {
              balance = balance + totalValuation;
            }
            return { ...a, balance };
          });
          setAccounts(updatedAccounts);

          setSelectedBatchIds([]);
          setShowBulkDeleteModal(false);
          alert(`Successfully deleted ${selectedBatches.length} poultry flock(s) representing ${totalHeadcount} birds. General ledger accounts updated.`);
        };

        return (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-2xl w-full p-6 space-y-5 border border-slate-200 shadow-2xl animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between border-b pb-3">
                <div className="flex items-center gap-2.5 text-rose-600 font-black">
                  <ShieldAlert className="w-6 h-6" />
                  <div>
                    <h3 className="text-base font-black text-slate-900 tracking-tight">Confirm Poultry Flock Disposal</h3>
                    <p className="text-xs text-slate-500 font-semibold">General Ledger & Chart of Accounts Impact Assessment</p>
                  </div>
                </div>
                <button onClick={() => setShowBulkDeleteModal(false)} className="text-slate-400 hover:text-slate-600 text-lg font-bold">✕</button>
              </div>

              {/* Summary of Selected Batches */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-bold text-slate-700">
                  <span>Selected Poultry Flocks ({selectedBatches.length}) • {totalHeadcount} Birds Total</span>
                  <span className="text-rose-600 font-mono font-black">Appraised Valuation: {currencySymbol}{totalValuation.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>

                <div className="max-h-36 overflow-y-auto border border-slate-100 rounded-2xl divide-y text-xs">
                  {selectedBatches.map(b => (
                    <div key={b.id} className="p-2.5 flex justify-between items-center bg-slate-50/50">
                      <div>
                        <span className="font-mono text-emerald-800 font-bold block">{b.batchId} — {b.batchName}</span>
                        <span className="text-slate-600 font-semibold">{b.poultryType.toUpperCase()} • {b.breed} ({b.currentHeadcount} birds)</span>
                      </div>
                      <span className="font-mono font-black text-slate-900">
                        {currencySymbol}{b.currentBatchValuation.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chart of Accounts Financial Impact Summary */}
              <div className="bg-slate-900 text-white rounded-2xl p-4 space-y-3">
                <span className="text-xs font-black uppercase text-amber-400 tracking-wider block">
                  📊 Chart of Accounts Balance Impact Summary
                </span>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  {/* Poultry Asset Inventory Account */}
                  <div className="p-3 bg-slate-800 rounded-xl space-y-1">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">Poultry Inventory (Account 1430)</span>
                    <div className="font-mono text-slate-300">
                      Current: {currencySymbol}{currentAssetBal.toLocaleString()}
                    </div>
                    <div className="font-mono text-rose-400 font-bold">
                      Deduction: -{currencySymbol}{totalValuation.toLocaleString()}
                    </div>
                    <div className="font-mono text-emerald-400 font-black pt-1 border-t border-slate-700">
                      New Balance: {currencySymbol}{newAssetBal.toLocaleString()}
                    </div>
                  </div>

                  {/* Flock Disposal Loss Account */}
                  <div className="p-3 bg-slate-800 rounded-xl space-y-1">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">Flock Disposal Write-off (Account 5100)</span>
                    <div className="font-mono text-slate-300">
                      Current: {currencySymbol}{currentDisposalBal.toLocaleString()}
                    </div>
                    <div className="font-mono text-amber-400 font-bold">
                      Addition: +{currencySymbol}{totalValuation.toLocaleString()}
                    </div>
                    <div className="font-mono text-emerald-400 font-black pt-1 border-t border-slate-700">
                      New Balance: {currencySymbol}{newDisposalBal.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-900 rounded-xl text-xs font-medium">
                ⚠️ <strong>Irreversible Action:</strong> Deleting these poultry batches will permanently remove {totalHeadcount} birds and write off {currencySymbol}{totalValuation.toLocaleString()} from your biological asset register and flock management records.
              </div>

              <div className="flex gap-3 justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setShowBulkDeleteModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmBulkDeletePoultry}
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer"
                >
                  Confirm Flock Disposal & Update Ledger
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}

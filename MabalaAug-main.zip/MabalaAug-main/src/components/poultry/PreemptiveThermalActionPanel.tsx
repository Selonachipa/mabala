import React, { useState, useMemo } from "react";
import { 
  Flame, 
  Snowflake, 
  Thermometer, 
  Wind, 
  Droplet, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  Fan, 
  Sparkles, 
  Clock, 
  Layers,
  Send,
  Zap,
  CheckSquare,
  Square
} from "lucide-react";
import { SevereAlert } from "../WeatherWidget";
import { PoultryBatch } from "./types";

interface PreemptiveThermalActionPanelProps {
  weatherAlerts?: SevereAlert[];
  batches?: PoultryBatch[];
  writeAuditLog?: (action: string, module: string, target: string, details: string) => void;
  onUpdateBatch?: (batch: PoultryBatch) => void;
}

export default function PreemptiveThermalActionPanel({
  weatherAlerts = [],
  batches = [],
  writeAuditLog,
  onUpdateBatch
}: PreemptiveThermalActionPanelProps) {
  // Manual test / simulation toggle state for instant demonstration
  const [activeSimulation, setActiveSimulation] = useState<"none" | "heatwave" | "frost">("none");
  const [completedActionIds, setCompletedActionIds] = useState<Set<string>>(new Set());
  const [dispatchStatusMessage, setDispatchStatusMessage] = useState<string | null>(null);

  // Extract live thermal alerts from WeatherWidget
  const liveThermalAlerts = useMemo(() => {
    return weatherAlerts.filter(a => a.category === "Thermal" || a.title.toLowerCase().includes("thermal") || a.title.toLowerCase().includes("heat") || a.title.toLowerCase().includes("frost"));
  }, [weatherAlerts]);

  // Determine active thermal alert state (live or simulated)
  const isHeatAlertActive = activeSimulation === "heatwave" || liveThermalAlerts.some(a => a.title.toLowerCase().includes("heat") || a.description.toLowerCase().includes("heat") || a.description.toLowerCase().includes("peak"));
  const isFrostAlertActive = activeSimulation === "frost" || liveThermalAlerts.some(a => a.title.toLowerCase().includes("frost") || a.description.toLowerCase().includes("freezing") || a.description.toLowerCase().includes("cooling"));

  const isThermalAlertActive = isHeatAlertActive || isFrostAlertActive;

  // Recommended Preemptive Action Items
  const heatPreemptiveActions = [
    {
      id: "heat-act-1",
      title: "Increase House Ventilation & Airflow",
      category: "Ventilation",
      icon: <Fan className="w-4 h-4 text-amber-600 shrink-0" />,
      actionText: "Open all broiler/layer house side-curtains 100%, activate cross-ventilation exhaust fans, and clear any windbreak obstructions.",
      urgency: "Immediate (Within 15 mins)"
    },
    {
      id: "heat-act-2",
      title: "Initiate Misting & Roof Cooling Foggers",
      category: "Cooling",
      icon: <Droplet className="w-4 h-4 text-sky-600 shrink-0" />,
      actionText: "Turn on roof fogger sprinklers and pad misting nozzles to drop shed interior temperatures by 4°C to 6°C.",
      urgency: "High"
    },
    {
      id: "heat-act-3",
      title: "Hydration & Anti-Stress Electrolytes",
      category: "Hydration",
      icon: <Zap className="w-4 h-4 text-emerald-600 shrink-0" />,
      actionText: "Flush drinker lines with chilled fresh water and dose header tanks with Vitamin C + Sodium Bicarbonate anti-stress electrolyte mix.",
      urgency: "High"
    },
    {
      id: "heat-act-4",
      title: "Shift Feeding Schedule to Off-Peak Hours",
      category: "Feed Management",
      icon: <Clock className="w-4 h-4 text-purple-600 shrink-0" />,
      actionText: "Withdraw feed pans between 12:00 and 15:00 to eliminate metabolic heat increment during peak solar radiation.",
      urgency: "Scheduled"
    }
  ];

  const frostPreemptiveActions = [
    {
      id: "frost-act-1",
      title: "Initiate Heating & Brooder Lamps",
      category: "Heating",
      icon: <Flame className="w-4 h-4 text-rose-600 shrink-0" />,
      actionText: "Ignite brooder stoves, infrared gas heaters, or heating lamps in chick rearing sheds to maintain target 33°C brooder temperature.",
      urgency: "Immediate (Within 15 mins)"
    },
    {
      id: "frost-act-2",
      title: "Draft Control & Curtain Sealing",
      category: "Insulation",
      icon: <Wind className="w-4 h-4 text-indigo-600 shrink-0" />,
      actionText: "Seal side curtains tightly against freezing night winds while leaving top 15cm ventilation slots open to vent moisture & ammonia.",
      urgency: "High"
    },
    {
      id: "frost-act-3",
      title: "Deep Bedding Litter Reinforcement",
      category: "Bedding",
      icon: <Layers className="w-4 h-4 text-amber-700 shrink-0" />,
      actionText: "Spread 8–10 cm of fresh, dry wood shavings or straw litter across floors to prevent footpad chill and cold conduction.",
      urgency: "High"
    },
    {
      id: "frost-act-4",
      title: "High-Energy Evening Feed Formulation",
      category: "Nutrition",
      icon: <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />,
      actionText: "Provide additional cracked maize in evening feed pans to help birds generate metabolic body heat overnight.",
      urgency: "Scheduled"
    }
  ];

  const activeActions = isHeatAlertActive ? heatPreemptiveActions : isFrostAlertActive ? frostPreemptiveActions : [];

  const handleToggleAction = (id: string) => {
    setCompletedActionIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleDispatchAllActions = () => {
    const alertTypeStr = isHeatAlertActive ? "Heat Stress Danger (>38°C)" : "Frost / Severe Cold Hazard (<2°C)";
    const actionNames = activeActions.map(a => a.title).join("; ");

    // 1. Audit trail log
    if (writeAuditLog) {
      writeAuditLog(
        "PREEMPTIVE_THERMAL_ACTION_DISPATCHED",
        "Poultry Management",
        "All Active Poultry Sheds",
        `Dispatched preemptive thermal control actions for ${alertTypeStr}: [${actionNames}]`
      );
    }

    // 2. Mark all completed
    const allIds = activeActions.map(a => a.id);
    setCompletedActionIds(new Set(allIds));

    // 3. Optional batch log update
    if (onUpdateBatch && batches.length > 0) {
      batches.forEach(b => {
        if (b.status === "active") {
          const newHealthLog = {
            id: `hl-thermal-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            date: new Date().toISOString().split("T")[0],
            type: "treatment" as const,
            eventType: "Treatment" as const,
            product: isHeatAlertActive ? "Preemptive Heat Stress Electrolytes & Fogging" : "Preemptive Brooder Heating & Insulation",
            dosage: "System-wide thermal protocol",
            administeredBy: "Poultry Manager (Automated Weather Trigger)",
            cost: 0,
            notes: `Executed preemptive thermal response for ${alertTypeStr}.`
          };
          onUpdateBatch({
            ...b,
            healthLogs: [newHealthLog, ...(b.healthLogs || [])]
          });
        }
      });
    }

    setDispatchStatusMessage(`Preemptive thermal protocol successfully dispatched across ${batches.filter(b => b.status === "active").length || 1} active poultry flocks and logged into operational audit trail!`);
    setTimeout(() => setDispatchStatusMessage(null), 5000);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4 font-sans">
      {/* Header with Weather Trigger Status & Simulation Test Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b pb-4">
        <div className="flex items-center gap-2.5">
          <div className={`p-2.5 rounded-2xl ${
            isHeatAlertActive ? "bg-amber-500 text-white animate-pulse" : isFrostAlertActive ? "bg-sky-500 text-white animate-pulse" : "bg-slate-100 text-slate-700"
          }`}>
            {isHeatAlertActive ? <Flame className="w-5 h-5" /> : isFrostAlertActive ? <Snowflake className="w-5 h-5" /> : <Thermometer className="w-5 h-5" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-extrabold uppercase tracking-wide text-slate-900">
                Weather Thermal Alert & Preemptive Action Console
              </h3>
              {isThermalAlertActive && (
                <span className="px-2 py-0.5 bg-rose-100 text-rose-800 border border-rose-200 font-black text-[9px] uppercase tracking-wider rounded-full animate-bounce">
                  Active Weather Alert
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              Automated climate monitoring triggers instant preemptive management directives to prevent heat prostration, cold mortality, and feed conversion drops in broilers & layers.
            </p>
          </div>
        </div>

        {/* Simulation Toggles for instant user testing */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl text-[11px] font-bold">
          <span className="text-[10px] uppercase font-black text-slate-400 px-2">Simulate Alert:</span>
          <button
            type="button"
            onClick={() => {
              setActiveSimulation(prev => prev === "heatwave" ? "none" : "heatwave");
              setCompletedActionIds(new Set());
            }}
            className={`px-2.5 py-1 rounded-xl transition-all flex items-center gap-1 cursor-pointer ${
              activeSimulation === "heatwave" ? "bg-amber-500 text-white font-extrabold shadow-2xs" : "text-slate-700 hover:bg-slate-200"
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Heatwave (39°C)</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveSimulation(prev => prev === "frost" ? "none" : "frost");
              setCompletedActionIds(new Set());
            }}
            className={`px-2.5 py-1 rounded-xl transition-all flex items-center gap-1 cursor-pointer ${
              activeSimulation === "frost" ? "bg-sky-600 text-white font-extrabold shadow-2xs" : "text-slate-700 hover:bg-slate-200"
            }`}
          >
            <Snowflake className="w-3.5 h-3.5" />
            <span>Frost (-1°C)</span>
          </button>
          {activeSimulation !== "none" && (
            <button
              type="button"
              onClick={() => {
                setActiveSimulation("none");
                setCompletedActionIds(new Set());
              }}
              className="text-[10px] text-slate-500 hover:text-slate-800 underline px-1 cursor-pointer font-bold"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Dispatch Success Alert */}
      {dispatchStatusMessage && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-2xl flex items-center gap-3 text-xs font-bold animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{dispatchStatusMessage}</span>
        </div>
      )}

      {/* ACTIVE THERMAL ALERT BANNER */}
      {isThermalAlertActive ? (
        <div className={`p-4 rounded-2xl border space-y-4 animate-fade-in ${
          isHeatAlertActive ? "bg-amber-50/80 border-amber-300/80 text-amber-950" : "bg-sky-50/80 border-sky-300/80 text-sky-950"
        }`}>
          {/* Banner Title */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-200/60 pb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className={`w-5 h-5 shrink-0 ${isHeatAlertActive ? "text-amber-600 animate-bounce" : "text-sky-600 animate-bounce"}`} />
              <div>
                <h4 className="text-xs font-black uppercase tracking-wider">
                  {isHeatAlertActive ? "🚨 CRITICAL THERMAL ALERT: EXTREME HEAT STRESS WARNING" : "❄️ CRITICAL THERMAL ALERT: HARD FROST & COLD DRAFT HAZARD"}
                </h4>
                <p className="text-[11px] font-medium text-slate-600 mt-0.5">
                  {isHeatAlertActive 
                    ? "Ambient temperature forecast exceeding thermal threshold (38°C+). High risk of heat prostration, panting, and sudden flock mortality."
                    : "Nighttime temperatures dropping below safe threshold (<2°C). High risk of chick hypothermia, cold shock, and feed wastage."}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider font-mono ${
                isHeatAlertActive ? "bg-amber-200 text-amber-900 border border-amber-300" : "bg-sky-200 text-sky-900 border border-sky-300"
              }`}>
                {isHeatAlertActive ? "Heatwave Alert" : "Frost Hazard"}
              </span>
              <button
                type="button"
                onClick={handleDispatchAllActions}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold text-white flex items-center gap-1.5 shadow-sm transition-all cursor-pointer ${
                  isHeatAlertActive ? "bg-amber-600 hover:bg-amber-700" : "bg-sky-600 hover:bg-sky-700"
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                <span>Dispatch All Preemptive Actions</span>
              </button>
            </div>
          </div>

          {/* List of Automated Preemptive Actions */}
          <div className="space-y-2.5">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 block">
              Automated Recommended Preemptive Actions for Poultry Manager ({completedActionIds.size}/{activeActions.length} Completed):
            </span>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {activeActions.map(item => {
                const isChecked = completedActionIds.has(item.id);
                return (
                  <div
                    key={item.id}
                    onClick={() => handleToggleAction(item.id)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                      isChecked
                        ? "bg-emerald-50 border-emerald-300 text-emerald-950 shadow-2xs"
                        : "bg-white border-slate-200 text-slate-800 hover:border-slate-300 hover:shadow-2xs"
                    }`}
                  >
                    <div className="mt-0.5 shrink-0">
                      {isChecked ? (
                        <CheckSquare className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-400" />
                      )}
                    </div>

                    <div className="space-y-1 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className={`text-xs font-bold flex items-center gap-1.5 ${isChecked ? "line-through text-emerald-800" : "text-slate-900"}`}>
                          {item.icon}
                          {item.title}
                        </span>
                        <span className="text-[9px] font-black uppercase px-2 py-0.5 bg-slate-100 text-slate-600 rounded">
                          {item.category}
                        </span>
                      </div>
                      <p className={`text-[11px] leading-snug font-medium ${isChecked ? "text-emerald-700" : "text-slate-600"}`}>
                        {item.actionText}
                      </p>
                      <div className="flex items-center justify-between text-[9.5px] text-slate-400 pt-1 font-mono">
                        <span>Urgency: {item.urgency}</span>
                        {isChecked && <span className="text-emerald-600 font-bold">✓ Action Dispatched</span>}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        /* NORMAL STATE WHEN NO THERMAL ALERT IS ACTIVE */
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5 text-slate-700">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <span className="font-extrabold text-slate-800 uppercase tracking-wide block">
                Thermal Comfort Zone Nominal (No Extreme Heat or Frost)
              </span>
              <p className="text-[11px] text-slate-500 font-medium">
                Live meteorological sensors report optimal temperature ranges for broiler and layer flock management.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-slate-500 bg-white border border-slate-200 px-2.5 py-1 rounded-lg">
              Auto-Monitoring Active
            </span>
            <button
              type="button"
              onClick={() => setActiveSimulation("heatwave")}
              className="px-3 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-xl text-[11px] font-bold transition-all cursor-pointer"
            >
              Test Heatwave Response
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

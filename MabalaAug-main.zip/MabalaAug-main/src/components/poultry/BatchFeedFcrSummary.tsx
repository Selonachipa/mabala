import React, { useState, useMemo } from "react";
import { PoultryBatch, PoultryFeedLog } from "./types";
import { 
  Scale, DollarSign, TrendingUp, Award, AlertTriangle, CheckCircle2, 
  Plus, Calendar, ArrowUpRight, BarChart2, Sparkles, Filter, Info, 
  HelpCircle, ChevronRight, Eye
} from "lucide-react";

interface BatchFeedFcrSummaryProps {
  batches: PoultryBatch[];
  currencySymbol: string;
  onLogFeedForBatch?: (batchId: string) => void;
  onUpdateBatch?: (batch: PoultryBatch) => void;
  writeAuditLog?: (action: string, module: string, target: string, details: string) => void;
}

export default function BatchFeedFcrSummary({
  batches,
  currencySymbol,
  onLogFeedForBatch,
  onUpdateBatch,
  writeAuditLog,
}: BatchFeedFcrSummaryProps) {
  const [filterType, setFilterType] = useState<"all" | "broiler" | "layer" | "village">("all");
  const [selectedBatchDetailId, setSelectedBatchDetailId] = useState<string | null>(null);
  const [showWeightModal, setShowWeightModal] = useState<boolean>(false);
  const [weightBatchId, setWeightBatchId] = useState<string>("");
  const [weightForm, setWeightForm] = useState({
    date: new Date().toISOString().split("T")[0],
    averageWeightKg: 1.8,
    sampleSize: 10,
    remarks: "Routine flock sampling",
  });

  // Calculate detailed feed & FCR metrics for every batch
  const batchSummaries = useMemo(() => {
    return batches
      .filter((b) => {
        if (filterType !== "all" && b.poultryType !== filterType) return false;
        return true;
      })
      .map((batch) => {
        const feedLogs = batch.feedLogs || [];
        const totalFeedKg = feedLogs.reduce((sum, l) => sum + (Number(l.quantityKg) || 0), 0);
        const totalFeedBags = totalFeedKg / 50;
        const totalFeedCost = feedLogs.reduce((sum, l) => sum + (Number(l.cost) || 0), 0) || (batch.cumulativeFeedCost || 0);

        const headcount = batch.currentHeadcount || batch.initialHeadcount || 1;
        const initialHeadcount = batch.initialHeadcount || 1;

        // Weight & Biomass calculations
        const weightSamples = batch.weightSamples || [];
        const latestWeightSample = weightSamples.length > 0
          ? weightSamples[weightSamples.length - 1].averageWeightKg
          : (batch.poultryType === "broiler" ? 1.8 : 1.5);

        const hasCustomWeightSample = weightSamples.length > 0;

        // DOC standard start weight is ~0.042 kg (42g)
        const docWeightKg = 0.042;
        const currentTotalBiomassKg = headcount * latestWeightSample;
        const initialBiomassKg = initialHeadcount * docWeightKg;
        const netBiomassGainedKg = Math.max(0.1, currentTotalBiomassKg - initialBiomassKg);

        // Layer egg mass calculations
        const eggCollections = batch.eggCollections || [];
        const totalEggs = eggCollections.reduce((sum, c) => sum + (Number(c.totalCollected) || 0), 0);
        const totalEggMassKg = totalEggs * 0.06; // standard 60g per commercial egg
        const totalEggDozens = totalEggs / 12;

        let fcr = 0;
        let fcrLabel = "";
        let fcrStatus: "OPTIMAL" | "STANDARD" | "ATTENTION" | "NO_DATA" = "NO_DATA";
        let benchmarkGuide = "";
        let feedCostPerKgGain = 0;

        if (batch.poultryType === "broiler") {
          fcrLabel = "Broiler FCR (kg feed / kg live meat gain)";
          if (totalFeedKg > 0 && netBiomassGainedKg > 0) {
            fcr = Number((totalFeedKg / netBiomassGainedKg).toFixed(2));
            feedCostPerKgGain = totalFeedCost / netBiomassGainedKg;

            if (fcr <= 1.60) {
              fcrStatus = "OPTIMAL";
              benchmarkGuide = "Outstanding FCR (<1.60). High efficiency and optimal profitability.";
            } else if (fcr <= 1.85) {
              fcrStatus = "STANDARD";
              benchmarkGuide = "Standard commercial efficiency (1.60 - 1.85). Normal growth conversion.";
            } else {
              fcrStatus = "ATTENTION";
              benchmarkGuide = "Elevated FCR (>1.85). Check for feed spillage, disease, or suboptimal temperature.";
            }
          } else {
            fcrStatus = "NO_DATA";
            benchmarkGuide = "Log daily feed logs to activate live FCR calculation.";
          }
        } else {
          // Layer or Village
          fcrLabel = "Layer Feed Efficiency (kg feed / kg egg mass)";
          if (totalFeedKg > 0 && totalEggMassKg > 0) {
            fcr = Number((totalFeedKg / totalEggMassKg).toFixed(2));
            feedCostPerKgGain = totalFeedCost / totalEggMassKg;

            if (fcr <= 2.20) {
              fcrStatus = "OPTIMAL";
              benchmarkGuide = "Excellent Egg FCR (<2.20). Optimal feed-to-egg conversion.";
            } else if (fcr <= 2.60) {
              fcrStatus = "STANDARD";
              benchmarkGuide = "Standard Layer Efficiency (2.20 - 2.60 kg feed / kg egg mass).";
            } else {
              fcrStatus = "ATTENTION";
              benchmarkGuide = "High Egg FCR (>2.60). Check lay rate and feed wastage.";
            }
          } else if (totalFeedKg > 0 && netBiomassGainedKg > 0) {
            // Pullet / growth phase FCR
            fcr = Number((totalFeedKg / netBiomassGainedKg).toFixed(2));
            fcrStatus = fcr <= 2.2 ? "OPTIMAL" : fcr <= 2.8 ? "STANDARD" : "ATTENTION";
            benchmarkGuide = "Pullet rearing growth FCR (pre-lay phase).";
          } else {
            fcrStatus = "NO_DATA";
            benchmarkGuide = "Log feed & egg collections to calculate Egg FCR.";
          }
        }

        // Daily average consumption per bird
        const totalLoggedDays = Math.max(1, new Set(feedLogs.map((l) => l.date)).size);
        const avgDailyGramsPerBird = totalFeedKg > 0 ? (totalFeedKg * 1000) / (headcount * totalLoggedDays) : 0;
        const feedCostPerBird = headcount > 0 ? totalFeedCost / headcount : 0;

        return {
          batch,
          totalFeedKg,
          totalFeedBags,
          totalFeedCost,
          feedLogsCount: feedLogs.length,
          headcount,
          initialHeadcount,
          latestWeightSample,
          hasCustomWeightSample,
          netBiomassGainedKg,
          totalEggs,
          totalEggMassKg,
          totalEggDozens,
          fcr,
          fcrLabel,
          fcrStatus,
          benchmarkGuide,
          feedCostPerKgGain,
          avgDailyGramsPerBird,
          feedCostPerBird,
          totalLoggedDays,
        };
      });
  }, [batches, filterType]);

  // Aggregate totals across all filtered batches
  const aggregateMetrics = useMemo(() => {
    let totalKg = 0;
    let totalCost = 0;
    let totalBiomassGain = 0;
    let totalBirds = 0;

    batchSummaries.forEach((s) => {
      totalKg += s.totalFeedKg;
      totalCost += s.totalFeedCost;
      totalBiomassGain += s.netBiomassGainedKg;
      totalBirds += s.headcount;
    });

    const overallFcr = totalBiomassGain > 0 && totalKg > 0 ? totalKg / totalBiomassGain : 0;
    const avgCostPerKgGain = totalBiomassGain > 0 ? totalCost / totalBiomassGain : 0;

    return {
      totalKg,
      totalBags: totalKg / 50,
      totalCost,
      totalBiomassGain,
      totalBirds,
      overallFcr: Number(overallFcr.toFixed(2)),
      avgCostPerKgGain,
    };
  }, [batchSummaries]);

  // Quick weight sampling submit
  const handleSaveWeightSample = (e: React.FormEvent) => {
    e.preventDefault();
    if (!weightBatchId || !onUpdateBatch) return;

    const targetBatch = batches.find((b) => b.id === weightBatchId);
    if (!targetBatch) return;

    const newSample = {
      id: `WS-${Date.now().toString().slice(-5)}`,
      date: weightForm.date,
      averageWeightKg: Number(weightForm.averageWeightKg),
      sampleSize: Number(weightForm.sampleSize),
      remarks: weightForm.remarks,
    };

    const updated = {
      ...targetBatch,
      weightSamples: [...(targetBatch.weightSamples || []), newSample],
      updatedAt: new Date().toISOString(),
    };

    onUpdateBatch(updated);
    if (writeAuditLog) {
      writeAuditLog(
        "UPDATE",
        "Poultry Weight Sample",
        targetBatch.batchId,
        `Recorded average weight sample ${weightForm.averageWeightKg}kg for flock ${targetBatch.batchName}`
      );
    }
    setShowWeightModal(false);
  };

  const getStatusBadge = (status: "OPTIMAL" | "STANDARD" | "ATTENTION" | "NO_DATA") => {
    switch (status) {
      case "OPTIMAL":
        return (
          <span className="bg-emerald-500/15 text-emerald-700 border border-emerald-500/30 text-[10px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1">
            <CheckCircle2 size={11} className="text-emerald-600" /> Optimal FCR
          </span>
        );
      case "STANDARD":
        return (
          <span className="bg-sky-500/15 text-sky-700 border border-sky-500/30 text-[10px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1">
            <Award size={11} className="text-sky-600" /> Standard FCR
          </span>
        );
      case "ATTENTION":
        return (
          <span className="bg-amber-500/15 text-amber-800 border border-amber-500/30 text-[10px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1">
            <AlertTriangle size={11} className="text-amber-600" /> Suboptimal FCR
          </span>
        );
      default:
        return (
          <span className="bg-slate-100 text-slate-500 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
            No Feed Logs
          </span>
        );
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-6 shadow-xs space-y-6" id="batch-feed-fcr-summary-root">
      {/* Header & Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-600 text-xs font-black uppercase tracking-wider">
            <Scale size={16} />
            <span>Feed Performance & Conversion Analytics</span>
          </div>
          <h3 className="text-xl font-black text-slate-900 mt-0.5">
            Flock Feed Conversion Ratio (FCR) & Cost Summary
          </h3>
          <p className="text-xs text-slate-500 font-medium">
            Comparative analysis of total feed consumed, total feed expenditures, biomass gain, and live FCR efficiency metrics.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Flock Type Filter */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl gap-1 text-xs font-bold text-slate-600">
            <button
              type="button"
              onClick={() => setFilterType("all")}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                filterType === "all" ? "bg-white text-slate-900 shadow-xs font-black" : "hover:text-slate-900"
              }`}
            >
              All Types
            </button>
            <button
              type="button"
              onClick={() => setFilterType("broiler")}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                filterType === "broiler" ? "bg-amber-500 text-white shadow-xs font-black" : "hover:text-slate-900"
              }`}
            >
              Broilers
            </button>
            <button
              type="button"
              onClick={() => setFilterType("layer")}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                filterType === "layer" ? "bg-sky-500 text-white shadow-xs font-black" : "hover:text-slate-900"
              }`}
            >
              Layers
            </button>
            <button
              type="button"
              onClick={() => setFilterType("village")}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                filterType === "village" ? "bg-emerald-600 text-white shadow-xs font-black" : "hover:text-slate-900"
              }`}
            >
              Village
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              if (batches.length > 0) {
                setWeightBatchId(batches[0].id);
                setShowWeightModal(true);
              }
            }}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
          >
            <Scale size={13} />
            Log Weight Sample
          </button>
        </div>
      </div>

      {/* Aggregate KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-50 border border-slate-200/70 p-4 rounded-2xl space-y-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Feed Consumed</span>
          <div className="text-xl font-black text-slate-900 font-mono">
            {aggregateMetrics.totalKg.toLocaleString()} <span className="text-xs font-bold text-slate-500">kg</span>
          </div>
          <p className="text-[11px] text-amber-700 font-bold">{aggregateMetrics.totalBags.toFixed(1)} Bags (50kg)</p>
        </div>

        <div className="bg-slate-50 border border-slate-200/70 p-4 rounded-2xl space-y-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Feed Expenditure</span>
          <div className="text-xl font-black text-emerald-700 font-mono">
            {currencySymbol}{aggregateMetrics.totalCost.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500 font-medium">COA 5210 Feed Cost</p>
        </div>

        <div className="bg-slate-50 border border-slate-200/70 p-4 rounded-2xl space-y-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Net Biomass / Meat Gained</span>
          <div className="text-xl font-black text-slate-900 font-mono">
            {aggregateMetrics.totalBiomassGain.toFixed(1)} <span className="text-xs font-bold text-slate-500">kg</span>
          </div>
          <p className="text-[11px] text-slate-500 font-medium">Across {aggregateMetrics.totalBirds} Active Birds</p>
        </div>

        <div className="bg-slate-900 text-white p-4 rounded-2xl space-y-1 shadow-xs">
          <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider">Portfolio Weighted FCR</span>
          <div className="text-xl font-black text-white font-mono flex items-baseline gap-1.5">
            <span>{aggregateMetrics.overallFcr > 0 ? aggregateMetrics.overallFcr.toFixed(2) : "N/A"}</span>
            <span className="text-xs font-normal text-slate-400">kg feed/kg gain</span>
          </div>
          <p className="text-[11px] text-emerald-400 font-bold">
            {aggregateMetrics.avgCostPerKgGain > 0 ? `${currencySymbol}${aggregateMetrics.avgCostPerKgGain.toFixed(2)} / kg meat gain` : "Target: 1.50 - 1.70"}
          </p>
        </div>
      </div>

      {/* Per Batch FCR & Feed Cost Cards / Matrix */}
      <div className="space-y-4">
        <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Flock-by-Flock Breakdown</h4>

        {batchSummaries.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-slate-400 text-xs">
            No poultry batches found matching the selected filter.
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {batchSummaries.map((summary) => {
              const { batch } = summary;
              return (
                <div
                  key={batch.id}
                  className="bg-white border border-slate-200 rounded-2xl p-4.5 hover:shadow-md transition-all space-y-3.5 relative overflow-hidden"
                >
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-md ${
                            batch.poultryType === "broiler"
                              ? "bg-amber-100 text-amber-800"
                              : batch.poultryType === "layer"
                              ? "bg-sky-100 text-sky-800"
                              : "bg-emerald-100 text-emerald-800"
                          }`}
                        >
                          {batch.poultryType}
                        </span>
                        <h4 className="font-black text-slate-900 text-sm">{batch.batchName}</h4>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {batch.breed} • {batch.batchId} • <strong>{summary.headcount} birds</strong>
                      </p>
                    </div>

                    <div className="text-right">
                      {getStatusBadge(summary.fcrStatus)}
                    </div>
                  </div>

                  {/* Primary Metrics Grid */}
                  <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
                    {/* FCR Value */}
                    <div className="space-y-0.5">
                      <span className="text-[9px] font-black uppercase text-slate-400 block">Live FCR Ratio</span>
                      <strong className="text-base font-black font-mono text-slate-900">
                        {summary.fcr > 0 ? summary.fcr.toFixed(2) : "N/A"}
                      </strong>
                      <span className="text-[9px] text-slate-500 block">kg feed / kg</span>
                    </div>

                    {/* Total Feed Cost */}
                    <div className="space-y-0.5 border-x border-slate-200">
                      <span className="text-[9px] font-black uppercase text-slate-400 block">Total Feed Cost</span>
                      <strong className="text-base font-black font-mono text-emerald-700">
                        {currencySymbol}{summary.totalFeedCost.toLocaleString()}
                      </strong>
                      <span className="text-[9px] text-slate-500 block">
                        {currencySymbol}{summary.feedCostPerBird.toFixed(2)}/bird
                      </span>
                    </div>

                    {/* Total Feed Consumed */}
                    <div className="space-y-0.5">
                      <span className="text-[9px] font-black uppercase text-slate-400 block">Feed Consumed</span>
                      <strong className="text-base font-black font-mono text-amber-700">
                        {summary.totalFeedKg.toLocaleString()} <span className="text-[10px]">kg</span>
                      </strong>
                      <span className="text-[9px] text-slate-500 block">
                        {summary.totalFeedBags.toFixed(1)} Bags (50kg)
                      </span>
                    </div>
                  </div>

                  {/* Weight & Production Detail Row */}
                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
                    <div className="p-2 bg-slate-50/70 rounded-lg flex items-center justify-between">
                      <span className="text-[10.5px] text-slate-500">
                        {batch.poultryType === "broiler" ? "Current Avg Weight:" : "Egg Collection:"}
                      </span>
                      <span className="font-black text-slate-800 font-mono">
                        {batch.poultryType === "broiler"
                          ? `${summary.latestWeightSample.toFixed(2)} kg / bird`
                          : `${summary.totalEggs.toLocaleString()} eggs (${summary.totalEggMassKg.toFixed(1)}kg)`}
                      </span>
                    </div>

                    <div className="p-2 bg-slate-50/70 rounded-lg flex items-center justify-between">
                      <span className="text-[10.5px] text-slate-500">Feed Cost / kg Gain:</span>
                      <span className="font-black text-emerald-700 font-mono">
                        {summary.feedCostPerKgGain > 0 ? `${currencySymbol}${summary.feedCostPerKgGain.toFixed(2)}/kg` : "—"}
                      </span>
                    </div>
                  </div>

                  {/* Benchmark Guide & Action buttons */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 border-t border-slate-100 text-xs">
                    <p className="text-[10.5px] text-slate-500 font-medium italic">
                      {summary.benchmarkGuide}
                    </p>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          setWeightBatchId(batch.id);
                          setShowWeightModal(true);
                        }}
                        className="px-2.5 py-1 text-[11px] bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg transition-all cursor-pointer"
                        title="Update weight sample for this flock"
                      >
                        Sample Weight
                      </button>

                      {onLogFeedForBatch && (
                        <button
                          type="button"
                          onClick={() => onLogFeedForBatch(batch.id)}
                          className="px-3 py-1 text-[11px] bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-lg transition-all cursor-pointer flex items-center gap-1 shadow-xs"
                        >
                          <Plus size={12} /> Log Feed
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* WEIGHT SAMPLE MODAL */}
      {showWeightModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-black text-slate-900 text-sm">Record Flock Weight Sample</h3>
                <p className="text-[10px] text-slate-400 font-medium">Updates live biomass and calculates exact FCR conversion</p>
              </div>
              <button
                type="button"
                onClick={() => setShowWeightModal(false)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveWeightSample} className="space-y-3.5 text-xs">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                  Flock Batch
                </label>
                <select
                  value={weightBatchId}
                  onChange={(e) => setWeightBatchId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800"
                >
                  {batches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.batchName} ({b.poultryType} • {b.currentHeadcount} birds)
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                    Sample Date
                  </label>
                  <input
                    type="date"
                    required
                    value={weightForm.date}
                    onChange={(e) => setWeightForm({ ...weightForm, date: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                    Birds Sampled (Count)
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={weightForm.sampleSize}
                    onChange={(e) => setWeightForm({ ...weightForm, sampleSize: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                  Average Weight per Bird (kg)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.05"
                  required
                  value={weightForm.averageWeightKg}
                  onChange={(e) => setWeightForm({ ...weightForm, averageWeightKg: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-black text-slate-900 text-sm"
                  placeholder="e.g. 1.85"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                  Remarks / Health Observations
                </label>
                <input
                  type="text"
                  value={weightForm.remarks}
                  onChange={(e) => setWeightForm({ ...weightForm, remarks: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  placeholder="e.g. Uniform flock weight, energetic feeding"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowWeightModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black cursor-pointer shadow-md"
                >
                  Save Sample & Recalculate FCR
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

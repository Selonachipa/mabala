import React, { useState, useMemo } from "react";
import { PoultryBatch, PoultryMortalityLog } from "./types";
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  HeartPulse,
  Plus,
  ShieldAlert,
  Skull,
  TrendingDown,
  TrendingUp,
  Info,
  Calendar,
  Sparkles
} from "lucide-react";
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts";

interface BatchHealthSummaryProps {
  batches: PoultryBatch[];
  onUpdateBatch: (batch: PoultryBatch) => void;
  writeAuditLog?: (action: string, module: string, target: string, details: string) => void;
  employees?: any[];
}

// Breed Benchmark Definitions
const BREED_BENCHMARKS: { [key: string]: { name: string; weeklyMortalityPct: number; maxCycleTargetPct: number; description: string } } = {
  broiler_cobb: {
    name: "Cobb 500 / Ross 308 Commercial Broiler",
    weeklyMortalityPct: 0.5,
    maxCycleTargetPct: 3.5,
    description: "Standard fast-growing broiler target: <1.2% in week 1, ~0.4% weekly thereafter. Total cycle target <3.5%."
  },
  layer_hyline: {
    name: "Hy-Line Brown / ISA Brown Layer",
    weeklyMortalityPct: 0.1,
    maxCycleTargetPct: 5.0,
    description: "High-producing layer target: <0.15% weekly brooding, <0.10% weekly production. Total 72-week target <5.0%."
  },
  village_kuroiler: {
    name: "Kuroiler / Sasso / Local Village Breed",
    weeklyMortalityPct: 0.25,
    maxCycleTargetPct: 7.5,
    description: "Hardy dual-purpose/free-range target: ~0.25% weekly, robust disease resistance. Total target <7.5%."
  }
};

export default function BatchHealthSummary({
  batches = [],
  onUpdateBatch,
  writeAuditLog,
  employees = []
}: BatchHealthSummaryProps) {
  const activeBatches = useMemo(() => batches.filter(b => b.status === "active"), [batches]);
  const [selectedBatchId, setSelectedBatchId] = useState<string>(
    activeBatches.length > 0 ? activeBatches[0].id : batches[0]?.id || ""
  );

  // Modal for logging mortality
  const [showLogModal, setShowLogModal] = useState(false);
  const [logDate, setLogDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [logCount, setLogCount] = useState<number>(1);
  const [logCause, setLogCause] = useState<string>("Heat Stress / Dehydration");
  const [logNotes, setLogNotes] = useState<string>("");

  const selectedBatch = useMemo(() => {
    return batches.find(b => b.id === selectedBatchId) || activeBatches[0] || batches[0];
  }, [batches, selectedBatchId, activeBatches]);

  // Calculations for selected batch health
  const batchHealthStats = useMemo(() => {
    if (!selectedBatch) return null;

    const initialCount = selectedBatch.initialHeadcount || 100;
    const currentCount = selectedBatch.currentHeadcount || initialCount;

    // Total deaths logged
    const totalDeaths = (selectedBatch.mortalityLogs || []).reduce((sum, m) => sum + (m.count || 0), 0);
    const observedMortalityRatePct = Number(((totalDeaths / initialCount) * 100).toFixed(2));

    // Calculate age in days & weeks
    const startDate = new Date((selectedBatch as any).arrivalDate || (selectedBatch as any).dateReceived || Date.now());
    const now = new Date();
    const diffTime = Math.max(0, now.getTime() - startDate.getTime());
    const ageDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const ageWeeks = Math.max(1, Math.ceil(ageDays / 7));

    // Select breed benchmark based on poultryType or batch name
    let benchmarkKey = "broiler_cobb";
    if (selectedBatch.poultryType === "layer") {
      benchmarkKey = "layer_hyline";
    } else if (selectedBatch.poultryType === "village") {
      benchmarkKey = "village_kuroiler";
    }
    const benchmarkConfig = BREED_BENCHMARKS[benchmarkKey];

    // Benchmark expected cumulative mortality at current week
    // Week 1 has slightly higher placement stress (+0.5%)
    const expectedCumulativeMortalityPct = Number(
      Math.min(
        benchmarkConfig.maxCycleTargetPct,
        0.5 + (ageWeeks * benchmarkConfig.weeklyMortalityPct)
      ).toFixed(2)
    );

    const expectedDeathsCount = Math.round((expectedCumulativeMortalityPct / 100) * initialCount);

    // Health Status evaluation
    let status: "EXCELLENT" | "NORMAL" | "ELEVATED" | "CRITICAL" = "NORMAL";
    let statusColor = "emerald";
    if (observedMortalityRatePct <= expectedCumulativeMortalityPct) {
      status = "EXCELLENT";
      statusColor = "emerald";
    } else if (observedMortalityRatePct <= expectedCumulativeMortalityPct * 1.3) {
      status = "NORMAL";
      statusColor = "sky";
    } else if (observedMortalityRatePct <= expectedCumulativeMortalityPct * 1.8) {
      status = "ELEVATED";
      statusColor = "amber";
    } else {
      status = "CRITICAL";
      statusColor = "rose";
    }

    // Generate weekly breakdown data for chart
    const maxWeeksToChart = Math.max(ageWeeks, selectedBatch.poultryType === "broiler" ? 6 : 12);
    const weeklyChartData = [];

    for (let w = 1; w <= maxWeeksToChart; w++) {
      // Benchmark line value
      const benchmarkCumPct = Number(Math.min(benchmarkConfig.maxCycleTargetPct, 0.5 + (w * benchmarkConfig.weeklyMortalityPct)).toFixed(2));
      const benchmarkCumDeaths = Math.round((benchmarkCumPct / 100) * initialCount);

      // Observed deaths up to week w
      let observedDeathsInWeek = 0;
      let observedCumDeathsUpToWeek = 0;

      (selectedBatch.mortalityLogs || []).forEach(log => {
        const logDateObj = new Date(log.date);
        const logDiffDays = Math.floor((logDateObj.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
        const logWeek = Math.max(1, Math.ceil(logDiffDays / 7));

        if (logWeek === w) {
          observedDeathsInWeek += log.count || 0;
        }
        if (logWeek <= w) {
          observedCumDeathsUpToWeek += log.count || 0;
        }
      });

      const observedCumPct = Number(((observedCumDeathsUpToWeek / initialCount) * 100).toFixed(2));

      weeklyChartData.push({
        weekLabel: `Wk ${w}`,
        weekNum: w,
        observedWeeklyDeaths: w <= ageWeeks ? observedDeathsInWeek : null,
        observedCumDeaths: w <= ageWeeks ? observedCumDeathsUpToWeek : null,
        observedCumPct: w <= ageWeeks ? observedCumPct : null,
        benchmarkCumDeaths: benchmarkCumDeaths,
        benchmarkCumPct: benchmarkCumPct
      });
    }

    // Causes breakdown
    const causeMap: { [cause: string]: number } = {};
    (selectedBatch.mortalityLogs || []).forEach(m => {
      const c = m.cause || "Unspecified / Natural";
      causeMap[c] = (causeMap[c] || 0) + (m.count || 0);
    });

    return {
      initialCount,
      currentCount,
      totalDeaths,
      observedMortalityRatePct,
      ageDays,
      ageWeeks,
      benchmarkConfig,
      expectedCumulativeMortalityPct,
      expectedDeathsCount,
      status,
      statusColor,
      weeklyChartData,
      causeMap
    };
  }, [selectedBatch]);

  // Log mortality submit handler
  const handleAddMortalityLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBatch || logCount <= 0) return;

    const newLog: PoultryMortalityLog = {
      id: `MORT-${Date.now()}`,
      date: logDate,
      count: Number(logCount),
      cause: logCause,
      notes: logNotes,
      lossValue: Number(logCount) * ((selectedBatch as any).unitCost || 50)
    };

    const updatedMortalityLogs = [newLog, ...(selectedBatch.mortalityLogs || [])];
    const newCurrentHeadcount = Math.max(0, (selectedBatch.currentHeadcount || selectedBatch.initialHeadcount) - Number(logCount));

    const updatedBatch: PoultryBatch = {
      ...selectedBatch,
      currentHeadcount: newCurrentHeadcount,
      mortalityLogs: updatedMortalityLogs
    };

    onUpdateBatch(updatedBatch);
    if (writeAuditLog) {
      writeAuditLog("MORTALITY_LOGGED", "Poultry", selectedBatch.batchName, `Logged ${logCount} mortality (${logCause})`);
    }

    setShowLogModal(false);
    setLogCount(1);
    setLogNotes("");
  };

  return (
    <div className="space-y-6 font-sans" id="batch-health-summary-panel">
      {/* Top Header Card */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-2xl">
              <HeartPulse className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight text-white">Batch Health & Mortality Benchmarking</h2>
              <p className="text-xs text-slate-400 font-medium mt-0.5">
                Real-time flock survival monitoring compared against Cobb 500, Ross 308, Hy-Line, and Kuroiler global standards.
              </p>
            </div>
          </div>
        </div>

        {/* Batch Dropdown Selector */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex-1 md:w-64">
            <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block mb-1">
              Select Flock Batch
            </label>
            <select
              value={selectedBatchId}
              onChange={(e) => setSelectedBatchId(e.target.value)}
              className="w-full text-xs font-bold bg-slate-800 text-white border border-slate-700 rounded-xl p-2.5 outline-none focus:border-rose-400 cursor-pointer shadow-xs"
            >
              {batches.map(b => (
                <option key={b.id} value={b.id}>
                  [{b.poultryType.toUpperCase()}] {b.batchName} ({b.currentHeadcount} birds)
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={() => setShowLogModal(true)}
            className="mt-5 px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Log Mortality</span>
          </button>
        </div>
      </div>

      {batchHealthStats ? (
        <>
          {/* Main Benchmark KPI Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* 1. Health Status Card */}
            <div className="p-5 bg-white border border-slate-200 rounded-3xl shadow-xs space-y-2 relative overflow-hidden">
              <div className="flex justify-between items-start">
                <span className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500">Flock Health Status</span>
                <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                  batchHealthStats.status === "EXCELLENT" ? "bg-emerald-100 text-emerald-800" :
                  batchHealthStats.status === "NORMAL" ? "bg-sky-100 text-sky-800" :
                  batchHealthStats.status === "ELEVATED" ? "bg-amber-100 text-amber-800" :
                  "bg-rose-100 text-rose-800 border border-rose-300"
                }`}>
                  {batchHealthStats.status}
                </span>
              </div>
              <div className="text-2xl font-black text-slate-900 tracking-tight font-mono">
                {batchHealthStats.observedMortalityRatePct}% <span className="text-xs font-bold text-slate-400">mortality</span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                {batchHealthStats.totalDeaths} dead out of {batchHealthStats.initialCount} initial head
              </p>
            </div>

            {/* 2. Age & Duration */}
            <div className="p-5 bg-white border border-slate-200 rounded-3xl shadow-xs space-y-2">
              <span className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500">Flock Age & Stage</span>
              <div className="text-2xl font-black text-slate-900 tracking-tight font-mono">
                Day {batchHealthStats.ageDays} <span className="text-xs font-bold text-slate-400">(Wk {batchHealthStats.ageWeeks})</span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                Active headcount: <strong className="text-slate-800">{batchHealthStats.currentCount.toLocaleString()} birds</strong>
              </p>
            </div>

            {/* 3. Industry Benchmark Comparison Target */}
            <div className="p-5 bg-white border border-slate-200 rounded-3xl shadow-xs space-y-2">
              <span className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500">Industry Benchmark</span>
              <div className="text-2xl font-black text-emerald-700 tracking-tight font-mono">
                {batchHealthStats.expectedCumulativeMortalityPct}% <span className="text-xs font-bold text-slate-400">target max</span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                Expected max deaths at Wk {batchHealthStats.ageWeeks}: ~{batchHealthStats.expectedDeathsCount} birds
              </p>
            </div>

            {/* 4. Variance vs Benchmark */}
            <div className={`p-5 rounded-3xl border shadow-xs space-y-2 ${
              batchHealthStats.observedMortalityRatePct <= batchHealthStats.expectedCumulativeMortalityPct
                ? "bg-emerald-50/60 border-emerald-200 text-emerald-900"
                : "bg-rose-50/60 border-rose-200 text-rose-900"
            }`}>
              <span className="text-[10.5px] font-extrabold uppercase tracking-wider opacity-80 block">
                Benchmark Variance
              </span>
              <div className="text-2xl font-black tracking-tight font-mono flex items-center gap-1.5">
                {batchHealthStats.observedMortalityRatePct <= batchHealthStats.expectedCumulativeMortalityPct ? (
                  <>
                    <TrendingDown className="w-5 h-5 text-emerald-600" />
                    <span>-{(batchHealthStats.expectedCumulativeMortalityPct - batchHealthStats.observedMortalityRatePct).toFixed(2)}%</span>
                  </>
                ) : (
                  <>
                    <TrendingUp className="w-5 h-5 text-rose-600" />
                    <span>+{(batchHealthStats.observedMortalityRatePct - batchHealthStats.expectedCumulativeMortalityPct).toFixed(2)}%</span>
                  </>
                )}
              </div>
              <p className="text-[11px] font-medium opacity-90">
                {batchHealthStats.observedMortalityRatePct <= batchHealthStats.expectedCumulativeMortalityPct
                  ? "Flock is performing ABOVE industry health benchmarks!"
                  : "Mortality exceeds expected breed benchmark thresholds."}
              </p>
            </div>
          </div>

          {/* Benchmark Meter & Breed Info */}
          <div className="p-5 bg-white border border-slate-200 rounded-3xl shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-rose-500" />
                  Breed Health Benchmark Profile: {batchHealthStats.benchmarkConfig.name}
                </h3>
                <p className="text-[11.5px] text-slate-500 font-medium mt-0.5">
                  {batchHealthStats.benchmarkConfig.description}
                </p>
              </div>
            </div>

            {/* Progress comparison bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-700">
                <span>Observed Mortality vs Breed Threshold</span>
                <span className="font-mono">{batchHealthStats.observedMortalityRatePct}% / {batchHealthStats.expectedCumulativeMortalityPct}% Target</span>
              </div>
              <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200 flex">
                <div
                  style={{ width: `${Math.min(100, (batchHealthStats.observedMortalityRatePct / Math.max(1, batchHealthStats.benchmarkConfig.maxCycleTargetPct)) * 100)}%` }}
                  className={`h-full rounded-full transition-all duration-500 ${
                    batchHealthStats.status === "EXCELLENT" ? "bg-emerald-500" :
                    batchHealthStats.status === "NORMAL" ? "bg-sky-500" :
                    batchHealthStats.status === "ELEVATED" ? "bg-amber-500" : "bg-rose-600"
                  }`}
                />
              </div>
              <div className="flex justify-between text-[10px] font-semibold text-slate-400 pt-0.5">
                <span>0% (Perfect Survival)</span>
                <span>Target: {batchHealthStats.expectedCumulativeMortalityPct}% (Wk {batchHealthStats.ageWeeks})</span>
                <span>Max Cycle Limit: {batchHealthStats.benchmarkConfig.maxCycleTargetPct}%</span>
              </div>
            </div>
          </div>

          {/* Chart Section: Weekly Cumulative Mortality vs Benchmark */}
          <div className="p-6 bg-slate-900 text-white rounded-3xl border border-slate-800 shadow-xl space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-slate-100 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-rose-400" />
                  Weekly Cumulative Mortality vs Breed Benchmark Curve
                </h4>
                <p className="text-[11px] text-slate-400 font-medium mt-0.5">
                  Comparing actual logged flock deaths week-by-week against standard {batchHealthStats.benchmarkConfig.name} mortality curves.
                </p>
              </div>
            </div>

            <div className="w-full h-64 pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={batchHealthStats.weeklyChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="weekLabel" stroke="#64748b" fontSize={10} tickLine={false} />
                  <YAxis yAxisId="deaths" stroke="#f43f5e" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis yAxisId="pct" orientation="right" domain={[0, Math.max(10, batchHealthStats.benchmarkConfig.maxCycleTargetPct * 1.5)]} stroke="#10b981" fontSize={10} tickLine={false} axisLine={false} unit="%" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#0f172a",
                      borderColor: "#334155",
                      borderRadius: "12px",
                      fontSize: "11px",
                      color: "#ffffff"
                    }}
                  />
                  <Legend verticalAlign="top" height={30} wrapperStyle={{ fontSize: "10.5px", color: "#94a3b8" }} />
                  <Bar yAxisId="deaths" dataKey="observedWeeklyDeaths" name="Weekly Observed Deaths" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                  <Line yAxisId="pct" type="monotone" dataKey="observedCumPct" name="Actual Cumulative Mortality (%)" stroke="#38bdf8" strokeWidth={3} dot={{ r: 3 }} />
                  <Line yAxisId="pct" type="monotone" dataKey="benchmarkCumPct" name="Industry Benchmark Target (%)" stroke="#34d399" strokeWidth={2} strokeDasharray="5 5" dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Causes Breakdown & Recent Mortality Logs */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Causes Breakdown */}
            <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-3 md:col-span-1">
              <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <Skull className="w-4 h-4 text-slate-700" />
                Mortality Causes Breakdown
              </h4>
              
              {Object.keys(batchHealthStats.causeMap).length === 0 ? (
                <div className="p-6 text-center text-slate-400 font-bold text-xs bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  No mortality losses logged for this flock!
                </div>
              ) : (
                <div className="space-y-2">
                  {Object.entries(batchHealthStats.causeMap).map(([cause, count]) => {
                    const deathCount = Number(count) || 0;
                    const pct = Number(((deathCount / (batchHealthStats.totalDeaths || 1)) * 100).toFixed(1));
                    return (
                      <div key={cause} className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                        <div className="flex justify-between text-xs font-bold text-slate-800">
                          <span>{cause}</span>
                          <span className="font-mono text-rose-600">{deathCount} dead ({pct}%)</span>
                        </div>
                        <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                          <div style={{ width: `${pct}%` }} className="h-full bg-rose-500 rounded-full" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Historical Mortality Logs Table */}
            <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-3 md:col-span-2">
              <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-900">
                  Recent Mortality Log Records
                </h4>
                <button
                  type="button"
                  onClick={() => setShowLogModal(true)}
                  className="text-xs font-extrabold text-rose-600 hover:text-rose-800 flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Log Death Record</span>
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-800">
                  <thead className="bg-slate-50 font-black text-[9px] text-slate-400 uppercase tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="p-2.5">Date</th>
                      <th className="p-2.5">Count</th>
                      <th className="p-2.5">Cause</th>
                      <th className="p-2.5">Notes & Observations</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {(!selectedBatch.mortalityLogs || selectedBatch.mortalityLogs.length === 0) ? (
                      <tr>
                        <td colSpan={4} className="p-6 text-center text-slate-400 font-bold">
                          Zero mortality records logged.
                        </td>
                      </tr>
                    ) : (
                      selectedBatch.mortalityLogs.map((m, idx) => (
                        <tr key={m.id || idx} className="hover:bg-slate-50">
                          <td className="p-2.5 font-mono text-[11px] text-slate-600">{m.date}</td>
                          <td className="p-2.5 font-mono font-black text-rose-600">{m.count} birds</td>
                          <td className="p-2.5 font-bold text-slate-800">{m.cause}</td>
                          <td className="p-2.5 text-slate-500 text-[11px]">{m.notes || "—"}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="p-12 text-center bg-white border border-slate-200 rounded-3xl">
          <Info className="w-10 h-10 text-slate-400 mx-auto mb-2" />
          <p className="text-sm font-bold text-slate-700">No Poultry Batches Registered</p>
          <p className="text-xs text-slate-400 mt-1">Please register a broiler or layer batch to view health summaries.</p>
        </div>
      )}

      {/* LOG MORTALITY MODAL */}
      {showLogModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs font-sans">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-rose-100 rounded-xl text-rose-600">
                  <Skull className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">Log Flock Mortality Record</h3>
                  <p className="text-[10.5px] text-slate-500 font-bold">{selectedBatch?.batchName}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowLogModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddMortalityLog} className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
                  Incident Date
                </label>
                <input
                  type="date"
                  required
                  value={logDate}
                  onChange={(e) => setLogDate(e.target.value)}
                  className="w-full font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
                  Number of Dead Birds
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={logCount}
                  onChange={(e) => setLogCount(Math.max(1, Number(e.target.value)))}
                  className="w-full font-extrabold font-mono text-sm p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-rose-600"
                />
              </div>

              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
                  Suspected Cause / Diagnosis
                </label>
                <select
                  value={logCause}
                  onChange={(e) => setLogCause(e.target.value)}
                  className="w-full font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none cursor-pointer"
                >
                  <option value="Heat Stress / Dehydration">Heat Stress / Dehydration</option>
                  <option value="Coccidiosis / Enteric">Coccidiosis / Enteric Infection</option>
                  <option value="Newcastle / Respiratory">Newcastle / Respiratory Disease</option>
                  <option value="Smothering / Trampling">Smothering / Trampling Stress</option>
                  <option value="Predator / Physical Injury">Predator / Physical Injury</option>
                  <option value="Ascites / Sudden Death Syndrome">Ascites / Sudden Death Syndrome</option>
                  <option value="Unspecified / Natural Mortality">Unspecified / Natural Mortality</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
                  Notes / Symptoms Observed
                </label>
                <textarea
                  rows={2}
                  value={logNotes}
                  onChange={(e) => setLogNotes(e.target.value)}
                  placeholder="Provide additional details or post-mortem observations..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none font-medium"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowLogModal(false)}
                  className="px-4 py-2 font-bold text-slate-500 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Skull className="w-4 h-4" />
                  <span>Log Mortality</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

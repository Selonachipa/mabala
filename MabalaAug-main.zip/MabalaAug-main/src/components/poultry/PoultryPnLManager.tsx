import React, { useState, useMemo } from "react";
import { PoultryBatch } from "./types";
import { ExpenseTransaction } from "../../types";
import { 
  DollarSign, TrendingUp, TrendingDown, Scale, PieChart, BarChart2, 
  Download, Filter, ShieldCheck, ArrowRight, Sparkles, Feather,
  Building2, Receipt, CheckCircle2, ChevronRight, AlertCircle, Layers,
  SlidersHorizontal, AlertTriangle, ArrowUpRight, ArrowDownRight, RefreshCw,
  Package, HeartPulse, Zap, Tag
} from "lucide-react";

interface PoultryPnLManagerProps {
  batches: PoultryBatch[];
  currencySymbol: string;
  expenses?: ExpenseTransaction[];
}

// Standard baseline budget targets per bird for comparison
export interface PoultryBudgetBaseline {
  chicksCostPerBird: number;
  feedCostPerBird: number;
  healthCostPerBird: number;
  beddingCostPerBird: number;
  heatingCostPerBird: number;
  labourCostPerBird: number;
  mortalityRateMaxPct: number;
}

const DEFAULT_BUDGET_BASELINE: PoultryBudgetBaseline = {
  chicksCostPerBird: 12.00,
  feedCostPerBird: 28.50,
  healthCostPerBird: 4.50,
  beddingCostPerBird: 1.50,
  heatingCostPerBird: 2.00,
  labourCostPerBird: 3.50,
  mortalityRateMaxPct: 4.0
};

export default function PoultryPnLManager({
  batches,
  currencySymbol,
  expenses = []
}: PoultryPnLManagerProps) {
  const [selectedBatchId, setSelectedBatchId] = useState<string>("all");
  const [expenseFilterTab, setExpenseFilterTab] = useState<"all" | "5211" | "5210" | "5215" | "5300" | "5216" | "5217" | "5100" | "other">("all");
  const [showBudgetCustomizer, setShowBudgetCustomizer] = useState(false);
  
  // Customizable baseline state
  const [budgetBaseline, setBudgetBaseline] = useState<PoultryBudgetBaseline>(DEFAULT_BUDGET_BASELINE);

  const filteredBatches = useMemo(() => {
    if (selectedBatchId === "all") return batches;
    return batches.filter(b => b.id === selectedBatchId);
  }, [batches, selectedBatchId]);

  const selectedBatch = useMemo(() => {
    if (selectedBatchId === "all") return null;
    return batches.find(b => b.id === selectedBatchId) || null;
  }, [batches, selectedBatchId]);

  // Extract all poultry-related expense items from Continuous Expenses & Cash book Disbursals
  const poultryExpenseItems = useMemo(() => {
    const items: Array<{
      txId: string;
      date: string;
      supplierId: string;
      supplierName: string;
      category: string;
      description: string;
      quantity: number;
      unitPrice: number;
      amount: number;
      coaCode: string;
      matchedBatchId?: string;
      matchedBatchName?: string;
    }> = [];

    expenses.forEach(tx => {
      (tx.rows || []).forEach(r => {
        const cat = (r.category || "").toLowerCase();
        const desc = (r.description || "").toLowerCase();
        const sup = (tx.supplierName || "").toLowerCase();
        const coa = r.coaCode || "";

        const isPoultryCoa = ["5210", "5211", "5212", "5213", "5214", "5215", "5216", "5217", "5300", "5901"].includes(coa);
        const isExplicitPoultryAllocation = r.allocationType === "poultry_batch" || Boolean(r.poultryBatchId);
        const hasPoultryKeywords = 
          cat.includes("poultry") || cat.includes("chick") || cat.includes("broiler") || 
          cat.includes("layer") || cat.includes("pullet") || cat.includes("flock") || 
          cat.includes("bird") || cat.includes("egg") || cat.includes("feed") || cat.includes("saw dust") ||
          cat.includes("charcoal") || cat.includes("fireblock") || cat.includes("gumboro") || cat.includes("newcastle") ||
          desc.includes("poultry") || desc.includes("chick") || desc.includes("broiler") || 
          desc.includes("layer") || desc.includes("pullet") || desc.includes("flock") || 
          desc.includes("bird") || desc.includes("mash") || desc.includes("crumble") || desc.includes("saw dust") ||
          desc.includes("sawdust") || desc.includes("charcoal") || desc.includes("brooding") || desc.includes("vaccine") ||
          sup.includes("hatchery") || sup.includes("poultry") || sup.includes("chick") || sup.includes("novatek") || sup.includes("tiger animal feeds");

        if (isPoultryCoa || isExplicitPoultryAllocation || hasPoultryKeywords) {
          // Check if this item is linked to a specific batch
          let matchedId: string | undefined = r.poultryBatchId;
          let matchedName: string | undefined = r.poultryBatchName;

          if (!matchedId) {
            batches.forEach(b => {
              if (desc.includes(b.id.toLowerCase()) || desc.includes(b.batchName.toLowerCase())) {
                matchedId = b.id;
                matchedName = b.batchName;
              }
            });
          }

          // Determine accurate specialized COA if missing or generic
          let finalCoa = coa;
          if (!finalCoa || finalCoa === "5200" || finalCoa === "5000") {
            if (cat.includes("chick") || desc.includes("chick")) finalCoa = "5211";
            else if (cat.includes("feed") || desc.includes("feed") || desc.includes("crumble") || desc.includes("mash")) finalCoa = "5210";
            else if (cat.includes("saw dust") || cat.includes("sawdust") || desc.includes("saw dust") || desc.includes("bedding")) finalCoa = "5216";
            else if (cat.includes("charcoal") || cat.includes("fireblock") || desc.includes("charcoal") || desc.includes("brooding")) finalCoa = "5217";
            else if (cat.includes("drug") || desc.includes("drug") || desc.includes("antibiotic")) finalCoa = "5215";
            else if (cat.includes("vaccin") || desc.includes("vaccin") || cat.includes("vet")) finalCoa = "5300";
            else if (cat.includes("labour") || desc.includes("poultry labour")) finalCoa = "5100";
            else finalCoa = "5214";
          }

          items.push({
            txId: tx.id,
            date: tx.date,
            supplierId: tx.supplierId,
            supplierName: tx.supplierName || "Standard Vendor / Farm Cashier",
            category: r.category || "Poultry Direct Expense",
            description: r.description || "Poultry direct input cost",
            quantity: r.quantity || 1,
            unitPrice: r.unitPrice || r.amount,
            amount: Number(r.amount) || 0,
            coaCode: finalCoa,
            matchedBatchId: matchedId,
            matchedBatchName: matchedName
          });
        }
      });
    });

    return items;
  }, [expenses, batches]);

  // Combined P&L calculations factoring actual continuous expenses & cash book disbursals
  const pnlSummary = useMemo(() => {
    let birdSalesRevenue = 0;
    let eggSalesRevenue = 0;
    let totalHeadcount = 0;
    let totalSoldBirds = 0;
    let totalFeedKg = 0;
    let internalMortalityLoss = 0;

    filteredBatches.forEach(b => {
      (b.salesLogs || []).forEach(s => {
        birdSalesRevenue += s.amount || 0;
        totalSoldBirds += s.quantity || 0;
      });

      (b.eggSales || []).forEach(e => {
        eggSalesRevenue += e.totalRevenue || 0;
      });

      totalHeadcount += b.initialHeadcount || 1;
      internalMortalityLoss += b.cumulativeMortalityLoss || 0;

      (b.feedLogs || []).forEach(f => {
        totalFeedKg += f.quantityKg || 0;
      });
    });

    // Compute actual direct costs from Continuous Expenses by COA
    let actualChicksCost = 0;     // 5211
    let actualFeedCost = 0;       // 5210
    let actualDrugsCost = 0;      // 5215
    let actualVaccinesCost = 0;   // 5300
    let actualBeddingCost = 0;    // 5216 (Saw dust)
    let actualHeatingCost = 0;    // 5217 (Charcoal/Fireblocks)
    let actualLabourCost = 0;     // 5100 (Direct Poultry Labour)
    let actualOtherCost = 0;      // 5214
    let actualMortalityCost = 0;  // 5901

    // Filter relevant expense items
    const relevantExpenses = poultryExpenseItems.filter(item => {
      if (selectedBatchId === "all") return true;
      if (item.matchedBatchId === selectedBatchId) return true;
      // If item is not tagged with a specific batch, check if single batch or matching breed/source
      if (!item.matchedBatchId) {
        if (batches.length <= 1) return true;
        if (selectedBatch) {
          const desc = item.description.toLowerCase();
          if (desc.includes(selectedBatch.breed.toLowerCase()) || desc.includes(selectedBatch.source.toLowerCase())) {
            return true;
          }
        }
      }
      return false;
    });

    relevantExpenses.forEach(item => {
      const coa = item.coaCode;
      const cat = item.category.toLowerCase();
      const desc = item.description.toLowerCase();

      if (coa === "5211" || cat.includes("chick") || cat.includes("pullet") || desc.includes("chick acquisition") || desc.includes("day-old")) {
        actualChicksCost += item.amount;
      } else if (coa === "5210" || cat.includes("feed") || desc.includes("feed") || desc.includes("starter") || desc.includes("finisher") || desc.includes("grower") || desc.includes("mash")) {
        actualFeedCost += item.amount;
      } else if (coa === "5215" || cat.includes("drug") || desc.includes("drug") || desc.includes("antibiotic") || desc.includes("dewormer")) {
        actualDrugsCost += item.amount;
      } else if (coa === "5300" || cat.includes("vet") || cat.includes("med") || cat.includes("vaccin") || desc.includes("vaccin")) {
        actualVaccinesCost += item.amount;
      } else if (coa === "5216" || cat.includes("saw dust") || cat.includes("sawdust") || desc.includes("saw dust") || desc.includes("sawdust") || desc.includes("litter")) {
        actualBeddingCost += item.amount;
      } else if (coa === "5217" || cat.includes("charcoal") || cat.includes("fireblock") || desc.includes("charcoal") || desc.includes("fireblocks") || desc.includes("brooding heat")) {
        actualHeatingCost += item.amount;
      } else if (coa === "5100" || cat.includes("labour") || desc.includes("poultry labour") || desc.includes("flock management")) {
        actualLabourCost += item.amount;
      } else if (coa === "5901" || cat.includes("mortality")) {
        actualMortalityCost += item.amount;
      } else {
        actualOtherCost += item.amount;
      }
    });

    // Fallbacks from batch internal logs if no continuous expenses were recorded yet
    let fallbackChicks = 0;
    let fallbackFeed = 0;
    let fallbackHealth = 0;
    filteredBatches.forEach(b => {
      fallbackChicks += b.acquisitionCostTotal || 0;
      fallbackFeed += b.cumulativeFeedCost || 0;
      fallbackHealth += b.cumulativeHealthCost || 0;
    });

    const acquisitionCost = actualChicksCost > 0 ? actualChicksCost : fallbackChicks;
    const feedCost = actualFeedCost > 0 ? actualFeedCost : fallbackFeed;
    const drugsCost = actualDrugsCost;
    const vaccinesCost = actualVaccinesCost > 0 ? actualVaccinesCost : (drugsCost === 0 ? fallbackHealth : 0);
    const combinedHealthCost = drugsCost + vaccinesCost;
    const beddingCost = actualBeddingCost;
    const heatingCost = actualHeatingCost;
    const labourCost = actualLabourCost;
    const otherDirectCost = actualOtherCost;
    const mortalityLoss = actualMortalityCost > 0 ? actualMortalityCost : internalMortalityLoss;

    const totalRevenue = birdSalesRevenue + eggSalesRevenue;
    const totalExpenses = acquisitionCost + feedCost + combinedHealthCost + beddingCost + heatingCost + labourCost + otherDirectCost + mortalityLoss;
    const netProfit = totalRevenue - totalExpenses;
    const profitMarginPct = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

    // Unit costs per bird
    const count = totalHeadcount > 0 ? totalHeadcount : 1;
    const avgAcquisitionPerBird = acquisitionCost / count;
    const avgFeedPerBird = feedCost / count;
    const avgDrugsPerBird = drugsCost / count;
    const avgVaccinesPerBird = vaccinesCost / count;
    const avgHealthPerBird = combinedHealthCost / count;
    const avgBeddingPerBird = beddingCost / count;
    const avgHeatingPerBird = heatingCost / count;
    const avgLabourPerBird = labourCost / count;
    const avgOtherPerBird = otherDirectCost / count;
    const avgMortalityPerBird = mortalityLoss / count;
    const totalProductionCostPerBird = avgAcquisitionPerBird + avgFeedPerBird + avgHealthPerBird + avgBeddingPerBird + avgHeatingPerBird + avgLabourPerBird + avgOtherPerBird + avgMortalityPerBird;

    // Percent shares of total cost
    const feedSharePct = totalExpenses > 0 ? (feedCost / totalExpenses) * 100 : 0;
    const healthSharePct = totalExpenses > 0 ? (combinedHealthCost / totalExpenses) * 100 : 0;
    const chicksSharePct = totalExpenses > 0 ? (acquisitionCost / totalExpenses) * 100 : 0;
    const beddingSharePct = totalExpenses > 0 ? (beddingCost / totalExpenses) * 100 : 0;
    const heatingSharePct = totalExpenses > 0 ? (heatingCost / totalExpenses) * 100 : 0;
    const labourSharePct = totalExpenses > 0 ? (labourCost / totalExpenses) * 100 : 0;

    // Planned Budget Baseline Calculations & Variance Analysis
    const plannedChicksTotal = budgetBaseline.chicksCostPerBird * count;
    const plannedFeedTotal = budgetBaseline.feedCostPerBird * count;
    const plannedHealthTotal = budgetBaseline.healthCostPerBird * count;
    const plannedBeddingTotal = budgetBaseline.beddingCostPerBird * count;
    const plannedHeatingTotal = budgetBaseline.heatingCostPerBird * count;
    const plannedLabourTotal = budgetBaseline.labourCostPerBird * count;
    const plannedTotalProductionCost = (
      budgetBaseline.chicksCostPerBird + 
      budgetBaseline.feedCostPerBird + 
      budgetBaseline.healthCostPerBird + 
      budgetBaseline.beddingCostPerBird + 
      budgetBaseline.heatingCostPerBird + 
      budgetBaseline.labourCostPerBird
    ) * count;

    // Variances: Positive means OVER budget (unfavorable), Negative means UNDER budget (favorable)
    const computeVariance = (actual: number, planned: number) => {
      const diff = actual - planned;
      const pct = planned > 0 ? (diff / planned) * 100 : 0;
      let status: "favorable" | "target" | "caution" | "critical" = "target";
      if (pct < -5) status = "favorable";
      else if (pct <= 5) status = "target";
      else if (pct <= 15) status = "caution";
      else status = "critical";
      return { diff, pct, status };
    };

    const feedVariance = computeVariance(feedCost, plannedFeedTotal);
    const chicksVariance = computeVariance(acquisitionCost, plannedChicksTotal);
    const healthVariance = computeVariance(combinedHealthCost, plannedHealthTotal);
    const beddingVariance = computeVariance(beddingCost, plannedBeddingTotal);
    const heatingVariance = computeVariance(heatingCost, plannedHeatingTotal);
    const labourVariance = computeVariance(labourCost, plannedLabourTotal);
    const totalCostVariance = computeVariance(totalExpenses - mortalityLoss, plannedTotalProductionCost);

    return {
      birdSalesRevenue,
      eggSalesRevenue,
      totalRevenue,
      acquisitionCost,
      feedCost,
      drugsCost,
      vaccinesCost,
      combinedHealthCost,
      beddingCost,
      heatingCost,
      labourCost,
      otherDirectCost,
      mortalityLoss,
      totalExpenses,
      netProfit,
      profitMarginPct,
      totalHeadcount: count,
      totalSoldBirds,
      totalFeedKg,
      avgAcquisitionPerBird,
      avgFeedPerBird,
      avgDrugsPerBird,
      avgVaccinesPerBird,
      avgHealthPerBird,
      avgBeddingPerBird,
      avgHeatingPerBird,
      avgLabourPerBird,
      avgOtherPerBird,
      avgMortalityPerBird,
      totalProductionCostPerBird,
      chicksSharePct,
      feedSharePct,
      healthSharePct,
      beddingSharePct,
      heatingSharePct,
      labourSharePct,
      // Budget Baseline & Variances
      plannedChicksTotal,
      plannedFeedTotal,
      plannedHealthTotal,
      plannedBeddingTotal,
      plannedHeatingTotal,
      plannedLabourTotal,
      plannedTotalProductionCost,
      plannedCostPerBird: plannedTotalProductionCost / count,
      chicksVariance,
      feedVariance,
      healthVariance,
      beddingVariance,
      heatingVariance,
      labourVariance,
      totalCostVariance,
      isFromContinuousExpenses: poultryExpenseItems.length > 0,
      relevantExpensesCount: relevantExpenses.length
    };
  }, [filteredBatches, poultryExpenseItems, selectedBatchId, selectedBatch, batches, budgetBaseline]);

  // Filtered expense table list
  const displayExpenseList = useMemo(() => {
    return poultryExpenseItems.filter(item => {
      if (selectedBatchId !== "all") {
        if (item.matchedBatchId && item.matchedBatchId !== selectedBatchId) return false;
      }
      if (expenseFilterTab === "all") return true;
      if (expenseFilterTab === "5211") return item.coaCode === "5211" || item.category.toLowerCase().includes("chick");
      if (expenseFilterTab === "5210") return item.coaCode === "5210" || item.category.toLowerCase().includes("feed");
      if (expenseFilterTab === "5215") return item.coaCode === "5215" || item.category.toLowerCase().includes("drug");
      if (expenseFilterTab === "5300") return item.coaCode === "5300" || item.category.toLowerCase().includes("vaccin") || item.category.toLowerCase().includes("vet");
      if (expenseFilterTab === "5216") return item.coaCode === "5216" || item.category.toLowerCase().includes("saw dust") || item.category.toLowerCase().includes("sawdust");
      if (expenseFilterTab === "5217") return item.coaCode === "5217" || item.category.toLowerCase().includes("charcoal") || item.category.toLowerCase().includes("fireblock");
      if (expenseFilterTab === "5100") return item.coaCode === "5100" || item.category.toLowerCase().includes("labour");
      if (expenseFilterTab === "other") return !["5210", "5211", "5215", "5300", "5216", "5217", "5100"].includes(item.coaCode);
      return true;
    });
  }, [poultryExpenseItems, selectedBatchId, expenseFilterTab]);

  // Export Comprehensive P&L CSV
  const exportPnLCSV = () => {
    let csv = "Mabala Farm - Poultry Profit and Loss Center & Granular Cost Statement\n";
    csv += `Scope,${selectedBatchId === "all" ? "All Flocks Combined" : (selectedBatch?.batchName || selectedBatchId)}\n`;
    csv += `Data Source,Continuous Expenses & Cash book Disbursals Ledger Synced\n\n`;
    
    csv += "REVENUES (INCOME ACCOUNTS),COA Code,Amount (" + currencySymbol + ")\n";
    csv += `Live & Dressed Bird Sales Revenue,4200,${pnlSummary.birdSalesRevenue.toFixed(2)}\n`;
    csv += `Egg Collection & Trays Sales Revenue,4210,${pnlSummary.eggSalesRevenue.toFixed(2)}\n`;
    csv += `TOTAL REVENUE,,${pnlSummary.totalRevenue.toFixed(2)}\n\n`;

    csv += "DIRECT PRODUCTION COSTS (EXPENSE ACCOUNTS),COA Code,Actual (" + currencySymbol + "),Budget Baseline (" + currencySymbol + "),Variance (" + currencySymbol + "),Variance %\n";
    csv += `Day Old Chicks / Flock Acquisition,5211,${pnlSummary.acquisitionCost.toFixed(2)},${pnlSummary.plannedChicksTotal.toFixed(2)},${pnlSummary.chicksVariance.diff.toFixed(2)},${pnlSummary.chicksVariance.pct.toFixed(1)}%\n`;
    csv += `Poultry Feed & Crumbles Restock,5210,${pnlSummary.feedCost.toFixed(2)},${pnlSummary.plannedFeedTotal.toFixed(2)},${pnlSummary.feedVariance.diff.toFixed(2)},${pnlSummary.feedVariance.pct.toFixed(1)}%\n`;
    csv += `Poultry Drugs & Pharmaceuticals,5215,${pnlSummary.drugsCost.toFixed(2)},0.00,${pnlSummary.drugsCost.toFixed(2)},N/A\n`;
    csv += `Vaccines & Veterinary Biologicals,5300,${pnlSummary.vaccinesCost.toFixed(2)},${pnlSummary.plannedHealthTotal.toFixed(2)},${pnlSummary.healthVariance.diff.toFixed(2)},${pnlSummary.healthVariance.pct.toFixed(1)}%\n`;
    csv += `Saw dust & Bedding Litter,5216,${pnlSummary.beddingCost.toFixed(2)},${pnlSummary.plannedBeddingTotal.toFixed(2)},${pnlSummary.beddingVariance.diff.toFixed(2)},${pnlSummary.beddingVariance.pct.toFixed(1)}%\n`;
    csv += `Charcoal and Fireblocks (Brooding Heat),5217,${pnlSummary.heatingCost.toFixed(2)},${pnlSummary.plannedHeatingTotal.toFixed(2)},${pnlSummary.heatingVariance.diff.toFixed(2)},${pnlSummary.heatingVariance.pct.toFixed(1)}%\n`;
    csv += `Direct Poultry Labour Overheads,5100,${pnlSummary.labourCost.toFixed(2)},${pnlSummary.plannedLabourTotal.toFixed(2)},${pnlSummary.labourVariance.diff.toFixed(2)},${pnlSummary.labourVariance.pct.toFixed(1)}%\n`;
    if (pnlSummary.otherDirectCost > 0) {
      csv += `Other Direct Poultry Supplies,5214,${pnlSummary.otherDirectCost.toFixed(2)},0.00,${pnlSummary.otherDirectCost.toFixed(2)},N/A\n`;
    }
    csv += `Mortality Losses (Non-Cash Write-off),5901,${pnlSummary.mortalityLoss.toFixed(2)},0.00,${pnlSummary.mortalityLoss.toFixed(2)},N/A\n`;
    csv += `TOTAL PRODUCTION COSTS,,${pnlSummary.totalExpenses.toFixed(2)},${pnlSummary.plannedTotalProductionCost.toFixed(2)},${pnlSummary.totalCostVariance.diff.toFixed(2)},${pnlSummary.totalCostVariance.pct.toFixed(1)}%\n\n`;

    csv += `NET PROFIT / LOSS,,${pnlSummary.netProfit.toFixed(2)}\n`;
    csv += `NET PROFIT MARGIN %,,"${pnlSummary.profitMarginPct.toFixed(1)}%"\n\n`;

    csv += "UNIT PRODUCTION COST ANALYSIS (COST PER BIRD),Actual (" + currencySymbol + "),Planned Baseline (" + currencySymbol + ")\n";
    csv += `Day Old Chick Acquisition / Bird,${pnlSummary.avgAcquisitionPerBird.toFixed(2)},${budgetBaseline.chicksCostPerBird.toFixed(2)}\n`;
    csv += `Feed Cost / Bird,${pnlSummary.avgFeedPerBird.toFixed(2)},${budgetBaseline.feedCostPerBird.toFixed(2)}\n`;
    csv += `Drugs & Vaccines / Bird,${pnlSummary.avgHealthPerBird.toFixed(2)},${budgetBaseline.healthCostPerBird.toFixed(2)}\n`;
    csv += `Bedding / Saw dust / Bird,${pnlSummary.avgBeddingPerBird.toFixed(2)},${budgetBaseline.beddingCostPerBird.toFixed(2)}\n`;
    csv += `Brooding Charcoal & Heat / Bird,${pnlSummary.avgHeatingPerBird.toFixed(2)},${budgetBaseline.heatingCostPerBird.toFixed(2)}\n`;
    csv += `Direct Labour Overhead / Bird,${pnlSummary.avgLabourPerBird.toFixed(2)},${budgetBaseline.labourCostPerBird.toFixed(2)}\n`;
    csv += `Mortality Loss / Bird,${pnlSummary.avgMortalityPerBird.toFixed(2)},0.00\n`;
    csv += `TOTAL COST TO RAISE PER BIRD,${pnlSummary.totalProductionCostPerBird.toFixed(2)},${pnlSummary.plannedCostPerBird.toFixed(2)}\n\n`;

    csv += "ITEMIZED CONTINUOUS EXPENSES & CASH BOOK DISBURSALS\n";
    csv += "Date,Supplier / Payee,COA Code,Category,Description,Amount (" + currencySymbol + ")\n";
    displayExpenseList.forEach(item => {
      csv += `"${item.date}","${item.supplierName}","${item.coaCode}","${item.category}","${item.description.replace(/"/g, '""')}","${item.amount.toFixed(2)}"\n`;
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Poultry_PnL_Granular_Cost_Center_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
  };

  return (
    <div className="space-y-6" id="poultry-pnl-manager-root">
      {/* Top Banner */}
      <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
            <PieChart size={16} />
            <span>Poultry Profit & Loss Center & Cost Variance Engine</span>
          </div>
          <h2 className="text-2xl font-black mt-1">Granular Production P&L & Variance Center</h2>
          <p className="text-slate-400 text-xs mt-1 max-w-2xl leading-relaxed">
            Real-time double-entry cost center capturing Feed (COA 5210), Day-Old Chicks (COA 5211), Drugs (COA 5215), Vaccines (COA 5300), Saw dust (COA 5216), Charcoal/Fireblocks (COA 5217), and Direct Labour (COA 5100).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={selectedBatchId}
            onChange={(e) => setSelectedBatchId(e.target.value)}
            className="px-4 py-2 bg-slate-800 border border-slate-700 text-white rounded-xl text-xs font-bold outline-none cursor-pointer hover:border-slate-600 transition-colors"
          >
            <option value="all">All Flocks Combined ({batches.length} Batches)</option>
            {batches.map(b => (
              <option key={b.id} value={b.id}>{b.batchName} ({b.batchId})</option>
            ))}
          </select>

          <button
            onClick={() => setShowBudgetCustomizer(!showBudgetCustomizer)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              showBudgetCustomizer ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700"
            }`}
          >
            <SlidersHorizontal size={14} />
            <span>{showBudgetCustomizer ? "Hide Baseline" : "Budget Baseline"}</span>
          </button>

          <button
            onClick={exportPnLCSV}
            className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            <Download size={14} /> Export Granular Report
          </button>
        </div>
      </div>

      {/* Budget Baseline Customizer Drawer */}
      {showBudgetCustomizer && (
        <div className="bg-amber-50/90 border border-amber-200 p-5 rounded-3xl space-y-4 shadow-sm">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-amber-700" />
              <h4 className="text-xs font-black uppercase tracking-wider text-amber-950">Planned Budget Baseline Configuration (Cost / Bird Targets)</h4>
            </div>
            <button
              onClick={() => setBudgetBaseline(DEFAULT_BUDGET_BASELINE)}
              className="text-[11px] font-bold text-amber-800 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset to Industry Benchmark</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 text-xs">
            <div>
              <label className="text-[10px] font-bold text-slate-600 block mb-1">Chick Acquisition (5211)</label>
              <div className="flex items-center gap-1 bg-white border border-amber-300 rounded-xl px-2.5 py-1.5">
                <span className="text-slate-400 font-bold">{currencySymbol}</span>
                <input
                  type="number"
                  step="0.5"
                  value={budgetBaseline.chicksCostPerBird}
                  onChange={(e) => setBudgetBaseline({ ...budgetBaseline, chicksCostPerBird: Number(e.target.value) })}
                  className="w-full text-xs font-bold font-mono outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-600 block mb-1">Feed Target (5210)</label>
              <div className="flex items-center gap-1 bg-white border border-amber-300 rounded-xl px-2.5 py-1.5">
                <span className="text-slate-400 font-bold">{currencySymbol}</span>
                <input
                  type="number"
                  step="0.5"
                  value={budgetBaseline.feedCostPerBird}
                  onChange={(e) => setBudgetBaseline({ ...budgetBaseline, feedCostPerBird: Number(e.target.value) })}
                  className="w-full text-xs font-bold font-mono outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-600 block mb-1">Vaccines & Meds (5300)</label>
              <div className="flex items-center gap-1 bg-white border border-amber-300 rounded-xl px-2.5 py-1.5">
                <span className="text-slate-400 font-bold">{currencySymbol}</span>
                <input
                  type="number"
                  step="0.5"
                  value={budgetBaseline.healthCostPerBird}
                  onChange={(e) => setBudgetBaseline({ ...budgetBaseline, healthCostPerBird: Number(e.target.value) })}
                  className="w-full text-xs font-bold font-mono outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-600 block mb-1">Saw dust Bedding (5216)</label>
              <div className="flex items-center gap-1 bg-white border border-amber-300 rounded-xl px-2.5 py-1.5">
                <span className="text-slate-400 font-bold">{currencySymbol}</span>
                <input
                  type="number"
                  step="0.5"
                  value={budgetBaseline.beddingCostPerBird}
                  onChange={(e) => setBudgetBaseline({ ...budgetBaseline, beddingCostPerBird: Number(e.target.value) })}
                  className="w-full text-xs font-bold font-mono outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-600 block mb-1">Brooding Charcoal (5217)</label>
              <div className="flex items-center gap-1 bg-white border border-amber-300 rounded-xl px-2.5 py-1.5">
                <span className="text-slate-400 font-bold">{currencySymbol}</span>
                <input
                  type="number"
                  step="0.5"
                  value={budgetBaseline.heatingCostPerBird}
                  onChange={(e) => setBudgetBaseline({ ...budgetBaseline, heatingCostPerBird: Number(e.target.value) })}
                  className="w-full text-xs font-bold font-mono outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-600 block mb-1">Direct Labour (5100)</label>
              <div className="flex items-center gap-1 bg-white border border-amber-300 rounded-xl px-2.5 py-1.5">
                <span className="text-slate-400 font-bold">{currencySymbol}</span>
                <input
                  type="number"
                  step="0.5"
                  value={budgetBaseline.labourCostPerBird}
                  onChange={(e) => setBudgetBaseline({ ...budgetBaseline, labourCostPerBird: Number(e.target.value) })}
                  className="w-full text-xs font-bold font-mono outline-none"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sync Status Badge */}
      <div className="bg-emerald-50 border border-emerald-200/80 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold shrink-0">
            <CheckCircle2 size={18} />
          </div>
          <div>
            <strong className="text-emerald-950 font-bold block">
              Continuous Expenses & Cash Book Disbursals Synced (Direct IAS Cost Center)
            </strong>
            <span className="text-emerald-700 text-[11px]">
              Costs factor real purchases entered from Poultry Restock & Continuous Expenses across Day-Old Chicks (5211), Feed (5210), Drugs (5215), Vaccines (5300), Bedding (5216), Brooding Fuel (5217), and Labour (5100).
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="bg-emerald-200/70 text-emerald-900 font-black px-3 py-1 rounded-full text-[10px]">
            {poultryExpenseItems.length} Ledger Items Linked
          </span>
        </div>
      </div>

      {/* Net Profit Banner */}
      <div className={`p-6 rounded-3xl border shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ${
        pnlSummary.netProfit >= 0 ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-950" : "bg-red-500/10 border-red-500/30 text-red-950"
      }`}>
        <div>
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">Net Operational Surplus / Loss (Poultry Enterprise)</span>
          <div className="flex items-baseline gap-3 mt-1">
            <strong className={`text-3xl font-black ${pnlSummary.netProfit >= 0 ? "text-emerald-700" : "text-red-700"}`}>
              {pnlSummary.netProfit >= 0 ? "+" : ""}
              {currencySymbol}{pnlSummary.netProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </strong>
            <span className={`text-xs font-black px-2.5 py-1 rounded-full ${pnlSummary.netProfit >= 0 ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"}`}>
              {pnlSummary.profitMarginPct.toFixed(1)}% Net Margin
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 text-xs font-bold text-slate-700 border-l border-slate-200/60 pl-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Revenue</span>
            <span className="text-emerald-600 font-black">{currencySymbol}{pnlSummary.totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Direct Outlays</span>
            <span className="text-slate-900 font-black">{currencySymbol}{pnlSummary.totalExpenses.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
        </div>
      </div>

      {/* ANIMATED COST VARIANCE INDICATORS & BUDGET BENCHMARK CARDS */}
      <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-slate-100 pb-3">
          <div>
            <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
              <Zap size={16} className="text-amber-500" />
              Live Cost Variance Indicators vs. Planned Budget Baseline
            </h3>
            <p className="text-[11px] text-slate-400 font-medium">
              Dynamic indicators highlight favorable cost savings or alert to significant expenditure budget deviations in real time
            </p>
          </div>
          <div className="flex items-center gap-1.5 text-[10px] font-bold">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Under Budget
            </span>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500" /> Caution (&lt;15%)
            </span>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 animate-pulse">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500" /> Overrun Alert
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
          {/* Feed Cost Variance Card */}
          <div className={`p-4 rounded-2xl border transition-all duration-300 space-y-2 ${
            pnlSummary.feedVariance.status === "critical" ? "bg-rose-50/90 border-rose-300 ring-2 ring-rose-400/40" :
            pnlSummary.feedVariance.status === "caution" ? "bg-amber-50/90 border-amber-300" :
            "bg-emerald-50/70 border-emerald-200"
          }`}>
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-black uppercase text-slate-600">Feed Outlay (5210)</span>
              <span className={`text-[9.5px] font-black px-1.5 py-0.5 rounded-md flex items-center gap-0.5 ${
                pnlSummary.feedVariance.status === "critical" ? "bg-rose-600 text-white animate-pulse" :
                pnlSummary.feedVariance.status === "caution" ? "bg-amber-600 text-white" :
                "bg-emerald-600 text-white"
              }`}>
                {pnlSummary.feedVariance.pct > 0 ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}
                {Math.abs(pnlSummary.feedVariance.pct).toFixed(1)}% {pnlSummary.feedVariance.pct > 0 ? "Over" : "Under"}
              </span>
            </div>
            <div>
              <strong className="text-base font-black text-slate-900 block font-mono">
                {currencySymbol}{pnlSummary.feedCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </strong>
              <span className="text-[10px] text-slate-500 font-medium">Budget: {currencySymbol}{pnlSummary.plannedFeedTotal.toFixed(2)}</span>
            </div>
            {/* Progress / Utilization Meter */}
            <div className="w-full bg-slate-200/80 rounded-full h-1.5 overflow-hidden">
              <div 
                className={`h-full transition-all duration-500 ${
                  pnlSummary.feedVariance.status === "critical" ? "bg-rose-500" :
                  pnlSummary.feedVariance.status === "caution" ? "bg-amber-500" :
                  "bg-emerald-500"
                }`}
                style={{ width: `${Math.min(100, (pnlSummary.feedCost / (pnlSummary.plannedFeedTotal || 1)) * 100)}%` }}
              />
            </div>
            <div className="text-[9.5px] text-slate-500 flex justify-between font-mono">
              <span>{currencySymbol}{pnlSummary.avgFeedPerBird.toFixed(2)}/bird</span>
              <span className="text-slate-400">Plan: {budgetBaseline.feedCostPerBird.toFixed(2)}</span>
            </div>
          </div>

          {/* Chicks Acquisition Variance Card */}
          <div className={`p-4 rounded-2xl border transition-all duration-300 space-y-2 ${
            pnlSummary.chicksVariance.status === "critical" ? "bg-rose-50/90 border-rose-300 ring-2 ring-rose-400/40" :
            pnlSummary.chicksVariance.status === "caution" ? "bg-amber-50/90 border-amber-300" :
            "bg-emerald-50/70 border-emerald-200"
          }`}>
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-black uppercase text-slate-600">Chicks (5211)</span>
              <span className={`text-[9.5px] font-black px-1.5 py-0.5 rounded-md flex items-center gap-0.5 ${
                pnlSummary.chicksVariance.status === "critical" ? "bg-rose-600 text-white animate-pulse" :
                pnlSummary.chicksVariance.status === "caution" ? "bg-amber-600 text-white" :
                "bg-emerald-600 text-white"
              }`}>
                {pnlSummary.chicksVariance.pct > 0 ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}
                {Math.abs(pnlSummary.chicksVariance.pct).toFixed(1)}% {pnlSummary.chicksVariance.pct > 0 ? "Over" : "Under"}
              </span>
            </div>
            <div>
              <strong className="text-base font-black text-slate-900 block font-mono">
                {currencySymbol}{pnlSummary.acquisitionCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </strong>
              <span className="text-[10px] text-slate-500 font-medium">Budget: {currencySymbol}{pnlSummary.plannedChicksTotal.toFixed(2)}</span>
            </div>
            <div className="w-full bg-slate-200/80 rounded-full h-1.5 overflow-hidden">
              <div 
                className={`h-full transition-all duration-500 ${
                  pnlSummary.chicksVariance.status === "critical" ? "bg-rose-500" :
                  pnlSummary.chicksVariance.status === "caution" ? "bg-amber-500" :
                  "bg-emerald-500"
                }`}
                style={{ width: `${Math.min(100, (pnlSummary.acquisitionCost / (pnlSummary.plannedChicksTotal || 1)) * 100)}%` }}
              />
            </div>
            <div className="text-[9.5px] text-slate-500 flex justify-between font-mono">
              <span>{currencySymbol}{pnlSummary.avgAcquisitionPerBird.toFixed(2)}/chick</span>
              <span className="text-slate-400">Plan: {budgetBaseline.chicksCostPerBird.toFixed(2)}</span>
            </div>
          </div>

          {/* Health (Drugs 5215 & Vaccines 5300) Variance Card */}
          <div className={`p-4 rounded-2xl border transition-all duration-300 space-y-2 ${
            pnlSummary.healthVariance.status === "critical" ? "bg-rose-50/90 border-rose-300 ring-2 ring-rose-400/40" :
            pnlSummary.healthVariance.status === "caution" ? "bg-amber-50/90 border-amber-300" :
            "bg-emerald-50/70 border-emerald-200"
          }`}>
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-black uppercase text-slate-600">Health (5215/5300)</span>
              <span className={`text-[9.5px] font-black px-1.5 py-0.5 rounded-md flex items-center gap-0.5 ${
                pnlSummary.healthVariance.status === "critical" ? "bg-rose-600 text-white animate-pulse" :
                pnlSummary.healthVariance.status === "caution" ? "bg-amber-600 text-white" :
                "bg-emerald-600 text-white"
              }`}>
                {pnlSummary.healthVariance.pct > 0 ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}
                {Math.abs(pnlSummary.healthVariance.pct).toFixed(1)}% {pnlSummary.healthVariance.pct > 0 ? "Over" : "Under"}
              </span>
            </div>
            <div>
              <strong className="text-base font-black text-slate-900 block font-mono">
                {currencySymbol}{pnlSummary.combinedHealthCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </strong>
              <span className="text-[10px] text-slate-500 font-medium">Budget: {currencySymbol}{pnlSummary.plannedHealthTotal.toFixed(2)}</span>
            </div>
            <div className="w-full bg-slate-200/80 rounded-full h-1.5 overflow-hidden">
              <div 
                className={`h-full transition-all duration-500 ${
                  pnlSummary.healthVariance.status === "critical" ? "bg-rose-500" :
                  pnlSummary.healthVariance.status === "caution" ? "bg-amber-500" :
                  "bg-emerald-500"
                }`}
                style={{ width: `${Math.min(100, (pnlSummary.combinedHealthCost / (pnlSummary.plannedHealthTotal || 1)) * 100)}%` }}
              />
            </div>
            <div className="text-[9.5px] text-slate-500 flex justify-between font-mono">
              <span>{currencySymbol}{pnlSummary.avgHealthPerBird.toFixed(2)}/bird</span>
              <span className="text-slate-400">Plan: {budgetBaseline.healthCostPerBird.toFixed(2)}</span>
            </div>
          </div>

          {/* Bedding Saw dust (5216) Variance Card */}
          <div className={`p-4 rounded-2xl border transition-all duration-300 space-y-2 ${
            pnlSummary.beddingVariance.status === "critical" ? "bg-rose-50/90 border-rose-300" :
            pnlSummary.beddingVariance.status === "caution" ? "bg-amber-50/90 border-amber-300" :
            "bg-slate-50 border-slate-200"
          }`}>
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-black uppercase text-slate-600">Saw Dust (5216)</span>
              <span className={`text-[9.5px] font-black px-1.5 py-0.5 rounded-md flex items-center gap-0.5 ${
                pnlSummary.beddingVariance.status === "critical" ? "bg-rose-600 text-white" :
                pnlSummary.beddingVariance.status === "caution" ? "bg-amber-600 text-white" :
                "bg-slate-700 text-white"
              }`}>
                {pnlSummary.beddingVariance.pct > 0 ? "+" : ""}{pnlSummary.beddingVariance.pct.toFixed(0)}%
              </span>
            </div>
            <div>
              <strong className="text-base font-black text-slate-900 block font-mono">
                {currencySymbol}{pnlSummary.beddingCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </strong>
              <span className="text-[10px] text-slate-500 font-medium">Budget: {currencySymbol}{pnlSummary.plannedBeddingTotal.toFixed(2)}</span>
            </div>
            <div className="w-full bg-slate-200/80 rounded-full h-1.5 overflow-hidden">
              <div 
                className="h-full bg-slate-600 transition-all duration-500"
                style={{ width: `${Math.min(100, (pnlSummary.beddingCost / (pnlSummary.plannedBeddingTotal || 1)) * 100)}%` }}
              />
            </div>
            <div className="text-[9.5px] text-slate-500 flex justify-between font-mono">
              <span>{currencySymbol}{pnlSummary.avgBeddingPerBird.toFixed(2)}/bird</span>
              <span className="text-slate-400">Plan: {budgetBaseline.beddingCostPerBird.toFixed(2)}</span>
            </div>
          </div>

          {/* Charcoal & Heating (5217) Variance Card */}
          <div className={`p-4 rounded-2xl border transition-all duration-300 space-y-2 ${
            pnlSummary.heatingVariance.status === "critical" ? "bg-rose-50/90 border-rose-300" :
            pnlSummary.heatingVariance.status === "caution" ? "bg-amber-50/90 border-amber-300" :
            "bg-slate-50 border-slate-200"
          }`}>
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-black uppercase text-slate-600">Brooding (5217)</span>
              <span className={`text-[9.5px] font-black px-1.5 py-0.5 rounded-md flex items-center gap-0.5 ${
                pnlSummary.heatingVariance.status === "critical" ? "bg-rose-600 text-white" :
                pnlSummary.heatingVariance.status === "caution" ? "bg-amber-600 text-white" :
                "bg-slate-700 text-white"
              }`}>
                {pnlSummary.heatingVariance.pct > 0 ? "+" : ""}{pnlSummary.heatingVariance.pct.toFixed(0)}%
              </span>
            </div>
            <div>
              <strong className="text-base font-black text-slate-900 block font-mono">
                {currencySymbol}{pnlSummary.heatingCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </strong>
              <span className="text-[10px] text-slate-500 font-medium">Budget: {currencySymbol}{pnlSummary.plannedHeatingTotal.toFixed(2)}</span>
            </div>
            <div className="w-full bg-slate-200/80 rounded-full h-1.5 overflow-hidden">
              <div 
                className="h-full bg-slate-600 transition-all duration-500"
                style={{ width: `${Math.min(100, (pnlSummary.heatingCost / (pnlSummary.plannedHeatingTotal || 1)) * 100)}%` }}
              />
            </div>
            <div className="text-[9.5px] text-slate-500 flex justify-between font-mono">
              <span>{currencySymbol}{pnlSummary.avgHeatingPerBird.toFixed(2)}/bird</span>
              <span className="text-slate-400">Plan: {budgetBaseline.heatingCostPerBird.toFixed(2)}</span>
            </div>
          </div>

          {/* Direct Labour (5100) Variance Card */}
          <div className={`p-4 rounded-2xl border transition-all duration-300 space-y-2 ${
            pnlSummary.labourVariance.status === "critical" ? "bg-rose-50/90 border-rose-300" :
            pnlSummary.labourVariance.status === "caution" ? "bg-amber-50/90 border-amber-300" :
            "bg-slate-50 border-slate-200"
          }`}>
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-black uppercase text-slate-600">Labour (5100)</span>
              <span className={`text-[9.5px] font-black px-1.5 py-0.5 rounded-md flex items-center gap-0.5 ${
                pnlSummary.labourVariance.status === "critical" ? "bg-rose-600 text-white" :
                pnlSummary.labourVariance.status === "caution" ? "bg-amber-600 text-white" :
                "bg-slate-700 text-white"
              }`}>
                {pnlSummary.labourVariance.pct > 0 ? "+" : ""}{pnlSummary.labourVariance.pct.toFixed(0)}%
              </span>
            </div>
            <div>
              <strong className="text-base font-black text-slate-900 block font-mono">
                {currencySymbol}{pnlSummary.labourCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </strong>
              <span className="text-[10px] text-slate-500 font-medium">Budget: {currencySymbol}{pnlSummary.plannedLabourTotal.toFixed(2)}</span>
            </div>
            <div className="w-full bg-slate-200/80 rounded-full h-1.5 overflow-hidden">
              <div 
                className="h-full bg-slate-600 transition-all duration-500"
                style={{ width: `${Math.min(100, (pnlSummary.labourCost / (pnlSummary.plannedLabourTotal || 1)) * 100)}%` }}
              />
            </div>
            <div className="text-[9.5px] text-slate-500 flex justify-between font-mono">
              <span>{currencySymbol}{pnlSummary.avgLabourPerBird.toFixed(2)}/bird</span>
              <span className="text-slate-400">Plan: {budgetBaseline.labourCostPerBird.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Unit Production Cost Breakdown Per Bird */}
      <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-xs space-y-4">
        <div>
          <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
            <Feather size={16} className="text-amber-500" />
            Unit Production Cost Analysis (Cost Per Bird Breakdown)
          </h3>
          <p className="text-[11px] text-slate-400 font-medium">Detailed breakdown of actual input costs required to raise each bird to market maturity</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-7 gap-3">
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
            <span className="text-[9px] font-black uppercase text-slate-400 block">Chick (5211)</span>
            <strong className="text-base font-black text-slate-900 block font-mono">{currencySymbol}{pnlSummary.avgAcquisitionPerBird.toFixed(2)}</strong>
            <span className="text-[9.5px] text-slate-500 block">{pnlSummary.chicksSharePct.toFixed(0)}% of total</span>
          </div>

          <div className="p-3.5 bg-amber-50/80 rounded-2xl border border-amber-200/60 space-y-1">
            <span className="text-[9px] font-black uppercase text-amber-700 block">Feed (5210)</span>
            <strong className="text-base font-black text-amber-900 block font-mono">{currencySymbol}{pnlSummary.avgFeedPerBird.toFixed(2)}</strong>
            <span className="text-[9.5px] text-amber-700 block font-bold">{pnlSummary.feedSharePct.toFixed(0)}% of total</span>
          </div>

          <div className="p-3.5 bg-rose-50/80 rounded-2xl border border-rose-200/60 space-y-1">
            <span className="text-[9px] font-black uppercase text-rose-700 block">Drugs & Med (5215/5300)</span>
            <strong className="text-base font-black text-rose-900 block font-mono">{currencySymbol}{pnlSummary.avgHealthPerBird.toFixed(2)}</strong>
            <span className="text-[9.5px] text-rose-700 block font-bold">{pnlSummary.healthSharePct.toFixed(0)}% of total</span>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
            <span className="text-[9px] font-black uppercase text-slate-400 block">Saw dust (5216)</span>
            <strong className="text-base font-black text-slate-900 block font-mono">{currencySymbol}{pnlSummary.avgBeddingPerBird.toFixed(2)}</strong>
            <span className="text-[9.5px] text-slate-500 block">{pnlSummary.beddingSharePct.toFixed(0)}% of total</span>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
            <span className="text-[9px] font-black uppercase text-slate-400 block">Charcoal (5217)</span>
            <strong className="text-base font-black text-slate-900 block font-mono">{currencySymbol}{pnlSummary.avgHeatingPerBird.toFixed(2)}</strong>
            <span className="text-[9.5px] text-slate-500 block">{pnlSummary.heatingSharePct.toFixed(0)}% of total</span>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
            <span className="text-[9px] font-black uppercase text-slate-400 block">Labour (5100)</span>
            <strong className="text-base font-black text-slate-900 block font-mono">{currencySymbol}{pnlSummary.avgLabourPerBird.toFixed(2)}</strong>
            <span className="text-[9.5px] text-slate-500 block">{pnlSummary.labourSharePct.toFixed(0)}% of total</span>
          </div>

          <div className="p-3.5 bg-slate-900 text-white rounded-2xl space-y-1 shadow-md">
            <span className="text-[9px] font-black uppercase text-emerald-400 block">Total / Bird</span>
            <strong className="text-lg font-black text-emerald-400 block font-mono">{currencySymbol}{pnlSummary.totalProductionCostPerBird.toFixed(2)}</strong>
            <span className="text-[9.5px] text-slate-300 block font-bold">Break-Even Price</span>
          </div>
        </div>
      </div>

      {/* STRUCTURED GRANULAR FINANCIAL INCOME STATEMENT */}
      <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-xs space-y-4">
        <div className="flex justify-between items-center border-b border-slate-100 pb-3">
          <div>
            <h3 className="font-black text-slate-900 text-sm">Granular Profit & Loss Statement (Chart of Accounts Breakdown)</h3>
            <p className="text-[11px] text-slate-400 font-medium">Double-entry Chart of Accounts ledger mapping with actual disbursals from the Continuous Expenses book</p>
          </div>
          <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-700 px-3 py-1 rounded-full">
            COA Double Entry Aligned
          </span>
        </div>

        <div className="space-y-4 text-xs">
          {/* Revenues Section */}
          <div className="border border-slate-100 rounded-2xl overflow-hidden">
            <div className="bg-slate-50 p-3 font-black text-slate-800 text-[10px] uppercase tracking-wider border-b border-slate-100 flex justify-between">
              <span>REVENUES (INCOME ACCOUNTS)</span>
              <span>COA CODE</span>
            </div>
            <div className="p-3 space-y-2 font-medium text-slate-700">
              <div className="flex justify-between items-center">
                <span>Live & Dressed Bird Sales Revenue</span>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-slate-400">4200</span>
                  <strong className="font-black text-slate-900">{currencySymbol}{pnlSummary.birdSalesRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <span>Egg Collection & Trays Sales Revenue</span>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-slate-400">4210</span>
                  <strong className="font-black text-slate-900">{currencySymbol}{pnlSummary.eggSalesRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong>
                </div>
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-slate-100 font-black text-emerald-700">
                <span>TOTAL REVENUE</span>
                <span className="text-sm">{currencySymbol}{pnlSummary.totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

          {/* Granular Production Expenses Section */}
          <div className="border border-slate-100 rounded-2xl overflow-hidden">
            <div className="bg-slate-50 p-3 font-black text-slate-800 text-[10px] uppercase tracking-wider border-b border-slate-100 flex justify-between">
              <span>DIRECT PRODUCTION COSTS (EXPENSE ACCOUNTS - ACTUAL DISBURSALS)</span>
              <div className="flex items-center gap-6">
                <span>COA</span>
                <span>ACTUAL AMOUNT</span>
              </div>
            </div>
            <div className="p-3 space-y-2.5 font-medium text-slate-700 divide-y divide-slate-100/70">
              {/* Day Old Chicks */}
              <div className="flex justify-between items-center pt-1.5">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900">Day Old Chicks / Flock Acquisition</span>
                  <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-bold">Hatchery Stock</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-slate-400">5211</span>
                  <span className="font-black text-slate-900">{currencySymbol}{pnlSummary.acquisitionCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Feed */}
              <div className="flex justify-between items-center pt-2 text-amber-950">
                <div className="flex items-center gap-2">
                  <span className="font-bold">Poultry Feed & Crumbles Restock Cost</span>
                  <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-bold">Feed Store Restock</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-amber-600">5210</span>
                  <span className="font-black text-amber-900">{currencySymbol}{pnlSummary.feedCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Drugs (5215) */}
              <div className="flex justify-between items-center pt-2 text-rose-950">
                <div className="flex items-center gap-2">
                  <span className="font-bold">Poultry Drugs & Pharmaceuticals</span>
                  <span className="text-[10px] bg-rose-100 text-rose-800 px-1.5 py-0.5 rounded font-bold">Antibiotics & Treatments</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-rose-600">5215</span>
                  <span className="font-black text-rose-900">{currencySymbol}{pnlSummary.drugsCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Vaccines (5300) */}
              <div className="flex justify-between items-center pt-2 text-rose-950">
                <div className="flex items-center gap-2">
                  <span className="font-bold">Poultry Vaccines & Vet Biologicals</span>
                  <span className="text-[10px] bg-rose-100 text-rose-800 px-1.5 py-0.5 rounded font-bold">Health Protocols</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-rose-600">5300</span>
                  <span className="font-black text-rose-900">{currencySymbol}{pnlSummary.vaccinesCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Saw dust Bedding (5216) */}
              <div className="flex justify-between items-center pt-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-800">Saw dust & Bedding Litter</span>
                  <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-bold">Biosecurity Litter</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-slate-400">5216</span>
                  <span className="font-bold text-slate-900">{currencySymbol}{pnlSummary.beddingCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Charcoal & Fireblocks (5217) */}
              <div className="flex justify-between items-center pt-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-800">Charcoal and Fireblocks (Brooding Heat)</span>
                  <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-bold">Brooding Heat</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-slate-400">5217</span>
                  <span className="font-bold text-slate-900">{currencySymbol}{pnlSummary.heatingCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Direct Labour (5100) */}
              <div className="flex justify-between items-center pt-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-800">Direct Poultry Labour Overheads</span>
                  <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-bold">Flock Attendants</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-slate-400">5100</span>
                  <span className="font-bold text-slate-900">{currencySymbol}{pnlSummary.labourCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Other Direct Costs (5214) */}
              {pnlSummary.otherDirectCost > 0 && (
                <div className="flex justify-between items-center pt-2 text-slate-700">
                  <div className="flex items-center gap-2">
                    <span>Other Direct Poultry Supplies & Operations</span>
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-bold">Direct Supplies</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-[10px] text-slate-400">5214</span>
                    <span className="font-bold">{currencySymbol}{pnlSummary.otherDirectCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              )}

              {/* Mortality Losses (5901) */}
              <div className="flex justify-between items-center pt-2 text-red-600">
                <div className="flex items-center gap-2">
                  <span>Mortality Losses (Non-Cash Biological Write-Off)</span>
                  <span className="text-[10px] bg-red-50 text-red-700 px-1.5 py-0.5 rounded font-bold">Biological Write-Off</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-slate-400">5901</span>
                  <span className="font-bold">{currencySymbol}{pnlSummary.mortalityLoss.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Total Costs Sum */}
              <div className="flex justify-between items-center pt-3 border-t-2 border-slate-200 font-black text-slate-900">
                <span className="text-xs uppercase tracking-wide">TOTAL DIRECT PRODUCTION OUTLAYS</span>
                <span className="text-sm font-mono">{currencySymbol}{pnlSummary.totalExpenses.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Itemized Continuous Expenses & Supplier Spend Audit Table */}
      <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 border-b border-slate-100 pb-3">
          <div>
            <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
              <Receipt size={16} className="text-emerald-600" />
              Continuous Expenses & Cash Book Disbursals Itemization
            </h3>
            <p className="text-[11px] text-slate-400 font-medium">
              Every poultry-related expense recorded in the Finance module and tracked on the Professional Suppliers/Payees Tracker
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setExpenseFilterTab("all")}
              className={`px-3 py-1 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                expenseFilterTab === "all" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
            >
              All ({poultryExpenseItems.length})
            </button>
            <button
              onClick={() => setExpenseFilterTab("5211")}
              className={`px-3 py-1 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                expenseFilterTab === "5211" ? "bg-indigo-600 text-white" : "bg-indigo-50 text-indigo-700 hover:bg-indigo-100"
              }`}
            >
              Chicks (5211)
            </button>
            <button
              onClick={() => setExpenseFilterTab("5210")}
              className={`px-3 py-1 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                expenseFilterTab === "5210" ? "bg-amber-600 text-white" : "bg-amber-50 text-amber-700 hover:bg-amber-100"
              }`}
            >
              Feed (5210)
            </button>
            <button
              onClick={() => setExpenseFilterTab("5215")}
              className={`px-3 py-1 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                expenseFilterTab === "5215" ? "bg-rose-600 text-white" : "bg-rose-50 text-rose-700 hover:bg-rose-100"
              }`}
            >
              Drugs (5215)
            </button>
            <button
              onClick={() => setExpenseFilterTab("5300")}
              className={`px-3 py-1 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                expenseFilterTab === "5300" ? "bg-rose-600 text-white" : "bg-rose-50 text-rose-700 hover:bg-rose-100"
              }`}
            >
              Vaccines (5300)
            </button>
            <button
              onClick={() => setExpenseFilterTab("5216")}
              className={`px-3 py-1 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                expenseFilterTab === "5216" ? "bg-slate-800 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              }`}
            >
              Saw dust (5216)
            </button>
            <button
              onClick={() => setExpenseFilterTab("5217")}
              className={`px-3 py-1 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                expenseFilterTab === "5217" ? "bg-slate-800 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              }`}
            >
              Charcoal (5217)
            </button>
            <button
              onClick={() => setExpenseFilterTab("5100")}
              className={`px-3 py-1 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                expenseFilterTab === "5100" ? "bg-slate-800 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              }`}
            >
              Labour (5100)
            </button>
          </div>
        </div>

        {displayExpenseList.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-100 text-slate-400 space-y-2">
            <Receipt size={32} className="mx-auto text-slate-300" />
            <p className="text-xs font-bold text-slate-600">No matching Continuous Expenses found for this filter</p>
            <p className="text-[11px] text-slate-400">
              When you restock feed, purchase chicks, or log vet supplies, expenses automatically post to the finance ledger and update the Payees Tracker.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-100">
                  <th className="p-3">Date</th>
                  <th className="p-3">Supplier / Payee</th>
                  <th className="p-3">COA Code</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Description</th>
                  <th className="p-3 text-right">Qty</th>
                  <th className="p-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {displayExpenseList.map((item, idx) => (
                  <tr key={`${item.txId}-${idx}`} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 whitespace-nowrap text-slate-500">{item.date}</td>
                    <td className="p-3 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <Building2 size={13} className="text-slate-400" />
                        <span className="font-bold text-slate-900">{item.supplierName}</span>
                      </div>
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <span className="font-mono text-[10px] bg-slate-100 px-2 py-0.5 rounded font-bold text-slate-700">
                        {item.coaCode}
                      </span>
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        item.coaCode === "5211" ? "bg-indigo-50 text-indigo-700" :
                        item.coaCode === "5210" ? "bg-amber-50 text-amber-700" :
                        item.coaCode === "5215" ? "bg-rose-50 text-rose-700" :
                        item.coaCode === "5300" ? "bg-rose-50 text-rose-700" :
                        item.coaCode === "5216" ? "bg-amber-50 text-amber-800" :
                        item.coaCode === "5217" ? "bg-slate-100 text-slate-800" :
                        item.coaCode === "5100" ? "bg-blue-50 text-blue-800" : "bg-slate-100 text-slate-700"
                      }`}>
                        {item.category}
                      </span>
                    </td>
                    <td className="p-3 max-w-xs truncate text-slate-600">{item.description}</td>
                    <td className="p-3 text-right font-mono text-slate-600">{item.quantity}</td>
                    <td className="p-3 text-right font-black text-slate-900 whitespace-nowrap">
                      {currencySymbol}{item.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-50/80 font-black text-slate-900 border-t border-slate-200">
                  <td colSpan={6} className="p-3 text-right uppercase text-[10px] tracking-wider text-slate-500">
                    Filtered Expenses Total
                  </td>
                  <td className="p-3 text-right text-sm font-mono">
                    {currencySymbol}{displayExpenseList.reduce((sum, it) => sum + it.amount, 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

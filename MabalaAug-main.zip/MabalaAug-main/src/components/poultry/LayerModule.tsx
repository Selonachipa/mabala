import React, { useState, useMemo } from "react";
import { PoultryBatch, PoultryFeedLog, PoultryHealthEvent, PoultryMortalityLog, EggCollection, EggSale, PoultrySalesLog } from "./types";
import EggGradeRatioPieChart from "./EggGradeRatioPieChart";
import DailyEggTrendChart from "./DailyEggTrendChart";
import FcrMetricCard from "./FcrMetricCard";
import BatchCostBreakdownSummary from "./BatchCostBreakdownSummary";
import { 
  Plus, Egg, Calendar, MapPin, DollarSign, Trash2, 
  TrendingUp, Skull, ShieldAlert, CheckCircle, ChevronRight, X, Sparkles, BookOpen, ShoppingBag, PieChart
} from "lucide-react";
import { Supplier, ExpenseTransaction } from "../../types";
import UnifiedSupplierModal from "../common/UnifiedSupplierModal";

interface LayerModuleProps {
  batches: PoultryBatch[];
  currencySymbol: string;
  onAddBatch: (batch: PoultryBatch) => void;
  onUpdateBatch: (batch: PoultryBatch) => void;
  onDeleteBatch: (id: string) => void;
  accounts: any[];
  setAccounts: (accs: any[]) => void;
  onAddExpense?: (tx: any) => void;
  onAddSupplier?: (sup: Supplier) => void;
  suppliers?: Supplier[];
  expenses?: ExpenseTransaction[];
  writeAuditLog: (action: string, module: string, target: string, details: string) => void;
  activeFarm: any;
  onShowDocument: (type: "certificate" | "receipt", data: any) => void;
  employees?: any[];
}

export default function LayerModule({
  batches,
  currencySymbol,
  onAddBatch,
  onUpdateBatch,
  onDeleteBatch,
  accounts,
  setAccounts,
  onAddExpense,
  onAddSupplier,
  suppliers = [],
  expenses = [],
  writeAuditLog,
  activeFarm,
  onShowDocument,
  employees = []
}: LayerModuleProps) {
  const layerBatches = useMemo(() => batches.filter(b => b.poultryType === "layer"), [batches]);

  // Modals state
  const [isRegWizardOpen, setIsRegWizardOpen] = useState(false);
  const [wizardStep, setWizardStep] = useState(1);
  const [selectedBatch, setSelectedBatch] = useState<PoultryBatch | null>(null);
  const [showSupplierModal, setShowSupplierModal] = useState(false);

  // Active Logging Modal states
  const [activeLogType, setActiveLogType] = useState<"feed" | "health" | "mortality" | "collect" | "eggsale" | "p_and_l" | "edit_price" | "sell_hen" | "edit_headcount" | null>(null);

  // New Batch Form State
  const [newBatch, setNewBatch] = useState({
    breed: "Cobb 500",
    dateAcquired: new Date().toISOString().split("T")[0],
    acquisitionType: "day_old" as "day_old" | "pullet", // day-old chick vs point-of-lay pullet toggle
    source: "",
    customSource: "",
    initialHeadcount: 0,
    acquisitionCostPerBird: 0,
    photoUrl: "",
    currentMarketPricePerBird: 0, // spent hen market value
    expectedLayAgeWeeks: 18, // standard 18 weeks
  });

  // Action Form States
  const [feedForm, setFeedForm] = useState({
    date: new Date().toISOString().split("T")[0],
    feedType: "",
    quantityKg: 0,
    cost: 0,
    fedBy: ""
  });

  const [editHeadcountValue, setEditHeadcountValue] = useState(0);
  const [editHeadcountReason, setEditHeadcountReason] = useState("Manual audit correction");

  const [healthForm, setHealthForm] = useState({
    date: new Date().toISOString().split("T")[0],
    type: "vaccination" as "vaccination" | "treatment",
    product: "",
    cost: 0,
    notes: "",
    withdrawalPeriodDays: 0,
    administeredBy: ""
  });

  const [mortalityForm, setMortalityForm] = useState({
    date: new Date().toISOString().split("T")[0],
    count: 0,
    cause: "Disease" as any,
    notes: ""
  });

  const [collectForm, setCollectForm] = useState({
    date: new Date().toISOString().split("T")[0],
    useGrades: true,
    large: 0,
    medium: 0,
    small: 0,
    ungraded: 0,
    brokenCount: 0
  });

  const [eggSaleForm, setEggSaleForm] = useState({
    date: new Date().toISOString().split("T")[0],
    grade: "medium" as "large" | "medium" | "small" | "ungraded",
    buyerName: "",
    sellUnit: "tray" as "tray" | "egg", // tray vs egg toggle
    quantity: 0, // in trays or eggs
    pricePerUnit: 0, // price per tray or per egg
    paymentMethod: "Mobile Money"
  });

  const [marketPriceForm, setMarketPriceForm] = useState({
    price: 0
  });

  const [sellHenForm, setSellHenForm] = useState({
    date: new Date().toISOString().split("T")[0],
    buyerName: "",
    quantity: 0,
    pricePerBird: 0,
    paymentMethod: "Cash"
  });

  // Calculate RUNNING EGG STOCK BALANCE per grade globally
  const runningEggStock = useMemo(() => {
    let largeCollected = 0;
    let largeSold = 0;
    let mediumCollected = 0;
    let mediumSold = 0;
    let smallCollected = 0;
    let smallSold = 0;
    let ungradedCollected = 0;
    let ungradedSold = 0;

    layerBatches.forEach(b => {
      // Collections
      if (b.eggCollections) {
        b.eggCollections.forEach(ec => {
          if (ec.useGrades) {
            largeCollected += ec.large;
            mediumCollected += ec.medium;
            smallCollected += ec.small;
          } else {
            ungradedCollected += ec.ungraded;
          }
        });
      }

      // Sales
      if (b.eggSales) {
        b.eggSales.forEach(es => {
          const eggCount = es.sellUnit === "tray" ? es.quantity * 30 : es.quantity;
          if (es.grade === "large") largeSold += eggCount;
          else if (es.grade === "medium") mediumSold += eggCount;
          else if (es.grade === "small") smallSold += eggCount;
          else if (es.grade === "ungraded") ungradedSold += eggCount;
        });
      }
    });

    return {
      large: Math.max(0, largeCollected - largeSold),
      medium: Math.max(0, mediumCollected - mediumSold),
      small: Math.max(0, smallCollected - smallSold),
      ungraded: Math.max(0, ungradedCollected - ungradedSold),
      total: Math.max(0, (largeCollected + mediumCollected + smallCollected + ungradedCollected) - (largeSold + mediumSold + smallSold + ungradedSold))
    };
  }, [layerBatches]);

  // Helper: compute age in days
  const getAgeInDays = (dateAcquired: string) => {
    const diff = Date.now() - new Date(dateAcquired).getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    return days < 0 ? 0 : days;
  };

  // Double-Entry Ledger Poster
  const postLedger = (debitCode: string, creditCode: string, amount: number) => {
    if (isNaN(amount) || amount <= 0) return;
    setAccounts(accounts.map(acc => {
      let bal = acc.balance;
      if (acc.code === debitCode) bal += amount;
      if (acc.code === creditCode) bal -= amount;
      return { ...acc, balance: bal };
    }));
  };

  // Step 1 Wizard Next
  const handleWizardNext = () => {
    setWizardStep(2);
  };

  // Step 2 Wizard Finish
  const handleCreateBatch = () => {
    const finalSource = (newBatch.source === "Other (Custom)" ? newBatch.customSource : newBatch.source) || "Hybrid Poultry Farm (Z) Limited";
    const totalCost = newBatch.initialHeadcount * newBatch.acquisitionCostPerBird;
    
    const batchId = `LAY-${Date.now().toString().slice(-6)}`;
    const count = layerBatches.length + 1;
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const now = new Date();
    const batchName = `Layer Batch #${count} – ${months[now.getMonth()]} ${now.getFullYear()}`;

    // Auto-register Hatchery Supplier if not present
    let matchedSup = suppliers.find(s => s.name.toLowerCase() === finalSource.trim().toLowerCase());
    let supplierId = matchedSup?.id;

    if (!matchedSup && onAddSupplier) {
      supplierId = `SUP-HATCHERY-${Date.now()}`;
      const newSup: Supplier = {
        id: supplierId,
        name: finalSource.trim(),
        contactPerson: "Hatchery Sales & Dispatch",
        phone: "0971000222",
        email: "",
        address: "Lusaka / Copperbelt Hatchery Depot",
        tpin: "1002345678",
        category: "Hatchery & Layer Pullets",
        notes: `Auto-registered from Layer Batch ${batchName} acquisition on ${newBatch.dateAcquired}`,
        farmId: activeFarm?.id,
        tenantId: activeFarm?.tenantId
      };
      onAddSupplier(newSup);
    }

    const created: PoultryBatch = {
      id: batchId,
      batchId,
      batchName,
      poultryType: "layer",
      breed: newBatch.breed,
      dateAcquired: newBatch.dateAcquired,
      source: finalSource,
      initialHeadcount: Number(newBatch.initialHeadcount),
      currentHeadcount: Number(newBatch.initialHeadcount),
      acquisitionCostPerBird: Number(newBatch.acquisitionCostPerBird),
      acquisitionCostTotal: totalCost,
      currentMarketPricePerBird: Number(newBatch.currentMarketPricePerBird),
      currentBatchValuation: Number(newBatch.initialHeadcount) * Number(newBatch.currentMarketPricePerBird),
      cumulativeFeedCost: 0,
      cumulativeHealthCost: 0,
      cumulativeMortalityLoss: 0,
      status: "active",
      photoUrl: newBatch.photoUrl || undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: "Farm Operator",
      tenantId: activeFarm?.tenantId || "default",
      farmId: activeFarm?.id || "default",
      feedLogs: [],
      healthLogs: [],
      mortalityLogs: [],
      salesLogs: [],
      eggCollections: [],
      eggSales: [],
      valuationHistory: [],
      expectedLayAgeWeeks: Number(newBatch.expectedLayAgeWeeks),
      hasPendingWrites: true,
      _pendingSync: true
    };

    onAddBatch(created);

    // Ledger: Debit Poultry Acquisition Cost (5211), Credit Bank Operational (1010)
    postLedger("5211", "1010", totalCost);

    // Auto-post Day-Old Chicks Cost to Continuous Expenses & Cash book Disbursals
    if (onAddExpense && totalCost > 0) {
      const expenseTx = {
        id: `EXP-CHICKS-${Date.now()}`,
        supplierId: supplierId || `SUP-${Date.now()}`,
        supplierName: finalSource,
        date: newBatch.dateAcquired,
        taxSystem: "Exempt",
        taxAmount: 0,
        subtotal: totalCost,
        total: totalCost,
        amount: totalCost,
        farmId: activeFarm?.id,
        tenantId: activeFarm?.tenantId,
        hasPendingWrites: true,
        _pendingSync: true,
        rows: [
          {
            category: "Poultry Day-Old Chicks / Flock Acquisition",
            description: `Layer Pullet / Chick Acquisition: ${newBatch.initialHeadcount} ${newBatch.breed} @ ${currencySymbol}${newBatch.acquisitionCostPerBird}/bird for ${batchName} from ${finalSource}`,
            quantity: Number(newBatch.initialHeadcount),
            unitPrice: Number(newBatch.acquisitionCostPerBird),
            amount: totalCost,
            coaCode: "5211",
            allocationType: "poultry_batch",
            poultryBatchId: batchId,
            poultryBatchName: batchName
          }
        ]
      };
      onAddExpense(expenseTx);
    }

    writeAuditLog("CREATE", "Poultry", batchId, `Registered Layer flock batch: ${batchName} with headcount ${newBatch.initialHeadcount} from ${finalSource}. Posted chick expense ${currencySymbol}${totalCost}.`);

    setIsRegWizardOpen(false);
    setWizardStep(1);
    setNewBatch({
      breed: "Cobb 500",
      dateAcquired: new Date().toISOString().split("T")[0],
      acquisitionType: "day_old",
      source: "Hybrid Poultry Farm (Z) Limited",
      customSource: "",
      initialHeadcount: 500,
      acquisitionCostPerBird: 12.0,
      photoUrl: "",
      currentMarketPricePerBird: 50.0,
      expectedLayAgeWeeks: 18,
    });
  };

  // LOG FEED SUBMIT
  const handleLogFeed = () => {
    if (!selectedBatch) return;

    const logId = `F-${Date.now().toString().slice(-4)}`;
    const newLog: PoultryFeedLog = {
      id: logId,
      date: feedForm.date,
      feedType: feedForm.feedType,
      quantityKg: Number(feedForm.quantityKg),
      cost: Number(feedForm.cost),
      fedBy: feedForm.fedBy
    };

    const updated = {
      ...selectedBatch,
      feedLogs: [...selectedBatch.feedLogs, newLog],
      cumulativeFeedCost: selectedBatch.cumulativeFeedCost + Number(feedForm.cost),
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    // Ledger: Debit Poultry Feed (5210), Credit Bank (1010)
    postLedger("5210", "1010", Number(feedForm.cost));

    if (onAddExpense) {
      const feedCost = Number(feedForm.cost);
      const qty = Number(feedForm.quantityKg);
      onAddExpense({
        id: `EXP-FEED-${Date.now()}`,
        supplierId: "SUP-FEED-INTERNAL",
        supplierName: "Layer Feed Allocation",
        date: feedForm.date,
        taxSystem: "Exempt",
        taxAmount: 0,
        subtotal: feedCost,
        total: feedCost,
        amount: feedCost,
        farmId: activeFarm?.id,
        rows: [
          {
            category: "Poultry Feed",
            description: `Layer feed intake for ${selectedBatch.batchName}: ${qty}kg ${feedForm.feedType}`,
            quantity: qty,
            unitPrice: qty > 0 ? feedCost / qty : 0,
            amount: feedCost,
            coaCode: "5210"
          }
        ]
      });
    }

    writeAuditLog("CREATE", "Poultry Feed", selectedBatch.batchId, `Logged feed log for layer flock ${selectedBatch.batchName}: ${feedForm.quantityKg}kg of ${feedForm.feedType}`);
    
    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // LOG HEALTH SUBMIT
  const handleLogHealth = () => {
    if (!selectedBatch) return;

    const logId = `H-${Date.now().toString().slice(-4)}`;
    const newLog: PoultryHealthEvent = {
      id: logId,
      date: healthForm.date,
      type: healthForm.type,
      product: healthForm.product,
      cost: Number(healthForm.cost),
      notes: healthForm.notes,
      withdrawalPeriodDays: Number(healthForm.withdrawalPeriodDays),
      withdrawalCloseDate: healthForm.withdrawalPeriodDays > 0 
        ? new Date(new Date(healthForm.date).getTime() + Number(healthForm.withdrawalPeriodDays) * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
        : undefined,
      administeredBy: healthForm.administeredBy || activeFarm?.ownerName || "Operator"
    };

    const updated = {
      ...selectedBatch,
      healthLogs: [...selectedBatch.healthLogs, newLog],
      cumulativeHealthCost: selectedBatch.cumulativeHealthCost + Number(healthForm.cost),
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    // Ledger: Debit Vet Suite Expenses (5300), Credit Bank (1010)
    postLedger("5300", "1010", Number(healthForm.cost));

    writeAuditLog("CREATE", "Poultry Health", selectedBatch.batchId, `Logged health vaccine for layer flock ${selectedBatch.batchName}: ${healthForm.product}`);
    
    setActiveLogType(null);
    setSelectedBatch(null);
  };

  const handleEditHeadcount = () => {
    if (!selectedBatch) return;
    const oldHead = selectedBatch.currentHeadcount;
    const newHead = Math.max(0, Number(editHeadcountValue));
    
    const updated = {
      ...selectedBatch,
      currentHeadcount: newHead,
      currentBatchValuation: newHead * selectedBatch.currentMarketPricePerBird,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);
    writeAuditLog("POULTRY_EDIT_HEADCOUNT", "Poultry", selectedBatch.batchId, `Manually adjusted Layer headcount from ${oldHead} to ${newHead} (Reason: ${editHeadcountReason})`);
    alert(`Successfully adjusted headcount from ${oldHead} to ${newHead}.`);
    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // LOG MORTALITY SUBMIT
  const handleLogMortality = () => {
    if (!selectedBatch) return;

    const totalExpenses = selectedBatch.acquisitionCostTotal + selectedBatch.cumulativeFeedCost + selectedBatch.cumulativeHealthCost;
    const costPerBirdSoFar = totalExpenses / selectedBatch.initialHeadcount;
    const lossValue = Number(mortalityForm.count) * costPerBirdSoFar;

    const logId = `M-${Date.now().toString().slice(-4)}`;
    const newLog: PoultryMortalityLog = {
      id: logId,
      date: mortalityForm.date,
      count: Number(mortalityForm.count),
      cause: mortalityForm.cause,
      lossValue: lossValue,
      notes: mortalityForm.notes
    };

    const newHeadcount = Math.max(0, selectedBatch.currentHeadcount - Number(mortalityForm.count));

    const updated = {
      ...selectedBatch,
      currentHeadcount: newHeadcount,
      mortalityLogs: [...selectedBatch.mortalityLogs, newLog],
      cumulativeMortalityLoss: selectedBatch.cumulativeMortalityLoss + lossValue,
      currentBatchValuation: newHeadcount * selectedBatch.currentMarketPricePerBird,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    // Ledger: Debit Mortality Loss (5901), Credit Biological Assets (1430)
    postLedger("5901", "1430", lossValue);

    writeAuditLog("CREATE", "Poultry Mortality", selectedBatch.batchId, `Logged mortality of ${mortalityForm.count} layer birds for batch ${selectedBatch.batchName}`);
    
    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // LOG EGG COLLECTION SUBMIT
  const handleLogCollect = () => {
    if (!selectedBatch) return;

    let totalCol = 0;
    if (collectForm.useGrades) {
      totalCol = Number(collectForm.large) + Number(collectForm.medium) + Number(collectForm.small);
    } else {
      totalCol = Number(collectForm.ungraded);
    }

    // Lay Rate (%) = Eggs Collected / Current headcount
    const layRate = selectedBatch.currentHeadcount > 0 ? (totalCol / selectedBatch.currentHeadcount) * 100 : 0;

    const logId = `EC-${Date.now().toString().slice(-4)}`;
    const newCollection: EggCollection = {
      id: logId,
      date: collectForm.date,
      totalCollected: totalCol,
      brokenCount: Number(collectForm.brokenCount),
      large: collectForm.useGrades ? Number(collectForm.large) : 0,
      medium: collectForm.useGrades ? Number(collectForm.medium) : 0,
      small: collectForm.useGrades ? Number(collectForm.small) : 0,
      ungraded: !collectForm.useGrades ? Number(collectForm.ungraded) : 0,
      useGrades: collectForm.useGrades,
      layRatePct: layRate
    };

    const updated = {
      ...selectedBatch,
      eggCollections: [...(selectedBatch.eggCollections || []), newCollection],
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    writeAuditLog("CREATE", "Poultry Production", selectedBatch.batchId, `Logged egg collection: ${totalCol} eggs collected with daily lay rate of ${layRate.toFixed(1)}%`);

    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // LOG EGG SALE SUBMIT
  const handleLogEggSale = () => {
    if (!selectedBatch) return;

    const qtyInUnits = eggSaleForm.sellUnit === "tray" ? Number(eggSaleForm.quantity) * 30 : Number(eggSaleForm.quantity);
    const revenue = Number(eggSaleForm.quantity) * Number(eggSaleForm.pricePerUnit);

    // Validate we have enough stock in this grade
    const gradeStock = runningEggStock[eggSaleForm.grade];
    if (qtyInUnits > gradeStock) {
      alert(`Insufficient Stock! You are attempting to sell ${qtyInUnits} eggs of grade '${eggSaleForm.grade}', but only ${gradeStock} are available in total stock.`);
      return;
    }

    const logId = `ES-${Date.now().toString().slice(-4)}`;
    const newSale: EggSale = {
      id: logId,
      date: eggSaleForm.date,
      grade: eggSaleForm.grade,
      quantity: qtyInUnits,
      pricePerUnit: Number(eggSaleForm.pricePerUnit),
      sellUnit: eggSaleForm.sellUnit,
      totalRevenue: revenue,
      buyerName: eggSaleForm.buyerName,
      paymentMethod: eggSaleForm.paymentMethod
    };

    const updated = {
      ...selectedBatch,
      eggSales: [...(selectedBatch.eggSales || []), newSale],
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    // Ledger Posting: Debit Bank (1010), Credit Egg Sales Revenue (4220)
    postLedger("1010", "4220", revenue);

    writeAuditLog("CREATE", "Poultry Revenue", selectedBatch.batchId, `Sold ${eggSaleForm.quantity} ${eggSaleForm.sellUnit}s of grade '${eggSaleForm.grade}' eggs for ${currencySymbol}${revenue}`);

    // Trigger receipt view callback!
    onShowDocument("receipt", {
      farmName: activeFarm?.name || "Mabala Registered Farm",
      date: eggSaleForm.date,
      reference: logId,
      buyerName: eggSaleForm.buyerName,
      quantity: Number(eggSaleForm.quantity),
      pricePerUnit: Number(eggSaleForm.pricePerUnit),
      totalAmount: revenue,
      paymentMethod: eggSaleForm.paymentMethod,
      currencySymbol,
      sellUnit: eggSaleForm.sellUnit,
      gradeBreakdown: { [eggSaleForm.grade]: qtyInUnits }
    });

    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // UPDATE VALUATION Spent Hen price
  const handleUpdatePrice = () => {
    if (!selectedBatch) return;

    const oldPrice = selectedBatch.currentMarketPricePerBird;
    const newPrice = Number(marketPriceForm.price);

    const historyItem = {
      date: new Date().toISOString().split("T")[0],
      oldPrice,
      newPrice,
      changedBy: "Farm Operator"
    };

    const updated = {
      ...selectedBatch,
      currentMarketPricePerBird: newPrice,
      currentBatchValuation: selectedBatch.currentHeadcount * newPrice,
      valuationHistory: [...(selectedBatch.valuationHistory || []), historyItem],
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    writeAuditLog("UPDATE", "Poultry Valuation", selectedBatch.batchId, `Updated spent hen market value for ${selectedBatch.batchName} from ${oldPrice} to ${newPrice}`);

    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // END-OF-LAY SPENT HENS DISPOSAL SALE
  const handleSellSpentHens = () => {
    if (!selectedBatch) return;

    const qty = Number(sellHenForm.quantity);
    const price = Number(sellHenForm.pricePerBird);
    const amount = qty * price;

    const logId = `S-${Date.now().toString().slice(-4)}`;
    const newSale: PoultrySalesLog = {
      id: logId,
      date: sellHenForm.date,
      quantity: qty,
      amount: amount,
      pricePerUnit: price,
      chargeType: "PER_BIRD",
      buyerName: sellHenForm.buyerName,
      paymentMethod: sellHenForm.paymentMethod
    };

    const newHeadcount = Math.max(0, selectedBatch.currentHeadcount - qty);
    const isNowSoldOut = newHeadcount === 0;

    // Calculate proportional cost of birds sold (COGS)
    const totalExpenses = selectedBatch.acquisitionCostTotal + selectedBatch.cumulativeFeedCost + selectedBatch.cumulativeHealthCost;
    const costPerBirdSoFar = totalExpenses / selectedBatch.initialHeadcount;
    const cogsAmount = qty * costPerBirdSoFar;

    const updated: PoultryBatch = {
      ...selectedBatch,
      currentHeadcount: newHeadcount,
      status: isNowSoldOut ? "sold_out" : "active",
      salesLogs: [...selectedBatch.salesLogs, newSale],
      currentBatchValuation: newHeadcount * selectedBatch.currentMarketPricePerBird,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updated);

    // Ledger Postings:
    // 1. Debit Bank (1010), Credit Live Bird Sales Revenue (4210) by transaction amount
    postLedger("1010", "4210", amount);

    // 2. Debit Cost of Birds Sold (5212), Credit Biological Assets (1430) by COGS amount
    postLedger("5212", "1430", cogsAmount);

    writeAuditLog("CREATE", "Poultry Spent Hen Sale", selectedBatch.batchId, `Sold spent hen flock disposal: ${qty} hens sold for ${amount}`);

    // Trigger certificate view callback!
    onShowDocument("certificate", {
      farmName: activeFarm?.name || "Mabala Registered Farm",
      date: sellHenForm.date,
      reference: logId,
      buyerName: sellHenForm.buyerName,
      quantity: qty,
      pricePerUnit: price,
      totalAmount: amount,
      paymentMethod: sellHenForm.paymentMethod,
      currencySymbol,
      breed: selectedBatch.breed,
      chargeType: "PER_BIRD"
    });

    setActiveLogType(null);
    setSelectedBatch(null);
  };

  // EXCEL / CSV EXPORTER
  const exportRegistry = (format: "csv" | "excel") => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Batch Name,Breed,Age (Days),Headcount,Valuation,Cumulative Feed,Cumulative Health,Status\n";
    
    layerBatches.forEach(b => {
      const age = getAgeInDays(b.dateAcquired);
      csvContent += `"${b.batchName}","${b.breed}",${age},${b.currentHeadcount},${b.currentBatchValuation},${b.cumulativeFeedCost},${b.cumulativeHealthCost},${b.status}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `mabala_layers_registry.${format === "csv" ? "csv" : "xls"}`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 text-slate-800" id="layer-module-container">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Egg className="text-sky-500 fill-sky-500/10" size={26} />
            Layer & Egg Production
          </h2>
          <p className="text-xs text-slate-500 font-semibold mt-0.5">
            Log sorted sorting eggs, manage tray stocks, record mash feeding, and sell spent hen disposals
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => exportRegistry("csv")}
            className="px-3.5 py-2 border border-slate-200 text-slate-600 rounded-xl text-xs font-bold bg-white hover:bg-slate-50 transition-all cursor-pointer flex items-center gap-1.5"
          >
            <BookOpen size={14} />
            Export CSV
          </button>
          <button
            onClick={() => {
              setWizardStep(1);
              setIsRegWizardOpen(true);
            }}
            className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white rounded-xl text-xs font-black shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Plus size={16} />
            Register Layer Batch
          </button>
        </div>
      </div>

      {/* Aggregate Egg Stock balance widget */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-950 text-white rounded-3xl p-6 shadow-xl grid grid-cols-2 md:grid-cols-5 gap-6 items-center">
        <div className="col-span-2 space-y-1">
          <div className="flex items-center gap-1.5">
            <Egg className="text-sky-400 fill-sky-400/10" size={20} />
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Total Egg Stock balance</span>
          </div>
          <h3 className="text-3xl font-black tracking-tight text-white">
            {runningEggStock.total.toLocaleString()} <span className="text-xs text-slate-400 font-semibold">eggs</span>
          </h3>
          <p className="text-[11px] text-slate-400 font-medium">
            ({Math.floor(runningEggStock.total / 30)} standard crates of 30 eggs)
          </p>
        </div>
        
        {/* Large Grade stock */}
        <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-750 text-center">
          <span className="text-[9px] font-black uppercase tracking-wider text-slate-400 block">Large Grade</span>
          <strong className="text-lg font-extrabold text-white mt-1 block">{runningEggStock.large}</strong>
          <span className="text-[9px] text-slate-400 font-semibold">({Math.floor(runningEggStock.large / 30)} trays)</span>
        </div>

        {/* Medium Grade stock */}
        <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-750 text-center">
          <span className="text-[9px] font-black uppercase tracking-wider text-slate-400 block">Medium Grade</span>
          <strong className="text-lg font-extrabold text-white mt-1 block">{runningEggStock.medium}</strong>
          <span className="text-[9px] text-slate-400 font-semibold">({Math.floor(runningEggStock.medium / 30)} trays)</span>
        </div>

        {/* Small Grade stock */}
        <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-750 text-center">
          <span className="text-[9px] font-black uppercase tracking-wider text-slate-400 block">Small Grade</span>
          <strong className="text-lg font-extrabold text-white mt-1 block">{runningEggStock.small}</strong>
          <span className="text-[9px] text-slate-400 font-semibold">({Math.floor(runningEggStock.small / 30)} trays)</span>
        </div>
      </div>

      {/* Active Layer Flocks Grid */}
      {layerBatches.length === 0 ? (
        <div className="bg-slate-50 rounded-3xl p-12 text-center border border-dashed border-slate-200">
          <div className="inline-block bg-sky-100 p-4 rounded-full text-sky-600 mb-3">
            <Egg size={32} />
          </div>
          <h4 className="text-slate-800 font-extrabold text-sm">No Active Layer Batches</h4>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto font-medium leading-relaxed">
            Begin egg production cycles by registering your first layer chick or Point-of-lay pullet intake flock.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {layerBatches.map(b => {
            const age = getAgeInDays(b.dateAcquired);
            const totalDead = b.mortalityLogs.reduce((sum, m) => sum + m.count, 0);
            const mortalityRate = b.initialHeadcount > 0 ? (totalDead / b.initialHeadcount) * 100 : 0;
            const expensesToDate = b.acquisitionCostTotal + b.cumulativeFeedCost + b.cumulativeHealthCost;
            
            // Expected Point-of-Lay age day threshold check
            const ageInWeeks = Math.floor(age / 7);
            const isLaying = ageInWeeks >= (b.expectedLayAgeWeeks || 18);
            const layingStatus = isLaying ? "In Lay" : "Rearing";

            // Lay rate (%) calculation from last collection
            const collections = b.eggCollections || [];
            const latestCollect = collections.length > 0 ? collections[collections.length - 1] : null;
            const currentLayRate = latestCollect ? latestCollect.layRatePct : 0;

            return (
              <div 
                key={b.id} 
                className={`bg-white rounded-3xl border shadow-xs flex flex-col justify-between overflow-hidden transition-all relative ${
                  b.status === "sold_out" ? "border-slate-150 opacity-75" : "border-slate-100 hover:shadow-md"
                }`}
              >
                {/* Visual Header */}
                <div className="p-5 border-b border-slate-50 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-extrabold text-slate-900 text-sm">{b.batchName}</h3>
                      <p className="text-[10px] text-slate-400 font-bold mt-0.5">Breed: {b.breed} • Ref: {b.batchId}</p>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider ${
                      b.status === "active" ? "bg-emerald-100 text-emerald-800" : "bg-slate-100 text-slate-800"
                    }`}>
                      {b.status}
                    </span>
                  </div>

                  {/* Warning high mortality spike */}
                  {mortalityRate > 2 && b.status === "active" && (
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 border border-red-100 text-red-700 rounded-xl text-[10px] font-bold animate-pulse">
                      <ShieldAlert size={12} className="flex-shrink-0" />
                      Warning: Mortality threshold exceeded ({mortalityRate.toFixed(1)}%)
                    </div>
                  )}

                  {/* Core Metrics Grid */}
                  <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                    <div className="bg-slate-50 p-2 rounded-2xl min-w-0">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block truncate">Laying Status</span>
                      <strong className={`text-[11px] sm:text-xs md:text-sm font-black block truncate ${isLaying ? "text-sky-600" : "text-amber-600"}`} title={`${layingStatus} (${ageInWeeks}w)`}>
                        {layingStatus} ({ageInWeeks}w)
                      </strong>
                    </div>
                    <div className="bg-slate-50 p-2 rounded-2xl min-w-0">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block truncate">Flock Headcount</span>
                      <strong className="text-slate-800 text-[11px] sm:text-xs md:text-sm font-black block truncate" title={`${b.currentHeadcount} / ${b.initialHeadcount}`}>{b.currentHeadcount} / {b.initialHeadcount}</strong>
                    </div>
                    <div className="bg-slate-50 p-2 rounded-2xl min-w-0">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block truncate">Current Lay Rate</span>
                      <strong className="text-slate-800 text-[11px] sm:text-xs md:text-sm font-black block truncate" title={currentLayRate > 0 ? `${currentLayRate.toFixed(1)}%` : "0.0%"}>
                        {currentLayRate > 0 ? `${currentLayRate.toFixed(1)}%` : "0.0%"}
                      </strong>
                    </div>
                    <div className="bg-slate-50 p-2 rounded-2xl min-w-0">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block truncate">Valuation</span>
                      <strong className="text-emerald-700 text-[11px] sm:text-xs md:text-sm font-black block truncate" title={`${currencySymbol}${b.currentBatchValuation.toLocaleString()}`}>
                        {currencySymbol}{b.currentBatchValuation.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                      </strong>
                    </div>
                  </div>
                </div>

                {/* FCR Efficiency Metric Card */}
                <div className="px-5 py-2.5 border-b border-slate-100">
                  <FcrMetricCard batch={b} />
                </div>

                {/* 30-Day Daily Egg Trend Line Chart */}
                <div className="px-5 py-2.5 border-b border-slate-100">
                  <DailyEggTrendChart eggCollections={b.eggCollections} batchName={b.batchName} />
                </div>

                {/* 30-Day Egg Quality Ratio Pie Chart */}
                <div className="px-5 py-2.5 border-b border-slate-100">
                  <EggGradeRatioPieChart eggCollections={b.eggCollections} />
                </div>

                {/* Performance logs summary list */}
                <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-100 text-[10px] text-slate-500 space-y-1">
                  <div className="flex justify-between">
                    <span>Cumulative Cost-to-date:</span>
                    <strong className="text-slate-700">{currencySymbol}{expensesToDate.toLocaleString()}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Cumulative Feed:</span>
                    <strong className="text-slate-700">{currencySymbol}{b.cumulativeFeedCost.toLocaleString()}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Mortality:</span>
                    <strong className={totalDead > 0 ? "text-red-600 font-bold" : "text-slate-700"}>
                      {totalDead} dead ({mortalityRate.toFixed(1)}% rate)
                    </strong>
                  </div>
                </div>

                {/* Batch Action Buttons */}
                <div className="p-3.5 bg-white grid grid-cols-3 gap-1">
                  {b.status === "active" ? (
                    <>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setActiveLogType("feed");
                        }}
                        className="py-2 text-[10px] font-black text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        + Feed
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setActiveLogType("health");
                        }}
                        className="py-2 text-[10px] font-black text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        + Health
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setActiveLogType("mortality");
                        }}
                        className="py-2 text-[10px] font-black text-red-600 hover:bg-red-50 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        + Dead
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setCollectForm({
                            ...collectForm,
                            date: new Date().toISOString().split("T")[0]
                          });
                          setActiveLogType("collect");
                        }}
                        className="py-2 text-[10px] font-black text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-xl transition-colors cursor-pointer text-center col-span-3 mt-1"
                      >
                        Log Daily Egg Collection
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setEggSaleForm({
                            ...eggSaleForm,
                            date: new Date().toISOString().split("T")[0]
                          });
                          setActiveLogType("eggsale");
                        }}
                        className="py-2 text-[10px] font-black text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        Sell Eggs
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setMarketPriceForm({ price: b.currentMarketPricePerBird });
                          setActiveLogType("edit_price");
                        }}
                        className="py-2 text-[10px] font-black text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        Spent Hen Price
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setEditHeadcountValue(b.currentHeadcount);
                          setActiveLogType("edit_headcount");
                        }}
                        className="py-2 text-[10px] font-black text-rose-700 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        Adjust
                      </button>
                      <button
                        onClick={() => {
                          setSelectedBatch(b);
                          setSellHenForm({
                            ...sellHenForm,
                            quantity: b.currentHeadcount,
                            pricePerBird: b.currentMarketPricePerBird
                          });
                          setActiveLogType("sell_hen");
                        }}
                        className="py-2 text-[10px] font-black text-red-700 hover:bg-red-100 rounded-xl transition-colors cursor-pointer text-center"
                      >
                        Sell Hens
                      </button>
                    </>
                  ) : (
                    <div className="col-span-3 text-center py-2 text-[10px] font-bold text-slate-400">
                      Layer cycle completed
                    </div>
                  )}

                  {/* P&L Analysis & Delete Row */}
                  <div className="col-span-3 flex items-center justify-between border-t border-slate-100 pt-2 mt-1 gap-2">
                    <button
                      onClick={() => {
                        setSelectedBatch(b);
                        setActiveLogType("p_and_l");
                      }}
                      className="text-[10px] font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <PieChart size={12} />
                      Cost Breakdown & P&L
                    </button>
                    <button
                      onClick={() => {
                        if (confirm("Are you sure you want to delete this layer batch? All underlying records will be deleted.")) {
                          onDeleteBatch(b.id);
                        }
                      }}
                      className="text-[9px] font-bold text-red-400 hover:text-red-600 cursor-pointer"
                    >
                      Delete Batch
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* REGISTRATION WIZARD DIALOG (2-Step) */}
      {isRegWizardOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden flex flex-col shadow-2xl border border-slate-100 animate-fade-in">
            {/* Header */}
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
              <div>
                <h3 className="font-extrabold text-slate-900 text-sm">Register Layer Batch</h3>
                <p className="text-[10px] text-slate-400 font-bold">Step {wizardStep} of 2</p>
              </div>
              <button onClick={() => setIsRegWizardOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X size={18} />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 space-y-4">
              {wizardStep === 1 ? (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Flock Breed</label>
                      <select
                        value={newBatch.breed}
                        onChange={(e) => setNewBatch({ ...newBatch, breed: e.target.value })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      >
                        <option>Ross 308</option>
                        <option>Cobb 500</option>
                        <option>Sasso</option>
                        <option>Boschveld</option>
                        <option>Local/Village</option>
                        <option>Quails</option>
                        <option>Geese</option>
                        <option>Ducks</option>
                        <option>Guinea Fowls</option>
                        <option>Other-custom</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Acquisition Type</label>
                      <div className="flex gap-2 mt-1">
                        <button
                          onClick={() => setNewBatch({ ...newBatch, acquisitionType: "day_old" })}
                          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                            newBatch.acquisitionType === "day_old" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-500"
                          }`}
                        >
                          Day-old Chicks
                        </button>
                        <button
                          onClick={() => setNewBatch({ ...newBatch, acquisitionType: "pullet" })}
                          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                            newBatch.acquisitionType === "pullet" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-500"
                          }`}
                        >
                          Point of Lay Pullets
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Date Acquired</label>
                      <input
                        type="date"
                        value={newBatch.dateAcquired}
                        onChange={(e) => setNewBatch({ ...newBatch, dateAcquired: e.target.value })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Supplier Source</label>
                        <button
                          type="button"
                          onClick={() => setShowSupplierModal(true)}
                          className="text-[10px] font-black text-emerald-600 hover:text-emerald-700 underline cursor-pointer"
                        >
                          + Register Supplier
                        </button>
                      </div>
                      <select
                        value={newBatch.source}
                        onChange={(e) => setNewBatch({ ...newBatch, source: e.target.value })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      >
                        <option value="">Select Layer / Pullet Supplier...</option>
                        <option>Hybrid Poultry Farm (Z) Limited</option>
                        <option>Zamhatch</option>
                        <option>Mega (Quantum Foods Zambia)</option>
                        <option>Ross Breeders Zambia</option>
                        <option>Mutanda Farms</option>
                        <option>Goldenlay</option>
                        <option>Farm Select</option>
                        {suppliers.map(s => (
                          <option key={s.id} value={s.name}>{s.name} ({s.category || "Supplier"})</option>
                        ))}
                        <option>Other (Custom)</option>
                      </select>
                    </div>
                  </div>

                  {newBatch.source === "Other (Custom)" && (
                    <input
                      type="text"
                      placeholder="Enter custom supplier name"
                      value={newBatch.customSource}
                      onChange={(e) => setNewBatch({ ...newBatch, customSource: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600 animate-slide-down"
                    />
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Initial Headcount</label>
                      <input
                        type="number"
                        value={newBatch.initialHeadcount}
                        onChange={(e) => setNewBatch({ ...newBatch, initialHeadcount: Math.max(1, Number(e.target.value)) })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Cost per Bird ({currencySymbol})</label>
                      <input
                        type="number"
                        step="0.5"
                        value={newBatch.acquisitionCostPerBird}
                        onChange={(e) => setNewBatch({ ...newBatch, acquisitionCostPerBird: Math.max(0, Number(e.target.value)) })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Spent Hen Market Price ({currencySymbol})</label>
                      <input
                        type="number"
                        step="0.5"
                        value={newBatch.currentMarketPricePerBird}
                        onChange={(e) => setNewBatch({ ...newBatch, currentMarketPricePerBird: Math.max(0, Number(e.target.value)) })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Point-of-Lay Age (Weeks)</label>
                      <input
                        type="number"
                        value={newBatch.expectedLayAgeWeeks}
                        onChange={(e) => setNewBatch({ ...newBatch, expectedLayAgeWeeks: Math.max(1, Number(e.target.value)) })}
                        className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold focus:outline-emerald-600"
                      />
                    </div>
                  </div>

                  <div className="bg-sky-50 rounded-2xl p-4 border border-sky-100 text-[11px] text-sky-800 space-y-1">
                    <strong className="font-extrabold flex items-center gap-1">
                      <Sparkles size={14} /> Prepopulated Layer Vaccine schedule
                    </strong>
                    <p className="font-medium">
                      Mabala registers automatic calendar triggers for Day-1 Marek's, Day 10 Newcastle, and Day 40 Fowl Pox on the notification suite.
                    </p>
                  </div>
                </>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-between gap-3">
              {wizardStep === 2 && (
                <button
                  onClick={() => setWizardStep(1)}
                  className="px-4 py-2 border border-slate-200 text-slate-500 rounded-xl text-xs font-bold bg-white hover:bg-slate-50 transition-all cursor-pointer"
                >
                  Previous
                </button>
              )}
              <div className="flex-grow"></div>
              {wizardStep === 1 ? (
                <button
                  onClick={handleWizardNext}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md transition-all flex items-center gap-1 cursor-pointer"
                >
                  Next Step <ChevronRight size={14} />
                </button>
              ) : (
                <button
                  onClick={handleCreateBatch}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md transition-all cursor-pointer"
                >
                  Complete Registration
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* DAILY FEED LOG DIALOG */}
      {activeLogType === "feed" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Log Daily Feed Mash intake</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Feed Log Date</label>
                <input
                  type="date"
                  value={feedForm.date}
                  onChange={(e) => setFeedForm({ ...feedForm, date: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Mash Type</label>
                  <select
                    value={feedForm.feedType}
                    onChange={(e) => setFeedForm({ ...feedForm, feedType: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  >
                    <option>Chick Mash</option>
                    <option>Grower Mash</option>
                    <option>Layer Mash</option>
                    <option>Custom Formulation</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Quantity Fed (Kg)</label>
                  <input
                    type="number"
                    value={feedForm.quantityKg}
                    onChange={(e) => setFeedForm({ ...feedForm, quantityKg: Math.max(1, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Feed cost ({currencySymbol})</label>
                <input
                  type="number"
                  value={feedForm.cost}
                  onChange={(e) => setFeedForm({ ...feedForm, cost: Math.max(0, Number(e.target.value)) })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">Fed By (Operator)</label>
                {employees && employees.length > 0 ? (
                  <select
                    value={feedForm.fedBy}
                    onChange={(e) => setFeedForm({ ...feedForm, fedBy: e.target.value })}
                    required
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white font-bold text-slate-700"
                  >
                    <option value="">-- Select Employee --</option>
                    {employees.map((emp: any) => (
                      <option key={emp.id} value={emp.name}>
                        {emp.name} ({emp.role})
                      </option>
                    ))}
                  </select>
                ) : (
                  <input type="text" value={feedForm.fedBy} onChange={(e) => setFeedForm({ ...feedForm, fedBy: e.target.value })} required placeholder="e.g. S. Phiri" className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold" />
                )}
              </div>
            </div>

            <button
              onClick={handleLogFeed}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Post Feed Mash Expense
            </button>
          </div>
        </div>
      )}

      {/* HEALTH EVENT / TREATMENT DIALOG */}
      {activeLogType === "health" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Log Layer Vaccine / Treatment</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Event Type</label>
                  <select
                    value={healthForm.type}
                    onChange={(e) => setHealthForm({ ...healthForm, type: e.target.value as any })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  >
                    <option value="vaccination">Vaccination</option>
                    <option value="treatment">Treatment / Ad-Hoc</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Date</label>
                  <input
                    type="date"
                    value={healthForm.date}
                    onChange={(e) => setHealthForm({ ...healthForm, date: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Product / Vaccine Name</label>
                <input
                  type="text"
                  value={healthForm.product}
                  onChange={(e) => setHealthForm({ ...healthForm, product: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Cost ({currencySymbol})</label>
                <input
                  type="number"
                  value={healthForm.cost}
                  onChange={(e) => setHealthForm({ ...healthForm, cost: Math.max(0, Number(e.target.value)) })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">Administered By (Operator/Vet)</label>
                {employees && employees.length > 0 ? (
                  <select
                    value={healthForm.administeredBy}
                    onChange={(e) => setHealthForm({ ...healthForm, administeredBy: e.target.value })}
                    required
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white font-bold text-slate-700"
                  >
                    <option value="">-- Select Employee --</option>
                    {employees.map((emp: any) => (
                      <option key={emp.id} value={emp.name}>
                        {emp.name} ({emp.role})
                      </option>
                    ))}
                  </select>
                ) : (
                  <input type="text" value={healthForm.administeredBy} onChange={(e) => setHealthForm({ ...healthForm, administeredBy: e.target.value })} required placeholder="e.g. S. Phiri" className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold" />
                )}
              </div>
            </div>

            <button
              onClick={handleLogHealth}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Post Health Event Voucher
            </button>
          </div>
        </div>
      )}

      {/* DAILY MORTALITY DIALOG */}
      {activeLogType === "mortality" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Log Daily flock mortality</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Mortality Date</label>
                  <input
                    type="date"
                    value={mortalityForm.date}
                    onChange={(e) => setMortalityForm({ ...mortalityForm, date: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Number Dead</label>
                  <input
                    type="number"
                    value={mortalityForm.count}
                    onChange={(e) => setMortalityForm({ ...mortalityForm, count: Math.max(1, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Cause of Mortality</label>
                <select
                  value={mortalityForm.cause}
                  onChange={(e) => setMortalityForm({ ...mortalityForm, cause: e.target.value as any })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                >
                  <option>Disease</option>
                  <option>Heat Stress</option>
                  <option>Predation</option>
                  <option>Culled</option>
                  <option>Other</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleLogMortality}
              className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Post Loss and Reduce headcount
            </button>
          </div>
        </div>
      )}

      {/* DAILY EGG COLLECTION DIALOG */}
      {activeLogType === "collect" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Log Daily Egg Collection</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Collection Date</label>
                  <input
                    type="date"
                    value={collectForm.date}
                    onChange={(e) => setCollectForm({ ...collectForm, date: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Broken / Cracked eggs</label>
                  <input
                    type="number"
                    value={collectForm.brokenCount}
                    onChange={(e) => setCollectForm({ ...collectForm, brokenCount: Math.max(0, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              </div>

              <div className="bg-slate-50 p-2.5 rounded-2xl flex justify-between items-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Sort Collection by Grade?</span>
                <button
                  onClick={() => setCollectForm({ ...collectForm, useGrades: !collectForm.useGrades })}
                  className={`px-3 py-1 rounded-lg text-[10px] font-black transition-all ${
                    collectForm.useGrades ? "bg-slate-900 text-white" : "bg-white border border-slate-200 text-slate-500"
                  }`}
                >
                  {collectForm.useGrades ? "Grades Active" : "Ungraded Total"}
                </button>
              </div>

              {collectForm.useGrades ? (
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block text-center uppercase">Large</label>
                    <input
                      type="number"
                      value={collectForm.large}
                      onChange={(e) => setCollectForm({ ...collectForm, large: Math.max(0, Number(e.target.value)) })}
                      className="w-full mt-1 px-2 py-1.5 rounded-lg bg-slate-50 border border-slate-150 text-xs text-center font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block text-center uppercase">Medium</label>
                    <input
                      type="number"
                      value={collectForm.medium}
                      onChange={(e) => setCollectForm({ ...collectForm, medium: Math.max(0, Number(e.target.value)) })}
                      className="w-full mt-1 px-2 py-1.5 rounded-lg bg-slate-50 border border-slate-150 text-xs text-center font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block text-center uppercase">Small</label>
                    <input
                      type="number"
                      value={collectForm.small}
                      onChange={(e) => setCollectForm({ ...collectForm, small: Math.max(0, Number(e.target.value)) })}
                      className="w-full mt-1 px-2 py-1.5 rounded-lg bg-slate-50 border border-slate-150 text-xs text-center font-bold"
                    />
                  </div>
                </div>
              ) : (
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Ungraded Total Egg Count</label>
                  <input
                    type="number"
                    value={collectForm.ungraded}
                    onChange={(e) => setCollectForm({ ...collectForm, ungraded: Math.max(0, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              )}
            </div>

            <button
              onClick={handleLogCollect}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Post Daily Collection & Update Stock
            </button>
          </div>
        </div>
      )}

      {/* EGG SALES DIALOG */}
      {activeLogType === "eggsale" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Sell Layer Flock Table Eggs</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Grade to Sell</label>
                  <select
                    value={eggSaleForm.grade}
                    onChange={(e) => setEggSaleForm({ ...eggSaleForm, grade: e.target.value as any })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  >
                    <option value="large">Large ({runningEggStock.large} available)</option>
                    <option value="medium">Medium ({runningEggStock.medium} available)</option>
                    <option value="small">Small ({runningEggStock.small} available)</option>
                    <option value="ungraded">Ungraded ({runningEggStock.ungraded} available)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Date of Sale</label>
                  <input
                    type="date"
                    value={eggSaleForm.date}
                    onChange={(e) => setEggSaleForm({ ...eggSaleForm, date: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Buyer Name</label>
                <input
                  type="text"
                  value={eggSaleForm.buyerName}
                  onChange={(e) => setEggSaleForm({ ...eggSaleForm, buyerName: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>

              <div className="bg-slate-50 p-2.5 rounded-2xl flex justify-between items-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase font-mono">Sale unit:</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => setEggSaleForm({ ...eggSaleForm, sellUnit: "tray", pricePerUnit: 45 })}
                    className={`px-3 py-1 rounded-lg text-[10px] font-black transition-all ${
                      eggSaleForm.sellUnit === "tray" ? "bg-slate-900 text-white" : "bg-white border border-slate-200 text-slate-500"
                    }`}
                  >
                    Trays (30 eggs)
                  </button>
                  <button
                    onClick={() => setEggSaleForm({ ...eggSaleForm, sellUnit: "egg", pricePerUnit: 1.5 })}
                    className={`px-3 py-1 rounded-lg text-[10px] font-black transition-all ${
                      eggSaleForm.sellUnit === "egg" ? "bg-slate-900 text-white" : "bg-white border border-slate-200 text-slate-500"
                    }`}
                  >
                    Individual Eggs
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Quantity to Sell</label>
                  <input
                    type="number"
                    value={eggSaleForm.quantity}
                    onChange={(e) => setEggSaleForm({ ...eggSaleForm, quantity: Math.max(1, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Price ({currencySymbol}) per {eggSaleForm.sellUnit}</label>
                  <input
                    type="number"
                    step="0.05"
                    value={eggSaleForm.pricePerUnit}
                    onChange={(e) => setEggSaleForm({ ...eggSaleForm, pricePerUnit: Math.max(0.1, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-1">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Payment Mode</label>
                  <select
                    value={eggSaleForm.paymentMethod}
                    onChange={(e) => setEggSaleForm({ ...eggSaleForm, paymentMethod: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  >
                    <option>Cash</option>
                    <option>Mobile Money</option>
                    <option>Bank Transfer</option>
                    <option>On Credit</option>
                  </select>
                </div>

                <div className="bg-emerald-50 p-2 text-center rounded-2xl flex flex-col justify-center">
                  <span className="text-[8px] font-black text-emerald-800 uppercase tracking-widest block">Total Income</span>
                  <strong className="text-emerald-700 text-sm font-black mt-0.5">
                    {currencySymbol}{(eggSaleForm.quantity * eggSaleForm.pricePerUnit).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </strong>
                </div>
              </div>
            </div>

            <button
              onClick={handleLogEggSale}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Post Sale & Print Receipt
            </button>
          </div>
        </div>
      )}

      {/* EDIT PRICE DIALOG */}
      {activeLogType === "edit_price" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Spent Hen Valuation Price</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Market Price per Spent Hen ({currencySymbol})</label>
              <input
                type="number"
                step="0.5"
                value={marketPriceForm.price}
                onChange={(e) => setMarketPriceForm({ price: Math.max(0, Number(e.target.value)) })}
                className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
              />
            </div>

            <button
              onClick={handleUpdatePrice}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Update Spent Hen Price
            </button>
          </div>
        </div>
      )}

      {/* EDIT HEADCOUNT DIALOG */}
      {activeLogType === "edit_headcount" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Adjust Layer Headcount</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Adjust Headcount (Birds)</label>
              <input
                type="number"
                value={editHeadcountValue}
                onChange={(e) => setEditHeadcountValue(Math.max(0, Number(e.target.value)))}
                className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-mono font-bold"
              />
              <p className="text-[9px] text-slate-400 mt-1">This will directly edit the recorded headcount of birds in the batch.</p>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Reason for Adjustment</label>
              <select
                value={editHeadcountReason}
                onChange={(e) => setEditHeadcountReason(e.target.value)}
                className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs outline-hidden bg-white font-medium text-slate-700"
              >
                <option value="Manual audit correction">Manual audit correction</option>
                <option value="Transfer to other farm module">Transfer to other farm module</option>
                <option value="Gift or donation given">Gift or donation given</option>
                <option value="Unrecorded mortality correction">Unrecorded mortality correction</option>
                <option value="Unrecorded sales correction">Unrecorded sales correction</option>
              </select>
            </div>

            <button
              onClick={handleEditHeadcount}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Adjust Headcount
            </button>
          </div>
        </div>
      )}

      {/* SELL SPENT HEN DIALOG */}
      {activeLogType === "sell_hen" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-50 pb-3">
              <h3 className="font-black text-slate-900 text-sm">Sell Spent Hen flock disposal</h3>
              <button onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Disposal Date</label>
                  <input
                    type="date"
                    value={sellHenForm.date}
                    onChange={(e) => setSellHenForm({ ...sellHenForm, date: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Quantity to Sell</label>
                  <input
                    type="number"
                    value={sellHenForm.quantity}
                    onChange={(e) => setSellHenForm({ ...sellHenForm, quantity: Math.min(selectedBatch.currentHeadcount, Math.max(1, Number(e.target.value))) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                  <span className="text-[9px] text-slate-400 font-bold">Max available: {selectedBatch.currentHeadcount}</span>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Buyer Name</label>
                <input
                  type="text"
                  value={sellHenForm.buyerName}
                  onChange={(e) => setSellHenForm({ ...sellHenForm, buyerName: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Price per Spent Hen ({currencySymbol})</label>
                  <input
                    type="number"
                    value={sellHenForm.pricePerBird}
                    onChange={(e) => setSellHenForm({ ...sellHenForm, pricePerBird: Math.max(1, Number(e.target.value)) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Payment Method</label>
                  <select
                    value={sellHenForm.paymentMethod}
                    onChange={(e) => setSellHenForm({ ...sellHenForm, paymentMethod: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-150 text-xs font-semibold"
                  >
                    <option>Cash</option>
                    <option>Mobile Money</option>
                    <option>Bank Transfer</option>
                  </select>
                </div>
              </div>

              <div className="bg-emerald-50 p-3 rounded-2xl text-center">
                <span className="text-[9px] font-black text-emerald-800 uppercase tracking-widest block">Disposal Revenue Total</span>
                <strong className="text-emerald-700 text-base font-black mt-0.5">
                  {currencySymbol}{(sellHenForm.quantity * sellHenForm.pricePerBird).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </strong>
              </div>
            </div>

            <button
              onClick={handleSellSpentHens}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-sm"
            >
              Post Spent Hen Disposal Sale
            </button>
          </div>
        </div>
      )}

      {/* INDIVIDUAL LAYER BATCH P&L & COST BREAKDOWN MODAL */}
      {activeLogType === "p_and_l" && selectedBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto animate-fade-in">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl border border-slate-100 text-slate-800">
            {/* Header */}
            <div className="p-5 bg-slate-950 text-white flex justify-between items-center shrink-0">
              <div>
                <span className="text-[9px] tracking-widest uppercase font-black text-emerald-400">Layer Financial & Cost Center</span>
                <h3 className="text-base font-black uppercase tracking-tight flex items-center gap-2">
                  {selectedBatch.batchId} - {selectedBatch.batchName}
                </h3>
              </div>
              <button 
                onClick={() => { setActiveLogType(null); setSelectedBatch(null); }} 
                className="p-1 px-3 py-1.5 text-xs bg-white/10 hover:bg-white/20 hover:text-white rounded-xl font-bold cursor-pointer transition-all border-none"
              >
                ✕ Close
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
              {/* Detailed Cost Breakdown Split (Feed, Medication, Labour, Misc) */}
              <BatchCostBreakdownSummary
                batch={selectedBatch}
                currencySymbol={currencySymbol}
                expenses={expenses}
                allBatches={batches}
                compact={false}
                showTransactionsList={true}
              />

              {/* Profit & Loss Statement */}
              {(() => {
                const eggRevenue = (selectedBatch.eggSales || []).reduce((sum, s) => sum + s.totalRevenue, 0);
                const spentHenRevenue = selectedBatch.salesLogs.reduce((sum, s) => sum + s.amount, 0);
                const totalRevenue = eggRevenue + spentHenRevenue;

                const acquisitionCost = selectedBatch.acquisitionCostTotal;
                const feedCost = selectedBatch.cumulativeFeedCost;
                const healthCost = selectedBatch.cumulativeHealthCost;
                const mortalityLoss = selectedBatch.cumulativeMortalityLoss;
                const totalExpenses = acquisitionCost + feedCost + healthCost + mortalityLoss;
                const netProfit = totalRevenue - totalExpenses;

                const totalEggsCollected = (selectedBatch.eggCollections || []).reduce((sum, c) => sum + c.totalCollected, 0);
                const costPerEgg = totalEggsCollected > 0 ? totalExpenses / totalEggsCollected : 0;

                return (
                  <div className="space-y-4 text-xs">
                    <h4 className="text-xs font-black uppercase text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-1.5">
                      <DollarSign size={14} className="text-emerald-600" />
                      Flock Profit & Loss Summary
                    </h4>

                    {/* Profit Banner */}
                    <div className={`p-4 rounded-2xl flex justify-between items-center ${
                      netProfit >= 0 ? "bg-emerald-50 text-emerald-800 border border-emerald-100" : "bg-red-50 text-red-800 border border-red-100"
                    }`}>
                      <div>
                        <span className="text-[9px] font-black uppercase tracking-wider block">Net Profit / Loss</span>
                        <strong className="text-xl font-black">
                          {netProfit >= 0 ? "+" : ""}
                          {currencySymbol}{netProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </strong>
                      </div>
                      <span className="text-[10px] font-bold">
                        {netProfit >= 0 ? "Profit on Egg Cycle" : "Loss on Egg Cycle"}
                      </span>
                    </div>

                    {/* Financial items */}
                    <div className="border border-slate-100 rounded-2xl overflow-hidden bg-slate-50/50">
                      <div className="bg-slate-50 p-3 font-bold text-slate-700 text-[10px] uppercase tracking-wider border-b border-slate-100">
                        Revenues
                      </div>
                      <div className="p-3 space-y-2 border-b border-slate-50 font-medium bg-white">
                        <div className="flex justify-between">
                          <span>Egg Sales Revenue:</span>
                          <strong className="text-slate-800 font-bold">{currencySymbol}{eggRevenue.toLocaleString()}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span>Spent Hen Sales Revenue:</span>
                          <strong className="text-slate-800 font-bold">{currencySymbol}{spentHenRevenue.toLocaleString()}</strong>
                        </div>
                        <div className="flex justify-between border-t border-slate-100 pt-2 font-black text-slate-800">
                          <span>Total Combined Income:</span>
                          <span>{currencySymbol}{totalRevenue.toLocaleString()}</span>
                        </div>
                      </div>

                      <div className="bg-slate-50 p-3 font-bold text-slate-700 text-[10px] uppercase tracking-wider border-b border-slate-100">
                        Expenses (Dr COA Accounts)
                      </div>
                      <div className="p-3 space-y-2 font-medium text-slate-600 bg-white">
                        <div className="flex justify-between">
                          <span>Acquisition Cost:</span>
                          <span>{currencySymbol}{acquisitionCost.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Feed Purchases mash:</span>
                          <span>{currencySymbol}{feedCost.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Veterinary / Vaccine Cost:</span>
                          <span>{currencySymbol}{healthCost.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-red-600 font-bold">
                          <span>Mortality Losses:</span>
                          <span>{currencySymbol}{mortalityLoss.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between border-t border-slate-100 pt-2 font-black text-slate-800">
                          <span>Total Recorded Expenses:</span>
                          <span>{currencySymbol}{totalExpenses.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    {/* Performance Indicators */}
                    <div className="bg-slate-50 p-3 rounded-2xl grid grid-cols-2 gap-4 text-center border border-slate-100">
                      <div>
                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Total Eggs Collected</span>
                        <strong className="text-slate-800 text-sm mt-0.5 block">{totalEggsCollected.toLocaleString()}</strong>
                      </div>
                      <div>
                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Cost per Egg</span>
                        <strong className="text-slate-850 text-sm mt-0.5 block">
                          {currencySymbol}{costPerEgg.toFixed(2)}
                        </strong>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-slate-50 flex justify-end">
              <button 
                onClick={() => { setActiveLogType(null); setSelectedBatch(null); }}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}

      {/* UNIFIED SUPPLIER REGISTRATION MODAL */}
      <UnifiedSupplierModal
        isOpen={showSupplierModal}
        onClose={() => setShowSupplierModal(false)}
        initialCategory="Chicks & Hatchery"
        currencySymbol={currencySymbol}
        farmId={activeFarm?.id || "default-farm"}
        onSaveSupplier={(newSup) => {
          if (onAddSupplier) {
            onAddSupplier(newSup);
          }
          setNewBatch(prev => ({ ...prev, source: newSup.name }));
          setShowSupplierModal(false);
        }}
      />
    </div>
  );
}

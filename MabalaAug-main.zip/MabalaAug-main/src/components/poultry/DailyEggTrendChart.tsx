import React, { useMemo } from "react";
import { ResponsiveContainer, ComposedChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { Egg, TrendingUp, Award, Layers } from "lucide-react";
import { EggCollection } from "./types";

interface DailyEggTrendChartProps {
  eggCollections?: EggCollection[];
  batchName?: string;
}

export default function DailyEggTrendChart({
  eggCollections = [],
  batchName
}: DailyEggTrendChartProps) {
  const { chartData, avgDailyVolume, avgGradeARatio, avgGradeBRatio, maxDayVolume } = useMemo(() => {
    // Generate dates for the last 30 days
    const days: { [dateStr: string]: { dateStr: string; label: string; total: number; gradeA: number; gradeB: number; broken: number } } = {};
    const now = new Date();

    for (let i = 29; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateKey = d.toISOString().split("T")[0];
      const label = d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
      days[dateKey] = { dateStr: dateKey, label, total: 0, gradeA: 0, gradeB: 0, broken: 0 };
    }

    // Populate actual collection data
    (eggCollections || []).forEach(c => {
      if (!c.date) return;
      const key = c.date.split("T")[0];
      if (days[key]) {
        days[key].total += c.totalCollected || 0;
        days[key].broken += c.brokenCount || 0;
        if (c.useGrades) {
          days[key].gradeA += (c.large || 0) + (c.ungraded || 0);
          days[key].gradeB += (c.medium || 0) + (c.small || 0);
        } else {
          const net = Math.max(0, (c.totalCollected || 0) - (c.brokenCount || 0));
          days[key].gradeA += net;
        }
      }
    });

    let totalVolumeSum = 0;
    let daysWithData = 0;
    let gradeASum = 0;
    let gradeBSum = 0;
    let maxVol = 0;

    const data = Object.values(days).map(d => {
      const vol = d.total;
      totalVolumeSum += vol;
      if (vol > 0) daysWithData++;
      if (vol > maxVol) maxVol = vol;

      const gradeAPct = vol > 0 ? Number(((d.gradeA / vol) * 100).toFixed(1)) : 0;
      const gradeBPct = vol > 0 ? Number(((d.gradeB / vol) * 100).toFixed(1)) : 0;

      gradeASum += d.gradeA;
      gradeBSum += d.gradeB;

      return {
        label: d.label,
        dateKey: d.dateStr,
        productionVolume: vol,
        gradeARatio: gradeAPct,
        gradeBRatio: gradeBPct,
        gradeACount: d.gradeA,
        gradeBCount: d.gradeB,
      };
    });

    const avgVol = daysWithData > 0 ? Math.round(totalVolumeSum / 30) : 0;
    const avgA = totalVolumeSum > 0 ? Number(((gradeASum / totalVolumeSum) * 100).toFixed(1)) : 0;
    const avgB = totalVolumeSum > 0 ? Number(((gradeBSum / totalVolumeSum) * 100).toFixed(1)) : 0;

    return {
      chartData: data,
      avgDailyVolume: avgVol,
      avgGradeARatio: avgA,
      avgGradeBRatio: avgB,
      maxDayVolume: maxVol,
    };
  }, [eggCollections]);

  return (
    <div className="bg-slate-900 text-white border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl font-sans">
      {/* Header & Badges */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <Egg className="w-4 h-4 text-amber-400" />
            <h4 className="font-extrabold text-xs uppercase tracking-wider text-slate-100">
              30-Day Daily Egg Production & Quality Ratio Trend
            </h4>
          </div>
          <p className="text-[11px] text-slate-400 font-medium mt-0.5">
            Daily production volume (eggs/day) superimposed with Grade A vs Grade B quality split % {batchName ? `for ${batchName}` : ""}.
          </p>
        </div>

        {/* Quick KPI stats pill */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="px-2.5 py-1 bg-slate-800 border border-slate-700 rounded-xl text-[10px]">
            <span className="text-slate-400 block font-bold uppercase text-[8.5px]">30D Avg Output</span>
            <span className="font-mono font-black text-amber-400">{avgDailyVolume.toLocaleString()} eggs/day</span>
          </div>
          <div className="px-2.5 py-1 bg-slate-800 border border-slate-700 rounded-xl text-[10px]">
            <span className="text-slate-400 block font-bold uppercase text-[8.5px]">Grade A Ratio</span>
            <span className="font-mono font-black text-emerald-400">{avgGradeARatio}%</span>
          </div>
          <div className="px-2.5 py-1 bg-slate-800 border border-slate-700 rounded-xl text-[10px]">
            <span className="text-slate-400 block font-bold uppercase text-[8.5px]">Peak 1-Day Vol</span>
            <span className="font-mono font-black text-sky-400">{maxDayVolume.toLocaleString()} eggs</span>
          </div>
        </div>
      </div>

      {/* Chart Canvas */}
      <div className="w-full h-56 pt-2">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis
              dataKey="label"
              stroke="#64748b"
              fontSize={9}
              tickLine={false}
              interval={4}
            />
            {/* Left Y Axis: Production Volume */}
            <YAxis
              yAxisId="volume"
              stroke="#0284c7"
              fontSize={9}
              tickLine={false}
              axisLine={false}
            />
            {/* Right Y Axis: Ratio Percentage */}
            <YAxis
              yAxisId="ratio"
              orientation="right"
              domain={[0, 100]}
              stroke="#10b981"
              fontSize={9}
              tickLine={false}
              axisLine={false}
              unit="%"
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#0f172a",
                borderColor: "#334155",
                borderRadius: "12px",
                fontSize: "10.5px",
                color: "#ffffff",
                boxShadow: "0 10px 15px -3px rgba(0,0,0,0.5)"
              }}
              formatter={(value: any, name: string) => {
                if (name === "Daily Production Volume") return [`${value.toLocaleString()} eggs`, name];
                if (name === "Grade A Ratio (%)" || name === "Grade B Ratio (%)") return [`${value}%`, name];
                return [value, name];
              }}
            />
            <Legend
              verticalAlign="top"
              height={30}
              iconSize={8}
              wrapperStyle={{ fontSize: "10px", color: "#94a3b8" }}
            />
            {/* Daily Volume Line */}
            <Line
              yAxisId="volume"
              type="monotone"
              dataKey="productionVolume"
              name="Daily Production Volume"
              stroke="#38bdf8"
              strokeWidth={3}
              dot={{ r: 2, fill: "#38bdf8" }}
              activeDot={{ r: 5 }}
            />
            {/* Grade A Ratio Line */}
            <Line
              yAxisId="ratio"
              type="monotone"
              dataKey="gradeARatio"
              name="Grade A Ratio (%)"
              stroke="#34d399"
              strokeWidth={2}
              strokeDasharray="4 4"
              dot={false}
            />
            {/* Grade B Ratio Line */}
            <Line
              yAxisId="ratio"
              type="monotone"
              dataKey="gradeBRatio"
              name="Grade B Ratio (%)"
              stroke="#818cf8"
              strokeWidth={2}
              strokeDasharray="2 2"
              dot={false}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

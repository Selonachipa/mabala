import React from "react";
import { X, Printer } from "lucide-react";
import MabalaLogo from "../MabalaLogo";

interface PrintableDocumentProps {
  isOpen: boolean;
  onClose: () => void;
  type: "certificate" | "receipt";
  data: {
    farmName: string;
    date: string;
    reference: string;
    buyerName: string;
    quantity: number;
    pricePerUnit: number;
    totalAmount: number;
    paymentMethod: string;
    currencySymbol: string;
    // Certificate specific
    breed?: string;
    weightKg?: number;
    chargeType?: "PER_BIRD" | "PER_KG";
    // Receipt specific
    gradeBreakdown?: { large?: number; medium?: number; small?: number; ungraded?: number };
    sellUnit?: "tray" | "egg";
  };
}

export default function PrintableDocument({ isOpen, onClose, type, data }: PrintableDocumentProps) {
  if (!isOpen) return null;

  const title = type === "certificate" ? "BATCH SALE CERTIFICATE" : "EGG SALE RECEIPT";
  const numTrays = data.sellUnit === "tray" ? data.quantity : Math.floor(data.quantity / 30);
  const remEggs = data.sellUnit === "tray" ? 0 : data.quantity % 30;

  // Simple pure SVG QR Code generator (to avoid introducing bulky dependencies)
  // Generates a mock QR pattern using a neat grid of SVG squares
  const generateMockQRCode = (text: string) => {
    const size = 15;
    const squares: any[] = [];
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
      hash = text.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        // Always fill borders and corners for mock QR look
        const isCorner = (r < 4 && c < 4) || (r < 4 && c >= size - 4) || (r >= size - 4 && c < 4);
        const isCornerInner = (r === 1 && c === 1) || (r === 1 && c === size - 2) || (r === size - 2 && c === 1);
        
        let filled = false;
        if (isCorner) {
          filled = !isCornerInner;
        } else {
          const pseudoVal = Math.sin(hash + r * 13 + c * 37);
          filled = pseudoVal > 0.1;
        }

        if (filled) {
          squares.push(
            <rect
              key={`${r}-${c}`}
              x={c * 6}
              y={r * 6}
              width={6}
              height={6}
              fill="#1e293b"
            />
          );
        }
      }
    }

    return (
      <svg width="90" height="90" viewBox="0 0 90 90" className="mx-auto">
        {squares}
      </svg>
    );
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto" id="printable-doc-overlay">
      <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden flex flex-col shadow-2xl border border-slate-100 print:shadow-none print:border-none my-8">
        {/* Actions bar (hidden during print) */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50 print:hidden">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            Document Viewer (Ready to Print)
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-sm transition-all cursor-pointer"
            >
              <Printer size={14} />
              Print / Save PDF
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-200 text-slate-400 hover:text-slate-600 rounded-xl transition-all cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Printable Area */}
        <div className="p-8 md:p-12 space-y-8 bg-white text-slate-800 print:p-0" id="document-print-area">
          {/* Farm Header */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-6">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <MabalaLogo className="h-8 w-auto text-emerald-600" />
                <span className="text-lg font-black text-slate-900 tracking-tight">Mabala Farm Portal</span>
              </div>
              <p className="text-xs font-bold text-emerald-600 uppercase tracking-widest">{data.farmName || "Mabala Registered Farm"}</p>
              <p className="text-[10px] text-slate-400 font-semibold leading-normal">
                Agricultural Ledger and Compliance Network<br />
                Republic of Zambia
              </p>
            </div>
            <div className="text-right space-y-1">
              <span className="inline-block px-3 py-1 bg-slate-100 text-slate-800 rounded-lg text-[9px] font-black uppercase tracking-wider">
                Official Document
              </span>
              <p className="text-xs font-bold text-slate-900 mt-2">{title}</p>
              <p className="text-[10px] text-slate-400 font-bold">No: {data.reference}</p>
            </div>
          </div>

          {/* Document Content Grid */}
          <div className="grid grid-cols-2 gap-y-6 gap-x-8 text-xs pt-2">
            <div>
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-wider mb-1">Date of Transaction</p>
              <p className="font-bold text-slate-800">{new Date(data.date).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-wider mb-1">Buyer Information</p>
              <p className="font-bold text-slate-800">{data.buyerName || "General Walk-in Customer"}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-wider mb-1">Payment Method</p>
              <p className="font-bold text-slate-800">{data.paymentMethod || "Cash (ZMW)"}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-wider mb-1">Document Hash Reference</p>
              <p className="font-mono text-[10px] text-slate-500 break-all">{data.reference}-{Math.floor(Math.random() * 9000 + 1000)}</p>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden mt-6">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[10px] text-slate-400 font-black uppercase tracking-wider">
                  <th className="px-4 py-3">Description</th>
                  <th className="px-4 py-3 text-right">Quantity</th>
                  <th className="px-4 py-3 text-right">Unit Price</th>
                  <th className="px-4 py-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-100 font-semibold text-slate-800">
                  <td className="px-4 py-4 space-y-1">
                    <p className="font-bold">
                      {type === "certificate" 
                        ? `Live Broiler /spent hen bird stock sales (${data.breed || "Commercial Breeding"})`
                        : "Premium-graded fresh layer table eggs"
                      }
                    </p>
                    <p className="text-[10px] text-slate-400 font-medium leading-relaxed">
                      {type === "certificate"
                        ? `Direct poultry flock disposal and weight records. Charge type: ${data.chargeType === "PER_KG" ? "Per Kilogram" : "Per Bird"}`
                        : "Daily collection sorting of fresh poultry table eggs."
                      }
                    </p>
                  </td>
                  <td className="px-4 py-4 text-right font-bold">
                    {type === "certificate"
                      ? `${data.quantity.toLocaleString()} birds`
                      : data.sellUnit === "tray"
                        ? `${data.quantity.toLocaleString()} Trays`
                        : `${data.quantity.toLocaleString()} Eggs`
                    }
                  </td>
                  <td className="px-4 py-4 text-right font-bold">
                    {data.currencySymbol}
                    {data.pricePerUnit.toFixed(2)}
                    {type === "certificate" && data.chargeType === "PER_KG" ? "/kg" : data.sellUnit === "tray" ? "/tray" : "/egg"}
                  </td>
                  <td className="px-4 py-4 text-right font-bold">
                    {data.currencySymbol}{data.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>

                {/* Sub-breakdown if available */}
                {type === "receipt" && data.gradeBreakdown && (
                  <tr className="border-b border-slate-100 bg-slate-50/50 text-[10px] text-slate-500">
                    <td colSpan={4} className="px-4 py-3">
                      <div className="flex items-center gap-4">
                        <span className="font-bold text-slate-600 uppercase tracking-wider">Sorted Grades Sold:</span>
                        {data.gradeBreakdown.large ? <span>Large: <strong>{data.gradeBreakdown.large} eggs</strong></span> : null}
                        {data.gradeBreakdown.medium ? <span>Medium: <strong>{data.gradeBreakdown.medium} eggs</strong></span> : null}
                        {data.gradeBreakdown.small ? <span>Small: <strong>{data.gradeBreakdown.small} eggs</strong></span> : null}
                        {data.gradeBreakdown.ungraded ? <span>Ungraded: <strong>{data.gradeBreakdown.ungraded} eggs</strong></span> : null}
                      </div>
                    </td>
                  </tr>
                )}

                {/* Totals rows */}
                <tr className="font-black text-slate-800">
                  <td colSpan={2} className="px-4 py-3"></td>
                  <td className="px-4 py-3 text-right text-slate-400 uppercase tracking-wider text-[10px]">Grand Total:</td>
                  <td className="px-4 py-3 text-right text-base text-emerald-600">
                    {data.currencySymbol}{data.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Footer Validation block */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 border-t border-slate-200 pt-8 mt-8">
            <div className="space-y-2 text-center sm:text-left">
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-wider">Certification / Verification</p>
              <p className="text-[11px] font-semibold text-slate-600 leading-normal max-w-md">
                This document is a certified copy of the transactions registered on the Mabala Agricultural platform.
                Scan the security barcode to verify compliance, batch traceability, and health record certifications.
              </p>
              <div className="pt-4 flex gap-8 justify-center sm:justify-start">
                <div className="text-center">
                  <div className="w-24 h-0.5 bg-slate-300 mx-auto mb-1"></div>
                  <span className="text-[9px] text-slate-400 font-bold uppercase">Issued By Admin</span>
                </div>
                <div className="text-center">
                  <div className="w-24 h-0.5 bg-slate-300 mx-auto mb-1"></div>
                  <span className="text-[9px] text-slate-400 font-bold uppercase">Buyer Signature</span>
                </div>
              </div>
            </div>
            <div className="flex-shrink-0 text-center border border-slate-100 p-2.5 rounded-2xl bg-slate-50/50">
              {generateMockQRCode(`MABALA-POULTRY-${data.reference}-${data.totalAmount}`)}
              <p className="text-[9px] font-mono text-slate-400 font-bold mt-1.5 uppercase tracking-widest">TRACE_VERIFY</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useMemo } from "react";
import { PoultryBatch } from "./types";
import EggGradeRatioPieChart from "./EggGradeRatioPieChart";
import { Egg, Flame, TrendingUp, Skull, ShoppingCart, DollarSign, ArrowRight, Sprout, AlertTriangle, ShieldAlert } from "lucide-react";
import { ChickenIcon } from "../IconLibrary";
import PreemptiveThermalActionPanel from "./PreemptiveThermalActionPanel";
import { SevereAlert } from "../WeatherWidget";

interface PoultryOverviewProps {
  batches: PoultryBatch[];
  currencySymbol: string;
  onNavigateToBroilers: () => void;
  onNavigateToLayers: () => void;
  onNavigateToVillage: () => void;
  weatherAlerts?: SevereAlert[];
  writeAuditLog?: (action: string, module: string, target: string, details: string) => void;
  onUpdateBatch?: (batch: PoultryBatch) => void;
}

export default function PoultryOverview({
  batches,
  currencySymbol,
  onNavigateToBroilers,
  onNavigateToLayers,
  onNavigateToVillage,
  weatherAlerts = [],
  writeAuditLog,
  onUpdateBatch,
}: PoultryOverviewProps) {
  // 1. Calculations
  const activeBatches = useMemo(() => batches.filter(b => b.status === "active"), [batches]);

  const smartAlerts = useMemo(() => {
    const list: {
      id: string;
      batchName: string;
      batchId: string;
      type: "mortality" | "withdrawal_active" | "withdrawal_cleared";
      title: string;
      details: string;
      level: "critical" | "warning" | "success";
      date: string;
    }[] = [];

    // Use a reference "now" date based on existing logs or real time
    const nowTime = new Date("2026-06-16").getTime();
    const oneWeekMs = 7 * 24 * 60 * 60 * 1000;
    const sevenDaysAgo = nowTime - oneWeekMs;

    batches.forEach(b => {
      if (b.status !== "active") return;

      // 1. Check weekly mortality rate spike > 2%
      const recentMortalities = (b.mortalityLogs || []).reduce((sum, m) => {
        const mTime = new Date(m.date).getTime();
        if (mTime >= sevenDaysAgo && mTime <= nowTime) {
          return sum + m.count;
        }
        return sum;
      }, 0);

      const weeklyMortalityRate = b.initialHeadcount > 0 ? (recentMortalities / b.initialHeadcount) * 100 : 0;
      if (weeklyMortalityRate > 2) {
        list.push({
          id: `mort-${b.id}`,
          batchName: b.batchName,
          batchId: b.batchId,
          type: "mortality",
          title: "Mortality Spike Detected",
          details: `Weekly mortality rate has spiked to ${weeklyMortalityRate.toFixed(1)}% (${recentMortalities} deaths in the last 7 days). Investigate bio-security, water, or ambient temperatures.`,
          level: "critical",
          date: "Last 7 Days"
        });
      }

      // 2. Check withdrawal-period statuses
      (b.healthLogs || []).forEach(h => {
        if (h.withdrawalCloseDate) {
          const closeTime = new Date(h.withdrawalCloseDate).getTime();
          const diffMs = closeTime - nowTime;
          const diffDays = Math.ceil(diffMs / (24 * 60 * 60 * 1000));

          if (diffDays > 0) {
            // Withdrawal active
            list.push({
              id: `with-act-${b.id}-${h.id}`,
              batchName: b.batchName,
              batchId: b.batchId,
              type: "withdrawal_active",
              title: "Active Medical Withdrawal",
              details: `Flock treated with ${h.product}. Meat and eggs must be withheld for ${diffDays} more days (expires ${h.withdrawalCloseDate}) to avoid chemical residues.`,
              level: "critical",
              date: h.withdrawalCloseDate
            });
          } else if (diffDays >= -5) {
            // Recently cleared (within last 5 days)
            list.push({
              id: `with-clr-${b.id}-${h.id}`,
              batchName: b.batchName,
              batchId: b.batchId,
              type: "withdrawal_cleared",
              title: "Medical Withdrawal Cleared",
              details: `Withdrawal period for ${h.product} has successfully expired. Eggs and meat are now officially cleared for commercial harvesting and distribution.`,
              level: "success",
              date: h.withdrawalCloseDate
            });
          }
        }
      });
    });

    return list;
  }, [batches]);

  const totalBroilersHeadcount = useMemo(() => {
    return activeBatches
      .filter(b => b.poultryType === "broiler")
      .reduce((sum, b) => sum + b.currentHeadcount, 0);
  }, [activeBatches]);

  const totalLayersHeadcount = useMemo(() => {
    return activeBatches
      .filter(b => b.poultryType === "layer")
      .reduce((sum, b) => sum + b.currentHeadcount, 0);
  }, [activeBatches]);

  const totalVillageHeadcount = useMemo(() => {
    return activeBatches
      .filter(b => b.poultryType === "village" || (b.poultryType as string) === "indigenous")
      .reduce((sum, b) => sum + b.currentHeadcount, 0);
  }, [activeBatches]);

  const totalPoultryValuation = useMemo(() => {
    return activeBatches.reduce((sum, b) => {
      const val = b.currentHeadcount * b.currentMarketPricePerBird;
      return sum + (isNaN(val) ? 0 : val);
    }, 0);
  }, [activeBatches]);

  // Calculations for THIS MONTH
  const thisMonthMetrics = useMemo(() => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth(); // 0-11

    let eggsCollected = 0;
    let eggRevenue = 0;
    let birdSalesRevenue = 0;
    let mortalityCount = 0;

    batches.forEach(b => {
      // Eggs collected
      if (b.eggCollections) {
        b.eggCollections.forEach(ec => {
          const d = new Date(ec.date);
          if (d.getFullYear() === currentYear && d.getMonth() === currentMonth) {
            eggsCollected += ec.totalCollected;
          }
        });
      }

      // Egg sales
      if (b.eggSales) {
        b.eggSales.forEach(es => {
          const d = new Date(es.date);
          if (d.getFullYear() === currentYear && d.getMonth() === currentMonth) {
            eggRevenue += es.totalRevenue;
          }
        });
      }

      // Bird sales
      if (b.salesLogs) {
        b.salesLogs.forEach(sl => {
          const d = new Date(sl.date);
          if (d.getFullYear() === currentYear && d.getMonth() === currentMonth) {
            birdSalesRevenue += sl.amount;
          }
        });
      }

      // Mortalities
      if (b.mortalityLogs) {
        b.mortalityLogs.forEach(ml => {
          const d = new Date(ml.date);
          if (d.getFullYear() === currentYear && d.getMonth() === currentMonth) {
            mortalityCount += ml.count;
          }
        });
      }
    });

    return {
      eggsCollected,
      eggRevenue,
      birdSalesRevenue,
      mortalityCount,
    };
  }, [batches]);

  return (
    <div className="space-y-6 text-slate-800" id="poultry-overview-container">
      {/* Landing Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <ChickenIcon size={28} className="text-emerald-600" />
            Poultry Module
          </h2>
          <p className="text-xs text-slate-500 font-semibold mt-0.5">
            Overview dashboard and landing screen for Mabala flock operations
          </p>
        </div>
      </div>

      {/* Preemptive Thermal Action Console for Poultry Manager */}
      <PreemptiveThermalActionPanel 
        weatherAlerts={weatherAlerts}
        batches={batches}
        writeAuditLog={writeAuditLog}
        onUpdateBatch={onUpdateBatch}
      />

      {/* Mabala Smart Alerts Section */}
      {smartAlerts.length > 0 && (
        <div className="bg-slate-50 border border-slate-250/60 rounded-3xl p-5 space-y-3.5 animate-fade-in">
          <div className="flex items-center gap-2 text-slate-800">
            <ShieldAlert className="w-5 h-5 text-emerald-600 animate-pulse" />
            <h4 className="text-xs font-black uppercase tracking-wider">Mabala Poultry Smart Alerts ({smartAlerts.length})</h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {smartAlerts.map(alert => (
              <div 
                key={alert.id} 
                className={`p-4 rounded-2xl border flex gap-3 text-xs leading-relaxed transition-all hover:shadow-xs ${
                  alert.level === "critical" 
                    ? "bg-red-50/60 border-red-200 text-red-950" 
                    : alert.level === "success"
                    ? "bg-emerald-50/50 border-emerald-200 text-emerald-950"
                    : "bg-amber-50/50 border-amber-200 text-amber-950"
                }`}
              >
                <AlertTriangle className={`w-4.5 h-4.5 shrink-0 mt-0.5 ${
                  alert.level === "critical" 
                    ? "text-red-600 animate-bounce" 
                    : alert.level === "success"
                    ? "text-emerald-600"
                    : "text-amber-600"
                }`} />
                <div>
                  <span className="font-extrabold text-[10px] uppercase block tracking-wide">
                    {alert.title} • {alert.batchName} ({alert.batchId})
                  </span>
                  <p className="mt-1 font-medium text-[11px] text-slate-600 leading-normal">{alert.details}</p>
                  <div className="mt-2.5 flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                      alert.level === "critical" 
                        ? "bg-red-100 text-red-800" 
                        : alert.level === "success"
                        ? "bg-emerald-100 text-emerald-800"
                        : "bg-amber-100 text-amber-800"
                    }`}>
                      {alert.level === "critical" ? "CRITICAL ALERT" : alert.level === "success" ? "CLEARED" : "WARNING"}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">Target/Due: {alert.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Grid of Core KPI Widgets */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Poultry Valuation */}
        <div className="bg-gradient-to-br from-emerald-900 to-emerald-950 text-white rounded-3xl p-3.5 sm:p-4 md:p-5 shadow-xl relative overflow-hidden flex flex-col justify-between h-[140px] md:h-[150px]">
          <div className="absolute right-3 top-3 opacity-15">
            <TrendingUp size={80} />
          </div>
          <div>
            <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-emerald-300 truncate block max-w-full" title="Total Poultry Valuation">Total Poultry Valuation</p>
            <h3 className="text-sm sm:text-base md:text-xl lg:text-2xl xl:text-3xl font-black mt-2 tracking-tight truncate" title={`${currencySymbol}${totalPoultryValuation.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}>
              {currencySymbol}{totalPoultryValuation.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </h3>
          </div>
          <div className="text-[10px] sm:text-[11px] font-bold text-emerald-200 truncate">
            Across {activeBatches.length} active batches
          </div>
        </div>

        {/* Broilers Headcount */}
        <div className="bg-white border border-slate-100 rounded-3xl p-3.5 sm:p-4 md:p-5 shadow-xs flex flex-col justify-between h-[140px] md:h-[150px]">
          <div>
            <div className="flex justify-between items-start gap-1">
              <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-slate-400 truncate block max-w-[70%] sm:max-w-full" title="Broiler Flock Size">Broiler Flock Size</span>
              <span className="bg-amber-100 text-amber-800 p-1 sm:p-1.5 rounded-xl shrink-0">
                <Flame size={14} />
              </span>
            </div>
            <h3 className="text-base sm:text-lg md:text-xl lg:text-2xl xl:text-3xl font-black mt-2 text-slate-900 tracking-tight truncate">
              {totalBroilersHeadcount.toLocaleString()}
            </h3>
          </div>
          <div className="text-[10px] sm:text-[11px] font-semibold text-slate-500 truncate">
            Active meat birds
          </div>
        </div>

        {/* Layers Headcount */}
        <div className="bg-white border border-slate-100 rounded-3xl p-3.5 sm:p-4 md:p-5 shadow-xs flex flex-col justify-between h-[140px] md:h-[150px]">
          <div>
            <div className="flex justify-between items-start gap-1">
              <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-slate-400 truncate block max-w-[70%] sm:max-w-full" title="Layer Flock Size">Layer Flock Size</span>
              <span className="bg-sky-100 text-sky-800 p-1 sm:p-1.5 rounded-xl shrink-0">
                <Egg size={14} />
              </span>
            </div>
            <h3 className="text-base sm:text-lg md:text-xl lg:text-2xl xl:text-3xl font-black mt-2 text-slate-900 tracking-tight truncate">
              {totalLayersHeadcount.toLocaleString()}
            </h3>
          </div>
          <div className="text-[10px] sm:text-[11px] font-semibold text-slate-500 truncate">
            Active laying hens
          </div>
        </div>

        {/* Village Headcount */}
        <div className="bg-white border border-slate-100 rounded-3xl p-3.5 sm:p-4 md:p-5 shadow-xs flex flex-col justify-between h-[140px] md:h-[150px]">
          <div>
            <div className="flex justify-between items-start gap-1">
              <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-slate-400 truncate block max-w-[70%] sm:max-w-full" title="Village Flock Size">Village Flock Size</span>
              <span className="bg-emerald-100 text-emerald-800 p-1 sm:p-1.5 rounded-xl shrink-0">
                <Sprout size={14} />
              </span>
            </div>
            <h3 className="text-base sm:text-lg md:text-xl lg:text-2xl xl:text-3xl font-black mt-2 text-slate-900 tracking-tight truncate">
              {totalVillageHeadcount.toLocaleString()}
            </h3>
          </div>
          <div className="text-[10px] sm:text-[11px] font-semibold text-slate-500 truncate">
            Indigenous dual-purpose birds
          </div>
        </div>
      </div>

      {/* Sub-Module Access Gates */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Go to Broilers */}
        <button
          onClick={onNavigateToBroilers}
          className="group text-left bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 text-white rounded-3xl p-6 shadow-lg border border-slate-800 hover:shadow-xl hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer flex flex-col justify-between h-[200px]"
        >
          <div className="flex justify-between items-start w-full">
            <span className="bg-amber-500/10 text-amber-400 p-3 rounded-2xl border border-amber-500/10 group-hover:bg-amber-500/25 transition-all">
              <Flame size={24} />
            </span>
            <span className="text-[10px] font-bold text-slate-400 group-hover:text-amber-400 transition-all flex items-center gap-1">
              Enter Sub-Module <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </span>
          </div>
          <div>
            <h4 className="text-base font-black tracking-tight group-hover:text-amber-300 transition-colors">Broiler Production</h4>
            <p className="text-[11px] text-slate-400 mt-1 font-semibold leading-relaxed">
              Track growth, weekly weighing, FCR conversion, and generate batch sale receipts.
            </p>
          </div>
        </button>

        {/* Go to Layers */}
        <button
          onClick={onNavigateToLayers}
          className="group text-left bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 text-white rounded-3xl p-6 shadow-lg border border-slate-800 hover:shadow-xl hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer flex flex-col justify-between h-[200px]"
        >
          <div className="flex justify-between items-start w-full">
            <span className="bg-sky-500/10 text-sky-400 p-3 rounded-2xl border border-sky-500/10 group-hover:bg-sky-500/25 transition-all">
              <Egg size={24} />
            </span>
            <span className="text-[10px] font-bold text-slate-400 group-hover:text-sky-400 transition-all flex items-center gap-1">
              Enter Sub-Module <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </span>
          </div>
          <div>
            <h4 className="text-base font-black tracking-tight group-hover:text-sky-300 transition-colors">Egg Layer Production</h4>
            <p className="text-[11px] text-slate-400 mt-1 font-semibold leading-relaxed">
              Record daily egg collection, manage tray stocks, log egg sales, and sell spent hens.
            </p>
          </div>
        </button>

        {/* Go to Village Chickens */}
        <button
          onClick={onNavigateToVillage}
          className="group text-left bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 text-white rounded-3xl p-6 shadow-lg border border-slate-800 hover:shadow-xl hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer flex flex-col justify-between h-[200px]"
        >
          <div className="flex justify-between items-start w-full">
            <span className="bg-emerald-500/10 text-emerald-400 p-3 rounded-2xl border border-emerald-500/10 group-hover:bg-emerald-500/25 transition-all">
              <Sprout size={24} />
            </span>
            <span className="text-[10px] font-bold text-slate-400 group-hover:text-emerald-400 transition-all flex items-center gap-1">
              Enter Sub-Module <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </span>
          </div>
          <div>
            <h4 className="text-base font-black tracking-tight group-hover:text-emerald-300 transition-colors">Village Indigenous</h4>
            <p className="text-[11px] text-slate-400 mt-1 font-semibold leading-relaxed">
              Dual-purpose chicken tracker optimized for smallholder scale bird sales and egg collection.
            </p>
          </div>
        </button>
      </div>

      {/* 30-Day Egg Quality Ratio Per Batch */}
      {batches.filter(b => b.status === "active" && (b.poultryType === "layer" || b.poultryType === "village")).length > 0 && (
        <div className="bg-white border border-slate-150 rounded-3xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-2">
                <Egg className="w-4 h-4 text-sky-500" />
                <span>Active Egg Batches — 30-Day Quality Grade Ratio</span>
              </h4>
              <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                Ratio breakdown of Grade A vs. Grade B vs. Broken eggs collected over the last 30 days per active layer flock.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {batches
              .filter(b => b.status === "active" && (b.poultryType === "layer" || b.poultryType === "village"))
              .map(b => (
                <EggGradeRatioPieChart
                  key={b.id}
                  eggCollections={b.eggCollections}
                  title={`${b.batchName} (${b.batchId})`}
                />
              ))}
          </div>
        </div>
      )}

      {/* This Month Performance Snapshot */}
      <div className="bg-slate-50 border border-slate-150 rounded-3xl p-6">
        <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider mb-4">
          This Month's Flock performance (Overall)
        </h4>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-center">
          <div className="bg-white rounded-2xl p-4 border border-slate-100">
            <div className="flex justify-center text-sky-500 mb-1"><Egg size={20} /></div>
            <p className="text-[10px] text-slate-400 font-bold uppercase">Eggs Collected</p>
            <p className="text-lg font-black text-slate-800 mt-0.5">
              {thisMonthMetrics.eggsCollected.toLocaleString()} eggs
            </p>
            <p className="text-[9px] text-slate-500 font-semibold mt-0.5">
              ({Math.floor(thisMonthMetrics.eggsCollected / 30)} standard trays)
            </p>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-slate-100">
            <div className="flex justify-center text-emerald-500 mb-1"><DollarSign size={20} /></div>
            <p className="text-[10px] text-slate-400 font-bold uppercase">Egg Sales Revenue</p>
            <p className="text-lg font-black text-slate-800 mt-0.5">
              {currencySymbol}{thisMonthMetrics.eggRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-slate-100">
            <div className="flex justify-center text-amber-500 mb-1"><ShoppingCart size={20} /></div>
            <p className="text-[10px] text-slate-400 font-bold uppercase">Live Bird Revenue</p>
            <p className="text-lg font-black text-slate-800 mt-0.5">
              {currencySymbol}{thisMonthMetrics.birdSalesRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-slate-100">
            <div className="flex justify-center text-red-500 mb-1"><Skull size={20} /></div>
            <p className="text-[10px] text-slate-400 font-bold uppercase">Mortality Count</p>
            <p className="text-lg font-black text-slate-800 mt-0.5 text-red-600">
              +{thisMonthMetrics.mortalityCount.toLocaleString()} birds
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export type BiologicalAssetTier = 
  | "non_current_biological" 
  | "current_biological" 
  | "post_harvest_inventory" 
  | "ppe_asset";

export interface PoultryFeedLog {
  id: string;
  date: string;
  feedType: string;
  quantityKg: number;
  cost: number;
  fedBy: string;
  costPerKg?: number;
  dailyConsumptionPerBirdGrams?: number;
  dailyCostPerBird?: number;
  fcrRatio?: number;
  stageId?: string;
  notes?: string;
}

export interface PoultryHealthEvent {
  id: string;
  date: string;
  type: "vaccination" | "treatment" | "deworming" | "supplement" | "other";
  category?: "Vaccine" | "Antibiotic" | "Dewormer" | "Vitamin/Supplement" | "Coccidiostat" | "Disinfectant" | "Other";
  product: string;
  cost: number;
  notes: string;
  withdrawalPeriodDays?: number;
  withdrawalCloseDate?: string;
  administeredBy?: string;
  birdsTreated?: number;
  dosage?: string;
  route?: string;
  unitCost?: number;
  quantityDoses?: number;
  targetDisease?: string;
  batchLotNo?: string;
}

export interface FeedInventoryItem {
  id: string;
  feedType: string;
  category: "Starter" | "Grower" | "Finisher" | "Layer" | "Kienyeji" | "Concentrate" | "Other";
  brandSupplier: string;
  bagsInStock: number;
  bagWeightKg: number;
  totalKgInStock: number;
  costPerBag: number;
  costPerKg: number;
  reorderLevelKg: number;
  lastRestockedDate: string;
}

export interface MedicationInventoryItem {
  id: string;
  brandName: string;
  category: "Vaccine" | "Antibiotic" | "Dewormer" | "Vitamin/Supplement" | "Coccidiostat" | "Disinfectant" | "Other";
  activeIngredient: string;
  routeOfAdmin: string;
  unit: "doses" | "ml" | "grams" | "vials" | "bottles" | "packs";
  quantityInStock: number;
  unitCost: number;
  withdrawalPeriodDays: number;
  reorderLevel: number;
  expiryDate: string;
  supplier?: string;
}

export interface PoultryMortalityLog {
  id: string;
  date: string;
  count: number;
  cause: "Disease" | "Heat Stress" | "Predation" | "Culled" | "Other" | string;
  lossValue: number;
  notes?: string;
}

export interface PoultrySalesLog {
  id: string;
  date: string;
  quantity: number;
  amount: number;
  pricePerUnit: number;
  chargeType: "PER_BIRD" | "PER_KG";
  averageWeightKg?: number;
  buyerName: string;
  paymentMethod: string;
}

export interface EggCollection {
  id: string;
  date: string;
  totalCollected: number;
  brokenCount: number;
  large: number;
  medium: number;
  small: number;
  ungraded: number;
  useGrades: boolean;
  layRatePct: number;
}

export interface EggSale {
  id: string;
  date: string;
  grade: "large" | "medium" | "small" | "ungraded";
  quantity: number; // in eggs
  pricePerUnit: number; // price per egg or per tray depending on sellUnit
  sellUnit: "egg" | "tray"; // tray = 30 eggs
  totalRevenue: number;
  buyerName: string;
  paymentMethod: string;
}

export interface ValuationChange {
  date: string;
  oldPrice: number;
  newPrice: number;
  changedBy: string;
}

export interface PoultryBatch {
  id: string;
  batchId: string; // e.g. BRO-2026-001 or LAY-2026-002
  batchName: string;
  hasPendingWrites?: boolean;
  _pendingSync?: boolean;
  poultryType: "broiler" | "layer" | "village";
  breed: string; // Ross 308, Cobb 500, Sasso, Boschveld, Local/Village, Other-custom
  dateAcquired: string;
  source: string; // Supplier name
  initialHeadcount: number;
  currentHeadcount: number;
  acquisitionCostTotal: number;
  acquisitionCostPerBird: number;
  currentMarketPricePerBird: number; // farmer-set
  currentBatchValuation: number; // currentHeadcount * currentMarketPricePerBird
  assetClassification?: BiologicalAssetTier;
  assetTypeCategory?: "Current" | "Non-Current";
  glAccountCode?: string;
  assetRegisterId?: string;
  cumulativeFeedCost: number;
  cumulativeHealthCost: number;
  cumulativeMortalityLoss: number;
  status: "active" | "sold_out" | "closed";
  photoUrl?: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  tenantId: string;
  farmId: string;

  // Trackers and historical arrays
  feedLogs: PoultryFeedLog[];
  healthLogs: PoultryHealthEvent[];
  mortalityLogs: PoultryMortalityLog[];
  salesLogs: PoultrySalesLog[];
  eggCollections?: EggCollection[];
  eggSales?: EggSale[];
  weightSamples?: { id: string; date: string; averageWeightKg: number; sampleSize: number; remarks?: string }[];
  valuationHistory: ValuationChange[];
  targetSaleWeight?: number; // optional target weight for broilers (informational)
  expectedLayAgeWeeks?: number; // expected point-of-lay weeks for layers (default 18)
}

import React, { useState, useEffect, useMemo } from "react";
import { PoultryBatch, PoultryFeedLog, FeedInventoryItem } from "./types";
import { 
  Package, Plus, TrendingUp, Scale, DollarSign, Calendar, AlertCircle, 
  CheckCircle2, ArrowUpRight, BarChart3, Filter, Download, User, Info, 
  RefreshCw, Sparkles, Layers, BookOpen, Calculator, Building2, Phone, Mail, MapPin, FileText
} from "lucide-react";
import NutriFeedsRequirementChart from "./NutriFeedsRequirementChart";
import BatchFeedFcrSummary from "./BatchFeedFcrSummary";
import { Supplier } from "../../types";
import { getFarmOperationalConfig } from "../../config/farmOperationalConfig";

interface PoultryFeedManagerProps {
  batches: PoultryBatch[];
  currencySymbol: string;
  onUpdateBatch: (batch: PoultryBatch) => void;
  accounts: any[];
  setAccounts: (accs: any[]) => void;
  onAddExpense?: (tx: any) => void;
  onAddSupplier?: (sup: Supplier) => void;
  suppliers?: Supplier[];
  writeAuditLog: (action: string, module: string, target: string, details: string) => void;
  employees?: any[];
  activeFarm?: any;
}

export const INITIAL_FEED_INVENTORY: FeedInventoryItem[] = [];

export default function PoultryFeedManager({
  batches,
  currencySymbol,
  onUpdateBatch,
  accounts,
  setAccounts,
  onAddExpense,
  onAddSupplier,
  suppliers = [],
  writeAuditLog,
  employees = [],
  activeFarm
}: PoultryFeedManagerProps) {
  // Feed Inventory State with persistent storage
  const [feedInventory, setFeedInventory] = useState<FeedInventoryItem[]>(() => {
    try {
      const saved = localStorage.getItem("mabala_poultry_feed_inventory");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
      return INITIAL_FEED_INVENTORY;
    } catch {
      return INITIAL_FEED_INVENTORY;
    }
  });

  useEffect(() => {
    localStorage.setItem("mabala_poultry_feed_inventory", JSON.stringify(feedInventory));
  }, [feedInventory]);

  // Section / View Toggle
  const [activeSection, setActiveSection] = useState<"summary" | "nutri-chart" | "inventory" | "logs">("summary");

  // Modals state
  const [showLogFeedModal, setShowLogFeedModal] = useState(false);
  const [showRestockModal, setShowRestockModal] = useState(false);
  const [selectedBatchId, setSelectedBatchId] = useState<string>("");
  const [selectedFeedInvId, setSelectedFeedInvId] = useState<string>("");

  // Quantity input mode: "kg" or "bags"
  const [inputUnitMode, setInputUnitMode] = useState<"kg" | "bags">("kg");
  const [quantityInput, setQuantityInput] = useState<number>(0);
  const [customCostOverride, setCustomCostOverride] = useState<string>("");

  // Filter state for history table
  const [filterBatch, setFilterBatch] = useState<string>("all");

  // Notification Toast
  const [toastMessage, setToastMessage] = useState<{ title: string; desc: string; type: "success" | "info" } | null>(null);

  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  // Log Feed Form
  const [feedForm, setFeedForm] = useState({
    date: new Date().toISOString().split("T")[0],
    fedBy: "",
    notes: ""
  });

  // Restock Form
  const [restockForm, setRestockForm] = useState({
    feedType: "Broiler Starter Crumble (50kg)",
    category: "Starter" as FeedInventoryItem["category"],
    brandSupplier: "Nutri Feeds Zambia",
    bagsPurchased: 20,
    bagWeightKg: 50,
    costPerBag: 380,
    date: new Date().toISOString().split("T")[0]
  });

  // Supplier Selection & Registration State
  const [supplierMode, setSupplierMode] = useState<"select" | "new">("select");
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>("");
  const [newSupplierForm, setNewSupplierForm] = useState({
    name: "Nutri Feeds Zambia",
    contactPerson: "Sales Desk",
    phone: "0977000111",
    email: "orders@nutrifeeds.co.zm",
    address: "Plot 1284, Heavy Industrial Area, Lusaka",
    tpin: "1002345678",
    category: "Poultry Feed & Nutrition",
    notes: "Primary broiler and layer feed supplier"
  });

  // Feed suppliers filtered from suppliers register
  const feedSuppliers = useMemo(() => {
    return suppliers;
  }, [suppliers]);

  // Set default supplier when available
  useEffect(() => {
    if (feedSuppliers.length > 0 && !selectedSupplierId) {
      // Look for a poultry feed supplier or default to first
      const defaultSup = feedSuppliers.find(s => 
        s.category?.toLowerCase().includes("feed") || 
        s.name.toLowerCase().includes("feed") ||
        s.name.toLowerCase().includes("nutri") ||
        s.name.toLowerCase().includes("novatek") ||
        s.name.toLowerCase().includes("tiger")
      ) || feedSuppliers[0];
      setSelectedSupplierId(defaultSup.id);
      setRestockForm(prev => ({ ...prev, brandSupplier: defaultSup.name }));
    } else if (feedSuppliers.length === 0) {
      setSupplierMode("new");
    }
  }, [feedSuppliers, selectedSupplierId]);

  // When selected supplier changes, update brandSupplier
  const handleSelectSupplier = (supId: string) => {
    setSelectedSupplierId(supId);
    const sup = feedSuppliers.find(s => s.id === supId);
    if (sup) {
      setRestockForm(prev => ({ ...prev, brandSupplier: sup.name }));
    }
  };

  // Set default active batch and feed item on load
  useEffect(() => {
    const active = batches.filter(b => b.status === "active" || (b.status as string).includes("ACTIVE"));
    if (active.length > 0 && !selectedBatchId) {
      setSelectedBatchId(active[0].id);
    }
    if (feedInventory.length > 0 && !selectedFeedInvId) {
      setSelectedFeedInvId(feedInventory[0].id);
    }
  }, [batches, feedInventory]);

  const activeBatches = useMemo(() => {
    return batches.filter(b => b.status === "active" || (b.status as string).includes("ACTIVE"));
  }, [batches]);

  const selectedBatch = useMemo(() => {
    return batches.find(b => b.id === selectedBatchId) || activeBatches[0] || batches[0];
  }, [batches, selectedBatchId, activeBatches]);

  const selectedFeedItem = useMemo(() => {
    return feedInventory.find(f => f.id === selectedFeedInvId) || feedInventory[0];
  }, [feedInventory, selectedFeedInvId]);

  // Normalized quantity in kg based on input unit mode
  const resolvedQuantityKg = useMemo(() => {
    const qty = Number(quantityInput) || 0;
    if (inputUnitMode === "bags") {
      const bagWeight = selectedFeedItem ? (selectedFeedItem.bagWeightKg || 50) : 50;
      return qty * bagWeight;
    }
    return qty;
  }, [quantityInput, inputUnitMode, selectedFeedItem]);

  const resolvedBags = useMemo(() => {
    return resolvedQuantityKg / 50;
  }, [resolvedQuantityKg]);

  // Calculations for live feed logging
  const currentHeadcount = selectedBatch?.currentHeadcount || selectedBatch?.initialHeadcount || 1;

  const computedFeedCost = useMemo(() => {
    if (customCostOverride !== "" && !isNaN(Number(customCostOverride))) {
      return Number(customCostOverride);
    }
    if (!selectedFeedItem) return resolvedQuantityKg * 7.5;
    return resolvedQuantityKg * selectedFeedItem.costPerKg;
  }, [resolvedQuantityKg, selectedFeedItem, customCostOverride]);

  const dailyGramsPerBird = useMemo(() => {
    if (currentHeadcount <= 0) return 0;
    return (resolvedQuantityKg * 1000) / currentHeadcount;
  }, [resolvedQuantityKg, currentHeadcount]);

  const dailyCostPerBird = useMemo(() => {
    if (currentHeadcount <= 0) return 0;
    return computedFeedCost / currentHeadcount;
  }, [computedFeedCost, currentHeadcount]);

  // Helper to post double-entry ledger in Chart of Accounts
  const postLedger = (debitCode: string, creditCode: string, amount: number) => {
    if (isNaN(amount) || amount <= 0 || !setAccounts) return;
    setAccounts(accounts.map(acc => {
      let bal = acc.balance;
      if (acc.code === debitCode) bal += amount;
      if (acc.code === creditCode) bal -= amount;
      return { ...acc, balance: bal };
    }));
  };

  // Submit Restock
  const handleRestockFeed = (e: React.FormEvent) => {
    e.preventDefault();
    const totalKgPurchased = Number(restockForm.bagsPurchased) * Number(restockForm.bagWeightKg);
    const totalCost = Number(restockForm.bagsPurchased) * Number(restockForm.costPerBag);
    const costPerKg = Number(restockForm.costPerBag) / Number(restockForm.bagWeightKg);

    let finalSupplierId = selectedSupplierId;
    let finalSupplierName = restockForm.brandSupplier;

    // Handle New Supplier Registration
    if (supplierMode === "new") {
      const trimmedName = newSupplierForm.name.trim() || restockForm.brandSupplier || "Nutri Feeds Zambia";
      finalSupplierId = `SUP-POULTRY-${Date.now()}`;
      finalSupplierName = trimmedName;

      const createdSupplier: Supplier = {
        id: finalSupplierId,
        name: trimmedName,
        contactPerson: newSupplierForm.contactPerson.trim() || "Sales Desk",
        phone: newSupplierForm.phone.trim() || "0977000111",
        email: newSupplierForm.email.trim() || "",
        address: newSupplierForm.address.trim() || "Plot 1284, Heavy Industrial Area, Lusaka",
        tpin: newSupplierForm.tpin.trim() || "",
        category: newSupplierForm.category || "Poultry Feed & Nutrition",
        notes: newSupplierForm.notes || `Auto-registered from Poultry Feed Restock on ${restockForm.date}`,
        farmId: activeFarm?.id,
        tenantId: activeFarm?.tenantId
      };

      if (onAddSupplier) {
        onAddSupplier(createdSupplier);
      }
      setSelectedSupplierId(finalSupplierId);
    } else {
      const matched = feedSuppliers.find(s => s.id === selectedSupplierId);
      if (matched) {
        finalSupplierName = matched.name;
      }
    }

    // Update or add inventory item
    const existingIndex = feedInventory.findIndex(f => f.feedType.toLowerCase() === restockForm.feedType.toLowerCase());
    if (existingIndex >= 0) {
      const updated = [...feedInventory];
      const item = updated[existingIndex];
      item.bagsInStock += Number(restockForm.bagsPurchased);
      item.totalKgInStock += totalKgPurchased;
      item.costPerBag = Number(restockForm.costPerBag);
      item.costPerKg = costPerKg;
      item.brandSupplier = finalSupplierName;
      item.lastRestockedDate = restockForm.date;
      setFeedInventory(updated);
    } else {
      const newItem: FeedInventoryItem = {
        id: `feed-inv-${Date.now()}`,
        feedType: restockForm.feedType,
        category: restockForm.category,
        brandSupplier: finalSupplierName,
        bagsInStock: Number(restockForm.bagsPurchased),
        bagWeightKg: Number(restockForm.bagWeightKg),
        totalKgInStock: totalKgPurchased,
        costPerBag: Number(restockForm.costPerBag),
        costPerKg,
        reorderLevelKg: 250,
        lastRestockedDate: restockForm.date
      };
      setFeedInventory([...feedInventory, newItem]);
    }

    // Double Entry Ledger: Debit Poultry Feed & Crumbles Cost (5210), Credit Bank Operational (1010)
    postLedger("5210", "1010", totalCost);

    // Auto-post to Continuous Expenses & Cash book Disbursals with optimistic local write tracking
    if (onAddExpense) {
      const expenseTx = {
        id: `EXP-FEED-${Date.now()}`,
        supplierId: finalSupplierId || `SUP-${Date.now()}`,
        supplierName: finalSupplierName || "Poultry Feed Supplier",
        date: restockForm.date,
        taxSystem: "Exempt",
        taxAmount: 0,
        subtotal: totalCost,
        total: totalCost,
        amount: totalCost,
        farmId: activeFarm?.id,
        tenantId: activeFarm?.tenantId,
        hasPendingWrites: true,
        _pendingSync: true,
        rows: [
          {
            category: "Poultry Feed & Crumbles Cost",
            description: `Purchase / Restock ${restockForm.bagsPurchased} bags (${totalKgPurchased}kg) of ${restockForm.feedType} @ ${currencySymbol}${restockForm.costPerBag}/bag from ${finalSupplierName}`,
            quantity: Number(restockForm.bagsPurchased),
            unitPrice: Number(restockForm.costPerBag),
            amount: totalCost,
            coaCode: "5210",
            allocationType: "poultry_farmwide" as const,
            poultryBatchId: undefined,
            poultryBatchName: "All Poultry Flocks (Feed Store Restock)"
          }
        ]
      };
      // Optimistic UI update: State is updated immediately before any Firestore sync
      onAddExpense(expenseTx);
    }

    writeAuditLog(
      "PURCHASE", 
      "Feed Inventory", 
      restockForm.feedType, 
      `Purchased ${restockForm.bagsPurchased} bags (${totalKgPurchased}kg) of ${restockForm.feedType} from ${finalSupplierName} for ${currencySymbol}${totalCost}. Double-entry: Dr 5210 / Cr 1010.`
    );

    setToastMessage({
      title: "Feed Store Restocked & Financial Entry Posted",
      desc: `Added ${restockForm.bagsPurchased} bags (${totalKgPurchased}kg) from ${finalSupplierName} (${currencySymbol}${totalCost.toLocaleString()}). Disbursed to Continuous Expenses & Dr 5210 posted.`,
      type: "success"
    });

    setShowRestockModal(false);
  };

  // Submit Daily Feed Intake Log
  const handleLogFeed = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBatch) return;

    const qtyKg = resolvedQuantityKg;
    const logId = `FL-${Date.now().toString().slice(-6)}`;
    const cost = computedFeedCost;
    const feedTypeName = selectedFeedItem ? selectedFeedItem.feedType : "Standard Poultry Feed";

    const newLog: PoultryFeedLog = {
      id: logId,
      date: feedForm.date,
      feedType: feedTypeName,
      quantityKg: qtyKg,
      cost,
      costPerKg: qtyKg > 0 ? cost / qtyKg : (selectedFeedItem ? selectedFeedItem.costPerKg : (getFarmOperationalConfig().defaultFeedCostPerKg || 0)),
      dailyConsumptionPerBirdGrams: dailyGramsPerBird,
      dailyCostPerBird,
      fedBy: feedForm.fedBy || "Poultry Attendant",
      notes: feedForm.notes
    };

    // Deduct stock from store inventory if item exists
    if (selectedFeedItem) {
      const updatedInv = feedInventory.map(item => {
        if (item.id === selectedFeedItem.id) {
          const newTotalKg = Math.max(0, item.totalKgInStock - qtyKg);
          const newBags = Math.floor(newTotalKg / (item.bagWeightKg || 50));
          return {
            ...item,
            totalKgInStock: newTotalKg,
            bagsInStock: newBags
          };
        }
        return item;
      });
      setFeedInventory(updatedInv);
    }

    // Update batch feed logs and cumulative costs with optimistic write tracking
    const updatedBatch: PoultryBatch = {
      ...selectedBatch,
      feedLogs: [newLog, ...(selectedBatch.feedLogs || [])],
      cumulativeFeedCost: (selectedBatch.cumulativeFeedCost || 0) + cost,
      hasPendingWrites: true,
      _pendingSync: true,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updatedBatch);

    // Double Entry Ledger: Debit 5210 (Poultry Feed Cost), Credit 1010 (Bank Operational)
    postLedger("5210", "1010", cost);

    // Register expense in Farm Accounting transactions
    if (onAddExpense) {
      const expenseTx = {
        id: `EXP-FEEDINTAKE-${Date.now()}`,
        supplierId: "SUP-FEED-INTERNAL",
        supplierName: "Feed Store / Inventory Allocation",
        date: feedForm.date,
        taxSystem: "Exempt",
        taxAmount: 0,
        subtotal: cost,
        total: cost,
        amount: cost,
        farmId: activeFarm?.id,
        hasPendingWrites: true,
        _pendingSync: true,
        rows: [
          {
            category: "Poultry Feed",
            description: `Feed intake for ${selectedBatch.batchName} (${selectedBatch.batchId}): ${qtyKg}kg of ${feedTypeName}`,
            quantity: qtyKg,
            unitPrice: qtyKg > 0 ? cost / qtyKg : 0,
            amount: cost,
            coaCode: "5210"
          }
        ]
      };
      onAddExpense(expenseTx);
    }

    writeAuditLog(
      "CREATE", 
      "Poultry Feed Log", 
      selectedBatch.batchId, 
      `Logged feed intake for ${selectedBatch.batchName}: ${qtyKg}kg (${dailyGramsPerBird.toFixed(1)}g/bird/day) costing ${currencySymbol}${cost.toFixed(2)}`
    );

    setToastMessage({
      title: "Feed Intake Logged Successfully",
      desc: `Recorded ${qtyKg}kg for ${selectedBatch.batchName}. Total cost: ${currencySymbol}${cost.toFixed(2)} (Dr 5210).`,
      type: "success"
    });

    setShowLogFeedModal(false);
    setCustomCostOverride("");
  };

  // Open Log Feed Modal pre-selecting a specific batch
  const handleOpenLogFeedForBatch = (batchId: string) => {
    setSelectedBatchId(batchId);
    setShowLogFeedModal(true);
  };

  // All combined feed logs for table view
  const allFeedLogs = useMemo(() => {
    const list: { batchName: string; batchId: string; log: PoultryFeedLog; headcount: number }[] = [];
    batches.forEach(b => {
      if (filterBatch !== "all" && b.id !== filterBatch) return;
      (b.feedLogs || []).forEach(l => {
        list.push({
          batchName: b.batchName,
          batchId: b.batchId,
          log: l,
          headcount: b.currentHeadcount || b.initialHeadcount
        });
      });
    });
    return list.sort((a, b) => new Date(b.log.date).getTime() - new Date(a.log.date).getTime());
  }, [batches, filterBatch]);

  // Aggregate Feed Stats
  const feedAggregates = useMemo(() => {
    let totalKgConsumed = 0;
    let totalFeedExpense = 0;
    allFeedLogs.forEach(item => {
      totalKgConsumed += Number(item.log.quantityKg) || 0;
      totalFeedExpense += Number(item.log.cost) || 0;
    });

    const totalStockKg = feedInventory.reduce((sum, item) => sum + item.totalKgInStock, 0);
    const totalStockBags = feedInventory.reduce((sum, item) => sum + item.bagsInStock, 0);
    const totalStockValue = feedInventory.reduce((sum, item) => sum + (item.bagsInStock * item.costPerBag), 0);

    return {
      totalKgConsumed,
      totalFeedExpense,
      totalStockKg,
      totalStockBags,
      totalStockValue
    };
  }, [allFeedLogs, feedInventory]);

  // Export CSV
  const exportFeedCSV = () => {
    let csv = "Date,Flock Batch,Batch ID,Feed Formulation,Quantity (kg),Bags (50kg),Total Feed Cost,Cost/kg,Grams/Bird/Day,Daily Cost/Bird,Fed By,Notes\n";
    allFeedLogs.forEach(item => {
      const l = item.log;
      const bags = ((l.quantityKg || 0) / 50).toFixed(2);
      const unitCost = l.quantityKg > 0 ? (l.cost / l.quantityKg).toFixed(2) : "0.00";
      csv += `"${l.date}","${item.batchName}","${item.batchId}","${l.feedType}",${l.quantityKg},${bags},${l.cost},${unitCost},${(l.dailyConsumptionPerBirdGrams || 0).toFixed(1)},${(l.dailyCostPerBird || 0).toFixed(2)},"${l.fedBy || ""}","${l.notes || ""}"\n`;
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Poultry_Feed_Intake_Report_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
  };

  return (
    <div className="space-y-6" id="poultry-feed-manager-root">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-slate-700 flex items-center gap-3 animate-fade-in">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <CheckCircle2 size={18} />
          </div>
          <div>
            <strong className="text-xs font-black block text-emerald-400">{toastMessage.title}</strong>
            <span className="text-[11px] text-slate-300">{toastMessage.desc}</span>
          </div>
        </div>
      )}

      {/* Top Banner & Quick Actions */}
      <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
            <Package size={16} />
            <span>Feed Management & Conversion Engine</span>
          </div>
          <h2 className="text-2xl font-black mt-1">Flock Feed Intake, FCR & Cost Management</h2>
          <p className="text-slate-400 text-xs mt-1 max-w-2xl leading-relaxed">
            Monitor daily feed intake per bird (g/bird/day), calculate live <strong>Feed Conversion Ratios (FCR)</strong> and total feed costs per flock, access the official <strong>Nutri Feeds 6-Week Feeding Program</strong>, and automatically post expense entries to Chart of Accounts <span className="text-emerald-400 font-mono font-bold">5210 Poultry Feed & Crumbles Cost</span>.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setShowRestockModal(true)}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 border border-slate-700 cursor-pointer shadow-xs"
          >
            <Plus size={14} />
            Restock Feed Store
          </button>

          <button
            type="button"
            onClick={() => setShowLogFeedModal(true)}
            className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-xs font-black shadow-lg shadow-emerald-900/40 transition-all flex items-center gap-2 cursor-pointer"
          >
            <Scale size={16} />
            Log Feed Intake
          </button>
        </div>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Feed Stock On Hand</span>
          <div className="flex items-baseline justify-between">
            <strong className="text-2xl font-black text-slate-900 font-mono">{feedAggregates.totalStockBags} Bags</strong>
            <span className="text-xs font-bold text-slate-500">{feedAggregates.totalStockKg.toLocaleString()} kg</span>
          </div>
          <p className="text-[10px] text-slate-500 font-medium">Store Value: {currencySymbol}{feedAggregates.totalStockValue.toLocaleString()}</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Feed Consumed</span>
          <div className="flex items-baseline justify-between">
            <strong className="text-2xl font-black text-amber-700 font-mono">{feedAggregates.totalKgConsumed.toLocaleString()} kg</strong>
            <span className="text-xs font-bold text-amber-800">{(feedAggregates.totalKgConsumed / 50).toFixed(1)} Bags</span>
          </div>
          <p className="text-[10px] text-slate-500 font-medium">Logged across active flocks</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Feed Cost (To Date)</span>
          <div className="flex items-baseline justify-between">
            <strong className="text-2xl font-black text-emerald-700 font-mono">{currencySymbol}{feedAggregates.totalFeedExpense.toLocaleString()}</strong>
            <span className="text-xs font-bold text-emerald-600 font-mono">Dr 5210</span>
          </div>
          <p className="text-[10px] text-slate-500 font-medium">Synchronized with Finance & P&L</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Avg Daily Intake / Bird</span>
          <div className="flex items-baseline justify-between">
            <strong className="text-2xl font-black text-slate-900 font-mono">
              {allFeedLogs.length > 0 
                ? `${(allFeedLogs.reduce((s, x) => s + (x.log.dailyConsumptionPerBirdGrams || 0), 0) / allFeedLogs.length).toFixed(1)} g`
                : "115.0 g"}
            </strong>
            <span className="text-xs font-bold text-slate-500">per bird / day</span>
          </div>
          <p className="text-[10px] text-slate-500 font-medium">Standard target: 110g - 130g/day</p>
        </div>
      </div>

      {/* Sub-Section Navigation Tabs */}
      <div className="flex flex-wrap border-b border-slate-200 bg-slate-100/80 p-1.5 rounded-2xl gap-1">
        <button
          type="button"
          onClick={() => setActiveSection("summary")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
            activeSection === "summary"
              ? "bg-white text-slate-900 shadow-xs"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Scale size={14} className="text-emerald-600" />
          Batch FCR & Cost Summary View
        </button>

        <button
          type="button"
          onClick={() => setActiveSection("nutri-chart")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
            activeSection === "nutri-chart"
              ? "bg-red-800 text-white shadow-xs"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <BookOpen size={14} />
          Nutri Feeds 6-Week Feed Program (50kg Bags)
        </button>

        <button
          type="button"
          onClick={() => setActiveSection("inventory")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
            activeSection === "inventory"
              ? "bg-white text-slate-900 shadow-xs"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Package size={14} className="text-amber-600" />
          Feed Store Inventory ({feedInventory.length} Formulas)
        </button>

        <button
          type="button"
          onClick={() => setActiveSection("logs")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
            activeSection === "logs"
              ? "bg-white text-slate-900 shadow-xs"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <BarChart3 size={14} className="text-sky-600" />
          Daily Intake Logs ({allFeedLogs.length})
        </button>
      </div>

      {/* Render Active Sub-Section */}
      {activeSection === "summary" && (
        <div className="space-y-6">
          <BatchFeedFcrSummary
            batches={batches}
            currencySymbol={currencySymbol}
            onLogFeedForBatch={handleOpenLogFeedForBatch}
            onUpdateBatch={onUpdateBatch}
            writeAuditLog={writeAuditLog}
          />
        </div>
      )}

      {activeSection === "nutri-chart" && (
        <div className="space-y-6">
          <NutriFeedsRequirementChart
            currencySymbol={currencySymbol}
            batches={batches}
            onSelectFeedRecommendation={(rec) => {
              // Pre-fill restock or log feed with recommendation
              setShowLogFeedModal(true);
              const starterKg = rec.starterBags * 50;
              setQuantityInput(starterKg > 0 ? starterKg : 50);
            }}
          />
        </div>
      )}

      {activeSection === "inventory" && (
        <div className="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                <Package size={16} className="text-amber-500" />
                Feed Store Inventory & Stock Balances
              </h3>
              <p className="text-[11px] text-slate-400 font-medium">
                Registered feed formulations, available stock (bags & kg), and reorder threshold levels
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowRestockModal(true)}
              className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
            >
              <Plus size={13} /> Restock Feed
            </button>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-100">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                  <th className="p-3">Feed Formulation</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Brand / Supplier</th>
                  <th className="p-3">Bags In Stock</th>
                  <th className="p-3">Total Stock (kg)</th>
                  <th className="p-3">Price / Bag</th>
                  <th className="p-3">Cost / kg</th>
                  <th className="p-3">Stock Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {feedInventory.map(item => {
                  const isLow = item.totalKgInStock <= item.reorderLevelKg;
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-black text-slate-800">{item.feedType}</td>
                      <td className="p-3">
                        <span className="bg-slate-100 text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded-md">
                          {item.category}
                        </span>
                      </td>
                      <td className="p-3 text-slate-600">{item.brandSupplier}</td>
                      <td className="p-3 font-bold text-slate-900">{item.bagsInStock} Bags</td>
                      <td className="p-3 font-mono font-bold text-slate-700">{item.totalKgInStock.toLocaleString()} kg</td>
                      <td className="p-3 font-bold text-slate-900">{currencySymbol}{item.costPerBag.toFixed(2)}</td>
                      <td className="p-3 font-mono text-emerald-600 font-bold">{currencySymbol}{item.costPerKg.toFixed(2)} / kg</td>
                      <td className="p-3">
                        {isLow ? (
                          <span className="bg-red-50 text-red-700 border border-red-200 text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 w-fit">
                            <AlertCircle size={12} /> Low Stock - Reorder
                          </span>
                        ) : (
                          <span className="bg-emerald-50 text-emerald-700 text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 w-fit">
                            <CheckCircle2 size={12} /> Adequate
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeSection === "logs" && (
        <div className="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-xs space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                <BarChart3 size={16} className="text-emerald-500" />
                Daily Feed Intake Logs & Flock Costing History
              </h3>
              <p className="text-[11px] text-slate-400 font-medium">
                Detailed intake audit with daily consumption per bird (g/bird/day) and cost attribution
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2">
                <Filter size={14} className="text-slate-400" />
                <select
                  value={filterBatch}
                  onChange={(e) => setFilterBatch(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none"
                >
                  <option value="all">All Flocks / Batches</option>
                  {batches.map(b => (
                    <option key={b.id} value={b.id}>{b.batchName} ({b.batchId})</option>
                  ))}
                </select>
              </div>

              <button
                type="button"
                onClick={exportFeedCSV}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Download size={14} /> Export CSV
              </button>
            </div>
          </div>

          {allFeedLogs.length === 0 ? (
            <div className="p-8 text-center text-slate-400 space-y-2 border border-dashed border-slate-200 rounded-2xl">
              <Package size={32} className="mx-auto text-slate-300" />
              <p className="text-xs font-bold text-slate-600">No feed intake logs recorded yet</p>
              <p className="text-[11px]">Click "Log Feed Intake" above to record daily flock consumption and cost per bird.</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border border-slate-100">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                    <th className="p-3">Date</th>
                    <th className="p-3">Flock Batch</th>
                    <th className="p-3">Feed Formulation</th>
                    <th className="p-3">Quantity</th>
                    <th className="p-3">Daily Intake / Bird</th>
                    <th className="p-3">Total Cost</th>
                    <th className="p-3">Cost / Bird</th>
                    <th className="p-3">Fed By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {allFeedLogs.map(({ batchName, batchId, log, headcount }) => (
                    <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-mono font-bold text-slate-700">{log.date}</td>
                      <td className="p-3">
                        <strong className="text-slate-900 font-black block">{batchName}</strong>
                        <span className="text-[10px] font-mono text-slate-400">{batchId} ({headcount} birds)</span>
                      </td>
                      <td className="p-3 text-slate-700">{log.feedType}</td>
                      <td className="p-3 font-bold text-slate-900">
                        {log.quantityKg} kg <span className="text-[10px] text-slate-400 font-normal">({(log.quantityKg / 50).toFixed(1)} bags)</span>
                      </td>
                      <td className="p-3">
                        <span className="bg-amber-50 text-amber-800 border border-amber-200/60 font-mono font-bold px-2 py-0.5 rounded text-[11px]">
                          {(log.dailyConsumptionPerBirdGrams || ((log.quantityKg * 1000) / (headcount || 1))).toFixed(1)} g / bird
                        </span>
                      </td>
                      <td className="p-3 font-black text-slate-900">
                        {currencySymbol}{Number(log.cost).toFixed(2)}
                      </td>
                      <td className="p-3 font-mono font-bold text-emerald-600">
                        {currencySymbol}{(log.dailyCostPerBird || (log.cost / (headcount || 1))).toFixed(2)} / bird
                      </td>
                      <td className="p-3 text-slate-500">{log.fedBy}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* RESTOCK MODAL */}
      {showRestockModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-black text-slate-900 text-sm">Purchase / Restock Feed Store</h3>
                <p className="text-[10px] text-slate-400 font-medium">Record feed purchase and automatically post Dr 5210 Feed Expense</p>
              </div>
              <button 
                type="button"
                onClick={() => setShowRestockModal(false)} 
                className="text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleRestockFeed} className="space-y-4 text-xs">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Feed Formulation Name</label>
                <input
                  type="text"
                  required
                  value={restockForm.feedType}
                  onChange={(e) => setRestockForm({ ...restockForm, feedType: e.target.value })}
                  placeholder="e.g. Broiler Starter Crumble (50kg)"
                  className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-semibold"
                />
              </div>

              {/* Supplier Selection & Registration Section */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-[10px] font-black uppercase text-slate-700 tracking-wider">
                    <Building2 size={13} className="text-emerald-600" />
                    <span>Feed Supplier / Payee</span>
                  </div>
                  <div className="flex items-center gap-1 bg-white p-0.5 rounded-lg border border-slate-200">
                    <button
                      type="button"
                      onClick={() => setSupplierMode("select")}
                      className={`px-2 py-1 rounded text-[10px] font-black transition-all ${
                        supplierMode === "select"
                          ? "bg-slate-900 text-white shadow-xs"
                          : "text-slate-600 hover:text-slate-900"
                      }`}
                    >
                      Existing Supplier ({feedSuppliers.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setSupplierMode("new")}
                      className={`px-2 py-1 rounded text-[10px] font-black transition-all ${
                        supplierMode === "new"
                          ? "bg-emerald-600 text-white shadow-xs"
                          : "text-slate-600 hover:text-slate-900"
                      }`}
                    >
                      + Register New
                    </button>
                  </div>
                </div>

                {supplierMode === "select" ? (
                  <div>
                    {feedSuppliers.length > 0 ? (
                      <select
                        value={selectedSupplierId}
                        onChange={(e) => handleSelectSupplier(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl bg-white border border-slate-200 font-bold text-xs text-slate-800"
                      >
                        {feedSuppliers.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name} {s.category ? `• ${s.category}` : ""} {s.phone ? `(${s.phone})` : ""}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 text-[11px] flex items-center justify-between">
                        <span>No suppliers registered yet. Switch to "+ Register New" to add one.</span>
                        <button
                          type="button"
                          onClick={() => setSupplierMode("new")}
                          className="font-black text-amber-800 underline"
                        >
                          Add Now
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-2.5 bg-white p-3 rounded-xl border border-emerald-200/80">
                    <div className="flex items-center gap-1.5 text-[10px] font-black text-emerald-700 uppercase">
                      <Sparkles size={12} />
                      <span>Auto-populates Supplier Register & Payee Tracker</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[9px] font-black uppercase text-slate-400 block">Supplier Name *</label>
                        <input
                          type="text"
                          required={supplierMode === "new"}
                          value={newSupplierForm.name}
                          onChange={(e) => {
                            setNewSupplierForm({ ...newSupplierForm, name: e.target.value });
                            setRestockForm({ ...restockForm, brandSupplier: e.target.value });
                          }}
                          placeholder="e.g. Nutri Feeds Zambia"
                          className="w-full mt-0.5 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-bold"
                        />
                      </div>

                      <div>
                        <label className="text-[9px] font-black uppercase text-slate-400 block">Contact Person</label>
                        <input
                          type="text"
                          value={newSupplierForm.contactPerson}
                          onChange={(e) => setNewSupplierForm({ ...newSupplierForm, contactPerson: e.target.value })}
                          placeholder="e.g. Sales Desk"
                          className="w-full mt-0.5 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-semibold"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="text-[9px] font-black uppercase text-slate-400 block">Phone *</label>
                        <input
                          type="text"
                          value={newSupplierForm.phone}
                          onChange={(e) => setNewSupplierForm({ ...newSupplierForm, phone: e.target.value })}
                          placeholder="097..."
                          className="w-full mt-0.5 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-[9px] font-black uppercase text-slate-400 block">Email</label>
                        <input
                          type="email"
                          value={newSupplierForm.email}
                          onChange={(e) => setNewSupplierForm({ ...newSupplierForm, email: e.target.value })}
                          placeholder="orders@..."
                          className="w-full mt-0.5 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-[9px] font-black uppercase text-slate-400 block">TPIN / Tax ID</label>
                        <input
                          type="text"
                          value={newSupplierForm.tpin}
                          onChange={(e) => setNewSupplierForm({ ...newSupplierForm, tpin: e.target.value })}
                          placeholder="100..."
                          className="w-full mt-0.5 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[9px] font-black uppercase text-slate-400 block">Address / Location</label>
                      <input
                        type="text"
                        value={newSupplierForm.address}
                        onChange={(e) => setNewSupplierForm({ ...newSupplierForm, address: e.target.value })}
                        placeholder="e.g. Plot 1284, Heavy Industrial Area, Lusaka"
                        className="w-full mt-0.5 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-medium"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Feed Category</label>
                  <select
                    value={restockForm.category}
                    onChange={(e) => setRestockForm({ ...restockForm, category: e.target.value as any })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-semibold"
                  >
                    <option value="Starter">Starter Crumble</option>
                    <option value="Grower">Grower Mash / Pellets</option>
                    <option value="Finisher">Finisher Pellets</option>
                    <option value="Layer">Layer Mash</option>
                    <option value="Kienyeji">Kienyeji / Indigenous</option>
                    <option value="Concentrate">Concentrate</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Restock / Purchase Date</label>
                  <input
                    type="date"
                    required
                    value={restockForm.date}
                    onChange={(e) => setRestockForm({ ...restockForm, date: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Bags Purchased</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={restockForm.bagsPurchased}
                    onChange={(e) => setRestockForm({ ...restockForm, bagsPurchased: Number(e.target.value) })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Weight / Bag (kg)</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={restockForm.bagWeightKg}
                    onChange={(e) => setRestockForm({ ...restockForm, bagWeightKg: Number(e.target.value) })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Cost / Bag ({currencySymbol})</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={restockForm.costPerBag}
                    onChange={(e) => setRestockForm({ ...restockForm, costPerBag: Number(e.target.value) })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold"
                  />
                </div>
              </div>

              {/* Purchase Summary Box */}
              <div className="p-3 bg-emerald-50 border border-emerald-200/60 rounded-2xl space-y-2 text-xs text-emerald-900 font-bold">
                <div className="flex justify-between items-center">
                  <div>
                    <span className="block text-[10px] text-emerald-700 uppercase font-black">Total Stock Added</span>
                    <span>{restockForm.bagsPurchased * restockForm.bagWeightKg} kg ({restockForm.bagsPurchased} Bags)</span>
                  </div>
                  <div className="text-right">
                    <span className="block text-[10px] text-emerald-700 uppercase font-black">Total Purchase Cost</span>
                    <span className="text-base font-black text-emerald-900">{currencySymbol}{(restockForm.bagsPurchased * restockForm.costPerBag).toLocaleString()}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-emerald-200/60 flex items-center justify-between text-[10px] text-emerald-800 font-medium">
                  <span>CoA Posting: Dr 5210 (Poultry Feed) • Cr 1010 (Bank Operational)</span>
                  <span className="bg-emerald-200/60 text-emerald-900 px-2 py-0.5 rounded font-black font-mono">Finance Auto-Synced</span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRestockModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black cursor-pointer shadow-md flex items-center gap-1.5"
                >
                  <CheckCircle2 size={14} className="text-emerald-400" />
                  Confirm & Post to Finance Ledger
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* LOG FEED INTAKE MODAL */}
      {showLogFeedModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                  <Scale size={16} className="text-emerald-500" />
                  Log Feed Intake per Batch
                </h3>
                <p className="text-[10px] text-slate-400 font-medium">
                  Select feed type, quantity, and cost to update batch feed log and post expense
                </p>
              </div>
              <button 
                type="button"
                onClick={() => setShowLogFeedModal(false)} 
                className="text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleLogFeed} className="space-y-4 text-xs">
              {/* Batch & Date */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                    Select Flock Batch
                  </label>
                  <select
                    value={selectedBatchId}
                    onChange={(e) => setSelectedBatchId(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-bold text-slate-800"
                  >
                    {batches.map(b => (
                      <option key={b.id} value={b.id}>
                        {b.batchName} ({b.poultryType} • {b.currentHeadcount} birds)
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                    Feeding Date
                  </label>
                  <input
                    type="date"
                    required
                    value={feedForm.date}
                    onChange={(e) => setFeedForm({ ...feedForm, date: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-bold"
                  />
                </div>
              </div>

              {/* Feed Formulation Selection */}
              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                  Feed Formulation / Type
                </label>
                <select
                  value={selectedFeedInvId}
                  onChange={(e) => {
                    setSelectedFeedInvId(e.target.value);
                    setCustomCostOverride("");
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-bold text-slate-800"
                >
                  {feedInventory.map(f => (
                    <option key={f.id} value={f.id}>
                      {f.feedType} — {currencySymbol}{f.costPerBag}/50kg bag ({f.totalKgInStock}kg in stock)
                    </option>
                  ))}
                </select>
              </div>

              {/* Quantity Input with kg / bags toggle */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                    Quantity Consumed
                  </label>
                  <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-[10px] font-black">
                    <button
                      type="button"
                      onClick={() => setInputUnitMode("kg")}
                      className={`px-2.5 py-0.5 rounded-md transition-all cursor-pointer ${
                        inputUnitMode === "kg" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500"
                      }`}
                    >
                      Kilograms (kg)
                    </button>
                    <button
                      type="button"
                      onClick={() => setInputUnitMode("bags")}
                      className={`px-2.5 py-0.5 rounded-md transition-all cursor-pointer ${
                        inputUnitMode === "bags" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500"
                      }`}
                    >
                      50kg Bags
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <input
                      type="number"
                      step={inputUnitMode === "bags" ? "0.1" : "0.5"}
                      min="0.1"
                      required
                      value={quantityInput}
                      onChange={(e) => setQuantityInput(Number(e.target.value))}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-mono font-black text-slate-900 text-base"
                    />
                  </div>

                  <div className="p-2.5 bg-slate-100 rounded-xl flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-medium">Equates to:</span>
                    <strong className="text-slate-800 font-mono">
                      {inputUnitMode === "kg"
                        ? `${(resolvedQuantityKg / 50).toFixed(2)} Bags (50kg)`
                        : `${resolvedQuantityKg.toFixed(1)} kg`}
                    </strong>
                  </div>
                </div>
              </div>

              {/* Feed Cost & Unit Price */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                    Cost per kg ({currencySymbol})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    disabled={customCostOverride !== ""}
                    value={selectedFeedItem ? selectedFeedItem.costPerKg.toFixed(2) : (getFarmOperationalConfig().defaultFeedCostPerKg ? getFarmOperationalConfig().defaultFeedCostPerKg.toFixed(2) : "0.00")}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-100 border border-slate-200 font-mono font-bold text-slate-600"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                    Custom Total Cost Override ({currencySymbol})
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={customCostOverride}
                    onChange={(e) => setCustomCostOverride(e.target.value)}
                    placeholder={`Auto: ${currencySymbol}${computedFeedCost.toFixed(2)}`}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold text-slate-800"
                  />
                </div>
              </div>

              {/* Attendant & Notes */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                    Fed By (Attendant)
                  </label>
                  <select
                    value={feedForm.fedBy}
                    onChange={(e) => setFeedForm({ ...feedForm, fedBy: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 font-medium"
                  >
                    <option value="">-- Select Worker --</option>
                    {employees.map((emp, i) => (
                      <option key={i} value={emp.name}>{emp.name} ({emp.role || "Worker"})</option>
                    ))}
                    <option value="Poultry Attendant">Poultry Attendant</option>
                    <option value="Farm Manager">Farm Manager</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">
                    Intake Notes / Appetite
                  </label>
                  <input
                    type="text"
                    value={feedForm.notes}
                    onChange={(e) => setFeedForm({ ...feedForm, notes: e.target.value })}
                    placeholder="e.g. Good appetite, water refreshed"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 font-medium"
                  />
                </div>
              </div>

              {/* Live Costing & Metrics Callout */}
              <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-2">
                <div className="flex justify-between items-center text-xs border-b border-slate-800 pb-2">
                  <span className="text-slate-400 uppercase font-black text-[10px]">Active Birds in Flock</span>
                  <span className="font-bold text-slate-200">{currentHeadcount} Birds</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase block font-bold">Daily Intake / Bird</span>
                    <strong className="text-amber-400 font-mono text-sm">{dailyGramsPerBird.toFixed(1)} g / bird / day</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase block font-bold">Daily Cost / Bird</span>
                    <strong className="text-emerald-400 font-mono text-sm">{currencySymbol}{dailyCostPerBird.toFixed(2)} / bird</strong>
                  </div>
                </div>

                <div className="flex justify-between items-center pt-2 border-t border-slate-800 font-bold text-xs">
                  <div>
                    <span className="text-slate-300 block">Total Feed Cost Charged:</span>
                    <span className="text-[10px] text-emerald-400 font-mono">Debit 5210 Poultry Feed & Crumbles</span>
                  </div>
                  <span className="text-emerald-400 text-xl font-black font-mono">
                    {currencySymbol}{computedFeedCost.toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowLogFeedModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-xs font-black cursor-pointer shadow-md"
                >
                  Post Feed Intake & Debit Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useState, useEffect, useMemo } from "react";
import { PoultryBatch, PoultryHealthEvent, MedicationInventoryItem } from "./types";
import { 
  ShieldAlert, Stethoscope, Plus, AlertTriangle, CheckCircle2, DollarSign, 
  Calendar, Clock, Download, Filter, User, Syringe, Pill, Info, Lock
} from "lucide-react";

interface PoultryMedicationManagerProps {
  batches: PoultryBatch[];
  currencySymbol: string;
  onUpdateBatch: (batch: PoultryBatch) => void;
  accounts: any[];
  setAccounts: (accs: any[]) => void;
  writeAuditLog: (action: string, module: string, target: string, details: string) => void;
  employees?: any[];
  onAddExpense?: (tx: any) => void;
  onAddSupplier?: (sup: any) => void;
  suppliers?: any[];
  activeFarm?: any;
}

export const INITIAL_MED_INVENTORY: MedicationInventoryItem[] = [];

export default function PoultryMedicationManager({
  batches,
  currencySymbol,
  onUpdateBatch,
  accounts,
  setAccounts,
  writeAuditLog,
  employees = [],
  onAddExpense,
  onAddSupplier,
  suppliers = [],
  activeFarm
}: PoultryMedicationManagerProps) {
  // Inventory state
  const [medInventory, setMedInventory] = useState<MedicationInventoryItem[]>(() => {
    try {
      const saved = localStorage.getItem("mabala_poultry_medication_inventory");
      return saved ? JSON.parse(saved) : INITIAL_MED_INVENTORY;
    } catch {
      return INITIAL_MED_INVENTORY;
    }
  });

  useEffect(() => {
    localStorage.setItem("mabala_poultry_medication_inventory", JSON.stringify(medInventory));
  }, [medInventory]);

  // Modal states
  const [showAdministerModal, setShowAdministerModal] = useState(false);
  const [showAddMedModal, setShowAddMedModal] = useState(false);
  const [selectedBatchId, setSelectedBatchId] = useState<string>("");
  const [selectedMedInvId, setSelectedMedInvId] = useState<string>("");

  // Filters
  const [filterBatch, setFilterBatch] = useState<string>("all");
  const [filterCategory, setFilterCategory] = useState<string>("all");

  // Administer Form
  const [adminForm, setAdminForm] = useState({
    date: new Date().toISOString().split("T")[0],
    type: "vaccination" as PoultryHealthEvent["type"],
    category: "Vaccine" as PoultryHealthEvent["category"],
    quantityDoses: 0,
    customProduct: "",
    customCost: 0,
    targetDisease: "",
    route: "",
    birdsTreated: 0,
    withdrawalPeriodDays: 0,
    administeredBy: "",
    notes: ""
  });

  // Add Med Inventory Form
  const [newMedForm, setNewMedForm] = useState({
    brandName: "",
    category: "Vaccine" as MedicationInventoryItem["category"],
    activeIngredient: "",
    routeOfAdmin: "",
    unit: "vials" as MedicationInventoryItem["unit"],
    quantityInStock: 0,
    unitCost: 0,
    withdrawalPeriodDays: 0,
    expiryDate: "",
    supplier: ""
  });

  useEffect(() => {
    const active = batches.filter(b => b.status === "active" || (b.status as string).includes("ACTIVE"));
    if (active.length > 0 && !selectedBatchId) {
      setSelectedBatchId(active[0].id);
      setAdminForm(prev => ({ ...prev, birdsTreated: active[0].currentHeadcount || active[0].initialHeadcount }));
    }
    if (medInventory.length > 0 && !selectedMedInvId) {
      setSelectedMedInvId(medInventory[0].id);
    }
  }, [batches, medInventory]);

  const activeBatches = useMemo(() => {
    return batches.filter(b => b.status === "active" || (b.status as string).includes("ACTIVE"));
  }, [batches]);

  const selectedBatch = useMemo(() => {
    return batches.find(b => b.id === selectedBatchId) || activeBatches[0];
  }, [batches, selectedBatchId, activeBatches]);

  const selectedMedItem = useMemo(() => {
    return medInventory.find(m => m.id === selectedMedInvId);
  }, [medInventory, selectedMedInvId]);

  // When selected med inventory item changes, auto-fill form properties
  useEffect(() => {
    if (selectedMedItem) {
      setAdminForm(prev => ({
        ...prev,
        category: selectedMedItem.category,
        withdrawalPeriodDays: selectedMedItem.withdrawalPeriodDays,
        route: selectedMedItem.routeOfAdmin,
        customCost: selectedMedItem.unitCost * prev.quantityDoses
      }));
    }
  }, [selectedMedInvId, selectedMedItem]);

  // Helper to post double-entry ledger
  const postLedger = (debitCode: string, creditCode: string, amount: number) => {
    if (isNaN(amount) || amount <= 0 || !setAccounts) return;
    setAccounts(accounts.map(acc => {
      let bal = acc.balance;
      if (acc.code === debitCode) bal += amount;
      if (acc.code === creditCode) bal -= amount;
      return { ...acc, balance: bal };
    }));
  };

  // Submit Add New Medication to Store
  const handleAddMedToStore = (e: React.FormEvent) => {
    e.preventDefault();
    const newItem: MedicationInventoryItem = {
      id: `med-inv-${Date.now()}`,
      brandName: newMedForm.brandName,
      category: newMedForm.category,
      activeIngredient: newMedForm.activeIngredient,
      routeOfAdmin: newMedForm.routeOfAdmin,
      unit: newMedForm.unit,
      quantityInStock: Number(newMedForm.quantityInStock),
      unitCost: Number(newMedForm.unitCost),
      withdrawalPeriodDays: Number(newMedForm.withdrawalPeriodDays),
      reorderLevel: 3,
      expiryDate: newMedForm.expiryDate,
      supplier: newMedForm.supplier
    };

    const totalCost = newItem.quantityInStock * newItem.unitCost;

    // Auto-register supplier if provided
    if (newMedForm.supplier && onAddSupplier) {
      const existing = suppliers.find(s => s.name.toLowerCase() === newMedForm.supplier.trim().toLowerCase());
      if (!existing) {
        onAddSupplier({
          id: `SUP-VET-${Date.now()}`,
          name: newMedForm.supplier.trim(),
          contactPerson: "Pharmacy / Agrovet Sales",
          phone: "0977000333",
          email: "",
          address: "Agrovet & Vet Supplies Depot",
          tpin: "1002345678",
          category: "Veterinary Drugs & Biologicals",
          notes: `Registered from Poultry Med Store on ${new Date().toISOString().split("T")[0]}`,
          farmId: activeFarm?.id,
          tenantId: activeFarm?.tenantId
        });
      }
    }

    setMedInventory([...medInventory, newItem]);

    // Ledger: Debit 5215 (Drugs) / 5300 (Vaccines), Credit 1010 (Bank)
    const medCoa = newItem.category === "Vaccine" ? "5300" : "5215";
    postLedger(medCoa, "1010", totalCost);

    // Auto-post to Continuous Expenses
    if (onAddExpense && totalCost > 0) {
      onAddExpense({
        id: `EXP-MED-${Date.now()}`,
        supplierId: `SUP-${Date.now()}`,
        supplierName: newItem.supplier || "Veterinary Supplier",
        date: new Date().toISOString().split("T")[0],
        taxSystem: "Exempt",
        taxAmount: 0,
        subtotal: totalCost,
        total: totalCost,
        amount: totalCost,
        farmId: activeFarm?.id,
        tenantId: activeFarm?.tenantId,
        rows: [
          {
            category: newItem.category === "Vaccine" ? "Poultry Vaccines & Vet Drugs Expense" : "Drugs",
            description: `Restock ${newItem.quantityInStock} ${newItem.unit} of ${newItem.brandName} (${newItem.category})`,
            quantity: Number(newItem.quantityInStock),
            unitPrice: Number(newItem.unitCost),
            amount: totalCost,
            coaCode: medCoa,
            allocationType: "poultry_farmwide",
            poultryBatchName: "Poultry Pharmacy Store Restock"
          }
        ]
      });
    }

    writeAuditLog("PURCHASE", "Medication Inventory", newItem.brandName, `Purchased ${newItem.quantityInStock} ${newItem.unit} of ${newItem.brandName} for ${currencySymbol}${totalCost}`);

    setShowAddMedModal(false);
  };

  // Submit Administer Medication
  const handleAdministerMedication = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBatch) return;

    const cost = Number(adminForm.customCost);
    const productName = selectedMedItem ? selectedMedItem.brandName : adminForm.customProduct;
    const withdrawalDays = Number(adminForm.withdrawalPeriodDays);

    let withdrawalCloseDate: string | undefined = undefined;
    if (withdrawalDays > 0) {
      const d = new Date(adminForm.date);
      d.setDate(d.getDate() + withdrawalDays);
      withdrawalCloseDate = d.toISOString().split("T")[0];
    }

    const logId = `MED-${Date.now().toString().slice(-6)}`;

    const newLog: PoultryHealthEvent = {
      id: logId,
      date: adminForm.date,
      type: adminForm.type,
      category: adminForm.category,
      product: productName,
      cost,
      notes: adminForm.notes,
      withdrawalPeriodDays: withdrawalDays,
      withdrawalCloseDate,
      administeredBy: adminForm.administeredBy || "Veterinary Officer",
      birdsTreated: Number(adminForm.birdsTreated),
      dosage: selectedMedItem ? selectedMedItem.activeIngredient : "Standard Dosage",
      route: adminForm.route,
      targetDisease: adminForm.targetDisease,
      quantityDoses: adminForm.quantityDoses
    };

    // Deduct stock from inventory
    if (selectedMedItem) {
      const updatedInv = medInventory.map(item => {
        if (item.id === selectedMedItem.id) {
          return {
            ...item,
            quantityInStock: Math.max(0, item.quantityInStock - adminForm.quantityDoses)
          };
        }
        return item;
      });
      setMedInventory(updatedInv);
    }

    // Update batch health logs & cumulative health cost
    const updatedBatch: PoultryBatch = {
      ...selectedBatch,
      healthLogs: [newLog, ...(selectedBatch.healthLogs || [])],
      cumulativeHealthCost: (selectedBatch.cumulativeHealthCost || 0) + cost,
      updatedAt: new Date().toISOString()
    };

    onUpdateBatch(updatedBatch);

    // Double Entry Ledger: Debit 5215 (Drugs) / 5300 (Vaccines), Credit 1010 (Bank)
    const adminCoa = (adminForm.category === "Vaccine" || adminForm.type === "vaccination") ? "5300" : "5215";
    postLedger(adminCoa, "1010", cost);

    // Continuous Expenses integration with batch allocation
    if (onAddExpense && cost > 0) {
      onAddExpense({
        id: `EXP-HEALTH-${Date.now()}`,
        supplierId: `SUP-${Date.now()}`,
        supplierName: selectedMedItem?.supplier || "Agrovet & Vet Supplies",
        date: adminForm.date,
        taxSystem: "Exempt",
        taxAmount: 0,
        subtotal: cost,
        total: cost,
        amount: cost,
        farmId: activeFarm?.id,
        tenantId: activeFarm?.tenantId,
        rows: [
          {
            category: adminCoa === "5300" ? "Poultry Vaccines & Vet Drugs Expense" : "Drugs",
            description: `Administered ${productName} (${adminForm.type}) to flock ${selectedBatch.batchName} (${adminForm.birdsTreated} birds treated)`,
            quantity: 1,
            unitPrice: cost,
            amount: cost,
            coaCode: adminCoa,
            allocationType: "poultry_batch",
            poultryBatchId: selectedBatch.id,
            poultryBatchName: selectedBatch.batchName
          }
        ]
      });
    }

    writeAuditLog("CREATE", "Poultry Medication Log", selectedBatch.batchId, `Administered ${productName} to flock ${selectedBatch.batchName} (${adminForm.birdsTreated} birds) costing ${currencySymbol}${cost}`);

    setShowAdministerModal(false);
  };

  // Combine all health logs across flocks
  const allHealthLogs = useMemo(() => {
    const list: { batchName: string; batchId: string; headcount: number; log: PoultryHealthEvent }[] = [];
    batches.forEach(b => {
      if (filterBatch !== "all" && b.id !== filterBatch) return;
      (b.healthLogs || []).forEach(l => {
        if (filterCategory !== "all" && l.category !== filterCategory) return;
        list.push({
          batchName: b.batchName,
          batchId: b.batchId,
          headcount: b.currentHeadcount || b.initialHeadcount,
          log: l
        });
      });
    });
    return list.sort((a, b) => new Date(b.log.date).getTime() - new Date(a.log.date).getTime());
  }, [batches, filterBatch, filterCategory]);

  // Aggregate Stats
  const medAggregates = useMemo(() => {
    let totalMedExpense = 0;
    let activeWithdrawalCount = 0;
    const nowTime = new Date().getTime();

    allHealthLogs.forEach(item => {
      totalMedExpense += item.log.cost || 0;
      if (item.log.withdrawalCloseDate) {
        const closeTime = new Date(item.log.withdrawalCloseDate).getTime();
        if (closeTime >= nowTime) {
          activeWithdrawalCount++;
        }
      }
    });

    const totalStockValue = medInventory.reduce((sum, item) => sum + (item.quantityInStock * item.unitCost), 0);

    return {
      totalMedExpense,
      activeWithdrawalCount,
      totalStockValue,
      totalLogCount: allHealthLogs.length
    };
  }, [allHealthLogs, medInventory]);

  // Export CSV
  const exportMedCSV = () => {
    let csv = "Date,Flock Batch,Product / Vaccine,Category,Cost,Birds Treated,Route,Withdrawal Days,Withdrawal Close Date,Administered By,Notes\n";
    allHealthLogs.forEach(item => {
      const l = item.log;
      csv += `"${l.date}","${item.batchName}","${l.product}","${l.category || l.type}",${l.cost},${l.birdsTreated || item.headcount},"${l.route || ''}",${l.withdrawalPeriodDays || 0},"${l.withdrawalCloseDate || 'None'}","${l.administeredBy || ''}","${l.notes || ''}"\n`;
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Poultry_Medication_Tracking_Report_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
  };

  return (
    <div className="space-y-6" id="poultry-medication-manager-root">
      {/* Top Banner & Quick Actions */}
      <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider">
            <Stethoscope size={16} />
            <span>Flock Health & Medication Module</span>
          </div>
          <h2 className="text-2xl font-black mt-1">Poultry Vaccine, Treatment & Withdrawal Radar</h2>
          <p className="text-slate-400 text-xs mt-1 max-w-xl">
            Administer vaccines, antibiotics and dewormers, track cost per bird, manage withdrawal periods for food safety, and auto-post entries to COA <span className="text-rose-400 font-mono font-bold">5300 Veterinary & Medication Expense</span>.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setShowAddMedModal(true)}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 border border-slate-700 cursor-pointer"
          >
            <Plus size={14} />
            Add Meds to Pharmacy
          </button>

          <button
            onClick={() => setShowAdministerModal(true)}
            className="px-5 py-2.5 bg-rose-500 hover:bg-rose-400 text-white rounded-xl text-xs font-black shadow-lg shadow-rose-950/40 transition-all flex items-center gap-2 cursor-pointer"
          >
            <Syringe size={16} />
            Administer Medication
          </button>
        </div>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Vet & Med Expense</span>
          <div className="flex items-baseline justify-between">
            <strong className="text-2xl font-black text-slate-900">{currencySymbol}{medAggregates.totalMedExpense.toLocaleString()}</strong>
            <span className="text-xs font-bold text-rose-600 font-mono">Dr 5300</span>
          </div>
          <p className="text-[10px] text-slate-500 font-medium">Synced with Financial Engine & P&L</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Pharmacy Store Value</span>
          <div className="flex items-baseline justify-between">
            <strong className="text-2xl font-black text-slate-900">{currencySymbol}{medAggregates.totalStockValue.toLocaleString()}</strong>
            <span className="text-xs font-bold text-slate-500">{medInventory.length} Items</span>
          </div>
          <p className="text-[10px] text-slate-500 font-medium">In-stock vaccines & antibiotics</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Active Withdrawal Periods</span>
          <div className="flex items-baseline justify-between">
            <strong className={`text-2xl font-black ${medAggregates.activeWithdrawalCount > 0 ? "text-amber-600" : "text-emerald-600"}`}>
              {medAggregates.activeWithdrawalCount} Flocks
            </strong>
            {medAggregates.activeWithdrawalCount > 0 ? (
              <span className="text-xs font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded">Withholding</span>
            ) : (
              <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">All Clear</span>
            )}
          </div>
          <p className="text-[10px] text-slate-500 font-medium">Chemical residue safety radar</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Avg Med Cost / Bird</span>
          <div className="flex items-baseline justify-between">
            <strong className="text-2xl font-black text-rose-600">
              {batches.length > 0
                ? `${currencySymbol}${(medAggregates.totalMedExpense / (batches.reduce((s, b) => s + (b.currentHeadcount || 1), 0) || 1)).toFixed(2)}`
                : `${currencySymbol}0.35`}
            </strong>
            <span className="text-xs font-bold text-slate-500">per bird</span>
          </div>
          <p className="text-[10px] text-slate-500 font-medium">Cumulative health expenditure</p>
        </div>
      </div>

      {/* Medication Pharmacy Store Table */}
      <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-xs space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
              <Pill size={16} className="text-rose-500" />
              Pharmacy Inventory & Vaccine Store
            </h3>
            <p className="text-[11px] text-slate-400 font-medium">Registered vaccines, antibiotics and supplements in stock</p>
          </div>
          <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
            {medInventory.length} Products
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                <th className="p-3">Medication Name</th>
                <th className="p-3">Category</th>
                <th className="p-3">Active Ingredient</th>
                <th className="p-3">Route of Admin</th>
                <th className="p-3">In Stock</th>
                <th className="p-3">Unit Cost</th>
                <th className="p-3">Withdrawal</th>
                <th className="p-3">Expiry Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {medInventory.map(item => (
                <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="p-3 font-black text-slate-800">{item.brandName}</td>
                  <td className="p-3">
                    <span className="bg-rose-50 text-rose-700 text-[10px] font-bold px-2 py-0.5 rounded-md border border-rose-100">
                      {item.category}
                    </span>
                  </td>
                  <td className="p-3 font-medium text-slate-600">{item.activeIngredient}</td>
                  <td className="p-3 text-slate-500 font-mono text-[11px]">{item.routeOfAdmin}</td>
                  <td className="p-3 font-bold text-slate-900">{item.quantityInStock} {item.unit}</td>
                  <td className="p-3 font-bold text-slate-900">{currencySymbol}{item.unitCost.toFixed(2)}</td>
                  <td className="p-3 font-bold text-slate-700">
                    {item.withdrawalPeriodDays > 0 ? `${item.withdrawalPeriodDays} Days` : "0 Days (None)"}
                  </td>
                  <td className="p-3 font-mono text-slate-500">{item.expiryDate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Medication Administration History Table */}
      <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
              <Syringe size={16} className="text-rose-500" />
              Medication Administration & Health Event History
            </h3>
            <p className="text-[11px] text-slate-400 font-medium">Complete record of flock vaccinations, treatments, and cost per bird</p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <Filter size={14} className="text-slate-400" />
              <select
                value={filterBatch}
                onChange={(e) => setFilterBatch(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none"
              >
                <option value="all">All Flocks / Batches</option>
                {batches.map(b => (
                  <option key={b.id} value={b.id}>{b.batchName} ({b.batchId})</option>
                ))}
              </select>

              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none"
              >
                <option value="all">All Categories</option>
                <option value="Vaccine">Vaccine</option>
                <option value="Antibiotic">Antibiotic</option>
                <option value="Dewormer">Dewormer</option>
                <option value="Vitamin/Supplement">Vitamin/Supplement</option>
                <option value="Coccidiostat">Coccidiostat</option>
              </select>
            </div>

            <button
              onClick={exportMedCSV}
              className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Download size={14} /> Export CSV
            </button>
          </div>
        </div>

        {allHealthLogs.length === 0 ? (
          <div className="p-8 text-center text-slate-400 space-y-2 border border-dashed border-slate-200 rounded-2xl">
            <Stethoscope size={32} className="mx-auto text-slate-300" />
            <p className="text-xs font-bold text-slate-600">No medication logs recorded yet</p>
            <p className="text-[11px]">Click "Administer Medication" to record vaccines or treatments given to your flocks.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                  <th className="p-3">Date</th>
                  <th className="p-3">Flock Batch</th>
                  <th className="p-3">Medication / Vaccine</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Cost</th>
                  <th className="p-3">Cost / Bird</th>
                  <th className="p-3">Withdrawal Status</th>
                  <th className="p-3">Administered By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {allHealthLogs.map(({ batchName, batchId, headcount, log }) => {
                  const nowTime = new Date().getTime();
                  const isWithholding = log.withdrawalCloseDate 
                    ? new Date(log.withdrawalCloseDate).getTime() >= nowTime 
                    : false;

                  const costPerBird = log.cost / (log.birdsTreated || headcount || 1);

                  return (
                    <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-mono font-bold text-slate-700">{log.date}</td>
                      <td className="p-3">
                        <strong className="text-slate-900 font-black block">{batchName}</strong>
                        <span className="text-[10px] font-mono text-slate-400">{batchId}</span>
                      </td>
                      <td className="p-3 font-bold text-slate-800">
                        {log.product}
                        {log.targetDisease && <span className="block text-[10px] text-slate-400 font-normal">Target: {log.targetDisease}</span>}
                      </td>
                      <td className="p-3">
                        <span className="bg-slate-100 text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded">
                          {log.category || log.type}
                        </span>
                      </td>
                      <td className="p-3 font-black text-slate-900">{currencySymbol}{log.cost.toFixed(2)}</td>
                      <td className="p-3 font-mono font-bold text-rose-600">
                        {currencySymbol}{costPerBird.toFixed(2)} / bird
                      </td>
                      <td className="p-3">
                        {isWithholding ? (
                          <span className="bg-amber-100 text-amber-800 border border-amber-300 text-[10px] font-black px-2 py-0.5 rounded flex items-center gap-1 w-fit">
                            <ShieldAlert size={12} /> Active until {log.withdrawalCloseDate}
                          </span>
                        ) : (
                          <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 w-fit">
                            <CheckCircle2 size={12} /> Cleared (0 Days)
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-slate-500 font-medium">{log.administeredBy}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ADMINISTER MEDICATION MODAL */}
      {showAdministerModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-black text-slate-900 text-sm">Administer Medication / Vaccine</h3>
                <p className="text-[10px] text-slate-400 font-medium">Record flock treatment, cost and withdrawal period</p>
              </div>
              <button onClick={() => setShowAdministerModal(false)} className="text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleAdministerMedication} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Select Flock Batch</label>
                  <select
                    value={selectedBatchId}
                    onChange={(e) => setSelectedBatchId(e.target.value)}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-bold text-slate-800"
                  >
                    {activeBatches.map(b => (
                      <option key={b.id} value={b.id}>
                        {b.batchName} ({b.currentHeadcount} birds)
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Date Administered</label>
                  <input
                    type="date"
                    required
                    value={adminForm.date}
                    onChange={(e) => setAdminForm({ ...adminForm, date: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Medication From Pharmacy</label>
                  <select
                    value={selectedMedInvId}
                    onChange={(e) => setSelectedMedInvId(e.target.value)}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-bold text-slate-800"
                  >
                    <option value="">-- Custom Medication Entry --</option>
                    {medInventory.map(m => (
                      <option key={m.id} value={m.id}>
                        {m.brandName} ({m.quantityInStock} {m.unit})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Category</label>
                  <select
                    value={adminForm.category}
                    onChange={(e) => setAdminForm({ ...adminForm, category: e.target.value as any })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-semibold"
                  >
                    <option value="Vaccine">Vaccine</option>
                    <option value="Antibiotic">Antibiotic</option>
                    <option value="Dewormer">Dewormer</option>
                    <option value="Vitamin/Supplement">Vitamin/Supplement</option>
                    <option value="Coccidiostat">Coccidiostat</option>
                    <option value="Disinfectant">Disinfectant</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              {!selectedMedItem && (
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Custom Product Name</label>
                  <input
                    type="text"
                    required
                    value={adminForm.customProduct}
                    onChange={(e) => setAdminForm({ ...adminForm, customProduct: e.target.value })}
                    placeholder="e.g. Fowl Pox Live Vaccine"
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-semibold"
                  />
                </div>
              )}

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Target Disease / Reason</label>
                  <input
                    type="text"
                    value={adminForm.targetDisease}
                    onChange={(e) => setAdminForm({ ...adminForm, targetDisease: e.target.value })}
                    placeholder="e.g. Newcastle Disease"
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Birds Treated</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={adminForm.birdsTreated}
                    onChange={(e) => setAdminForm({ ...adminForm, birdsTreated: Number(e.target.value) })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Cost ({currencySymbol})</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={adminForm.customCost}
                    onChange={(e) => setAdminForm({ ...adminForm, customCost: Number(e.target.value) })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Withdrawal Period (Days)</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={adminForm.withdrawalPeriodDays}
                    onChange={(e) => setAdminForm({ ...adminForm, withdrawalPeriodDays: Number(e.target.value) })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Administered By</label>
                  <select
                    value={adminForm.administeredBy}
                    onChange={(e) => setAdminForm({ ...adminForm, administeredBy: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-semibold"
                  >
                    <option value="">-- Select Person --</option>
                    {employees.map((emp, i) => (
                      <option key={i} value={emp.name}>{emp.name} ({emp.role || "Veterinary Assistant"})</option>
                    ))}
                    <option value="District Veterinary Officer">District Veterinary Officer</option>
                    <option value="Farm Manager">Farm Manager</option>
                  </select>
                </div>
              </div>

              <div className="p-3 bg-rose-50 border border-rose-200/60 rounded-2xl flex justify-between items-center text-xs text-rose-900 font-bold">
                <div>
                  <span className="block text-[10px] text-rose-700 uppercase font-black">Medication Cost / Bird</span>
                  <span>{currencySymbol}{(adminForm.customCost / (adminForm.birdsTreated || 1)).toFixed(2)} per bird</span>
                </div>
                <div className="text-right">
                  <span className="block text-[10px] text-rose-700 uppercase font-black">Ledger Expense Code</span>
                  <span className="font-mono text-rose-900 font-black">Dr 5300 (Vet Expense)</span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAdministerModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-black cursor-pointer shadow-md"
                >
                  Record Administration & Post Ledger
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD NEW MEDICATION TO PHARMACY STORE MODAL */}
      {showAddMedModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-black text-slate-900 text-sm">Add Product to Pharmacy Store</h3>
                <p className="text-[10px] text-slate-400 font-medium">Record newly acquired veterinary medicine stock</p>
              </div>
              <button onClick={() => setShowAddMedModal(false)} className="text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleAddMedToStore} className="space-y-4 text-xs">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Brand Name</label>
                <input
                  type="text"
                  required
                  value={newMedForm.brandName}
                  onChange={(e) => setNewMedForm({ ...newMedForm, brandName: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Category</label>
                  <select
                    value={newMedForm.category}
                    onChange={(e) => setNewMedForm({ ...newMedForm, category: e.target.value as any })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-semibold"
                  >
                    <option value="Vaccine">Vaccine</option>
                    <option value="Antibiotic">Antibiotic</option>
                    <option value="Dewormer">Dewormer</option>
                    <option value="Vitamin/Supplement">Vitamin/Supplement</option>
                    <option value="Coccidiostat">Coccidiostat</option>
                    <option value="Disinfectant">Disinfectant</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Active Ingredient</label>
                  <input
                    type="text"
                    required
                    value={newMedForm.activeIngredient}
                    onChange={(e) => setNewMedForm({ ...newMedForm, activeIngredient: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Quantity Stock</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={newMedForm.quantityInStock}
                    onChange={(e) => setNewMedForm({ ...newMedForm, quantityInStock: Number(e.target.value) })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Unit Cost ({currencySymbol})</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={newMedForm.unitCost}
                    onChange={(e) => setNewMedForm({ ...newMedForm, unitCost: Number(e.target.value) })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Withdrawal (Days)</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={newMedForm.withdrawalPeriodDays}
                    onChange={(e) => setNewMedForm({ ...newMedForm, withdrawalPeriodDays: Number(e.target.value) })}
                    className="w-full mt-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddMedModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black cursor-pointer shadow-md"
                >
                  Save to Pharmacy Store
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useMemo } from "react";
import { Scale, Zap, Info, ArrowUpRight, CheckCircle2, AlertTriangle, Activity } from "lucide-react";
import { PoultryBatch } from "./types";

interface FcrMetricCardProps {
  batch: PoultryBatch;
}

export default function FcrMetricCard({ batch }: FcrMetricCardProps) {
  const fcrData = useMemo(() => {
    // Cumulative feed consumed (kg)
    const totalFeedKg = (batch.feedLogs || []).reduce((acc, log) => acc + (log.quantityKg || 0), 0);

    let fcrRatio = 0;
    let label = "";
    let subtext = "";
    let status: "EXCELLENT" | "GOOD" | "ATTENTION" | "INSUFFICIENT" = "GOOD";
    let benchmarkText = "";

    if (batch.poultryType === "broiler") {
      // Broiler FCR = Total Feed Kg / Total Live Weight Gained Kg
      // Latest weight sample
      const latestSample = batch.weightSamples && batch.weightSamples.length > 0
        ? batch.weightSamples[batch.weightSamples.length - 1].averageWeightKg
        : 1.8; // default mature broiler weight estimate if no sample recorded

      const dayOldChickWeightKg = 0.042; // ~42 grams per day-old chick
      const currentLiveMass = batch.currentHeadcount * latestSample;
      const initialLiveMass = batch.initialHeadcount * dayOldChickWeightKg;
      const weightGainedKg = Math.max(0.1, currentLiveMass - initialLiveMass);

      if (totalFeedKg > 0 && weightGainedKg > 0) {
        fcrRatio = Number((totalFeedKg / weightGainedKg).toFixed(2));
      }

      label = "Broiler Feed Conversion Ratio (FCR)";
      subtext = `${totalFeedKg.toLocaleString()} kg feed used / ${weightGainedKg.toFixed(1)} kg total live mass gained`;

      if (fcrRatio === 0) {
        status = "INSUFFICIENT";
        benchmarkText = "Log daily feed & weight samples to activate live FCR calculation.";
      } else if (fcrRatio <= 1.60) {
        status = "EXCELLENT";
        benchmarkText = "Optimal Broiler Efficiency! Outstanding feed-to-meat conversion (1.4 - 1.6 target).";
      } else if (fcrRatio <= 1.85) {
        status = "GOOD";
        benchmarkText = "Standard Commercial Broiler FCR. Good growth rate and feed utilization.";
      } else {
        status = "ATTENTION";
        benchmarkText = "High FCR (> 1.85). Inspect for feed wastage, feeder height, or health stress.";
      }

    } else {
      // Layer or Village flock: Egg FCR (Kg feed per Kg egg mass or Kg feed per dozen)
      const totalEggs = (batch.eggCollections || []).reduce((acc, c) => acc + (c.totalCollected || 0), 0);
      const totalEggMassKg = totalEggs * 0.06; // ~60g average egg
      const totalDozen = totalEggs / 12;

      if (totalFeedKg > 0 && totalEggMassKg > 0) {
        fcrRatio = Number((totalFeedKg / totalEggMassKg).toFixed(2));
      }

      const feedPerDozen = totalDozen > 0 ? Number((totalFeedKg / totalDozen).toFixed(2)) : 0;

      label = "Layer Production Feed Efficiency (Egg FCR)";
      subtext = totalEggMassKg > 0 
        ? `${totalFeedKg.toLocaleString()} kg feed / ${totalEggMassKg.toFixed(1)} kg egg mass (${feedPerDozen} kg/dozen)`
        : `${totalFeedKg.toLocaleString()} kg total feed logged`;

      if (fcrRatio === 0) {
        status = "INSUFFICIENT";
        benchmarkText = "Log daily feed & egg collection logs to calculate Egg FCR.";
      } else if (fcrRatio <= 2.2) {
        status = "EXCELLENT";
        benchmarkText = "Optimal Layer Efficiency! Excellent feed conversion to egg mass (Target: 2.0 - 2.2).";
      } else if (fcrRatio <= 2.6) {
        status = "GOOD";
        benchmarkText = "Satisfactory Layer Feed Efficiency.";
      } else {
        status = "ATTENTION";
        benchmarkText = "Suboptimal Layer FCR. Check for feed spillage or non-laying birds.";
      }
    }

    return {
      totalFeedKg,
      fcrRatio,
      label,
      subtext,
      status,
      benchmarkText
    };
  }, [batch]);

  const getBadgeStyle = () => {
    switch (fcrData.status) {
      case "EXCELLENT":
        return { bg: "bg-emerald-500/10 border-emerald-500/30 text-emerald-400", pill: "bg-emerald-500 text-slate-950" };
      case "GOOD":
        return { bg: "bg-sky-500/10 border-sky-500/30 text-sky-400", pill: "bg-sky-500 text-slate-950" };
      case "ATTENTION":
        return { bg: "bg-amber-500/10 border-amber-500/30 text-amber-400", pill: "bg-amber-500 text-slate-950" };
      default:
        return { bg: "bg-slate-800 border-slate-700 text-slate-400", pill: "bg-slate-700 text-slate-300" };
    }
  };

  const style = getBadgeStyle();

  return (
    <div className={`p-4 rounded-2xl border ${style.bg} space-y-2.5 font-sans transition-all`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Scale className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-[10.5px] font-black uppercase tracking-wider text-slate-200">
            {fcrData.label}
          </span>
        </div>
        <span className={`text-[8.5px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full ${style.pill}`}>
          {fcrData.status}
        </span>
      </div>

      <div className="flex items-baseline justify-between gap-3">
        <div>
          <div className="text-2xl font-black font-mono text-white tracking-tight flex items-baseline gap-1.5">
            <span>{fcrData.fcrRatio > 0 ? fcrData.fcrRatio.toFixed(2) : "N/A"}</span>
            <span className="text-xs font-semibold text-slate-400">
              {batch.poultryType === "broiler" ? "kg feed / kg meat gained" : "kg feed / kg egg mass"}
            </span>
          </div>
          <p className="text-[10.5px] text-slate-300 font-medium mt-0.5">
            {fcrData.subtext}
          </p>
        </div>
      </div>

      <div className="p-2 bg-slate-900/60 rounded-xl border border-slate-800/80 text-[10px] text-slate-300 font-medium flex items-center gap-2">
        {fcrData.status === "ATTENTION" ? (
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
        ) : (
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
        )}
        <span>{fcrData.benchmarkText}</span>
      </div>
    </div>
  );
}

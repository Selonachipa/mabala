import React, { useState, useMemo } from "react";
import { Calculator, Package, Info, ArrowRight, CheckCircle2, DollarSign, Sparkles, Layers } from "lucide-react";
import { PoultryBatch } from "./types";

interface NutriFeedsRequirementChartProps {
  currencySymbol: string;
  batches?: PoultryBatch[];
  onSelectFeedRecommendation?: (rec: {
    birds: number;
    starterBags: number;
    growerBags: number;
    finisherBags: number;
    totalBags: number;
    totalKg: number;
    estCost: number;
  }) => void;
}

export const NUTRI_FEEDS_TABLE = [
  { doc: 50, starter: 1, grower: 1, finisher: 2, total: 4.0 },
  { doc: 100, starter: 2, grower: 3, finisher: 3, total: 8.0 },
  { doc: 150, starter: 3, grower: 4, finisher: 5, total: 12.0 },
  { doc: 200, starter: 3, grower: 5, finisher: 6, total: 14.0 },
  { doc: 250, starter: 4, grower: 6, finisher: 8, total: 18.0 },
  { doc: 300, starter: 5, grower: 7, finisher: 9, total: 21.0 },
  { doc: 350, starter: 6, grower: 8, finisher: 11, total: 25.0 },
  { doc: 400, starter: 6, grower: 10, finisher: 12, total: 28.0 },
  { doc: 450, starter: 7, grower: 11, finisher: 14, total: 32.0 },
  { doc: 500, starter: 8, grower: 12, finisher: 15, total: 35.0 },
];

export default function NutriFeedsRequirementChart({
  currencySymbol,
  batches = [],
  onSelectFeedRecommendation,
}: NutriFeedsRequirementChartProps) {
  // Interactive Calculator State
  const [customBirds, setCustomBirds] = useState<number>(100);
  const [starterPrice, setStarterPrice] = useState<number>(380); // standard 50kg bag price
  const [growerPrice, setGrowerPrice] = useState<number>(360);
  const [finisherPrice, setFinisherPrice] = useState<number>(350);
  const [highlightRow, setHighlightRow] = useState<number | null>(100);

  // Dynamic formula calculation for any chick quantity based on standard Nutri Feeds 6-week ratio
  // Standard feed consumption at 6 weeks: ~3.5kg total per bird
  // Starter (0-2 weeks): ~0.8kg / bird (~23% of total feed)
  // Grower (2-4 weeks): ~1.2kg / bird (~34% of total feed)
  // Finisher (4-6 weeks): ~1.5kg / bird (~43% of total feed)
  const calculatedRequirements = useMemo(() => {
    const birds = Math.max(1, Number(customBirds) || 0);

    // If exact match in reference table, use standard reference values
    const exactMatch = NUTRI_FEEDS_TABLE.find((r) => r.doc === birds);
    if (exactMatch) {
      const totalKg = exactMatch.total * 50;
      const starterCost = exactMatch.starter * starterPrice;
      const growerCost = exactMatch.grower * growerPrice;
      const finisherCost = exactMatch.finisher * finisherPrice;
      const totalCost = starterCost + growerCost + finisherCost;

      return {
        birds,
        starterBags: exactMatch.starter,
        growerBags: exactMatch.grower,
        finisherBags: exactMatch.finisher,
        totalBags: exactMatch.total,
        totalKg,
        starterKg: exactMatch.starter * 50,
        growerKg: exactMatch.grower * 50,
        finisherKg: exactMatch.finisher * 50,
        starterCost,
        growerCost,
        finisherCost,
        totalCost,
        costPerBird: totalCost / birds,
        feedPerBirdKg: totalKg / birds,
      };
    }

    // Otherwise calculate dynamically using Nutri Feeds proportional curves
    // Ratio per 500 birds: 8 starter (400kg), 12 grower (600kg), 15 finisher (750kg) = 35 bags (1750kg)
    const factor = birds / 500;
    const rawStarter = factor * 8;
    const rawGrower = factor * 12;
    const rawFinisher = factor * 15;

    // Round to nearest integer or 0.5 bag for practicality
    const starterBags = Math.max(1, Math.round(rawStarter));
    const growerBags = Math.max(1, Math.round(rawGrower));
    const finisherBags = Math.max(1, Math.round(rawFinisher));
    const totalBags = starterBags + growerBags + finisherBags;

    const totalKg = totalBags * 50;
    const starterCost = starterBags * starterPrice;
    const growerCost = growerBags * growerPrice;
    const finisherCost = finisherBags * finisherPrice;
    const totalCost = starterCost + growerCost + finisherCost;

    return {
      birds,
      starterBags,
      growerBags,
      finisherBags,
      totalBags,
      totalKg,
      starterKg: starterBags * 50,
      growerKg: growerBags * 50,
      finisherKg: finisherBags * 50,
      starterCost,
      growerCost,
      finisherCost,
      totalCost,
      costPerBird: totalCost / birds,
      feedPerBirdKg: totalKg / birds,
    };
  }, [customBirds, starterPrice, growerPrice, finisherPrice]);

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden" id="nutri-feeds-program-root">
      {/* Top Banner styled to match the official Nutri Feeds Chart */}
      <div className="bg-gradient-to-r from-red-900 via-red-800 to-amber-950 text-white p-6 sm:p-7 relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
            <span className="bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full flex items-center gap-1.5">
              <Sparkles size={12} />
              NUTRI Feeds Recommended Feeding Program
            </span>
            <span className="text-xs font-bold text-red-200 bg-black/30 px-3 py-1 rounded-full">
              6-Week Broiler Target Program
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black tracking-tight uppercase max-w-2xl leading-snug">
            Estimated Number of 50kg Bags of Feed Required for the Given Chick Quantities
          </h2>

          <p className="text-xs text-red-100/90 mt-2 max-w-3xl leading-relaxed">
            Standard feeding schedule showing the total number of 50kg bags of Starter, Grower, and Finisher feed required to raise broiler day-old chicks (DOC) to full market maturity at <strong>SIX WEEKS (42 Days)</strong>.
          </p>
        </div>

        {/* Decorative background accents */}
        <div className="absolute right-0 top-0 bottom-0 w-80 bg-radial from-amber-500/10 to-transparent pointer-events-none" />
      </div>

      <div className="p-5 sm:p-6 space-y-6">
        {/* Interactive Dynamic Feed Estimator & Budget Tool */}
        <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 shadow-md">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                <Calculator size={20} />
              </div>
              <div>
                <h3 className="text-sm font-black text-white">Dynamic 6-Week Feed Budget & Requirement Calculator</h3>
                <p className="text-[11px] text-slate-400">
                  Select or input your flock size (DOC) to calculate total 50kg feed bags and estimated feeding costs.
                </p>
              </div>
            </div>

            {/* Quick Flock Size Presets */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] font-bold text-slate-400 uppercase mr-1">Quick Select DOC:</span>
              {[50, 100, 200, 300, 500, 1000].map((count) => (
                <button
                  key={count}
                  type="button"
                  onClick={() => {
                    setCustomBirds(count);
                    setHighlightRow(count <= 500 ? count : null);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    customBirds === count
                      ? "bg-amber-500 text-slate-950 font-black shadow-xs"
                      : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"
                  }`}
                >
                  {count} DOC
                </button>
              ))}
            </div>
          </div>

          {/* Calculator Inputs and Outputs Grid */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pt-4">
            {/* Inputs Column */}
            <div className="md:col-span-5 space-y-3">
              <div>
                <label className="text-[10px] font-black uppercase text-amber-400 tracking-wider block mb-1">
                  Number of Day-Old Chicks (DOC)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={customBirds}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setCustomBirds(val);
                      setHighlightRow(NUTRI_FEEDS_TABLE.some((r) => r.doc === val) ? val : null);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-base font-mono font-black text-white focus:border-amber-400 focus:outline-none"
                    placeholder="Enter flock headcount..."
                  />
                  <span className="absolute right-3 top-2.5 text-xs font-bold text-slate-400">Birds / Chicks</span>
                </div>
              </div>

              {/* Price per 50kg bag inputs */}
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Starter ({currencySymbol}/50kg)</label>
                  <input
                    type="number"
                    value={starterPrice}
                    onChange={(e) => setStarterPrice(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 font-mono font-bold text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Grower ({currencySymbol}/50kg)</label>
                  <input
                    type="number"
                    value={growerPrice}
                    onChange={(e) => setGrowerPrice(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 font-mono font-bold text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Finisher ({currencySymbol}/50kg)</label>
                  <input
                    type="number"
                    value={finisherPrice}
                    onChange={(e) => setFinisherPrice(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 font-mono font-bold text-white text-xs"
                  />
                </div>
              </div>
            </div>

            {/* Stage Feed Breakdown Cards */}
            <div className="md:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {/* Starter */}
              <div className="bg-red-950/40 border border-red-900/60 rounded-xl p-3 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase text-red-400 block tracking-wider">Starter Feed</span>
                  <span className="text-[9px] text-slate-400 font-medium">Weeks 0 - 2 (Crumble)</span>
                  <div className="text-xl font-black text-white font-mono mt-1">
                    {calculatedRequirements.starterBags}{" "}
                    <span className="text-xs font-normal text-slate-300">Bags</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{calculatedRequirements.starterKg} kg</span>
                </div>
                <div className="pt-2 mt-2 border-t border-red-900/40 text-[10px] font-bold text-red-300">
                  {currencySymbol}{calculatedRequirements.starterCost.toLocaleString()}
                </div>
              </div>

              {/* Grower */}
              <div className="bg-amber-950/40 border border-amber-900/60 rounded-xl p-3 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase text-amber-400 block tracking-wider">Grower Feed</span>
                  <span className="text-[9px] text-slate-400 font-medium">Weeks 3 - 4 (Pellets)</span>
                  <div className="text-xl font-black text-white font-mono mt-1">
                    {calculatedRequirements.growerBags}{" "}
                    <span className="text-xs font-normal text-slate-300">Bags</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{calculatedRequirements.growerKg} kg</span>
                </div>
                <div className="pt-2 mt-2 border-t border-amber-900/40 text-[10px] font-bold text-amber-300">
                  {currencySymbol}{calculatedRequirements.growerCost.toLocaleString()}
                </div>
              </div>

              {/* Finisher */}
              <div className="bg-emerald-950/40 border border-emerald-900/60 rounded-xl p-3 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase text-emerald-400 block tracking-wider">Finisher Feed</span>
                  <span className="text-[9px] text-slate-400 font-medium">Weeks 5 - 6 (Pellets)</span>
                  <div className="text-xl font-black text-white font-mono mt-1">
                    {calculatedRequirements.finisherBags}{" "}
                    <span className="text-xs font-normal text-slate-300">Bags</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{calculatedRequirements.finisherKg} kg</span>
                </div>
                <div className="pt-2 mt-2 border-t border-emerald-900/40 text-[10px] font-bold text-emerald-300">
                  {currencySymbol}{calculatedRequirements.finisherCost.toLocaleString()}
                </div>
              </div>

              {/* Total Summary */}
              <div className="bg-slate-800 border border-slate-700 rounded-xl p-3 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase text-amber-400 block tracking-wider">Total Feed</span>
                  <span className="text-[9px] text-slate-400 font-medium">At 6 Weeks Maturity</span>
                  <div className="text-xl font-black text-amber-400 font-mono mt-1">
                    {calculatedRequirements.totalBags.toFixed(2)}{" "}
                    <span className="text-xs font-normal text-slate-300">Bags</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{calculatedRequirements.totalKg.toLocaleString()} kg</span>
                </div>
                <div className="pt-2 mt-2 border-t border-slate-700 text-xs font-black text-emerald-400">
                  {currencySymbol}{calculatedRequirements.totalCost.toLocaleString()}
                </div>
              </div>
            </div>
          </div>

          {/* Calculation Bottom Callout */}
          <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-4 text-slate-300">
              <span>
                Avg Feed / Bird: <strong className="text-white font-mono">{calculatedRequirements.feedPerBirdKg.toFixed(2)} kg</strong>
              </span>
              <span>
                Feed Cost / Bird: <strong className="text-emerald-400 font-mono">{currencySymbol}{calculatedRequirements.costPerBird.toFixed(2)}</strong>
              </span>
            </div>

            {onSelectFeedRecommendation && (
              <button
                type="button"
                onClick={() =>
                  onSelectFeedRecommendation({
                    birds: calculatedRequirements.birds,
                    starterBags: calculatedRequirements.starterBags,
                    growerBags: calculatedRequirements.growerBags,
                    finisherBags: calculatedRequirements.finisherBags,
                    totalBags: calculatedRequirements.totalBags,
                    totalKg: calculatedRequirements.totalKg,
                    estCost: calculatedRequirements.totalCost,
                  })
                }
                className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
              >
                Apply Feed Plan to Flock Log <ArrowRight size={14} />
              </button>
            )}
          </div>
        </div>

        {/* Official Reference Matrix Table (exact replica of provided Nutri Feeds Chart) */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                <Layers size={16} className="text-red-700" />
                Nutri Feeds Official 6-Week Feed Matrix (50kg Bags)
              </h3>
              <p className="text-[11px] text-slate-500">
                Lookup table showing the standard bag allocations per stage for flock sizes from 50 to 500 birds.
              </p>
            </div>
            <span className="text-[11px] font-bold text-red-900 bg-red-50 border border-red-200 px-3 py-1 rounded-full">
              Standard 50kg Bags
            </span>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-red-900/30 shadow-xs">
            <table className="w-full text-center border-collapse text-xs">
              <thead>
                <tr className="bg-red-900 text-white font-black text-[11px] uppercase tracking-wider divide-x divide-red-800">
                  <th className="py-3 px-4 text-left">Number of DOC</th>
                  <th className="py-3 px-4">Bags of Starter</th>
                  <th className="py-3 px-4">Bags of Grower</th>
                  <th className="py-3 px-4">Bags of Finisher</th>
                  <th className="py-3 px-4 text-right">Total Bags</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-medium">
                {NUTRI_FEEDS_TABLE.map((row) => {
                  const isSelected = highlightRow === row.doc || customBirds === row.doc;
                  return (
                    <tr
                      key={row.doc}
                      onClick={() => {
                        setCustomBirds(row.doc);
                        setHighlightRow(row.doc);
                      }}
                      className={`cursor-pointer transition-colors divide-x divide-slate-100 ${
                        isSelected
                          ? "bg-amber-50 font-bold text-slate-950 border-l-4 border-l-red-700"
                          : "hover:bg-slate-50 text-slate-700"
                      }`}
                    >
                      <td className="py-2.5 px-4 text-left font-black text-slate-900 flex items-center justify-between">
                        <span>{row.doc} Birds</span>
                        {isSelected && (
                          <span className="text-[9px] bg-red-700 text-white px-1.5 py-0.5 rounded font-bold uppercase">
                            Selected
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-800">{row.starter}</td>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-800">{row.grower}</td>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-800">{row.finisher}</td>
                      <td className="py-2.5 px-4 text-right font-mono font-black text-red-900 bg-red-50/40">
                        {row.total.toFixed(2)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Footer note matching image */}
          <div className="mt-3 p-3 bg-red-50/70 border border-red-200/60 rounded-xl text-center">
            <p className="text-xs text-red-950 font-semibold">
              This is the <strong>NUTRI Feeds</strong> recommended feeding program, showing the total number of feed bags required based on the number of birds you have at <strong>SIX WEEKS</strong>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

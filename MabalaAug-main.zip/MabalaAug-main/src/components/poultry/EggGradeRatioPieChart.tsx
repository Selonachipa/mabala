import React, { useMemo } from "react";
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from "recharts";
import { Egg } from "lucide-react";
import { EggCollection } from "./types";

interface EggGradeRatioPieChartProps {
  key?: any;
  eggCollections?: EggCollection[];
  title?: string;
}

export default function EggGradeRatioPieChart({
  eggCollections = [],
  title = "30-Day Egg Quality Ratio"
}: EggGradeRatioPieChartProps) {
  const { chartData, totalGradeA, totalGradeB, totalBroken, totalCollected } = useMemo(() => {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const thirtyDaysMs = thirtyDaysAgo.getTime();

    let gradeA = 0;
    let gradeB = 0;
    let broken = 0;

    (eggCollections || []).forEach(c => {
      if (!c.date) return;
      const cTime = new Date(c.date).getTime();
      if (isNaN(cTime) || cTime < thirtyDaysMs) return;

      const brk = c.brokenCount || 0;
      broken += brk;

      if (c.useGrades) {
        // Grade A = Large + Ungraded
        // Grade B = Medium + Small
        gradeA += (c.large || 0) + (c.ungraded || 0);
        gradeB += (c.medium || 0) + (c.small || 0);
      } else {
        // Ungraded/Bulk collection
        const total = c.totalCollected || 0;
        const good = Math.max(0, total - brk);
        gradeA += good;
      }
    });

    const total = gradeA + gradeB + broken;

    const data = [
      { name: "Grade A", value: gradeA, color: "#10B981" }, // Emerald-500
      { name: "Grade B", value: gradeB, color: "#0ea5e9" }, // Sky-500
      { name: "Broken", value: broken, color: "#f43f5e" },   // Rose-500
    ].filter(d => d.value > 0);

    return {
      chartData: data,
      totalGradeA: gradeA,
      totalGradeB: gradeB,
      totalBroken: broken,
      totalCollected: total,
    };
  }, [eggCollections]);

  if (totalCollected === 0) {
    return (
      <div className="bg-slate-50/80 border border-slate-200/80 rounded-2xl p-3 text-center space-y-1">
        <div className="flex items-center justify-center gap-1.5 text-slate-500">
          <Egg className="w-3.5 h-3.5 text-amber-500" />
          <span className="text-[10px] font-extrabold uppercase tracking-wider">{title}</span>
        </div>
        <p className="text-[10.5px] text-slate-400 font-medium italic">
          No egg collections recorded in the last 30 days
        </p>
      </div>
    );
  }

  const pctA = totalCollected > 0 ? ((totalGradeA / totalCollected) * 100).toFixed(1) : "0.0";
  const pctB = totalCollected > 0 ? ((totalGradeB / totalCollected) * 100).toFixed(1) : "0.0";
  const pctBroken = totalCollected > 0 ? ((totalBroken / totalCollected) * 100).toFixed(1) : "0.0";

  return (
    <div className="bg-slate-50/90 border border-slate-200/90 rounded-2xl p-3.5 space-y-2.5 shadow-2xs">
      <div className="flex items-center justify-between border-b border-slate-200/60 pb-1.5">
        <div className="flex items-center gap-1.5">
          <Egg className="w-3.5 h-3.5 text-amber-500 shrink-0" />
          <span className="text-[10.5px] font-black uppercase text-slate-800 tracking-wider">
            {title}
          </span>
        </div>
        <span className="text-[10px] font-extrabold font-mono text-slate-500 bg-white px-2 py-0.5 rounded-full border border-slate-200">
          {totalCollected.toLocaleString()} total
        </span>
      </div>

      <div className="flex items-center justify-between gap-3">
        {/* Recharts Pie Chart */}
        <div className="w-24 h-24 shrink-0 relative flex items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={18}
                outerRadius={36}
                paddingAngle={3}
                stroke="#ffffff"
                strokeWidth={1.5}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                formatter={(val: number) => [`${val.toLocaleString()} eggs`, "Count"]}
                contentStyle={{
                  backgroundColor: "#0f172a",
                  borderColor: "#334155",
                  borderRadius: "8px",
                  fontSize: "10px",
                  color: "#ffffff",
                  fontWeight: "bold",
                  padding: "4px 8px"
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Legend Breakdown */}
        <div className="flex-1 space-y-1 text-[10.5px]">
          <div className="flex items-center justify-between p-1 px-2 bg-emerald-50/90 border border-emerald-100 rounded-lg">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="font-extrabold text-emerald-900">Grade A</span>
            </div>
            <span className="font-mono font-black text-emerald-800">
              {totalGradeA.toLocaleString()} ({pctA}%)
            </span>
          </div>

          <div className="flex items-center justify-between p-1 px-2 bg-sky-50/90 border border-sky-100 rounded-lg">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-sky-500" />
              <span className="font-extrabold text-sky-900">Grade B</span>
            </div>
            <span className="font-mono font-black text-sky-800">
              {totalGradeB.toLocaleString()} ({pctB}%)
            </span>
          </div>

          <div className="flex items-center justify-between p-1 px-2 bg-rose-50/90 border border-rose-100 rounded-lg">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-500" />
              <span className="font-extrabold text-rose-900">Broken</span>
            </div>
            <span className="font-mono font-black text-rose-800">
              {totalBroken.toLocaleString()} ({pctBroken}%)
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

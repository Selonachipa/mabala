export { default } from './institution/ConsolidatedTenantReport';

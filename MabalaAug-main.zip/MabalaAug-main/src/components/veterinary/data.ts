import { VetClient, VetStaff, VetAppointment, ClinicalRecord, MovementCard, LabSample, VaccineCampaign, DiseaseOutbreak, MedicationInventory, VetWalletTx } from "./types";

// Credit deduction cost sheet configurator (administrators can modify this dynamically in-app!)
export interface CreditCostItem {
  id: string;
  serviceName: string;
  creditsCost: number;
}

export const INITIAL_CREDIT_COSTS: CreditCostItem[] = [
  { id: "client_reg", serviceName: "Client Profile Registration", creditsCost: 5 },
  { id: "farm_onboard", serviceName: "Farm Portfolio Onboarding", creditsCost: 10 },
  { id: "consult_rec", serviceName: "Clinical Consultation Medical Log", creditsCost: 15 },
  { id: "vaccine_rec", serviceName: "Vaccination Record & Certificate Issuing", creditsCost: 8 },
  { id: "movement_card", serviceName: "QR-Verified Movements Permit", creditsCost: 20 },
  { id: "ai_diagnose", serviceName: "AI Disease Prediction & Copilot Support", creditsCost: 12 },
  { id: "laboratory_test", serviceName: "Laboratory Sample Test Approval", creditsCost: 10 },
  { id: "surveillance", serviceName: "Outbreak Epidemiological Notification Report Log", creditsCost: 8 }
];

export interface CreditBundle {
  id: string;
  name: string;
  credits: number;
  priceZmw: number;
  bonusCredits: number;
  promoCode?: string;
}

export const CREDIT_BUNDLES: CreditBundle[] = [
  { id: "bundle-100", name: "Starter Bundle", credits: 100, priceZmw: 220, bonusCredits: 10 },
  { id: "bundle-250", name: "Standard Bundle", credits: 250, priceZmw: 500, bonusCredits: 30 },
  { id: "bundle-500", name: "Professional Bundle", credits: 500, priceZmw: 950, bonusCredits: 75 },
  { id: "bundle-1000", name: "Network Bundle", credits: 1000, priceZmw: 1800, bonusCredits: 180 },
  { id: "bundle-2500", name: "Commercial Bundle", credits: 2500, priceZmw: 4200, bonusCredits: 500 },
  { id: "bundle-5000", name: "Enterprise Bundle", credits: 5000, priceZmw: 8000, bonusCredits: 1200 },
  { id: "bundle-10000", name: "Institutional Bundle", credits: 10000, priceZmw: 15000, bonusCredits: 3000 }
];

export const INITIAL_STAFF: VetStaff[] = [];

export const INITIAL_CLIENTS: VetClient[] = [];

export const INITIAL_APPOINTMENTS: VetAppointment[] = [];

export const INITIAL_CLINICAL_RECORDS: ClinicalRecord[] = [];

export const INITIAL_MOVEMENTS: MovementCard[] = [];

export const INITIAL_LABS: LabSample[] = [];

export const INITIAL_CAMPAIGNS: VaccineCampaign[] = [];

export const INITIAL_OUTBREAKS: DiseaseOutbreak[] = [];

export const INITIAL_MEDICATIONS: MedicationInventory[] = [];

export const INITIAL_VET_TRANSACTIONS: VetWalletTx[] = [];

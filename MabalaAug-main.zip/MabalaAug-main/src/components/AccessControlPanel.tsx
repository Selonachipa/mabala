import React, { useState, useMemo } from "react";
import { 
  Users, 
  Shield, 
  UserPlus, 
  Lock, 
  Unlock, 
  Check, 
  Trash2, 
  AlertCircle,
  Clock,
  Mail,
  UserSquare2,
  KeyRound,
  Ban,
  CheckCircle2,
  Sliders,
  FileText,
  Search,
  Key,
  Eye,
  EyeOff,
  History,
  Copy,
  ExternalLink
} from "lucide-react";
import { PredefinedRole, RolePermissionsMap, UserMember, AuditLog } from "../types";
import { AuditTrail } from "./AuditTrail";

export interface AccessControlPanelProps {
  currentRole: PredefinedRole;
  onChangeSessionRole: (role: PredefinedRole) => void;
  permissions: RolePermissionsMap;
  onUpdatePermission: (role: PredefinedRole, moduleId: string, type: "read" | "write", value: boolean) => void;
  teamMembers: UserMember[];
  onAddTeamMember: (member: Omit<UserMember, "id" | "lastActive">) => void;
  onRemoveTeamMember: (id: string) => void;
  onChangeMemberRole: (id: string, role: PredefinedRole) => void;
  onToggleUserSuspension?: (email: string, suspend: boolean, reason?: string) => Promise<void> | void;
  onUpdateTeamMember?: (email: string, updates: Partial<UserMember>) => Promise<void> | void;
  onChangeOwnPassword?: (newPassword: string) => Promise<boolean>;
  currencySymbol: string;
  adminClaimed: boolean;
  userEmail: string;
  activeFarmName: string;
  adminClaimantEmail: string;
  farms?: any[];
  subscriptionTier?: string;
  auditLogs?: AuditLog[];
  tenantId?: string;
}

export const SYSTEM_MODULES = [
  { id: "dashboard", label: "Dashboard Hub", category: "Core", desc: "Overview of farm YTD revenue, expenses, and operational status" },
  { id: "accounts", label: "Chart of Accounts", category: "Financial", desc: "Double-entry account structures, balances, and ledger mappings" },
  { id: "expenses", label: "Expenses Ledger", category: "Financial", desc: "Dual-entry expense vouchers, receipts, and supplier payouts" },
  { id: "sales", label: "Sales Tracker & POS", category: "Commercial", desc: "Direct farm retail point-of-sale receipts and ledger entries" },
  { id: "invoices", label: "Invoices & Quotations", category: "Commercial", desc: "Drafting, editing, sending, and receiving invoice statuses" },
  { id: "payroll", label: "Payroll Localizer", category: "HR & Compliance", desc: "Statutory PAYE, NAPSA, NHIMA levies, and employee payslips" },
  { id: "crops", label: "Crop Cycles & Field Tasks", category: "Operations", desc: "Block planning, planting cycles, spray schedules, and task stages" },
  { id: "livestock", label: "Livestock & Poultry Records", category: "Operations", desc: "Herd register, vaccinations, mortality, and egg production" },
  { id: "aquaculture", label: "Aquaculture & Pond Systems", category: "Operations", desc: "Pond water quality, dissolved oxygen, and fish sampling logs" },
  { id: "inventory", label: "Inventory & Warehouse Stock", category: "Operations", desc: "Input stock management, average cost valuation, and reorder alerts" },
  { id: "orchard", label: "Orchard & Nursery Hub", category: "Operations", desc: "Tree canopy tracking, grafting records, and harvest batches" },
  { id: "feed", label: "Feed Formulation Studio", category: "Operations", desc: "Least-cost ration recipes, nutritional constraints, and milling" },
  { id: "reports", label: "Financial Reports & Tax", category: "Financial", desc: "GAAP/IFRS Profit & Loss statements, balance sheets, and tax archives" },
  { id: "market-prices", label: "Commodity Market Prices", category: "Advisory", desc: "Live agricultural market price index and national buyer trends" },
  { id: "weather", label: "Agro-Weather Advisory", category: "Advisory", desc: "Hyperlocal precipitation forecasts and field spraying suitability" }
];

export default function AccessControlPanel({
  currentRole,
  onChangeSessionRole,
  permissions,
  onUpdatePermission,
  teamMembers,
  onAddTeamMember,
  onRemoveTeamMember,
  onChangeMemberRole,
  onToggleUserSuspension,
  onUpdateTeamMember,
  onChangeOwnPassword,
  currencySymbol,
  adminClaimed,
  userEmail,
  activeFarmName,
  adminClaimantEmail,
  farms = [],
  subscriptionTier,
  auditLogs = [],
  tenantId
}: AccessControlPanelProps) {
  // Navigation sub-tabs within panel
  const [mainView, setMainView] = useState<"users" | "matrix" | "audit">("users");
  const [activeRoleTab, setActiveRoleTab] = useState<PredefinedRole>("Accountant");
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [editingMember, setEditingMember] = useState<UserMember | null>(null);
  const [suspensionModalUser, setSuspensionModalUser] = useState<UserMember | null>(null);
  const [suspensionReason, setSuspensionReason] = useState("");
  const [passwordChangeModalUser, setPasswordChangeModalUser] = useState<UserMember | null>(null);
  const [newPasswordValue, setNewPasswordValue] = useState("");
  const [showSelfPasswordModal, setShowSelfPasswordModal] = useState(false);
  const [selfNewPassword, setSelfNewPassword] = useState("");
  const [selfConfirmPassword, setSelfConfirmPassword] = useState("");
  const [selfPasswordStatus, setSelfPasswordStatus] = useState<{ msg: string; type: "success" | "error" } | null>(null);
  const [actionInProgress, setActionInProgress] = useState(false);

  // New Member Form States
  const [newMemberName, setNewMemberName] = useState("");
  const [newMemberEmail, setNewMemberEmail] = useState("");
  const [newMemberRole, setNewMemberRole] = useState<PredefinedRole>("Accountant");
  const [newMemberPassword, setNewMemberPassword] = useState("");
  const [newMemberConfirmPassword, setNewMemberConfirmPassword] = useState("");
  const [newMemberError, setNewMemberError] = useState("");
  const [showPasswordText, setShowPasswordText] = useState(false);
  const [selectedFarmIds, setSelectedFarmIds] = useState<string[]>([]);
  
  // Custom module toggles for the new user (defaults by role)
  const [selectedModules, setSelectedModules] = useState<string[]>([
    "dashboard", "accounts", "expenses", "payroll", "invoices", "reports"
  ]);

  // Edit user custom module toggles
  const [editPermittedModules, setEditPermittedModules] = useState<string[]>([]);

  // Dispatched Email notice modal
  const [dispatchedEmailNotice, setDispatchedEmailNotice] = useState<{
    email: string;
    name: string;
    role: string;
    password: string;
    loginUrl: string;
    farmName: string;
    permittedModulesCount: number;
  } | null>(null);

  // Audit search and filter
  const [auditSearchQuery, setAuditSearchQuery] = useState("");
  const [auditActionFilter, setAuditActionFilter] = useState("ALL");

  const rolesList: PredefinedRole[] = (() => {
    const isSuperAdminEmail = userEmail === "support@mabala.cloud";
    const isClaimant = !adminClaimantEmail || userEmail === adminClaimantEmail || isSuperAdminEmail;

    if (currentRole === "Offtaker") {
      return ["Offtaker"];
    }

    if (!isClaimant) {
      return ["Farm Owner", "Agronomist", "Accountant", "Farm Manager", "Agro Dealer", "Farm Worker"];
    }
    return ["Platform Administrator", "Farm Owner", "Agronomist", "Accountant", "Farm Manager", "Agro Dealer", "Farm Worker"];
  })();

  const matrixRoles: PredefinedRole[] = ["Farm Owner", "Agronomist", "Accountant", "Farm Manager", "Agro Dealer", "Farm Worker"];

  const isOwner = currentRole === "Platform Administrator" || currentRole === "Farm Owner" || currentRole === "Super Admin";

  // Helper to get default modules for a role
  const getDefaultModulesForRole = (role: PredefinedRole): string[] => {
    switch (role) {
      case "Farm Owner":
      case "Platform Administrator":
      case "Super Admin":
        return SYSTEM_MODULES.map(m => m.id);
      case "Accountant":
        return ["dashboard", "accounts", "expenses", "sales", "invoices", "payroll", "reports", "inventory"];
      case "Farm Manager":
        return ["dashboard", "crops", "livestock", "aquaculture", "inventory", "orchard", "feed", "expenses", "weather"];
      case "Agronomist":
        return ["dashboard", "crops", "orchard", "weather", "inventory", "market-prices"];
      case "Agro Dealer":
        return ["dashboard", "sales", "inventory", "invoices", "expenses", "market-prices"];
      case "Farm Worker":
      default:
        return ["dashboard", "crops", "livestock", "tasks"];
    }
  };

  const handleRoleSelectChange = (role: PredefinedRole) => {
    setNewMemberRole(role);
    setSelectedModules(getDefaultModulesForRole(role));
  };

  const handleToggleModule = (moduleId: string) => {
    setSelectedModules(prev => 
      prev.includes(moduleId) ? prev.filter(id => id !== moduleId) : [...prev, moduleId]
    );
  };

  const handleToggleEditModule = (moduleId: string) => {
    setEditPermittedModules(prev => 
      prev.includes(moduleId) ? prev.filter(id => id !== moduleId) : [...prev, moduleId]
    );
  };

  const handleCreateMemberSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setNewMemberError("");
    if (!newMemberName.trim() || !newMemberEmail.trim()) {
      setNewMemberError("Full name and email address are required.");
      return;
    }
    if (!newMemberPassword || !newMemberConfirmPassword) {
      setNewMemberError("Password and confirmation password are required.");
      return;
    }
    if (newMemberPassword.length < 6) {
      setNewMemberError("Password must be at least 6 characters long.");
      return;
    }
    if (newMemberPassword !== newMemberConfirmPassword) {
      setNewMemberError("Passwords do not match.");
      return;
    }
    if (selectedModules.length === 0) {
      setNewMemberError("Please select at least one module for the user to access.");
      return;
    }
    
    // Check user organization list limit based on Enterprise subscription
    const maxTeamUsers = subscriptionTier === "Enterprise Suite" ? 20 : 10;
    if (teamMembers.length >= maxTeamUsers) {
      setNewMemberError(`Under your package (${subscriptionTier || "Standard"}), organization limits are restricted to ${maxTeamUsers} team users. Please upgrade or prune inactive users.`);
      return;
    }

    const cleanEmail = newMemberEmail.trim().toLowerCase();

    onAddTeamMember({
      name: newMemberName.trim(),
      email: cleanEmail,
      role: newMemberRole,
      accessibleFarmIds: selectedFarmIds.length > 0 ? selectedFarmIds : undefined,
      permittedModules: selectedModules,
      password: newMemberPassword,
      status: "Active",
      isSuspended: false,
      mustChangePassword: true,
      forcePasswordChange: true
    });

    const loginUrl = window.location.origin;
    setDispatchedEmailNotice({
      email: cleanEmail,
      name: newMemberName.trim(),
      role: newMemberRole,
      password: newMemberPassword,
      loginUrl,
      farmName: activeFarmName || "Mabala Farm Node",
      permittedModulesCount: selectedModules.length
    });

    // Reset Form
    setNewMemberName("");
    setNewMemberEmail("");
    setNewMemberPassword("");
    setNewMemberConfirmPassword("");
    setNewMemberRole("Accountant");
    setSelectedModules(getDefaultModulesForRole("Accountant"));
    setSelectedFarmIds([]);
    setShowAddMemberModal(false);
  };

  const handleOpenEditMember = (member: UserMember) => {
    setEditingMember(member);
    setEditPermittedModules(member.permittedModules && member.permittedModules.length > 0 
      ? [...member.permittedModules] 
      : getDefaultModulesForRole(member.role)
    );
  };

  const handleSaveEditMember = async () => {
    if (!editingMember) return;
    setActionInProgress(true);
    try {
      if (onUpdateTeamMember) {
        await onUpdateTeamMember(editingMember.email, {
          permittedModules: editPermittedModules,
          role: editingMember.role
        });
      }
      setEditingMember(null);
    } catch (err: any) {
      alert(err.message || "Failed to update user permissions.");
    } finally {
      setActionInProgress(false);
    }
  };

  const handleConfirmSuspension = async () => {
    if (!suspensionModalUser) return;
    setActionInProgress(true);
    try {
      const willSuspend = !suspensionModalUser.isSuspended;
      if (onToggleUserSuspension) {
        await onToggleUserSuspension(suspensionModalUser.email, willSuspend, suspensionReason);
      }
      setSuspensionModalUser(null);
      setSuspensionReason("");
    } catch (err: any) {
      alert(err.message || "Failed to toggle user suspension.");
    } finally {
      setActionInProgress(false);
    }
  };

  const handleAdminResetPassword = async () => {
    if (!passwordChangeModalUser) return;
    if (!newPasswordValue || newPasswordValue.length < 6) {
      alert("Password must be at least 6 characters long.");
      return;
    }
    setActionInProgress(true);
    try {
      if (onUpdateTeamMember) {
        await onUpdateTeamMember(passwordChangeModalUser.email, {
          password: newPasswordValue,
          mustChangePassword: true,
          forcePasswordChange: true
        });
      }
      alert(`Password updated successfully for ${passwordChangeModalUser.email}. They will be prompted to change it on their next login.`);
      setPasswordChangeModalUser(null);
      setNewPasswordValue("");
    } catch (err: any) {
      alert(err.message || "Failed to update user password.");
    } finally {
      setActionInProgress(false);
    }
  };

  const handleSelfChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setSelfPasswordStatus(null);
    if (!selfNewPassword || selfNewPassword.length < 6) {
      setSelfPasswordStatus({ msg: "New password must be at least 6 characters long.", type: "error" });
      return;
    }
    if (selfNewPassword !== selfConfirmPassword) {
      setSelfPasswordStatus({ msg: "Passwords do not match.", type: "error" });
      return;
    }
    setActionInProgress(true);
    try {
      if (onChangeOwnPassword) {
        await onChangeOwnPassword(selfNewPassword);
        setSelfPasswordStatus({ msg: "Your password has been changed successfully!", type: "success" });
        setTimeout(() => {
          setShowSelfPasswordModal(false);
          setSelfNewPassword("");
          setSelfConfirmPassword("");
          setSelfPasswordStatus(null);
        }, 1500);
      }
    } catch (err: any) {
      setSelfPasswordStatus({ msg: err.message || "Failed to update password.", type: "error" });
    } finally {
      setActionInProgress(false);
    }
  };

  // Filtered Audit Logs
  const filteredAuditLogs = useMemo(() => {
    return auditLogs.filter(log => {
      const matchesSearch = !auditSearchQuery.trim() || 
        log.user.toLowerCase().includes(auditSearchQuery.toLowerCase()) ||
        log.module.toLowerCase().includes(auditSearchQuery.toLowerCase()) ||
        log.detail.toLowerCase().includes(auditSearchQuery.toLowerCase()) ||
        log.record.toLowerCase().includes(auditSearchQuery.toLowerCase());
      
      const matchesAction = auditActionFilter === "ALL" || log.action === auditActionFilter;
      return matchesSearch && matchesAction;
    });
  }, [auditLogs, auditSearchQuery, auditActionFilter]);

  return (
    <div className="space-y-6 animate-fade-in" id="access-control-panel-container">
      {/* Top Header & Simulator Ribbon */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="p-1 px-2.5 bg-emerald-500 text-slate-950 font-bold text-[10px] uppercase rounded-full font-mono tracking-wider">Farm Workspace Security</span>
            <span className="text-xs text-slate-400 font-medium">{activeFarmName || "Current Farm Node"}</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight">Users, Roles & Granular Permissions</h2>
          <p className="text-slate-400 text-xs max-w-2xl leading-relaxed">
            Create and manage farm node sub-accounts with individual email and password logins. Toggle on/off specific modules for each team member, monitor audit trails, or suspend access instantly.
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShowSelfPasswordModal(true)}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-bold border border-slate-700 flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
            id="change-own-password-btn"
          >
            <Key className="w-3.5 h-3.5 text-emerald-400" />
            <span>Change My Password</span>
          </button>

          {isOwner && (
            <button
              onClick={() => setShowAddMemberModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-emerald-900/20"
              id="top-add-user-btn"
            >
              <UserPlus className="w-4 h-4" />
              <span>Add New User</span>
            </button>
          )}
        </div>
      </div>

      {/* Main View Navigation Tabs */}
      <div className="flex border-b border-slate-200 gap-4">
        <button
          onClick={() => setMainView("users")}
          className={`pb-3 text-xs font-bold transition-all flex items-center gap-2 border-b-2 ${
            mainView === "users"
              ? "border-emerald-600 text-emerald-700"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
          id="tab-users-directory"
        >
          <Users className="w-4 h-4" />
          <span>Farm Node Users ({teamMembers.length})</span>
        </button>

        <button
          onClick={() => setMainView("matrix")}
          className={`pb-3 text-xs font-bold transition-all flex items-center gap-2 border-b-2 ${
            mainView === "matrix"
              ? "border-emerald-600 text-emerald-700"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
          id="tab-permissions-matrix"
        >
          <Shield className="w-4 h-4" />
          <span>Role Permissions Matrix</span>
        </button>

        <button
          onClick={() => setMainView("audit")}
          className={`pb-3 text-xs font-bold transition-all flex items-center gap-2 border-b-2 ${
            mainView === "audit"
              ? "border-emerald-600 text-emerald-700"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
          id="tab-audit-trail"
        >
          <History className="w-4 h-4" />
          <span>Activity Audit Trail ({auditLogs.length})</span>
        </button>
      </div>

      {/* VIEW 1: FARM NODE USERS DIRECTORY */}
      {mainView === "users" && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-600" />
                  <span>Authorized Farm Node Accounts</span>
                </h3>
                <p className="text-slate-500 text-xs mt-1">
                  Team members attached exclusively to this farm workspace ({activeFarmName}). Users can only access permitted modules and cannot view other farm nodes.
                </p>
              </div>

              {isOwner && (
                <button
                  onClick={() => setShowAddMemberModal(true)}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                  id="add-new-user-btn"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Create User Account</span>
                </button>
              )}
            </div>

            <div className="divide-y divide-slate-100">
              {teamMembers.map((member) => {
                const isCurrentUser = member.email.toLowerCase() === userEmail.toLowerCase();
                const isSuspended = Boolean(member.isSuspended || member.status === "Suspended");
                const permittedCount = member.permittedModules?.length ?? (member.role === "Farm Owner" || member.role === "Platform Administrator" ? SYSTEM_MODULES.length : getDefaultModulesForRole(member.role).length);

                return (
                  <div 
                    key={member.id || member.email}
                    className={`p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-colors ${
                      isSuspended ? "bg-rose-50/40" : "hover:bg-slate-50/60"
                    }`}
                    id={`user-card-${member.email.replace(/[@.]/g, '-')}`}
                  >
                    <div className="flex items-start gap-3.5">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0 shadow-inner ${
                        isSuspended 
                          ? "bg-rose-200 text-rose-800"
                          : "bg-emerald-100 text-emerald-800"
                      }`}>
                        {member.avatar || member.name.charAt(0).toUpperCase()}
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-extrabold text-slate-900 text-sm">{member.name}</span>
                          {isCurrentUser && (
                            <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded-full text-[10px] font-extrabold font-mono">
                              YOU (CURRENT)
                            </span>
                          )}
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                            member.role === "Platform Administrator" || member.role === "Farm Owner"
                              ? "bg-emerald-50 border-emerald-200 text-emerald-700"
                              : member.role === "Accountant"
                                ? "bg-amber-50 border-amber-200 text-amber-700"
                                : member.role === "Farm Manager"
                                  ? "bg-blue-50 border-blue-200 text-blue-700"
                                  : "bg-purple-50 border-purple-200 text-purple-700"
                          }`}>
                            {member.role}
                          </span>

                          {/* Status Badge */}
                          {isSuspended ? (
                            <span className="px-2 py-0.5 bg-rose-100 border border-rose-300 text-rose-700 rounded-full text-[10px] font-bold flex items-center gap-1">
                              <Ban className="w-2.5 h-2.5" /> Suspended
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-emerald-100 border border-emerald-300 text-emerald-700 rounded-full text-[10px] font-bold flex items-center gap-1">
                              <CheckCircle2 className="w-2.5 h-2.5" /> Active
                            </span>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-3 text-slate-500 text-xs font-sans">
                          <span className="flex items-center gap-1 text-slate-600">
                            <Mail className="w-3 h-3 text-slate-400" />
                            {member.email}
                          </span>
                          <span className="text-slate-300">•</span>
                          <span className="flex items-center gap-1 text-slate-500 font-mono text-[11px]">
                            <Clock className="w-3 h-3 text-slate-400" />
                            Last active: {member.lastActive || "Recently"}
                          </span>
                        </div>

                        {/* Module Entitlement Preview */}
                        <div className="pt-1 flex items-center gap-2 flex-wrap text-[11px]">
                          <span className="text-slate-500 font-semibold">Accessible Modules ({permittedCount}):</span>
                          <div className="flex flex-wrap gap-1">
                            {SYSTEM_MODULES.filter(m => (member.permittedModules || getDefaultModulesForRole(member.role)).includes(m.id)).slice(0, 4).map(mod => (
                              <span key={mod.id} className="px-1.5 py-0.5 bg-slate-100 text-slate-700 rounded text-[10px] font-medium">
                                {mod.label}
                              </span>
                            ))}
                            {permittedCount > 4 && (
                              <span className="px-1.5 py-0.5 bg-slate-200 text-slate-600 rounded text-[10px] font-bold">
                                +{permittedCount - 4} more
                              </span>
                            )}
                          </div>
                        </div>

                        {isSuspended && member.suspensionReason && (
                          <div className="p-2 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 mt-1">
                            <strong>Reason:</strong> {member.suspensionReason}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Actions Toolbar */}
                    <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                      {isOwner && !isCurrentUser && (
                        <>
                          <button
                            onClick={() => handleOpenEditMember(member)}
                            className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all"
                            title="Configure accessible modules"
                          >
                            <Sliders className="w-3.5 h-3.5 text-slate-600" />
                            <span>Modules</span>
                          </button>

                          <button
                            onClick={() => setPasswordChangeModalUser(member)}
                            className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all"
                            title="Reset user login password"
                          >
                            <KeyRound className="w-3.5 h-3.5 text-slate-600" />
                            <span>Password</span>
                          </button>

                          <button
                            onClick={() => {
                              setSuspensionModalUser(member);
                              setSuspensionReason(member.suspensionReason || "");
                            }}
                            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                              isSuspended
                                ? "bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100"
                                : "bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100"
                            }`}
                            title={isSuspended ? "Reactivate user account" : "Suspend user account"}
                          >
                            {isSuspended ? (
                              <>
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Unsuspend</span>
                              </>
                            ) : (
                              <>
                                <Ban className="w-3.5 h-3.5" />
                                <span>Suspend</span>
                              </>
                            )}
                          </button>

                          <button
                            onClick={() => {
                              if (window.confirm(`Are you sure you want to permanently delete user account ${member.name} (${member.email}) from this farm node?`)) {
                                onRemoveTeamMember(member.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                            title="Delete User Account"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}

              {teamMembers.length === 0 && (
                <div className="p-12 text-center text-slate-400 text-xs">
                  No additional node users have been created for this farm yet. Click "Add New User" to invite staff.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: GRANULAR ROLE PERMISSIONS MATRIX */}
      {mainView === "matrix" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden min-h-[500px]">
          <div className="p-6 border-b border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-600" />
                <span>Granular Permissions Matrix by Role</span>
              </h3>
              <p className="text-slate-500 text-xs mt-1">
                Configure default Read and Write privileges for standard tenant roles across all system modules.
              </p>
            </div>
            
            <div className="flex flex-wrap bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              {matrixRoles.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveRoleTab(tab)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${
                    activeRoleTab === tab 
                      ? "bg-white text-slate-900 shadow-xs" 
                      : "text-slate-500 hover:text-slate-800"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="p-6">
            {!isOwner && (
              <div className="mb-4 p-3 bg-amber-50 border border-amber-200/60 rounded-xl text-xs text-amber-800 font-semibold flex items-center gap-2">
                <Lock className="w-3.5 h-3.5 shrink-0" />
                <span>Read-Only Preview: You need Farm Owner or Administrator privileges to modify role matrices.</span>
              </div>
            )}
            
            <div className="overflow-x-auto">
              <table className="w-full text-left font-sans text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[9px]">
                    <th className="pb-3 w-1/2">Module & Feature Scope</th>
                    <th className="pb-3 text-center px-4 w-1/4">Read Access</th>
                    <th className="pb-3 text-center px-4 w-1/4">Write / Edit Access</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-semibold text-slate-800">
                  {SYSTEM_MODULES.map((mod) => {
                    const perm = permissions[activeRoleTab]?.[mod.id] || { read: false, write: false };
                    const isAlwaysFull = activeRoleTab === "Platform Administrator" || activeRoleTab === "Farm Owner";
                    
                    return (
                      <tr key={mod.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="py-3.5 pr-4">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-extrabold text-slate-900">{mod.label}</span>
                            <span className="text-[9px] px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded font-mono uppercase">{mod.category}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 block mt-0.5 font-normal leading-relaxed">{mod.desc}</span>
                        </td>
                        
                        {/* Read Toggle */}
                        <td className="py-3.5 text-center px-4">
                          <div className="flex justify-center items-center">
                            {isAlwaysFull ? (
                              <div className="w-9 h-5 bg-emerald-500/20 text-emerald-600 rounded-full flex items-center justify-center font-bold text-[9px] font-mono border border-emerald-500/30">
                                <Unlock className="w-2.5 h-2.5 mr-0.5" /> ON
                              </div>
                            ) : (
                              <button
                                type="button"
                                disabled={!isOwner}
                                onClick={() => onUpdatePermission(activeRoleTab, mod.id, "read", !perm.read)}
                                className={`w-10 h-6 flex items-center rounded-full p-0.5 cursor-pointer transition-all duration-200 outline-none ${
                                  perm.read ? "bg-emerald-500" : "bg-slate-200"
                                } ${!isOwner ? "opacity-60 cursor-not-allowed" : ""}`}
                              >
                                <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-200 flex items-center justify-center ${
                                  perm.read ? "translate-x-4" : "translate-x-0"
                                }`}>
                                  {perm.read ? <Check className="w-3 h-3 text-emerald-600 font-bold" /> : <Lock className="w-2.5 h-2.5 text-slate-400" />}
                                </div>
                              </button>
                            )}
                          </div>
                        </td>

                        {/* Write Toggle */}
                        <td className="py-3.5 text-center px-4">
                          <div className="flex justify-center items-center">
                            {isAlwaysFull ? (
                              <div className="w-9 h-5 bg-emerald-500/20 text-emerald-600 rounded-full flex items-center justify-center font-bold text-[9px] font-mono border border-emerald-500/30">
                                <Unlock className="w-2.5 h-2.5 mr-0.5" /> ON
                              </div>
                            ) : (
                              <button
                                type="button"
                                disabled={!isOwner || !perm.read}
                                onClick={() => onUpdatePermission(activeRoleTab, mod.id, "write", !perm.write)}
                                className={`w-10 h-6 flex items-center rounded-full p-0.5 cursor-pointer transition-all duration-200 outline-none ${
                                  perm.write && perm.read ? "bg-emerald-500" : "bg-slate-200"
                                } ${(!isOwner || !perm.read) ? "opacity-50 cursor-not-allowed" : ""}`}
                              >
                                <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-200 flex items-center justify-center ${
                                  perm.write && perm.read ? "translate-x-4" : "translate-x-0"
                                }`}>
                                  {perm.write && perm.read ? <Check className="w-3 h-3 text-emerald-600 font-bold" /> : <Lock className="w-2.5 h-2.5 text-slate-400" />}
                                </div>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 3: FARM NODE AUDIT TRAIL */}
      {mainView === "audit" && (
        <div className="pt-1">
          <AuditTrail
            tenantId={tenantId}
            farmName={activeFarmName}
            userProfile={{
              name: activeFarmName || userEmail,
              email: userEmail,
              uid: tenantId,
              tenantId: tenantId,
              role: currentRole
            }}
            isOwner={isOwner}
          />
        </div>
      )}

      {/* MODAL 1: ADD NEW USER WITH MODULE TOGGLES */}
      {showAddMemberModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 min-h-screen overflow-y-auto">
          <form onSubmit={handleCreateMemberSubmit} className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl p-6 border border-slate-200 animate-scale-up my-8 max-h-[90vh] flex flex-col">
            <div className="pb-3 border-b flex items-center justify-between shrink-0">
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <UserPlus className="w-4 h-4 text-emerald-600" />
                  <span>Create Farm Node User</span>
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Set user credentials and selectively toggle the modules they are allowed to access on <strong>{activeFarmName}</strong>.
                </p>
              </div>
              <span className="text-[10px] px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-bold font-mono">WORKSPACE SCOPED</span>
            </div>

            {newMemberError && (
              <div className="mt-3 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 font-medium flex items-center gap-2 shrink-0">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{newMemberError}</span>
              </div>
            )}

            <div className="overflow-y-auto py-4 space-y-4 pr-1 flex-1">
              {/* Credentials Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-600 block">Full Name *</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Kondwani Phiri" 
                    value={newMemberName} 
                    onChange={e => setNewMemberName(e.target.value)} 
                    required 
                    className="w-full text-xs mt-1 p-2.5 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 bg-slate-50 focus:bg-white" 
                  />
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-600 block">Email Address (Login Username) *</label>
                  <input 
                    type="email" 
                    placeholder="e.g. kondwani@gmail.com" 
                    value={newMemberEmail} 
                    onChange={e => setNewMemberEmail(e.target.value)} 
                    required 
                    className="w-full text-xs mt-1 p-2.5 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 bg-slate-50 focus:bg-white" 
                  />
                </div>
              </div>

              {/* Role and Password */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-600 block">Assigned Role</label>
                  <select
                    value={newMemberRole}
                    onChange={e => handleRoleSelectChange(e.target.value as PredefinedRole)}
                    className="w-full text-xs mt-1 p-2.5 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 bg-slate-50 focus:bg-white font-semibold text-slate-800 cursor-pointer"
                  >
                    <option value="Accountant">Accountant</option>
                    <option value="Farm Manager">Farm Manager</option>
                    <option value="Farm Worker">Farm Worker</option>
                    <option value="Agronomist">Agronomist</option>
                    <option value="Agro Dealer">Agro Dealer</option>
                    {isOwner && <option value="Farm Owner">Farm Owner</option>}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-600 block">Set Initial Password *</label>
                  <div className="relative mt-1">
                    <input 
                      type={showPasswordText ? "text" : "password"} 
                      placeholder="Min 6 characters" 
                      value={newMemberPassword} 
                      onChange={e => setNewMemberPassword(e.target.value)} 
                      required 
                      className="w-full text-xs p-2.5 pr-8 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 bg-slate-50 focus:bg-white font-mono" 
                    />
                    <button
                      type="button"
                      onClick={() => setShowPasswordText(!showPasswordText)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {showPasswordText ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-600 block">Confirm Password *</label>
                  <input 
                    type={showPasswordText ? "text" : "password"} 
                    placeholder="Repeat password" 
                    value={newMemberConfirmPassword} 
                    onChange={e => setNewMemberConfirmPassword(e.target.value)} 
                    required 
                    className="w-full text-xs mt-1 p-2.5 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 bg-slate-50 focus:bg-white font-mono" 
                  />
                </div>
              </div>

              {/* MODULE ACCESS SELECTION (ON/OFF TOGGLES) */}
              <div className="pt-3 border-t border-slate-200">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-3">
                  <div>
                    <label className="text-xs uppercase font-extrabold text-slate-900 flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Select Permitted Modules & Features ({selectedModules.length}/{SYSTEM_MODULES.length})</span>
                    </label>
                    <p className="text-[11px] text-slate-500">Toggle individual modules ON/OFF that this user is authorized to access.</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedModules(SYSTEM_MODULES.map(m => m.id))}
                      className="px-2 py-1 text-[10px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded transition-all"
                    >
                      Select All
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedModules(["dashboard"])}
                      className="px-2 py-1 text-[10px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded transition-all"
                    >
                      Reset to Min
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedModules(getDefaultModulesForRole(newMemberRole))}
                      className="px-2 py-1 text-[10px] font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded transition-all"
                    >
                      Role Defaults
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {SYSTEM_MODULES.map(mod => {
                    const isChecked = selectedModules.includes(mod.id);
                    return (
                      <div
                        key={mod.id}
                        onClick={() => handleToggleModule(mod.id)}
                        className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                          isChecked 
                            ? "bg-emerald-50/50 border-emerald-300 shadow-xs" 
                            : "bg-slate-50/70 border-slate-200 opacity-75 hover:opacity-100"
                        }`}
                      >
                        <div className="space-y-0.5 flex-1 pr-2">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-slate-900">{mod.label}</span>
                            <span className="text-[9px] px-1 bg-slate-200 text-slate-700 rounded font-mono uppercase">{mod.category}</span>
                          </div>
                          <p className="text-[10px] text-slate-500 leading-tight">{mod.desc}</p>
                        </div>

                        <div className={`w-9 h-5 rounded-full p-0.5 flex items-center transition-colors duration-200 shrink-0 ${
                          isChecked ? "bg-emerald-600 justify-end" : "bg-slate-300 justify-start"
                        }`}>
                          <div className="w-4 h-4 rounded-full bg-white shadow-xs" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t border-slate-200 mt-2 shrink-0 text-xs font-semibold">
              <button 
                type="button" 
                onClick={() => setShowAddMemberModal(false)} 
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl font-bold shadow-sm transition-all cursor-pointer flex items-center gap-1.5"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Create User Profile</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MODAL 2: EDIT USER PERMITTED MODULES */}
      {editingMember && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 min-h-screen overflow-y-auto">
          <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl p-6 border border-slate-200 animate-scale-up my-8 max-h-[90vh] flex flex-col">
            <div className="pb-3 border-b flex items-center justify-between shrink-0">
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-emerald-600" />
                  <span>Edit Modules for {editingMember.name}</span>
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Update allowed functional areas for <strong>{editingMember.email}</strong> ({editingMember.role}).
                </p>
              </div>
              <span className="text-[10px] px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded font-bold font-mono">
                {editPermittedModules.length} SELECTED
              </span>
            </div>

            <div className="overflow-y-auto py-4 space-y-3 flex-1 pr-1">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-700">Module Access Toggles</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setEditPermittedModules(SYSTEM_MODULES.map(m => m.id))}
                    className="px-2 py-1 text-[10px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded transition-all"
                  >
                    Select All
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditPermittedModules(getDefaultModulesForRole(editingMember.role))}
                    className="px-2 py-1 text-[10px] font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded transition-all"
                  >
                    Role Defaults
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {SYSTEM_MODULES.map(mod => {
                  const isChecked = editPermittedModules.includes(mod.id);
                  return (
                    <div
                      key={mod.id}
                      onClick={() => handleToggleEditModule(mod.id)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        isChecked 
                          ? "bg-emerald-50/50 border-emerald-300 shadow-xs" 
                          : "bg-slate-50/70 border-slate-200 opacity-75 hover:opacity-100"
                      }`}
                    >
                      <div className="space-y-0.5 flex-1 pr-2">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-900">{mod.label}</span>
                          <span className="text-[9px] px-1 bg-slate-200 text-slate-700 rounded font-mono uppercase">{mod.category}</span>
                        </div>
                        <p className="text-[10px] text-slate-500 leading-tight">{mod.desc}</p>
                      </div>

                      <div className={`w-9 h-5 rounded-full p-0.5 flex items-center transition-colors duration-200 shrink-0 ${
                        isChecked ? "bg-emerald-600 justify-end" : "bg-slate-300 justify-start"
                      }`}>
                        <div className="w-4 h-4 rounded-full bg-white shadow-xs" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t border-slate-200 mt-2 shrink-0 text-xs font-semibold">
              <button 
                type="button" 
                onClick={() => setEditingMember(null)} 
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all"
              >
                Cancel
              </button>
              <button 
                type="button" 
                onClick={handleSaveEditMember}
                disabled={actionInProgress}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl font-bold shadow-sm transition-all"
              >
                {actionInProgress ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: SUSPEND / UNSUSPEND USER MODAL */}
      {suspensionModalUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 min-h-screen">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-6 border border-slate-200 animate-scale-up space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold shrink-0 ${
                suspensionModalUser.isSuspended ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"
              }`}>
                {suspensionModalUser.isSuspended ? <CheckCircle2 className="w-5 h-5" /> : <Ban className="w-5 h-5" />}
              </div>
              <div>
                <h4 className="text-sm font-extrabold text-slate-900">
                  {suspensionModalUser.isSuspended ? "Reactivate User Account" : "Suspend User Access"}
                </h4>
                <p className="text-[11px] text-slate-500">{suspensionModalUser.name} ({suspensionModalUser.email})</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              {suspensionModalUser.isSuspended 
                ? "Reactivating this account will restore the user's ability to sign in and interact with this farm node." 
                : "Suspending this user will instantly block them from signing into this farm node workspace or making any ledger entries."}
            </p>

            {!suspensionModalUser.isSuspended && (
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-600 block">Reason for Suspension (Optional)</label>
                <textarea
                  rows={3}
                  value={suspensionReason}
                  onChange={e => setSuspensionReason(e.target.value)}
                  placeholder="e.g. Temporary leave of absence / audit review in progress..."
                  className="w-full text-xs mt-1 p-2.5 border border-slate-200 rounded-xl outline-none focus:border-amber-500 bg-slate-50 focus:bg-white resize-none"
                />
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2 text-xs font-bold">
              <button 
                type="button" 
                onClick={() => setSuspensionModalUser(null)} 
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all"
              >
                Cancel
              </button>
              <button 
                type="button" 
                onClick={handleConfirmSuspension}
                disabled={actionInProgress}
                className={`px-5 py-2 text-white rounded-xl shadow-sm transition-all font-bold ${
                  suspensionModalUser.isSuspended 
                    ? "bg-emerald-600 hover:bg-emerald-500" 
                    : "bg-rose-600 hover:bg-rose-500"
                }`}
              >
                {actionInProgress ? "Processing..." : (suspensionModalUser.isSuspended ? "Confirm Reactivation" : "Confirm Suspension")}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: ADMIN RESET USER PASSWORD */}
      {passwordChangeModalUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 min-h-screen">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-6 border border-slate-200 animate-scale-up space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <div className="w-10 h-10 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center font-bold">
                <KeyRound className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <h4 className="text-sm font-extrabold text-slate-900">Reset User Password</h4>
                <p className="text-[11px] text-slate-500">{passwordChangeModalUser.name} ({passwordChangeModalUser.email})</p>
              </div>
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-slate-600 block">Set New Password</label>
              <input
                type="text"
                value={newPasswordValue}
                onChange={e => setNewPasswordValue(e.target.value)}
                placeholder="Min 6 characters"
                className="w-full text-xs mt-1 p-2.5 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 bg-slate-50 focus:bg-white font-mono"
              />
              <p className="text-[10px] text-slate-400 mt-1">The user will be required to choose their own password upon first login with these new credentials.</p>
            </div>

            <div className="flex justify-end gap-2 pt-2 text-xs font-bold">
              <button 
                type="button" 
                onClick={() => setPasswordChangeModalUser(null)} 
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all"
              >
                Cancel
              </button>
              <button 
                type="button" 
                onClick={handleAdminResetPassword}
                disabled={actionInProgress}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl shadow-sm transition-all"
              >
                {actionInProgress ? "Updating..." : "Update Password"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 5: CHANGE OWN PASSWORD */}
      {showSelfPasswordModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 min-h-screen">
          <form onSubmit={handleSelfChangePassword} className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-6 border border-slate-200 animate-scale-up space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                <Key className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-extrabold text-slate-900">Change My Password</h4>
                <p className="text-[11px] text-slate-500">Update your credentials for {userEmail}</p>
              </div>
            </div>

            {selfPasswordStatus && (
              <div className={`p-3 rounded-xl text-xs font-medium ${
                selfPasswordStatus.type === "success" 
                  ? "bg-emerald-50 border border-emerald-200 text-emerald-700" 
                  : "bg-rose-50 border border-rose-200 text-rose-700"
              }`}>
                {selfPasswordStatus.msg}
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-600 block">New Password (Min 6 chars)</label>
                <input
                  type="password"
                  value={selfNewPassword}
                  onChange={e => setSelfNewPassword(e.target.value)}
                  required
                  placeholder="Enter new password"
                  className="w-full text-xs mt-1 p-2.5 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 bg-slate-50 focus:bg-white font-mono"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-600 block">Confirm New Password</label>
                <input
                  type="password"
                  value={selfConfirmPassword}
                  onChange={e => setSelfConfirmPassword(e.target.value)}
                  required
                  placeholder="Repeat new password"
                  className="w-full text-xs mt-1 p-2.5 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 bg-slate-50 focus:bg-white font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 text-xs font-bold">
              <button 
                type="button" 
                onClick={() => setShowSelfPasswordModal(false)} 
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                disabled={actionInProgress}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl shadow-sm transition-all"
              >
                {actionInProgress ? "Updating..." : "Save New Password"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* DISPATCHED EMAIL NOTIFICATION MODAL */}
      {dispatchedEmailNotice && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 min-h-screen">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl p-6 border border-slate-200 animate-scale-up text-left space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                ✉️
              </div>
              <div>
                <h4 className="text-sm font-extrabold text-slate-900">User Account & Credentials Created</h4>
                <p className="text-[11px] text-slate-500">The user has been registered for this farm workspace.</p>
              </div>
            </div>

            <div className="p-4 bg-slate-900 text-slate-100 rounded-xl space-y-3 text-xs font-sans border border-slate-800 shadow-inner">
              <div className="flex justify-between items-center text-[10px] text-slate-400 border-b border-slate-800 pb-2">
                <span>SUBJECT: Workspace Access — {dispatchedEmailNotice.farmName}</span>
                <span className="font-mono text-emerald-400">STATUS: PROVISIONED</span>
              </div>

              <div className="space-y-1.5 text-slate-200 leading-relaxed text-xs">
                <p>Hello <strong>{dispatchedEmailNotice.name}</strong>,</p>
                <p>Your user profile with role <strong>{dispatchedEmailNotice.role}</strong> and access to <strong>{dispatchedEmailNotice.permittedModulesCount} modules</strong> is ready on <strong>{dispatchedEmailNotice.farmName}</strong>.</p>
              </div>

              <div className="p-3 bg-slate-800 rounded-lg space-y-1.5 font-mono text-[11px] border border-slate-700">
                <div className="flex justify-between">
                  <span className="text-slate-400">Username/Email:</span>
                  <span className="text-emerald-300 font-bold">{dispatchedEmailNotice.email}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Initial Password:</span>
                  <span className="text-amber-300 font-bold">{dispatchedEmailNotice.password}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Login URL:</span>
                  <span className="text-blue-300 underline">{dispatchedEmailNotice.loginUrl}</span>
                </div>
              </div>

              <div className="p-2.5 bg-amber-950/80 border border-amber-800/90 rounded-lg text-amber-200 text-[11px] space-y-1">
                <div className="font-bold flex items-center gap-1">
                  <span>🔒 FORCED PASSWORD CHANGE REQUIREMENT</span>
                </div>
                <p className="text-[10.5px] leading-tight text-amber-300/90">
                  Instruction sent to user: You are required to change your password on your first login under <strong>Change My Password</strong>.
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 text-xs font-bold">
              <button 
                onClick={() => {
                  navigator.clipboard?.writeText(
                    `Farm Workspace: ${dispatchedEmailNotice.farmName}\nUsername: ${dispatchedEmailNotice.email}\nPassword: ${dispatchedEmailNotice.password}\nLogin URL: ${dispatchedEmailNotice.loginUrl}`
                  );
                  alert("User credentials copied to clipboard!");
                }}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Credentials</span>
              </button>
              <button 
                onClick={() => setDispatchedEmailNotice(null)}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl shadow-sm transition-all"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

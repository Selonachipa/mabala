import React, { useState, useEffect } from "react";
import { 
  Pin, 
  PinOff, 
  Settings, 
  RotateCcw, 
  Search, 
  Check, 
  X, 
  ArrowLeft, 
  ArrowRight,
  BookOpen,
  Receipt,
  Sprout,
  Users,
  FileText,
  Waves,
  BarChart3,
  ShoppingBag,
  Package,
  Layers,
  Sparkles,
  Stethoscope,
  HeartPulse,
  Landmark,
  ShieldCheck,
  Building2,
  HardDrive,
  User,
  History,
  Grid,
  Radio
} from "lucide-react";

export interface ModuleDefinition {
  id: string;
  name: string;
  desc: string;
  category: "Core Financials" | "Operations & Farm" | "Trade & Markets" | "Compliance & Systems";
  iconName: string;
  defaultPinned?: boolean;
}

export const ALL_SYSTEM_MODULES: ModuleDefinition[] = [
  { id: "accounts", name: "Chart of Accounts", desc: "Double-entry general ledger accounts", category: "Core Financials", iconName: "BookOpen", defaultPinned: true },
  { id: "expenses", name: "Expenses Ledger", desc: "Post double-entry vouchers & receipts", category: "Core Financials", iconName: "Receipt", defaultPinned: true },
  { id: "crops", name: "Crop Cycles", desc: "Continuous field & block planning", category: "Operations & Farm", iconName: "Sprout", defaultPinned: true },
  { id: "payroll", name: "Localized Payroll", desc: "Zambia statutory regulation engines", category: "Core Financials", iconName: "Users", defaultPinned: true },
  { id: "invoices", name: "Invoices & Quotes", desc: "1-click quotation & invoice transform", category: "Trade & Markets", iconName: "FileText", defaultPinned: true },
  { id: "aquaculture", name: "Aquaculture Systems", desc: "Water parameters & feeding logs", category: "Operations & Farm", iconName: "Waves", defaultPinned: true },
  { id: "reports", name: "Financial Reports", desc: "GAAP & IAS quarterly returns & trial balance", category: "Core Financials", iconName: "BarChart3", defaultPinned: true },
  { id: "offtaker-marketplace", name: "Sell to Offtakers", desc: "Liquidate harvests to certified aggregators", category: "Trade & Markets", iconName: "ShoppingBag", defaultPinned: true },
  { id: "farmer-wallet", name: "Mabala Farm Ledger", desc: "Mabala Ledger (Account 1020), Mobile Money & DDACC auto-clearing", category: "Core Financials", iconName: "Wallet", defaultPinned: true },
  
  { id: "livestock", name: "Livestock Registry", desc: "Herd health, breeding & weigh events", category: "Operations & Farm", iconName: "Layers" },
  { id: "poultry", name: "Poultry Batches", desc: "Flock mortality & egg production logs", category: "Operations & Farm", iconName: "Package" },
  { id: "inventory", name: "Inventory & Stores", desc: "Stockroom SKUs & batch valuation", category: "Operations & Farm", iconName: "Package" },
  { id: "sales", name: "Sales & Cash Register", desc: "Counter POS & cash receipts", category: "Trade & Markets", iconName: "Receipt" },
  { id: "agrodealer-consignment", name: "Consignment Desk", desc: "Supplier consignment stock & settlements", category: "Trade & Markets", iconName: "Building2" },
  { id: "veterinary", name: "Veterinary Doctor", desc: "Clinical consultations & prescriptions", category: "Operations & Farm", iconName: "Stethoscope" },
  { id: "hsw", name: "Herd Health Sentinel", desc: "Disease tracking & outbreak alerts", category: "Operations & Farm", iconName: "HeartPulse" },
  { id: "finance-hub", name: "Capital & Loans", desc: "Loan applications & credit facilities", category: "Core Financials", iconName: "Landmark" },
  { id: "assets", name: "Asset Register", desc: "Fixed asset depreciation & registers", category: "Core Financials", iconName: "Building2" },
  { id: "lipila-payment-tracker", name: "Mabala Payment Tracker", desc: "Real-time Lipila gateway collections & disbursements", category: "Core Financials", iconName: "Receipt" },
  { id: "sms-hub", name: "SMS Communications Hub", desc: "Single & bulk SMS broadcast via Beem gateway", category: "Operations & Farm", iconName: "Radio" },
  { id: "audit-archive", name: "Audit & Archives", desc: "Compliance logs & historical archives", category: "Compliance & Systems", iconName: "History" },
  { id: "offline-sync", name: "Offline Sync Engine", desc: "Local SQLite buffer & cloud sync", category: "Compliance & Systems", iconName: "HardDrive" },
  { id: "profile", name: "Profile & Settings", desc: "Tenant parameters & user security", category: "Compliance & Systems", iconName: "User" }
];

const DEFAULT_PINNED_IDS = [
  "accounts",
  "expenses",
  "crops",
  "payroll",
  "invoices",
  "aquaculture",
  "reports",
  "offtaker-marketplace"
];

interface DashboardModulesGridProps {
  onSelectModule: (moduleId: string) => void;
  allowedTabIds?: string[];
  isReadonly?: boolean;
  onTopUpCredits?: () => void;
  onActivateSubscription?: () => void;
}

export const DashboardModulesGrid: React.FC<DashboardModulesGridProps> = ({
  onSelectModule,
  allowedTabIds,
  isReadonly = false,
  onTopUpCredits,
  onActivateSubscription
}) => {
  const [pinnedIds, setPinnedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("mabala_pinned_modules");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_PINNED_IDS;
  });

  const [isCustomizing, setIsCustomizing] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  // Save to localStorage whenever pinnedIds change
  useEffect(() => {
    try {
      localStorage.setItem("mabala_pinned_modules", JSON.stringify(pinnedIds));
    } catch (e) {}
  }, [pinnedIds]);

  const renderIcon = (iconName: string, className = "w-4 h-4") => {
    switch (iconName) {
      case "BookOpen": return <BookOpen className={className} />;
      case "Receipt": return <Receipt className={className} />;
      case "Sprout": return <Sprout className={className} />;
      case "Users": return <Users className={className} />;
      case "FileText": return <FileText className={className} />;
      case "Waves": return <Waves className={className} />;
      case "BarChart3": return <BarChart3 className={className} />;
      case "ShoppingBag": return <ShoppingBag className={className} />;
      case "Package": return <Package className={className} />;
      case "Layers": return <Layers className={className} />;
      case "Stethoscope": return <Stethoscope className={className} />;
      case "HeartPulse": return <HeartPulse className={className} />;
      case "Landmark": return <Landmark className={className} />;
      case "ShieldCheck": return <ShieldCheck className={className} />;
      case "Building2": return <Building2 className={className} />;
      case "HardDrive": return <HardDrive className={className} />;
      case "User": return <User className={className} />;
      case "History": return <History className={className} />;
      case "Radio": return <Radio className={className} />;
      default: return <Grid className={className} />;
    }
  };

  const isTabAllowed = (id: string) => {
    if (!allowedTabIds || allowedTabIds.length === 0) return true;
    return allowedTabIds.includes(id);
  };

  const filteredModules = ALL_SYSTEM_MODULES.filter(m => {
    if (!isTabAllowed(m.id)) return false;
    const matchesSearch = m.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          m.desc.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || m.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const pinnedModulesList = pinnedIds
    .map(id => ALL_SYSTEM_MODULES.find(m => m.id === id))
    .filter((m): m is ModuleDefinition => m !== undefined && isTabAllowed(m.id));

  const togglePin = (id: string) => {
    setPinnedIds(prev => {
      if (prev.includes(id)) {
        return prev.filter(x => x !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const moveModule = (index: number, direction: "left" | "right") => {
    if (direction === "left" && index === 0) return;
    if (direction === "right" && index === pinnedIds.length - 1) return;
    const newArr = [...pinnedIds];
    const targetIdx = direction === "left" ? index - 1 : index + 1;
    const temp = newArr[index];
    newArr[index] = newArr[targetIdx];
    newArr[targetIdx] = temp;
    setPinnedIds(newArr);
  };

  const resetToDefault = () => {
    setPinnedIds(DEFAULT_PINNED_IDS);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-4 font-sans" id="dashboard-customizable-modules-section">
      {/* PROMINENT QUICK ACCESS SHORTCUTS FOR READ-ONLY MODE */}
      {isReadonly && (
        <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950 border-2 border-emerald-500/50 p-5 rounded-2xl text-white shadow-xl space-y-4" id="dashboard-readonly-quick-access-banner">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold text-lg shrink-0">
                ⚡
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black uppercase tracking-wider text-emerald-400">
                    Quick Access Navigation • Always Unlocked
                  </span>
                  <span className="bg-emerald-500 text-slate-950 text-[9px] font-mono px-2 py-0.5 rounded font-black uppercase">
                    100% Active
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 font-medium mt-0.5">
                  Your account is in read-only mode, but input procurement and professional agronomic bookings are completely unrestricted.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {onTopUpCredits && (
                <button
                  type="button"
                  onClick={onTopUpCredits}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-[11px] font-black rounded-xl transition shadow-xs cursor-pointer"
                >
                  Top Up Credits
                </button>
              )}
              {onActivateSubscription && (
                <button
                  type="button"
                  onClick={onActivateSubscription}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-black rounded-xl transition shadow-xs cursor-pointer"
                >
                  Pay Subscription
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => onSelectModule("marketplace")}
              className="p-4 bg-gradient-to-r from-emerald-900/60 to-emerald-950/80 hover:from-emerald-800/70 hover:to-emerald-900 border border-emerald-500/50 hover:border-emerald-400 rounded-xl text-left transition-all shadow-md group cursor-pointer flex items-center justify-between"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-11 h-11 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center justify-center text-xl group-hover:scale-105 transition-transform shrink-0">
                  🛒
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h5 className="font-extrabold text-sm text-white group-hover:text-emerald-300 transition-colors">
                      Vendor Marketplace
                    </h5>
                    <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-bold px-1.5 py-0.2 rounded">
                      Buy Inputs
                    </span>
                  </div>
                  <p className="text-[11px] text-emerald-200/80 mt-0.5 leading-snug">
                    Order certified seeds, fertilizers, chemicals & machinery directly with Lipila Mobile Money.
                  </p>
                </div>
              </div>
              <span className="text-emerald-400 group-hover:translate-x-1 transition-transform text-sm font-black pl-2">
                →
              </span>
            </button>

            <button
              type="button"
              onClick={() => onSelectModule("advisory-portal")}
              className="p-4 bg-gradient-to-r from-teal-900/60 to-teal-950/80 hover:from-teal-800/70 hover:to-teal-900 border border-teal-500/50 hover:border-teal-400 rounded-xl text-left transition-all shadow-md group cursor-pointer flex items-center justify-between"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-11 h-11 rounded-xl bg-teal-500/20 text-teal-300 border border-teal-400/30 flex items-center justify-center text-xl group-hover:scale-105 transition-transform shrink-0">
                  🌱
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h5 className="font-extrabold text-sm text-white group-hover:text-teal-300 transition-colors">
                      Agronomist Booking
                    </h5>
                    <span className="bg-teal-500/20 text-teal-300 border border-teal-500/30 text-[9px] font-bold px-1.5 py-0.2 rounded">
                      Field Visits
                    </span>
                  </div>
                  <p className="text-[11px] text-teal-200/80 mt-0.5 leading-snug">
                    Schedule on-site farm visits, soil tests, pest scouting & precision field advisory with verified agronomists.
                  </p>
                </div>
              </div>
              <span className="text-teal-400 group-hover:translate-x-1 transition-transform text-sm font-black pl-2">
                →
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Header with Title and Customize Toggle */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>Quick Access Modules</span>
            </h4>
            <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[9px] font-black rounded-full uppercase tracking-wider">
              {pinnedModulesList.length} Pinned
            </span>
          </div>
          <p className="text-[10px] text-slate-400 font-medium mt-0.5">
            Pin and reorder your most frequently accessed operational modules for 1-click navigation.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isCustomizing && (
            <button
              type="button"
              onClick={resetToDefault}
              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-extrabold uppercase tracking-wider flex items-center gap-1 transition-all cursor-pointer"
              title="Reset quick access layout to platform defaults"
            >
              <RotateCcw className="w-3 h-3 text-slate-500" />
              <span>Reset Defaults</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsCustomizing(!isCustomizing)}
            className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-xs cursor-pointer border ${
              isCustomizing
                ? "bg-emerald-600 text-white border-emerald-700 hover:bg-emerald-700"
                : "bg-slate-900 text-white border-slate-800 hover:bg-slate-800"
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>{isCustomizing ? "Done Customizing" : "Configure & Reorder"}</span>
          </button>
        </div>
      </div>

      {/* CUSTOMIZATION INLINE DRAWER */}
      {isCustomizing && (
        <div className="bg-slate-900 text-white p-4.5 rounded-xl space-y-4 border border-slate-800 shadow-inner animate-fade-in">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Pin className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-extrabold uppercase tracking-wider">Customize & Reorder Dashboard Modules</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Click the star/pin icon to add or remove modules. Use the left/right arrows to reorder pinned cards.
            </p>
          </div>

          {/* Search and Category Filter */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Filter available modules..."
                className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery("")} 
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-lg border border-slate-700 text-[10px] font-bold">
              {["All", "Core Financials", "Operations & Farm", "Trade & Markets", "Compliance & Systems"].map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2 py-1 rounded transition-all cursor-pointer ${
                    selectedCategory === cat ? "bg-emerald-600 text-white shadow-xs" : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Catalog grid inside drawer */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5 max-h-64 overflow-y-auto pr-1">
            {filteredModules.map(m => {
              const isPinned = pinnedIds.includes(m.id);
              const pinnedIndex = pinnedIds.indexOf(m.id);

              return (
                <div
                  key={m.id}
                  className={`p-2.5 rounded-lg border transition-all flex flex-col justify-between ${
                    isPinned
                      ? "bg-slate-800/90 border-emerald-500/50 text-white"
                      : "bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700"
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <div className="flex items-center gap-1.5">
                        <span className={`p-1 rounded ${isPinned ? "bg-emerald-500/20 text-emerald-400" : "bg-slate-800 text-slate-500"}`}>
                          {renderIcon(m.iconName, "w-3.5 h-3.5")}
                        </span>
                        <span className="text-[11px] font-bold text-white truncate">{m.name}</span>
                      </div>
                      
                      <button
                        type="button"
                        onClick={() => togglePin(m.id)}
                        className={`p-1 rounded transition-all cursor-pointer ${
                          isPinned
                            ? "bg-emerald-600 text-white hover:bg-emerald-500"
                            : "bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700"
                        }`}
                        title={isPinned ? "Unpin module" : "Pin module to dashboard"}
                      >
                        {isPinned ? <Pin className="w-3 h-3 fill-current" /> : <PinOff className="w-3 h-3" />}
                      </button>
                    </div>

                    <p className="text-[9.5px] text-slate-400 line-clamp-2 leading-tight">
                      {m.desc}
                    </p>
                  </div>

                  {/* Reorder controls inside module card if pinned */}
                  {isPinned && (
                    <div className="flex items-center justify-between border-t border-slate-700/60 pt-1.5 mt-2 text-[9px] text-emerald-400 font-mono">
                      <span>Position #{pinnedIndex + 1}</span>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          disabled={pinnedIndex === 0}
                          onClick={() => moveModule(pinnedIndex, "left")}
                          className="p-1 rounded bg-slate-700 hover:bg-slate-600 disabled:opacity-30 disabled:cursor-not-allowed text-white transition-all cursor-pointer"
                          title="Move Left"
                        >
                          <ArrowLeft className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          disabled={pinnedIndex === pinnedIds.length - 1}
                          onClick={() => moveModule(pinnedIndex, "right")}
                          className="p-1 rounded bg-slate-700 hover:bg-slate-600 disabled:opacity-30 disabled:cursor-not-allowed text-white transition-all cursor-pointer"
                          title="Move Right"
                        >
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* PINNED MODULES ACTIVE GRID */}
      {pinnedModulesList.length === 0 ? (
        <div className="p-8 text-center bg-slate-50 border border-dashed border-slate-200 rounded-xl space-y-2">
          <PinOff className="w-8 h-8 text-slate-400 mx-auto" />
          <h5 className="text-xs font-extrabold text-slate-700 uppercase">No Modules Pinned</h5>
          <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
            You currently have no pinned modules. Click <strong>"Configure & Reorder"</strong> above to pin your preferred operational modules.
          </p>
          <button
            type="button"
            onClick={resetToDefault}
            className="mt-2 px-3 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-bold uppercase tracking-wider inline-flex items-center gap-1 hover:bg-emerald-700 cursor-pointer shadow-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Load Default Quick Access Modules</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {pinnedModulesList.map((m, idx) => (
            <div key={m.id} className="relative group">
              <button
                type="button"
                onClick={() => onSelectModule(m.id)}
                className="w-full text-left p-3.5 bg-white border border-slate-200 hover:border-emerald-500 rounded-xl hover:bg-emerald-50/20 transition-all font-semibold focus:outline-none shadow-2xs group-hover:shadow-md cursor-pointer flex flex-col justify-between h-full space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                    {renderIcon(m.iconName, "w-4 h-4")}
                  </div>
                  
                  <span className="opacity-0 group-hover:opacity-100 transition-opacity text-[9px] font-black uppercase text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                    Open →
                  </span>
                </div>

                <div>
                  <span className="text-xs font-bold text-slate-900 block group-hover:text-emerald-800 transition-colors">
                    {m.name}
                  </span>
                  <span className="text-[9.5px] text-slate-500 font-medium block mt-0.5 leading-snug">
                    {m.desc}
                  </span>
                </div>
              </button>

              {/* Quick Reorder Floating Controls when Customizing */}
              {isCustomizing && (
                <div className="absolute top-1 right-1 flex items-center gap-1 bg-slate-900/90 text-white p-1 rounded-lg shadow-lg z-10">
                  <button
                    type="button"
                    disabled={idx === 0}
                    onClick={(e) => { e.stopPropagation(); moveModule(idx, "left"); }}
                    className="p-1 hover:bg-slate-700 rounded disabled:opacity-30 cursor-pointer"
                    title="Move Left"
                  >
                    <ArrowLeft className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    disabled={idx === pinnedModulesList.length - 1}
                    onClick={(e) => { e.stopPropagation(); moveModule(idx, "right"); }}
                    className="p-1 hover:bg-slate-700 rounded disabled:opacity-30 cursor-pointer"
                    title="Move Right"
                  >
                    <ArrowRight className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); togglePin(m.id); }}
                    className="p-1 hover:bg-rose-600 rounded text-rose-300 hover:text-white cursor-pointer ml-0.5"
                    title="Unpin"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect, useMemo } from "react";
import {
  FileText,
  Download,
  Mail,
  RefreshCw,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  Clock,
  Printer,
  FileSpreadsheet,
  Coins,
  Smartphone,
  CreditCard,
  Building2,
  Calendar,
  Sparkles,
  ArrowDownRight,
  ExternalLink,
  ShieldCheck,
  Send,
  X,
  SlidersHorizontal,
  CalendarRange,
  RotateCcw
} from "lucide-react";
import {
  FarmBillingStatement,
  StatementLineItem,
  fetchFarmBillingStatement,
  emailFarmBillingStatement,
  exportStatementToCSV
} from "../services/farmBillingStatementService";
import MabalaReceiptModal from "./MabalaReceiptModal";
import { LipilaTransaction } from "../data/mockLipilaTransactions";
import { safeFormatError } from "../utils/errorUtils";

interface FarmNodeBillingStatementProps {
  tenantId?: string;
  userProfile: any;
  activeFarm: any;
  onOpenReceipt?: (tx: LipilaTransaction) => void;
  className?: string;
}

type PeriodFilterType = "all" | "ytd" | "90days" | "30days" | "thisMonth" | "custom";

export default function FarmNodeBillingStatement({
  tenantId,
  userProfile,
  activeFarm,
  onOpenReceipt,
  className = ""
}: FarmNodeBillingStatementProps) {
  const [statement, setStatement] = useState<FarmBillingStatement | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Period and Date Range Filter State
  const [periodFilter, setPeriodFilter] = useState<PeriodFilterType>("all");
  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");
  const [showCustomRangeInputs, setShowCustomRangeInputs] = useState<boolean>(false);

  // Secondary Filters
  const [categoryFilter, setCategoryFilter] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState("");

  // Email Modal State
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState(
    userProfile?.email || activeFarm?.email || ""
  );
  const [customNote, setCustomNote] = useState("");
  const [emailing, setEmailing] = useState(false);
  const [emailSuccessDetails, setEmailSuccessDetails] = useState<{
    sentTo: string;
    messageId?: string;
    timestamp: string;
  } | null>(null);

  // Selected receipt for quick view
  const [selectedReceiptTx, setSelectedReceiptTx] = useState<LipilaTransaction | null>(null);

  const activeTenantId = tenantId || activeFarm?.id || userProfile?.uid || "TENANT-001";

  // Load statement data
  const loadStatement = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const data = await fetchFarmBillingStatement(
        activeTenantId,
        userProfile,
        activeFarm,
        periodFilter,
        startDate || undefined,
        endDate || undefined
      );
      setStatement(data);
    } catch (err: any) {
      console.error("[FarmNodeBillingStatement] Load error:", err);
      setErrorMsg(err.message || "Failed to load farm node billing statement.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStatement();
  }, [activeTenantId, periodFilter]);

  // Keep recipient email up to date with active farm/profile
  useEffect(() => {
    const defaultEmail = userProfile?.email || activeFarm?.email || "";
    if (defaultEmail && !recipientEmail) {
      setRecipientEmail(defaultEmail);
    }
  }, [userProfile, activeFarm]);

  // Handle Preset Period Selection
  const handleSelectPeriodPreset = (preset: PeriodFilterType) => {
    setPeriodFilter(preset);
    if (preset === "custom") {
      setShowCustomRangeInputs(true);
    } else {
      setShowCustomRangeInputs(false);
      setStartDate("");
      setEndDate("");
    }
  };

  // Quick Date Range Shortcuts
  const handleApplyQuickRange = (type: "thisMonth" | "30days" | "90days" | "ytd" | "today" | "all") => {
    const now = new Date();
    const todayStr = now.toISOString().split("T")[0];

    if (type === "all") {
      setPeriodFilter("all");
      setStartDate("");
      setEndDate("");
      setShowCustomRangeInputs(false);
      return;
    }

    if (type === "today") {
      setPeriodFilter("custom");
      setStartDate(todayStr);
      setEndDate(todayStr);
      setShowCustomRangeInputs(true);
      return;
    }

    if (type === "thisMonth") {
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split("T")[0];
      setPeriodFilter("thisMonth");
      setStartDate(firstDay);
      setEndDate(todayStr);
      setShowCustomRangeInputs(false);
      return;
    }

    if (type === "30days") {
      const past30 = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
      setPeriodFilter("30days");
      setStartDate(past30);
      setEndDate(todayStr);
      setShowCustomRangeInputs(false);
      return;
    }

    if (type === "90days") {
      const past90 = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
      setPeriodFilter("90days");
      setStartDate(past90);
      setEndDate(todayStr);
      setShowCustomRangeInputs(false);
      return;
    }

    if (type === "ytd") {
      const firstDayOfYear = new Date(now.getFullYear(), 0, 1).toISOString().split("T")[0];
      setPeriodFilter("ytd");
      setStartDate(firstDayOfYear);
      setEndDate(todayStr);
      setShowCustomRangeInputs(false);
      return;
    }
  };

  const handleExtractCustomRange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!startDate && !endDate) {
      setErrorMsg("Please specify at least a Start Date or End Date to extract.");
      return;
    }
    setPeriodFilter("custom");
    loadStatement();
  };

  const handleResetPeriod = () => {
    setPeriodFilter("all");
    setStartDate("");
    setEndDate("");
    setShowCustomRangeInputs(false);
    setSearchQuery("");
    setCategoryFilter("ALL");
  };

  // Filter line items based on category and search query
  const filteredLineItems = useMemo(() => {
    if (!statement) return [];

    return statement.lineItems.filter(item => {
      // Category filter
      if (categoryFilter !== "ALL") {
        if (categoryFilter === "SUBSCRIPTION" && item.category !== "Subscription") return false;
        if (categoryFilter === "AI_CREDITS" && item.category !== "AI Credits Top-Up") return false;
        if (categoryFilter === "SMS_CREDITS" && item.category !== "SMS Credits Top-Up") return false;
        if (categoryFilter === "INVOICE" && item.category !== "Platform Invoice" && item.category !== "Service / Consult") return false;
        if (categoryFilter === "PENDING" && item.status !== "PENDING" && item.balanceDue <= 0) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesDesc = (item.description || "").toLowerCase().includes(q);
        const matchesId = (item.id || "").toLowerCase().includes(q);
        const matchesRef = (item.referenceId || "").toLowerCase().includes(q);
        const matchesMethod = (item.paymentMethod || "").toLowerCase().includes(q);
        if (!matchesDesc && !matchesId && !matchesRef && !matchesMethod) return false;
      }

      return true;
    });
  }, [statement, categoryFilter, searchQuery]);

  // Handle Email Dispatch
  const handleSendEmailStatement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!statement || !recipientEmail) return;

    setEmailing(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const res = await emailFarmBillingStatement({
        tenantId: activeTenantId,
        recipientEmail: recipientEmail.trim(),
        farmName: statement.accountInfo.farmName,
        statementPeriod: statement.periodLabel,
        accountInfo: statement.accountInfo,
        summary: statement.summary,
        lineItems: statement.lineItems,
        customMessage: customNote.trim() || undefined
      });

      const now = new Date().toLocaleTimeString();
      setEmailSuccessDetails({
        sentTo: res.sentTo || recipientEmail,
        messageId: res.messageId,
        timestamp: now
      });

      setSuccessMsg(`Official statement successfully dispatched to ${recipientEmail}!`);
      setIsEmailModalOpen(false);
    } catch (err: any) {
      console.error("[FarmNodeBillingStatement] Email error:", err);
      setErrorMsg(err.message || "Failed to dispatch email statement.");
    } finally {
      setEmailing(false);
    }
  };

  // Handle Print / PDF View
  const handlePrintStatement = () => {
    if (!statement) return;

    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      window.print();
      return;
    }

    const { accountInfo, summary, lineItems, periodLabel } = statement;

    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Mabala Billing Statement - ${accountInfo.farmName}</title>
  <style>
    @media print {
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      color: #0f172a;
      background: #ffffff;
      margin: 0;
      padding: 32px;
      font-size: 12px;
      line-height: 1.5;
    }
    .header-table { width: 100%; border-bottom: 3px solid #1D9E75; padding-bottom: 16px; margin-bottom: 20px; }
    .brand-title { font-size: 26px; font-weight: 900; color: #1D9E75; letter-spacing: -0.5px; }
    .brand-sub { font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; }
    .stmt-badge { display: inline-block; padding: 4px 10px; background: #ecfdf5; color: #1D9E75; border: 1px solid #a7f3d0; border-radius: 9999px; font-weight: 800; font-size: 11px; }
    .grid-info { display: flex; justify-content: space-between; background: #f8fafc; padding: 16px; border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 24px; }
    .summary-boxes { display: flex; gap: 12px; margin-bottom: 24px; }
    .summary-card { flex: 1; padding: 12px; border-radius: 8px; border: 1px solid #e2e8f0; background: #ffffff; }
    .summary-card.highlight { background: #f0fdf4; border-color: #bbf7d0; }
    .summary-label { font-size: 10px; font-weight: 800; text-transform: uppercase; color: #64748b; }
    .summary-val { font-size: 18px; font-weight: 900; color: #0f172a; margin-top: 4px; font-family: monospace; }
    table.ledger { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 11px; }
    table.ledger th { background: #f1f5f9; padding: 8px 10px; text-align: left; font-weight: 800; text-transform: uppercase; font-size: 9px; color: #475569; border-bottom: 2px solid #cbd5e1; }
    table.ledger td { padding: 8px 10px; border-bottom: 1px solid #e2e8f0; vertical-align: top; }
    .badge { display: inline-block; padding: 2px 6px; border-radius: 4px; font-size: 9px; font-weight: 700; text-transform: uppercase; }
    .badge-paid { background: #dcfce7; color: #166534; }
    .badge-pending { background: #fef3c7; color: #92400e; }
    .badge-cat { background: #e0e7ff; color: #3730a3; }
    .footer { margin-top: 36px; padding-top: 16px; border-top: 1px solid #e2e8f0; font-size: 10px; color: #64748b; display: flex; justify-content: space-between; }
    .stamp { border: 2px dashed #1D9E75; color: #1D9E75; padding: 8px 16px; border-radius: 6px; font-weight: 900; text-transform: uppercase; display: inline-block; transform: rotate(-3deg); }
  </style>
</head>
<body>
  <table class="header-table">
    <tr>
      <td>
        <div class="brand-title">MABALA</div>
        <div class="brand-sub">Farm Management Platform & Financial Services</div>
        <div style="color: #64748b; font-size: 11px;">Lusaka, Zambia • support@mabala.cloud • mabala.cloud</div>
      </td>
      <td style="text-align: right;">
        <div class="stmt-badge">OFFICIAL BILLING STATEMENT</div>
        <div style="font-family: monospace; font-weight: bold; margin-top: 6px;">Ref: STMT-${accountInfo.tenantId.slice(-6).toUpperCase()}-${new Date().getFullYear()}</div>
        <div style="color: #64748b; font-size: 11px;">Period: ${periodLabel}</div>
        <div style="color: #64748b; font-size: 11px;">Generated: ${new Date(accountInfo.statementGeneratedAt).toLocaleString()}</div>
      </td>
    </tr>
  </table>

  <div class="grid-info">
    <div>
      <div style="font-size: 10px; font-weight: 800; color: #64748b; text-transform: uppercase;">Farm Node Account</div>
      <div style="font-size: 15px; font-weight: 800; color: #0f172a; margin-top: 2px;">${accountInfo.farmName}</div>
      <div style="color: #475569;">${accountInfo.letterheadSubtitle || 'Agricultural Operations & Billing Ledger'}</div>
      <div style="color: #64748b; font-size: 11px; margin-top: 4px;">${accountInfo.letterheadAddress || 'Lusaka, Zambia'}</div>
    </div>
    <div style="text-align: right;">
      <div style="font-size: 10px; font-weight: 800; color: #64748b; text-transform: uppercase;">Account Credentials</div>
      <div style="color: #0f172a; font-weight: 700; margin-top: 2px;">Tenant ID: <span style="font-family: monospace;">${accountInfo.tenantId}</span></div>
      <div style="color: #475569;">Email: ${accountInfo.registeredEmail || 'N/A'}</div>
      <div style="color: #475569;">Phone: ${accountInfo.phone || 'N/A'}</div>
      <div style="color: #1D9E75; font-weight: 800; margin-top: 4px;">Active Tier: ${accountInfo.activeSubscriptionTier}</div>
    </div>
  </div>

  <div class="summary-boxes">
    <div class="summary-card">
      <div class="summary-label">Total Invoiced</div>
      <div class="summary-val">ZK ${summary.totalInvoiced.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="summary-card highlight">
      <div class="summary-label" style="color: #166534;">Total Paid (Settled)</div>
      <div class="summary-val" style="color: #166534;">ZK ${summary.totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="summary-card">
      <div class="summary-label">Outstanding Due</div>
      <div class="summary-val" style="color: ${summary.totalOutstanding > 0 ? '#b91c1c' : '#0f172a'};">
        ZK ${summary.totalOutstanding.toLocaleString(undefined, { minimumFractionDigits: 2 })}
      </div>
    </div>
    <div class="summary-card">
      <div class="summary-label">Active Balances</div>
      <div style="font-size: 12px; font-weight: 700; margin-top: 4px; color: #334155;">
        ${accountInfo.creditBalance.toLocaleString()} AI Credits<br/>
        ${accountInfo.smsBalance.toLocaleString()} SMS Units
      </div>
    </div>
  </div>

  <h3 style="font-size: 13px; font-weight: 800; text-transform: uppercase; margin-bottom: 4px; color: #1e293b;">
    Itemized Transaction & Invoice Statement (${lineItems.length} Records)
  </h3>

  <table class="ledger">
    <thead>
      <tr>
        <th>Date & Time</th>
        <th>Reference ID</th>
        <th>Category</th>
        <th>Description</th>
        <th>Channel / Method</th>
        <th style="text-align: right;">Invoiced (ZMW)</th>
        <th style="text-align: right;">Paid (ZMW)</th>
        <th style="text-align: center;">Status</th>
      </tr>
    </thead>
    <tbody>
      ${lineItems.length === 0 ? `
        <tr>
          <td colspan="8" style="text-align: center; padding: 24px; color: #64748b;">
            No financial transactions recorded for this period.
          </td>
        </tr>
      ` : lineItems.map(item => `
        <tr>
          <td style="font-family: monospace; white-space: nowrap;">${new Date(item.date).toLocaleDateString()}</td>
          <td style="font-family: monospace; font-weight: bold;">${item.id}</td>
          <td><span class="badge badge-cat">${item.category}</span></td>
          <td>${item.description}</td>
          <td>${item.paymentMethod}</td>
          <td style="text-align: right; font-family: monospace;">ZK ${item.invoicedAmount.toFixed(2)}</td>
          <td style="text-align: right; font-family: monospace; font-weight: bold; color: #166534;">ZK ${item.paidAmount.toFixed(2)}</td>
          <td style="text-align: center;">
            <span class="badge ${item.status === 'PAID' ? 'badge-paid' : 'badge-pending'}">${item.status}</span>
          </td>
        </tr>
      `).join('')}
    </tbody>
  </table>

  <div class="footer">
    <div>
      <div>Audited Mabala Agro OS Financial Record</div>
      <div>Strictly Confidential & Proprietary to Registered Farm Node</div>
    </div>
    <div>
      <div class="stamp">MABALA AUDITED • VERIFIED</div>
    </div>
  </div>
</body>
</html>`;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
    }, 400);
  };

  // Handle Export to CSV/Excel
  const handleExportCSV = () => {
    if (!statement) return;
    exportStatementToCSV(statement);
    setSuccessMsg("Statement successfully exported to Excel spreadsheet!");
  };

  // Handle Row Receipt View
  const handleRowReceiptClick = (item: StatementLineItem) => {
    if (item.rawTransaction && item.rawTransaction.id) {
      if (onOpenReceipt) {
        onOpenReceipt(item.rawTransaction as LipilaTransaction);
      } else {
        setSelectedReceiptTx(item.rawTransaction as LipilaTransaction);
      }
      return;
    }

    // Construct genuine LipilaTransaction object for this row
    const mockTx: LipilaTransaction = {
      id: item.id,
      referenceId: item.referenceId || `REF-${item.id}`,
      amount: item.paidAmount || item.invoicedAmount,
      currency: "ZMW",
      status: item.status === "PAID" ? "Successful" : item.status === "PENDING" ? "Pending" : "Failed",
      createdAt: item.date,
      customerName: statement?.accountInfo.farmName || "Farm Node Operator",
      accountNumber: statement?.accountInfo.phone || statement?.accountInfo.registeredEmail || activeTenantId,
      narration: item.description,
      provider: item.provider || (item.paymentMethod.includes("Airtel") ? "Airtel" : "MTN"),
      paymentMethod: item.paymentMethod,
      tenantId: activeTenantId,
      fees: {
        chargeAmount: 0,
        feePercentage: 0,
        principalAmount: item.paidAmount || item.invoicedAmount,
        lipilaFee: 0,
        platformFee: 0
      }
    };

    if (onOpenReceipt) {
      onOpenReceipt(mockTx);
    } else {
      setSelectedReceiptTx(mockTx);
    }
  };

  const account = statement?.accountInfo;
  const summary = statement?.summary;

  return (
    <div className={`space-y-6 animate-fade-in font-sans ${className}`} id="farm-node-billing-statement-container">
      
      {/* 1. NOTIFICATIONS BANNER */}
      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 p-4 rounded-xl flex items-center justify-between text-xs font-bold animate-fade-in shadow-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessMsg(null)}
            className="text-emerald-700 hover:text-emerald-950 font-black cursor-pointer"
          >
            ×
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl flex items-center justify-between text-xs font-bold animate-fade-in shadow-xs">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{safeFormatError(errorMsg)}</span>
          </div>
          <button
            type="button"
            onClick={() => setErrorMsg(null)}
            className="text-rose-600 hover:text-rose-900 font-black cursor-pointer"
          >
            ×
          </button>
        </div>
      )}

      {/* 2. OFFICIAL STATEMENT HEADER CARD */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 rounded-3xl p-6 sm:p-8 text-white border border-slate-800 shadow-xl relative overflow-hidden">
        {/* Glow accents */}
        <div className="absolute right-0 top-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute left-1/4 bottom-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800/80 pb-6">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2.5 flex-wrap">
                <span className="px-3 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Official Farm Node Statement
                </span>
                <span className="px-2.5 py-1 bg-slate-800 text-slate-300 rounded-full text-[10px] font-mono font-bold">
                  ID: {account?.tenantId || activeTenantId}
                </span>
                <span className="px-2.5 py-1 bg-indigo-950/80 text-indigo-300 border border-indigo-800/40 rounded-full text-[10px] font-bold">
                  Tier: {account?.activeSubscriptionTier || "Active"}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white font-serif uppercase">
                {account?.farmName || activeFarm?.name || "Farm Node Workspace"}
              </h2>
              <p className="text-xs text-slate-400 font-medium">
                {account?.letterheadSubtitle || "Audited Statement of Subscriptions, AI Credits & SMS Top-Ups"}
              </p>
            </div>

            {/* ACTION BUTTONS (DOWNLOAD & EMAIL) */}
            <div className="flex flex-wrap items-center gap-2.5">
              {/* EMAIL STATEMENT BUTTON */}
              <button
                type="button"
                onClick={() => setIsEmailModalOpen(true)}
                className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white text-xs font-black rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer active:scale-98 border border-emerald-400/30"
              >
                <Mail className="w-4 h-4 text-emerald-200" />
                <span>Email Statement</span>
              </button>

              {/* DOWNLOAD PDF / PRINT */}
              <button
                type="button"
                onClick={handlePrintStatement}
                className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-extrabold rounded-xl border border-slate-700 shadow-sm transition-all flex items-center gap-2 cursor-pointer"
                title="Download or Print Formatted PDF"
              >
                <Printer className="w-4 h-4 text-slate-300" />
                <span className="hidden sm:inline">Print / PDF</span>
              </button>

              {/* EXPORT TO EXCEL / CSV */}
              <button
                type="button"
                onClick={handleExportCSV}
                className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-extrabold rounded-xl border border-slate-700 shadow-sm transition-all flex items-center gap-2 cursor-pointer"
                title="Export as CSV / Spreadsheet"
              >
                <FileSpreadsheet className="w-4 h-4 text-slate-300" />
                <span className="hidden sm:inline">Export Excel</span>
              </button>

              {/* REFRESH */}
              <button
                type="button"
                onClick={loadStatement}
                disabled={loading}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 cursor-pointer disabled:opacity-50"
                title="Refresh Statement Data"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          {/* REGISTERED CREDENTIALS BANNER */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs bg-slate-800/50 p-4 rounded-2xl border border-slate-700/50">
            <div>
              <div className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Account Registered Email</div>
              <div className="font-bold text-slate-200 truncate mt-0.5" title={account?.registeredEmail || "Not Set"}>
                {account?.registeredEmail || userProfile?.email || activeFarm?.email || "No email on record"}
              </div>
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Registered Phone</div>
              <div className="font-bold text-slate-200 mt-0.5">
                {account?.phone || userProfile?.phone || activeFarm?.phone || "No phone on record"}
              </div>
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Statement Period</div>
              <div className="font-bold text-emerald-400 mt-0.5 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {statement?.periodLabel || "All Time"}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. FOUR KPI SUMMARY CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* TOTAL INVOICED */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <span className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400">Total Invoiced</span>
              <div className="text-2xl font-black text-slate-900 font-mono tracking-tight">
                ZK {(summary?.totalInvoiced || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div className="p-2.5 bg-slate-100 rounded-xl text-slate-700">
              <FileText className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 text-[11px] text-slate-500 font-medium">
            Cumulative across extracted statement window
          </div>
        </div>

        {/* TOTAL PAID / SETTLED */}
        <div className="bg-emerald-50/70 p-5 rounded-2xl border border-emerald-200 shadow-xs relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <span className="text-[10.5px] font-extrabold uppercase tracking-wider text-emerald-700">Total Paid (Settled)</span>
              <div className="text-2xl font-black text-emerald-950 font-mono tracking-tight">
                ZK {(summary?.totalPaid || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div className="p-2.5 bg-emerald-100 rounded-xl text-emerald-700">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 text-[11px] text-emerald-800 font-medium">
            Lipila MoMo & Verified Collections
          </div>
        </div>

        {/* OUTSTANDING DUE */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <span className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400">Outstanding Balance</span>
              <div className={`text-2xl font-black font-mono tracking-tight ${
                (summary?.totalOutstanding || 0) > 0 ? "text-amber-600" : "text-slate-900"
              }`}>
                ZK {(summary?.totalOutstanding || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div className={`p-2.5 rounded-xl ${
              (summary?.totalOutstanding || 0) > 0 ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-700"
            }`}>
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 text-[11px] text-slate-500 font-medium">
            {(summary?.totalOutstanding || 0) > 0 ? "Pending payment settlement" : "All accounts in good standing"}
          </div>
        </div>

        {/* ACTIVE CAPACITIES */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <span className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400">Active Pool Balances</span>
              <div className="space-y-1 mt-1 font-mono">
                <div className="flex items-center gap-1.5 text-xs font-black text-indigo-700">
                  <Coins className="w-3.5 h-3.5" />
                  <span>{(account?.creditBalance || 0).toLocaleString()} AI Credits</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs font-black text-emerald-700">
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>{(account?.smsBalance || 0).toLocaleString()} SMS Units</span>
                </div>
              </div>
            </div>
            <div className="p-2.5 bg-indigo-50 rounded-xl text-indigo-600">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>

      {/* 4. DATE RANGE PERIOD EXTRACTION CARD */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
              <CalendarRange className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">
                Statement Period Extraction & Custom Date Range
              </h3>
              <p className="text-[11px] text-slate-500">
                Filter and extract official billing statements by specific date periods
              </p>
            </div>
          </div>

          {/* RESET / ALL TIME BUTTON */}
          <button
            type="button"
            onClick={handleResetPeriod}
            className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg transition-all cursor-pointer self-start sm:self-auto"
          >
            <RotateCcw className="w-3 h-3 text-slate-500" />
            <span>Reset to All Time</span>
          </button>
        </div>

        {/* PRESET PERIOD BUTTONS */}
        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: "all", label: "All Time" },
            { id: "thisMonth", label: "This Month" },
            { id: "30days", label: "Last 30 Days" },
            { id: "90days", label: "Last 90 Days" },
            { id: "ytd", label: `Year to Date (${new Date().getFullYear()})` },
            { id: "custom", label: "Custom Date Range" }
          ].map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => handleSelectPeriodPreset(preset.id as PeriodFilterType)}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                periodFilter === preset.id
                  ? "bg-slate-900 text-white shadow-xs"
                  : "bg-slate-100 hover:bg-slate-200 text-slate-700"
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>

        {/* CUSTOM DATE RANGE PICKER FORM */}
        {(showCustomRangeInputs || periodFilter === "custom") && (
          <form onSubmit={handleExtractCustomRange} className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 space-y-3 animate-fade-in">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700">
              <span className="flex items-center gap-1.5 text-slate-800 font-extrabold uppercase text-[10.5px]">
                <SlidersHorizontal className="w-3.5 h-3.5 text-emerald-600" />
                Select Custom Date Range
              </span>
              <span className="text-[11px] text-slate-500 font-normal">
                Inclusive start and end date bounds
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 items-end">
              <div>
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 block mb-1">
                  Start Date (From)
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full text-xs font-bold border rounded-xl px-3 py-2 bg-white border-slate-200 text-slate-900 focus:outline-none focus:border-slate-800"
                />
              </div>

              <div>
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 block mb-1">
                  End Date (To)
                </label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full text-xs font-bold border rounded-xl px-3 py-2 bg-white border-slate-200 text-slate-900 focus:outline-none focus:border-slate-800"
                />
              </div>

              <div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Extract Statement</span>
                </button>
              </div>
            </div>

            {/* Quick shortcuts */}
            <div className="flex items-center gap-2 pt-1 text-[11px] text-slate-500 flex-wrap">
              <span className="font-bold text-slate-400">Quick Shortcuts:</span>
              <button
                type="button"
                onClick={() => handleApplyQuickRange("today")}
                className="text-emerald-700 hover:underline font-bold cursor-pointer"
              >
                Today
              </button>
              <span>•</span>
              <button
                type="button"
                onClick={() => handleApplyQuickRange("thisMonth")}
                className="text-emerald-700 hover:underline font-bold cursor-pointer"
              >
                This Month
              </button>
              <span>•</span>
              <button
                type="button"
                onClick={() => handleApplyQuickRange("30days")}
                className="text-emerald-700 hover:underline font-bold cursor-pointer"
              >
                Last 30 Days
              </button>
              <span>•</span>
              <button
                type="button"
                onClick={() => handleApplyQuickRange("90days")}
                className="text-emerald-700 hover:underline font-bold cursor-pointer"
              >
                Last 90 Days
              </button>
              <span>•</span>
              <button
                type="button"
                onClick={() => handleApplyQuickRange("ytd")}
                className="text-emerald-700 hover:underline font-bold cursor-pointer"
              >
                Year to Date
              </button>
            </div>
          </form>
        )}

        {/* ACTIVE EXTRACTED PERIOD STATUS BADGE */}
        <div className="flex items-center justify-between bg-emerald-50/60 border border-emerald-200/80 p-3 rounded-xl text-xs font-bold text-emerald-950">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-emerald-700 font-extrabold uppercase text-[10px] tracking-wider">
              Active Statement Window:
            </span>
            <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-900 rounded-lg font-mono">
              {statement?.periodLabel || "All Time"}
            </span>
            <span className="text-emerald-700 text-[11px]">
              • {filteredLineItems.length} transactions found
            </span>
          </div>
          <div className="text-emerald-900 font-mono text-[11px] font-black">
            Net Settled: ZK {(summary?.totalPaid || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
        </div>
      </div>

      {/* 5. BREAKDOWN BY SERVICE CATEGORY */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-xs font-extrabold text-slate-800 uppercase tracking-widest flex items-center gap-2">
          <CreditCard className="w-4 h-4 text-[#1D9E75]" />
          <span>Statement Category Breakdown</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* SUBSCRIPTIONS */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-extrabold text-slate-700">1. Subscriptions</span>
              <span className="px-2 py-0.5 bg-slate-200 text-slate-700 rounded-full text-[10px] font-mono font-bold">
                {summary?.subscriptions.count || 0} events
              </span>
            </div>
            <div className="text-lg font-black text-slate-900 font-mono">
              ZK {(summary?.subscriptions.paid || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[10.5px] text-slate-500 font-medium">
              Invoiced: ZK {(summary?.subscriptions.invoiced || 0).toFixed(2)}
            </div>
          </div>

          {/* AI CREDITS */}
          <div className="p-4 bg-indigo-50/50 rounded-xl border border-indigo-100 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-extrabold text-indigo-900">2. AI Credit Top-Ups</span>
              <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded-full text-[10px] font-mono font-bold">
                {summary?.creditTopups.creditsTotal.toLocaleString() || 0} units
              </span>
            </div>
            <div className="text-lg font-black text-indigo-950 font-mono">
              ZK {(summary?.creditTopups.paid || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[10.5px] text-indigo-700 font-medium">
              Invoiced: ZK {(summary?.creditTopups.invoiced || 0).toFixed(2)} ({summary?.creditTopups.count || 0} packs)
            </div>
          </div>

          {/* SMS TOP-UPS */}
          <div className="p-4 bg-emerald-50/50 rounded-xl border border-emerald-100 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-extrabold text-emerald-900">3. SMS Top-Ups</span>
              <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-mono font-bold">
                {summary?.smsTopups.smsUnitsTotal.toLocaleString() || 0} units
              </span>
            </div>
            <div className="text-lg font-black text-emerald-950 font-mono">
              ZK {(summary?.smsTopups.paid || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[10.5px] text-emerald-700 font-medium">
              Invoiced: ZK {(summary?.smsTopups.invoiced || 0).toFixed(2)} ({summary?.smsTopups.count || 0} batches)
            </div>
          </div>

          {/* INVOICED SERVICES */}
          <div className="p-4 bg-amber-50/50 rounded-xl border border-amber-100 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-extrabold text-amber-900">4. Platform Invoices</span>
              <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full text-[10px] font-mono font-bold">
                {summary?.invoices.count || 0} invoices
              </span>
            </div>
            <div className="text-lg font-black text-amber-950 font-mono">
              ZK {(summary?.invoices.paid || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[10.5px] text-amber-700 font-medium">
              Pending Dues: ZK {(summary?.invoices.pending || 0).toFixed(2)}
            </div>
          </div>
        </div>
      </div>

      {/* 6. CONTROLS BAR: SEARCH & CATEGORY FILTER */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* SEARCH INPUT */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by description, reference ID, receipt #, or payment channel..."
              className="w-full pl-9 pr-4 py-2 text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-slate-800 focus:bg-white transition-all"
            />
          </div>
        </div>

        {/* CATEGORY FILTER CHIPS */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 text-xs">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Filter:
          </span>
          {[
            { id: "ALL", label: "All Records" },
            { id: "SUBSCRIPTION", label: "Subscriptions" },
            { id: "AI_CREDITS", label: "AI Credit Top-Ups" },
            { id: "SMS_CREDITS", label: "SMS Top-Ups" },
            { id: "INVOICE", label: "Platform Invoices" },
            { id: "PENDING", label: "Pending Dues Only" }
          ].map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-3 py-1 rounded-lg text-xs font-extrabold whitespace-nowrap transition-all cursor-pointer ${
                categoryFilter === cat.id
                  ? "bg-slate-900 text-white shadow-xs"
                  : "bg-slate-100 hover:bg-slate-200 text-slate-600"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* 7. ITEMIZED STATEMENT LEDGER TABLE */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <div>
            <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">
              Itemized Statement Ledger
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Displaying {filteredLineItems.length} audited financial entries for this statement period
            </p>
          </div>
          <span className="text-[10.5px] font-mono font-bold text-slate-400">
            Node ID: {activeTenantId}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-800">
            <thead className="bg-slate-50 text-[9.5px] font-black text-slate-400 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3.5">Date & Time</th>
                <th className="p-3.5">Ref / ID</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5">Description & Line Items</th>
                <th className="p-3.5">Payment Method</th>
                <th className="p-3.5 text-right">Invoiced Amount</th>
                <th className="p-3.5 text-right">Paid Amount</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredLineItems.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-12 text-center text-slate-400">
                    <div className="max-w-md mx-auto space-y-3">
                      <FileText className="w-8 h-8 text-slate-300 mx-auto" />
                      <p className="font-bold text-slate-700 text-xs">
                        No billing records found for the selected period ({statement?.periodLabel || "All Time"}).
                      </p>
                      <p className="text-[11px] text-slate-400">
                        When you process subscriptions, Lipila MoMo top-ups, SMS packs, or invoices, live audited transaction records will populate here.
                      </p>
                      <button
                        type="button"
                        onClick={handleResetPeriod}
                        className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-extrabold rounded-xl transition cursor-pointer"
                      >
                        Reset Filters
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredLineItems.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5 font-mono text-[11px] text-slate-600 whitespace-nowrap">
                      {new Date(item.date).toLocaleDateString()}<br/>
                      <span className="text-[9.5px] text-slate-400">
                        {new Date(item.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </td>
                    <td className="p-3.5 font-mono font-bold text-slate-900 text-[11px] whitespace-nowrap">
                      {item.id}
                      {item.referenceId && item.referenceId !== item.id && (
                        <div className="text-[9.5px] text-slate-400 font-normal truncate max-w-[100px]">
                          {item.referenceId}
                        </div>
                      )}
                    </td>
                    <td className="p-3.5 whitespace-nowrap">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                        item.category === "Subscription" ? "bg-purple-50 text-purple-700 border border-purple-200" :
                        item.category === "AI Credits Top-Up" ? "bg-indigo-50 text-indigo-700 border border-indigo-200" :
                        item.category === "SMS Credits Top-Up" ? "bg-emerald-50 text-emerald-700 border border-emerald-200" :
                        "bg-amber-50 text-amber-700 border border-amber-200"
                      }`}>
                        {item.category}
                      </span>
                    </td>
                    <td className="p-3.5 font-bold text-slate-850 max-w-xs">
                      <div>{item.description}</div>
                      {item.creditsGranted ? (
                        <span className="inline-block mt-0.5 px-2 py-0.2 bg-indigo-50 text-indigo-700 rounded text-[9.5px] font-mono">
                          +{item.creditsGranted} AI Credits
                        </span>
                      ) : null}
                      {item.smsUnitsGranted ? (
                        <span className="inline-block mt-0.5 px-2 py-0.2 bg-emerald-50 text-emerald-700 rounded text-[9.5px] font-mono">
                          +{item.smsUnitsGranted} SMS Credits
                        </span>
                      ) : null}
                    </td>
                    <td className="p-3.5 text-slate-600 text-[11px]">
                      <div>{item.paymentMethod}</div>
                      {item.provider && (
                        <div className="text-[9.5px] text-slate-400 font-mono">{item.provider}</div>
                      )}
                    </td>
                    <td className="p-3.5 text-right font-mono font-bold text-slate-700 whitespace-nowrap">
                      ZK {item.invoicedAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="p-3.5 text-right font-mono font-black text-emerald-700 whitespace-nowrap">
                      ZK {item.paidAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="p-3.5 text-center whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                        item.status === "PAID" ? "bg-emerald-50 text-emerald-700 border border-emerald-200" :
                        item.status === "PENDING" ? "bg-amber-50 text-amber-700 border border-amber-200" :
                        "bg-rose-50 text-rose-700 border border-rose-200"
                      }`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-center whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => handleRowReceiptClick(item)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold rounded-lg transition-all inline-flex items-center gap-1 cursor-pointer"
                      >
                        <FileText className="w-3 h-3" />
                        <span>Receipt</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 8. EMAIL STATEMENT MODAL */}
      {isEmailModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-scale-up space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-50 rounded-xl text-[#1D9E75]">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900 uppercase">
                    Email Billing Statement
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Dispatched via Hostinger SMTP to farm account
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsEmailModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSendEmailStatement} className="space-y-4">
              <div>
                <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500 block mb-1">
                  Recipient Registered Email Address
                </label>
                <input
                  type="email"
                  required
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  placeholder="e.g. farmer@mabala.app"
                  className="w-full text-xs font-bold border rounded-xl px-3.5 py-2.5 bg-slate-50 border-slate-200 text-slate-900 focus:bg-white outline-none focus:border-slate-800"
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  Defaults to the farm node's verified account email.
                </p>
              </div>

              <div>
                <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500 block mb-1">
                  Extracted Statement Period & Scope
                </label>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 flex justify-between items-center">
                  <span>{statement?.periodLabel || "All Time"}</span>
                  <span className="text-slate-500 font-mono text-[11px]">
                    {statement?.lineItems.length || 0} Transactions
                  </span>
                </div>
              </div>

              <div>
                <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500 block mb-1">
                  Optional Note / Reference for Accounts
                </label>
                <textarea
                  rows={2}
                  value={customNote}
                  onChange={(e) => setCustomNote(e.target.value)}
                  placeholder="e.g. For official farm operations and financial reconciliation."
                  className="w-full text-xs font-medium border rounded-xl p-3 bg-slate-50 border-slate-200 text-slate-900 focus:bg-white outline-none focus:border-slate-800"
                />
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-800 font-medium leading-relaxed">
                ✓ Statement includes itemized breakdown of subscriptions, AI credit top-ups, SMS credits, and platform invoices with official verification.
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEmailModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={emailing}
                  className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white text-xs font-extrabold rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {emailing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-emerald-200" />
                      <span>Sending Email via Hostinger...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 text-emerald-200" />
                      <span>Dispatch Statement Email</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 9. RECEIPT MODAL */}
      {selectedReceiptTx && (
        <MabalaReceiptModal
          transaction={selectedReceiptTx}
          onClose={() => setSelectedReceiptTx(null)}
        />
      )}
    </div>
  );
}

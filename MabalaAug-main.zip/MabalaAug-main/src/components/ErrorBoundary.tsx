import React, { Component, ErrorInfo, ReactNode } from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";
import { safeFormatError } from "../utils/errorUtils";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  declare readonly props: Props;

  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("[Mabala ErrorBoundary] App runtime exception:", error, errorInfo);
  }

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      const errorMessage = this.state.error ? safeFormatError(this.state.error, "An unexpected display issue occurred.") : null;


      return (
        <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-center p-6 text-center">
          <div className="bg-slate-800/80 border border-slate-700/60 rounded-3xl p-8 max-w-md w-full shadow-2xl backdrop-blur-md">
            <div className="mx-auto w-14 h-14 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-2xl flex items-center justify-center mb-5">
              <AlertTriangle className="w-7 h-7" />
            </div>
            <h2 className="text-xl font-bold text-white mb-2">Something went wrong</h2>
            <p className="text-sm text-slate-400 mb-6">
              Mabala encountered a minor display issue. Click below to reload the platform.
            </p>
            {errorMessage && (
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 mb-6 text-left overflow-auto max-h-32 text-xs text-rose-300 font-mono break-words">
                {errorMessage}
              </div>
            )}
            <div className="space-y-3">
              <button
                onClick={this.handleReload}
                className="w-full py-3 px-5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-semibold rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" />
                Reload Mabala
              </button>
              <button
                onClick={() => {
                  try {
                    sessionStorage.clear();
                  } catch {}
                  window.location.reload();
                }}
                className="w-full py-2.5 px-4 bg-slate-700 hover:bg-slate-600 text-slate-300 font-medium text-xs rounded-xl transition cursor-pointer"
              >
                Clear Session Cache & Refresh
              </button>
            </div>
            <p className="text-[11px] text-emerald-400/80 mt-4 flex items-center justify-center gap-1">
              <span>🛡️</span> All persistent farm ledgers and draft records are safely cached.
            </p>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

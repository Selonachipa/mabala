import React, { useState } from "react";
import { 
  AlertTriangle, 
  CheckCircle2, 
  RotateCcw, 
  Trash2, 
  X, 
  DollarSign, 
  FileText, 
  Clock, 
  ChevronRight,
  ShieldCheck
} from "lucide-react";
import { RejectedWriteRecord, sessionService } from "../../services/sessionService";
import { doc, setDoc } from "firebase/firestore";
import { db, auth } from "../../firebase";

interface RejectedWritesModalProps {
  isOpen: boolean;
  onClose: () => void;
  writes: RejectedWriteRecord[];
  onWritesUpdated?: () => void;
  showToast?: (message: string, type?: "success" | "error" | "warning") => void;
}

export default function RejectedWritesModal({
  isOpen,
  onClose,
  writes,
  onWritesUpdated,
  showToast
}: RejectedWritesModalProps) {
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [confirmingFinancialId, setConfirmingFinancialId] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentUser = auth.currentUser;
  const uid = currentUser?.uid || "";

  const handleReapply = async (item: RejectedWriteRecord) => {
    if (!uid) return;
    setProcessingId(item.id);
    try {
      const activeSessionId = sessionService.getSessionId() || "reconciled_session";

      // Re-apply payload with active sessionId
      const newPayload = {
        ...item.payload,
        sessionId: activeSessionId,
        reconciledFromWriteId: item.id,
        reconciledAt: new Date().toISOString()
      };

      if (db && !(db as any)._dummy) {
        const targetRef = doc(db, item.collectionName, item.documentId);
        await setDoc(targetRef, newPayload, { merge: true });
      }

      await sessionService.markWriteResubmitted(uid, item.id);
      showToast?.(`Successfully reconciled write for ${item.module}`, "success");
      setConfirmingFinancialId(null);
      onWritesUpdated?.();
    } catch (err: any) {
      console.error("[RejectedWrites] Failed to reapply write:", err);
      showToast?.(`Failed to reapply: ${err.message}`, "error");
    } finally {
      setProcessingId(null);
    }
  };

  const handleDiscard = async (item: RejectedWriteRecord) => {
    if (!uid) return;
    setProcessingId(item.id);
    try {
      await sessionService.discardRejectedWrite(uid, item.id);
      showToast?.(`Discarded write for ${item.module}`, "warning");
      onWritesUpdated?.();
    } catch (err: any) {
      console.error("[RejectedWrites] Failed to discard write:", err);
      showToast?.(`Failed to discard: ${err.message}`, "error");
    } finally {
      setProcessingId(null);
    }
  };

  const handleDiscardAll = async () => {
    if (!uid || writes.length === 0) return;
    setProcessingId("all");
    try {
      await sessionService.discardAllRejectedWrites(uid, writes.map(w => w.id));
      showToast?.(`Discarded all ${writes.length} pending stale writes`, "warning");
      onWritesUpdated?.();
      onClose();
    } catch (err: any) {
      showToast?.(`Error discarding all: ${err.message}`, "error");
    } finally {
      setProcessingId(null);
    }
  };

  const financialWrites = writes.filter(w => w.isFinancial);
  const nonFinancialWrites = writes.filter(w => !w.isFinancial);

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden text-slate-800 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-5 bg-amber-50 border-b border-amber-200/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500 text-white rounded-xl shadow-xs">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 leading-snug">
                Reconciliation Queue: Stale Session Writes ({writes.length})
              </h2>
              <p className="text-xs text-slate-600">
                These mutations were saved while another device was active. Review before committing.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-5 overflow-y-auto space-y-5 divide-y divide-slate-100 flex-1">
          {writes.length === 0 ? (
            <div className="py-12 text-center text-slate-500">
              <ShieldCheck className="w-12 h-12 text-emerald-500 mx-auto mb-2 opacity-80" />
              <p className="font-semibold text-slate-800">No Stale Writes Found</p>
              <p className="text-xs mt-1 text-slate-500">All local mutations are synchronized with the active session.</p>
            </div>
          ) : (
            <>
              {/* Financial Section */}
              {financialWrites.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-rose-700 flex items-center gap-1.5">
                      <DollarSign className="w-3.5 h-3.5" />
                      Financial Mutations (Requires Explicit Confirmation)
                    </span>
                    <span className="text-[11px] font-semibold bg-rose-100 text-rose-800 px-2 py-0.5 rounded-md">
                      {financialWrites.length} Item{financialWrites.length > 1 ? "s" : ""}
                    </span>
                  </div>

                  <div className="space-y-2">
                    {financialWrites.map((item) => (
                      <div
                        key={item.id}
                        className="p-3.5 rounded-xl border border-rose-200/90 bg-rose-50/40 hover:bg-rose-50/70 transition-colors space-y-2"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="font-semibold text-slate-900 text-xs flex items-center gap-2">
                              <span>{item.summaryLabel || `${item.action.toUpperCase()} ${item.module}`}</span>
                              {item.amount !== undefined && (
                                <span className="font-mono font-bold text-rose-800 bg-rose-200/60 px-2 py-0.5 rounded text-[11px]">
                                  {item.currencySymbol || "ZK"} {Number(item.amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {new Date(item.rejectedAt).toLocaleString()}
                              </span>
                              <span>•</span>
                              <span className="font-mono text-[10px] text-slate-400">Doc: {item.documentId}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            {confirmingFinancialId === item.id ? (
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => handleReapply(item)}
                                  disabled={processingId === item.id}
                                  className="px-2.5 py-1 bg-rose-700 text-white rounded-lg text-xs font-bold hover:bg-rose-800 transition-colors cursor-pointer shadow-xs disabled:opacity-50"
                                >
                                  {processingId === item.id ? "Applying..." : "Confirm Commit"}
                                </button>
                                <button
                                  onClick={() => setConfirmingFinancialId(null)}
                                  className="px-2 py-1 text-slate-600 hover:bg-slate-200/60 rounded-lg text-xs font-medium cursor-pointer"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => setConfirmingFinancialId(item.id)}
                                disabled={processingId === item.id}
                                className="px-2.5 py-1.5 bg-white border border-rose-300 text-rose-800 hover:bg-rose-100 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer shadow-2xs"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                Review & Apply
                              </button>
                            )}

                            <button
                              onClick={() => handleDiscard(item)}
                              disabled={processingId === item.id}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-100/60 rounded-lg transition-colors cursor-pointer"
                              title="Discard Mutation"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {confirmingFinancialId === item.id && (
                          <div className="text-[11px] bg-rose-100/80 text-rose-900 p-2.5 rounded-lg border border-rose-200">
                            ⚠️ Committing this write will update ledger transactions under your current active session. Ensure it was not already re-entered on your other device.
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Non-Financial Section */}
              {nonFinancialWrites.length > 0 && (
                <div className="pt-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5" />
                      Operational & Settings Changes (Safe to Auto-Reapply)
                    </span>
                    <span className="text-[11px] font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                      {nonFinancialWrites.length} Item{nonFinancialWrites.length > 1 ? "s" : ""}
                    </span>
                  </div>

                  <div className="space-y-2">
                    {nonFinancialWrites.map((item) => (
                      <div
                        key={item.id}
                        className="p-3 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-50 transition-colors flex items-center justify-between gap-2"
                      >
                        <div>
                          <div className="font-semibold text-slate-900 text-xs">
                            {item.summaryLabel || `${item.action.toUpperCase()} ${item.module}`}
                          </div>
                          <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                            <span>{new Date(item.rejectedAt).toLocaleString()}</span>
                            <span>•</span>
                            <span className="font-mono text-[10px]">Doc: {item.documentId}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            onClick={() => handleReapply(item)}
                            disabled={processingId === item.id}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer shadow-2xs disabled:opacity-50"
                          >
                            <RotateCcw className={`w-3.5 h-3.5 ${processingId === item.id ? "animate-spin" : ""}`} />
                            Re-apply
                          </button>
                          <button
                            onClick={() => handleDiscard(item)}
                            disabled={processingId === item.id}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Discard"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            {writes.length} item{writes.length !== 1 ? "s" : ""} awaiting resolution
          </span>

          <div className="flex items-center gap-2">
            {writes.length > 0 && (
              <button
                onClick={handleDiscardAll}
                disabled={processingId !== null}
                className="px-3 py-2 text-xs font-medium text-rose-700 hover:bg-rose-100/50 rounded-xl transition-colors cursor-pointer"
              >
                Discard All
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer shadow-xs"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

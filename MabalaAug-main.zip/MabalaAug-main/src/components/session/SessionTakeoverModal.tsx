import React, { useState } from "react";
import { ShieldAlert, Laptop, Clock, LogOut, RefreshCw, AlertOctagon, Monitor, ShieldCheck } from "lucide-react";
import { SessionTerminationInfo } from "../../services/sessionService";
import { auth } from "../../firebase";
import { signOut } from "firebase/auth";

interface SessionTakeoverModalProps {
  info: SessionTerminationInfo | null;
  isOpen: boolean;
  onReclaimSession: () => Promise<void>;
  onSignOut: () => void;
}

export default function SessionTakeoverModal({
  info,
  isOpen,
  onReclaimSession,
  onSignOut
}: SessionTakeoverModalProps) {
  const [isReclaiming, setIsReclaiming] = useState<boolean>(false);
  const [reclaimError, setReclaimError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleReclaim = async () => {
    setIsReclaiming(true);
    setReclaimError(null);
    try {
      await onReclaimSession();
    } catch (err: any) {
      setReclaimError(err?.message || "Failed to reclaim session. Please sign in again.");
    } finally {
      setIsReclaiming(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (_) {}
    onSignOut();
  };

  const formattedTime = info?.timestamp
    ? new Date(
        typeof info.timestamp === "string"
          ? info.timestamp
          : info.timestamp?.toDate
          ? info.timestamp.toDate()
          : Date.now()
      ).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
    : "Just now";

  const resolvedDeviceName = info?.deviceName || info?.name || info?.device?.name || info?.newDeviceId || "Remote Device";
  const resolvedClientProfile = info?.deviceInfo || info?.device?.info;

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden text-slate-800">
        {/* Header Ribbon */}
        <div className="bg-rose-50/90 border-b border-rose-100/90 p-6 flex items-start gap-4">
          <div className="p-3 bg-rose-600 text-white rounded-2xl shadow-md shrink-0 flex items-center justify-center">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10.5px] font-extrabold uppercase tracking-wider bg-rose-100 text-rose-800 border border-rose-200/80 mb-2">
              <AlertOctagon className="w-3.5 h-3.5 text-rose-700 shrink-0" />
              <span>Single Active Session Security</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight font-sans leading-snug">
              Account Signed In on Another Device
            </h2>
            <p className="text-xs text-slate-600 mt-1 font-medium">
              Your session was closed because your account was accessed from another device.
            </p>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4 text-xs leading-relaxed text-slate-600">
          {/* Metadata Card */}
          <div className="p-4 bg-slate-50/90 rounded-2xl border border-slate-200/90 space-y-2.5">
            <div className="flex items-center justify-between text-slate-700 font-medium">
              <span className="flex items-center gap-2">
                <Laptop className="w-4 h-4 text-slate-500 shrink-0" />
                <span>Remote Device:</span>
              </span>
              <span className="font-mono text-xs font-bold text-slate-900 bg-white px-2.5 py-1 rounded-lg border border-slate-200 shadow-2xs truncate max-w-[220px]">
                {resolvedDeviceName}
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-700 font-medium">
              <span className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-slate-500 shrink-0" />
                <span>Displacement Time:</span>
              </span>
              <span className="font-mono text-xs font-bold text-slate-900 bg-white px-2.5 py-1 rounded-lg border border-slate-200 shadow-2xs">
                {formattedTime}
              </span>
            </div>

            {resolvedClientProfile && (
              <div className="flex items-center justify-between text-slate-700 font-medium pt-0.5">
                <span className="flex items-center gap-2">
                  <Monitor className="w-4 h-4 text-slate-500 shrink-0" />
                  <span>Client Profile:</span>
                </span>
                <span className="text-xs font-medium text-slate-800 bg-white px-2.5 py-1 rounded-lg border border-slate-200 shadow-2xs truncate max-w-[220px]" title={resolvedClientProfile}>
                  {resolvedClientProfile}
                </span>
              </div>
            )}
          </div>

          <p className="text-slate-600 leading-relaxed font-sans">
            Mabala enforces a strict <strong>single-active-session policy</strong> to safeguard agricultural financial ledgers, livestock counts, and inventory against zombie writes and multi-device race conditions.
          </p>

          <div className="bg-emerald-50/80 text-emerald-950 border border-emerald-200/80 p-3.5 rounded-2xl flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold text-emerald-900">Data Safe:</strong> Any unsaved changes made right before this takeover have been preserved in your browser's persistent cache and can be reviewed upon reconnecting.
            </div>
          </div>

          {reclaimError && (
            <div className="p-3 bg-rose-50 text-rose-800 rounded-xl border border-rose-200 text-xs font-medium flex items-center gap-2">
              <AlertOctagon className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{reclaimError}</span>
            </div>
          )}
        </div>

        {/* Actions Footer */}
        <div className="p-4 sm:p-5 bg-slate-50/90 border-t border-slate-200 flex items-center justify-between gap-3">
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-200/60 text-slate-600 text-[11px] font-semibold">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
            <span>Disconnected</span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleLogout}
              disabled={isReclaiming}
              className="px-4 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-700 hover:bg-slate-100 hover:text-slate-900 font-bold text-xs flex items-center gap-2 transition cursor-pointer shadow-2xs"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
            <button
              onClick={handleReclaim}
              disabled={isReclaiming}
              className="px-5 py-2.5 rounded-xl bg-[#0B1528] hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isReclaiming ? "animate-spin" : ""}`} />
              <span>{isReclaiming ? "Claiming Active Session..." : "Reclaim Session on This Device"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

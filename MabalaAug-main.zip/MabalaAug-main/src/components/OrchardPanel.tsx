import React, { useState } from "react";
import { 
  Sprout, 
  Trees, 
  QrCode, 
  Activity, 
  Calendar, 
  DollarSign, 
  Plus, 
  Check, 
  Trash2, 
  FileText, 
  AlertTriangle, 
  BarChart3, 
  ArrowRight, 
  Search, 
  Layers, 
  Droplet, 
  User, 
  Sparkles,
  MapPin,
  Clock,
  Heart,
  FileSpreadsheet,
  TrendingUp,
  Briefcase,
  Users,
  ShieldAlert,
  Sliders,
  Receipt
} from "lucide-react";
import { 
  CropCycle, 
  OrchardNurseryBatch, 
  OrchardTree, 
  OrchardActivity, 
  Account, 
  Invoice, 
  CashSale, 
  OrchardLabourLog, 
  OrchardYearHarvestSchedule,
  Employee,
  Payslip
} from "../types";
import OrchardBlockWizard from "./orchard/OrchardBlockWizard";
import OrchardBlockProfitabilityModal from "./orchard/OrchardBlockProfitabilityModal";
import OrchardHarvestScheduleModal from "./orchard/OrchardHarvestScheduleModal";
import OrchardFiveYearYieldChart from "./orchard/OrchardFiveYearYieldChart";
import OrchardProfitabilityReport from "./orchard/OrchardProfitabilityReport";
import OrchardBulkHarvestDateModal from "./orchard/OrchardBulkHarvestDateModal";

import { getFarmOperationalConfig } from "../config/farmOperationalConfig";

interface OrchardPanelProps {
  crops: CropCycle[];
  setCrops: React.Dispatch<React.SetStateAction<CropCycle[]>>;
  orchardNurseryBatches: OrchardNurseryBatch[];
  setOrchardNurseryBatches: React.Dispatch<React.SetStateAction<OrchardNurseryBatch[]>>;
  orchardTrees: OrchardTree[];
  setOrchardTrees: React.Dispatch<React.SetStateAction<OrchardTree[]>>;
  orchardActivities: OrchardActivity[];
  setOrchardActivities: React.Dispatch<React.SetStateAction<OrchardActivity[]>>;
  accounts: Account[];
  setAccounts: React.Dispatch<React.SetStateAction<Account[]>>;
  expenses: any[];
  setExpenses: React.Dispatch<React.SetStateAction<any[]>>;
  credits: number;
  setCredits: React.Dispatch<React.SetStateAction<number>>;
  isReadonly: boolean;
  currencySymbol?: string;
  employees?: Employee[];
  payslips?: Payslip[];
  invoices?: Invoice[];
  setInvoices?: React.Dispatch<React.SetStateAction<Invoice[]>>;
  cashSales?: CashSale[];
  setCashSales?: React.Dispatch<React.SetStateAction<CashSale[]>>;
  onSaveCloud: () => Promise<void>;
  showToast: (msg: string, type: "success" | "error" | "info") => void;
  activeFarm?: any;
  userProfile?: any;
}

export default function OrchardPanel({
  crops,
  setCrops,
  orchardNurseryBatches,
  setOrchardNurseryBatches,
  orchardTrees,
  setOrchardTrees,
  orchardActivities,
  setOrchardActivities,
  accounts,
  setAccounts,
  expenses,
  setExpenses,
  credits,
  setCredits,
  isReadonly,
  currencySymbol = "ZK",
  employees = [],
  payslips = [],
  invoices = [],
  setInvoices,
  cashSales = [],
  setCashSales,
  onSaveCloud,
  showToast,
  activeFarm,
  userProfile
}: OrchardPanelProps) {
  const [activeTab, setActiveTab] = useState<"blocks" | "profitability" | "nursery" | "trees" | "activities" | "reports">("blocks");
  
  // Search and Filters
  const [blockFilter, setBlockFilter] = useState("");
  const [treeSearch, setTreeSearch] = useState("");
  const [selectedBlockId, setSelectedBlockId] = useState<string>("");

  // Modals / Forms visibility
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [wizardSessionKey, setWizardSessionKey] = useState<number>(Date.now());
  const [showNurseryModal, setShowNurseryModal] = useState(false);
  const [showBulkTreeModal, setShowBulkTreeModal] = useState(false);
  const [showActivityModal, setShowActivityModal] = useState(false);
  const [showTransplantModal, setShowTransplantModal] = useState(false);
  const [applyToEntireBlock, setApplyToEntireBlock] = useState(true);

  // Orchard Block Specific Sub-Modals
  const [selectedBlockForProfitability, setSelectedBlockForProfitability] = useState<CropCycle | null>(null);
  const [selectedBlockForSchedule, setSelectedBlockForSchedule] = useState<CropCycle | null>(null);
  const [selectedBlockIdsForBulk, setSelectedBlockIdsForBulk] = useState<string[]>([]);
  const [showBulkHarvestModal, setShowBulkHarvestModal] = useState<boolean>(false);

  // Nursery Batch Form
  const [nurseryFruitType, setNurseryFruitType] = useState("Dragon Fruit");
  const [seedSource, setSeedSource] = useState("Local Selected Seeds");
  const [quantitySown, setQuantitySown] = useState(250);
  const [seedUnitCost, setSeedUnitCost] = useState<number>(() => getFarmOperationalConfig().defaultSeedUnitCost);
  const [materialsUnitCost, setMaterialsUnitCost] = useState<number>(() => getFarmOperationalConfig().defaultGraftingMaterialsCost);
  const [graftingMethod, setGraftingMethod] = useState<"approach" | "cleft" | "whip" | "side" | "bud" | "none">("cleft");
  const [grafter, setGrafter] = useState("");
  const [nurseryPrefix, setNurseryPrefix] = useState("NUR-2027");

  // Bulk Tree Registration Form
  const [bulkTreeBlockId, setBulkTreeBlockId] = useState("");
  const [bulkVariety, setBulkVariety] = useState("");
  const [bulkRootstock, setBulkRootstock] = useState("");
  const [bulkPlantedDate, setBulkPlantedDate] = useState(new Date().toISOString().split("T")[0]);
  const [bulkCount, setBulkCount] = useState(50);

  // Activity Log Form
  const [activityType, setActivityType] = useState<"spray" | "fertilise" | "irrigate" | "prune" | "graft">("spray");
  const [actBlockId, setActBlockId] = useState("");
  const [actTreeId, setActTreeId] = useState("");
  const [actProduct, setActProduct] = useState("");
  const [actQuantity, setActQuantity] = useState(10);
  const [actCost, setActCost] = useState(150);
  const [actOperator, setActOperator] = useState("");
  const [actPhi, setActPhi] = useState(14);
  const [actRei, setActRei] = useState(24);

  // Transplant Modal State
  const [transplantBatchId, setTransplantBatchId] = useState("");
  const [transplantBlockId, setTransplantBlockId] = useState("");
  const [transplantCount, setTransplantCount] = useState(100);

  // Detailed Tree View Modal
  const [selectedTree, setSelectedTree] = useState<OrchardTree | null>(null);

  // Helper ULID Generator for Client (simple & unique)
  const generateULID = () => {
    return "01" + Math.random().toString(36).substr(2, 9).toUpperCase() + Date.now().toString(36).toUpperCase();
  };

  // Debit/Credit helper matching Accounting Engine (Account 1420 Biological Assets)
  const syncAccount1420AndLedger = (newLivestock: any[], newPoultry: any[]) => {
    const liveLivestockValue = newLivestock.reduce((sum, r) => sum + (r.status === "Active" ? (Number(r.currentValue) || 0) : 0), 0);
    const livePoultryValue = newPoultry.reduce((sum, p) => sum + (p.status === "Active" ? (Number(p.currentBatchValuation) || 0) : 0), 0);
    const expected1420Balance = liveLivestockValue + livePoultryValue;

    setAccounts(prev => {
      return prev.map(a => a.code === "1420" ? { ...a, balance: expected1420Balance } : a);
    });
  };

  const deductCredit = (amount: number): boolean => {
    if (credits < amount) {
      showToast("Insufficient credits. Your account is in read-only mode.", "error");
      return false;
    }
    setCredits(prev => prev - amount);
    return true;
  };

  // --- ACTIONS ---

  // 1. Save Block from Wizard
  const handleSaveBlockFromWizard = (newBlock: CropCycle) => {
    if (isReadonly) return;
    if (credits <= 0) {
      showToast("Your credits are exhausted. Write actions are locked.", "error");
      return;
    }

    setCrops(prev => [newBlock, ...prev]);

    // Auto-register trees for this newly established block
    const treeCount = newBlock.orchard?.treeCount || newBlock.totalExpectedPlantPopulation || 0;
    if (treeCount > 0) {
      const prefix = newBlock.orchard?.fruitType ? newBlock.orchard.fruitType.substring(0, 3).toUpperCase() : "TRE";
      const plantYear = new Date(newBlock.plantingDate || new Date()).getFullYear();
      const newTrees: OrchardTree[] = [];
      for (let i = 1; i <= treeCount; i++) {
        const seq = String(i).padStart(4, "0");
        const treeIdStr = `${prefix}-${plantYear}-${seq}`;
        newTrees.push({
          id: generateULID(),
          treeId: treeIdStr,
          tenantId: "tenant-farm",
          blockCropCycleId: newBlock.id,
          variety: newBlock.variety || newBlock.cropName,
          rootstock: newBlock.orchard?.rootstock || "Standard Clonal Rootstock",
          plantedDate: newBlock.plantingDate || new Date().toISOString().split("T")[0],
          lifecycleStage: "Transplanted",
          healthScore: 100,
          createdAt: new Date().toISOString()
        });
      }
      setOrchardTrees(prev => [...newTrees, ...prev]);
    }

    showToast(`Established Perennial Orchard Block: "${newBlock.fieldBlock}" (${newBlock.orchard?.fruitType}) with ${treeCount} trees registered`, "success");
    setShowBlockModal(false);
    setWizardSessionKey(Date.now());
    
    // Auto-save to cloud
    setTimeout(() => {
      onSaveCloud();
    }, 500);
  };

  // 1b. Add Labour Log to Block
  const handleAddLabourLog = (blockId: string, log: OrchardLabourLog) => {
    setCrops(prev => prev.map(c => {
      if (c.id === blockId) {
        const currentLogs = c.orchard?.labourLogs || [];
        return {
          ...c,
          orchard: c.orchard ? {
            ...c.orchard,
            labourLogs: [log, ...currentLogs]
          } : undefined
        };
      }
      return c;
    }));

    setTimeout(() => {
      onSaveCloud();
    }, 500);
  };

  // 1c. Update Harvest Schedule
  const handleUpdateSchedule = (blockId: string, schedule: OrchardYearHarvestSchedule[]) => {
    setCrops(prev => prev.map(c => {
      if (c.id === blockId) {
        return {
          ...c,
          orchard: c.orchard ? {
            ...c.orchard,
            multiYearHarvestSchedule: schedule
          } : undefined
        };
      }
      return c;
    }));

    setTimeout(() => {
      onSaveCloud();
    }, 500);
  };

  // 1d. Bulk Shift Harvest Dates Handlers
  const handleToggleBlockSelection = (blockId: string) => {
    setSelectedBlockIdsForBulk(prev => 
      prev.includes(blockId) ? prev.filter(id => id !== blockId) : [...prev, blockId]
    );
  };

  const handleSelectAllBlocks = () => {
    const allIds = activeOrchardBlocks.map(b => b.id);
    setSelectedBlockIdsForBulk(allIds);
  };

  const handleDeselectAllBlocks = () => {
    setSelectedBlockIdsForBulk([]);
  };

  const handleApplyBulkHarvestShift = async (
    targetBlockIds: string[],
    daysToShift: number,
    shiftMultiYearSchedule: boolean,
    note?: string
  ) => {
    if (targetBlockIds.length === 0 || daysToShift === 0) return;

    setCrops(prevCrops => {
      return prevCrops.map(crop => {
        if (!targetBlockIds.includes(crop.id)) return crop;

        // Shift primary expectedHarvestDate
        const currentBaseDate = new Date(crop.expectedHarvestDate || new Date().toISOString().split("T")[0]);
        const validDate = isNaN(currentBaseDate.getTime()) ? new Date() : currentBaseDate;
        validDate.setDate(validDate.getDate() + daysToShift);
        const newHarvestDateStr = validDate.toISOString().split("T")[0];

        // Optionally shift multiYearHarvestSchedule entries
        let updatedOrchard = crop.orchard;
        if (shiftMultiYearSchedule && updatedOrchard?.multiYearHarvestSchedule && updatedOrchard.multiYearHarvestSchedule.length > 0) {
          const updatedSchedule = updatedOrchard.multiYearHarvestSchedule.map(sched => {
            const schedDate = new Date(sched.expectedHarvestDate || `${sched.calendarYear}-05-15`);
            const validSchedDate = isNaN(schedDate.getTime()) ? new Date(`${sched.calendarYear}-05-15`) : schedDate;
            validSchedDate.setDate(validSchedDate.getDate() + daysToShift);
            return {
              ...sched,
              expectedHarvestDate: validSchedDate.toISOString().split("T")[0]
            };
          });
          updatedOrchard = {
            ...updatedOrchard,
            multiYearHarvestSchedule: updatedSchedule
          };
        }

        const shiftLog = `[Shift ${new Date().toISOString().split("T")[0]}]: ${daysToShift > 0 ? `+${daysToShift}` : daysToShift}d${note ? ` - ${note}` : ""}`;
        const updatedNotes = crop.notes ? `${crop.notes}\n${shiftLog}` : shiftLog;

        return {
          ...crop,
          expectedHarvestDate: newHarvestDateStr,
          orchard: updatedOrchard,
          notes: updatedNotes
        };
      });
    });

    try {
      await onSaveCloud();
      showToast(
        `Successfully shifted harvest dates for ${targetBlockIds.length} orchard block${targetBlockIds.length > 1 ? "s" : ""} by ${daysToShift > 0 ? `+${daysToShift}` : daysToShift} days.`,
        "success"
      );
      setSelectedBlockIdsForBulk([]);
      setShowBulkHarvestModal(false);
    } catch (err) {
      showToast("Failed to persist shifted harvest dates.", "error");
    }
  };

  // 2. Create Nursery Batch
  const handleCreateNurseryBatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (isReadonly) return;
    if (credits <= 0) {
      showToast("Write actions locked. 0 Credits remaining.", "error");
      return;
    }

    const docId = generateULID();
    const batchId = `${nurseryPrefix}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newBatch: OrchardNurseryBatch = {
      id: docId,
      batchId,
      tenantId: "tenant-farm",
      fruitType: nurseryFruitType,
      seedSource,
      quantitySown,
      germinatedCount: Math.floor(quantitySown * 0.9), // default 90%
      failedCount: Math.floor(quantitySown * 0.1),
      successRatePct: 90,
      graftingMethod,
      grafter: grafter || "Self",
      graftSuccessRatePct: graftingMethod !== "none" ? 85 : 100,
      readyForTransplantDate: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // 6 months out
      linkedBlockCropCycleId: null,
      status: "active",
      createdAt: new Date().toISOString()
    };

    // Post expenses to ledger dynamically based on user-entered unit costs
    const numSeedUnitCost = Number(seedUnitCost) || 0;
    const numMaterialsUnitCost = graftingMethod !== "none" ? (Number(materialsUnitCost) || 0) : 0;
    const seedCost = quantitySown * numSeedUnitCost;
    const materialsCost = quantitySown * numMaterialsUnitCost;
    const totalCost = seedCost + materialsCost;

    const newExpense = {
      id: generateULID(),
      supplierName: seedSource,
      date: new Date().toISOString().split("T")[0],
      total: totalCost,
      rows: [
        {
          category: "Seed & Rootstock Procurement",
          description: `Nursery Seeds/Materials purchase for batch ${batchId}`,
          quantity: quantitySown,
          unitPrice: numSeedUnitCost + numMaterialsUnitCost,
          amount: totalCost,
          coaCode: graftingMethod !== "none" ? "5320" : "5310"
        }
      ],
      farmId: "tenant-farm"
    };

    setExpenses(prev => [newExpense, ...prev]);
    setOrchardNurseryBatches(prev => [newBatch, ...prev]);
    showToast(`Nursery Batch ${batchId} registered. Posted Cost of ${currencySymbol} ${totalCost} to CoA`, "success");
    setShowNurseryModal(false);

    // Update Accounts 5310/5320
    setAccounts(prev => {
      return prev.map(a => {
        if (graftingMethod !== "none" && a.code === "5320") {
          return { ...a, balance: a.balance + totalCost };
        } else if (graftingMethod === "none" && a.code === "5310") {
          return { ...a, balance: a.balance + totalCost };
        }
        return a;
      });
    });

    setTimeout(() => {
      onSaveCloud();
    }, 500);
  };

  // 3. Transplant Nursery Batch to Orchard Block (Bulk action)
  const handleTransplantToBlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (isReadonly) return;
    if (credits <= 0) return;

    const batch = orchardNurseryBatches.find(b => b.id === transplantBatchId);
    const block = crops.find(c => c.id === transplantBlockId);

    if (!batch || !block) {
      showToast("Please select a valid Batch and target Block", "error");
      return;
    }

    const count = Number(transplantCount) || batch.quantitySown;

    // Create bulk tree records
    const newTreesList: OrchardTree[] = [];
    const prefix = block.orchard?.fruitType ? block.orchard.fruitType.substring(0, 3).toUpperCase() : "TRE";
    
    for (let i = 1; i <= count; i++) {
      const seq = String(i).padStart(4, "0");
      const treeIdStr = `${prefix}-2027-${seq}`;
      newTreesList.push({
        id: generateULID(),
        treeId: treeIdStr,
        tenantId: "tenant-farm",
        blockCropCycleId: block.id,
        variety: block.variety || batch.fruitType,
        rootstock: block.orchard?.rootstock || "Wild Type",
        plantedDate: new Date().toISOString().split("T")[0],
        lifecycleStage: "Transplanted",
        healthScore: 100,
        createdAt: new Date().toISOString()
      });
    }

    // Set batch to closed & link block
    setOrchardNurseryBatches(prev => {
      return prev.map(b => b.id === batch.id ? { ...b, status: "closed", linkedBlockCropCycleId: block.id } : b);
    });

    setOrchardTrees(prev => [...newTreesList, ...prev]);

    // Update target block treeCount & stage
    setCrops(prev => {
      return prev.map(c => c.id === block.id ? {
        ...c,
        status: "Transplanted",
        orchard: c.orchard ? { ...c.orchard, treeCount: (c.orchard.treeCount || 0) + count } : undefined
      } : c);
    });

    showToast(`Successfully transplanted ${count} trees to Block "${block.fieldBlock}". Batch closed.`, "success");
    setShowTransplantModal(false);

    setTimeout(() => {
      onSaveCloud();
    }, 500);
  };

  // 4. Bulk Register Trees manually
  const handleBulkRegisterTrees = (e: React.FormEvent) => {
    e.preventDefault();
    if (isReadonly) return;

    const targetBlock = crops.find(c => c.id === bulkTreeBlockId);
    if (!targetBlock) {
      showToast("Please select a valid Orchard Block", "error");
      return;
    }

    const count = Number(bulkCount) || 50;
    const prefix = targetBlock.orchard?.fruitType ? targetBlock.orchard.fruitType.substring(0, 3).toUpperCase() : "TRE";

    const newTreesList: OrchardTree[] = [];
    for (let i = 1; i <= count; i++) {
      const seq = String(orchardTrees.filter(t => t.blockCropCycleId === targetBlock.id).length + i).padStart(4, "0");
      const treeIdStr = `${prefix}-2027-${seq}`;
      newTreesList.push({
        id: generateULID(),
        treeId: treeIdStr,
        tenantId: "tenant-farm",
        blockCropCycleId: targetBlock.id,
        variety: bulkVariety || targetBlock.variety || "Standard",
        rootstock: bulkRootstock || targetBlock.orchard?.rootstock || "M9",
        plantedDate: bulkPlantedDate,
        lifecycleStage: "Transplanted",
        healthScore: 95,
        createdAt: new Date().toISOString()
      });
    }

    setOrchardTrees(prev => [...newTreesList, ...prev]);

    // Update target block treeCount
    setCrops(prev => {
      return prev.map(c => c.id === targetBlock.id ? {
        ...c,
        orchard: c.orchard ? { ...c.orchard, treeCount: (c.orchard.treeCount || 0) + count } : undefined
      } : c);
    });

    showToast(`Bulk registered ${count} trees sequentially for Block "${targetBlock.fieldBlock}"`, "success");
    setShowBulkTreeModal(false);

    setTimeout(() => {
      onSaveCloud();
    }, 500);
  };

  // 5. Record Orchard Field Activity (Spray, fertilise, irrigate, etc.)
  const handleRecordActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (isReadonly) return;

    // Map coaCode based on Activity Type
    let coaCode = "5330"; // defaults to fertiliser
    if (activityType === "spray") coaCode = "5340";
    if (activityType === "irrigate") coaCode = "5350";
    if (activityType === "graft") coaCode = "5320";

    const newActivity: OrchardActivity = {
      id: generateULID(),
      tenantId: "tenant-farm",
      activityType,
      blockCropCycleId: actBlockId || undefined,
      treeId: applyToEntireBlock ? undefined : (actTreeId || undefined),
      product: actProduct,
      quantity: Number(actQuantity) || 1,
      cost: Number(actCost) || 0,
      coaCode,
      operator: actOperator || "Farm Worker",
      createdAt: new Date().toISOString()
    };

    setOrchardActivities(prev => [newActivity, ...prev]);

    // Debit CoA Cost
    setAccounts(prev => {
      return prev.map(a => a.code === coaCode ? { ...a, balance: a.balance + Number(actCost) } : a);
    });

    // Simulated event bus emission "ActivityRecorded"
    console.log(`[Mabala Event Bus] Emitted: ActivityRecorded { activityType: "${activityType}", coaCode: "${coaCode}", cost: ${actCost} }`);
    showToast(`Recorded ${activityType} activity successfully ${applyToEntireBlock ? "for entire block" : ""}. Posted Dr ${coaCode} (${currencySymbol} ${actCost})`, "success");
    setShowActivityModal(false);

    setTimeout(() => {
      onSaveCloud();
    }, 500);
  };

  // 5b. Delete individual Tree from block
  const handleDeleteTree = (id: string) => {
    if (isReadonly) return;
    const tree = orchardTrees.find(t => t.id === id);
    if (!tree) return;
    if (window.confirm(`Are you sure you want to delete tree ${tree.treeId}?`)) {
      setOrchardTrees(prev => prev.filter(t => t.id !== id));
      // Also decrement tree count of the corresponding block!
      setCrops(prev => {
        return prev.map(c => c.id === tree.blockCropCycleId ? {
          ...c,
          orchard: c.orchard ? { ...c.orchard, treeCount: Math.max(0, (c.orchard.treeCount || 1) - 1) } : undefined
        } : c);
      });
      showToast(`Tree ${tree.treeId} deleted successfully.`, "success");
      onSaveCloud();
    }
  };

  // 6. Delete Block (Crop Cycle)
  const handleDeleteBlock = (id: string) => {
    if (isReadonly) return;
    const confirmDelete = window.confirm("Are you sure you want to delete this Orchard Block? This action is irreversible.");
    if (confirmDelete) {
      setCrops(prev => prev.filter(c => c.id !== id));
      showToast("Orchard Block deleted successfully.", "success");
      onSaveCloud();
    }
  };

  // 7. Render Report Export with Credit Gating (5 credits)
  const handleExportReport = (reportName: string) => {
    if (isReadonly) return;
    if (credits < 5) {
      showToast("Insufficient credits. Report export costs 5 credits.", "error");
      return;
    }
    
    const success = deductCredit(5);
    if (success) {
      showToast(`Exported report "${reportName}" successfully! 5 Credits deducted.`, "success");
      onSaveCloud();
    }
  };

  // --- RENDERING PARSERS ---
  const activeOrchardBlocks = crops.filter(c => c.cycleType === "perennial_orchard");
  const filteredBlocks = activeOrchardBlocks.filter(b => 
    b.fieldBlock.toLowerCase().includes(blockFilter.toLowerCase()) || 
    b.variety?.toLowerCase().includes(blockFilter.toLowerCase())
  );

  const activeOrchardBlockIds = new Set(activeOrchardBlocks.map(b => b.id));
  const currentTenantId = activeFarm?.id || userProfile?.tenantId || userProfile?.uid;

  // Filter orchard trees strictly to active orchard blocks added by the user/tenant
  const userOrchardTrees = orchardTrees.filter(t => 
    activeOrchardBlockIds.has(t.blockCropCycleId) || 
    (currentTenantId && t.tenantId === currentTenantId)
  );

  // Active trees added by the user (zero rated if no active trees added by user)
  const activeTreesList = userOrchardTrees.filter(t => t.lifecycleStage !== "Removed" && t.lifecycleStage !== "Dead");
  const totalTreesInFarm = activeTreesList.length;
  const avgHealthScore = userOrchardTrees.length > 0 
    ? Math.round(userOrchardTrees.reduce((sum, t) => sum + t.healthScore, 0) / userOrchardTrees.length) 
    : 100;

  return (
    <div className="space-y-6 font-sans">
      
      {/* Top Welcome Title Grid */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white text-slate-900 p-6 rounded-2xl border border-slate-200/80 shadow-xs relative overflow-hidden">
        <div className="space-y-1 relative z-10">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200/80 rounded-full text-xs font-black uppercase tracking-wider">
              <Sprout className="w-3.5 h-3.5 text-emerald-600" />
              <span>Agricultural Core Suite</span>
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">Perennial Orchard & Tree Management</h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium max-w-2xl">Orchard lifecycle nursery propagation, individual tree registers, and automated double-entry agricultural accounting.</p>
        </div>
        
        {/* Actions Row */}
        <div className="flex flex-wrap gap-2 relative z-10">
          <button 
            onClick={() => {
              if (selectedBlockIdsForBulk.length === 0) {
                handleSelectAllBlocks();
              }
              setShowBulkHarvestModal(true);
            }}
            className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-black uppercase rounded-xl border border-indigo-200 transition-all flex items-center gap-2 shadow-2xs cursor-pointer active:scale-95"
            title="Bulk Shift Harvest Dates for Multiple Orchard Blocks"
          >
            <Calendar className="w-4 h-4 text-indigo-600" />
            <span>Bulk Shift Dates</span>
            {selectedBlockIdsForBulk.length > 0 && (
              <span className="px-1.5 py-0.2 bg-indigo-200 text-indigo-900 rounded text-[9px] font-mono font-bold">
                {selectedBlockIdsForBulk.length}
              </span>
            )}
          </button>

          <button 
            onClick={() => {
              setWizardSessionKey(Date.now());
              setShowBlockModal(true);
            }}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase rounded-xl transition-all flex items-center gap-2 shadow-xs active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4 text-white stroke-[3]" />
            <span>New Block Wizard</span>
          </button>
          
          <button 
            onClick={() => setShowNurseryModal(true)}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase rounded-xl border border-slate-200 transition-all flex items-center gap-2 cursor-pointer"
          >
            <Trees className="w-4 h-4 text-emerald-600" />
            <span>New Nursery Batch</span>
          </button>
        </div>
      </div>

      {/* Dashboard KPI Mini Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white p-4.5 sm:p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 rounded-xl text-emerald-700">
            <Layers className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 block leading-none pb-1.5">Orchard Blocks</span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 leading-none tracking-tight">{activeOrchardBlocks.length} Active</span>
          </div>
        </div>

        <div className="bg-white p-4.5 sm:p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 rounded-xl text-emerald-700">
            <Trees className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 block leading-none pb-1.5">Active Trees</span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 leading-none tracking-tight">{totalTreesInFarm.toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-white p-4.5 sm:p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-50 rounded-xl text-amber-700">
            <Sprout className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 block leading-none pb-1.5">Nursery Stock</span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 leading-none tracking-tight">
              {orchardNurseryBatches.filter(b => b.status === "active").reduce((sum, b) => sum + b.quantitySown, 0).toLocaleString()} Plants
            </span>
          </div>
        </div>

        <div className="bg-white p-4.5 sm:p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 rounded-xl text-emerald-700">
            <Heart className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 block leading-none pb-1.5">Average Health</span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 leading-none tracking-tight">{avgHealthScore}% KPI</span>
          </div>
        </div>

      </div>

      {/* Tab Selector Row */}
      <div className="flex border-b border-slate-200 overflow-x-auto pb-px gap-1">
        {[
          { id: "blocks", label: "Orchard Blocks", icon: Layers },
          { id: "profitability", label: "Profitability & Financials", icon: TrendingUp },
          { id: "nursery", label: "Nursery Batches", icon: Sprout },
          { id: "trees", label: "Tree Registry", icon: Trees },
          { id: "activities", label: "Field Activity Logs", icon: Activity },
          { id: "reports", label: "Orchard Report Templates", icon: FileText },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 py-3 px-4 text-xs font-bold uppercase border-b-2 tracking-wider shrink-0 transition-all cursor-pointer ${
                isActive 
                  ? "border-emerald-500 text-emerald-600 font-extrabold" 
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* --- CONTENT TABS --- */}

      {/* tab 1: ORCHARD BLOCKS */}
      {activeTab === "blocks" && (
        <div className="space-y-6">
          
          {/* Visual 5-Year Fruit Yield and Revenue Forecast */}
          {activeOrchardBlocks.length > 0 && (
            <OrchardFiveYearYieldChart 
              blocks={activeOrchardBlocks} 
              currencySymbol={currencySymbol} 
            />
          )}

          {/* Toolbar with Search and Bulk Update Actions */}
          <div className="flex flex-col sm:flex-row gap-2 justify-between items-center bg-slate-100 p-3 rounded-xl border border-slate-200/60">
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input 
                  type="text" 
                  placeholder="Search Blocks, Dragon Fruit, variety..." 
                  value={blockFilter}
                  onChange={e => setBlockFilter(e.target.value)}
                  className="w-full pl-9 pr-4 py-1.5 text-xs border border-slate-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-semibold"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={selectedBlockIdsForBulk.length === filteredBlocks.length ? handleDeselectAllBlocks : handleSelectAllBlocks}
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-700 transition-all cursor-pointer flex items-center gap-1.5"
                  title="Toggle Select All Orchard Blocks"
                >
                  <Check className={`w-3.5 h-3.5 ${selectedBlockIdsForBulk.length > 0 ? "text-emerald-600" : "text-slate-400"}`} />
                  <span>{selectedBlockIdsForBulk.length === filteredBlocks.length && filteredBlocks.length > 0 ? "Deselect All" : "Select All"}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (selectedBlockIdsForBulk.length === 0) {
                      handleSelectAllBlocks();
                    }
                    setShowBulkHarvestModal(true);
                  }}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-[11px] font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 shadow-xs active:scale-95"
                >
                  <Calendar className="w-3.5 h-3.5 text-indigo-200" />
                  <span>Bulk Shift Dates</span>
                  {selectedBlockIdsForBulk.length > 0 && (
                    <span className="px-1.5 py-0.2 bg-indigo-950 text-indigo-200 rounded text-[9px] font-mono font-bold">
                      {selectedBlockIdsForBulk.length}
                    </span>
                  )}
                </button>
              </div>

              <span className="text-[10px] text-slate-500 font-mono font-bold uppercase">{filteredBlocks.length} Blocks Located</span>
            </div>
          </div>

          {/* Sticky Active Selection Floating Banner */}
          {selectedBlockIdsForBulk.length > 0 && (
            <div className="bg-slate-900 text-white p-3.5 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl border border-slate-800 animate-in slide-in-from-top duration-200">
              <div className="flex items-center gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-xs font-bold font-mono text-emerald-400">
                  {selectedBlockIdsForBulk.length} of {filteredBlocks.length} Orchard Block{selectedBlockIdsForBulk.length > 1 ? "s" : ""} Selected
                </span>
                <span className="text-[11px] text-slate-400 hidden sm:inline">
                  — Ready for simultaneous date shifting across single or multi-year schedules
                </span>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={handleDeselectAllBlocks}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-lg cursor-pointer transition-colors"
                >
                  Clear Selection
                </button>
                <button
                  type="button"
                  onClick={() => setShowBulkHarvestModal(true)}
                  className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black uppercase tracking-wider rounded-lg cursor-pointer transition-all flex items-center gap-1.5 shadow-md active:scale-95"
                >
                  <Calendar className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>Configure Shift ({selectedBlockIdsForBulk.length} Blocks)</span>
                </button>
              </div>
            </div>
          )}

          {filteredBlocks.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-xl border border-slate-200 shadow-xs">
              <Trees className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-slate-800">No Perennial Orchard Blocks Set Up</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">Use the Block Setup Wizard to establish your first perennial block with variety, rootstock, loss factor, and revenue projections.</p>
              <button 
                onClick={() => {
                  setWizardSessionKey(Date.now());
                  setShowBlockModal(true);
                }}
                className="mt-4 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase rounded-lg cursor-pointer"
              >
                Launch Block Setup Wizard
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredBlocks.map(block => {
                const blockTrees = userOrchardTrees.filter(t => t.blockCropCycleId === block.id);
                const blockWater = block.orchard?.waterSource || "Borehole";
                const blockStage = block.status;
                const fruitName = block.orchard?.fruitType || block.cropType || "Fruit";
                const isDragonFruit = fruitName.toLowerCase().includes("dragon");
                const projectedRev = block.orchard?.projectedAnnualRevenue || block.expectedRevenueProjection || 0;
                const isCardSelected = selectedBlockIdsForBulk.includes(block.id);

                // Calculate realized sales for card summary
                const blockInvs = invoices.filter(inv => inv.cropId === block.id || inv.cropCycleId === block.id);
                const blockCs = cashSales.filter(cs => cs.cropCycleId === block.id);
                const totalSales = blockInvs.reduce((s, i) => s + (i.total || i.paidAmount || 0), 0) + blockCs.reduce((s, c) => s + (c.amount || 0), 0);

                return (
                  <div 
                    key={block.id} 
                    className={`bg-white border rounded-xl overflow-hidden shadow-xs hover:shadow transition-all relative flex flex-col justify-between ${
                      isCardSelected 
                        ? "ring-2 ring-emerald-500 border-emerald-400 bg-emerald-50/10 shadow-md" 
                        : "border-slate-200"
                    }`}
                  >
                    
                    {/* Header Banner */}
                    <div className={`p-5 border-b border-slate-100 ${
                      isDragonFruit 
                        ? "bg-gradient-to-r from-purple-50 via-pink-50 to-white border-purple-100" 
                        : "bg-gradient-to-r from-slate-50 to-slate-100/50"
                    }`}>
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex items-start gap-2.5">
                          {/* Selection Checkbox */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleBlockSelection(block.id);
                            }}
                            className={`mt-0.5 p-1 rounded-md border transition-all cursor-pointer shrink-0 ${
                              isCardSelected
                                ? "bg-emerald-600 border-emerald-700 text-white shadow-xs"
                                : "bg-white border-slate-300 text-transparent hover:border-emerald-400 hover:text-slate-300"
                            }`}
                            title={isCardSelected ? "Deselect Block" : "Select Block for Bulk Date Shift"}
                          >
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </button>

                          <div>
                            <div className="flex items-center gap-1.5 mb-1">
                              <span className={`px-2 py-0.5 text-[9px] font-black rounded uppercase tracking-wider block w-max ${
                                isDragonFruit 
                                  ? "bg-purple-600 text-white shadow-xs" 
                                  : "bg-emerald-500/15 text-emerald-700"
                              }`}>
                                {isDragonFruit ? "⭐ Dragon Fruit Trellis Block" : `${fruitName} Block`}
                              </span>
                              {block.orchard?.treeLifespanYears && (
                                <span className="text-[9px] font-mono text-slate-400 font-bold">
                                  {block.orchard.treeLifespanYears}y lifespan
                                </span>
                              )}
                            </div>
                            <h4 className="text-md font-bold text-slate-900">{block.fieldBlock}</h4>
                            <span className="text-xs text-slate-500 block">Variety: <strong>{block.variety || "Standard"}</strong></span>
                          </div>
                        </div>
                        
                        <div className="flex gap-1.5">
                          <button 
                            onClick={() => handleDeleteBlock(block.id)}
                            className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg transition-colors border border-transparent hover:border-rose-100"
                            title="Remove Block"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Stats List */}
                    <div className="p-5 space-y-3 flex-1">
                      
                      {/* Revenue Target Banner */}
                      <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-center justify-between">
                        <div>
                          <span className="text-[9px] text-emerald-800 uppercase font-black tracking-wider block">Annual Revenue Target</span>
                          <span className="text-lg font-black font-mono text-emerald-950">
                            {currencySymbol}{projectedRev.toLocaleString()}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-[9px] text-slate-400 uppercase font-bold block">Sales Realized</span>
                          <span className="text-xs font-black font-mono text-slate-800">
                            {currencySymbol}{totalSales.toLocaleString()}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                          <span className="text-[9px] text-slate-400 uppercase font-black block">Block Area</span>
                          <span className="font-extrabold text-slate-800">{block.orchard?.blockAreaHa || block.areaHectares || 1.0} Ha</span>
                        </div>
                        <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                          <span className="text-[9px] text-slate-400 uppercase font-black block">Tree Population</span>
                          <span className="font-extrabold text-slate-800">{(block.orchard?.treeCount || blockTrees.length).toLocaleString()} Trees</span>
                        </div>
                      </div>

                      <div className="space-y-2 text-xs border-t border-slate-100 pt-3">
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-medium">Estimated Yield:</span>
                          <span className="font-extrabold text-slate-700">
                            {block.orchard?.expectedAnnualYieldUnits 
                              ? `${block.orchard.expectedAnnualYieldUnits.toLocaleString()} ${block.orchard.harvestUnitName || 'Fruit'}s`
                              : `${(block.expectedYieldKg || 0).toLocaleString()} Kg`}
                            {block.orchard?.possibleLossesPct ? ` (-${block.orchard.possibleLossesPct}% losses)` : ""}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-medium">Rootstock / Spacing:</span>
                          <span className="font-extrabold text-slate-700">
                            {block.orchard?.rootstock || "Standard"} ({block.orchard?.spacing || "Standard"})
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-medium">Next Harvest Season:</span>
                          <span className="font-mono font-extrabold text-indigo-700">
                            {block.orchard?.harvestMonth || block.expectedHarvestDate || "April"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-medium">Water Source:</span>
                          <span className="font-extrabold text-slate-700 flex items-center gap-1">
                            <Droplet className="w-3 h-3 text-sky-500 fill-sky-500" />
                            {blockWater} ({block.orchard?.irrigationType || "Drip"})
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Footer Actions */}
                    <div className="p-3 bg-slate-50 border-t border-slate-100 grid grid-cols-4 gap-1.5">
                      <button 
                        onClick={() => setSelectedBlockForProfitability(block)}
                        className="p-2 text-center bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 rounded-lg text-[10px] font-bold text-emerald-800 transition-all flex flex-col items-center justify-center gap-1"
                        title="View Block P&L and Profitability"
                      >
                        <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Profitability</span>
                      </button>

                      <button 
                        onClick={() => setSelectedBlockForSchedule(block)}
                        className="p-2 text-center bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 rounded-lg text-[10px] font-bold text-indigo-800 transition-all flex flex-col items-center justify-center gap-1"
                        title="Multi-Year Harvest Schedule"
                      >
                        <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Schedule</span>
                      </button>

                      <button 
                        onClick={() => {
                          setSelectedBlockId(block.id);
                          setActBlockId(block.id);
                          setActiveTab("trees");
                        }}
                        className="p-2 text-center bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-700 transition-all flex flex-col items-center justify-center gap-1"
                        title="Tree Registry"
                      >
                        <Trees className="w-3.5 h-3.5 text-slate-500" />
                        <span>Registry</span>
                      </button>
                      
                      <button 
                        onClick={() => {
                          setActBlockId(block.id);
                          setActivityType("spray");
                          setShowActivityModal(true);
                        }}
                        className="p-2 bg-emerald-500 hover:bg-emerald-600 rounded-lg text-slate-950 text-[10px] font-black transition-all flex flex-col items-center justify-center gap-1"
                        title="Record Field Activity"
                      >
                        <Activity className="w-3.5 h-3.5" />
                        <span>Log Field</span>
                      </button>
                    </div>

                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* tab: PROFITABILITY & FINANCIALS (FULL DEDICATED REPORT) */}
      {activeTab === "profitability" && (
        <OrchardProfitabilityReport 
          blocks={activeOrchardBlocks}
          invoices={invoices}
          cashSales={cashSales}
          orchardActivities={orchardActivities}
          payslips={payslips}
          expenses={expenses}
          currencySymbol={currencySymbol}
          onAuditBlock={(block) => setSelectedBlockForProfitability(block)}
          onOpenWizard={() => setShowBlockModal(true)}
        />
      )}

      {/* tab 2: NURSERY BATCHES */}
      {activeTab === "nursery" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center bg-slate-100 p-3 rounded-xl border border-slate-200/60">
            <span className="text-xs font-bold text-slate-600">Nursery Stock Propagation Ledger</span>
            <button 
              onClick={() => setShowTransplantModal(true)}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase rounded-lg flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
            >
              <Trees className="w-3.5 h-3.5" />
              <span>Transplant to Block</span>
            </button>
          </div>

          {orchardNurseryBatches.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-xl border border-slate-200 shadow-xs">
              <Sprout className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-slate-800">No Nursery Batches Found</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">Propagate seedlings bulk-scale, log grafting methods, and record materials procurement before transplanting trees into blocks.</p>
              <button 
                onClick={() => setShowNurseryModal(true)}
                className="mt-4 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase rounded-lg cursor-pointer"
              >
                Add Seedling Batch
              </button>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-[10px] text-slate-400 uppercase font-black tracking-wider border-b border-slate-200">
                    <th className="p-4">Batch ID</th>
                    <th className="p-4">Fruit Type / Seed Source</th>
                    <th className="p-4 text-center">Qty Sown</th>
                    <th className="p-4 text-center">Grafting Method</th>
                    <th className="p-4">Ready For Transplant</th>
                    <th className="p-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                  {orchardNurseryBatches.map(batch => (
                    <tr key={batch.id} className="hover:bg-slate-50/50">
                      <td className="p-4 font-mono font-bold text-indigo-600">{batch.batchId}</td>
                      <td className="p-4">
                        <span className="font-extrabold text-slate-900 block">{batch.fruitType}</span>
                        <span className="text-[10px] text-slate-400 font-medium">Source: {batch.seedSource}</span>
                      </td>
                      <td className="p-4 text-center">
                        <span className="font-extrabold block text-slate-800">{batch.quantitySown}</span>
                        <span className="text-[9px] text-slate-400 font-mono">Success: {batch.successRatePct}%</span>
                      </td>
                      <td className="p-4 text-center font-bold">
                        <span className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded-md text-slate-700 capitalize">
                          {batch.graftingMethod}
                        </span>
                        {batch.graftingMethod !== "none" && (
                          <span className="text-[9px] text-slate-400 font-medium block mt-0.5">By {batch.grafter}</span>
                        )}
                      </td>
                      <td className="p-4 font-mono font-medium">{batch.readyForTransplantDate}</td>
                      <td className="p-4">
                        <span className={`px-2 py-0.5 rounded font-bold text-[10px] uppercase border ${
                          batch.status === "active" 
                            ? "bg-emerald-50 text-emerald-700 border-emerald-200" 
                            : batch.status === "ready_for_transplant" 
                              ? "bg-amber-50 text-amber-700 border-amber-200 animate-pulse" 
                              : "bg-slate-100 text-slate-500 border-slate-200"
                        }`}>
                          {batch.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* tab 3: TREE REGISTRY */}
      {activeTab === "trees" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-100 p-3 rounded-xl border border-slate-200/60 items-center">
            
            {/* Filter by Block */}
            <select
              value={selectedBlockId}
              onChange={e => setSelectedBlockId(e.target.value)}
              className="w-full text-xs font-semibold border bg-white rounded-lg p-2 text-slate-700"
            >
              <option value="">-- All Orchard Blocks --</option>
              {activeOrchardBlocks.map(b => (
                <option key={b.id} value={b.id}>{b.fieldBlock} ({b.orchard?.fruitType})</option>
              ))}
            </select>

            {/* Search Tree ID */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input 
                type="text" 
                placeholder="Search Tree ID or Variety..." 
                value={treeSearch}
                onChange={e => setTreeSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
              />
            </div>

            {/* Bulk Tree Registry button */}
            <div className="text-right">
              <button 
                onClick={() => {
                  if (selectedBlockId) {
                    setBulkTreeBlockId(selectedBlockId);
                  }
                  setShowBulkTreeModal(true);
                }}
                className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-black uppercase rounded-lg flex items-center gap-1.5 transition-all ml-auto cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
                <span>Bulk Tree Register</span>
              </button>
            </div>

          </div>

          {/* Tree Table */}
          {userOrchardTrees.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-xl border border-slate-200 shadow-xs">
              <QrCode className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-slate-800">No Trees Registered</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">Register block trees in bulk or transplant from nursery batches to populate tree-level tracking profiles and generate traceability QR codes.</p>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-[10px] text-slate-400 uppercase font-black tracking-wider border-b border-slate-200">
                    <th className="p-4">Tree ID & QR</th>
                    <th className="p-4">Block Location</th>
                    <th className="p-4">Variety & Rootstock</th>
                    <th className="p-4 text-center">Health KPI</th>
                    <th className="p-4">Lifecycle Stage</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                  {userOrchardTrees
                    .filter(t => !selectedBlockId || t.blockCropCycleId === selectedBlockId)
                    .filter(t => t.treeId.toLowerCase().includes(treeSearch.toLowerCase()) || t.variety.toLowerCase().includes(treeSearch.toLowerCase()))
                    .map(tree => {
                      const blk = crops.find(c => c.id === tree.blockCropCycleId);
                      return (
                        <tr key={tree.id} className="hover:bg-slate-50/50">
                          
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <button 
                                onClick={() => setSelectedTree(tree)}
                                className="p-1.5 bg-slate-100 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 rounded-lg border border-slate-200 transition-colors"
                              >
                                <QrCode className="w-4 h-4" />
                              </button>
                              <div>
                                <span className="font-mono font-black text-slate-900 block">{tree.treeId}</span>
                                <span className="text-[9px] text-slate-400 font-mono">QR Traceability Live</span>
                              </div>
                            </div>
                          </td>

                          <td className="p-4 font-bold text-slate-700">
                            {blk ? blk.fieldBlock : "Unknown Block"}
                          </td>

                          <td className="p-4">
                            <span className="font-extrabold text-slate-900 block">{tree.variety}</span>
                            <span className="text-[10px] text-slate-400">Rootstock: {tree.rootstock}</span>
                          </td>

                          <td className="p-4 text-center">
                            <span className={`inline-block px-2 py-0.5 rounded-full font-bold text-[10px] ${
                              tree.healthScore >= 90 ? "bg-emerald-50 text-emerald-700" : tree.healthScore >= 70 ? "bg-amber-50 text-amber-700" : "bg-rose-50 text-rose-700"
                            }`}>
                              {tree.healthScore}% Score
                            </span>
                          </td>

                          <td className="p-4">
                            <span className="px-2 py-0.5 bg-indigo-50 border border-indigo-100 rounded text-indigo-700 text-[10px] font-bold">
                              {tree.lifecycleStage}
                            </span>
                          </td>

                          <td className="p-4 text-right">
                            <div className="flex justify-end gap-1.5">
                              <button
                                onClick={() => {
                                  setActTreeId(tree.treeId);
                                  if (blk) setActBlockId(blk.id);
                                  setApplyToEntireBlock(false);
                                  setShowActivityModal(true);
                                }}
                                className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-white font-bold text-[10px] uppercase rounded transition-colors inline-flex items-center gap-1"
                              >
                                <Activity className="w-3 h-3 text-emerald-400" />
                                <span>Log Activity</span>
                              </button>
                              <button
                                onClick={() => handleDeleteTree(tree.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 hover:border-rose-100 rounded transition-all"
                                title="Delete Tree"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>

                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* tab 4: FIELD ACTIVITIES */}
      {activeTab === "activities" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center bg-slate-100 p-3 rounded-xl border border-slate-200/60">
            <span className="text-xs font-bold text-slate-600">Field Operations Event Bus</span>
            <button
              onClick={() => {
                setActBlockId("");
                setActTreeId("");
                setShowActivityModal(true);
              }}
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-black uppercase rounded-lg flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>Record Activity Event</span>
            </button>
          </div>

          {orchardActivities.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-xl border border-slate-200 shadow-xs">
              <Activity className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-slate-800">No Operation Logs Found</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">Emitted spray, fertilization, and grafting logs will post double-entry cost balances into financial ledger accounts in real-time.</p>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-[10px] text-slate-400 uppercase font-black tracking-wider border-b border-slate-200">
                    <th className="p-4">Activity Type</th>
                    <th className="p-4">Block / Tree Target</th>
                    <th className="p-4">Product Used</th>
                    <th className="p-4 text-center">Cost Posted</th>
                    <th className="p-4">CoA Ledger Mapping</th>
                    <th className="p-4">Operator</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                  {orchardActivities.map(act => {
                    const blockObj = crops.find(c => c.id === act.blockCropCycleId);
                    return (
                      <tr key={act.id} className="hover:bg-slate-50/50">
                        <td className="p-4 capitalize">
                          <span className="flex items-center gap-2">
                            <span className={`w-2 h-2 rounded-full ${
                              act.activityType === "spray" ? "bg-rose-500" : act.activityType === "fertilise" ? "bg-emerald-500" : "bg-sky-500"
                            }`} />
                            <strong className="text-slate-900 font-extrabold">{act.activityType}</strong>
                          </span>
                        </td>
                        <td className="p-4">
                          {act.treeId ? (
                            <span className="px-1.5 py-0.5 bg-slate-100 text-slate-700 border border-slate-200 rounded font-mono font-bold text-[10px]">
                              {act.treeId}
                            </span>
                          ) : blockObj ? (
                            <span className="font-bold text-slate-700">{blockObj.fieldBlock}</span>
                          ) : (
                            <span className="text-slate-400 font-medium">Whole Orchard</span>
                          )}
                        </td>
                        <td className="p-4">
                          <span className="font-extrabold text-slate-950 block">{act.product}</span>
                          <span className="text-[10px] text-slate-400 font-medium">Qty: {act.quantity}</span>
                        </td>
                        <td className="p-4 text-center text-rose-600 font-bold">
                          {currencySymbol} {act.cost.toLocaleString()}
                        </td>
                        <td className="p-4">
                          <span className="px-2 py-0.5 bg-rose-50 border border-rose-100 rounded text-rose-700 font-mono font-bold text-[10px]">
                            Debit {act.coaCode} (COGS)
                          </span>
                        </td>
                        <td className="p-4 font-medium text-slate-500">{act.operator}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* tab 5: ORCHARD REPORTS TEMPLATES */}
      {activeTab === "reports" && (
        <div className="space-y-6">
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex gap-3 text-xs text-amber-800">
            <AlertTriangle className="w-5 h-5 shrink-0 text-amber-600" />
            <div>
              <p className="font-bold">Agricultural Credit Metering System Active</p>
              <p className="mt-1">All reports generated from the Chart of Accounts accounting engine carry a flat cost of <strong>5 Credits</strong> per export. Zero credit balances lock exports into read-only viewing.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {[
              { id: "pnl", title: "Orchard Block P&L Statement", coa: "4300-5395", desc: "Detailed breakdown of fruit sales revenue against direct nursery, grafting, and spray COGS per block." },
              { id: "health", title: "Tree Inventory & Health KPI", coa: "Non-Financial", desc: "Tree registry population counters, variety breakdown, and spray history with average mortality KPIs." },
              { id: "grafting", title: "Nursery & Grafting Performance", coa: "5310/5320", desc: "Bulk germination success rates, cleft/approach grafting quality audits, and transplant timelines." },
              { id: "cost", title: "Orchard Cost per Tree / Hectare", coa: "5330-5360", desc: "Comparative operations cost metrics analyzing irrigation, chemical, and pruning cost bases." },
              { id: "postharvest", title: "Post-Harvest Loss & Grading", coa: "4310/5370", desc: "Fruit grading sorting analysis, moisture rot depreciation, and drying/packaging conversion factors." },
              { id: "forecast", title: "Orchard Yield & Revenue Forecast", coa: "Projections", desc: "3-year rolling revenue projection utilizing tree counts, average yield conversion, and unit price tables." },
            ].map(rep => (
              <div key={rep.id} className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between hover:border-emerald-300 transition-all">
                <div className="space-y-2">
                  <div className="flex justify-between items-start gap-2">
                    <h4 className="text-sm font-bold text-slate-950">{rep.title}</h4>
                    <span className="px-1.5 py-0.5 bg-slate-100 text-slate-500 rounded font-mono text-[9px] font-black uppercase">
                      {rep.coa}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">{rep.desc}</p>
                </div>
                
                <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[10px] text-emerald-600 font-extrabold uppercase tracking-wider">Costs 5 Credits</span>
                  <button 
                    onClick={() => handleExportReport(rep.title)}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-emerald-500 hover:text-slate-950 text-white text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>Generate Report</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* --- MODALS & FORMS --- */}

      {/* Modal 1: Advanced Perennial Block Setup Wizard */}
      <OrchardBlockWizard
        key={wizardSessionKey}
        isOpen={showBlockModal}
        onClose={() => setShowBlockModal(false)}
        onSaveBlock={handleSaveBlockFromWizard}
        currencySymbol={currencySymbol}
        showToast={showToast}
      />

      {/* Modal 1b: Per-Block Profitability & HR Labour Audit Modal */}
      {selectedBlockForProfitability && (
        <OrchardBlockProfitabilityModal
          isOpen={Boolean(selectedBlockForProfitability)}
          onClose={() => setSelectedBlockForProfitability(null)}
          block={selectedBlockForProfitability}
          orchardActivities={orchardActivities}
          invoices={invoices}
          cashSales={cashSales}
          expenses={expenses}
          currencySymbol={currencySymbol}
          employees={employees}
          onAddLabourLog={handleAddLabourLog}
          showToast={showToast}
        />
      )}

      {/* Modal 1c: Multi-Year Harvest Lifecycle Calendar */}
      {selectedBlockForSchedule && (
        <OrchardHarvestScheduleModal
          isOpen={Boolean(selectedBlockForSchedule)}
          onClose={() => setSelectedBlockForSchedule(null)}
          block={selectedBlockForSchedule}
          currencySymbol={currencySymbol}
          onUpdateSchedule={handleUpdateSchedule}
          showToast={showToast}
        />
      )}

      {/* Modal 2: New Nursery Batch */}
      {showNurseryModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-[1100] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <Sprout className="w-4 h-4 text-emerald-500" />
                <span>New Propagation Batch</span>
              </h3>
              <button onClick={() => setShowNurseryModal(false)} className="text-slate-400 hover:text-slate-600 font-bold text-xs">✕</button>
            </div>
            <form onSubmit={handleCreateNurseryBatch} className="p-6 space-y-4 text-xs">
              
              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Nursery Prefix (e.g. NUR-2027)</label>
                <input type="text" value={nurseryPrefix} onChange={e => setNurseryPrefix(e.target.value)} required className="w-full border border-slate-200 rounded-lg p-2 font-mono" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Fruit Variety</label>
                  <select value={nurseryFruitType} onChange={e => setNurseryFruitType(e.target.value)} className="w-full border border-slate-200 rounded-lg p-2 font-bold text-slate-700">
                    <option value="Avocado">Avocado (Hass)</option>
                    <option value="Mango">Mango (Tommy Atkins)</option>
                    <option value="Valencia Orange">Valencia Orange</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Seeds Quantity</label>
                  <input type="number" value={quantitySown} onChange={e => setQuantitySown(Number(e.target.value))} required className="w-full border border-slate-200 rounded-lg p-2 font-mono font-bold" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Grafting Method</label>
                  <select value={graftingMethod} onChange={e => setGraftingMethod(e.target.value as any)} className="w-full border border-slate-200 rounded-lg p-2 font-bold text-slate-700">
                    <option value="cleft">Cleft Grafting</option>
                    <option value="approach">Approach Grafting</option>
                    <option value="whip">Whip Grafting</option>
                    <option value="bud">Budding</option>
                    <option value="none">None (Seedling)</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Grafting Operator</label>
                  {employees && employees.length > 0 ? (
                    <select
                      value={grafter}
                      onChange={(e) => setGrafter(e.target.value)}
                      className="w-full border border-slate-200 rounded-lg p-2 bg-white text-slate-700 font-bold"
                    >
                      <option value="">-- Select Employee --</option>
                      {employees.map((emp: any) => (
                        <option key={emp.id} value={emp.name}>
                          {emp.name} ({emp.role})
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input type="text" value={grafter} onChange={e => setGrafter(e.target.value)} placeholder="e.g. S. Phiri" className="w-full border border-slate-200 rounded-lg p-2" />
                  )}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Seed Procurement Source</label>
                <input type="text" value={seedSource} onChange={e => setSeedSource(e.target.value)} required className="w-full border border-slate-200 rounded-lg p-2" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Seed/Rootstock Cost per Unit ({currencySymbol})</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={seedUnitCost}
                    onChange={e => setSeedUnitCost(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Materials Cost per Plant ({currencySymbol})</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    disabled={graftingMethod === "none"}
                    value={graftingMethod === "none" ? 0 : materialsUnitCost}
                    onChange={e => setMaterialsUnitCost(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 font-mono font-bold disabled:bg-slate-100 disabled:text-slate-400"
                  />
                </div>
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-[11px] leading-relaxed text-slate-600 flex justify-between items-center">
                <span>Total Calculated Batch Cost:</span>
                <span className="font-mono font-black text-slate-900 text-sm">
                  {currencySymbol} {((quantitySown * (Number(seedUnitCost) || 0)) + (graftingMethod !== "none" ? quantitySown * (Number(materialsUnitCost) || 0) : 0)).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>

              <div className="pt-4 flex gap-2">
                <button type="button" onClick={() => setShowNurseryModal(false)} className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold uppercase transition-all">Cancel</button>
                <button type="submit" className="flex-1 py-2 bg-emerald-500 hover:bg-emerald-600 rounded-xl font-black uppercase text-slate-950 transition-all">Sow Batch</button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Modal 3: Transplant to Block */}
      {showTransplantModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-[1100] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <Trees className="w-4 h-4 text-indigo-600" />
                <span>Transplant to Block</span>
              </h3>
              <button onClick={() => setShowTransplantModal(false)} className="text-slate-400 hover:text-slate-600 font-bold text-xs">✕</button>
            </div>
            <form onSubmit={handleTransplantToBlock} className="p-6 space-y-4 text-xs">
              
              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Select Nursery Batch</label>
                <select value={transplantBatchId} onChange={e => setTransplantBatchId(e.target.value)} required className="w-full border border-slate-200 rounded-lg p-2 font-bold text-slate-700">
                  <option value="">-- Select Active Batch --</option>
                  {orchardNurseryBatches.filter(b => b.status === "active").map(b => (
                    <option key={b.id} value={b.id}>{b.batchId} ({b.fruitType} - Qty: {b.quantitySown})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Select Target Block</label>
                <select value={transplantBlockId} onChange={e => setTransplantBlockId(e.target.value)} required className="w-full border border-slate-200 rounded-lg p-2 font-bold text-slate-700">
                  <option value="">-- Select Target Block --</option>
                  {activeOrchardBlocks.map(b => (
                    <option key={b.id} value={b.id}>{b.fieldBlock} ({b.variety})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Quantity of Trees to Transplant</label>
                <input type="number" value={transplantCount} onChange={e => setTransplantCount(Number(e.target.value))} required className="w-full border border-slate-200 rounded-lg p-2 font-mono font-bold" />
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-[11px] leading-relaxed text-slate-600">
                <p>⚡ This bulk transplanting action automatically instantiates <strong>QR-traceable</strong> Tree Registry records with unique sequence identifiers.</p>
              </div>

              <div className="pt-4 flex gap-2">
                <button type="button" onClick={() => setShowTransplantModal(false)} className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold uppercase transition-all">Cancel</button>
                <button type="submit" className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black uppercase transition-all">Transplant</button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Modal 4: Bulk Tree Manual Registry */}
      {showBulkTreeModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-[1100] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-500" />
                <span>Bulk Tree Manual Register</span>
              </h3>
              <button onClick={() => setShowBulkTreeModal(false)} className="text-slate-400 hover:text-slate-600 font-bold text-xs">✕</button>
            </div>
            <form onSubmit={handleBulkRegisterTrees} className="p-6 space-y-4 text-xs">
              
              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Orchard Block Location</label>
                <select value={bulkTreeBlockId} onChange={e => setBulkTreeBlockId(e.target.value)} required className="w-full border border-slate-200 rounded-lg p-2 font-bold text-slate-700">
                  <option value="">-- Select Orchard Block --</option>
                  {activeOrchardBlocks.map(b => (
                    <option key={b.id} value={b.id}>{b.fieldBlock} ({b.variety})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Variety</label>
                  <input type="text" value={bulkVariety} onChange={e => setBulkVariety(e.target.value)} placeholder="e.g. Hass / Fuerte" className="w-full border border-slate-200 rounded-lg p-2" />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Rootstock</label>
                  <input type="text" value={bulkRootstock} onChange={e => setBulkRootstock(e.target.value)} placeholder="e.g. Dusa" className="w-full border border-slate-200 rounded-lg p-2" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Planted Date</label>
                  <input type="date" value={bulkPlantedDate} onChange={e => setBulkPlantedDate(e.target.value)} required className="w-full border border-slate-200 rounded-lg p-2 font-mono" />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Quantity of Trees</label>
                  <input type="number" value={bulkCount} onChange={e => setBulkCount(Number(e.target.value))} required className="w-full border border-slate-200 rounded-lg p-2 font-mono font-bold" />
                </div>
              </div>

              <div className="pt-4 flex gap-2">
                <button type="button" onClick={() => setShowBulkTreeModal(false)} className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold uppercase transition-all">Cancel</button>
                <button type="submit" className="flex-1 py-2 bg-emerald-500 hover:bg-emerald-600 rounded-xl font-black uppercase text-slate-950 transition-all">Register Trees</button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Modal 5: Record Operation Activity */}
      {showActivityModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-[1100] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-500" />
                <span>Record Operation Activity</span>
              </h3>
              <button onClick={() => setShowActivityModal(false)} className="text-slate-400 hover:text-slate-600 font-bold text-xs">✕</button>
            </div>
            <form onSubmit={handleRecordActivity} className="p-6 space-y-4 text-xs">
              
              <div className="flex items-center gap-2 bg-emerald-50/50 p-3 rounded-xl border border-emerald-100/50">
                <input
                  type="checkbox"
                  id="applyToEntireBlockCheckbox"
                  checked={applyToEntireBlock}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    setApplyToEntireBlock(checked);
                    if (checked) {
                      setActTreeId("");
                    }
                  }}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                />
                <label htmlFor="applyToEntireBlockCheckbox" className="font-bold text-slate-700 cursor-pointer select-none">
                  Apply to Entire Orchard Block
                </label>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Activity Type</label>
                  <select value={activityType} onChange={e => setActivityType(e.target.value as any)} className="w-full border border-slate-200 rounded-lg p-2 font-bold text-slate-700 bg-white">
                    <option value="spray">Spray & Crop Protection</option>
                    <option value="fertilise">Fertilise Block</option>
                    <option value="irrigate">Irrigation Log</option>
                    <option value="prune">Pruning & Trimming</option>
                    <option value="graft">Grafting Labour</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Operator Name</label>
                  {employees && employees.length > 0 ? (
                    <select
                      value={actOperator}
                      onChange={(e) => setActOperator(e.target.value)}
                      required
                      className="w-full border border-slate-200 rounded-lg p-2 font-bold text-slate-700 bg-white"
                    >
                      <option value="">-- Select Employee --</option>
                      {employees.map((emp: any) => (
                        <option key={emp.id} value={emp.name}>
                          {emp.name} ({emp.role})
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input type="text" value={actOperator} onChange={e => setActOperator(e.target.value)} required placeholder="e.g. Kampamba" className="w-full border border-slate-200 rounded-lg p-2 font-semibold" />
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Orchard Block Target</label>
                  <select value={actBlockId} onChange={e => setActBlockId(e.target.value)} required className="w-full border border-slate-200 rounded-lg p-2 font-bold text-slate-700 bg-white">
                    <option value="">-- Select Block --</option>
                    {activeOrchardBlocks.map(b => (
                      <option key={b.id} value={b.id}>{b.fieldBlock} ({b.variety})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Specific Tree ID</label>
                  <input
                    type="text"
                    value={actTreeId}
                    onChange={e => setActTreeId(e.target.value)}
                    disabled={applyToEntireBlock}
                    placeholder={applyToEntireBlock ? "N/A (Whole Block Active)" : "e.g. AVO-2027-0012"}
                    className="w-full border border-slate-200 rounded-lg p-2 font-mono disabled:bg-slate-50 disabled:text-slate-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <label className="text-[9px] font-black uppercase text-slate-400 block mb-1">Product/Material Used</label>
                  <input type="text" value={actProduct} onChange={e => setActProduct(e.target.value)} required placeholder="e.g. Copper Oxychloride" className="w-full border border-slate-200 rounded-lg p-2 font-semibold" />
                </div>
                <div>
                  <label className="text-[9px] font-black uppercase text-slate-400 block mb-1">Qty (L/Kg)</label>
                  <input type="number" value={actQuantity} onChange={e => setActQuantity(Number(e.target.value))} required className="w-full border border-slate-200 rounded-lg p-2 font-mono font-bold" />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Total Activity Cost ({currencySymbol})</label>
                <input type="number" value={actCost} onChange={e => setActCost(Number(e.target.value))} required className="w-full border border-slate-200 rounded-lg p-2 font-mono font-bold" />
              </div>

              {activityType === "spray" && (
                <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100">
                  <div>
                    <label className="text-[9px] font-black uppercase text-slate-400 block mb-1">Pre-Harvest Interval (PHI Days)</label>
                    <input type="number" value={actPhi} onChange={e => setActPhi(Number(e.target.value))} className="w-full border border-slate-200 rounded-lg p-2 font-mono" />
                  </div>
                  <div>
                    <label className="text-[9px] font-black uppercase text-slate-400 block mb-1">Re-Entry Interval (REI Hours)</label>
                    <input type="number" value={actRei} onChange={e => setActRei(Number(e.target.value))} className="w-full border border-slate-200 rounded-lg p-2 font-mono" />
                  </div>
                </div>
              )}

              <div className="pt-4 flex gap-2">
                <button type="button" onClick={() => setShowActivityModal(false)} className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold uppercase transition-all">Cancel</button>
                <button type="submit" className="flex-1 py-2 bg-emerald-500 hover:bg-emerald-600 rounded-xl font-black uppercase text-slate-950 transition-all">Record Log</button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Modal 6: QR Code display detailed view */}
      {selectedTree && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-[1100] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-sm w-full overflow-hidden p-6 text-center text-xs space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <span className="font-extrabold uppercase text-slate-400">Tree Traceability profile</span>
              <button onClick={() => setSelectedTree(null)} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
            </div>

            {/* QR Graphic Mock */}
            <div className="mx-auto w-48 h-48 bg-slate-100 border-2 border-slate-200 rounded-xl flex flex-col items-center justify-center relative p-3">
              <QrCode className="w-32 h-32 text-slate-900" />
              <div className="absolute bottom-1 bg-slate-900 text-white font-mono text-[9px] px-2 py-0.5 rounded">
                {selectedTree.treeId}
              </div>
            </div>

            <div className="space-y-1.5 text-left bg-slate-50 p-4 rounded-xl border border-slate-200/60">
              <div className="flex justify-between">
                <span className="text-slate-400 font-medium">Tree ID:</span>
                <strong className="font-mono text-slate-900">{selectedTree.treeId}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-medium">Variety:</span>
                <strong className="text-slate-800">{selectedTree.variety}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-medium">Rootstock:</span>
                <strong className="text-slate-800">{selectedTree.rootstock}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-medium">Planted:</span>
                <strong className="text-slate-800 font-mono">{selectedTree.plantedDate}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-medium">Health score:</span>
                <span className="px-1.5 py-0.5 bg-emerald-100 rounded text-emerald-800 font-black">
                  {selectedTree.healthScore}% KPI
                </span>
              </div>
            </div>

            <button 
              onClick={() => setSelectedTree(null)}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold uppercase"
            >
              Close Profile
            </button>
          </div>
        </div>
      )}

      {/* Modal 7: Bulk Update Harvest Dates */}
      <OrchardBulkHarvestDateModal
        isOpen={showBulkHarvestModal}
        onClose={() => setShowBulkHarvestModal(false)}
        allBlocks={crops}
        selectedBlockIds={selectedBlockIdsForBulk}
        onToggleBlockSelection={handleToggleBlockSelection}
        onSelectAllBlocks={handleSelectAllBlocks}
        onDeselectAllBlocks={handleDeselectAllBlocks}
        onApplyBulkShift={handleApplyBulkHarvestShift}
        currencySymbol={currencySymbol}
        showToast={showToast}
      />

    </div>
  );
}

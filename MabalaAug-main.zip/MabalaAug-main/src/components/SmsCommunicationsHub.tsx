import React, { useState, useEffect, useRef, useMemo } from "react";
import { SmsDeliveryStatusLogs } from "./SmsDeliveryStatusLogs";
import { safeFormatError } from "../utils/errorUtils";
import {
  Eye,
  RotateCw,
  ChevronsLeft,
  ChevronsRight,
  ChevronLeft,
  Radio,
  MessageSquare,
  Send,
  Upload,
  Download,
  Users,
  CheckSquare,
  Square,
  Search,
  FileSpreadsheet,
  Plus,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  Clock,
  CreditCard,
  Smartphone,
  Sparkles,
  RefreshCw,
  FileText,
  Phone,
  UserCheck,
  ShieldCheck,
  History,
  DollarSign,
  Filter,
  ArrowRight,
  ChevronRight,
  Info,
  Calendar,
  X,
  Copy,
  ExternalLink
} from "lucide-react";

export interface ContactItem {
  id: string;
  name: string;
  phone: string;
  category: "Customer" | "Employee" | "Supplier" | "Agro Dealer" | "Agronomist" | "Custom";
  role?: string;
  location?: string;
  notes?: string;
}

export interface SmsPackage {
  id: string;
  name: string;
  credits: number;
  priceZmw: number;
  popular?: boolean;
}

export interface SmsBatchRecord {
  id: string;
  senderUid: string;
  senderType: string;
  tenantId: string;
  message_template: string;
  total_recipients: number;
  total_parts: number;
  cost_per_sms: number;
  total_cost: number;
  send_mode: "immediate" | "scheduled";
  scheduled_time?: string | null;
  status: "sent" | "delivered" | "scheduled" | "failed" | "pending";
  processed_gateway?: string;
  timestamp: string;
}

export interface SmsLedgerItem {
  id: string;
  institutionId?: string;
  amount: number;
  type: "top_up" | "deduction" | "refund";
  reference: string;
  note?: string;
  createdAt: string;
}

interface SmsCommunicationsHubProps {
  userProfile: any;
  currentRole: string;
  workspaceMode: string;
  activeFarm?: any;
  farms?: any[];
  customers?: any[];
  employees?: any[];
  suppliers?: any[];
  smsCredits?: number;
  setSmsCredits?: (updater: number | ((prev: number) => number)) => void;
  credits?: number;
  setCredits?: (updater: number | ((prev: number) => number)) => void;
  setLipilaCheckout?: (bundle: any) => void;
  selectedCountry?: string;
}

export const SmsCommunicationsHub: React.FC<SmsCommunicationsHubProps> = ({
  userProfile,
  currentRole,
  workspaceMode,
  activeFarm,
  farms = [],
  customers = [],
  employees = [],
  suppliers = [],
  smsCredits = 0,
  setSmsCredits,
  credits = 0,
  setLipilaCheckout,
  selectedCountry = "Zambia"
}) => {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<"broadcast" | "single" | "delivery_logs" | "topup" | "batches" | "ledger">("broadcast");
  const [inspectingBatch, setInspectingBatch] = useState<any | null>(null);
  const [inspectingBatchLoading, setInspectingBatchLoading] = useState<boolean>(false);
  const [batchPage, setBatchPage] = useState<number>(1);
  const [batchStatusFilter, setBatchStatusFilter] = useState<string>("all");

  // System Gateway Registry & Pricing State
  const [ratePerSmsZmw, setRatePerSmsZmw] = useState<number>(0.90);
  const [activeGatewayName, setActiveGatewayName] = useState<string>("Beem SMS Gateway");
  const [smsPackages, setSmsPackages] = useState<SmsPackage[]>([
    { id: "starter", name: "Starter SMS Pack", credits: 50, priceZmw: 45, popular: false },
    { id: "farm_node", name: "Farm Node Pack", credits: 100, priceZmw: 90, popular: true },
    { id: "business", name: "Agro Business & Supplier Pack", credits: 250, priceZmw: 200, popular: false },
    { id: "enterprise", name: "Commercial Broadcast Pack", credits: 500, priceZmw: 380, popular: false },
    { id: "commercial", name: "Enterprise Hub Pack", credits: 1000, priceZmw: 700, popular: false }
  ]);
  const [isLoadingPricing, setIsLoadingPricing] = useState<boolean>(false);

  // Audience & Directory State
  const [contacts, setContacts] = useState<ContactItem[]>([]);
  const [selectedContactIds, setSelectedContactIds] = useState<Set<string>>(new Set());
  const [recipientCategoryFilter, setRecipientCategoryFilter] = useState<string>("all");
  const [contactSearchQuery, setContactSearchQuery] = useState<string>("");
  const [audienceSourceTab, setAudienceSourceTab] = useState<"directory" | "csv" | "manual">("directory");

  // CSV Import State
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [csvParsedContacts, setCsvParsedContacts] = useState<ContactItem[]>([]);
  const [csvParseErrors, setCsvParseErrors] = useState<string[]>([]);
  const [isParsingCsv, setIsParsingCsv] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Manual Add State
  const [manualInputText, setManualInputText] = useState<string>("");
  const [manualNameInput, setManualNameInput] = useState<string>("");
  const [manualPhoneInput, setManualPhoneInput] = useState<string>("");
  const [manualCategoryInput, setManualCategoryInput] = useState<string>("Customer");

  // Broadcast Message Composer State
  const [broadcastMessage, setBroadcastMessage] = useState<string>(
    "Hello {firstName}, update from {farmName}: We have fresh harvest available for order. Contact us at {farmPhone}."
  );
  const [sendMode, setSendMode] = useState<"immediate" | "scheduled">("immediate");
  const [scheduledDateTime, setScheduledDateTime] = useState<string>("");
  const [isSendingBroadcast, setIsSendingBroadcast] = useState<boolean>(false);
  const [broadcastSuccessResult, setBroadcastSuccessResult] = useState<any>(null);
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);

  // Single SMS State
  const [singleRecipientPhone, setSingleRecipientPhone] = useState<string>("");
  const [singleRecipientName, setSingleRecipientName] = useState<string>("");
  const [singleCategory, setSingleCategory] = useState<string>("Customer");
  const [singleMessage, setSingleMessage] = useState<string>("");
  const [isSendingSingle, setIsSendingSingle] = useState<boolean>(false);
  const [singleSuccessResult, setSingleSuccessResult] = useState<any>(null);

  // Batches & Ledger State
  const [batches, setBatches] = useState<SmsBatchRecord[]>([]);
  const [isLoadingBatches, setIsLoadingBatches] = useState<boolean>(false);
  const [selectedBatchDetails, setSelectedBatchDetails] = useState<any | null>(null);
  const [ledgerEntries, setLedgerEntries] = useState<SmsLedgerItem[]>([]);

  // Lipila Top-up Modal State
  const [selectedTopUpPackage, setSelectedTopUpPackage] = useState<SmsPackage | null>(null);
  const [customCreditsAmount, setCustomCreditsAmount] = useState<number>(100);
  const [momoOperator, setMomoOperator] = useState<"MTN" | "AIRTEL" | "ZAMTEL">("MTN");
  const [momoPhoneNumber, setMomoPhoneNumber] = useState<string>(userProfile?.phone || "");
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [paymentSuccessNotice, setPaymentSuccessNotice] = useState<string | null>(null);

  // Manual payment reconciliation state (e.g. for K45 payment timeout recovery)
  const [showReconcileModal, setShowReconcileModal] = useState<boolean>(false);
  const [manualReconcileRef, setManualReconcileRef] = useState<string>("");
  const [isReconciling, setIsReconciling] = useState<boolean>(false);
  const [reconcileResult, setReconcileResult] = useState<{ success: boolean; message: string; credits?: number } | null>(null);

  const handleManualReconcile = async (refToTest?: string) => {
    const targetRef = (refToTest || manualReconcileRef).trim();
    if (!targetRef) {
      setReconcileResult({ 
        success: false, 
        message: "Please enter your Lipila or Mobile Money Reference ID (e.g. ref-1787993978099-8310 or LPLXC-...)" 
      });
      return;
    }

    setIsReconciling(true);
    setReconcileResult(null);

    try {
      const res = await fetch("/api/payments/manual-reconcile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          referenceId: targetRef,
          tenantId: userProfile?.tenantId || activeFarm?.id || "global",
          uid: userProfile?.uid
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        const addedCredits = Number(data.allocation?.allocatedCredits) || 50;
        setReconcileResult({
          success: true,
          message: data.message || `Payment verified! Successfully credited +${addedCredits} SMS Credits.`,
          credits: addedCredits
        });
        if (setSmsCredits) {
          setSmsCredits((prev: number) => (Number(prev) || 0) + addedCredits);
        }
        setPaymentSuccessNotice(`🎉 Payment verified! Successfully credited +${addedCredits} SMS credits to your wallet.`);
      } else {
        setReconcileResult({
          success: false,
          message: data.message || data.error || "Payment record not found or not yet settled on Lipila. Please double check the reference ID."
        });
      }
    } catch (err: any) {
      setReconcileResult({
        success: false,
        message: `Verification network error: ${err.message || "Failed to reach server"}`
      });
    } finally {
      setIsReconciling(false);
    }
  };

  // Derive active farm name
  const currentFarmName = useMemo(() => {
    return activeFarm?.name || userProfile?.farmName || userProfile?.name || "Mabala Farm Node";
  }, [activeFarm, userProfile]);

  const currentFarmPhone = useMemo(() => {
    return userProfile?.phone || activeFarm?.phone || "";
  }, [userProfile, activeFarm]);

  // 1. Initial Load: Fetch Pricing & Gateways
  const fetchSmsPricing = async () => {
    setIsLoadingPricing(true);
    try {
      const res = await fetch(`/api/sms/pricing?uid=${userProfile?.uid || ""}&tenantId=${userProfile?.tenantId || "global"}`);
      if (res.ok) {
        const data = await res.json();
        if (data.ratePerSmsZmw) {
          setRatePerSmsZmw(Number(data.ratePerSmsZmw));
        }
        if (data.gatewayName) {
          setActiveGatewayName(data.gatewayName);
        }
        if (Array.isArray(data.packages) && data.packages.length > 0) {
          setSmsPackages(data.packages);
        }
      }
    } catch (err) {
      console.warn("Failed to fetch SMS pricing, using registry fallback", err);
    } finally {
      setIsLoadingPricing(false);
    }
  };

  // 2. Aggregate all Contacts from Props and Server
  useEffect(() => {
    fetchSmsPricing();
    loadBatches();
    aggregateContacts();
  }, [customers, employees, suppliers, userProfile]);

  const aggregateContacts = () => {
    const list: ContactItem[] = [];

    // Add Customers
    if (Array.isArray(customers)) {
      customers.forEach((c: any, idx: number) => {
        if (c.phone || c.phoneNumber) {
          list.push({
            id: c.id || `cust_${idx}_${c.phone || c.phoneNumber}`,
            name: c.name || c.customerName || "Customer",
            phone: c.phone || c.phoneNumber,
            category: "Customer",
            location: c.location || c.address || "",
            notes: c.notes || c.cropPurchased || c.preferredProduce || ""
          });
        }
      });
    }

    // Add Employees
    if (Array.isArray(employees)) {
      employees.forEach((e: any, idx: number) => {
        if ((e.phone || e.phoneNumber) && e.status !== "Terminated") {
          list.push({
            id: e.id || `emp_${idx}_${e.phone || e.phoneNumber}`,
            name: e.name || e.employeeName || "Farm Worker",
            phone: e.phone || e.phoneNumber,
            category: "Employee",
            role: e.role || e.designation || e.department || "Staff",
            location: e.location || "",
            notes: e.department || e.role || ""
          });
        }
      });
    }

    // Add Suppliers
    if (Array.isArray(suppliers)) {
      suppliers.forEach((s: any, idx: number) => {
        if (s.phone || s.phoneNumber) {
          list.push({
            id: s.id || `sup_${idx}_${s.phone || s.phoneNumber}`,
            name: s.name || s.companyName || "Supplier",
            phone: s.phone || s.phoneNumber,
            category: "Supplier",
            role: s.contactPerson || s.category || "Vendor",
            notes: s.category || s.productsSupplied || ""
          });
        }
      });
    }

    // Set strictly authentic live contacts
    setContacts(list);
  };

  // Inspect specific batch recipient delivery report
  const handleInspectBatch = async (batch: SmsBatchRecord) => {
    setInspectingBatch({ batch, messages: [], summary: null });
    setInspectingBatchLoading(true);
    setBatchPage(1);
    setBatchStatusFilter("all");
    try {
      const uid = userProfile?.uid || "";
      const email = userProfile?.email || "";
      const res = await fetch(`/api/sms/batches/${batch.id}?uid=${encodeURIComponent(uid)}&email=${encodeURIComponent(email)}`);
      if (res.ok) {
        const data = await res.json();
        setInspectingBatch({
          batch: data.batch || batch,
          messages: data.messages || [],
          summary: data.summary || {
            total: (data.messages || []).length,
            sent: (data.messages || []).filter((m: any) => m.status === "sent" || m.status === "delivered").length,
            delivered: (data.messages || []).filter((m: any) => m.status === "delivered").length,
            failed: (data.messages || []).filter((m: any) => m.status === "failed").length,
            pending: (data.messages || []).filter((m: any) => m.status === "pending").length,
            deliveryRate: (data.messages || []).length > 0 ? 100 : 0
          }
        });
      }
    } catch (err) {
      console.error("Failed to fetch batch delivery details", err);
    } finally {
      setInspectingBatchLoading(false);
    }
  };

  // 3. Load Batches History
  const loadBatches = async () => {
    setIsLoadingBatches(true);
    try {
      const uid = userProfile?.uid || "";
      const tenantId = userProfile?.tenantId || (userProfile?.role === "Farm Owner" ? `farmer_${uid}` : "global");
      const email = userProfile?.email || "";
      const res = await fetch(`/api/sms/batches?uid=${encodeURIComponent(uid)}&tenantId=${encodeURIComponent(tenantId)}&email=${encodeURIComponent(email)}`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.batches)) {
          setBatches(data.batches);
        }
      }
    } catch (err) {
      console.warn("Failed to load SMS batches", err);
    } finally {
      setIsLoadingBatches(false);
    }
  };

  // Filtered Contacts for Selection
  const filteredContacts = useMemo(() => {
    return contacts.filter((c) => {
      const matchesCategory =
        recipientCategoryFilter === "all" ||
        c.category.toLowerCase() === recipientCategoryFilter.toLowerCase();
      const matchesSearch =
        !contactSearchQuery.trim() ||
        c.name.toLowerCase().includes(contactSearchQuery.toLowerCase()) ||
        c.phone.includes(contactSearchQuery) ||
        (c.notes && c.notes.toLowerCase().includes(contactSearchQuery.toLowerCase())) ||
        (c.role && c.role.toLowerCase().includes(contactSearchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [contacts, recipientCategoryFilter, contactSearchQuery]);

  // Selected Contacts Array
  const selectedContactsList = useMemo(() => {
    return contacts.filter((c) => selectedContactIds.has(c.id));
  }, [contacts, selectedContactIds]);

  // Toggle Single Contact Selection
  const handleToggleContact = (id: string) => {
    setSelectedContactIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  // Select / Deselect All Filtered
  const handleSelectAllFiltered = () => {
    setSelectedContactIds((prev) => {
      const next = new Set(prev);
      filteredContacts.forEach((c) => next.add(c.id));
      return next;
    });
  };

  const handleDeselectAllFiltered = () => {
    setSelectedContactIds((prev) => {
      const next = new Set(prev);
      filteredContacts.forEach((c) => next.delete(c.id));
      return next;
    });
  };

  // CSV Import Handlers
  const handleCsvFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCsvFile(file);
    setIsParsingCsv(true);
    setCsvParseErrors([]);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const text = evt.target?.result as string;
        if (!text) {
          setCsvParseErrors(["File is empty"]);
          setIsParsingCsv(false);
          return;
        }

        const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
        if (lines.length < 2) {
          setCsvParseErrors(["CSV must contain a header row and at least 1 contact record"]);
          setIsParsingCsv(false);
          return;
        }

        const header = lines[0].split(",").map((h) => h.trim().toLowerCase());
        const nameIdx = header.findIndex((h) => h.includes("name"));
        const phoneIdx = header.findIndex((h) => h.includes("phone") || h.includes("number") || h.includes("mobile"));
        const catIdx = header.findIndex((h) => h.includes("category") || h.includes("group") || h.includes("type"));
        const notesIdx = header.findIndex((h) => h.includes("note") || h.includes("remark") || h.includes("tag"));

        const parsed: ContactItem[] = [];
        const errors: string[] = [];

        for (let i = 1; i < lines.length; i++) {
          const cols = lines[i].split(",").map((c) => c.trim().replace(/^["']|["']$/g, ""));
          if (cols.length === 0 || !cols.some((c) => c.length > 0)) continue;

          const rawPhone = phoneIdx >= 0 ? cols[phoneIdx] : cols[1] || cols[0];
          const rawName = nameIdx >= 0 ? cols[nameIdx] : cols[0] || `Recipient ${i}`;
          const rawCat = catIdx >= 0 ? cols[catIdx] : "Custom";
          const rawNotes = notesIdx >= 0 ? cols[notesIdx] : "";

          // Clean phone
          let cleanPhone = rawPhone ? rawPhone.replace(/[^0-9+]/g, "") : "";
          if (cleanPhone.startsWith("0")) {
            cleanPhone = "+260" + cleanPhone.slice(1);
          } else if (!cleanPhone.startsWith("+") && cleanPhone.length === 9) {
            cleanPhone = "+260" + cleanPhone;
          } else if (!cleanPhone.startsWith("+") && cleanPhone.startsWith("260")) {
            cleanPhone = "+" + cleanPhone;
          }

          if (!cleanPhone || cleanPhone.length < 9) {
            errors.push(`Row ${i + 1}: Invalid phone number (${rawPhone})`);
            continue;
          }

          parsed.push({
            id: `csv_${Date.now()}_${i}_${cleanPhone}`,
            name: rawName || "CSV Contact",
            phone: cleanPhone,
            category: (rawCat as any) || "Custom",
            notes: rawNotes
          });
        }

        setCsvParsedContacts(parsed);
        setCsvParseErrors(errors);
      } catch (err: any) {
        setCsvParseErrors([`Failed to parse CSV: ${err.message}`]);
      } finally {
        setIsParsingCsv(false);
      }
    };
    reader.readAsText(file);
  };

  const handleAddCsvToAudience = () => {
    if (csvParsedContacts.length === 0) return;
    setContacts((prev) => {
      const existingIds = new Set(prev.map((c) => c.phone));
      const newItems = csvParsedContacts.filter((c) => !existingIds.has(c.phone));
      return [...newItems, ...prev];
    });

    setSelectedContactIds((prev) => {
      const next = new Set(prev);
      csvParsedContacts.forEach((c) => next.add(c.id));
      return next;
    });

    setAudienceSourceTab("directory");
  };

  // Download Sample CSV
  const handleDownloadSampleCsv = () => {
    const sampleCsvContent = `Full Name,Phone Number,Category,Notes
Mwila Chilufya,+260977123456,Customer,Maize bulk buyer
Chileshe Banda,+260966789012,Employee,Irrigation supervisor
Mutale Phiri,+260955345678,Supplier,Fertilizer distributor
Agrovet Central,+260978901234,Agro Dealer,Seed stockist
Dr. Emmanuel Bwalya,+260971234567,Agronomist,Soil diagnostic specialist`;

    const blob = new Blob([sampleCsvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "mabala_bulk_sms_recipients_sample.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Manual Add Handler
  const handleAddManualContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualPhoneInput.trim()) return;

    let cleanPhone = manualPhoneInput.replace(/[^0-9+]/g, "");
    if (cleanPhone.startsWith("0")) {
      cleanPhone = "+260" + cleanPhone.slice(1);
    } else if (!cleanPhone.startsWith("+") && cleanPhone.length === 9) {
      cleanPhone = "+260" + cleanPhone;
    } else if (!cleanPhone.startsWith("+") && cleanPhone.startsWith("260")) {
      cleanPhone = "+" + cleanPhone;
    }

    const newContact: ContactItem = {
      id: `man_${Date.now()}_${cleanPhone}`,
      name: manualNameInput.trim() || "Manual Contact",
      phone: cleanPhone,
      category: manualCategoryInput as any,
      notes: "Manually entered"
    };

    setContacts((prev) => [newContact, ...prev]);
    setSelectedContactIds((prev) => new Set(prev).add(newContact.id));
    setManualNameInput("");
    setManualPhoneInput("");
  };

  // Message Calculations
  const smsLength = broadcastMessage.length;
  const smsParts = useMemo(() => {
    if (smsLength <= 160) return 1;
    return Math.ceil(smsLength / 153);
  }, [smsLength]);

  const totalCalculatedCostCredits = useMemo(() => {
    return selectedContactsList.length * smsParts;
  }, [selectedContactsList, smsParts]);

  const totalCalculatedCostZmw = useMemo(() => {
    return (totalCalculatedCostCredits * ratePerSmsZmw).toFixed(2);
  }, [totalCalculatedCostCredits, ratePerSmsZmw]);

  const hasSufficientCredits = (smsCredits || 0) >= totalCalculatedCostCredits;

  // Insert Variable Tag into Broadcast Message
  const insertVariableTag = (tag: string) => {
    setBroadcastMessage((prev) => prev + " " + tag);
  };

  // Preview Message for First Selected Recipient
  const previewPersonalizedMessage = useMemo(() => {
    const targetRecipient = selectedContactsList[0] || (contacts[0] ? contacts[0] : {
      name: "Recipient",
      phone: "+260970000000",
      category: "Contact",
      notes: ""
    });
    const firstName = targetRecipient.name.split(" ")[0] || "Farmer";
    return broadcastMessage
      .replace(/{name}/g, targetRecipient.name)
      .replace(/{firstName}/g, firstName)
      .replace(/{first_name}/g, firstName)
      .replace(/{farmName}/g, currentFarmName)
      .replace(/{farmPhone}/g, currentFarmPhone)
      .replace(/{phone}/g, targetRecipient.phone)
      .replace(/{category}/g, targetRecipient.category)
      .replace(/{notes}/g, targetRecipient.notes || "")
      .replace(/{date}/g, new Date().toLocaleDateString());
  }, [broadcastMessage, selectedContactsList, currentFarmName, currentFarmPhone]);

  // Dispatch Broadcast Campaign
  const handleExecuteBroadcast = async () => {
    if (selectedContactsList.length === 0) {
      alert("Please select at least one recipient.");
      return;
    }
    if (!broadcastMessage.trim()) {
      alert("Please enter a message to broadcast.");
      return;
    }
    if (!hasSufficientCredits) {
      setActiveTab("topup");
      return;
    }

    setIsSendingBroadcast(true);
    setShowConfirmModal(false);
    setBroadcastSuccessResult(null);

    try {
      const payload = {
        uid: userProfile?.uid || "",
        tenantId: userProfile?.tenantId || (userProfile?.role === "Farm Owner" ? `farmer_${userProfile?.uid}` : activeFarm?.id || "global"),
        email: userProfile?.email || "",
        senderType: currentRole === "super_admin" ? "super_admin" : "farmer",
        selectedRecipients: selectedContactsList.map((c) => ({
          id: c.id,
          name: c.name,
          phone: c.phone,
          category: c.category,
          notes: c.notes
        })),
        rawMessage: broadcastMessage,
        sendMode: sendMode,
        scheduledTime: sendMode === "scheduled" ? scheduledDateTime : null
      };

      const res = await fetch("/api/sms/send-batch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to dispatch SMS broadcast");
      }

      setBroadcastSuccessResult(data);
      if (setSmsCredits) {
        setSmsCredits((prev: number) => Math.max(0, prev - totalCalculatedCostCredits));
      }

      // Add to local batches
      const newBatch: SmsBatchRecord = {
        id: data.batchId || `batch_${Date.now()}`,
        senderUid: userProfile?.uid || "current_user",
        senderType: currentRole,
        tenantId: userProfile?.tenantId || "global",
        message_template: broadcastMessage,
        total_recipients: selectedContactsList.length,
        total_parts: totalCalculatedCostCredits,
        cost_per_sms: ratePerSmsZmw,
        total_cost: Number(totalCalculatedCostZmw),
        send_mode: sendMode,
        scheduled_time: sendMode === "scheduled" ? scheduledDateTime : null,
        status: sendMode === "scheduled" ? "scheduled" : "sent",
        processed_gateway: data.gatewayUsed || "Beem SMS Gateway",
        timestamp: new Date().toISOString()
      };

      setBatches((prev) => [newBatch, ...prev]);
    } catch (err: any) {
      alert(`Broadcast failed: ${err.message}`);
    } finally {
      setIsSendingBroadcast(false);
    }
  };

  // Dispatch Single SMS
  const handleSendSingleSms = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!singleRecipientPhone.trim() || !singleMessage.trim()) {
      alert("Please provide both phone number and message.");
      return;
    }

    const singleParts = Math.ceil(singleMessage.length / 160) || 1;
    if ((smsCredits || 0) < singleParts) {
      alert(`Insufficient SMS credits (${smsCredits} available, ${singleParts} required). Please top up via Lipila.`);
      setActiveTab("topup");
      return;
    }

    setIsSendingSingle(true);
    setSingleSuccessResult(null);

    try {
      const res = await fetch("/api/sms/send-single", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          uid: userProfile?.uid,
          tenantId: userProfile?.tenantId || (userProfile?.role === "Farm Owner" ? `farmer_${userProfile?.uid}` : activeFarm?.id || "global"),
          email: userProfile?.email || "",
          phone: singleRecipientPhone,
          recipientName: singleRecipientName || "Direct Contact",
          category: singleCategory,
          message: singleMessage
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to send single SMS");
      }

      setSingleSuccessResult(data);
      if (setSmsCredits) {
        setSmsCredits((prev: number) => Math.max(0, prev - singleParts));
      }
      setSingleMessage("");
      setSingleRecipientPhone("");
      setSingleRecipientName("");
    } catch (err: any) {
      alert(`Single SMS failed: ${err.message}`);
    } finally {
      setIsSendingSingle(false);
    }
  };

  // Lipila SMS Credit Top-Up Checkout
  const handleInitiateLipilaPurchase = async (pkg: SmsPackage) => {
    if (setLipilaCheckout) {
      setLipilaCheckout({
        id: `sms_topup_${pkg.id}_${Date.now()}`,
        name: `${pkg.name} (${pkg.credits} SMS Credits)`,
        packageName: `${pkg.name} (${pkg.credits} SMS Credits)`,
        packageType: "sms_topup",
        type: "sms_topup",
        price: pkg.priceZmw,
        amount: pkg.priceZmw,
        creditsToAward: pkg.credits,
        smsCreditsToAward: pkg.credits,
        institutionId: userProfile?.tenantId || activeFarm?.id,
        uid: userProfile?.uid
      });
      return;
    }

    // Direct Lipila API execution modal
    setSelectedTopUpPackage(pkg);
  };

  const handleDirectLipilaSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTopUpPackage) return;
    if (!momoPhoneNumber.trim()) {
      alert("Please enter mobile money phone number");
      return;
    }

    setIsProcessingPayment(true);
    setPaymentSuccessNotice(null);

    try {
      const referenceId = `SMS_LIP_${Date.now()}`;
      const res = await fetch("/api/payments/collect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          referenceId,
          amount: selectedTopUpPackage.priceZmw,
          narration: `SMS Topup ${selectedTopUpPackage.credits} Credits`,
          accountNumber: momoPhoneNumber,
          uid: userProfile?.uid,
          packageName: selectedTopUpPackage.name,
          packageType: "sms_topup",
          creditsToAward: selectedTopUpPackage.credits,
          institutionId: userProfile?.tenantId || activeFarm?.id
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Lipila payment initiation failed");
      }

      // Simulate verification/confirm
      const confirmRes = await fetch("/api/lipila/confirm-payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reference: referenceId,
          transactionId: referenceId,
          status: "Success",
          packageType: "sms_topup",
          packageName: selectedTopUpPackage.name,
          creditsToAward: selectedTopUpPackage.credits,
          amount: selectedTopUpPackage.priceZmw,
          uid: userProfile?.uid,
          institutionId: userProfile?.tenantId || activeFarm?.id
        })
      });

      if (setSmsCredits) {
        setSmsCredits((prev: number) => prev + selectedTopUpPackage.credits);
      }

      setPaymentSuccessNotice(
        `Payment confirmed! Added ${selectedTopUpPackage.credits} SMS Credits to your wallet via Lipila.`
      );
      setSelectedTopUpPackage(null);
    } catch (err: any) {
      alert(`Payment error: ${err.message}`);
    } finally {
      setIsProcessingPayment(false);
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6 font-sans antialiased text-slate-900 pb-16">
      {/* 1. TOP HEADER & TELEMETRY STRIP */}
      <div className="bg-white text-slate-900 rounded-3xl p-6 sm:p-8 shadow-xs relative overflow-hidden border border-slate-200/80">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2.5">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-800 text-xs font-black uppercase tracking-wider rounded-full border border-emerald-200/80">
                <Radio className="w-3.5 h-3.5 text-emerald-600" />
                {activeGatewayName}
              </span>
              <span className="text-xs text-slate-500 font-mono">Gateway Priority #1</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900">
              SMS Communications Hub
            </h1>
            <p className="text-sm text-slate-500 leading-relaxed font-medium">
              Broadcast single and bulk SMS across farm nodes, suppliers, workers, and clients. Powered by the{" "}
              <strong className="text-slate-800 font-bold">{activeGatewayName}</strong> with automated Lipila wallet credit top-ups.
            </p>
          </div>

          {/* Quick Metrics & Lipila Topup */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-3">
            <div className="bg-slate-50/90 border border-slate-200/80 rounded-2xl p-4 min-w-[140px] shadow-2xs">
              <span className="text-[10px] font-extrabold uppercase text-slate-500 tracking-wider block">
                SMS Wallet Balance
              </span>
              <div className="text-2xl font-black text-emerald-700 mt-0.5 flex items-baseline gap-1 font-mono">
                {smsCredits !== undefined ? smsCredits : 0}
                <span className="text-xs font-bold text-slate-500 font-sans">Credits</span>
              </div>
            </div>

            <div className="bg-slate-50/90 border border-slate-200/80 rounded-2xl p-4 min-w-[140px] shadow-2xs">
              <span className="text-[10px] font-extrabold uppercase text-slate-500 tracking-wider block">
                Registry Rate
              </span>
              <div className="text-2xl font-black text-indigo-700 mt-0.5 flex items-baseline gap-1 font-mono">
                K{ratePerSmsZmw.toFixed(2)}
                <span className="text-xs font-bold text-slate-500 font-sans">/ SMS</span>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <button
                onClick={() => setActiveTab("topup")}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-black text-xs rounded-xl transition shadow-xs flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
              >
                <CreditCard className="w-4 h-4 text-white" />
                Top Up with Lipila
              </button>
              <button
                type="button"
                onClick={() => setShowReconcileModal(true)}
                className="px-5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-750 border border-slate-200 font-bold text-[11px] rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap shadow-2xs"
              >
                <RefreshCw className="w-3.5 h-3.5 text-indigo-600" />
                Reconcile Past Payment
              </button>
            </div>
          </div>
        </div>

        {/* Global Notice / Feedback */}
        {paymentSuccessNotice && (
          <div className="mt-4 p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900 font-bold flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{paymentSuccessNotice}</span>
            </div>
            <button onClick={() => setPaymentSuccessNotice(null)} className="text-slate-400 hover:text-slate-700">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* 2. NAVIGATION TABS */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab("broadcast")}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
            activeTab === "broadcast"
              ? "bg-slate-900 text-white shadow-sm"
              : "bg-white text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-slate-200"
          }`}
        >
          <Users className="w-4 h-4" />
          Bulk SMS Broadcast
        </button>

        <button
          onClick={() => setActiveTab("single")}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
            activeTab === "single"
              ? "bg-slate-900 text-white shadow-sm"
              : "bg-white text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-slate-200"
          }`}
        >
          <Send className="w-4 h-4" />
          Single SMS Direct
        </button>

        <button
          onClick={() => setActiveTab("delivery_logs")}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
            activeTab === "delivery_logs"
              ? "bg-slate-900 text-white shadow-sm"
              : "bg-white text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-slate-200"
          }`}
        >
          <Smartphone className="w-4 h-4 text-emerald-500" />
          SMS Delivery Status & Logs
          <span className="px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
            Live
          </span>
        </button>

        <button
          onClick={() => {
            setActiveTab("batches");
            loadBatches();
          }}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
            activeTab === "batches"
              ? "bg-slate-900 text-white shadow-sm"
              : "bg-white text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-slate-200"
          }`}
        >
          <History className="w-4 h-4" />
          Campaign Batches ({batches.length})
        </button>

        <button
          onClick={() => setActiveTab("topup")}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
            activeTab === "topup"
              ? "bg-slate-900 text-white shadow-sm"
              : "bg-white text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-slate-200"
          }`}
        >
          <CreditCard className="w-4 h-4 text-emerald-500" />
          Buy Credits (Lipila)
        </button>
      </div>

      {/* 3. TAB 1: BULK SMS BROADCAST */}
      {activeTab === "broadcast" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* LEFT 6 COLS: AUDIENCE SELECTOR & CSV IMPORTER */}
          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
              {/* Audience Tab Switcher */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h2 className="text-base font-black text-slate-900">1. Target Audience</h2>
                  <p className="text-xs text-slate-500">
                    Choose contacts from farm directory, upload CSV, or add numbers.
                  </p>
                </div>
                <div className="text-xs font-black text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-100">
                  {selectedContactIds.size} Selected
                </div>
              </div>

              <div className="grid grid-cols-3 gap-1 bg-slate-100 p-1 rounded-2xl">
                <button
                  type="button"
                  onClick={() => setAudienceSourceTab("directory")}
                  className={`py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                    audienceSourceTab === "directory"
                      ? "bg-white text-slate-900 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  Directory ({contacts.length})
                </button>
                <button
                  type="button"
                  onClick={() => setAudienceSourceTab("csv")}
                  className={`py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                    audienceSourceTab === "csv"
                      ? "bg-white text-slate-900 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-600" />
                  CSV Bulk Upload
                </button>
                <button
                  type="button"
                  onClick={() => setAudienceSourceTab("manual")}
                  className={`py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                    audienceSourceTab === "manual"
                      ? "bg-white text-slate-900 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <Plus className="w-3.5 h-3.5 text-emerald-600" />
                  Quick Add
                </button>
              </div>

              {/* AUDIENCE SUB-TAB: DIRECTORY */}
              {audienceSourceTab === "directory" && (
                <div className="space-y-3">
                  {/* Category Filter Chips */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    {["all", "Customer", "Employee", "Supplier", "Agronomist", "Custom"].map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setRecipientCategoryFilter(cat)}
                        className={`px-3 py-1 rounded-lg text-[11px] font-black uppercase tracking-wider transition cursor-pointer shrink-0 ${
                          recipientCategoryFilter === cat
                            ? "bg-slate-900 text-white"
                            : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                        }`}
                      >
                        {cat === "all" ? "All Groups" : cat}
                      </button>
                    ))}
                  </div>

                  {/* Search Bar + Select All Bar */}
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="Search name, phone or role..."
                        value={contactSearchQuery}
                        onChange={(e) => setContactSearchQuery(e.target.value)}
                        className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-emerald-500"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleSelectAllFiltered}
                      className="px-2.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-black rounded-xl cursor-pointer"
                    >
                      Select All
                    </button>
                    <button
                      type="button"
                      onClick={handleDeselectAllFiltered}
                      className="px-2.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-500 text-[11px] font-bold rounded-xl cursor-pointer"
                    >
                      Clear
                    </button>
                  </div>

                  {/* Contact Checkbox List */}
                  <div className="max-h-[360px] overflow-y-auto space-y-1.5 pr-1 divide-y divide-slate-100">
                    {filteredContacts.length === 0 ? (
                      <div className="text-center py-8 text-slate-400 text-xs font-medium">
                        No contacts found in this group. Use "CSV Bulk Upload" or "Quick Add" to add recipients.
                      </div>
                    ) : (
                      filteredContacts.map((contact) => {
                        const isSelected = selectedContactIds.has(contact.id);
                        return (
                          <div
                            key={contact.id}
                            onClick={() => handleToggleContact(contact.id)}
                            className={`p-2.5 rounded-2xl flex items-center justify-between transition cursor-pointer select-none ${
                              isSelected
                                ? "bg-emerald-50/80 border border-emerald-200/80 text-emerald-950"
                                : "hover:bg-slate-50 border border-transparent text-slate-700"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              {isSelected ? (
                                <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                              ) : (
                                <Square className="w-4 h-4 text-slate-300 shrink-0" />
                              )}
                              <div>
                                <div className="text-xs font-black text-slate-900 flex items-center gap-2">
                                  {contact.name}
                                  <span
                                    className={`text-[9px] px-1.5 py-0.5 rounded font-extrabold uppercase ${
                                      contact.category === "Customer"
                                        ? "bg-blue-100 text-blue-700"
                                        : contact.category === "Employee"
                                        ? "bg-amber-100 text-amber-700"
                                        : contact.category === "Supplier"
                                        ? "bg-purple-100 text-purple-700"
                                        : "bg-slate-100 text-slate-700"
                                    }`}
                                  >
                                    {contact.category}
                                  </span>
                                </div>
                                <div className="text-[11px] font-mono text-slate-500">
                                  {contact.phone}{" "}
                                  {contact.role && <span className="text-slate-400">• {contact.role}</span>}
                                  {contact.notes && <span className="text-slate-400"> ({contact.notes})</span>}
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              )}

              {/* AUDIENCE SUB-TAB: CSV BULK UPLOAD */}
              {audienceSourceTab === "csv" && (
                <div className="space-y-4">
                  {/* Download Sample Button */}
                  <div className="flex items-center justify-between p-3 bg-indigo-50/80 border border-indigo-100 rounded-2xl">
                    <div className="flex items-center gap-2 text-xs text-indigo-900 font-semibold">
                      <FileSpreadsheet className="w-4 h-4 text-indigo-600 shrink-0" />
                      <span>Need standard template headers?</span>
                    </div>
                    <button
                      type="button"
                      onClick={handleDownloadSampleCsv}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Download Sample CSV
                    </button>
                  </div>

                  {/* File Picker Drag & Drop Box */}
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-slate-300 hover:border-emerald-500 bg-slate-50 hover:bg-emerald-50/20 rounded-3xl p-6 text-center cursor-pointer transition"
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".csv"
                      onChange={handleCsvFileUpload}
                      className="hidden"
                    />
                    <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-xs font-bold text-slate-800">
                      {csvFile ? csvFile.name : "Click to select or drop CSV contact list"}
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Expected columns: <code className="bg-slate-200/80 px-1 py-0.5 rounded font-mono">Full Name, Phone Number, Category, Notes</code>
                    </p>
                  </div>

                  {/* Parsing Warnings / Errors */}
                  {csvParseErrors.length > 0 && (
                    <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-800 space-y-1">
                      <div className="font-bold flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                        Warnings during parsing:
                      </div>
                      {csvParseErrors.map((err, i) => (
                        <div key={i} className="text-[11px] font-mono">{safeFormatError(err)}</div>
                      ))}
                    </div>
                  )}

                  {/* Parsed Contacts Preview */}
                  {csvParsedContacts.length > 0 && (
                    <div className="space-y-3 bg-slate-50 border border-slate-200 rounded-2xl p-4">
                      <div className="flex items-center justify-between">
                        <div className="text-xs font-black text-slate-900">
                          {csvParsedContacts.length} valid contacts extracted
                        </div>
                        <button
                          type="button"
                          onClick={handleAddCsvToAudience}
                          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl transition cursor-pointer flex items-center gap-1.5"
                        >
                          <UserCheck className="w-3.5 h-3.5" />
                          Add & Select All for Broadcast
                        </button>
                      </div>

                      <div className="max-h-48 overflow-y-auto divide-y divide-slate-200/60 text-xs">
                        {csvParsedContacts.map((c, idx) => (
                          <div key={idx} className="py-1.5 flex items-center justify-between">
                            <div>
                              <span className="font-bold text-slate-800">{c.name}</span>{" "}
                              <span className="text-[10px] text-slate-500 font-mono">({c.phone})</span>
                            </div>
                            <span className="text-[10px] font-black uppercase text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                              {c.category}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* AUDIENCE SUB-TAB: MANUAL QUICK ADD */}
              {audienceSourceTab === "manual" && (
                <form onSubmit={handleAddManualContact} className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-extrabold uppercase text-slate-500">Contact Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Bwalya Phiri"
                        value={manualNameInput}
                        onChange={(e) => setManualNameInput(e.target.value)}
                        className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-extrabold uppercase text-slate-500">Zambian Phone Number</label>
                      <input
                        type="text"
                        placeholder="e.g. 0977123456 or +260..."
                        value={manualPhoneInput}
                        onChange={(e) => setManualPhoneInput(e.target.value)}
                        className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-emerald-500"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-extrabold uppercase text-slate-500">Group / Category</label>
                    <select
                      value={manualCategoryInput}
                      onChange={(e) => setManualCategoryInput(e.target.value)}
                      className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-emerald-500"
                    >
                      <option value="Customer">Customer</option>
                      <option value="Employee">Employee</option>
                      <option value="Supplier">Supplier</option>
                      <option value="Agro Dealer">Agro Dealer</option>
                      <option value="Agronomist">Agronomist</option>
                      <option value="Custom">Custom</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-emerald-400" />
                    Add Recipient to Active Selection
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* RIGHT 6 COLS: COMPOSER, LIVE SIMULATOR & CAMPAIGN SUMMARY */}
          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-5">
              <div className="border-b border-slate-100 pb-3">
                <h2 className="text-base font-black text-slate-900">2. Message Composer</h2>
                <p className="text-xs text-slate-500">
                  Compose dynamic broadcast template with personalized variable tags.
                </p>
              </div>

              {/* Dynamic Variable Insertion Pills */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider block">
                  Click to Insert Personalization Tag
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { tag: "{firstName}", label: "First Name" },
                    { tag: "{name}", label: "Full Name" },
                    { tag: "{farmName}", label: "Farm Node Name" },
                    { tag: "{farmPhone}", label: "Farm Phone" },
                    { tag: "{date}", label: "Today's Date" },
                    { tag: "{notes}", label: "Notes/Produce" }
                  ].map((item) => (
                    <button
                      key={item.tag}
                      type="button"
                      onClick={() => insertVariableTag(item.tag)}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 font-mono text-[11px] font-bold rounded-lg border border-slate-200 transition cursor-pointer"
                    >
                      {item.tag}
                    </button>
                  ))}
                </div>
              </div>

              {/* Message Textarea */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-extrabold text-slate-700">SMS Body</span>
                  <span
                    className={`font-mono font-bold ${
                      smsLength > 160 ? "text-amber-600" : "text-slate-500"
                    }`}
                  >
                    {smsLength} Chars • {smsParts} Part{smsParts > 1 ? "s" : ""} (GSM 7-bit)
                  </span>
                </div>
                <textarea
                  rows={4}
                  value={broadcastMessage}
                  onChange={(e) => setBroadcastMessage(e.target.value)}
                  placeholder="Type broadcast SMS message..."
                  className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium focus:bg-white focus:outline-emerald-500 leading-relaxed"
                />
              </div>

              {/* Live Mobile Simulator Preview */}
              <div className="bg-slate-900 rounded-2xl p-4 text-white space-y-2 border border-slate-800">
                <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800 pb-2">
                  <span className="flex items-center gap-1 font-bold text-emerald-400">
                    <Smartphone className="w-3.5 h-3.5" />
                    Recipient Mobile Preview
                  </span>
                  <span className="font-mono text-[10px] text-slate-500">
                    Via {activeGatewayName}
                  </span>
                </div>
                <div className="bg-slate-800/90 rounded-xl p-3 text-xs text-slate-200 font-sans leading-relaxed border border-slate-700/50">
                  {previewPersonalizedMessage}
                </div>
              </div>

              {/* Delivery Timing Options */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setSendMode("immediate")}
                  className={`p-3 rounded-2xl border text-left transition cursor-pointer ${
                    sendMode === "immediate"
                      ? "bg-emerald-50/80 border-emerald-500 text-emerald-950 shadow-sm"
                      : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-white"
                  }`}
                >
                  <div className="text-xs font-black flex items-center gap-1.5">
                    <Send className="w-3.5 h-3.5 text-emerald-600" />
                    Send Immediately
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Instant dispatch via Beem gateway
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setSendMode("scheduled")}
                  className={`p-3 rounded-2xl border text-left transition cursor-pointer ${
                    sendMode === "scheduled"
                      ? "bg-indigo-50/80 border-indigo-500 text-indigo-950 shadow-sm"
                      : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-white"
                  }`}
                >
                  <div className="text-xs font-black flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-indigo-600" />
                    Schedule for Later
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Auto-trigger at scheduled time
                  </div>
                </button>
              </div>

              {sendMode === "scheduled" && (
                <div className="space-y-1">
                  <label className="text-[10px] font-extrabold uppercase text-slate-500">
                    Scheduled Date & Time (Zambia Time)
                  </label>
                  <input
                    type="datetime-local"
                    value={scheduledDateTime}
                    onChange={(e) => setScheduledDateTime(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>
              )}

              {/* Campaign Cost Summary Bar */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                <div className="grid grid-cols-3 gap-2 text-center divide-x divide-slate-200">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Recipients</span>
                    <span className="text-sm font-black text-slate-900">{selectedContactsList.length}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Total Parts</span>
                    <span className="text-sm font-black text-slate-900">{totalCalculatedCostCredits}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Total Value</span>
                    <span className="text-sm font-black text-indigo-600">K{totalCalculatedCostZmw}</span>
                  </div>
                </div>

                {!hasSufficientCredits ? (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between text-xs">
                    <div className="text-amber-800 font-bold flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>Need {totalCalculatedCostCredits - (smsCredits || 0)} more credits.</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveTab("topup")}
                      className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white font-black rounded-lg cursor-pointer"
                    >
                      Top Up via Lipila
                    </button>
                  </div>
                ) : (
                  <div className="text-[11px] text-emerald-700 font-bold flex items-center gap-1.5 justify-center">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    Sufficient credits available ({smsCredits} in wallet).
                  </div>
                )}
              </div>

              {/* Action Button */}
              <button
                type="button"
                disabled={isSendingBroadcast || selectedContactsList.length === 0 || !broadcastMessage.trim()}
                onClick={() => setShowConfirmModal(true)}
                className={`w-full py-4 rounded-2xl font-black text-sm transition flex items-center justify-center gap-2 shadow-lg cursor-pointer ${
                  selectedContactsList.length === 0 || !broadcastMessage.trim()
                    ? "bg-slate-200 text-slate-400 cursor-not-allowed shadow-none"
                    : hasSufficientCredits
                    ? "bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white shadow-emerald-600/20"
                    : "bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] text-white shadow-indigo-600/20"
                }`}
              >
                {isSendingBroadcast ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Dispatching Campaign via {activeGatewayName}...
                  </>
                ) : hasSufficientCredits ? (
                  <>
                    <Send className="w-4 h-4" />
                    Dispatch Broadcast to {selectedContactsList.length} Recipients
                  </>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4" />
                    Top Up Credits to Send Campaign
                  </>
                )}
              </button>

              {/* Broadcast Success Feedback Banner */}
              {broadcastSuccessResult && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900 space-y-1.5">
                  <div className="font-black flex items-center gap-1.5 text-emerald-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Broadcast Dispatched Successfully!
                  </div>
                  <div className="text-[11px] text-emerald-800">
                    Batch Reference: <code className="font-mono font-bold">{broadcastSuccessResult.batchId}</code> • Gateway:{" "}
                    <strong>{broadcastSuccessResult.gatewayUsed || activeGatewayName}</strong> • Remaining Wallet:{" "}
                    <strong>{smsCredits} Credits</strong>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 4. TAB 2: SINGLE SMS DIRECT */}
      {activeTab === "single" && (
        <div className="max-w-2xl mx-auto bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-black text-slate-900">Direct Single SMS Gateway</h2>
            <p className="text-xs text-slate-500">
              Send an instant message to any farmer, customer, employee, or supplier via {activeGatewayName}.
            </p>
          </div>

          <form onSubmit={handleSendSingleSms} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500">Recipient Name</label>
                <input
                  type="text"
                  placeholder="e.g. Mwila Chilufya"
                  value={singleRecipientName}
                  onChange={(e) => setSingleRecipientName(e.target.value)}
                  className="w-full mt-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-emerald-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500">Recipient Phone Number</label>
                <input
                  type="text"
                  placeholder="e.g. +260977123456"
                  value={singleRecipientPhone}
                  onChange={(e) => setSingleRecipientPhone(e.target.value)}
                  className="w-full mt-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-emerald-500"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-extrabold uppercase text-slate-500">Recipient Group</label>
              <select
                value={singleCategory}
                onChange={(e) => setSingleCategory(e.target.value)}
                className="w-full mt-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-emerald-500"
              >
                <option value="Customer">Customer</option>
                <option value="Employee">Employee / Farm Worker</option>
                <option value="Supplier">Supplier</option>
                <option value="Agro Dealer">Agro Dealer</option>
                <option value="Agronomist">Agronomist</option>
                <option value="Other">Other Contact</option>
              </select>
            </div>

            {/* Quick Templates */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider block">
                Quick Message Presets
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  {
                    title: "Order Ready",
                    text: `Hello, your produce order from ${currentFarmName} is packed and ready for collection. Thank you!`
                  },
                  {
                    title: "Harvest Delivery",
                    text: `Greetings from ${currentFarmName}. Harvest delivery is en route to your depot today.`
                  },
                  {
                    title: "Field Advisory",
                    text: `Urgent Agronomy Alert from ${currentFarmName}: Please check your irrigation lines and scout for fall armyworm today.`
                  },
                  {
                    title: "Payment Received",
                    text: `Payment received with thanks. Receipt confirmed by ${currentFarmName}.`
                  }
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSingleMessage(preset.text)}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold rounded-lg transition cursor-pointer"
                  >
                    {preset.title}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <label className="text-[10px] font-extrabold uppercase text-slate-500">SMS Message</label>
                <span className="text-slate-500 font-mono text-[11px]">
                  {singleMessage.length} Chars • {Math.ceil(singleMessage.length / 160) || 1} Part (Cost: 1 Credit)
                </span>
              </div>
              <textarea
                rows={4}
                value={singleMessage}
                onChange={(e) => setSingleMessage(e.target.value)}
                placeholder="Type your message here..."
                className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium focus:bg-white focus:outline-emerald-500"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isSendingSingle || !singleRecipientPhone.trim() || !singleMessage.trim()}
              className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs sm:text-sm rounded-2xl transition flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              {isSendingSingle ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Routing via {activeGatewayName}...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 text-emerald-400" />
                  Send SMS Now via {activeGatewayName}
                </>
              )}
            </button>
          </form>

          {singleSuccessResult && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900 space-y-1">
              <div className="font-bold flex items-center gap-1 text-emerald-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Message Delivered Successfully!
              </div>
              <div>
                Dispatched to <strong className="font-mono">{singleSuccessResult.recipient}</strong> via{" "}
                <strong>{singleSuccessResult.gatewayUsed}</strong>. Remaining Balance:{" "}
                <strong>{singleSuccessResult.remainingCredits} Credits</strong>.
              </div>
            </div>
          )}
        </div>
      )}

      {/* 5. TAB 3: BUY CREDITS (LIPILA) */}
      {activeTab === "topup" && (
        <div className="space-y-6">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-emerald-100 text-emerald-800 text-xs font-black uppercase tracking-wider rounded-full">
              <CreditCard className="w-3.5 h-3.5" />
              Automated Lipila Mobile Money Flow
            </div>
            <h2 className="text-2xl font-black text-slate-900">Purchase SMS Credits</h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Credits are tied directly to your farm node space. Instantly charged at the official System Gateway Registry rate (K{ratePerSmsZmw.toFixed(2)}/SMS).
            </p>
          </div>

          {/* Unconfirmed Payment Recovery Card */}
          <div className="bg-gradient-to-r from-slate-900 to-indigo-950 border border-indigo-500/30 rounded-3xl p-5 sm:p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-1.5 max-w-xl">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 bg-indigo-500/20 text-indigo-300 text-[10px] font-black uppercase tracking-wider rounded-md border border-indigo-500/30">
                  Payment Recovery Engine
                </span>
                <span className="text-xs text-slate-400 font-mono">Live Lipila Sync</span>
              </div>
              <h3 className="text-base font-bold text-white">Paid but SMS credits not reflected yet?</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                If your mobile money funds were deducted or payment confirmation timed out, enter your receipt or reference ID to immediately query Lipila and credit your SMS wallet.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowReconcileModal(true)}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-black text-xs rounded-xl shadow-lg transition flex items-center gap-2 shrink-0 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              Reconcile Payment Now
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {smsPackages.map((pkg) => {
              const isPopular = pkg.popular;
              return (
                <div
                  key={pkg.id}
                  className={`bg-white border rounded-3xl p-5 shadow-sm relative flex flex-col justify-between transition hover:shadow-md ${
                    isPopular ? "border-emerald-500 ring-2 ring-emerald-500/20" : "border-slate-200"
                  }`}
                >
                  {isPopular && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-emerald-500 text-slate-950 text-[9px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full shadow">
                      Most Popular
                    </span>
                  )}
                  <div className="space-y-3">
                    <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider block">
                      {pkg.name}
                    </span>
                    <div className="text-3xl font-black text-slate-900">
                      {pkg.credits}
                      <span className="text-xs font-bold text-slate-400 block mt-0.5">SMS Credits</span>
                    </div>
                    <div className="text-xl font-black text-emerald-600">
                      K{pkg.priceZmw}
                      <span className="text-[11px] text-slate-400 font-normal ml-1">ZMW</span>
                    </div>
                    <div className="text-[11px] text-slate-500 leading-snug">
                      ≈ K{(pkg.priceZmw / pkg.credits).toFixed(2)} per SMS part via {activeGatewayName}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleInitiateLipilaPurchase(pkg)}
                    className="w-full mt-5 py-2.5 bg-slate-900 hover:bg-emerald-600 hover:text-slate-950 text-white font-black text-xs rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    Buy with Lipila
                  </button>
                </div>
              );
            })}
          </div>

          {/* Direct Lipila Checkout Modal (if standalone) */}
          {selectedTopUpPackage && (
            <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
              <div className="bg-white border border-slate-200 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-5 animate-fade-in">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <span className="text-[10px] font-black uppercase text-emerald-600 tracking-widest block font-mono">
                      Lipila Mobile Money Gateway
                    </span>
                    <h3 className="text-base font-black text-slate-900">{selectedTopUpPackage.name}</h3>
                  </div>
                  <button
                    onClick={() => setSelectedTopUpPackage(null)}
                    className="text-slate-400 hover:text-slate-700"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-500 font-bold block">Amount to Pay</span>
                    <span className="text-2xl font-black text-slate-900">K{selectedTopUpPackage.priceZmw} ZMW</span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-slate-500 font-bold block">Credits Awarded</span>
                    <span className="text-2xl font-black text-emerald-600">+{selectedTopUpPackage.credits}</span>
                  </div>
                </div>

                <form onSubmit={handleDirectLipilaSubmit} className="space-y-4">
                  <div>
                    <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1">
                      Select Network Operator
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(["MTN", "AIRTEL", "ZAMTEL"] as const).map((op) => (
                        <button
                          key={op}
                          type="button"
                          onClick={() => setMomoOperator(op)}
                          className={`py-2 text-xs font-black rounded-xl border transition cursor-pointer ${
                            momoOperator === op
                              ? "bg-slate-900 text-white border-slate-900"
                              : "bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100"
                          }`}
                        >
                          {op} Money
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-extrabold uppercase text-slate-500">
                      Mobile Money Phone Number
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 0977123456"
                      value={momoPhoneNumber}
                      onChange={(e) => setMomoPhoneNumber(e.target.value)}
                      className="w-full mt-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:bg-white focus:outline-emerald-500"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isProcessingPayment}
                    className="w-full py-3.5 bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-slate-950 font-black text-sm rounded-2xl transition shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isProcessingPayment ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        Prompting Mobile PIN...
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-4 h-4" />
                        Authorize K{selectedTopUpPackage.priceZmw} with Lipila
                      </>
                    )}
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB: SMS DELIVERY STATUS & LOGS WITH PAGINATION */}
      {activeTab === "delivery_logs" && (
        <SmsDeliveryStatusLogs
          userProfile={userProfile}
          currentRole={currentRole}
          activeGatewayName={activeGatewayName}
          smsCredits={smsCredits}
          onNavigateToSingle={() => setActiveTab("single")}
          onNavigateToBroadcast={() => setActiveTab("broadcast")}
          onNavigateToTopUp={() => setActiveTab("topup")}
        />
      )}

      {/* 6. TAB 4: BROADCAST HISTORY & DELIVERY REPORTS */}
      {activeTab === "batches" && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-lg font-black text-slate-900">Broadcast Campaigns & Reports</h2>
              <p className="text-xs text-slate-500">
                Detailed delivery audits dispatched via {activeGatewayName}.
              </p>
            </div>
            <button
              onClick={loadBatches}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Refresh
            </button>
          </div>

          {batches.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs font-medium">
              No previous SMS broadcasts found. Dispatched campaigns will appear here automatically.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                    <th className="py-3 px-3">Batch ID & Date</th>
                    <th className="py-3 px-3">Message Snippet</th>
                    <th className="py-3 px-3">Recipients</th>
                    <th className="py-3 px-3">Parts / Cost</th>
                    <th className="py-3 px-3">Gateway</th>
                    <th className="py-3 px-3">Status</th>
                    <th className="py-3 px-3 text-right">Delivery Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {batches.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-50 transition">
                      <td className="py-3 px-3">
                        <span className="font-mono font-bold text-slate-900 block">{b.id}</span>
                        <span className="text-[10px] text-slate-400">
                          {b.timestamp ? new Date(b.timestamp).toLocaleString() : "N/A"}
                        </span>
                      </td>
                      <td className="py-3 px-3 max-w-xs truncate text-slate-600 font-medium">
                        {b.message_template}
                      </td>
                      <td className="py-3 px-3 font-bold text-slate-800">
                        {b.total_recipients} Contacts
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-bold text-slate-900 block">{b.total_parts} Credits</span>
                        <span className="text-[10px] text-indigo-600 font-bold">K{Number(b.total_cost || 0).toFixed(2)}</span>
                      </td>
                      <td className="py-3 px-3 text-[11px] font-semibold text-slate-600">
                        {b.processed_gateway || activeGatewayName}
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`inline-flex items-center gap-1 text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                            b.status === "delivered" || b.status === "sent"
                              ? "bg-emerald-100 text-emerald-800"
                              : b.status === "scheduled"
                              ? "bg-indigo-100 text-indigo-800"
                              : "bg-amber-100 text-amber-800"
                          }`}
                        >
                          {b.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={() => handleInspectBatch(b)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-700 font-bold text-[11px] rounded-lg transition flex items-center gap-1 ml-auto cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          Audit Delivery
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* BATCH DELIVERY AUDIT MODAL WITH PAGINATION */}
      {inspectingBatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white border border-slate-200 rounded-3xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl animate-fade-in overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-2xl">
                  <Radio className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Campaign Batch Delivery Report</h3>
                  <p className="text-xs text-slate-400 font-mono">
                    Batch: {inspectingBatch.batch.id} • {new Date(inspectingBatch.batch.timestamp || Date.now()).toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={`/api/sms/batches/${inspectingBatch.batch.id}?format=csv`}
                  download
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download CSV
                </a>
                <button
                  onClick={() => setInspectingBatch(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Batch Metrics Cards */}
            <div className="p-5 bg-slate-50 border-b border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-white p-3 rounded-2xl border border-slate-200/80">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Recipients</span>
                <span className="text-base font-black text-slate-900">{inspectingBatch.summary?.total || inspectingBatch.batch.total_recipients || 0}</span>
              </div>
              <div className="bg-white p-3 rounded-2xl border border-emerald-200/80">
                <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider block">Sent / Delivered</span>
                <span className="text-base font-black text-emerald-700">
                  {inspectingBatch.summary?.sent || 0} ({inspectingBatch.summary?.deliveryRate || 100}%)
                </span>
              </div>
              <div className="bg-white p-3 rounded-2xl border border-amber-200/80">
                <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider block">Pending / Queued</span>
                <span className="text-base font-black text-amber-700">{inspectingBatch.summary?.pending || 0}</span>
              </div>
              <div className="bg-white p-3 rounded-2xl border border-rose-200/80">
                <span className="text-[10px] font-bold text-rose-600 uppercase tracking-wider block">Failed / Rejected</span>
                <span className="text-base font-black text-rose-700">{inspectingBatch.summary?.failed || 0}</span>
              </div>
            </div>

            {/* Filter pills & Table */}
            <div className="p-5 flex-1 overflow-y-auto space-y-4">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="font-bold text-slate-500 mr-1">Filter Status:</span>
                  {(["all", "delivered", "sent", "pending", "failed"] as const).map((st) => (
                    <button
                      key={st}
                      onClick={() => {
                        setBatchStatusFilter(st);
                        setBatchPage(1);
                      }}
                      className={`px-2.5 py-1 rounded-lg font-bold text-[11px] capitalize transition cursor-pointer ${
                        batchStatusFilter === st
                          ? "bg-slate-900 text-white"
                          : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>

                <span className="text-xs text-slate-400 font-semibold">
                  Showing {inspectingBatch.messages.length} message records
                </span>
              </div>

              {inspectingBatchLoading ? (
                <div className="py-12 text-center text-xs text-slate-500 font-bold">
                  <RefreshCw className="w-6 h-6 animate-spin mx-auto text-indigo-600 mb-2" />
                  Loading recipient delivery audit...
                </div>
              ) : inspectingBatch.messages.length === 0 ? (
                <div className="text-center py-10 text-xs text-slate-400 font-medium">
                  No recipient message delivery logs recorded for this batch.
                </div>
              ) : (
                <div className="border border-slate-200 rounded-2xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-black uppercase text-slate-400">
                        <th className="py-2.5 px-3">Recipient</th>
                        <th className="py-2.5 px-3">Message Snippet</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3">Error Diagnosis</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {inspectingBatch.messages
                        .filter((m: any) => {
                          if (batchStatusFilter === "all") return true;
                          if (batchStatusFilter === "delivered" || batchStatusFilter === "sent") {
                            return m.status === batchStatusFilter || (batchStatusFilter === "delivered" && m.status === "sent");
                          }
                          return m.status === batchStatusFilter;
                        })
                        .slice((batchPage - 1) * 8, batchPage * 8)
                        .map((m: any, idx: number) => (
                          <tr key={m.id || idx} className="hover:bg-slate-50">
                            <td className="py-2.5 px-3">
                              <span className="font-bold text-slate-900 block">{m.recipient_name || m.recipientName || "Recipient"}</span>
                              <span className="font-mono text-[11px] text-slate-500">{m.recipient_phone || m.recipient}</span>
                            </td>
                            <td className="py-2.5 px-3 max-w-xs truncate text-slate-600 font-medium">
                              {m.personalized_message || m.message}
                            </td>
                            <td className="py-2.5 px-3 whitespace-nowrap">
                              <span
                                className={`inline-flex items-center gap-1 text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                                  m.status === "delivered" || m.status === "sent"
                                    ? "bg-emerald-100 text-emerald-800"
                                    : m.status === "pending" || m.status === "scheduled"
                                    ? "bg-amber-100 text-amber-800"
                                    : "bg-rose-100 text-rose-800"
                                }`}
                              >
                                {m.status}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-[11px] text-rose-600 font-semibold max-w-xs truncate">
                              {m.error_message || "—"}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Batch Pagination footer */}
              {inspectingBatch.messages.length > 8 && (
                <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                  <span className="text-slate-500">
                    Page {batchPage} of {Math.ceil(inspectingBatch.messages.length / 8)}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setBatchPage((p) => Math.max(1, p - 1))}
                      disabled={batchPage <= 1}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 rounded-lg text-xs font-bold transition cursor-pointer"
                    >
                      Prev
                    </button>
                    <button
                      onClick={() => setBatchPage((p) => Math.min(Math.ceil(inspectingBatch.messages.length / 8), p + 1))}
                      disabled={batchPage >= Math.ceil(inspectingBatch.messages.length / 8)}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 rounded-lg text-xs font-bold transition cursor-pointer"
                    >
                      Next
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setInspectingBatch(null)}
                className="px-4 py-2 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-slate-800 cursor-pointer"
              >
                Close Audit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRMATION MODAL BEFORE DISPATCH */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white border border-slate-200 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-emerald-100 text-emerald-700 rounded-2xl">
                <Radio className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900">Confirm Broadcast Dispatch</h3>
                <p className="text-xs text-slate-500">
                  Ready to send via {activeGatewayName}.
                </p>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500 font-bold">Target Audience:</span>
                <span className="font-black text-slate-900">{selectedContactsList.length} Recipients</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-bold">SMS Length / Parts:</span>
                <span className="font-black text-slate-900">{smsLength} Chars ({smsParts} Parts each)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-bold">Total Wallet Deduction:</span>
                <span className="font-black text-emerald-600">{totalCalculatedCostCredits} SMS Credits</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-bold">Registry Value:</span>
                <span className="font-black text-indigo-600">K{totalCalculatedCostZmw} ZMW</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-2">
                <span className="text-slate-500 font-bold">Dispatch Mode:</span>
                <span className="font-black uppercase text-slate-800">{sendMode}</span>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteBroadcast}
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                Confirm & Dispatch
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MANUAL PAYMENT RECONCILIATION MODAL */}
      {showReconcileModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 text-white shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
                  <RefreshCw className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Reconcile Lipila Payment</h3>
                  <p className="text-[11px] text-slate-400">Verify & allocate SMS or platform credits immediately</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowReconcileModal(false);
                  setReconcileResult(null);
                }}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-300 leading-relaxed text-[11.5px]">
                Enter your transaction reference from your Lipila receipt or mobile money SMS (e.g. <span className="font-mono text-indigo-400 font-bold">ref-1787993978099-8310</span> or <span className="font-mono text-emerald-400 font-bold">LPLXC-20260829-085959-034-3697</span>):
              </p>

              <div>
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block mb-1">
                  Payment Reference / Lipila Tx ID
                </label>
                <input
                  type="text"
                  placeholder="e.g. ref-1787993978099-8310"
                  value={manualReconcileRef}
                  onChange={(e) => setManualReconcileRef(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono font-bold text-white outline-none focus:border-indigo-500 placeholder:text-slate-600"
                />
              </div>

              {reconcileResult && (
                <div
                  className={`p-3.5 rounded-xl border text-xs leading-relaxed font-medium ${
                    reconcileResult.success
                      ? "bg-emerald-950/40 border-emerald-500/40 text-emerald-300"
                      : "bg-rose-950/40 border-rose-500/40 text-rose-300"
                  }`}
                >
                  {reconcileResult.success ? "✓ " : "⚠️ "}
                  {reconcileResult.message}
                </div>
              )}
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowReconcileModal(false);
                  setReconcileResult(null);
                }}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold text-xs rounded-xl cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                disabled={isReconciling || !manualReconcileRef.trim()}
                onClick={() => handleManualReconcile()}
                className={`flex-1 py-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-2 cursor-pointer transition ${
                  isReconciling || !manualReconcileRef.trim()
                    ? "bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed"
                    : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg active:scale-95"
                }`}
              >
                {isReconciling ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Querying Lipila...
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    Verify & Credit Wallet
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SmsCommunicationsHub;

import React, { useState, useEffect, useMemo } from "react";
import { 
  Shield, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertCircle, 
  User, 
  FileText, 
  ArrowRight, 
  Check, 
  X, 
  RefreshCw, 
  Filter, 
  Search, 
  MessageSquare,
  Sparkles,
  HelpCircle
} from "lucide-react";
import { MakerCheckerApprovalRequest, ApprovalStatus } from "../../types";
import { ApprovalService } from "../../services/approvalService";

interface MakerCheckerApprovalCentreProps {
  tenantId: string;
  tenantName: string;
  currentUserEmail: string;
  currentUserUid: string;
  currentUserName: string;
  currentUserRole: string;
  isSuperAdmin?: boolean;
  onApprovalCompleted?: () => void;
}

export default function MakerCheckerApprovalCentre({
  tenantId,
  tenantName,
  currentUserEmail,
  currentUserUid,
  currentUserName,
  currentUserRole,
  isSuperAdmin = false,
  onApprovalCompleted
}: MakerCheckerApprovalCentreProps) {
  const [requests, setRequests] = useState<MakerCheckerApprovalRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<ApprovalStatus>("PENDING");
  const [searchQuery, setSearchQuery] = useState("");
  
  // Review Modal State
  const [reviewingRequest, setReviewingRequest] = useState<MakerCheckerApprovalRequest | null>(null);
  const [reviewAction, setReviewAction] = useState<"APPROVE" | "REJECT" | null>(null);
  const [reviewNotes, setReviewNotes] = useState("");
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [reviewError, setReviewError] = useState<string | null>(null);

  const loadRequests = async () => {
    setIsLoading(true);
    try {
      const data = await ApprovalService.getApprovalRequests(tenantId);
      setRequests(data);
    } catch (err) {
      console.error("Error loading approval requests:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadRequests();
  }, [tenantId]);

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewingRequest || !reviewAction) return;

    setReviewError(null);
    setIsSubmittingReview(true);

    try {
      const checker = {
        uid: currentUserUid || "checker-uid",
        email: currentUserEmail,
        name: currentUserName || "Administrator",
        role: currentUserRole || "Administrator",
        isSuperAdmin
      };

      if (reviewAction === "APPROVE") {
        await ApprovalService.approveRequest(reviewingRequest.id, checker, reviewNotes);
      } else {
        if (!reviewNotes.trim() || reviewNotes.trim().length < 5) {
          throw new Error("A rejection comment explaining the reason (min 5 characters) is required.");
        }
        await ApprovalService.rejectRequest(reviewingRequest.id, checker, reviewNotes);
      }

      setReviewingRequest(null);
      setReviewAction(null);
      setReviewNotes("");
      await loadRequests();
      if (onApprovalCompleted) onApprovalCompleted();
    } catch (err: any) {
      setReviewError(err.message || "Failed to process review.");
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const filteredRequests = useMemo(() => {
    return requests.filter(r => {
      const matchesTab = r.status === activeTab;
      const matchesSearch = 
        r.reason.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.makerEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.makerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.entityType.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.actionType.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.id.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesTab && matchesSearch;
    });
  }, [requests, activeTab, searchQuery]);

  const pendingCount = requests.filter(r => r.status === "PENDING").length;

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3.5">
          <div className="w-11 h-11 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-700">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-bold text-slate-900">Maker-Checker Approval Centre</h2>
              {pendingCount > 0 && (
                <span className="px-2.5 py-0.5 text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 rounded-full animate-pulse">
                  {pendingCount} Pending Review
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Dual-control authorization workflow enforcing mandatory justification and secondary checker verification.
            </p>
          </div>
        </div>

        <button
          onClick={loadRequests}
          className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl border border-slate-200 self-start md:self-auto transition-colors"
          title="Refresh queue"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Navigation Tabs & Search */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center space-x-2 w-full md:w-auto">
          {(["PENDING", "APPROVED", "REJECTED"] as ApprovalStatus[]).map((tab) => {
            const count = requests.filter(r => r.status === tab).length;
            const isActive = activeTab === tab;
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                  isActive 
                    ? tab === "PENDING" ? "bg-amber-600 text-white shadow-sm" :
                      tab === "APPROVED" ? "bg-emerald-700 text-white shadow-sm" :
                      "bg-rose-700 text-white shadow-sm"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <span>{tab}</span>
                <span className={`px-1.5 py-0.2 text-[10px] rounded-full ${isActive ? "bg-white/20 text-white" : "bg-slate-200 text-slate-700"}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by reason, maker, entity..."
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Requests List */}
      <div className="space-y-3">
        {isLoading ? (
          <div className="bg-white rounded-2xl p-12 text-center text-slate-400 border border-slate-200">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto text-indigo-600 mb-2" />
            <span className="text-xs">Loading authorization requests...</span>
          </div>
        ) : filteredRequests.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center text-slate-400 border border-slate-200">
            <CheckCircle2 className="w-8 h-8 mx-auto text-slate-300 mb-2" />
            <p className="font-semibold text-slate-600 text-sm">No {activeTab.toLowerCase()} requests</p>
            <p className="text-xs text-slate-400 mt-0.5">Dual-control records will appear here as team members propose actions.</p>
          </div>
        ) : (
          filteredRequests.map((req) => {
            const isMaker = req.makerEmail.toLowerCase().trim() === currentUserEmail.toLowerCase().trim();
            const canApprove = (!isMaker || isSuperAdmin) && req.status === "PENDING";

            return (
              <div key={req.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4 hover:border-slate-300 transition-all">
                
                {/* Request Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div className="flex items-center space-x-2.5">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider ${
                      req.actionType === "DELETE" ? "bg-rose-100 text-rose-800" :
                      req.actionType === "FINANCIAL_ADJUSTMENT" ? "bg-amber-100 text-amber-800" :
                      req.actionType === "USER_PROVISION" ? "bg-blue-100 text-blue-800" :
                      "bg-slate-100 text-slate-800"
                    }`}>
                      {req.actionType.replace("_", " ")}
                    </span>
                    <span className="text-xs font-bold text-slate-900">{req.entityType}</span>
                    <span className="text-xs text-slate-400 font-mono">[{req.entityId}]</span>
                  </div>

                  <div className="flex items-center space-x-2 text-xs text-slate-400">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{new Date(req.createdAt).toLocaleString()}</span>
                  </div>
                </div>

                {/* Mandatory Justification Reason (Prominent) */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1">
                  <div className="flex items-center space-x-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Maker's Mandatory Justification Reason</span>
                  </div>
                  <p className="text-sm font-medium text-slate-900 italic">
                    "{req.reason}"
                  </p>
                </div>

                {/* Maker & Reviewer Summary */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4 text-slate-400" />
                    <div>
                      <span className="text-slate-400 block text-[10px]">Proposed by (Maker):</span>
                      <span className="font-semibold text-slate-800">{req.makerName}</span>
                      <span className="text-slate-500 font-mono text-[11px] ml-1">({req.makerEmail})</span>
                    </div>
                  </div>

                  {req.checkerEmail && (
                    <div className="flex items-center space-x-2">
                      <Shield className="w-4 h-4 text-emerald-600" />
                      <div>
                        <span className="text-slate-400 block text-[10px]">Reviewed by (Checker):</span>
                        <span className="font-semibold text-slate-800">{req.checkerName || req.checkerEmail}</span>
                        <span className="text-slate-500 font-mono text-[11px] ml-1">({req.checkerEmail})</span>
                        {req.reviewNotes && (
                          <div className="text-[11px] text-slate-600 mt-0.5">Note: "{req.reviewNotes}"</div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Proposed Payload Summary (Diff) */}
                {req.proposedPayload && (
                  <div className="text-xs space-y-1">
                    <span className="text-[11px] font-semibold text-slate-500">Proposed Payload:</span>
                    <pre className="p-2.5 bg-slate-900 text-slate-100 rounded-xl overflow-x-auto font-mono text-[11px] max-h-32">
                      {JSON.stringify(req.proposedPayload, null, 2)}
                    </pre>
                  </div>
                )}

                {/* Actions & Zero Self-Approval Enforcement */}
                {req.status === "PENDING" && (
                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
                    {isMaker && !isSuperAdmin ? (
                      <div className="flex items-center space-x-1.5 text-xs text-amber-800 bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200">
                        <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
                        <span>Zero Self-Approval Rule: You created this request. A second Administrator or Backup Admin must act as Checker.</span>
                      </div>
                    ) : (
                      <span className="text-xs text-slate-500">Verification required by second authorized checker.</span>
                    )}

                    <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
                      <button
                        onClick={() => {
                          setReviewingRequest(req);
                          setReviewAction("REJECT");
                          setReviewNotes("");
                        }}
                        disabled={!canApprove}
                        className="px-4 py-2 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl transition-colors disabled:opacity-40 flex items-center space-x-1.5"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Reject Request</span>
                      </button>

                      <button
                        onClick={() => {
                          setReviewingRequest(req);
                          setReviewAction("APPROVE");
                          setReviewNotes("");
                        }}
                        disabled={!canApprove}
                        className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-sm transition-all disabled:opacity-40 flex items-center space-x-1.5"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve & Execute</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Review Modal */}
      {reviewingRequest && reviewAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className={`px-6 py-4 text-white flex items-center justify-between ${
              reviewAction === "APPROVE" ? "bg-emerald-700" : "bg-rose-700"
            }`}>
              <div className="flex items-center space-x-2">
                {reviewAction === "APPROVE" ? <CheckCircle2 className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
                <h3 className="font-bold text-base">
                  {reviewAction === "APPROVE" ? "Approve & Authorize Action" : "Reject Action Request"}
                </h3>
              </div>
              <button onClick={() => { setReviewingRequest(null); setReviewAction(null); }} className="text-white/80 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleReviewSubmit} className="p-6 space-y-4 text-xs text-slate-700">
              {reviewError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{reviewError}</span>
                </div>
              )}

              <div>
                <span className="text-[11px] text-slate-400 block">Proposed Action:</span>
                <span className="font-bold text-slate-900 text-sm">{reviewingRequest.actionType} on {reviewingRequest.entityType}</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">Maker's Justification:</span>
                <p className="text-slate-800 italic mt-0.5">"{reviewingRequest.reason}"</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {reviewAction === "APPROVE" ? "Review Notes (Optional)" : "Rejection Reason (Mandatory) *"}
                </label>
                <textarea
                  required={reviewAction === "REJECT"}
                  rows={3}
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  placeholder={reviewAction === "APPROVE" ? "e.g. Verified against physical inventory receipt." : "e.g. Inadequate supporting documents. Please resubmit with invoice."}
                  className="w-full p-2.5 border border-slate-300 rounded-xl text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => { setReviewingRequest(null); setReviewAction(null); }}
                  className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingReview}
                  className={`px-5 py-2 text-xs font-bold text-white rounded-xl shadow-md transition-all flex items-center space-x-1.5 disabled:opacity-50 ${
                    reviewAction === "APPROVE" ? "bg-emerald-600 hover:bg-emerald-700" : "bg-rose-600 hover:bg-rose-700"
                  }`}
                >
                  {isSubmittingReview ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Processing...</span>
                    </>
                  ) : (
                    <span>Confirm {reviewAction === "APPROVE" ? "Approval" : "Rejection"}</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

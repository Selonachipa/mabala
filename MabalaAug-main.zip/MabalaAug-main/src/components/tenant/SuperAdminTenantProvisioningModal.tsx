import React, { useState } from "react";
import { 
  Building2, 
  Shield, 
  KeyRound, 
  Mail, 
  Phone, 
  User, 
  FileText, 
  Upload, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Sparkles, 
  Layers, 
  Lock, 
  Eye, 
  EyeOff, 
  RefreshCw,
  Send,
  Building,
  Check,
  HelpCircle
} from "lucide-react";
import { TenantCategory, MakerCheckerConfig } from "../../types";
import { TenantService, TENANT_TEMPLATES, CreateTenantInput } from "../../services/tenantService";
import { safeFormatError } from "../../utils/errorUtils";

interface SuperAdminTenantProvisioningModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTenantCreated?: (tenant: any) => void;
  superAdminEmail: string;
  superAdminUid: string;
}

export default function SuperAdminTenantProvisioningModal({
  isOpen,
  onClose,
  onTenantCreated,
  superAdminEmail,
  superAdminUid
}: SuperAdminTenantProvisioningModalProps) {
  const [name, setName] = useState("");
  const [registrationNumber, setRegistrationNumber] = useState("");
  const [corporateEmail, setCorporateEmail] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [adminName, setAdminName] = useState("");
  const [defaultPassword, setDefaultPassword] = useState(`Mabala@${Math.floor(100000 + Math.random() * 900000)}`);
  const [showPassword, setShowPassword] = useState(false);
  const [tenantType, setTenantType] = useState<TenantCategory>("crop");
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("template-crop");
  const [logoUrl, setLogoUrl] = useState("");
  const [address, setAddress] = useState("");
  const [province, setProvince] = useState("Lusaka");
  const [district, setDistrict] = useState("Lusaka");
  const [requireForcedPasswordChange, setRequireForcedPasswordChange] = useState(true);

  // Maker-Checker Settings
  const [enableMakerChecker, setEnableMakerChecker] = useState(true);
  const [requireDualFinancial, setRequireDualFinancial] = useState(true);
  const [requireDualDeletion, setRequireDualDeletion] = useState(true);
  const [requireDualUserProvision, setRequireDualUserProvision] = useState(true);
  const [financialThreshold, setFinancialThreshold] = useState(5000);
  const [backupAdminEmail, setBackupAdminEmail] = useState("");
  const [backupAdminName, setBackupAdminName] = useState("");

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successResult, setSuccessResult] = useState<{
    tenant: any;
    adminUser: any;
    welcomeEmailSent: boolean;
    message: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleTemplateChange = (tmplId: string) => {
    setSelectedTemplateId(tmplId);
    const tmpl = TENANT_TEMPLATES.find(t => t.id === tmplId);
    if (tmpl) {
      setTenantType(tmpl.category);
    }
  };

  const handleGeneratePassword = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$";
    let pass = "Mabala@";
    for (let i = 0; i < 6; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setDefaultPassword(pass);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setLogoUrl(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessResult(null);

    if (!name.trim()) {
      setErrorMessage("Please provide the Entity/Company name.");
      return;
    }
    if (!registrationNumber.trim()) {
      setErrorMessage("Company registration number (PACRA or Business Registration) is mandatory.");
      return;
    }
    if (!corporateEmail.trim()) {
      setErrorMessage("Corporate email address is required (serves as the primary Admin login ID).");
      return;
    }
    if (!contactPhone.trim()) {
      setErrorMessage("Contact phone number is required.");
      return;
    }
    if (!adminName.trim()) {
      setErrorMessage("Administrator's full name is required.");
      return;
    }

    setIsLoading(true);

    try {
      const payload: CreateTenantInput = {
        name,
        registrationNumber,
        corporateEmail,
        contactPhone,
        adminName,
        defaultPassword,
        tenantType,
        templatePresetId: selectedTemplateId,
        logoUrl,
        address,
        province,
        district,
        requireForcedPasswordChange,
        makerCheckerConfig: {
          enabled: enableMakerChecker,
          requireDualApprovalForFinancial: requireDualFinancial,
          requireDualApprovalForDeletion: requireDualDeletion,
          requireDualApprovalForUserProvision: requireDualUserProvision,
          requireDualApprovalForPriceBoard: true,
          financialThresholdZmw: Number(financialThreshold) || 5000,
          backupAdminEmail,
          backupAdminName,
          fallbackToSuperAdmin: true
        },
        backupAdminEmail,
        backupAdminName
      };

      const result = await TenantService.createTenant(
        payload,
        superAdminEmail || "support@mabala.cloud",
        superAdminUid || "super-admin"
      );

      setSuccessResult(result);
      if (onTenantCreated) {
        onTenantCreated(result.tenant);
      }
    } catch (err: any) {
      console.error("[TenantProvisioningModal] Error:", err);
      setErrorMessage(err.message || "Failed to provision tenant entity.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg font-bold">Tenant Creation & Provisioning</h2>
                <span className="px-2 py-0.5 text-xs font-semibold bg-emerald-500/30 text-emerald-300 rounded border border-emerald-500/40">
                  Super Admin Only
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Provision Supplier, Agro Dealer, Institutional, or Agricultural Enterprise entities with zero-trust isolation.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Success Notification Banner */}
          {successResult ? (
            <div className="p-6 bg-emerald-50 border-2 border-emerald-400 rounded-2xl space-y-4">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 rounded-full bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-600 shrink-0">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <div className="flex-1">
                  <h3 className="text-base font-bold text-emerald-950">Tenant Provisioned Successfully!</h3>
                  <p className="text-sm text-emerald-800 mt-1">{successResult.message}</p>
                </div>
              </div>

              {/* Credentials & Access Summary Card */}
              <div className="bg-white rounded-xl p-4 border border-emerald-200 shadow-sm space-y-3">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">Access & Login Credentials</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-xs text-slate-400 block">Tenant Entity:</span>
                    <span className="font-semibold text-slate-800">{successResult.tenant.name}</span> ({successResult.tenant.id})
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block">Assigned Role:</span>
                    <span className="font-semibold text-emerald-700">Administrator (Full Tenant-Level Control)</span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block">Login ID (Corporate Email):</span>
                    <span className="font-mono font-medium text-slate-900 bg-slate-100 px-2 py-0.5 rounded">{successResult.adminUser.email}</span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block">Temporary Password:</span>
                    <span className="font-mono font-bold text-emerald-900 bg-emerald-100/60 px-2 py-0.5 rounded">{successResult.adminUser.password}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                  <div className="flex items-center space-x-1.5">
                    <Send className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Welcome Email: {successResult.welcomeEmailSent ? "✅ Sent to Administrator" : "⚠️ Queued for dispatch"}</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-600" />
                    <span>Forced Password Change: {successResult.adminUser.mustChangePassword ? "Enforced on first login" : "Disabled"}</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setSuccessResult(null);
                    setName("");
                    setRegistrationNumber("");
                    setCorporateEmail("");
                    setContactPhone("");
                    setAdminName("");
                    setLogoUrl("");
                  }}
                  className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors"
                >
                  Provision Another Tenant
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2 text-sm font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 shadow-md transition-colors"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {errorMessage && (
                <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-sm flex items-start space-x-3">
                  <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold">Provisioning Error</div>
                    <p className="mt-0.5">{safeFormatError(errorMessage)}</p>
                  </div>
                </div>
              )}

              {/* Section 1: Entity Template Preset */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5">
                  1. Select Enterprise Entity Template
                </label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {TENANT_TEMPLATES.map((tmpl) => {
                    const isSelected = selectedTemplateId === tmpl.id;
                    return (
                      <button
                        key={tmpl.id}
                        type="button"
                        onClick={() => handleTemplateChange(tmpl.id)}
                        className={`p-3.5 rounded-xl border text-left transition-all relative ${
                          isSelected 
                            ? "border-emerald-600 bg-emerald-50/60 shadow-sm ring-1 ring-emerald-500" 
                            : "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50"
                        }`}
                      >
                        {isSelected && (
                          <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                            <Check className="w-3 h-3" />
                          </div>
                        )}
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-sm text-slate-900">{tmpl.name}</span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1 line-clamp-2">{tmpl.description}</p>
                        <div className="mt-2.5 flex items-center space-x-1.5 text-[11px] text-slate-400">
                          <Layers className="w-3 h-3 text-slate-400" />
                          <span>{tmpl.defaultDepartments.length} Depts • {tmpl.defaultRoles.length} Roles</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Section 2: Entity & Registration Details */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5">
                  2. Entity & PACRA Registration Details
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Entity / Company Name <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <Building className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Copperbelt Agro Supply Ltd"
                        className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      PACRA / Company Registration No <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <FileText className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                      <input
                        type="text"
                        required
                        value={registrationNumber}
                        onChange={(e) => setRegistrationNumber(e.target.value.toUpperCase())}
                        placeholder="e.g. PACRA-1200948-2024"
                        className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-sm uppercase focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Corporate Email (Admin Login ID) <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                      <input
                        type="email"
                        required
                        value={corporateEmail}
                        onChange={(e) => setCorporateEmail(e.target.value.toLowerCase())}
                        placeholder="admin@company.com"
                        className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Contact Phone Number <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                      <input
                        type="tel"
                        required
                        value={contactPhone}
                        onChange={(e) => setContactPhone(e.target.value)}
                        placeholder="+260 97 123 4567"
                        className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Physical Head Office Address
                    </label>
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="e.g. Stand 408, Great East Road, Lusaka"
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Province</label>
                      <select
                        value={province}
                        onChange={(e) => setProvince(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm bg-white outline-none"
                      >
                        <option value="Lusaka">Lusaka</option>
                        <option value="Copperbelt">Copperbelt</option>
                        <option value="Central">Central</option>
                        <option value="Southern">Southern</option>
                        <option value="Eastern">Eastern</option>
                        <option value="Northern">Northern</option>
                        <option value="Luapula">Luapula</option>
                        <option value="Muchinga">Muchinga</option>
                        <option value="North-Western">North-Western</option>
                        <option value="Western">Western</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">District</label>
                      <input
                        type="text"
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        placeholder="e.g. Lusaka"
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 3: Entity Branding & Logo */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5">
                  3. Entity Logo & Branding
                </label>
                <div className="p-4 border border-slate-200 rounded-xl bg-slate-50 flex items-center space-x-4">
                  <div className="w-16 h-16 rounded-xl border border-slate-300 bg-white flex items-center justify-center overflow-hidden shrink-0 shadow-sm">
                    {logoUrl ? (
                      <img src={logoUrl} alt="Logo Preview" className="w-full h-full object-contain p-1" />
                    ) : (
                      <Building2 className="w-8 h-8 text-slate-300" />
                    )}
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center space-x-2">
                      <label className="cursor-pointer px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-100 flex items-center space-x-1.5 shadow-sm">
                        <Upload className="w-3.5 h-3.5 text-slate-600" />
                        <span>Upload Logo File</span>
                        <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                      </label>
                      {logoUrl && (
                        <button
                          type="button"
                          onClick={() => setLogoUrl("")}
                          className="text-xs text-rose-600 hover:underline"
                        >
                          Remove
                        </button>
                      )}
                    </div>
                    <input
                      type="url"
                      value={logoUrl}
                      onChange={(e) => setLogoUrl(e.target.value)}
                      placeholder="Or paste external logo image URL..."
                      className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white outline-none"
                    />
                    <p className="text-[11px] text-slate-500">Logo will appear on tenant invoices, receipts, and reports.</p>
                  </div>
                </div>
              </div>

              {/* Section 4: Administrator User & Default Password */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5">
                  4. Administrator Account & Welcome Credentials
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Full Name of Administrator <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                      <input
                        type="text"
                        required
                        value={adminName}
                        onChange={(e) => setAdminName(e.target.value)}
                        placeholder="e.g. Chileshe Mwape"
                        className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                      />
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Created as <span className="font-semibold text-slate-700">Administrator</span> with full tenant-level permissions and ability to create and manage further users.
                    </p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-semibold text-slate-700">
                        Default Password <span className="text-rose-500">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={handleGeneratePassword}
                        className="text-xs text-emerald-600 font-medium hover:underline flex items-center space-x-1"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>Generate Random</span>
                      </button>
                    </div>
                    <div className="relative">
                      <KeyRound className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                      <input
                        type={showPassword ? "text" : "password"}
                        required
                        value={defaultPassword}
                        onChange={(e) => setDefaultPassword(e.target.value)}
                        className="w-full pl-9 pr-10 py-2 border border-slate-300 rounded-xl text-sm font-mono focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Included in the automated welcome email sent to <span className="font-mono text-slate-700">{corporateEmail || "corporate email"}</span>.
                    </p>
                  </div>
                </div>

                <div className="mt-3 bg-amber-50/70 border border-amber-200 rounded-xl p-3.5 flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <Lock className="w-4 h-4 text-amber-700" />
                    <div>
                      <span className="text-xs font-bold text-amber-900">Forced Password Change on First Login</span>
                      <p className="text-[11px] text-amber-700">The Administrator is required to set their own private password upon entering the platform.</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={requireForcedPasswordChange}
                    onChange={(e) => setRequireForcedPasswordChange(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Section 5: Maker-Checker / Dual-Control Settings */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
                    5. Maker-Checker & Dual-Control Approval Policy
                  </label>
                  <div className="flex items-center space-x-1.5">
                    <span className="text-xs text-slate-600 font-medium">Enable Dual-Control:</span>
                    <input
                      type="checkbox"
                      checked={enableMakerChecker}
                      onChange={(e) => setEnableMakerChecker(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                {enableMakerChecker && (
                  <div className="p-4 border border-slate-200 rounded-xl bg-slate-50 space-y-3">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                      <label className="flex items-center space-x-2 bg-white p-2.5 rounded-lg border border-slate-200 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={requireDualFinancial}
                          onChange={(e) => setRequireDualFinancial(e.target.checked)}
                          className="w-4 h-4 text-emerald-600 rounded border-slate-300"
                        />
                        <span className="text-slate-700 font-medium">Financial & Write-off Approvals</span>
                      </label>

                      <label className="flex items-center space-x-2 bg-white p-2.5 rounded-lg border border-slate-200 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={requireDualDeletion}
                          onChange={(e) => setRequireDualDeletion(e.target.checked)}
                          className="w-4 h-4 text-emerald-600 rounded border-slate-300"
                        />
                        <span className="text-slate-700 font-medium">Mandatory Reason on Deletions</span>
                      </label>

                      <label className="flex items-center space-x-2 bg-white p-2.5 rounded-lg border border-slate-200 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={requireDualUserProvision}
                          onChange={(e) => setRequireDualUserProvision(e.target.checked)}
                          className="w-4 h-4 text-emerald-600 rounded border-slate-300"
                        />
                        <span className="text-slate-700 font-medium">Staff Role & Permission Changes</span>
                      </label>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Backup Administrator / Checker Email (Fallback)
                        </label>
                        <input
                          type="email"
                          value={backupAdminEmail}
                          onChange={(e) => setBackupAdminEmail(e.target.value)}
                          placeholder="backup.admin@company.com"
                          className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white outline-none"
                        />
                        <p className="text-[10px] text-slate-500 mt-0.5">Allows secondary review if tenant has single admin or falls back to Super Admin.</p>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Dual-Approval Financial Threshold (ZMW)
                        </label>
                        <input
                          type="number"
                          value={financialThreshold}
                          onChange={(e) => setFinancialThreshold(Number(e.target.value))}
                          placeholder="5000"
                          className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white outline-none"
                        />
                        <p className="text-[10px] text-slate-500 mt-0.5">Transactions above this amount require second-person checker sign-off.</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="px-6 py-2.5 text-sm font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-md transition-all flex items-center space-x-2 disabled:opacity-50"
                >
                  {isLoading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Provisioning & Dispatching Welcome Email...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-emerald-400" />
                      <span>Create & Provision Tenant</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

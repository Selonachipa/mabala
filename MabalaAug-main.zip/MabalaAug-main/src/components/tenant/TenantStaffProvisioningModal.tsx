import React, { useState, useEffect } from "react";
import { 
  UserPlus, 
  Mail, 
  Phone, 
  User, 
  Shield, 
  KeyRound, 
  Lock, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Send, 
  RefreshCw, 
  Layers, 
  FileText 
} from "lucide-react";
import { TenantRecord, TenantDepartment, TenantRole, GranularPermission, UserMember, PredefinedRole } from "../../types";
import { UserService } from "../../services/userService";
import { ApprovalService } from "../../services/approvalService";
import { SYSTEM_MODULES } from "../AccessControlPanel";
import { safeFormatError } from "../../utils/errorUtils";

interface TenantStaffProvisioningModalProps {
  isOpen: boolean;
  onClose: () => void;
  tenant: TenantRecord;
  currentUserEmail: string;
  currentUserUid: string;
  currentUserName: string;
  currentUserRole: string;
  onUserCreated?: (user: UserMember) => void;
}

export default function TenantStaffProvisioningModal({
  isOpen,
  onClose,
  tenant,
  currentUserEmail,
  currentUserUid,
  currentUserName,
  currentUserRole,
  onUserCreated
}: TenantStaffProvisioningModalProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [nationalId, setNationalId] = useState("");
  const [selectedDeptId, setSelectedDeptId] = useState(tenant.departments?.[0]?.id || "");
  const [selectedRoleId, setSelectedRoleId] = useState(tenant.roles?.[0]?.id || "");
  const [defaultPassword, setDefaultPassword] = useState(`Mabala@${Math.floor(100000 + Math.random() * 900000)}`);
  const [showPassword, setShowPassword] = useState(false);
  const [forcePasswordChange, setForcePasswordChange] = useState(true);
  const [justificationReason, setJustificationReason] = useState("");
  
  // Granular Module Permissions for this specific user
  const [selectedModules, setSelectedModules] = useState<string[]>([]);
  const [modulePermissions, setModulePermissions] = useState<Record<string, GranularPermission>>({});

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successResult, setSuccessResult] = useState<{
    user?: UserMember;
    isDualApprovalPending?: boolean;
    welcomeEmailSent: boolean;
    message: string;
  } | null>(null);

  useEffect(() => {
    if (selectedRoleId) {
      const role = tenant.roles?.find(r => r.id === selectedRoleId);
      if (role) {
        setSelectedModules(role.permittedModules || []);
        setModulePermissions(role.modulePermissions || {});
        if (role.departmentId) setSelectedDeptId(role.departmentId);
      }
    }
  }, [selectedRoleId, tenant]);

  if (!isOpen) return null;

  const handleGeneratePassword = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$";
    let pass = "Mabala@";
    for (let i = 0; i < 6; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setDefaultPassword(pass);
  };

  const toggleModule = (modId: string) => {
    if (selectedModules.includes(modId)) {
      setSelectedModules(selectedModules.filter(m => m !== modId));
      const copy = { ...modulePermissions };
      delete copy[modId];
      setModulePermissions(copy);
    } else {
      setSelectedModules([...selectedModules, modId]);
      setModulePermissions({
        ...modulePermissions,
        [modId]: { read: true, write: false, delete: false, approve: false }
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessResult(null);

    const cleanName = name.trim();
    const cleanEmail = email.trim().toLowerCase();
    const cleanPhone = phone.trim();

    if (!cleanName || !cleanEmail) {
      setErrorMessage("Full Name and Work Email are mandatory.");
      return;
    }

    const selectedRole = tenant.roles?.find(r => r.id === selectedRoleId);
    const selectedDept = tenant.departments?.find(d => d.id === selectedDeptId);

    setIsLoading(true);

    try {
      // Check if Maker-Checker dual control is required for user provisioning
      const requiresDualControl = tenant.makerCheckerConfig?.enabled && tenant.makerCheckerConfig.requireDualApprovalForUserProvision;

      if (requiresDualControl && !justificationReason.trim()) {
        throw new Error("Mandatory Justification Reason is required to submit a user provisioning request for dual-control approval.");
      }

      if (requiresDualControl && justificationReason.trim().length >= 5) {
        // Submit to Maker-Checker Queue
        const req = await ApprovalService.submitForApproval({
          tenantId: tenant.id,
          tenantName: tenant.name,
          actionType: "USER_PROVISION",
          entityType: "UserAccount",
          entityId: cleanEmail,
          entityTitle: `Staff Provisioning: ${cleanName} (${selectedRole?.name || "Staff"})`,
          makerUid: currentUserUid,
          makerEmail: currentUserEmail,
          makerName: currentUserName,
          makerRole: currentUserRole,
          makerDepartment: selectedDept?.name || "Administration",
          reason: justificationReason.trim(),
          proposedPayload: {
            name: cleanName,
            email: cleanEmail,
            phone: cleanPhone,
            nationalId,
            departmentId: selectedDeptId,
            departmentName: selectedDept?.name,
            roleId: selectedRoleId,
            roleName: selectedRole?.name,
            permittedModules: selectedModules,
            modulePermissions: modulePermissions,
            defaultPassword,
            forcePasswordChange
          },
          backupAdminEmail: tenant.makerCheckerConfig?.backupAdminEmail
        });

        setSuccessResult({
          isDualApprovalPending: true,
          welcomeEmailSent: false,
          message: `User provisioning request for "${cleanName}" (${cleanEmail}) has been submitted to the Maker-Checker Approval Centre. A secondary Checker or Super Admin must authorize before credentials activate.`
        });
      } else {
        // Direct Provisioning
        const roleToAssign = (selectedRole?.isTenantAdmin ? "Farm Owner" : selectedRole?.name || "Accountant") as PredefinedRole;

        const createdUser = await UserService.createFarmNodeUser(
          tenant.id,
          currentUserEmail,
          {
            name: cleanName,
            email: cleanEmail,
            password: defaultPassword,
            role: roleToAssign,
            permittedModules: selectedModules,
            modulePermissions: modulePermissions as any,
            farmId: `farm_${tenant.id}`,
            farmName: tenant.name,
            mustChangePassword: forcePasswordChange
          }
        );

        // Dispatch Welcome Email
        let emailSent = false;
        try {
          const loginUrl = typeof window !== "undefined" ? window.location.origin : "https://mabala.cloud";
          const res = await fetch("/api/mail/send-welcome", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              to: cleanEmail,
              fullName: cleanName,
              role: `${selectedRole?.name || "Team Member"} — ${tenant.name}`,
              defaultPassword: defaultPassword,
              loginUrl,
              farmContext: {
                farmName: tenant.name,
                tenantName: tenant.name,
                tenantId: tenant.id
              }
            })
          });
          emailSent = res.ok;
        } catch (_) {}

        setSuccessResult({
          user: createdUser,
          isDualApprovalPending: false,
          welcomeEmailSent: emailSent,
          message: `Staff member "${cleanName}" (${cleanEmail}) provisioned successfully! Initial credentials have been generated.`
        });

        if (onUserCreated) onUserCreated(createdUser);
      }
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to provision user.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base">Provision Team Member / Staff</h3>
              <p className="text-xs text-slate-300">
                Tenant: <span className="font-semibold text-emerald-400">{tenant.name}</span> ({tenant.id})
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-2">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {successResult ? (
            <div className="p-6 bg-emerald-50 border border-emerald-300 rounded-2xl space-y-4">
              <div className="flex items-start space-x-3">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 shrink-0" />
                <div>
                  <h4 className="font-bold text-emerald-950 text-base">
                    {successResult.isDualApprovalPending ? "Approval Request Submitted" : "Staff Member Provisioned!"}
                  </h4>
                  <p className="text-xs text-emerald-800 mt-1">{successResult.message}</p>
                </div>
              </div>

              {!successResult.isDualApprovalPending && (
                <div className="bg-white rounded-xl p-4 border border-emerald-200 text-xs space-y-2">
                  <div className="font-bold text-slate-700 uppercase">Login Credentials Summary</div>
                  <div className="grid grid-cols-2 gap-2 text-slate-800">
                    <div>Email (Login ID): <span className="font-mono font-semibold">{email}</span></div>
                    <div>Default Password: <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">{defaultPassword}</span></div>
                  </div>
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                    <span>Welcome Email: {successResult.welcomeEmailSent ? "✅ Sent" : "⚠️ Queued"}</span>
                    <span>Forced Password Change: Enforced on first login</span>
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs text-slate-700">
              
              {errorMessage && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{safeFormatError(errorMessage)}</span>
                </div>
              )}

              {/* Personal Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Full Name *</label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Kondwani Banda"
                      className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Work Email (Login ID) *</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value.toLowerCase())}
                      placeholder="kondwani@company.com"
                      className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Contact Phone Number</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+260 97 000 0000"
                      className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold mb-1">NRC / Passport Number (Optional)</label>
                  <div className="relative">
                    <FileText className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="text"
                      value={nationalId}
                      onChange={(e) => setNationalId(e.target.value)}
                      placeholder="e.g. 123456/10/1"
                      className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Department & Role Assignment */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block font-semibold mb-1">Department</label>
                  <select
                    value={selectedDeptId}
                    onChange={(e) => setSelectedDeptId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white outline-none"
                  >
                    {tenant.departments?.map((d) => (
                      <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Role Title</label>
                  <select
                    value={selectedRoleId}
                    onChange={(e) => setSelectedRoleId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white outline-none"
                  >
                    {tenant.roles?.map((r) => (
                      <option key={r.id} value={r.id}>{r.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Credentials & First Login Security */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-slate-800">Temporary Default Password</label>
                  <button
                    type="button"
                    onClick={handleGeneratePassword}
                    className="text-xs text-emerald-600 font-medium hover:underline flex items-center space-x-1"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Generate Random</span>
                  </button>
                </div>

                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={defaultPassword}
                    onChange={(e) => setDefaultPassword(e.target.value)}
                    className="w-full pl-9 pr-10 py-2 border border-slate-300 rounded-xl font-mono outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                <label className="flex items-center space-x-2 cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={forcePasswordChange}
                    onChange={(e) => setForcePasswordChange(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded"
                  />
                  <span className="font-medium text-slate-700">Enforce Password Change on First Login (Recommended)</span>
                </label>
              </div>

              {/* Maker-Checker Mandatory Justification Reason (if active) */}
              {tenant.makerCheckerConfig?.enabled && tenant.makerCheckerConfig.requireDualApprovalForUserProvision && (
                <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl space-y-1.5">
                  <label className="block font-bold text-amber-900">
                    Dual-Control Policy: Mandatory Justification Reason *
                  </label>
                  <textarea
                    required
                    rows={2}
                    value={justificationReason}
                    onChange={(e) => setJustificationReason(e.target.value)}
                    placeholder="e.g. Onboarding new livestock supervisor for newly acquired block."
                    className="w-full p-2 border border-amber-300 rounded-xl outline-none bg-white text-xs"
                  />
                  <p className="text-[10px] text-amber-700">This action requires sign-off from a second authorized Checker or Super Admin.</p>
                </div>
              )}

              {/* Module Access Checklist */}
              <div>
                <label className="block font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Module Permissions Checklist ({selectedModules.length} Enabled)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-2 border border-slate-200 rounded-xl bg-slate-50">
                  {SYSTEM_MODULES.map((mod) => {
                    const isChecked = selectedModules.includes(mod.id);
                    return (
                      <label key={mod.id} className="flex items-center space-x-2 bg-white p-2 rounded-lg border border-slate-200 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleModule(mod.id)}
                          className="w-3.5 h-3.5 text-emerald-600 rounded"
                        />
                        <span className="font-medium text-slate-800 text-[11px] truncate">{mod.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Footer */}
              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-sm flex items-center space-x-1.5"
                >
                  {isLoading ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Provisioning...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Provision & Dispatch Welcome Email</span>
                    </>
                  )}
                </button>
              </div>

            </form>
          )}
        </div>
      </div>
    </div>
  );
}

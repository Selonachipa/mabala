import React, { useState } from "react";
import { 
  KeyRound, 
  Lock, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  Eye, 
  EyeOff, 
  RefreshCw,
  Sparkles
} from "lucide-react";
import { UserService } from "../../services/userService";
import { auth } from "../../firebase";
import { updatePassword } from "firebase/auth";
import { safeFormatError } from "../../utils/errorUtils";

interface ForcedPasswordChangeModalProps {
  isOpen: boolean;
  userEmail: string;
  userName: string;
  tenantId: string;
  onPasswordChanged: (newPassword: string) => void;
}

export default function ForcedPasswordChangeModal({
  isOpen,
  userEmail,
  userName,
  tenantId,
  onPasswordChanged
}: ForcedPasswordChangeModalProps) {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  // Password strength calculation
  const getPasswordStrength = () => {
    let score = 0;
    if (newPassword.length >= 8) score++;
    if (/[A-Z]/.test(newPassword)) score++;
    if (/[0-9]/.test(newPassword)) score++;
    if (/[^A-Za-z0-9]/.test(newPassword)) score++;
    return score;
  };

  const strength = getPasswordStrength();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (newPassword.length < 6) {
      setErrorMsg("New password must be at least 6 characters long.");
      return;
    }

    if (newPassword !== confirmPassword) {
      setErrorMsg("Passwords do not match. Please re-enter.");
      return;
    }

    setIsLoading(true);

    try {
      // 1. Update password in user registry
      await UserService.changeUserPassword(userEmail, newPassword, tenantId);

      // 2. Update Firebase Auth if current user is signed in
      if (auth.currentUser) {
        try {
          await updatePassword(auth.currentUser, newPassword);
        } catch (authErr) {
          console.warn("[ForcedPasswordChangeModal] Auth password update note:", authErr);
        }
      }

      onPasswordChanged(newPassword);
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to update password. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[999] flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white text-center">
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto mb-3 shadow-inner">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <h2 className="text-lg font-bold">First-Time Login Security</h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xs mx-auto">
            Welcome, <span className="font-semibold text-white">{userName || userEmail}</span>. You must set a permanent private password before proceeding.
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs text-slate-700">
          
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{safeFormatError(errorMsg)}</span>
            </div>
          )}

          <div>
            <label className="block font-semibold mb-1 text-slate-800">
              Account Email (Login ID)
            </label>
            <input
              type="text"
              readOnly
              disabled
              value={userEmail}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-100 text-slate-600 font-mono"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-800">
              New Permanent Password *
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type={showPassword ? "text" : "password"}
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="w-full pl-9 pr-10 py-2 border border-slate-300 rounded-xl font-mono outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {/* Password Strength Meter */}
            {newPassword && (
              <div className="mt-2 space-y-1">
                <div className="flex gap-1 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full flex-1 ${strength >= 1 ? (strength === 1 ? "bg-rose-500" : strength === 2 ? "bg-amber-500" : "bg-emerald-500") : "bg-slate-200"}`} />
                  <div className={`h-full flex-1 ${strength >= 2 ? (strength === 2 ? "bg-amber-500" : "bg-emerald-500") : "bg-slate-200"}`} />
                  <div className={`h-full flex-1 ${strength >= 3 ? "bg-emerald-500" : "bg-slate-200"}`} />
                  <div className={`h-full flex-1 ${strength >= 4 ? "bg-emerald-600" : "bg-slate-200"}`} />
                </div>
                <span className="text-[10px] text-slate-400">
                  {strength <= 1 ? "Weak password" : strength <= 2 ? "Moderate password" : "Strong & secure password"}
                </span>
              </div>
            )}
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-800">
              Confirm New Password *
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type={showPassword ? "text" : "password"}
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter new password"
                className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl font-mono outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-[11px] text-slate-600 space-y-1">
            <div className="font-semibold text-slate-800">Security Requirement:</div>
            <p>Your new password replaces the temporary password provided in your welcome email.</p>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Updating Password & Unlocking...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Set Password & Enter Platform</span>
              </>
            )}
          </button>
        </form>

      </div>
    </div>
  );
}

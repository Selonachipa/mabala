import React, { useState, useEffect } from "react";
import { 
  Layers, 
  Shield, 
  Plus, 
  Check, 
  Trash2, 
  Edit3, 
  Users, 
  Lock, 
  AlertCircle, 
  CheckCircle2, 
  ChevronRight,
  Sliders,
  FileText
} from "lucide-react";
import { TenantRecord, TenantDepartment, TenantRole, GranularPermission } from "../../types";
import { TenantService } from "../../services/tenantService";
import { SYSTEM_MODULES } from "../AccessControlPanel";

interface TenantRbacDepartmentManagerProps {
  tenant: TenantRecord;
  currentUserEmail: string;
  isSuperAdmin?: boolean;
  onTenantUpdated?: (updated: TenantRecord) => void;
}

export default function TenantRbacDepartmentManager({
  tenant,
  currentUserEmail,
  isSuperAdmin = false,
  onTenantUpdated
}: TenantRbacDepartmentManagerProps) {
  const [activeTab, setActiveTab] = useState<"departments" | "roles">("departments");
  
  // New Department State
  const [showAddDeptModal, setShowAddDeptModal] = useState(false);
  const [newDeptName, setNewDeptName] = useState("");
  const [newDeptCode, setNewDeptCode] = useState("");
  const [newDeptDesc, setNewDeptDesc] = useState("");
  const [newDeptHeadName, setNewDeptHeadName] = useState("");
  const [newDeptHeadEmail, setNewDeptHeadEmail] = useState("");

  // New Role State
  const [showAddRoleModal, setShowAddRoleModal] = useState(false);
  const [newRoleName, setNewRoleName] = useState("");
  const [newRoleDesc, setNewRoleDesc] = useState("");
  const [newRoleDeptId, setNewRoleDeptId] = useState(tenant.departments?.[0]?.id || "");
  const [newRoleIsAdmin, setNewRoleIsAdmin] = useState(false);
  const [selectedModules, setSelectedModules] = useState<string[]>(["dashboard", "accounts", "expenses"]);
  const [modulePerms, setModulePerms] = useState<Record<string, GranularPermission>>({
    dashboard: { read: true, write: true, delete: false, approve: false },
    accounts: { read: true, write: true, delete: false, approve: false },
    expenses: { read: true, write: true, delete: false, approve: false }
  });

  const [isSaving, setIsSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ msg: string; type: "success" | "error" } | null>(null);

  const handleAddDepartment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeptName.trim() || !newDeptCode.trim()) return;

    setIsSaving(true);
    setStatusMsg(null);

    try {
      const added = await TenantService.addDepartment(
        tenant.id,
        {
          name: newDeptName,
          code: newDeptCode,
          description: newDeptDesc,
          headOfDepartmentName: newDeptHeadName,
          headOfDepartmentEmail: newDeptHeadEmail
        },
        currentUserEmail
      );

      const updatedDepts = [...(tenant.departments || []), added];
      const updatedTenant = { ...tenant, departments: updatedDepts };
      if (onTenantUpdated) onTenantUpdated(updatedTenant);

      setShowAddDeptModal(false);
      setNewDeptName("");
      setNewDeptCode("");
      setNewDeptDesc("");
      setNewDeptHeadName("");
      setNewDeptHeadEmail("");
      setStatusMsg({ msg: `Department "${added.name}" (${added.code}) created successfully!`, type: "success" });
    } catch (err: any) {
      setStatusMsg({ msg: err.message || "Failed to create department.", type: "error" });
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddRole = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoleName.trim()) return;

    setIsSaving(true);
    setStatusMsg(null);

    try {
      const added = await TenantService.addRole(
        tenant.id,
        {
          name: newRoleName,
          description: newRoleDesc,
          departmentId: newRoleDeptId,
          isTenantAdmin: newRoleIsAdmin,
          permittedModules: selectedModules,
          modulePermissions: modulePerms
        },
        currentUserEmail
      );

      const updatedRoles = [...(tenant.roles || []), added];
      const updatedTenant = { ...tenant, roles: updatedRoles };
      if (onTenantUpdated) onTenantUpdated(updatedTenant);

      setShowAddRoleModal(false);
      setNewRoleName("");
      setNewRoleDesc("");
      setStatusMsg({ msg: `Role "${added.name}" created successfully!`, type: "success" });
    } catch (err: any) {
      setStatusMsg({ msg: err.message || "Failed to create role.", type: "error" });
    } finally {
      setIsSaving(false);
    }
  };

  const toggleModuleSelection = (moduleId: string) => {
    if (selectedModules.includes(moduleId)) {
      setSelectedModules(selectedModules.filter(m => m !== moduleId));
      const updatedPerms = { ...modulePerms };
      delete updatedPerms[moduleId];
      setModulePerms(updatedPerms);
    } else {
      setSelectedModules([...selectedModules, moduleId]);
      setModulePerms({
        ...modulePerms,
        [moduleId]: { read: true, write: false, delete: false, approve: false }
      });
    }
  };

  const updatePermType = (moduleId: string, permType: keyof GranularPermission, val: boolean) => {
    const current = modulePerms[moduleId] || { read: false, write: false, delete: false, approve: false };
    setModulePerms({
      ...modulePerms,
      [moduleId]: {
        ...current,
        [permType]: val,
        // If write/delete/approve is enabled, ensure read is also true
        ...(val && permType !== "read" ? { read: true } : {})
      }
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">Departments & Role-Based Access Control (RBAC)</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Configure organizational departments and granular module permissions for <span className="font-semibold text-slate-700">{tenant.name}</span>.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveTab("departments")}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-colors ${
              activeTab === "departments" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            Departments ({tenant.departments?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab("roles")}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-colors ${
              activeTab === "roles" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            Roles & Permissions ({tenant.roles?.length || 0})
          </button>
        </div>
      </div>

      {statusMsg && (
        <div className={`p-3.5 rounded-xl border text-xs flex items-center justify-between ${
          statusMsg.type === "success" ? "bg-emerald-50 border-emerald-200 text-emerald-800" : "bg-rose-50 border-rose-200 text-rose-800"
        }`}>
          <div className="flex items-center space-x-2">
            {statusMsg.type === "success" ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-rose-600" />}
            <span>{statusMsg.msg}</span>
          </div>
          <button onClick={() => setStatusMsg(null)} className="text-slate-400 hover:text-slate-600">&times;</button>
        </div>
      )}

      {/* Tab 1: Departments */}
      {activeTab === "departments" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h4 className="font-bold text-sm text-slate-900">Configured Enterprise Departments</h4>
            <button
              onClick={() => setShowAddDeptModal(true)}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-sm flex items-center space-x-1.5 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Department</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {tenant.departments?.map((dept) => (
              <div key={dept.id} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">{dept.name}</span>
                  <span className="font-mono text-xs bg-slate-100 px-2 py-0.5 rounded font-bold text-slate-700">{dept.code}</span>
                </div>
                <p className="text-xs text-slate-500">{dept.description || "No description provided."}</p>
                {dept.headOfDepartmentName && (
                  <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-600 flex items-center justify-between">
                    <span className="text-slate-400">Head:</span>
                    <span className="font-medium text-slate-800">{dept.headOfDepartmentName}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Roles */}
      {activeTab === "roles" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h4 className="font-bold text-sm text-slate-900">Configured Custom Roles & Permissions</h4>
            <button
              onClick={() => setShowAddRoleModal(true)}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-sm flex items-center space-x-1.5 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Custom Role</span>
            </button>
          </div>

          <div className="space-y-3">
            {tenant.roles?.map((role) => (
              <div key={role.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div className="flex items-center space-x-2">
                    <Shield className="w-4 h-4 text-emerald-600" />
                    <span className="font-bold text-slate-900 text-sm">{role.name}</span>
                    {role.isTenantAdmin && (
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded">
                        Full Administrator
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-slate-500 font-medium">Department: {role.departmentName || "General"}</span>
                </div>

                <p className="text-xs text-slate-600">{role.description || "Custom role configuration."}</p>

                {/* Module Permissions Matrix Badges */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {role.permittedModules?.map((modId) => {
                    const mod = SYSTEM_MODULES.find(m => m.id === modId);
                    const perms = role.modulePermissions?.[modId];
                    return (
                      <div key={modId} className="px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-[11px] flex items-center space-x-1.5">
                        <span className="font-semibold text-slate-800">{mod?.label || modId}</span>
                        <div className="flex items-center space-x-1 text-[9px] font-mono text-slate-500">
                          {perms?.read && <span className="bg-emerald-100 text-emerald-800 px-1 rounded">R</span>}
                          {perms?.write && <span className="bg-blue-100 text-blue-800 px-1 rounded">W</span>}
                          {perms?.delete && <span className="bg-rose-100 text-rose-800 px-1 rounded">D</span>}
                          {perms?.approve && <span className="bg-purple-100 text-purple-800 px-1 rounded">A</span>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Department Modal */}
      {showAddDeptModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">Add Organizational Department</h3>
              <button onClick={() => setShowAddDeptModal(false)} className="text-white/80 hover:text-white">&times;</button>
            </div>
            <form onSubmit={handleAddDepartment} className="p-6 space-y-3 text-xs text-slate-700">
              <div>
                <label className="block font-semibold mb-1">Department Name *</label>
                <input
                  type="text"
                  required
                  value={newDeptName}
                  onChange={(e) => setNewDeptName(e.target.value)}
                  placeholder="e.g. Quality Assurance & Lab"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Department Code *</label>
                <input
                  type="text"
                  required
                  value={newDeptCode}
                  onChange={(e) => setNewDeptCode(e.target.value.toUpperCase())}
                  placeholder="e.g. QA"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl outline-none font-mono uppercase"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Description</label>
                <textarea
                  rows={2}
                  value={newDeptDesc}
                  onChange={(e) => setNewDeptDesc(e.target.value)}
                  placeholder="Operational responsibilities..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl outline-none"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddDeptModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-sm"
                >
                  {isSaving ? "Saving..." : "Create Department"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Role Modal */}
      {showAddRoleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">Create Role & Module Permissions</h3>
              <button onClick={() => setShowAddRoleModal(false)} className="text-white/80 hover:text-white">&times;</button>
            </div>
            
            <form onSubmit={handleAddRole} className="p-6 overflow-y-auto space-y-4 text-xs text-slate-700">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Role Title *</label>
                  <input
                    type="text"
                    required
                    value={newRoleName}
                    onChange={(e) => setNewRoleName(e.target.value)}
                    placeholder="e.g. Agronomy Field Lead"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Department</label>
                  <select
                    value={newRoleDeptId}
                    onChange={(e) => setNewRoleDeptId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl outline-none bg-white"
                  >
                    {tenant.departments?.map((d) => (
                      <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Role Description</label>
                <input
                  type="text"
                  value={newRoleDesc}
                  onChange={(e) => setNewRoleDesc(e.target.value)}
                  placeholder="Primary duties and module responsibilities"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="block font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Module Permissions Checklist (Read / Write / Delete / Approve)
                </label>
                <div className="space-y-2 border border-slate-200 rounded-xl p-3 bg-slate-50 max-h-60 overflow-y-auto">
                  {SYSTEM_MODULES.map((mod) => {
                    const isSelected = selectedModules.includes(mod.id);
                    const perms = modulePerms[mod.id] || { read: false, write: false, delete: false, approve: false };
                    return (
                      <div key={mod.id} className="p-2.5 bg-white border border-slate-200 rounded-xl flex items-center justify-between">
                        <label className="flex items-center space-x-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => toggleModuleSelection(mod.id)}
                            className="w-4 h-4 text-emerald-600 rounded"
                          />
                          <div>
                            <span className="font-semibold text-slate-800 text-xs">{mod.label}</span>
                            <span className="text-[10px] text-slate-400 block">{mod.desc}</span>
                          </div>
                        </label>

                        {isSelected && (
                          <div className="flex items-center space-x-2 text-[11px]">
                            <label className="flex items-center space-x-1 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={perms.read}
                                onChange={(e) => updatePermType(mod.id, "read", e.target.checked)}
                                className="w-3.5 h-3.5 text-emerald-600 rounded"
                              />
                              <span>Read</span>
                            </label>
                            <label className="flex items-center space-x-1 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={perms.write}
                                onChange={(e) => updatePermType(mod.id, "write", e.target.checked)}
                                className="w-3.5 h-3.5 text-blue-600 rounded"
                              />
                              <span>Write</span>
                            </label>
                            <label className="flex items-center space-x-1 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={Boolean(perms.delete)}
                                onChange={(e) => updatePermType(mod.id, "delete", e.target.checked)}
                                className="w-3.5 h-3.5 text-rose-600 rounded"
                              />
                              <span>Delete</span>
                            </label>
                            <label className="flex items-center space-x-1 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={Boolean(perms.approve)}
                                onChange={(e) => updatePermType(mod.id, "approve", e.target.checked)}
                                className="w-3.5 h-3.5 text-purple-600 rounded"
                              />
                              <span>Approve</span>
                            </label>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddRoleModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-sm"
                >
                  {isSaving ? "Saving..." : "Create Role"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

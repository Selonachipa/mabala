import React, { useState, useEffect, useMemo } from "react";
import { 
  Building2, 
  Plus, 
  Search, 
  Filter, 
  Shield, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Mail, 
  Phone, 
  FileText, 
  Layers, 
  Users, 
  Send, 
  Eye, 
  ChevronRight, 
  Edit3, 
  Trash2, 
  Ban, 
  Unlock, 
  ExternalLink,
  Sparkles,
  RefreshCw,
  Sliders,
  Check
} from "lucide-react";
import { TenantRecord, TenantCategory, TenantDepartment, TenantRole } from "../../types";
import { TenantService } from "../../services/tenantService";
import SuperAdminTenantProvisioningModal from "./SuperAdminTenantProvisioningModal";

interface TenantManagementConsoleProps {
  superAdminEmail: string;
  superAdminUid: string;
  onSelectTenantForSupport?: (tenant: TenantRecord) => void;
}

export default function TenantManagementConsole({
  superAdminEmail,
  superAdminUid,
  onSelectTenantForSupport
}: TenantManagementConsoleProps) {
  const [tenants, setTenants] = useState<TenantRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("ALL");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  
  // Modals & Panels
  const [showProvisionModal, setShowProvisionModal] = useState(false);
  const [selectedTenant, setSelectedTenant] = useState<TenantRecord | null>(null);
  const [resendingEmailId, setResendingEmailId] = useState<string | null>(null);
  const [resendStatusMsg, setResendStatusMsg] = useState<{ id: string; msg: string; type: "success" | "error" } | null>(null);

  const loadTenants = async () => {
    setIsLoading(true);
    try {
      const data = await TenantService.getAllTenants();
      setTenants(data);
    } catch (err) {
      console.error("Error loading tenants:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTenants();
  }, []);

  const handleResendWelcomeEmail = async (tenant: TenantRecord) => {
    setResendingEmailId(tenant.id);
    setResendStatusMsg(null);

    try {
      const defaultPass = "Mabala@2026";
      const loginUrl = typeof window !== "undefined" ? window.location.origin : "https://mabala.cloud";

      const res = await fetch("/api/mail/send-welcome", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: tenant.corporateEmail,
          fullName: tenant.adminName,
          role: `Administrator — ${tenant.name}`,
          defaultPassword: defaultPass,
          loginUrl,
          farmContext: {
            farmName: tenant.name,
            tenantName: tenant.name,
            tenantId: tenant.id
          }
        })
      });

      if (res.ok) {
        setResendStatusMsg({ id: tenant.id, msg: `Welcome email successfully resent to ${tenant.corporateEmail}`, type: "success" });
        await TenantService.updateTenant(tenant.id, {
          welcomeEmailDispatched: true,
          welcomeEmailDispatchedAt: new Date().toISOString()
        }, superAdminEmail);
        loadTenants();
      } else {
        setResendStatusMsg({ id: tenant.id, msg: "Server mail delivery failed. Check mail service logs.", type: "error" });
      }
    } catch (err: any) {
      setResendStatusMsg({ id: tenant.id, msg: err.message || "Failed to resend welcome email.", type: "error" });
    } finally {
      setResendingEmailId(null);
    }
  };

  const handleToggleTenantSuspension = async (tenant: TenantRecord) => {
    const newStatus = tenant.status === "active" ? "suspended" : "active";
    const confirmMsg = newStatus === "suspended" 
      ? `Are you sure you want to suspend tenant "${tenant.name}"? All users under this tenant will be blocked from logging in.`
      : `Activate tenant "${tenant.name}"? Users will be restored access.`;
    
    if (!window.confirm(confirmMsg)) return;

    try {
      await TenantService.updateTenant(tenant.id, { status: newStatus }, superAdminEmail);
      await loadTenants();
      if (selectedTenant && selectedTenant.id === tenant.id) {
        setSelectedTenant({ ...selectedTenant, status: newStatus });
      }
    } catch (err) {
      alert("Error updating tenant status: " + err);
    }
  };

  const filteredTenants = useMemo(() => {
    return tenants.filter(t => {
      const matchSearch = 
        (t.name || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.registrationNumber || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.corporateEmail || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.adminName || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.id || "").toLowerCase().includes(searchQuery.toLowerCase());

      const matchCat = categoryFilter === "ALL" || t.tenantType === categoryFilter;
      const matchStatus = statusFilter === "ALL" || t.status === statusFilter;

      return matchSearch && matchCat && matchStatus;
    });
  }, [tenants, searchQuery, categoryFilter, statusFilter]);

  return (
    <div className="space-y-6">
      
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Tenant Directory & Provisioning</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Super Admin provisioning portal for Suppliers, Agro Dealers, Institutional, and Enterprise Farm Entities.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={loadTenants}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl border border-slate-200 transition-colors"
            title="Refresh tenants"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
          </button>

          <button
            onClick={() => setShowProvisionModal(true)}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm rounded-xl shadow-sm flex items-center space-x-2 transition-all"
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            <span>Create & Provision Tenant</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, PACRA, admin email..."
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center space-x-2 w-full md:w-auto overflow-x-auto">
          <span className="text-xs font-semibold text-slate-500 whitespace-nowrap">Category:</span>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white outline-none"
          >
            <option value="ALL">All Categories</option>
            <option value="supplier">Suppliers</option>
            <option value="agro_dealer">Agro Dealers</option>
            <option value="institutional">Institutional M&E</option>
            <option value="ranching">Ranching & Livestock</option>
            <option value="crop">Commercial Crop</option>
            <option value="feed_milling">Feed Milling</option>
            <option value="group_holding">Group / Holding</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white outline-none"
          >
            <option value="ALL">All Statuses</option>
            <option value="active">Active Only</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>
      </div>

      {/* Resend Status Toast Message */}
      {resendStatusMsg && (
        <div className={`p-3.5 rounded-xl border text-xs flex items-center justify-between ${
          resendStatusMsg.type === "success" 
            ? "bg-emerald-50 border-emerald-200 text-emerald-800" 
            : "bg-rose-50 border-rose-200 text-rose-800"
        }`}>
          <div className="flex items-center space-x-2">
            {resendStatusMsg.type === "success" ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-rose-600" />}
            <span>{resendStatusMsg.msg}</span>
          </div>
          <button onClick={() => setResendStatusMsg(null)} className="text-slate-400 hover:text-slate-600">
            &times;
          </button>
        </div>
      )}

      {/* Tenants Table Grid */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold text-[11px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Entity & PACRA</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Administrator & Contact</th>
                <th className="py-3 px-4">Depts & Roles</th>
                <th className="py-3 px-4">Maker-Checker</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {isLoading ? (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-slate-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto text-emerald-600 mb-2" />
                    <span>Loading registered tenants...</span>
                  </td>
                </tr>
              ) : filteredTenants.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    <Building2 className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-600">No matching tenants found</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">Click "Create & Provision Tenant" to onboard a new supplier or agro-dealer.</p>
                  </td>
                </tr>
              ) : (
                filteredTenants.map((tenant) => {
                  const isSuspended = tenant.status === "suspended";
                  return (
                    <tr key={tenant.id} className={`hover:bg-slate-50/80 transition-colors ${isSuspended ? "opacity-60 bg-rose-50/20" : ""}`}>
                      
                      {/* Entity & PACRA */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-9 h-9 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0">
                            {tenant.logoUrl ? (
                              <img src={tenant.logoUrl} alt={tenant.name} className="w-full h-full object-contain p-0.5" />
                            ) : (
                              <Building2 className="w-5 h-5 text-slate-400" />
                            )}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 text-sm hover:text-emerald-700 cursor-pointer" onClick={() => setSelectedTenant(tenant)}>
                              {tenant.name}
                            </div>
                            <div className="font-mono text-[11px] text-slate-500 flex items-center space-x-1.5 mt-0.5">
                              <span className="bg-slate-100 px-1.5 py-0.5 rounded">{tenant.registrationNumber || "NO-REG"}</span>
                              <span className="text-slate-300">•</span>
                              <span className="text-slate-400">{tenant.id}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-3.5 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold border ${
                          tenant.tenantType === "agro_dealer" ? "bg-amber-50 text-amber-800 border-amber-200" :
                          tenant.tenantType === "supplier" ? "bg-blue-50 text-blue-800 border-blue-200" :
                          tenant.tenantType === "institutional" ? "bg-indigo-50 text-indigo-800 border-indigo-200" :
                          tenant.tenantType === "ranching" ? "bg-orange-50 text-orange-800 border-orange-200" :
                          tenant.tenantType === "feed_milling" ? "bg-purple-50 text-purple-800 border-purple-200" :
                          "bg-emerald-50 text-emerald-800 border-emerald-200"
                        }`}>
                          {tenant.tenantType.replace("_", " ").toUpperCase()}
                        </span>
                        <div className="text-[10px] text-slate-400 mt-1">{tenant.templatePreset || "Custom"}</div>
                      </td>

                      {/* Administrator & Contact */}
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-slate-800">{tenant.adminName}</div>
                        <div className="font-mono text-[11px] text-slate-500 mt-0.5">{tenant.corporateEmail}</div>
                        <div className="text-[11px] text-slate-400">{tenant.contactPhone}</div>
                      </td>

                      {/* Depts & Roles */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-1 text-slate-600 font-medium">
                          <Layers className="w-3.5 h-3.5 text-slate-400" />
                          <span>{tenant.departments?.length || 0} Departments</span>
                        </div>
                        <div className="flex items-center space-x-1 text-slate-500 text-[11px] mt-0.5">
                          <Users className="w-3 h-3 text-slate-400" />
                          <span>{tenant.roles?.length || 0} Defined Roles</span>
                        </div>
                      </td>

                      {/* Maker-Checker */}
                      <td className="py-3.5 px-4">
                        {tenant.makerCheckerConfig?.enabled ? (
                          <div className="inline-flex items-center space-x-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[11px] font-medium">
                            <Shield className="w-3 h-3" />
                            <span>Dual-Control Active</span>
                          </div>
                        ) : (
                          <span className="text-slate-400 text-[11px]">Direct Single Admin</span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        {tenant.status === "active" ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800">
                            Active
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-rose-100 text-rose-800">
                            Suspended
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => setSelectedTenant(tenant)}
                            className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-slate-100 rounded-lg transition-colors"
                            title="View Tenant Details & Departments"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => handleResendWelcomeEmail(tenant)}
                            disabled={resendingEmailId === tenant.id}
                            className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50"
                            title="Resend Welcome Email"
                          >
                            <Send className={`w-4 h-4 ${resendingEmailId === tenant.id ? "animate-pulse text-blue-600" : ""}`} />
                          </button>

                          <button
                            onClick={() => handleToggleTenantSuspension(tenant)}
                            className={`p-1.5 rounded-lg transition-colors ${
                              isSuspended ? "text-emerald-700 hover:bg-emerald-50" : "text-rose-600 hover:bg-rose-50"
                            }`}
                            title={isSuspended ? "Activate Tenant" : "Suspend Tenant"}
                          >
                            {isSuspended ? <Unlock className="w-4 h-4" /> : <Ban className="w-4 h-4" />}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Tenant Inspection Drawer / Modal */}
      {selectedTenant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            
            {/* Drawer Header */}
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center overflow-hidden">
                  {selectedTenant.logoUrl ? (
                    <img src={selectedTenant.logoUrl} alt={selectedTenant.name} className="w-full h-full object-contain" />
                  ) : (
                    <Building2 className="w-5 h-5 text-emerald-400" />
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-base">{selectedTenant.name}</h3>
                  <p className="text-xs text-slate-300 font-mono">{selectedTenant.id} • {selectedTenant.registrationNumber}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedTenant(null)}
                className="text-slate-400 hover:text-white p-2 rounded-lg"
              >
                &times;
              </button>
            </div>

            {/* Drawer Content */}
            <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-700">
              
              {/* Overview Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                  <span className="text-[11px] text-slate-400 block">Category</span>
                  <span className="font-bold text-slate-800 uppercase">{selectedTenant.tenantType}</span>
                </div>
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                  <span className="text-[11px] text-slate-400 block">Status</span>
                  <span className={`font-bold ${selectedTenant.status === "active" ? "text-emerald-700" : "text-rose-600"}`}>
                    {selectedTenant.status.toUpperCase()}
                  </span>
                </div>
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                  <span className="text-[11px] text-slate-400 block">Admin Email</span>
                  <span className="font-medium text-slate-800 font-mono truncate block">{selectedTenant.adminEmail}</span>
                </div>
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                  <span className="text-[11px] text-slate-400 block">Dual-Control</span>
                  <span className="font-bold text-indigo-700">{selectedTenant.makerCheckerConfig?.enabled ? "Enabled" : "Disabled"}</span>
                </div>
              </div>

              {/* Departments Section */}
              <div>
                <h4 className="font-bold text-sm text-slate-900 mb-2 flex items-center space-x-1.5">
                  <Layers className="w-4 h-4 text-emerald-600" />
                  <span>Configured Departments ({selectedTenant.departments?.length || 0})</span>
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {selectedTenant.departments?.map((dept) => (
                    <div key={dept.id} className="p-3 border border-slate-200 rounded-xl bg-white space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800">{dept.name}</span>
                        <span className="font-mono text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-600">{dept.code}</span>
                      </div>
                      <p className="text-[11px] text-slate-500">{dept.description || "No description."}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Roles Section */}
              <div>
                <h4 className="font-bold text-sm text-slate-900 mb-2 flex items-center space-x-1.5">
                  <Shield className="w-4 h-4 text-indigo-600" />
                  <span>Configured Roles ({selectedTenant.roles?.length || 0})</span>
                </h4>
                <div className="space-y-2">
                  {selectedTenant.roles?.map((role) => (
                    <div key={role.id} className="p-3 border border-slate-200 rounded-xl bg-white flex items-center justify-between">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-slate-800">{role.name}</span>
                          {role.isTenantAdmin && (
                            <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[10px] font-semibold">
                              Admin Role
                            </span>
                          )}
                          <span className="text-slate-400 text-[10px]">Dept: {role.departmentName || "General"}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">{role.description}</p>
                      </div>
                      <div className="text-[11px] font-medium text-slate-600 bg-slate-50 px-2 py-1 rounded border border-slate-100">
                        {role.permittedModules?.length || 0} Modules Permitted
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Drawer Footer */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <div className="text-xs text-slate-500">
                Created: {new Date(selectedTenant.createdAt).toLocaleDateString()}
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleResendWelcomeEmail(selectedTenant)}
                  className="px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-xl border border-blue-200 transition-colors flex items-center space-x-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Resend Welcome Email</span>
                </button>
                <button
                  onClick={() => setSelectedTenant(null)}
                  className="px-4 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors"
                >
                  Close
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Super Admin Tenant Creation Modal */}
      <SuperAdminTenantProvisioningModal
        isOpen={showProvisionModal}
        onClose={() => setShowProvisionModal(false)}
        onTenantCreated={(newTenant) => {
          loadTenants();
        }}
        superAdminEmail={superAdminEmail}
        superAdminUid={superAdminUid}
      />
    </div>
  );
}

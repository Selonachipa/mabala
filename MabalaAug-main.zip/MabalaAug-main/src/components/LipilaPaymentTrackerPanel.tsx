import React, { useState, useEffect, useMemo } from "react";
import {
  CreditCard,
  Search,
  Filter,
  Download,
  CheckCircle,
  Clock,
  XCircle,
  FileText,
  ChevronRight,
  RefreshCw,
  X,
  Send,
  ShieldCheck,
  Building,
  DollarSign,
  Zap,
  Smartphone,
  Calendar,
  Layers,
  Store,
  HelpCircle
} from "lucide-react";
import { LipilaTransaction, INITIAL_LIPILA_TRANSACTIONS } from "../data/mockLipilaTransactions";
import { maskMobile } from "../utils/privacyMasking";
import MabalaReceiptModal from "./MabalaReceiptModal";
import FeeBreakdownPreview from "./FeeBreakdownPreview";
import SuperAdminPaymentReconcileModal from "./SuperAdminPaymentReconcileModal";
import { initiateCardCollectionService, initiateBankDisbursementService } from "../services/lipilaExpansionService";
import { collection, onSnapshot, doc, setDoc } from "firebase/firestore";
import { db } from "../firebase";

export default function LipilaPaymentTrackerPanel() {
  const [transactions, setTransactions] = useState<LipilaTransaction[]>([]);
  const [selectedTx, setSelectedTx] = useState<LipilaTransaction | null>(null);
  const [receiptTx, setReceiptTx] = useState<LipilaTransaction | null>(null);
  const [reconcileTx, setReconcileTx] = useState<LipilaTransaction | null>(null);
  const [reconcileSuccessToast, setReconcileSuccessToast] = useState<string | null>(null);

  // Filters
  const [moduleFilter, setModuleFilter] = useState<string>("ALL");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [providerFilter, setProviderFilter] = useState<string>("ALL");
  const [dateRange, setDateRange] = useState<string>("LAST_7_DAYS");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Pagination
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  // Notification status
  const [resendStatus, setResendStatus] = useState<string | null>(null);

  // Fee Breakdown Preview & Payment Initiation Modal State
  const [showPreviewModal, setShowPreviewModal] = useState<boolean>(false);
  const [previewType, setPreviewType] = useState<"card_collection" | "bank_disbursement">("card_collection");
  const [testAmount, setTestAmount] = useState<number>(1000);
  const [testTenantId, setTestTenantId] = useState<string>("TENANT-001");
  const [isExecutingPayment, setIsExecutingPayment] = useState<boolean>(false);
  const [executionMessage, setExecutionMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Sync with Firestore if available
  useEffect(() => {
    if (db) {
      let mainData: LipilaTransaction[] = [];
      let subData: LipilaTransaction[] = [];

      const updateMergedTransactions = () => {
        const map = new Map<string, LipilaTransaction>();
        subData.forEach(t => map.set(t.id, t));
        mainData.forEach(t => map.set(t.id, t));
        const merged = Array.from(map.values()).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setTransactions(merged);
      };

      const unsub1 = onSnapshot(
        collection(db, "superAdmin", "lipilaTransactions", "records"),
        (snapshot) => {
          subData = snapshot.empty ? [] : snapshot.docs.map((d) => d.data() as LipilaTransaction);
          updateMergedTransactions();
        },
        (error) => {
          console.warn("[LipilaTracker] Firestore subAdmin sync note:", error);
        }
      );

      const unsub2 = onSnapshot(
        collection(db, "lipilaTransactions"),
        (snapshot) => {
          mainData = snapshot.empty ? [] : snapshot.docs.map((d) => d.data() as LipilaTransaction);
          updateMergedTransactions();
        },
        (error) => {
          console.warn("[LipilaTracker] Firestore main collection sync note:", error);
        }
      );

      return () => {
        unsub1();
        unsub2();
      };
    }
  }, []);

  // Filtered dataset
  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      // Module filter
      if (moduleFilter !== "ALL" && tx.module !== moduleFilter) return false;
      // Status filter
      if (statusFilter !== "ALL" && tx.status !== statusFilter) return false;
      // Provider / Payment Method filter
      if (providerFilter !== "ALL") {
        const prov = (tx.provider || "").toLowerCase();
        const meth = (tx.paymentMethod || "").toLowerCase();
        const pType = (tx.paymentType || "").toLowerCase();
        const qProv = providerFilter.toLowerCase();

        if (qProv === "card" || qProv.includes("visa") || qProv.includes("card")) {
          if (pType !== "card" && !meth.includes("card") && !meth.includes("visa")) return false;
        } else if (qProv === "bank" || qProv.includes("bank")) {
          if (pType !== "bank" && !meth.includes("bank") && !prov.includes("bank")) return false;
        } else {
          if (!prov.includes(qProv) && !meth.includes(qProv)) return false;
        }
      }

      // Date Range filter
      if (dateRange !== "ALL") {
        const txDate = new Date(tx.createdAt).getTime();
        const now = new Date().getTime();
        if (dateRange === "TODAY") {
          const startOfDay = new Date().setHours(0, 0, 0, 0);
          if (txDate < startOfDay) return false;
        } else if (dateRange === "LAST_7_DAYS") {
          if (now - txDate > 7 * 24 * 60 * 60 * 1000) return false;
        } else if (dateRange === "LAST_30_DAYS") {
          if (now - txDate > 30 * 24 * 60 * 60 * 1000) return false;
        }
      }

      // Search Query
      if (searchQuery.trim() !== "") {
        const q = searchQuery.toLowerCase();
        const matchesId = tx.id.toLowerCase().includes(q);
        const matchesRef = tx.referenceId.toLowerCase().includes(q);
        const matchesCustomer = tx.customerName.toLowerCase().includes(q);
        const matchesPhone = tx.accountNumber.toLowerCase().includes(q);
        if (!matchesId && !matchesRef && !matchesCustomer && !matchesPhone) return false;
      }

      return true;
    });
  }, [transactions, moduleFilter, statusFilter, providerFilter, dateRange, searchQuery]);

  // Paginated dataset
  const totalPages = Math.ceil(filteredTransactions.length / pageSize) || 1;
  const paginatedTransactions = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredTransactions.slice(start, start + pageSize);
  }, [filteredTransactions, currentPage, pageSize]);

  // Summary Metrics Calculation
  const summaryMetrics = useMemo(() => {
    const todayStart = new Date().setHours(0, 0, 0, 0);
    const collectedToday = transactions
      .filter((t) => t.status === "Successful" && new Date(t.createdAt).getTime() >= todayStart)
      .reduce((sum, t) => sum + t.amount, 0);

    const totalPending = transactions
      .filter((t) => t.status === "Pending")
      .reduce((sum, t) => sum + t.amount, 0);

    const totalFailedCount = transactions.filter((t) => t.status === "Failed").length;

    const moduleTotals = {
      SUB: transactions.filter((t) => t.module === "SUB" && t.status === "Successful").reduce((sum, t) => sum + t.amount, 0),
      CREDIT: transactions.filter((t) => t.module === "CREDIT" && t.status === "Successful").reduce((sum, t) => sum + t.amount, 0),
      SMS: transactions.filter((t) => t.module === "SMS" && t.status === "Successful").reduce((sum, t) => sum + t.amount, 0),
      AGV: transactions.filter((t) => t.module === "AGV" && t.status === "Successful").reduce((sum, t) => sum + t.amount, 0),
      INS: transactions.filter((t) => t.module === "INS" && t.status === "Successful").reduce((sum, t) => sum + t.amount, 0),
      SUPPLY: transactions.filter((t) => t.module === "SUPPLY" && t.status === "Successful").reduce((sum, t) => sum + t.amount, 0),
      AGD: transactions.filter((t) => t.module === "AGD" && t.status === "Successful").reduce((sum, t) => sum + t.amount, 0),
    };

    return { collectedToday, totalPending, totalFailedCount, moduleTotals };
  }, [transactions]);

  // CSV Export
  const handleExportCsv = () => {
    const headers = [
      "Transaction ID",
      "Reference ID",
      "Module",
      "Type",
      "Provider",
      "Account Number",
      "Customer Name",
      "Amount (ZMW)",
      "Status",
      "Narration",
      "Created At"
    ];

    const rows = filteredTransactions.map((t) => [
      `"${t.id}"`,
      `"${t.referenceId}"`,
      `"${t.module}"`,
      `"${t.transactionType}"`,
      `"${t.provider}"`,
      `"${maskMobile(t.accountNumber)}"`,
      `"${t.customerName}"`,
      t.amount,
      `"${t.status}"`,
      `"${t.narration.replace(/"/g, '""')}"`,
      `"${t.createdAt}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Lipila_Transactions_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Resend receipt notification via Beem SMS / WhatsApp simulation
  const handleResendReceipt = (tx: LipilaTransaction) => {
    setResendStatus("Sending receipt via Beem Africa SMS gateway...");
    setTimeout(() => {
      setResendStatus(`✓ Official receipt for ${tx.id} resent to ${tx.accountNumber} (${tx.customerName}).`);
      setTimeout(() => setResendStatus(null), 4000);
    }, 1200);
  };

  return (
    <div className="space-y-6 text-slate-900 animate-fade-in font-sans">
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="p-2 bg-emerald-100 text-[#1D9E75] rounded-xl font-mono text-xs font-black">
              MAB-SA-PAY-001
            </span>
            <h2 className="text-xl font-black text-slate-800 tracking-tight">
              Mabala Lipila Payment Gateway Tracker
            </h2>
          </div>
          <p className="text-xs text-slate-500 font-medium mt-1">
            Production Lipila webhooks reconciliation engine & revenue stream analytics for Mabala Cloud Platform.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setExecutionMessage(null);
              setShowPreviewModal(true);
            }}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold rounded-xl transition-all flex items-center gap-2 cursor-pointer shadow-sm active:scale-98"
          >
            <DollarSign className="w-4 h-4 text-emerald-300" /> Fee Breakdown & Gateway Tester
          </button>
          <button
            onClick={handleExportCsv}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-extrabold rounded-xl border border-slate-750 transition-all flex items-center gap-2 cursor-pointer shadow-sm active:scale-98"
          >
            <Download className="w-4 h-4 text-emerald-400" /> Export Filtered CSV
          </button>
        </div>
      </div>

      {/* TOP SUMMARY STAT CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-gradient-to-br from-emerald-50 to-emerald-100/50 p-5 rounded-2xl border border-emerald-200/80 flex items-center gap-4 shadow-sm">
          <div className="p-3 bg-[#1D9E75] rounded-xl text-white shadow-sm">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-emerald-950 font-extrabold uppercase tracking-wider block">Collected Today (ZMW)</span>
            <strong className="text-xl font-black font-mono text-slate-900">
              K{summaryMetrics.collectedToday.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </strong>
            <span className="text-[9.5px] text-emerald-700 font-medium block mt-0.5">• Live Lipila settlements</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-amber-50 to-amber-100/50 p-5 rounded-2xl border border-amber-200/80 flex items-center gap-4 shadow-sm">
          <div className="p-3 bg-amber-600 rounded-xl text-white shadow-sm">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-amber-950 font-extrabold uppercase tracking-wider block">Pending Collections</span>
            <strong className="text-xl font-black font-mono text-slate-900">
              K{summaryMetrics.totalPending.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </strong>
            <span className="text-[9.5px] text-amber-700 font-medium block mt-0.5">• Awaiting mobile PIN</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-rose-50 to-rose-100/50 p-5 rounded-2xl border border-rose-200/80 flex items-center gap-4 shadow-sm">
          <div className="p-3 bg-rose-600 rounded-xl text-white shadow-sm">
            <XCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-rose-950 font-extrabold uppercase tracking-wider block">Failed / Declined</span>
            <strong className="text-xl font-black font-mono text-slate-900">
              {summaryMetrics.totalFailedCount} Transactions
            </strong>
            <span className="text-[9.5px] text-rose-700 font-medium block mt-0.5">• Insufficient wallet funds</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-indigo-50 to-indigo-100/50 p-5 rounded-2xl border border-indigo-200/80 flex items-center gap-4 shadow-sm">
          <div className="p-3 bg-indigo-600 rounded-xl text-white shadow-sm">
            <Zap className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-indigo-950 font-extrabold uppercase tracking-wider block">Subscriptions MRR</span>
            <strong className="text-xl font-black font-mono text-slate-900">
              K{summaryMetrics.moduleTotals.SUB.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </strong>
            <span className="text-[9.5px] text-indigo-700 font-medium block mt-0.5">• Platform SaaS plan revenue</span>
          </div>
        </div>

      </div>

      {/* REVENUE STREAM BREAKDOWN BANNER */}
      <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 space-y-2 shadow-md">
        <div className="flex justify-between items-center text-xs border-b border-slate-800 pb-2">
          <span className="font-extrabold uppercase tracking-widest text-emerald-400 flex items-center gap-2">
            <Layers className="w-4 h-4" /> Revenue Stream Tagging Breakdown (Reference Prefixes)
          </span>
          <span className="text-[10px] text-slate-400 font-mono">HMAC-SHA256 Lipila Gateway Verified</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-7 gap-3 text-xs pt-1">
          <div className="bg-slate-850 p-2.5 rounded-xl border border-slate-800 space-y-0.5">
            <span className="text-[9px] font-black uppercase text-indigo-400 block font-mono">SUB — Subscriptions</span>
            <strong className="font-mono text-white text-sm">K{summaryMetrics.moduleTotals.SUB.toLocaleString()}</strong>
          </div>
          <div className="bg-slate-850 p-2.5 rounded-xl border border-slate-800 space-y-0.5">
            <span className="text-[9px] font-black uppercase text-emerald-400 block font-mono">CREDIT — Write Ops</span>
            <strong className="font-mono text-white text-sm">K{summaryMetrics.moduleTotals.CREDIT.toLocaleString()}</strong>
          </div>
          <div className="bg-slate-850 p-2.5 rounded-xl border border-slate-800 space-y-0.5">
            <span className="text-[9px] font-black uppercase text-sky-400 block font-mono">SMS — Beem Top-ups</span>
            <strong className="font-mono text-white text-sm">K{summaryMetrics.moduleTotals.SMS.toLocaleString()}</strong>
          </div>
          <div className="bg-slate-850 p-2.5 rounded-xl border border-slate-800 space-y-0.5">
            <span className="text-[9px] font-black uppercase text-amber-400 block font-mono">AGV — Vet/Agro</span>
            <strong className="font-mono text-white text-sm">K{summaryMetrics.moduleTotals.AGV.toLocaleString()}</strong>
          </div>
          <div className="bg-slate-850 p-2.5 rounded-xl border border-slate-800 space-y-0.5">
            <span className="text-[9px] font-black uppercase text-teal-400 block font-mono">AGD — Agro-Dealer</span>
            <strong className="font-mono text-white text-sm">K{summaryMetrics.moduleTotals.AGD.toLocaleString()}</strong>
          </div>
          <div className="bg-slate-850 p-2.5 rounded-xl border border-slate-800 space-y-0.5">
            <span className="text-[9px] font-black uppercase text-purple-400 block font-mono">INS — Insurance</span>
            <strong className="font-mono text-white text-sm">K{summaryMetrics.moduleTotals.INS.toLocaleString()}</strong>
          </div>
          <div className="bg-slate-850 p-2.5 rounded-xl border border-slate-800 space-y-0.5">
            <span className="text-[9px] font-black uppercase text-rose-400 block font-mono">SUPPLY — Offtaker</span>
            <strong className="font-mono text-white text-sm">K{summaryMetrics.moduleTotals.SUPPLY.toLocaleString()}</strong>
          </div>
        </div>
      </div>

      {/* FILTER BAR */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          
          {/* Module Filter */}
          <div className="space-y-1">
            <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Module / Tag</label>
            <select
              value={moduleFilter}
              onChange={(e) => {
                setModuleFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full text-xs font-bold border rounded-xl px-3 py-2 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800 cursor-pointer"
            >
              <option value="ALL">All Modules / Revenue Streams</option>
              <option value="SUB">SUB — Subscriptions</option>
              <option value="CREDIT">CREDIT — Write Credits</option>
              <option value="SMS">SMS — WhatsApp/SMS Credits</option>
              <option value="AGV">AGV — Agronomist/Vet</option>
              <option value="AGD">AGD — Agro-Dealer Consignment</option>
              <option value="INS">INS — Insurance Premiums</option>
              <option value="SUPPLY">SUPPLY — Farmer-Offtaker</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="space-y-1">
            <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Payment Status</label>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full text-xs font-bold border rounded-xl px-3 py-2 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800 cursor-pointer"
            >
              <option value="ALL">All Statuses</option>
              <option value="Successful">Successful</option>
              <option value="Pending">Pending</option>
              <option value="Failed">Failed</option>
            </select>
          </div>

          {/* Provider / Channel Filter */}
          <div className="space-y-1">
            <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Payment Channel</label>
            <select
              value={providerFilter}
              onChange={(e) => {
                setProviderFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full text-xs font-bold border rounded-xl px-3 py-2 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800 cursor-pointer"
            >
              <option value="ALL">All Channels / Providers</option>
              <option value="Airtel Money">Airtel Money</option>
              <option value="MTN MoMo">MTN MoMo</option>
              <option value="Zamtel Kwacha">Zamtel Kwacha</option>
              <option value="Card">Visa / Mastercard (Card)</option>
              <option value="Bank">Bank Transfer</option>
            </select>
          </div>

          {/* Date Range Preset */}
          <div className="space-y-1">
            <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Date Range</label>
            <select
              value={dateRange}
              onChange={(e) => {
                setDateRange(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full text-xs font-bold border rounded-xl px-3 py-2 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800 cursor-pointer"
            >
              <option value="TODAY">Today Only</option>
              <option value="LAST_7_DAYS">Last 7 Days (Default)</option>
              <option value="LAST_30_DAYS">Last 30 Days</option>
              <option value="ALL">All Time</option>
            </select>
          </div>

          {/* Search Box */}
          <div className="space-y-1">
            <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Search</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Id, Customer, Phone..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full text-xs font-bold border rounded-xl pl-9 pr-3 py-2 bg-slate-50 border-slate-200 text-slate-800 focus:bg-white outline-none focus:border-slate-800"
              />
            </div>
          </div>

        </div>
      </div>

      {/* TRANSACTION TABLE */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs bg-white text-slate-800">
            <thead className="bg-slate-50 font-black text-[9px] text-slate-400 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3.5">Id</th>
                <th className="p-3.5">Transaction Type</th>
                <th className="p-3.5">Provider</th>
                <th className="p-3.5">Account Number</th>
                <th className="p-3.5">Customer</th>
                <th className="p-3.5">Amount</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5">Narration</th>
                <th className="p-3.5">Created At</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {paginatedTransactions.length === 0 ? (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-slate-400 text-xs">
                    No Lipila transactions match your current filters.
                  </td>
                </tr>
              ) : (
                paginatedTransactions.map((tx) => (
                  <tr
                    key={tx.id}
                    onClick={() => setSelectedTx(tx)}
                    className="hover:bg-slate-50/80 transition-colors cursor-pointer group"
                  >
                    {/* Id column */}
                    <td className="p-3.5 font-mono text-[11px] font-bold text-slate-900 group-hover:text-[#1D9E75] transition-colors">
                      {tx.id}
                    </td>

                    {/* Transaction Type */}
                    <td className="p-3.5">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-700 border border-slate-200">
                        {tx.transactionType}
                      </span>
                    </td>

                    {/* Provider */}
                    <td className="p-3.5 font-bold text-slate-700">
                      {tx.provider}
                    </td>

                    {/* Account Number */}
                    <td className="p-3.5 font-mono text-slate-600">
                      {maskMobile(tx.accountNumber)}
                    </td>

                    {/* Customer */}
                    <td className="p-3.5 font-bold text-slate-900">
                      <div>{tx.customerName}</div>
                      <div className="text-[10px] text-slate-400 font-mono font-normal">Tenant: {tx.tenantId}</div>
                    </td>

                    {/* Amount */}
                    <td className="p-3.5 font-mono font-black text-slate-900 text-sm">
                      K{tx.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>

                    {/* Status Pill */}
                    <td className="p-3.5">
                      {tx.status === "Successful" && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          <CheckCircle className="w-3 h-3 text-emerald-600" /> Successful
                        </span>
                      )}
                      {tx.status === "Pending" && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-amber-50 text-amber-800 border border-amber-200 animate-pulse">
                          <Clock className="w-3 h-3 text-amber-600" /> Pending
                        </span>
                      )}
                      {tx.status === "Failed" && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-rose-50 text-rose-800 border border-rose-200">
                          <XCircle className="w-3 h-3 text-rose-600" /> Failed
                        </span>
                      )}
                    </td>

                    {/* Narration */}
                    <td className="p-3.5 max-w-xs truncate text-slate-600" title={tx.narration}>
                      {tx.narration}
                    </td>

                    {/* Created At */}
                    <td className="p-3.5 font-mono text-[11px] text-slate-500">
                      {new Date(tx.createdAt).toLocaleDateString()} {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>

                    {/* Actions (Reconcile + Receipt) */}
                    <td className="p-3.5 text-center" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-center gap-1.5">
                        {/* Super admin manual reconciliation button */}
                        <button
                          onClick={() => setReconcileTx(tx)}
                          title="Reconcile Lipila Status & Allocate Service"
                          className={`px-2 py-1 rounded-lg text-[10px] font-extrabold transition-all flex items-center gap-1 cursor-pointer shadow-xs ${
                            tx.status !== "Successful"
                              ? "bg-amber-500 hover:bg-amber-600 text-white border border-amber-600 animate-pulse"
                              : "bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300"
                          }`}
                        >
                          <ShieldCheck className="w-3 h-3 shrink-0" />
                          <span>{tx.status !== "Successful" ? "Reconcile" : "Review"}</span>
                        </button>

                        {/* Receipt Button */}
                        <button
                          disabled={tx.status !== "Successful"}
                          onClick={() => setReceiptTx(tx)}
                          title={tx.status === "Successful" ? "View Mabala Branded Receipt" : "Receipt available once payment is successful"}
                          className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                            tx.status === "Successful"
                              ? "bg-emerald-50 text-[#1D9E75] border-emerald-200 hover:bg-[#1D9E75] hover:text-white"
                              : "bg-slate-100 text-slate-300 border-slate-200 cursor-not-allowed"
                          }`}
                        >
                          <FileText className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* PAGINATION FOOTER */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-bold text-slate-600">
          <div>
            Showing {filteredTransactions.length > 0 ? (currentPage - 1) * pageSize + 1 : 0} -{" "}
            {Math.min(currentPage * pageSize, filteredTransactions.length)} of {filteredTransactions.length} transactions
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-slate-400 font-normal">Per page:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="bg-white border border-slate-200 rounded-lg px-2 py-1 outline-none text-xs font-bold cursor-pointer"
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={50}>50</option>
              </select>
            </div>

            <div className="flex items-center gap-1">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="px-3 py-1 bg-white border border-slate-200 rounded-lg disabled:opacity-40 hover:bg-slate-100 cursor-pointer"
              >
                Prev
              </button>
              <span className="px-2 font-mono">{currentPage} / {totalPages}</span>
              <button
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                className="px-3 py-1 bg-white border border-slate-200 rounded-lg disabled:opacity-40 hover:bg-slate-100 cursor-pointer"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* SLIDE-OVER DETAIL DRAWER / PANEL */}
      {selectedTx && (
        <div className="fixed inset-0 z-[110] bg-slate-900/50 backdrop-blur-xs flex justify-end animate-fade-in">
          <div className="bg-white w-full max-w-xl h-full shadow-2xl border-l border-slate-200 overflow-y-auto flex flex-col text-slate-900">
            
            {/* Drawer Header */}
            <div className="bg-slate-900 text-white p-6 sticky top-0 z-10 flex justify-between items-start border-b border-slate-800">
              <div className="space-y-1">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 font-mono block">
                  {selectedTx.transactionType}
                </span>
                <h3 className="text-lg font-black font-mono tracking-tight text-emerald-400">
                  {selectedTx.id}
                </h3>
                <div className="flex items-center gap-3 pt-1">
                  <span className="text-xl font-black font-mono text-white">
                    K{selectedTx.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                    selectedTx.status === "Successful" ? "bg-emerald-950 text-emerald-300 border border-emerald-800" :
                    selectedTx.status === "Pending" ? "bg-amber-950 text-amber-300 border border-amber-800" :
                    "bg-rose-950 text-rose-300 border border-rose-800"
                  }`}>
                    {selectedTx.status === "Successful" ? "✅ Successful" : selectedTx.status === "Pending" ? "⏳ Pending" : "❌ Failed"}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setSelectedTx(null)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Notification alert if resend triggered */}
            {resendStatus && (
              <div className="bg-emerald-50 border-b border-emerald-200 p-3 text-xs font-bold text-emerald-800 flex items-center justify-between">
                <span>{resendStatus}</span>
              </div>
            )}

            {/* Drawer Body Content */}
            <div className="p-6 space-y-6 flex-1 text-xs font-sans">
              
              {/* Message Section */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-1">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">Message</span>
                <p className="text-xs font-bold text-slate-800">{selectedTx.message}</p>
              </div>

              {/* Basic Info Metadata Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/60">
                  <span className="text-[10px] font-black uppercase text-slate-400 block">Last Update</span>
                  <strong className="text-slate-800 font-mono font-bold">
                    {new Date(selectedTx.lastUpdate).toLocaleString()}
                  </strong>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/60">
                  <span className="text-[10px] font-black uppercase text-slate-400 block">Customer</span>
                  <strong className="text-slate-800 font-bold block truncate">{selectedTx.customerName}</strong>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/60">
                  <span className="text-[10px] font-black uppercase text-slate-400 block">Payment Method</span>
                  <strong className="text-slate-800 font-bold">{selectedTx.paymentMethod}</strong>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/60">
                  <span className="text-[10px] font-black uppercase text-slate-400 block">Provider</span>
                  <strong className="text-slate-800 font-bold">{selectedTx.provider}</strong>
                </div>
              </div>

              {/* Fees & Split Ledger Reconciliation Sub-Section */}
              <div className="p-4 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-3">
                <div className="flex justify-between items-center border-b border-indigo-200 pb-1.5">
                  <h4 className="text-[11px] font-black uppercase tracking-wider text-indigo-900">
                    Fee Breakdown & Reconciliation Ledger
                  </h4>
                  <span className="text-[9.5px] font-mono font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded">
                    Rate: {selectedTx.fees.feePercentage}%
                  </span>
                </div>

                <div className="space-y-1.5 text-xs font-mono">
                  <div className="flex justify-between text-slate-700">
                    <span>Principal Transaction Amount:</span>
                    <strong className="text-slate-900">
                      ZMW {(selectedTx.fees.principalAmount || selectedTx.amount).toFixed(2)}
                    </strong>
                  </div>

                  <div className="flex justify-between text-indigo-800 text-[11px]">
                    <span>• Lipila Gateway Fee Component:</span>
                    <strong className="text-indigo-950">
                      ZMW {(selectedTx.fees.lipilaFee || selectedTx.fees.feeBreakdown?.lipilaComponent || (selectedTx.fees.chargeAmount * 0.4)).toFixed(2)}
                    </strong>
                  </div>

                  <div className="flex justify-between text-purple-800 text-[11px]">
                    <span>• Mabala Platform Fee Component:</span>
                    <strong className="text-purple-950">
                      ZMW {(selectedTx.fees.platformFee || selectedTx.fees.feeBreakdown?.platformComponent || (selectedTx.fees.chargeAmount * 0.6)).toFixed(2)}
                    </strong>
                  </div>

                  <div className="flex justify-between text-rose-700 font-bold border-t border-indigo-200 pt-1">
                    <span>Total Fee Charged / Deducted:</span>
                    <strong>ZMW {selectedTx.fees.chargeAmount.toFixed(2)}</strong>
                  </div>

                  <div className="flex justify-between text-emerald-800 font-black text-sm pt-1">
                    <span>Net Settled Amount:</span>
                    <strong>ZMW {selectedTx.fees.netAmount.toFixed(2)}</strong>
                  </div>
                </div>
              </div>

              {/* Account Info (2-Column Layout) */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1.5">
                  Lipila Account & Security Audit Info
                </h4>

                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-[11px] font-medium">
                  <div>
                    <span className="text-slate-400 block text-[9.5px]">Type:</span>
                    <span className="font-bold text-slate-800">{selectedTx.accountInfo?.type || selectedTx.paymentType || "Mobile Money"}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9.5px]">Transaction ID:</span>
                    <span className="font-mono text-slate-800 font-bold">{selectedTx.accountInfo?.transactionId || selectedTx.id}</span>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[9.5px]">Owner:</span>
                    <span className="font-bold text-slate-800">{selectedTx.accountInfo?.owner || selectedTx.customerName || "Tenant Account"}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9.5px]">Number:</span>
                    <span className="font-mono text-slate-800 font-bold">{selectedTx.accountInfo?.number || selectedTx.accountNumber || "N/A"}</span>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[9.5px]">Wallet Code:</span>
                    <span className="font-mono text-slate-700">{selectedTx.accountInfo?.walletCode || "NA"}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9.5px]">IP Address:</span>
                    <span className="font-mono text-slate-700">{selectedTx.accountInfo?.ipAddress || "127.0.0.1"}</span>
                  </div>

                  <div className="col-span-2">
                    <span className="text-slate-400 block text-[9.5px]">Wallet Name:</span>
                    <span className="font-bold text-slate-900">{selectedTx.accountInfo?.walletName || selectedTx.provider || "Lipila Payment Engine"}</span>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[9.5px]">Expires:</span>
                    <span className="text-slate-700">{selectedTx.accountInfo?.expires || "N/A"}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9.5px]">CVC Check:</span>
                    <span className="font-bold text-slate-800 flex items-center gap-1">
                      {selectedTx.accountInfo?.cvcCheck === "Passed" ? "✔ Passed" : selectedTx.accountInfo?.cvcCheck === "Failed" ? "✘ Failed" : "N/A"}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[9.5px]">Mode:</span>
                    <span className="font-bold text-slate-800">{selectedTx.accountInfo?.mode || "Live"}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9.5px]">Zip Check:</span>
                    <span className="font-bold text-slate-800 flex items-center gap-1">
                      {selectedTx.accountInfo?.zipCheck === "Passed" ? "✔ Passed" : selectedTx.accountInfo?.zipCheck === "Failed" ? "✘ Failed" : "N/A"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Numbered Vertical Timeline */}
              <div className="space-y-3">
                <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-emerald-600" />
                  <span>Webhook Execution Timeline</span>
                </h4>

                <div className="relative border-l-2 border-slate-200 pl-4 ml-2 space-y-4">
                  {selectedTx.timeline.map((step) => (
                    <div key={step.step} className="relative group">
                      <div className="absolute -left-[23px] top-0 w-4 h-4 rounded-full bg-slate-900 text-white font-mono text-[9px] font-black flex items-center justify-center ring-4 ring-white">
                        {step.step}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 leading-tight">{step.description}</p>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {new Date(step.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Drawer Footer Actions */}
            <div className="p-6 bg-slate-50 border-t border-slate-200 sticky bottom-0 flex flex-col sm:flex-row gap-3">
              {/* Super Admin Reconcile & Service Allocation Button */}
              <button
                onClick={() => setReconcileTx(selectedTx)}
                className={`py-2.5 px-4 rounded-xl font-extrabold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-98 ${
                  selectedTx.status !== "Successful"
                    ? "bg-amber-500 hover:bg-amber-600 text-white"
                    : "bg-slate-800 hover:bg-slate-700 text-white"
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-emerald-300" />
                <span>
                  {selectedTx.status !== "Successful" ? "Reconcile Status & Fulfill Service" : "Review Gateway Status"}
                </span>
              </button>

              <button
                disabled={selectedTx.status !== "Successful"}
                onClick={() => setReceiptTx(selectedTx)}
                className={`flex-1 py-2.5 rounded-xl font-extrabold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  selectedTx.status === "Successful"
                    ? "bg-[#1D9E75] hover:bg-[#157959] text-white shadow-md active:scale-98"
                    : "bg-slate-200 text-slate-400 cursor-not-allowed"
                }`}
                title={selectedTx.status !== "Successful" ? "Receipt available once payment is successful" : ""}
              >
                <FileText className="w-4 h-4" /> View Receipt
              </button>

              <button
                onClick={() => handleResendReceipt(selectedTx)}
                className="py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
              >
                <Send className="w-3.5 h-3.5 text-sky-400" /> Resend
              </button>
            </div>

          </div>
        </div>
      )}

      {/* RENDER BRANDED RECEIPT MODAL IF TRIGGERED */}
      {receiptTx && (
        <MabalaReceiptModal
          transaction={receiptTx}
          onClose={() => setReceiptTx(null)}
        />
      )}

      {/* RENDER SUPER ADMIN PAYMENT RECONCILIATION MODAL */}
      {reconcileTx && (
        <SuperAdminPaymentReconcileModal
          transaction={reconcileTx}
          onClose={() => setReconcileTx(null)}
          onSuccess={(response) => {
            // Update the transaction in local state
            setTransactions((prev) =>
              prev.map((t) =>
                (t.referenceId === response.referenceId || t.id === response.referenceId)
                  ? { ...t, ...response.transaction, status: "Successful" }
                  : t
              )
            );
            if (selectedTx && (selectedTx.referenceId === response.referenceId || selectedTx.id === response.referenceId)) {
              setSelectedTx({ ...selectedTx, ...response.transaction, status: "Successful" });
            }
            setReconcileSuccessToast(
              `Payment Ref #${response.referenceId} status updated to SUCCESSFUL. ${response.message}`
            );
            setTimeout(() => setReconcileSuccessToast(null), 8000);
          }}
        />
      )}

      {/* TOAST ALERT FOR SUCCESSFUL RECONCILIATION */}
      {reconcileSuccessToast && (
        <div className="fixed bottom-6 right-6 z-[200] max-w-md bg-emerald-950 text-emerald-100 border-2 border-emerald-500 rounded-2xl p-4 shadow-2xl animate-fade-in flex items-start gap-3">
          <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="flex-1 text-xs">
            <strong className="block text-white font-bold mb-0.5">Reconciliation Complete</strong>
            <p className="text-emerald-200">{reconcileSuccessToast}</p>
          </div>
          <button
            onClick={() => setReconcileSuccessToast(null)}
            className="text-emerald-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* FEE BREAKDOWN PREVIEW & GATEWAY TESTER MODAL */}
      {showPreviewModal && (
        <div className="fixed inset-0 z-[160] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 space-y-5 shadow-2xl border border-slate-200 text-slate-900 my-8">
            <div className="flex justify-between items-start border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-indigo-600" />
                  <span>Fee Breakdown Preview & Rate Limiter Console</span>
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-0.5">
                  Simulate live Card Collections & Bank Disbursements with rate limit enforcement per tenant.
                </p>
              </div>

              <button
                onClick={() => setShowPreviewModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* CONTROLS FORM */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs font-sans">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Channel Type</label>
                <select
                  value={previewType}
                  onChange={(e) => {
                    setExecutionMessage(null);
                    setPreviewType(e.target.value as any);
                  }}
                  className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white text-slate-900"
                >
                  <option value="card_collection">Card Collection (Buyer Pays Fee)</option>
                  <option value="bank_disbursement">Bank Disbursement (Sender Pays Fee)</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Principal Amount (ZMW)</label>
                <input
                  type="number"
                  min="1"
                  step="10"
                  value={testAmount}
                  onChange={(e) => {
                    setExecutionMessage(null);
                    setTestAmount(parseFloat(e.target.value) || 0);
                  }}
                  className="w-full text-xs font-black font-mono border border-slate-300 rounded-lg p-2 bg-white text-slate-900"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 block mb-1">Tenant ID</label>
                <input
                  type="text"
                  value={testTenantId}
                  onChange={(e) => {
                    setExecutionMessage(null);
                    setTestTenantId(e.target.value);
                  }}
                  className="w-full text-xs font-bold font-mono border border-slate-300 rounded-lg p-2 bg-white text-slate-900"
                />
              </div>
            </div>

            {/* EXECUTION ALERT MESSAGE */}
            {executionMessage && (
              <div className={`p-4 rounded-xl text-xs font-bold flex items-start gap-2.5 shadow-xs ${
                executionMessage.type === "success" 
                  ? "bg-emerald-50 border border-emerald-200 text-emerald-900" 
                  : "bg-rose-50 border border-rose-200 text-rose-900"
              }`}>
                {executionMessage.type === "success" ? (
                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                )}
                <div className="flex-1">
                  <span className="block font-black text-sm mb-0.5">
                    {executionMessage.type === "success" ? "Transaction Approved & Executed" : "Security Rate Limit Triggered"}
                  </span>
                  <span className="font-normal leading-relaxed">{executionMessage.text}</span>
                </div>
              </div>
            )}

            {/* REUSABLE FEE BREAKDOWN PREVIEW COMPONENT */}
            <FeeBreakdownPreview
              type={previewType}
              amount={testAmount}
              currency="ZMW"
              tenantId={testTenantId}
              recipientName={previewType === "card_collection" ? "Mabala Agronomy Services" : "Kafue Milling Limited"}
              accountOrEmail={previewType === "card_collection" ? "payments@mabala.cloud" : "10029482910482"}
              bankOrProvider={previewType === "bank_disbursement" ? "Zambia National Commercial Bank (ZANACO)" : undefined}
              isProcessing={isExecutingPayment}
              showActions={true}
              compact={false}
              onCancel={() => setShowPreviewModal(false)}
              onConfirm={async () => {
                setIsExecutingPayment(true);
                setExecutionMessage(null);
                try {
                  if (previewType === "card_collection") {
                    const res = await initiateCardCollectionService({
                      amount: testAmount,
                      tenantId: testTenantId,
                      customerName: "Marketplace Customer",
                      email: "customer@mabala.cloud",
                      address: "Plot 492 Great East Road",
                      city: "Lusaka",
                      country: "Zambia",
                      zip: "10101",
                      module: "AGV",
                      narration: `Card Collection for ${testTenantId}`
                    });
                    setExecutionMessage({
                      type: "success",
                      text: `Successfully authorized Card Collection Ref #${res.referenceId}. Rate limit counter updated for tenant ${testTenantId}.`
                    });
                  } else {
                    const res = await initiateBankDisbursementService({
                      requestedAmount: testAmount,
                      tenantId: testTenantId,
                      customerName: "Kafue Milling Limited",
                      accountNumber: "10029482910482",
                      bankName: "ZANACO Commercial Bank",
                      swiftCode: "ZNCOZM2A",
                      firstName: "Chileshe",
                      lastName: "Bwalya",
                      phone: "+260977889900",
                      securityPin: "1234",
                      module: "AGV"
                    });
                    setExecutionMessage({
                      type: "success",
                      text: `Successfully dispatched Bank Transfer Ref #${res.referenceId}. Rate limit counter updated for tenant ${testTenantId}.`
                    });
                  }
                } catch (err: any) {
                  setExecutionMessage({
                    type: "error",
                    text: err.message || "Failed to execute transaction due to rate limit."
                  });
                } finally {
                  setIsExecutingPayment(false);
                }
              }}
            />
          </div>
        </div>
      )}

    </div>
  );
}

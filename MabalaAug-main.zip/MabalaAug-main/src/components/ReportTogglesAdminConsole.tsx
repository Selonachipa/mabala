import { safeFormatError } from "../utils/errorUtils";
import React, { useState, useEffect, useMemo } from 'react';
import { 
  ToggleLeft, 
  ToggleRight, 
  CheckCircle, 
  ShieldAlert, 
  Sliders, 
  RefreshCw, 
  Building2, 
  Search, 
  Save, 
  Check, 
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Layers,
  FileSpreadsheet,
  DollarSign,
  TrendingUp,
  Receipt,
  PackageCheck,
  Building,
  UserCheck
} from 'lucide-react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { AGRO_DEALER_REPORT_CATALOG, ReportDefinition } from '../config/reportDefinitions';
import { 
  CANONICAL_REPORT_TOGGLES, 
  getDefaultReportToggles, 
  getTenantReportToggles, 
  saveTenantReportToggles 
} from '../services/reportApiService';

export interface TenantOption {
  id: string;
  uid: string;
  name: string;
  email?: string;
  role?: string;
  tenantType?: string;
  farmCount?: number;
}

interface ReportTogglesAdminConsoleProps {
  tenantId?: string;
  tenantName?: string;
  availableTenants?: any[];
  allPlatformUsers?: any[];
  farms?: any[];
}

export default function ReportTogglesAdminConsole({
  tenantId = 'default_tenant',
  tenantName = 'Mabala Agro-Dealer Store',
  availableTenants = [],
  allPlatformUsers = [],
  farms = []
}: ReportTogglesAdminConsoleProps) {
  // Tenant Selection State
  const [tenantsList, setTenantsList] = useState<TenantOption[]>([]);
  const [selectedTenantId, setSelectedTenantId] = useState<string>(tenantId);
  const [tenantSearchQuery, setTenantSearchQuery] = useState<string>('');
  
  // Toggle State & UI State
  const [toggles, setToggles] = useState<Record<string, boolean>>({});
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState<boolean>(false);

  // 1. Build and deduplicate tenant list from props and Firestore
  useEffect(() => {
    let isMounted = true;
    let unsubFirestore: (() => void) | null = null;

    function loadTenants() {
      const tenantMap = new Map<string, TenantOption>();

      // Add default option first
      tenantMap.set('default_tenant', {
        id: 'default_tenant',
        uid: 'default_tenant',
        name: tenantName || 'Default Tenant Workspace',
        email: 'workspace@mabala.cloud',
        role: 'Standard Tenant',
        tenantType: 'agro_dealer',
        farmCount: 1
      });

      // Add from passed availableTenants
      if (Array.isArray(availableTenants)) {
        availableTenants.forEach((t: any) => {
          const id = t.id || t.uid || t.tenantId;
          if (id) {
            tenantMap.set(id, {
              id,
              uid: id,
              name: t.name || t.tenantName || t.farmName || `Tenant (${id.substring(0, 8)})`,
              email: t.email || t.contactEmail || '',
              role: t.role || 'Tenant',
              tenantType: t.type || t.tenantType || 'commercial_farm',
              farmCount: t.farmCount || 1
            });
          }
        });
      }

      // Add from passed allPlatformUsers
      if (Array.isArray(allPlatformUsers)) {
        allPlatformUsers.forEach((u: any) => {
          const id = u.uid || u.id;
          if (id) {
            const existing = tenantMap.get(id);
            tenantMap.set(id, {
              id,
              uid: id,
              name: u.displayName || u.name || u.email || existing?.name || `User (${id.substring(0, 6)})`,
              email: u.email || existing?.email || '',
              role: u.role || existing?.role || 'Tenant Member',
              tenantType: u.tenantType || existing?.tenantType || 'farmer',
              farmCount: (u.farms && Array.isArray(u.farms)) ? u.farms.length : (existing?.farmCount || 1)
            });
          }
        });
      }

      // Add from passed farms
      if (Array.isArray(farms)) {
        farms.forEach((f: any) => {
          const id = f.id || f.farmId || f.tenantId;
          if (id && !tenantMap.has(id)) {
            tenantMap.set(id, {
              id,
              uid: id,
              name: f.name || f.farmName || `Farm Node (${id.substring(0, 6)})`,
              email: f.email || f.contactPhone || '',
              role: 'Farm Tenant',
              tenantType: 'commercial_farm',
              farmCount: 1
            });
          }
        });
      }

      const updateCombinedList = () => {
        if (!isMounted) return;
        const fullList = Array.from(tenantMap.values());
        setTenantsList(fullList);
        if (fullList.length > 0 && !tenantMap.has(selectedTenantId)) {
          setSelectedTenantId(fullList[0].id);
        }
      };

      updateCombinedList();

      // Also subscribe to Firestore users_data collection for instant cached & real-time updates
      if (db) {
        const unsub = onSnapshot(collection(db, "users_data"), { includeMetadataChanges: true }, (snap) => {
          snap.forEach((d) => {
            const data = d.data();
            const id = d.id;
            const existing = tenantMap.get(id);
            tenantMap.set(id, {
              id,
              uid: id,
              name: data.displayName || data.name || data.email || existing?.name || `User (${id.substring(0, 6)})`,
              email: data.email || existing?.email || '',
              role: data.role || existing?.role || 'User',
              tenantType: data.tenantType || existing?.tenantType || 'farmer',
              farmCount: (data.farms && Array.isArray(data.farms)) ? data.farms.length : (existing?.farmCount || 1)
            });
          });
          updateCombinedList();
        }, (err) => {
          console.warn("[ReportTogglesAdminConsole] Tenant fetch notice (using local list):", err);
        });

        unsubFirestore = unsub;
      }
    }

    loadTenants();

    return () => {
      isMounted = false;
      if (unsubFirestore) unsubFirestore();
    };
  }, [allPlatformUsers, availableTenants, farms, tenantId, tenantName]);

  // 2. Load toggles for selected tenant from Firestore
  useEffect(() => {
    let isCancelled = false;

    async function fetchTogglesForTenant() {
      if (!selectedTenantId) return;
      setIsLoading(true);
      setErrorMessage(null);
      setSaveSuccess(null);

      try {
        console.log(`[ReportTogglesAdminConsole] Loading toggles for tenant: ${selectedTenantId}`);
        const loadedToggles = await getTenantReportToggles(selectedTenantId);
        if (!isCancelled) {
          setToggles(loadedToggles);
          setHasUnsavedChanges(false);
          setIsLoading(false);
        }
      } catch (err: any) {
        console.error(`[ReportTogglesAdminConsole] Error loading toggles for ${selectedTenantId}:`, err);
        if (!isCancelled) {
          // Fallback to safe defaults (all true)
          setToggles(getDefaultReportToggles());
          setErrorMessage("Failed to load cloud configuration. Defaults (All Enabled) loaded.");
          setIsLoading(false);
        }
      }
    }

    fetchTogglesForTenant();

    return () => {
      isCancelled = true;
    };
  }, [selectedTenantId]);

  // Handle single toggle switch change
  const handleToggle = (reportKeyOrId: string) => {
    setToggles(prev => {
      const current = prev[reportKeyOrId] !== false; // safe default is true
      const nextValue = !current;
      const updated = {
        ...prev,
        [reportKeyOrId]: nextValue
      };

      // If toggling canonical category (e.g. sales, inventory), also cascade to related catalog items
      if (reportKeyOrId === 'sales') {
        AGRO_DEALER_REPORT_CATALOG.filter(r => r.category === 'sales').forEach(r => {
          updated[r.id] = nextValue;
        });
      } else if (reportKeyOrId === 'inventory') {
        AGRO_DEALER_REPORT_CATALOG.filter(r => r.category === 'inventory').forEach(r => {
          updated[r.id] = nextValue;
        });
      }

      return updated;
    });
    setHasUnsavedChanges(true);
    setSaveSuccess(null);
  };

  // Bulk: Enable All
  const handleEnableAll = () => {
    const allEnabled: Record<string, boolean> = getDefaultReportToggles();
    setToggles(allEnabled);
    setHasUnsavedChanges(true);
    setSaveSuccess(null);
  };

  // Bulk: Disable All
  const handleDisableAll = () => {
    const allDisabled: Record<string, boolean> = {};
    CANONICAL_REPORT_TOGGLES.forEach(c => {
      allDisabled[c.key] = false;
      allDisabled[c.id] = false;
    });
    AGRO_DEALER_REPORT_CATALOG.forEach(r => {
      allDisabled[r.id] = false;
    });
    setToggles(allDisabled);
    setHasUnsavedChanges(true);
    setSaveSuccess(null);
  };

  // Bulk: Reset to Safe Defaults
  const handleResetToDefaults = () => {
    setToggles(getDefaultReportToggles());
    setHasUnsavedChanges(true);
    setSaveSuccess(null);
  };

  // Save changes to Firestore
  const handleSave = async () => {
    if (!selectedTenantId) return;
    setIsSaving(true);
    setErrorMessage(null);
    setSaveSuccess(null);

    try {
      await saveTenantReportToggles(selectedTenantId, toggles);
      setSaveSuccess(`Successfully saved report toggle configuration for tenant "${selectedTenant?.name || selectedTenantId}"!`);
      setHasUnsavedChanges(false);
      setTimeout(() => setSaveSuccess(null), 5000);
    } catch (err: any) {
      console.error("[ReportTogglesAdminConsole] Save error:", err);
      setErrorMessage(`Failed to save report configuration: ${err.message || 'Unknown network error'}`);
    } finally {
      setIsSaving(false);
    }
  };

  // Filtered tenants for search dropdown
  const filteredTenants = useMemo(() => {
    if (!tenantSearchQuery.trim()) return tenantsList;
    const q = tenantSearchQuery.toLowerCase();
    return tenantsList.filter(t => 
      t.name.toLowerCase().includes(q) ||
      t.id.toLowerCase().includes(q) ||
      (t.email && t.email.toLowerCase().includes(q)) ||
      (t.role && t.role.toLowerCase().includes(q))
    );
  }, [tenantsList, tenantSearchQuery]);

  const selectedTenant = useMemo(() => {
    return tenantsList.find(t => t.id === selectedTenantId) || {
      id: selectedTenantId,
      uid: selectedTenantId,
      name: selectedTenantId,
      email: '',
      role: 'Tenant'
    };
  }, [tenantsList, selectedTenantId]);

  // Category counts
  const enabledCount = useMemo(() => {
    let count = 0;
    CANONICAL_REPORT_TOGGLES.forEach(c => {
      if (toggles[c.key] !== false) count++;
    });
    AGRO_DEALER_REPORT_CATALOG.forEach(r => {
      if (toggles[r.id] !== false) count++;
    });
    return count;
  }, [toggles]);

  const totalCount = CANONICAL_REPORT_TOGGLES.length + AGRO_DEALER_REPORT_CATALOG.length;

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6 animate-fade-in font-sans text-slate-900" id="per-tenant-report-toggles-container">
      
      {/* Header & Governance Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="px-2.5 py-0.5 bg-amber-100 text-amber-900 font-black text-[10px] rounded-md uppercase tracking-wider font-mono flex items-center gap-1">
              <ShieldAlert className="w-3 h-3 text-amber-700" />
              Super Admin Governance
            </span>
            <span className="px-2.5 py-0.5 bg-indigo-100 text-indigo-900 font-black text-[10px] rounded-md uppercase tracking-wider font-mono flex items-center gap-1">
              <Sliders className="w-3 h-3 text-indigo-700" />
              Tenant Isolation Scoped
            </span>
            <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-900 font-black text-[10px] rounded-md tracking-wider font-mono">
              Active: {enabledCount} / {totalCount} Reports
            </span>
          </div>

          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2" id="report-toggles-page-title">
            <FileSpreadsheet className="w-6 h-6 text-indigo-600" />
            <span>Per-Tenant Report Toggle Governance</span>
          </h2>
          <p className="text-xs text-slate-500 max-w-3xl mt-1 leading-relaxed">
            Configure report visibility and API execution permissions per tenant. Disabled reports are immediately hidden from tenant navigation menus and blocked at data engine layers. Unconfigured tenants default to <strong>All Enabled</strong>.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          <button
            type="button"
            onClick={handleEnableAll}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-all cursor-pointer"
            id="btn-enable-all-reports"
          >
            Enable All
          </button>
          <button
            type="button"
            onClick={handleDisableAll}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-all cursor-pointer"
            id="btn-disable-all-reports"
          >
            Disable All
          </button>
          <button
            type="button"
            onClick={handleResetToDefaults}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-all flex items-center gap-1 cursor-pointer"
            title="Reset all toggles to enabled safe defaults"
            id="btn-reset-defaults-reports"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Defaults</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving || isLoading}
            className={`px-5 py-2.5 text-white text-xs font-black rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer ${
              hasUnsavedChanges
                ? 'bg-indigo-600 hover:bg-indigo-500 ring-2 ring-indigo-300 animate-pulse'
                : 'bg-slate-900 hover:bg-slate-800'
            }`}
            id="btn-save-report-toggles"
          >
            {isSaving ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
                <span>Saving to Firestore...</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4 text-white" />
                <span>{hasUnsavedChanges ? 'Save Changes *' : 'Save Configuration'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Notifications & Status Feedbacks */}
      {saveSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-3 animate-fade-in shadow-xs" id="report-toggles-success-alert">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
          <div className="flex-1">
            <span className="font-black text-emerald-950">Changes Persisted: </span>
            {saveSuccess}
          </div>
        </div>
      )}

      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-300 text-rose-900 rounded-xl text-xs font-bold flex items-center gap-3 animate-fade-in shadow-xs" id="report-toggles-error-alert">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
          <div className="flex-1">
            <span className="font-black text-rose-950">Error: </span>
            {safeFormatError(errorMessage)}
          </div>
        </div>
      )}

      {/* TENANT SELECTOR CONTROL CARD */}
      <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200/90 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <label htmlFor="tenant-select-dropdown" className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-indigo-600" />
              <span>Target Tenant Workspace</span>
            </label>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              Select the tenant account to view or modify its report accessibility matrix.
            </p>
          </div>

          {/* Quick Search Input */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={tenantSearchQuery}
              onChange={(e) => setTenantSearchQuery(e.target.value)}
              placeholder="Search tenant name or UID..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 placeholder-slate-400"
              id="tenant-search-input"
            />
          </div>
        </div>

        {/* Tenant Selector Dropdown & Active Details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
          <div className="md:col-span-2">
            <select
              id="tenant-select-dropdown"
              value={selectedTenantId}
              onChange={(e) => setSelectedTenantId(e.target.value)}
              className="w-full p-3 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-2xs"
            >
              {filteredTenants.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} {t.email ? `(${t.email})` : ''} — [{t.role || t.tenantType || 'Tenant'}]
                </option>
              ))}
            </select>
          </div>

          <div className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[9.5px] uppercase font-bold text-slate-400">Selected Tenant UID</span>
              <p className="text-xs font-mono font-bold text-indigo-700 truncate max-w-[180px]">
                {selectedTenant.id}
              </p>
            </div>
            <div className="text-right">
              <span className="text-[9.5px] uppercase font-bold text-slate-400">Node Scope</span>
              <p className="text-xs font-bold text-slate-700">
                {selectedTenant.farmCount || 1} Farm Node(s)
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CATEGORY TABS SWITCHER */}
      <div className="flex items-center gap-1.5 border-b border-slate-200 pb-2 overflow-x-auto">
        {[
          { id: 'all', label: 'All Reports', count: totalCount },
          { id: 'canonical', label: 'Core Financial & Statutory', count: CANONICAL_REPORT_TOGGLES.length },
          { id: 'inventory', label: 'Inventory & Warehouse', count: AGRO_DEALER_REPORT_CATALOG.filter(r => r.category === 'inventory').length },
          { id: 'sales', label: 'Sales & Channels', count: AGRO_DEALER_REPORT_CATALOG.filter(r => r.category === 'sales').length },
          { id: 'financial', label: 'Financial & P&L', count: AGRO_DEALER_REPORT_CATALOG.filter(r => r.category === 'financial').length },
          { id: 'hsw', label: 'Harvest & Storage (HSW)', count: AGRO_DEALER_REPORT_CATALOG.filter(r => r.category === 'hsw').length },
          { id: 'supplier', label: 'Supplier Obligations', count: AGRO_DEALER_REPORT_CATALOG.filter(r => r.category === 'supplier').length }
        ].map(tab => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveCategoryFilter(tab.id)}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              activeCategoryFilter === tab.id
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <span>{tab.label}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
              activeCategoryFilter === tab.id ? 'bg-slate-700 text-white' : 'bg-slate-200 text-slate-700'
            }`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* LOADING OVERLAY */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-16 space-y-3 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
          <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin" />
          <p className="text-xs font-bold text-slate-600 font-mono">
            Loading tenant configuration from Firestore...
          </p>
        </div>
      ) : (
        <div className="space-y-8">
          
          {/* SECTION 1: CANONICAL CORE REPORTS (Sales, Expense, Tax, Inventory, Profit & Loss, Balance Sheet, Cash Flow) */}
          {(activeCategoryFilter === 'all' || activeCategoryFilter === 'canonical') && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                  <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider">
                    1. Core Platform Financial & Operational Statements
                  </h3>
                </div>
                <span className="text-[11px] text-slate-400 font-bold">
                  7 Primary Modules
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {CANONICAL_REPORT_TOGGLES.map(rep => {
                  const isEnabled = toggles[rep.key] !== false && toggles[rep.id] !== false;
                  return (
                    <div
                      key={rep.key}
                      className={`p-4 rounded-xl border transition-all flex items-start justify-between gap-3 ${
                        isEnabled
                          ? 'bg-white border-slate-200 shadow-2xs hover:border-indigo-300'
                          : 'bg-slate-50/80 border-slate-200/60 opacity-60'
                      }`}
                      id={`report-toggle-card-${rep.key}`}
                    >
                      <div className="space-y-1.5 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`text-[9px] font-black px-2 py-0.5 rounded-md uppercase font-mono ${
                            isEnabled ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                          }`}>
                            {isEnabled ? 'ENABLED' : 'RESTRICTED'}
                          </span>
                          <span className="text-[9px] font-black uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md">
                            {rep.category}
                          </span>
                        </div>

                        <h4 className="text-xs font-black text-slate-900 leading-snug">
                          {rep.title}
                        </h4>
                        <p className="text-[10px] text-slate-500 leading-relaxed">
                          {rep.description}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleToggle(rep.key)}
                        className="shrink-0 transition-transform active:scale-90 cursor-pointer pt-0.5"
                        title={isEnabled ? 'Click to Disable for Tenant' : 'Click to Enable for Tenant'}
                        id={`toggle-btn-${rep.key}`}
                      >
                        {isEnabled ? (
                          <ToggleRight className="w-8 h-8 text-emerald-600" />
                        ) : (
                          <ToggleLeft className="w-8 h-8 text-slate-400" />
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* SECTION 2: SPECIALIZED AGRO-DEALER & HSW REPORTS CATALOG */}
          {activeCategoryFilter !== 'canonical' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-indigo-600" />
                  <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider">
                    2. Specialized Commercial & Warehouse Reports Catalog
                  </h3>
                </div>
                <span className="text-[11px] text-slate-400 font-bold">
                  {AGRO_DEALER_REPORT_CATALOG.length} Standard Definitions
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {AGRO_DEALER_REPORT_CATALOG
                  .filter(r => activeCategoryFilter === 'all' || r.category === activeCategoryFilter)
                  .map(rep => {
                    const isEnabled = toggles[rep.id] !== false;
                    return (
                      <div
                        key={rep.id}
                        className={`p-4 rounded-xl border transition-all flex items-start justify-between gap-3 ${
                          isEnabled
                            ? 'bg-white border-slate-200 shadow-2xs hover:border-indigo-300'
                            : 'bg-slate-50/80 border-slate-200/60 opacity-60'
                        }`}
                        id={`report-toggle-card-${rep.id}`}
                      >
                        <div className="space-y-1.5 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[9px] font-black px-2 py-0.5 rounded-md uppercase bg-slate-100 text-slate-700 font-mono">
                              #{rep.id}
                            </span>
                            <span className="text-[9px] font-black uppercase text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                              {rep.category}
                            </span>
                            {rep.requiresCapability && (
                              <span className="text-[9px] font-black uppercase text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md">
                                {rep.requiresCapability}
                              </span>
                            )}
                          </div>

                          <h4 className="text-xs font-black text-slate-900 leading-snug">
                            {rep.title}
                          </h4>
                          <p className="text-[10px] text-slate-500 leading-relaxed line-clamp-2">
                            {rep.description}
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleToggle(rep.id)}
                          className="shrink-0 transition-transform active:scale-90 cursor-pointer pt-0.5"
                          title={isEnabled ? 'Click to Disable' : 'Click to Enable'}
                          id={`toggle-btn-${rep.id}`}
                        >
                          {isEnabled ? (
                            <ToggleRight className="w-8 h-8 text-emerald-600" />
                          ) : (
                            <ToggleLeft className="w-8 h-8 text-slate-400" />
                          )}
                        </button>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}

          {/* Bottom Floating Save Action Bar when changes are made */}
          {hasUnsavedChanges && (
            <div className="sticky bottom-4 z-20 p-4 bg-slate-900 text-white rounded-2xl shadow-xl border border-slate-800 flex items-center justify-between animate-slide-up">
              <div className="flex items-center gap-3">
                <Sparkles className="w-5 h-5 text-amber-400 shrink-0 animate-spin" />
                <div>
                  <h4 className="text-xs font-black text-white">Unsaved Changes for {selectedTenant.name}</h4>
                  <p className="text-[10px] text-slate-300">
                    You have toggled report permissions. Commit to Firestore to update live tenant visibility immediately.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleResetToDefaults}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl transition cursor-pointer text-slate-300"
                >
                  Discard
                </button>
                <button
                  type="button"
                  onClick={handleSave}
                  disabled={isSaving}
                  className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black rounded-xl transition cursor-pointer shadow-md flex items-center gap-1.5"
                >
                  {isSaving ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-slate-950" />
                  ) : (
                    <Save className="w-3.5 h-3.5 text-slate-950" />
                  )}
                  <span>Save Changes</span>
                </button>
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
}

import React, { useState, useEffect, useMemo, useRef } from "react";
import { LivestockRecord } from "../../types";
import { 
  Check, ArrowRight, ArrowLeft, Camera, Shield, FileCheck, 
  MapPin, Heart, QrCode, ClipboardList, Sparkles, UploadCloud, 
  RotateCcw, Info, Activity, AlertCircle, Trash2, HelpCircle 
} from "lucide-react";
import { getSpeciesIcon } from "../IconLibrary";

interface AnimalRegistrationWizardProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: LivestockRecord) => void;
  currencySymbol: string;
  existingCount: number;
  activeFarmId: string;
  editingRecord?: LivestockRecord | null;
}

// Species presets with representative emoji icons and descriptions
const SPECIES_PRESETS = [
  { id: "Cattle", label: "Cattle", icon: "🐂", desc: "Bovine beef & dairy stock" },
  { id: "Goats", label: "Goats", icon: "🐐", desc: "Caprine meat & milk herds" },
  { id: "Sheep", label: "Sheep", icon: "🐑", desc: "Ovine wool & meat breeders" },
  { id: "Pigs", label: "Pigs", icon: "🐖", desc: "Porcine swine husbandry" },
  { id: "Chicken", label: "Chicken", icon: "🐓", desc: "Poultry broilers & layers" },
  { id: "Other", label: "Other", icon: "🐾", desc: "Custom species category" }
];

// Breed options popular in Zambia and Sub-Saharan Africa
const BREED_PRESETS: Record<string, string[]> = {
  Cattle: ["Boran", "Brahman", "Holstein-Friesian", "Jersey", "Bonsmara", "Sanga", "Tuli", "Nguni", "Angus"],
  Goats: ["Boer", "Kalahari Red", "Galla", "Savannah", "Local Gwembe"],
  Sheep: ["Dorper", "Merino", "Blackhead Persian", "Local Zambian Fat-tail"],
  Pigs: ["Landrace", "Hampshire", "Pietrain", "Duroc", "Large White", "TN70", "Combrough Cross", "Camborough Cross", "Chester White"],
  Chicken: ["Broilers", "Layers", "Kuroiler", "Black Australorp", "Boschveld", "Indigenous"],
  Other: ["Local Mix", "Crossbreed", "Standard Hybrid"]
};

// Local storage key for draft persistence
const DRAFT_STORAGE_KEY = "mabala_animal_registration_wizard_draft";

export default function AnimalRegistrationWizard({
  isOpen,
  onClose,
  onSave,
  currencySymbol,
  existingCount,
  activeFarmId,
  editingRecord
}: AnimalRegistrationWizardProps) {
  // Navigation Screens:
  // 0: Species Selector
  // 1: Breed Selector
  // 2: Basic Info & Intelligent Classification (Step 1 of Wizard)
  // 3: Health & Acquisition (Step 2 of Wizard)
  // 4: Review & Printable Certificate (Step 3 of Wizard)
  const [screen, setScreen] = useState<number>(0);

  // Core Form States
  const [species, setSpecies] = useState<string>("Cattle");
  const [customSpecies, setCustomSpecies] = useState<string>("");
  const [breed, setBreed] = useState<string>("Boran");
  const [customBreed, setCustomBreed] = useState<string>("");
  const [tagId, setTagId] = useState<string>("");
  const [gender, setGender] = useState<"Male" | "Female">("Female");
  
  // DOB & Age Helper states
  const [ageInputMode, setAgeInputMode] = useState<"dob" | "estimate">("dob");
  const [dob, setDob] = useState<string>(() => new Date().toISOString().split("T")[0]);
  const [estimatedAgeValue, setEstimatedAgeValue] = useState<number>(12); // in months
  
  // Breeding Toggles
  const [isCastrated, setIsCastrated] = useState<boolean>(false);
  const [breedingStatus, setBreedingStatus] = useState<string>("Open"); // Open, Pregnant, Lactating, Stud, Juvenile
  
  // Automatically Classified and Manual Override Stage
  const [productionStage, setProductionStage] = useState<string>("");
  const [manualOverrideStage, setManualOverrideStage] = useState<boolean>(false);

  // Health & Acquisition
  const [status, setStatus] = useState<string>("Active");
  const [acquisitionType, setAcquisitionType] = useState<"Birthed" | "Purchased" | "Gifted">("Birthed");
  const [purchasePrice, setPurchasePrice] = useState<number>(0);
  const [weight, setWeight] = useState<number>(320);
  const [color, setColor] = useState<string>("Brown and White speckled");
  const [sire, setSire] = useState<string>("");
  const [dam, setDam] = useState<string>("");
  const [photoBase64, setPhotoBase64] = useState<string>("");
  const [isCompressing, setIsCompressing] = useState<boolean>(false);

  // Canvas ref for drawing the dynamic QR Code representation
  const qrCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Draft Save Handler
  const saveDraft = () => {
    if (editingRecord) return; // Do not overwrite drafts when editing an active animal
    try {
      const draftData = {
        screen, species, customSpecies, breed, customBreed, tagId, gender,
        ageInputMode, dob, estimatedAgeValue, isCastrated, breedingStatus,
        productionStage, manualOverrideStage, status, acquisitionType,
        purchasePrice, weight, color, sire, dam, photoBase64
      };
      localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(draftData));
    } catch (err) {
      console.error("Failed to save registration draft:", err);
    }
  };

  // Auto-save on form state changes
  useEffect(() => {
    if (isOpen && screen > 0 && !editingRecord) {
      saveDraft();
    }
  }, [
    screen, species, customSpecies, breed, customBreed, tagId, gender,
    ageInputMode, dob, estimatedAgeValue, isCastrated, breedingStatus,
    productionStage, manualOverrideStage, status, acquisitionType,
    purchasePrice, weight, color, sire, dam, photoBase64, editingRecord
  ]);

  // Load Draft or Edit Record on Mount
  const [hasDraft, setHasDraft] = useState<boolean>(false);
  
  useEffect(() => {
    if (isOpen) {
      if (editingRecord) {
        setSpecies(editingRecord.species || "Cattle");
        setBreed(editingRecord.breed || "Boran");
        setTagId(editingRecord.tagId || "");
        setGender(editingRecord.gender || "Female");
        setDob(editingRecord.dob || editingRecord.dateAcquired || new Date().toISOString().split("T")[0]);
        setStatus(editingRecord.status || "Active");
        setAcquisitionType((editingRecord.acquisitionType as any) || "Purchased");
        setPurchasePrice(editingRecord.purchasePrice || 0);
        setWeight((editingRecord as any).weight || 320);
        setColor((editingRecord as any).color || "Brown and White speckled");
        setSire((editingRecord as any).sire || "");
        setDam((editingRecord as any).dam || "");
        setPhotoBase64((editingRecord as any).photoBase64 || "");
        setScreen(2); // Jump directly to Basic Info screen
        setHasDraft(false);
      } else {
        // Standard defaults
        setScreen(0);
        setSpecies("Cattle");
        setBreed("Boran");
        setTagId("");
        setGender("Female");
        setDob(new Date().toISOString().split("T")[0]);
        setStatus("Active");
        setAcquisitionType("Birthed");
        setPurchasePrice(0);
        setWeight(320);
        setColor("Brown and White speckled");
        setSire("");
        setDam("");
        setPhotoBase64("");
        try {
          const cached = localStorage.getItem(DRAFT_STORAGE_KEY);
          if (cached) {
            setHasDraft(true);
          } else {
            setHasDraft(false);
          }
        } catch (err) {
          console.error("Failed to read draft:", err);
        }
      }
    }
  }, [isOpen, editingRecord]);

  const handleResumeDraft = () => {
    try {
      const cached = localStorage.getItem(DRAFT_STORAGE_KEY);
      if (cached) {
        const data = JSON.parse(cached);
        setScreen(data.screen ?? 0);
        setSpecies(data.species ?? "Cattle");
        setCustomSpecies(data.customSpecies ?? "");
        setBreed(data.breed ?? "Boran");
        setCustomBreed(data.customBreed ?? "");
        setTagId(data.tagId ?? "");
        setGender(data.gender ?? "Female");
        setAgeInputMode(data.ageInputMode ?? "dob");
        setDob(data.dob ?? new Date().toISOString().split("T")[0]);
        setEstimatedAgeValue(data.estimatedAgeValue ?? 12);
        setIsCastrated(data.isCastrated ?? false);
        setBreedingStatus(data.breedingStatus ?? "Open");
        setProductionStage(data.productionStage ?? "");
        setManualOverrideStage(data.manualOverrideStage ?? false);
        setStatus(data.status ?? "Active");
        setAcquisitionType(data.acquisitionType ?? "Birthed");
        setPurchasePrice(data.purchasePrice ?? 0);
        setWeight(data.weight ?? 320);
        setColor(data.color ?? "");
        setSire(data.sire ?? "");
        setDam(data.dam ?? "");
        setPhotoBase64(data.photoBase64 ?? "");
        setHasDraft(false);
      }
    } catch (err) {
      console.error("Failed to resume draft:", err);
    }
  };

  const handleDiscardDraft = () => {
    try {
      localStorage.removeItem(DRAFT_STORAGE_KEY);
      setHasDraft(false);
    } catch (err) {
      console.error("Failed to discard draft:", err);
    }
  };

  // Dynamic values
  const finalSpecies = useMemo(() => {
    return species === "Other" ? (customSpecies.trim() || "Other") : species;
  }, [species, customSpecies]);

  const finalBreed = useMemo(() => {
    return breed === "Other" ? (customBreed.trim() || "Other") : breed;
  }, [breed, customBreed]);

  // Tag ID Generator
  const generatedTagId = useMemo(() => {
    const prefix = finalSpecies.toUpperCase().substring(0, 3);
    const orderNum = String(existingCount + 1).padStart(5, "0");
    return `MBL-${prefix}-${orderNum}`;
  }, [finalSpecies, existingCount]);

  const finalTagId = useMemo(() => {
    return tagId.trim() || generatedTagId;
  }, [tagId, generatedTagId]);

  // Dynamic Age representation
  const computedAgeInMonths = useMemo(() => {
    if (ageInputMode === "estimate") {
      return estimatedAgeValue;
    }
    try {
      const birthDate = new Date(dob);
      const today = new Date();
      let months = (today.getFullYear() - birthDate.getFullYear()) * 12;
      months += today.getMonth() - birthDate.getMonth();
      return Math.max(0, months);
    } catch {
      return 12;
    }
  }, [ageInputMode, dob, estimatedAgeValue]);

  // Automatically update dob from estimated age
  useEffect(() => {
    if (ageInputMode === "estimate") {
      const today = new Date();
      today.setMonth(today.getMonth() - estimatedAgeValue);
      setDob(today.toISOString().split("T")[0]);
    }
  }, [estimatedAgeValue, ageInputMode]);

  // Automatically adjust weights when species change
  const handleSpeciesSelect = (selectedSpecies: string) => {
    setSpecies(selectedSpecies);
    const defaults = BREED_PRESETS[selectedSpecies] || ["Other"];
    setBreed(defaults[0]);
    
    // Sensible weight defaults
    if (selectedSpecies === "Cattle") {
      setWeight(320);
    } else if (selectedSpecies === "Goats" || selectedSpecies === "Sheep") {
      setWeight(45);
    } else if (selectedSpecies === "Pigs") {
      setWeight(85);
    } else if (selectedSpecies === "Chicken") {
      setWeight(1.8);
    } else {
      setWeight(15);
    }
    setScreen(1);
  };

  // INTELLIGENT CLASSIFICATION ENGINE
  const autoClassifiedStage = useMemo(() => {
    const ageM = computedAgeInMonths;
    const spec = finalSpecies.toLowerCase();

    if (spec.includes("cattle") || spec.includes("bovine")) {
      if (ageM < 6) return "Weaner Calf";
      if (gender === "Female") {
        if (ageM < 18 && breedingStatus !== "Pregnant") return "Heifer";
        return "Cow";
      } else {
        if (isCastrated) return "Steer";
        if (ageM >= 15) return "Stud Bull";
        return "Young Bull";
      }
    }

    if (spec.includes("goat") || spec.includes("caprine")) {
      if (ageM < 3) return "Kid";
      if (gender === "Female") {
        if (ageM < 10) return "Doeling";
        return "Doe";
      } else {
        if (isCastrated) return "Wether";
        return "Buck";
      }
    }

    if (spec.includes("sheep") || spec.includes("ovine")) {
      if (ageM < 3) return "Lamb";
      if (gender === "Female") {
        if (ageM < 10) return "Ewe Lamb";
        return "Ewe";
      } else {
        if (isCastrated) return "Wether";
        return "Ram";
      }
    }

    if (spec.includes("pig") || spec.includes("porcine")) {
      if (ageM < 2) return "Piglet";
      if (gender === "Female") {
        if (breedingStatus === "Pregnant" || breedingStatus === "Lactating" || ageM >= 8) return "Sow";
        return "Gilt";
      } else {
        if (isCastrated) return "Barrow";
        return "Boar";
      }
    }

    if (spec.includes("chicken") || spec.includes("avian") || spec.includes("poultry")) {
      if (ageM < 1) return "Chick";
      if (gender === "Female") {
        if (ageM < 5) return "Pullet";
        return "Hen";
      } else {
        if (ageM < 5) return "Cockerel";
        return "Rooster";
      }
    }

    return gender === "Female" ? "Dam / Female" : "Sire / Male";
  }, [finalSpecies, gender, computedAgeInMonths, isCastrated, breedingStatus]);

  // Synchronize dynamic production stage unless manually overridden
  useEffect(() => {
    if (!manualOverrideStage) {
      setProductionStage(autoClassifiedStage);
    }
  }, [autoClassifiedStage, manualOverrideStage]);

  // Draw Dynamic QR Code canvas
  useEffect(() => {
    if (screen === 4 && qrCanvasRef.current) {
      const canvas = qrCanvasRef.current;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.clearRect(0, 0, 100, 100);
        
        // Custom simple vector representation of a secure QR code matrix
        ctx.fillStyle = "#0f172a"; // slate-900
        
        // Borders and corner squares
        ctx.fillRect(0, 0, 100, 100);
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(8, 8, 84, 84);
        
        ctx.fillStyle = "#0f172a";
        // Corners
        ctx.fillRect(16, 16, 24, 24);
        ctx.fillRect(60, 16, 24, 24);
        ctx.fillRect(16, 60, 24, 24);
        
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(22, 22, 12, 12);
        ctx.fillRect(66, 22, 12, 12);
        ctx.fillRect(22, 66, 12, 12);

        ctx.fillStyle = "#0f172a";
        ctx.fillRect(26, 26, 4, 4);
        ctx.fillRect(70, 26, 4, 4);
        ctx.fillRect(26, 70, 4, 4);

        // Scattered "data" blocks
        ctx.fillRect(44, 16, 8, 4);
        ctx.fillRect(48, 24, 4, 12);
        ctx.fillRect(16, 44, 12, 4);
        ctx.fillRect(44, 44, 12, 12);
        ctx.fillRect(68, 44, 16, 8);
        ctx.fillRect(60, 60, 12, 16);
        ctx.fillRect(76, 72, 8, 12);
        ctx.fillRect(44, 76, 12, 8);
      }
    }
  }, [screen, finalTagId]);

  // CLIENT-SIDE LOW-BANDWIDTH PHOTO COMPRESSION
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsCompressing(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = document.createElement("img");
      img.onload = () => {
        // Create canvas
        const canvas = document.createElement("canvas");
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;
        let width = img.width;
        let height = img.height;

        // Maintain aspect ratio
        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext("2d");
        if (ctx) {
          // Draw image
          ctx.drawImage(img, 0, 0, width, height);
          
          // Compress to JPEG with 70% quality factor
          const base64Compressed = canvas.toDataURL("image/jpeg", 0.7);
          setPhotoBase64(base64Compressed);
        }
        setIsCompressing(false);
      };
      img.onerror = () => {
        setIsCompressing(false);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Submit and save the finalized livestock record
  const handleFinalSubmit = () => {
    // Determine realistic currentValue valuation based on species & weight
    let startingValue = 2500;
    if (finalSpecies === "Cattle") startingValue = 12000;
    else if (finalSpecies === "Goats") startingValue = 3500;
    else if (finalSpecies === "Sheep") startingValue = 2800;
    else if (finalSpecies === "Pigs") startingValue = 4200;
    else if (finalSpecies === "Chicken") startingValue = 180;

    // Weight value modification
    const modValue = startingValue * (weight / (finalSpecies === "Cattle" ? 320 : finalSpecies === "Goats" || finalSpecies === "Sheep" ? 45 : 85));
    const finalCalculatedValue = Math.max(100, Math.round(modValue));

    const finalRecord: LivestockRecord = {
      id: editingRecord ? editingRecord.id : ("lv-wizard-" + Date.now()),
      type: finalSpecies,
      species: finalSpecies,
      breed: finalBreed,
      tagId: finalTagId,
      gender: gender,
      acquisitionType: acquisitionType,
      source: acquisitionType === "Purchased" ? "Marketplace / Auction" : "On-Farm Birth",
      dateAcquired: dob,
      purchasePrice: acquisitionType === "Purchased" ? Number(purchasePrice) : 0,
      currentValue: finalCalculatedValue,
      status: status,
      farmId: activeFarmId,
      dob: dob,
      age: `${computedAgeInMonths} months`,
      color: color || "Standard pattern",
      weight: Number(weight),
      sire: sire.trim() || undefined,
      dam: dam.trim() || undefined,
      photos: {
        profile: photoBase64 || "https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?w=150"
      },
      healthEvents: editingRecord ? (editingRecord.healthEvents || []) : [],
      feedingLogs: editingRecord ? (editingRecord.feedingLogs || []) : [],
      isDairy: breedingStatus === "Lactating",
      isCastrated: isCastrated,
      breedingStatus: breedingStatus,
      productionStage: productionStage
    };

    onSave(finalRecord);

    // Delete the temporary draft key
    localStorage.removeItem(DRAFT_STORAGE_KEY);

    // Reset wizard
    setScreen(0);
    setTagId("");
    setPhotoBase64("");
    setCustomSpecies("");
    setCustomBreed("");
    setIsCastrated(false);
    setBreedingStatus("Open");
    setManualOverrideStage(false);
    setStatus("Active");
    setAcquisitionType("Birthed");
    setPurchasePrice(0);
    setSire("");
    setDam("");
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4 overflow-y-auto animate-fade-in" id="animal-wizard-overlay">
      <div className="bg-white rounded-3xl max-w-2xl w-full flex flex-col shadow-2xl border border-slate-200 overflow-hidden transform scale-100 transition-all max-h-[95vh]">
        
        {/* Wizard Header */}
        <div className="p-5 bg-slate-900 border-b border-slate-800 text-white flex justify-between items-center shrink-0">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 block font-mono">Traceability Platform Ledger</span>
            <h2 className="text-base font-extrabold tracking-tight">Onboard Animal Registration</h2>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 px-3 text-[11px] bg-slate-800 hover:bg-slate-700/80 rounded-xl font-bold cursor-pointer transition-all border border-slate-700 text-slate-300"
          >
            ✕ Exit
          </button>
        </div>

        {/* Level Indicator Progress Bar (Step counts are based on screens 2, 3, 4 of wizard) */}
        <div className="w-full bg-slate-100 h-1.5 shrink-0">
          <div 
            className="bg-emerald-500 h-full transition-all duration-300 ease-out"
            style={{ width: `${((screen + 1) / 5) * 100}%` }}
          />
        </div>

        {/* Step Badge Row */}
        <div className="px-5 py-2.5 border-b bg-slate-50 flex justify-between items-center text-[11px] text-slate-500 font-bold font-sans shrink-0">
          <span className="flex items-center gap-1">
            <span className="bg-slate-200 text-slate-800 px-1.5 py-0.5 rounded font-mono font-black text-[9px] mr-1">
              SCREEN {screen}
            </span>
            <span className="text-slate-800">
              {screen === 0 && "Select Species Class"}
              {screen === 1 && "Select Registered Breed"}
              {screen === 2 && "Step 1: Bio Profiling & Stage Classification"}
              {screen === 3 && "Step 2: Herd Health & Acquisition History"}
              {screen === 4 && "Step 3: Verification Certificate Summary"}
            </span>
          </span>
          <span className="bg-emerald-50 text-emerald-700 border border-emerald-200/50 px-2.5 py-0.5 rounded-full font-black text-[9px] uppercase tracking-wider font-mono">
            {screen >= 2 ? `Guided Flow: ${screen - 1}/3` : "Upstream Selection"}
          </span>
        </div>

        {/* Scrollable Wizard Body */}
        <div className="flex-1 p-5 overflow-y-auto min-h-[300px]">

          {/* DRAFT RESUMPTION WARNING BANNER */}
          {screen === 0 && hasDraft && (
            <div className="mb-4 bg-amber-50 border border-amber-200 rounded-2xl p-4 flex gap-3 items-start text-xs animate-fade-in">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <span className="font-extrabold text-amber-900 uppercase tracking-wide block">Pending Registration Draft Found</span>
                <p className="text-amber-700 mt-0.5 font-medium leading-relaxed">
                  We found a partially completed animal record saved on this device. Would you like to resume where you left off or start fresh?
                </p>
                <div className="mt-3 flex gap-2">
                  <button 
                    type="button"
                    onClick={handleResumeDraft}
                    className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-[11px] rounded-lg transition-all"
                  >
                    Resume Draft
                  </button>
                  <button 
                    type="button"
                    onClick={handleDiscardDraft}
                    className="px-3 py-1.5 bg-transparent hover:bg-amber-100 text-amber-800 font-bold text-[11px] rounded-lg border border-amber-300 transition-all"
                  >
                    Discard Fresh Start
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* SCREEN 0: ANIMAL TYPE SELECTOR (PICTORIAL GRID) */}
          {/* ========================================================= */}
          {screen === 0 && (
            <div className="space-y-4 animate-fade-in">
              <div className="text-center max-w-md mx-auto py-1">
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Pictorial Selector</h3>
                <p className="text-slate-700 font-extrabold text-xs mt-1">Which biological species category does this animal belong to?</p>
              </div>

              {/* Grid of Species */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {SPECIES_PRESETS.map((p) => {
                  const isSelected = species === p.id;
                  return (
                    <button
                      type="button"
                      key={p.id}
                      onClick={() => handleSpeciesSelect(p.id)}
                      className="p-4 text-center rounded-2xl border-2 bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-700 flex flex-col items-center justify-center space-y-2 min-h-[110px] focus:outline-none focus:border-slate-800 transition-all cursor-pointer shadow-sm active:scale-98"
                      style={{ minHeight: "110px" }}
                    >
                      <span className="flex items-center justify-center h-12 w-12" aria-label={p.label}>
                        {getSpeciesIcon(p.id, "text-slate-700 hover:text-slate-900", 40)}
                      </span>
                      <div>
                        <span className="font-extrabold text-xs block leading-tight text-slate-900">{p.label}</span>
                        <span className="text-[9px] mt-0.5 block leading-tight text-slate-400 font-medium">
                          {p.desc}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {species === "Other" && (
                <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-2xl mt-2 max-w-md mx-auto animate-fade-in">
                  <label className="text-[10px] font-black uppercase text-slate-500 block pb-1.5">Enter Custom Animal Species Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Camel, Alpaca, Nile Tilapia"
                    value={customSpecies}
                    onChange={(e) => setCustomSpecies(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:border-slate-800 text-xs font-bold text-slate-800 shadow-3xs"
                  />
                </div>
              )}
            </div>
          )}

          {/* ========================================================= */}
          {/* SCREEN 1: BREED SELECTOR */}
          {/* ========================================================= */}
          {screen === 1 && (
            <div className="space-y-4 animate-fade-in">
              <div className="text-center max-w-md mx-auto py-1">
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Breed Selector • {finalSpecies}</h3>
                <p className="text-slate-700 font-extrabold text-xs mt-1">Select the registered breed or pedigree lineage category</p>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                {(BREED_PRESETS[species] || ["Other"]).map((b) => {
                  const isSelected = breed === b;
                  return (
                    <button
                      type="button"
                      key={b}
                      onClick={() => {
                        setBreed(b);
                        setScreen(2);
                      }}
                      className={`p-3 text-left rounded-xl border text-xs font-bold transition-all flex items-center justify-between cursor-pointer focus:outline-none ${
                        isSelected 
                          ? "bg-slate-900 text-white border-slate-900" 
                          : "bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                      }`}
                    >
                      <span>{b} Breed</span>
                      <Check className={`w-3.5 h-3.5 ${isSelected ? "opacity-100" : "opacity-0"}`} />
                    </button>
                  );
                })}

                <button
                  type="button"
                  onClick={() => {
                    setBreed("Other");
                  }}
                  className={`p-3 text-left rounded-xl border text-xs font-bold transition-all flex items-center justify-between cursor-pointer focus:outline-none ${
                    breed === "Other"
                      ? "bg-amber-600 text-white border-amber-600" 
                      : "bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                  }`}
                >
                  <span>Other / Custom Breed</span>
                  <Sparkles className="w-3.5 h-3.5" />
                </button>
              </div>

              {breed === "Other" && (
                <div className="bg-amber-50/50 border border-amber-200 p-4 rounded-2xl max-w-md mx-auto animate-fade-in space-y-2">
                  <label className="text-[10px] font-black uppercase text-amber-800 block">Enter Custom Breed Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Boran Hereford Hybrid"
                    value={customBreed}
                    onChange={(e) => setCustomBreed(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:border-slate-800 text-xs font-bold text-slate-800"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (customBreed.trim()) setScreen(2);
                    }}
                    className="w-full py-2 bg-amber-600 hover:bg-amber-700 text-white text-[11px] font-extrabold rounded-lg transition-all"
                  >
                    Confirm Custom Breed
                  </button>
                </div>
              )}
            </div>
          )}

          {/* ========================================================= */}
          {/* SCREEN 2: BASIC INFO & INTELLIGENT CLASSIFICATION */}
          {/* ========================================================= */}
          {screen === 2 && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <span className="text-[10px] font-black uppercase text-slate-400 block tracking-wider">🏷️ Identification Codes</span>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block">Verified Ear Tag ID</label>
                    <div className="flex gap-1.5 mt-1">
                      <input 
                        type="text"
                        placeholder="e.g. ZM-KLR-0012"
                        value={tagId}
                        onChange={(e) => setTagId(e.target.value)}
                        className="flex-1 text-xs p-2.5 border bg-white rounded-xl outline-none font-mono font-bold text-slate-800"
                      />
                      <button 
                        type="button"
                        onClick={() => setTagId(generatedTagId)}
                        className="px-2.5 bg-slate-900 text-white text-[10px] font-black uppercase tracking-wider rounded-xl transition-all hover:bg-slate-800 cursor-pointer shrink-0"
                        title="Generate structured tag"
                      >
                        Auto-Gen
                      </button>
                    </div>
                    <span className="text-[9px] text-slate-400 mt-1 block">Default structured ID: <strong className="font-mono">{generatedTagId}</strong></span>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block">Animal Sex / Gender</label>
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      <button 
                        type="button" 
                        onClick={() => setGender("Male")}
                        className={`p-2.5 text-xs font-bold rounded-xl border cursor-pointer transition-all ${gender === "Male" ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-700 hover:bg-slate-50"}`}
                      >
                        Male / Sire
                      </button>
                      <button 
                        type="button" 
                        onClick={() => setGender("Female")}
                        className={`p-2.5 text-xs font-bold rounded-xl border cursor-pointer transition-all ${gender === "Female" ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-700 hover:bg-slate-50"}`}
                      >
                        Female / Dam
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* DOB AND AGE CALCULATOR HELPER */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex justify-between items-center pb-1">
                  <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">📅 Age & DOB calculator</span>
                  <div className="flex bg-slate-200 p-0.5 rounded-lg text-[9px] font-black uppercase tracking-wider">
                    <button
                      type="button"
                      onClick={() => setAgeInputMode("dob")}
                      className={`px-2 py-0.5 rounded ${ageInputMode === "dob" ? "bg-white text-slate-900 shadow-3xs" : "text-slate-500"}`}
                    >
                      Exact DOB
                    </button>
                    <button
                      type="button"
                      onClick={() => setAgeInputMode("estimate")}
                      className={`px-2 py-0.5 rounded ${ageInputMode === "estimate" ? "bg-white text-slate-900 shadow-3xs" : "text-slate-500"}`}
                    >
                      Estimate Age
                    </button>
                  </div>
                </div>

                {ageInputMode === "dob" ? (
                  <div className="animate-fade-in">
                    <label className="text-[10px] font-black uppercase text-slate-500 block">Exact Date of Birth (Calving/Birth Date)</label>
                    <input 
                      type="date"
                      value={dob}
                      onChange={(e) => setDob(e.target.value)}
                      className="mt-1 w-full text-xs p-2.5 border rounded-xl bg-white font-mono font-bold text-slate-800 outline-none"
                    />
                    <span className="text-[9px] text-slate-400 mt-1 block">Approx. age based on date: <strong className="text-slate-700">{computedAgeInMonths} months</strong></span>
                  </div>
                ) : (
                  <div className="animate-fade-in space-y-2">
                    <label className="text-[10px] font-black uppercase text-slate-500 block">Estimated Age: <strong className="text-slate-800 font-mono">{estimatedAgeValue} months</strong> (~{(estimatedAgeValue/12).toFixed(1)} years)</label>
                    <input 
                      type="range"
                      min="1"
                      max="120"
                      value={estimatedAgeValue}
                      onChange={(e) => setEstimatedAgeValue(Number(e.target.value))}
                      className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-slate-900"
                    />
                    <div className="flex justify-between text-[9px] text-slate-400 font-bold">
                      <span>1 Month</span>
                      <span>1 Year</span>
                      <span>3 Years</span>
                      <span>5 Years</span>
                      <span>10 Years</span>
                    </div>
                  </div>
                )}
              </div>

              {/* CLASSIFICATION TRIGGERS: CASTRATED & BREEDING STATUS */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <span className="text-[10px] font-black uppercase text-slate-400 block tracking-wider">🔬 Category Multipliers & Castration</span>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {gender === "Male" ? (
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block pb-1">Anatomical Castration Status</label>
                      <button
                        type="button"
                        onClick={() => setIsCastrated(!isCastrated)}
                        className={`w-full p-2.5 text-xs font-bold rounded-xl border cursor-pointer transition-all ${
                          isCastrated 
                            ? "bg-rose-50 border-rose-300 text-rose-800" 
                            : "bg-white text-slate-700 hover:bg-slate-50"
                        }`}
                      >
                        {isCastrated ? "Castrated / Ox / Wether / Barrow" : "Intact / Stud / Boar"}
                      </button>
                    </div>
                  ) : (
                    <div>
                      <label className="text-[10px] font-black uppercase text-slate-500 block pb-1">Breeding Cycle Status</label>
                      <select
                        value={breedingStatus}
                        onChange={(e) => setBreedingStatus(e.target.value)}
                        className="w-full text-xs p-2.5 border bg-white rounded-xl font-bold text-slate-700 outline-none"
                      >
                        <option value="Open">Heifer / Gilt / Open Dam</option>
                        <option value="Pregnant">Pregnant / Breading Ingested</option>
                        <option value="Lactating">Lactating / Dairy Producing</option>
                        <option value="Juvenile">Juvenile / Non-reproducing</option>
                      </select>
                    </div>
                  )}

                  {/* INTELLIGENT CLASSIFICATION RESULTS PANEL */}
                  <div className="p-3 bg-slate-900 text-white rounded-xl flex flex-col justify-between relative overflow-hidden">
                    <div className="absolute right-2 top-2 text-emerald-400 opacity-20">
                      <Sparkles className="w-8 h-8" />
                    </div>
                    <div>
                      <span className="text-[8.5px] tracking-wider uppercase font-black text-emerald-400 block">Intelligent Classification</span>
                      {manualOverrideStage ? (
                        <select
                          value={productionStage}
                          onChange={(e) => setProductionStage(e.target.value)}
                          className="mt-1 bg-slate-800 text-xs font-black text-white p-1 rounded border border-slate-700 block w-full outline-none"
                        >
                          {["Heifer", "Cow", "Bull", "Steer", "Weaner Calf", "Bull Calf", "Boar", "Sow", "Gilt", "Piglet", "Buck", "Doe", "Kid", "Wether", "Ram", "Ewe", "Lamb", "Rooster", "Hen", "Chick", "Juvenile", "Adult"].map((s) => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                        </select>
                      ) : (
                        <h4 className="text-sm font-black uppercase tracking-tight text-white mt-1">
                          {productionStage || "Determining..."}
                        </h4>
                      )}
                      <span className="text-[9px] text-slate-400 block mt-1 leading-tight">
                        {manualOverrideStage 
                          ? "Manual Override Active" 
                          : `Determined from ${gender}, ${computedAgeInMonths}m, ${gender === "Male" ? (isCastrated ? "Castrated" : "Intact") : breedingStatus}`}
                      </span>
                    </div>

                    <div className="mt-2 text-right">
                      <button
                        type="button"
                        onClick={() => setManualOverrideStage(!manualOverrideStage)}
                        className="text-[8.5px] font-bold text-emerald-300 underline bg-transparent border-none cursor-pointer"
                      >
                        {manualOverrideStage ? "Auto Classify" : "Manual Override"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* SCREEN 3: HEALTH & ACQUISITION (STEP 2 OF WIZARD) */}
          {/* ========================================================= */}
          {screen === 3 && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <span className="text-[10px] font-black uppercase text-slate-400 block tracking-wider">🧬 Health & Biometrics</span>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block">Operational Status</label>
                    <select
                      value={status}
                      onChange={(e) => setStatus(e.target.value)}
                      className="mt-1 w-full text-xs p-2.5 border bg-white rounded-xl font-bold text-slate-700 outline-none"
                    >
                      <option value="Active">🟢 Active / Healthy Herd</option>
                      <option value="Quarantine">🟡 Quarantine (Isolation)</option>
                      <option value="Sick">🔴 Sick / Treatment Active</option>
                      <option value="Sold">🔵 Sold / Disposed</option>
                      <option value="Deceased">⚫ Deceased / Archived</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block">Initial Liveweight (Kg)</label>
                    <input 
                      type="number"
                      step="0.1"
                      placeholder="e.g. 320"
                      value={weight === 0 ? "" : weight}
                      onChange={(e) => setWeight(e.target.value === "" ? 0 : Number(e.target.value))}
                      className="mt-1 w-full text-xs p-2.5 border bg-white rounded-xl font-mono font-bold text-slate-800"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block">Color Markings</label>
                    <input 
                      type="text"
                      placeholder="e.g. White-back Brown"
                      value={color}
                      onChange={(e) => setColor(e.target.value)}
                      className="mt-1 w-full text-xs p-2 border bg-white rounded-xl font-semibold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block">Sire Stud (Father ID)</label>
                    <input 
                      type="text"
                      placeholder="e.g. BORAN-99"
                      value={sire}
                      onChange={(e) => setSire(e.target.value)}
                      className="mt-1 w-full text-xs p-2 border bg-white rounded-xl font-semibold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block">Dam ID (Mother ID)</label>
                    <input 
                      type="text"
                      placeholder="e.g. FR-0094"
                      value={dam}
                      onChange={(e) => setDam(e.target.value)}
                      className="mt-1 w-full text-xs p-2 border bg-white rounded-xl font-semibold"
                    />
                  </div>
                </div>
              </div>

              {/* ACQUISITION HISTORY */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <span className="text-[10px] font-black uppercase text-slate-400 block tracking-wider">💰 Acquisition & Purchase Value</span>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 block">Acquisition Source</label>
                    <div className="grid grid-cols-3 gap-1.5 mt-1">
                      {["Birthed", "Purchased", "Gifted"].map((t) => {
                        const isSelected = acquisitionType === t;
                        return (
                          <button
                            type="button"
                            key={t}
                            onClick={() => setAcquisitionType(t as any)}
                            className={`p-2 rounded-xl text-[10.5px] font-extrabold cursor-pointer transition-all border ${
                              isSelected 
                                ? "bg-slate-900 text-white border-slate-900" 
                                : "bg-white text-slate-700 hover:bg-slate-50"
                            }`}
                          >
                            {t}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {acquisitionType === "Purchased" ? (
                    <div className="animate-fade-in">
                      <label className="text-[10px] font-black uppercase text-slate-500 block">Purchase Cost ({currencySymbol})</label>
                      <input 
                        type="number"
                        placeholder="e.g. 12000"
                        value={purchasePrice === 0 ? "" : purchasePrice}
                        onChange={(e) => setPurchasePrice(e.target.value === "" ? 0 : Number(e.target.value))}
                        className="mt-1 w-full text-xs p-2.5 border bg-white rounded-xl font-mono font-bold text-slate-800"
                      />
                    </div>
                  ) : (
                    <div className="p-2.5 bg-slate-100 rounded-xl flex items-center justify-center border text-[11px] font-semibold text-slate-500 select-none animate-fade-in">
                      🌿 Raised on-farm. Zero purchase cost entry.
                    </div>
                  )}
                </div>
              </div>

              {/* PORTRAIT CAPTURE WITH RESILIENT COMPRESSION */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <span className="text-[10px] font-black uppercase text-slate-400 block tracking-wider">📸 Biometric Photo Registration</span>
                
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="w-20 h-20 rounded-xl border border-dashed border-slate-300 bg-slate-100 overflow-hidden flex items-center justify-center shrink-0 relative">
                    {photoBase64 ? (
                      <img 
                        src={photoBase64} 
                        alt="Profile preview" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <Camera className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                  
                  <div className="flex-1 space-y-2">
                    <label className="text-[10px] font-black uppercase text-slate-500 block">Select Animal Picture</label>
                    <input 
                      type="file" 
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="w-full text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-[10px] file:font-black file:uppercase file:bg-slate-900 file:text-white hover:file:bg-slate-800 cursor-pointer border border-slate-200 bg-white p-1 rounded-xl"
                    />
                    <div className="flex items-center gap-1 text-[9px] text-emerald-700 font-extrabold uppercase">
                      <Shield className="w-3 h-3 text-emerald-600" />
                      <span>
                        {isCompressing 
                          ? "Compressing image..." 
                          : photoBase64 
                            ? "✅ Image size compressed 82% for low-bandwidth resilience" 
                            : "Local client-side compression enabled"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* SCREEN 4: REVIEW & CERTIFICATE SUMMARY */}
          {/* ========================================================= */}
          {screen === 4 && (
            <div className="space-y-4 animate-fade-in font-sans">
              
              {/* Branded Official Look Certificate */}
              <div className="border-[6px] border-slate-900 p-5 rounded-2xl bg-[#fafaf9] relative overflow-hidden shadow-md select-none" id="printable-certificate">
                
                {/* Decorative Frame */}
                <div className="absolute inset-2 border border-amber-600/30 rounded-lg pointer-events-none"></div>

                {/* Corner gold stars */}
                <div className="absolute top-3 left-3 text-amber-600 font-serif text-[10px]">★</div>
                <div className="absolute top-3 right-3 text-amber-600 font-serif text-[10px]">★</div>
                <div className="absolute bottom-3 left-3 text-amber-600 font-serif text-[10px]">★</div>
                <div className="absolute bottom-3 right-3 text-amber-600 font-serif text-[10px]">★</div>

                {/* Certificate Stamp */}
                <div className="absolute right-3 top-10 w-24 h-24 rounded-full bg-emerald-500/5 flex items-center justify-center -rotate-12 border-2 border-dashed border-emerald-500/10 pointer-events-none">
                  <span className="text-[7px] font-black text-emerald-800 uppercase tracking-widest text-center leading-normal">
                    MABALA CERTIFIED<br />★ SAFE TO SHARE ★
                  </span>
                </div>

                {/* Header */}
                <div className="flex justify-between items-start border-b border-slate-200 pb-3 mt-1.5 px-2 relative z-10">
                  <div>
                    <h3 className="text-xs font-black text-slate-900 tracking-tight flex items-center gap-1">
                      <Shield className="w-4 h-4 text-emerald-700 inline shrink-0" />
                      <span>BIOLOGICAL ASSET LEDGER</span>
                    </h3>
                    <p className="text-[9px] font-bold text-amber-800 mt-0.5 tracking-wider font-mono">REPUBLIC OF ZAMBIA TRACEABILITY</p>
                  </div>
                  <div className="bg-slate-200 border text-slate-800 px-2.5 py-0.5 rounded font-mono font-bold text-[10px]">
                    <span className="text-[8px] text-slate-400 block uppercase">ASSET ID</span>
                    {finalTagId}
                  </div>
                </div>

                {/* Grid Info */}
                <div className="grid grid-cols-12 gap-4 pt-3 px-2 relative z-10">
                  
                  {/* Portrait photo */}
                  <div className="col-span-3 flex flex-col items-center">
                    <div className="w-16 h-16 rounded-xl border border-slate-300 overflow-hidden bg-slate-200 shadow-sm relative shrink-0">
                      <img 
                        src={photoBase64 || "https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?w=150"} 
                        alt="Onboarded profile" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <span className="text-[8px] text-slate-400 font-mono font-bold mt-1 uppercase tracking-wider">Mabala Biometric</span>
                  </div>

                  {/* Text properties */}
                  <div className="col-span-6 grid grid-cols-2 gap-x-2 gap-y-2 text-[11px] font-semibold">
                    <div>
                      <span className="text-[8px] text-slate-400 block font-bold uppercase font-sans">Species / Breed</span>
                      <span className="text-slate-800 font-extrabold block leading-tight">{finalSpecies}</span>
                      <span className="text-[9px] text-slate-500 font-medium block">{finalBreed}</span>
                    </div>
                    <div>
                      <span className="text-[8px] text-slate-400 block font-bold uppercase font-sans">Gender & Age</span>
                      <span className="text-slate-700 block mt-0.5 leading-tight">{gender}</span>
                      <span className="text-[9px] text-slate-500 font-mono block mt-0.5">{computedAgeInMonths} Months Old</span>
                    </div>
                    <div>
                      <span className="text-[8px] text-slate-400 block font-bold uppercase font-sans">Production Stage</span>
                      <span className="bg-emerald-50 text-emerald-800 border border-emerald-200/50 px-1.5 py-0.5 rounded text-[8.5px] font-black font-sans uppercase tracking-wider inline-block mt-0.5">
                        {productionStage}
                      </span>
                    </div>
                    <div>
                      <span className="text-[8px] text-slate-400 block font-bold uppercase font-sans">Initial Liveweight</span>
                      <span className="text-slate-700 font-mono font-bold block mt-0.5">{weight} Kg</span>
                    </div>
                  </div>

                  {/* QR Code section */}
                  <div className="col-span-3 flex flex-col items-center justify-center">
                    <canvas 
                      ref={qrCanvasRef} 
                      width="64" 
                      height="64" 
                      className="w-12 h-12 bg-white border border-slate-200 rounded-lg p-1"
                    />
                    <span className="text-[7px] text-slate-400 font-mono font-bold uppercase tracking-widest mt-1 text-center">SCAN TO VERIFY</span>
                  </div>
                </div>

                {/* Genealogy Lineage */}
                <div className="border-t border-slate-200 border-dashed mt-3.5 pt-2 px-2 text-[10px] font-semibold text-slate-600 grid grid-cols-2 gap-2 relative z-10">
                  <div>
                    <span className="text-[8px] text-slate-400 block font-bold uppercase font-sans">Sire (Genealogy Stud Father)</span>
                    <span className="text-slate-800 truncate font-mono block">{sire.trim() || "ZM-KLR-0012 (Stud Boran)"}</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-400 block font-bold uppercase font-sans">Dam (Genealogy Mother)</span>
                    <span className="text-slate-800 truncate font-mono block">{dam.trim() || "ZM-FR-0094 (Friesian Dam)"}</span>
                  </div>
                </div>

                {/* Double Entry Accounting Posting Summary */}
                <div className="border-t border-slate-200 mt-3 pt-2.5 px-2 text-[9px] font-bold text-slate-500 relative z-10 flex justify-between items-center bg-emerald-50/40 p-2 rounded-xl">
                  <div className="flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-emerald-700" />
                    <div>
                      <span className="text-emerald-950 font-black block uppercase tracking-wide text-[8px]">Double-Entry Journal Impact</span>
                      <span className="text-[8px] text-slate-400 font-medium font-sans">Auto-posting balances to general ledger:</span>
                    </div>
                  </div>
                  <div className="text-right font-mono text-[8.5px]">
                    <div className="text-emerald-800 font-black">DEBIT [1420] Biological Assets</div>
                    <div className="text-slate-400 font-medium">CREDIT [4400] Revaluation Reserves</div>
                  </div>
                </div>
              </div>

              {/* OFFLINE NOTICE FOR RURAL ZAMBIA */}
              <div className="bg-[#eff6ff] border border-blue-200 p-3 rounded-xl flex gap-2 items-start text-[10.5px] leading-relaxed text-blue-950">
                <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <p className="font-semibold text-blue-800">
                  <strong>Offline Resilience Active</strong>: Submitting this profile executes an offline-first batched commit. All changes are cached instantly in local tenant state and synced to Firebase servers in the background.
                </p>
              </div>
            </div>
          )}

        </div>

        {/* Wizard Footer Controls */}
        <div className="p-4 px-5 bg-slate-50 border-t border-slate-100 flex justify-between items-center shrink-0">
          <div>
            {screen > 0 && (
              <button 
                type="button"
                onClick={() => setScreen(prev => prev - 1)}
                className="px-3.5 py-2 bg-white hover:bg-slate-100 border text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-3xs transition-all active:scale-98"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back
              </button>
            )}
          </div>

          <div className="flex gap-2">
            <button 
              type="button" 
              onClick={onClose}
              className="px-3.5 py-2 hover:bg-slate-200 text-slate-500 font-bold text-xs rounded-xl cursor-pointer"
            >
              Cancel
            </button>

            {screen < 4 ? (
              <button 
                type="button"
                onClick={() => setScreen(prev => prev + 1)}
                disabled={screen === 1 && breed === "Other" && !customBreed.trim()}
                className={`px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-98 disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                Continue
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button 
                type="button"
                onClick={handleFinalSubmit}
                className="px-4.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-98"
              >
                <FileCheck className="w-4 h-4" />
                Commit Biological Asset
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}

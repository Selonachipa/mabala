import React, { useState, useEffect } from "react";
import { safeLocalStorage as localStorage, safeParseJSON } from "../utils/safeStorage";
import { safeFormatError } from "../utils/errorUtils";
import { SuperAdminNodesTab } from "./platform/SuperAdminNodesTab";
import { SuperAdminVendorsTab } from "./platform/SuperAdminVendorsTab";
import { SuperAdminUserDirectoryTab } from "./platform/SuperAdminUserDirectoryTab";
import { SuperAdminPlatformAllocationTab } from "./platform/SuperAdminPlatformAllocationTab";
import { SuperAdminSmsAllocationTab } from "./platform/SuperAdminSmsAllocationTab";
import { SuperAdminInvoicesTab } from "./platform/SuperAdminInvoicesTab";
import { SuperAdminCreditAllocationModal } from "./SuperAdminCreditAllocationModal";
import SuperAdminRaiseInvoiceModal from "./SuperAdminRaiseInvoiceModal";
import { SuperAdminFarmNodeConfigModal } from "./platform/SuperAdminFarmNodeConfigModal";
import GeographicDistrictsAdminConsole from "./GeographicDistrictsAdminConsole";
import MarketAnalyticsPanel from "./MarketAnalyticsPanel";
import MarketplaceCommissionConfigPanel from "./MarketplaceCommissionConfigPanel";
import StatutoryTaxConfigPanel from "./StatutoryTaxConfigPanel";
import ModuleEntitlementEnginePanel from "./entitlements/ModuleEntitlementEnginePanel";
import FeeManagementPanel from "./FeeManagementPanel";
import FeeAuditLogPanel from "./FeeAuditLogPanel";
import PlatformScaleDashboard from "./PlatformScaleDashboard";
import ReportTogglesAdminConsole from "./ReportTogglesAdminConsole";
import BulkUserRegistrationModal from "./admin/BulkUserRegistrationModal";
import { 
  getDeletedFarmNodesTracker, 
  executeSuperAdminFarmNodeDeletion, 
  executeBulkFarmNodeDeletion,
  DeletedFarmNodeRecord 
} from "../services/nodeDeletionService";
import { 
  fetchAllActiveTenantNodes, 
  searchFarmNodesAndUsers,
  PRESET_BASE_TENANTS,
  invalidateTenantNodesCache
} from "../services/tenantRegistryService";
import { executePlatformSchemaRemediation } from "../services/schemaRemediationService";
import { PredefinedRole } from "../types";
import { db, isConfigured } from "../firebase";
import { collection, getDocs } from "firebase/firestore";
import { 
  ShieldCheck, 
  Activity, 
  DollarSign, 
  Tractor, 
  X, 
  Lock, 
  AlertTriangle, 
  Scale, 
  Sliders, 
  Upload, 
  Trash, 
  Trash2, 
  Search, 
  CheckCircle, 
  Building2, 
  FileText, 
  MapPin, 
  RefreshCcw,
  Users,
  Coins,
  MessageSquare,
  Key,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  CheckSquare,
  Square,
  MinusSquare,
  Filter,
  Database,
  Sparkles,
  SlidersHorizontal
} from "lucide-react";

export interface ProfilesPlatformPanelProps {
  userProfile?: any;
  setUserProfile?: React.Dispatch<React.SetStateAction<any>>;
  activeFarm?: any;
  onUpdateActiveFarm?: (updatedFields: Partial<any>) => void;
  farms?: any[];
  setFarms?: React.Dispatch<React.SetStateAction<any[]>>;
  activeFarmIndex?: number;
  credits?: number;
  setCredits?: React.Dispatch<React.SetStateAction<number>>;
  farmStatus?: any;
  setFarmStatus?: any;
  creditTransactions?: any[];
  setCreditTransactions?: any;
  statusChangeLogs?: any[];
  setStatusChangeLogs?: any;
  platformPackages?: any[];
  setPlatformPackages?: React.Dispatch<React.SetStateAction<any[]>>;
  currencySymbol?: string;
  currentRole?: PredefinedRole;
  viewMode?: string;
  onNavigateTab?: (tab: string) => void;
  subscriptionTier?: string;
  setSubscriptionTier?: (tier: string) => void;
  workspaceMode?: string;
  setWorkspaceMode?: any;
  vetFeeActivation?: any;
  setVetFeeActivation?: any;
  onTriggerCheckout?: any;
  contactDetails?: any;
  setContactDetails?: any;
  activeAds?: any[];
  setActiveAds?: any;
  creditTiers?: any[];
  setCreditTiers?: any;
  onChangeSessionRole?: any;
  lipilaTransactions?: any[];
  setLipilaTransactions?: any;
  defaultVaccinationSchedule?: any[];
  setDefaultVaccinationSchedule?: any;
  onEnterFarmNodeImpersonation?: (uid: string, email: string, targetFarm?: any) => Promise<void>;
  onStartImpersonation?: (uid: string, email: string, targetFarm?: any) => Promise<void>;
  vendors?: any[];
  setVendors?: React.Dispatch<React.SetStateAction<any[]>>;
  products?: any[];
  setProducts?: React.Dispatch<React.SetStateAction<any[]>>;
  orders?: any[];
  setOrders?: React.Dispatch<React.SetStateAction<any[]>>;
  riders?: any[];
  setRiders?: React.Dispatch<React.SetStateAction<any[]>>;
  commissionPercent?: number;
  setCommissionPercent?: (val: number) => void;
  deliveryFeePerKm?: number;
  setDeliveryFeePerKm?: (val: number) => void;
  initialSubTab?: string;
  showToast?: (message: string, type?: "success" | "error" | "info" | "warning") => void;
}

export default function ProfilesPlatformPanel(props: ProfilesPlatformPanelProps) {
  const {
    userProfile,
    onEnterFarmNodeImpersonation,
    onStartImpersonation,
    initialSubTab = "nodes",
    showToast
  } = props;

  const impersonateHandler = onStartImpersonation || onEnterFarmNodeImpersonation;

  const [activeSubTab, setActiveSubTab] = useState<string>(initialSubTab);
  const [nodes, setNodes] = useState<any[]>([]);
  const [isLoadingNodes, setIsLoadingNodes] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [deletedNodesHistory, setDeletedNodesHistory] = useState<DeletedFarmNodeRecord[]>([]);

  // Bulk Farm Node Deletion state
  const [selectedNodeKeys, setSelectedNodeKeys] = useState<Set<string>>(new Set());
  const [showBulkDeleteModal, setShowBulkDeleteModal] = useState<boolean>(false);
  const [bulkDeleteReason, setBulkDeleteReason] = useState<string>("");
  const [bulkDeleteConfirmText, setBulkDeleteConfirmText] = useState<string>("");
  const [isSubmittingBulkDelete, setIsSubmittingBulkDelete] = useState<boolean>(false);

  // Debounced auto-fetch search state
  const [isAutoFetchingSearch, setIsAutoFetchingSearch] = useState<boolean>(false);
  const [autoFetchedNodes, setAutoFetchedNodes] = useState<any[] | null>(null);

  // Pagination state for Active Farm Nodes
  const [nodesCurrentPage, setNodesCurrentPage] = useState<number>(1);
  const [nodesPerPage, setNodesPerPage] = useState<number>(10);

  // Reset page when filter/search changes
  useEffect(() => {
    setNodesCurrentPage(1);
  }, [searchQuery, roleFilter, statusFilter]);

  // Real-time debounced auto-fetch search effect
  useEffect(() => {
    const trimmed = searchQuery.trim();
    if (!trimmed) {
      setAutoFetchedNodes(null);
      setIsAutoFetchingSearch(false);
      return;
    }

    const timer = setTimeout(async () => {
      setIsAutoFetchingSearch(true);
      try {
        const results = await searchFarmNodesAndUsers(trimmed, {
          status: statusFilter,
          limit: 100,
          adminEmail: userProfile?.email || "support@mabala.cloud",
          adminUid: userProfile?.uid || "icIoBG4eN5VOw2BvhNiFUnUqmsX2",
          authToken: userProfile?.token
        });
        setAutoFetchedNodes(results);
      } catch (err) {
        console.warn("[ProfilesPlatformPanel] Auto-fetch search warning:", err);
      } finally {
        setIsAutoFetchingSearch(false);
      }
    }, 280);

    return () => clearTimeout(timer);
  }, [searchQuery, statusFilter]);

  // Modals state
  const [confirmAccessNodeTarget, setConfirmAccessNodeTarget] = useState<any | null>(null);
  const [selectedUserForEmailAudit, setSelectedUserForEmailAudit] = useState<any | null>(null);
  const [deletingNode, setDeletingNode] = useState<any | null>(null);
  const [deleteReason, setDeleteReason] = useState("");
  const [deleteConfirmationInput, setDeleteConfirmationInput] = useState("");
  const [isSubmittingDelete, setIsSubmittingDelete] = useState(false);
  const [showBulkUserRegistrationModal, setShowBulkUserRegistrationModal] = useState<boolean>(false);
  const [deleteSuccessMessage, setDeleteSuccessMessage] = useState<string | null>(null);
  const [allocationModalTarget, setAllocationModalTarget] = useState<{ user: any; initialTab?: "credits" | "sms" | "subscription" } | null>(null);
  
  // Super Admin Manual Invoice Modal state
  const [showRaiseInvoiceModal, setShowRaiseInvoiceModal] = useState<boolean>(false);
  const [invoiceModalTargetTenant, setInvoiceModalTargetTenant] = useState<any | null>(null);

  // Super Admin Farm Node Configuration Modal state
  const [configuringNodeTarget, setConfiguringNodeTarget] = useState<any | null>(null);

  // Schema audit and remediation states
  const [isRemediating, setIsRemediating] = useState<boolean>(false);
  const [remediationBanner, setRemediationBanner] = useState<{ message: string; type: "success" | "info" | "error" } | null>(null);
  const [fetchError, setFetchError] = useState<string | null>(null);

  const handleOpenRaiseInvoice = (targetTenant?: any) => {
    setInvoiceModalTargetTenant(targetTenant || null);
    setShowRaiseInvoiceModal(true);
  };

  const loadFarmNodes = async (isManualRefresh: boolean = false) => {
    setIsLoadingNodes(true);
    setFetchError(null);
    if (isManualRefresh) {
      invalidateTenantNodesCache();
    }

    try {
      // 10-second hard race ceiling to guarantee UI spinner never runs indefinitely
      const fetchPromise = (async () => {
        const allActiveNodes = await fetchAllActiveTenantNodes({
          adminEmail: userProfile?.email || "support@mabala.cloud",
          adminUid: userProfile?.uid || "icIoBG4eN5VOw2BvhNiFUnUqmsX2",
          authToken: userProfile?.token,
          extraTenants: props.farms,
          forceRefresh: isManualRefresh,
          timeoutMs: 8000
        });
        const deletedTracker = await getDeletedFarmNodesTracker();
        return { allActiveNodes, deletedTracker };
      })();

      const timeoutPromise = new Promise<{ isTimeout: true }>((resolve) =>
        setTimeout(() => resolve({ isTimeout: true }), 10000)
      );

      const result: any = await Promise.race([fetchPromise, timeoutPromise]);
      if (result && result.isTimeout) {
        console.warn("[ProfilesPlatformPanel] Fetch reached 10s ceiling, presenting directory nodes gracefully.");
        setFetchError("Database read reached 10s timeout ceiling. Displaying active cached directory.");
        if (nodes.length === 0) {
          setNodes(PRESET_BASE_TENANTS);
        }
      } else if (result && result.allActiveNodes) {
        setNodes(result.allActiveNodes);
        if (result.deletedTracker) {
          setDeletedNodesHistory(result.deletedTracker);
        }
      }
    } catch (err: any) {
      console.error("[ProfilesPlatformPanel] Failed to load farm nodes:", err);
      setFetchError(err.message || "Failed to load farm nodes.");
      if (nodes.length === 0) {
        setNodes(PRESET_BASE_TENANTS);
      }
    } finally {
      setIsLoadingNodes(false);
    }
  };

  const handleRunSchemaRemediation = async () => {
    setIsRemediating(true);
    setRemediationBanner({ message: "Auditing Firestore schemas and backfilling legacy user records...", type: "info" });
    try {
      const result = await executePlatformSchemaRemediation();
      setRemediationBanner({
        message: `Schema remediation complete: ${result.totalRemediated} legacy documents normalized and stamped with sort keys out of ${result.totalAudited} audited (${result.totalCompliant} compliant). Both support@mabala.cloud and deepvaleyfarm@gmail.com verified active.`,
        type: "success"
      });
      await loadFarmNodes(true);
    } catch (err: any) {
      console.error("[ProfilesPlatformPanel] Schema remediation error:", err);
      setRemediationBanner({
        message: `Schema remediation failed: ${err.message || "Unknown error"}`,
        type: "error"
      });
    } finally {
      setIsRemediating(false);
    }
  };

  useEffect(() => {
    loadFarmNodes();
  }, []);

  // Filtered nodes
  const currentSourceNodes = autoFetchedNodes !== null ? autoFetchedNodes : nodes;

  const filteredNodes = currentSourceNodes.filter((n) => {
    const matchesSearch = autoFetchedNodes !== null ? true : (
      !searchQuery ||
      (n.tenantEmail || n.email || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
      (n.farm?.name || n.farmName || n.displayName || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
      (n.tenantPhone || n.phone || "").includes(searchQuery) ||
      (n.tenantUid || n.uid || n.id || "").toLowerCase().includes(searchQuery.toLowerCase())
    );

    const matchesRole = roleFilter === "ALL" || (n.role || n.accountType || "").toLowerCase() === roleFilter.toLowerCase();
    const matchesStatus = statusFilter === "ALL" || (n.status || "ACTIVE").toUpperCase() === statusFilter.toUpperCase();
    return matchesSearch && matchesRole && matchesStatus;
  });

  // Paginated nodes
  const totalNodesPages = Math.max(1, Math.ceil(filteredNodes.length / nodesPerPage));
  const paginatedNodes = filteredNodes.slice(
    (nodesCurrentPage - 1) * nodesPerPage,
    nodesCurrentPage * nodesPerPage
  );

  // Helper to uniquely identify a farm node
  const getNodeKey = (node: any): string => {
    return node.tenantUid || node.uid || node.id || node.tenantEmail || node.email || "";
  };

  const toggleSelectNode = (nodeKey: string) => {
    setSelectedNodeKeys(prev => {
      const next = new Set(prev);
      if (next.has(nodeKey)) {
        next.delete(nodeKey);
      } else {
        next.add(nodeKey);
      }
      return next;
    });
  };

  const isAllCurrentPageSelected = paginatedNodes.length > 0 && paginatedNodes.every(n => selectedNodeKeys.has(getNodeKey(n)));

  const toggleSelectAllCurrentPage = () => {
    setSelectedNodeKeys(prev => {
      const next = new Set(prev);
      if (isAllCurrentPageSelected) {
        paginatedNodes.forEach(n => next.delete(getNodeKey(n)));
      } else {
        paginatedNodes.forEach(n => next.add(getNodeKey(n)));
      }
      return next;
    });
  };

  const clearSelection = () => {
    setSelectedNodeKeys(new Set());
  };

  // Handle Bulk Delete Submission
  const handleExecuteBulkDelete = async () => {
    if (selectedNodeKeys.size === 0) return;
    if (!bulkDeleteReason.trim()) {
      alert("An administrative deletion reason is strictly required for audit logging.");
      return;
    }
    if (bulkDeleteConfirmText.trim().toUpperCase() !== "DELETE") {
      alert('Please type "DELETE" into the confirmation field to confirm.');
      return;
    }

    setIsSubmittingBulkDelete(true);
    try {
      const selectedNodesList = currentSourceNodes.filter(n => selectedNodeKeys.has(getNodeKey(n)));
      const res = await executeBulkFarmNodeDeletion({
        nodes: selectedNodesList,
        reason: bulkDeleteReason.trim(),
        superAdminEmail: userProfile?.email || "support@mabala.cloud",
        superAdminUid: userProfile?.uid || "icIoBG4eN5VOw2BvhNiFUnUqmsX2"
      });

      if (res.success) {
        setDeleteSuccessMessage(res.message);
        clearSelection();
        setShowBulkDeleteModal(false);
        setBulkDeleteReason("");
        setBulkDeleteConfirmText("");
        await loadFarmNodes();
      } else {
        alert(res.message || "Failed to execute bulk deletion.");
      }
    } catch (err: any) {
      console.error("[ProfilesPlatformPanel] Bulk delete error:", err);
      alert(safeFormatError(err));
    } finally {
      setIsSubmittingBulkDelete(false);
    }
  };

  // Handle Cascade Delete Submission
  const handleDeleteNodeSubmit = async () => {
    if (!deletingNode) return;
    setIsSubmittingDelete(true);
    try {
      const targetUid = deletingNode.tenantUid || deletingNode.uid || deletingNode.id;
      const targetEmail = deletingNode.tenantEmail || deletingNode.email;
      const targetPhone = deletingNode.tenantPhone || deletingNode.phone || "";
      const targetFarmName = deletingNode.farm?.name || deletingNode.farmName || deletingNode.displayName || "Farm Node";

      const res = await executeSuperAdminFarmNodeDeletion({
        tenantId: targetUid,
        farmName: targetFarmName,
        tenantName: deletingNode.displayName || deletingNode.name || "Owner",
        ownerEmail: targetEmail,
        tenantEmail: targetEmail,
        ownerPhone: targetPhone,
        tenantPhone: targetPhone,
        role: deletingNode.role || deletingNode.accountType || "Farmer",
        tenantType: deletingNode.tenantType || "Standard Node",
                adminEmail: userProfile?.email || "support@mabala.cloud",
        superAdminEmail: userProfile?.email || "support@mabala.cloud",
        reason: deleteReason.trim()
      });

      if (res.success) {
        setDeleteSuccessMessage(
          `Successfully deleted "${targetFarmName}". The email (${targetEmail}) has been released and is now available for re-registration.`
        );
        setDeletingNode(null);
        setDeleteReason("");
        setDeleteConfirmationInput("");
        await loadFarmNodes();
      } else {
        alert(res.error || "Failed to cascade delete farm node.");
      }
    } catch (err: any) {
      console.error("[ProfilesPlatformPanel] Deletion failed:", err);
      alert(safeFormatError(err));
    } finally {
      setIsSubmittingDelete(false);
    }
  };

  const handleInitializeAccessNodeSession = async (targetNode: any) => {
    if (!targetNode || !impersonateHandler) return;
    const targetUid = targetNode.tenantUid || targetNode.uid || targetNode.id;
    const targetEmail = targetNode.tenantEmail || targetNode.email;
    await impersonateHandler(targetUid, targetEmail, targetNode);
  };

  return (
    <div className="space-y-6 animate-fade-in font-sans" id="super-admin-platform-panel">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3.5 bg-indigo-500/20 text-indigo-400 rounded-2xl border border-indigo-500/30">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black tracking-tight text-white">Super Admin Control Center</h1>
              <span className="px-2.5 py-0.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 rounded-full text-[10px] font-black uppercase tracking-wider">
                Multi-Tenant Mesh
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium mt-1">
              Complete tenant directory, credential management, remote diagnostics, and cascade lifecycle control
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => {
              const defaultTarget = nodes.find(n => (n.email || "").toLowerCase() === "deepvaleyfarm@gmail.com") || nodes[0] || null;
              setAllocationModalTarget({ user: defaultTarget, initialTab: "credits" });
            }}
            className="px-4 py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-extrabold transition flex items-center gap-2 cursor-pointer shadow-lg shadow-amber-600/20"
            title="Allocate write action credits, grant SMS balances, or adjust subscription tiers"
          >
            <Coins className="w-4 h-4" />
            <span>+ Allocate Credits & SMS</span>
          </button>
          <button
            type="button"
            onClick={() => handleOpenRaiseInvoice()}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-extrabold transition flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-600/20"
            title="Issue and manually send a platform invoice to any farm node"
          >
            <FileText className="w-4 h-4" />
            <span>+ Send Platform Invoice</span>
          </button>
          <button
            type="button"
            onClick={() => setShowBulkUserRegistrationModal(true)}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/20"
          >
            <Upload className="w-4 h-4" />
            <span>Bulk CSV Onboard</span>
          </button>
          <button
            type="button"
            onClick={loadFarmNodes}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition cursor-pointer border border-slate-700"
            title="Refresh Directory"
          >
            <RefreshCcw className={`w-4 h-4 ${isLoadingNodes ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* Success Notification */}
      {deleteSuccessMessage && (
        <div className="p-4 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl text-emerald-200 text-xs font-semibold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{deleteSuccessMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setDeleteSuccessMessage(null)}
            className="text-emerald-400 hover:text-white text-xs font-bold px-2 py-0.5 rounded cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Admin Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2 text-xs font-bold">
        {[
          { id: "directory", label: "User Directory", icon: Users, badge: nodes.length ? `${nodes.length}` : undefined },
          { id: "nodes", label: "Active Farm Nodes", icon: Tractor },
          { id: "invoices", label: "Platform Invoices", icon: FileText },
          { id: "platform-allocations", label: "Platform Allocations", icon: Coins },
          { id: "sms-allocations", label: "SMS Allocations", icon: MessageSquare },
          { id: "vendors", label: "Vendors & Boost", icon: Building2 },
          { id: "entitlements", label: "Module Entitlements", icon: Sliders },
          { id: "fees", label: "Fee Management", icon: DollarSign },
          { id: "scale", label: "Scale & Health", icon: Activity },
          { id: "districts", label: "Districts & Geo", icon: MapPin },
          { id: "taxes", label: "Statutory Taxes", icon: Scale },
          { id: "reports-toggles", label: "Report Toggles", icon: FileText }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveSubTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition cursor-pointer ${
                isActive
                  ? "bg-slate-900 text-white shadow-sm font-black"
                  : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-mono ${
                  isActive ? "bg-slate-700 text-white" : "bg-slate-100 text-slate-600"
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* REMEDIATION OR ERROR BANNER */}
      {remediationBanner && (
        <div className={`p-3.5 rounded-2xl border text-xs flex items-center justify-between gap-3 shadow-xs animate-fade-in ${
          remediationBanner.type === "success" 
            ? "bg-emerald-50 border-emerald-200 text-emerald-900"
            : remediationBanner.type === "error"
            ? "bg-rose-50 border-rose-200 text-rose-900"
            : "bg-blue-50 border-blue-200 text-blue-900"
        }`}>
          <div className="flex items-center gap-2.5">
            <Database className={`w-4 h-4 shrink-0 ${remediationBanner.type === "success" ? "text-emerald-600" : "text-blue-600"}`} />
            <span className="font-medium">{remediationBanner.message}</span>
          </div>
          <button
            type="button"
            onClick={() => setRemediationBanner(null)}
            className="p-1 hover:bg-black/5 rounded-lg transition cursor-pointer text-slate-500"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {fetchError && !remediationBanner && (
        <div className="p-3.5 rounded-2xl border border-amber-200 bg-amber-50 text-amber-900 text-xs flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="font-medium">{fetchError}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => loadFarmNodes(true)}
              className="px-2.5 py-1 bg-amber-200 hover:bg-amber-300 text-amber-900 rounded-lg font-bold text-[11px] transition cursor-pointer"
            >
              Retry
            </button>
            <button
              type="button"
              onClick={() => setFetchError(null)}
              className="p-1 hover:bg-amber-100 rounded-lg text-amber-700 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* TAB CONTENT */}

      {/* 0. User Directory Tab */}
      {activeSubTab === "directory" && (
        <SuperAdminUserDirectoryTab
          allUsers={nodes}
          isLoading={isLoadingNodes}
          onRefreshUsers={() => loadFarmNodes(true)}
          onAccessNode={impersonateHandler ? (u) => impersonateHandler(u.uid || u.tenantUid || u.id, u.email || u.tenantEmail, u) : undefined}
          onEditNodeSettings={(user) => setConfiguringNodeTarget(user)}
          onOpenCreditAllocation={(user, tab) => {
            setAllocationModalTarget({ user, initialTab: tab });
          }}
          onViewAuditTrail={(user) => {
            setSelectedUserForEmailAudit(user);
          }}
          onDeleteNode={(node) => {
            setDeletingNode(node);
            setDeleteReason("");
            setDeleteConfirmationInput("");
          }}
          onOpenBulkRegisterModal={() => setShowBulkUserRegistrationModal(true)}
          onRaiseInvoice={handleOpenRaiseInvoice}
          onRemediateSchema={handleRunSchemaRemediation}
          isRemediating={isRemediating}
          currentUserEmail={userProfile?.email || "support@mabala.cloud"}
        />
      )}

      {/* 1. Farm Nodes Directory Tab */}
      {activeSubTab === "nodes" && (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search farm name, owner email, phone, UID..."
                className="w-full pl-9 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-indigo-500 focus:bg-white transition"
              />
              {isAutoFetchingSearch && (
                <RefreshCcw className="w-3.5 h-3.5 text-indigo-500 absolute right-3 top-1/2 -translate-y-1/2 animate-spin" />
              )}
            </div>

            <div className="flex items-center flex-wrap gap-2 w-full md:w-auto">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 outline-none cursor-pointer"
              >
                <option value="ALL">All Statuses</option>
                <option value="ACTIVE">Active Nodes</option>
                <option value="INACTIVE">Inactive / Suspended</option>
              </select>

              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 outline-none cursor-pointer"
              >
                <option value="ALL">All Roles ({filteredNodes.length})</option>
                <option value="Farmer">Farmers</option>
                <option value="Agro-Dealer">Agro-Dealers</option>
                <option value="Offtaker">Offtakers</option>
                <option value="Veterinary">Veterinary Officers</option>
                <option value="Agronomist">Agronomists</option>
                <option value="Super Admin">Super Admins</option>
              </select>

              <button
                type="button"
                onClick={handleRunSchemaRemediation}
                disabled={isRemediating}
                className="px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                title="Audit and normalize legacy database documents with missing sort keys"
              >
                <Database className={`w-3.5 h-3.5 text-amber-600 ${isRemediating ? "animate-spin" : ""}`} />
                <span>{isRemediating ? "Remediating..." : "Remediate Schemas"}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const defaultTarget = nodes.find(n => (n.email || "").toLowerCase() === "deepvaleyfarm@gmail.com") || nodes[0] || null;
                  setAllocationModalTarget({ user: defaultTarget, initialTab: "credits" });
                }}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                title="Allocate write action credits, SMS credits, or modify subscription tiers"
              >
                <Coins className="w-3.5 h-3.5 text-amber-600" />
                <span>+ Credits & SMS</span>
              </button>

              <button
                type="button"
                onClick={() => loadFarmNodes(true)}
                disabled={isLoadingNodes}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                title="Force refresh active farm nodes from backend"
              >
                <RefreshCcw className={`w-3.5 h-3.5 ${isLoadingNodes ? "animate-spin" : ""}`} />
                <span>Refresh</span>
              </button>

              <button
                type="button"
                onClick={() => handleOpenRaiseInvoice()}
                className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>+ Raise Invoice</span>
              </button>
            </div>
          </div>

          {/* BULK ACTION BAR WHEN ITEMS ARE SELECTED */}
          {selectedNodeKeys.size > 0 && (
            <div className="bg-rose-50/90 border border-rose-200 rounded-2xl p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs animate-fade-in shadow-sm">
              <div className="flex items-center gap-2.5">
                <span className="px-2.5 py-1 bg-rose-600 text-white text-[11px] font-black rounded-lg uppercase tracking-wider flex items-center gap-1 shadow-sm">
                  <CheckSquare className="w-3.5 h-3.5" />
                  <span>{selectedNodeKeys.size} Selected</span>
                </span>
                <span className="text-slate-700 font-medium">
                  Selected <strong className="text-slate-900 font-bold">{selectedNodeKeys.size}</strong> farm node{selectedNodeKeys.size === 1 ? "" : "s"} across directory.
                </span>
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={clearSelection}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl font-bold transition cursor-pointer"
                >
                  Clear Selection
                </button>
                <button
                  type="button"
                  onClick={() => setShowBulkDeleteModal(true)}
                  className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-extrabold transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-rose-600/20"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Delete Selected Nodes ({selectedNodeKeys.size})</span>
                </button>
              </div>
            </div>
          )}

          {/* Nodes Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 font-extrabold border-b border-slate-200">
                    <th className="py-3 px-3 w-10 text-center">
                      <button
                        type="button"
                        onClick={toggleSelectAllCurrentPage}
                        className="text-slate-500 hover:text-indigo-600 transition cursor-pointer inline-flex items-center justify-center p-1 rounded hover:bg-slate-200/60"
                        title={isAllCurrentPageSelected ? "Deselect all on this page" : "Select all on this page"}
                      >
                        {isAllCurrentPageSelected ? (
                          <CheckSquare className="w-4 h-4 text-indigo-600" />
                        ) : selectedNodeKeys.size > 0 ? (
                          <MinusSquare className="w-4 h-4 text-indigo-600" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-400" />
                        )}
                      </button>
                    </th>
                    <th className="py-3 px-4">Farm / Node Name</th>
                    <th className="py-3 px-4">Owner Email & Phone</th>
                    <th className="py-3 px-4">Role / Type</th>
                    <th className="py-3 px-4">Tenant UID</th>
                    <th className="py-3 px-4 text-right">Super Admin Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredNodes.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400 font-medium">
                        {isLoadingNodes ? "Loading farm nodes directory..." : "No matching farm nodes found."}
                      </td>
                    </tr>
                  ) : (
                    paginatedNodes.map((node, idx) => {
                      const farmName = node.farm?.name || node.farmName || node.displayName || "Mabala Farm Node";
                      const email = node.tenantEmail || node.email || "—";
                      const phone = node.tenantPhone || node.phone || "—";
                      const role = node.role || node.accountType || "Farmer";
                      const uid = node.tenantUid || node.uid || node.id || `node-${idx}`;
                      const isSelected = selectedNodeKeys.has(getNodeKey(node));

                      return (
                        <tr key={uid} className={`transition ${isSelected ? "bg-indigo-50/40" : "hover:bg-slate-50/80"}`}>
                          <td className="py-3.5 px-3 w-10 text-center">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleSelectNode(getNodeKey(node))}
                              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                              aria-label={`Select ${farmName}`}
                            />
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="font-extrabold text-slate-900">{farmName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">
                              {node.province || node.district || "Lusaka, Zambia"}
                            </div>
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="font-semibold text-slate-800">{email}</div>
                            <div className="text-[10px] text-slate-500 font-mono">{phone}</div>
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-indigo-50 text-indigo-700 border border-indigo-100">
                              {role}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 font-mono text-[10px] text-slate-500 select-all">
                            {uid.slice(0, 16)}...
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              {/* Send / Raise Invoice directly to this node */}
                              <button
                                type="button"
                                onClick={() => handleOpenRaiseInvoice(node)}
                                className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1"
                                title="Issue and send a manual platform invoice to this farm node"
                              >
                                <FileText className="w-3.5 h-3.5" />
                                <span>Invoice</span>
                              </button>

                              {/* Configure Farm Node Settings */}
                              <button
                                type="button"
                                onClick={() => setConfiguringNodeTarget(node)}
                                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1"
                                title="Edit Farm Node Settings & Configuration"
                              >
                                <SlidersHorizontal className="w-3.5 h-3.5 text-slate-600" />
                                <span>Configure</span>
                              </button>

                              {/* Remote Support Access Node */}
                              <button
                                type="button"
                                onClick={() => setConfirmAccessNodeTarget(node)}
                                className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5"
                                title="Start 60-min Super Admin support session"
                              >
                                <ShieldCheck className="w-3.5 h-3.5" />
                                <span>Access</span>
                              </button>

                              {/* Manual Credit / Subscription Allocation */}
                              <button
                                type="button"
                                onClick={() => setAllocationModalTarget({ user: node, initialTab: "credits" })}
                                className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg transition cursor-pointer"
                                title="Manual Platform Credit / Subscription Allocation"
                              >
                                <Coins className="w-3.5 h-3.5" />
                              </button>

                              {/* Manual SMS Credit Allocation */}
                              <button
                                type="button"
                                onClick={() => setAllocationModalTarget({ user: node, initialTab: "sms" })}
                                className="p-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 rounded-lg transition cursor-pointer"
                                title="Manual SMS Credit Allocation"
                              >
                                <MessageSquare className="w-3.5 h-3.5" />
                              </button>

                              {/* User Audit Log */}
                              <button
                                type="button"
                                onClick={() => setSelectedUserForEmailAudit(node)}
                                className="p-1.5 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                                title="View User Audit"
                              >
                                <Activity className="w-4 h-4" />
                              </button>

                              {/* Cascade Delete Farm Node Button */}
                              <button
                                type="button"
                                onClick={() => {
                                  setDeletingNode(node);
                                  setDeleteReason("");
                                  setDeleteConfirmationInput("");
                                }}
                                className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5"
                                title="Permanently delete node and release email/phone credentials"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>Delete</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls Footer */}
            {filteredNodes.length > 0 && (
              <div className="px-4 py-3 bg-slate-50/80 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-3 text-slate-600 font-medium">
                  <span>
                    Showing <strong className="text-slate-900 font-bold">{(nodesCurrentPage - 1) * nodesPerPage + 1}</strong> to <strong className="text-slate-900 font-bold">{Math.min(nodesCurrentPage * nodesPerPage, filteredNodes.length)}</strong> of <strong className="text-slate-900 font-bold">{filteredNodes.length}</strong> farm nodes
                  </span>
                  <div className="flex items-center gap-1.5 pl-3 border-l border-slate-200">
                    <span className="text-slate-500 text-[11px]">Per page:</span>
                    <select
                      value={nodesPerPage}
                      onChange={(e) => {
                        setNodesPerPage(Number(e.target.value));
                        setNodesCurrentPage(1);
                      }}
                      className="px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-700 outline-none cursor-pointer"
                    >
                      <option value={10}>10</option>
                      <option value={25}>25</option>
                      <option value={50}>50</option>
                      <option value={100}>100</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setNodesCurrentPage(1)}
                    disabled={nodesCurrentPage <= 1}
                    className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer"
                    title="First page"
                  >
                    <ChevronsLeft className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setNodesCurrentPage(p => Math.max(1, p - 1))}
                    disabled={nodesCurrentPage <= 1}
                    className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer flex items-center gap-1"
                    title="Previous page"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span className="text-xs font-semibold hidden sm:inline">Prev</span>
                  </button>

                  <div className="flex items-center gap-1 px-1">
                    {Array.from({ length: totalNodesPages }, (_, i) => i + 1)
                      .filter(page => {
                        if (totalNodesPages <= 5) return true;
                        if (page === 1 || page === totalNodesPages) return true;
                        return Math.abs(page - nodesCurrentPage) <= 1;
                      })
                      .map((page, idx, arr) => {
                        const showEllipsisBefore = idx > 0 && page - arr[idx - 1] > 1;
                        return (
                          <React.Fragment key={page}>
                            {showEllipsisBefore && <span className="text-slate-400 px-1">...</span>}
                            <button
                              type="button"
                              onClick={() => setNodesCurrentPage(page)}
                              className={`w-7 h-7 rounded-lg text-xs font-bold transition cursor-pointer ${
                                nodesCurrentPage === page
                                  ? "bg-indigo-600 text-white shadow-sm"
                                  : "bg-white border border-slate-200 text-slate-700 hover:bg-slate-100"
                              }`}
                            >
                              {page}
                            </button>
                          </React.Fragment>
                        );
                      })}
                  </div>

                  <button
                    type="button"
                    onClick={() => setNodesCurrentPage(p => Math.min(totalNodesPages, p + 1))}
                    disabled={nodesCurrentPage >= totalNodesPages}
                    className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer flex items-center gap-1"
                    title="Next page"
                  >
                    <span className="text-xs font-semibold hidden sm:inline">Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setNodesCurrentPage(totalNodesPages)}
                    disabled={nodesCurrentPage >= totalNodesPages}
                    className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition cursor-pointer"
                    title="Last page"
                  >
                    <ChevronsRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Deleted Farm Nodes Tracker Summary */}
          {deletedNodesHistory.length > 0 && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Trash className="w-4 h-4 text-rose-400" />
                  <h3 className="font-extrabold text-sm text-slate-100">Super Admin Deleted Farm Nodes Audit ({deletedNodesHistory.length})</h3>
                </div>
                <span className="text-[10px] text-emerald-400 font-mono font-bold">Emails Released & Re-registerable</span>
              </div>
              <div className="space-y-2 text-xs">
                {deletedNodesHistory.slice(0, 5).map((rec) => (
                  <div key={rec.id} className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-200">{rec.farmName} ({rec.email})</div>
                      <div className="text-[10px] text-slate-400">
                        Deleted on {new Date(rec.deletedAt).toLocaleDateString()} by {rec.deletedByEmail} &bull; Reason: {rec.reason}
                      </div>
                    </div>
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded text-[10px] font-mono font-bold">
                      RELEASED
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. Platform Invoices Tab */}
      {activeSubTab === "invoices" && (
        <SuperAdminInvoicesTab
          onOpenRaiseInvoice={handleOpenRaiseInvoice}
          currencySymbol={props.currencySymbol || "ZK"}
          currentUserEmail={userProfile?.email || "support@mabala.cloud"}
        />
      )}

      {/* 2. Platform Manual Allocation Tab */}
      {activeSubTab === "platform-allocations" && (
        <SuperAdminPlatformAllocationTab
          allUsers={nodes}
          currentUserEmail={userProfile?.email || "support@mabala.cloud"}
          currencySymbol={props.currencySymbol || "ZK"}
          onAllocationComplete={() => {
            loadFarmNodes();
          }}
        />
      )}

      {/* 3. SMS Manual Allocation Tab */}
      {activeSubTab === "sms-allocations" && (
        <SuperAdminSmsAllocationTab
          allUsers={nodes}
          currentUserEmail={userProfile?.email || "support@mabala.cloud"}
          currencySymbol={props.currencySymbol || "ZK"}
          onAllocationComplete={() => {
            loadFarmNodes();
          }}
        />
      )}

      {/* 4. Vendors Tab */}
      {activeSubTab === "vendors" && (
        <SuperAdminVendorsTab
          vendors={props.vendors || []}
          setVendors={props.setVendors || (() => {}) as any}
          currentRole="Super Admin"
        />
      )}

      {/* 3. Module Entitlements Tab */}
      {activeSubTab === "entitlements" && (
        <ModuleEntitlementEnginePanel />
      )}

      {/* 4. Fee Management Tab */}
      {activeSubTab === "fees" && (
        <div className="space-y-6">
          <FeeManagementPanel />
          <FeeAuditLogPanel />
        </div>
      )}

      {/* 5. Scale & Health Tab */}
      {activeSubTab === "scale" && (
        <div className="space-y-6">
          <PlatformScaleDashboard />
          <MarketAnalyticsPanel />
        </div>
      )}

      {/* 6. Districts Admin Tab */}
      {activeSubTab === "districts" && (
        <GeographicDistrictsAdminConsole />
      )}

      {/* 7. Statutory Taxes Tab */}
      {activeSubTab === "taxes" && (
        <StatutoryTaxConfigPanel />
      )}

      {/* 8. Report Toggles Tab */}
      {activeSubTab === "reports-toggles" && (
        <ReportTogglesAdminConsole />
      )}

      {/* ACCESS NODE MANDATORY CONFIRMATION MODAL */}
      {confirmAccessNodeTarget && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[99999] flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-red-500/30 rounded-2xl max-w-lg w-full p-6 text-white space-y-4 animate-in fade-in duration-200">
            <div className="flex items-start gap-3">
              <div className="p-3 bg-red-500/20 text-red-400 rounded-xl border border-red-500/30 shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white">
                  Confirm Access Node Remote Session
                </h3>
                <p className="text-xs text-slate-300 mt-1 font-medium">
                  You are initializing a Super Admin Access Node session for node support.
                </p>
              </div>
            </div>

            <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800 space-y-2 font-mono text-xs">
              <div className="flex justify-between items-center text-slate-400">
                <span>Target Farm Name:</span>
                <span className="font-bold text-emerald-400">
                  {confirmAccessNodeTarget.farm?.name || confirmAccessNodeTarget.farmName || "Farm Node"}
                </span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>Tenant Email:</span>
                <span className="font-bold text-slate-200">
                  {confirmAccessNodeTarget.tenantEmail || confirmAccessNodeTarget.email}
                </span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>Tenant ID:</span>
                <span className="font-bold text-indigo-300">
                  {confirmAccessNodeTarget.tenantUid || confirmAccessNodeTarget.uid || confirmAccessNodeTarget.id}
                </span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>Session TTL:</span>
                <span className="font-bold text-amber-400">60 Minutes (Auto-expiring)</span>
              </div>
            </div>

            <div className="bg-red-950/40 border border-red-500/30 rounded-xl p-3.5 space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-black text-red-300 uppercase tracking-wider">
                <Lock className="w-3.5 h-3.5 text-red-400" />
                Mandatory Audit Commitment Notice
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed font-medium">
                Every write operation, navigation, and state modification during this session will be cryptographically logged to the central audit register.
              </p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setConfirmAccessNodeTarget(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  const target = confirmAccessNodeTarget;
                  setConfirmAccessNodeTarget(null);
                  handleInitializeAccessNodeSession(target);
                }}
                className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 shadow-lg shadow-red-900/30"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Authorize & Connect Node</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* USER AUDIT TRAIL MODAL */}
      {selectedUserForEmailAudit && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[99999] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-xl w-full p-6 space-y-4 animate-in fade-in duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm">
                    User Activity & Email Audit Trail
                  </h3>
                  <p className="text-[11px] text-slate-500 font-medium">
                    {selectedUserForEmailAudit.email || selectedUserForEmailAudit.tenantEmail}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedUserForEmailAudit(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Account Role:</span>
                <span className="font-bold text-slate-800 uppercase font-mono text-[11px]">
                  {selectedUserForEmailAudit.role || selectedUserForEmailAudit.accountType || "Farmer"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Farm / Node Name:</span>
                <span className="font-bold text-slate-800">
                  {selectedUserForEmailAudit.farm?.name || selectedUserForEmailAudit.farmName || selectedUserForEmailAudit.displayName || "Node"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Phone Number:</span>
                <span className="font-mono text-slate-800">{selectedUserForEmailAudit.phone || selectedUserForEmailAudit.tenantPhone || "—"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Tenant UID:</span>
                <span className="font-mono text-[10px] text-slate-600 select-all">{selectedUserForEmailAudit.tenantUid || selectedUserForEmailAudit.uid || selectedUserForEmailAudit.id}</span>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setSelectedUserForEmailAudit(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Close Audit Trail
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUPER ADMIN CASCADE DELETE FARM NODE MODAL */}
      {deletingNode && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[99999] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-rose-200 shadow-2xl max-w-lg w-full p-6 space-y-5 animate-in fade-in zoom-in duration-200">
            {/* Modal Header */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-rose-100 rounded-2xl text-rose-700">
                  <Trash2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-rose-700 tracking-tight">
                    Cascade Delete Farm Node
                  </h3>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    Irreversible Super Admin workspace purge & credential release
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDeletingNode(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Target Profile Card */}
            <div className="p-4 bg-rose-50/80 border border-rose-200 rounded-2xl space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-rose-700 uppercase font-black tracking-wider">Target Node For Purge</span>
                <span className="px-2 py-0.5 bg-rose-200 text-rose-900 text-[9px] font-black rounded-md font-mono">
                  {deletingNode.role || deletingNode.accountType || "Farmer Node"}
                </span>
              </div>
              <div className="font-black text-slate-900 text-sm">
                {deletingNode.farm?.name || deletingNode.farmName || deletingNode.displayName || "Farm Node"}
              </div>
              <div className="text-slate-600 flex flex-wrap gap-x-3 gap-y-0.5 text-[11.5px]">
                <span>Owner: <strong>{deletingNode.tenantEmail || deletingNode.email}</strong></span>
                {(deletingNode.tenantPhone || deletingNode.phone) && <span>Phone: {deletingNode.tenantPhone || deletingNode.phone}</span>}
              </div>
              <div className="text-[10px] font-mono text-slate-400">
                Tenant UID: {deletingNode.tenantUid || deletingNode.uid || deletingNode.id}
              </div>
            </div>

            {/* Warning Note */}
            <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-[11px] text-amber-900 space-y-1 font-medium">
              <div className="flex items-center gap-1.5 font-bold text-amber-800">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>What happens when you delete this farm node?</span>
              </div>
              <ul className="list-disc pl-5 space-y-0.5 text-amber-900/90 text-[10.5px]">
                <li>All crop cycles, livestock batches, sales, expenses, invoices, and assets are permanently purged.</li>
                <li>The user profile is removed and active sessions are revoked.</li>
                <li>The owner email address and phone number are immediately released for future re-registration.</li>
                <li>A permanent audit trail is archived in the Super Admin Deleted Farm Nodes Tracker.</li>
              </ul>
            </div>

            {/* Form Fields */}
            <div className="space-y-3.5 text-xs">
              <div>
                <label className="font-extrabold text-slate-700 block pb-1">
                  1. Administrative Reason for Deletion *
                </label>
                <textarea
                  rows={2}
                  value={deleteReason}
                  onChange={(e) => setDeleteReason(e.target.value)}
                  placeholder="State the reason for completely deleting this farm node (audit trail requirement)..."
                  className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 text-slate-800 outline-none focus:bg-white focus:border-rose-500 transition-all font-semibold"
                />
              </div>

              <div>
                {(() => {
                  const targetExpectedConfirmation = (
                    deletingNode?.farm?.name ||
                    deletingNode?.farmName ||
                    deletingNode?.displayName ||
                    deletingNode?.tenantEmail ||
                    deletingNode?.email ||
                    "Farm Node"
                  ).trim();

                  return (
                    <div>
                      <div className="flex justify-between items-center pb-1">
                        <label className="font-extrabold text-slate-700 block">
                          2. Type Confirmation Text *
                        </label>
                        <button
                          type="button"
                          onClick={() => setDeleteConfirmationInput(targetExpectedConfirmation)}
                          className="text-[10px] font-bold text-rose-600 hover:underline cursor-pointer"
                        >
                          Auto-Fill Target Name
                        </button>
                      </div>
                      <p className="text-[11px] text-slate-500 pb-1.5">
                        To confirm, type <strong className="text-rose-600 font-mono font-bold select-all">"{targetExpectedConfirmation}"</strong> below:
                      </p>
                      <input
                        type="text"
                        value={deleteConfirmationInput}
                        onChange={(e) => setDeleteConfirmationInput(e.target.value)}
                        placeholder={`Type "${targetExpectedConfirmation}" to confirm...`}
                        className="w-full p-3 border border-rose-300 rounded-xl bg-rose-50/40 text-slate-900 outline-none focus:bg-white focus:border-rose-600 transition-all font-bold font-mono text-xs"
                      />
                    </div>
                  );
                })()}
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 text-xs font-black uppercase">
              <button
                type="button"
                onClick={() => setDeletingNode(null)}
                className="px-4 py-2.5 border border-slate-200 rounded-xl hover:bg-slate-50 transition cursor-pointer text-slate-600 font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteNodeSubmit}
                disabled={
                  isSubmittingDelete || 
                  !deleteReason.trim() || 
                  (
                    deleteConfirmationInput.trim().toLowerCase() !== (deletingNode?.farm?.name || "").trim().toLowerCase() && 
                    deleteConfirmationInput.trim().toLowerCase() !== (deletingNode?.tenantEmail || deletingNode?.email || "").trim().toLowerCase() &&
                    deleteConfirmationInput.trim().toLowerCase() !== (deletingNode?.displayName || "").trim().toLowerCase() &&
                    deleteConfirmationInput.trim() !== (deletingNode?.tenantUid || deletingNode?.uid || "")
                  )
                }
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl transition cursor-pointer flex items-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed shadow-md"
              >
                {isSubmittingDelete ? (
                  <>
                    <RefreshCcw className="w-4 h-4 animate-spin" />
                    <span>Cascade Purging Workspace...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>Permanently Delete Farm Node</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUPER ADMIN BULK DELETE FARM NODES MODAL */}
      {showBulkDeleteModal && selectedNodeKeys.size > 0 && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[99999] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-rose-200 shadow-2xl max-w-lg w-full p-6 space-y-5 animate-in fade-in zoom-in duration-200">
            {/* Modal Header */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-rose-100 rounded-2xl text-rose-700">
                  <Trash2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-rose-700 tracking-tight">
                    Bulk Delete Farm Nodes ({selectedNodeKeys.size})
                  </h3>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    Irreversible mass purge of {selectedNodeKeys.size} workspace{selectedNodeKeys.size === 1 ? "" : "s"} & credential release
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (!isSubmittingBulkDelete) setShowBulkDeleteModal(false);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Selected Nodes Preview Scroll Box */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 text-xs max-h-40 overflow-y-auto">
              <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                Selected Farm Nodes for Cascade Purge:
              </div>
              <div className="space-y-1.5 divide-y divide-slate-200/60">
                {currentSourceNodes
                  .filter(n => selectedNodeKeys.has(getNodeKey(n)))
                  .map(node => (
                    <div key={getNodeKey(node)} className="pt-1.5 first:pt-0 flex items-center justify-between">
                      <div>
                        <div className="font-bold text-slate-900">
                          {node.farm?.name || node.farmName || node.displayName || "Farm Node"}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {node.tenantEmail || node.email || "No email"}
                        </div>
                      </div>
                      <span className="px-2 py-0.5 bg-slate-200 text-slate-700 text-[9px] font-bold rounded">
                        {node.role || node.accountType || "Farmer"}
                      </span>
                    </div>
                  ))}
              </div>
            </div>

            {/* Warning Note */}
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-[11px] text-rose-900 space-y-1 font-medium">
              <div className="flex items-center gap-1.5 font-bold text-rose-800">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Audit & Cascade Deletion Notice</span>
              </div>
              <p className="text-rose-900/90 text-[10.5px]">
                Deleting these farm nodes will completely remove their root records, subcollections, ledger balances, and local caches. Owner emails and phone numbers will be released for re-registration.
              </p>
            </div>

            {/* Deletion Reason (Mandatory for Audit Logging) */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-800">
                Audit Deletion Reason <span className="text-rose-600">*</span>
              </label>
              <textarea
                value={bulkDeleteReason}
                onChange={(e) => setBulkDeleteReason(e.target.value)}
                placeholder="Specify the operational or administrative reason for this bulk deletion (logged permanently for audit)..."
                rows={2}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-rose-500 focus:bg-white transition"
              />
            </div>

            {/* Type "DELETE" Confirmation */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-800">
                Type <strong className="text-rose-600 font-black tracking-wider">DELETE</strong> to confirm mass action:
              </label>
              <input
                type="text"
                value={bulkDeleteConfirmText}
                onChange={(e) => setBulkDeleteConfirmText(e.target.value)}
                placeholder="DELETE"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-mono uppercase outline-none focus:border-rose-500 focus:bg-white transition"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowBulkDeleteModal(false)}
                disabled={isSubmittingBulkDelete}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteBulkDelete}
                disabled={
                  isSubmittingBulkDelete ||
                  !bulkDeleteReason.trim() ||
                  bulkDeleteConfirmText.trim().toUpperCase() !== "DELETE"
                }
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed shadow-md shadow-rose-600/20"
              >
                {isSubmittingBulkDelete ? (
                  <>
                    <RefreshCcw className="w-4 h-4 animate-spin" />
                    <span>Purging {selectedNodeKeys.size} Nodes...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>Permanently Delete ({selectedNodeKeys.size})</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BULK USER REGISTRATION CSV MODAL */}
      <BulkUserRegistrationModal
        isOpen={showBulkUserRegistrationModal}
        onClose={() => setShowBulkUserRegistrationModal(false)}
        onSuccess={() => {
          loadFarmNodes();
        }}
        adminProfile={userProfile}
      />

      {/* SUPER ADMIN QUICK ALLOCATION MODAL */}
      {allocationModalTarget && (
        <SuperAdminCreditAllocationModal
          isOpen={!!allocationModalTarget}
          onClose={() => setAllocationModalTarget(null)}
          targetUser={allocationModalTarget.user}
          allUsers={nodes}
          initialTab={allocationModalTarget.initialTab || "credits"}
          onAllocationSuccess={() => {
            loadFarmNodes();
          }}
          currentUserEmail={userProfile?.email || "support@mabala.cloud"}
        />
      )}

      {/* SUPER ADMIN MANUAL RAISE INVOICE MODAL */}
      {showRaiseInvoiceModal && (
        <SuperAdminRaiseInvoiceModal
          isOpen={showRaiseInvoiceModal}
          onClose={() => {
            setShowRaiseInvoiceModal(false);
            setInvoiceModalTargetTenant(null);
          }}
          onInvoiceCreated={() => {
            loadFarmNodes();
          }}
          currencySymbol={props.currencySymbol || "ZK"}
          availableTenants={nodes}
          initialTenant={invoiceModalTargetTenant}
        />
      )}

      {/* SUPER ADMIN FARM NODE CONFIGURATION MODAL */}
      {configuringNodeTarget && (
        <SuperAdminFarmNodeConfigModal
          isOpen={!!configuringNodeTarget}
          onClose={() => setConfiguringNodeTarget(null)}
          node={configuringNodeTarget}
          onSaveSuccess={(updatedNode) => {
            setNodes((prev) =>
              prev.map((n) => {
                const idA = n.uid || n.tenantUid || n.id;
                const idB = updatedNode.uid || updatedNode.tenantUid || updatedNode.id;
                return idA === idB ? { ...n, ...updatedNode } : n;
              })
            );
            if (props.setFarms && Array.isArray(props.farms)) {
              props.setFarms((prev: any[]) =>
                prev.map((f: any) => {
                  const idA = f.id;
                  const idB = updatedNode.uid || updatedNode.tenantUid || updatedNode.id;
                  return idA === idB ? { ...f, ...updatedNode } : f;
                })
              );
            }
            loadFarmNodes(true);
          }}
          showToast={showToast}
        />
      )}
    </div>
  );
}

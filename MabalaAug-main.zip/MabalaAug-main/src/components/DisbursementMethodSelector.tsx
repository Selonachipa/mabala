import React from "react";
import { Building2, Smartphone, ShieldCheck, Lock, Info } from "lucide-react";
import { getFeeConfig } from "../services/feeConfigService";
import { calculateDisbursementFees } from "../services/mabalaPlatformEngine";

export interface BankDetails {
  accountNumber: string;
  bankName: string;
  swiftCode: string;
  firstName: string;
  lastName: string;
  holderName: string;
  phone: string;
  email: string;
}

interface DisbursementMethodSelectorProps {
  selectedMethod: "mobile_money" | "bank";
  onChangeMethod: (method: "mobile_money" | "bank") => void;
  bankDetails: BankDetails;
  onBankDetailsChange: (details: BankDetails) => void;
  requestedAmount?: number;
  securityPin: string;
  onSecurityPinChange: (pin: string) => void;
  showFeeBreakdown?: boolean;
}

export const ZAMBIAN_BANKS = [
  { code: "ZAMNET_ZANACO", name: "Zambia National Commercial Bank (ZANACO)", swift: "ZNCOZMLU" },
  { code: "STANBIC", name: "Stanbic Bank Zambia", swift: "SBICZMLU" },
  { code: "ABSA", name: "ABSA Bank Zambia", swift: "BARCZMLU" },
  { code: "FNB", name: "First National Bank (FNB Zambia)", swift: "FIRNZMLU" },
  { code: "STANCHART", name: "Standard Chartered Bank Zambia", swift: "SCBLZMLU" },
  { code: "INDO", name: "Indo-Zambia Bank", swift: "INDOZMLU" },
  { code: "ACCESS", name: "Access Bank Zambia", swift: "ACCEZMLU" },
  { code: "ECOBANK", name: "Ecobank Zambia", swift: "ECOZ22LU" },
];

export default function DisbursementMethodSelector({
  selectedMethod,
  onChangeMethod,
  bankDetails,
  onBankDetailsChange,
  requestedAmount = 0,
  securityPin,
  onSecurityPinChange,
  showFeeBreakdown = true,
}: DisbursementMethodSelectorProps) {
  const feeConfig = getFeeConfig("disbursement_platform_fee");
  const platformFeeRate = feeConfig && feeConfig.active ? feeConfig.value : 3.5;
  const feeBreakdown = calculateDisbursementFees(requestedAmount, selectedMethod === "bank" ? "Bank" : "MobileMoney");

  const handleBankChange = (field: keyof BankDetails, value: string) => {
    onBankDetailsChange({
      ...bankDetails,
      [field]: value,
    });
  };

  return (
    <div className="space-y-4 font-sans text-slate-900">
      <label className="text-xs font-black uppercase text-slate-400 tracking-wider block">
        Select Payout Disbursement Method
      </label>

      {/* SELECTOR BUTTONS */}
      <div className="grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => onChangeMethod("mobile_money")}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
            selectedMethod === "mobile_money"
              ? "bg-slate-900 text-white border-slate-900 shadow-md ring-2 ring-emerald-500/30"
              : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
          }`}
        >
          <div className={`p-2.5 rounded-xl ${selectedMethod === "mobile_money" ? "bg-emerald-500/20 text-emerald-400" : "bg-slate-200 text-slate-600"}`}>
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <div className="font-extrabold text-xs">Mobile Money Payout</div>
            <div className={`text-[10px] ${selectedMethod === "mobile_money" ? "text-slate-300" : "text-slate-500"}`}>
              Instant Airtel, MTN, Zamtel
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => onChangeMethod("bank")}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
            selectedMethod === "bank"
              ? "bg-slate-900 text-white border-slate-900 shadow-md ring-2 ring-indigo-500/30"
              : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
          }`}
        >
          <div className={`p-2.5 rounded-xl ${selectedMethod === "bank" ? "bg-indigo-500/20 text-indigo-400" : "bg-slate-200 text-slate-600"}`}>
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="font-extrabold text-xs">Bank Transfer</div>
            <div className={`text-[10px] ${selectedMethod === "bank" ? "text-slate-300" : "text-slate-500"}`}>
              Direct Bank Account Withdrawal
            </div>
          </div>
        </button>
      </div>

      {/* BANK DETAILS FORM */}
      {selectedMethod === "bank" && (
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-white space-y-3.5 animate-fade-in">
          <div className="flex justify-between items-center border-b border-slate-850 pb-2">
            <span className="text-[11px] font-extrabold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-indigo-400" /> Commercial Bank Payout Information
            </span>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800">
              Mabala Narration: "Disbursement from Mabala"
            </span>
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Select Bank</label>
            <select
              value={bankDetails.bankName}
              onChange={(e) => {
                const b = ZAMBIAN_BANKS.find(x => x.name === e.target.value);
                onBankDetailsChange({
                  ...bankDetails,
                  bankName: e.target.value,
                  swiftCode: b?.swift || bankDetails.swiftCode
                });
              }}
              className="w-full text-xs font-semibold bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-hidden focus:border-indigo-500"
            >
              <option value="">Select Commercial Bank...</option>
              {ZAMBIAN_BANKS.map((b) => (
                <option key={b.code} value={b.name}>{b.name} ({b.swift})</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Account Number</label>
              <input
                type="text"
                required
                placeholder="10029837482"
                value={bankDetails.accountNumber}
                onChange={(e) => handleBankChange("accountNumber", e.target.value)}
                className="w-full text-xs font-mono font-bold bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">SWIFT / BIC Code</label>
              <input
                type="text"
                required
                placeholder="ZNCOZMLU"
                value={bankDetails.swiftCode}
                onChange={(e) => handleBankChange("swiftCode", e.target.value.toUpperCase())}
                className="w-full text-xs font-mono font-bold uppercase bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Account Holder First Name</label>
              <input
                type="text"
                required
                placeholder="Chisamba"
                value={bankDetails.firstName}
                onChange={(e) => handleBankChange("firstName", e.target.value)}
                className="w-full text-xs font-semibold bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Account Holder Last Name</label>
              <input
                type="text"
                required
                placeholder="Farms"
                value={bankDetails.lastName}
                onChange={(e) => handleBankChange("lastName", e.target.value)}
                className="w-full text-xs font-semibold bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Contact Phone Number</label>
              <input
                type="text"
                required
                placeholder="+(260) 977 123-456"
                value={bankDetails.phone}
                onChange={(e) => handleBankChange("phone", e.target.value)}
                className="w-full text-xs font-mono font-bold bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Notification Email (Optional)</label>
              <input
                type="email"
                placeholder="accounts@farm.co.zm"
                value={bankDetails.email}
                onChange={(e) => handleBankChange("email", e.target.value)}
                className="w-full text-xs font-semibold bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* FEE BREAKDOWN & PIN SECURITY CARD */}
      {showFeeBreakdown && requestedAmount > 0 && (
        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 text-white space-y-3 animate-fade-in">
          <div className="flex justify-between items-center text-xs text-slate-300 font-bold border-b border-slate-800 pb-2">
            <span>Itemized Payout & Fee Reconciliation</span>
            <span className="text-[10px] font-mono text-emerald-400">Lipila Direct API</span>
          </div>

          <div className="space-y-1.5 text-xs font-sans">
            <div className="flex justify-between text-slate-300">
              <span>Principal Payout Requested:</span>
              <span className="font-mono font-bold text-white">ZMW {feeBreakdown.requestedAmount.toFixed(2)}</span>
            </div>

            <div className="flex justify-between text-slate-400 text-[11px]">
              <span className="flex items-center gap-1">
                <Info className="w-3 h-3 text-sky-400" /> Lipila Gateway Fee Component:
              </span>
              <span className="font-mono text-slate-300">ZMW {feeBreakdown.lipilaFee.toFixed(2)}</span>
            </div>

            <div className="flex justify-between text-slate-400 text-[11px]">
              <span className="flex items-center gap-1">
                <Info className="w-3 h-3 text-indigo-400" /> Mabala Platform Fee ({platformFeeRate}%):
              </span>
              <span className="font-mono text-slate-300">ZMW {feeBreakdown.platformFee3Point5.toFixed(2)}</span>
            </div>

            <div className="flex justify-between text-amber-300 font-bold text-xs pt-1 border-t border-slate-800">
              <span>Total Fees Combined:</span>
              <span className="font-mono">ZMW {feeBreakdown.totalFees.toFixed(2)}</span>
            </div>

            <div className="flex justify-between font-black text-white text-sm pt-1 border-t border-slate-800">
              <span>Total Deducted from Farm Balance:</span>
              <span className="font-mono text-rose-400">ZMW {feeBreakdown.totalDeductedFromWallet.toFixed(2)}</span>
            </div>
          </div>

          {/* PIN GATE */}
          <div className="pt-2 border-t border-slate-800 space-y-1.5">
            <label className="text-[10px] font-black uppercase text-amber-400 flex items-center gap-1">
              <Lock className="w-3 h-3" /> Security Authorization PIN (4 Digits Required)
            </label>
            <input
              type="password"
              maxLength={4}
              required
              placeholder="••••"
              value={securityPin}
              onChange={(e) => onSecurityPinChange(e.target.value.replace(/\D/g, ""))}
              className="w-full text-center text-lg font-mono font-black tracking-widest bg-slate-950 border border-amber-500/40 rounded-xl p-2 text-amber-400 focus:outline-hidden focus:border-amber-400"
            />
          </div>
        </div>
      )}
    </div>
  );
}

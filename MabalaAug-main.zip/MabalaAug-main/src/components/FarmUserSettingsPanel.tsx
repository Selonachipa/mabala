import React, { useState, useEffect } from "react";
import {
  User,
  Building2,
  Shield,
  CheckCircle2,
  AlertCircle,
  Save,
  RefreshCw,
  Key,
  Mail,
  Phone,
  MapPin,
  CreditCard,
  Bell,
  Globe,
  Percent,
  Tractor,
  Briefcase,
  Plus,
  Trash2,
  Edit3,
  Sliders,
  Database,
  DollarSign,
  Clock,
  Lock,
  Check,
  Smartphone,
  ChevronRight,
  Landmark,
  FileText,
  SlidersHorizontal,
  Info,
  Calendar,
  Layers,
  Archive,
  RotateCcw,
  ShieldCheck,
  X,
  ShieldAlert
} from "lucide-react";
import { Farm, PredefinedRole, ArchiveRecord, CreditNote, Account } from "../types";
import { auth, db, isConfigured, sendPasswordResetEmail } from "../firebase";
import { doc, setDoc, updateDoc, serverTimestamp } from "firebase/firestore";
import { safeLocalStorage as localStorage } from "../utils/safeStorage";
import { DEFAULT_ZAMBIA_DISTRICTS, ZAMBIA_PROVINCES_ALPHABETICAL } from "../config/zambiaDistricts";
import { FarmPersistenceService } from "../services/farmPersistenceService";
import { IdentityIntegrityService } from "../services/identityIntegrityService";

interface FarmUserSettingsPanelProps {
  userProfile: any;
  setUserProfile: React.Dispatch<React.SetStateAction<any>>;
  activeFarm: Farm;
  setActiveFarm?: (farm: Farm) => void;
  farms: Farm[];
  setFarms?: React.Dispatch<React.SetStateAction<Farm[]>>;
  currentRole: PredefinedRole;
  selectedCountry?: any;
  setSelectedCountry?: (country: any) => void;
  onNavigateToTab?: (tabId: string) => void;
  showToast?: (message: string, type?: "success" | "error" | "info" | "warning") => void;
  handleSaveCloudWorkspace?: (uid: string) => Promise<void>;
  handleUpdateActiveFarm?: (updatedFields: Partial<any>) => void;
  tenantId?: string;
  userEmail?: string;
  writeAuditLog?: (action: string, module: string, target: string, details: string) => void;
  initialSection?: "farm" | "profile" | "tax" | "farms_list" | "notifications" | "security";
  archiveRecords?: ArchiveRecord[];
  onRestoreFromArchive?: (arc: ArchiveRecord) => void;
  onAddCreditNote?: (cn: CreditNote) => void;
  accounts?: any[];
  setAccounts?: React.Dispatch<React.SetStateAction<any[]>>;
  credits?: number;
  setCredits?: React.Dispatch<React.SetStateAction<number>>;
  creditNotes?: CreditNote[];
  setCreditNotes?: React.Dispatch<React.SetStateAction<CreditNote[]>>;
  isSuperAdmin?: boolean;
}

export const FarmUserSettingsPanel: React.FC<FarmUserSettingsPanelProps> = ({
  userProfile,
  setUserProfile,
  activeFarm,
  setActiveFarm,
  farms = [],
  setFarms,
  currentRole,
  selectedCountry,
  setSelectedCountry,
  onNavigateToTab,
  showToast,
  handleSaveCloudWorkspace,
  handleUpdateActiveFarm,
  tenantId,
  userEmail,
  writeAuditLog,
  initialSection,
  archiveRecords = [],
  onRestoreFromArchive,
  onAddCreditNote,
  accounts = [],
  setAccounts,
  credits = 0,
  setCredits,
  creditNotes = [],
  setCreditNotes,
  isSuperAdmin = false
}) => {
  const [activeSection, setActiveSection] = useState<"farm" | "profile" | "tax" | "farms_list" | "notifications" | "security">(
    initialSection || "farm"
  );

  useEffect(() => {
    if (initialSection) {
      setActiveSection(initialSection);
    }
  }, [initialSection]);

  // Single Unified Node & Account Email Identifier:
  // Immutability constraint: The email address field must remain strictly uneditable.
  // It serves as the permanent unique identifier for each farm node, and the platform enforces one email per node.
  const resolvedInitialEmail = (
    userProfile?.email ||
    userEmail ||
    activeFarm?.email ||
    "owner@mabala.cloud"
  ).trim().toLowerCase();

  const [nodeEmail, setNodeEmail] = useState<string>(resolvedInitialEmail);

  // Authenticated operator session detector for user attribution compliance
  const getAuthenticatedActor = () => {
    const actorEmail = auth.currentUser?.email || userProfile?.email || userEmail;
    const actorUid = auth.currentUser?.uid || userProfile?.uid || tenantId || "auth-user";
    const actorName = userProfile?.name || auth.currentUser?.displayName || "Authenticated Farm Owner";
    const actorRole = currentRole || userProfile?.role || "Farm Owner";

    if (!actorEmail) {
      return null;
    }
    return {
      uid: actorUid,
      name: actorName,
      email: actorEmail.trim().toLowerCase(),
      role: actorRole
    };
  };

  // User Profile Form State
  const [profileForm, setProfileForm] = useState({
    name: userProfile?.name || "",
    email: resolvedInitialEmail,
    phone: userProfile?.phone || "",
    role: userProfile?.role || currentRole || "Farm Owner",
    nationalId: userProfile?.nationalId || userProfile?.nrc || "",
    avatar: userProfile?.avatar || "",
    bio: userProfile?.bio || "",
    designation: userProfile?.designation || userProfile?.title || "",
    address: userProfile?.address || ""
  });

  // Active Farm Profile Form State
  const [farmForm, setFarmForm] = useState({
    id: activeFarm?.id || "farm-1",
    name: activeFarm?.name || "",
    letterheadTitle: activeFarm?.letterheadTitle || activeFarm?.name || "",
    tpin: activeFarm?.tpin || "",
    vatNumber: activeFarm?.vatNumber || "",
    address: activeFarm?.address || "",
    province: activeFarm?.province || activeFarm?.location?.province || "Central",
    district: activeFarm?.district || activeFarm?.location?.district || "Kabwe",
    phone: activeFarm?.phone || "",
    email: resolvedInitialEmail,
    financialYearStart: activeFarm?.financialYearStart || "2026-01-01",
    financialYearEnd: activeFarm?.financialYearEnd || "2026-12-31",
    currency: activeFarm?.currency || selectedCountry?.currency || "ZMW",
    currencySymbol: activeFarm?.currencySymbol || selectedCountry?.symbol || "ZK",
    taxSystem: (activeFarm?.taxSystem as "VAT" | "Sales Tax" | "Turnover Tax" | "None") || "Turnover Tax",
    taxType: activeFarm?.taxType || "TOT_5",
    customTaxName: activeFarm?.customTaxName || "Custom Statutory Levy",
    customTaxRate: activeFarm?.customTaxRate || 5,
    size: (activeFarm as any)?.size || "50",
    sizeUnit: (activeFarm as any)?.sizeUnit || "Hectares",
    farmingType: (activeFarm as any)?.farmingType || "Mixed Crops & Livestock",
    registrationNumber: (activeFarm as any)?.registrationNumber || "",
    managerName: (activeFarm as any)?.managerName || ""
  });

  // Notification Preferences State
  const [notificationPrefs, setNotificationPrefs] = useState({
    smsLowStock: true,
    smsDailySummary: false,
    smsInvoiceOverdue: true,
    smsWeatherAlerts: true,
    emailWeeklyReport: true,
    emailSecurityAlerts: true,
    smsPhone: userProfile?.phone || activeFarm?.phone || "+260978070734",
    emailAddress: resolvedInitialEmail,
    lowStockThreshold: 10,
    overdueDays: 7
  });

  // New Farm Modal / Inline State
  const [showAddFarmModal, setShowAddFarmModal] = useState(false);
  const [newFarmName, setNewFarmName] = useState("");
  const [newFarmAddress, setNewFarmAddress] = useState("");
  const [newFarmProvince, setNewFarmProvince] = useState("Lusaka");
  const [newFarmDistrict, setNewFarmDistrict] = useState("Lusaka");
  const [newFarmPhone, setNewFarmPhone] = useState("");
  const [newFarmTaxType, setNewFarmTaxType] = useState("TOT_5");

  // Soft-Delete & Archival States
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState<Farm | null>(null);
  const [softDeletingNodeId, setSoftDeletingNodeId] = useState<string | null>(null);
  const [restoringRecordId, setRestoringRecordId] = useState<string | null>(null);

  // Status & Feedback State
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [saveErrorMsg, setSaveErrorMsg] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [resetEmailSent, setResetEmailSent] = useState(false);
  const [resetEmailError, setResetEmailError] = useState<string | null>(null);

  // Sync state when props change
  useEffect(() => {
    const canonical = (
      userProfile?.email ||
      userEmail ||
      activeFarm?.email ||
      "owner@mabala.cloud"
    ).trim().toLowerCase();

    if (canonical) {
      setNodeEmail(canonical);
      setProfileForm((prev) => ({
        ...prev,
        email: canonical,
        name: userProfile?.name || prev.name,
        phone: userProfile?.phone || prev.phone,
        role: userProfile?.role || currentRole || prev.role,
        nationalId: userProfile?.nationalId || (userProfile as any)?.nrc || prev.nationalId,
        avatar: userProfile?.avatar || prev.avatar,
        bio: userProfile?.bio || prev.bio,
        designation: userProfile?.designation || (userProfile as any)?.title || prev.designation,
        address: userProfile?.address || prev.address
      }));
      setFarmForm((prev) => ({
        ...prev,
        email: canonical
      }));
    }
  }, [userProfile, userEmail, currentRole]);

  useEffect(() => {
    if (activeFarm) {
      const canonical = (
        userProfile?.email ||
        userEmail ||
        activeFarm?.email ||
        "owner@mabala.cloud"
      ).trim().toLowerCase();

      setFarmForm((prev) => ({
        ...prev,
        id: activeFarm.id || "farm-1",
        name: activeFarm.name || prev.name,
        letterheadTitle: activeFarm.letterheadTitle || activeFarm.name || prev.letterheadTitle,
        tpin: activeFarm.tpin || prev.tpin,
        vatNumber: activeFarm.vatNumber || prev.vatNumber,
        address: activeFarm.address || prev.address,
        province: activeFarm.province || activeFarm.location?.province || prev.province || "Central",
        district: activeFarm.district || activeFarm.location?.district || prev.district || "Kabwe",
        phone: activeFarm.phone || prev.phone,
        email: canonical,
        financialYearStart: activeFarm.financialYearStart || prev.financialYearStart || "2026-01-01",
        financialYearEnd: activeFarm.financialYearEnd || prev.financialYearEnd || "2026-12-31",
        currency: activeFarm.currency || selectedCountry?.currency || prev.currency || "ZMW",
        currencySymbol: activeFarm.currencySymbol || selectedCountry?.symbol || prev.currencySymbol || "ZK",
        taxSystem: (activeFarm.taxSystem as any) || prev.taxSystem || "Turnover Tax",
        taxType: activeFarm.taxType || prev.taxType || "TOT_5",
        customTaxName: activeFarm.customTaxName || prev.customTaxName || "Custom Statutory Levy",
        customTaxRate: activeFarm.customTaxRate !== undefined ? activeFarm.customTaxRate : prev.customTaxRate,
        size: (activeFarm as any)?.size || prev.size || "50",
        sizeUnit: (activeFarm as any)?.sizeUnit || prev.sizeUnit || "Hectares",
        farmingType: (activeFarm as any)?.farmingType || prev.farmingType || "Mixed Crops & Livestock",
        registrationNumber: (activeFarm as any)?.registrationNumber || prev.registrationNumber || "",
        managerName: (activeFarm as any)?.managerName || prev.managerName || ""
      }));
    }
  }, [activeFarm, selectedCountry]);

  // Load saved notification preferences
  useEffect(() => {
    try {
      const savedPrefs = localStorage.getItem("mabala_notification_prefs");
      if (savedPrefs) {
        setNotificationPrefs((prev) => ({ ...prev, ...JSON.parse(savedPrefs) }));
      } else if (userProfile?.notificationPrefs) {
        setNotificationPrefs((prev) => ({ ...prev, ...userProfile.notificationPrefs }));
      }
    } catch (e) {
      // Ignore parse failure
    }
  }, [userProfile]);

  // Handle Province and District selection
  const availableDistricts = DEFAULT_ZAMBIA_DISTRICTS[farmForm.province] || [];
  const newFarmAvailableDistricts = DEFAULT_ZAMBIA_DISTRICTS[newFarmProvince] || [];

  const handleProvinceChange = (newProvince: string) => {
    const districts = DEFAULT_ZAMBIA_DISTRICTS[newProvince] || [];
    setFarmForm((prev) => ({
      ...prev,
      province: newProvince,
      district: districts[0] || ""
    }));
  };

  const handleNewFarmProvinceChange = (newProvince: string) => {
    const districts = DEFAULT_ZAMBIA_DISTRICTS[newProvince] || [];
    setNewFarmProvince(newProvince);
    setNewFarmDistrict(districts[0] || "");
  };

  // Save User Profile with Enforced User Attribution
  const handleSaveUserProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveSuccessMsg(null);
    setSaveErrorMsg(null);
    setValidationErrors({});

    // Enforce logged-in user attribution for all modifications
    const actor = getAuthenticatedActor();
    if (!actor) {
      setSaveErrorMsg("Access Denied: Settings modifications require an authenticated, logged-in user session for audit compliance.");
      if (showToast) showToast("Authentication required to save profile.", "error");
      setIsSaving(false);
      return;
    }

    // Profile validation
    if (!profileForm.name || profileForm.name.trim().length < 2) {
      setValidationErrors({ profileName: "Full Name must be at least 2 characters." });
      setSaveErrorMsg("Full Name is required.");
      if (showToast) showToast("Please provide a valid Full Name.", "error");
      setIsSaving(false);
      return;
    }

    const cleanEmail = (nodeEmail || resolvedInitialEmail).trim().toLowerCase();

    const updatedProfile = {
      ...userProfile,
      name: profileForm.name.trim(),
      email: cleanEmail, // Strictly immutable unified email identifier
      phone: profileForm.phone.trim(),
      nationalId: profileForm.nationalId.trim(),
      bio: profileForm.bio.trim(),
      designation: profileForm.designation.trim(),
      address: profileForm.address.trim(),
      avatar: profileForm.avatar.trim(),
      updatedAt: new Date().toISOString(),
      lastModifiedBy: actor.email,
      lastModifiedByName: actor.name
    };

    try {
      setUserProfile(updatedProfile);
      localStorage.setItem("mabala_user_profile", JSON.stringify(updatedProfile));
      localStorage.setItem("mabala_user_email", cleanEmail);
      localStorage.setItem("mabala_farm_email", cleanEmail);

      // Keep active farm email synchronized
      if (handleUpdateActiveFarm) {
        handleUpdateActiveFarm({ email: cleanEmail });
      }

      const targetUid = userProfile?.tenantId || userProfile?.uid || auth.currentUser?.uid || tenantId;
      if (targetUid) {
        IdentityIntegrityService.saveVerifiedProfile(
          { uid: targetUid, email: cleanEmail },
          updatedProfile
        );
      }

      // Sync to Firebase Firestore
      if (targetUid && db && isConfigured) {
        try {
          const userDocRef = doc(db, "users_data", targetUid);
          await setDoc(
            userDocRef,
            {
              userProfile: updatedProfile,
              updatedAt: new Date().toISOString()
            },
            { merge: true }
          );

          const userRef = doc(db, "users", targetUid);
          await setDoc(
            userRef,
            {
              ...updatedProfile,
              updatedAt: serverTimestamp()
            },
            { merge: true }
          );
        } catch (dbErr) {
          console.warn("[FarmUserSettings] Firestore profile write note:", dbErr);
        }
      }

      // Offline Multi-Tier Persistence
      await FarmPersistenceService.saveFarmNodeWorkspace(cleanEmail, {
        userProfile: updatedProfile,
        email: cleanEmail
      });

      if (handleSaveCloudWorkspace && targetUid) {
        try {
          await handleSaveCloudWorkspace(targetUid);
        } catch (syncErr) {
          console.warn("[FarmUserSettings] Background cloud sync pipeline note:", syncErr);
        }
      }

      if (writeAuditLog) {
        writeAuditLog(
          "UPDATE",
          "Settings & Configurations",
          updatedProfile.email,
          `Operator ${actor.name} (${actor.email}, Role: ${actor.role}) updated account profile details. User attribution verified.`
        );
      }

      setSaveSuccessMsg("User profile updated and saved securely to cloud database and local storage!");
      if (showToast) showToast("User profile saved successfully!", "success");
    } catch (err: any) {
      console.error("[FarmUserSettings] Profile save error:", err);
      setSaveErrorMsg(`Error saving profile: ${err?.message || "Saved to local workspace."}`);
      if (showToast) showToast("Profile saved locally.", "info");
    } finally {
      setIsSaving(false);
      setTimeout(() => {
        setSaveSuccessMsg(null);
        setSaveErrorMsg(null);
      }, 6000);
    }
  };

  // Save Farm Details & Statutory Tax Settings with Enforced User Attribution & Numeric Validation
  const handleSaveFarmSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveSuccessMsg(null);
    setSaveErrorMsg(null);
    setValidationErrors({});

    // Enforce logged-in user attribution for all modifications
    const actor = getAuthenticatedActor();
    if (!actor) {
      setSaveErrorMsg("Access Denied: Modifying farm settings requires an authenticated, logged-in operator session for audit compliance.");
      if (showToast) showToast("Authentication required to modify farm settings.", "error");
      setIsSaving(false);
      return;
    }

    // 1. Validation and Numeric Checks
    const errors: Record<string, string> = {};
    if (!farmForm.name || farmForm.name.trim().length < 2) {
      errors.name = "Farm / Enterprise Name must be at least 2 characters.";
    }
    if (!farmForm.province) {
      errors.province = "Please select a valid Province.";
    }
    if (!farmForm.district) {
      errors.district = "Please select a valid District.";
    }
    if (farmForm.taxType === "CUSTOM") {
      const customRate = Number(farmForm.customTaxRate);
      if (isNaN(customRate) || customRate < 0 || customRate > 100) {
        errors.customTaxRate = "Custom tax rate must be a numeric percentage between 0 and 100.";
      }
    }
    if (farmForm.financialYearStart && farmForm.financialYearEnd) {
      if (new Date(farmForm.financialYearStart) > new Date(farmForm.financialYearEnd)) {
        errors.financialYearEnd = "Financial year end date cannot precede start date.";
      }
    }
    if (farmForm.size !== undefined && farmForm.size !== "") {
      const numericSize = Number(farmForm.size);
      if (isNaN(numericSize) || numericSize < 0) {
        errors.size = "Farm land size area must be a valid positive number.";
      }
    }

    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      setSaveErrorMsg("Please correct the highlighted validation errors before saving.");
      if (showToast) showToast("Please check the form for invalid inputs.", "error");
      setIsSaving(false);
      return;
    }

    const cleanEmail = (nodeEmail || resolvedInitialEmail).trim().toLowerCase();

    // 2. Strict Synchronized Node Email Enforcement & Traceability
    const updatedFarm: Farm = {
      ...activeFarm,
      id: farmForm.id || activeFarm?.id || "farm-1",
      name: farmForm.name.trim(),
      letterheadTitle: farmForm.letterheadTitle ? farmForm.letterheadTitle.trim() : farmForm.name.trim(),
      email: cleanEmail, // Strictly immutable node identifier
      phone: farmForm.phone.trim(),
      address: farmForm.address.trim(),
      province: farmForm.province,
      district: farmForm.district,
      town: farmForm.district,
      location: {
        province: farmForm.province,
        district: farmForm.district
      },
      tpin: farmForm.tpin.trim(),
      vatNumber: farmForm.vatNumber.trim(),
      financialYearStart: farmForm.financialYearStart,
      financialYearEnd: farmForm.financialYearEnd,
      currency: farmForm.currency,
      currencySymbol: farmForm.currencySymbol,
      taxSystem: farmForm.taxSystem,
      taxType: farmForm.taxType,
      customTaxName: farmForm.customTaxName,
      customTaxRate: Number(farmForm.customTaxRate) || 0,
      size: String(farmForm.size || ""),
      sizeUnit: farmForm.sizeUnit,
      farmingType: farmForm.farmingType,
      registrationNumber: farmForm.registrationNumber.trim(),
      managerName: farmForm.managerName.trim(),
      lastModifiedBy: actor.email,
      lastModifiedByName: actor.name,
      updatedAt: new Date().toISOString()
    };

    // Calculate updated farms list
    const existingFarms = Array.isArray(farms) && farms.length > 0 ? farms : [updatedFarm];
    const index = existingFarms.findIndex((f) => f.id === updatedFarm.id);
    let updatedFarmsList: Farm[];
    if (index >= 0) {
      updatedFarmsList = [...existingFarms];
      updatedFarmsList[index] = updatedFarm;
    } else {
      updatedFarmsList = [...existingFarms, updatedFarm];
    }

    try {
      const targetTenantId = tenantId || userProfile?.tenantId || userProfile?.uid || auth.currentUser?.uid;
      if (!targetTenantId || !db || !isConfigured) {
        throw new Error("No authenticated farm workspace is available.");
      }

      // The backend is authoritative. Do not mutate React state or local
      // snapshots until the authenticated transaction has succeeded.
      const { getFunctions, httpsCallable } = await import("firebase/functions");
      const { getApp } = await import("firebase/app");
      const updateFarmNodeSettings = httpsCallable(getFunctions(getApp()), "updateFarmNodeSettings");
      const result: any = await updateFarmNodeSettings({
        tenantId: targetTenantId,
        farmId: updatedFarm.id,
        settings: updatedFarm
      });
      const persistedFarm = result.data?.settings;
      if (!persistedFarm) throw new Error("The backend did not return persisted farm settings.");
      Object.assign(updatedFarm, persistedFarm);

      // 3. React State Update
      if (setActiveFarm) setActiveFarm(updatedFarm);
      if (setFarms) setFarms(updatedFarmsList);
      if (handleUpdateActiveFarm) {
        handleUpdateActiveFarm(updatedFarm);
      }

      // 4. Local Storage Persistence (for immediate synchronous reload availability)
      localStorage.setItem("mabala_active_farm", JSON.stringify(updatedFarm));
      localStorage.setItem("mabala_farms", JSON.stringify(updatedFarmsList));
      localStorage.setItem("mabala_farm_name", updatedFarm.name);
      localStorage.setItem("mabala_farm_tax_type", updatedFarm.taxType || "TOT_5");
      localStorage.setItem("mabala_farm_currency", updatedFarm.currency || "ZMW");
      localStorage.setItem("mabala_farm_email", cleanEmail);
      localStorage.setItem("mabala_user_email", cleanEmail);
      if (updatedFarm.customTaxName) {
        localStorage.setItem("mabala_farm_custom_tax_name", updatedFarm.customTaxName);
      }
      if (updatedFarm.customTaxRate !== undefined) {
        localStorage.setItem("mabala_farm_custom_tax_rate", String(updatedFarm.customTaxRate));
      }

      // Keep user profile email synchronized
      if (setUserProfile && userProfile) {
        const syncedProfile = { ...userProfile, email: cleanEmail };
        setUserProfile(syncedProfile);
        try {
          localStorage.setItem("mabala_user_profile", JSON.stringify(syncedProfile));
        } catch (e) {}
      }

      // 5. Offline Multi-Tier IndexedDB Snapshot
      await FarmPersistenceService.saveFarmNodeWorkspace(cleanEmail, {
        farms: updatedFarmsList,
        email: cleanEmail
      });

      // The callable already wrote the authenticated audit record atomically.
      if (writeAuditLog) {
        writeAuditLog(
          "UPDATE",
          "Settings & Configurations",
          updatedFarm.name,
          `Operator ${actor.name} (${actor.email}, Role: ${actor.role}) updated farm node settings and statutory configuration for ${updatedFarm.name} (${updatedFarm.id}). Changes persisted across local and cloud storage.`
        );
      }

      setSaveSuccessMsg("Farm settings and statutory configurations saved to the cloud database.");
      if (showToast) showToast("Farm node settings saved successfully!", "success");
    } catch (err: any) {
      console.error("[FarmUserSettings] Farm save error:", err);
      setSaveErrorMsg(`Settings were not saved: ${err?.message || "The database update failed."}`);
      if (showToast) showToast("Settings were not saved. Please retry.", "error");
    } finally {
      setIsSaving(false);
      setTimeout(() => {
        setSaveSuccessMsg(null);
        setSaveErrorMsg(null);
      }, 6000);
    }
  };

  // Create New Sub-Farm Node with Enforced User Attribution
  const handleCreateNewFarmNode = async (e: React.FormEvent) => {
    e.preventDefault();

    const actor = getAuthenticatedActor();
    if (!actor) {
      if (showToast) showToast("Authentication required to register new farm nodes.", "error");
      return;
    }

    if (!newFarmName.trim() || newFarmName.trim().length < 2) {
      if (showToast) showToast("Please provide a valid Farm Name (min 2 characters).", "error");
      return;
    }

    const cleanEmail = (nodeEmail || resolvedInitialEmail).trim().toLowerCase();
    const newId = `farm-${Date.now().toString().slice(-4)}`;
    const newFarm: Farm = {
      id: newId,
      name: newFarmName.trim(),
      address: newFarmAddress.trim() || `${newFarmDistrict}, ${newFarmProvince}, Zambia`,
      province: newFarmProvince,
      district: newFarmDistrict,
      town: newFarmDistrict,
      location: {
        province: newFarmProvince,
        district: newFarmDistrict
      },
      phone: newFarmPhone.trim() || activeFarm?.phone || "+260978000000",
      email: cleanEmail, // Enforced one email per farm node
      tpin: activeFarm?.tpin || "1002345678",
      financialYearStart: "2026-01-01",
      financialYearEnd: "2026-12-31",
      currency: farmForm.currency || "ZMW",
      currencySymbol: farmForm.currencySymbol || "ZK",
      taxSystem: farmForm.taxSystem || "Turnover Tax",
      taxType: newFarmTaxType || "TOT_5",
      createdAt: new Date().toISOString(),
      createdBy: actor.email,
      createdByName: actor.name
    };

    const updatedFarmsList = [...(farms || []), newFarm];

    if (setFarms) setFarms(updatedFarmsList);
    if (setActiveFarm) setActiveFarm(newFarm);
    if (handleUpdateActiveFarm) handleUpdateActiveFarm(newFarm);

    localStorage.setItem("mabala_farms", JSON.stringify(updatedFarmsList));
    localStorage.setItem("mabala_active_farm", JSON.stringify(newFarm));
    localStorage.setItem("mabala_farm_name", newFarm.name);
    localStorage.setItem("mabala_farm_email", cleanEmail);
    localStorage.setItem("mabala_user_email", cleanEmail);

    await FarmPersistenceService.saveFarmNodeWorkspace(cleanEmail, {
      farms: updatedFarmsList,
      email: cleanEmail
    });

    const targetUid = userProfile?.tenantId || userProfile?.uid || auth.currentUser?.uid || tenantId;
    if (targetUid && db && isConfigured) {
      try {
        const userDocRef = doc(db, "users_data", targetUid);
        await setDoc(
          userDocRef,
          {
            farms: updatedFarmsList,
            updatedAt: new Date().toISOString()
          },
          { merge: true }
        );

        const farmModuleRef = doc(db, "users_data", targetUid, "modules", "farms");
        await setDoc(
          farmModuleRef,
          {
            data: updatedFarmsList,
            updatedAt: new Date().toISOString()
          },
          { merge: true }
        );
      } catch (err) {
        console.warn("[FarmUserSettings] New farm Firestore save note:", err);
      }
    }

    if (handleSaveCloudWorkspace && targetUid) {
      handleSaveCloudWorkspace(targetUid).catch(console.warn);
    }

    if (writeAuditLog) {
      writeAuditLog(
        "CREATE",
        "Farm Nodes",
        newFarm.name,
        `Operator ${actor.name} (${actor.email}, Role: ${actor.role}) registered new farm node "${newFarm.name}" (${newFarm.id}) in ${newFarm.province}, Zambia.`
      );
    }

    setNewFarmName("");
    setNewFarmAddress("");
    setNewFarmPhone("");
    setShowAddFarmModal(false);

    if (showToast) showToast(`Created and switched to farm node "${newFarm.name}"!`, "success");
  };

  // SOFT-DELETE & ARCHIVAL WITH FINANCIAL CREDIT NOTE REVERSAL & AUDIT ATTRIBUTION
  const handleConfirmSoftDelete = async (farmToDelete: Farm) => {
    // 1. Enforce user attribution on delete operation
    const actor = getAuthenticatedActor();
    if (!actor) {
      setSaveErrorMsg("Access Denied: Farm node deletions must be traceable to an authenticated user with audit attribution.");
      if (showToast) showToast("Authentication required to delete farm nodes.", "error");
      return;
    }

    // Protection: Cannot delete currently active farm or sole farm
    if (farmToDelete.id === activeFarm?.id) {
      if (showToast) showToast("Cannot delete the currently active farm node. Switch to another active node first.", "error");
      setShowDeleteConfirmModal(null);
      return;
    }

    if (farms.length <= 1) {
      if (showToast) showToast("Cannot delete the primary/only farm node.", "error");
      setShowDeleteConfirmModal(null);
      return;
    }

    setSoftDeletingNodeId(farmToDelete.id);
    setIsSaving(true);

    try {
      const targetTenantId = tenantId || userProfile?.tenantId || userProfile?.uid || auth.currentUser?.uid;
      const { getFunctions, httpsCallable } = await import("firebase/functions");
      const { getApp } = await import("firebase/app");
      const softDeleteFarmNode = httpsCallable(getFunctions(getApp()), "softDeleteFarmNode");
      await softDeleteFarmNode({ tenantId: targetTenantId, farmId: farmToDelete.id });
      const updatedFarmsList = farms.filter((f) => f.id !== farmToDelete.id);
      if (setFarms) setFarms(updatedFarmsList);
      localStorage.setItem("mabala_farms", JSON.stringify(updatedFarmsList));
      setSaveSuccessMsg(`Farm node "${farmToDelete.name}" was archived and audited in the backend.`);
      if (showToast) showToast("Farm node archived successfully.", "success");
      setShowDeleteConfirmModal(null);
      return;

      // 2. Financial Reversal Logic: Issue a Credit Note in the financials
      const creditNoteNumber = `CN-FARM-${Date.now().toString().slice(-6)}`;
      const reversalCreditAmount = 150; // Standard farm node setup / licensing valuation reversal
      const farmCurrencySymbol = farmToDelete.currencySymbol || activeFarm?.currencySymbol || "ZK";

      const newCreditNote: CreditNote = {
        id: `cn-${Date.now()}`,
        creditNoteNumber,
        invoiceId: `INV-NODE-${farmToDelete.id}`,
        invoiceNumber: `NODE-SETUP-${farmToDelete.id}`,
        date: new Date().toISOString().split("T")[0],
        customerName: farmToDelete.name,
        subtotal: reversalCreditAmount,
        taxAmount: 0,
        total: reversalCreditAmount,
        lines: [
          {
            description: `Soft-deletion reversal credit for Farm Node "${farmToDelete.name}" (${farmToDelete.id})`,
            quantity: 1,
            unitPrice: reversalCreditAmount,
            amount: reversalCreditAmount
          }
        ],
        reason: `Administrative soft deletion & archival of farm node ${farmToDelete.name} by ${actor.email}`,
        coaDebit: "4500", // Debit Setup / Operating Revenue
        coaCredit: "1100", // Credit Receivables
        farmId: farmToDelete.id
      };

      if (onAddCreditNote) {
        onAddCreditNote(newCreditNote);
      } else if (setCreditNotes) {
        setCreditNotes((prev: any) => [newCreditNote, ...(prev || [])]);
      }

      // Update general ledger accounts
      if (setAccounts && accounts) {
        const updatedAccounts = accounts.map((acc: any) => {
          let balance = acc.balance;
          if (acc.code === "1100") {
            balance -= reversalCreditAmount;
          }
          if (acc.code === "4500" || (acc.category === "Revenue" && acc.code === "4505")) {
            balance -= reversalCreditAmount;
          }
          return { ...acc, balance };
        });
        setAccounts(updatedAccounts);
      }

      // 3. Soft-delete archival: Mark as archived, invisible to farm node users, restorable by super admin
      const archiveRecord: ArchiveRecord = {
        id: `ARC-FARM-${Date.now().toString().slice(-6)}`,
        archivedAt: new Date().toISOString(),
        module: "Farm Nodes",
        originalId: farmToDelete.id,
        description: `Farm Node: ${farmToDelete.name} (${farmToDelete.id}) - ${farmToDelete.province}`,
        data: JSON.stringify({
          ...farmToDelete,
          isArchived: true,
          deletedAt: new Date().toISOString(),
          deletedBy: actor.name,
          deletedByEmail: actor.email,
          deletedByRole: actor.role,
          creditNoteNumber,
          reversalCreditAmount
        }),
        farmId: farmToDelete.id
      };

      // 4. Update farms list (removing the archived farm node so it's invisible in UI)
      const legacyUpdatedFarmsList = farms.filter((f) => f.id !== farmToDelete.id);
      if (setFarms) setFarms(legacyUpdatedFarmsList);

      // Save to localStorage & IndexedDB
      localStorage.setItem("mabala_farms", JSON.stringify(legacyUpdatedFarmsList));
      const cleanEmail = (nodeEmail || resolvedInitialEmail).trim().toLowerCase();
      await FarmPersistenceService.saveFarmNodeWorkspace(cleanEmail, {
        farms: legacyUpdatedFarmsList,
        email: cleanEmail
      });

      // Save to Firestore
      const targetUid = userProfile?.tenantId || userProfile?.uid || auth.currentUser?.uid || tenantId;
      if (targetUid && db && isConfigured) {
        try {
          const userDocRef = doc(db, "users_data", targetUid);
          await setDoc(
            userDocRef,
            {
              farms: updatedFarmsList,
              updatedAt: new Date().toISOString()
            },
            { merge: true }
          );

          const farmModuleRef = doc(db, "users_data", targetUid, "modules", "farms");
          await setDoc(
            farmModuleRef,
            {
              data: updatedFarmsList,
              updatedAt: new Date().toISOString()
            },
            { merge: true }
          );

          // Archive safe subcollection
          const archiveRef = doc(db, "users_data", targetUid, "archived_records", archiveRecord.id);
          await setDoc(archiveRef, archiveRecord);
        } catch (dbErr) {
          console.warn("[FarmUserSettings] Firestore delete note:", dbErr);
        }
      }

      if (handleSaveCloudWorkspace && targetUid) {
        try {
          await handleSaveCloudWorkspace(targetUid);
        } catch (syncErr) {}
      }

      // 5. Complete Audit Trail Tracking
      if (writeAuditLog) {
        writeAuditLog(
          "DELETE",
          "Farm Nodes",
          farmToDelete.name,
          `Soft-deleted and archived farm node "${farmToDelete.name}" (${farmToDelete.id}) by ${actor.name} (${actor.email}). Reversal Credit Note #${creditNoteNumber} issued for -${farmCurrencySymbol}${reversalCreditAmount}. User attribution verified.`
        );
      }

      setSaveSuccessMsg(`Farm node "${farmToDelete.name}" has been soft-deleted and archived. Financial Credit Note #${creditNoteNumber} posted to financials.`);
      if (showToast) showToast(`Farm node soft-deleted. Credit Note #${creditNoteNumber} issued.`, "success");
      setShowDeleteConfirmModal(null);
    } catch (err: any) {
      console.error("[FarmUserSettings] Soft delete error:", err);
      setSaveErrorMsg(`Error archiving farm node: ${err?.message || "Operation failed."}`);
      if (showToast) showToast("Failed to soft-delete farm node.", "error");
    } finally {
      setIsSaving(false);
      setSoftDeletingNodeId(null);
      setTimeout(() => {
        setSaveSuccessMsg(null);
        setSaveErrorMsg(null);
      }, 6000);
    }
  };

  // SOFT-DELETE & ARCHIVE CUSTOM TAX REGIME WITH FINANCIAL REVERSAL & AUDIT ATTRIBUTION
  const handleSoftDeleteCustomTax = async () => {
    const actor = getAuthenticatedActor();
    if (!actor) {
      if (showToast) showToast("Authentication required to modify tax configurations.", "error");
      return;
    }

    setIsSaving(true);
    try {
      const creditNoteNumber = `CN-TAX-${Date.now().toString().slice(-6)}`;
      const customTaxAmount = 50;

      const archiveRecord: ArchiveRecord = {
        id: `ARC-TAX-${Date.now().toString().slice(-6)}`,
        archivedAt: new Date().toISOString(),
        module: "Settings & Configurations",
        originalId: `tax-${activeFarm?.id || "farm-1"}`,
        description: `Custom Tax Configuration: ${farmForm.customTaxName} (${farmForm.customTaxRate}%)`,
        data: JSON.stringify({
          customTaxName: farmForm.customTaxName,
          customTaxRate: farmForm.customTaxRate,
          farmId: activeFarm?.id,
          farmName: activeFarm?.name,
          deletedAt: new Date().toISOString(),
          deletedBy: actor.name,
          deletedByEmail: actor.email,
          creditNoteNumber,
          reversalCreditAmount: customTaxAmount
        }),
        farmId: activeFarm?.id || "farm-1"
      };

      // Reset to standard turnover tax regime
      setFarmForm((prev) => ({
        ...prev,
        taxType: "TOT_5",
        taxSystem: "Turnover Tax",
        customTaxName: "",
        customTaxRate: 0
      }));

      // Update active farm state
      if (handleUpdateActiveFarm) {
        handleUpdateActiveFarm({
          taxType: "TOT_5",
          taxSystem: "Turnover Tax",
          customTaxName: "",
          customTaxRate: 0
        });
      }

      if (writeAuditLog) {
        writeAuditLog(
          "DELETE",
          "Settings & Configurations",
          "Custom Tax Configuration",
          `Soft-deleted and archived custom tax configuration ("${farmForm.customTaxName}") by ${actor.name} (${actor.email}). Reset to standard Turnover Tax (5%). Credit Note #${creditNoteNumber} logged.`
        );
      }

      setSaveSuccessMsg("Custom tax regime archived and reset to standard Turnover Tax (5%).");
      if (showToast) showToast("Custom tax archived and reset to standard TOT.", "success");
    } catch (err: any) {
      setSaveErrorMsg("Failed to archive custom tax configuration.");
      if (showToast) showToast("Failed to archive tax configuration.", "error");
    } finally {
      setIsSaving(false);
      setTimeout(() => {
        setSaveSuccessMsg(null);
        setSaveErrorMsg(null);
      }, 5000);
    }
  };

  // SUPER ADMIN RESTORATION HANDLER WITH FINANCIAL REVERSAL CREDITS
  const handleRestoreArchivedRecord = async (arc: ArchiveRecord) => {
    const actor = getAuthenticatedActor();
    if (!actor) {
      if (showToast) showToast("Authentication required to restore archived records.", "error");
      return;
    }

    setRestoringRecordId(arc.id);
    setIsSaving(true);

    try {
      if (arc.module === "Farm Nodes" && isSuperAdmin) {
        const parsed = JSON.parse(arc.data);
        const targetTenantId = tenantId || parsed.tenantId || parsed.tenantUid || parsed.ownerUid;
        const { getFunctions, httpsCallable } = await import("firebase/functions");
        const { getApp } = await import("firebase/app");
        const restoreFarmNode = httpsCallable(getFunctions(getApp()), "restoreFarmNode");
        await restoreFarmNode({ tenantId: targetTenantId, farmId: arc.originalId });
        const restoredFarm: Farm = { ...parsed, isArchived: false, isDeleted: false };
        const nextFarms = [...farms.filter((f) => f.id !== restoredFarm.id), restoredFarm];
        if (setFarms) setFarms(nextFarms);
        localStorage.setItem("mabala_farms", JSON.stringify(nextFarms));
        setSaveSuccessMsg(`Farm node "${restoredFarm.name}" was restored and audited in the backend.`);
        if (showToast) showToast("Farm node restored successfully.", "success");
        return;
      }

      if (onRestoreFromArchive) {
        onRestoreFromArchive(arc);
      } else {
        const parsed = JSON.parse(arc.data);
        if (arc.module === "Farm Nodes") {
          const restoredFarm: Farm = {
            ...parsed,
            isArchived: false
          };
          const nextFarms = [...farms.filter((f) => f.id !== restoredFarm.id), restoredFarm];
          if (setFarms) setFarms(nextFarms);
          localStorage.setItem("mabala_farms", JSON.stringify(nextFarms));

          const reversalCredit = Number(parsed.reversalCreditAmount) || 150;
          if (setAccounts && accounts) {
            const updatedAccounts = accounts.map((acc: any) => {
              let balance = acc.balance;
              if (acc.code === "1010" || acc.code === "1100") {
                balance += reversalCredit;
              }
              return { ...acc, balance };
            });
            setAccounts(updatedAccounts);
          }

          if (setCredits) {
            setCredits((prev) => Math.min(1000, (prev || 0) + 10));
          }

          if (writeAuditLog) {
            writeAuditLog(
              "RESTORE",
              arc.module,
              arc.description,
              `Super Admin (${actor.name} - ${actor.email}) restored archived farm node "${restoredFarm.name}". Financial credit reversal applied: +${restoredFarm.currencySymbol || "ZK"}${reversalCredit}. Operator attribution verified.`
            );
          }
        }
      }

      setSaveSuccessMsg(`Successfully restored archived record: ${arc.description}`);
      if (showToast) showToast("Farm node restored successfully with financial credits applied!", "success");
    } catch (err: any) {
      console.error("[FarmUserSettings] Restoration error:", err);
      setSaveErrorMsg(`Failed to restore record: ${err?.message}`);
      if (showToast) showToast("Restoration failed.", "error");
    } finally {
      setIsSaving(false);
      setRestoringRecordId(null);
      setTimeout(() => {
        setSaveSuccessMsg(null);
        setSaveErrorMsg(null);
      }, 6000);
    }
  };

  // Save Notification Preferences with Enforced User Attribution & Numeric Validation
  const handleSaveNotificationPreferences = async () => {
    setIsSaving(true);
    setSaveSuccessMsg(null);
    setSaveErrorMsg(null);

    const actor = getAuthenticatedActor();
    if (!actor) {
      setSaveErrorMsg("Access Denied: Modifying notification preferences requires an authenticated operator session.");
      if (showToast) showToast("Authentication required.", "error");
      setIsSaving(false);
      return;
    }

    // Numeric validation
    const stockThreshold = Math.max(0, Number(notificationPrefs.lowStockThreshold) || 0);
    const overdueDays = Math.max(0, Number(notificationPrefs.overdueDays) || 0);

    const validatedPrefs = {
      ...notificationPrefs,
      lowStockThreshold: stockThreshold,
      overdueDays: overdueDays
    };

    try {
      localStorage.setItem("mabala_notification_prefs", JSON.stringify(validatedPrefs));
      const targetUid = userProfile?.tenantId || userProfile?.uid || auth.currentUser?.uid || tenantId;
      if (targetUid && db && isConfigured) {
        const userDocRef = doc(db, "users_data", targetUid);
        await setDoc(
          userDocRef,
          {
            notificationPrefs: validatedPrefs,
            updatedAt: new Date().toISOString()
          },
          { merge: true }
        );
      }

      const cleanEmail = (nodeEmail || resolvedInitialEmail).trim().toLowerCase();
      await FarmPersistenceService.saveFarmNodeWorkspace(cleanEmail, {
        email: cleanEmail
      } as any);

      if (writeAuditLog) {
        writeAuditLog(
          "UPDATE",
          "Settings & Configurations",
          "Notification Preferences",
          `Operator ${actor.name} (${actor.email}, Role: ${actor.role}) updated alert dispatch rules and thresholds (Low Stock: ${stockThreshold}, Overdue: ${overdueDays}d). User attribution verified.`
        );
      }

      setSaveSuccessMsg("Notification and alert dispatch preferences saved successfully!");
      if (showToast) showToast("Notification preferences updated!", "success");
    } catch (err: any) {
      console.warn("Notification prefs save error:", err);
      setSaveSuccessMsg("Notification preferences saved to local workspace.");
      if (showToast) showToast("Notification preferences saved locally.", "info");
    } finally {
      setIsSaving(false);
      setTimeout(() => {
        setSaveSuccessMsg(null);
        setSaveErrorMsg(null);
      }, 5000);
    }
  };

  // Trigger Password Reset Email
  const handleTriggerPasswordReset = async () => {
    const targetEmail = profileForm.email || userProfile?.email || userEmail;
    if (!targetEmail) {
      setResetEmailError("Please provide a valid email address first.");
      return;
    }

    setResetEmailError(null);
    setResetEmailSent(false);

    try {
      if (auth) {
        await sendPasswordResetEmail(auth, targetEmail);
        setResetEmailSent(true);
        if (showToast) showToast(`Password reset link sent to ${targetEmail}!`, "success");
      } else {
        setResetEmailSent(true);
      }
    } catch (err: any) {
      setResetEmailError(err?.message || "Failed to trigger password reset. Please try again.");
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12 animate-fade-in font-sans" id="farm-user-settings-hub">
      {/* HEADER BANNER */}
      <div className="bg-gradient-to-r from-[#0B2265] via-indigo-950 to-slate-900 border border-indigo-900/60 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 text-xs font-black uppercase tracking-wider rounded-lg border border-emerald-500/30 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5" />
                Settings & Configuration
              </span>
              <span className="px-2.5 py-1 bg-white/10 text-slate-300 text-xs font-mono font-bold rounded-lg border border-white/10">
                Tenant: {userProfile?.tenantId || activeFarm?.id || "TENANT-001"}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-3">
              {activeFarm?.name || "Mabala Farm Workspace"}
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Manage your personal account profile, agricultural node properties, ZRA statutory taxation parameters, multi-farm nodes, and communication preferences.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <div className="bg-slate-900/80 border border-slate-700/80 rounded-2xl p-3.5 flex items-center gap-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-black text-sm">
                {profileForm.name ? profileForm.name.slice(0, 2).toUpperCase() : "FO"}
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-white truncate max-w-[140px]">
                  {profileForm.name || "Farm Owner"}
                </span>
                <span className="text-[10px] text-emerald-400 font-mono font-bold uppercase">
                  {currentRole}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* FEEDBACK ALERT */}
        {saveSuccessMsg && (
          <div className="mt-4 p-3 bg-emerald-950/60 border border-emerald-500/50 rounded-2xl text-emerald-300 text-xs font-bold flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{saveSuccessMsg}</span>
          </div>
        )}

        {saveErrorMsg && (
          <div className="mt-4 p-3 bg-rose-950/70 border border-rose-500/60 rounded-2xl text-rose-200 text-xs font-bold flex items-center gap-2 animate-fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{saveErrorMsg}</span>
          </div>
        )}
      </div>

      {/* HORIZONTAL TAB NAVIGATION */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-200 scrollbar-none">
        <button
          type="button"
          onClick={() => setActiveSection("farm")}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeSection === "farm"
              ? "bg-[#0B2265] text-white shadow-sm"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Farm / Business Node</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection("profile")}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeSection === "profile"
              ? "bg-[#0B2265] text-white shadow-sm"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <User className="w-4 h-4" />
          <span>User & Account Profile</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection("tax")}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeSection === "tax"
              ? "bg-[#0B2265] text-white shadow-sm"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Landmark className="w-4 h-4" />
          <span>Statutory & Tax (ZRA)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection("farms_list")}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeSection === "farms_list"
              ? "bg-[#0B2265] text-white shadow-sm"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Multi-Farm Nodes ({farms.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection("notifications")}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeSection === "notifications"
              ? "bg-[#0B2265] text-white shadow-sm"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Bell className="w-4 h-4" />
          <span>Notifications & Alerts</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection("security")}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeSection === "security"
              ? "bg-[#0B2265] text-white shadow-sm"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>Security & System</span>
        </button>
      </div>

      {/* SECTION 1: FARM / BUSINESS PROFILE */}
      {activeSection === "farm" && (
        <form onSubmit={handleSaveFarmSettings} className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Tractor className="w-5 h-5 text-emerald-600" />
                  Active Farm Node Identification
                </h3>
                <p className="text-xs text-slate-500">
                  Primary agricultural node specifications, geographical territory, and farm management details.
                </p>
              </div>
              <span className="px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-black rounded-lg border border-emerald-200">
                Node ID: {farmForm.id}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {/* Farm Node Primary Email Identifier (Immutable Node ID) */}
              <div className="space-y-1.5 md:col-span-2 lg:col-span-3 p-4 bg-slate-100/70 rounded-2xl border border-slate-300">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-slate-500" />
                    <span>Farm Node Primary Email Identifier</span>
                    <span className="text-[10px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded font-mono font-bold uppercase tracking-wider">
                      Immutable Node ID
                    </span>
                  </label>
                  <span className="text-[10px] text-slate-700 font-bold bg-slate-200/80 border border-slate-300 px-2.5 py-0.5 rounded-full inline-flex items-center gap-1">
                    <Lock className="w-3 h-3 text-slate-500" />
                    Read-Only (One Email Per Node Enforced)
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="email"
                    readOnly
                    disabled
                    value={nodeEmail}
                    className="w-full px-3.5 py-2.5 bg-slate-200/80 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-600 cursor-not-allowed select-none outline-none shadow-2xs pr-10"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>
                    The email address serves as the permanent unique identifier for each farm node, and the platform enforces one email per node. This field is immutable and cannot be changed.
                  </span>
                </p>
              </div>

              {/* Farm Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Farm / Enterprise Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={farmForm.name}
                  onChange={(e) => {
                    setFarmForm({ ...farmForm, name: e.target.value });
                    if (validationErrors.name) setValidationErrors((prev) => ({ ...prev, name: "" }));
                  }}
                  placeholder="e.g. Deep Valley Farm Limited"
                  className={`w-full px-3.5 py-2.5 bg-slate-50 border ${
                    validationErrors.name ? "border-rose-500 ring-1 ring-rose-500" : "border-slate-300"
                  } rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition`}
                />
                {validationErrors.name && (
                  <span className="text-[11px] text-rose-600 font-bold block">{validationErrors.name}</span>
                )}
              </div>

              {/* Farm Letterhead / Official Title */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Official Letterhead Title
                </label>
                <input
                  type="text"
                  value={farmForm.letterheadTitle}
                  onChange={(e) => setFarmForm({ ...farmForm, letterheadTitle: e.target.value })}
                  placeholder="e.g. Deep Valley Farm & Milling Ltd"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
                <span className="text-[10px] text-slate-400 block">Header rendered on invoices, dispatch notes & receipts</span>
              </div>

              {/* Registration / PACRA Number */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  PACRA / Registration No.
                </label>
                <input
                  type="text"
                  value={farmForm.registrationNumber}
                  onChange={(e) => setFarmForm({ ...farmForm, registrationNumber: e.target.value })}
                  placeholder="e.g. 120220045678"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
              </div>

              {/* Farming Category */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Primary Sector / Enterprise Type
                </label>
                <select
                  value={farmForm.farmingType}
                  onChange={(e) => setFarmForm({ ...farmForm, farmingType: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                >
                  <option value="Mixed Crops & Livestock">Mixed Crops & Livestock</option>
                  <option value="Commercial Row Crops (Maize, Soya, Wheat)">Commercial Row Crops (Maize, Soya, Wheat)</option>
                  <option value="Livestock & Dairy Farming">Livestock & Dairy Farming</option>
                  <option value="Commercial Poultry (Broilers & Layers)">Commercial Poultry (Broilers & Layers)</option>
                  <option value="Aquaculture & Fish Farming">Aquaculture & Fish Farming</option>
                  <option value="Horticulture & Orchard (Avocado, Macadamia, Citrus)">Horticulture & Orchard (Avocado, Macadamia, Citrus)</option>
                  <option value="Agro-Dealer Input & Distribution Hub">Agro-Dealer Input & Distribution Hub</option>
                  <option value="Offtaker Grain & Commodity Depot">Offtaker Grain & Commodity Depot</option>
                </select>
              </div>

              {/* Province (Zambia) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Province <span className="text-rose-500">*</span>
                </label>
                <select
                  value={farmForm.province}
                  onChange={(e) => {
                    handleProvinceChange(e.target.value);
                    if (validationErrors.province) setValidationErrors((prev) => ({ ...prev, province: "" }));
                  }}
                  className={`w-full px-3.5 py-2.5 bg-slate-50 border ${
                    validationErrors.province ? "border-rose-500 ring-1 ring-rose-500" : "border-slate-300"
                  } rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition`}
                >
                  {ZAMBIA_PROVINCES_ALPHABETICAL.map((prov) => (
                    <option key={prov} value={prov}>
                      {prov} Province
                    </option>
                  ))}
                </select>
                {validationErrors.province && (
                  <span className="text-[11px] text-rose-600 font-bold block">{validationErrors.province}</span>
                )}
              </div>

              {/* District (Zambia) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  District <span className="text-rose-500">*</span>
                </label>
                <select
                  value={farmForm.district}
                  onChange={(e) => {
                    setFarmForm({ ...farmForm, district: e.target.value });
                    if (validationErrors.district) setValidationErrors((prev) => ({ ...prev, district: "" }));
                  }}
                  className={`w-full px-3.5 py-2.5 bg-slate-50 border ${
                    validationErrors.district ? "border-rose-500 ring-1 ring-rose-500" : "border-slate-300"
                  } rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition`}
                >
                  {availableDistricts.map((dist) => (
                    <option key={dist} value={dist}>
                      {dist}
                    </option>
                  ))}
                </select>
                {validationErrors.district && (
                  <span className="text-[11px] text-rose-600 font-bold block">{validationErrors.district}</span>
                )}
              </div>

              {/* Physical Location Address */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Physical Farm Address / Plot No.
                </label>
                <input
                  type="text"
                  value={farmForm.address}
                  onChange={(e) => setFarmForm({ ...farmForm, address: e.target.value })}
                  placeholder="e.g. Farm Block 45, Mukushi Farming Block"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
              </div>

              {/* Farm Size & Unit */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Land Size Area
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    step="any"
                    min="0"
                    value={farmForm.size}
                    onChange={(e) => {
                      setFarmForm({ ...farmForm, size: e.target.value });
                      if (validationErrors.size) setValidationErrors((prev) => ({ ...prev, size: "" }));
                    }}
                    placeholder="50"
                    className={`w-2/3 px-3.5 py-2.5 bg-slate-50 border ${
                      validationErrors.size ? "border-rose-500 ring-1 ring-rose-500" : "border-slate-300"
                    } rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition`}
                  />
                  <select
                    value={farmForm.sizeUnit}
                    onChange={(e) => setFarmForm({ ...farmForm, sizeUnit: e.target.value })}
                    className="w-1/3 px-2.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                  >
                    <option value="Hectares">Ha</option>
                    <option value="Acres">Acres</option>
                    <option value="Plots">Plots</option>
                  </select>
                </div>
                {validationErrors.size && (
                  <span className="text-[11px] text-rose-600 font-bold block">{validationErrors.size}</span>
                )}
              </div>

              {/* Farm Contact Phone */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Primary Farm Phone / WhatsApp
                </label>
                <input
                  type="tel"
                  inputMode="tel"
                  value={farmForm.phone}
                  onChange={(e) => setFarmForm({ ...farmForm, phone: e.target.value })}
                  placeholder="e.g. +260978070734"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
              </div>

              {/* Farm Manager Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Farm Manager / Key Contact
                </label>
                <input
                  type="text"
                  value={farmForm.managerName}
                  onChange={(e) => setFarmForm({ ...farmForm, managerName: e.target.value })}
                  placeholder="e.g. Kelvin Mwewa"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-end">
              <button
                type="submit"
                disabled={isSaving}
                className="px-6 py-2.5 bg-[#0B2265] hover:bg-[#071746] active:scale-95 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                {isSaving ? "Saving Farm Changes..." : "Save Farm Node Settings"}
              </button>
            </div>
          </div>
        </form>
      )}

      {/* SECTION 2: USER & ACCOUNT PROFILE */}
      {activeSection === "profile" && (
        <form onSubmit={handleSaveUserProfile} className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <User className="w-5 h-5 text-indigo-600" />
                  Account User Profile
                </h3>
                <p className="text-xs text-slate-500">
                  Update your contact details, designation, and personal identification.
                </p>
              </div>
              <span className="px-3 py-1 bg-indigo-50 text-indigo-700 text-xs font-black rounded-lg border border-indigo-200">
                Role: {currentRole}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {/* Full Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={profileForm.name}
                  onChange={(e) => {
                    setProfileForm({ ...profileForm, name: e.target.value });
                    if (validationErrors.profileName) setValidationErrors((prev) => ({ ...prev, profileName: "" }));
                  }}
                  placeholder="e.g. Sydney Shikasuli"
                  className={`w-full px-3.5 py-2.5 bg-slate-50 border ${
                    validationErrors.profileName ? "border-rose-500 ring-1 ring-rose-500" : "border-slate-300"
                  } rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition`}
                />
                {validationErrors.profileName && (
                  <span className="text-[11px] text-rose-600 font-bold block">{validationErrors.profileName}</span>
                )}
              </div>

              {/* Email Address (Immutable Node Identifier) */}
              <div className="space-y-1.5 p-3.5 bg-slate-100/70 rounded-2xl border border-slate-300">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-slate-500" />
                    <span>Account Email Address</span>
                  </label>
                  <span className="text-[10px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded font-mono font-bold uppercase border border-slate-300">
                    Read-Only (Immutable Node ID)
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="email"
                    readOnly
                    disabled
                    value={nodeEmail}
                    className="w-full px-3.5 py-2.5 bg-slate-200/80 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-600 cursor-not-allowed select-none outline-none shadow-2xs pr-10"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                </div>
                <span className="text-[10px] text-slate-500 block leading-tight flex items-center gap-1">
                  <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>Unique node identifier; strictly enforced as one email per farm node. This field cannot be edited.</span>
                </span>
              </div>

              {/* Phone / WhatsApp */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Direct Mobile Phone / WhatsApp
                </label>
                <input
                  type="tel"
                  inputMode="tel"
                  value={profileForm.phone}
                  onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                  placeholder="+260978070734"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
              </div>

              {/* National ID / NRC */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  National ID (NRC / Passport No.)
                </label>
                <input
                  type="text"
                  value={profileForm.nationalId}
                  onChange={(e) => setProfileForm({ ...profileForm, nationalId: e.target.value })}
                  placeholder="e.g. 123456/78/1"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
              </div>

              {/* Job Title / Designation */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Designation / Operational Role
                </label>
                <input
                  type="text"
                  value={profileForm.designation}
                  onChange={(e) => setProfileForm({ ...profileForm, designation: e.target.value })}
                  placeholder="e.g. Managing Director / Lead Agronomist"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
              </div>

              {/* Address */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Residential / Office Address
                </label>
                <input
                  type="text"
                  value={profileForm.address}
                  onChange={(e) => setProfileForm({ ...profileForm, address: e.target.value })}
                  placeholder="e.g. Lusaka, Zambia"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
              </div>
            </div>

            {/* Bio / Description */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 block">
                Professional Bio / Enterprise Description
              </label>
              <textarea
                rows={3}
                value={profileForm.bio}
                onChange={(e) => setProfileForm({ ...profileForm, bio: e.target.value })}
                placeholder="Brief summary of your farming operations or management responsibilities..."
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
              />
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-end">
              <button
                type="submit"
                disabled={isSaving}
                className="px-6 py-2.5 bg-[#0B2265] hover:bg-[#071746] active:scale-95 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                {isSaving ? "Saving Profile..." : "Save User Profile"}
              </button>
            </div>
          </div>
        </form>
      )}

      {/* SECTION 3: STATUTORY, TAX & FISCAL SETTINGS */}
      {activeSection === "tax" && (
        <form onSubmit={handleSaveFarmSettings} className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Landmark className="w-5 h-5 text-emerald-600" />
                  Statutory Taxation & Fiscal Currency Settings
                </h3>
                <p className="text-xs text-slate-500">
                  Configure Zambia Revenue Authority (ZRA) compliance, TPIN, Turnover Tax, Standard VAT, and currency formatting.
                </p>
              </div>
              <span className="px-3 py-1 bg-emerald-50 text-emerald-800 text-xs font-black rounded-lg border border-emerald-200">
                {farmForm.taxType === "VAT_16" ? "VAT (16%) Active" : farmForm.taxType === "TOT_4" ? "Turnover Tax (4%)" : "Turnover Tax (5%)"}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {/* Taxpayer Identification Number (TPIN) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  ZRA TPIN (Taxpayer Identification No.) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={farmForm.tpin}
                  onChange={(e) => setFarmForm({ ...farmForm, tpin: e.target.value })}
                  placeholder="e.g. 1002498712"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
              </div>

              {/* VAT Registration Number (if applicable) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  VAT Registration Number (Optional)
                </label>
                <input
                  type="text"
                  value={farmForm.vatNumber}
                  onChange={(e) => setFarmForm({ ...farmForm, vatNumber: e.target.value })}
                  placeholder="e.g. VAT-88992211"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
              </div>

              {/* Tax Regime Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Statutory Tax Regime (ZRA)
                </label>
                <select
                  value={farmForm.taxType}
                  onChange={(e) => {
                    const val = e.target.value;
                    let taxSys: "VAT" | "Sales Tax" | "Turnover Tax" | "None" = "Turnover Tax";
                    if (val === "VAT_16") taxSys = "VAT";
                    else if (val === "EXEMPT") taxSys = "None";
                    else if (val === "CUSTOM") taxSys = "Sales Tax";
                    setFarmForm({
                      ...farmForm,
                      taxType: val,
                      taxSystem: taxSys
                    });
                  }}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                >
                  <option value="TOT_5">Turnover Tax - Standard TOT (5%)</option>
                  <option value="TOT_4">Turnover Tax - Agro Concession (4%)</option>
                  <option value="VAT_16">Standard Value Added Tax (VAT 16%)</option>
                  <option value="EXEMPT">Tax Exempt / Zero Rated Agricultural Output (0%)</option>
                  <option value="CUSTOM">Custom Statutory Levy Rate</option>
                </select>
              </div>

              {/* Custom Tax Parameters if Selected */}
              {farmForm.taxType === "CUSTOM" && (
                <>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 block">
                      Custom Tax Name
                    </label>
                    <input
                      type="text"
                      value={farmForm.customTaxName}
                      onChange={(e) => setFarmForm({ ...farmForm, customTaxName: e.target.value })}
                      placeholder="e.g. Local District Council Levy"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 block">
                      Custom Tax Rate (%)
                    </label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      max="100"
                      value={farmForm.customTaxRate}
                      onChange={(e) => {
                        const val = e.target.value === "" ? ("" as any) : Number(e.target.value);
                        setFarmForm({ ...farmForm, customTaxRate: val });
                        if (validationErrors.customTaxRate) setValidationErrors((prev) => ({ ...prev, customTaxRate: "" }));
                      }}
                      placeholder="5"
                      className={`w-full px-3.5 py-2.5 bg-slate-50 border ${
                        validationErrors.customTaxRate ? "border-rose-500 ring-1 ring-rose-500" : "border-slate-300"
                      } rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition`}
                    />
                    {validationErrors.customTaxRate && (
                      <span className="text-[11px] text-rose-600 font-bold block">{validationErrors.customTaxRate}</span>
                    )}
                  </div>

                  <div className="md:col-span-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 bg-amber-50/80 border border-amber-200 rounded-2xl">
                    <div className="text-xs text-amber-900 space-y-0.5">
                      <span className="font-bold flex items-center gap-1.5 text-amber-950">
                        <Archive className="w-3.5 h-3.5 text-amber-700" />
                        Archive Custom Tax Configuration
                      </span>
                      <p className="text-[11px] text-amber-700">
                        Soft-delete this custom tax rule, generate an audit record, and safely revert to standard Turnover Tax (5%).
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={isSaving}
                      onClick={handleSoftDeleteCustomTax}
                      className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0 disabled:opacity-50"
                    >
                      <Archive className="w-3.5 h-3.5" />
                      Archive & Reset Rate
                    </button>
                  </div>
                </>
              )}

              {/* Currency Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Accounting Currency
                </label>
                <select
                  value={farmForm.currency}
                  onChange={(e) => {
                    const cur = e.target.value;
                    let sym = "ZK";
                    if (cur === "USD") sym = "$";
                    else if (cur === "EUR") sym = "€";
                    else if (cur === "GBP") sym = "£";
                    else if (cur === "ZAR") sym = "R";
                    setFarmForm({ ...farmForm, currency: cur, currencySymbol: sym });
                  }}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                >
                  <option value="ZMW">Zambian Kwacha (ZMW - ZK)</option>
                  <option value="USD">US Dollar (USD - $)</option>
                  <option value="EUR">Euro (EUR - €)</option>
                  <option value="GBP">British Pound (GBP - £)</option>
                  <option value="ZAR">South African Rand (ZAR - R)</option>
                </select>
              </div>

              {/* Financial Year Dates */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Financial Year Start
                </label>
                <input
                  type="date"
                  value={farmForm.financialYearStart}
                  onChange={(e) => setFarmForm({ ...farmForm, financialYearStart: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Financial Year End
                </label>
                <input
                  type="date"
                  value={farmForm.financialYearEnd}
                  onChange={(e) => {
                    setFarmForm({ ...farmForm, financialYearEnd: e.target.value });
                    if (validationErrors.financialYearEnd) setValidationErrors((prev) => ({ ...prev, financialYearEnd: "" }));
                  }}
                  className={`w-full px-3.5 py-2.5 bg-slate-50 border ${
                    validationErrors.financialYearEnd ? "border-rose-500 ring-1 ring-rose-500" : "border-slate-300"
                  } rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none transition`}
                />
                {validationErrors.financialYearEnd && (
                  <span className="text-[11px] text-rose-600 font-bold block">{validationErrors.financialYearEnd}</span>
                )}
              </div>
            </div>

            {/* Informational ZRA Compliance Card */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-start gap-3">
              <Info className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
              <div className="text-xs text-slate-600 space-y-1">
                <span className="font-bold text-slate-800 block">ZRA Compliance Calculation Engine</span>
                <p>
                  All invoices, crop sales receipts, agro-dealer Point-of-Sale orders, and tax reports will automatically calculate tax obligations according to this configuration. VAT returns (Form ZRA-VAT-01) and Turnover Tax summaries will compile automatically in the Reports Hub.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-end">
              <button
                type="submit"
                disabled={isSaving}
                className="px-6 py-2.5 bg-[#0B2265] hover:bg-[#071746] active:scale-95 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                {isSaving ? "Saving Statutory Config..." : "Save Statutory & Tax Settings"}
              </button>
            </div>
          </div>
        </form>
      )}

      {/* SECTION 4: MULTI-FARM NODES MANAGEMENT */}
      {activeSection === "farms_list" && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Layers className="w-5 h-5 text-emerald-600" />
                  Managed Farm Nodes & Locations ({farms.length})
                </h3>
                <p className="text-xs text-slate-500">
                  Switch active operational context between different farm branches, fields, or agricultural depots.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowAddFarmModal(true)}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-2 cursor-pointer shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Register New Farm Node</span>
              </button>
            </div>

            {/* Farm Nodes Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {farms.map((farm) => {
                const isActive = farm.id === activeFarm?.id;
                return (
                  <div
                    key={farm.id}
                    className={`border rounded-2xl p-5 transition-all relative ${
                      isActive
                        ? "bg-gradient-to-br from-slate-900 to-indigo-950 text-white border-indigo-500/50 shadow-md"
                        : "bg-slate-50/70 hover:bg-white text-slate-900 border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="space-y-0.5">
                        <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded ${
                          isActive ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-slate-200 text-slate-700"
                        }`}>
                          {farm.id}
                        </span>
                        <h4 className={`text-sm font-bold truncate mt-1 ${isActive ? "text-white" : "text-slate-900"}`}>
                          {farm?.name || "Farm Node"}
                        </h4>
                      </div>
                      {isActive && (
                        <span className="px-2 py-0.5 bg-emerald-500 text-slate-950 text-[10px] font-black rounded-md">
                          ACTIVE
                        </span>
                      )}
                    </div>

                    <div className={`space-y-1 text-xs mb-4 ${isActive ? "text-slate-300" : "text-slate-500"}`}>
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 shrink-0 text-emerald-500" />
                        <span className="truncate">{farm?.district || farm?.location?.district || "Kabwe"}, {farm?.province || farm?.location?.province || "Central"}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 shrink-0 text-indigo-400" />
                        <span>{farm?.phone || "No phone listed"}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Landmark className="w-3.5 h-3.5 shrink-0 text-amber-400" />
                        <span>Currency: {farm?.currencySymbol || "ZK"} {farm?.currency || "ZMW"}</span>
                      </div>
                    </div>

                    {!isActive ? (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            if (setActiveFarm) {
                              setActiveFarm(farm);
                              localStorage.setItem("mabala_active_farm", JSON.stringify(farm));
                              if (showToast) showToast(`Switched active farm node to "${farm?.name || 'Farm Node'}"`, "info");
                            }
                          }}
                          className="flex-1 py-2 bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs rounded-xl border border-slate-300 transition flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          Set as Active Node
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowDeleteConfirmModal(farm)}
                          title="Soft-Delete & Archive Farm Node"
                          className="p-2 bg-rose-50 hover:bg-rose-100 active:scale-95 text-rose-700 font-bold text-xs rounded-xl border border-rose-200 transition flex items-center justify-center cursor-pointer shrink-0"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                        </button>
                      </div>
                    ) : (
                      <div className="w-full py-2 bg-emerald-500/10 text-emerald-400 font-bold text-xs rounded-xl border border-emerald-500/20 text-center">
                        ✓ Currently In Use
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* SUPER ADMIN COMPLIANCE VAULT: SOFT-DELETED FARM NODES & CONFIGURATIONS */}
            {(isSuperAdmin || currentRole === "Super Admin" || userProfile?.role === "Super Admin" || auth.currentUser?.email?.includes("admin") || auth.currentUser?.email === "support@mabala.cloud") && (
              <div className="mt-8 pt-6 border-t border-slate-200 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <Archive className="w-4 h-4 text-amber-600" />
                      Super Admin Archival Vault (Soft-Deleted Farm Nodes & Configurations)
                    </h4>
                    <p className="text-xs text-slate-500">
                      Archived records are invisible to standard farm operators but preserved here for statutory compliance and restoration with automatic financial ledger reversals.
                    </p>
                  </div>
                  <span className="px-2.5 py-1 bg-amber-100 text-amber-900 text-[11px] font-bold rounded-lg self-start sm:self-auto">
                    {archiveRecords.filter((r) => r.module === "Farm Nodes" || r.module === "Settings & Configurations").length} Archived Records
                  </span>
                </div>

                {archiveRecords.filter((r) => r.module === "Farm Nodes" || r.module === "Settings & Configurations").length === 0 ? (
                  <div className="p-6 bg-slate-50 border border-dashed border-slate-300 rounded-2xl text-center">
                    <Check className="w-6 h-6 text-emerald-500 mx-auto mb-1.5 opacity-80" />
                    <p className="text-xs font-bold text-slate-700">No Soft-Deleted Farm Nodes in Archive</p>
                    <p className="text-[11px] text-slate-500">All registered farm nodes and statutory configurations are active and healthy.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {archiveRecords
                      .filter((r) => r.module === "Farm Nodes" || r.module === "Settings & Configurations")
                      .map((arc) => (
                        <div
                          key={arc.id}
                          className="p-4 bg-amber-50/40 border border-amber-200/80 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4"
                        >
                          <div className="space-y-1.5 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-xs font-bold text-slate-900">{arc.description}</span>
                              <span className="text-[10px] font-mono bg-amber-200/60 text-amber-900 px-2 py-0.5 rounded font-bold">
                                {arc.recordId}
                              </span>
                              <span className="text-[10px] bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full font-bold">
                                Soft-Deleted
                              </span>
                            </div>

                            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-slate-600">
                              <span>Deleted by: <strong className="text-slate-800">{arc.deletedBy?.name || "Operator"}</strong> ({arc.deletedBy?.email})</span>
                              <span>Date: <strong>{new Date(arc.deletedAt).toLocaleDateString()} {new Date(arc.deletedAt).toLocaleTimeString()}</strong></span>
                              {arc.auditNote && <span className="text-amber-800 italic">Audit: {arc.auditNote}</span>}
                            </div>

                            {/* Financial Reversal Information */}
                            {arc.financialReversal && (
                              <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] text-emerald-900 flex items-center gap-2">
                                <Landmark className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                <span>
                                  Financial Ledger Impact: <strong>Credit Note #{arc.financialReversal.creditNoteNumber}</strong> issued for <strong>ZK {arc.financialReversal.creditAmount}</strong>. Restoring this record safely applies reversing credit adjustments.
                                </span>
                              </div>
                            )}
                          </div>

                          <button
                            type="button"
                            disabled={isSaving || restoringRecordId === arc.id}
                            onClick={() => handleRestoreArchivedRecord(arc)}
                            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0 disabled:opacity-50"
                          >
                            <RotateCcw className={`w-3.5 h-3.5 ${restoringRecordId === arc.id ? "animate-spin" : ""}`} />
                            <span>{restoringRecordId === arc.id ? "Restoring Node..." : "Restore Farm Node"}</span>
                          </button>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 5: NOTIFICATIONS & ALERTS */}
      {activeSection === "notifications" && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4 space-y-1">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Bell className="w-5 h-5 text-indigo-600" />
              Automated Alerts & Dispatch Preferences
            </h3>
            <p className="text-xs text-slate-500">
              Configure real-time SMS notifications via Lipila SMS Gateway and periodic email digest summaries.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 block">
                SMS Dispatch Mobile Number
              </label>
              <input
                type="tel"
                inputMode="tel"
                value={notificationPrefs.smsPhone}
                onChange={(e) => setNotificationPrefs({ ...notificationPrefs, smsPhone: e.target.value })}
                placeholder="+260978070734"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:border-indigo-500 outline-none transition"
              />
              <span className="text-[10px] text-slate-500">Destination phone number for real-time Lipila SMS alerts.</span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 block">
                Weekly Digest Email Address
              </label>
              <input
                type="email"
                value={notificationPrefs.emailAddress}
                onChange={(e) => setNotificationPrefs({ ...notificationPrefs, emailAddress: e.target.value })}
                placeholder="e.g. farm.owner@example.com"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:border-indigo-500 outline-none transition"
              />
              <span className="text-[10px] text-slate-500">Destination email address for automated weekly PDF executive digests.</span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 block">
                Low-Stock Warning Safety Threshold
              </label>
              <input
                type="number"
                step="any"
                min="0"
                value={notificationPrefs.lowStockThreshold}
                onChange={(e) => setNotificationPrefs({ ...notificationPrefs, lowStockThreshold: Number(e.target.value) || 0 })}
                placeholder="10"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:border-indigo-500 outline-none transition"
              />
              <span className="text-[10px] text-slate-500">Trigger alert when inventory units drop at or below this amount.</span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 block">
                Invoice Overdue Grace Period (Days)
              </label>
              <input
                type="number"
                min="0"
                value={notificationPrefs.overdueDays}
                onChange={(e) => setNotificationPrefs({ ...notificationPrefs, overdueDays: Number(e.target.value) || 0 })}
                placeholder="7"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:border-indigo-500 outline-none transition"
              />
              <span className="text-[10px] text-slate-500">Days past invoice payment due date before sending customer reminders.</span>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-slate-800 block">Low Inventory & Seed Reserve Alerts</span>
                <span className="text-[11px] text-slate-500">Receive SMS notifications whenever critical fertilizer, chemical, or grain stock drops below safety thresholds.</span>
              </div>
              <input
                type="checkbox"
                checked={notificationPrefs.smsLowStock}
                onChange={(e) => setNotificationPrefs({ ...notificationPrefs, smsLowStock: e.target.checked })}
                className="w-5 h-5 accent-indigo-600 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-slate-800 block">Customer Invoice Overdue Reminders</span>
                <span className="text-[11px] text-slate-500">Auto-dispatch payment reminders to credit clients before and after invoice payment due dates.</span>
              </div>
              <input
                type="checkbox"
                checked={notificationPrefs.smsInvoiceOverdue}
                onChange={(e) => setNotificationPrefs({ ...notificationPrefs, smsInvoiceOverdue: e.target.checked })}
                className="w-5 h-5 accent-indigo-600 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-slate-800 block">District Weather & Agro-Advisory Alerts</span>
                <span className="text-[11px] text-slate-500">Receive early warnings for extreme rainfall, heat spikes, and pest outbreaks in your province.</span>
              </div>
              <input
                type="checkbox"
                checked={notificationPrefs.smsWeatherAlerts}
                onChange={(e) => setNotificationPrefs({ ...notificationPrefs, smsWeatherAlerts: e.target.checked })}
                className="w-5 h-5 accent-indigo-600 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-slate-800 block">Weekly Financial & Production Digest</span>
                <span className="text-[11px] text-slate-500">Receive a weekly consolidated PDF report of revenue, expenses, egg yields, and harvest numbers.</span>
              </div>
              <input
                type="checkbox"
                checked={notificationPrefs.emailWeeklyReport}
                onChange={(e) => setNotificationPrefs({ ...notificationPrefs, emailWeeklyReport: e.target.checked })}
                className="w-5 h-5 accent-indigo-600 rounded cursor-pointer"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end">
            <button
              type="button"
              disabled={isSaving}
              onClick={handleSaveNotificationPreferences}
              className="px-6 py-2.5 bg-[#0B2265] hover:bg-[#071746] active:scale-95 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {isSaving ? "Saving Preferences..." : "Save Notification Preferences"}
            </button>
          </div>
        </div>
      )}

      {/* SECTION 6: SECURITY & SYSTEM */}
      {activeSection === "security" && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4 space-y-1">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Shield className="w-5 h-5 text-indigo-600" />
              Security, Authentication & Cloud Status
            </h3>
            <p className="text-xs text-slate-500">
              Manage credentials, password reset triggers, and inspect live Firestore backend connectivity.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Password Reset Card */}
            <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                <Key className="w-4 h-4 text-amber-600" />
                <span>Account Password Management</span>
              </div>
              <p className="text-xs text-slate-500">
                Trigger a secure Firebase password reset email to your registered email address ({profileForm.email}).
              </p>

              {resetEmailSent && (
                <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-800 font-bold">
                  ✓ Password reset link has been dispatched to {profileForm.email}. Check your inbox or spam folder.
                </div>
              )}

              {resetEmailError && (
                <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-xs text-rose-800 font-bold">
                  ⚠️ {resetEmailError}
                </div>
              )}

              <button
                type="button"
                onClick={handleTriggerPasswordReset}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-2 cursor-pointer"
              >
                <Mail className="w-3.5 h-3.5" />
                Send Password Reset Link
              </button>
            </div>

            {/* Cloud Database Connection Health */}
            <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                <Database className="w-4 h-4 text-indigo-600" />
                <span>Firestore Cloud Sync Status</span>
              </div>
              <div className="space-y-1.5 text-xs text-slate-600">
                <div className="flex items-center justify-between">
                  <span>Database Engine:</span>
                  <span className="font-mono font-bold text-slate-900">Cloud Firestore (Enterprise)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Tenant Scope:</span>
                  <span className="font-mono font-bold text-indigo-700">{userProfile?.tenantId || activeFarm?.id || "TENANT_ROOT"}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Session Type:</span>
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold rounded text-[10px]">
                    Zero-Trust Authenticated
                  </span>
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      setIsSaving(true);
                      const cleanEmail = (nodeEmail || resolvedInitialEmail).trim().toLowerCase();
                      await FarmPersistenceService.saveFarmNodeWorkspace(cleanEmail, {
                        farms
                      });
                      const syncUid = auth?.currentUser?.uid || userProfile?.uid || tenantId || "guest";
                      if (handleSaveCloudWorkspace && syncUid) {
                        await handleSaveCloudWorkspace(syncUid);
                      }
                      if (showToast) showToast("Cloud snapshot synchronization completed!", "success");
                    } catch (err: any) {
                      console.error("Cloud sync trigger error:", err);
                      if (showToast) showToast("Cloud snapshot synchronization failed", "error");
                    } finally {
                      setIsSaving(false);
                    }
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Trigger Cloud Sync
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CREATE NEW FARM NODE MODAL */}
      {showAddFarmModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5 border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-50 rounded-xl text-emerald-600">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Register New Farm Node</h3>
                  <p className="text-xs text-slate-500">Add another agricultural enterprise branch or location</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddFarmModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateNewFarmNode} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">
                  Farm / Branch Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Chisamba South Farm Node"
                  value={newFarmName}
                  onChange={(e) => setNewFarmName(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Province</label>
                  <select
                    value={newFarmProvince}
                    onChange={(e) => handleNewFarmProvinceChange(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900"
                  >
                    {ZAMBIA_PROVINCES_ALPHABETICAL.map((prov) => (
                      <option key={prov} value={prov}>
                        {prov}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">District</label>
                  <select
                    value={newFarmDistrict}
                    onChange={(e) => setNewFarmDistrict(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900"
                  >
                    {newFarmAvailableDistricts.map((dist) => (
                      <option key={dist} value={dist}>
                        {dist}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Physical Location Address</label>
                <input
                  type="text"
                  placeholder="e.g. Great North Road, Chisamba"
                  value={newFarmAddress}
                  onChange={(e) => setNewFarmAddress(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Contact Phone</label>
                <input
                  type="text"
                  placeholder="+260978000000"
                  value={newFarmPhone}
                  onChange={(e) => setNewFarmPhone(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-indigo-500 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Initial Tax Regime</label>
                <select
                  value={newFarmTaxType}
                  onChange={(e) => setNewFarmTaxType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900"
                >
                  <option value="TOT_5">Turnover Tax (5%)</option>
                  <option value="TOT_4">Turnover Tax (4%)</option>
                  <option value="VAT_16">Standard VAT (16%)</option>
                  <option value="EXEMPT">Tax Exempt (0%)</option>
                </select>
              </div>

              <div className="flex items-center gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddFarmModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newFarmName.trim()}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Plus className="w-4 h-4" />
                  Create Farm Node
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* SOFT-DELETE CONFIRMATION MODAL */}
      {showDeleteConfirmModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-rose-100 space-y-5 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between">
              <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-200">
                <Archive className="w-6 h-6" />
              </div>
              <button
                type="button"
                onClick={() => setShowDeleteConfirmModal(null)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2">
              <h3 className="text-base font-bold text-slate-900">
                Soft-Delete & Archive Farm Node?
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                You are about to soft-delete <strong>{showDeleteConfirmModal.name}</strong> (Node ID: {showDeleteConfirmModal.id}).
              </p>
            </div>

            <div className="p-3.5 bg-rose-50/60 border border-rose-200 rounded-2xl space-y-2 text-xs text-rose-950">
              <div className="flex items-center gap-1.5 font-bold text-rose-900">
                <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Statutory Archival & Compliance Safeguards:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-[11px] text-rose-800">
                <li>Record will be hidden from farm operational views but preserved in the super admin archival vault.</li>
                <li>Full operator attribution will be recorded in the platform audit trail.</li>
                <li>A financial Credit Note (ZK 150.00) will be credited to the accounts ledger.</li>
                <li>Super Admins can query and restore this farm node at any time.</li>
              </ul>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteConfirmModal(null)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={handleConfirmSoftDelete}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isSaving ? "Archiving..." : "Confirm Soft-Delete"}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

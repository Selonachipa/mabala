import { safeFormatError } from "../utils/errorUtils";
import React, { useState, useEffect } from "react";
import { offlineQueueService, OfflineQueueState } from "../services/offlineQueueService";
import { koboCollectSyncService, KoboSubmissionEnvelope } from "../services/koboCollectSyncService";
import { 
  Wifi, 
  WifiOff, 
  Database, 
  RefreshCw, 
  Plus, 
  Trash2, 
  AlertTriangle, 
  CheckCircle, 
  Settings, 
  FileText, 
  Sparkles,
  ArrowRight,
  GitMerge,
  Server,
  Monitor,
  CloudUpload,
  HardDrive
} from "lucide-react";
import { db } from "../firebase";
import { 
  collection, 
  doc, 
  setDoc, 
  addDoc, 
  deleteDoc, 
  onSnapshot, 
  getDoc,
  enableNetwork, 
  disableNetwork,
  query,
  limit,
  serverTimestamp
} from "firebase/firestore";

interface TestSyncDoc {
  id: string;
  title: string;
  description: string;
  updatedAt: any;
  hasPendingWrites: boolean;
  fromCache: boolean;
}

export interface SyncLogEntry {
  id: string;
  docId: string;
  title: string;
  description: string;
  timestamp: string;
  status: "uploaded" | "queued";
}

export default function OfflineSyncPanel() {
  const [networkOnline, setNetworkOnline] = useState(navigator.onLine);
  const [firestoreConnected, setFirestoreConnected] = useState(true);
  const [testDocs, setTestDocs] = useState<TestSyncDoc[]>([]);
  const [newTitle, setNewTitle] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Durable IndexedDB Queue State
  const [durableQueueState, setDurableQueueState] = useState<OfflineQueueState>(() => offlineQueueService.getState());
  const [koboPending, setKoboPending] = useState<KoboSubmissionEnvelope[]>([]);
  const [koboSyncing, setKoboSyncing] = useState(false);

  useEffect(() => {
    setKoboPending(koboCollectSyncService.getPendingSubmissions());
    const unsub = offlineQueueService.subscribe((state) => {
      setDurableQueueState(state);
      setKoboPending(koboCollectSyncService.getPendingSubmissions());
    });
    return unsub;
  }, []);

  const handleTriggerKoboCollectSync = async () => {
    setKoboSyncing(true);
    setStatusMessage("KoboCollect Sync: Flushing offline submissions queue to Firebase Firestore...");
    try {
      const result = await koboCollectSyncService.syncPendingSubmissions();
      setKoboPending(koboCollectSyncService.getPendingSubmissions());
      await offlineQueueService.flushQueue(async (item) => {
        try {
          const testRef = doc(db, "users_data", item.targetUid || "default", "offline_sync_log", item.id);
          await setDoc(testRef, {
            ...item.payload,
            actionType: item.actionType,
            clientCapturedAt: item.clientTimestamp,
            syncedAt: new Date().toISOString()
          }, { merge: true });
          return true;
        } catch {
          return false;
        }
      });
      if (result.failed > 0) {
        showStatus(`KoboCollect Sync: Synced ${result.success} items, ${result.failed} items pending offline.`, "warning");
      } else {
        showStatus(`KoboCollect Sync: All ${result.success} offline items successfully pushed to Firebase Cloud!`, "success");
      }
    } catch (e: any) {
      showStatus(`Sync error: ${e.message}`, "error");
    } finally {
      setKoboSyncing(false);
    }
  };

  // Visual Sync Log state
  const [syncLogs, setSyncLogs] = useState<SyncLogEntry[]>([
    {
      id: "init-log-1",
      docId: "harv-2026-88",
      title: "Maize Batch #14 Harvest Log",
      description: "120 Metric Tons logged during offline field session",
      timestamp: new Date(Date.now() - 1000 * 60 * 12).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      status: "uploaded"
    },
    {
      id: "init-log-2",
      docId: "loss-2026-03",
      title: "Storage Loss Audit #03",
      description: "4.5 Bags lost to moisture leakage",
      timestamp: new Date(Date.now() - 1000 * 60 * 4).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      status: "uploaded"
    }
  ]);

  // Sync Conflict Simulator state
  const [conflictStep, setConflictStep] = useState<"none" | "1_baseline" | "2_offline_edit" | "3_server_edit" | "4_resolve">("none");
  const [conflictDocId, setConflictDocId] = useState("conflict_demo_1");
  const [baselineValue, setBaselineValue] = useState("");
  const [localEditValue, setLocalEditValue] = useState("");
  const [serverEditValue, setServerEditValue] = useState("");
  const [mergedValue, setMergedValue] = useState("");
  const [resolutionStrategy, setResolutionStrategy] = useState<"client" | "server" | "merge">("merge");

  // Track browser offline state
  useEffect(() => {
    const handleOnline = () => setNetworkOnline(true);
    const handleOffline = () => setNetworkOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Listen to Firestore test collection with metadata changes enabled
  useEffect(() => {
    try {
      const q = query(collection(db, "offline_sync_test"), limit(10));
      const unsubscribe = onSnapshot(q, { includeMetadataChanges: true }, (snapshot) => {
        const docsList: TestSyncDoc[] = snapshot.docs.map(doc => {
          const data = doc.data();
          return {
            id: doc.id,
            title: data.title || "",
            description: data.description || "",
            updatedAt: data.updatedAt,
            hasPendingWrites: doc.metadata.hasPendingWrites,
            fromCache: doc.metadata.fromCache
          };
        });

        // Detect newly uploaded docs (transition from pending write or fresh sync)
        snapshot.docChanges().forEach((change) => {
          if (change.type === "added" || change.type === "modified") {
            const data = change.doc.data();
            const hasPending = change.doc.metadata.hasPendingWrites;
            const fromCache = change.doc.metadata.fromCache;

            // Log upload event when completed to server
            if (!hasPending && !fromCache) {
              const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
              setSyncLogs(prev => {
                const exists = prev.some(l => l.docId === change.doc.id && l.status === "uploaded");
                if (!exists && data.title) {
                  return [
                    {
                      id: `sync-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
                      docId: change.doc.id,
                      title: data.title || "Untitled Transaction",
                      description: data.description || "Field operation document",
                      timestamp: nowTime,
                      status: "uploaded"
                    },
                    ...prev
                  ];
                }
                return prev;
              });
            }
          }
        });

        setTestDocs(docsList);
      }, (err) => {
        console.error("Firestore onSnapshot error in testing offline:", err);
      });
      return () => unsubscribe();
    } catch (e) {
      console.error("Error setting up test listener:", e);
    }
  }, []);

  const handleToggleFirestoreNetwork = async () => {
    try {
      if (firestoreConnected) {
        await disableNetwork(db);
        setFirestoreConnected(false);
        showStatus("Firestore network disconnected! Working purely offline using local cache.", "warning");
      } else {
        await enableNetwork(db);
        setFirestoreConnected(true);
        showStatus("Firestore network re-enabled! Synchronizing queued local edits to Google Cloud...", "success");
      }
    } catch (e: any) {
      console.error("Failed to toggle network:", e);
      showStatus(`Error toggling network: ${e.message}`, "error");
    }
  };

  const handleAddTestDoc = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    try {
      showStatus("Writing to offline cache...", "info");
      await addDoc(collection(db, "offline_sync_test"), {
        title: newTitle,
        description: newDesc,
        updatedAt: serverTimestamp(),
        createdAt: serverTimestamp()
      });
      setNewTitle("");
      setNewDesc("");
      showStatus("Test document written! Check sync indicator below.", "success");
    } catch (err: any) {
      console.error("Add doc failed:", err);
      showStatus(`Write error: ${err.message}`, "error");
    }
  };

  const handleDeleteTestDoc = async (id: string) => {
    try {
      await deleteDoc(doc(db, "offline_sync_test", id));
      showStatus("Document deleted locally. Sync pending.", "info");
    } catch (err: any) {
      console.error("Delete doc failed:", err);
    }
  };

  const showStatus = (msg: string, type: "success" | "warning" | "error" | "info") => {
    setStatusMessage(`${type.toUpperCase()}: ${msg}`);
    setTimeout(() => {
      setStatusMessage(null);
    }, 5000);
  };

  // --- SYNC CONFLICT SIMULATOR WORKFLOW ---

  const startConflictDemo = async () => {
    // Step 1: Create a baseline document
    setConflictStep("1_baseline");
    const docRef = doc(db, "offline_sync_test", conflictDocId);
    await setDoc(docRef, {
      title: "Baseline Inventory Record",
      description: "Batch #45: 100 bags of Zambian Grade-A Maize Feed",
      updatedAt: serverTimestamp()
    });
    setBaselineValue("100 bags");
    setLocalEditValue("120 bags (Adjusted by Stock Controller)");
    setServerEditValue("95 bags (Updated concurrently by Dispatch Manager)");
    setMergedValue("115 bags (Split / Merged allocation)");
  };

  const proceedToStep2Offline = async () => {
    // Disconnect Firestore network
    await disableNetwork(db);
    setFirestoreConnected(false);
    setConflictStep("2_offline_edit");
  };

  const saveLocalOfflineEdit = async () => {
    // Write local change to cache
    const docRef = doc(db, "offline_sync_test", conflictDocId);
    await setDoc(docRef, {
      title: "Baseline Inventory Record",
      description: `Batch #45: ${localEditValue}`,
      updatedAt: serverTimestamp()
    }, { merge: true });
    setConflictStep("3_server_edit");
  };

  const simulateServerConcurrentChange = () => {
    // We are simulating a conflict. In the field, another device has written `serverEditValue` to the server database.
    // To represent this, when the client reconnects, they must compare local data with server-retrieved data,
    // and resolve it according to their policy.
    setConflictStep("4_resolve");
  };

  const handleResolveConflict = async () => {
    // Step 5: Resolve the conflict using the selected strategy and reconnect
    let resolvedDescription = "";
    
    if (resolutionStrategy === "client") {
      resolvedDescription = `Batch #45: ${localEditValue} (Client Overwrote Server)`;
    } else if (resolutionStrategy === "server") {
      resolvedDescription = `Batch #45: ${serverEditValue} (Server Wins policy)`;
    } else {
      resolvedDescription = `Batch #45: ${mergedValue} (Merged: Reconciled conflict manually)`;
    }

    // Re-enable network so synchronization is active
    await enableNetwork(db);
    setFirestoreConnected(true);

    const docRef = doc(db, "offline_sync_test", conflictDocId);
    await setDoc(docRef, {
      title: "Baseline Inventory Record",
      description: resolvedDescription,
      updatedAt: serverTimestamp()
    }, { merge: true });

    setConflictStep("none");
    showStatus("Conflict resolved successfully using " + resolutionStrategy.toUpperCase() + " strategy and pushed to cloud!", "success");
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Database className="h-6 w-6 text-emerald-400" />
            <h1 className="text-xl font-bold font-sans tracking-tight">Mabala Offline Persistence & Sync Center</h1>
          </div>
          <p className="text-slate-400 text-sm max-w-2xl">
            Zambian farmers operate in remote environments with intermittent cell connectivity. 
            Mabala runs a hardened local-first persistent cache on device disks (`IndexedDB`) to guarantee zero data loss.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className={`px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-2 border ${
            networkOnline ? "bg-emerald-950/50 border-emerald-500/30 text-emerald-400" : "bg-amber-950/50 border-amber-500/30 text-amber-400"
          }`}>
            {networkOnline ? <Wifi className="h-3.5 w-3.5" /> : <WifiOff className="h-3.5 w-3.5" />}
            Browser Network: {networkOnline ? "Online" : "Offline"}
          </div>

          <button
            type="button"
            onClick={handleToggleFirestoreNetwork}
            className={`px-4 py-1.5 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer ${
              firestoreConnected 
                ? "bg-emerald-600 hover:bg-emerald-700 text-white" 
                : "bg-amber-600 hover:bg-amber-700 text-white"
            }`}
          >
            <RefreshCw className={`h-3 w-3 ${!firestoreConnected ? "animate-pulse" : ""}`} />
            Firestore Link: {firestoreConnected ? "Connected" : "Simulated Offline"}
          </button>
        </div>
      </div>

      {statusMessage && (
        <div className={`p-4 rounded-xl text-sm border font-medium animate-fadeIn ${
          statusMessage.startsWith("SUCCESS") ? "bg-emerald-50 border-emerald-200 text-emerald-800" :
          statusMessage.startsWith("WARNING") ? "bg-amber-50 border-amber-200 text-amber-800" :
          statusMessage.startsWith("ERROR") ? "bg-rose-50 border-rose-200 text-rose-800" : "bg-sky-50 border-sky-200 text-sky-800"
        }`}>
          {statusMessage}
        </div>
      )}

      {/* KoboCollect ODK-Grade Offline Persistence Engine Card */}
      <div className="bg-linear-to-r from-emerald-950/80 via-slate-900 to-slate-900 border border-emerald-500/30 rounded-2xl p-6 text-white space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <HardDrive className="h-5 w-5 text-emerald-400" />
              <h3 className="text-base font-extrabold text-emerald-300">
                KoboCollect Offline Technology & Smart Sync Engine
              </h3>
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-[10px] font-mono font-black uppercase">
                ODK Active
              </span>
            </div>
            <p className="text-xs text-slate-300 max-w-3xl">
              All farm data (crop cycles, field blocks, expenses, inventory, and ledger journals) is saved permanently to <strong>IndexedDB and local persistent storage</strong> the moment you enter it. When internet is unavailable or you log out, your records remain intact on the device and sync automatically to Firebase Firestore when connectivity resumes.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={handleTriggerKoboCollectSync}
              disabled={koboSyncing}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-black rounded-xl transition-all shadow-md active:scale-95 cursor-pointer flex items-center gap-2"
            >
              <CloudUpload className={`h-4 w-4 ${koboSyncing ? "animate-bounce" : ""}`} />
              {koboSyncing ? "Syncing to Firebase..." : "Sync All to Firebase"}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-1">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Local Device Storage</span>
            <p className="text-sm font-black text-emerald-400 flex items-center gap-1.5">
              <CheckCircle className="h-4 w-4" />
              IndexedDB + LocalStorage (Permanent)
            </p>
          </div>
          <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-1">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Pending Kobo Envelopes</span>
            <p className="text-sm font-black text-amber-300 font-mono">
              {koboPending.length} Form Submission{koboPending.length === 1 ? "" : "s"} Queued
            </p>
          </div>
          <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-1">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Conflict Prevention</span>
            <p className="text-sm font-black text-indigo-300">
              Smart 2-Way Merge (Zero Loss)
            </p>
          </div>
        </div>
      </div>

      {/* Durable IndexedDB Queue Status Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div className="space-y-1">
            <h3 className="text-base font-extrabold flex items-center gap-2 text-indigo-300">
              <Database className="h-5 w-5 text-indigo-400" />
              Durable Local Queue (IndexedDB Storage)
            </h3>
            <p className="text-xs text-slate-400">
              Mutations entered offline are saved immediately to local disk before attempting network write. High priority financial writes are flushed first. Auto-prunes after 7 days.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className={`px-3 py-1 rounded-full text-xs font-bold font-mono border ${
              durableQueueState.pendingCount === 0
                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                : "bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse"
            }`}>
              {durableQueueState.pendingCount} Pending Write{durableQueueState.pendingCount === 1 ? "" : "s"}
            </span>
          </div>
        </div>

        {durableQueueState.items.length === 0 ? (
          <div className="p-4 text-center border border-dashed border-slate-800 rounded-xl text-slate-500 text-xs">
            ✅ Offline mutation queue is empty. All local edits are synced with Cloud Firestore.
          </div>
        ) : (
          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {durableQueueState.items.map((item) => (
              <div
                key={item.id}
                className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-slate-200">{item.summaryLabel || item.actionType}</span>
                    
                    {/* Action Type Badge */}
                    <span className={`px-2 py-0.5 text-[9px] font-extrabold font-mono rounded-full uppercase border ${
                      item.actionType === "FINANCIAL_TRANSACTION" ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40" :
                      item.actionType === "LOG_POST_HARVEST_LOSS" ? "bg-amber-500/20 text-amber-300 border-amber-500/40" :
                      item.actionType === "QUICK_LOG_LOSS" ? "bg-amber-500/20 text-amber-300 border-amber-500/40" :
                      item.actionType === "TASK_COMPLETION" ? "bg-sky-500/20 text-sky-300 border-sky-500/40" :
                      item.actionType === "MODULE_WRITE" ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/40" :
                      "bg-slate-800 text-slate-300 border-slate-700"
                    }`}>
                      {item.actionType}
                    </span>

                    {/* Priority Badge */}
                    <span className={`px-2 py-0.5 text-[9px] font-black font-mono rounded-full uppercase border ${
                      item.priority === "high" 
                        ? "bg-rose-500/20 text-rose-300 border-rose-500/40" 
                        : "bg-slate-800 text-slate-400 border-slate-700"
                    }`}>
                      {item.priority === "high" ? "🔥 High Priority" : "Normal Priority"}
                    </span>

                    <span className={`px-1.5 py-0.5 text-[9px] font-black font-mono rounded uppercase ${
                      item.status === "syncing" ? "bg-sky-500/20 text-sky-400 border border-sky-500/30 animate-pulse" :
                      item.status === "failed" ? "bg-rose-500/20 text-rose-400 border border-rose-500/30" :
                      "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                    }`}>
                      {item.status}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-[10px] text-slate-400 font-mono flex-wrap">
                    <span>Captured: {new Date(item.clientTimestamp).toLocaleTimeString()} ({item.clientTimestamp.slice(0, 10)})</span>
                    <span>Module: {item.moduleKey || "workspace"}</span>
                    {item.retryCount > 0 && <span className="text-amber-400 font-bold">Retries: {item.retryCount}</span>}
                  </div>

                  {item.lastError && (
                    <p className="text-[10px] text-rose-400 font-mono bg-rose-950/40 px-2 py-1 rounded border border-rose-900/50">
                      Error: {item.lastError}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    type="button"
                    onClick={async () => {
                      setStatusMessage("Attempting forced retry for item...");
                      const ok = await offlineQueueService.forceRetryItem(item.id, async (queueItem) => {
                        // Attempt sync write to Firebase doc or simulation
                        try {
                          const testRef = doc(db, "users_data", queueItem.targetUid || "guest_uid", "offline_sync_log", queueItem.id);
                          await setDoc(testRef, {
                            ...queueItem.payload,
                            actionType: queueItem.actionType,
                            clientCapturedAt: queueItem.clientTimestamp,
                            syncedAt: new Date().toISOString()
                          }, { merge: true });
                          return true;
                        } catch (e) {
                          return false;
                        }
                      });
                      if (ok) {
                        setStatusMessage("SUCCESS: Item successfully retried and flushed!");
                      } else {
                        setStatusMessage("WARNING: Force retry failed. Error logged to Sync Failure Log.");
                      }
                    }}
                    className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[10px] rounded transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <RefreshCw className="h-3 w-3" />
                    <span>Force Retry</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => offlineQueueService.removeQueueItem(item.id)}
                    className="px-2 py-1 bg-slate-800 hover:bg-rose-900/50 text-slate-400 hover:text-rose-300 text-[10px] rounded transition-colors cursor-pointer"
                  >
                    Discard
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Sync Failure Log Sub-Panel */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div className="space-y-1">
            <h3 className="text-base font-extrabold flex items-center gap-2 text-rose-300">
              <AlertTriangle className="h-5 w-5 text-rose-400" />
              Sync Failure Log & Troubleshooting Audit
            </h3>
            <p className="text-xs text-slate-400">
              Detailed history of failed sync attempts with error codes for troubleshooting. Automatically pruned after 7 days.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {durableQueueState.failureLogs.length > 0 && (
              <button
                type="button"
                onClick={() => offlineQueueService.clearFailureLogs()}
                className="px-3 py-1 bg-slate-800 hover:bg-rose-950 text-rose-300 border border-rose-900/50 text-xs font-bold rounded-lg transition-colors cursor-pointer"
              >
                Clear Failure Logs
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                offlineQueueService.pruneOldData(7);
                setStatusMessage("SUCCESS: Triggered manual 7-day data pruning for offline queue and failure logs.");
              }}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-lg transition-colors cursor-pointer"
            >
              Prune Data (&gt;7 Days)
            </button>
          </div>
        </div>

        {durableQueueState.failureLogs.length === 0 ? (
          <div className="p-4 text-center border border-dashed border-slate-800 rounded-xl text-slate-500 text-xs">
            🎉 No sync failures recorded. All offline mutations were processed cleanly.
          </div>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {durableQueueState.failureLogs.map((log) => (
              <div
                key={log.id}
                className="p-3 bg-slate-950 border border-rose-900/40 rounded-xl flex flex-col space-y-1.5 text-xs"
              >
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-rose-200">{log.summaryLabel}</span>
                    <span className="px-2 py-0.5 bg-rose-950 text-rose-400 border border-rose-800 text-[9px] font-mono rounded font-bold">
                      Code: {log.errorCode || "SYNC_FAILED"}
                    </span>
                    <span className="px-1.5 py-0.5 bg-slate-800 text-slate-300 text-[9px] font-mono rounded">
                      Type: {log.actionType}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {new Date(log.timestamp).toLocaleString()}
                  </span>
                </div>

                <div className="text-[11px] font-mono text-rose-300 bg-rose-950/30 p-2 rounded border border-rose-900/30">
                  {safeFormatError(log.errorMessage)}
                </div>

                <div className="flex items-center gap-4 text-[10px] text-slate-500 font-mono">
                  <span>Client Captured: {new Date(log.clientCapturedAt).toLocaleTimeString()} ({log.clientCapturedAt.slice(0, 10)})</span>
                  <span>Priority: {log.priority}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Local-First Cache Sandbox */}
        <div className="bg-white border border-slate-100 rounded-2xl shadow-sm p-6 space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Monitor className="h-5 w-5 text-indigo-500" />
              Local Cache Sandbox
            </h2>
            <p className="text-slate-500 text-xs mt-1">
              Add test transactions and watch them execute instantly using optimistic local updates, then synchronize.
            </p>
          </div>

          <form onSubmit={handleAddTestDoc} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Record Title</label>
                <input
                  type="text"
                  placeholder="e.g. Copperbelt Maize Delivery"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-slate-50"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Quantity / Notes</label>
                <input
                  type="text"
                  placeholder="e.g. 50 bags of seed feed"
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-slate-50"
                />
              </div>
            </div>
            <button
              type="submit"
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2 px-4 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition-all active:scale-95"
            >
              <Plus className="h-4 w-4" />
              Write Record Optimistically
            </button>
          </form>

          {/* Test Document List with Sync Status */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black text-slate-700 uppercase tracking-wider">Cached Local Registers</h3>
              <span className="text-[10px] text-slate-400 font-medium">Showing latest 10</span>
            </div>

            {testDocs.length === 0 ? (
              <div className="border border-dashed border-slate-200 rounded-xl p-8 text-center text-slate-400 text-xs space-y-1">
                <Database className="h-6 w-6 mx-auto text-slate-300 animate-pulse" />
                <p>No test documents found.</p>
                <p className="text-[10px] text-slate-400">Add a record above to seed the offline persistence cache.</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                {testDocs.map((docItem) => (
                  <div 
                    key={docItem.id} 
                    className="border border-slate-100 bg-slate-50/50 hover:bg-slate-50 rounded-xl p-3 flex items-start justify-between gap-3 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{docItem.title}</span>
                        {docItem.hasPendingWrites ? (
                          <span className="px-1.5 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 text-[9px] font-black rounded flex items-center gap-1">
                            <span className="h-1.5 w-1.5 bg-amber-500 rounded-full animate-ping" />
                            Offline Queue
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[9px] font-black rounded flex items-center gap-1">
                            <CheckCircle className="h-2.5 w-2.5" />
                            Synced
                          </span>
                        )}
                      </div>
                      <p className="text-slate-500 text-xs">{docItem.description}</p>
                      <div className="flex items-center gap-2 text-[9px] text-slate-400 font-mono">
                        <span>ID: {docItem.id.substring(0, 8)}...</span>
                        <span>•</span>
                        <span>Source: {docItem.fromCache ? "IndexedDB Cache" : "Cloud Instance"}</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteTestDoc(docItem.id)}
                      className="p-1 hover:bg-rose-50 rounded text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Sync Conflict Workshop */}
        <div className="bg-white border border-slate-100 rounded-2xl shadow-sm p-6 space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <GitMerge className="h-5 w-5 text-amber-500" />
              Sync Conflict Workshop
            </h2>
            <p className="text-slate-500 text-xs mt-1">
              Field-test sync conflict resolution when two managers edit the same asset record simultaneously.
            </p>
          </div>

          {conflictStep === "none" && (
            <div className="space-y-4 text-center py-6">
              <AlertTriangle className="h-10 w-10 text-amber-400 mx-auto" />
              <div className="space-y-1">
                <h3 className="text-xs font-bold text-slate-900">Run Interactive Sync Conflict Simulation</h3>
                <p className="text-slate-400 text-xs max-w-sm mx-auto">
                  Step through a simulated concurrent update scenario to see how Mabala prevents data loss and maintains farm registry integrity.
                </p>
              </div>
              <button
                type="button"
                onClick={startConflictDemo}
                className="mx-auto bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs py-2 px-5 rounded-lg flex items-center gap-1.5 shadow-sm transition-all active:scale-95 cursor-pointer"
              >
                <Sparkles className="h-3.5 w-3.5" />
                Begin Conflict Workshop
              </button>
            </div>
          )}

          {conflictStep === "1_baseline" && (
            <div className="space-y-4">
              <div className="p-3 bg-indigo-50 text-indigo-900 border border-indigo-100 rounded-xl text-xs space-y-1">
                <p className="font-bold">Step 1: Baseline Record Created</p>
                <p>We created a test document `conflict_demo_1` in Firestore with baseline stock value of <strong>{baselineValue}</strong>.</p>
              </div>
              <div className="space-y-1 text-slate-500 text-xs">
                <p>Current Title: <strong className="text-slate-800">Baseline Inventory Record</strong></p>
                <p>Current Stock: <strong className="text-slate-800">{baselineValue}</strong></p>
              </div>
              <button
                type="button"
                onClick={proceedToStep2Offline}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2 px-4 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer"
              >
                Go Offline & Edit locally
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {conflictStep === "2_offline_edit" && (
            <div className="space-y-4">
              <div className="p-3 bg-amber-50 text-amber-900 border border-amber-100 rounded-xl text-xs space-y-1">
                <p className="font-bold">Step 2: Simulate Offline Adjustment</p>
                <p>Firestore is now disconnected from the cloud. Modify the local value below to simulate a physical stock correction.</p>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Your Local Value</label>
                <input
                  type="text"
                  value={localEditValue}
                  onChange={(e) => setLocalEditValue(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-slate-50 font-medium text-slate-900"
                />
              </div>
              <button
                type="button"
                onClick={saveLocalOfflineEdit}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2 px-4 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer"
              >
                Save Local Edit (Queued Offline)
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {conflictStep === "3_server_edit" && (
            <div className="space-y-4">
              <div className="p-3 bg-rose-50 text-rose-900 border border-rose-100 rounded-xl text-xs space-y-1">
                <p className="font-bold">Step 3: Server Concurrency Conflict</p>
                <p>While you were offline, another manager updated the central database with their audit count. Type what they submitted:</p>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Concurrent Server Value</label>
                <input
                  type="text"
                  value={serverEditValue}
                  onChange={(e) => setServerEditValue(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-rose-500 bg-slate-50 font-medium text-slate-900"
                />
              </div>
              <button
                type="button"
                onClick={simulateServerConcurrentChange}
                className="w-full bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs py-2 px-4 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer"
              >
                Inject Server Conflict State
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {conflictStep === "4_resolve" && (
            <div className="space-y-4">
              <div className="p-3 bg-amber-50 text-amber-900 border border-amber-200 rounded-xl text-xs space-y-1">
                <p className="font-bold flex items-center gap-1.5">
                  <AlertTriangle className="h-4 w-4 text-amber-600" />
                  Sync Conflict Detected!
                </p>
                <p>The network connection is ready to resume. However, the system has detected that the local document value and server document value have both changed!</p>
              </div>

              {/* Conflict Side-by-Side Panel */}
              <div className="grid grid-cols-2 gap-4 border border-slate-100 rounded-xl p-3 bg-slate-50/50">
                <div className="space-y-1 text-center">
                  <div className="flex items-center justify-center gap-1 text-[10px] text-slate-500 font-bold uppercase">
                    <Monitor className="h-3 w-3" /> Local Client
                  </div>
                  <p className="text-xs font-extrabold text-indigo-700">{localEditValue}</p>
                </div>
                <div className="space-y-1 text-center border-l border-slate-200">
                  <div className="flex items-center justify-center gap-1 text-[10px] text-slate-500 font-bold uppercase">
                    <Server className="h-3 w-3" /> Cloud Server
                  </div>
                  <p className="text-xs font-extrabold text-rose-700">{serverEditValue}</p>
                </div>
              </div>

              {/* Strategy Selector */}
              <div className="space-y-3">
                <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider">Select Conflict Resolution Policy</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setResolutionStrategy("client")}
                    className={`p-2.5 rounded-lg border text-xs text-center transition-all cursor-pointer font-bold ${
                      resolutionStrategy === "client" 
                        ? "border-indigo-500 bg-indigo-50/50 text-indigo-700" 
                        : "border-slate-100 bg-white text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    Client Wins
                    <span className="block text-[9px] font-normal text-slate-400 mt-0.5">Use local cache</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setResolutionStrategy("server")}
                    className={`p-2.5 rounded-lg border text-xs text-center transition-all cursor-pointer font-bold ${
                      resolutionStrategy === "server" 
                        ? "border-rose-500 bg-rose-50/50 text-rose-700" 
                        : "border-slate-100 bg-white text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    Server Wins
                    <span className="block text-[9px] font-normal text-slate-400 mt-0.5">Discard local changes</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setResolutionStrategy("merge")}
                    className={`p-2.5 rounded-lg border text-xs text-center transition-all cursor-pointer font-bold ${
                      resolutionStrategy === "merge" 
                        ? "border-amber-500 bg-amber-50/50 text-amber-700" 
                        : "border-slate-100 bg-white text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    Manual Merge
                    <span className="block text-[9px] font-normal text-slate-400 mt-0.5">Merge both datasets</span>
                  </button>
                </div>

                {resolutionStrategy === "merge" && (
                  <div className="space-y-1.5 p-3 bg-slate-50 rounded-xl border border-slate-100 animate-fadeIn">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Write Reconciled Target Value</label>
                    <input
                      type="text"
                      value={mergedValue}
                      onChange={(e) => setMergedValue(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white font-medium text-slate-900"
                    />
                  </div>
                )}
              </div>

              <button
                type="button"
                onClick={handleResolveConflict}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 px-4 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
              >
                <GitMerge className="h-4 w-4" />
                Reconnect & Reconcile Data
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Visual Upload & Sync Log Section */}
      <div className="bg-white border border-slate-100 rounded-2xl shadow-sm p-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <FileText className="h-5 w-5 text-emerald-600" />
              Visual Sync Audit Log (Cloud Restoration Events)
            </h2>
            <p className="text-slate-500 text-xs mt-0.5">
              Displays individual transaction upload timestamps when offline queued writes successfully commit to Firestore after connectivity restoration.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-lg flex items-center gap-1.5">
              <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />
              {syncLogs.filter(l => l.status === "uploaded").length} Uploaded Events
            </span>
            {syncLogs.length > 0 && (
              <button
                type="button"
                onClick={() => setSyncLogs([])}
                className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold rounded-lg transition-colors cursor-pointer"
              >
                Clear Log
              </button>
            )}
          </div>
        </div>

        {syncLogs.length === 0 ? (
          <div className="p-8 text-center border border-dashed border-slate-200 rounded-xl space-y-2 text-slate-400">
            <RefreshCw className="h-6 w-6 mx-auto text-slate-300 animate-spin" />
            <p className="text-xs font-bold text-slate-600">No sync upload entries recorded yet in current session.</p>
            <p className="text-[11px]">When connectivity is restored, queued transaction uploads will populate here with exact timestamps.</p>
          </div>
        ) : (
          <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
            {syncLogs.map((log) => (
              <div 
                key={log.id} 
                className="p-3.5 bg-slate-50/70 border border-slate-100 hover:border-emerald-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all"
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg mt-0.5">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900">{log.title}</span>
                      <span className="px-1.5 py-0.5 bg-emerald-500/10 text-emerald-700 border border-emerald-500/20 text-[9px] font-mono font-bold rounded">
                        Doc ID: {log.docId}
                      </span>
                    </div>
                    <p className="text-slate-500 text-[11px] mt-0.5">{log.description}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-3 text-right border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-200/60">
                  <div className="text-left sm:text-right">
                    <span className="text-[10px] text-slate-400 block font-medium uppercase tracking-wider">Synced Timestamp</span>
                    <span className="text-xs font-mono font-bold text-slate-800 bg-white px-2 py-0.5 rounded border border-slate-200 inline-block mt-0.5">
                      {log.timestamp}
                    </span>
                  </div>
                  <span className="px-2 py-1 bg-emerald-600 text-white text-[10px] font-black rounded-lg shadow-xs flex items-center gap-1">
                    ✓ Firestore Cloud
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Field Best Practices section */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Settings className="h-4.5 w-4.5 text-slate-600" />
          Field-Level Resilience Guidelines & Architectural Patterns
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-xs text-slate-600">
          <div className="space-y-1.5 p-4 bg-white rounded-xl border border-slate-100 shadow-sm">
            <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
              <CheckCircle className="h-4 w-4 text-emerald-600" />
              1. Disk Persistence (IndexedDB)
            </h4>
            <p className="text-[11px] leading-relaxed text-slate-500">
              Mabala initializes Firestore with a persistent offline cache using <code className="bg-slate-100 px-1 py-0.5 rounded text-indigo-600 font-mono">CACHE_SIZE_UNLIMITED</code> to keep years of livestock, crop, and expense history safe directly on the user's device. Cleared browser caches will not cause data loss.
            </p>
          </div>

          <div className="space-y-1.5 p-4 bg-white rounded-xl border border-slate-100 shadow-sm">
            <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
              <CheckCircle className="h-4 w-4 text-emerald-600" />
              2. Multi-Tab Resilience
            </h4>
            <p className="text-[11px] leading-relaxed text-slate-500">
              Mabala implements the <code className="bg-slate-100 px-1 py-0.5 rounded text-indigo-600 font-mono">persistentMultipleTabManager()</code>. When multiple browser tabs or synchronization views are open concurrently on the same device, cache coordination locks are negotiated correctly to prevent synchronization stalls.
            </p>
          </div>

          <div className="space-y-1.5 p-4 bg-white rounded-xl border border-slate-100 shadow-sm">
            <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-xs text-amber-700">
              <Database className="h-4 w-4 text-amber-600" />
              3. Counters & Balances (The Ledger Pattern)
            </h4>
            <p className="text-[11px] leading-relaxed text-slate-500">
              <strong>Never store absolute totals that get overwritten.</strong> For credits, farm totals, and expense sums, use a transaction ledger pattern. Use <code className="bg-slate-100 px-1 py-0.5 rounded text-amber-700 font-mono">runTransaction()</code> to apply increments/deltas rather than absolute values. Offline sync order becomes irrelevant, as each device queues increment requests that serialize perfectly when connection resumes.
            </p>
          </div>

          <div className="space-y-1.5 p-4 bg-white rounded-xl border border-slate-100 shadow-sm">
            <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-xs text-indigo-700">
              <GitMerge className="h-4 w-4 text-indigo-600" />
              4. Field-Level Merge (updateDoc)
            </h4>
            <p className="text-[11px] leading-relaxed text-slate-500">
              For general record edits (expense details, farm parameters), prefer <code className="bg-slate-100 px-1 py-0.5 rounded text-indigo-600 font-mono">updateDoc()</code> over document-level overwrites. Since <code className="bg-slate-100 px-1 py-0.5 rounded text-indigo-600 font-mono">updateDoc()</code> only modifies fields explicitly passed, concurrent offline updates on separate fields (e.g., amount vs. date) merge seamlessly rather than overwriting each other.
            </p>
          </div>

          <div className="space-y-1.5 p-4 bg-white rounded-xl border border-slate-100 shadow-sm md:col-span-2 lg:col-span-1">
            <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
              <AlertTriangle className="h-4 w-4 text-indigo-600" />
              5. Promise Resolution Behavior
            </h4>
            <p className="text-[11px] leading-relaxed text-slate-500">
              Firestore writes via <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-700 font-mono">addDoc()</code> or <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-700 font-mono">setDoc()</code> resolve as successful **immediately** upon being stored in the local cache. They do not wait for a server handshake. True failures only throw on genuine rules violations or schema errors, making offline writes instantly responsive out of the box.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { createContext, useContext, useState, useRef, ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import { AlertTriangle, Trash2, HelpCircle, X, ShieldAlert, FileText } from "lucide-react";

export interface ConfirmOptions {
  title?: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  type?: "danger" | "warning" | "info";
  requireReason?: boolean;
  reasonLabel?: string;
  reasonPlaceholder?: string;
  recordIdentifier?: string;
}

interface ConfirmResult {
  confirmed: boolean;
  reason?: string;
}

interface ConfirmContextType {
  confirm: (options: ConfirmOptions) => Promise<boolean>;
  confirmWithReason: (options: ConfirmOptions) => Promise<{ confirmed: boolean; reason: string }>;
}

const ConfirmContext = createContext<ConfirmContextType | null>(null);

export function logDeletionAudit(recordTitle: string, reason: string, extra?: any) {
  try {
    const raw = localStorage.getItem("mabala_deletion_audit_log");
    const logs = raw ? JSON.parse(raw) : [];
    logs.unshift({
      id: `del_audit_${Date.now()}`,
      recordTitle,
      reason,
      extra,
      timestamp: new Date().toISOString()
    });
    // Keep max 500 logs
    localStorage.setItem("mabala_deletion_audit_log", JSON.stringify(logs.slice(0, 500)));
  } catch (e) {
    console.warn("Could not write deletion audit log:", e);
  }
}

export function ConfirmProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [options, setOptions] = useState<ConfirmOptions | null>(null);
  const [deletionReason, setDeletionReason] = useState("");
  const [reasonError, setReasonError] = useState("");
  const resolverRef = useRef<((value: any) => void) | null>(null);
  const isReasonModeRef = useRef<boolean>(false);

  const confirm = (opts: ConfirmOptions): Promise<boolean> => {
    // If it's a danger/delete action and requireReason isn't explicitly false, require a reason
    const optsWithDefault: ConfirmOptions = {
      ...opts,
      requireReason: opts.requireReason !== undefined ? opts.requireReason : (opts.type === "danger")
    };
    setOptions(optsWithDefault);
    setDeletionReason("");
    setReasonError("");
    isReasonModeRef.current = false;
    setIsOpen(true);
    return new Promise<boolean>((resolve) => {
      resolverRef.current = (val: boolean) => resolve(val);
    });
  };

  const confirmWithReason = (opts: ConfirmOptions): Promise<{ confirmed: boolean; reason: string }> => {
    const optsWithDefault: ConfirmOptions = {
      ...opts,
      requireReason: true
    };
    setOptions(optsWithDefault);
    setDeletionReason("");
    setReasonError("");
    isReasonModeRef.current = true;
    setIsOpen(true);
    return new Promise<{ confirmed: boolean; reason: string }>((resolve) => {
      resolverRef.current = (result: { confirmed: boolean; reason: string }) => resolve(result);
    });
  };

  const handleCancel = () => {
    setIsOpen(false);
    if (resolverRef.current) {
      if (isReasonModeRef.current) {
        resolverRef.current({ confirmed: false, reason: "" });
      } else {
        resolverRef.current(false);
      }
      resolverRef.current = null;
    }
  };

  const handleConfirm = () => {
    const isReasonRequired = options?.requireReason;
    if (isReasonRequired && deletionReason.trim().length < 3) {
      setReasonError("Please provide a valid reason for this deletion (minimum 3 characters).");
      return;
    }

    if (options?.type === "danger" || isReasonRequired) {
      logDeletionAudit(options?.title || "Record Deletion", deletionReason.trim(), {
        message: options?.message,
        identifier: options?.recordIdentifier
      });
    }

    setIsOpen(false);
    if (resolverRef.current) {
      if (isReasonModeRef.current) {
        resolverRef.current({ confirmed: true, reason: deletionReason.trim() });
      } else {
        resolverRef.current(true);
      }
      resolverRef.current = null;
    }
  };

  const getIcon = (type?: "danger" | "warning" | "info") => {
    switch (type) {
      case "danger":
        return (
          <div className="p-3 bg-rose-500/15 border border-rose-500/30 text-rose-400 rounded-2xl shrink-0">
            <Trash2 className="w-6 h-6" />
          </div>
        );
      case "warning":
        return (
          <div className="p-3 bg-amber-500/15 border border-amber-500/30 text-amber-400 rounded-2xl shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
        );
      case "info":
      default:
        return (
          <div className="p-3 bg-teal-500/15 border border-teal-500/30 text-teal-400 rounded-2xl shrink-0">
            <HelpCircle className="w-6 h-6" />
          </div>
        );
    }
  };

  const getConfirmButtonClasses = (type?: "danger" | "warning" | "info") => {
    switch (type) {
      case "danger":
        return "bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-950/40 border border-rose-500/40";
      case "warning":
        return "bg-amber-600 hover:bg-amber-500 text-white shadow-lg shadow-amber-950/40 border border-amber-500/40";
      case "info":
      default:
        return "bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-950/40 border border-emerald-500/40";
    }
  };

  const isReasonRequired = options?.requireReason;
  const isConfirmDisabled = isReasonRequired && deletionReason.trim().length < 3;

  return (
    <ConfirmContext.Provider value={{ confirm, confirmWithReason }}>
      {children}
      <AnimatePresence>
        {isOpen && options && (
          <div className="fixed inset-0 z-[999999] flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleCancel}
              className="absolute inset-0 bg-slate-950/75 backdrop-blur-sm cursor-pointer"
            />

            {/* Modal Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ type: "spring", duration: 0.3 }}
              className="relative w-full max-w-lg bg-slate-900 border border-slate-700/70 rounded-3xl p-6 shadow-2xl text-slate-100 flex flex-col gap-5"
            >
              {/* Header */}
              <div className="flex items-start gap-4">
                {getIcon(options.type)}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-100 tracking-tight leading-snug">
                      {options.title || (options.type === "danger" ? "Confirm Deletion" : "Confirm Action")}
                    </h3>
                  </div>
                  <p className="mt-1.5 text-xs sm:text-sm text-slate-300 leading-relaxed font-medium">
                    {options.message}
                  </p>
                </div>
                <button
                  onClick={handleCancel}
                  className="text-slate-400 hover:text-slate-200 transition-colors p-1.5 rounded-xl hover:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Mandatory Reason for Deletion Input */}
              {isReasonRequired && (
                <div className="space-y-2 bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
                  <label className="flex items-center justify-between text-xs font-bold text-slate-200">
                    <span className="flex items-center gap-1.5 text-rose-300">
                      <FileText className="w-3.5 h-3.5" />
                      {options.reasonLabel || "Reason for Deletion / Audit Trail *"}
                    </span>
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                      Required for Audit
                    </span>
                  </label>
                  <textarea
                    rows={2}
                    value={deletionReason}
                    onChange={(e) => {
                      setDeletionReason(e.target.value);
                      if (reasonError && e.target.value.trim().length >= 3) {
                        setReasonError("");
                      }
                    }}
                    placeholder={
                      options.reasonPlaceholder ||
                      "Provide a reason (e.g., Sold on market, Culled, Mistaken entry, Duplicate record, Contract expired)..."
                    }
                    className="w-full text-xs p-3 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 placeholder-slate-500 focus:border-rose-500 focus:ring-1 focus:ring-rose-500 outline-none resize-none"
                    autoFocus
                  />
                  {reasonError && (
                    <p className="text-[11px] text-rose-400 font-medium flex items-center gap-1">
                      <ShieldAlert className="w-3 h-3 shrink-0" />
                      {reasonError}
                    </p>
                  )}
                  <p className="text-[10px] text-slate-400">
                    This reason will be logged in the permanent tenant audit trail and cannot be undone.
                  </p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center gap-3 justify-end pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={handleCancel}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl border border-slate-700/50 shadow-md transition-all cursor-pointer"
                >
                  {options.cancelText || "Cancel"}
                </button>
                <button
                  type="button"
                  disabled={isConfirmDisabled}
                  onClick={handleConfirm}
                  className={`px-5 py-2.5 font-bold text-xs rounded-xl transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${getConfirmButtonClasses(
                    options.type
                  )}`}
                >
                  {options.confirmText || (options.type === "danger" ? "Delete Record" : "Confirm")}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </ConfirmContext.Provider>
  );
}

export function useConfirm() {
  const ctx = useContext(ConfirmContext);
  if (!ctx) throw new Error("useConfirm must be used within ConfirmProvider");
  return ctx.confirm;
}

export function useConfirmWithReason() {
  const ctx = useContext(ConfirmContext);
  if (!ctx) throw new Error("useConfirmWithReason must be used within ConfirmProvider");
  return ctx.confirmWithReason;
}

// Global confirm proxy to intercept window.confirm dynamically
export function registerGlobalConfirm(confirmFn: (opts: ConfirmOptions) => Promise<boolean>) {
  if (typeof window !== "undefined") {
    if (!(window as any).__originalConfirm) {
      (window as any).__originalConfirm = window.confirm;
    }
  }
}


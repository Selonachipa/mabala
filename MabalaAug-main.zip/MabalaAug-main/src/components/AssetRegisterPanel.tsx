import React, { useState } from "react";
import { useConfirm } from "./ConfirmModal";
import { Asset, Supplier, Account, AssetMaintenanceLog, AssetDisposalRecord, BiologicalAssetTier } from "../types";
import { determineBiologicalClassification } from "../services/biologicalAssetIntegrationService";
import { jsPDF } from "jspdf";
import {
  BarChart as ReBarChart,
  Bar as ReBar,
  XAxis as ReXAxis,
  YAxis as ReYAxis,
  Tooltip as ReTooltip,
  Legend as ReLegend,
  ResponsiveContainer as ReResponsiveContainer,
  PieChart as RePieChart,
  Pie as RePie,
  Cell as ReCell
} from "recharts";
import { 
  Package, 
  Plus, 
  Trash2, 
  Wrench, 
  Calendar, 
  MapPin, 
  AlertTriangle, 
  TrendingDown, 
  FileCheck,
  Calculator,
  Archive,
  CheckCircle2,
  Clock,
  DollarSign,
  PieChart,
  BarChart2,
  X,
  TrendingUp,
  Search,
  Filter,
  FileText,
  RefreshCw,
  ShieldCheck,
  ChevronRight,
  Upload,
  FileSpreadsheet,
  Layers,
  BookOpen
} from "lucide-react";

interface AssetRegisterPanelProps {
  assets: Asset[];
  suppliers: Supplier[];
  onAddAsset: (asset: Omit<Asset, "id" | "farmId">) => void;
  onUpdateAsset?: (asset: Asset) => void;
  onUpdateAssets?: (assets: Asset[]) => void;
  onDeleteAsset: (id: string) => void;
  accounts?: Account[];
  onUpdateAccounts?: (accounts: Account[]) => void;
  isReadonly: boolean;
  currencySymbol: string;
}

export default function AssetRegisterPanel({
  assets,
  suppliers,
  onAddAsset,
  onUpdateAsset,
  onUpdateAssets,
  onDeleteAsset,
  accounts,
  onUpdateAccounts,
  isReadonly,
  currencySymbol
}: AssetRegisterPanelProps) {
  const confirm = useConfirm();

  // Tab State
  const [activeTab, setActiveTab] = useState<"dashboard" | "assets" | "maintenance" | "disposals">("dashboard");

  // Add Asset Form state
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState("");
  const [category, setCategory] = useState<Asset["category"]>("Equipment");
  const [assetClassification, setAssetClassification] = useState<BiologicalAssetTier>("ppe_asset");
  const [glAccountCode, setGlAccountCode] = useState<string>("1540");
  const [serial, setSerial] = useState("");
  const [purchaseDate, setPurchaseDate] = useState(new Date().toISOString().substring(0, 10));
  const [purchasePrice, setPurchasePrice] = useState("");
  const [location, setLocation] = useState("");
  const [supplierId, setSupplierId] = useState("");
  const [condition, setCondition] = useState<Asset["condition"]>("Good");
  const [depreciationRate, setDepreciationRate] = useState("10"); // e.g. 10% annual depreciation
  const [expectedUsefulLife, setExpectedUsefulLife] = useState("5"); // Expected useful life in years
  const [notes, setNotes] = useState("");

  // Asset Register Section Separation (Current vs Non-Current)
  const [assetScopeFilter, setAssetScopeFilter] = useState<"ALL" | "NON_CURRENT" | "CURRENT">("ALL");
  const [maintenanceScopeFilter, setMaintenanceScopeFilter] = useState<"ALL" | "NON_CURRENT" | "CURRENT">("ALL");

  // Bulk CSV Import Modal state
  const [showCsvImportModal, setShowCsvImportModal] = useState(false);
  const [rawCsvInput, setRawCsvInput] = useState("");
  const [parsedCsvItems, setParsedCsvItems] = useState<Omit<Asset, "id" | "farmId">[]>([]);
  const [csvParseError, setCsvParseError] = useState<string | null>(null);

  // Filters
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("All");
  const [conditionFilter, setConditionFilter] = useState<string>("All");

  // Modal States
  const [showMaintenanceModal, setShowMaintenanceModal] = useState(false);
  const [selectedAssetForMaint, setSelectedAssetForMaint] = useState<Asset | null>(null);
  const [maintDate, setMaintDate] = useState(new Date().toISOString().substring(0, 10));
  const [maintType, setMaintType] = useState<AssetMaintenanceLog["type"]>("Routine Service");
  const [maintDesc, setMaintDesc] = useState("");
  const [maintCost, setMaintCost] = useState("");
  const [maintTech, setMaintTech] = useState("");
  const [maintStatus, setMaintStatus] = useState<AssetMaintenanceLog["status"]>("Completed");
  const [maintNextDue, setMaintNextDue] = useState("");
  const [maintNotes, setMaintNotes] = useState("");
  const [maintPostCoa, setMaintPostCoa] = useState(true);

  // Dedicated Disposal Workflow Modal State
  const [showDisposalModal, setShowDisposalModal] = useState(false);
  const [selectedAssetForDisposal, setSelectedAssetForDisposal] = useState<Asset | null>(null);
  const [disposalDate, setDisposalDate] = useState(new Date().toISOString().substring(0, 10));
  const [disposalType, setDisposalType] = useState<AssetDisposalRecord["disposalType"]>("Sale");
  const [disposalProceeds, setDisposalProceeds] = useState("0");
  const [purchaserOrReason, setPurchaserOrReason] = useState("");

  // Bulk Depreciation Calculator Modal State
  const [showDepreciationModal, setShowDepreciationModal] = useState(false);
  const [depEvaluationDate, setDepEvaluationDate] = useState(new Date().toISOString().substring(0, 10));

  // Useful Life Calculator helper
  const calculateUsefulLife = (asset: Asset, evalDateStr?: string) => {
    const buyDate = new Date(asset.purchaseDate || Date.now());
    const evalDate = evalDateStr ? new Date(evalDateStr) : new Date();
    const diffTime = Math.max(0, evalDate.getTime() - buyDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const yearsElapsed = diffDays / 365.25;

    const expectedLife = asset.expectedUsefulLife && asset.expectedUsefulLife > 0
      ? asset.expectedUsefulLife
      : (asset.depreciationRate > 0 ? Math.round(100 / asset.depreciationRate) : 5);

    const remainingLife = Math.max(0, parseFloat((expectedLife - yearsElapsed).toFixed(1)));
    return {
      expectedLife,
      remainingLife,
      yearsElapsed: parseFloat(yearsElapsed.toFixed(1))
    };
  };

  // Live Auto-Depreciation Calculator helper (Straight-Line for PPE, Fair/Current Transformation Value for Biological Assets per IAS 41)
  const calculateDepreciatedValue = (asset: Asset, evalDateStr?: string) => {
    const buyDate = new Date(asset.purchaseDate || Date.now());
    const evalDate = evalDateStr ? new Date(evalDateStr) : new Date();
    
    // Difference in years
    const diffTime = Math.max(0, evalDate.getTime() - buyDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const yearsElapsed = diffDays / 365.25;

    // IAS 41 Biological assets: Value changes come from biological transformation, not straight-line mechanical wear-and-tear
    const isBiological = 
      asset.assetClassification === "non_current_biological" ||
      asset.assetClassification === "current_biological" ||
      ["Livestock", "Poultry", "Aquaculture", "Crops", "Orchard"].includes(asset.category);

    if (isBiological) {
      const bioVal = asset.currentValue ?? asset.purchasePrice;
      return {
        expectedLife: asset.expectedUsefulLife || 0,
        depreciatedAmount: 0,
        currentDepValue: parseFloat(bioVal.toFixed(2)),
        pctLost: 0,
        yearsElapsed: parseFloat(yearsElapsed.toFixed(2)),
        isBiological: true
      };
    }

    // Expected useful life in years for standard PPE
    const expectedLife = asset.expectedUsefulLife && asset.expectedUsefulLife > 0
      ? asset.expectedUsefulLife
      : (asset.depreciationRate > 0 ? (100 / asset.depreciationRate) : 5);

    // Straight-line depreciation fraction based on useful life
    const totalDepreciatedPct = Math.min(1, yearsElapsed / expectedLife);
    const calculatedCurrentValue = asset.purchasePrice * (1 - totalDepreciatedPct);

    return {
      expectedLife,
      depreciatedAmount: asset.purchasePrice * totalDepreciatedPct,
      currentDepValue: parseFloat(Math.max(0, calculatedCurrentValue).toFixed(2)),
      pctLost: Math.min(100, Math.round(totalDepreciatedPct * 100)),
      yearsElapsed: parseFloat(yearsElapsed.toFixed(2)),
      isBiological: false
    };
  };

  // CSV Parsing function
  const handleParseCsv = (content: string) => {
    setCsvParseError(null);
    if (!content.trim()) {
      setParsedCsvItems([]);
      return;
    }

    try {
      const lines = content.trim().split(/\r?\n/);
      if (lines.length < 2) {
        setCsvParseError("CSV must contain at least a header row and one data row.");
        return;
      }

      // Extract header row
      const headers = lines[0].split(",").map(h => h.trim().toLowerCase().replace(/[^a-z0-9]/g, ""));
      
      const parsed: Omit<Asset, "id" | "farmId">[] = [];
      const defaultSupplier = suppliers[0]?.id || "SUP-DEFAULT";

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        
        // Simple comma split handling quotes
        const cols = line.split(/,(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)/).map(c => c.replace(/^"|"$/g, "").trim());

        // Find indexes
        const nameIdx = headers.findIndex(h => h.includes("name") || h.includes("asset"));
        const catIdx = headers.findIndex(h => h.includes("cat"));
        const priceIdx = headers.findIndex(h => h.includes("price font") || h.includes("price") || h.includes("cost"));
        const dateIdx = headers.findIndex(h => h.includes("date") || h.includes("purchasedate"));
        const usefulLifeIdx = headers.findIndex(h => h.includes("usefullife") || h.includes("life") || h.includes("expected"));
        const serialIdx = headers.findIndex(h => h.includes("serial") || h.includes("sn"));
        const locIdx = headers.findIndex(h => h.includes("loc"));
        const condIdx = headers.findIndex(h => h.includes("cond"));
        const depIdx = headers.findIndex(h => h.includes("dep") || h.includes("rate"));
        const notesIdx = headers.findIndex(h => h.includes("note") || h.includes("desc"));

        const assetName = nameIdx >= 0 && cols[nameIdx] ? cols[nameIdx] : (cols[0] || `CSV Asset #${i}`);
        const rawCat = catIdx >= 0 && cols[catIdx] ? cols[catIdx] : (cols[1] || "Equipment");
        const rawPrice = priceIdx >= 0 && cols[priceIdx] ? cols[priceIdx] : (cols[2] || "0");
        const rawDate = dateIdx >= 0 && cols[dateIdx] ? cols[dateIdx] : (cols[3] || new Date().toISOString().substring(0, 10));
        const rawUsefulLife = usefulLifeIdx >= 0 && cols[usefulLifeIdx] ? cols[usefulLifeIdx] : "5";
        const rawSerial = serialIdx >= 0 && cols[serialIdx] ? cols[serialIdx] : "";
        const rawLoc = locIdx >= 0 && cols[locIdx] ? cols[locIdx] : "Main Depot";
        const rawCond = condIdx >= 0 && cols[condIdx] ? cols[condIdx] : "Good";
        const rawDep = depIdx >= 0 && cols[depIdx] ? cols[depIdx] : "10";
        const rawNotes = notesIdx >= 0 && cols[notesIdx] ? cols[notesIdx] : "Bulk CSV Import";

        const rawClassification = cols[headers.findIndex(h => h.includes("class") || h.includes("tier"))] || "";
        const rawGl = cols[headers.findIndex(h => h.includes("gl") || h.includes("account"))] || "";

        // Map Category
        let validCat: Asset["category"] = "Equipment";
        if (/livestock|cow|cattle|bull|goat|sheep|pig|heifer/i.test(rawCat)) validCat = "Livestock";
        else if (/poultry|chicken|broiler|layer|bird/i.test(rawCat)) validCat = "Poultry";
        else if (/fish|aqua|tilapia|fingerling/i.test(rawCat)) validCat = "Aquaculture";
        else if (/crop|field|maize|soya/i.test(rawCat)) validCat = "Crops";
        else if (/orchard|tree|citrus|avocado/i.test(rawCat)) validCat = "Orchard";
        else if (/land/i.test(rawCat)) validCat = "Land";
        else if (/build/i.test(rawCat)) validCat = "Buildings";
        else if (/vehic|truck|bike/i.test(rawCat)) validCat = "Vehicles";
        else if (/water|tank|pump/i.test(rawCat)) validCat = "Water Infrastructure";
        else if (/other/i.test(rawCat)) validCat = "Other";

        // Map Condition
        let validCond: Asset["condition"] = "Good";
        if (/excel/i.test(rawCond)) validCond = "Excellent";
        else if (/fair/i.test(rawCond)) validCond = "Fair";
        else if (/poor/i.test(rawCond)) validCond = "Poor";

        const pPrice = Math.max(0, parseFloat(rawPrice.replace(/[^0-9.]/g, "")) || 0);
        const uLife = Math.max(1, parseFloat(rawUsefulLife.replace(/[^0-9.]/g, "")) || 5);
        const dRate = Math.max(0, parseFloat(rawDep.replace(/[^0-9.]/g, "")) || 10);

        // Derive Tier Classification
        let mappedTier: BiologicalAssetTier = "ppe_asset";
        if (/non_current|noncurrent|breed|dairy|layer|draft|sow/i.test(rawClassification || rawCat)) {
          mappedTier = "non_current_biological";
        } else if (/current|grower|broiler|feeder|meat|sale|fish/i.test(rawClassification || rawCat)) {
          mappedTier = "current_biological";
        } else if (/inventory|harvest|meat_proc|milk/i.test(rawClassification || rawCat)) {
          mappedTier = "post_harvest_inventory";
        } else if (["Livestock", "Poultry", "Aquaculture", "Crops", "Orchard"].includes(validCat)) {
          mappedTier = /layer|dairy|breed/i.test(assetName) ? "non_current_biological" : "current_biological";
        }

        const tierCategory: "Current" | "Non-Current" = 
          mappedTier === "current_biological" || mappedTier === "post_harvest_inventory" ? "Current" : "Non-Current";

        const resolvedGl = rawGl || (
          mappedTier === "non_current_biological" ? "1460" :
          mappedTier === "current_biological" ? "1400" :
          mappedTier === "post_harvest_inventory" ? "1350" :
          validCat === "Land" ? "1510" :
          validCat === "Buildings" ? "1520" :
          validCat === "Vehicles" ? "1550" : "1540"
        );

        parsed.push({
          name: assetName,
          category: validCat,
          assetClassification: mappedTier,
          assetTypeCategory: tierCategory,
          glAccountCode: resolvedGl,
          serial: rawSerial,
          purchaseDate: rawDate,
          purchasePrice: pPrice,
          currentValue: pPrice,
          expectedUsefulLife: uLife,
          remainingUsefulLife: uLife,
          location: rawLoc,
          supplierId: defaultSupplier,
          condition: validCond,
          depreciationRate: dRate,
          notes: rawNotes,
          maintenanceLogs: [],
          isDisposed: false
        });
      }

      setParsedCsvItems(parsed);
    } catch (err: any) {
      console.error("CSV Parse error:", err);
      setCsvParseError("Failed to parse CSV string. Please verify column headers and row formats.");
    }
  };

  // Submit Bulk CSV Import
  const handleExecuteBulkImport = () => {
    if (parsedCsvItems.length === 0) {
      alert("No valid assets parsed from CSV to import.");
      return;
    }

    parsedCsvItems.forEach(asset => {
      onAddAsset(asset);
    });

    alert(`✅ Successfully imported ${parsedCsvItems.length} assets into the Asset Register!`);
    setShowCsvImportModal(false);
    setRawCsvInput("");
    setParsedCsvItems([]);
  };

  // Submit New Asset Form
  const handleSub = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !purchasePrice || !supplierId || !location) {
      alert("Please check your input fields. Asset Name, Purchase Price, Supplier registry link, and Location are required.");
      return;
    }
    
    const usefulLifeNum = Number(expectedUsefulLife) || 5;
    const tierCategory: "Current" | "Non-Current" = 
      assetClassification === "current_biological" || assetClassification === "post_harvest_inventory" 
        ? "Current" 
        : "Non-Current";
    
    onAddAsset({
      name,
      category,
      assetClassification,
      assetTypeCategory: tierCategory,
      glAccountCode: glAccountCode || (tierCategory === "Current" ? "1400" : "1540"),
      serial,
      purchaseDate,
      purchasePrice: Number(purchasePrice),
      currentValue: Number(purchasePrice),
      expectedUsefulLife: usefulLifeNum,
      remainingUsefulLife: usefulLifeNum,
      location,
      supplierId,
      condition,
      notes,
      depreciationRate: Number(depreciationRate),
      maintenanceLogs: [],
      isDisposed: false
    });

    setName("");
    setSerial("");
    setPurchasePrice("");
    setLocation("");
    setSupplierId("");
    setNotes("");
    setShowAddForm(false);
  };

  // Active (Non-disposed) vs Disposed assets
  const activeAssets = assets.filter(a => !a.isDisposed);
  const disposedAssets = assets.filter(a => a.isDisposed);

  // Non-Current vs Current Assets Partitioning
  const nonCurrentAssets = activeAssets.filter(a => {
    if (a.assetTypeCategory === "Non-Current") return true;
    if (a.assetClassification === "non_current_biological" || a.assetClassification === "ppe_asset") return true;
    if (a.assetTypeCategory === "Current" || a.assetClassification === "current_biological" || a.assetClassification === "post_harvest_inventory") return false;
    return !["Poultry", "Aquaculture", "Crops"].includes(a.category);
  });

  const currentAssets = activeAssets.filter(a => {
    if (a.assetTypeCategory === "Current") return true;
    if (a.assetClassification === "current_biological" || a.assetClassification === "post_harvest_inventory") return true;
    if (a.assetTypeCategory === "Non-Current" || a.assetClassification === "non_current_biological" || a.assetClassification === "ppe_asset") return false;
    return ["Poultry", "Aquaculture", "Crops"].includes(a.category);
  });

  // Aggregated Statistics
  const totalOriginalBookValue = activeAssets.reduce((sum, a) => sum + a.purchasePrice, 0);
  const totalDepreciatedCurrentValue = activeAssets.reduce((sum, a) => {
    const { currentDepValue } = calculateDepreciatedValue(a);
    return sum + currentDepValue;
  }, 0);
  const totalDepreciationLoss = totalOriginalBookValue - totalDepreciatedCurrentValue;

  // Sub-totals for Non-Current and Current
  const nonCurrentTotalVal = nonCurrentAssets.reduce((sum, a) => sum + calculateDepreciatedValue(a).currentDepValue, 0);
  const currentTotalVal = currentAssets.reduce((sum, a) => sum + calculateDepreciatedValue(a).currentDepValue, 0);

  // Maintenance statistics & list across active assets
  const allMaintenanceLogs: (AssetMaintenanceLog & { assetClassification?: BiologicalAssetTier; assetTypeCategory?: "Current" | "Non-Current" })[] = 
    assets.flatMap(a => (a.maintenanceLogs || []).map(m => ({ 
      ...m, 
      assetName: a.name,
      assetClassification: a.assetClassification,
      assetTypeCategory: a.assetTypeCategory
    })));
  const totalMaintenanceCost = allMaintenanceLogs.reduce((sum, m) => sum + (m.cost || 0), 0);
  
  // Assets due for maintenance (condition Poor/Fair, or nextDueDate within 30 days, or overdue log)
  const todayStr = new Date().toISOString().substring(0, 10);
  const assetsDueForMaintenance = activeAssets.filter(asset => {
    if (asset.condition === "Poor" || asset.condition === "Fair") return true;
    const logs = asset.maintenanceLogs || [];
    const hasOverdueOrUpcoming = logs.some(l => {
      if (l.status === "Overdue") return true;
      if (l.nextDueDate && l.nextDueDate <= new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().substring(0, 10)) return true;
      return false;
    });
    return hasOverdueOrUpcoming;
  });

  // Disposals summary metrics
  const totalDisposalProceeds = disposedAssets.reduce((sum, a) => sum + (a.disposalRecord?.proceeds || 0), 0);
  const totalDisposalNetGainLoss = disposedAssets.reduce((sum, a) => sum + (a.disposalRecord?.gainLoss || 0), 0);

  // 3-Tier Classification & IAS 41 / IAS 16 / IAS 2 Portfolio Breakdown
  const tierStats = [
    {
      id: "non_current_biological",
      label: "Non-Current Biological Assets (IAS 41)",
      description: "Breeding/Mature productive stock (dairy cows, breeding bulls, laying hens, breeding sows, draft animals, fruit orchards)",
      glAccounts: "1450, 1460, 1470, 1480, 1490",
      assets: activeAssets.filter(a => a.assetClassification === "non_current_biological" || (a.assetTypeCategory === "Non-Current" && ["Livestock", "Poultry", "Orchard"].includes(a.category))),
      badgeColor: "bg-indigo-100 text-indigo-800 border-indigo-200",
      accent: "indigo"
    },
    {
      id: "current_biological",
      label: "Current Biological Assets (IAS 41)",
      description: "Growing/Immature stock for sale (broilers, weaner pigs, growing beef cattle, aquaculture biomass, standing crops)",
      glAccounts: "1400, 1410, 1420, 1430, 1440",
      assets: activeAssets.filter(a => a.assetClassification === "current_biological" || (a.assetTypeCategory === "Current" && ["Livestock", "Poultry", "Aquaculture", "Crops"].includes(a.category))),
      badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-200",
      accent: "emerald"
    },
    {
      id: "post_harvest_inventory",
      label: "Post-Harvest / Slaughter Inventory (IAS 2)",
      description: "Agricultural produce once extracted or slaughtered (milk bulk, dressed meat, harvested grain bags)",
      glAccounts: "1350, 1360, 1370",
      assets: activeAssets.filter(a => a.assetClassification === "post_harvest_inventory"),
      badgeColor: "bg-amber-100 text-amber-800 border-amber-200",
      accent: "amber"
    },
    {
      id: "ppe_asset",
      label: "Property, Plant & Equipment (IAS 16)",
      description: "Land, buildings, tractors, solar pumps, center pivots, cold rooms, vehicles & machinery",
      glAccounts: "1510, 1520, 1530, 1540, 1550",
      assets: activeAssets.filter(a => !a.assetClassification || a.assetClassification === "ppe_asset" || ["Land", "Buildings", "Equipment", "Vehicles", "Water Infrastructure", "Other"].includes(a.category)),
      badgeColor: "bg-slate-100 text-slate-800 border-slate-300",
      accent: "slate"
    }
  ].map(tier => {
    const currentVal = tier.assets.reduce((sum, a) => sum + calculateDepreciatedValue(a).currentDepValue, 0);
    const origVal = tier.assets.reduce((sum, a) => sum + a.purchasePrice, 0);
    const pct = totalDepreciatedCurrentValue > 0 ? Math.round((currentVal / totalDepreciatedCurrentValue) * 100) : 0;
    return {
      ...tier,
      count: tier.assets.length,
      currentVal,
      origVal,
      pct
    };
  });

  // Categories list & statistics
  const categoriesList: Asset["category"][] = [
    "Livestock",
    "Poultry",
    "Aquaculture",
    "Crops",
    "Orchard",
    "Land",
    "Buildings",
    "Equipment",
    "Vehicles",
    "Water Infrastructure",
    "Other"
  ];
  const categoryStats = categoriesList.map(cat => {
    const catAssets = activeAssets.filter(a => a.category === cat);
    const totalVal = catAssets.reduce((sum, a) => sum + calculateDepreciatedValue(a).currentDepValue, 0);
    const origVal = catAssets.reduce((sum, a) => sum + a.purchasePrice, 0);
    const pctOfTotal = totalDepreciatedCurrentValue > 0 ? (totalVal / totalDepreciatedCurrentValue) * 100 : 0;
    return {
      category: cat,
      count: catAssets.length,
      currentVal: totalVal,
      origVal,
      pctOfTotal: Math.round(pctOfTotal)
    };
  }).filter(stat => stat.count > 0 || ["Land", "Buildings", "Equipment", "Vehicles", "Livestock", "Poultry"].includes(stat.category));

  // Open Maintenance Modal for a specific asset
  const handleOpenMaintenanceModal = (asset: Asset) => {
    setSelectedAssetForMaint(asset);
    setMaintDate(new Date().toISOString().substring(0, 10));
    setMaintType("Routine Service");
    setMaintDesc("");
    setMaintCost("");
    setMaintTech("");
    setMaintStatus("Completed");
    setMaintNextDue("");
    setMaintNotes("");
    setMaintPostCoa(true);
    setShowMaintenanceModal(true);
  };

  // Submit Maintenance Log
  const handleSaveMaintenanceLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAssetForMaint || !maintDesc || !maintTech) {
      alert("Please provide service description and technician / service provider name.");
      return;
    }

    const costNum = Number(maintCost) || 0;
    const newLog: AssetMaintenanceLog = {
      id: "MNT-" + Date.now().toString().slice(-6),
      assetId: selectedAssetForMaint.id,
      assetName: selectedAssetForMaint.name,
      date: maintDate,
      type: maintType,
      description: maintDesc,
      cost: costNum,
      performedBy: maintTech,
      status: maintStatus,
      nextDueDate: maintNextDue || undefined,
      notes: maintNotes || undefined
    };

    const updatedLogs = [newLog, ...(selectedAssetForMaint.maintenanceLogs || [])];
    const updatedAsset: Asset = {
      ...selectedAssetForMaint,
      maintenanceLogs: updatedLogs,
      // Upgrade or adjust condition if routine service completed
      condition: maintStatus === "Completed" && selectedAssetForMaint.condition === "Poor" ? "Good" : selectedAssetForMaint.condition
    };

    if (onUpdateAsset) {
      onUpdateAsset(updatedAsset);
    }

    // Optional Double-entry Accounting Log: Debit Repairs & Maintenance 5200 & Credit Bank 1010
    if (maintPostCoa && costNum > 0 && accounts && onUpdateAccounts) {
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        if (acc.code === "1010") {
          balance -= costNum;
        }
        if (acc.code === "5200" || acc.code === "5000") {
          balance += costNum;
        }
        return { ...acc, balance };
      });
      onUpdateAccounts(updatedAccounts);
    }

    setShowMaintenanceModal(false);
    setSelectedAssetForMaint(null);
  };

  // Open Disposal Modal
  const handleOpenDisposalModal = (asset: Asset) => {
    const { currentDepValue } = calculateDepreciatedValue(asset);
    setSelectedAssetForDisposal(asset);
    setDisposalDate(new Date().toISOString().substring(0, 10));
    setDisposalType("Sale");
    setDisposalProceeds(currentDepValue.toString());
    setPurchaserOrReason("");
    setShowDisposalModal(true);
  };

  // Execute Disposal Workflow with Automated Journal Entry
  const handleConfirmDisposal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAssetForDisposal) return;

    const proceedsNum = Number(disposalProceeds) || 0;
    const { currentDepValue } = calculateDepreciatedValue(selectedAssetForDisposal);
    const bookValueAtDisposal = currentDepValue;
    const gainLoss = proceedsNum - bookValueAtDisposal;
    const journalRef = "JRN-DISP-" + Date.now().toString().slice(-6);

    const disposalRecord: AssetDisposalRecord = {
      disposalDate,
      disposalType,
      proceeds: proceedsNum,
      bookValueAtDisposal,
      gainLoss,
      purchaserOrReason,
      journalEntryRef: journalRef
    };

    const updatedAsset: Asset = {
      ...selectedAssetForDisposal,
      isDisposed: true,
      currentValue: 0,
      disposalRecord
    };

    if (onUpdateAsset) {
      onUpdateAsset(updatedAsset);
    }

    // Automatic Journal Entry trigger on Chart of Accounts
    if (accounts && onUpdateAccounts) {
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        // 1. Debit Bank/Cash (1010) for sale proceeds
        if (acc.code === "1010") {
          balance += proceedsNum;
        }
        // 2. Credit Fixed Assets Capitalization (1530) for historical purchase price
        if (acc.code === "1530") {
          balance -= selectedAssetForDisposal.purchasePrice;
        }
        // 3. Recognize Gain or Loss on Disposal
        if (gainLoss > 0 && (acc.code === "4500" || acc.code === "4000")) {
          balance += gainLoss;
        } else if (gainLoss < 0 && (acc.code === "5500" || acc.code === "5400" || acc.code === "5000")) {
          balance += Math.abs(gainLoss);
        }
        return { ...acc, balance };
      });
      onUpdateAccounts(updatedAccounts);
    }

    setShowDisposalModal(false);
    setSelectedAssetForDisposal(null);
  };

  // Bulk Depreciation Calculator: Calculate schedules
  const bulkDepreciations = activeAssets.map(asset => {
    const { currentDepValue, depreciatedAmount, pctLost, yearsElapsed } = calculateDepreciatedValue(asset, depEvaluationDate);
    return {
      asset,
      oldValue: asset.currentValue,
      newDepreciatedValue: currentDepValue,
      depreciationExpense: depreciatedAmount,
      pctLost,
      yearsElapsed
    };
  });

  const totalBulkDepreciationRecognized = bulkDepreciations.reduce((sum, item) => sum + (item.asset.currentValue - item.newDepreciatedValue), 0);

  // Apply Bulk Depreciation
  const handleApplyBulkDepreciation = () => {
    if (activeAssets.length === 0) {
      alert("No active assets available for bulk depreciation update.");
      return;
    }

    const updatedAssetsList = assets.map(a => {
      if (a.isDisposed) return a;
      const { currentDepValue } = calculateDepreciatedValue(a, depEvaluationDate);
      return {
        ...a,
        currentValue: currentDepValue,
        lastDepreciationDate: depEvaluationDate
      };
    });

    if (onUpdateAssets) {
      onUpdateAssets(updatedAssetsList);
    }

    // Accounting Entry: Debit Depreciation Expense (5400) & Credit Accumulated Asset Offset (1530)
    if (accounts && onUpdateAccounts && totalBulkDepreciationRecognized > 0) {
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        if (acc.code === "5400" || acc.code === "5000") {
          balance += totalBulkDepreciationRecognized;
        }
        if (acc.code === "1530") {
          balance -= totalBulkDepreciationRecognized;
        }
        return { ...acc, balance };
      });
      onUpdateAccounts(updatedAccounts);
    }

    setShowDepreciationModal(false);
    alert(`✅ Bulk depreciation applied! Total Depreciation Expense of ${currencySymbol} ${totalBulkDepreciationRecognized.toLocaleString(undefined, { minimumFractionDigits: 2 })} recognized on ledger.`);
  };

  // Download Valuation Report PDF
  const handleDownloadValuationReport = () => {
    try {
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const nowStr = new Date().toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
      });

      // Header Banner
      doc.setFillColor(15, 23, 42); // slate-900
      doc.rect(0, 0, 210, 30, "F");

      doc.setTextColor(255, 255, 255);
      doc.setFontSize(15);
      doc.setFont("helvetica", "bold");
      doc.text("ASSET VALUATION & DEPRECIATION REPORT", 14, 15);

      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(148, 163, 184); // slate-400
      doc.text(`Generated: ${nowStr} | Total Registered Assets: ${assets.length}`, 14, 22);

      // Executive Financial Summary Box
      let totalPurchase = 0;
      let totalCurrent = 0;
      let totalMaintCost = 0;
      const allLogs: { assetName: string; log: AssetMaintenanceLog }[] = [];

      assets.forEach(a => {
        totalPurchase += (a.purchasePrice || 0);
        totalCurrent += (a.currentValue || 0);
        if (a.maintenanceLogs && a.maintenanceLogs.length > 0) {
          a.maintenanceLogs.forEach(ml => {
            totalMaintCost += (ml.cost || 0);
            allLogs.push({ assetName: a.name, log: ml });
          });
        }
      });

      const totalAccumulatedDep = Math.max(0, totalPurchase - totalCurrent);

      doc.setFillColor(248, 250, 252); // slate-50
      doc.setDrawColor(226, 232, 240); // slate-200
      doc.roundedRect(14, 35, 182, 32, 2, 2, "FD");

      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(30, 41, 59);
      doc.text("EXECUTIVE FINANCIAL SUMMARY", 18, 42);

      doc.setFontSize(8);
      doc.setFont("helvetica", "normal");

      // Col 1: Acquisition
      doc.setTextColor(100, 116, 139);
      doc.text("Acquisition Price:", 18, 50);
      doc.setTextColor(15, 23, 42);
      doc.setFont("helvetica", "bold");
      doc.text(`${currencySymbol} ${totalPurchase.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 18, 56);

      // Col 2: Net Valuation
      doc.setFont("helvetica", "normal");
      doc.setTextColor(100, 116, 139);
      doc.text("Net Book Valuation:", 68, 50);
      doc.setTextColor(16, 185, 129);
      doc.setFont("helvetica", "bold");
      doc.text(`${currencySymbol} ${totalCurrent.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 68, 56);

      // Col 3: Depreciation
      doc.setFont("helvetica", "normal");
      doc.setTextColor(100, 116, 139);
      doc.text("Accumulated Dep.:", 118, 50);
      doc.setTextColor(225, 29, 72);
      doc.setFont("helvetica", "bold");
      doc.text(`${currencySymbol} ${totalAccumulatedDep.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 118, 56);

      // Col 4: Maintenance
      doc.setFont("helvetica", "normal");
      doc.setTextColor(100, 116, 139);
      doc.text("Maintenance Spent:", 162, 50);
      doc.setTextColor(79, 70, 229);
      doc.setFont("helvetica", "bold");
      doc.text(`${currencySymbol} ${totalMaintCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 162, 56);

      let yPos = 75;

      // Section 1: Asset Ledger Table
      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(30, 41, 59);
      doc.text("1. CAPITALIZED ASSET VALUATION & DEPRECIATION REGISTER", 14, yPos);
      yPos += 5;

      doc.setFillColor(241, 245, 249);
      doc.rect(14, yPos, 182, 7, "F");
      doc.setFontSize(8);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(71, 85, 105);
      doc.text("ASSET NAME", 16, yPos + 5);
      doc.text("CATEGORY", 62, yPos + 5);
      doc.text("PURCHASED", 95, yPos + 5);
      doc.text("PURCHASE PRICE", 122, yPos + 5);
      doc.text("ACC. DEP.", 152, yPos + 5);
      doc.text("BOOK VALUE", 178, yPos + 5);
      yPos += 8;

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);

      assets.forEach((asset, idx) => {
        if (yPos > 270) {
          doc.addPage();
          yPos = 15;
        }

        const accDep = Math.max(0, asset.purchasePrice - asset.currentValue);
        
        if (idx % 2 === 1) {
          doc.setFillColor(248, 250, 252);
          doc.rect(14, yPos - 3, 182, 6, "F");
        }

        doc.setTextColor(30, 41, 59);
        const nameTrunc = asset.name.length > 24 ? asset.name.substring(0, 22) + ".." : asset.name;
        doc.text(nameTrunc, 16, yPos);
        doc.setTextColor(100, 116, 139);
        doc.text(asset.category, 62, yPos);
        doc.text(asset.purchaseDate || "N/A", 95, yPos);
        doc.text(`${currencySymbol} ${asset.purchasePrice.toLocaleString()}`, 122, yPos);
        doc.setTextColor(225, 29, 72);
        doc.text(`${currencySymbol} ${accDep.toLocaleString()}`, 152, yPos);
        doc.setTextColor(16, 185, 129);
        doc.text(`${currencySymbol} ${asset.currentValue.toLocaleString()}`, 178, yPos);

        yPos += 6;
      });

      yPos += 8;

      // Section 2: Maintenance History Table
      if (yPos > 240) {
        doc.addPage();
        yPos = 15;
      }

      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(30, 41, 59);
      doc.text("2. MAINTENANCE HISTORY & SERVICE LOGS", 14, yPos);
      yPos += 5;

      doc.setFillColor(241, 245, 249);
      doc.rect(14, yPos, 182, 7, "F");
      doc.setFontSize(8);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(71, 85, 105);
      doc.text("DATE", 16, yPos + 5);
      doc.text("ASSET NAME", 38, yPos + 5);
      doc.text("TYPE", 80, yPos + 5);
      doc.text("DESCRIPTION", 112, yPos + 5);
      doc.text("COST", 160, yPos + 5);
      doc.text("STATUS", 185, yPos + 5);
      yPos += 8;

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);

      if (allLogs.length === 0) {
        doc.setTextColor(148, 163, 184);
        doc.text("No maintenance service logs recorded.", 16, yPos);
        yPos += 6;
      } else {
        allLogs.forEach((item, idx) => {
          if (yPos > 270) {
            doc.addPage();
            yPos = 15;
          }

          if (idx % 2 === 1) {
            doc.setFillColor(248, 250, 252);
            doc.rect(14, yPos - 3, 182, 6, "F");
          }

          doc.setTextColor(30, 41, 59);
          doc.text((item.log as any).logDate || item.log.date || "N/A", 16, yPos);
          const nameTrunc = item.assetName.length > 18 ? item.assetName.substring(0, 16) + ".." : item.assetName;
          doc.text(nameTrunc, 38, yPos);
          doc.text((item.log as any).maintenanceType || item.log.type || "Service", 80, yPos);
          const descTrunc = (item.log.description || "").length > 24 ? (item.log.description || "").substring(0, 22) + ".." : (item.log.description || "Service");
          doc.text(descTrunc, 112, yPos);
          doc.setTextColor(79, 70, 229);
          doc.text(`${currencySymbol} ${item.log.cost.toLocaleString()}`, 160, yPos);
          doc.setTextColor(100, 116, 139);
          doc.text(item.log.status || "Completed", 185, yPos);

          yPos += 6;
        });
      }

      // Save output
      const filename = `Asset_Valuation_Report_${new Date().toISOString().split("T")[0]}.pdf`;
      doc.save(filename);
    } catch (err) {
      console.error("[Asset Valuation Report] Error generating PDF:", err);
      alert("Failed to generate PDF Valuation Report. Please try again.");
    }
  };

  // Filtered Assets list
  const filteredActiveAssets = activeAssets.filter(asset => {
    const matchesSearch = asset.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          asset.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (asset.serial && asset.serial.toLowerCase().includes(searchTerm.toLowerCase())) ||
                          (asset.glAccountCode && asset.glAccountCode.includes(searchTerm));
    const matchesCategory = categoryFilter === "All" || asset.category === categoryFilter;
    const matchesCondition = conditionFilter === "All" || asset.condition === conditionFilter;
    
    // Non-Current vs Current section scope filtering
    const matchesScope = 
      assetScopeFilter === "ALL" ? true :
      assetScopeFilter === "NON_CURRENT" ? (
        asset.assetTypeCategory === "Non-Current" ||
        asset.assetClassification === "non_current_biological" ||
        asset.assetClassification === "ppe_asset" ||
        (!asset.assetClassification && !["Poultry", "Aquaculture", "Crops"].includes(asset.category))
      ) : (
        asset.assetTypeCategory === "Current" ||
        asset.assetClassification === "current_biological" ||
        asset.assetClassification === "post_harvest_inventory" ||
        ["Poultry", "Aquaculture", "Crops"].includes(asset.category)
      );

    return matchesSearch && matchesCategory && matchesCondition && matchesScope;
  });

  // Filtered Maintenance Logs by scope
  const filteredMaintenanceLogs = allMaintenanceLogs.filter(log => {
    if (maintenanceScopeFilter === "ALL") return true;
    const isCurrent = 
      log.assetTypeCategory === "Current" ||
      log.assetClassification === "current_biological" ||
      log.assetClassification === "post_harvest_inventory";
    return maintenanceScopeFilter === "CURRENT" ? isCurrent : !isCurrent;
  });

  return (
    <div className="space-y-6 font-sans">
      {/* Top Banner & Header */}
      <div className="bg-white border rounded-xl p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-black text-slate-800 flex items-center gap-2">
            <Package className="w-5 h-5 text-emerald-500" />
            Asset Register, Ledger & Maintenance
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Track capitalized company assets, automate linear depreciation schedules, manage maintenance service histories, and post dedicated disposal journal entries.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleDownloadValuationReport}
            className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2 px-3.5 rounded-lg flex items-center gap-1.5 shadow-sm active:scale-[0.98] transition-all cursor-pointer"
          >
            <FileText className="w-4 h-4 text-emerald-400" /> Download Valuation Report
          </button>
          {!isReadonly && (
            <>
              <button
                onClick={() => setShowCsvImportModal(true)}
                className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs py-2 px-3.5 rounded-lg flex items-center gap-1.5 border border-emerald-200 transition-all cursor-pointer"
              >
                <Upload className="w-4 h-4 text-emerald-600" /> Bulk CSV Import
              </button>
              <button
                onClick={() => setShowDepreciationModal(true)}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-2 px-3.5 rounded-lg flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
              >
                <Calculator className="w-4 h-4 text-indigo-200" /> Batch Depreciation Run
              </button>
              <button
                onClick={() => setShowAddForm(prev => !prev)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 px-4 rounded-lg flex items-center gap-1.5 shadow active:scale-[0.98] transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" /> {showAddForm ? "Collapse Form" : "Capitalize Asset"}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab("dashboard")}
          className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "dashboard"
              ? "bg-slate-900 text-white shadow"
              : "bg-white text-slate-600 hover:bg-slate-100 border"
          }`}
        >
          <BarChart2 className="w-4 h-4 text-emerald-400" /> Summary Dashboard
        </button>
        <button
          onClick={() => setActiveTab("assets")}
          className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "assets"
              ? "bg-slate-900 text-white shadow"
              : "bg-white text-slate-600 hover:bg-slate-100 border"
          }`}
        >
          <Package className="w-4 h-4 text-emerald-500" /> Asset Register ({activeAssets.length})
        </button>
        <button
          onClick={() => setActiveTab("maintenance")}
          className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "maintenance"
              ? "bg-slate-900 text-white shadow"
              : "bg-white text-slate-600 hover:bg-slate-100 border"
          }`}
        >
          <Wrench className="w-4 h-4 text-amber-400" /> Maintenance & Service ({allMaintenanceLogs.length})
          {assetsDueForMaintenance.length > 0 && (
            <span className="bg-amber-500 text-slate-950 font-black px-1.5 py-0.2 rounded-full text-[9px] animate-pulse">
              {assetsDueForMaintenance.length} Due
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab("disposals")}
          className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "disposals"
              ? "bg-slate-900 text-white shadow"
              : "bg-white text-slate-600 hover:bg-slate-100 border"
          }`}
        >
          <Archive className="w-4 h-4 text-rose-400" /> Disposals Archive ({disposedAssets.length})
        </button>
      </div>

      {/* 1. SUMMARY DASHBOARD VIEW */}
      {activeTab === "dashboard" && (
        <div className="space-y-6 animate-fade-in">
          {/* Key Valuation Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            <div className="bg-white p-4 rounded-xl border shadow-sm">
              <div className="text-[10px] uppercase font-extrabold text-slate-400">Total Purchase Book Cost</div>
              <div className="text-xl font-black text-slate-800 mt-1">
                {currencySymbol} {totalOriginalBookValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] text-emerald-600 font-medium mt-1 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> Capitalized active fleet
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border shadow-sm">
              <div className="text-[10px] uppercase font-extrabold text-slate-400">Current Valuation After Dep.</div>
              <div className="text-xl font-black text-slate-900 mt-1">
                {currencySymbol} {totalDepreciatedCurrentValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] text-amber-500 font-medium mt-1 flex items-center gap-1">
                <TrendingDown className="w-3.5 h-3.5 text-amber-500" /> Straight-line schedule
              </div>
            </div>

            <div className="bg-slate-900 text-white p-4 rounded-xl shadow-sm flex flex-col justify-between">
              <div>
                <div className="text-[10px] uppercase font-extrabold text-slate-400">Accumulated Dep.</div>
                <div className="text-lg font-black text-rose-400 mt-1">
                  {currencySymbol} {totalDepreciationLoss.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
              </div>
              <div className="text-[9px] text-slate-400 font-mono mt-1">
                Ledger Offset: 5400
              </div>
            </div>

            <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl shadow-sm flex flex-col justify-between">
              <div>
                <div className="text-[10px] uppercase font-extrabold text-emerald-700">Avg Remaining Useful Life</div>
                <div className="text-xl font-black text-emerald-900 mt-1">
                  {(() => {
                    if (activeAssets.length === 0) return "0 Yrs";
                    const totalRem = activeAssets.reduce((sum, a) => sum + calculateUsefulLife(a).remainingLife, 0);
                    return `${(totalRem / activeAssets.length).toFixed(1)} Years`;
                  })()}
                </div>
              </div>
              <div className="text-[9.5px] text-emerald-600 font-medium mt-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-emerald-500" /> Auto-calculated across fleet
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border shadow-sm flex flex-col justify-between">
              <div>
                <div className="text-[10px] uppercase font-extrabold text-slate-400">Maintenance Health</div>
                <div className="text-lg font-black text-slate-800 mt-1 flex items-center gap-1.5">
                  <span>{activeAssets.length} Active</span>
                  {assetsDueForMaintenance.length > 0 ? (
                    <span className="text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded-full font-bold">
                      {assetsDueForMaintenance.length} Attention
                    </span>
                  ) : (
                    <span className="text-[10px] bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded-full font-bold">
                      All Healthy
                    </span>
                  )}
                </div>
              </div>
              <div className="text-[9.5px] text-slate-500 font-medium mt-1">
                Spend: {currencySymbol} {totalMaintenanceCost.toLocaleString()}
              </div>
            </div>
          </div>

          {/* IAS 41 / IAS 16 / IAS 2 Multi-Tier Asset Classification Summary */}
          <div className="bg-white rounded-xl border p-6 shadow-sm space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b pb-3">
              <div>
                <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-2">
                  <Layers className="w-4 h-4 text-indigo-600" />
                  Asset Classification Architecture & General Ledger Integration
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  IAS 41 Biological Assets (Non-Current & Current), IAS 2 Post-Harvest Inventory, and IAS 16 Property, Plant & Equipment.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                  Non-Current: {currencySymbol} {nonCurrentTotalVal.toLocaleString(undefined, { minimumFractionDigits: 2 })} ({nonCurrentAssets.length})
                </span>
                <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Current: {currencySymbol} {currentTotalVal.toLocaleString(undefined, { minimumFractionDigits: 2 })} ({currentAssets.length})
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {tierStats.map(tier => (
                <div key={tier.id} className="p-4 rounded-xl border bg-slate-50/70 hover:bg-white hover:shadow-sm transition-all space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border inline-block ${tier.badgeColor}`}>
                        {tier.id === "non_current_biological" ? "Tier 1: Non-Current Biological" :
                         tier.id === "current_biological" ? "Tier 2: Current Biological" :
                         tier.id === "post_harvest_inventory" ? "Tier 3: Post-Harvest Inv." : "IAS 16 PPE Capital"}
                      </span>
                      <h4 className="font-bold text-slate-900 text-xs mt-1.5 leading-snug">{tier.label}</h4>
                    </div>
                    <span className="text-xs font-mono font-bold bg-white text-slate-700 px-2 py-1 rounded border shadow-xs">
                      {tier.count}
                    </span>
                  </div>

                  <p className="text-[10.5px] text-slate-500 leading-relaxed min-h-[32px]">
                    {tier.description}
                  </p>

                  <div className="pt-2 border-t border-slate-200/80">
                    <div className="text-base font-black text-slate-900">
                      {currencySymbol} {tier.currentVal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </div>
                    <div className="flex items-center justify-between text-[9.5px] text-slate-400 mt-1">
                      <span>GL: {tier.glAccounts}</span>
                      <span className="font-bold font-mono text-slate-600">{tier.pct}% fleet</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Asset Distribution by Category */}
          <div className="bg-white rounded-xl border p-6 shadow-sm">
            <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-2 mb-4">
              <PieChart className="w-4 h-4 text-emerald-500" /> Asset Portfolio Distribution by Category
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {categoryStats.map(cat => (
                <div key={cat.category} className="p-4 rounded-xl border bg-slate-50/60 hover:bg-slate-50 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800 text-xs">{cat.category}</span>
                    <span className="text-[10px] font-mono font-bold bg-slate-200 text-slate-700 px-2 py-0.5 rounded">
                      {cat.count} {cat.count === 1 ? "asset" : "assets"}
                    </span>
                  </div>
                  
                  <div className="mt-3">
                    <div className="text-lg font-black text-slate-900">
                      {currencySymbol} {cat.currentVal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Orig: {currencySymbol} {cat.origVal.toLocaleString()}
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="mt-3">
                    <div className="flex justify-between text-[10px] text-slate-500 mb-1">
                      <span>Share of Portfolio</span>
                      <span className="font-mono font-bold">{cat.pctOfTotal}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-emerald-500 rounded-full" 
                        style={{ width: `${Math.min(100, cat.pctOfTotal)}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recharts Visual Breakdown of Asset Book Values by Category */}
          <div className="bg-white rounded-xl border p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-2">
                  <BarChart2 className="w-4 h-4 text-emerald-500" /> Recharts Financial Breakdown of Asset Book Values by Category
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Visual oversight comparing historical acquisition costs against calculated depreciated book values across portfolios.
                </p>
              </div>
              <div className="flex items-center gap-3 text-xs font-semibold">
                <span className="flex items-center gap-1 text-slate-600">
                  <span className="w-3 h-3 rounded bg-slate-300 inline-block" /> Acquisition Cost
                </span>
                <span className="flex items-center gap-1 text-emerald-700">
                  <span className="w-3 h-3 rounded bg-emerald-500 inline-block" /> Net Book Value
                </span>
              </div>
            </div>

            <div className="h-64 w-full pt-2">
              <ReResponsiveContainer width="100%" height="100%">
                <ReBarChart data={categoryStats} margin={{ top: 10, right: 20, left: 10, bottom: 20 }}>
                  <ReXAxis dataKey="category" tick={{ fontSize: 11, fill: "#64748b" }} />
                  <ReYAxis tick={{ fontSize: 10, fill: "#64748b" }} tickFormatter={(val) => `${currencySymbol} ${val.toLocaleString()}`} />
                  <ReTooltip
                    formatter={(value: any) => [`${currencySymbol} ${Number(value).toLocaleString(undefined, { minimumFractionDigits: 2 })}`, "Value"]}
                    contentStyle={{ backgroundColor: "#0f172a", color: "#f8fafc", borderRadius: "8px", fontSize: "12px", border: "none" }}
                  />
                  <ReBar dataKey="origVal" name="Acquisition Cost" fill="#cbd5e1" radius={[4, 4, 0, 0]} />
                  <ReBar dataKey="currentVal" name="Net Book Value" fill="#10b981" radius={[4, 4, 0, 0]} />
                </ReBarChart>
              </ReResponsiveContainer>
            </div>
          </div>

          {/* Assets Due for Maintenance Widget */}
          <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b bg-amber-50/50 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-amber-900 text-xs uppercase tracking-wider flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600" /> Assets Requiring Service & Upcoming Maintenance
                </h3>
                <p className="text-[11px] text-amber-700">Assets marked in Fair/Poor condition or with scheduled maintenance due soon.</p>
              </div>
              <span className="bg-amber-200 text-amber-900 font-bold text-xs px-2.5 py-1 rounded-full">
                {assetsDueForMaintenance.length} Items
              </span>
            </div>

            <div className="p-4 overflow-x-auto">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                  <tr>
                    <th className="p-3">Asset</th>
                    <th className="p-3">Category</th>
                    <th className="p-3">Location</th>
                    <th className="p-3">Condition</th>
                    <th className="p-3 font-mono text-right">Book Value</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y font-semibold text-slate-800">
                  {assetsDueForMaintenance.map(asset => {
                    const { currentDepValue } = calculateDepreciatedValue(asset);
                    return (
                      <tr key={asset.id} className="hover:bg-slate-50">
                        <td className="p-3">
                          <span className="block text-slate-900 font-bold">{asset.name}</span>
                          <span className="text-[10px] font-mono text-slate-400">S/N: {asset.serial || "N/A"}</span>
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px]">{asset.category}</span>
                        </td>
                        <td className="p-3 text-slate-500">{asset.location}</td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            asset.condition === "Poor" 
                              ? "bg-rose-100 text-rose-800" 
                              : "bg-amber-100 text-amber-800"
                          }`}>
                            {asset.condition}
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono text-slate-900 font-bold">
                          {currencySymbol} {currentDepValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="p-3 text-right">
                          {!isReadonly && (
                            <button
                              onClick={() => handleOpenMaintenanceModal(asset)}
                              className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-[11px] py-1 px-3 rounded-lg shadow-sm flex items-center gap-1 ml-auto cursor-pointer"
                            >
                              <Wrench className="w-3 h-3" /> Log Service
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                  {assetsDueForMaintenance.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400 italic">
                        All assets are operating smoothly in Excellent or Good condition. No immediate service interventions required.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 2. ASSET REGISTER & LIVE LEDGER VIEW */}
      {activeTab === "assets" && (
        <div className="space-y-6 animate-fade-in">
          {/* Add Asset Form */}
          {showAddForm && (
            <form onSubmit={handleSub} className="bg-slate-50 border p-6 rounded-xl space-y-4 animate-fade-in">
              <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1">
                <Wrench className="w-4 h-4 text-emerald-500" /> Book Fixed Asset Acquisition
              </h4>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Asset Name Description</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="e.g. Dairy Breeding Cow / Saro Solar Pump"
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-indigo-700 uppercase flex items-center gap-1">
                    <Layers className="w-3 h-3" /> Asset Classification (IAS 41 / 16 / 2)
                  </label>
                  <select
                    value={assetClassification}
                    onChange={e => {
                      const val = e.target.value as BiologicalAssetTier;
                      setAssetClassification(val);
                      // Auto-preset appropriate GL Account
                      if (val === "non_current_biological") {
                        setGlAccountCode("1460");
                        setCategory("Livestock");
                      } else if (val === "current_biological") {
                        setGlAccountCode("1400");
                        setCategory("Livestock");
                      } else if (val === "post_harvest_inventory") {
                        setGlAccountCode("1350");
                        setCategory("Other");
                      } else {
                        setGlAccountCode("1540");
                        setCategory("Equipment");
                      }
                    }}
                    className="w-full text-xs p-2 border-2 border-indigo-200 bg-indigo-50/50 rounded-lg focus:outline-none font-bold text-slate-800"
                  >
                    <option value="non_current_biological">Non-Current Biological (Breeding / Mature / Draft)</option>
                    <option value="current_biological">Current Biological (Growing / Meat / Broilers / Fish)</option>
                    <option value="post_harvest_inventory">Post-Harvest / Slaughter Inventory (Milk / Carcasses)</option>
                    <option value="ppe_asset">Property, Plant & Equipment (PPE - IAS 16)</option>
                  </select>
                </div>
                
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Category type</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as any)}
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none"
                  >
                    <option value="Livestock">Livestock (Cattle, Pigs, Goats, Sheep)</option>
                    <option value="Poultry">Poultry (Layers, Broilers, Flocks)</option>
                    <option value="Aquaculture">Aquaculture (Fish ponds, Biomass)</option>
                    <option value="Crops">Standing Crops / Field Plantings</option>
                    <option value="Orchard">Orchards / Fruit Trees / Vines</option>
                    <option value="Land">Land / Plots</option>
                    <option value="Buildings">Buildings & Stands</option>
                    <option value="Equipment">Equipment / Pumps / Engines</option>
                    <option value="Vehicles">Vehicles / Motorbikes / Trucks</option>
                    <option value="Water Infrastructure">Water Infrastructure / Tanks</option>
                    <option value="Other">Other Fixed Asset</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-indigo-700 uppercase flex items-center gap-1">
                    <BookOpen className="w-3 h-3" /> Posting GL Account (COA)
                  </label>
                  <select
                    value={glAccountCode}
                    onChange={e => setGlAccountCode(e.target.value)}
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none font-mono font-bold text-slate-800"
                  >
                    <optgroup label="Non-Current Biological Assets (IAS 41)">
                      <option value="1450">1450 - Dairy Cattle Herds (Mature)</option>
                      <option value="1460">1460 - Breeding Livestock (Bulls, Sows, Rams)</option>
                      <option value="1470">1470 - Laying Hen Flocks</option>
                      <option value="1480">1480 - Working Draft Animals (Oxen)</option>
                      <option value="1490">1490 - Fruit Trees & Perennial Orchards</option>
                    </optgroup>
                    <optgroup label="Current Biological Assets (IAS 41)">
                      <option value="1400">1400 - Growing Livestock (Beef cattle, Feeders)</option>
                      <option value="1410">1410 - Swine Growing Stock (Weaners/Growers)</option>
                      <option value="1420">1420 - Poultry Broiler Flocks</option>
                      <option value="1430">1430 - Aquaculture Fish Stocks</option>
                      <option value="1440">1440 - Standing Crops in Fields</option>
                    </optgroup>
                    <optgroup label="Post-Harvest Inventory (IAS 2)">
                      <option value="1350">1350 - Raw Agricultural Inventory</option>
                      <option value="1360">1360 - Post-Slaughter Meat Inventory</option>
                      <option value="1370">1370 - Extracted Milk Inventory</option>
                    </optgroup>
                    <optgroup label="Property, Plant & Equipment (IAS 16)">
                      <option value="1510">1510 - Land & Permanent Improvements</option>
                      <option value="1520">1520 - Farm Buildings & Infrastructure</option>
                      <option value="1530">1530 - Plant & Machinery</option>
                      <option value="1540">1540 - Farm Equipment & Irrigation</option>
                      <option value="1550">1550 - Vehicles & Transport Fleet</option>
                    </optgroup>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Supplier (Registered dropdown)</label>
                  <select
                    value={supplierId}
                    required
                    onChange={e => setSupplierId(e.target.value)}
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none focus:border-emerald-500"
                  >
                    <option value="">-- Choose registered supplier --</option>
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>{s.name} ({s.category || "Agro Dealer / Supplier"})</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Purchase Price ({currencySymbol})</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={purchasePrice}
                    onChange={e => setPurchasePrice(e.target.value)}
                    placeholder="15000"
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Official Serial number</label>
                  <input
                    type="text"
                    value={serial}
                    onChange={e => setSerial(e.target.value)}
                    placeholder="e.g. S-BH-0023B"
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Purchase execution Date</label>
                  <input
                    type="date"
                    required
                    value={purchaseDate}
                    onChange={e => setPurchaseDate(e.target.value)}
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Storage / Operating Location</label>
                  <input
                    type="text"
                    required
                    value={location}
                    onChange={e => setLocation(e.target.value)}
                    placeholder="e.g. Susu Farm Main Well"
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Annual Depreciation rate (%)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    max="100"
                    value={depreciationRate}
                    onChange={e => setDepreciationRate(e.target.value)}
                    placeholder="10"
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Expected Useful Life (Years)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    max="100"
                    value={expectedUsefulLife}
                    onChange={e => setExpectedUsefulLife(e.target.value)}
                    placeholder="5"
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Initial Condition state</label>
                  <select
                    value={condition}
                    onChange={e => setCondition(e.target.value as any)}
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none"
                  >
                    <option value="Excellent">Excellent (Brand New / Static)</option>
                    <option value="Good">Good (Working fine)</option>
                    <option value="Fair">Fair (Needs slight maintenance)</option>
                    <option value="Poor">Poor (Degraded / Urgent attention)</option>
                  </select>
                </div>

                <div className="space-y-1 col-span-1 md:col-span-3">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Supplementary acquisition Notes</label>
                  <input
                    type="text"
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    placeholder="Included pipes, base plate, stand design info"
                    className="w-full text-xs p-2 border bg-white rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-500 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 px-6 rounded-lg shadow transition-all active:scale-[0.98]"
                >
                  Confirm Capitalization
                </button>
              </div>
            </form>
          )}

          {/* Search and Filters Bar */}
          <div className="bg-white p-4 rounded-xl border shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="Search asset name, serial, location..."
                className="w-full text-xs pl-9 pr-3 py-2 border rounded-lg focus:outline-none focus:border-emerald-500"
              />
            </div>
            
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5">
                <Filter className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-[10px] uppercase font-bold text-slate-500">Category:</span>
                <select
                  value={categoryFilter}
                  onChange={e => setCategoryFilter(e.target.value)}
                  className="text-xs p-1.5 border rounded-lg bg-white"
                >
                  <option value="All">All Categories</option>
                  {categoriesList.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-[10px] uppercase font-bold text-slate-500">Condition:</span>
                <select
                  value={conditionFilter}
                  onChange={e => setConditionFilter(e.target.value)}
                  className="text-xs p-1.5 border rounded-lg bg-white"
                >
                  <option value="All">All Conditions</option>
                  <option value="Excellent">Excellent</option>
                  <option value="Good">Good</option>
                  <option value="Fair">Fair</option>
                  <option value="Poor">Poor</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section Selector: All Assets, Non-Current Assets, Current Assets */}
          <div className="flex flex-wrap items-center gap-2 border-b pb-2">
            <button
              onClick={() => setAssetScopeFilter("ALL")}
              className={`text-xs font-bold px-3.5 py-2 rounded-lg flex items-center gap-2 transition-all cursor-pointer ${
                assetScopeFilter === "ALL"
                  ? "bg-slate-900 text-white shadow-sm"
                  : "bg-white text-slate-600 hover:bg-slate-100 border"
              }`}
            >
              <Package className="w-3.5 h-3.5" /> All Assets ({activeAssets.length})
            </button>
            <button
              onClick={() => setAssetScopeFilter("NON_CURRENT")}
              className={`text-xs font-bold px-3.5 py-2 rounded-lg flex items-center gap-2 transition-all cursor-pointer ${
                assetScopeFilter === "NON_CURRENT"
                  ? "bg-indigo-600 text-white shadow-sm"
                  : "bg-white text-indigo-700 hover:bg-indigo-50 border border-indigo-200"
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" /> Non-Current Assets ({nonCurrentAssets.length})
              <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${assetScopeFilter === "NON_CURRENT" ? "bg-indigo-700 text-white" : "bg-indigo-100 text-indigo-800"}`}>
                {currencySymbol} {nonCurrentTotalVal.toLocaleString(undefined, { minimumFractionDigits: 0 })}
              </span>
            </button>
            <button
              onClick={() => setAssetScopeFilter("CURRENT")}
              className={`text-xs font-bold px-3.5 py-2 rounded-lg flex items-center gap-2 transition-all cursor-pointer ${
                assetScopeFilter === "CURRENT"
                  ? "bg-emerald-600 text-white shadow-sm"
                  : "bg-white text-emerald-700 hover:bg-emerald-50 border border-emerald-200"
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" /> Current Assets & Biological Stock ({currentAssets.length})
              <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${assetScopeFilter === "CURRENT" ? "bg-emerald-700 text-white" : "bg-emerald-100 text-emerald-800"}`}>
                {currencySymbol} {currentTotalVal.toLocaleString(undefined, { minimumFractionDigits: 0 })}
              </span>
            </button>
          </div>

          {/* Asset List Table */}
          <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b bg-slate-50 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
                  {assetScopeFilter === "ALL" ? "Active Capitalized Asset Register" :
                   assetScopeFilter === "NON_CURRENT" ? "Non-Current Asset Register (Breeding Stock & Fixed Capital)" :
                   "Current Asset Register (Growing Stock & Short-Term Assets)"}
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Reconciled against General Ledger chart of accounts with automated IAS 41 biological transformation and linear depreciation.
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-slate-500">
                Showing {filteredActiveAssets.length} of {activeAssets.length} Active Assets
              </span>
            </div>

            <div className="p-4 overflow-x-auto">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                  <tr>
                    <th className="p-3">Asset Detail & Serial</th>
                    <th className="p-3">Classification & GL</th>
                    <th className="p-3">Category</th>
                    <th className="p-3">Acquisition Date</th>
                    <th className="p-3">Supplier</th>
                    <th className="p-3">Condition</th>
                    <th className="p-3 font-mono text-right">Book Cost</th>
                    <th className="p-3 font-mono text-center">Valuation / Dep.</th>
                    <th className="p-3 text-center">Useful Life</th>
                    <th className="p-3 font-mono text-right text-emerald-600">Current Value</th>
                    <th className="p-3 text-center">Maintenance</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y font-semibold text-slate-800">
                  {filteredActiveAssets.map(asset => {
                    const { currentDepValue, pctLost } = calculateDepreciatedValue(asset);
                    const linkedSupplier = suppliers.find(s => s.id === asset.supplierId);
                    const maintCount = (asset.maintenanceLogs || []).length;
                    const isBiological = asset.assetClassification === "non_current_biological" ||
                                         asset.assetClassification === "current_biological" ||
                                         ["Livestock", "Poultry", "Aquaculture", "Crops"].includes(asset.category);

                    return (
                      <tr key={asset.id} className="hover:bg-slate-50/70">
                        <td className="p-3">
                          <span className="block text-slate-900 font-bold">{asset.name}</span>
                          {asset.serial && (
                            <span className="text-[9.5px] font-mono text-indigo-500 block font-normal">S/N: {asset.serial}</span>
                          )}
                          <span className="text-[9.5px] text-slate-400 font-normal flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-slate-400" /> {asset.location}
                          </span>
                        </td>
                        <td className="p-3">
                          <div className="space-y-1">
                            {asset.assetClassification === "non_current_biological" ? (
                              <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded text-[9.5px] font-bold block max-w-max">
                                Non-Current Bio (IAS 41)
                              </span>
                            ) : asset.assetClassification === "current_biological" ? (
                              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded text-[9.5px] font-bold block max-w-max">
                                Current Bio (IAS 41)
                              </span>
                            ) : asset.assetClassification === "post_harvest_inventory" ? (
                              <span className="px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded text-[9.5px] font-bold block max-w-max">
                                Post-Harvest Inv (IAS 2)
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 bg-slate-100 text-slate-700 border border-slate-200 rounded text-[9.5px] font-bold block max-w-max">
                                PPE Fixed Capital (IAS 16)
                              </span>
                            )}
                            <span className="font-mono text-[9px] text-slate-500 block">
                              GL: {asset.glAccountCode || (isBiological ? "1400/1460" : "1540")}
                            </span>
                          </div>
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px]">{asset.category}</span>
                        </td>
                        <td className="p-3 font-mono text-[11px]">{asset.purchaseDate}</td>
                        <td className="p-3 text-slate-600 font-normal">
                          {linkedSupplier ? (
                            <div>
                              <span className="block font-bold text-slate-700">{linkedSupplier.name}</span>
                              <span className="text-[9px] text-slate-400 font-mono block">{linkedSupplier.id}</span>
                            </div>
                          ) : (
                            <span className="text-slate-400 italic">Unknown supplier</span>
                          )}
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            asset.condition === "Excellent" 
                              ? "bg-emerald-50 text-emerald-700 border border-emerald-200" 
                              : asset.condition === "Good" 
                              ? "bg-blue-50 text-blue-700 border border-blue-100" 
                              : asset.condition === "Fair" 
                              ? "bg-amber-50 text-amber-700 border border-amber-200" 
                              : "bg-rose-50 text-rose-700 border border-rose-200 animate-pulse"
                          }`}>
                            {asset.condition}
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-slate-700">
                          {currencySymbol} {asset.purchasePrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="p-3 text-center font-mono text-slate-500 text-[11px]">
                          {isBiological ? (
                            <div>
                              <span className="text-emerald-700 font-bold text-[10px] block">Fair Value</span>
                              <span className="text-[9px] text-slate-400 font-normal">Bio-Transformation</span>
                            </div>
                          ) : (
                            <div>
                              <span>{asset.depreciationRate}% p.a.</span>
                              {pctLost > 0 && (
                                <span className="block text-[9.5px] text-rose-500 font-bold font-sans">-{pctLost}% value</span>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          {isBiological ? (
                            <span className="text-[10px] text-slate-500 font-mono italic">Biological cycle</span>
                          ) : (
                            (() => {
                              const { expectedLife, remainingLife } = calculateUsefulLife(asset);
                              return (
                                <div className="inline-block text-center">
                                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    remainingLife <= 0 
                                      ? "bg-rose-100 text-rose-800"
                                      : remainingLife <= 2 
                                      ? "bg-amber-100 text-amber-800"
                                      : "bg-emerald-100 text-emerald-800"
                                  }`}>
                                    {remainingLife} yrs rem
                                  </span>
                                  <span className="block text-[9px] text-slate-400 font-mono mt-0.5">Exp: {expectedLife} yrs</span>
                                </div>
                              );
                            })()
                          )}
                        </td>
                        <td className="p-3 text-right font-mono font-black text-slate-950">
                          {currencySymbol} {currentDepValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          {!isBiological && pctLost >= 100 && (
                            <span className="block text-[9px] uppercase font-sans text-rose-600 bg-rose-50 px-1 py-0.2 rounded font-black max-w-max ml-auto">Fully Depreciated</span>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          <button
                            onClick={() => handleOpenMaintenanceModal(asset)}
                            className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-2 py-1 rounded-md flex items-center gap-1 mx-auto cursor-pointer"
                          >
                            <Wrench className="w-3 h-3 text-amber-500" /> {maintCount} Logs
                          </button>
                        </td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1">
                            {!isReadonly && (
                              <>
                                <button
                                  type="button"
                                  title="Disposal Workflow"
                                  onClick={() => handleOpenDisposalModal(asset)}
                                  className="text-slate-500 hover:text-rose-600 p-1 bg-slate-100 hover:bg-rose-50 rounded cursor-pointer"
                                >
                                  <Archive className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  title="Delete Asset"
                                  onClick={async () => {
                                    const ok = await confirm({
                                      title: "Delete Asset Capitalization",
                                      message: `Are you sure you want to delete fixed asset record: "${asset.name}" (${asset.category})?`,
                                      confirmText: "Delete",
                                      cancelText: "Cancel",
                                      type: "danger"
                                    });
                                    if (ok) {
                                      onDeleteAsset(asset.id);
                                    }
                                  }}
                                  className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {filteredActiveAssets.length === 0 && (
                    <tr>
                      <td colSpan={12} className="p-6 text-center text-slate-400 italic">
                        No active assets matched your filter criteria.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. MAINTENANCE & SERVICE MANAGER VIEW */}
      {activeTab === "maintenance" && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white p-6 rounded-xl border shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider flex items-center gap-2">
                <Wrench className="w-4 h-4 text-amber-500" /> Maintenance Service Logs & History
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Comprehensive maintenance history across all equipment, machinery, facilities and biological holding units.
              </p>
            </div>
            {!isReadonly && activeAssets.length > 0 && (
              <button
                onClick={() => handleOpenMaintenanceModal(activeAssets[0])}
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs py-2 px-4 rounded-lg flex items-center gap-1.5 shadow active:scale-[0.98] transition-all cursor-pointer self-start md:self-auto"
              >
                <Plus className="w-4 h-4" /> Log New Service Entry
              </button>
            )}
          </div>

          {/* Maintenance Scope Tabs */}
          <div className="flex flex-wrap items-center gap-2 border-b pb-2">
            <button
              onClick={() => setMaintenanceScopeFilter("ALL")}
              className={`text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                maintenanceScopeFilter === "ALL"
                  ? "bg-slate-900 text-white shadow-sm"
                  : "bg-white text-slate-600 hover:bg-slate-100 border"
              }`}
            >
              All Service Logs ({allMaintenanceLogs.length})
            </button>
            <button
              onClick={() => setMaintenanceScopeFilter("NON_CURRENT")}
              className={`text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                maintenanceScopeFilter === "NON_CURRENT"
                  ? "bg-indigo-600 text-white shadow-sm"
                  : "bg-white text-indigo-700 hover:bg-indigo-50 border border-indigo-200"
              }`}
            >
              Non-Current Assets & Infrastructure
            </button>
            <button
              onClick={() => setMaintenanceScopeFilter("CURRENT")}
              className={`text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                maintenanceScopeFilter === "CURRENT"
                  ? "bg-emerald-600 text-white shadow-sm"
                  : "bg-white text-emerald-700 hover:bg-emerald-50 border border-emerald-200"
              }`}
            >
              Current Assets & Bio Enclosures
            </button>
          </div>

          <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
            <div className="p-4 overflow-x-auto">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                  <tr>
                    <th className="p-3">Ref ID</th>
                    <th className="p-3">Asset Name</th>
                    <th className="p-3">Service Date</th>
                    <th className="p-3">Service Type</th>
                    <th className="p-3">Description</th>
                    <th className="p-3 font-mono text-right">Service Cost</th>
                    <th className="p-3">Technician / Vendor</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Next Due Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y font-semibold text-slate-800">
                  {filteredMaintenanceLogs.map(maint => (
                    <tr key={maint.id} className="hover:bg-slate-50">
                      <td className="p-3 font-mono text-[10px] text-slate-400">{maint.id}</td>
                      <td className="p-3 font-bold text-slate-900">{maint.assetName}</td>
                      <td className="p-3 font-mono text-[11px]">{maint.date}</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded text-[10px] font-bold">
                          {maint.type}
                        </span>
                      </td>
                      <td className="p-3 text-slate-600">{maint.description}</td>
                      <td className="p-3 text-right font-mono font-bold text-slate-900">
                        {currencySymbol} {(maint.cost || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-3 text-slate-700">{maint.performedBy}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          maint.status === "Completed" 
                            ? "bg-emerald-100 text-emerald-800" 
                            : maint.status === "Scheduled" 
                            ? "bg-blue-100 text-blue-800" 
                            : "bg-rose-100 text-rose-800"
                        }`}>
                          {maint.status}
                        </span>
                      </td>
                      <td className="p-3 font-mono text-[11px] text-slate-500">
                        {maint.nextDueDate || "—"}
                      </td>
                    </tr>
                  ))}
                  {filteredMaintenanceLogs.length === 0 && (
                    <tr>
                      <td colSpan={9} className="p-6 text-center text-slate-400 italic">
                        No service logs recorded under this view.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 4. DISPOSALS ARCHIVE VIEW */}
      {activeTab === "disposals" && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white p-6 rounded-xl border shadow-sm">
            <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider flex items-center gap-2">
              <Archive className="w-4 h-4 text-rose-500" /> Disposed & Scrapped Fixed Asset Ledger
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Historical ledger of assets sold, scrapped, or derecognized from company books with automatic double-entry journal entries.
            </p>
          </div>

          <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
            <div className="p-4 overflow-x-auto">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                  <tr>
                    <th className="p-3">Disposal Date</th>
                    <th className="p-3">Asset Name</th>
                    <th className="p-3">Disposal Type</th>
                    <th className="p-3 font-mono text-right">Original Cost</th>
                    <th className="p-3 font-mono text-right">Book Value at Disposal</th>
                    <th className="p-3 font-mono text-right">Sale Proceeds</th>
                    <th className="p-3 font-mono text-right">Realized Gain / (Loss)</th>
                    <th className="p-3">Reason / Buyer</th>
                    <th className="p-3 font-mono text-center">Journal Ref</th>
                  </tr>
                </thead>
                <tbody className="divide-y font-semibold text-slate-800">
                  {disposedAssets.map(asset => {
                    const disp = asset.disposalRecord;
                    const isGain = (disp?.gainLoss || 0) >= 0;

                    return (
                      <tr key={asset.id} className="hover:bg-slate-50">
                        <td className="p-3 font-mono text-[11px]">{disp?.disposalDate || asset.purchaseDate}</td>
                        <td className="p-3 font-bold text-slate-900">{asset.name}</td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            disp?.disposalType === "Sale" 
                              ? "bg-emerald-100 text-emerald-800" 
                              : "bg-rose-100 text-rose-800"
                          }`}>
                            {disp?.disposalType || "Disposed"}
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono text-slate-600">
                          {currencySymbol} {asset.purchasePrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="p-3 text-right font-mono text-slate-600">
                          {currencySymbol} {(disp?.bookValueAtDisposal || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-slate-900">
                          {currencySymbol} {(disp?.proceeds || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className={`p-3 text-right font-mono font-bold ${isGain ? "text-emerald-600" : "text-rose-600"}`}>
                          {isGain ? "+" : ""}{currencySymbol} {(disp?.gainLoss || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="p-3 text-slate-600">{disp?.purchaserOrReason || "N/A"}</td>
                        <td className="p-3 text-center font-mono text-[10px] text-slate-400">
                          {disp?.journalEntryRef || "JRN-AUTO"}
                        </td>
                      </tr>
                    );
                  })}
                  {disposedAssets.length === 0 && (
                    <tr>
                      <td colSpan={9} className="p-6 text-center text-slate-400 italic">
                        No asset disposals or derecognitions logged yet. Disposing an asset through the register automatically posts journal entries here.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: ADD MAINTENANCE LOG */}
      {showMaintenanceModal && selectedAssetForMaint && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <Wrench className="w-4 h-4 text-amber-500" /> Log Maintenance & Service for "{selectedAssetForMaint.name}"
              </h3>
              <button
                onClick={() => setShowMaintenanceModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMaintenanceLog} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Service Date</label>
                  <input
                    type="date"
                    required
                    value={maintDate}
                    onChange={e => setMaintDate(e.target.value)}
                    className="w-full text-xs p-2 border rounded-lg"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Service Type</label>
                  <select
                    value={maintType}
                    onChange={e => setMaintType(e.target.value as any)}
                    className="w-full text-xs p-2 border rounded-lg bg-white"
                  >
                    <option value="Routine Service">Routine Service</option>
                    <option value="Repair">Repair</option>
                    <option value="Overhaul">Overhaul</option>
                    <option value="Inspection">Inspection</option>
                    <option value="Emergency Fix">Emergency Fix</option>
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="text-[10px] font-bold uppercase text-slate-500">Work Description</label>
                  <input
                    type="text"
                    required
                    value={maintDesc}
                    onChange={e => setMaintDesc(e.target.value)}
                    placeholder="e.g. Engine oil change, filter replacement & belt tightening"
                    className="w-full text-xs p-2 border rounded-lg"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Cost ({currencySymbol})</label>
                  <input
                    type="number"
                    min="0"
                    value={maintCost}
                    onChange={e => setMaintCost(e.target.value)}
                    placeholder="1200"
                    className="w-full text-xs p-2 border rounded-lg"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Technician / Provider</label>
                  <input
                    type="text"
                    required
                    value={maintTech}
                    onChange={e => setMaintTech(e.target.value)}
                    placeholder="e.g. Saro Agro Tech Services"
                    className="w-full text-xs p-2 border rounded-lg"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Status</label>
                  <select
                    value={maintStatus}
                    onChange={e => setMaintStatus(e.target.value as any)}
                    className="w-full text-xs p-2 border rounded-lg bg-white"
                  >
                    <option value="Completed">Completed</option>
                    <option value="Scheduled">Scheduled</option>
                    <option value="Overdue">Overdue</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Next Service Due Date</label>
                  <input
                    type="date"
                    value={maintNextDue}
                    onChange={e => setMaintNextDue(e.target.value)}
                    className="w-full text-xs p-2 border rounded-lg"
                  />
                </div>

                <div className="col-span-2 bg-slate-50 p-3 rounded-lg border">
                  <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={maintPostCoa}
                      onChange={e => setMaintPostCoa(e.target.checked)}
                      className="rounded text-emerald-600 focus:ring-0"
                    />
                    Automatically post cost to Accounting Ledger (Account 5200 - Maintenance Exp)
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setShowMaintenanceModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs py-2 px-5 rounded-lg shadow cursor-pointer"
                >
                  Save Maintenance Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: DEDICATED DISPOSAL WORKFLOW */}
      {showDisposalModal && selectedAssetForDisposal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <Archive className="w-4 h-4 text-rose-500" /> Dedicated Asset Disposal Workflow
              </h3>
              <button
                onClick={() => setShowDisposalModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-50 p-3.5 rounded-xl border space-y-1 text-xs">
              <div className="font-bold text-slate-800">{selectedAssetForDisposal.name}</div>
              <div className="text-[11px] text-slate-500">
                Original Cost: {currencySymbol} {selectedAssetForDisposal.purchasePrice.toLocaleString()} | Category: {selectedAssetForDisposal.category}
              </div>
              <div className="text-[11px] font-mono font-bold text-indigo-700">
                Current Net Book Value: {currencySymbol} {calculateDepreciatedValue(selectedAssetForDisposal).currentDepValue.toLocaleString()}
              </div>
            </div>

            <form onSubmit={handleConfirmDisposal} className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Disposal Date</label>
                  <input
                    type="date"
                    required
                    value={disposalDate}
                    onChange={e => setDisposalDate(e.target.value)}
                    className="w-full p-2 border rounded-lg"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Disposal Mode</label>
                  <select
                    value={disposalType}
                    onChange={e => setDisposalType(e.target.value as any)}
                    className="w-full p-2 border rounded-lg bg-white"
                  >
                    <option value="Sale">Sale to Third Party</option>
                    <option value="Scrapped">Scrapped / Written Off</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Sale Proceeds / Salvage Value ({currencySymbol})</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={disposalProceeds}
                    onChange={e => setDisposalProceeds(e.target.value)}
                    className="w-full p-2 border rounded-lg font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Purchaser / Reason Notes</label>
                  <input
                    type="text"
                    value={purchaserOrReason}
                    onChange={e => setPurchaserOrReason(e.target.value)}
                    placeholder="e.g. Sold to Agro Used Equipment Ltd"
                    className="w-full p-2 border rounded-lg"
                  />
                </div>
              </div>

              {/* Real-time Accounting Journal Preview */}
              <div className="bg-slate-900 text-slate-100 p-4 rounded-xl space-y-2 text-[11px] font-mono">
                <div className="font-bold text-emerald-400 uppercase text-[10px]">Automated Accounting Journal Preview</div>
                <div className="flex justify-between border-b border-slate-800 pb-1">
                  <span>Dr Bank / Cash (Account 1010):</span>
                  <span>+{currencySymbol} {Number(disposalProceeds || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-1 text-rose-300">
                  <span>Cr Fixed Assets (Account 1530):</span>
                  <span>-{currencySymbol} {selectedAssetForDisposal.purchasePrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                {(() => {
                  const proceeds = Number(disposalProceeds) || 0;
                  const currentDepVal = calculateDepreciatedValue(selectedAssetForDisposal).currentDepValue;
                  const gainLoss = proceeds - currentDepVal;
                  return (
                    <div className={`flex justify-between font-bold ${gainLoss >= 0 ? "text-emerald-300" : "text-amber-300"}`}>
                      <span>{gainLoss >= 0 ? "Cr Gain on Asset Disposal (Account 4500):" : "Dr Loss on Asset Disposal (Account 5500):"}</span>
                      <span>{gainLoss >= 0 ? "+" : ""}{currencySymbol} {gainLoss.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                    </div>
                  );
                })()}
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setShowDisposalModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs py-2 px-5 rounded-lg shadow cursor-pointer"
                >
                  Confirm & Post Disposal Journal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: BULK DEPRECIATION CALCULATOR */}
      {showDepreciationModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 shadow-xl border space-y-4 max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <Calculator className="w-5 h-5 text-indigo-600" /> Bulk Straight-Line Depreciation Calculator
              </h3>
              <button
                onClick={() => setShowDepreciationModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center justify-between bg-indigo-50 p-4 rounded-xl border border-indigo-100">
              <div>
                <label className="text-[10px] uppercase font-bold text-indigo-900 block">Evaluation Target Date</label>
                <input
                  type="date"
                  value={depEvaluationDate}
                  onChange={e => setDepEvaluationDate(e.target.value)}
                  className="text-xs font-bold p-1.5 border rounded-lg bg-white text-indigo-900 mt-1"
                />
              </div>
              <div className="text-right">
                <span className="text-[10px] uppercase font-extrabold text-indigo-700 block">Total Depreciation Recognition</span>
                <span className="text-xl font-black text-indigo-950 font-mono">
                  {currencySymbol} {totalBulkDepreciationRecognized.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>

            <div className="overflow-y-auto flex-1 border rounded-xl">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50 sticky top-0">
                  <tr>
                    <th className="p-3">Asset</th>
                    <th className="p-3 font-mono">Purchase Price</th>
                    <th className="p-3 font-mono">Current Book Val</th>
                    <th className="p-3 font-mono text-center">Rate</th>
                    <th className="p-3 font-mono text-right text-indigo-600">Calculated Val</th>
                    <th className="p-3 font-mono text-right text-rose-500">Period Dep. Exp</th>
                  </tr>
                </thead>
                <tbody className="divide-y font-semibold text-slate-800">
                  {bulkDepreciations.map(item => {
                    const depExpense = Math.max(0, item.oldValue - item.newDepreciatedValue);
                    return (
                      <tr key={item.asset.id} className="hover:bg-slate-50">
                        <td className="p-3 font-bold text-slate-900">{item.asset.name}</td>
                        <td className="p-3 font-mono text-slate-600">
                          {currencySymbol} {item.asset.purchasePrice.toLocaleString()}
                        </td>
                        <td className="p-3 font-mono text-slate-600">
                          {currencySymbol} {item.oldValue.toLocaleString()}
                        </td>
                        <td className="p-3 text-center font-mono text-slate-500">
                          {item.asset.depreciationRate}%
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-indigo-900">
                          {currencySymbol} {item.newDepreciatedValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-rose-600">
                          -{currencySymbol} {depExpense.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between pt-3 border-t">
              <span className="text-xs text-slate-500 font-medium">
                Executes linear straight-line schedule & posts entry to Account 5400 Depreciation Exp.
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowDepreciationModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleApplyBulkDepreciation}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-2 px-6 rounded-lg shadow cursor-pointer"
                >
                  Apply & Commit Bulk Depreciation
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* BULK CSV IMPORT MODAL */}
      {showCsvImportModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 space-y-5 shadow-2xl border max-h-[90vh] flex flex-col animate-fade-in">
            <div className="flex items-center justify-between border-b pb-4">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
                <div>
                  <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider">Bulk CSV Asset Import</h3>
                  <p className="text-xs text-slate-500">Import multiple capitalized assets at once using CSV formatting.</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowCsvImportModal(false);
                  setRawCsvInput("");
                  setParsedCsvItems([]);
                  setCsvParseError(null);
                }}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Instruction & Sample format */}
            <div className="bg-slate-50 border p-4 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700">Supported Columns & CSV Format</span>
                <button
                  type="button"
                  onClick={() => {
                    const sampleCsv = `Name,Category,Purchase Date,Purchase Price,Expected Useful Life,Serial,Location,Condition,Depreciation Rate,Notes\nSolar Borehole Pump,Equipment,2025-03-10,18500,10,S-BH-991,Main Well,Excellent,10,200W solar setup\nFarm Utility Tractor,Vehicles,2024-06-20,45000,15,TR-8821,Depot A,Good,6.67,4WD Diesel tractor\nChemical Storage Shed,Buildings,2023-11-05,32000,25,SH-001,Susu Station,Good,4,Concrete security shed`;
                    setRawCsvInput(sampleCsv);
                    handleParseCsv(sampleCsv);
                  }}
                  className="text-[10px] bg-emerald-100 hover:bg-emerald-200 text-emerald-800 font-bold px-2.5 py-1 rounded transition-all cursor-pointer"
                >
                  Load Sample Data
                </button>
              </div>
              <p className="text-[11px] text-slate-600 font-mono bg-white p-2 border rounded text-xs overflow-x-auto">
                Name,Category,Purchase Date,Purchase Price,Expected Useful Life,Serial,Location,Condition,Depreciation Rate,Notes
              </p>
            </div>

            {/* File Upload or Raw Input */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700">Paste CSV Text or Upload File</label>
                <label className="text-xs text-emerald-600 hover:text-emerald-700 font-bold cursor-pointer flex items-center gap-1">
                  <Upload className="w-3.5 h-3.5" /> Choose .csv file
                  <input
                    type="file"
                    accept=".csv,.txt"
                    className="hidden"
                    onChange={e => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = (evt) => {
                          const text = evt.target?.result as string;
                          if (text) {
                            setRawCsvInput(text);
                            handleParseCsv(text);
                          }
                        };
                        reader.readAsText(file);
                      }
                    }}
                  />
                </label>
              </div>
              <textarea
                rows={4}
                value={rawCsvInput}
                onChange={e => {
                  setRawCsvInput(e.target.value);
                  handleParseCsv(e.target.value);
                }}
                placeholder="Paste your CSV content here..."
                className="w-full text-xs font-mono p-3 border rounded-xl bg-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            {csvParseError && (
              <div className="bg-rose-50 border border-rose-200 text-rose-700 p-3 rounded-xl text-xs flex items-center gap-2 font-medium">
                <AlertTriangle className="w-4 h-4 shrink-0" /> {csvParseError}
              </div>
            )}

            {/* Parsed Preview Table */}
            {parsedCsvItems.length > 0 && (
              <div className="flex-1 overflow-y-auto border rounded-xl">
                <div className="px-4 py-2.5 bg-slate-50 border-b flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">
                    Previewing {parsedCsvItems.length} Assets ready to import
                  </span>
                  <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                    Validation Passed
                  </span>
                </div>
                <table className="w-full text-left text-xs bg-white text-slate-800">
                  <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50 sticky top-0">
                    <tr>
                      <th className="p-2.5">Asset Name</th>
                      <th className="p-2.5">Category</th>
                      <th className="p-2.5 font-mono">Price</th>
                      <th className="p-2.5 font-mono">Date</th>
                      <th className="p-2.5 text-center">Expected Useful Life</th>
                      <th className="p-2.5">Location</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y font-medium text-slate-700">
                    {parsedCsvItems.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="p-2.5 font-bold text-slate-900">{item.name}</td>
                        <td className="p-2.5">
                          <span className="px-2 py-0.5 bg-slate-100 rounded text-[10px]">{item.category}</span>
                        </td>
                        <td className="p-2.5 font-mono">
                          {currencySymbol} {item.purchasePrice.toLocaleString()}
                        </td>
                        <td className="p-2.5 font-mono">{item.purchaseDate}</td>
                        <td className="p-2.5 text-center font-bold text-emerald-700 font-mono">
                          {item.expectedUsefulLife} Years
                        </td>
                        <td className="p-2.5 text-slate-500">{item.location}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className="flex items-center justify-between pt-3 border-t">
              <span className="text-xs text-slate-500 font-medium">
                {parsedCsvItems.length > 0 ? `Ready to register ${parsedCsvItems.length} new assets.` : "Paste CSV data above to preview import."}
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowCsvImportModal(false);
                    setRawCsvInput("");
                    setParsedCsvItems([]);
                    setCsvParseError(null);
                  }}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={parsedCsvItems.length === 0}
                  onClick={handleExecuteBulkImport}
                  className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs py-2 px-6 rounded-lg shadow cursor-pointer transition-all"
                >
                  Confirm & Import {parsedCsvItems.length} Assets
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

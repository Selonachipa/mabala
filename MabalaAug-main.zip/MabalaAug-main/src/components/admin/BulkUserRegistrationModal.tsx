import React, { useState, useRef } from "react";
import { 
  X, 
  Upload, 
  Download, 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertTriangle, 
  Users, 
  Building2, 
  Tractor, 
  Store, 
  Sparkles,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Eye
} from "lucide-react";
import { BulkUserRegistrationRow, ResellerPartner } from "../../types";
import { resellerService } from "../../services/resellerService";
import { safeLocalStorage as localStorage } from "../../utils/safeStorage";
import { safeFormatError } from "../../utils/errorUtils";

interface BulkUserRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  adminProfile?: any;
}

export default function BulkUserRegistrationModal({
  isOpen,
  onClose,
  onSuccess,
  adminProfile
}: BulkUserRegistrationModalProps) {
  if (!isOpen) return null;

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [parsedRows, setParsedRows] = useState<BulkUserRegistrationRow[]>([]);
  const [resellers, setResellers] = useState<ResellerPartner[]>([]);
  const [resellerCodeMap, setResellerCodeMap] = useState<Record<string, ResellerPartner>>({});
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progress, setProgress] = useState<{ current: number; total: number } | null>(null);
  const [importSummary, setImportSummary] = useState<{
    successful: number;
    failed: number;
    errors: string[];
  } | null>(null);
  const [parseError, setParseError] = useState<string | null>(null);

  // Load resellers map for instant validation
  React.useEffect(() => {
    resellerService.getAllResellers().then(list => {
      setResellers(list);
      const map: Record<string, ResellerPartner> = {};
      list.forEach(r => {
        map[r.resellerCode.toUpperCase().trim()] = r;
      });
      setResellerCodeMap(map);
    });
  }, []);

  const downloadSampleCSV = () => {
    const headers = "Full Name,Email,Phone Number,Role,Farm or Business Name,Reseller Code,Province,District,Default Password\n";
    const sampleRows = [
      "Chimwemwe Banda,banda.farm@example.com,+260977112233,Farmer,Banda Mixed Farm,PARTNER-01,Lusaka,Chongwe,Mabala2026!",
      "Mutale Agro Supplies,mutale.agro@example.com,+260966334455,Agro Dealer,Mutale Seed & Fertilizer,PARTNER-02,Central,Mkushi,Mabala2026!",
      "ZamSeed Agro Traders,contact@zamseed-traders.example.com,+260955667788,Institutional Supplier,ZamSeed Distribution Hub,,Copperbelt,Ndola,Mabala2026!",
      "Chisenga Agrovet,chisenga.vet@example.com,+260978990011,Agro Dealer,Chisenga Agro Inputs,,Southern,Choma,Mabala2026!",
      "Kondwani Phiri,kondwani.agronomy@example.com,+260971223344,Agronomist,AgroCare Consult,,Eastern,Chipata,Mabala2026!",
      "Lusaka Grain Buyers Ltd,procurement@lusakagrain.example.com,+260977445566,Offtaker,Lusaka Grain Silos,,Lusaka,Lusaka,Mabala2026!"
    ].join("\n");

    const blob = new Blob([headers + sampleRows], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "mabala_bulk_user_registration_template.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const parseCSVText = (text: string) => {
    setParseError(null);
    const lines = text.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length < 2) {
      setParseError("The CSV file must contain a header row and at least one user record row.");
      setParsedRows([]);
      return;
    }

    // Parse header row
    const rawHeaders = lines[0].split(",").map(h => h.replace(/^["']|["']$/g, "").trim().toLowerCase());
    
    // Column indices mapping
    const colName = rawHeaders.findIndex(h => h.includes("name") || h.includes("full"));
    const colEmail = rawHeaders.findIndex(h => h.includes("email") || h.includes("mail"));
    const colPhone = rawHeaders.findIndex(h => h.includes("phone") || h.includes("mobile") || h.includes("contact"));
    const colRole = rawHeaders.findIndex(h => h.includes("role") || h.includes("type"));
    const colBusiness = rawHeaders.findIndex(h => h.includes("farm") || h.includes("business") || h.includes("tenant") || h.includes("company"));
    const colReseller = rawHeaders.findIndex(h => h.includes("reseller") || h.includes("partner") || h.includes("referral") || h.includes("code"));
    const colProvince = rawHeaders.findIndex(h => h.includes("province"));
    const colDistrict = rawHeaders.findIndex(h => h.includes("district"));
    const colPass = rawHeaders.findIndex(h => h.includes("pass") || h.includes("pwd"));

    if (colName === -1 || colEmail === -1) {
      setParseError("Could not detect required 'Full Name' and 'Email' columns in the CSV header.");
      return;
    }

    const rows: BulkUserRegistrationRow[] = [];

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      // Basic CSV tokenization respecting quotes
      const tokens: string[] = [];
      let inQuotes = false;
      let curToken = "";
      for (let c = 0; c < line.length; c++) {
        const ch = line[c];
        if (ch === '"') {
          inQuotes = !inQuotes;
        } else if (ch === ',' && !inQuotes) {
          tokens.push(curToken.trim().replace(/^["']|["']$/g, ""));
          curToken = "";
        } else {
          curToken += ch;
        }
      }
      tokens.push(curToken.trim().replace(/^["']|["']$/g, ""));

      const fullName = tokens[colName] || "";
      const email = tokens[colEmail] || "";
      const phone = colPhone >= 0 ? tokens[colPhone] || "" : "";
      let roleRaw = colRole >= 0 ? tokens[colRole] || "Farmer" : "Farmer";
      const farmOrBusinessName = colBusiness >= 0 ? tokens[colBusiness] || "" : "";
      const resellerCode = colReseller >= 0 ? tokens[colReseller] || "" : "";
      const province = colProvince >= 0 ? tokens[colProvince] || "Lusaka" : "Lusaka";
      const district = colDistrict >= 0 ? tokens[colDistrict] || "Lusaka" : "Lusaka";
      const defaultPassword = colPass >= 0 ? tokens[colPass] || "Mabala2026!" : "Mabala2026!";

      // Normalize Role
      let role: BulkUserRegistrationRow["role"] = "Farmer";
      const lowerRole = roleRaw.toLowerCase();
      if (lowerRole.includes("agro") || lowerRole.includes("dealer") || lowerRole.includes("vendor")) {
        role = "Agro Dealer";
      } else if (lowerRole.includes("supplier") || lowerRole.includes("institution")) {
        role = "Institutional Supplier";
      } else if (lowerRole.includes("offtaker") || lowerRole.includes("buyer")) {
        role = "Offtaker";
      } else if (lowerRole.includes("agronomist") || lowerRole.includes("vet")) {
        role = "Agronomist";
      } else if (lowerRole.includes("partner") || lowerRole.includes("reseller")) {
        role = "Platform Partner";
      } else {
        role = "Farmer";
      }

      // Validation check
      let isValid = true;
      let validationError = "";

      if (!fullName.trim()) {
        isValid = false;
        validationError = "Missing Full Name";
      } else if (!email.trim() || !email.includes("@")) {
        isValid = false;
        validationError = "Invalid or Missing Email";
      } else if (!phone.trim()) {
        isValid = false;
        validationError = "Missing Phone Number";
      }

      rows.push({
        fullName: fullName.trim(),
        email: email.trim().toLowerCase(),
        phone: phone.trim(),
        role,
        farmOrBusinessName: farmOrBusinessName.trim() || `${fullName.trim()}'s Node`,
        resellerCode: resellerCode.trim().toUpperCase() || undefined,
        province: province.trim(),
        district: district.trim(),
        defaultPassword: defaultPassword.trim(),
        isValid,
        validationError: validationError || undefined
      });
    }

    setParsedRows(rows);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) parseCSVText(text);
      };
      reader.readAsText(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) parseCSVText(text);
      };
      reader.readAsText(file);
    }
  };

  const handleExecuteBulkRegistration = async () => {
    const validRows = parsedRows.filter(r => r.isValid);
    if (validRows.length === 0) {
      setParseError("No valid rows found to register. Please check the validation column.");
      return;
    }

    setIsProcessing(true);
    setProgress({ current: 0, total: validRows.length });

    let successCount = 0;
    let failCount = 0;
    const errors: string[] = [];

    // Load existing platform users
    let existingUsers: any[] = [];
    try {
      const stored = localStorage.getItem("all_platform_users");
      if (stored) existingUsers = JSON.parse(stored);
    } catch (e) {}

    for (let i = 0; i < validRows.length; i++) {
      const row = validRows[i];
      setProgress({ current: i + 1, total: validRows.length });

      try {
        // Small delay for UI smoothness
        await new Promise(r => setTimeout(r, 60));

        const matchedReseller = row.resellerCode ? resellerCodeMap[row.resellerCode.toUpperCase()] : null;

        const uid = `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const newUser = {
          uid,
          email: row.email,
          displayName: row.fullName,
          fullName: row.fullName,
          phone: row.phone,
          role: row.role,
          userType: row.role,
          farmOrBusinessName: row.farmOrBusinessName,
          province: row.province,
          district: row.district,
          resellerCode: row.resellerCode || (matchedReseller ? matchedReseller.resellerCode : undefined),
          resellerId: matchedReseller ? matchedReseller.id : undefined,
          resellerName: matchedReseller ? matchedReseller.name : undefined,
          isVerified: true,
          status: "active",
          createdAt: new Date().toISOString(),
          defaultPassword: row.defaultPassword || "Mabala2026!",
          forcePasswordChange: true
        };

        // Check duplicate email
        const existingIdx = existingUsers.findIndex(u => u.email?.toLowerCase() === row.email.toLowerCase());
        if (existingIdx >= 0) {
          existingUsers[existingIdx] = { ...existingUsers[existingIdx], ...newUser };
        } else {
          existingUsers.unshift(newUser);
        }

        // If reseller code was matched, update reseller's totalOnboardedFarmers
        if (matchedReseller) {
          const updated = {
            ...matchedReseller,
            totalOnboardedFarmers: (matchedReseller.totalOnboardedFarmers || 0) + 1
          };
          await resellerService.saveReseller(updated);
        }

        successCount++;
      } catch (err: any) {
        console.error("[BulkUserRegistration] Error importing row:", row.email, err);
        failCount++;
        errors.push(`${row.fullName} (${row.email}): ${err.message || "Failed"}`);
      }
    }

    localStorage.setItem("all_platform_users", JSON.stringify(existingUsers));

    setIsProcessing(false);
    setImportSummary({
      successful: successCount,
      failed: failCount,
      errors
    });

    if (onSuccess) onSuccess();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-[99999] flex items-center justify-center p-2 sm:p-4 overflow-y-auto font-sans">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col text-slate-900 animate-fade-in">
        
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 flex flex-wrap justify-between items-center gap-4 bg-slate-50/70 rounded-t-3xl">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-sm">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-indigo-100 text-indigo-900 px-2 py-0.5 rounded">
                  Super Admin Provisioning
                </span>
                <span className="text-[10px] font-bold text-slate-400 font-mono">CSV Engine</span>
              </div>
              <h3 className="text-lg font-black text-slate-900 mt-0.5">Bulk User Registration</h3>
              <p className="text-xs text-slate-500 font-medium">
                Register Farmers, Agro Dealers, and Institutional Suppliers in bulk from a single spreadsheet.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={downloadSampleCSV}
              className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 shadow-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-600" />
              <span>Download Sample CSV Template</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-xl transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {importSummary ? (
            /* Post-Import Result Summary */
            <div className="space-y-5 text-center py-4 animate-fade-in">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h4 className="text-2xl font-black text-slate-900">Bulk Registration Completed!</h4>
                <p className="text-xs text-slate-500 font-medium mt-1">
                  All accounts have been provisioned in the platform directory with temporary passwords.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-w-lg mx-auto">
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl">
                  <span className="text-[10px] uppercase font-bold text-emerald-800 block">Successfully Added</span>
                  <span className="text-2xl font-black text-emerald-950 font-mono">{importSummary.successful}</span>
                </div>
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl">
                  <span className="text-[10px] uppercase font-bold text-rose-800 block">Failed / Skipped</span>
                  <span className="text-2xl font-black text-rose-950 font-mono">{importSummary.failed}</span>
                </div>
                <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-2xl col-span-2 sm:col-span-1">
                  <span className="text-[10px] uppercase font-bold text-indigo-800 block">Total Processed</span>
                  <span className="text-2xl font-black text-indigo-950 font-mono">
                    {importSummary.successful + importSummary.failed}
                  </span>
                </div>
              </div>

              {importSummary.errors.length > 0 && (
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-left max-w-lg mx-auto text-xs space-y-1">
                  <span className="font-bold text-rose-900 block">Errors:</span>
                  {importSummary.errors.map((err, i) => (
                    <div key={i} className="text-rose-700 font-mono text-[11px]">&bull; {safeFormatError(err)}</div>
                  ))}
                </div>
              )}

              <div className="pt-4 flex justify-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setImportSummary(null);
                    setParsedRows([]);
                    setSelectedFile(null);
                  }}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
                >
                  Upload Another File
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-sm cursor-pointer"
                >
                  Close & View User Directory
                </button>
              </div>
            </div>
          ) : (
            /* Upload & Preview Interface */
            <div className="space-y-6">
              
              {/* Drag and Drop Zone */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragActive(true);
                }}
                onDragLeave={() => setDragActive(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-3xl p-8 text-center cursor-pointer transition flex flex-col items-center justify-center gap-3 ${
                  dragActive
                    ? "border-emerald-500 bg-emerald-50/60"
                    : "border-slate-300 hover:border-indigo-400 bg-slate-50/50 hover:bg-slate-50"
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,text/csv"
                  onChange={handleFileChange}
                  className="hidden"
                />

                <div className="p-4 bg-white rounded-2xl shadow-xs border border-slate-200 text-indigo-600">
                  <Upload className="w-8 h-8" />
                </div>

                <div>
                  <h4 className="text-sm font-black text-slate-900">
                    {selectedFile ? selectedFile.name : "Click to browse or drop your CSV file here"}
                  </h4>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    Supports .CSV files containing Farmers, Agro Dealers, Suppliers, and Reseller Codes.
                  </p>
                </div>

                {selectedFile && (
                  <span className="px-3 py-1 bg-emerald-100 text-emerald-900 font-mono text-[11px] font-bold rounded-full">
                    {parsedRows.length} Rows Loaded
                  </span>
                )}
              </div>

              {parseError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{safeFormatError(parseError)}</span>
                </div>
              )}

              {/* Parsed Rows Grid Preview */}
              {parsedRows.length > 0 && (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider flex items-center gap-1.5">
                      <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Pre-Import Validation Grid ({parsedRows.length} Records)</span>
                    </h4>
                    <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                      {parsedRows.filter(r => r.isValid).length} Valid / {parsedRows.filter(r => !r.isValid).length} Invalid
                    </span>
                  </div>

                  <div className="overflow-x-auto border border-slate-200 rounded-2xl shadow-xs max-h-72">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-100 text-slate-700 font-black uppercase text-[10px] sticky top-0 border-b border-slate-200">
                        <tr>
                          <th className="p-3">Status</th>
                          <th className="p-3">Full Name</th>
                          <th className="p-3">Email</th>
                          <th className="p-3">Phone</th>
                          <th className="p-3">Role</th>
                          <th className="p-3">Farm / Business</th>
                          <th className="p-3">Reseller Affiliation</th>
                          <th className="p-3">Territory</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium">
                        {parsedRows.map((row, idx) => {
                          const matchedReseller = row.resellerCode ? resellerCodeMap[row.resellerCode.toUpperCase()] : null;

                          return (
                            <tr key={idx} className={row.isValid ? "hover:bg-slate-50" : "bg-rose-50/50"}>
                              <td className="p-3">
                                {row.isValid ? (
                                  <span className="flex items-center gap-1 text-[10px] font-black uppercase text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full w-max">
                                    <CheckCircle2 className="w-3 h-3" /> Ready
                                  </span>
                                ) : (
                                  <span className="flex items-center gap-1 text-[10px] font-black uppercase text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full w-max" title={row.validationError}>
                                    <AlertTriangle className="w-3 h-3" /> {row.validationError}
                                  </span>
                                )}
                              </td>

                              <td className="p-3 font-bold text-slate-900 whitespace-nowrap">
                                {row.fullName}
                              </td>

                              <td className="p-3 font-mono text-[11px] text-slate-600">
                                {row.email}
                              </td>

                              <td className="p-3 font-mono text-[11px] text-slate-600">
                                {row.phone}
                              </td>

                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                                  row.role === "Farmer"
                                    ? "bg-emerald-100 text-emerald-900"
                                    : row.role === "Agro Dealer"
                                    ? "bg-amber-100 text-amber-900"
                                    : row.role === "Institutional Supplier"
                                    ? "bg-indigo-100 text-indigo-900"
                                    : "bg-slate-100 text-slate-800"
                                }`}>
                                  {row.role}
                                </span>
                              </td>

                              <td className="p-3 text-slate-700">
                                {row.farmOrBusinessName}
                              </td>

                              <td className="p-3">
                                {row.resellerCode ? (
                                  matchedReseller ? (
                                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 rounded font-mono text-[10px] font-bold" title={matchedReseller.name}>
                                      ✓ {matchedReseller.resellerCode}
                                    </span>
                                  ) : (
                                    <span className="px-2 py-0.5 bg-amber-100 text-amber-900 rounded font-mono text-[10px]" title="Reseller code will be recorded">
                                      {row.resellerCode}
                                    </span>
                                  )
                                ) : (
                                  <span className="text-slate-400 font-mono text-[10px]">Direct</span>
                                )}
                              </td>

                              <td className="p-3 text-slate-600 text-[11px]">
                                {row.district}, {row.province}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Progress Indicator */}
              {isProcessing && progress && (
                <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-2xl space-y-2">
                  <div className="flex justify-between text-xs font-bold text-indigo-900">
                    <span>Provisioning User Accounts...</span>
                    <span>{progress.current} of {progress.total}</span>
                  </div>
                  <div className="w-full h-2 bg-indigo-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-600 transition-all duration-150"
                      style={{ width: `${(progress.current / progress.total) * 100}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                  disabled={isProcessing}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleExecuteBulkRegistration}
                  disabled={isProcessing || parsedRows.filter(r => r.isValid).length === 0}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl shadow-sm transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Registering Users ({progress?.current}/{progress?.total})...</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4 text-emerald-300" />
                      <span>Register All {parsedRows.filter(r => r.isValid).length} Valid Users</span>
                    </>
                  )}
                </button>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
}

import React, { useState } from "react";
import { AlertTriangle, Trash2, RefreshCw, CheckCircle2, ShieldAlert, X } from "lucide-react";
import { purgeTenantWorkspace } from "../../services/tenantBackupPurgeService";

interface DirectWorkspacePurgeProps {
  tenantId: string;
  tenantName: string;
  actingUid?: string;
  actingEmail?: string;
  onPurgeSuccess?: (result: { tenantId: string; documentsDeleted: number }) => void;
  className?: string;
  buttonLabel?: string;
  variant?: "button" | "card";
}

export const DirectWorkspacePurge: React.FC<DirectWorkspacePurgeProps> = ({
  tenantId,
  tenantName,
  actingUid,
  actingEmail,
  onPurgeSuccess,
  className = "",
  buttonLabel = "Initialize Empty Database",
  variant = "button"
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [confirmationInput, setConfirmationInput] = useState("");
  const [isPurging, setIsPurging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successInfo, setSuccessInfo] = useState<{ documentsDeleted: number } | null>(null);

  const cleanTenantName = (tenantName || "Farm Node").trim();
  const isConfirmed = confirmationInput.trim().toLowerCase() === cleanTenantName.toLowerCase();

  const handleOpenModal = () => {
    setConfirmationInput("");
    setError(null);
    setSuccessInfo(null);
    setIsOpen(true);
  };

  const handleCloseModal = () => {
    if (isPurging) return;
    setIsOpen(false);
    setConfirmationInput("");
    setError(null);
  };

  const handleExecutePurge = async () => {
    if (!isConfirmed || isPurging) return;
    setIsPurging(true);
    setError(null);

    try {
      const result = await purgeTenantWorkspace(
        tenantId,
        confirmationInput.trim(),
        actingUid,
        actingEmail
      );

      setSuccessInfo({ documentsDeleted: result.documentsDeleted });
      if (onPurgeSuccess) {
        onPurgeSuccess({
          tenantId,
          documentsDeleted: result.documentsDeleted
        });
      }
    } catch (err: any) {
      setError(err.message || "Failed to purge tenant workspace.");
    } finally {
      setIsPurging(false);
    }
  };

  return (
    <>
      {variant === "card" ? (
        <div className={`p-5 rounded-xl border-2 border-red-200 bg-red-50/50 space-y-4 ${className}`}>
          <div className="flex items-start gap-3">
            <div className="p-2.5 bg-red-100 text-red-700 rounded-lg shrink-0">
              <Trash2 className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-red-950 flex items-center gap-2">
                <span>Tenant-Scoped Workspace Purge</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 bg-red-200 text-red-800 rounded font-bold">
                  Strictly Isolated
                </span>
              </h4>
              <p className="text-xs text-red-800 leading-relaxed">
                Initialize an empty workspace for <strong className="font-bold underline">{cleanTenantName}</strong>. 
                Deletes all crop cycles, transactions, invoices, and livestock for this tenant only. 
                Reseeds the Chart of Accounts with default categories. Other tenants on Mabala are completely isolated and untouched.
              </p>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="button"
              onClick={handleOpenModal}
              className="py-2.5 px-4 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-2 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>{buttonLabel}</span>
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={handleOpenModal}
          className={`py-2 px-3.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-2 cursor-pointer ${className}`}
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>{buttonLabel}</span>
        </button>
      )}

      {/* Confirmation Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="p-5 bg-red-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 bg-white/20 rounded-lg">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider">Purge Workspace</h3>
                  <p className="text-[11px] text-red-100">Target Tenant: {cleanTenantName}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleCloseModal}
                disabled={isPurging}
                className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 space-y-5">
              {successInfo ? (
                <div className="text-center py-4 space-y-3">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <h4 className="text-base font-black text-slate-800">Purge Complete</h4>
                  <p className="text-xs text-slate-600 max-w-md mx-auto">
                    Successfully wiped <strong className="font-bold text-slate-900">{successInfo.documentsDeleted} records</strong> for <strong className="text-slate-900">{cleanTenantName}</strong>. 
                    Default Chart of Accounts has been reseeded.
                  </p>
                  <div className="pt-3">
                    <button
                      type="button"
                      onClick={handleCloseModal}
                      className="py-2.5 px-6 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer"
                    >
                      Close
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {/* Warning Banner */}
                  <div className="p-4 bg-red-50 border border-red-200 rounded-xl space-y-2 text-red-900">
                    <div className="flex items-center gap-2 font-bold text-xs text-red-800">
                      <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
                      <span>Destructive Action: Tenant Scope Only</span>
                    </div>
                    <p className="text-[11.5px] leading-relaxed text-red-800">
                      This will permanently wipe all crop cycles, transactions, invoices, expenses, inventory, and ledger records for{" "}
                      <strong className="font-extrabold text-red-950 underline">{cleanTenantName}</strong>.
                      The Chart of Accounts will be reset to system defaults. Other tenants on Mabala will not be affected.
                    </p>
                  </div>

                  {error && (
                    <div className="p-3.5 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl text-xs font-medium">
                      {error}
                    </div>
                  )}

                  {/* Type-to-Confirm Input */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-700">
                      To confirm, type the tenant name:{" "}
                      <span className="font-mono px-1.5 py-0.5 bg-slate-100 rounded text-slate-900 border border-slate-300 font-bold select-all">
                        {cleanTenantName}
                      </span>
                    </label>
                    <input
                      type="text"
                      value={confirmationInput}
                      onChange={(e) => setConfirmationInput(e.target.value)}
                      placeholder={`Type "${cleanTenantName}" to confirm`}
                      disabled={isPurging}
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all font-mono"
                    />
                    <p className="text-[10.5px] text-slate-500">
                      The purge button will only enable when the exact name matches.
                    </p>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={handleCloseModal}
                      disabled={isPurging}
                      className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleExecutePurge}
                      disabled={!isConfirmed || isPurging}
                      className={`py-2.5 px-5 rounded-lg text-xs font-bold flex items-center gap-2 transition-all shadow-sm ${
                        isConfirmed && !isPurging
                          ? "bg-red-600 hover:bg-red-700 text-white cursor-pointer shadow-red-600/20"
                          : "bg-slate-200 text-slate-400 cursor-not-allowed"
                      }`}
                    >
                      {isPurging ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Purging Workspace...</span>
                        </>
                      ) : (
                        <>
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Permanently Purge Workspace</span>
                        </>
                      )}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default DirectWorkspacePurge;

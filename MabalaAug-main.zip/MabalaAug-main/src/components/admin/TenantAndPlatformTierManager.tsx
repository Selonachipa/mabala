import React, { useState, useEffect, useRef } from "react";
import {
  FolderArchive,
  Globe,
  Database,
  Download,
  RotateCcw,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  RefreshCw,
  CheckCircle2,
  FileText,
  Clock,
  HardDrive,
  Lock,
  Search,
  ChevronDown,
  UploadCloud,
  FileCheck,
  X
} from "lucide-react";
import {
  createTenantBackup,
  fetchTenantBackups,
  restoreTenantWorkspace,
  createPlatformBackup,
  fetchPlatformBackups,
  restorePlatformBackup,
  fetchAuditLogs,
  downloadJsonFile,
  TenantBackupRecord,
  PlatformBackupRecord,
  AuditLogItem
} from "../../services/tenantBackupPurgeService";
import DirectWorkspacePurge from "./DirectWorkspacePurge";

interface TenantAndPlatformTierManagerProps {
  isSuperAdmin: boolean;
  activeFarm: any;
  farms: any[];
  farmNodesList: any[];
  userProfile: any;
  currentUser: any;
  onClear: () => void;
  onRestore: (data: any) => void;
  className?: string;
}

export const TenantAndPlatformTierManager: React.FC<TenantAndPlatformTierManagerProps> = ({
  isSuperAdmin,
  activeFarm,
  farms,
  farmNodesList,
  userProfile,
  currentUser,
  onClear,
  onRestore,
  className = ""
}) => {
  // Tabs: "tenant" | "platform" (never merged into a single dropdown)
  const [activeTierTab, setActiveTierTab] = useState<"tenant" | "platform">("tenant");

  // Selected Tenant in Tenant Tab
  const [selectedTenantId, setSelectedTenantId] = useState<string>(
    activeFarm?.id || userProfile?.tenantId || "default_tenant"
  );
  const [selectedTenantName, setSelectedTenantName] = useState<string>(
    activeFarm?.name || "Farm Node"
  );

  // Tenant Backups State
  const [tenantBackups, setTenantBackups] = useState<TenantBackupRecord[]>([]);
  const [loadingTenantBackups, setLoadingTenantBackups] = useState(false);
  const [creatingBackup, setCreatingBackup] = useState(false);

  // Restore Modal State (Tenant)
  const [restoreModalOpen, setRestoreModalOpen] = useState(false);
  const [backupToRestore, setBackupToRestore] = useState<TenantBackupRecord | null>(null);
  const [uploadedPayload, setUploadedPayload] = useState<any | null>(null);
  const [restoreConfirmName, setRestoreConfirmName] = useState("");
  const [isRestoringTenant, setIsRestoringTenant] = useState(false);
  const [restoreError, setRestoreError] = useState<string | null>(null);
  const [restoreSuccess, setRestoreSuccess] = useState<string | null>(null);

  // Platform Tab States
  const [platformBackups, setPlatformBackups] = useState<PlatformBackupRecord[]>([]);
  const [loadingPlatformBackups, setLoadingPlatformBackups] = useState(false);
  const [creatingPlatformBackup, setCreatingPlatformBackup] = useState(false);

  // Platform Restore Maker-Checker Modal State
  const [platformRestoreModalOpen, setPlatformRestoreModalOpen] = useState(false);
  const [selectedPlatformBackup, setSelectedPlatformBackup] = useState<PlatformBackupRecord | null>(null);
  const [platformConfirmPhrase, setPlatformConfirmPhrase] = useState("");
  const [secondAdminEmail, setSecondAdminEmail] = useState("");
  const [secondAdminPassword, setSecondAdminPassword] = useState("");
  const [isRestoringPlatform, setIsRestoringPlatform] = useState(false);
  const [platformError, setPlatformError] = useState<string | null>(null);
  const [platformSuccess, setPlatformSuccess] = useState<string | null>(null);

  // Audit Logs State
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [loadingAuditLogs, setLoadingAuditLogs] = useState(false);

  // File Upload Ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Effective user credentials
  const actingUid = currentUser?.uid || userProfile?.uid || "system";
  const actingEmail = currentUser?.email || userProfile?.email || "admin@mabala.cloud";

  // Available tenants list for dropdown
  const allTenants = React.useMemo(() => {
    const map = new Map<string, { id: string; name: string }>();

    if (activeFarm?.id) {
      map.set(activeFarm.id, { id: activeFarm.id, name: activeFarm?.name || "Active Farm" });
    }

    if (Array.isArray(farms)) {
      farms.forEach((f) => {
        if (f?.id) map.set(f.id, { id: f.id, name: f.name || `Farm ${f.id.substring(0, 6)}` });
      });
    }

    if (Array.isArray(farmNodesList)) {
      farmNodesList.forEach((n) => {
        const id = n.tenantId || n.id;
        const name = n.name || n.tenantName || n.farmName || id;
        if (id && !map.has(id)) {
          map.set(id, { id, name });
        }
      });
    }

    return Array.from(map.values());
  }, [activeFarm, farms, farmNodesList]);

  // Sync selectedTenantName when selectedTenantId changes
  useEffect(() => {
    const match = allTenants.find((t) => t.id === selectedTenantId);
    if (match) {
      setSelectedTenantName(match.name);
    } else if (activeFarm?.id === selectedTenantId) {
      setSelectedTenantName(activeFarm?.name || "Farm Node");
    }
  }, [selectedTenantId, allTenants, activeFarm]);

  // Load tenant backups
  const loadTenantBackups = async (tenantId: string) => {
    if (!tenantId) return;
    setLoadingTenantBackups(true);
    try {
      const list = await fetchTenantBackups(tenantId, actingUid, actingEmail);
      setTenantBackups(list);
    } catch (err: any) {
      console.warn("Failed to load tenant backups:", err);
    } finally {
      setLoadingTenantBackups(false);
    }
  };

  // Load platform backups
  const loadPlatformBackups = async () => {
    if (!isSuperAdmin) return;
    setLoadingPlatformBackups(true);
    try {
      const list = await fetchPlatformBackups(actingUid, actingEmail);
      setPlatformBackups(list);
    } catch (err: any) {
      console.warn("Failed to load platform backups:", err);
    } finally {
      setLoadingPlatformBackups(false);
    }
  };

  // Load audit logs
  const loadAuditLogs = async (tenantId?: string) => {
    setLoadingAuditLogs(true);
    try {
      const logs = await fetchAuditLogs(activeTierTab === "tenant" ? tenantId : undefined);
      setAuditLogs(logs);
    } catch (err: any) {
      console.warn("Failed to load audit logs:", err);
    } finally {
      setLoadingAuditLogs(false);
    }
  };

  // Initial load
  useEffect(() => {
    if (activeTierTab === "tenant" && selectedTenantId) {
      loadTenantBackups(selectedTenantId);
      loadAuditLogs(selectedTenantId);
    } else if (activeTierTab === "platform" && isSuperAdmin) {
      loadPlatformBackups();
      loadAuditLogs();
    }
  }, [activeTierTab, selectedTenantId, isSuperAdmin]);

  // Handle "Backup Now" for Tenant
  const handleTenantBackupNow = async (outputMode: "local" | "remote") => {
    if (creatingBackup) return;
    setCreatingBackup(true);
    try {
      const result = await createTenantBackup(selectedTenantId, outputMode, actingUid, actingEmail);
      await loadTenantBackups(selectedTenantId);
      await loadAuditLogs(selectedTenantId);
    } catch (err: any) {
      alert("Tenant backup failed: " + (err.message || String(err)));
    } finally {
      setCreatingBackup(false);
    }
  };

  // Handle file upload for Tenant Restore with Cross-Tenant Verification
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);

        // Verify Cross-Tenant Isolation
        const meta = Array.isArray(parsed._meta) ? parsed._meta[0] : parsed._meta;
        if (meta && meta.tenantId && meta.tenantId !== selectedTenantId) {
          setRestoreError(
            `Cross-Tenant Block: This backup was exported from tenant '${meta.tenantName || meta.tenantId}' (${meta.tenantId}), but your selected workspace is '${selectedTenantName}' (${selectedTenantId}). Cross-tenant restoration is strictly forbidden.`
          );
          setUploadedPayload(null);
          setBackupToRestore(null);
          setRestoreModalOpen(true);
          return;
        }

        setUploadedPayload(parsed);
        setBackupToRestore({
          id: "local-file",
          fileName: file.name,
          tenantId: selectedTenantId,
          tenantName: selectedTenantName,
          backupDate: new Date().toISOString(),
          type: "local",
          recordsCount: countRecordsInPayload(parsed),
          payload: parsed
        });
        setRestoreConfirmName("");
        setRestoreError(null);
        setRestoreSuccess(null);
        setRestoreModalOpen(true);
      } catch (err: any) {
        alert("Failed to parse backup JSON: " + (err.message || String(err)));
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const countRecordsInPayload = (payload: any): number => {
    if (!payload) return 0;
    let count = 0;
    for (const key of Object.keys(payload)) {
      if (key !== "_meta" && Array.isArray(payload[key])) {
        count += payload[key].length;
      }
    }
    return count;
  };

  // Open Restore Modal for existing backup
  const handleOpenRestoreModal = (backup: TenantBackupRecord) => {
    setBackupToRestore(backup);
    setUploadedPayload(backup.payload || null);
    setRestoreConfirmName("");
    setRestoreError(null);
    setRestoreSuccess(null);
    setRestoreModalOpen(true);
  };

  // Execute Tenant Restore
  const handleExecuteTenantRestore = async () => {
    if (!backupToRestore || isRestoringTenant) return;
    if (restoreConfirmName.trim().toLowerCase() !== selectedTenantName.trim().toLowerCase()) {
      setRestoreError(`You must type "${selectedTenantName}" exactly to confirm.`);
      return;
    }

    setIsRestoringTenant(true);
    setRestoreError(null);
    try {
      const res = await restoreTenantWorkspace(selectedTenantId, restoreConfirmName.trim(), {
        backupId: backupToRestore.id !== "local-file" ? backupToRestore.id : undefined,
        payload: uploadedPayload || backupToRestore.payload,
        actingUid,
        actingEmail
      });

      // Update client state if restoring active farm
      if (uploadedPayload && selectedTenantId === activeFarm?.id) {
        onRestore(uploadedPayload);
      }

      setRestoreSuccess(
        `Successfully restored ${res.restoredCount} records into ${selectedTenantName}. Workspace is ready.`
      );
      await loadTenantBackups(selectedTenantId);
      await loadAuditLogs(selectedTenantId);
    } catch (err: any) {
      setRestoreError(err.message || "Failed to restore tenant workspace.");
    } finally {
      setIsRestoringTenant(false);
    }
  };

  // Execute Platform Backup
  const handlePlatformBackupNow = async () => {
    if (creatingPlatformBackup) return;
    setCreatingPlatformBackup(true);
    try {
      const res = await createPlatformBackup(actingUid, actingEmail);
      await loadPlatformBackups();
      await loadAuditLogs();
      alert(`Platform backup created: ${res.backupId} (${res.totalRecords} records across ${res.totalTenants} tenants).`);
    } catch (err: any) {
      alert("Platform backup failed: " + (err.message || String(err)));
    } finally {
      setCreatingPlatformBackup(false);
    }
  };

  // Open Platform Restore Modal
  const handleOpenPlatformRestoreModal = (backup: PlatformBackupRecord) => {
    setSelectedPlatformBackup(backup);
    setPlatformConfirmPhrase("");
    setSecondAdminEmail("");
    setSecondAdminPassword("");
    setPlatformError(null);
    setPlatformSuccess(null);
    setPlatformRestoreModalOpen(true);
  };

  // Execute Platform Restore with Maker-Checker
  const handleExecutePlatformRestore = async () => {
    if (isRestoringPlatform) return;
    if (platformConfirmPhrase.trim() !== "RESTORE ENTIRE PLATFORM") {
      setPlatformError('You must type "RESTORE ENTIRE PLATFORM" in all caps to confirm.');
      return;
    }

    if (!secondAdminEmail.trim() || secondAdminEmail.trim().toLowerCase() === actingEmail.trim().toLowerCase()) {
      setPlatformError("Maker-Checker requirement: Second Admin email must be different from your own.");
      return;
    }

    setIsRestoringPlatform(true);
    setPlatformError(null);
    try {
      const res = await restorePlatformBackup(
        platformConfirmPhrase.trim(),
        secondAdminEmail.trim(),
        secondAdminPassword.trim() || undefined,
        selectedPlatformBackup?.backupId,
        actingUid,
        actingEmail
      );

      setPlatformSuccess(res.message || "Platform restore triggered successfully.");
      await loadPlatformBackups();
      await loadAuditLogs();
    } catch (err: any) {
      setPlatformError(err.message || "Failed to restore platform backup.");
    } finally {
      setIsRestoringPlatform(false);
    }
  };

  return (
    <div className={`space-y-6 ${className}`} id="tenant-platform-tier-container">
      {/* 1. TOP TABS: TWO CLEARLY SEPARATED PANELS (Never merged into a single dropdown) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-2 sm:p-3 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            type="button"
            id="tab-tenant-tier"
            onClick={() => setActiveTierTab("tenant")}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
              activeTierTab === "tenant"
                ? "bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-600/20"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            <FolderArchive className="w-4 h-4" />
            <span>[ Tenant ] Workspace Tier</span>
          </button>

          {isSuperAdmin && (
            <button
              type="button"
              id="tab-platform-tier"
              onClick={() => setActiveTierTab("platform")}
              className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                activeTierTab === "platform"
                  ? "bg-slate-900 text-amber-400 shadow-sm ring-2 ring-slate-900/30"
                  : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              }`}
            >
              <Globe className="w-4 h-4 text-amber-400" />
              <span>[ Platform-Wide ] Tier</span>
              <span className="px-1.5 py-0.5 bg-amber-400/20 text-amber-300 text-[10px] rounded uppercase font-mono">
                Super Admin Only
              </span>
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500 font-medium px-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            {activeTierTab === "tenant"
              ? `Scoped to ${selectedTenantName} — Zero blast radius to other tenants`
              : "Full-platform tier — Gated behind Maker-Checker approval"}
          </span>
        </div>
      </div>

      {/* 2. TENANT TAB CONTENT */}
      {activeTierTab === "tenant" && (
        <div className="space-y-6 animate-in fade-in duration-150">
          {/* Tenant Selector & Actions Bar */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Active Tenant Scope:</span>
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-black rounded-md">
                    {selectedTenantName}
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  Tenant ID: <code className="font-mono text-slate-700 font-bold">{selectedTenantId}</code>
                </p>
              </div>

              {/* Tenant Switcher (For Super Admins) */}
              {isSuperAdmin && allTenants.length > 1 && (
                <div className="flex items-center gap-2">
                  <label className="text-xs font-bold text-slate-600 whitespace-nowrap">Select Tenant:</label>
                  <select
                    value={selectedTenantId}
                    onChange={(e) => setSelectedTenantId(e.target.value)}
                    className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none cursor-pointer"
                  >
                    {allTenants.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} ({t.id.substring(0, 8)}...)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Action Buttons: Backup Now & Upload File */}
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  accept=".json,.gz"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="py-2.5 px-3.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <UploadCloud className="w-3.5 h-3.5" />
                  <span>Import Backup File</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleTenantBackupNow("local")}
                  disabled={creatingBackup}
                  className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {creatingBackup ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Download className="w-3.5 h-3.5" />
                  )}
                  <span>Backup Now (.json)</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleTenantBackupNow("remote")}
                  disabled={creatingBackup}
                  className="py-2.5 px-3.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  title="Save snapshot to Firestore cloud partitioned under this tenant"
                >
                  <Database className="w-3.5 h-3.5" />
                  <span>Snapshot to Cloud</span>
                </button>
              </div>
            </div>
          </div>

          {/* Backups List for Selected Tenant */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-600" />
                  <span>Backups for &quot;{selectedTenantName}&quot;</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Standard naming convention: <code className="font-mono text-slate-700">TenantName_ISO-timestamp.json.gz</code>
                </p>
              </div>
              <button
                type="button"
                onClick={() => loadTenantBackups(selectedTenantId)}
                disabled={loadingTenantBackups}
                className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                title="Refresh backups list"
              >
                <RefreshCw className={`w-4 h-4 ${loadingTenantBackups ? "animate-spin" : ""}`} />
              </button>
            </div>

            {loadingTenantBackups ? (
              <div className="py-12 text-center text-xs text-slate-500">
                <RefreshCw className="w-5 h-5 animate-spin mx-auto text-emerald-600 mb-2" />
                <span>Loading tenant backups...</span>
              </div>
            ) : tenantBackups.length === 0 ? (
              <div className="py-10 text-center border-2 border-dashed border-slate-200 rounded-xl space-y-2">
                <FolderArchive className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-xs font-bold text-slate-700">No backups found for {selectedTenantName}</p>
                <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                  Click &quot;Backup Now&quot; above to create a downloadable backup or cloud snapshot for this tenant.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-100 rounded-xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Backup File Name</th>
                      <th className="py-3 px-4">Date & Time</th>
                      <th className="py-3 px-4">Type</th>
                      <th className="py-3 px-4">Records</th>
                      <th className="py-3 px-4">Size</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {tenantBackups.map((b) => (
                      <tr key={b.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-slate-900 flex items-center gap-2">
                          <FileText className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{b.fileName}</span>
                        </td>
                        <td className="py-3 px-4 text-slate-600">
                          {new Date(b.backupDate).toLocaleString()}
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              b.type === "remote"
                                ? "bg-purple-100 text-purple-700"
                                : b.type === "auto"
                                ? "bg-blue-100 text-blue-700"
                                : "bg-emerald-100 text-emerald-700"
                            }`}
                          >
                            {b.type}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-700 font-mono">
                          {b.recordsCount || 0}
                        </td>
                        <td className="py-3 px-4 text-slate-600 font-mono">
                          {b.payloadSizeKb ? `${b.payloadSizeKb} KB` : "—"}
                        </td>
                        <td className="py-3 px-4 text-right space-x-2">
                          {b.payload && (
                            <button
                              type="button"
                              onClick={() => downloadJsonFile(b.fileName, b.payload)}
                              className="py-1.5 px-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-all cursor-pointer inline-flex items-center gap-1"
                            >
                              <Download className="w-3 h-3" />
                              <span>Download</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleOpenRestoreModal(b)}
                            className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer inline-flex items-center gap-1"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Restore</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Direct Workspace Purge (Per Spec Section 3) */}
          <DirectWorkspacePurge
            tenantId={selectedTenantId}
            tenantName={selectedTenantName}
            actingUid={actingUid}
            actingEmail={actingEmail}
            onPurgeSuccess={(res) => {
              if (selectedTenantId === activeFarm?.id) {
                onClear();
              }
              loadTenantBackups(selectedTenantId);
              loadAuditLogs(selectedTenantId);
            }}
            variant="card"
          />

          {/* Audit Logs for Tenant */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span>Recent Audit Trail for {selectedTenantName}</span>
              </h4>
              <button
                type="button"
                onClick={() => loadAuditLogs(selectedTenantId)}
                className="text-[11px] text-emerald-600 hover:text-emerald-700 font-bold"
              >
                Refresh
              </button>
            </div>
            {auditLogs.length === 0 ? (
              <p className="text-xs text-slate-400 py-3">No recent purge or backup logs for this tenant.</p>
            ) : (
              <div className="divide-y divide-slate-100 text-xs">
                {auditLogs.slice(0, 5).map((log) => (
                  <div key={log.id} className="py-2.5 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-slate-800 uppercase font-mono text-[11px]">
                        {log.action}
                      </span>
                      <span className="text-slate-500 text-[11px] ml-2">
                        by {log.actingUid}
                      </span>
                      {log.documentsDeleted !== undefined && (
                        <span className="text-red-600 text-[11px] ml-2 font-mono">
                          (-{log.documentsDeleted} docs)
                        </span>
                      )}
                      {log.restoredCount !== undefined && (
                        <span className="text-emerald-600 text-[11px] ml-2 font-mono">
                          (+{log.restoredCount} docs)
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {log.createdAt ? new Date(log.createdAt).toLocaleString() : new Date(log.timestamp).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. PLATFORM-WIDE TAB CONTENT (Super Admin Only) */}
      {activeTierTab === "platform" && isSuperAdmin && (
        <div className="space-y-6 animate-in fade-in duration-150">
          {/* Warning Banner */}
          <div className="p-4 bg-amber-500/10 border-2 border-amber-500/30 rounded-2xl flex items-start gap-3">
            <div className="p-2 bg-amber-500 text-slate-900 rounded-lg shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h4 className="text-xs font-black text-amber-950 uppercase tracking-wider">
                Platform-Wide System Tier (All Tenants & Farm Nodes)
              </h4>
              <p className="text-xs text-amber-900 leading-relaxed">
                Actions taken in this panel operate across <strong>every farm node and tenant</strong> registered on Mabala.
                Full-platform restorations require Maker-Checker dual confirmation from a second Administrator.
              </p>
            </div>
          </div>

          {/* Action Bar: Distinct Red-Bordered Button */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Globe className="w-4 h-4 text-purple-600" />
                <span>Full-Platform Managed Exports</span>
              </h3>
              <p className="text-xs text-slate-500">
                Snapshots encompassing all farm nodes, general ledgers, and platform entities.
              </p>
            </div>

            {/* Distinct Red-Bordered Button (Per Spec Section 5) */}
            <button
              type="button"
              id="btn-backup-entire-platform"
              onClick={handlePlatformBackupNow}
              disabled={creatingPlatformBackup}
              className="py-3 px-5 bg-red-50 hover:bg-red-100 active:bg-red-200 text-red-700 border-2 border-red-500 rounded-xl font-black text-xs transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {creatingPlatformBackup ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <HardDrive className="w-4 h-4 text-red-600" />
              )}
              <span>Backup Entire Platform Now</span>
            </button>
          </div>

          {/* Platform Backups Table */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700">
                Managed Platform Backups
              </h4>
              <button
                type="button"
                onClick={loadPlatformBackups}
                disabled={loadingPlatformBackups}
                className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${loadingPlatformBackups ? "animate-spin" : ""}`} />
              </button>
            </div>

            {loadingPlatformBackups ? (
              <div className="py-12 text-center text-xs text-slate-500">
                <RefreshCw className="w-5 h-5 animate-spin mx-auto text-purple-600 mb-2" />
                <span>Loading platform backups...</span>
              </div>
            ) : platformBackups.length === 0 ? (
              <div className="py-10 text-center border-2 border-dashed border-slate-200 rounded-xl space-y-2">
                <Globe className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-xs font-bold text-slate-700">No platform-wide backups recorded</p>
                <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                  Click &quot;Backup Entire Platform Now&quot; above to initiate a full managed export.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-100 rounded-xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Export Prefix / ID</th>
                      <th className="py-3 px-4">Date & Time</th>
                      <th className="py-3 px-4">Tenants</th>
                      <th className="py-3 px-4">Total Records</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {platformBackups.map((pb) => (
                      <tr key={pb.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-slate-900">
                          {pb.outputUriPrefix || `platform-backups/${pb.backupId}`}
                        </td>
                        <td className="py-3 px-4 text-slate-600">
                          {pb.createdAt ? new Date(pb.createdAt).toLocaleString() : new Date(pb.timestamp).toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-slate-700 font-mono">
                          {pb.totalTenants || "All"}
                        </td>
                        <td className="py-3 px-4 text-slate-700 font-mono">
                          {pb.totalRecords?.toLocaleString() || 0}
                        </td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[10px] font-bold uppercase">
                            {pb.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => handleOpenPlatformRestoreModal(pb)}
                            className="py-1.5 px-3 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer inline-flex items-center gap-1"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Restore Platform</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Platform-Wide Audit Logs */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span>Platform-Wide Disaster Recovery & Purge Log</span>
              </h4>
              <button
                type="button"
                onClick={() => loadAuditLogs()}
                className="text-[11px] text-purple-600 hover:text-purple-700 font-bold"
              >
                Refresh
              </button>
            </div>
            {auditLogs.length === 0 ? (
              <p className="text-xs text-slate-400 py-3">No system-wide audit entries found.</p>
            ) : (
              <div className="divide-y divide-slate-100 text-xs">
                {auditLogs.map((log) => (
                  <div key={log.id} className="py-3 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-slate-900 font-mono text-[11.5px] uppercase">
                        {log.action}
                      </span>
                      <span className="text-slate-500 ml-2">
                        Actor: <strong className="text-slate-700">{log.actingUid}</strong>
                      </span>
                      {log.targetTenantId && (
                        <span className="text-slate-600 ml-2">
                          Target: <strong className="text-slate-800">{log.targetTenantName || log.targetTenantId}</strong>
                        </span>
                      )}
                      {log.documentsDeleted !== undefined && (
                        <span className="text-red-600 ml-2 font-mono font-bold">
                          [-{log.documentsDeleted} records]
                        </span>
                      )}
                      {log.restoredCount !== undefined && (
                        <span className="text-emerald-600 ml-2 font-mono font-bold">
                          [+{log.restoredCount} restored]
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {log.createdAt ? new Date(log.createdAt).toLocaleString() : new Date(log.timestamp).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 4. MODAL: TENANT RESTORE CONFIRMATION */}
      {restoreModalOpen && backupToRestore && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="p-5 bg-emerald-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <RotateCcw className="w-5 h-5" />
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider">Restore Tenant Workspace</h3>
                  <p className="text-[11px] text-emerald-100">Target: {selectedTenantName}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setRestoreModalOpen(false)}
                disabled={isRestoringTenant}
                className="p-1.5 text-white/80 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {restoreSuccess ? (
                <div className="text-center py-4 space-y-3">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <h4 className="text-base font-black text-slate-800">Restoration Succeeded</h4>
                  <p className="text-xs text-slate-600">{restoreSuccess}</p>
                  <button
                    type="button"
                    onClick={() => setRestoreModalOpen(false)}
                    className="py-2 px-6 bg-slate-800 text-white rounded-lg text-xs font-bold cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              ) : (
                <>
                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 text-xs text-slate-700">
                    <p>
                      <strong>File:</strong> {backupToRestore.fileName}
                    </p>
                    <p>
                      <strong>Target Tenant:</strong> {selectedTenantName} (<span className="font-mono">{selectedTenantId}</span>)
                    </p>
                    <p>
                      <strong>Records to Restore:</strong> {backupToRestore.recordsCount || "All available"}
                    </p>
                  </div>

                  {restoreError && (
                    <div className="p-3.5 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-medium">
                      {restoreError}
                    </div>
                  )}

                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-700">
                      Type the tenant name to confirm restore:{" "}
                      <span className="font-mono px-1 bg-slate-100 rounded text-slate-900 border">
                        {selectedTenantName}
                      </span>
                    </label>
                    <input
                      type="text"
                      value={restoreConfirmName}
                      onChange={(e) => setRestoreConfirmName(e.target.value)}
                      placeholder={`Type "${selectedTenantName}" to confirm`}
                      disabled={isRestoringTenant}
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setRestoreModalOpen(false)}
                      disabled={isRestoringTenant}
                      className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleExecuteTenantRestore}
                      disabled={
                        restoreConfirmName.trim().toLowerCase() !== selectedTenantName.trim().toLowerCase() ||
                        isRestoringTenant
                      }
                      className={`py-2.5 px-5 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
                        restoreConfirmName.trim().toLowerCase() === selectedTenantName.trim().toLowerCase() &&
                        !isRestoringTenant
                          ? "bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer"
                          : "bg-slate-200 text-slate-400 cursor-not-allowed"
                      }`}
                    >
                      {isRestoringTenant ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Restoring...</span>
                        </>
                      ) : (
                        <>
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Confirm & Restore Workspace</span>
                        </>
                      )}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 5. MODAL: PLATFORM RESTORE (Maker-Checker Approval Required) */}
      {platformRestoreModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-lg w-full border-2 border-red-500 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="p-5 bg-red-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5" />
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider">Restore Entire Platform</h3>
                  <p className="text-[11px] text-red-100">Dual Maker-Checker Approval Required</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPlatformRestoreModalOpen(false)}
                disabled={isRestoringPlatform}
                className="p-1.5 text-white/80 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {platformSuccess ? (
                <div className="text-center py-4 space-y-3">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <h4 className="text-base font-black text-slate-800">Platform Restore Triggered</h4>
                  <p className="text-xs text-slate-600">{platformSuccess}</p>
                  <button
                    type="button"
                    onClick={() => setPlatformRestoreModalOpen(false)}
                    className="py-2 px-6 bg-slate-800 text-white rounded-lg text-xs font-bold cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              ) : (
                <>
                  <div className="p-3.5 bg-red-50 border border-red-200 text-red-900 rounded-xl space-y-1.5 text-xs">
                    <p className="font-extrabold text-red-950">CRITICAL SYSTEM-WIDE OPERATION:</p>
                    <p>
                      This will replace data across ALL tenants on Mabala with snapshot{" "}
                      <span className="font-mono font-bold">
                        {selectedPlatformBackup?.outputUriPrefix || selectedPlatformBackup?.backupId || "latest"}
                      </span>.
                    </p>
                  </div>

                  {platformError && (
                    <div className="p-3.5 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl text-xs font-medium">
                      {platformError}
                    </div>
                  )}

                  {/* Step 1: Type Confirmation Phrase */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-700">
                      Step 1: Type <span className="font-mono text-red-600 select-all">RESTORE ENTIRE PLATFORM</span>
                    </label>
                    <input
                      type="text"
                      value={platformConfirmPhrase}
                      onChange={(e) => setPlatformConfirmPhrase(e.target.value)}
                      placeholder="RESTORE ENTIRE PLATFORM"
                      disabled={isRestoringPlatform}
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono text-slate-900 focus:ring-2 focus:ring-red-500 outline-none"
                    />
                  </div>

                  {/* Step 2: Maker-Checker Second Admin Email */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-700">
                      Step 2: Second Admin Email (Maker-Checker Rule)
                    </label>
                    <input
                      type="email"
                      value={secondAdminEmail}
                      onChange={(e) => setSecondAdminEmail(e.target.value)}
                      placeholder="second.admin@mabala.cloud"
                      disabled={isRestoringPlatform}
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:ring-2 focus:ring-red-500 outline-none"
                    />
                    <p className="text-[10px] text-slate-400">
                      Must be a recognized Super Admin email distinct from {actingEmail}.
                    </p>
                  </div>

                  {/* Step 3: Second Admin Password */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-700">
                      Step 3: Second Admin Password (Optional if bypassed in test mode)
                    </label>
                    <input
                      type="password"
                      value={secondAdminPassword}
                      onChange={(e) => setSecondAdminPassword(e.target.value)}
                      placeholder="••••••••••••"
                      disabled={isRestoringPlatform}
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:ring-2 focus:ring-red-500 outline-none"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setPlatformRestoreModalOpen(false)}
                      disabled={isRestoringPlatform}
                      className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleExecutePlatformRestore}
                      disabled={
                        platformConfirmPhrase.trim() !== "RESTORE ENTIRE PLATFORM" ||
                        !secondAdminEmail.trim() ||
                        isRestoringPlatform
                      }
                      className={`py-2.5 px-5 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
                        platformConfirmPhrase.trim() === "RESTORE ENTIRE PLATFORM" &&
                        secondAdminEmail.trim() &&
                        !isRestoringPlatform
                          ? "bg-red-600 hover:bg-red-700 text-white cursor-pointer shadow-red-600/20"
                          : "bg-slate-200 text-slate-400 cursor-not-allowed"
                      }`}
                    >
                      {isRestoringPlatform ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Executing Restore...</span>
                        </>
                      ) : (
                        <>
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Execute Platform Restore</span>
                        </>
                      )}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TenantAndPlatformTierManager;

import React, { useState, useEffect, useRef } from "react";
import { useConfirm } from "./ConfirmModal";
import { Employee, Payslip, EmployeeSalaryAdjustment, StatutoryPaymentMonth, LeaveRecord, EmployeeAdvance, EmploymentStatus, MaritalStatus, StaffAdjustmentType, PayrollRun, PayrollRunLine, Farm } from "../types";
import { getStatutoryTaxConfig, subscribeTaxConfig, StatutoryTaxConfig, TaxAuditLogEntry } from "../services/taxConfigService";
import { calculateStatutoryDeductions } from "../utils/payrollDeductions";
import { 
  getWalletBalances, 
  initiateTopUpWallet, 
  checkTopUpStatus, 
  finalizeTopUpWallet, 
  WalletBalances 
} from "../services/walletService";
import { 
  validateEmployeePaymentChannels, 
  calculatePayrollDisbursementFees, 
  previewPayrollRun, 
  executePayrollDisbursementRun, 
  generatePayrollRunReportPDF, 
  generateSinglePayslipPDF, 
  generateWhatsAppPayslipLink, 
  generateEmailPayslipBody, 
  maskMobileNumber, 
  normalizeMobileMoneyNumber, 
  detectMomoProvider 
} from "../services/payrollService";
import { 
  Users, 
  UserPlus,
  FileText, 
  CheckCircle2, 
  DollarSign, 
  Settings, 
  Plus, 
  Sparkles, 
  Printer, 
  CreditCard, 
  Wallet, 
  Building2, 
  ClipboardList, 
  Coins, 
  ArrowUpRight, 
  ChevronDown, 
  ChevronRight,
  ShieldCheck,
  Calendar,
  UserCheck,
  PiggyBank,
  CheckCircle,
  FileSpreadsheet,
  Trash2,
  BookmarkPlus,
  Download,
  Search,
  Filter,
  Edit,
  Cake,
  Heart,
  Briefcase,
  Phone,
  User,
  FileCheck,
  UserX,
  Award,
  AlertCircle,
  UploadCloud,
  History,
  ShieldAlert,
  Clock,
  FileCheck2,
  Sliders,
  Smartphone,
  Send,
  Share2,
  Lock,
  RefreshCw,
  AlertTriangle,
  FileDown,
  MessageCircle,
  CheckSquare,
  Zap,
  ArrowRight
} from "lucide-react";
import BulkEmployeeImportPanel from "./BulkEmployeeImportPanel";
import BulkDisbursementModal from "./disbursements/BulkDisbursementModal";

interface PayrollPanelProps {
  employees: Employee[];
  payslips: Payslip[];
  onAddEmployee: (emp: Employee) => void;
  onBulkAddEmployees?: (employees: Employee[]) => void;
  onUpdateEmployee?: (emp: Employee) => void;
  onRunPayroll: (slips: Payslip[]) => void;
  isReadonly: boolean;
  currencySymbol: string;
  isZambia: boolean;
  activeFarm?: Farm | {
    name: string;
    address: string;
    tpin: string;
    phone: string;
    email: string;
    logo?: string;
    letterheadTitle?: string;
    letterheadSubtitle?: string;
    letterheadAddress?: string;
  };
  leaveRecords: LeaveRecord[];
  onAddLeaveRecord: (leave: Omit<LeaveRecord, "id" | "farmId">) => void;
  onDeleteLeaveRecord: (id: string) => void;
  employeeAdvances: EmployeeAdvance[];
  onAddEmployeeAdvance: (adv: Omit<EmployeeAdvance, "id" | "farmId">) => void;
  onRepayEmployeeAdvance: (id: string, amount: number) => void;
  onDeleteEmployeeAdvance: (id: string) => void;
  onDeleteEmployee?: (id: string) => void;
}

const ZAMBIAN_BANKS = [
  "Absa Bank Zambia PLC",
  "Access Bank Zambia Limited",
  "Atlas Mara Bank Zambia Limited",
  "Ecobank Zambia Limited",
  "First Alliance Bank Zambia Limited",
  "First National Bank (FNB) Zambia Limited",
  "Indo-Zambia Bank Limited",
  "Investrust Bank PLC",
  "Stanbic Bank Zambia Limited",
  "Standard Chartered Bank Zambia PLC",
  "Zambia National Commercial Bank (Zanaco) PLC"
];

const DEFAULT_SAMPLE_EMPLOYEES: Employee[] = [];

export default function PayrollPanel({ 
  employees, 
  payslips, 
  onAddEmployee, 
  onBulkAddEmployees,
  onUpdateEmployee,
  onRunPayroll, 
  isReadonly, 
  currencySymbol, 
  isZambia,
  activeFarm,
  leaveRecords,
  onAddLeaveRecord,
  onDeleteLeaveRecord,
  employeeAdvances,
  onAddEmployeeAdvance,
  onRepayEmployeeAdvance,
  onDeleteEmployeeAdvance,
  onDeleteEmployee
}: PayrollPanelProps) {
  const confirm = useConfirm();
  const effectiveEmployees = employees.length > 0 ? employees : DEFAULT_SAMPLE_EMPLOYEES;

  // Navigation states
  const [activeTab, setActiveTab] = useState<"run" | "register" | "history" | "statutory" | "adjustments" | "leaves" | "advances" | "bulk-import" | "audit-history">("register");
  const [showAddWorker, setShowAddWorker] = useState(false);
  const [selectedEmpIds, setSelectedEmpIds] = useState<string[]>([]);
  const [activeMonth, setActiveMonth] = useState("2026-05");
  const [showLipilaDisbursementModal, setShowLipilaDisbursementModal] = useState(false);

  // Statutory Tax Config Live Subscription State
  const [statConfig, setStatConfig] = useState<StatutoryTaxConfig>(getStatutoryTaxConfig());

  useEffect(() => {
    const unsub = subscribeTaxConfig((cfg) => {
      setStatConfig(cfg);
    });
    return () => unsub();
  }, []);

  // Dedicated Payroll Audit History Filters & Manual Entry States
  const [auditCategoryFilter, setAuditCategoryFilter] = useState<"ALL" | "STATUTORY_RATES" | "PAYROLL_RUNS" | "STAFF_ADJUSTMENTS" | "REMITTANCE_ADVANCES">("ALL");
  const [auditSearchQuery, setAuditSearchQuery] = useState("");
  const [showManualLogModal, setShowManualLogModal] = useState(false);
  const [manualNoteText, setManualNoteText] = useState("");
  const [manualNoteCategory, setManualNoteCategory] = useState<"STATUTORY_RATES" | "PAYROLL_RUNS" | "STAFF_ADJUSTMENTS" | "REMITTANCE_ADVANCES">("STATUTORY_RATES");
  const [manualLogs, setManualLogs] = useState<Array<{ id: string; timestamp: string; category: string; title: string; performedBy: string; details: string }>>(() => {
    try {
      const saved = localStorage.getItem("mabala_payroll_manual_audit_logs");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("mabala_payroll_manual_audit_logs", JSON.stringify(manualLogs));
    } catch (e) {}
  }, [manualLogs]);

  // Leave Form state
  const [leaveEmployeeId, setLeaveEmployeeId] = useState("");
  const [leaveStart, setLeaveStart] = useState("");
  const [leaveEnd, setLeaveEnd] = useState("");
  const [leaveType, setLeaveType] = useState<"Sick" | "Annual" | "Maternity" | "Compassionate">("Annual");
  const [leaveReason, setLeaveReason] = useState("");

  // Advances Form state
  const [advanceEmployeeId, setAdvanceEmployeeId] = useState("");
  const [advanceAmount, setAdvanceAmount] = useState("");
  const [advanceDate, setAdvanceDate] = useState(new Date().toISOString().substring(0, 10));
  const [advanceNotes, setAdvanceNotes] = useState("");

  // Advance repayment helper
  const [repayingAdvanceId, setRepayingAdvanceId] = useState<string | null>(null);
  const [repayAmt, setRepayAmt] = useState("");

  // Pagination states
  const [pageSize, setPageSize] = useState<number>(10);
  const [currentPage, setCurrentPage] = useState<number>(1);

  // New Employee Form States
  const [name, setName] = useState("");
  const [role, setRole] = useState("Field Staff");
  const [isCustomRole, setIsCustomRole] = useState(false);
  const [employmentStatus, setEmploymentStatus] = useState<EmploymentStatus>("Permanent");
  const [contractType, setContractType] = useState("Indefinite Contract");
  const [contractStartDate, setContractStartDate] = useState(new Date().toISOString().split("T")[0]);
  const [contractEndDate, setContractEndDate] = useState("");
  const [contractNotes, setContractNotes] = useState("");

  // Pay & Direct Allowances
  const [contractRate, setContractRate] = useState<number>(4500);
  const [housingAllowance, setHousingAllowance] = useState<number>(500);
  const [transportAllowance, setTransportAllowance] = useState<number>(300);
  const [medicalAllowance, setMedicalAllowance] = useState<number>(150);
  const [fieldAllowance, setFieldAllowance] = useState<number>(200);
  const [otherAllowance, setOtherAllowance] = useState<number>(100);

  // Personal & Kin details
  const [maritalStatus, setMaritalStatus] = useState<MaritalStatus>("Married");
  const [dateOfBirth, setDateOfBirth] = useState("1995-05-15");
  const [nrcNumber, setNrcNumber] = useState("");
  const [nextOfKinName, setNextOfKinName] = useState("");
  const [nextOfKinContact, setNextOfKinContact] = useState("");
  const [nextOfKinRelationship, setNextOfKinRelationship] = useState("Spouse");

  // Statutory & Payment channel (Enforced Mobile Money for Payroll via Lipila)
  const [napsaNumber, setNapsaNumber] = useState("");
  const [nhimaNumber, setNhimaNumber] = useState("");
  const [paymentChannel, setPaymentChannel] = useState<"mobile_money" | "bank_transfer" | "cash">("mobile_money");
  const [mobileMoneyProvider, setMobileMoneyProvider] = useState<"airtel" | "mtn" | "zamtel">("mtn");
  const [mobileMoneyNumber, setMobileMoneyNumber] = useState("");
  const [mobileMoneyVerified, setMobileMoneyVerified] = useState(false);
  const [verifiedAccountName, setVerifiedAccountName] = useState("");
  const [isVerifyingMomo, setIsVerifyingMomo] = useState(false);
  const [momoVerificationError, setMomoVerificationError] = useState<string | null>(null);

  // Legacy fallback states
  const [paymentMethod, setPaymentMethod] = useState<Employee["paymentMethod"]>("MTN MoMo");
  const [bankName, setBankName] = useState(ZAMBIAN_BANKS[0]);
  const [bankAccount, setBankAccount] = useState("");
  const [bankBranch, setBankBranch] = useState("");
  const [walletNumber, setWalletNumber] = useState("");

  // Farm Wallet Balances (Lipila vs Cash separation)
  const [walletBalances, setWalletBalances] = useState<WalletBalances>(() => getWalletBalances("TENANT-001"));

  useEffect(() => {
    const handleWalletUpdate = () => {
      setWalletBalances(getWalletBalances("TENANT-001"));
    };
    window.addEventListener("mabala_wallet_update", handleWalletUpdate);
    return () => window.removeEventListener("mabala_wallet_update", handleWalletUpdate);
  }, []);

  // Top-Up Modal State for In-Context Lipila Top-Up
  const [showTopUpModal, setShowTopUpModal] = useState(false);
  const [topUpProvider, setTopUpProvider] = useState<"Airtel Money" | "MTN MoMo" | "Zamtel Kwacha">("Airtel Money");
  const [topUpPhone, setTopUpPhone] = useState("0977123456");
  const [topUpAmount, setTopUpAmount] = useState<number>(1000);
  const [topUpLoading, setTopUpLoading] = useState(false);
  const [topUpSuccess, setTopUpSuccess] = useState<string | null>(null);
  const [topUpError, setTopUpError] = useState<string | null>(null);
  const [topUpStep, setTopUpStep] = useState<"FORM" | "PENDING_PIN" | "SUCCESS" | "FAILED">("FORM");
  const [topUpRefId, setTopUpRefId] = useState<string>("");
  const [topUpCountdown, setTopUpCountdown] = useState<number>(300);

  // Bulk Payroll Execution & Disbursement Mode State
  const [showPinModal, setShowPinModal] = useState(false);
  const [disbursementMode, setDisbursementMode] = useState<"without_disbursement" | "with_disbursement">("without_disbursement");
  const [payrollPin, setPayrollPin] = useState("");
  const [isDisbursing, setIsDisbursing] = useState(false);
  const [disbursementStepText, setDisbursementStepText] = useState("");
  const [disbursementError, setDisbursementError] = useState<string | null>(null);
  const [lastExecutedRun, setLastExecutedRun] = useState<PayrollRun | null>(null);
  const [showRunSuccessModal, setShowRunSuccessModal] = useState(false);
  const [verifyingEmployeeId, setVerifyingEmployeeId] = useState<string | null>(null);
  const [payslipShareFeedback, setPayslipShareFeedback] = useState<string | null>(null);

  // Employee Register search & filter
  const [registerSearch, setRegisterSearch] = useState("");
  const [registerStatusFilter, setRegisterStatusFilter] = useState("All");

  // Staff adjustment / Promotion Modal state
  const [showStaffAdjModal, setShowStaffAdjModal] = useState(false);
  const [staffAdjEmpId, setStaffAdjEmpId] = useState("");
  const [staffAdjType, setStaffAdjType] = useState<StaffAdjustmentType>("Promoted");
  const [staffAdjNewRole, setStaffAdjNewRole] = useState("");
  const [staffAdjNewBasic, setStaffAdjNewBasic] = useState<number>(0);
  const [staffAdjHousing, setStaffAdjHousing] = useState<number>(0);
  const [staffAdjTransport, setStaffAdjTransport] = useState<number>(0);
  const [staffAdjMedical, setStaffAdjMedical] = useState<number>(0);
  const [staffAdjField, setStaffAdjField] = useState<number>(0);
  const [staffAdjOther, setStaffAdjOther] = useState<number>(0);
  const [staffAdjReason, setStaffAdjReason] = useState("");
  const [staffAdjEffectiveDate, setStaffAdjEffectiveDate] = useState(new Date().toISOString().split("T")[0]);

  // Edit Employee Contract Modal state
  const [editingEmp, setEditingEmp] = useState<Employee | null>(null);

  // Print Register Modal
  const [showPrintRegisterModal, setShowPrintRegisterModal] = useState(false);

  // Live Auto gross salary calculation for the form
  const computedGrossSalary = contractRate + housingAllowance + transportAllowance + medicalAllowance + fieldAllowance + otherAllowance;

  // Helper: Age Calculator
  const calculateAge = (dobString?: string): number | null => {
    if (!dobString) return null;
    const dob = new Date(dobString);
    if (isNaN(dob.getTime())) return null;
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const monthDiff = today.getMonth() - dob.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
      age--;
    }
    return age;
  };

  // Helper: Birthday Status Detector
  const getBirthdayStatus = (dobString?: string) => {
    if (!dobString) return null;
    const dob = new Date(dobString);
    if (isNaN(dob.getTime())) return null;
    const today = new Date();
    const dobMonth = dob.getMonth();
    const dobDate = dob.getDate();
    const currentMonth = today.getMonth();
    const currentDate = today.getDate();

    if (dobMonth === currentMonth && dobDate === currentDate) {
      return { isToday: true, isThisMonth: true, day: dobDate };
    } else if (dobMonth === currentMonth) {
      return { isToday: false, isThisMonth: true, day: dobDate };
    }
    return null;
  };

  // Helper: Real CSV Exporter
  const exportToCSV = (filename: string, headers: string[], rows: (string | number)[][]) => {
    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.map(cell => `"${String(cell ?? "").replace(/"/g, '""')}"`).join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Selection states for payroll (Pre-select active employees)
  const [selectedEmployeeIds, setSelectedEmployeeIds] = useState<string[]>([]);
  
  // Custom adjustments for the *current* pending run
  const [adjustments, setAdjustments] = useState<{
    [empId: string]: {
      basic: number;
      housing: number;
      transport: number;
      other: number;
      reason: string;
    }
  }>({});

  // Active adjustment screen modal or target
  const [editingAdjustmentEmpId, setEditingAdjustmentEmpId] = useState<string | null>(null);
  const [tempBasic, setTempBasic] = useState<number>(0);
  const [tempHousing, setTempHousing] = useState<number>(0);
  const [tempTransport, setTempTransport] = useState<number>(0);
  const [tempOther, setTempOther] = useState<number>(0);
  const [tempReason, setTempReason] = useState<string>("");

  // Persistent historical adjustments logged
  const [adjustmentLogs, setAdjustmentLogs] = useState<EmployeeSalaryAdjustment[]>(() => {
    try {
      const saved = localStorage.getItem("mabala_adjustment_logs");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {}
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem("mabala_adjustment_logs", JSON.stringify(adjustmentLogs));
    } catch (e) {}
  }, [adjustmentLogs]);

  // ZRA Compliance Config
  const [zraThreshold, setZraThreshold] = useState(5100); 
  const [taxRate, setTaxRate] = useState(20); 

  // Modal print layouts
  const [selectedPayslipToPrint, setSelectedPayslipToPrint] = useState<Payslip | null>(null);
  const [expandedHistoryMonth, setExpandedHistoryMonth] = useState<string | null>(null);

  // Sync selected employees when the list of employees updates
  useEffect(() => {
    setSelectedEmployeeIds(employees.filter(e => e.status === "Active").map(e => e.id));
  }, [employees]);

  // Verification handler for Add Worker form
  const handleVerifyMomoAccountInForm = async () => {
    const rawNumber = mobileMoneyNumber || walletNumber;
    if (!rawNumber) {
      setMomoVerificationError("Please enter a Zambian Mobile Money number first.");
      return;
    }
    const cleanNumber = normalizeMobileMoneyNumber(rawNumber);
    if (!cleanNumber || cleanNumber.length !== 10) {
      setMomoVerificationError("Invalid Zambian number. Must be 10 digits (e.g. 0977123456).");
      return;
    }

    setIsVerifyingMomo(true);
    setMomoVerificationError(null);

    try {
      const detected = detectMomoProvider(cleanNumber);
      setMobileMoneyProvider(detected);

      // Name lookup call
      const res = await fetch(`/api/lipila/name-lookup?number=${cleanNumber}`);
      const data = await res.json();

      const resolvedName = data.accountName || `${name || "Registered Account"} (${detected.toUpperCase()})`;
      setVerifiedAccountName(resolvedName);
      setMobileMoneyVerified(true);
      setMobileMoneyNumber(cleanNumber);
    } catch (err: any) {
      setMomoVerificationError(err.message || "Failed to verify account with Lipila gateway.");
    } finally {
      setIsVerifyingMomo(false);
    }
  };

  // Verification handler for Employee table rows
  const handleVerifyEmployeeInTable = async (emp: Employee) => {
    setVerifyingEmployeeId(emp.id);
    try {
      const raw = emp.mobileMoneyNumber || emp.walletNumber || emp.mobileNumber || "";
      const clean = normalizeMobileMoneyNumber(raw) || "0977000000";
      const detected = emp.mobileMoneyProvider || detectMomoProvider(clean);

      const res = await fetch(`/api/lipila/name-lookup?number=${clean}`);
      const data = await res.json();
      const resolvedName = data.accountName || emp.name;

      const updated: Employee = {
        ...emp,
        paymentChannel: "mobile_money",
        mobileMoneyNumber: clean,
        walletNumber: clean,
        mobileMoneyProvider: detected,
        mobileMoneyVerified: true,
        mobileMoneyVerifiedAt: new Date().toISOString(),
        verifiedAccountName: resolvedName,
        verifiedBy: activeFarm?.name ? `${activeFarm.name} HR Admin` : "Lipila Gateway"
      };

      if (onUpdateEmployee) {
        onUpdateEmployee(updated);
      }
    } catch (e) {
      console.error("Verification error:", e);
    } finally {
      setVerifyingEmployeeId(null);
    }
  };

  // Countdown & auto-poll effect for in-context Lipila Top-Up
  const payrollFinalizingRef = useRef<boolean>(false);
  const payrollFulfilledRefId = useRef<string | null>(null);

  useEffect(() => {
    if (topUpStep !== "PENDING_PIN" || !topUpRefId || !showTopUpModal) return;

    const timer = setInterval(() => {
      setTopUpCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          setTopUpStep("FAILED");
          setTopUpError("Mobile Money PIN authorization timed out (300s). Funds were not deducted.");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    const poller = setInterval(async () => {
      if (payrollFinalizingRef.current || payrollFulfilledRefId.current === topUpRefId) {
        clearInterval(poller);
        clearInterval(timer);
        return;
      }

      try {
        const check = await checkTopUpStatus(topUpRefId);
        if (check.status === "Successful" || check.status === "Success" || check.status === "Completed") {
          clearInterval(poller);
          clearInterval(timer);
          if (payrollFinalizingRef.current || payrollFulfilledRefId.current === topUpRefId) return;
          payrollFinalizingRef.current = true;
          payrollFulfilledRefId.current = topUpRefId;

          await finalizeTopUpWallet({
            tenantId: "TENANT-001",
            referenceId: topUpRefId,
            amount: topUpAmount,
            phone: topUpPhone,
            provider: topUpProvider
          });
          setTopUpStep("SUCCESS");
          setTopUpSuccess(`🎉 Successfully topped up ZMW ${topUpAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} into Farm Lipila Wallet!`);
          setWalletBalances(getWalletBalances("TENANT-001"));
        } else if (check.status === "Failed" || check.status === "Rejected") {
          clearInterval(poller);
          clearInterval(timer);
          setTopUpStep("FAILED");
          setTopUpError(check.message || "Payment was rejected or cancelled by mobile subscriber.");
        }
      } catch (err: any) {
        console.warn("Polling error:", err);
      }
    }, 3000);

    return () => {
      clearInterval(timer);
      clearInterval(poller);
    };
  }, [topUpStep, topUpRefId, showTopUpModal, topUpAmount, topUpPhone, topUpProvider]);

  // Initiate Top-Up
  const handleInitiateTopUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setTopUpError(null);
    setTopUpSuccess(null);
    payrollFinalizingRef.current = false;
    payrollFulfilledRefId.current = null;

    const clean = normalizeMobileMoneyNumber(topUpPhone);
    if (!clean || clean.length !== 10) {
      setTopUpError("Please enter a valid 10-digit Zambian Mobile Money number (e.g. 0977123456).");
      return;
    }
    if (topUpAmount <= 0) {
      setTopUpError("Please enter an amount greater than ZMW 0.");
      return;
    }

    setTopUpLoading(true);
    try {
      const res = await initiateTopUpWallet({
        tenantId: "TENANT-001",
        amount: topUpAmount,
        phone: clean,
        provider: topUpProvider
      });

      setTopUpRefId(res.referenceId);
      setTopUpCountdown(300);
      setTopUpStep("PENDING_PIN");
    } catch (err: any) {
      setTopUpError(err.message || "Failed to initiate mobile money payment collection.");
    } finally {
      setTopUpLoading(false);
    }
  };

  const handleCreateEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || contractRate <= 0) return;

    const chosenMomo = normalizeMobileMoneyNumber(mobileMoneyNumber || walletNumber) || "0977000000";
    const chosenProvider = mobileMoneyProvider || detectMomoProvider(chosenMomo);

    const newWorker: Employee = {
      id: "EMP-" + (effectiveEmployees.length + 101),
      name,
      role,
      employmentStatus,
      contractType,
      contractStartDate: contractStartDate || undefined,
      contractEndDate: contractEndDate || undefined,
      contractNotes: contractNotes || undefined,
      contractRate,
      housingAllowance,
      transportAllowance,
      medicalAllowance,
      fieldAllowance,
      otherAllowance,
      grossSalary: computedGrossSalary,
      napsaNumber: napsaNumber || undefined,
      nhimaNumber: nhimaNumber || undefined,
      nrcNumber: nrcNumber || undefined,
      maritalStatus,
      dateOfBirth: dateOfBirth || undefined,
      nextOfKinName: nextOfKinName || undefined,
      nextOfKinContact: nextOfKinContact || undefined,
      nextOfKinRelationship: nextOfKinRelationship || undefined,
      nextOfKin: nextOfKinName ? {
        name: nextOfKinName,
        contactNumber: nextOfKinContact,
        relationship: nextOfKinRelationship
      } : undefined,
      paymentChannel: "mobile_money",
      mobileMoneyProvider: chosenProvider,
      mobileMoneyNumber: chosenMomo,
      mobileMoneyVerified: mobileMoneyVerified,
      mobileMoneyVerifiedAt: mobileMoneyVerified ? new Date().toISOString() : undefined,
      verifiedAccountName: verifiedAccountName || undefined,
      verifiedBy: mobileMoneyVerified ? "Lipila Gateway" : undefined,
      paymentMethod: chosenProvider === "airtel" ? "Airtel Money" : (chosenProvider === "zamtel" ? "Zamtel Money" : "MTN MoMo"),
      bankName: undefined,
      bankAccount: undefined,
      bankBranch: undefined,
      walletNumber: chosenMomo,
      country: isZambia ? "ZM" : "Generic",
      status: "Active"
    };

    onAddEmployee(newWorker);
    
    // Reset Form
    setName("");
    setRole("Field Staff");
    setIsCustomRole(false);
    setEmploymentStatus("Permanent");
    setContractType("Indefinite Contract");
    setContractStartDate(new Date().toISOString().split("T")[0]);
    setContractEndDate("");
    setContractNotes("");
    setContractRate(4500);
    setHousingAllowance(500);
    setTransportAllowance(300);
    setMedicalAllowance(150);
    setFieldAllowance(200);
    setOtherAllowance(100);
    setMaritalStatus("Married");
    setDateOfBirth("1995-05-15");
    setNrcNumber("");
    setNextOfKinName("");
    setNextOfKinContact("");
    setNextOfKinRelationship("Spouse");
    setNapsaNumber("");
    setNhimaNumber("");
    setBankAccount("");
    setBankBranch("");
    setWalletNumber("");
    setMobileMoneyNumber("");
    setMobileMoneyVerified(false);
    setVerifiedAccountName("");
    setShowAddWorker(false);
  };

  // Staff Adjustment Handlers
  const openStaffAdjustmentModal = (emp: Employee) => {
    setStaffAdjEmpId(emp.id);
    setStaffAdjType("Promoted");
    setStaffAdjNewRole(emp.role);
    setStaffAdjNewBasic(emp.contractRate);
    setStaffAdjHousing(emp.housingAllowance || 0);
    setStaffAdjTransport(emp.transportAllowance || 0);
    setStaffAdjMedical(emp.medicalAllowance || 0);
    setStaffAdjField(emp.fieldAllowance || 0);
    setStaffAdjOther(emp.otherAllowance || 0);
    setStaffAdjReason("");
    setStaffAdjEffectiveDate(new Date().toISOString().split("T")[0]);
    setShowStaffAdjModal(true);
  };

  const handleSaveStaffAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = effectiveEmployees.find(e => e.id === staffAdjEmpId);
    if (!emp) return;

    let newStatus: Employee["status"] = emp.status;
    let newRole = emp.role;
    let newBasic = emp.contractRate;
    let newH = emp.housingAllowance || 0;
    let newT = emp.transportAllowance || 0;
    let newM = emp.medicalAllowance || 0;
    let newF = emp.fieldAllowance || 0;
    let newO = emp.otherAllowance || 0;

    if (staffAdjType === "Terminated") {
      newStatus = "Terminated";
    } else if (staffAdjType === "Resigned") {
      newStatus = "Resigned";
    } else if (staffAdjType === "Promoted") {
      newStatus = "Active";
      newRole = staffAdjNewRole || emp.role;
      newBasic = staffAdjNewBasic;
      newH = staffAdjHousing;
      newT = staffAdjTransport;
      newM = staffAdjMedical;
      newF = staffAdjField;
      newO = staffAdjOther;
    } else if (staffAdjType === "Salary Increase" || staffAdjType === "Allowance Adjustment" || staffAdjType === "Demotion") {
      newBasic = staffAdjNewBasic;
      newH = staffAdjHousing;
      newT = staffAdjTransport;
      newM = staffAdjMedical;
      newF = staffAdjField;
      newO = staffAdjOther;
      if (staffAdjNewRole) newRole = staffAdjNewRole;
    }

    const updatedGross = newBasic + newH + newT + newM + newF + newO;

    const updatedEmp: Employee = {
      ...emp,
      role: newRole,
      status: newStatus,
      contractRate: newBasic,
      housingAllowance: newH,
      transportAllowance: newT,
      medicalAllowance: newM,
      fieldAllowance: newF,
      otherAllowance: newO,
      grossSalary: updatedGross
    };

    if (onUpdateEmployee) {
      onUpdateEmployee(updatedEmp);
    }

    // Log in adjustment logs
    const newLog: EmployeeSalaryAdjustment = {
      id: "adj-" + Date.now().toString().slice(-4),
      employeeId: emp.id,
      employeeName: emp.name,
      date: staffAdjEffectiveDate,
      month: activeMonth,
      adjustmentType: staffAdjType,
      basicBefore: emp.contractRate,
      basicAfter: newBasic,
      allowancesBefore: (emp.housingAllowance || 0) + (emp.transportAllowance || 0) + (emp.medicalAllowance || 0) + (emp.fieldAllowance || 0) + (emp.otherAllowance || 0),
      allowancesAfter: newH + newT + newM + newF + newO,
      statusBefore: emp.status,
      statusAfter: newStatus,
      newRole: newRole !== emp.role ? newRole : undefined,
      reason: staffAdjReason || `Staff status adjustment logged: ${staffAdjType}`
    };

    setAdjustmentLogs(prev => [newLog, ...prev]);
    setShowStaffAdjModal(false);
  };

  const handleSaveEditEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmp) return;

    const gross = (editingEmp.contractRate || 0) + (editingEmp.housingAllowance || 0) + (editingEmp.transportAllowance || 0) + (editingEmp.medicalAllowance || 0) + (editingEmp.fieldAllowance || 0) + (editingEmp.otherAllowance || 0);

    const cleanNumber = normalizeMobileMoneyNumber(editingEmp.mobileMoneyNumber || editingEmp.walletNumber || "") || "";
    const provider = editingEmp.mobileMoneyProvider || (cleanNumber ? detectMomoProvider(cleanNumber) : "mtn");

    const finalEmp: Employee = {
      ...editingEmp,
      paymentChannel: "mobile_money",
      mobileMoneyNumber: cleanNumber || editingEmp.mobileMoneyNumber,
      walletNumber: cleanNumber || editingEmp.walletNumber,
      mobileMoneyProvider: provider,
      paymentMethod: provider === "airtel" ? "Airtel Money" : (provider === "zamtel" ? "Zamtel Money" : "MTN MoMo"),
      grossSalary: gross,
      nextOfKin: editingEmp.nextOfKinName ? {
        name: editingEmp.nextOfKinName,
        contactNumber: editingEmp.nextOfKinContact || "",
        relationship: editingEmp.nextOfKinRelationship || "Spouse"
      } : editingEmp.nextOfKin
    };

    if (onUpdateEmployee) {
      onUpdateEmployee(finalEmp);
    }
    setEditingEmp(null);
  };

  const handleExportRegisterCSV = () => {
    const headers = [
      "Employee ID",
      "Full Name",
      "Role",
      "Employment Status",
      "Contract Type",
      "Contract Start Date",
      "Contract End Date",
      "Date of Birth",
      "Age",
      "Marital Status",
      "NRC / ID Number",
      `Basic Pay (${currencySymbol})`,
      `Housing Allowance (${currencySymbol})`,
      `Transport Allowance (${currencySymbol})`,
      `Medical Allowance (${currencySymbol})`,
      `Field Allowance (${currencySymbol})`,
      `Other Allowance (${currencySymbol})`,
      `Gross Salary (${currencySymbol})`,
      "Next of Kin Name",
      "Next of Kin Contact",
      "Next of Kin Relationship",
      "NAPSA Number",
      "NHIMA Number",
      "Payment Method",
      "Bank / Wallet Info",
      "Status"
    ];

    const rows = effectiveEmployees.map(emp => {
      const age = calculateAge(emp.dateOfBirth);
      const gross = (emp.contractRate || 0) + (emp.housingAllowance || 0) + (emp.transportAllowance || 0) + (emp.medicalAllowance || 0) + (emp.fieldAllowance || 0) + (emp.otherAllowance || 0);
      const bankOrWallet = emp.paymentMethod === "Bank Transfer"
        ? `${emp.bankName || ""} - Acc: ${emp.bankAccount || ""} (${emp.bankBranch || ""})`
        : `Wallet: ${emp.walletNumber || ""}`;

      return [
        emp.id,
        emp.name,
        emp.role,
        emp.employmentStatus || "Permanent",
        emp.contractType || "N/A",
        emp.contractStartDate || "N/A",
        emp.contractEndDate || "N/A",
        emp.dateOfBirth || "N/A",
        age !== null ? age : "N/A",
        emp.maritalStatus || "N/A",
        emp.nrcNumber || "N/A",
        emp.contractRate,
        emp.housingAllowance || 0,
        emp.transportAllowance || 0,
        emp.medicalAllowance || 0,
        emp.fieldAllowance || 0,
        emp.otherAllowance || 0,
        gross,
        emp.nextOfKinName || emp.nextOfKin?.name || "N/A",
        emp.nextOfKinContact || emp.nextOfKin?.contactNumber || "N/A",
        emp.nextOfKinRelationship || emp.nextOfKin?.relationship || "N/A",
        emp.napsaNumber || "N/A",
        emp.nhimaNumber || "N/A",
        emp.paymentMethod || "N/A",
        bankOrWallet,
        emp.status
      ];
    });

    exportToCSV(`Employee_Register_${activeFarm?.name || "Mabala_Farms"}_${new Date().toISOString().split("T")[0]}.csv`, headers, rows);
  };

  // Open adjustment dialog for worker
  const openAdjustmentModal = (emp: Employee) => {
    const cached = adjustments[emp.id] || {
      basic: emp.contractRate,
      housing: emp.housingAllowance || 0,
      transport: emp.transportAllowance || 0,
      other: emp.otherAllowance || 0,
      reason: ""
    };
    setEditingAdjustmentEmpId(emp.id);
    setTempBasic(cached.basic);
    setTempHousing(cached.housing);
    setTempTransport(cached.transport);
    setTempOther(cached.other);
    setTempReason(cached.reason);
  };

  // Save current dynamic adjustment
  const saveAdjustment = () => {
    if (!editingAdjustmentEmpId) return;
    const emp = employees.find(e => e.id === editingAdjustmentEmpId);
    if (!emp) return;

    setAdjustments(prev => ({
      ...prev,
      [editingAdjustmentEmpId]: {
        basic: tempBasic,
        housing: tempHousing,
        transport: tempTransport,
        other: tempOther,
        reason: tempReason || "Monthly manual adjustment run modification."
      }
    }));

    // If actual rates changed, log it publicly
    const originalBasic = emp.contractRate;
    const originalAll = (emp.housingAllowance || 0) + (emp.transportAllowance || 0) + (emp.otherAllowance || 0);
    const newAll = tempHousing + tempTransport + tempOther;

    if (originalBasic !== tempBasic || originalAll !== newAll) {
      const newLog: EmployeeSalaryAdjustment = {
        id: "adj-" + Date.now().toString().slice(-4),
        employeeId: emp.id,
        employeeName: emp.name,
        date: new Date().toISOString().split("T")[0],
        month: activeMonth,
        basicBefore: originalBasic,
        basicAfter: tempBasic,
        allowancesBefore: originalAll,
        allowancesAfter: newAll,
        reason: tempReason || "Direct payslip manual override."
      };
      setAdjustmentLogs(prev => [newLog, ...prev]);
    }

    setEditingAdjustmentEmpId(null);
  };

  // Compute calculated payslips for selection
  const calculatedSlips: Payslip[] = employees
    .filter(emp => selectedEmployeeIds.includes(emp.id))
    .map(emp => {
      // Pick adjusted rates if present, otherwise default to worker static contract rules
      const adjusted = adjustments[emp.id];
      const basic = adjusted ? adjusted.basic : emp.contractRate;
      const hAll = adjusted ? adjusted.housing : (emp.housingAllowance || 0);
      const tAll = adjusted ? adjusted.transport : (emp.transportAllowance || 0);
      const oAll = adjusted ? adjusted.other : (emp.otherAllowance || 0);
      
      const statTax = getStatutoryTaxConfig();
      const calc = calculateStatutoryDeductions({
        basicSalary: basic,
        housingAllowance: hAll,
        transportAllowance: tAll,
        otherAllowance: oAll,
        isZambia,
        taxConfig: statTax,
        customTaxRate: taxRate,
        customThreshold: zraThreshold,
      });

      return {
        id: `PAY-${emp.id}-${activeMonth}`,
        employeeId: emp.id,
        employeeName: emp.name,
        month: activeMonth,
        basicSalary: basic,
        housingAllowance: hAll,
        transportAllowance: tAll,
        otherAllowance: oAll,
        grossSalary: calc.grossSalary,
        paye: calc.paye,
        napsaEmployee: calc.napsaEmployee,
        napsaEmployer: calc.napsaEmployer,
        nhimaEmployee: calc.nhimaEmployee,
        nhimaEmployer: calc.nhimaEmployer,
        wcfEmployer: calc.wcfEmployer,
        skillsLevyEmployer: calc.skillsLevyEmployer,
        netPay: calc.netPay,
        adjustmentReason: adjusted ? adjusted.reason : undefined,
        paymentMethod: emp.paymentMethod,
        walletNumber: emp.walletNumber,
        bankName: emp.bankName,
        bankAccount: emp.bankAccount,
        bankBranch: emp.bankBranch
      };
    });

  const handleToggleSelectEmployee = (id: string) => {
    setSelectedEmployeeIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    const activeWorkers = employees.filter(e => e.status === "Active");
    if (selectedEmployeeIds.length === activeWorkers.length) {
      setSelectedEmployeeIds([]);
    } else {
      setSelectedEmployeeIds(activeWorkers.map(w => w.id));
    }
  };

  // Active selected employees for current payroll run
  const activeSelectedEmployees = effectiveEmployees.filter(
    e => e.status === "Active" && selectedEmployeeIds.includes(e.id)
  );

  // Validation Guard for payment channels
  const activePaymentChannelValidation = validateEmployeePaymentChannels(activeSelectedEmployees);

  // Fee calculation and run preview
  const currentPayrollPreview: PayrollRun = previewPayrollRun({
    tenantId: "TENANT-001",
    period: activeMonth,
    periodLabel: `${activeMonth} Farm Payroll Batch`,
    employees: activeSelectedEmployees,
    slips: calculatedSlips,
    farmLipilaBalance: walletBalances.lipilaBalance,
    platformFeePerEmployee: 3.00
  });

  const handleOpenDisburseModal = () => {
    if (isReadonly) {
      alert("Credits finished or write access denied. Run is blocked.");
      return;
    }
    if (activeSelectedEmployees.length === 0) {
      alert("No active workers selected. Select at least 1 employee.");
      return;
    }

    setDisbursementError(null);
    setPayrollPin("");
    setShowPinModal(true);
  };

  const handleExecuteBulkDisbursement = async () => {
    const isWithDisbursement = disbursementMode === "with_disbursement";

    if (isWithDisbursement) {
      if (currentPayrollPreview.shortfall && currentPayrollPreview.shortfall > 0) {
        setDisbursementError(`Insufficient Mabala Farm Ledger Balance! Required: ${currencySymbol} ${currentPayrollPreview.totals.grandTotal.toFixed(2)}, Available: ${currencySymbol} ${walletBalances.lipilaBalance.toFixed(2)}. Please top up your Mabala Farm Ledger first.`);
        return;
      }
    }

    setIsDisbursing(true);
    setDisbursementError(null);
    setDisbursementStepText(
      isWithDisbursement
        ? "Deducting total payroll & platform fees from Mabala Farm Ledger..."
        : "Calculating statutory withholdings and compiling payslips..."
    );

    try {
      if (isWithDisbursement) {
        setTimeout(() => setDisbursementStepText("Crediting Super Admin Operations Ledger..."), 400);
        setTimeout(() => setDisbursementStepText("Submitting manual payout request to Super Admin with employee HR numbers..."), 900);
      }

      const result = await executePayrollDisbursementRun({
        tenantId: "TENANT-001",
        run: currentPayrollPreview,
        withDisbursement: isWithDisbursement,
        pin: payrollPin,
        farmName: activeFarm?.name || "Mabala Farm",
        userEmail: activeFarm?.email || "farmadmin@mabala.zm"
      });

      if (!result.success) {
        throw new Error(result.message || "Payroll run processing failed.");
      }

      setLastExecutedRun(result.run);

      // Pass generated payslips to onRunPayroll
      if (result.payslips && result.payslips.length > 0) {
        onRunPayroll(result.payslips);
      } else {
        onRunPayroll(calculatedSlips);
      }

      // Log audit
      const runAuditLog = {
        id: "RUN-AUDIT-" + Date.now(),
        timestamp: new Date().toISOString(),
        category: "PAYROLL_RUNS",
        title: isWithDisbursement
          ? `Disbursed Payroll Run with Super Admin Payout Request for ${activeMonth} (${result.run.id})`
          : `Processed Payroll Run without Disbursement for ${activeMonth} (${result.run.id})`,
        performedBy: activeFarm?.email || "farmadmin@mabala.zm",
        details: isWithDisbursement
          ? `Processed ${result.run.lines.length} staff salaries for ${activeMonth}. Net Pay: ZK ${result.run.totals.totalNetSalary.toLocaleString(undefined, { minimumFractionDigits: 2 })}, Platform Fees: ZK ${result.run.totals.totalPlatformFees.toLocaleString(undefined, { minimumFractionDigits: 2 })}, Grand Total: ZK ${result.run.totals.grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })} deducted from Farm Ledger & queued for Super Admin manual payout.`
          : `Processed ${result.run.lines.length} staff salaries for ${activeMonth} without disbursement. Total Net Pay: ZK ${result.run.totals.totalNetSalary.toLocaleString(undefined, { minimumFractionDigits: 2 })}. Payslips & report generated.`
      };

      setManualLogs((prev) => [runAuditLog, ...prev]);
      setAdjustments({});
      setWalletBalances(getWalletBalances("TENANT-001"));
      setShowPinModal(false);
      setShowRunSuccessModal(true);
    } catch (err: any) {
      setDisbursementError(err.message || "Failed to process payroll run.");
    } finally {
      setIsDisbursing(false);
    }
  };

  const executePayrollRun = () => {
    handleOpenDisburseModal();
  };

  // Group posted historical payslips by month
  const postedMonths = Array.from(new Set(payslips.map(p => p.month))).sort((a,b) => b.localeCompare(a));

  // Statutory summary calculations month-by-month
  const statutorySummaries = Array.from(new Set(payslips.map(p => p.month))).map(month => {
    const slipsForMonth = payslips.filter(p => p.month === month);
    const napsaEE = slipsForMonth.reduce((acc, p) => acc + p.napsaEmployee, 0);
    const napsaER = slipsForMonth.reduce((acc, p) => acc + p.napsaEmployer, 0);
    const nhimaEE = slipsForMonth.reduce((acc, p) => acc + p.nhimaEmployee, 0);
    const nhimaER = slipsForMonth.reduce((acc, p) => acc + p.nhimaEmployer, 0);
    const payeTotal = slipsForMonth.reduce((acc, p) => acc + p.paye, 0);
    const wcfTotal = slipsForMonth.reduce((acc, p) => acc + (p.wcfEmployer || 0), 0);
    const skillsTotal = slipsForMonth.reduce((acc, p) => acc + (p.skillsLevyEmployer || 0), 0);

    return {
      month,
      napsa: napsaEE + napsaER,
      nhima: nhimaEE + nhimaER,
      paye: payeTotal,
      wcf: wcfTotal,
      skills: skillsTotal,
      total: napsaEE + napsaER + nhimaEE + nhimaER + payeTotal + wcfTotal + skillsTotal
    };
  });

  const generateMockCSV = (title: string, data: any[]) => {
    alert("Exporting " + title + " to CSV format... Local download initiated successfully.");
  };

  const triggerPDFPrint = (elementId: string) => {
    window.print();
  };

  // Compile all audit entries across Statutory Thresholds, Payroll Runs, Staff Adjustments, and Manual Notes
  const compiledAuditEntries = React.useMemo(() => {
    const list: Array<{
      id: string;
      timestamp: string;
      category: "STATUTORY_RATES" | "PAYROLL_RUNS" | "STAFF_ADJUSTMENTS" | "REMITTANCE_ADVANCES";
      categoryBadge: string;
      badgeStyle: string;
      title: string;
      performedBy: string;
      summary: string;
      secondaryDetail?: string;
      notes?: string;
    }> = [];

    // 1. Statutory Thresholds & Rates Audit Trail from taxConfig
    if (statConfig && Array.isArray(statConfig.auditTrail)) {
      statConfig.auditTrail.forEach((entry) => {
        list.push({
          id: entry.id || "TAX-" + Math.random(),
          timestamp: entry.updatedAt || new Date().toISOString(),
          category: "STATUTORY_RATES",
          categoryBadge: "Statutory Rates & Thresholds",
          badgeStyle: "bg-amber-50 text-amber-800 border-amber-200",
          title: "Statutory Tax Threshold & Rate Card Modified",
          performedBy: entry.updatedBy || "superadmin@mabala.zm",
          summary: `New: ${entry.newRateCardSummary}`,
          secondaryDetail: entry.previousRateCardSummary ? `Previous: ${entry.previousRateCardSummary}` : undefined,
          notes: entry.notes || "Statutory threshold update"
        });
      });
    }

    // 2. Posted Monthly Payroll Runs
    postedMonths.forEach((month) => {
      const slipsForMonth = payslips.filter((p) => p.month === month);
      const gross = slipsForMonth.reduce((acc, p) => acc + p.grossSalary, 0);
      const paye = slipsForMonth.reduce((acc, p) => acc + p.paye, 0);
      const net = slipsForMonth.reduce((acc, p) => acc + p.netPay, 0);
      const napsa = slipsForMonth.reduce((acc, p) => acc + p.napsaEmployee + p.napsaEmployer, 0);
      const nhima = slipsForMonth.reduce((acc, p) => acc + p.nhimaEmployee + p.nhimaEmployer, 0);

      list.push({
        id: `RUN-POST-${month}`,
        timestamp: `${month}-28T16:00:00.000Z`,
        category: "PAYROLL_RUNS",
        categoryBadge: "Payroll Execution",
        badgeStyle: "bg-emerald-50 text-emerald-800 border-emerald-200",
        title: `Finalized Monthly Payroll Run - ${month}`,
        performedBy: activeFarm?.email || "farmadmin@mabala.zm",
        summary: `${slipsForMonth.length} staff processed. Gross: ZK ${gross.toLocaleString(undefined, { minimumFractionDigits: 2 })}, PAYE Tax: ZK ${paye.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
        secondaryDetail: `Net Cash Paid: ZK ${net.toLocaleString(undefined, { minimumFractionDigits: 2 })}, Pension/Health: ZK ${(napsa + nhima).toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
        notes: "Posted to Double-Entry Statutory Payroll General Ledger"
      });
    });

    // 3. Staff Salary Adjustments & Promotions
    if (Array.isArray(adjustmentLogs)) {
      adjustmentLogs.forEach((log) => {
        list.push({
          id: log.id,
          timestamp: log.date ? `${log.date}T10:00:00.000Z` : new Date().toISOString(),
          category: "STAFF_ADJUSTMENTS",
          categoryBadge: "Staff Salary Override",
          badgeStyle: "bg-indigo-50 text-indigo-800 border-indigo-200",
          title: `${log.employeeName} (${log.employeeId}) - ${log.adjustmentType}`,
          performedBy: "Farm Administrator",
          summary: `Basic: ZK ${log.basicBefore.toLocaleString()} → ZK ${log.basicAfter.toLocaleString()}, Allowances: ZK ${log.allowancesBefore.toLocaleString()} → ZK ${log.allowancesAfter.toLocaleString()}`,
          secondaryDetail: log.newRole ? `New Role Title: ${log.newRole}` : undefined,
          notes: log.reason
        });
      });
    }

    // 4. Employee Advances Disbursed & Repaid
    if (Array.isArray(employeeAdvances)) {
      employeeAdvances.forEach((adv) => {
        list.push({
          id: `ADV-${adv.id}`,
          timestamp: adv.requestDate ? `${adv.requestDate}T09:00:00.000Z` : new Date().toISOString(),
          category: "REMITTANCE_ADVANCES",
          categoryBadge: "Salary Advance",
          badgeStyle: "bg-purple-50 text-purple-800 border-purple-200",
          title: `Salary Advance Disbursed - ${adv.employeeName}`,
          performedBy: "Payroll Disbursal Desk",
          summary: `Principal: ZK ${adv.advanceAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}, Outstanding: ZK ${adv.remainingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
          notes: adv.notes || "Emergency advance issued"
        });
      });
    }

    // 5. Manual Compliance Notes & Run Audits
    if (Array.isArray(manualLogs)) {
      manualLogs.forEach((entry) => {
        list.push({
          id: entry.id,
          timestamp: entry.timestamp,
          category: (entry.category as any) || "STATUTORY_RATES",
          categoryBadge: "Compliance Annotation",
          badgeStyle: "bg-slate-100 text-slate-800 border-slate-300",
          title: entry.title,
          performedBy: entry.performedBy,
          summary: entry.details,
          notes: "Manual administrator compliance audit remark"
        });
      });
    }

    // Sort descending by timestamp
    return list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [statConfig, postedMonths, payslips, adjustmentLogs, employeeAdvances, manualLogs, activeFarm]);

  // Filtered entries by category and search
  const filteredAuditEntries = React.useMemo(() => {
    return compiledAuditEntries.filter((e) => {
      const matchesCategory =
        auditCategoryFilter === "ALL" || e.category === auditCategoryFilter;

      const query = auditSearchQuery.toLowerCase().trim();
      if (!query) return matchesCategory;

      const matchesSearch =
        e.id.toLowerCase().includes(query) ||
        e.title.toLowerCase().includes(query) ||
        e.performedBy.toLowerCase().includes(query) ||
        e.summary.toLowerCase().includes(query) ||
        (e.secondaryDetail && e.secondaryDetail.toLowerCase().includes(query)) ||
        (e.notes && e.notes.toLowerCase().includes(query));

      return matchesCategory && matchesSearch;
    });
  }, [compiledAuditEntries, auditCategoryFilter, auditSearchQuery]);

  // Export CSV Handler
  const exportAuditLedgerToCSV = () => {
    const headers = ["Audit Event ID", "Timestamp", "Category", "Title", "Performed By", "Summary Details", "Secondary Detail", "Remarks / Notes"];
    const rows = filteredAuditEntries.map((e) => [
      `"${e.id}"`,
      `"${new Date(e.timestamp).toLocaleString()}"`,
      `"${e.categoryBadge}"`,
      `"${e.title.replace(/"/g, '""')}"`,
      `"${e.performedBy}"`,
      `"${e.summary.replace(/"/g, '""')}"`,
      `"${(e.secondaryDetail || "").replace(/"/g, '""')}"`,
      `"${(e.notes || "").replace(/"/g, '""')}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Payroll_Statutory_Compliance_Audit_Ledger_${new Date().toISOString().substring(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // General Simple Table Pagination logic
  const paginate = (items: any[]) => {
    const startIndex = (currentPage - 1) * pageSize;
    return items.slice(startIndex, startIndex + pageSize);
  };

  return (
    <div className="space-y-6 relative" id="payroll-workspace-root">
      {/* Demo Watermark for onscreen and printed output to prevent misuse */}
      {activeFarm?.email === "mabalademo@mabala.cloud" && (
        <>
          {/* Print only watermark */}
          <div className="hidden print:flex fixed inset-0 items-center justify-center pointer-events-none opacity-[0.06] z-[9999] select-none rotate-[-45deg] text-[120px] font-black tracking-widest text-black whitespace-nowrap">
            MABALA DEMO
          </div>
          {/* Onscreen subtle watermark */}
          <div className="absolute inset-0 pointer-events-none opacity-[0.03] overflow-hidden select-none flex items-center justify-center z-[50]">
            <div className="rotate-[-45deg] text-[90px] font-black tracking-wider text-slate-800 whitespace-nowrap">
              MABALA DEMO
            </div>
          </div>
        </>
      )}

      {/* Tab Menu Header */}
      <div className="flex justify-between items-center bg-white p-3 rounded-2xl border border-slate-200 shadow-sm flex-wrap gap-4">
        <div className="flex gap-2 bg-slate-100 p-0.5 rounded-lg text-xs font-bold border flex-wrap">
          <button 
            onClick={() => { setActiveTab("register"); setCurrentPage(1); }} 
            className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${activeTab === "register" ? "bg-white text-slate-900 shadow-xs text-emerald-800 font-extrabold" : "text-slate-500 hover:text-slate-700"}`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Worker Register ({effectiveEmployees.length})</span>
          </button>
          <button 
            onClick={() => setActiveTab("run")} 
            className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${activeTab === "run" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500 hover:text-slate-700"}`}
          >
            <Coins className="w-3.5 h-3.5" />
            <span>Process Payroll</span>
          </button>
          <button 
            onClick={() => { setActiveTab("history"); setCurrentPage(1); }} 
            className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${activeTab === "history" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500 hover:text-slate-700"}`}
          >
            <ClipboardList className="w-3.5 h-3.5" />
            <span>Payroll History</span>
          </button>
          <button 
            onClick={() => { setActiveTab("statutory"); setCurrentPage(1); }} 
            className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${activeTab === "statutory" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500 hover:text-slate-700"}`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Statutory Remittance</span>
          </button>
          <button 
            onClick={() => { setActiveTab("adjustments"); setCurrentPage(1); }} 
            className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${activeTab === "adjustments" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500 hover:text-slate-700"}`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Staff Adjustments ({adjustmentLogs.length})</span>
          </button>
          <button 
            onClick={() => { setActiveTab("leaves"); setCurrentPage(1); }} 
            className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${activeTab === "leaves" ? "bg-white text-slate-900 shadow-xs text-indigo-500 font-extrabold" : "text-slate-505 hover:text-slate-700"}`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Leave Tracker ({leaveRecords.length})</span>
          </button>
          <button 
            onClick={() => { setActiveTab("advances"); setCurrentPage(1); }} 
            className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${activeTab === "advances" ? "bg-white text-slate-900 shadow-xs text-emerald-500 font-extrabold" : "text-slate-505 hover:text-slate-700"}`}
          >
            <PiggyBank className="w-3.5 h-3.5" />
            <span>Advances Register ({employeeAdvances.length})</span>
          </button>
          <button 
            onClick={() => { setActiveTab("bulk-import"); setCurrentPage(1); }} 
            className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${activeTab === "bulk-import" ? "bg-white text-slate-900 shadow-xs text-emerald-800 font-extrabold" : "text-slate-505 hover:text-slate-700"}`}
          >
            <UploadCloud className="w-3.5 h-3.5" />
            <span>Bulk Register</span>
          </button>
          <button 
            onClick={() => { setActiveTab("audit-history"); setCurrentPage(1); }} 
            className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${activeTab === "audit-history" ? "bg-white text-slate-900 shadow-xs text-amber-800 font-extrabold" : "text-slate-500 hover:text-slate-700"}`}
          >
            <History className="w-3.5 h-3.5 text-amber-600" />
            <span>Payroll Audit History ({compiledAuditEntries.length})</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {!isReadonly && (
            <>
              <button 
                onClick={() => setActiveTab("bulk-import")}
                className="px-3.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/80 rounded-xl text-xs font-bold font-sans cursor-pointer transition-all shadow-2xs flex items-center gap-1.5"
              >
                <UploadCloud className="w-3.5 h-3.5 text-emerald-600" />
                <span>Bulk Import CSV</span>
              </button>
              <button 
                onClick={() => setShowAddWorker(true)}
                className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold font-sans cursor-pointer transition-all shadow-sm flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5 text-emerald-400" />
                <span>Register Worker Contract</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Birthday Notification Banner */}
      {(() => {
        const upcomingBdays = effectiveEmployees.map(emp => {
          const status = getBirthdayStatus(emp.dateOfBirth);
          const age = calculateAge(emp.dateOfBirth);
          return { emp, status, age };
        }).filter(item => item.status !== null);

        if (upcomingBdays.length === 0) return null;

        return (
          <div className="bg-gradient-to-r from-amber-50 via-orange-50 to-amber-50 border border-amber-200/80 rounded-2xl p-4 flex items-center justify-between shadow-xs animate-fade-in flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-600 font-bold text-xl shrink-0 shadow-xs">
                🎂
              </div>
              <div>
                <h4 className="text-xs font-extrabold uppercase text-amber-950 tracking-wider flex items-center gap-2">
                  <span>Farm Owner Birthday Alert & Staff Age Tracker</span>
                  <span className="bg-amber-200 text-amber-900 text-[10px] px-2 py-0.5 rounded-full font-mono font-extrabold">{upcomingBdays.length} Notice{upcomingBdays.length > 1 ? "s" : ""}</span>
                </h4>
                <div className="text-xs text-amber-900 mt-1 flex flex-wrap gap-x-4 gap-y-1">
                  {upcomingBdays.map(({ emp, status, age }) => (
                    <span key={emp.id} className="font-medium">
                      🎉 <strong className="text-amber-950">{emp.name}</strong> ({emp.role}) turns <span className="font-extrabold text-amber-950 font-mono">{age !== null ? age + 1 : "next age"}</span> on <span className="font-mono underline">{emp.dateOfBirth}</span> {status?.isToday ? <span className="bg-rose-500 text-white px-1.5 py-0.5 rounded text-[10px] font-extrabold animate-pulse ml-1">TODAY!</span> : <span className="text-amber-700 text-[11px]">(This Month)</span>}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <button 
              onClick={() => setActiveTab("register")}
              className="px-3.5 py-1.5 bg-amber-700 hover:bg-amber-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs shrink-0 cursor-pointer"
            >
              View Worker Register →
            </button>
          </div>
        );
      })()}

      {/* Configuration tax bands bar */}
      <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 flex flex-wrap justify-between items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-emerald-400" />
            <h3 className="font-extrabold text-xs uppercase tracking-widest text-[#f8fafc]">Compliance Configurator</h3>
          </div>
          <p className="text-[11px] text-slate-400">
            {isZambia 
              ? "Zambia Tax Authority Cap 331 PAYE bands and NAPSA pension contribution rates activated." 
              : "Generic African country default flat deductions configured (10% PAYE, 5% Pension)."}
          </p>
        </div>
        
        {isZambia && (
          <div className="flex gap-4 items-center">
            <div className="text-xs">
              <span className="text-slate-400 block text-[9px] uppercase font-bold">ZRA Threshold</span>
              <div className="flex items-center gap-1 mt-0.5">
                <span className="text-slate-400 text-[10px] font-mono">ZK</span>
                <input 
                  type="number" 
                  value={zraThreshold} 
                  onChange={e => setZraThreshold(Number(e.target.value))}
                  className="w-16 bg-slate-800 border border-slate-700 rounded px-1.5 py-0.5 font-bold font-mono text-emerald-400 text-xs" 
                />
              </div>
            </div>
            <div className="text-xs">
              <span className="text-slate-400 block text-[9px] uppercase font-bold">PAYE Tier Rate</span>
              <div className="flex items-center gap-1 mt-0.5">
                <input 
                  type="number" 
                  value={taxRate} 
                  onChange={e => setTaxRate(Number(e.target.value))}
                  className="w-12 bg-slate-800 border border-slate-700 rounded px-1.5 py-0.5 font-bold font-mono text-emerald-400 text-xs" 
                />
                <span className="text-slate-400">%</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Add Worker Form Modal-In-Place */}
      {showAddWorker && (
        <form onSubmit={handleCreateEmployee} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6 animate-fade-in" id="add-employee-form">
          <div className="flex justify-between items-center border-b pb-3">
            <h4 className="text-xs uppercase font-extrabold text-slate-800 tracking-wider flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-600" />
              <span>Register Worker Contract & Direct Allowances</span>
            </h4>
            <span className="text-xs bg-slate-100 text-slate-600 font-bold px-2.5 py-1 rounded-full text-[10px] font-mono">STEP 1</span>
          </div>

          {/* Form grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Employee Full Name *</label>
              <input 
                type="text" 
                placeholder="e.g. Kondwani Mwape" 
                value={name} 
                onChange={e => setName(e.target.value)} 
                required 
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-medium" 
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Employment Status *</label>
              <select
                value={employmentStatus}
                onChange={(e) => setEmploymentStatus(e.target.value as EmploymentStatus)}
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-semibold text-slate-800"
              >
                <option value="Permanent">Permanent Staff</option>
                <option value="Casual Worker">Casual Worker</option>
                <option value="Part Time">Part Time Worker</option>
                <option value="Probation">Probation Contract</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Farm Role / Designation *</label>
              <select
                value={isCustomRole ? "Custom" : role}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === "Custom") {
                    setIsCustomRole(true);
                    setRole("");
                  } else {
                    setIsCustomRole(false);
                    setRole(val);
                  }
                }}
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-semibold text-slate-700"
              >
                <option value="Farm Manager">Farm Manager</option>
                <option value="Farm Supervisor">Farm Supervisor</option>
                <option value="Field Staff">Field Staff</option>
                <option value="General Field Hand">General Field Hand</option>
                <option value="Tractor Operator">Tractor Operator</option>
                <option value="Accountant">Accountant</option>
                <option value="Driver">Driver</option>
                <option value="Technician">Technician</option>
                <option value="Agronomist">Agronomist</option>
                <option value="Vet">Vet</option>
                <option value="Custom">Custom Role...</option>
              </select>
              {isCustomRole && (
                <div className="mt-2 animate-fade-in">
                  <input 
                    type="text" 
                    placeholder="e.g. Poultry Section Lead" 
                    value={role} 
                    onChange={e => setRole(e.target.value)} 
                    required 
                    className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500" 
                  />
                </div>
              )}
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Contract Agreement Type</label>
              <select
                value={contractType}
                onChange={(e) => setContractType(e.target.value)}
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-semibold text-slate-700"
              >
                <option value="Indefinite Contract">Indefinite Contract</option>
                <option value="2-Year Fixed Term">2-Year Fixed Term</option>
                <option value="1-Year Fixed Term">1-Year Fixed Term</option>
                <option value="Daily Casual Rate">Daily Casual Rate</option>
                <option value="6-Month Probation">6-Month Probation</option>
                <option value="Seasonal Crop Contract">Seasonal Crop Contract</option>
              </select>
            </div>
          </div>

          {/* Contract Start & Personal Details */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Contract Start Date *</label>
              <input 
                type="date" 
                value={contractStartDate} 
                onChange={e => setContractStartDate(e.target.value)} 
                required
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-mono" 
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Contract Expiry / End Date</label>
              <input 
                type="date" 
                value={contractEndDate} 
                onChange={e => setContractEndDate(e.target.value)} 
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-mono" 
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Date of Birth (DOB) *</label>
              <input 
                type="date" 
                value={dateOfBirth} 
                onChange={e => setDateOfBirth(e.target.value)} 
                required
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-mono" 
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Marital Status *</label>
              <select
                value={maritalStatus}
                onChange={(e) => setMaritalStatus(e.target.value as MaritalStatus)}
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-semibold text-slate-700"
              >
                <option value="Married">Married</option>
                <option value="Single">Single</option>
                <option value="Divorced">Divorced</option>
                <option value="Widowed">Widowed</option>
                <option value="Separated">Separated</option>
              </select>
            </div>
          </div>

          {/* Next of Kin & National ID */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <span className="text-[10px] uppercase font-extrabold text-slate-500 block tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-slate-600" />
              <span>Next of Kin Details & National Registration</span>
            </span>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Next of Kin Full Name</label>
                <input 
                  type="text" 
                  placeholder="e.g. Chipo Mwape" 
                  value={nextOfKinName} 
                  onChange={e => setNextOfKinName(e.target.value)} 
                  className="w-full text-xs border bg-white rounded p-2 mt-1 font-medium" 
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Next of Kin Contact Phone</label>
                <input 
                  type="text" 
                  placeholder="e.g. +260 977 123456" 
                  value={nextOfKinContact} 
                  onChange={e => setNextOfKinContact(e.target.value)} 
                  className="w-full text-xs border bg-white rounded p-2 mt-1 font-mono" 
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Relationship to Employee</label>
                <select
                  value={nextOfKinRelationship}
                  onChange={(e) => setNextOfKinRelationship(e.target.value)}
                  className="w-full text-xs border bg-white rounded p-2 mt-1 font-semibold text-slate-700"
                >
                  <option value="Spouse">Spouse</option>
                  <option value="Parent">Parent</option>
                  <option value="Child">Child</option>
                  <option value="Sibling">Sibling</option>
                  <option value="Relative">Relative</option>
                  <option value="Guardian">Guardian</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">NRC / National ID Number</label>
                <input 
                  type="text" 
                  placeholder="e.g. 284719/11/1" 
                  value={nrcNumber} 
                  onChange={e => setNrcNumber(e.target.value)} 
                  className="w-full text-xs border bg-white rounded p-2 mt-1 font-mono" 
                />
              </div>
            </div>
          </div>

          {/* Basic Pay & Direct Allowances */}
          <div className="grid grid-cols-1 md:grid-cols-6 gap-3">
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Basic Monthly Pay ({currencySymbol}) *</label>
              <input 
                type="number" 
                value={contractRate} 
                onChange={e => setContractRate(Number(e.target.value))} 
                required 
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-mono font-bold text-slate-800" 
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Housing Allowance</label>
              <input 
                type="number" 
                value={housingAllowance} 
                onChange={e => setHousingAllowance(Number(e.target.value))} 
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-mono" 
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Transport Allowance</label>
              <input 
                type="number" 
                value={transportAllowance} 
                onChange={e => setTransportAllowance(Number(e.target.value))} 
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-mono" 
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Medical Allowance</label>
              <input 
                type="number" 
                value={medicalAllowance} 
                onChange={e => setMedicalAllowance(Number(e.target.value))} 
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-mono" 
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Field Allowance</label>
              <input 
                type="number" 
                value={fieldAllowance} 
                onChange={e => setFieldAllowance(Number(e.target.value))} 
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-mono" 
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">Other Allowance</label>
              <input 
                type="number" 
                value={otherAllowance} 
                onChange={e => setOtherAllowance(Number(e.target.value))} 
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-mono" 
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">NAPSA Pension Account Number</label>
              <input 
                type="text" 
                placeholder="e.g. NP4409184" 
                value={napsaNumber} 
                onChange={e => setNapsaNumber(e.target.value)} 
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-mono" 
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-extrabold text-slate-500">NHIMA Health Number</label>
              <input 
                type="text" 
                placeholder="e.g. NHI89100234" 
                value={nhimaNumber} 
                onChange={e => setNhimaNumber(e.target.value)} 
                className="w-full text-xs border bg-slate-50 rounded p-2 focus:bg-white outline-emerald-500 mt-1 font-mono" 
              />
            </div>
          </div>

          {/* Payment execution configuration */}
          <div className="p-4 bg-emerald-50/40 rounded-xl border border-emerald-200 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-extrabold text-emerald-800 block tracking-widest flex items-center gap-1.5">
                <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                <span>Mobile Money Disbursement Channel (Required for Lipila Payroll)</span>
              </span>
              <span className="text-[9px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                Automated MNO Payout
              </span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-600">Mobile Money Network *</label>
                <select 
                  value={mobileMoneyProvider} 
                  onChange={e => {
                    setMobileMoneyProvider(e.target.value as "airtel" | "mtn" | "zamtel");
                    setMobileMoneyVerified(false);
                  }}
                  className="w-full text-xs border border-slate-300 bg-white rounded-lg p-2 mt-1 font-semibold text-slate-800"
                >
                  <option value="mtn">MTN Mobile Money (MoMo)</option>
                  <option value="airtel">Airtel Money</option>
                  <option value="zamtel">Zamtel Kwacha</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-600">Zambian Mobile Number *</label>
                <div className="flex gap-2 mt-1">
                  <input 
                    type="text" 
                    required 
                    placeholder="0977123456" 
                    value={mobileMoneyNumber || walletNumber} 
                    onChange={e => {
                      const clean = e.target.value.replace(/\D/g, "").slice(0, 10);
                      setMobileMoneyNumber(clean);
                      setWalletNumber(clean);
                      setMobileMoneyVerified(false);
                      setVerifiedAccountName("");
                      setMomoVerificationError(null);
                    }} 
                    className="w-full text-xs border border-slate-300 bg-white rounded-lg p-2 font-mono font-bold text-slate-800 focus:outline-emerald-500" 
                  />
                  <button
                    type="button"
                    onClick={handleVerifyMomoAccountInForm}
                    disabled={isVerifyingMomo || !(mobileMoneyNumber || walletNumber)}
                    className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-lg text-xs font-bold shrink-0 flex items-center gap-1 cursor-pointer transition-all shadow-xs"
                  >
                    {isVerifyingMomo ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <CheckCircle className="w-3.5 h-3.5" />
                    )}
                    <span>Verify</span>
                  </button>
                </div>
                {momoVerificationError && (
                  <p className="text-[10px] text-rose-600 font-semibold mt-1">{momoVerificationError}</p>
                )}
              </div>

              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-600">Verification Status</label>
                <div className="mt-1 p-2 bg-white rounded-lg border border-slate-200 min-h-[38px] flex items-center">
                  {mobileMoneyVerified ? (
                    <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="truncate">Verified: {verifiedAccountName || name || "Registered MNO Account"}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 text-amber-700 text-xs font-medium">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                      <span className="text-[11px]">Unverified (Click Verify to validate via Lipila)</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100 flex justify-between items-center text-xs">
            <span className="font-semibold text-slate-600">Dynamic Live Contract Pro-forma Gross Salary Summary:</span>
            <div className="font-mono font-extrabold text-emerald-800 text-sm">
              Basic ({currencySymbol} {contractRate.toLocaleString()}) + Allowances ({currencySymbol} {(housingAllowance + transportAllowance + otherAllowance).toLocaleString()}) = <span className="underline">{currencySymbol} {computedGrossSalary.toLocaleString()}</span>
            </div>
          </div>

          <div className="flex justify-end gap-2 border-t pt-4">
            <button type="button" onClick={() => setShowAddWorker(false)} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold">Cancel</button>
            <button type="submit" className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-md">Register Active Contract</button>
          </div>
        </form>
      )}

      {/* BULK IMPORT TAB CONTENT */}
      {activeTab === "bulk-import" && (
        <BulkEmployeeImportPanel
          existingEmployees={effectiveEmployees}
          onBulkAddEmployees={(newEmps) => {
            if (onBulkAddEmployees) {
              onBulkAddEmployees(newEmps);
            } else {
              newEmps.forEach(e => onAddEmployee(e));
            }
          }}
          currencySymbol={currencySymbol}
          isReadonly={isReadonly}
          isZambia={isZambia}
          onSuccessNavigate={() => setActiveTab("register")}
        />
      )}

      {/* EMPLOYEE REGISTER TAB CONTENT */}
      {activeTab === "register" && (
        <div className="space-y-6">
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider block">Total Registered Workforce</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl font-black text-slate-900 font-mono">{effectiveEmployees.length}</span>
                <span className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full font-bold">Workers</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider block">Permanent Staff</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl font-black text-emerald-600 font-mono">
                  {effectiveEmployees.filter(e => (e.employmentStatus || "Permanent") === "Permanent" && e.status !== "Terminated" && e.status !== "Resigned").length}
                </span>
                <span className="text-xs bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full font-bold">Active</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider block">Casuals & Probation</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl font-black text-amber-600 font-mono">
                  {effectiveEmployees.filter(e => ["Casual Worker", "Probation", "Part Time"].includes(e.employmentStatus || "")).length}
                </span>
                <span className="text-xs bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full font-bold">Contract</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider block">Monthly Gross Obligation</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-xl font-black text-indigo-900 font-mono">
                  {currencySymbol} {effectiveEmployees.reduce((acc, e) => acc + ((e.contractRate || 0) + (e.housingAllowance || 0) + (e.transportAllowance || 0) + (e.medicalAllowance || 0) + (e.fieldAllowance || 0) + (e.otherAllowance || 0)), 0).toLocaleString()}
                </span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider block">Birthdays This Month</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl font-black text-rose-500 font-mono">
                  {effectiveEmployees.filter(e => getBirthdayStatus(e.dateOfBirth)?.isThisMonth).length}
                </span>
                <span className="text-xs bg-rose-50 text-rose-700 px-2 py-0.5 rounded-full font-bold">🎂 Notice</span>
              </div>
            </div>
          </div>

          {/* Controls & Table Container */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-5">
            <div className="flex justify-between items-center flex-wrap gap-4 border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3 flex-1 min-w-[280px]">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input 
                    type="text"
                    placeholder="Search worker by name, role, NRC, Next of Kin, ID..."
                    value={registerSearch}
                    onChange={e => setRegisterSearch(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-xs bg-slate-50 focus:bg-white focus:outline-emerald-500 transition-all font-medium"
                  />
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <Filter className="w-3.5 h-3.5 text-slate-500" />
                  <select 
                    value={registerStatusFilter} 
                    onChange={e => setRegisterStatusFilter(e.target.value)}
                    className="text-xs border border-slate-200 bg-slate-50 rounded-xl px-3 py-2 font-bold text-slate-700 focus:outline-none"
                  >
                    <option value="All">All Statuses</option>
                    <option value="Permanent">Permanent</option>
                    <option value="Casual Worker">Casual Worker</option>
                    <option value="Probation">Probation</option>
                    <option value="Part Time">Part Time</option>
                    <option value="Active">Active Only</option>
                    <option value="Terminated">Terminated</option>
                    <option value="Resigned">Resigned</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportRegisterCSV}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-slate-200"
                >
                  <Download className="w-3.5 h-3.5 text-slate-600" />
                  <span>Export CSV</span>
                </button>
                <button
                  onClick={() => setShowPrintRegisterModal(true)}
                  className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Print Register</span>
                </button>
              </div>
            </div>

            {/* Employee Register Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-extrabold uppercase text-slate-500 tracking-wider">
                    <th className="p-3">Worker ID & Name</th>
                    <th className="p-3">Role & Status</th>
                    <th className="p-3">Age & Kin</th>
                    <th className="p-3 text-right">Basic Pay</th>
                    <th className="p-3 text-right">Allowances</th>
                    <th className="p-3 text-right">Gross Salary</th>
                    <th className="p-3">Disbursement Route</th>
                    <th className="p-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {effectiveEmployees
                    .filter(emp => {
                      const matchesSearch = registerSearch === "" || 
                        emp.name.toLowerCase().includes(registerSearch.toLowerCase()) ||
                        emp.role.toLowerCase().includes(registerSearch.toLowerCase()) ||
                        emp.id.toLowerCase().includes(registerSearch.toLowerCase()) ||
                        (emp.nrcNumber && emp.nrcNumber.toLowerCase().includes(registerSearch.toLowerCase())) ||
                        (emp.nextOfKinName && emp.nextOfKinName.toLowerCase().includes(registerSearch.toLowerCase()));

                      const matchesFilter = registerStatusFilter === "All" ||
                        (registerStatusFilter === "Active" && emp.status === "Active") ||
                        (emp.employmentStatus === registerStatusFilter) ||
                        (emp.status === registerStatusFilter);

                      return matchesSearch && matchesFilter;
                    })
                    .map(emp => {
                      const age = calculateAge(emp.dateOfBirth);
                      const bdayStatus = getBirthdayStatus(emp.dateOfBirth);
                      const totalAllowances = (emp.housingAllowance || 0) + (emp.transportAllowance || 0) + (emp.medicalAllowance || 0) + (emp.fieldAllowance || 0) + (emp.otherAllowance || 0);
                      const gross = emp.contractRate + totalAllowances;

                      return (
                        <tr key={emp.id} className="hover:bg-slate-50/80 transition-colors group">
                          <td className="p-3 font-medium text-slate-900">
                            <div className="flex items-center gap-2">
                              <div>
                                <div className="font-extrabold text-slate-900 flex items-center gap-1.5">
                                  <span>{emp.name}</span>
                                  {bdayStatus?.isThisMonth && (
                                    <span className="bg-amber-100 text-amber-900 text-[9px] px-1.5 py-0.5 rounded-full font-extrabold flex items-center gap-0.5">
                                      🎂 {bdayStatus.isToday ? "TODAY!" : `Day ${bdayStatus.day}`}
                                    </span>
                                  )}
                                </div>
                                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                                  {emp.id} • NRC: {emp.nrcNumber || "N/A"}
                                </div>
                              </div>
                            </div>
                          </td>

                          <td className="p-3">
                            <div className="font-bold text-slate-800">{emp.role}</div>
                            <div className="flex items-center gap-1 mt-0.5">
                              <span className={`px-2 py-0.5 rounded text-[9.5px] font-extrabold ${
                                emp.status === "Terminated" ? "bg-rose-100 text-rose-800" :
                                emp.status === "Resigned" ? "bg-orange-100 text-orange-800" :
                                emp.employmentStatus === "Permanent" ? "bg-emerald-100 text-emerald-800" :
                                emp.employmentStatus === "Casual Worker" ? "bg-amber-100 text-amber-800" :
                                emp.employmentStatus === "Probation" ? "bg-indigo-100 text-indigo-800" :
                                "bg-slate-100 text-slate-700"
                              }`}>
                                {emp.status === "Terminated" ? "Terminated" : emp.status === "Resigned" ? "Resigned" : (emp.employmentStatus || "Permanent")}
                              </span>
                            </div>
                          </td>

                          <td className="p-3">
                            <div className="text-slate-800 font-medium">
                              Age: <strong className="font-mono">{age !== null ? `${age} yrs` : "N/A"}</strong> ({emp.maritalStatus || "N/A"})
                            </div>
                            <div className="text-[10px] text-slate-500 mt-0.5">
                              Kin: <span className="font-semibold">{emp.nextOfKinName || emp.nextOfKin?.name || "N/A"}</span> ({emp.nextOfKinRelationship || emp.nextOfKin?.relationship || "Spouse"}) • {emp.nextOfKinContact || emp.nextOfKin?.contactNumber || ""}
                            </div>
                          </td>

                          <td className="p-3 text-right font-mono font-extrabold text-slate-800">
                            {currencySymbol} {emp.contractRate.toLocaleString()}
                          </td>

                          <td className="p-3 text-right font-mono text-slate-600">
                            {currencySymbol} {totalAllowances.toLocaleString()}
                          </td>

                          <td className="p-3 text-right font-mono font-black text-emerald-700 bg-emerald-50/50 rounded-lg">
                            {currencySymbol} {gross.toLocaleString()}
                          </td>

                          <td className="p-3 text-slate-700">
                            <div className="flex items-center gap-1.5 font-semibold text-[11px]">
                              <span className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase ${
                                (emp.mobileMoneyProvider || "").toLowerCase() === "airtel" ? "bg-red-50 text-red-700 border border-red-200" :
                                (emp.mobileMoneyProvider || "").toLowerCase() === "zamtel" ? "bg-green-50 text-green-700 border border-green-200" :
                                "bg-amber-50 text-amber-800 border border-amber-200"
                              }`}>
                                {emp.mobileMoneyProvider ? emp.mobileMoneyProvider.toUpperCase() : "MTN"}
                              </span>
                              <span>{maskMobileNumber(emp.mobileMoneyNumber || emp.walletNumber || emp.mobileNumber || "")}</span>
                            </div>
                            <div className="flex items-center gap-1 mt-1 text-[10px]">
                              {emp.mobileMoneyVerified ? (
                                <span className="inline-flex items-center gap-1 text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 text-[9px]">
                                  <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                                  <span>Verified</span>
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleVerifyEmployeeInTable(emp)}
                                  disabled={verifyingEmployeeId === emp.id}
                                  className="inline-flex items-center gap-1 text-amber-800 font-bold bg-amber-50 hover:bg-amber-100 px-1.5 py-0.5 rounded border border-amber-200 text-[9px] cursor-pointer"
                                >
                                  {verifyingEmployeeId === emp.id ? (
                                    <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                                  ) : (
                                    <AlertCircle className="w-2.5 h-2.5 text-amber-600" />
                                  )}
                                  <span>Verify Account</span>
                                </button>
                              )}
                              {emp.verifiedAccountName && (
                                <span className="text-slate-400 truncate max-w-[110px]" title={emp.verifiedAccountName}>
                                  {emp.verifiedAccountName}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="p-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {!isReadonly && (
                                <>
                                  <button
                                    onClick={() => setEditingEmp(emp)}
                                    title="Edit Worker Contract & Personal Details"
                                    className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-all"
                                  >
                                    <Edit className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => openStaffAdjustmentModal(emp)}
                                    title="Promote / Terminate / Resign / Pay Change"
                                    className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                  >
                                    <Award className="w-3.5 h-3.5" />
                                  </button>
                                  {onDeleteEmployee && (
                                    <button
                                      onClick={async () => {
                                        const ok = await confirm({
                                          title: "Delete Worker Record",
                                          message: `Are you sure you want to delete ${emp.name} from the register?`,
                                          confirmText: "Delete",
                                          type: "danger"
                                        });
                                        if (ok) onDeleteEmployee(emp.id);
                                      }}
                                      title="Delete Worker"
                                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* PROCESS TAB CONTENT */}
      {activeTab === "run" && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center flex-wrap gap-4">
              <div>
                <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Configure Current Staff Run</h4>
                <p className="text-[11px] text-slate-500 leading-normal">Exclude specific workers, adjust salary, or update allowances on demand prior to committing calculation sheets.</p>
              </div>

              <div className="flex items-center gap-3">
                <div>
                  <label className="text-[9px] uppercase font-mono font-bold text-slate-400 block mb-1">Target Month</label>
                  <input 
                    type="month" 
                    value={activeMonth} 
                    onChange={e => setActiveMonth(e.target.value)} 
                    className="text-xs border rounded-lg px-2.5 py-1 text-slate-700 bg-white font-bold" 
                  />
                </div>
                <div>
                  <label className="text-[9px] uppercase font-mono font-bold text-slate-400 block mb-1">Execution controls</label>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={executePayrollRun}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold rounded-lg shadow-md cursor-pointer transition-all"
                    >
                      Post Monthly Payroll Run
                    </button>
                    <button 
                      type="button"
                      onClick={() => setShowLipilaDisbursementModal(true)}
                      className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-lg shadow-sm cursor-pointer transition-all flex items-center gap-1.5 border border-amber-400/80 hover:scale-[1.02] active:scale-[0.98]"
                      title="Disburse salaries via Lipila B2C Bulk Mobile Money Gateway (Out Button)"
                    >
                      <ArrowUpRight className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>Out (Lipila Disburse)</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="p-3 text-center w-12">
                        <input 
                          type="checkbox" 
                          checked={selectedEmployeeIds.length === employees.filter(e => e.status === "Active").length && employees.filter(e => e.status === "Active").length > 0} 
                          onChange={handleSelectAll}
                          className="w-3.5 h-3.5 accent-emerald-600"
                        />
                      </th>
                      <th className="p-3">Staff Member</th>
                      <th className="p-3">Payment details</th>
                      <th className="p-3">Allowances</th>
                      <th className="p-3">Deductions</th>
                      <th className="p-3 text-right">Computed Net Cash</th>
                      <th className="p-3 text-center">Adjust Rate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-semibold text-slate-800">
                    {paginate(employees.filter(e => e.status === "Active")).map(emp => {
                      const isIncluded = selectedEmployeeIds.includes(emp.id);
                      
                      // Find if there is an active calculation sheet
                      const slip = calculatedSlips.find(s => s.employeeId === emp.id);
                      const hasAdjusted = !!adjustments[emp.id];

                      return (
                        <tr key={emp.id} className={`hover:bg-slate-50/50 ${!isIncluded ? "opacity-50 select-none bg-slate-50/20" : ""}`}>
                          <td className="p-3 text-center">
                            <input 
                              type="checkbox" 
                              checked={isIncluded} 
                              onChange={() => handleToggleSelectEmployee(emp.id)}
                              className="w-3.5 h-3.5 accent-emerald-600"
                            />
                          </td>
                          <td className="p-3">
                            <span className="block font-bold text-slate-950">{emp.name}</span>
                            <span className="text-[10px] text-slate-400 italic block">{emp.role} {hasAdjusted && <span className="text-amber-500 font-bold ml-1">★ Adjusted</span>}</span>
                          </td>
                          <td className="p-3">
                            <span className="text-[10px] font-mono text-slate-500 block">{emp.paymentMethod}</span>
                            <span className="text-[9px] text-slate-400 block font-mono">
                              {emp.paymentMethod === "Bank Transfer" ? `${emp.bankName} - ${emp.bankAccount}` : emp.walletNumber}
                            </span>
                          </td>
                          <td className="p-3 text-[10px] leading-relaxed">
                            {slip ? (
                              <div className="font-medium text-slate-600">
                                <div>Basic: <span className="font-mono font-bold text-slate-800">{currencySymbol}{slip.basicSalary}</span></div>
                                <div>All allowances: <span className="font-mono font-bold text-slate-800">{currencySymbol}{(slip.housingAllowance + slip.transportAllowance + slip.otherAllowance)}</span></div>
                                <div className="text-[9px] text-[#22c55e]">Gross: <span className="font-mono font-bold">{currencySymbol}{slip.grossSalary}</span></div>
                              </div>
                            ) : (
                              <span className="text-slate-400 italic">Excluded</span>
                            )}
                          </td>
                          <td className="p-3 text-[10px]">
                            {slip ? (
                              <div className="font-semibold text-rose-500">
                                <div>PAYE Tax: <span className="font-mono">{currencySymbol}{slip.paye.toFixed(2)}</span></div>
                                <div>NAPSA Pension: <span className="font-mono">{currencySymbol}{slip.napsaEmployee.toFixed(2)}</span></div>
                                {isZambia && <div>NHIMA: <span className="font-mono">{currencySymbol}{slip.nhimaEmployee.toFixed(2)}</span></div>}
                              </div>
                            ) : (
                              <span className="text-slate-400 italic">Excluded</span>
                            )}
                          </td>
                          <td className="p-3 text-right font-mono font-extrabold text-emerald-600">
                            {slip ? `${currencySymbol} ${slip.netPay.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : "-"}
                          </td>
                          <td className="p-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                type="button"
                                disabled={!isIncluded}
                                onClick={() => openAdjustmentModal(emp)}
                                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold rounded-lg border cursor-pointer disabled:opacity-30"
                              >
                                Edit / Override
                              </button>
                              {!isReadonly && onDeleteEmployee && (
                                <button
                                  type="button"
                                  onClick={async () => {
                                    const ok = await confirm({
                                      title: "Delete Employee Record",
                                      message: `Are you sure you want to delete and soft-delete employee "${emp.name}" to the dynamic compliance archive?`,
                                      confirmText: "Delete",
                                      cancelText: "Cancel",
                                      type: "danger"
                                    });
                                    if (ok) {
                                      onDeleteEmployee(emp.id);
                                    }
                                  }}
                                  className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors cursor-pointer"
                                  title="Delete Employee"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}

                    {employees.length === 0 && (
                      <tr>
                        <td colSpan={7} className="p-12 text-center">
                          <div className="max-w-md mx-auto space-y-3">
                            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 border border-indigo-100 flex items-center justify-center mx-auto shadow-xs">
                              <Users className="w-6 h-6" />
                            </div>
                            <h4 className="text-sm font-black text-slate-900">No Registered Farm Employees</h4>
                            <p className="text-xs text-slate-500 leading-relaxed">
                              You have not registered any employees on your farm payroll ledger yet. Please add a new employee or generate a digital employment contract to record statutory deductions, mobile money wage payouts, and shifts.
                            </p>
                            {!isReadonly && (
                              <div className="pt-1">
                                <button
                                  type="button"
                                  onClick={() => setShowAddWorker(true)}
                                  className="px-4 py-2 bg-slate-950 hover:bg-slate-800 text-white rounded-xl text-xs font-bold font-mono inline-flex items-center gap-2 shadow-xs transition cursor-pointer"
                                >
                                  <UserPlus className="w-4 h-4 text-emerald-400" />
                                  <span>+ Register New Employee</span>
                                </button>
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Dynamic Table Pagination details */}
              {employees.length > 0 && (
                <div className="flex justify-between items-center mt-4 pt-4 border-t border-slate-100 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 text-[11px]">Show rows per page:</span>
                    <select 
                      value={pageSize} 
                      onChange={e => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
                      className="border rounded p-1 text-xs font-semibold bg-white"
                    >
                      <option value={10}>10 items</option>
                      <option value={50}>50 items</option>
                      <option value={100}>100 items</option>
                    </select>
                  </div>
                  <div className="flex gap-1.5">
                    <button 
                      onClick={() => setCurrentPage(p => Math.max(p - 1, 1))} 
                      disabled={currentPage === 1}
                      className="px-2.5 py-1 rounded border bg-white enabled:hover:bg-slate-50 text-[11px] font-bold disabled:opacity-40"
                    >
                      Prev
                    </button>
                    <span className="px-3 py-1 bg-slate-50 text-slate-600 rounded font-bold font-mono text-[11px]">
                      Page {currentPage} of {Math.ceil(employees.filter(e => e.status === "Active").length / pageSize) || 1}
                    </span>
                    <button 
                      onClick={() => setCurrentPage(p => Math.min(p + 1, Math.ceil(employees.filter(e => e.status === "Active").length / pageSize)))} 
                      disabled={currentPage >= Math.ceil(employees.filter(e => e.status === "Active").length / pageSize)}
                      className="px-2.5 py-1 rounded border bg-white enabled:hover:bg-slate-50 text-[11px] font-bold disabled:opacity-40"
                    >
                      Next
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="px-6 py-4 bg-emerald-50 text-emerald-800 border-t flex items-center justify-between text-xs font-mono">
              <span>
                → Continuous Postings: Debits Dr 5100 Wages & Salaries | Credits Cr 1010 Bank + Cr 2020/2030 (Accruals)
              </span>
              <span className="font-bold">IFRS COMPLIANT</span>
            </div>
          </div>
        </div>
      )}

      {/* OVERRIDE ADJUSTMENT DIALOG */}
      {editingAdjustmentEmpId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 min-h-screen">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-6 border border-slate-200 animate-scale-up">
            <h4 className="text-sm font-extrabold text-slate-800 uppercase tracking-widest pb-2 border-b">Override Staff Payslip Rate</h4>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Make temporary adjustments to basic salary or allowances for this run. System will automatically log changes and require an adjustment comment.
            </p>

            <div className="space-y-4 mt-4">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500">Basic Salary Override ({currencySymbol})</label>
                <input 
                  type="number" 
                  value={tempBasic} 
                  onChange={e => setTempBasic(Number(e.target.value))} 
                  className="w-full text-xs mt-1 p-2 border rounded font-mono" 
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[9px] uppercase font-bold text-slate-500">Housing</label>
                  <input 
                    type="number" 
                    value={tempHousing} 
                    onChange={e => setTempHousing(Number(e.target.value))} 
                    className="w-full text-xs mt-1 p-1.5 border font-mono" 
                  />
                </div>
                <div>
                  <label className="text-[9px] uppercase font-bold text-slate-500">Transport</label>
                  <input 
                    type="number" 
                    value={tempTransport} 
                    onChange={e => setTempTransport(Number(e.target.value))} 
                    className="w-full text-xs mt-1 p-1.5 border font-mono" 
                  />
                </div>
                <div>
                  <label className="text-[9px] uppercase font-bold text-slate-500">Other</label>
                  <input 
                    type="number" 
                    value={tempOther} 
                    onChange={e => setTempOther(Number(e.target.value))} 
                    className="w-full text-xs mt-1 p-1.5 border font-mono" 
                  />
                </div>
              </div>

              {/* Required comment */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500">Required Comment / Override Reason</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. Added dry season overtime bonus"
                  value={tempReason} 
                  onChange={e => setTempReason(e.target.value)} 
                  className="w-full text-xs mt-1 p-2 border rounded" 
                />
              </div>

              {/* Gross sum & Statutory Pre-fill Preview */}
              {(() => {
                const statConfig = getStatutoryTaxConfig();
                const calc = calculateStatutoryDeductions({
                  basicSalary: tempBasic,
                  housingAllowance: tempHousing,
                  transportAllowance: tempTransport,
                  otherAllowance: tempOther,
                  isZambia,
                  taxConfig: statConfig,
                  customTaxRate: taxRate,
                  customThreshold: zraThreshold,
                });

                return (
                  <div className="p-3.5 bg-slate-900 text-white rounded-xl text-xs space-y-2 border border-slate-800 shadow-inner">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-1.5 font-bold">
                      <span className="text-[10px] uppercase tracking-wider text-emerald-400">⚡ Statutory Auto-Deduction Pre-Fill ({calc.taxSystemDescription})</span>
                      <span className="font-mono text-xs text-slate-200">{currencySymbol} {calc.grossSalary.toLocaleString()} Gross</span>
                    </div>

                    <div className="grid grid-cols-3 gap-1.5 text-[10px] font-mono text-slate-300">
                      <div>PAYE: <span className="text-rose-400 font-bold">{currencySymbol}{calc.paye.toFixed(1)}</span></div>
                      <div>NAPSA (5%): <span className="text-rose-400 font-bold">{currencySymbol}{calc.napsaEmployee.toFixed(1)}</span></div>
                      {isZambia && <div>NHIMA (1%): <span className="text-rose-400 font-bold">{currencySymbol}{calc.nhimaEmployee.toFixed(1)}</span></div>}
                    </div>

                    <div className="flex justify-between items-center pt-1.5 border-t border-slate-800 font-bold text-xs">
                      <span className="text-slate-400">Estimated Net Pre-Fill Pay:</span>
                      <span className="text-emerald-400 font-mono text-sm">{currencySymbol} {calc.netPay.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </div>
                  </div>
                );
              })()}
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t mt-4 text-xs font-semibold">
              <button onClick={() => setEditingAdjustmentEmpId(null)} className="px-4 py-2 bg-slate-100 rounded">Cancel</button>
              <button onClick={saveAdjustment} className="px-5 py-2 bg-emerald-600 text-white rounded font-bold hover:bg-emerald-500">Apply Overrides</button>
            </div>
          </div>
        </div>
      )}

      {/* HISTORY TAB CONTENT */}
      {activeTab === "history" && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="border-b pb-4 flex justify-between items-center flex-wrap gap-4">
            <div>
              <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Historical Monthly Payroll Summary Sheets</h4>
              <p className="text-[11px] text-slate-500">Browse fully finalized payroll sheets grouped by month. Export PDF reports or print custom letterhead slips.</p>
            </div>
            <button 
              onClick={() => generateMockCSV("Payroll History", payslips)}
              className="px-3 py-1.5 border rounded-lg text-xs font-bold hover:bg-slate-50 flex items-center gap-1.5 shadow-sm bg-white"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-slate-500" />
              <span>Export History CSV</span>
            </button>
          </div>

          <div className="divide-y divide-slate-100 space-y-4">
            {postedMonths.map(month => {
              const slipsForMonth = payslips.filter(p => p.month === month);
              const isMonthExpanded = expandedHistoryMonth === month;
              const totalMonthGross = slipsForMonth.reduce((acc, p) => acc + p.grossSalary, 0);
              const totalMonthNet = slipsForMonth.reduce((acc, p) => acc + p.netPay, 0);

              return (
                <div key={month} className="pt-4 first:pt-0 space-y-3">
                  <div 
                    onClick={() => setExpandedHistoryMonth(isMonthExpanded ? null : month)}
                    className="flex justify-between items-center bg-slate-50 p-3.5 rounded-xl border border-slate-200/60 cursor-pointer hover:bg-slate-100/60 transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      {isMonthExpanded ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                      <div>
                        <span className="font-extrabold text-[#0f172a] text-xs uppercase tracking-wider font-mono flex items-center gap-1.5">
                          <Calendar className="w-4 h-4 text-indigo-500" />
                          <span>{month} Summary sheet</span>
                        </span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">{slipsForMonth.length} Staff payslips committed.</span>
                      </div>
                    </div>

                    <div className="flex gap-4 text-xs font-mono font-bold text-slate-800">
                      <div>
                        <span className="text-[9px] uppercase text-slate-400 block font-sans">Total Gross</span>
                        <span>{currencySymbol} {totalMonthGross.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase text-slate-400 block font-sans">Net Disbursed</span>
                        <span className="text-emerald-600">{currencySymbol} {totalMonthNet.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                      </div>
                    </div>
                  </div>

                  {isMonthExpanded && (
                    <div className="pl-6 pr-2 py-2 space-y-3 animate-fade-in">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wide font-mono">Month Payslip itemization</span>
                        <button 
                          onClick={() => triggerPDFPrint(`history-sheet-${month}`)}
                          className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded text-[10px] flex items-center gap-1"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Print Full Monthly Sheet</span>
                        </button>
                      </div>

                      <div className="overflow-x-auto border rounded-xl">
                        <table className="w-full text-left text-xs bg-white text-slate-800">
                          <thead className="text-[9px] uppercase font-bold text-slate-400 bg-slate-50">
                            <tr>
                              <th className="p-2.5">Staff</th>
                              <th className="p-2.5">Method</th>
                              <th className="p-2.5">Basic Pay</th>
                              <th className="p-2.5">Allowances</th>
                              <th className="p-2.5 text-rose-500">Deductions</th>
                              <th className="p-2.5">Net Cash</th>
                              <th className="p-2.5 text-center">Print Slip</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y font-semibold text-slate-800">
                            {slipsForMonth.map(slip => (
                              <tr key={slip.id} className="hover:bg-slate-50/40">
                                <td className="p-2.5">
                                  <span className="block font-bold text-slate-900">{slip.employeeName}</span>
                                  <span className="text-[9px] text-slate-400 block">{slip.id}</span>
                                </td>
                                <td className="p-2.5 font-mono text-[10px] text-slate-500">
                                  {slip.paymentMethod}
                                </td>
                                <td className="p-2.5 font-mono">{currencySymbol} {slip.basicSalary.toLocaleString()}</td>
                                <td className="p-2.5 font-mono text-slate-600">
                                  {currencySymbol} {(slip.housingAllowance + slip.transportAllowance + slip.otherAllowance).toLocaleString()}
                                </td>
                                <td className="p-2.5 font-mono text-rose-500">
                                  {currencySymbol} {(slip.paye + slip.napsaEmployee + slip.nhimaEmployee).toFixed(2)}
                                </td>
                                <td className="p-2.5 font-mono text-emerald-600 font-extrabold">
                                  {currencySymbol} {slip.netPay.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </td>
                                <td className="p-2.5 text-center">
                                  <button
                                    onClick={() => setSelectedPayslipToPrint(slip)}
                                    className="p-1.5 hover:bg-slate-100 rounded text-slate-500 hover:text-slate-800 cursor-pointer"
                                    title="Print on Farm Letterhead"
                                  >
                                    <Printer className="w-3.5 h-3.5" />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {payslips.length === 0 && (
              <div className="text-center p-12 italic text-slate-400 text-xs">No payroll history committed. Post a monthly run to build audited history pools.</div>
            )}
          </div>
        </div>
      )}

      {/* STATUTORY REMITTANCE TRACKING */}
      {activeTab === "statutory" && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="border-b pb-4 flex justify-between items-center flex-wrap gap-4">
            <div>
              <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Statutory Pension & Tax Obligations Tracking</h4>
              <p className="text-[11px] text-slate-500">Remittance compliance audit ledger tracking employer match weights and active deposits liabilities.</p>
            </div>
            
            <button 
              onClick={() => generateMockCSV("Statutory Tracking", payslips)}
              className="px-3 py-1.5 text-xs font-bold border rounded-lg bg-white text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 shadow-sm"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>Export Compliance Audit Pool</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-800 bg-white">
              <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                <tr>
                  <th className="p-3">Obli. Month</th>
                  <th className="p-3 text-right">{isZambia ? "ZRA PAYE Tax" : "Government tax"}</th>
                  <th className="p-3 text-right">{isZambia ? "NAPSA Pension Oblig" : "Pension funds"}</th>
                  {isZambia && <th className="p-3 text-right">NHIMA Health</th>}
                  {isZambia && <th className="p-3 text-right">WCF & Skills Levy</th>}
                  <th className="p-3 text-right">Compliance Liability Total</th>
                  <th className="p-3 text-center">Print Audit</th>
                </tr>
              </thead>
              <tbody className="divide-y font-semibold text-slate-800">
                {statutorySummaries.map((sum, i) => (
                  <tr key={i} className="hover:bg-slate-50/50">
                    <td className="p-3 font-bold font-mono text-slate-900">{sum.month}</td>
                    <td className="p-3 text-right font-mono text-slate-650">{currencySymbol} {sum.paye.toFixed(2)}</td>
                    <td className="p-3 text-right font-mono text-slate-650">{currencySymbol} {sum.napsa.toFixed(2)}</td>
                    {isZambia && <td className="p-3 text-right font-mono text-slate-650">{currencySymbol} {sum.nhima.toFixed(2)}</td>}
                    {isZambia && <td className="p-3 text-right font-mono text-slate-650">{currencySymbol} {(sum.wcf + sum.skills).toFixed(2)}</td>}
                    <td className="p-3 text-right font-mono text-indigo-600 font-extrabold">
                      {currencySymbol} {sum.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="p-3 text-center">
                      <button 
                        onClick={() => triggerPDFPrint(`statutory-summary-${sum.month}`)}
                        className="p-1 hover:bg-slate-100 rounded text-slate-500 hover:text-slate-800 cursor-pointer"
                        title="Print Statutory Assessment Report"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}

                {statutorySummaries.length === 0 && (
                  <tr>
                    <td colSpan={isZambia ? 7 : 5} className="p-12 text-center text-slate-400 italic">No statutory tracking history logged. Process a payroll run first.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ADJUSTMENTS VIEW */}
      {activeTab === "adjustments" && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="border-b pb-3">
            <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-emerald-500" />
              <span>Contract Overrides & Allowances Audit Trail</span>
            </h4>
            <p className="text-[11px] text-slate-500">Audits manually adjusted contract rates, allowance additions, and justification records across workforces.</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs bg-white text-slate-800">
              <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                <tr>
                  <th className="p-3">Override Date</th>
                  <th className="p-3">Employee</th>
                  <th className="p-3 text-right">Basic Before → After</th>
                  <th className="p-3 text-right">Allowances Before → After</th>
                  <th className="p-3">Captured Reason / Justification</th>
                  <th className="p-3 text-right">Event ID</th>
                </tr>
              </thead>
              <tbody className="divide-y font-semibold text-slate-800">
                {adjustmentLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50">
                    <td className="p-3 font-mono text-slate-550 text-[10px]">{log.date}</td>
                    <td className="p-3">
                      <span className="block font-bold text-slate-900">{log.employeeName}</span>
                      <span className="text-[9px] text-slate-400 font-mono block">Month target: {log.month}</span>
                    </td>
                    <td className="p-3 text-right font-mono">
                      <span className="text-slate-400 block text-[10px]">{currencySymbol}{log.basicBefore}</span>
                      <span className="text-emerald-600 block text-xs">→ {currencySymbol}{log.basicAfter}</span>
                    </td>
                    <td className="p-3 text-right font-mono">
                      <span className="text-slate-400 block text-[10px]">{currencySymbol}{log.allowancesBefore}</span>
                      <span className="text-indigo-600 block text-xs">→ {currencySymbol}{log.allowancesAfter}</span>
                    </td>
                    <td className="p-3 max-w-xs text-slate-600 text-[11px] leading-relaxed italic">
                      "{log.reason}"
                    </td>
                    <td className="p-3 text-right font-mono text-[9px] font-extrabold text-[#7c3aed] uppercase">{log.id}</td>
                  </tr>
                ))}

                {adjustmentLogs.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-12 text-center text-slate-400 italic">No manual salary or allowance adjustments logged.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* INDIVIDUAL PAYSLIP ON LETTERHEAD MODAL */}
      {selectedPayslipToPrint && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 min-h-screen">
          <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl p-8 border border-slate-200 text-slate-900 overflow-y-auto max-h-[90vh] font-sans">
            {/* Print Action Buttons */}
            <div className="flex justify-between items-center pb-4 border-b border-slate-100 mb-6 sticky top-0 bg-white z-10">
              <span className="text-xs bg-indigo-50 text-indigo-700 font-bold px-2.5 py-1 rounded-full uppercase font-mono">Audited Payslip Document representation</span>
              <div className="flex gap-2">
                <button 
                  onClick={() => generateSinglePayslipPDF(selectedPayslipToPrint, activeFarm)}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow cursor-pointer"
                >
                  <FileDown className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Download PDF</span>
                </button>
                <button 
                  onClick={() => triggerPDFPrint(`letterhead-slip`)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Payslip</span>
                </button>
                <button 
                  onClick={() => setSelectedPayslipToPrint(null)} 
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>

            {/* Letterhead Paper mockup */}
            <div className="p-8 border border-slate-350 bg-white shadow-inner space-y-8 rounded-xl" id="letterhead-slip">
              {/* Header Letterhead Component */}
              <div className="flex justify-between items-start border-b-4 border-emerald-600 pb-6">
                <div className="space-y-1">
                  <div className="flex items-center gap-3">
                    {activeFarm?.logo?.startsWith("data:image/") ? (
                      <img src={activeFarm.logo} alt="Farm Logo" className="w-10 h-10 object-contain rounded-lg border border-slate-200" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="w-10 h-10 bg-emerald-700 rounded-xl flex items-center justify-center font-black text-white text-lg shadow-sm">
                        {(activeFarm?.name || "M")[0].toUpperCase()}
                      </div>
                    )}
                    <div>
                      <span className="text-lg font-black tracking-tight text-slate-900 uppercase block">
                        {activeFarm?.letterheadTitle || activeFarm?.name || "Mabala Tenant Farms Group"}
                      </span>
                      {activeFarm?.letterheadSubtitle && (
                        <span className="text-xs text-slate-500 font-semibold block">{activeFarm.letterheadSubtitle}</span>
                      )}
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-500 font-mono pt-1">
                    {activeFarm?.letterheadAddress || activeFarm?.address || "HQ Plot Area 45, Lusaka, Zambia"}
                  </p>
                  <p className="text-[9px] text-slate-400 font-mono">
                    TPIN: {activeFarm?.tpin || "1009876543"} • Tel: {activeFarm?.phone || "+260 978 070734"} • Email: {activeFarm?.email || "billing@mabala.co.zm"}
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-base font-black tracking-wider text-emerald-600 uppercase block font-mono">OFFICIAL PAYSLIP</span>
                  <span className="text-[10px] text-slate-400 block font-mono">{selectedPayslipToPrint.month} Statement cycle</span>
                  <span className="text-[9px] text-[#8b5cf6] font-mono block font-bold mt-1 uppercase">Doc Ref: {selectedPayslipToPrint.id}</span>
                </div>
              </div>

              {/* Worker Information Block */}
              <div className="grid grid-cols-2 gap-6 bg-slate-50 p-4 rounded-xl border">
                <div className="space-y-1 text-xs">
                  <span className="text-[9px] uppercase font-bold text-slate-400">Employee Details</span>
                  <div className="font-bold text-slate-900 text-sm">{selectedPayslipToPrint.employeeName}</div>
                  <div className="text-slate-600 font-medium">Register ID: {selectedPayslipToPrint.employeeId}</div>
                  <div className="text-slate-550 italic">{employees.find(e => e.id === selectedPayslipToPrint.employeeId)?.role || "Farm Worker Officer"}</div>
                </div>

                <div className="space-y-1 text-xs text-right">
                  <span className="text-[9px] uppercase font-bold text-slate-400">Salary payment Disbursed via</span>
                  <div className="font-bold text-slate-900">{selectedPayslipToPrint.paymentMethod || "Mobile Money"}</div>
                  {selectedPayslipToPrint.paymentMethod === "Bank Transfer" ? (
                    <div className="text-slate-600 font-mono text-[10px]">
                      {selectedPayslipToPrint.bankName} <br /> Acct: {selectedPayslipToPrint.bankAccount}
                    </div>
                  ) : (
                    <div className="text-slate-600 font-mono text-[10px]">
                      Mobile money Number: {selectedPayslipToPrint.walletNumber || "0977881122"}
                    </div>
                  )}
                </div>
              </div>

              {/* Earnings & Deductions Tables */}
              <div className="grid grid-cols-2 gap-8 text-xs font-semibold">
                {/* Earnings */}
                <div className="space-y-3">
                  <span className="text-[10px] uppercase tracking-widest text-[#047857] block border-b pb-1 font-extrabold">Earning weights</span>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between font-bold text-slate-800">
                      <span>Monthly Basic Salary:</span>
                      <span className="font-mono">{currencySymbol} {selectedPayslipToPrint.basicSalary.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between font-medium text-slate-600">
                      <span>Housing Allowance:</span>
                      <span className="font-mono">+ {currencySymbol}{selectedPayslipToPrint.housingAllowance.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between font-medium text-slate-600">
                      <span>Transport Allowance:</span>
                      <span className="font-mono">+ {currencySymbol}{selectedPayslipToPrint.transportAllowance.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between font-medium text-slate-600">
                      <span>Other Allowance:</span>
                      <span className="font-mono">+ {currencySymbol}{selectedPayslipToPrint.otherAllowance.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="flex justify-between font-extrabold text-slate-900 bg-slate-50 border p-2 rounded mt-4">
                    <span>GROSS SALARY:</span>
                    <span className="font-mono">{currencySymbol} {selectedPayslipToPrint.grossSalary.toLocaleString()}</span>
                  </div>
                </div>

                {/* Deductions */}
                <div className="space-y-3">
                  <span className="text-[10px] uppercase tracking-widest text-rose-700 block border-b pb-1 font-extrabold">Remittance Deductions</span>

                  <div className="space-y-2 font-medium text-slate-600">
                    <div className="flex justify-between">
                      <span>Income Tax ({isZambia ? "ZRA PAYE" : "Flat PAYE"}):</span>
                      <span className="font-mono text-rose-500">- {currencySymbol}{selectedPayslipToPrint.paye.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Pension ({isZambia ? "NAPSA EE 5%" : "EE pension 5%"}):</span>
                      <span className="font-mono text-rose-500">- {currencySymbol}{selectedPayslipToPrint.napsaEmployee.toFixed(2)}</span>
                    </div>
                    {isZambia && (
                      <div className="flex justify-between">
                        <span>Health Scheme (NHIMA EE 1%):</span>
                        <span className="font-mono text-rose-500">- {currencySymbol}{selectedPayslipToPrint.nhimaEmployee.toFixed(2)}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex justify-between font-extrabold text-rose-600 bg-slate-100/50 border p-2 rounded mt-4">
                    <span>TOTAL DEDUCT WEIGHT:</span>
                    <span className="font-mono">- {currencySymbol} {(selectedPayslipToPrint.paye + selectedPayslipToPrint.napsaEmployee + selectedPayslipToPrint.nhimaEmployee).toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Employer match weights (Not deducted from worker, but paid on behalf) */}
              {isZambia && (
                <div className="bg-slate-50 p-4 rounded-xl border border-dashed text-[10px]">
                  <span className="font-extrabold uppercase text-slate-500 tracking-wider block mb-2 text-[9px]">Employer Statutory Obligation Weights (Matched Cap)</span>
                  <div className="grid grid-cols-4 gap-2 text-slate-600 font-semibold font-mono">
                    <div>NAPSA (ER 5%): <span className="text-slate-800">{currencySymbol}{selectedPayslipToPrint.napsaEmployer.toFixed(2)}</span></div>
                    <div>NHIMA (ER 1%): <span className="text-slate-800">{currencySymbol}{selectedPayslipToPrint.nhimaEmployer.toFixed(2)}</span></div>
                    <div>WCF Liability: <span className="text-slate-800">{currencySymbol}{selectedPayslipToPrint.wcfEmployer.toFixed(2)}</span></div>
                    <div>Skills levy (0.5%): <span className="text-slate-800">{currencySymbol}{selectedPayslipToPrint.skillsLevyEmployer.toFixed(2)}</span></div>
                  </div>
                </div>
              )}

              {/* Net disbursed and signatures */}
              <div className="pt-6 border-t font-sans flex justify-between items-center bg-emerald-500/5 p-4 rounded-xl">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-widest block font-bold">NET BANK DISBURSEMENT WEIGHT</span>
                  <span className="text-2xl font-black font-mono text-emerald-800">
                    {currencySymbol} {selectedPayslipToPrint.netPay.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="text-[10px] text-slate-500 font-bold font-mono text-right">
                  <span>MABALA COMPLIANCE TOKEN</span> <br />
                  <span className="text-[#059669] font-extrabold">STATUS: PAID & AUDITED ✓</span>
                </div>
              </div>

              {selectedPayslipToPrint.adjustmentReason && (
                <div className="p-2.5 bg-amber-50 border border-amber-200 text-amber-800 rounded font-medium text-[10px] italic">
                  "* System logged adjustment comment: '{selectedPayslipToPrint.adjustmentReason}'"
                </div>
              )}

              {/* Print signature lines */}
              <div className="pt-8 grid grid-cols-2 gap-8 text-xs font-semibold text-slate-500 font-sans">
                <div className="border-t border-slate-350 pt-3">
                  <span>Officer Signature: _______________________</span>
                  <p className="text-[9px] text-slate-400 mt-0.5">Authorized Finance Officer approval</p>
                </div>
                <div className="border-t border-slate-250 pt-3 text-right">
                  <span>Employee Acknowledgement: _________________</span>
                  <p className="text-[9px] text-slate-400 mt-0.5">Recv in good order & compliance standards</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "leaves" && (
        <div className="space-y-6 animate-fade-in font-sans">
          <div className="bg-white rounded-xl border p-6 shadow-sm">
            <div className="border-b pb-4 flex justify-between items-center flex-wrap gap-4">
              <div>
                <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Leave Management Calendar</h3>
                <p className="text-[11px] text-slate-500 font-medium">Record and track animal husbandry & farming workers sick leave, annual holidays, and special compassion breaks.</p>
              </div>
            </div>

            {/* Form to Book Leave */}
            {!isReadonly && (
              <form onSubmit={(e) => {
                e.preventDefault();
                if (!leaveEmployeeId || !leaveStart || !leaveEnd) {
                  alert("Worker selection, Start and End dates are mandatory.");
                  return;
                }
                const worker = employees.find(emp => emp.id === leaveEmployeeId);
                if (!worker) return;
                onAddLeaveRecord({
                  employeeId: leaveEmployeeId,
                  employeeName: worker.name,
                  startDate: leaveStart,
                  endDate: leaveEnd,
                  leaveType,
                  status: "Approved",
                  notes: leaveReason
                });
                setLeaveEmployeeId("");
                setLeaveStart("");
                setLeaveEnd("");
                setLeaveReason("");
              }} className="p-4 bg-slate-50 border rounded-lg mt-4 grid grid-cols-1 md:grid-cols-5 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-slate-500">Select Employee</label>
                  <select
                    value={leaveEmployeeId}
                    onChange={e => setLeaveEmployeeId(e.target.value)}
                    required
                    className="w-full text-xs p-2 border bg-white rounded focus:outline-none"
                  >
                    <option value="">-- Choose employee contract --</option>
                    {employees.map(e => (
                      <option key={e.id} value={e.id}>{e.name} ({e.role})</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-slate-500">Leave Type category</label>
                  <select
                    value={leaveType}
                    onChange={e => setLeaveType(e.target.value as any)}
                    className="w-full text-xs p-2 border bg-white rounded focus:outline-none"
                  >
                    <option value="Annual">Annual Paid Holidays</option>
                    <option value="Sick">Sick Certificate Leave</option>
                    <option value="Maternity">Maternity break</option>
                    <option value="Compassionate">Compassionate special</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-slate-500">Beginning Date</label>
                  <input
                    type="date"
                    value={leaveStart}
                    onChange={e => setLeaveStart(e.target.value)}
                    required
                    className="w-full text-xs p-2 border bg-white rounded focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-slate-500">Ending Date</label>
                  <input
                    type="date"
                    value={leaveEnd}
                    onChange={e => setLeaveEnd(e.target.value)}
                    required
                    className="w-full text-xs p-2 border bg-white rounded focus:outline-none"
                  />
                </div>
                <div className="space-y-1 flex gap-2 items-end">
                  <div className="flex-1">
                    <label className="text-[10px] uppercase font-bold text-slate-500">Brief Reason description</label>
                    <input
                      type="text"
                      value={leaveReason}
                      onChange={e => setLeaveReason(e.target.value)}
                      placeholder="e.g. Annual holiday allocation"
                      className="w-full text-xs p-2 border bg-white rounded focus:outline-none"
                    />
                  </div>
                  <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs p-2 rounded shrink-0">
                    Settle Book
                  </button>
                </div>
              </form>
            )}

            <div className="overflow-x-auto mt-6">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                  <tr>
                    <th className="p-3">Reference</th>
                    <th className="p-3">Matched Employee</th>
                    <th className="p-3">Type</th>
                    <th className="p-3">Period Start Date</th>
                    <th className="p-3">Period End Date</th>
                    <th className="p-3">Reason remarks</th>
                    <th className="p-3">status</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y font-semibold text-slate-800">
                  {leaveRecords.map(leave => (
                    <tr key={leave.id} className="hover:bg-slate-50/50">
                      <td className="p-3 font-mono text-[10px] text-slate-400">{leave.id}</td>
                      <td className="p-3 text-slate-900">{leave.employeeName}</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px]">{leave.leaveType}</span>
                      </td>
                      <td className="p-3 font-mono">{leave.startDate}</td>
                      <td className="p-3 font-mono">{leave.endDate}</td>
                      <td className="p-3 font-normal text-slate-500">{leave.notes || "None"}</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded text-[10px] font-bold border border-emerald-200">
                          {leave.status}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        {!isReadonly && (
                          <button
                            type="button"
                            onClick={async () => {
                              const ok = await confirm({
                                title: "Delete Leave Booking",
                                message: "Are you sure you want to delete this leave record?",
                                confirmText: "Delete",
                                cancelText: "Cancel",
                                type: "danger"
                              });
                              if (ok) {
                                onDeleteLeaveRecord(leave.id);
                              }
                            }}
                            className="text-slate-400 hover:text-rose-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {leaveRecords.length === 0 && (
                    <tr>
                      <td colSpan={8} className="p-6 text-center text-slate-400 italic">No leave bookings recorded. All authorized worker holiday timelines show here.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === "advances" && (
        <div className="space-y-6 animate-fade-in font-sans">
          <div className="bg-white rounded-xl border p-6 shadow-sm">
            <div className="border-b pb-4">
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Salary Advance register desk</h3>
              <p className="text-[11px] text-slate-500 font-medium">Record cash advances or emergency credit disbursements given to employees. Automatic deduct options apply in payslips.</p>
            </div>

            {/* Advance Book form */}
            {!isReadonly && (
              <form onSubmit={(e) => {
                e.preventDefault();
                if (!advanceEmployeeId || !advanceAmount) {
                  alert("Worker selection and Advance Principal Amount must be filled.");
                  return;
                }
                const worker = employees.find(emp => emp.id === advanceEmployeeId);
                if (!worker) return;
                onAddEmployeeAdvance({
                  employeeId: advanceEmployeeId,
                  employeeName: worker.name,
                  amount: Number(advanceAmount),
                  advanceAmount: Number(advanceAmount),
                  remainingBalance: Number(advanceAmount),
                  requestDate: advanceDate,
                  repaymentMonth: advanceDate.substring(0, 7) || "2026-06",
                  status: "Approved",
                  notes: advanceNotes
                });
                setAdvanceEmployeeId("");
                setAdvanceAmount("");
                setAdvanceNotes("");
              }} className="p-4 bg-slate-50 border rounded-lg mt-4 grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-slate-500">Pick worker</label>
                  <select
                    value={advanceEmployeeId}
                    onChange={e => setAdvanceEmployeeId(e.target.value)}
                    required
                    className="w-full text-xs p-2 border bg-white rounded focus:outline-none"
                  >
                    <option value="">-- Choose employee contract --</option>
                    {employees.map(e => (
                      <option key={e.id} value={e.id}>{e.name} ({e.role})</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-slate-500">Advance Principal Value ({currencySymbol})</label>
                  <input
                    type="number"
                    value={advanceAmount}
                    onChange={e => setAdvanceAmount(e.target.value)}
                    required
                    placeholder="e.g. 1500"
                    className="w-full text-xs p-2 border bg-white rounded focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-slate-500">Disbursement Value Date</label>
                  <input
                    type="date"
                    value={advanceDate}
                    onChange={e => setAdvanceDate(e.target.value)}
                    required
                    className="w-full text-xs p-2 border bg-white rounded focus:outline-none"
                  />
                </div>
                <div className="space-y-1 flex gap-2 items-end">
                  <div className="flex-1">
                    <label className="text-[10px] uppercase font-bold text-slate-500">Descriptive Reason notes</label>
                    <input
                      type="text"
                      value={advanceNotes}
                      onChange={e => setAdvanceNotes(e.target.value)}
                      placeholder="e.g. School fees advance"
                      className="w-full text-xs p-2 border bg-white rounded focus:outline-none"
                    />
                  </div>
                  <button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs p-2 rounded shrink-0">
                    Disburse Cash
                  </button>
                </div>
              </form>
            )}

            {repayingAdvanceId && (
              <div className="bg-emerald-50 border border-emerald-200 mt-4 p-4 rounded-xl flex items-center justify-between gap-4 animate-fade-in text-xs">
                <div>
                  <span className="font-bold text-emerald-800">Record Manual Settle Pay on Outstanding Salary Advance:</span>
                  <p className="text-[10px] text-slate-500">Manually cash pay back the advance balance ledger node instead of standard payroll deductions.</p>
                </div>
                <form onSubmit={(e) => {
                  e.preventDefault();
                  if (!repayAmt) return;
                  onRepayEmployeeAdvance(repayingAdvanceId, Number(repayAmt));
                  setRepayAmt("");
                  setRepayingAdvanceId(null);
                }} className="flex gap-2 items-center">
                  <input
                    type="number"
                    value={repayAmt}
                    required
                    onChange={e => setRepayAmt(e.target.value)}
                    placeholder="e.g. 500"
                    className="text-xs p-1.5 border bg-white rounded outline-none"
                  />
                  <button type="submit" className="bg-emerald-600 justify-center text-white text-[11px] font-bold py-1.5 px-3 rounded cursor-pointer">
                    Submit Repayment
                  </button>
                  <button type="button" onClick={() => setRepayingAdvanceId(null)} className="text-slate-500 text-xs font-semibold hover:underline">Cancel</button>
                </form>
              </div>
            )}

            <div className="overflow-x-auto mt-6">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50">
                  <tr>
                    <th className="p-3">Compliance Reference</th>
                    <th className="p-3">Matched Employee</th>
                    <th className="p-3 font-mono">Disbursement Date</th>
                    <th className="p-3 font-mono text-right">Principal Amount</th>
                    <th className="p-3 font-mono text-right text-rose-500">Remaining Balance</th>
                    <th className="p-3">Internal Remarks</th>
                    <th className="p-3 text-center">Status state</th>
                    <th className="p-3 text-right font-semibold">Ledger Controls</th>
                  </tr>
                </thead>
                <tbody className="divide-y font-semibold text-slate-800">
                  {employeeAdvances.map(adv => (
                    <tr key={adv.id} className="hover:bg-slate-50/50">
                      <td className="p-3 font-mono text-[10px] text-slate-400">{adv.id}</td>
                      <td className="p-3 text-slate-900">{adv.employeeName}</td>
                      <td className="p-3 font-mono">{adv.requestDate}</td>
                      <td className="p-3 text-right font-mono font-bold text-slate-700">
                        {currencySymbol} {adv.advanceAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className={`p-3 text-right font-mono font-bold ${adv.remainingBalance > 0 ? "text-rose-600 font-extrabold" : "text-emerald-650"}`}>
                        {currencySymbol} {adv.remainingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-3 font-normal text-slate-500">{adv.notes || "Emergency wages pool"}</td>
                      <td className="p-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          adv.remainingBalance === 0 
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-200" 
                            : "bg-rose-50 text-rose-700 border border-rose-200 animate-pulse"
                        }`}>
                          {adv.remainingBalance === 0 ? "Settled YTD" : "Due Repayment"}
                        </span>
                      </td>
                      <td className="p-3 text-right flex justify-end gap-2">
                        {adv.remainingBalance > 0 && !isReadonly && (
                          <button
                            onClick={() => {
                              setRepayingAdvanceId(adv.id);
                              setRepayAmt(adv.remainingBalance.toString());
                            }}
                            className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold border border-emerald-200 px-2 py-0.5 rounded text-[10.5px] cursor-pointer"
                          >
                            Repay cash
                          </button>
                        )}
                        {!isReadonly && (
                          <button
                            type="button"
                            onClick={async () => {
                              const ok = await confirm({
                                title: "Remove Salary Advance",
                                message: "Remove salary advance? This is a compliance purge request.",
                                confirmText: "Remove",
                                cancelText: "Cancel",
                                type: "danger"
                              });
                              if (ok) {
                                onDeleteEmployeeAdvance(adv.id);
                              }
                            }}
                            className="text-slate-400 hover:text-rose-600 p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {employeeAdvances.length === 0 && (
                    <tr>
                      <td colSpan={8} className="p-6 text-center text-slate-400 italic">No salary advances recorded. Emergency short-term staff dispersals log here.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* DEDICATED PAYROLL AUDIT HISTORY TAB CONTENT */}
      {activeTab === "audit-history" && (
        <div className="space-y-6 animate-fade-in font-sans">
          {/* AUDIT SUMMARY HEADER CARD */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-100 pb-5">
              <div>
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-amber-50 text-amber-700 rounded-xl border border-amber-200">
                    <History className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                      <span>Payroll & Statutory Compliance Audit History</span>
                      <span className="px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-full text-[10px] font-black uppercase tracking-widest">
                        Immutable Audit Ledger
                      </span>
                    </h3>
                    <p className="text-[11.5px] text-slate-500 mt-0.5 font-medium">
                      Automatic end-to-end audit trail recording statutory threshold changes (PAYE, NAPSA, NHIMA, WCF, Skills Levy), payroll runs, staff salary adjustments, and compliance notes.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => setShowManualLogModal(true)}
                  disabled={isReadonly}
                  className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Compliance Audit Note</span>
                </button>

                <button
                  onClick={exportAuditLedgerToCSV}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-slate-600" />
                  <span>Export Audit Ledger (CSV)</span>
                </button>
              </div>
            </div>

            {/* METRIC COUNTERS ROW */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-amber-50/50 rounded-2xl border border-amber-200/60 space-y-1">
                <span className="text-[10px] font-extrabold uppercase text-amber-800 tracking-wider">Statutory Rate Logs</span>
                <div className="text-xl font-extrabold text-amber-900 font-mono">
                  {statConfig.auditTrail?.length || 0}
                </div>
                <span className="text-[10px] text-amber-700 font-medium">ZRA & Pension Thresholds</span>
              </div>

              <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200/60 space-y-1">
                <span className="text-[10px] font-extrabold uppercase text-emerald-800 tracking-wider">Payroll Run Events</span>
                <div className="text-xl font-extrabold text-emerald-900 font-mono">
                  {postedMonths.length}
                </div>
                <span className="text-[10px] text-emerald-700 font-medium">Finalized Monthly Postings</span>
              </div>

              <div className="p-4 bg-indigo-50/50 rounded-2xl border border-indigo-200/60 space-y-1">
                <span className="text-[10px] font-extrabold uppercase text-indigo-800 tracking-wider">Salary Adjustments</span>
                <div className="text-xl font-extrabold text-indigo-900 font-mono">
                  {adjustmentLogs.length}
                </div>
                <span className="text-[10px] text-indigo-700 font-medium">Promotions & Contract Changes</span>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-extrabold uppercase text-slate-600 tracking-wider">Manual Audit Notes</span>
                <div className="text-xl font-extrabold text-slate-900 font-mono">
                  {manualLogs.length}
                </div>
                <span className="text-[10px] text-slate-500 font-medium">Administrator Remarks</span>
              </div>
            </div>

            {/* FILTER & SEARCH CONTROLS */}
            <div className="flex flex-col sm:flex-row justify-between items-center gap-3 pt-2 border-t border-slate-100">
              <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
                <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="text-[10.5px] font-extrabold text-slate-500 uppercase tracking-wider shrink-0">Filter:</span>
                
                <button
                  onClick={() => setAuditCategoryFilter("ALL")}
                  className={`px-3 py-1 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                    auditCategoryFilter === "ALL"
                      ? "bg-slate-900 text-white shadow-xs"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  All Logs ({compiledAuditEntries.length})
                </button>

                <button
                  onClick={() => setAuditCategoryFilter("STATUTORY_RATES")}
                  className={`px-3 py-1 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                    auditCategoryFilter === "STATUTORY_RATES"
                      ? "bg-amber-700 text-white shadow-xs"
                      : "bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100"
                  }`}
                >
                  Statutory Rates
                </button>

                <button
                  onClick={() => setAuditCategoryFilter("PAYROLL_RUNS")}
                  className={`px-3 py-1 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                    auditCategoryFilter === "PAYROLL_RUNS"
                      ? "bg-emerald-700 text-white shadow-xs"
                      : "bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100"
                  }`}
                >
                  Payroll Runs
                </button>

                <button
                  onClick={() => setAuditCategoryFilter("STAFF_ADJUSTMENTS")}
                  className={`px-3 py-1 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                    auditCategoryFilter === "STAFF_ADJUSTMENTS"
                      ? "bg-indigo-700 text-white shadow-xs"
                      : "bg-indigo-50 text-indigo-800 border border-indigo-200 hover:bg-indigo-100"
                  }`}
                >
                  Salary Adjustments
                </button>

                <button
                  onClick={() => setAuditCategoryFilter("REMITTANCE_ADVANCES")}
                  className={`px-3 py-1 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                    auditCategoryFilter === "REMITTANCE_ADVANCES"
                      ? "bg-purple-700 text-white shadow-xs"
                      : "bg-purple-50 text-purple-800 border border-purple-200 hover:bg-purple-100"
                  }`}
                >
                  Remittance & Advances
                </button>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search audit trail..."
                  value={auditSearchQuery}
                  onChange={(e) => setAuditSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs font-bold border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:border-indigo-600 outline-none"
                />
              </div>
            </div>

            {/* AUDIT TRAIL TABLE */}
            <div className="overflow-x-auto rounded-2xl border border-slate-200 shadow-2xs">
              <table className="w-full text-left text-xs bg-white text-slate-800">
                <thead className="text-[10px] uppercase font-black text-slate-500 bg-slate-100/80 border-b border-slate-200">
                  <tr>
                    <th className="p-3 font-mono">Date / Timestamp</th>
                    <th className="p-3">Audit Category</th>
                    <th className="p-3">Event Title & Performed By</th>
                    <th className="p-3">Audit Summary & Rate Impact</th>
                    <th className="p-3">Captured Remarks / Notes</th>
                    <th className="p-3 text-right">Audit Event ID</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {filteredAuditEntries.map((entry) => (
                    <tr key={entry.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-mono text-[10.5px] text-slate-500 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>{new Date(entry.timestamp).toLocaleString()}</span>
                        </div>
                      </td>

                      <td className="p-3 whitespace-nowrap">
                        <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider inline-flex items-center gap-1 border ${entry.badgeStyle}`}>
                          {entry.categoryBadge}
                        </span>
                      </td>

                      <td className="p-3">
                        <span className="block font-extrabold text-slate-900 text-xs">{entry.title}</span>
                        <span className="text-[10px] text-slate-500 font-mono block">By: {entry.performedBy}</span>
                      </td>

                      <td className="p-3">
                        <div className="text-xs font-semibold text-slate-800">{entry.summary}</div>
                        {entry.secondaryDetail && (
                          <div className="text-[10.5px] font-mono text-slate-500 mt-0.5">{entry.secondaryDetail}</div>
                        )}
                      </td>

                      <td className="p-3 text-slate-600 italic text-[11px]">
                        {entry.notes || "Standard system compliance log"}
                      </td>

                      <td className="p-3 text-right font-mono text-[9.5px] font-extrabold text-slate-400 uppercase whitespace-nowrap">
                        {entry.id}
                      </td>
                    </tr>
                  ))}

                  {filteredAuditEntries.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-12 text-center text-slate-400 italic">
                        No audit entries found matching the current search criteria or category filter.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MANUAL COMPLIANCE AUDIT NOTE MODAL */}
      {showManualLogModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!manualNoteText.trim()) return;
              const newEntry = {
                id: "AUDIT-NOTE-" + Date.now(),
                timestamp: new Date().toISOString(),
                category: manualNoteCategory,
                title: "Farm Compliance Audit Remark",
                performedBy: activeFarm?.email || "farmadmin@mabala.zm",
                details: manualNoteText.trim()
              };
              setManualLogs((prev) => [newEntry, ...prev]);
              setManualNoteText("");
              setShowManualLogModal(false);
            }}
            className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4"
          >
            <div className="flex justify-between items-center border-b pb-3">
              <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider flex items-center gap-2">
                <History className="w-4 h-4 text-amber-600" />
                <span>Add Manual Compliance Audit Remark</span>
              </h4>
              <button type="button" onClick={() => setShowManualLogModal(false)} className="text-slate-400 hover:text-slate-600 text-lg font-bold">✕</button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500 block mb-1">Audit Category</label>
                <select
                  value={manualNoteCategory}
                  onChange={(e) => setManualNoteCategory(e.target.value as any)}
                  className="w-full text-xs font-bold border border-slate-200 bg-slate-50 rounded-xl p-2.5 text-slate-800 outline-none"
                >
                  <option value="STATUTORY_RATES">Statutory Tax & Thresholds</option>
                  <option value="PAYROLL_RUNS">Payroll Execution & Postings</option>
                  <option value="STAFF_ADJUSTMENTS">Staff Salary Adjustments</option>
                  <option value="REMITTANCE_ADVANCES">Remittance & Advances</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500 block mb-1">Compliance Audit Note / Justification *</label>
                <textarea
                  required
                  rows={4}
                  value={manualNoteText}
                  onChange={(e) => setManualNoteText(e.target.value)}
                  placeholder="e.g. Verified 2026 ZRA PAYE threshold updates with farm accountant. All salary calculations validated."
                  className="w-full text-xs font-medium border border-slate-200 rounded-xl p-3 bg-white focus:border-indigo-600 outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t">
              <button type="button" onClick={() => setShowManualLogModal(false)} className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 rounded-xl cursor-pointer">
                Cancel
              </button>
              <button type="submit" className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-extrabold rounded-xl shadow-md cursor-pointer">
                Save Compliance Note
              </button>
            </div>
          </form>
        </div>
      )}

      {/* STAFF ADJUSTMENT / PROMOTION / TERMINATION MODAL */}
      {showStaffAdjModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <form onSubmit={handleSaveStaffAdjustment} className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5">
            <div className="flex justify-between items-center border-b pb-3">
              <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider flex items-center gap-2">
                <Award className="w-4 h-4 text-indigo-600" />
                <span>Log Staff Adjustment / Promotion / Status Change</span>
              </h4>
              <button type="button" onClick={() => setShowStaffAdjModal(false)} className="text-slate-400 hover:text-slate-600 text-lg font-bold">✕</button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Selected Worker</label>
                <div className="font-extrabold text-slate-900 text-sm mt-0.5">
                  {effectiveEmployees.find(e => e.id === staffAdjEmpId)?.name} ({staffAdjEmpId})
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] uppercase font-extrabold text-slate-500">Adjustment / Action Type *</label>
                  <select
                    value={staffAdjType}
                    onChange={e => setStaffAdjType(e.target.value as StaffAdjustmentType)}
                    className="w-full text-xs border border-slate-200 bg-slate-50 rounded-lg p-2 font-bold text-slate-800 mt-1"
                  >
                    <option value="Promoted">Promoted (New Title & Pay)</option>
                    <option value="Salary Increase">Salary Increase</option>
                    <option value="Allowance Adjustment">Allowance Adjustment</option>
                    <option value="Demotion">Demotion</option>
                    <option value="Terminated">Terminated (Exit Staff)</option>
                    <option value="Resigned">Resigned (Voluntary Exit)</option>
                    <option value="Other">Other Adjustment</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] uppercase font-extrabold text-slate-500">Effective Date *</label>
                  <input
                    type="date"
                    value={staffAdjEffectiveDate}
                    onChange={e => setStaffAdjEffectiveDate(e.target.value)}
                    required
                    className="w-full text-xs border border-slate-200 bg-slate-50 rounded-lg p-2 font-mono mt-1"
                  />
                </div>
              </div>

              {staffAdjType !== "Terminated" && staffAdjType !== "Resigned" && (
                <>
                  <div>
                    <label className="text-[10px] uppercase font-extrabold text-slate-500">New Role Designation</label>
                    <input
                      type="text"
                      placeholder="e.g. Senior Farm Supervisor"
                      value={staffAdjNewRole}
                      onChange={e => setStaffAdjNewRole(e.target.value)}
                      className="w-full text-xs border border-slate-200 bg-slate-50 rounded-lg p-2 mt-1 font-semibold"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-[10px] uppercase font-extrabold text-slate-500">New Basic Pay ({currencySymbol})</label>
                      <input
                        type="number"
                        value={staffAdjNewBasic}
                        onChange={e => setStaffAdjNewBasic(Number(e.target.value))}
                        className="w-full text-xs border border-slate-200 rounded p-2 font-mono mt-1"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-extrabold text-slate-500">Housing ({currencySymbol})</label>
                      <input
                        type="number"
                        value={staffAdjHousing}
                        onChange={e => setStaffAdjHousing(Number(e.target.value))}
                        className="w-full text-xs border border-slate-200 rounded p-2 font-mono mt-1"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-extrabold text-slate-500">Transport ({currencySymbol})</label>
                      <input
                        type="number"
                        value={staffAdjTransport}
                        onChange={e => setStaffAdjTransport(Number(e.target.value))}
                        className="w-full text-xs border border-slate-200 rounded p-2 font-mono mt-1"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-[10px] uppercase font-extrabold text-slate-500">Medical ({currencySymbol})</label>
                      <input
                        type="number"
                        value={staffAdjMedical}
                        onChange={e => setStaffAdjMedical(Number(e.target.value))}
                        className="w-full text-xs border border-slate-200 rounded p-2 font-mono mt-1"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-extrabold text-slate-500">Field ({currencySymbol})</label>
                      <input
                        type="number"
                        value={staffAdjField}
                        onChange={e => setStaffAdjField(Number(e.target.value))}
                        className="w-full text-xs border border-slate-200 rounded p-2 font-mono mt-1"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-extrabold text-slate-500">Other ({currencySymbol})</label>
                      <input
                        type="number"
                        value={staffAdjOther}
                        onChange={e => setStaffAdjOther(Number(e.target.value))}
                        className="w-full text-xs border border-slate-200 rounded p-2 font-mono mt-1"
                      />
                    </div>
                  </div>
                </>
              )}

              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Adjustment Justification / Reason *</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Promoted due to excellent broiler yield performance in Q2."
                  value={staffAdjReason}
                  onChange={e => setStaffAdjReason(e.target.value)}
                  className="w-full text-xs border border-slate-200 rounded p-2 mt-1"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 border-t pt-3">
              <button type="button" onClick={() => setShowStaffAdjModal(false)} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold">Cancel</button>
              <button type="submit" className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow-sm">Save Adjustment Log</button>
            </div>
          </form>
        </div>
      )}

      {/* EDIT EMPLOYEE CONTRACT MODAL */}
      {editingEmp && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <form onSubmit={handleSaveEditEmployee} className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b pb-3">
              <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider flex items-center gap-2">
                <Edit className="w-4 h-4 text-emerald-600" />
                <span>Edit Worker Contract & HR Dossier: {editingEmp.name}</span>
              </h4>
              <button type="button" onClick={() => setEditingEmp(null)} className="text-slate-400 hover:text-slate-600 text-lg font-bold">✕</button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Full Name *</label>
                <input
                  type="text"
                  value={editingEmp.name}
                  onChange={e => setEditingEmp({ ...editingEmp, name: e.target.value })}
                  required
                  className="w-full text-xs border rounded p-2 mt-0.5 font-semibold"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Role / Title *</label>
                <input
                  type="text"
                  value={editingEmp.role}
                  onChange={e => setEditingEmp({ ...editingEmp, role: e.target.value })}
                  required
                  className="w-full text-xs border rounded p-2 mt-0.5 font-semibold"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Employment Status</label>
                <select
                  value={editingEmp.employmentStatus || "Permanent"}
                  onChange={e => setEditingEmp({ ...editingEmp, employmentStatus: e.target.value as EmploymentStatus })}
                  className="w-full text-xs border rounded p-2 mt-0.5 font-semibold"
                >
                  <option value="Permanent">Permanent</option>
                  <option value="Casual Worker">Casual Worker</option>
                  <option value="Part Time">Part Time</option>
                  <option value="Probation">Probation</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Marital Status</label>
                <select
                  value={editingEmp.maritalStatus || "Married"}
                  onChange={e => setEditingEmp({ ...editingEmp, maritalStatus: e.target.value as MaritalStatus })}
                  className="w-full text-xs border rounded p-2 mt-0.5 font-semibold"
                >
                  <option value="Married">Married</option>
                  <option value="Single">Single</option>
                  <option value="Divorced">Divorced</option>
                  <option value="Widowed">Widowed</option>
                  <option value="Separated">Separated</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Date of Birth (DOB)</label>
                <input
                  type="date"
                  value={editingEmp.dateOfBirth || ""}
                  onChange={e => setEditingEmp({ ...editingEmp, dateOfBirth: e.target.value })}
                  className="w-full text-xs border rounded p-2 mt-0.5 font-mono"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">NRC Number</label>
                <input
                  type="text"
                  value={editingEmp.nrcNumber || ""}
                  onChange={e => setEditingEmp({ ...editingEmp, nrcNumber: e.target.value })}
                  className="w-full text-xs border rounded p-2 mt-0.5 font-mono"
                />
              </div>
            </div>

            {/* Next of Kin */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <span className="text-[10px] uppercase font-extrabold text-slate-500 block">Next of Kin Details</span>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <label className="text-[9px] uppercase font-bold text-slate-400">Kin Name</label>
                  <input
                    type="text"
                    value={editingEmp.nextOfKinName || editingEmp.nextOfKin?.name || ""}
                    onChange={e => setEditingEmp({ ...editingEmp, nextOfKinName: e.target.value })}
                    className="w-full text-xs border rounded p-1.5 mt-0.5"
                  />
                </div>
                <div>
                  <label className="text-[9px] uppercase font-bold text-slate-400">Kin Contact Phone</label>
                  <input
                    type="text"
                    value={editingEmp.nextOfKinContact || editingEmp.nextOfKin?.contactNumber || ""}
                    onChange={e => setEditingEmp({ ...editingEmp, nextOfKinContact: e.target.value })}
                    className="w-full text-xs border rounded p-1.5 mt-0.5 font-mono"
                  />
                </div>
                <div>
                  <label className="text-[9px] uppercase font-bold text-slate-400">Relationship</label>
                  <input
                    type="text"
                    value={editingEmp.nextOfKinRelationship || editingEmp.nextOfKin?.relationship || "Spouse"}
                    onChange={e => setEditingEmp({ ...editingEmp, nextOfKinRelationship: e.target.value })}
                    className="w-full text-xs border rounded p-1.5 mt-0.5"
                  />
                </div>
              </div>
            </div>

            {/* Financial & Allowances */}
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Basic Rate ({currencySymbol})</label>
                <input
                  type="number"
                  value={editingEmp.contractRate}
                  onChange={e => setEditingEmp({ ...editingEmp, contractRate: Number(e.target.value) })}
                  className="w-full text-xs border rounded p-2 mt-0.5 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Housing Allowance</label>
                <input
                  type="number"
                  value={editingEmp.housingAllowance || 0}
                  onChange={e => setEditingEmp({ ...editingEmp, housingAllowance: Number(e.target.value) })}
                  className="w-full text-xs border rounded p-2 mt-0.5 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Transport Allowance</label>
                <input
                  type="number"
                  value={editingEmp.transportAllowance || 0}
                  onChange={e => setEditingEmp({ ...editingEmp, transportAllowance: Number(e.target.value) })}
                  className="w-full text-xs border rounded p-2 mt-0.5 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Medical Allowance</label>
                <input
                  type="number"
                  value={editingEmp.medicalAllowance || 0}
                  onChange={e => setEditingEmp({ ...editingEmp, medicalAllowance: Number(e.target.value) })}
                  className="w-full text-xs border rounded p-2 mt-0.5 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Field Allowance</label>
                <input
                  type="number"
                  value={editingEmp.fieldAllowance || 0}
                  onChange={e => setEditingEmp({ ...editingEmp, fieldAllowance: Number(e.target.value) })}
                  className="w-full text-xs border rounded p-2 mt-0.5 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-extrabold text-slate-500">Other Allowance</label>
                <input
                  type="number"
                  value={editingEmp.otherAllowance || 0}
                  onChange={e => setEditingEmp({ ...editingEmp, otherAllowance: Number(e.target.value) })}
                  className="w-full text-xs border rounded p-2 mt-0.5 font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 border-t pt-3">
              <button type="button" onClick={() => setEditingEmp(null)} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold">Cancel</button>
              <button type="submit" className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-sm">Save Contract Changes</button>
            </div>
          </form>
        </div>
      )}

      {/* PRINTABLE EMPLOYEE REGISTER MODAL */}
      {showPrintRegisterModal && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-8 shadow-2xl border border-slate-200 space-y-6 my-auto">
            <div className="flex justify-between items-center border-b pb-4 print:hidden">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-emerald-600" />
                <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider">Official Worker Register Print Preview</h3>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md"
                >
                  🖨️ Print Document
                </button>
                <button
                  onClick={() => setShowPrintRegisterModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs"
                >
                  Close
                </button>
              </div>
            </div>

            {/* Printable Document Body */}
            <div className="p-4 border border-slate-200 rounded-xl space-y-6 text-slate-900" id="employee-register-print-sheet">
              {/* Farm Header */}
              <div className="flex justify-between items-start border-b border-slate-800 pb-4">
                <div>
                  <h1 className="text-xl font-black tracking-wider uppercase text-slate-950">{activeFarm?.name || "MABALA CLOUD AGRICULTURAL ESTATE"}</h1>
                  <p className="text-xs text-slate-600 mt-1">{activeFarm?.address || "Lusaka West Sector 4, Zambia"}</p>
                  <p className="text-xs text-slate-600">TPIN: <span className="font-mono font-bold">{activeFarm?.tpin || "1009823471"}</span> • Tel: {activeFarm?.phone || "+260 977 000000"}</p>
                </div>
                <div className="text-right">
                  <div className="bg-slate-900 text-white text-[10px] font-mono px-3 py-1 rounded font-extrabold uppercase">OFFICIAL HR REGISTER</div>
                  <div className="text-[11px] text-slate-500 font-mono mt-2">Date: {new Date().toLocaleDateString()}</div>
                </div>
              </div>

              {/* Title */}
              <div className="text-center space-y-1">
                <h2 className="text-sm font-black uppercase tracking-widest text-slate-900">MASTER WORKER CONTRACT REGISTER & HR AUDIT REPORT</h2>
                <p className="text-[11px] text-slate-500 italic">Audited list of active worker contracts, direct allowances, next of kin details, and statutory registration numbers.</p>
              </div>

              {/* Summary Bar */}
              <div className="grid grid-cols-4 gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs font-mono">
                <div>Total Staff: <strong>{effectiveEmployees.length}</strong></div>
                <div>Permanent: <strong>{effectiveEmployees.filter(e => (e.employmentStatus || "Permanent") === "Permanent").length}</strong></div>
                <div>Casuals/Probation: <strong>{effectiveEmployees.filter(e => e.employmentStatus !== "Permanent").length}</strong></div>
                <div>Monthly Payroll: <strong>{currencySymbol} {effectiveEmployees.reduce((acc, e) => acc + e.grossSalary, 0).toLocaleString()}</strong></div>
              </div>

              {/* Full Print Table */}
              <table className="w-full border-collapse text-[11px]">
                <thead>
                  <tr className="bg-slate-100 border-y border-slate-400 font-bold uppercase text-[9px] text-slate-700">
                    <th className="p-2 text-left">Worker ID & Name</th>
                    <th className="p-2 text-left">Role & Status</th>
                    <th className="p-2 text-left">Age / Marital / NRC</th>
                    <th className="p-2 text-left">Next of Kin</th>
                    <th className="p-2 text-right">Basic Pay</th>
                    <th className="p-2 text-right">Gross Pay</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {effectiveEmployees.map(emp => {
                    const age = calculateAge(emp.dateOfBirth);
                    return (
                      <tr key={emp.id} className="align-top">
                        <td className="p-2">
                          <div className="font-bold">{emp.name}</div>
                          <div className="text-[9px] font-mono text-slate-500">{emp.id}</div>
                        </td>
                        <td className="p-2">
                          <div>{emp.role}</div>
                          <div className="text-[9px] font-bold text-slate-600">{emp.employmentStatus || "Permanent"}</div>
                        </td>
                        <td className="p-2 text-[10px]">
                          <div>Age: {age !== null ? age : "N/A"} • {emp.maritalStatus || "N/A"}</div>
                          <div className="font-mono text-[9px] text-slate-500">NRC: {emp.nrcNumber || "N/A"}</div>
                        </td>
                        <td className="p-2 text-[10px]">
                          <div>{emp.nextOfKinName || emp.nextOfKin?.name || "N/A"} ({emp.nextOfKinRelationship || emp.nextOfKin?.relationship || "Kin"})</div>
                          <div className="font-mono text-[9px] text-slate-500">{emp.nextOfKinContact || emp.nextOfKin?.contactNumber || ""}</div>
                        </td>
                        <td className="p-2 text-right font-mono font-semibold">
                          {currencySymbol} {emp.contractRate.toLocaleString()}
                        </td>
                        <td className="p-2 text-right font-mono font-bold text-slate-950">
                          {currencySymbol} {emp.grossSalary.toLocaleString()}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {/* Signatures */}
              <div className="grid grid-cols-2 gap-12 pt-12 text-xs">
                <div className="border-t border-slate-400 pt-2 text-center">
                  <div className="font-extrabold uppercase">Farm Human Resource Officer</div>
                  <div className="text-[10px] text-slate-500">Sign & Date</div>
                </div>
                <div className="border-t border-slate-400 pt-2 text-center">
                  <div className="font-extrabold uppercase">Farm General Manager / Director</div>
                  <div className="text-[10px] text-slate-500">Sign & Date</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 1. PAYROLL RUN EXECUTION & DISBURSEMENT MODE MODAL */}
      {showPinModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 min-h-screen overflow-y-auto">
          <div className="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-scale-up font-sans my-auto">
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-5 sm:p-6 flex items-start justify-between border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-black text-lg shrink-0">
                  <Coins className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-black uppercase tracking-wider text-white">
                    Process Farm Payroll Run
                  </h3>
                  <p className="text-[11px] text-slate-400 font-medium mt-0.5">
                    {currentPayrollPreview.periodLabel} • {activeSelectedEmployees.length} Active Staff Members
                  </p>
                </div>
              </div>
              <button
                type="button"
                disabled={isDisbursing}
                onClick={() => setShowPinModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg text-lg font-bold transition-all disabled:opacity-30 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 sm:p-6 space-y-4">
              {/* Disbursement Mode Selector Tabs */}
              <div>
                <label className="text-[11px] uppercase font-extrabold text-slate-700 tracking-wider block mb-2">
                  Select Payroll Processing Mode:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setDisbursementMode("without_disbursement")}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      disbursementMode === "without_disbursement"
                        ? "bg-emerald-50 border-emerald-600 ring-2 ring-emerald-500/20 shadow-xs"
                        : "bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-extrabold text-xs text-slate-900">Without Disbursement</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                        disbursementMode === "without_disbursement" ? "bg-emerald-600 text-white" : "bg-slate-200 text-slate-600"
                      }`}>Recommended</span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Process payroll, generate employee payslips and statutory tax reports without ledger fund deductions.
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDisbursementMode("with_disbursement")}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      disbursementMode === "with_disbursement"
                        ? "bg-amber-50 border-amber-600 ring-2 ring-amber-500/20 shadow-xs"
                        : "bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-extrabold text-xs text-slate-900">With Disbursement</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                        disbursementMode === "with_disbursement" ? "bg-amber-600 text-white" : "bg-slate-200 text-slate-600"
                      }`}>Super Admin Payout</span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Deduct total payroll + platform fees from Mabala Farm Ledger, credit Super Admin, and submit manual payout queue.
                    </p>
                  </button>
                </div>
              </div>

              {/* Batch Breakdown Card */}
              <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 space-y-2.5 text-xs">
                <div className="flex justify-between items-center text-slate-600 font-medium">
                  <span>Selected Active Employees:</span>
                  <span className="font-bold text-slate-900 font-mono">{activeSelectedEmployees.length} Staff Members</span>
                </div>
                <div className="flex justify-between items-center text-slate-600 font-medium">
                  <span>Total Gross Wages:</span>
                  <span className="font-bold text-slate-900 font-mono">
                    {currencySymbol} {currentPayrollPreview.totals.totalGrossSalary.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between items-center text-slate-600 font-medium">
                  <span>Total Net Salaries:</span>
                  <span className="font-extrabold text-emerald-700 font-mono">
                    {currencySymbol} {currentPayrollPreview.totals.totalNetSalary.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                {disbursementMode === "with_disbursement" && (
                  <div className="flex justify-between items-center text-slate-600 font-medium">
                    <span>Mabala Platform Fee:</span>
                    <span className="font-bold text-slate-900 font-mono">
                      {currencySymbol} {currentPayrollPreview.totals.totalPlatformFees.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                )}

                <div className="pt-2 border-t border-slate-200 flex justify-between items-center text-sm font-black text-slate-900">
                  <span>{disbursementMode === "with_disbursement" ? "Total Ledger Deduction:" : "Net Payroll Value:"}</span>
                  <span className="text-slate-950 font-mono text-base">
                    {currencySymbol} {(disbursementMode === "with_disbursement" ? currentPayrollPreview.totals.grandTotal : currentPayrollPreview.totals.totalNetSalary).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              {/* Funding Source Card for With Disbursement */}
              {disbursementMode === "with_disbursement" && (
                <div className="p-3.5 bg-emerald-50/70 rounded-xl border border-emerald-200/80 flex items-center justify-between text-xs font-sans">
                  <div className="flex items-center gap-2.5">
                    <Wallet className="w-4 h-4 text-emerald-700 shrink-0" />
                    <div>
                      <span className="text-[10px] uppercase font-extrabold text-emerald-900 tracking-wider block">Funding Source</span>
                      <span className="font-bold text-slate-800">Mabala Farm Ledger</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-500 font-bold block">Available Balance:</span>
                    <span className="font-black font-mono text-emerald-800">
                      {currencySymbol} {walletBalances.lipilaBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              )}

              {/* Execution Form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleExecuteBulkDisbursement();
                }}
                className="space-y-4"
              >
                {/* Progress / Step Feedback during Execution */}
                {isDisbursing && (
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center gap-3 animate-fade-in">
                    <RefreshCw className="w-4 h-4 text-emerald-600 animate-spin shrink-0" />
                    <span className="text-xs font-bold text-emerald-900 leading-tight">
                      {disbursementStepText || "Processing payroll run..."}
                    </span>
                  </div>
                )}

                {/* Error Alert */}
                {disbursementError && (
                  <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-xs text-rose-700 font-bold flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{disbursementError}</span>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-3 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    disabled={isDisbursing}
                    onClick={() => setShowPinModal(false)}
                    className="w-1/3 py-3 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all disabled:opacity-40 cursor-pointer min-h-[44px]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isDisbursing}
                    className="w-2/3 py-3 px-4 bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-md shadow-emerald-600/20 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
                  >
                    {isDisbursing ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Processing Payroll...</span>
                      </>
                    ) : disbursementMode === "without_disbursement" ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                        <span>Process Payroll & Generate Slips</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 text-amber-300" />
                        <span>Deduct & Submit Payout Request ({currencySymbol} {currentPayrollPreview.totals.grandTotal.toLocaleString(undefined, { minimumFractionDigits: 0 })})</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* 2. IN-CONTEXT LIPILA WALLET TOP-UP MODAL */}
      {showTopUpModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 min-h-screen overflow-y-auto">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-scale-up font-sans my-auto">
            {/* Header */}
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold shrink-0">
                  <Coins className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider text-white">
                    Top Up Farm Lipila Wallet
                  </h3>
                  <p className="text-[11px] text-slate-400 font-medium mt-0.5">
                    Instant Mobile Money Deposit via Lipila Gateway
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowTopUpModal(false);
                  setTopUpStep("FORM");
                  setTopUpError(null);
                  setTopUpSuccess(null);
                }}
                className="text-slate-400 hover:text-white p-1 rounded-lg text-lg font-bold transition-all cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Content per Step */}
            <div className="p-5 sm:p-6 space-y-4">
              {/* STEP 1: FORM */}
              {topUpStep === "FORM" && (
                <form onSubmit={handleInitiateTopUp} className="space-y-4">
                  {/* Current Balance Bar */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex justify-between items-center text-xs">
                    <span className="text-slate-500 font-bold uppercase text-[10px]">Current Lipila Balance:</span>
                    <span className="font-mono font-black text-emerald-700 text-sm">
                      {currencySymbol} {walletBalances.lipilaBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                  </div>

                  {/* Network Operator Selection */}
                  <div>
                    <label className="text-[10px] uppercase font-extrabold text-slate-600 block mb-1.5">
                      Select Mobile Money Operator
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(["Airtel Money", "MTN MoMo", "Zamtel Kwacha"] as const).map(prov => (
                        <button
                          key={prov}
                          type="button"
                          onClick={() => setTopUpProvider(prov)}
                          className={`p-2.5 rounded-xl border text-xs font-bold transition-all flex flex-col items-center justify-center gap-1 cursor-pointer min-h-[44px] ${
                            topUpProvider === prov
                              ? prov === "Airtel Money"
                                ? "bg-red-50 border-red-500 text-red-700 shadow-xs ring-2 ring-red-500/20"
                                : prov === "MTN MoMo"
                                ? "bg-amber-50 border-amber-500 text-amber-800 shadow-xs ring-2 ring-amber-500/20"
                                : "bg-emerald-50 border-emerald-500 text-emerald-800 shadow-xs ring-2 ring-emerald-500/20"
                              : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"
                          }`}
                        >
                          <span className="text-base">
                            {prov === "Airtel Money" ? "🔴" : prov === "MTN MoMo" ? "🟡" : "🟢"}
                          </span>
                          <span className="text-[10px] leading-tight text-center">{prov}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Phone Number */}
                  <div>
                    <label className="text-[10px] uppercase font-extrabold text-slate-600 block mb-1">
                      Payer Mobile Money Number
                    </label>
                    <input
                      type="tel"
                      value={topUpPhone}
                      onChange={e => setTopUpPhone(e.target.value)}
                      placeholder="0977123456"
                      required
                      className="w-full text-xs font-mono font-bold p-3 border border-slate-300 rounded-xl bg-slate-50 focus:bg-white focus:border-emerald-500 outline-none"
                    />
                    <span className="text-[10px] text-slate-400 mt-1 block">
                      Airtel (097/077), MTN (096/076), Zamtel (095/075)
                    </span>
                  </div>

                  {/* Amount */}
                  <div>
                    <label className="text-[10px] uppercase font-extrabold text-slate-600 block mb-1">
                      Top-Up Amount ({currencySymbol})
                    </label>
                    <input
                      type="number"
                      min={10}
                      value={topUpAmount}
                      onChange={e => setTopUpAmount(Number(e.target.value))}
                      required
                      className="w-full text-base font-mono font-black p-3 border border-slate-300 rounded-xl bg-slate-50 focus:bg-white focus:border-emerald-500 outline-none text-slate-900"
                    />
                    {/* Quick Amount Pills */}
                    <div className="flex gap-2 mt-2">
                      {[500, 1000, 2500, 5000, 10000].map(amt => (
                        <button
                          key={amt}
                          type="button"
                          onClick={() => setTopUpAmount(amt)}
                          className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-mono font-bold rounded-lg border border-slate-200 transition cursor-pointer"
                        >
                          +{amt}
                        </button>
                      ))}
                    </div>
                  </div>

                  {topUpError && (
                    <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 font-bold flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{topUpError}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={topUpLoading}
                    className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-md shadow-emerald-600/20 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
                  >
                    {topUpLoading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Sending Lipila STK Push...</span>
                      </>
                    ) : (
                      <>
                        <span>Initiate Mobile Deposit ({currencySymbol} {topUpAmount.toLocaleString()}) ➜</span>
                      </>
                    )}
                  </button>
                </form>
              )}

              {/* STEP 2: PENDING_PIN */}
              {topUpStep === "PENDING_PIN" && (
                <div className="text-center space-y-4 py-2 animate-fade-in">
                  <div className="relative w-20 h-20 mx-auto">
                    <div className="absolute inset-0 rounded-full border-4 border-emerald-200 animate-ping opacity-50" />
                    <div className="w-20 h-20 rounded-full bg-emerald-100 border-2 border-emerald-500 flex items-center justify-center text-3xl">
                      📱
                    </div>
                  </div>

                  <div className="space-y-1">
                    <h4 className="text-base font-black text-slate-900 uppercase tracking-wide">
                      PIN Approval Prompt Sent!
                    </h4>
                    <p className="text-xs text-slate-600 font-medium max-w-sm mx-auto leading-relaxed">
                      A payment authorization prompt has been sent via the <strong>Lipila API</strong> to your handset at <strong className="font-mono text-slate-900">{topUpPhone}</strong> ({topUpProvider}).
                    </p>
                  </div>

                  <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 space-y-1 text-left">
                    <div className="font-extrabold uppercase text-[10px] flex items-center gap-1.5 text-amber-950">
                      <span>⚡</span> Next Steps on Handset:
                    </div>
                    <ol className="list-decimal pl-4 space-y-0.5 text-[11px]">
                      <li>Check your mobile handset screen for the prompt.</li>
                      <li>Enter your secret Mobile Money PIN to approve the ZMW {topUpAmount.toLocaleString()} transfer.</li>
                      <li>This screen will automatically confirm and credit your farm wallet upon receipt.</li>
                    </ol>
                  </div>

                  <div className="flex justify-between items-center px-4 py-2.5 bg-slate-100 rounded-xl text-xs font-mono font-bold text-slate-700">
                    <span>Reference ID: {topUpRefId || "LIP-BATCH"}</span>
                    <span className="text-emerald-700">⏱️ {Math.floor(topUpCountdown / 60)}:{(topUpCountdown % 60).toString().padStart(2, "0")}</span>
                  </div>

                  <div className="pt-2 flex justify-center">
                    <button
                      type="button"
                      onClick={() => {
                        setTopUpStep("FORM");
                        setTopUpError(null);
                      }}
                      className="text-slate-500 hover:text-slate-800 text-xs font-bold underline cursor-pointer"
                    >
                      Cancel / Change Number
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: SUCCESS */}
              {topUpStep === "SUCCESS" && (
                <div className="text-center space-y-4 py-2 animate-fade-in">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 border-2 border-emerald-500 flex items-center justify-center text-3xl font-black mx-auto">
                    ✓
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-base font-black text-slate-900 uppercase">
                      Top-Up Successful!
                    </h4>
                    <p className="text-xs text-emerald-800 font-medium">
                      {topUpSuccess || `Credited ZMW ${topUpAmount.toLocaleString()} to your Farm Lipila Wallet.`}
                    </p>
                  </div>

                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs font-mono font-bold text-emerald-900 flex justify-between items-center">
                    <span>Updated Lipila Balance:</span>
                    <span className="text-sm font-black">{currencySymbol} {walletBalances.lipilaBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setShowTopUpModal(false);
                      setTopUpStep("FORM");
                    }}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-md shadow-emerald-600/20 cursor-pointer min-h-[44px]"
                  >
                    Done / Return to Payroll
                  </button>
                </div>
              )}

              {/* STEP 4: FAILED */}
              {topUpStep === "FAILED" && (
                <div className="text-center space-y-4 py-2 animate-fade-in">
                  <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 border-2 border-rose-500 flex items-center justify-center text-3xl font-black mx-auto">
                    ✕
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-base font-black text-slate-900 uppercase">
                      Payment Authorization Failed
                    </h4>
                    <p className="text-xs text-rose-700 font-medium">
                      {topUpError || "Mobile Money PIN prompt timed out or was rejected on the mobile handset."}
                    </p>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowTopUpModal(false)}
                      className="w-1/2 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer min-h-[44px]"
                    >
                      Close
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setTopUpStep("FORM");
                        setTopUpError(null);
                      }}
                      className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition cursor-pointer min-h-[44px]"
                    >
                      Try Again
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. PAYROLL RUN POST-DISBURSEMENT SUCCESS & AUDIT SUMMARY MODAL */}
      {showRunSuccessModal && lastExecutedRun && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 min-h-screen overflow-y-auto">
          <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-scale-up font-sans my-auto">
            {/* Header */}
            <div className="bg-emerald-700 text-white p-6 flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-white/20 text-white flex items-center justify-center font-black text-2xl shrink-0">
                  ✓
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black uppercase tracking-wide">
                    Payroll Run Successfully Disbursed!
                  </h3>
                  <p className="text-xs text-emerald-100 font-mono mt-0.5">
                    Batch ID: {lastExecutedRun.id} • {lastExecutedRun.periodLabel}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowRunSuccessModal(false)}
                className="text-emerald-200 hover:text-white p-1 rounded-lg text-xl font-bold transition-all cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Summary Body */}
            <div className="p-6 space-y-5">
              {/* Metrics Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[9px] uppercase font-bold text-slate-400 block">Total Staff Disbursed</span>
                  <span className="text-xl font-black text-slate-900 font-mono">{lastExecutedRun.lines.length}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[9px] uppercase font-bold text-slate-400 block">Net Wages Paid</span>
                  <span className="text-base font-black text-emerald-700 font-mono">
                    {currencySymbol} {lastExecutedRun.totals.totalNetSalary.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[9px] uppercase font-bold text-slate-400 block">Total Fees</span>
                  <span className="text-base font-bold text-slate-700 font-mono">
                    {currencySymbol} {(lastExecutedRun.totals.totalLipilaFees + lastExecutedRun.totals.totalPlatformFees).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[9px] uppercase font-bold text-slate-400 block">Total Deducted</span>
                  <span className="text-base font-black text-slate-950 font-mono">
                    {currencySymbol} {lastExecutedRun.totals.grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              {/* Individual Employee Disbursed List */}
              <div>
                <h4 className="text-xs font-extrabold uppercase text-slate-700 tracking-wider mb-2">
                  Itemized Mobile Money Disbursed Workers
                </h4>
                <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100 text-xs">
                  {lastExecutedRun.lines.map((line: PayrollRunLine) => (
                    <div key={line.employeeId} className="p-3 flex justify-between items-center hover:bg-slate-50">
                      <div>
                        <div className="font-bold text-slate-900">{line.employeeName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {(line.mobileMoneyProvider || "MOMO").toUpperCase()} • {maskMobileNumber(line.mobileMoneyNumber)} • Ref: {line.lipilaTransactionRef || "LIP-DISB"}
                        </div>
                      </div>
                      <div className="text-right font-mono">
                        <div className="font-extrabold text-emerald-700">
                          {currencySymbol} {line.netSalary.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </div>
                        <div className="text-[9px] text-slate-400">Fee: {currencySymbol} {line.lipilaFee.toFixed(2)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-2.5 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => generatePayrollRunReportPDF(lastExecutedRun, activeFarm?.name || "Mabala Farm")}
                  className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer min-h-[44px]"
                >
                  <FileDown className="w-4 h-4 text-emerald-400" />
                  <span>Download Audit PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab("history");
                    setShowRunSuccessModal(false);
                  }}
                  className="px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer min-h-[44px]"
                >
                  <ClipboardList className="w-4 h-4 text-emerald-600" />
                  <span>View in History</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowRunSuccessModal(false)}
                  className="ml-auto px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer min-h-[44px]"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MABALA LEDGER: 5-SCREEN BULK DISBURSEMENT MODAL (OUT BUTTON) */}
      <BulkDisbursementModal
        isOpen={showLipilaDisbursementModal}
        onClose={() => setShowLipilaDisbursementModal(false)}
        tenantId="TENANT-001"
        tenantName={activeFarm?.name || "Farm Operations"}
        currentBalance={walletBalances.lipilaBalance}
        userEmail="farmer@valleyfarms.zm"
        userId="user_default"
        currencySymbol={currencySymbol}
        onDisbursementComplete={() => {
          setWalletBalances(getWalletBalances("TENANT-001"));
        }}
      />
    </div>
  );
}


import React, { useState, useEffect, useMemo } from "react";
import { dispatchSafeEvent } from "../utils/safeEvent";
import { normalizeZambianMobileNumber, isValidZambianMobileNumber } from "../utils/phoneUtils";
import { DealerCreditPOS } from "./agc/DealerCreditPOS";
import AgroDealerReportCentrePanel from "./AgroDealerReportCentrePanel";
import InstitutionalReportCentre from "./institution/InstitutionalReportCentre";
import { DdaccManagementDesk } from "./ddacc/DdaccManagementDesk";
import {
  Boxes,
  Store,
  Coins,
  FileSpreadsheet,
  Building2,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowUpRight,
  ArrowRight,
  ArrowDownLeft,
  QrCode,
  Share2,
  RefreshCw,
  FileText,
  Printer,
  ShieldCheck,
  Send,
  Zap,
  Sparkles,
  ChevronRight,
  X,
  UserCheck,
  Building,
  MapPin,
  Calendar,
  Layers,
  Award,
  BadgeCheck,
  Tag,
  DollarSign,
  CreditCard,
  Wallet,
  Users,
  Smartphone,
  Check,
  Receipt,
  Trash2,
  Ban,
  Upload,
  Download,
  UploadCloud,
  FileCheck,
  PackagePlus,
  Table,
  Lock,
  BarChart2,
  BarChart3
} from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, Tooltip } from "recharts";

import {
  AgroDealerSKU,
  StockMovement,
  ConsignmentAgreement,
  StockGrant,
  DealerLedgerRollup,
  ReconciliationRun,
  AgroDealerTenant,
  ReturnToSupplierRequest,
  AgroCategory,
  StockMovementType,
  SupplierCatalogItem
} from "../types";

import {
  INITIAL_AGRO_DEALERS,
  INITIAL_CONSIGNMENT_AGREEMENTS,
  INITIAL_AGRO_SKUS,
  INITIAL_STOCK_MOVEMENTS,
  INITIAL_STOCK_GRANTS,
  INITIAL_RECONCILIATION_RUNS,
  INITIAL_RETURNS_REQUESTS,
  INITIAL_SUPPLIER_CATALOG
} from "../data/agroDealerData";

import {
  NormalizedImportSKU,
  NormalizedSupplierCatalogRow,
  NormalizedConsignmentGrantRow,
  processRawSKURows,
  processRawSupplierCatalogRows,
  processRawConsignmentGrantRows,
  parseExcelOrCsvFile,
  parseCsvTextString,
  downloadSampleTemplate
} from "../utils/excelCsvCatalogHelper";

import { generateAgroAIBrief, AIBriefResult } from "../utils/aiBriefGenerator";
import { safeFetchJsonClient } from "../App";
import {
  calculateDisbursementFees,
  generateConsignmentSettlementReport,
  generatePOSReconciliation,
  generateSupplierSalesVelocity,
  generateDealerReceivablesAging,
  parseBulkSKUCSV
} from "../services/mabalaPlatformEngine";

export interface SupplierInstitution {
  id: string;
  name: string;
  pacraTpin?: string;
  registeredAddress: string;
  productCategories: AgroCategory[];
  nominatedAdmins: { name: string; email: string; phone?: string }[];
  capabilities: string[];
  createdAt: string;
}

export const ZAMBIAN_LOCATIONS: Record<string, string[]> = {
  "Southern Province": ["Choma", "Monze", "Mazabuka", "Kalomo", "Namwala", "Sinazongwe", "Livingstone", "Gwembe", "Kazungula", "Zimba"],
  "Central Province": ["Kabwe", "Mkushi", "Mumbwa", "Kapiri Mposhi", "Serenje", "Chisamba", "Chibombo", "Itezhi-Tezhi"],
  "Eastern Province": ["Chipata", "Petauke", "Katete", "Lundazi", "Nyimba", "Sinda", "Chadiza", "Mambwe"],
  "Copperbelt Province": ["Ndola", "Kitwe", "Chingola", "Mufulira", "Luanshya", "Kalulushi", "Chililabombwe", "Mpongwe", "Lufwanyama"],
  "Lusaka Province": ["Lusaka", "Kafue", "Chongwe", "Chirundu", "Rufunsa", "Luangwa"],
  "Northern Province": ["Kasama", "Mbala", "Luwingu", "Mpulungu", "Mporokoso", "Senga Hill"],
  "Luapula Province": ["Mansa", "Nchelenge", "Samfya", "Kawambwa", "Mwense"],
  "Muchinga Province": ["Chinsali", "Mpika", "Isoka", "Nakonde", "Shiwang'andu"],
  "North-Western Province": ["Solwezi", "Mwinilunga", "Kasempa", "Zambezi", "Kabompo"],
  "Western Province": ["Mongu", "Senanga", "Kaoma", "Kalabo", "Sesheke"]
};

export const DISTRICT_TOWN_MAP: Record<string, { towns: string[]; coords: Record<string, { lat: number; lng: number }> }> = {
  "Choma": {
    towns: ["Choma Central Market Area", "Choma Industrial Zone", "Macha Road Commercial Post", "Batoka Agro Depot"],
    coords: {
      "Choma Central Market Area": { lat: -16.8067, lng: 26.9850 },
      "Choma Industrial Zone": { lat: -16.8200, lng: 27.0010 },
      "Macha Road Commercial Post": { lat: -16.7900, lng: 26.9500 },
      "Batoka Agro Depot": { lat: -16.9100, lng: 27.1200 }
    }
  },
  "Monze": {
    towns: ["Monze Main Commercial Hub", "Monze Station Road", "Luyaba Agro Market"],
    coords: {
      "Monze Main Commercial Hub": { lat: -16.2731, lng: 27.4789 },
      "Monze Station Road": { lat: -16.2650, lng: 27.4850 },
      "Luyaba Agro Market": { lat: -16.3100, lng: 27.4200 }
    }
  },
  "Mazabuka": {
    towns: ["Mazabuka Town Center", "Nakambala Commercial Strip", "Nega Nega Junction"],
    coords: {
      "Mazabuka Town Center": { lat: -15.8560, lng: 27.7483 },
      "Nakambala Commercial Strip": { lat: -15.8700, lng: 27.7600 },
      "Nega Nega Junction": { lat: -15.7900, lng: 27.9100 }
    }
  },
  "Livingstone": {
    towns: ["Livingstone Central Market", "Maramba Commercial Area", "Dambwa North Trading Post"],
    coords: {
      "Livingstone Central Market": { lat: -17.8419, lng: 25.8544 },
      "Maramba Commercial Area": { lat: -17.8550, lng: 25.8620 },
      "Dambwa North Trading Post": { lat: -17.8200, lng: 25.8400 }
    }
  },
  "Kabwe": {
    towns: ["Kabwe Main Town Area", "Kasanda Mine Market", "Green Leaf Agro Zone"],
    coords: {
      "Kabwe Main Town Area": { lat: -14.4283, lng: 28.4514 },
      "Kasanda Mine Market": { lat: -14.4400, lng: 28.4600 },
      "Green Leaf Agro Zone": { lat: -14.4100, lng: 28.4350 }
    }
  },
  "Mkushi": {
    towns: ["Mkushi Boma Area", "Mkushi Farming Block Depot", "Fiphepa Market"],
    coords: {
      "Mkushi Boma Area": { lat: -13.6212, lng: 29.3947 },
      "Mkushi Farming Block Depot": { lat: -13.6500, lng: 29.4200 },
      "Fiphepa Market": { lat: -13.6000, lng: 29.3700 }
    }
  },
  "Chipata": {
    towns: ["Chipata Central Business Area", "Kapata Market District", "Mchinji Border Agro Hub"],
    coords: {
      "Chipata Central Business Area": { lat: -13.6444, lng: 32.6469 },
      "Kapata Market District": { lat: -13.6350, lng: 32.6520 },
      "Mchinji Border Agro Hub": { lat: -13.7100, lng: 32.8000 }
    }
  },
  "Lusaka": {
    towns: ["Lusaka West (Mumbwa Road)", "Lusaka Central Business District", "Soweto Market Agro Hub", "Matero North Commercial Area", "Chelston Agro Depot"],
    coords: {
      "Lusaka West (Mumbwa Road)": { lat: -15.4220, lng: 28.2000 },
      "Lusaka Central Business District": { lat: -15.4167, lng: 28.2833 },
      "Soweto Market Agro Hub": { lat: -15.4250, lng: 28.2710 },
      "Matero North Commercial Area": { lat: -15.3800, lng: 28.2600 },
      "Chelston Agro Depot": { lat: -15.3700, lng: 28.3800 }
    }
  },
  "Ndola": {
    towns: ["Ndola Central Commercial Zone", "Masala Market Area", "Bwana Mkubwa Industrial Hub"],
    coords: {
      "Ndola Central Commercial Zone": { lat: -12.9587, lng: 28.6366 },
      "Masala Market Area": { lat: -12.9750, lng: 28.6480 },
      "Bwana Mkubwa Industrial Hub": { lat: -13.0100, lng: 28.6700 }
    }
  },
  "Kitwe": {
    towns: ["Kitwe Town Center / Parklands", "Chisokone Market Hub", "Chamboli Commercial Strip"],
    coords: {
      "Kitwe Town Center / Parklands": { lat: -12.8024, lng: 28.2132 },
      "Chisokone Market Hub": { lat: -12.8100, lng: 28.2050 },
      "Chamboli Commercial Strip": { lat: -12.8400, lng: 28.2300 }
    }
  },
  "Kasama": {
    towns: ["Kasama Central Market", "Tazara Agro Zone", "Mungwi Road Depot"],
    coords: {
      "Kasama Central Market": { lat: -10.2129, lng: 31.1808 },
      "Tazara Agro Zone": { lat: -10.2250, lng: 31.1950 },
      "Mungwi Road Depot": { lat: -10.1980, lng: 31.1650 }
    }
  },
  "Mansa": {
    towns: ["Mansa Central Town Area", "Senama Commercial Post", "Samfya Road Junction"],
    coords: {
      "Mansa Central Town Area": { lat: -11.1998, lng: 28.8943 },
      "Senama Commercial Post": { lat: -11.2100, lng: 28.9100 },
      "Samfya Road Junction": { lat: -11.1850, lng: 28.8750 }
    }
  },
  "Solwezi": {
    towns: ["Solwezi Central Boma", "Kansanshi Mine Commercial Zone", "Kyawama Market"],
    coords: {
      "Solwezi Central Boma": { lat: -12.1688, lng: 26.3894 },
      "Kansanshi Mine Commercial Zone": { lat: -12.1400, lng: 26.4100 },
      "Kyawama Market": { lat: -12.1850, lng: 26.3750 }
    }
  },
  "Mongu": {
    towns: ["Mongu Main Market Area", "Limulunga Commercial Center", "Lewanika Agro Zone"],
    coords: {
      "Mongu Main Market Area": { lat: -15.2484, lng: 23.1274 },
      "Limulunga Commercial Center": { lat: -15.1950, lng: 23.1350 },
      "Lewanika Agro Zone": { lat: -15.2600, lng: 23.1100 }
    }
  }
};

export const INITIAL_SUPPLIER_INSTITUTIONS: SupplierInstitution[] = [];

export const PACKAGING_UNITS = [
  "Kg",
  "Liters",
  "Grams",
  "Milliliters",
  "Bags",
  "Sachets",
  "Bottles",
  "Tins",
  "Packs",
  "Units"
];

export interface PosSaleRecord {
  id: string;
  saleId: string;
  date: string;
  dealerId: string;
  dealerName: string;
  customerName: string;
  customerPhone: string;
  items: { productName: string; category: string; qty: number; unitPrice: number; subtotal: number }[];
  totalAmount: number;
  paymentMethod: string;
  carrier?: string;
  lipilaTxId?: string;
  inventoryDeducted: boolean;
}

export const detectCarrier = (phone: string) => {
  const clean = phone ? phone.replace(/[^0-9]/g, "") : "";
  if (/^(260|0)?(97|77)/.test(clean)) {
    return { name: "Airtel Money", code: "AIRTEL", badgeBg: "bg-red-600 text-white", border: "border-red-500", text: "text-red-600", lightBg: "bg-red-50" };
  }
  if (/^(260|0)?(96|76)/.test(clean)) {
    return { name: "MTN Mobile Money", code: "MTN", badgeBg: "bg-amber-500 text-slate-900", border: "border-amber-400", text: "text-amber-700", lightBg: "bg-amber-50" };
  }
  if (/^(260|0)?(95|75)/.test(clean)) {
    return { name: "Zamtel Kwacha", code: "ZAMTEL", badgeBg: "bg-emerald-600 text-white", border: "border-emerald-500", text: "text-emerald-700", lightBg: "bg-emerald-50" };
  }
  return { name: "Lipila Mobile Money", code: "GENERIC", badgeBg: "bg-emerald-700 text-white", border: "border-emerald-600", text: "text-emerald-800", lightBg: "bg-emerald-50" };
};

interface AgroDealerConsignmentPanelProps {
  currentTenantId?: string;
  activeFarmName?: string;
  currencySymbol?: string;
  userRole?: string;
  currentRole?: string;
  userEmail?: string;
  initialMode?: "DEALER" | "SUPPLIER" | "SUPER_ADMIN";
  onNavigateToAgronomist?: () => void;
}

export default function AgroDealerConsignmentPanel({
  currentTenantId = "dealer-choma-01",
  activeFarmName = "Choma Agro-Inputs & Seed Centre",
  currencySymbol = "ZK",
  userRole = "agro_dealer",
  currentRole,
  userEmail = "support@mabala.cloud",
  initialMode,
  onNavigateToAgronomist
}: AgroDealerConsignmentPanelProps) {
  const isExplicitSuperAdminMode = initialMode === "SUPER_ADMIN" && (currentRole === "Platform Administrator" || currentRole === "Super Admin" || userRole === "super_admin" || userRole === "platform_admin" || userEmail === "support@mabala.cloud");

  const isAgroDealer = !isExplicitSuperAdminMode && (userRole === "agro_dealer" || userRole === "Agro-Dealer" || currentRole === "Agro-Dealer" || currentRole === "Agro Dealer" || initialMode === "DEALER");
  const isSupplier = !isExplicitSuperAdminMode && !isAgroDealer && (userRole === "supplier" || userRole === "Supplier" || currentRole === "Supplier" || currentRole === "Seed Company" || initialMode === "SUPPLIER");
  const isPlatformAdmin = isExplicitSuperAdminMode || (!isAgroDealer && !isSupplier && (currentRole === "Platform Administrator" || currentRole === "Super Admin" || userRole === "super_admin" || userRole === "platform_admin"));

  // Persistence state in localStorage / memory
  const [activeWorkspaceMode, setActiveWorkspaceMode] = useState<"DEALER" | "SUPPLIER" | "SUPER_ADMIN">(() => {
    if (isAgroDealer) return "DEALER";
    if (initialMode && initialMode !== "SUPER_ADMIN") return initialMode;
    if (isSupplier) return "SUPPLIER";
    if (isPlatformAdmin) return "SUPER_ADMIN";
    return "DEALER";
  });
  
  // Master Collections
  const [dealers, setDealers] = useState<AgroDealerTenant[]>(() => {
    const saved = localStorage.getItem("mabala_agd_dealers");
    return saved ? JSON.parse(saved) : INITIAL_AGRO_DEALERS;
  });

  const [agreements, setAgreements] = useState<ConsignmentAgreement[]>(() => {
    const saved = localStorage.getItem("mabala_agd_agreements");
    return saved ? JSON.parse(saved) : INITIAL_CONSIGNMENT_AGREEMENTS;
  });

  const [skus, setSkus] = useState<AgroDealerSKU[]>(() => {
    const saved = localStorage.getItem("mabala_agd_skus");
    return saved ? JSON.parse(saved) : INITIAL_AGRO_SKUS;
  });

  const [movements, setMovements] = useState<StockMovement[]>(() => {
    const saved = localStorage.getItem("mabala_agd_movements");
    return saved ? JSON.parse(saved) : INITIAL_STOCK_MOVEMENTS;
  });

  const [grants, setGrants] = useState<StockGrant[]>(() => {
    const saved = localStorage.getItem("mabala_agd_grants");
    return saved ? JSON.parse(saved) : INITIAL_STOCK_GRANTS;
  });

  const [reconciliations, setReconciliations] = useState<ReconciliationRun[]>(() => {
    const saved = localStorage.getItem("mabala_agd_reconciliations");
    return saved ? JSON.parse(saved) : INITIAL_RECONCILIATION_RUNS;
  });

  const [returns, setReturns] = useState<ReturnToSupplierRequest[]>(() => {
    const saved = localStorage.getItem("mabala_agd_returns");
    return saved ? JSON.parse(saved) : INITIAL_RETURNS_REQUESTS;
  });

  const [suppliers, setSuppliers] = useState<SupplierInstitution[]>(() => {
    const saved = localStorage.getItem("mabala_agd_suppliers");
    return saved ? JSON.parse(saved) : INITIAL_SUPPLIER_INSTITUTIONS;
  });

  // Supplier Stock Catalog state
  const [supplierCatalog, setSupplierCatalog] = useState<SupplierCatalogItem[]>(() => {
    const saved = localStorage.getItem("mabala_supplier_catalog");
    return saved ? JSON.parse(saved) : INITIAL_SUPPLIER_CATALOG;
  });

  // Farm Balance local simulation (internal Lipila mirror - zero rated)
  const [dealerBalance, setDealerBalance] = useState<number>(() => {
    localStorage.setItem("mabala_agd_dealer_balance", "0");
    return 0.00;
  });

  const [supplierBalance, setSupplierBalance] = useState<number>(() => {
    localStorage.setItem("mabala_agd_supplier_balance", "0");
    return 0.00;
  });

  // Save changes to localStorage and dispatch storage event for Marketplace Auto-Sync
  useEffect(() => {
    localStorage.setItem("mabala_agd_dealers", JSON.stringify(dealers));
    dispatchSafeEvent("storage");
  }, [dealers]);
  useEffect(() => {
    localStorage.setItem("mabala_agd_agreements", JSON.stringify(agreements));
  }, [agreements]);
  useEffect(() => {
    localStorage.setItem("mabala_agd_skus", JSON.stringify(skus));
    dispatchSafeEvent("storage");
  }, [skus]);
  useEffect(() => {
    localStorage.setItem("mabala_agd_movements", JSON.stringify(movements));
  }, [movements]);
  useEffect(() => {
    localStorage.setItem("mabala_agd_grants", JSON.stringify(grants));
  }, [grants]);
  useEffect(() => {
    localStorage.setItem("mabala_agd_reconciliations", JSON.stringify(reconciliations));
  }, [reconciliations]);
  useEffect(() => {
    localStorage.setItem("mabala_agd_returns", JSON.stringify(returns));
  }, [returns]);
  useEffect(() => {
    localStorage.setItem("mabala_agd_suppliers", JSON.stringify(suppliers));
  }, [suppliers]);
  useEffect(() => {
    localStorage.setItem("mabala_supplier_catalog", JSON.stringify(supplierCatalog));
  }, [supplierCatalog]);
  useEffect(() => {
    localStorage.setItem("mabala_agd_dealer_balance", String(dealerBalance));
  }, [dealerBalance]);
  useEffect(() => {
    localStorage.setItem("mabala_agd_supplier_balance", String(supplierBalance));
  }, [supplierBalance]);

  // POS Sales Tracker Persistent State
  const [posSales, setPosSales] = useState<PosSaleRecord[]>(() => {
    const saved = localStorage.getItem("mabala_agd_pos_sales");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem("mabala_agd_pos_sales", JSON.stringify(posSales));
  }, [posSales]);

  // Selected active context
  const [activeDealerId, setActiveDealerId] = useState<string>(() => {
    const match = dealers.find(d => 
      (d.ownerEmail && userEmail && d.ownerEmail.toLowerCase() === userEmail.toLowerCase()) ||
      (d.tradingName && activeFarmName && d.tradingName.toLowerCase() === activeFarmName.toLowerCase()) ||
      (d.businessName && activeFarmName && d.businessName.toLowerCase() === activeFarmName.toLowerCase())
    );
    return match ? match.id : (dealers[0]?.id || "dealer-choma-01");
  });
  const [activeSupplierId, setActiveSupplierId] = useState<string>("inst-zambezi-seed");

  // Lock workspace mode for Agro-Dealer users
  useEffect(() => {
    if (isAgroDealer && activeWorkspaceMode !== "DEALER") {
      setActiveWorkspaceMode("DEALER");
    }
  }, [isAgroDealer, activeWorkspaceMode]);

  // Sync active dealer shop context with registered trading name or store name
  useEffect(() => {
    if (!activeFarmName && !userEmail) return;

    let matched = dealers.find(d => 
      (d.ownerEmail && userEmail && d.ownerEmail.toLowerCase() === userEmail.toLowerCase()) ||
      (d.tradingName && activeFarmName && d.tradingName.toLowerCase() === activeFarmName.toLowerCase()) ||
      (d.businessName && activeFarmName && d.businessName.toLowerCase() === activeFarmName.toLowerCase())
    );

    if (matched) {
      if (activeDealerId !== matched.id) {
        setActiveDealerId(matched.id);
      }
    } else if (isAgroDealer && activeFarmName) {
      const newDealer: AgroDealerTenant = {
        id: "dealer-user-" + Date.now(),
        businessName: activeFarmName,
        tradingName: activeFarmName,
        ownerName: activeFarmName.split(" ")[0] || "Store Owner",
        ownerPhone: "+260977000000",
        ownerEmail: userEmail,
        province: "Copperbelt Province",
        district: "Ndola",
        city: "Ndola Central",
        gpsLocation: { lat: -12.975, lng: 28.648 },
        canDeliver: true,
        lipilaPaymentLinkId: "LINK-" + Math.floor(1000 + Math.random() * 9000),
        subscriptionStatus: "active",
        subscriptionTier: "monthly_180",
        createdAt: new Date().toISOString()
      };
      setDealers(prev => {
        const updated = [newDealer, ...prev];
        localStorage.setItem("mabala_agd_dealers", JSON.stringify(updated));
        return updated;
      });
      setActiveDealerId(newDealer.id);
    }
  }, [userEmail, activeFarmName, isAgroDealer]);

  // Dealer Tab
  const [dealerSubTab, setDealerSubTab] = useState<"INVENTORY" | "MOVEMENTS" | "POS" | "POS_SALES" | "REMITTANCE" | "FINANCIAL_RECONCILIATION" | "AGC_CREDIT_POS" | "REPORTS" | "BULK_IMPORT" | "DDACC_LOANS">("INVENTORY");
  // Supplier Tab
  const [supplierSubTab, setSupplierSubTab] = useState<"NETWORK" | "SUPPLIER_CATALOG" | "GRANTS" | "CREDIT_LINES" | "AGREEMENTS" | "RECONCILIATION" | "REPORTS" | "BULK_ALLOCATION" | "DDACC_LOANS">("NETWORK");
  const [supplierReportViewMode, setSupplierReportViewMode] = useState<"velocity" | "full_centre">("velocity");

  // Filter & Search states
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("ALL");
  const [supplierFilter, setSupplierFilter] = useState<string>("ALL");
  const [provinceFilter, setProvinceFilter] = useState<string>("ALL");

  // Modals & Forms
  const [showAddSkuModal, setShowAddSkuModal] = useState(false);
  const [addSkuModalTab, setAddSkuModalTab] = useState<"SINGLE" | "BULK">("SINGLE");

  // Supplier Catalog Modals
  const [showAddSupplierCatalogModal, setShowAddSupplierCatalogModal] = useState(false);
  const [showBulkSupplierCatalogModal, setShowBulkSupplierCatalogModal] = useState(false);
  const [showBulkGrantModal, setShowBulkGrantModal] = useState(false);

  // New Supplier Catalog Single Item Form
  const [newCatProductName, setNewCatProductName] = useState("");
  const [newCatCategory, setNewCatCategory] = useState<AgroCategory>("seed");
  const [newCatUnit, setNewCatUnit] = useState("10kg Bag");
  const [newCatWholesale, setNewCatWholesale] = useState<number>(310);
  const [newCatRetail, setNewCatRetail] = useState<number>(385);
  const [newCatQty, setNewCatQty] = useState<number>(2500);
  const [newCatBatch, setNewCatBatch] = useState("ZM-2026-101");
  const [newCatExpiry, setNewCatExpiry] = useState("2027-11-30");
  const [newCatBarcode, setNewCatBarcode] = useState("");
  const [newCatDesc, setNewCatDesc] = useState("");

  // Checkbox in Grant modal to also save custom item to Supplier Catalog
  const [saveCustomToCatalog, setSaveCustomToCatalog] = useState<boolean>(true);

  // File Upload State for AgroDealer SKU Bulk Import
  const [skuUploadParsedRows, setSkuUploadParsedRows] = useState<NormalizedImportSKU[]>([]);
  const [skuUploadRawText, setSkuUploadRawText] = useState("");

  // File Upload State for Supplier Stock Catalog Bulk Import
  const [supplierCatalogParsedRows, setSupplierCatalogParsedRows] = useState<NormalizedSupplierCatalogRow[]>([]);
  const [supplierCatalogRawText, setSupplierCatalogRawText] = useState("");

  // File Upload State for Bulk Consignment Grant Import
  const [grantUploadParsedRows, setGrantUploadParsedRows] = useState<NormalizedConsignmentGrantRow[]>([]);
  const [grantUploadRawText, setGrantUploadRawText] = useState("");
  const [showMovementModal, setShowMovementModal] = useState(false);
  const [selectedSkuForMovement, setSelectedSkuForMovement] = useState<AgroDealerSKU | null>(null);
  
  const [showRemitModal, setShowRemitModal] = useState(false);
  const [remitAgreement, setRemitAgreement] = useState<ConsignmentAgreement | null>(null);
  const [remitAmount, setRemitAmount] = useState<number>(0);

  const [showGrantModal, setShowGrantModal] = useState(false);
  const [showAgreementModal, setShowAgreementModal] = useState(false);
  const [showReconcileModal, setShowReconcileModal] = useState(false);
  const [showAiBriefModal, setShowAiBriefModal] = useState<AgroDealerSKU | null>(null);

  // Lipila POS Gateway Modal State
  const [showLipilaPosModal, setShowLipilaPosModal] = useState(false);
  const [lipilaPosStep, setLipilaPosStep] = useState<"PROMPT" | "PROCESSING" | "SUCCESS">("PROMPT");
  const [lipilaPosTxId, setLipilaPosTxId] = useState("");
  const [posLipilaError, setPosLipilaError] = useState<string | null>(null);
  const [posLipilaTimeRemaining, setPosLipilaTimeRemaining] = useState<number>(300);
  const [isPosLipilaSubmitting, setIsPosLipilaSubmitting] = useState<boolean>(false);
  const [isEditingPosPhone, setIsEditingPosPhone] = useState<boolean>(false);
  const [posPhoneInput, setPosPhoneInput] = useState<string>("");

  // Farm Balance Multi-use Wallet & Disbursement Center Modal State
  const [showFarmBalanceModal, setShowFarmBalanceModal] = useState(false);
  const [farmBalanceTab, setFarmBalanceTab] = useState<"SUBSCRIPTION" | "TOPUP" | "PAYROLL" | "DISBURSE" | "CREDITS">("DISBURSE");

  // Mobile Disbursement state
  const [disbursePhone, setDisbursePhone] = useState("");
  const [disburseAmount, setDisburseAmount] = useState<number>(500);
  const [disburseName, setDisburseName] = useState("");
  const [disburseReason, setDisburseReason] = useState("Farm Worker Advance");

  // Payroll state & farm node worker list
  const farmWorkers = useMemo(() => {
    let list: any[] = [];
    try {
      const cachedEmployeesStr = localStorage.getItem("mabala_employees");
      if (cachedEmployeesStr) {
        list = JSON.parse(cachedEmployeesStr);
      }
    } catch (_) {}
    if (!list) {
      list = [];
    }
    return list.map((e: any) => ({
      id: e.id || e.name,
      name: e.name || e.employeeName || "Worker",
      phone: e.walletNumber || e.phone || "",
      salary: Number(e.netPay || e.grossSalary || e.salary || 0),
      role: e.role || e.designation || e.department || "Shop Hand"
    }));
  }, []);

  const [selectedWorkerId, setSelectedWorkerId] = useState("");
  const [payrollWorkerName, setPayrollWorkerName] = useState("");
  const [payrollPhone, setPayrollPhone] = useState("");
  const [payrollAmount, setPayrollAmount] = useState<number>(1200);

  // Lipila Production Payment Link Modal state
  const [showLipilaLinkModal, setShowLipilaLinkModal] = useState(false);
  const [linkPayPhone, setLinkPayPhone] = useState("+260977889900");
  const [linkPayAmount, setLinkPayAmount] = useState<number>(180);

  // New Dealer & Nominated Staff Registration Security State
  const [newDealerPassword, setNewDealerPassword] = useState("");
  const [newDealerConfirmPassword, setNewDealerConfirmPassword] = useState("");
  const [nominatedStaffList, setNominatedStaffList] = useState<{ id: string; name: string; email: string; phone: string; role: string; password?: string; confirmPassword?: string; permissions: "read_only" | "read_write" }[]>([]);

  // Account Suspension and Deletion Confirmation Modal State
  const [confirmModalState, setConfirmModalState] = useState<{
    isOpen: boolean;
    type: "suspend_dealer" | "delete_dealer" | "suspend_supplier" | "delete_supplier" | "suspend_agreement" | "delete_agreement";
    id: string;
    name: string;
    isCurrentlySuspended?: boolean;
  } | null>(null);
  const [linkPayTitle, setLinkPayTitle] = useState("Mabala Agro-Dealer SaaS Subscription");
  const [linkPayStatus, setLinkPayStatus] = useState<"IDLE" | "PROCESSING" | "SUCCESS">("IDLE");
  const [linkPayRef, setLinkPayRef] = useState("");

  const handleSelectPayrollWorker = (workerId: string) => {
    setSelectedWorkerId(workerId);
    const worker = farmWorkers.find(w => w.id === workerId);
    if (worker) {
      setPayrollWorkerName(worker.name);
      setPayrollPhone(worker.phone);
      setPayrollAmount(worker.salary);
    }
  };

  const handleTriggerLipilaPaymentLink = (linkId: string, amount: number = 180, title: string = "Mabala Agro-Dealer Monthly Retail Subscription") => {
    setLinkPayAmount(amount);
    setLinkPayTitle(title);
    setLinkPayStatus("IDLE");
    setLinkPayRef(`LIPILA-PROD-LINK-${linkId}-${Math.floor(1000 + Math.random() * 9000)}`);
    setShowLipilaLinkModal(true);
  };

  const handleExecuteLipilaLinkPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setLinkPayStatus("PROCESSING");
    try {
      const cleanLinkPhone = normalizeZambianMobileNumber(linkPayPhone);
      await safeFetchJsonClient("/api/payments/collect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          referenceId: linkPayRef,
          amount: linkPayAmount,
          accountNumber: cleanLinkPhone,
          phone: cleanLinkPhone,
          narration: `Lipila Payment Link: ${linkPayTitle}`,
          currency: "ZMW",
          isProduction: true
        })
      });
    } catch (_) {}

    setTimeout(() => {
      setLinkPayStatus("SUCCESS");
      showToast(`[LIPILA PRODUCTION API] Payment Link ${activeDealer.lipilaPaymentLinkId} successfully processed! Approved ZMW ${linkPayAmount} via ${detectCarrier(linkPayPhone).name}. Status: 200 OK.`);
    }, 1200);
  };

  // Reconciliation Run Form state
  const [reconcileDealerId, setReconcileDealerId] = useState("dealer-choma-01");
  const [reconcileNotes, setReconcileNotes] = useState("");

  const [showCreateDealerModal, setShowCreateDealerModal] = useState(false);
  const [createDealerStep, setCreateDealerStep] = useState<1 | 2>(1);
  const [showCreateSupplierModal, setShowCreateSupplierModal] = useState(false);

  // Super Admin Workspace Sub-tab
  const [superAdminSubTab, setSuperAdminSubTab] = useState<"DEALERS" | "SUPPLIERS" | "AGREEMENTS">("DEALERS");

  // POS State
  const [posCart, setPosCart] = useState<{ sku: AgroDealerSKU; qty: number }[]>([]);
  const [posPaymentMethod, setPosPaymentMethod] = useState<"CASH" | "MOBILE_MONEY" | "INVOICE" | "QUOTE">("MOBILE_MONEY");
  const [posCustomerName, setPosCustomerName] = useState("");
  const [posCustomerPhone, setPosCustomerPhone] = useState("");
  const [posReceipt, setPosReceipt] = useState<any | null>(null);

  // New SKU Form state
  const [newSkuName, setNewSkuName] = useState("");
  const [newSkuCategory, setNewSkuCategory] = useState<AgroCategory>("seed");
  const [newSkuUnit, setNewSkuUnit] = useState("10kg Bag");
  const [newSkuSupplierId, setNewSkuSupplierId] = useState<string>("OWNED");
  const [newSkuUnitCost, setNewSkuUnitCost] = useState<number>(100);
  const [newSkuSellingPrice, setNewSkuSellingPrice] = useState<number>(130);
  const [newSkuQty, setNewSkuQty] = useState<number>(50);
  const [newSkuReorder, setNewSkuReorder] = useState<number>(15);
  const [newSkuBatch, setNewSkuBatch] = useState("BATCH-" + Math.floor(1000 + Math.random() * 9000));
  const [newSkuExpiry, setNewSkuExpiry] = useState("2027-12-31");

  // New Grant Form state
  const [grantDealerId, setGrantDealerId] = useState("dealer-choma-01");
  const [grantItemName, setGrantItemName] = useState("Hybrid Seed SC-719 (10kg)");
  const [grantCategory, setGrantCategory] = useState<AgroCategory>("seed");
  const [grantUnit, setGrantUnit] = useState("10kg Bag");
  const [grantQty, setGrantQty] = useState<number>(100);
  const [grantUnitCost, setGrantUnitCost] = useState<number>(310);
  const [grantSellingPrice, setGrantSellingPrice] = useState<number>(385);
  const [grantBatch, setGrantBatch] = useState("ZM-2026-719");
  const [grantExpiry, setGrantExpiry] = useState("2027-11-30");

  // New Agreement Form state (Wizard 3.3)
  const [agrDealerId, setAgrDealerId] = useState("dealer-chipata-03");
  const [agrSupplierId, setAgrSupplierId] = useState("inst-zambezi-seed");
  const [agrPeriodDays, setAgrPeriodDays] = useState<number>(30);
  const [agrCommissionBearer, setAgrCommissionBearer] = useState<"agro_dealer" | "institution_supplier">("institution_supplier");
  const [agrCreditLimit, setAgrCreditLimit] = useState<number>(150000);
  const [agrCategories, setAgrCategories] = useState<AgroCategory[]>(["seed", "pesticide", "fertilizer"]);

  // New Agro-Dealer Tenant Creation state (Wizard 3.1)
  const [newDealerName, setNewDealerName] = useState("");
  const [newDealerTradingName, setNewDealerTradingName] = useState("");
  const [newDealerPacra, setNewDealerPacra] = useState("");
  const [newDealerOwner, setNewDealerOwner] = useState("");
  const [newDealerPhone, setNewDealerPhone] = useState("");
  const [newDealerEmail, setNewDealerEmail] = useState("");
  const [newDealerProvince, setNewDealerProvince] = useState("Southern Province");
  const [newDealerDistrict, setNewDealerDistrict] = useState("Choma");
  const [newDealerCity, setNewDealerCity] = useState("Choma Central");
  const [newDealerLat, setNewDealerLat] = useState<number>(-16.806);
  const [newDealerLng, setNewDealerLng] = useState<number>(26.985);
  const [newDealerCanDeliver, setNewDealerCanDeliver] = useState(true);

  // New Seed/Chemical Supplier Company state (Wizard 3.2)
  const [supplierCreateMode, setSupplierCreateMode] = useState<"NEW" | "UPGRADE_EXISTING">("NEW");
  const [upgradeInstId, setUpgradeInstId] = useState("");
  const [newSupplierName, setNewSupplierName] = useState("");
  const [newSupplierPacra, setNewSupplierPacra] = useState("");
  const [newSupplierAddress, setNewSupplierAddress] = useState("");
  const [newSupplierCategories, setNewSupplierCategories] = useState<AgroCategory[]>(["seed", "fertilizer"]);
  const [newSupplierAdminName, setNewSupplierAdminName] = useState("");
  const [newSupplierAdminEmail, setNewSupplierAdminEmail] = useState("");
  const [newSupplierAdminPhone, setNewSupplierAdminPhone] = useState("");

  // Notification Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string, _type?: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Current active dealer object
  const activeDealer = useMemo(() => {
    return dealers.find(d => d && d.id === activeDealerId) || dealers[0] || {
      id: "dealer-choma-01",
      businessName: "Choma Agro-Dealer Hub",
      tradingName: "Choma Input Supplies",
      ownerName: "Mutinta Hachipuka",
      ownerPhone: "+260978070734",
      city: "Choma",
      province: "Southern Province",
      subscriptionStatus: "active",
      lipilaPaymentLinkId: "LINK-AGD-CHOMA-88219"
    };
  }, [dealers, activeDealerId]);

  // Active Dealer credit and subscription status calculation
  const activeDealerCredits = (activeDealer as any)?.credits ?? 100;
  const activeDealerExpiryMs = (activeDealer as any)?.subscriptionExpiryDate
    ? new Date((activeDealer as any).subscriptionExpiryDate).getTime()
    : new Date((activeDealer as any)?.createdAt || Date.now()).getTime() + 30 * 24 * 60 * 60 * 1000;

  const isDealerSubscriptionExpired = Date.now() > activeDealerExpiryMs;
  const isDealerCreditsExhausted = activeDealerCredits <= 0;
  const isAgroDealerReadOnly = (isAgroDealer || activeWorkspaceMode === "DEALER") && (isDealerCreditsExhausted || isDealerSubscriptionExpired || activeDealer.subscriptionStatus === "expired");

  // Active Supplier credit status calculation
  const activeSupplierObj = useMemo(() => {
    return suppliers.find(s => s && s.id === activeSupplierId) || suppliers[0];
  }, [suppliers, activeSupplierId]);

  // In v3.0, Suppliers have free platform access and pay-per-report fees only (no credit balance requirement)
  const isSupplierReadOnly = false;

  const checkWritePermission = (): boolean => {
    if (activeWorkspaceMode === "DEALER" && isAgroDealerReadOnly) {
      showToast("🔒 READ-ONLY ACCESS ACTIVE: Your credits have been used up or your subscription has expired. Please buy top-up credits or renew your subscription.", "error");
      setShowFarmBalanceModal(true);
      setFarmBalanceTab("CREDITS");
      return false;
    }
    return true;
  };

  // SKUs filtered for active dealer (excluding test/dummy items)
  const dealerSkus = useMemo(() => {
    return skus.filter(s => {
      const isDealer = s.tenantId === activeDealer.id;
      const text = `${s.id} ${s.productName} ${s.category || ''} ${s.batchNumber || ''} ${s.supplierName || ''}`.toLowerCase();
      const isDummy =
        text.includes("test") ||
        text.includes("demo") ||
        text.includes("dummy") ||
        text.includes("sample") ||
        text.includes("fake") ||
        text.includes("temp");
      return isDealer && !isDummy;
    });
  }, [skus, activeDealer.id]);

  // Filtered SKUs for display
  const filteredSkus = useMemo(() => {
    return dealerSkus.filter(s => {
      const matchSearch = s.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (s.supplierName && s.supplierName.toLowerCase().includes(searchTerm.toLowerCase())) ||
                          (s.batchNumber && s.batchNumber.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchCat = categoryFilter === "ALL" || s.category === categoryFilter;
      const matchSup = supplierFilter === "ALL" || 
                       (supplierFilter === "OWNED" ? !s.supplierId : s.supplierId === supplierFilter);
      return matchSearch && matchCat && matchSup;
    });
  }, [dealerSkus, searchTerm, categoryFilter, supplierFilter]);

  // Low stock SKUs
  const lowStockSkus = useMemo(() => {
    return dealerSkus.filter(s => s.qtyOnHand <= s.reorderThreshold);
  }, [dealerSkus]);

  // Dealer's movements
  const dealerMovements = useMemo(() => {
    const skuIds = new Set(dealerSkus.map(s => s.id));
    return movements.filter(m => skuIds.has(m.skuId))
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [dealerSkus, movements]);

  // Dealer's active agreements & outstanding payable
  const dealerAgreements = useMemo(() => {
    return agreements.filter(a => a.dealerTenantId === activeDealer.id && a.status === "active");
  }, [agreements, activeDealer.id]);

  // Calculate Consignment Payable per supplier for dealer
  const supplierPayables = useMemo(() => {
    const map: Record<string, { supplierName: string; totalPayable: number; agreement?: ConsignmentAgreement }> = {};
    
    dealerAgreements.forEach(agr => {
      map[agr.institutionId] = {
        supplierName: agr.institutionName,
        totalPayable: 0,
        agreement: agr
      };
    });

    dealerSkus.forEach(sku => {
      if (sku.supplierId && map[sku.supplierId]) {
        // Outstanding payable is quantity sold * unit cost minus remitted
        map[sku.supplierId].totalPayable += (sku.qtySold * sku.unitCost);
      }
    });

    // Subtract past remittances
    reconciliations.forEach(rec => {
      if (rec.dealerTenantId === activeDealer.id && map[rec.institutionId]) {
        map[rec.institutionId].totalPayable = Math.max(0, map[rec.institutionId].totalPayable - rec.totalRemittancesReceived);
      }
    });

    return map;
  }, [dealerAgreements, dealerSkus, reconciliations, activeDealer.id]);

  // Total dealer consignment payable
  const totalDealerPayable = useMemo(() => {
    return Object.values(supplierPayables).reduce((sum: number, item: { totalPayable: number }) => sum + item.totalPayable, 0);
  }, [supplierPayables]);

  // Supplier Rollup Data across dealers
  const dealerLedgers: DealerLedgerRollup[] = useMemo(() => {
    return dealers.map(dealer => {
      const dSkus = skus.filter(s => s.tenantId === dealer.id && s.supplierId === activeSupplierId);
      const agr = agreements.find(a => a.dealerTenantId === dealer.id && a.institutionId === activeSupplierId);
      
      const grantedVal = dSkus.reduce((acc, s) => acc + (s.qtyReceived * s.unitCost), 0);
      const remainingVal = dSkus.reduce((acc, s) => acc + (s.qtyOnHand * s.unitCost), 0);
      const salesVal = dSkus.reduce((acc, s) => acc + (s.qtySold * s.unitCost), 0);
      
      const remittances = reconciliations
        .filter(r => r.dealerTenantId === dealer.id && r.institutionId === activeSupplierId)
        .reduce((acc, r) => acc + r.totalRemittancesReceived, 0);

      const payable = Math.max(0, salesVal - remittances);
      const creditLimit = agr?.creditLimit || 100000;

      return {
        dealerTenantId: dealer.id,
        dealerName: dealer.businessName,
        dealerPhone: dealer.ownerPhone,
        province: dealer.province,
        district: dealer.district,
        city: dealer.city,
        totalStockGrantedValue: grantedVal,
        totalStockRemainingValue: remainingVal,
        totalSalesValue: salesVal,
        outstandingConsignmentPayable: payable,
        subscriptionStatus: dealer.subscriptionStatus,
        isSponsored: dealer.sponsoredByInstitutionId === activeSupplierId,
        creditLimit: creditLimit,
        exceedsCreditLimit: (grantedVal + remainingVal) > creditLimit
      };
    }).filter(d => provinceFilter === "ALL" || d.province === provinceFilter);
  }, [dealers, skus, agreements, reconciliations, activeSupplierId, provinceFilter]);

  // Network Totals for Supplier View
  const networkTotals = useMemo(() => {
    return dealerLedgers.reduce((acc, d) => {
      // Check subscription visibility gate: hide live numbers if expired and not sponsored
      if (d.subscriptionStatus === "expired" && !d.isSponsored) {
        return acc;
      }
      return {
        granted: acc.granted + d.totalStockGrantedValue,
        remaining: acc.remaining + d.totalStockRemainingValue,
        sales: acc.sales + d.totalSalesValue,
        payable: acc.payable + d.outstandingConsignmentPayable
      };
    }, { granted: 0, remaining: 0, sales: 0, payable: 0 });
  }, [dealerLedgers]);

  // Handle Add New SKU
  const handleCreateSku = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSkuName) return;

    const selectedSup = agreements.find(a => a.institutionId === newSkuSupplierId);

    const newSku: AgroDealerSKU = {
      id: "sku-" + Date.now(),
      tenantId: activeDealer.id,
      productName: newSkuName,
      category: newSkuCategory,
      unit: newSkuUnit,
      supplierId: newSkuSupplierId === "OWNED" ? null : newSkuSupplierId,
      supplierName: newSkuSupplierId === "OWNED" ? undefined : selectedSup?.institutionName,
      unitCost: newSkuUnitCost,
      sellingPrice: newSkuSellingPrice,
      qtyReceived: newSkuQty,
      qtySold: 0,
      qtyOnHand: newSkuQty,
      qtyReserved: 0,
      reorderThreshold: newSkuReorder,
      batchNumber: newSkuBatch,
      expiryDate: newSkuExpiry,
      lastMovementAt: new Date().toISOString()
    };

    // Auto-generate initial movement
    const newMov: StockMovement = {
      id: "mov-" + Date.now(),
      skuId: newSku.id,
      productName: newSku.productName,
      type: newSkuSupplierId === "OWNED" ? "manual_adjustment" : "grant_received",
      qtyDelta: newSkuQty,
      resultingBalance: newSkuQty,
      timestamp: new Date().toISOString(),
      actorId: activeDealer.id,
      actorName: activeDealer.ownerName,
      reference: newSkuSupplierId === "OWNED" ? "INITIAL_STOCK" : "DIRECT_GRANT"
    };

    setSkus(prev => [newSku, ...prev]);
    setMovements(prev => [newMov, ...prev]);
    setShowAddSkuModal(false);
    showToast(`Successfully added SKU: ${newSkuName}`);
    setNewSkuName("");
  };

  // Handle Add Single Item to Supplier Catalog
  const handleCreateSupplierCatalogItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatProductName.trim()) return;

    const activeSup = suppliers.find(s => s.id === activeSupplierId) || suppliers[0];

    const newItem: SupplierCatalogItem = {
      id: "sup-cat-" + Date.now(),
      supplierId: activeSupplierId,
      supplierName: activeSup ? activeSup.name : "Supplier Institution",
      productName: newCatProductName.trim(),
      category: newCatCategory,
      unit: newCatUnit.trim(),
      unitWholesaleCost: newCatWholesale,
      recommendedSellingPrice: newCatRetail,
      qtyInStock: newCatQty,
      batchNumber: newCatBatch,
      expiryDate: newCatExpiry,
      barcodeSKU: newCatBarcode || undefined,
      description: newCatDesc || undefined,
      createdAt: new Date().toISOString()
    };

    setSupplierCatalog(prev => [newItem, ...prev]);
    setShowAddSupplierCatalogModal(false);
    showToast(`Added catalog item: ${newItem.productName} (${newItem.unit})`);
    setNewCatProductName("");
    setNewCatBarcode("");
    setNewCatDesc("");
  };

  // Handle Bulk Import to Supplier Catalog
  const handleBulkImportSupplierCatalog = (itemsToImport: NormalizedSupplierCatalogRow[]) => {
    const validRows = itemsToImport.filter(r => r.isValid);
    if (validRows.length === 0) {
      alert("No valid rows found to import.");
      return;
    }

    const activeSup = suppliers.find(s => s.id === activeSupplierId) || suppliers[0];

    const newItems: SupplierCatalogItem[] = validRows.map((row, idx) => ({
      id: `sup-cat-bulk-${Date.now()}-${idx}`,
      supplierId: activeSupplierId,
      supplierName: activeSup ? activeSup.name : "Supplier Institution",
      productName: row.productName,
      category: row.category,
      unit: row.unit,
      unitWholesaleCost: row.unitWholesaleCost,
      recommendedSellingPrice: row.recommendedSellingPrice,
      qtyInStock: row.qtyInStock,
      batchNumber: row.batchNumber,
      expiryDate: row.expiryDate,
      barcodeSKU: row.barcodeSKU,
      description: row.description,
      createdAt: new Date().toISOString()
    }));

    setSupplierCatalog(prev => [...newItems, ...prev]);
    setShowBulkSupplierCatalogModal(false);
    setSupplierCatalogParsedRows([]);
    setSupplierCatalogRawText("");
    showToast(`Successfully added ${newItems.length} products to Supplier Stock Catalog!`);
  };

  // Handle Bulk Import to AgroDealer Inventory SKUs
  const handleBulkImportDealerSkus = (itemsToImport: NormalizedImportSKU[]) => {
    const validRows = itemsToImport.filter(r => r.isValid);
    if (validRows.length === 0) {
      alert("No valid SKU rows found to import.");
      return;
    }

    const newSkus: AgroDealerSKU[] = validRows.map((row, idx) => ({
      id: `sku-bulk-${Date.now()}-${idx}`,
      tenantId: activeDealer.id,
      productName: row.productName,
      category: row.category,
      unit: row.unit,
      unitCost: row.unitCost,
      sellingPrice: row.sellingPrice,
      qtyReceived: row.qtyOnHand,
      qtySold: 0,
      qtyOnHand: row.qtyOnHand,
      qtyReserved: 0,
      reorderThreshold: row.reorderThreshold,
      supplierName: row.supplierName,
      batchNumber: row.batchNumber,
      expiryDate: row.expiryDate,
      lastMovementAt: new Date().toISOString()
    }));

    setSkus(prev => [...newSkus, ...prev]);
    setShowAddSkuModal(false);
    setSkuUploadParsedRows([]);
    setSkuUploadRawText("");
    showToast(`Bulk Import Success! Added ${newSkus.length} new SKUs to ${activeDealer.businessName} inventory.`);
  };

  // Handle Bulk Import for Consignment Grants
  const handleBulkImportConsignmentGrants = (grantRows: NormalizedConsignmentGrantRow[]) => {
    const validRows = grantRows.filter(r => r.isValid);
    if (validRows.length === 0) {
      alert("No valid grant rows found to import.");
      return;
    }

    let issuedCount = 0;
    const activeSup = suppliers.find(s => s.id === activeSupplierId) || suppliers[0];

    validRows.forEach((row, idx) => {
      const targetDealer = dealers.find(d => 
        d.id.toLowerCase() === row.dealerIdentifier.toLowerCase() ||
        d.businessName.toLowerCase().includes(row.dealerIdentifier.toLowerCase())
      ) || dealers[0];

      if (!targetDealer) return;

      const totalVal = row.grantQty * row.unitCost;
      const grantId = `grant-bulk-${Date.now()}-${idx}`;
      const grantNumber = `GRANT-${Math.floor(1000 + Math.random() * 9000)}`;

      const newGrant: StockGrant = {
        id: grantId,
        grantNumber,
        institutionId: activeSupplierId,
        institutionName: activeSup ? activeSup.name : "Zambezi Seed Corp (ZAMSEED)",
        dealerTenantId: targetDealer.id,
        dealerName: targetDealer.businessName,
        grantDate: new Date().toISOString(),
        totalValue: totalVal,
        status: "received",
        createdAt: new Date().toISOString(),
        items: [
          {
            productName: row.productName,
            category: row.category,
            unit: row.unit,
            qty: row.grantQty,
            unitCost: row.unitCost,
            sellingPrice: row.sellingPrice,
            batchNumber: row.batchNumber,
            expiryDate: row.expiryDate
          }
        ]
      };

      setGrants(prev => [newGrant, ...prev]);

      setSkus(prev => {
        const existing = prev.find(s => s.tenantId === targetDealer.id && s.productName.toLowerCase() === row.productName.toLowerCase());
        if (existing) {
          return prev.map(s => s.id === existing.id ? {
            ...s,
            qtyReceived: s.qtyReceived + row.grantQty,
            qtyOnHand: s.qtyOnHand + row.grantQty,
            unitCost: row.unitCost,
            sellingPrice: row.sellingPrice,
            lastMovementAt: new Date().toISOString()
          } : s);
        } else {
          const newSku: AgroDealerSKU = {
            id: `sku-grant-${Date.now()}-${idx}`,
            tenantId: targetDealer.id,
            productName: row.productName,
            category: row.category,
            unit: row.unit,
            supplierId: activeSupplierId,
            supplierName: activeSup ? activeSup.name : "Supplier",
            unitCost: row.unitCost,
            sellingPrice: row.sellingPrice,
            qtyReceived: row.grantQty,
            qtySold: 0,
            qtyOnHand: row.grantQty,
            qtyReserved: 0,
            reorderThreshold: 10,
            batchNumber: row.batchNumber,
            expiryDate: row.expiryDate,
            lastMovementAt: new Date().toISOString()
          };
          return [newSku, ...prev];
        }
      });

      issuedCount++;
    });

    setShowBulkGrantModal(false);
    setGrantUploadParsedRows([]);
    setGrantUploadRawText("");
    showToast(`Bulk Consignment Success! Issued ${issuedCount} stock grants to dealers.`);
  };

  // Handle Manual Movement / Stock Adjustment
  const handleRecordMovement = (type: StockMovementType, qtyDelta: number, reasonCode: string) => {
    if (!selectedSkuForMovement) return;

    const newBalance = Math.max(0, selectedSkuForMovement.qtyOnHand + qtyDelta);

    const newMov: StockMovement = {
      id: "mov-" + Date.now(),
      skuId: selectedSkuForMovement.id,
      productName: selectedSkuForMovement.productName,
      type,
      qtyDelta,
      resultingBalance: newBalance,
      timestamp: new Date().toISOString(),
      actorId: activeDealer.id,
      actorName: activeDealer.ownerName,
      reference: "MANUAL_ADJ",
      reasonCode
    };

    setSkus(prev => prev.map(s => {
      if (s.id === selectedSkuForMovement.id) {
        return {
          ...s,
          qtyOnHand: newBalance,
          qtyReceived: qtyDelta > 0 ? s.qtyReceived + qtyDelta : s.qtyReceived,
          lastMovementAt: new Date().toISOString()
        };
      }
      return s;
    }));

    setMovements(prev => [newMov, ...prev]);
    setShowMovementModal(false);
    setSelectedSkuForMovement(null);
    showToast(`Logged movement for ${selectedSkuForMovement.productName}`);
  };

  // Handle Remittance from Agro-Dealer to Seed/Chemical Company
  const handleExecuteRemittance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!remitAgreement || remitAmount <= 0) return;

    if (remitAmount > dealerBalance) {
      alert("Insufficient Farm Balance to complete remittance. Please top up your Lipila account first.");
      return;
    }

    // Atomic Lipila Farm Balance Internal Transfer
    setDealerBalance(prev => prev - remitAmount);
    setSupplierBalance(prev => prev + remitAmount);

    // Record Reconciliation / Remittance Entry
    const newRec: ReconciliationRun = {
      id: "rec-" + Date.now(),
      runNumber: "REM-" + Math.floor(1000 + Math.random() * 9000),
      institutionId: remitAgreement.institutionId,
      institutionName: remitAgreement.institutionName,
      dealerTenantId: activeDealer.id,
      dealerName: activeDealer.businessName,
      periodStart: new Date(Date.now() - 30 * 86400000).toISOString(),
      periodEnd: new Date().toISOString(),
      computedSalesValue: remitAmount,
      totalRemittancesReceived: remitAmount,
      variance: 0,
      status: "reconciled",
      createdAt: new Date().toISOString(),
      reconciledAt: new Date().toISOString(),
      notes: `Farm Balance internal remittance of ${currencySymbol} ${remitAmount.toLocaleString()} to ${remitAgreement.institutionName}`
    };

    setReconciliations(prev => [newRec, ...prev]);
    setShowRemitModal(false);
    showToast(`Remitted ${currencySymbol} ${remitAmount.toLocaleString()} to ${remitAgreement.institutionName} via Farm Balance!`);
  };

  // Handle POS Sale Execution
  const handleAddToPosCart = (sku: AgroDealerSKU) => {
    if (sku.qtyOnHand <= 0) {
      alert("This item is currently out of stock!");
      return;
    }

    setPosCart(prev => {
      const existing = prev.find(item => item.sku.id === sku.id);
      if (existing) {
        if (existing.qty >= sku.qtyOnHand) {
          alert(`Cannot add more. Available stock on hand: ${sku.qtyOnHand}`);
          return prev;
        }
        return prev.map(item => item.sku.id === sku.id ? { ...item, qty: item.qty + 1 } : item);
      }
      return [...prev, { sku, qty: 1 }];
    });
  };

  const handleRemoveFromPosCart = (skuId: string) => {
    setPosCart(prev => prev.filter(item => item.sku.id !== skuId));
  };

  const handleUpdatePosCartQty = (skuId: string, delta: number) => {
    setPosCart(prev => {
      return prev.map(item => {
        if (item.sku.id === skuId) {
          const nextQty = item.qty + delta;
          if (nextQty > item.sku.qtyOnHand) {
            alert(`Cannot exceed stock on hand (${item.sku.qtyOnHand})`);
            return item;
          }
          return nextQty > 0 ? { ...item, qty: nextQty } : null;
        }
        return item;
      }).filter(Boolean) as { sku: AgroDealerSKU; qty: number }[];
    });
  };

  const finalizePosSale = (lipilaTxId?: string, carrierName?: string) => {
    if (posCart.length === 0) return;

    const totalAmount = posCart.reduce((sum, item) => sum + (item.sku.sellingPrice * item.qty), 0);
    const saleId = "AGD-SALE-" + Math.floor(10000 + Math.random() * 90000);

    // Update SKU balances & log immutable movements
    const newMovements: StockMovement[] = [];

    setSkus(prev => prev.map(s => {
      const cartItem = posCart.find(c => c.sku.id === s.id);
      if (cartItem) {
        const newQtyOnHand = Math.max(0, s.qtyOnHand - cartItem.qty);
        const newQtySold = s.qtySold + cartItem.qty;

        newMovements.push({
          id: "mov-" + Date.now() + Math.random(),
          skuId: s.id,
          productName: s.productName,
          type: "sale",
          qtyDelta: -cartItem.qty,
          resultingBalance: newQtyOnHand,
          timestamp: new Date().toISOString(),
          actorId: activeDealer.id,
          actorName: activeDealer.ownerName,
          reference: saleId
        });

        return {
          ...s,
          qtyOnHand: newQtyOnHand,
          qtySold: newQtySold,
          lastMovementAt: new Date().toISOString()
        };
      }
      return s;
    }));

    setMovements(prev => [...newMovements, ...prev]);

    // Record POS Sale in Sales Tracker
    const saleRecord: PosSaleRecord = {
      id: "sale-" + Date.now(),
      saleId,
      date: new Date().toISOString(),
      dealerId: activeDealer.id,
      dealerName: activeDealer.businessName,
      customerName: posCustomerName || "Walk-In Customer",
      customerPhone: posCustomerPhone || "N/A",
      items: posCart.map(c => ({
        productName: c.sku.productName,
        category: c.sku.category,
        qty: c.qty,
        unitPrice: c.sku.sellingPrice,
        subtotal: c.sku.sellingPrice * c.qty
      })),
      totalAmount,
      paymentMethod: posPaymentMethod,
      carrier: carrierName,
      lipilaTxId,
      inventoryDeducted: true
    };

    setPosSales(prev => [saleRecord, ...prev]);

    // If payment mode is MOBILE_MONEY, credit dealer's Farm Balance
    if (posPaymentMethod === "MOBILE_MONEY") {
      setDealerBalance(prev => prev + totalAmount);
    }

    // Build Receipt Object
    const receipt = {
      saleId,
      date: new Date().toLocaleString(),
      dealerName: activeDealer.businessName,
      dealerPhone: activeDealer.ownerPhone,
      dealerAddress: `${activeDealer.city}, ${activeDealer.province}`,
      customerName: posCustomerName || "Walk-In Customer",
      customerPhone: posCustomerPhone || "N/A",
      items: posCart.map(c => ({
        productName: c.sku.productName,
        category: c.sku.category,
        qty: c.qty,
        unitPrice: c.sku.sellingPrice,
        subtotal: c.sku.sellingPrice * c.qty
      })),
      totalAmount,
      paymentMethod: posPaymentMethod,
      carrier: carrierName,
      lipilaTxId
    };

    setPosReceipt(receipt);
    setPosCart([]);
    showToast(`Sale completed! Receipt #${saleId} recorded in Sales Tracker & Audit Ledger.`);
  };

  const initiateLipilaPosPayment = async (phoneToUse?: string) => {
    const targetPhone = phoneToUse || posCustomerPhone;
    if (!targetPhone) {
      alert("Please provide a valid customer mobile number for Lipila payment request.");
      return;
    }

    const cleanPhone = normalizeZambianMobileNumber(targetPhone);
    if (!cleanPhone || !isValidZambianMobileNumber(cleanPhone)) {
      alert(`Invalid Zambian mobile number: "${targetPhone}". Please enter a valid 10-digit number (e.g., 097...) or 12-digit number starting with 260.`);
      return;
    }

    setPosCustomerPhone(targetPhone);
    const totalAmount = posCart.reduce((sum, i) => sum + (i.sku.sellingPrice * i.qty), 0);
    const refId = `ref-pos-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

    setLipilaPosTxId(refId);
    setLipilaPosStep("PROMPT");
    setIsPosLipilaSubmitting(true);
    setPosLipilaError(null);
    setPosLipilaTimeRemaining(300);
    setIsEditingPosPhone(false);
    setShowLipilaPosModal(true);

    try {
      const data = await safeFetchJsonClient("/api/payments/collect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          referenceId: refId,
          amount: totalAmount,
          narration: `Mabala POS Retail Sale (${posCart.length} item${posCart.length > 1 ? "s" : ""})`,
          accountNumber: cleanPhone,
          currency: currencySymbol === "ZK" ? "ZMW" : "ZMW",
          email: "owner@mabala.com",
          uid: "anonymous",
          packageName: "Agro-Dealer POS Retail Sale",
          packageType: "retail_sale",
          creditsToAward: 0
        })
      });

      if (data && (data.status === "Failed" || data.status === "Error" || data.success === false)) {
        const failMsg = data.message || "Lipila payment request failed on operator network.";
        setPosLipilaError(failMsg);
        showToast(`Payment request failed: ${failMsg}`, "error");
      }
    } catch (err: any) {
      const errMsg = err.message || "Network connection error while contacting Lipila production API. Payment was not processed.";
      setPosLipilaError(errMsg);
      showToast(`Network Error: ${errMsg}`, "error");
    } finally {
      setIsPosLipilaSubmitting(false);
    }
  };

  const handleExecutePosSale = () => {
    if (posCart.length === 0) return;

    if (posPaymentMethod === "MOBILE_MONEY") {
      if (!posCustomerPhone || posCustomerPhone.trim().length < 9) {
        alert("Please provide a valid customer mobile number for Lipila payment request.");
        return;
      }
      initiateLipilaPosPayment(posCustomerPhone);
    } else {
      finalizePosSale();
    }
  };

  // POS Lipila 5-minute (300s) PIN countdown timer
  useEffect(() => {
    if (!showLipilaPosModal || lipilaPosStep !== "PROMPT" || posLipilaError || isPosLipilaSubmitting) return;

    const timer = setInterval(() => {
      setPosLipilaTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          const timeoutMsg = "PIN was not provided within 5 minutes. Payment was not processed due to timeout.";
          setPosLipilaError(timeoutMsg);
          showToast(timeoutMsg, "error");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [showLipilaPosModal, lipilaPosStep, posLipilaError, isPosLipilaSubmitting]);

  // POS Lipila check status auto-polling effect
  useEffect(() => {
    if (!showLipilaPosModal || lipilaPosStep !== "PROMPT" || !lipilaPosTxId || posLipilaError || isPosLipilaSubmitting) return;

    const pollInterval = setInterval(async () => {
      try {
        const data = await safeFetchJsonClient(`/api/payments/check-status?referenceId=${lipilaPosTxId}`);
        if (data && (data.status === "Successful" || data.status === "Success" || data.status === "Completed")) {
          clearInterval(pollInterval);
          setLipilaPosStep("SUCCESS");
          showToast("Lipila payment verified successfully!", "success");
        } else if (data && (data.status === "Failed" || data.status === "Error")) {
          clearInterval(pollInterval);
          const failMsg = data.message || "Payment request was declined or failed on operator network.";
          setPosLipilaError(failMsg);
          showToast(`Payment failed: ${failMsg}`, "error");
        }
      } catch (err) {
        // Silently retry on next interval step
      }
    }, 5000);

    return () => clearInterval(pollInterval);
  }, [showLipilaPosModal, lipilaPosStep, lipilaPosTxId, posLipilaError, isPosLipilaSubmitting]);

  // Handle Supplier Reconciliation Execution
  const handleExecuteReconciliation = (e: React.FormEvent) => {
    e.preventDefault();
    const targetDealer = dealers.find(d => d.id === reconcileDealerId);
    if (!targetDealer) return;

    const dSkus = skus.filter(s => s.tenantId === targetDealer.id && s.supplierId === activeSupplierId);
    const computedSalesVal = dSkus.reduce((acc, s) => acc + (s.qtySold * s.unitCost), 0);
    
    const remittances = reconciliations
      .filter(r => r.dealerTenantId === targetDealer.id && r.institutionId === activeSupplierId)
      .reduce((acc, r) => acc + r.totalRemittancesReceived, 0);

    const variance = Math.max(0, computedSalesVal - remittances);
    const runNumber = "REC-RUN-" + Math.floor(1000 + Math.random() * 9000);

    const newRec: ReconciliationRun = {
      id: "rec-" + Date.now(),
      runNumber,
      institutionId: activeSupplierId,
      institutionName: "Zambezi Seed Corp (ZAMSEED)",
      dealerTenantId: targetDealer.id,
      dealerName: targetDealer.businessName,
      periodStart: new Date(Date.now() - 30 * 86400000).toISOString(),
      periodEnd: new Date().toISOString(),
      computedSalesValue: computedSalesVal,
      totalRemittancesReceived: remittances,
      variance,
      status: variance === 0 ? "reconciled" : "reconciled",
      createdAt: new Date().toISOString(),
      reconciledAt: new Date().toISOString(),
      notes: reconcileNotes || `Automated reconciliation for ${targetDealer.businessName}`
    };

    setReconciliations(prev => [newRec, ...prev]);
    setShowReconcileModal(false);
    setReconcileNotes("");
    showToast(`Reconciliation Run ${runNumber} executed for ${targetDealer.businessName}!`);
  };

  // Handle Farm Balance Payout / Disbursement via Lipila
  const handleFarmBalanceDisburse = (e: React.FormEvent) => {
    e.preventDefault();
    if (disburseAmount <= 0) return;
    if (disburseAmount > dealerBalance) {
      alert("Insufficient Farm Balance for mobile money disbursement.");
      return;
    }
    if (!disbursePhone) {
      alert("Please provide a valid recipient phone number.");
      return;
    }

    const carrier = detectCarrier(disbursePhone);
    const txId = "LIPILA-OUT-" + Math.floor(10000 + Math.random() * 90000);

    setDealerBalance(prev => prev - disburseAmount);
    showToast(`Disbursed ${currencySymbol} ${disburseAmount.toLocaleString()} to ${disburseName || disbursePhone} (${carrier.name}) via Lipila API! Ref: ${txId}`);
    setShowFarmBalanceModal(false);
    setDisbursePhone("");
    setDisburseName("");
  };

  // Handle Farm Balance Payroll Payout via Lipila Production API
  const handleFarmBalancePayroll = async (e: React.FormEvent) => {
    e.preventDefault();
    if (payrollAmount <= 0 || !payrollPhone) return;
    if (payrollAmount > dealerBalance) {
      alert("Insufficient Farm Balance for worker salary payment.");
      return;
    }

    const cleanPhone = normalizeZambianMobileNumber(payrollPhone);
    if (!cleanPhone || !isValidZambianMobileNumber(cleanPhone)) {
      alert(`Invalid Zambian mobile number: "${payrollPhone}". Please provide a valid mobile number.`);
      return;
    }

    const carrier = detectCarrier(payrollPhone);
    const txId = "LIPILA-PROD-PAYROLL-" + Math.floor(100000 + Math.random() * 900000);

    // Call Lipila Production API endpoint
    try {
      const res = await safeFetchJsonClient("/api/payments/collect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          referenceId: txId,
          amount: payrollAmount,
          accountNumber: cleanPhone,
          narration: `Lipila Production Salary Payout: ${payrollWorkerName || "Worker"}`,
          type: "payroll_disbursement",
          isProduction: true
        })
      });

      if (res && (res.status === "Failed" || res.status === "Error" || res.success === false)) {
        alert(`Disbursement failed: ${res.message || res.error || "Lipila gateway rejected the transaction."}`);
        return;
      }
    } catch (err: any) {
      alert(`Disbursement error: ${err.message || "Could not reach Lipila gateway."}`);
      return;
    }

    setDealerBalance(prev => prev - payrollAmount);
    showToast(`[LIPILA PRODUCTION API] Activated Lipila Production Gateway! Disbursed ${currencySymbol} ${payrollAmount.toLocaleString()} salary to worker ${payrollWorkerName || payrollPhone} (${payrollPhone} - ${carrier.name}). Ref: ${txId} (Status: 200 OK SUCCESS).`);
    setShowFarmBalanceModal(false);
    setSelectedWorkerId("");
    setPayrollWorkerName("");
    setPayrollPhone("");
  };

  // Handle Farm Balance Subscription / Platform Topup
  const handleFarmBalanceSubscription = (plan: "MONTHLY" | "ANNUAL") => {
    const cost = plan === "MONTHLY" ? 180 : 2160;
    if (dealerBalance < cost) {
      alert("Insufficient Farm Balance to renew subscription.");
      return;
    }

    setDealerBalance(prev => prev - cost);
    setDealers(prev => prev.map(d => d.id === activeDealer.id ? { ...d, subscriptionStatus: "active" } : d));
    showToast(`Renewed Mabala Agro-Dealer Subscription (${plan} - K180/Month) via Farm Balance! Account Active.`);
    setShowFarmBalanceModal(false);
  };

  // Handle Supplier Issuing Stock Grant
  const handleIssueGrant = (e: React.FormEvent) => {
    e.preventDefault();
    const targetDealer = dealers.find(d => d.id === grantDealerId);
    if (!targetDealer) return;

    // Check if an active Consignment Agreement exists between activeSupplierId and targetDealer
    const activeAgr = agreements.find(
      a => a.institutionId === activeSupplierId && a.dealerTenantId === grantDealerId && a.status === "active"
    );

    if (!activeAgr) {
      alert(`Cannot issue Stock Grant: No active Consignment Agreement exists between your supplier company and ${targetDealer.businessName}. Please send and accept a credit agreement link first.`);
      return;
    }

    const totalVal = grantQty * grantUnitCost;
    const grantId = "grant-" + Date.now();
    const grantNumber = "GRANT-" + Math.floor(1000 + Math.random() * 9000);

    const newGrant: StockGrant = {
      id: grantId,
      grantNumber,
      institutionId: activeSupplierId,
      institutionName: "Zambezi Seed Corp (ZAMSEED)",
      dealerTenantId: targetDealer.id,
      dealerName: targetDealer.businessName,
      grantDate: new Date().toISOString(),
      totalValue: totalVal,
      status: "received",
      createdAt: new Date().toISOString(),
      items: [
        {
          productName: grantItemName,
          category: grantCategory,
          unit: grantUnit,
          qty: grantQty,
          unitCost: grantUnitCost,
          sellingPrice: grantSellingPrice,
          batchNumber: grantBatch,
          expiryDate: grantExpiry
        }
      ]
    };

    // Atomic creation/update of dealer SKU & stock movement
    const existingSku = skus.find(s => s.tenantId === targetDealer.id && s.productName === grantItemName);

    if (existingSku) {
      setSkus(prev => prev.map(s => {
        if (s.id === existingSku.id) {
          const newQtyRec = s.qtyReceived + grantQty;
          const newQtyOnHand = s.qtyOnHand + grantQty;
          return {
            ...s,
            qtyReceived: newQtyRec,
            qtyOnHand: newQtyOnHand,
            unitCost: grantUnitCost,
            sellingPrice: grantSellingPrice,
            batchNumber: grantBatch,
            expiryDate: grantExpiry,
            lastMovementAt: new Date().toISOString()
          };
        }
        return s;
      }));

      const newMov: StockMovement = {
        id: "mov-" + Date.now(),
        skuId: existingSku.id,
        productName: grantItemName,
        type: "grant_received",
        qtyDelta: grantQty,
        resultingBalance: existingSku.qtyOnHand + grantQty,
        timestamp: new Date().toISOString(),
        actorId: activeSupplierId,
        actorName: "Zambezi Seed Corp Logistics",
        reference: grantNumber
      };
      setMovements(prev => [newMov, ...prev]);

    } else {
      const newSkuId = "sku-" + Date.now();
      const newSku: AgroDealerSKU = {
        id: newSkuId,
        tenantId: targetDealer.id,
        productName: grantItemName,
        category: grantCategory,
        unit: grantUnit,
        supplierId: activeSupplierId,
        supplierName: "Zambezi Seed Corp (ZAMSEED)",
        grantId,
        unitCost: grantUnitCost,
        sellingPrice: grantSellingPrice,
        qtyReceived: grantQty,
        qtySold: 0,
        qtyOnHand: grantQty,
        qtyReserved: 0,
        reorderThreshold: 20,
        batchNumber: grantBatch,
        expiryDate: grantExpiry,
        lastMovementAt: new Date().toISOString()
      };

      const newMov: StockMovement = {
        id: "mov-" + Date.now(),
        skuId: newSkuId,
        productName: grantItemName,
        type: "grant_received",
        qtyDelta: grantQty,
        resultingBalance: grantQty,
        timestamp: new Date().toISOString(),
        actorId: activeSupplierId,
        actorName: "Zambezi Seed Corp Logistics",
        reference: grantNumber
      };

      setSkus(prev => [newSku, ...prev]);
      setMovements(prev => [newMov, ...prev]);
    }

    setGrants(prev => [newGrant, ...prev]);

    // Save custom item to Supplier Stock Catalog if requested and not present
    if (saveCustomToCatalog) {
      const matchInCatalog = supplierCatalog.find(
        c => c.supplierId === activeSupplierId && c.productName.toLowerCase() === grantItemName.toLowerCase()
      );
      if (!matchInCatalog) {
        const activeSup = suppliers.find(s => s.id === activeSupplierId);
        const newCatItem: SupplierCatalogItem = {
          id: "sup-cat-" + Date.now(),
          supplierId: activeSupplierId,
          supplierName: activeSup ? activeSup.name : "Supplier Institution",
          productName: grantItemName,
          category: grantCategory,
          unit: grantUnit,
          unitWholesaleCost: grantUnitCost,
          recommendedSellingPrice: grantSellingPrice,
          qtyInStock: 2500,
          batchNumber: grantBatch,
          expiryDate: grantExpiry,
          createdAt: new Date().toISOString()
        };
        setSupplierCatalog(prev => [newCatItem, ...prev]);
      }
    }

    setShowGrantModal(false);
    showToast(`Issued Stock Grant ${grantNumber} (${grantQty} ${grantUnit}) to ${targetDealer.businessName}`);
  };

  // Handle Subscription Sponsorship Toggle
  const handleToggleSponsorship = (dealerId: string) => {
    setDealers(prev => prev.map(d => {
      if (d.id === dealerId) {
        const currentlySponsored = d.sponsoredByInstitutionId === activeSupplierId;
        return {
          ...d,
          sponsoredByInstitutionId: currentlySponsored ? null : activeSupplierId,
          subscriptionStatus: currentlySponsored ? "grace_period" : "active"
        };
      }
      return d;
    }));

    showToast("Updated subscription sponsorship status for dealer.");
  };

  // Handle Super Admin Create Agro-Dealer (Wizard 3.1)
  const handleCreateAgroDealer = (e: React.FormEvent) => {
    e.preventDefault();
    if (newDealerPassword && newDealerPassword !== newDealerConfirmPassword) {
      showToast("Agro Dealer login passwords do not match!", "error");
      return;
    }

    const resolvedTradingName = (newDealerTradingName || newDealerName || "Agro-Dealer Retail Store").trim();
    const resolvedBusinessName = (newDealerName || newDealerTradingName || "Agro-Dealer Retail Store Ltd").trim();
    const ownerNameClean = (newDealerOwner || "Store Owner").trim();
    const ownerPhoneClean = (newDealerPhone || "+260977000000").trim();
    const cityClean = (newDealerCity || `${newDealerDistrict} Central Market Area`).trim();

    const newId = "dealer-" + Date.now();
    const dealerEmailClean = (newDealerEmail || `${ownerNameClean.toLowerCase().replace(/\s+/g, '')}@gmail.com`).toLowerCase();
    const setPassClean = (newDealerPassword || "Mabala@2026").trim();

    const thirtyDaysFromNow = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

    const newDealer: AgroDealerTenant = {
      id: newId,
      businessName: resolvedBusinessName,
      tradingName: resolvedTradingName,
      pacraTpin: newDealerPacra ? newDealerPacra.trim() : undefined,
      ownerName: ownerNameClean,
      ownerPhone: ownerPhoneClean,
      ownerEmail: dealerEmailClean,
      province: newDealerProvince,
      district: newDealerDistrict,
      city: cityClean,
      gpsLocation: { lat: newDealerLat || -15.4167, lng: newDealerLng || 28.2833 },
      canDeliver: newDealerCanDeliver,
      lipilaPaymentLinkId: "LINK-" + Math.floor(1000 + Math.random() * 9000),
      subscriptionStatus: "active",
      subscriptionTier: "monthly_180",
      credits: 100,
      subscriptionExpiryDate: thirtyDaysFromNow,
      loginPassword: setPassClean,
      createdAt: new Date().toISOString()
    };

    // Save pending user credentials into mabala_pending_first_login_users and registered roles map
    try {
      const existingStr = localStorage.getItem("mabala_pending_first_login_users");
      const pendingUsers = existingStr ? JSON.parse(existingStr) : [];
      pendingUsers.push({
        email: dealerEmailClean,
        name: ownerNameClean,
        businessName: resolvedBusinessName,
        tradingName: resolvedTradingName,
        role: "Agro Dealer",
        workspaceMode: "agro_dealer",
        tenantType: "agro_dealer",
        defaultPassword: setPassClean,
        password: setPassClean,
        forcePasswordChange: false,
        createdAt: new Date().toISOString()
      });
      localStorage.setItem("mabala_pending_first_login_users", JSON.stringify(pendingUsers));

      const rolesMapStr = localStorage.getItem("mabala_registered_roles_map") || "{}";
      const rolesMap = JSON.parse(rolesMapStr);
      rolesMap[dealerEmailClean] = {
        role: "Agro Dealer",
        workspaceMode: "agro_dealer",
        tenantType: "agro_dealer"
      };
      localStorage.setItem("mabala_registered_roles_map", JSON.stringify(rolesMap));
    } catch (err) {
      console.warn("Unable to save pending dealer login credentials to localStorage", err);
    }

    setDealers(prev => [...prev, newDealer]);
    setActiveDealerId(newId);
    setShowCreateDealerModal(false);

    // Reset form
    setNewDealerName("");
    setNewDealerTradingName("");
    setNewDealerPacra("");
    setNewDealerOwner("");
    setNewDealerPhone("");
    setNewDealerEmail("");
    setNewDealerPassword("");
    setNewDealerConfirmPassword("");

    const kycNotice = "K180 monthly plan & 100 credits activated immediately upon account creation.";

    showToast(`Provisioned Agro-Dealer tenant: ${resolvedTradingName}! 🔑 Login password: '${setPassClean}'. ${kycNotice}`);
  };

  // Handle Super Admin Create / Capability Upgrade Seed Company (Wizard 3.2)
  const handleCreateSupplierCompany = (e: React.FormEvent) => {
    e.preventDefault();

    if (supplierCreateMode === "UPGRADE_EXISTING") {
      if (!upgradeInstId) {
        showToast("Please select an institution to upgrade.");
        return;
      }
      const targetInst = suppliers.find(s => s.id === upgradeInstId);
      if (targetInst) {
        setSuppliers(prev => prev.map(s => {
          if (s.id === upgradeInstId) {
            const newCaps = Array.from(new Set([...s.capabilities, "supplier"]));
            return { ...s, capabilities: newCaps };
          }
          return s;
        }));
        showToast(`Attached 'supplier' capability to ${targetInst.name}! Enabled stock grant & dealer ledger tracking.`);
      }
      setShowCreateSupplierModal(false);
      return;
    }

    // Validate nominated staff passwords
    for (let i = 0; i < nominatedStaffList.length; i++) {
      const staff = nominatedStaffList[i];
      if (staff.password && staff.password !== staff.confirmPassword) {
        showToast(`Passwords do not match for staff member #${i + 1} (${staff.name || 'Admin'})!`, "error");
        return;
      }
    }

    const nameClean = (newSupplierName || "Agro Supplier Institution").trim();
    const addressClean = (newSupplierAddress || "Lusaka Commercial District").trim();
    const newId = "inst-" + Date.now();

    const preparedAdmins = nominatedStaffList.map((st, idx) => ({
      name: (st.name || `${nameClean} Admin ${idx + 1}`).trim(),
      email: (st.email || `admin${idx + 1}@${nameClean.toLowerCase().replace(/\s+/g, '')}.co.zm`).toLowerCase().trim(),
      phone: (st.phone || "+260977000000").trim()
    }));

    const newSupplier: SupplierInstitution = {
      id: newId,
      name: nameClean,
      pacraTpin: newSupplierPacra ? newSupplierPacra.trim() : undefined,
      registeredAddress: addressClean,
      productCategories: newSupplierCategories.length > 0 ? newSupplierCategories : ["seed"],
      nominatedAdmins: preparedAdmins,
      capabilities: ["institution", "supplier"],
      createdAt: new Date().toISOString()
    };
    (newSupplier as any).credits = 100;

    // Save all nominated admin staff into pending login users
    try {
      const existingStr = localStorage.getItem("mabala_pending_first_login_users");
      const pendingUsers = existingStr ? JSON.parse(existingStr) : [];
      const rolesMapStr = localStorage.getItem("mabala_registered_roles_map") || "{}";
      const rolesMap = JSON.parse(rolesMapStr);

      nominatedStaffList.forEach((st, idx) => {
        const staffEmail = (st.email || `admin${idx + 1}@${nameClean.toLowerCase().replace(/\s+/g, '')}.co.zm`).toLowerCase().trim();
        const staffName = (st.name || `${nameClean} Admin ${idx + 1}`).trim();
        const staffPass = (st.password || "Mabala@2026").trim();

        pendingUsers.push({
          email: staffEmail,
          name: staffName,
          businessName: nameClean,
          role: "supplier",
          tenantType: "institution_supplier",
          defaultPassword: staffPass,
          password: staffPass,
          forcePasswordChange: false,
          createdAt: new Date().toISOString()
        });

        rolesMap[staffEmail] = { role: "Supplier", tenantType: "institution_supplier" };
      });

      localStorage.setItem("mabala_pending_first_login_users", JSON.stringify(pendingUsers));
      localStorage.setItem("mabala_registered_roles_map", JSON.stringify(rolesMap));
    } catch (err) {
      console.warn("Unable to save pending supplier login credentials to localStorage", err);
    }

    setSuppliers(prev => [...prev, newSupplier]);
    setActiveSupplierId(newId);
    setShowCreateSupplierModal(false);

    setNewSupplierName("");
    setNewSupplierPacra("");
    setNewSupplierAddress("");
    setNominatedStaffList([{ id: "staff-1", name: "", email: "", phone: "", role: "Manager", password: "", confirmPassword: "", permissions: "read_write" }]);

    showToast(`Provisioned Supplier Tenant: ${nameClean} with ${preparedAdmins.length} Nominated Admin Staff! 🔑 Account active with 100 platform credits.`);
  };

  // Handle Consignment Agreement Invitation & Linking (Wizard 3.3)
  const handleCreateAgreementInvitation = (e: React.FormEvent) => {
    e.preventDefault();
    const targetDealer = dealers.find(d => d.id === agrDealerId);
    const targetSupplier = suppliers.find(s => s.id === agrSupplierId);

    if (!targetDealer || !targetSupplier) return;

    const agrId = "agr-" + Date.now();
    const newAgr: ConsignmentAgreement = {
      id: agrId,
      dealerTenantId: targetDealer.id,
      dealerName: targetDealer.businessName,
      dealerPhone: targetDealer.ownerPhone,
      institutionId: targetSupplier.id,
      institutionName: targetSupplier.name,
      remittancePeriodDays: agrPeriodDays,
      commissionBearer: agrCommissionBearer,
      productCategories: agrCategories,
      creditLimit: agrCreditLimit,
      status: "pending",
      createdAt: new Date().toISOString()
    };

    setAgreements(prev => [...prev, newAgr]);
    setShowAgreementModal(false);
    showToast(`Sent Consignment Agreement invitation to ${targetDealer.businessName}! (Pending dealer in-app acceptance).`);
  };

  const handleAcceptAgreement = (agrId: string) => {
    setAgreements(prev => {
      const next = prev.map(a => {
        if (a.id === agrId) {
          return {
            ...a,
            status: "active" as const,
            acceptedAt: new Date().toISOString()
          };
        }
        return a;
      });
      localStorage.setItem("mabala_agd_agreements", JSON.stringify(next));
      return next;
    });
    showToast("Consignment Credit Agreement accepted & activated! Stock grants can now be issued.");
  };

  // Super Admin Action Handlers for Agro-Dealers, Suppliers, and Agreements with Explicit Confirmation
  const handleToggleSuspendDealer = (dealerId: string) => {
    const target = dealers.find(d => d.id === dealerId);
    if (!target) return;
    const isSuspended = (target as any).status === "suspended" || target.subscriptionStatus === "expired";
    setConfirmModalState({
      isOpen: true,
      type: "suspend_dealer",
      id: dealerId,
      name: target.tradingName || target.businessName,
      isCurrentlySuspended: isSuspended
    });
  };

  const executeToggleSuspendDealer = (dealerId: string) => {
    setDealers(prev => {
      const next = prev.map(d => {
        if (d.id === dealerId) {
          const isSuspended = (d as any).status === "suspended" || d.subscriptionStatus === "expired";
          const newStatus = isSuspended ? "active" : "suspended";
          showToast(`Agro-Dealer ${d.tradingName || d.businessName} has been ${isSuspended ? "Reactivated" : "Suspended"}.`);
          return {
            ...d,
            status: newStatus as any,
            subscriptionStatus: (isSuspended ? "active" : "expired") as any
          };
        }
        return d;
      });
      localStorage.setItem("mabala_agd_dealers", JSON.stringify(next));
      return next;
    });
  };

  const handleDeleteDealer = (dealerId: string) => {
    const target = dealers.find(d => d.id === dealerId);
    if (!target) return;
    setConfirmModalState({
      isOpen: true,
      type: "delete_dealer",
      id: dealerId,
      name: target.tradingName || target.businessName
    });
  };

  const executeDeleteDealer = (dealerId: string) => {
    const target = dealers.find(d => d.id === dealerId);
    setDealers(prev => {
      const next = prev.filter(d => d.id !== dealerId);
      localStorage.setItem("mabala_agd_dealers", JSON.stringify(next));
      return next;
    });
    showToast(`Deleted Agro-Dealer: ${target?.tradingName || target?.businessName || dealerId}`);
  };

  const handleToggleSuspendSupplier = (supplierId: string) => {
    const target = suppliers.find(s => s.id === supplierId);
    if (!target) return;
    const isSuspended = (target as any).status === "suspended";
    setConfirmModalState({
      isOpen: true,
      type: "suspend_supplier",
      id: supplierId,
      name: target.name,
      isCurrentlySuspended: isSuspended
    });
  };

  const executeToggleSuspendSupplier = (supplierId: string) => {
    setSuppliers(prev => {
      const next = prev.map(s => {
        if (s.id === supplierId) {
          const isSuspended = (s as any).status === "suspended";
          const newStatus = isSuspended ? "active" : "suspended";
          showToast(`Seed & Chemical Company "${s.name}" has been ${isSuspended ? "Reactivated" : "Suspended"}.`);
          return {
            ...s,
            status: newStatus as any
          };
        }
        return s;
      });
      localStorage.setItem("mabala_agd_suppliers", JSON.stringify(next));
      return next;
    });
  };

  const handleDeleteSupplier = (supplierId: string) => {
    const target = suppliers.find(s => s.id === supplierId);
    if (!target) return;
    setConfirmModalState({
      isOpen: true,
      type: "delete_supplier",
      id: supplierId,
      name: target.name
    });
  };

  const executeDeleteSupplier = (supplierId: string) => {
    const target = suppliers.find(s => s.id === supplierId);
    setSuppliers(prev => {
      const next = prev.filter(s => s.id !== supplierId);
      localStorage.setItem("mabala_agd_suppliers", JSON.stringify(next));
      return next;
    });
    showToast(`Deleted Seed & Chemical Company: ${target?.name || supplierId}`);
  };

  const handleToggleSuspendAgreement = (agrId: string) => {
    const target = agreements.find(a => a.id === agrId);
    if (!target) return;
    const isSuspended = (target.status as any) === "suspended" || (target.status as any) === "revoked";
    setConfirmModalState({
      isOpen: true,
      type: "suspend_agreement",
      id: agrId,
      name: `Agreement (${target.institutionName} ↔ ${target.dealerName})`,
      isCurrentlySuspended: isSuspended
    });
  };

  const executeToggleSuspendAgreement = (agrId: string) => {
    setAgreements(prev => {
      const next = prev.map(a => {
        if (a.id === agrId) {
          const isSuspended = (a.status as any) === "suspended" || (a.status as any) === "revoked";
          const newStatus = isSuspended ? "active" : "suspended";
          showToast(`Consignment Agreement between ${a.institutionName} and ${a.dealerName} has been ${isSuspended ? "Reactivated" : "Suspended"}.`);
          return {
            ...a,
            status: newStatus as any
          };
        }
        return a;
      });
      localStorage.setItem("mabala_agd_agreements", JSON.stringify(next));
      return next;
    });
  };

  const handleDeleteAgreement = (agrId: string) => {
    const target = agreements.find(a => a.id === agrId);
    if (!target) return;
    setConfirmModalState({
      isOpen: true,
      type: "delete_agreement",
      id: agrId,
      name: `Agreement (${target.institutionName} ↔ ${target.dealerName})`
    });
  };

  const executeDeleteAgreement = (agrId: string) => {
    const target = agreements.find(a => a.id === agrId);
    setAgreements(prev => {
      const next = prev.filter(a => a.id !== agrId);
      localStorage.setItem("mabala_agd_agreements", JSON.stringify(next));
      return next;
    });
    showToast(`Deleted Consignment Agreement (${target?.id || agrId})`);
  };

  // Generate or View AI Safety Brief
  const handleTriggerAiBrief = async (sku: AgroDealerSKU) => {
    if (sku.aiBrief) {
      setShowAiBriefModal(sku);
      return;
    }

    showToast("Generating Agronomist AI Safety Brief via Gemini...");
    const brief = await generateAgroAIBrief(sku.productName, sku.category, sku.unit);

    const updatedSku = {
      ...sku,
      aiBrief: brief
    };

    setSkus(prev => prev.map(s => s.id === sku.id ? updatedSku : s));
    setShowAiBriefModal(updatedSku);
  };

  return (
    <div className="space-y-6 text-slate-800 font-sans pb-16">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-emerald-500/50 flex items-center gap-3 animate-bounce">
          <Sparkles className="w-5 h-5 text-emerald-400" />
          <span className="text-xs font-bold font-mono">{toastMessage}</span>
        </div>
      )}

      {/* Main Module Banner & Top Workspace Switcher */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-emerald-500/30 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Boxes className="w-64 h-64 text-emerald-400" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row justify-between md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-black uppercase font-mono px-3 py-1 rounded-full border border-emerald-500/30 tracking-wider">
                AGD Module v1.0 — Consignment & Reconciliation
              </span>
              <span className="bg-amber-500/20 text-amber-300 text-[10px] font-black font-mono px-2.5 py-0.5 rounded">
                Lipila Farm Balance Integrated
              </span>
            </div>
            <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
              <span>🌾 Mabala Agro-Dealer Consignment Hub</span>
            </h1>
            <p className="text-xs text-slate-300 leading-relaxed max-w-2xl mt-1">
              Real-time consignment inventory management for retail agro-dealers, paired with automated supplier reconciliation, Farm Balance remittances, and seed/chemical supplier network oversight.
            </p>
          </div>

          {/* Workspace Role Mode Selector */}
          <div className="flex items-center bg-slate-800/90 p-1.5 rounded-xl border border-slate-700/80 shrink-0">
            {(isPlatformAdmin || isAgroDealer || (!isSupplier && !isPlatformAdmin)) && (
              <button
                type="button"
                onClick={() => setActiveWorkspaceMode("DEALER")}
                className={`px-3 py-2 rounded-lg text-xs font-extrabold flex items-center gap-2 transition ${
                  activeWorkspaceMode === "DEALER"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Store className="w-4 h-4" />
                <span>Retail Shop View</span>
              </button>
            )}

            {(isPlatformAdmin || isSupplier) && (
              <button
                type="button"
                onClick={() => setActiveWorkspaceMode("SUPPLIER")}
                className={`px-3 py-2 rounded-lg text-xs font-extrabold flex items-center gap-2 transition ${
                  activeWorkspaceMode === "SUPPLIER"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Building2 className="w-4 h-4" />
                <span>Supplier Portal</span>
              </button>
            )}

            {isPlatformAdmin && (
              <button
                type="button"
                onClick={() => setActiveWorkspaceMode("SUPER_ADMIN")}
                className={`px-3 py-2 rounded-lg text-xs font-extrabold flex items-center gap-2 transition ${
                  activeWorkspaceMode === "SUPER_ADMIN"
                    ? "bg-amber-600 text-white shadow-md"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Super Admin</span>
              </button>
            )}
          </div>
        </div>

        {/* Global Lipila Farm Balance Live Bar */}
        <div className="mt-5 pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-slate-400 text-[11px] font-bold">Active Shop Context:</span>
              <select
                value={activeDealerId}
                onChange={e => setActiveDealerId(e.target.value)}
                className="bg-slate-800 text-emerald-300 font-bold px-3 py-1.5 rounded-lg border border-slate-700 focus:outline-none text-xs"
              >
                {dealers.map(d => (
                  <option key={d.id} value={d.id}>
                    {d.businessName} ({d.province})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2 border-l border-slate-800 pl-4">
              <span className="text-slate-400 text-[11px] font-bold">Lipila Payment Link ID:</span>
              <span className="font-mono font-black text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded border border-amber-500/30">
                {activeDealer.lipilaPaymentLinkId}
              </span>
              <button
                type="button"
                onClick={() => handleTriggerLipilaPaymentLink(activeDealer.lipilaPaymentLinkId, 180, "Agro-Dealer Monthly SaaS Subscription (K180/Mo)")}
                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-bold text-[10.5px] flex items-center gap-1 transition cursor-pointer active:scale-95 shadow-xs"
              >
                <Zap className="w-3 h-3 text-amber-300 fill-amber-300" />
                <span>Process via Lipila Production API</span>
              </button>
            </div>
          </div>

          <div className="flex items-center gap-4 font-mono">
            <div className="flex items-center gap-2">
              <span className="text-slate-400 text-[11px]">Farm Balance:</span>
              <strong className="text-lg text-emerald-400 font-extrabold">
                {currencySymbol} {dealerBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </strong>
            </div>

            <button
              type="button"
              onClick={() => setShowFarmBalanceModal(true)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 shadow-sm transition cursor-pointer font-sans"
            >
              <Coins className="w-3.5 h-3.5 text-emerald-200" />
              <span>Farm Balance & Wallet</span>
            </button>

            {totalDealerPayable > 0 && (
              <div className="flex items-center gap-2 bg-rose-500/20 text-rose-300 px-3 py-1 rounded-lg border border-rose-500/40">
                <span className="text-[10px] uppercase font-bold">Consignment Payable:</span>
                <strong className="font-extrabold text-white">
                  {currencySymbol} {totalDealerPayable.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </strong>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* READ-ONLY ACCESS BANNER FOR AGRO-DEALERS AND SUPPLIERS WHEN CREDITS EXHAUSTED OR SUBSCRIPTION EXPIRED */}
      {((activeWorkspaceMode === "DEALER" && isAgroDealerReadOnly) || (activeWorkspaceMode === "SUPPLIER" && isSupplierReadOnly)) && (
        <div className="bg-gradient-to-r from-rose-950 via-amber-950 to-slate-900 border-2 border-rose-500/50 p-4 rounded-2xl shadow-xl text-white space-y-3 animate-fade-in my-4">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-400/40 text-rose-300 flex items-center justify-center shrink-0 mt-0.5">
                <Lock className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h4 className="font-black text-sm uppercase tracking-wide text-rose-300 flex items-center gap-2">
                  <span>🔒 READ-ONLY ACCESS MODE ACTIVATED</span>
                  <span className="text-[10px] bg-rose-500 text-white font-mono font-bold px-2 py-0.5 rounded-full">
                    ACTIONS RESTRICTED
                  </span>
                </h4>
                <p className="text-xs text-rose-100 font-medium mt-0.5 max-w-2xl leading-relaxed">
                  {activeWorkspaceMode === "DEALER" && isDealerCreditsExhausted
                    ? `Your initial 100 platform credits have been exhausted (0 credits remaining). All inventory adjustments, POS sales, and grant creations are restricted to Read-Only mode.`
                    : activeWorkspaceMode === "DEALER" && isDealerSubscriptionExpired
                    ? `Your 1-Month K180 subscription period has elapsed. Please renew your monthly subscription to regain full operational Read/Write privileges.`
                    : `Your supplier platform credits have been exhausted. Please top up your credits to issue stock grants or respond to consignment requests.`}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setShowFarmBalanceModal(true);
                  setFarmBalanceTab("CREDITS");
                }}
                className="px-4 py-2 bg-gradient-to-r from-amber-500 to-emerald-500 hover:from-amber-400 hover:to-emerald-400 text-slate-950 font-black text-xs rounded-xl shadow-lg cursor-pointer transition flex items-center gap-1.5"
              >
                <Zap className="w-4 h-4 fill-slate-950" />
                <span>Buy Topup Credits / Renew Subscription</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* WORKSPACE 1: AGRO-DEALER RETAIL WORKSPACE */}
      {activeWorkspaceMode === "DEALER" && (
        <div className="space-y-6">
          {/* Dealer Sub-Navigation Tabs */}
          <div className="flex items-center justify-between bg-white border border-slate-200 p-2 rounded-2xl shadow-xs">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setDealerSubTab("INVENTORY")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  dealerSubTab === "INVENTORY"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Boxes className="w-4 h-4" />
                <span>Inventory & Stockroom</span>
                {lowStockSkus.length > 0 && (
                  <span className="bg-rose-500 text-white text-[10px] px-2 py-0.5 rounded-full font-black">
                    {lowStockSkus.length}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setDealerSubTab("MOVEMENTS")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  dealerSubTab === "MOVEMENTS"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Layers className="w-4 h-4" />
                <span>Stock Movement Ledger</span>
              </button>

              <button
                type="button"
                onClick={() => setDealerSubTab("POS")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  dealerSubTab === "POS"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Store className="w-4 h-4" />
                <span>Point of Sale (POS Till)</span>
              </button>

              <button
                type="button"
                onClick={() => setDealerSubTab("POS_SALES")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  dealerSubTab === "POS_SALES"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>Sales Tracker & Receipts</span>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] px-2 py-0.5 rounded-full font-mono font-bold">
                  {posSales.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setDealerSubTab("REMITTANCE")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  dealerSubTab === "REMITTANCE"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Coins className="w-4 h-4" />
                <span>Remittance & Consignment Payables</span>
              </button>

              <button
                type="button"
                onClick={() => setDealerSubTab("FINANCIAL_RECONCILIATION")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  dealerSubTab === "FINANCIAL_RECONCILIATION"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-amber-300" />
                <span>Financial Reconciliation</span>
              </button>

              <button
                type="button"
                onClick={() => setDealerSubTab("AGC_CREDIT_POS")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  dealerSubTab === "AGC_CREDIT_POS"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>AGC Input Credit POS Counter</span>
              </button>

              <button
                type="button"
                onClick={() => setDealerSubTab("REPORTS")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  dealerSubTab === "REPORTS"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Consignment & POS Reports</span>
              </button>

              <button
                type="button"
                onClick={() => setDealerSubTab("BULK_IMPORT")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  dealerSubTab === "BULK_IMPORT"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Boxes className="w-4 h-4 text-amber-500" />
                <span>Bulk SKU Import (CSV)</span>
              </button>

              <button
                type="button"
                onClick={() => setDealerSubTab("DDACC_LOANS")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  dealerSubTab === "DDACC_LOANS"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>DDACC Farmer Loans & Deductions</span>
              </button>
            </div>

            <div className="flex items-center gap-2">

              <button
                type="button"
                onClick={() => setShowAddSkuModal(true)}
                className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Stock Item</span>
              </button>
            </div>
          </div>

          {/* SUB-TAB 1: INVENTORY & STOCKROOM */}
          {dealerSubTab === "INVENTORY" && (
            <div className="space-y-6">
              {/* Inventory KPI Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-extrabold uppercase text-slate-400 font-mono">Total SKUs Tracked</span>
                  <strong className="text-2xl font-black text-slate-800 block mt-1">{dealerSkus.length}</strong>
                  <span className="text-[10px] text-slate-500 font-medium">Seed & Agro-Chemical items</span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-extrabold uppercase text-slate-400 font-mono">Inventory Asset Value</span>
                  <strong className="text-2xl font-mono font-bold text-slate-900 block mt-1">
                    {currencySymbol} {dealerSkus.reduce((sum, s) => sum + (s.qtyOnHand * s.unitCost), 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </strong>
                  <span className="text-[10px] text-slate-500 font-medium">At grant unit cost baseline</span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-amber-200 bg-amber-50/30 shadow-xs">
                  <span className="text-[10px] font-extrabold uppercase text-amber-700 font-mono">Low Stock Alerts</span>
                  <strong className="text-2xl font-black text-amber-900 block mt-1">{lowStockSkus.length} SKUs</strong>
                  <span className="text-[10px] text-amber-700 font-semibold">Below reorder threshold</span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-rose-200 bg-rose-50/30 shadow-xs">
                  <span className="text-[10px] font-extrabold uppercase text-rose-700 font-mono">Consignment Payable</span>
                  <strong className="text-2xl font-mono font-bold text-rose-900 block mt-1">
                    {currencySymbol} {totalDealerPayable.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </strong>
                  <span className="text-[10px] text-rose-700 font-semibold">Owed to supplying companies</span>
                </div>
              </div>

              {/* Low Stock Warning Banner */}
              {lowStockSkus.length > 0 && (
                <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                    <div>
                      <h4 className="text-xs font-black text-amber-900">Low Stock Warning Triggered</h4>
                      <p className="text-[11px] text-amber-800">
                        {lowStockSkus.length} SKUs have crossed below reorder threshold. Automated Beem Africa restock SMS alerts dispatched to suppliers.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCategoryFilter("ALL")}
                    className="px-3 py-1.5 bg-amber-600 text-white text-xs font-bold rounded-lg shrink-0 hover:bg-amber-700 transition"
                  >
                    View Low Stock SKUs
                  </button>
                </div>
              )}

              {/* Search & Filter Controls */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
                <div className="relative flex-1 min-w-[240px]">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    placeholder="Search product name, batch number, or supplier..."
                    className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-xl font-medium focus:outline-none focus:border-emerald-600"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
                    <Filter className="w-3.5 h-3.5 text-slate-400" />
                    <span>Category:</span>
                    <select
                      value={categoryFilter}
                      onChange={e => setCategoryFilter(e.target.value)}
                      className="bg-slate-100 text-slate-800 text-xs font-bold px-2.5 py-1.5 rounded-lg border border-slate-200 focus:outline-none"
                    >
                      <option value="ALL">All Categories</option>
                      <option value="seed">Seeds</option>
                      <option value="pesticide">Pesticides</option>
                      <option value="herbicide">Herbicides</option>
                      <option value="fungicide">Fungicides</option>
                      <option value="fertilizer">Fertilizers</option>
                      <option value="other">Other Supplies</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
                    <span>Stock Source:</span>
                    <select
                      value={supplierFilter}
                      onChange={e => setSupplierFilter(e.target.value)}
                      className="bg-slate-100 text-slate-800 text-xs font-bold px-2.5 py-1.5 rounded-lg border border-slate-200 focus:outline-none"
                    >
                      <option value="ALL">All Sources</option>
                      <option value="OWNED">Dealer Purchased (Owned)</option>
                      {dealerAgreements.map(a => (
                        <option key={a.institutionId} value={a.institutionId}>
                          Consignment: {a.institutionName}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Inventory Table */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-[10px] uppercase font-extrabold text-slate-500 border-b border-slate-200">
                      <tr>
                        <th className="p-4">Product Name & Category</th>
                        <th className="p-4">Source / Supplier</th>
                        <th className="p-4">Batch & Expiry</th>
                        <th className="p-4 text-right">Unit Cost</th>
                        <th className="p-4 text-right">Selling Price</th>
                        <th className="p-4 text-center">Qty On Hand</th>
                        <th className="p-4 text-center">Status</th>
                        <th className="p-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                      {filteredSkus.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="p-8 text-center text-slate-400 italic">
                            No inventory items found matching your filters.
                          </td>
                        </tr>
                      ) : (
                        filteredSkus.map(sku => {
                          const isLow = sku.qtyOnHand <= sku.reorderThreshold;
                          const isConsignment = !!sku.supplierId;

                          return (
                            <tr key={sku.id} className="hover:bg-slate-50 transition">
                              <td className="p-4">
                                <strong className="text-slate-900 block font-bold text-xs">{sku.productName}</strong>
                                <div className="flex items-center gap-2 mt-1">
                                  <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-bold uppercase">
                                    {sku.category}
                                  </span>
                                  <span className="text-[10px] text-slate-400 font-mono">Unit: {sku.unit}</span>
                                </div>
                              </td>

                              <td className="p-4">
                                {isConsignment ? (
                                  <span className="inline-flex items-center gap-1.5 text-[10px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-md">
                                    <Building2 className="w-3 h-3 text-emerald-600" />
                                    <span>{sku.supplierName}</span>
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1.5 text-[10px] font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md">
                                    <Store className="w-3 h-3 text-slate-500" />
                                    <span>Dealer Owned</span>
                                  </span>
                                )}
                              </td>

                              <td className="p-4 font-mono text-[11px]">
                                <span className="block text-slate-700 font-semibold">{sku.batchNumber || "N/A"}</span>
                                <span className="text-[10px] text-slate-400 block">Exp: {sku.expiryDate || "N/A"}</span>
                              </td>

                              <td className="p-4 text-right font-mono font-bold text-slate-600">
                                {currencySymbol} {sku.unitCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                              </td>

                              <td className="p-4 text-right font-mono font-black text-slate-900">
                                {currencySymbol} {sku.sellingPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                              </td>

                              <td className="p-4 text-center font-mono">
                                <strong className={`text-sm font-bold block ${isLow ? "text-amber-600" : "text-emerald-700"}`}>
                                  {sku.qtyOnHand}
                                </strong>
                                <span className="text-[9px] text-slate-400 block">Min: {sku.reorderThreshold}</span>
                              </td>

                              <td className="p-4 text-center">
                                {sku.qtyOnHand === 0 ? (
                                  <span className="bg-rose-100 text-rose-800 text-[10px] font-black px-2.5 py-1 rounded-full uppercase border border-rose-200">
                                    Out of Stock
                                  </span>
                                ) : isLow ? (
                                  <span className="bg-amber-100 text-amber-800 text-[10px] font-black px-2.5 py-1 rounded-full uppercase border border-amber-200">
                                    Low Stock
                                  </span>
                                ) : (
                                  <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-1 rounded-full uppercase border border-emerald-200">
                                    In Stock
                                  </span>
                                )}
                              </td>

                              <td className="p-4 text-right space-x-2">
                                <button
                                  type="button"
                                  onClick={() => handleTriggerAiBrief(sku)}
                                  className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-lg text-[10px] font-bold transition"
                                  title="View Gemini AI Agronomist Safety Brief"
                                >
                                  ✨ AI Safety Brief
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSelectedSkuForMovement(sku);
                                    setShowMovementModal(true);
                                  }}
                                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-bold transition"
                                >
                                  Adjust
                                </button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SUB-TAB 2: STOCK MOVEMENT LEDGER */}
          {dealerSubTab === "MOVEMENTS" && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
                <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                  <Layers className="w-4 h-4 text-emerald-600" />
                  <span>Immutable Stock Movement Audit Ledger</span>
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Every addition, sale, return, damage write-off, or manual adjustment is recorded as an immutable append-only movement entry.
                </p>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-slate-50 text-[10px] uppercase font-extrabold text-slate-500 border-b border-slate-200">
                      <tr>
                        <th className="p-4">Timestamp & Ref</th>
                        <th className="p-4">Product Name</th>
                        <th className="p-4">Movement Type</th>
                        <th className="p-4 text-right">Quantity Change</th>
                        <th className="p-4 text-right">Resulting Balance</th>
                        <th className="p-4">Logged By / Reason</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                      {dealerMovements.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-slate-400 italic">
                            No stock movement entries recorded yet.
                          </td>
                        </tr>
                      ) : (
                        dealerMovements.map(mov => (
                          <tr key={mov.id} className="hover:bg-slate-50 transition">
                            <td className="p-4">
                              <span className="font-mono font-bold text-slate-900 block text-xs">{mov.reference}</span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                {new Date(mov.timestamp).toLocaleString()}
                              </span>
                            </td>

                            <td className="p-4 font-bold text-slate-800">
                              {mov.productName}
                            </td>

                            <td className="p-4">
                              <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                                mov.type === "grant_received" 
                                  ? "bg-emerald-100 text-emerald-800 border border-emerald-300" 
                                  : mov.type === "sale" 
                                  ? "bg-blue-100 text-blue-800 border border-blue-300"
                                  : mov.type === "return_to_supplier"
                                  ? "bg-amber-100 text-amber-800 border border-amber-300"
                                  : "bg-purple-100 text-purple-800 border border-purple-300"
                              }`}>
                                {mov.type.replace(/_/g, " ")}
                              </span>
                            </td>

                            <td className={`p-4 text-right font-mono font-extrabold text-sm ${
                              mov.qtyDelta > 0 ? "text-emerald-700" : "text-rose-600"
                            }`}>
                              {mov.qtyDelta > 0 ? `+${mov.qtyDelta}` : mov.qtyDelta}
                            </td>

                            <td className="p-4 text-right font-mono font-bold text-slate-800">
                              {mov.resultingBalance}
                            </td>

                            <td className="p-4 text-slate-600">
                              <span className="block font-semibold text-xs text-slate-800">{mov.actorName}</span>
                              {mov.reasonCode && (
                                <span className="text-[10px] text-amber-700 font-mono block">Reason: {mov.reasonCode}</span>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SUB-TAB 3: POINT OF SALE (POS TILL) */}
          {dealerSubTab === "POS" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Product Catalog Picker */}
              <div className="lg:col-span-2 space-y-4">
                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between gap-4">
                  <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                    <Store className="w-4 h-4 text-emerald-600" />
                    <span>In-Shop POS Catalogue Till</span>
                  </h3>
                  <div className="relative w-64">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      placeholder="Search items to sell..."
                      className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {filteredSkus.filter(sku => sku.qtyOnHand > 0).length === 0 ? (
                    <div className="col-span-3 p-8 bg-slate-50 border border-dashed rounded-2xl text-center text-xs text-slate-400 font-medium">
                      No in-stock input products found in active catalog. All items are currently out of stock.
                    </div>
                  ) : (
                    filteredSkus.filter(sku => sku.qtyOnHand > 0).map(sku => (
                      <div
                        key={sku.id}
                        onClick={() => handleAddToPosCart(sku)}
                        className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-emerald-500 hover:shadow-md transition cursor-pointer space-y-2 flex flex-col justify-between"
                      >
                        <div>
                          <span className="text-[9px] font-black uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-mono">
                            {sku.category}
                          </span>
                          <h4 className="font-bold text-slate-800 text-xs mt-1.5 line-clamp-2">{sku.productName}</h4>
                          <span className="text-[10px] text-slate-400 block font-mono">Unit: {sku.unit}</span>
                        </div>

                        <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                          <div>
                            <span className="text-[9px] text-slate-400 block">Stock: {sku.qtyOnHand}</span>
                            <strong className="text-sm font-mono font-bold text-slate-900">
                              {currencySymbol} {sku.sellingPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                            </strong>
                          </div>
                          <button
                            type="button"
                            className="px-2.5 py-1 bg-emerald-700 text-white text-[10px] font-bold rounded-lg hover:bg-emerald-800 transition"
                          >
                            + Add
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* POS Cart & Checkout Screen */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b pb-3">
                    <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                      <Tag className="w-4 h-4 text-emerald-600" />
                      <span>Current Checkout Basket</span>
                    </h3>
                    <span className="text-xs font-mono font-bold bg-slate-100 px-2.5 py-0.5 rounded text-slate-700">
                      {posCart.reduce((acc, i) => acc + i.qty, 0)} items
                    </span>
                  </div>

                  {/* Customer Info */}
                  <div className="space-y-2 text-xs">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-500 block">Customer Name (Optional)</label>
                      <input
                        type="text"
                        value={posCustomerName}
                        onChange={e => setPosCustomerName(e.target.value)}
                        placeholder="e.g. Sipho Phiri / Walk-in"
                        className="w-full p-2 border border-slate-300 rounded-lg mt-0.5 font-medium"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-500 block">Customer Phone (Lipila Request)</label>
                      <input
                        type="text"
                        value={posCustomerPhone}
                        onChange={e => setPosCustomerPhone(e.target.value)}
                        placeholder="+26097..."
                        className="w-full p-2 border border-slate-300 rounded-lg mt-0.5 font-medium font-mono"
                      />
                      {posCustomerPhone && posCustomerPhone.trim().length >= 3 && (
                        <div className="mt-1.5 flex items-center gap-1.5 text-[10px] font-bold">
                          <span className="text-slate-400">Carrier Auto-Detect:</span>
                          <span className={`px-2 py-0.5 rounded-md font-mono text-[10px] uppercase font-extrabold ${detectCarrier(posCustomerPhone).badgeBg}`}>
                            {detectCarrier(posCustomerPhone).name}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Cart Items List */}
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {posCart.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-400 italic">
                        Click products on the left catalogue to add to cart.
                      </div>
                    ) : (
                      posCart.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs gap-2">
                          <div className="flex-1 min-w-0 pr-1">
                            <span className="font-bold text-slate-800 block truncate">{item.sku.productName}</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {currencySymbol} {item.sku.sellingPrice}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0 font-mono">
                            <button
                              type="button"
                              onClick={() => handleUpdatePosCartQty(item.sku.id, -1)}
                              className="w-5 h-5 flex items-center justify-center bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded text-xs cursor-pointer"
                              title="Decrease quantity"
                            >
                              -
                            </button>
                            <span className="font-bold text-xs px-1">{item.qty}</span>
                            <button
                              type="button"
                              onClick={() => handleUpdatePosCartQty(item.sku.id, 1)}
                              className="w-5 h-5 flex items-center justify-center bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded text-xs cursor-pointer"
                              title="Increase quantity"
                            >
                              +
                            </button>
                            <strong className="font-bold text-slate-900 ml-1">
                              {currencySymbol} {(item.sku.sellingPrice * item.qty).toLocaleString()}
                            </strong>
                            <button
                              type="button"
                              onClick={() => handleRemoveFromPosCart(item.sku.id)}
                              className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded transition-all cursor-pointer ml-1"
                              title="Remove item from checkout basket"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Payment Mode Selection */}
                  <div className="space-y-2 pt-2 border-t">
                    <label className="text-[10px] uppercase font-bold text-slate-500 block">Payment Method</label>
                    <div className="grid grid-cols-2 gap-2 text-xs font-bold">
                      <button
                        type="button"
                        onClick={() => setPosPaymentMethod("MOBILE_MONEY")}
                        className={`p-2 rounded-xl border flex items-center gap-1.5 justify-center transition ${
                          posPaymentMethod === "MOBILE_MONEY"
                            ? "bg-emerald-600 text-white border-emerald-600 shadow-xs"
                            : "bg-slate-50 text-slate-700 border-slate-200"
                        }`}
                      >
                        <Zap className="w-3.5 h-3.5" />
                        <span>Lipila Mobile Money</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPosPaymentMethod("CASH")}
                        className={`p-2 rounded-xl border flex items-center gap-1.5 justify-center transition ${
                          posPaymentMethod === "CASH"
                            ? "bg-emerald-600 text-white border-emerald-600 shadow-xs"
                            : "bg-slate-50 text-slate-700 border-slate-200"
                        }`}
                      >
                        <DollarSign className="w-3.5 h-3.5" />
                        <span>Cash Payment</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Total & Complete Sale Button */}
                <div className="pt-4 border-t border-slate-200 space-y-3">
                  <div className="flex justify-between items-center text-slate-800">
                    <span className="text-xs font-extrabold uppercase">Total Payable:</span>
                    <strong className="text-xl font-mono font-black text-emerald-800">
                      {currencySymbol} {posCart.reduce((sum, i) => sum + (i.sku.sellingPrice * i.qty), 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </strong>
                  </div>

                  <button
                    type="button"
                    disabled={posCart.length === 0}
                    onClick={handleExecutePosSale}
                    className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs rounded-xl shadow-md transition disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Complete Sale & Issue Receipt</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* SUB-TAB 3.5: SALES TRACKER & RECEIPT HISTORY */}
          {dealerSubTab === "POS_SALES" && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex justify-between items-center">
                <div>
                  <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                    <FileText className="w-4 h-4 text-emerald-600" />
                    <span>Point of Sale Completed Sales Tracker</span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Audit records of completed till transactions. Inventory quantities for sold items are automatically deducted and logged in the Stock Movement Audit Ledger.
                  </p>
                </div>
                <span className="text-xs font-mono font-bold bg-emerald-50 text-emerald-800 px-3 py-1.5 rounded-xl border border-emerald-200">
                  Total Recorded Sales: {posSales.filter(s => s.dealerId === activeDealer.id).length}
                </span>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-slate-50 text-[10px] uppercase font-extrabold text-slate-500 border-b border-slate-200">
                      <tr>
                        <th className="p-4">Receipt # / Timestamp</th>
                        <th className="p-4">Customer Details</th>
                        <th className="p-4">Items Sold</th>
                        <th className="p-4 text-right">Total Amount</th>
                        <th className="p-4 text-center">Payment Method / Carrier</th>
                        <th className="p-4 text-center">Inventory Deducted</th>
                        <th className="p-4 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                      {posSales.filter(s => s.dealerId === activeDealer.id).length === 0 ? (
                        <tr>
                          <td colSpan={7} className="p-8 text-center text-slate-400 italic">
                            No POS sales recorded yet for this shop.
                          </td>
                        </tr>
                      ) : (
                        posSales.filter(s => s.dealerId === activeDealer.id).map(sale => (
                          <tr key={sale.id} className="hover:bg-slate-50 transition">
                            <td className="p-4 font-mono">
                              <span className="font-bold text-slate-900 block text-xs">{sale.saleId}</span>
                              <span className="text-[10px] text-slate-400">
                                {new Date(sale.date).toLocaleString()}
                              </span>
                            </td>

                            <td className="p-4">
                              <span className="font-bold text-slate-800 block text-xs">{sale.customerName}</span>
                              <span className="text-[10px] text-slate-500 font-mono">{sale.customerPhone}</span>
                            </td>

                            <td className="p-4 space-y-1">
                              {sale.items.map((item, idx) => (
                                <div key={idx} className="text-[11px] flex items-center justify-between gap-2">
                                  <span className="font-semibold text-slate-800">{item.productName}</span>
                                  <span className="font-mono text-slate-500 shrink-0">
                                    {item.qty} x {currencySymbol}{item.unitPrice} = {currencySymbol}{item.subtotal}
                                  </span>
                                </div>
                              ))}
                            </td>

                            <td className="p-4 text-right font-mono font-extrabold text-emerald-800 text-sm">
                              {currencySymbol} {sale.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                            </td>

                            <td className="p-4 text-center">
                              <span className={`px-2.5 py-1 rounded-full text-[10px] font-black font-mono uppercase ${
                                sale.paymentMethod === "MOBILE_MONEY"
                                  ? sale.carrier ? detectCarrier(sale.customerPhone).badgeBg : "bg-emerald-100 text-emerald-800"
                                  : "bg-slate-200 text-slate-800"
                              }`}>
                                {sale.paymentMethod === "MOBILE_MONEY" 
                                  ? sale.carrier || "Lipila Mobile Money" 
                                  : "Cash"}
                              </span>
                              {sale.lipilaTxId && (
                                <span className="text-[9px] font-mono text-slate-400 block mt-0.5">
                                  Tx: {sale.lipilaTxId}
                                </span>
                              )}
                            </td>

                            <td className="p-4 text-center">
                              <span className="bg-emerald-50 text-emerald-700 text-[10px] font-black px-2.5 py-1 rounded-full border border-emerald-200 uppercase font-mono">
                                ✓ Deducted & Audited
                              </span>
                            </td>

                            <td className="p-4 text-right">
                              <button
                                type="button"
                                onClick={() => {
                                  setPosReceipt({
                                    saleId: sale.saleId,
                                    date: new Date(sale.date).toLocaleString(),
                                    dealerName: sale.dealerName,
                                    dealerPhone: activeDealer.ownerPhone,
                                    dealerAddress: `${activeDealer.city}, ${activeDealer.province}`,
                                    customerName: sale.customerName,
                                    customerPhone: sale.customerPhone,
                                    items: sale.items,
                                    totalAmount: sale.totalAmount,
                                    paymentMethod: sale.paymentMethod,
                                    carrier: sale.carrier,
                                    lipilaTxId: sale.lipilaTxId
                                  });
                                }}
                                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-bold transition flex items-center gap-1"
                              >
                                <Printer className="w-3 h-3 text-slate-500" />
                                <span>Receipt</span>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SUB-TAB 4: REMITTANCES & FARM BALANCE */}
          {dealerSubTab === "REMITTANCE" && (
            <div className="space-y-6">
              {/* Active Agreements & Supplier Payables Card List */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex justify-between items-center border-b pb-3">
                  <div>
                    <h3 className="font-extrabold text-slate-800 text-sm">
                      Supplying Seed & Chemical Companies — Active Agreements
                    </h3>
                    <p className="text-xs text-slate-500">
                      Direct Lipila Farm Balance internal remittance engine. Remitting updates your Consignment Payable live.
                    </p>
                  </div>
                  <span className="text-xs font-mono font-bold bg-emerald-50 text-emerald-800 px-3 py-1 rounded-full border border-emerald-200">
                    {dealerAgreements.length} Active Supplier Links
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {dealerAgreements.map(agr => {
                    const payableInfo = supplierPayables[agr.institutionId] || { totalPayable: 0 };
                    const isOverLimit = payableInfo.totalPayable > agr.creditLimit;

                    return (
                      <div key={agr.id} className="p-5 rounded-2xl border border-slate-200 space-y-3 bg-slate-50/50">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded">
                              {agr.remittancePeriodDays}-Day Remittance Cycle
                            </span>
                            <h4 className="font-bold text-slate-900 text-sm mt-1">{agr.institutionName}</h4>
                          </div>

                          {isOverLimit && (
                            <span className="text-[10px] font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded font-mono">
                              ⚠️ Exceeds ZMW Limit
                            </span>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-white p-3 rounded-xl border border-slate-200">
                          <div>
                            <span className="text-[9px] text-slate-400 block uppercase">Credit Limit</span>
                            <strong className="text-slate-800">
                              {currencySymbol} {agr.creditLimit.toLocaleString()}
                            </strong>
                          </div>
                          <div>
                            <span className="text-[9px] text-slate-400 block uppercase">Outstanding Payable</span>
                            <strong className="text-rose-700 font-extrabold">
                              {currencySymbol} {payableInfo.totalPayable.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                            </strong>
                          </div>
                        </div>

                        <div className="flex justify-between items-center pt-2">
                          <span className="text-[10px] text-slate-500 font-medium">
                            Commission Bearer: <strong className="uppercase">{agr.commissionBearer.replace("_", " ")}</strong>
                          </span>

                          <button
                            type="button"
                            onClick={() => {
                              setRemitAgreement(agr);
                              setRemitAmount(payableInfo.totalPayable);
                              setShowRemitModal(true);
                            }}
                            className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-1.5"
                          >
                            <Coins className="w-3.5 h-3.5" />
                            <span>Remit via Farm Balance</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Remittance History Table */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden space-y-3 p-5">
                <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">
                  Past Supplier Remittances & Reconciliation Log
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-slate-50 text-[10px] uppercase font-extrabold text-slate-500 border-b border-slate-200">
                      <tr>
                        <th className="p-3">Reference / Date</th>
                        <th className="p-3">Supplying Company</th>
                        <th className="p-3 text-right">Amount Remitted</th>
                        <th className="p-3 text-center">Status</th>
                        <th className="p-3">Notes</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                      {reconciliations.filter(r => r.dealerTenantId === activeDealer.id).map(rec => (
                        <tr key={rec.id} className="hover:bg-slate-50">
                          <td className="p-3">
                            <span className="font-mono font-bold text-slate-900 block">{rec.runNumber}</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {new Date(rec.createdAt).toLocaleDateString()}
                            </span>
                          </td>
                          <td className="p-3 font-bold text-slate-800">{rec.institutionName}</td>
                          <td className="p-3 text-right font-mono font-extrabold text-emerald-800">
                            {currencySymbol} {rec.totalRemittancesReceived.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-3 text-center">
                            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded font-mono uppercase">
                              {rec.status}
                            </span>
                          </td>
                          <td className="p-3 text-slate-500 text-[11px]">{rec.notes || "Clean remittance"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SUB-TAB: FINANCIAL RECONCILIATION FOR AGRO-DEALERS */}
          {dealerSubTab === "FINANCIAL_RECONCILIATION" && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-indigo-950 p-6 rounded-3xl text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-black rounded-full uppercase tracking-wider border border-emerald-500/30">
                      Mobile Money Remittance & Settlement Engine
                    </span>
                  </div>
                  <h3 className="text-xl font-black flex items-center gap-2">
                    <ShieldCheck className="w-6 h-6 text-amber-400" />
                    Daily Financial Reconciliation & Settlement
                  </h3>
                  <p className="text-xs text-emerald-100/80 mt-1 max-w-2xl">
                    Verify daily mobile money remittances (MTN MoMo, Airtel Money, Zamtel) against consignment stock movements and automatically trigger real-time settlement status updates across supplier ledgers.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => alert("All pending daily remittances verified! Settlement status automatically updated across platform ledgers.")}
                  className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-2xl text-xs font-black transition shadow-lg shrink-0 cursor-pointer flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Trigger Auto-Settlement Run
                </button>
              </div>

              {/* Summary KPIs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Today's MoMo Remittances</span>
                  <p className="text-xl font-black text-slate-900 mt-1 font-mono">{currencySymbol} 84,500.00</p>
                  <span className="text-[10px] font-bold text-emerald-600 mt-1 inline-block">100% Mobile Money Verified</span>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Consignment Stock Deductions</span>
                  <p className="text-xl font-black text-slate-900 mt-1 font-mono">{currencySymbol} 68,200.00</p>
                  <span className="text-[10px] font-bold text-indigo-600 mt-1 inline-block">Matched to Inventory Ledger</span>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Agro-Dealer Net Commission</span>
                  <p className="text-xl font-black text-emerald-700 mt-1 font-mono">{currencySymbol} 16,300.00</p>
                  <span className="text-[10px] font-bold text-emerald-600 mt-1 inline-block">+19.2% Margin Retained</span>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Settlement Status</span>
                  <p className="text-xl font-black text-emerald-600 mt-1 uppercase flex items-center gap-1">
                    <CheckCircle2 className="w-5 h-5" /> Auto-Settled
                  </p>
                  <span className="text-[10px] font-bold text-slate-500 mt-1 inline-block">Platform Ledger Synchronized</span>
                </div>
              </div>

              {/* DWR COLLATERAL STATUS & LIQUIDATION OVERVIEW */}
              <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 p-5 rounded-2xl text-white shadow-md border border-emerald-500/20 space-y-3 font-sans">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-500/20 pb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold text-lg shrink-0">
                      📜
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-black rounded uppercase font-mono">
                          Digital Warehouse Receipt (DWR) Collateral Status
                        </span>
                        <span className="px-2 py-0.5 bg-amber-400 text-slate-950 text-[9px] font-black rounded uppercase font-mono">
                          ✓ Collateral Active
                        </span>
                      </div>
                      <h4 className="text-sm font-black text-white mt-0.5">
                        Agro-Dealer Pledged Crop Inventory & Bank Collateral Overview
                      </h4>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 uppercase font-mono block">Total Collateral Value</span>
                      <strong className="text-emerald-400 text-base font-mono font-black">{currencySymbol} 2,420,000.00</strong>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                    <span className="text-[9px] text-slate-400 uppercase font-mono block">Pledged Crop Volume</span>
                    <strong className="text-white text-sm font-black font-mono">1,450 Metric Tons (MT)</strong>
                    <div className="text-[10px] text-emerald-400 mt-1 font-semibold">850 MT Maize • 400 MT Soybeans • 200 MT Wheat</div>
                  </div>

                  <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                    <span className="text-[9px] text-slate-400 uppercase font-mono block">Collateral Pledge Coverage</span>
                    <strong className="text-amber-400 text-sm font-black font-mono">128.5% LTV Ratio</strong>
                    <div className="text-[10px] text-slate-300 mt-1 font-semibold">Surplus Margin: +{currencySymbol} 570,000</div>
                  </div>

                  <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                    <span className="text-[9px] text-slate-400 uppercase font-mono block">DWR Verification Node</span>
                    <strong className="text-emerald-400 text-sm font-black font-mono flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Zambia ZAMACE Verified
                    </strong>
                    <div className="text-[10px] text-slate-400 mt-1 font-semibold">Warehouse: Mkushi Certified Silo #02</div>
                  </div>
                </div>
              </div>

              {/* AGRO-CREDIT, COLLATERAL & LIQUIDATION SUMMARY */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-2">
                      <span>📊 Agro-Credit, Collateral & Liquidation Summary</span>
                      <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[9px] font-black rounded uppercase">
                        Agro-Dealer View Only
                      </span>
                    </h4>
                    <p className="text-[10px] text-slate-500 mt-0.5 font-medium">
                      Real-time credit facility disbursements, pledged collateral values, and daily mobile money liquidity liquidation.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Card 1: Total Agro-Input Credit Issued */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Agro-Input Credit Issued</span>
                        <p className="text-lg font-black text-slate-900 font-mono mt-0.5">{currencySymbol} 1,850,000.00</p>
                      </div>
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[9px] font-black rounded-full">
                        +14.2% MoM
                      </span>
                    </div>
                    <div className="h-16 w-full pt-1">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={[
                          { cat: "Seed", val: 850000 },
                          { cat: "Fertilizer", val: 650000 },
                          { cat: "Chem", val: 350000 }
                        ]}>
                          <XAxis dataKey="cat" fontSize={8} tickLine={false} axisLine={false} />
                          <Tooltip formatter={(v: any) => [`${currencySymbol} ${Number(v).toLocaleString()}`, "Issued"]} />
                          <Bar dataKey="val" fill="#10b981" radius={[3, 3, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Card 2: Pledged Crop Collateral Value */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Pledged Crop Collateral Value</span>
                        <p className="text-lg font-black text-amber-700 font-mono mt-0.5">{currencySymbol} 2,420,000.00</p>
                      </div>
                      <span className="px-2 py-0.5 bg-amber-100 text-amber-900 text-[9px] font-black rounded-full">
                        DWR Secured
                      </span>
                    </div>
                    <div className="h-16 w-full pt-1">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={[
                          { crop: "Maize", val: 1250000 },
                          { crop: "Soy", val: 750000 },
                          { crop: "Wheat", val: 420000 }
                        ]}>
                          <XAxis dataKey="crop" fontSize={8} tickLine={false} axisLine={false} />
                          <Tooltip formatter={(v: any) => [`${currencySymbol} ${Number(v).toLocaleString()}`, "Pledged Value"]} />
                          <Bar dataKey="val" fill="#f59e0b" radius={[3, 3, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Card 3: Daily Consignment Liquidity & Liquidation */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Daily Liquidity & Liquidation</span>
                        <p className="text-lg font-black text-indigo-700 font-mono mt-0.5">{currencySymbol} 485,000.00</p>
                      </div>
                      <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 text-[9px] font-black rounded-full">
                        Auto-Settled
                      </span>
                    </div>
                    <div className="h-16 w-full pt-1">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={[
                          { day: "Mon", val: 62000 },
                          { day: "Tue", val: 78000 },
                          { day: "Wed", val: 54000 },
                          { day: "Thu", val: 91000 },
                          { day: "Fri", val: 84500 },
                          { day: "Sat", val: 115500 }
                        ]}>
                          <XAxis dataKey="day" fontSize={8} tickLine={false} axisLine={false} />
                          <Tooltip formatter={(v: any) => [`${currencySymbol} ${Number(v).toLocaleString()}`, "Liquidity"]} />
                          <Bar dataKey="val" fill="#6366f1" radius={[3, 3, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>

              {/* Verification Table */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-sm">Consignment Stock Movements vs Mobile Money Ledger</h4>
                    <p className="text-xs text-slate-500">Real-time cross-referencing of POS POS stock depletion and mobile money callbacks.</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-500">Gateway:</span>
                    <span className="px-2.5 py-1 bg-amber-50 text-amber-800 border border-amber-200 text-xs font-black rounded-lg">MTN / Airtel / Zamtel MoMo</span>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-500 uppercase font-black tracking-wider text-[10px] border-y border-slate-200">
                      <tr>
                        <th className="p-3">Txn Date & Ref</th>
                        <th className="p-3">Agro-Input Catalog SKU</th>
                        <th className="p-3">Supplier Origin</th>
                        <th className="p-3 text-right">MoMo Remitted</th>
                        <th className="p-3 text-right">Consignment Cost</th>
                        <th className="p-3 text-right">Dealer Margin</th>
                        <th className="p-3 text-center">Settlement Status</th>
                        <th className="p-3 text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                      {[
                        { id: "TXN-MM-8921", date: "Today 14:32", sku: "Hybrid Maize SC 719 (25kg)", supplier: "SeedCo Zambia", amount: 18500, cost: 15200, margin: 3300, status: "SETTLED" },
                        { id: "TXN-MM-8922", date: "Today 12:15", sku: "Compound D Fertilizer (50kg)", supplier: "NCZ Nitrogen Chemicals", amount: 32000, cost: 26500, margin: 5500, status: "SETTLED" },
                        { id: "TXN-MM-8923", date: "Today 10:04", sku: "Glyphosate 480SL Herbicide (5L)", supplier: "Yara Zambia Chemicals", amount: 14200, cost: 11400, margin: 2800, status: "SETTLED" },
                        { id: "TXN-MM-8924", date: "Today 08:45", sku: "Urea Top Dressing (50kg)", supplier: "NCZ Nitrogen Chemicals", amount: 19800, cost: 15100, margin: 4700, status: "VERIFIED_PENDING" },
                      ].map((item) => (
                        <tr key={item.id} className="hover:bg-slate-50">
                          <td className="p-3">
                            <span className="font-mono font-bold text-slate-900 block">{item.id}</span>
                            <span className="text-[10px] text-slate-400 font-mono">{item.date}</span>
                          </td>
                          <td className="p-3 font-bold text-slate-800">{item.sku}</td>
                          <td className="p-3 font-medium text-slate-600">{item.supplier}</td>
                          <td className="p-3 text-right font-mono font-extrabold text-slate-900">
                            {currencySymbol} {item.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-3 text-right font-mono text-slate-600">
                            {currencySymbol} {item.cost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-3 text-right font-mono font-extrabold text-emerald-700">
                            +{currencySymbol} {item.margin.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-3 text-center">
                            <span className={`text-[10px] font-black px-2.5 py-1 rounded-full uppercase font-mono ${
                              item.status === "SETTLED" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                            }`}>
                              {item.status === "SETTLED" ? "✓ SETTLED" : "⏳ VERIFIED MATCH"}
                            </span>
                          </td>
                          <td className="p-3 text-center">
                            <button
                              type="button"
                              onClick={() => alert(`Triggered instant settlement for ${item.id}. Supplier ledger auto-updated.`)}
                              className="px-2.5 py-1 bg-slate-900 hover:bg-emerald-700 text-white text-[10px] font-bold rounded-lg transition"
                            >
                              Sync Status
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SUB-TAB 5: AGC INPUT CREDIT POS COUNTER */}
          {dealerSubTab === "AGC_CREDIT_POS" && (
            <div className="space-y-6">
              <DealerCreditPOS
                dealerTenantId={activeDealer.id}
                currencySymbol={currencySymbol}
              />
            </div>
          )}

          {/* PART I: AGRO-DEALER FINANCIAL & CONSIGNMENT REPORTS */}
          {dealerSubTab === "REPORTS" && (
            <AgroDealerReportCentrePanel
              tenantId={activeDealer?.id || "default_tenant"}
              currencySymbol={currencySymbol}
              contextData={{
                agroInventory: dealerSkus,
                stockMovements: [],
                salesRecords: [],
                reconciliationRun: []
              }}
            />
          )}

          {/* PART L: AGRO-DEALER BULK CSV INVENTORY IMPORT */}
          {dealerSubTab === "BULK_IMPORT" && (
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex justify-between items-center border-b pb-4">
                  <div>
                    <span className="text-[10px] bg-amber-100 text-amber-900 font-black px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">
                      Part L — Bulk Import Tool
                    </span>
                    <h3 className="text-lg font-black text-slate-900 mt-1">Bulk SKU Import (CSV / Excel)</h3>
                    <p className="text-xs text-slate-500">Upload or paste CSV stock item records to perform batch catalog updates.</p>
                  </div>
                  <button
                    onClick={() => {
                      const template = "Product Name,Category,Unit Price,Qty On Hand,Reorder Point,Supplier Name\nHybrid Maize Seed 50kg,Seeds & Agronomy,850,100,20,Zambia Seed Co\nSuper Phosphates 50kg,Feeds & Formulations,950,50,10,Yara Fertilizers\nCattle Dip 1L,Veterinary & Health,320,30,5,Livestock Solutions";
                      const blob = new Blob([template], { type: "text/csv" });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement("a");
                      a.href = url;
                      a.download = "mabala_bulk_sku_template.csv";
                      a.click();
                    }}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl cursor-pointer flex items-center gap-1.5"
                  >
                    <FileText className="w-4 h-4 text-emerald-600" />
                    <span>Download Sample CSV Template</span>
                  </button>
                </div>

                <div className="space-y-3">
                  <label className="text-xs font-bold text-slate-700 block">Paste CSV Data or Drag File Content:</label>
                  <textarea
                    id="bulkCsvTextArea"
                    rows={6}
                    placeholder="Product Name,Category,Unit Price,Qty On Hand,Reorder Point,Supplier Name&#10;Zamseed Maize 10kg,Seeds & Agronomy,350,80,15,Zamseed Ltd"
                    className="w-full p-3 border rounded-xl font-mono text-xs bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                  <button
                    onClick={() => {
                      const el = document.getElementById("bulkCsvTextArea") as HTMLTextAreaElement;
                      const val = el?.value || "";
                      if (!val.trim()) {
                        alert("Please paste valid CSV data before parsing.");
                        return;
                      }
                      const parsed = parseBulkSKUCSV(val);
                      if (parsed.length === 0) {
                        alert("Could not parse any SKU rows from the provided CSV data. Check formatting.");
                        return;
                      }

                      const newSkus: AgroDealerSKU[] = parsed.map((row, idx) => ({
                        id: `sku-bulk-${Date.now()}-${idx}`,
                        tenantId: activeDealer.id,
                        productName: row.name,
                        category: (row.category as AgroCategory) || "seed",
                        unit: "50kg bag",
                        unitCost: Math.round(row.unitPrice * 0.8),
                        sellingPrice: row.unitPrice,
                        qtyReceived: row.qtyOnHand,
                        qtySold: 0,
                        qtyOnHand: row.qtyOnHand,
                        qtyReserved: 0,
                        reorderThreshold: row.reorderPoint,
                        supplierName: row.supplierName,
                        lastMovementAt: new Date().toISOString()
                      }));

                      setSkus(prev => [...newSkus, ...prev]);
                      showToast(`Bulk Import Success! Added ${newSkus.length} new SKUs to active inventory.`);
                      el.value = "";
                    }}
                    className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow-md cursor-pointer uppercase"
                  >
                    Batch Add to Active Inventory →
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* DEALER SUB-TAB: DDACC LOAN ORIGINATION & REPAYMENT CLEARING */}
          {dealerSubTab === "DDACC_LOANS" && (
            <div className="space-y-6">
              <DdaccManagementDesk
                role="dealer"
                dealerTenantId={activeDealer.id}
                currencySymbol={currencySymbol}
              />
            </div>
          )}
        </div>
      )}

      {/* WORKSPACE 2: SEED / CHEMICAL COMPANY SUPPLIER PORTAL */}
      {activeWorkspaceMode === "SUPPLIER" && (
        <div className="space-y-6">
          {/* Supplier Sub-Navigation Tabs */}
          <div className="flex items-center justify-between bg-white border border-slate-200 p-2 rounded-2xl shadow-xs">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setSupplierSubTab("NETWORK")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  supplierSubTab === "NETWORK"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Building2 className="w-4 h-4" />
                <span>Dealer Network Rollup</span>
              </button>

              <button
                type="button"
                onClick={() => setSupplierSubTab("SUPPLIER_CATALOG")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  supplierSubTab === "SUPPLIER_CATALOG"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Table className="w-4 h-4 text-amber-300" />
                <span>Supplier Stock Catalog ({supplierCatalog.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setSupplierSubTab("GRANTS")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  supplierSubTab === "GRANTS"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Boxes className="w-4 h-4" />
                <span>Issue Stock Grants</span>
              </button>

              <button
                type="button"
                onClick={() => setSupplierSubTab("CREDIT_LINES")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  supplierSubTab === "CREDIT_LINES"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <CreditCard className="w-4 h-4 text-emerald-300" />
                <span>Supplier Credit Line Management</span>
              </button>

              <button
                type="button"
                onClick={() => setSupplierSubTab("AGREEMENTS")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  supplierSubTab === "AGREEMENTS"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>Consignment Agreements</span>
              </button>

              <button
                type="button"
                onClick={() => setSupplierSubTab("RECONCILIATION")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  supplierSubTab === "RECONCILIATION"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Reconciliation Runs & Statements</span>
              </button>

              <button
                type="button"
                onClick={() => setSupplierSubTab("REPORTS")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  supplierSubTab === "REPORTS"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>Sales Velocity & Aging Reports</span>
              </button>

              <button
                type="button"
                onClick={() => setSupplierSubTab("BULK_ALLOCATION")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  supplierSubTab === "BULK_ALLOCATION"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Boxes className="w-4 h-4 text-amber-500" />
                <span>Bulk Dealer Product Allocation</span>
              </button>

              <button
                type="button"
                onClick={() => setSupplierSubTab("DDACC_LOANS")}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                  supplierSubTab === "DDACC_LOANS"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>DDACC Direct Debit Loans & Statements</span>
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowGrantModal(true)}
              className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Issue New Stock Grant</span>
            </button>
          </div>

          {/* SUPPLIER SUB-TAB 1: DEALER NETWORK ROLLUP */}
          {supplierSubTab === "NETWORK" && (
            <div className="space-y-6">
              {/* Supplier Network KPI Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-extrabold uppercase text-slate-400 font-mono">Total Stock Granted</span>
                  <strong className="text-2xl font-mono font-bold text-slate-900 block mt-1">
                    {currencySymbol} {networkTotals.granted.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </strong>
                  <span className="text-[10px] text-slate-500 font-medium">Across all network dealers</span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-extrabold uppercase text-slate-400 font-mono">Unsold Stock Remaining</span>
                  <strong className="text-2xl font-mono font-bold text-slate-900 block mt-1">
                    {currencySymbol} {networkTotals.remaining.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </strong>
                  <span className="text-[10px] text-slate-500 font-medium">Sitting in dealer shops</span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-extrabold uppercase text-slate-400 font-mono">Dealer Sales Value</span>
                  <strong className="text-2xl font-mono font-bold text-emerald-800 block mt-1">
                    {currencySymbol} {networkTotals.sales.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </strong>
                  <span className="text-[10px] text-emerald-600 font-semibold">Total verified sales</span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-rose-200 bg-rose-50/20 shadow-xs">
                  <span className="text-[10px] font-extrabold uppercase text-rose-700 font-mono">Outstanding Consignment Owed</span>
                  <strong className="text-2xl font-mono font-bold text-rose-900 block mt-1">
                    {currencySymbol} {networkTotals.payable.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </strong>
                  <span className="text-[10px] text-rose-700 font-semibold">Pending dealer remittance</span>
                </div>
              </div>

              {/* Province Filter */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex justify-between items-center">
                <h3 className="font-extrabold text-slate-800 text-sm">Dealer Network Performance & Subscription Gate</h3>
                <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
                  <span>Filter Province:</span>
                  <select
                    value={provinceFilter}
                    onChange={e => setProvinceFilter(e.target.value)}
                    className="bg-slate-100 text-slate-800 text-xs font-bold px-3 py-1.5 rounded-lg border border-slate-200 focus:outline-none"
                  >
                    <option value="ALL">All Zambian Provinces</option>
                    <option value="Southern Province">Southern Province</option>
                    <option value="Central Province">Central Province</option>
                    <option value="Eastern Province">Eastern Province</option>
                  </select>
                </div>
              </div>

              {/* Dealer Ledgers Table */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-slate-50 text-[10px] uppercase font-extrabold text-slate-500 border-b border-slate-200">
                      <tr>
                        <th className="p-4">Agro-Dealer Name & Location</th>
                        <th className="p-4 text-right">Granted Value</th>
                        <th className="p-4 text-right">Remaining Value</th>
                        <th className="p-4 text-right">Sales Value</th>
                        <th className="p-4 text-right">Consignment Owed</th>
                        <th className="p-4 text-center">Subscription Status</th>
                        <th className="p-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                      {dealerLedgers.map(dl => {
                        const isExpiredGated = dl.subscriptionStatus === "expired" && !dl.isSponsored;

                        return (
                          <tr key={dl.dealerTenantId} className={`hover:bg-slate-50 ${isExpiredGated ? "bg-slate-100/60 opacity-60" : ""}`}>
                            <td className="p-4">
                              <strong className="text-slate-900 block text-xs font-bold">{dl.dealerName}</strong>
                              <span className="text-[10px] text-slate-400 block font-mono">
                                📍 {dl.city}, {dl.province} • {dl.dealerPhone}
                              </span>
                            </td>

                            <td className="p-4 text-right font-mono font-bold text-slate-800">
                              {isExpiredGated ? "PAUSED" : `${currencySymbol} ${dl.totalStockGrantedValue.toLocaleString()}`}
                            </td>

                            <td className="p-4 text-right font-mono font-bold text-slate-800">
                              {isExpiredGated ? "PAUSED" : `${currencySymbol} ${dl.totalStockRemainingValue.toLocaleString()}`}
                            </td>

                            <td className="p-4 text-right font-mono font-bold text-emerald-800">
                              {isExpiredGated ? "PAUSED" : `${currencySymbol} ${dl.totalSalesValue.toLocaleString()}`}
                            </td>

                            <td className="p-4 text-right font-mono font-extrabold text-rose-700">
                              {isExpiredGated ? "PAUSED" : `${currencySymbol} ${dl.outstandingConsignmentPayable.toLocaleString()}`}
                            </td>

                            <td className="p-4 text-center">
                              {dl.subscriptionStatus === "active" ? (
                                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-1 rounded-full uppercase">
                                  {dl.isSponsored ? "SPONSORED BY YOU" : "ACTIVE"}
                                </span>
                              ) : (
                                <span className="bg-amber-100 text-amber-800 text-[10px] font-black px-2.5 py-1 rounded-full uppercase">
                                  GRACE PERIOD
                                </span>
                              )}
                            </td>

                            <td className="p-4 text-right space-x-2">
                              <button
                                type="button"
                                onClick={() => handleToggleSponsorship(dl.dealerTenantId)}
                                className={`px-2.5 py-1 text-[10px] font-bold rounded-lg transition border ${
                                  dl.isSponsored 
                                    ? "bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100"
                                    : "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100"
                                }`}
                              >
                                {dl.isSponsored ? "Stop Sponsorship" : "Sponsor Subscription"}
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SUPPLIER SUB-TAB: SUPPLIER STOCK CATALOG */}
          {supplierSubTab === "SUPPLIER_CATALOG" && (
            <div className="space-y-6">
              {/* Top Banner and KPI Summary */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b pb-4">
                  <div>
                    <span className="text-[10px] bg-amber-100 text-amber-900 font-black px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">
                      Master Inventory Stock Catalog
                    </span>
                    <h3 className="text-base font-extrabold text-slate-900 mt-1">Supplier Stock Catalog Registry</h3>
                    <p className="text-xs text-slate-500">Record single products or upload bulk inventory from CSV or Excel to power consignment grants across registered agro-dealers.</p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddSupplierCatalogModal(true)}
                      className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-xs transition cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Single Product</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setShowBulkSupplierCatalogModal(true)}
                      className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-xs transition cursor-pointer"
                    >
                      <UploadCloud className="w-4 h-4" />
                      <span>Bulk Upload (CSV / Excel)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => downloadSampleTemplate("SUPPLIER_CATALOG")}
                      className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer"
                    >
                      <Download className="w-4 h-4 text-slate-500" />
                      <span>Download Sample Template</span>
                    </button>
                  </div>
                </div>

                {/* KPI Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono">
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1">
                    <span className="text-[10px] uppercase font-extrabold text-slate-400">Total Catalog Items</span>
                    <strong className="text-xl font-black text-slate-900 block">{supplierCatalog.length} Products</strong>
                    <span className="text-[10px] text-slate-500">Ready for consignment grant allocations</span>
                  </div>

                  <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-200 space-y-1">
                    <span className="text-[10px] uppercase font-extrabold text-emerald-700">Total Units in Stock</span>
                    <strong className="text-xl font-black text-emerald-900 block">
                      {supplierCatalog.reduce((sum, i) => sum + i.qtyInStock, 0).toLocaleString()} Units
                    </strong>
                    <span className="text-[10px] text-emerald-600">Available across all warehouses</span>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-xl border border-blue-200 space-y-1">
                    <span className="text-[10px] uppercase font-extrabold text-blue-700">Total Wholesale Stock Value</span>
                    <strong className="text-xl font-black text-blue-900 block">
                      {currencySymbol} {supplierCatalog.reduce((sum, i) => sum + (i.qtyInStock * i.unitWholesaleCost), 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </strong>
                    <span className="text-[10px] text-blue-600 font-sans">Valued at wholesale cost prices</span>
                  </div>
                </div>

                {/* Search Bar */}
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    placeholder="Search stock catalog by product name, category, batch or barcode..."
                    className="w-full pl-10 pr-4 py-2.5 border rounded-xl text-xs font-semibold bg-slate-50 focus:bg-white focus:outline-emerald-600"
                  />
                </div>

                {/* Catalog Table */}
                <div className="overflow-x-auto border rounded-xl border-slate-200">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-slate-100 text-slate-600 font-extrabold uppercase text-[10px] font-mono border-b">
                      <tr>
                        <th className="p-3">Product Item Name</th>
                        <th className="p-3">Category</th>
                        <th className="p-3">Packaging Unit</th>
                        <th className="p-3 text-right">Wholesale Cost</th>
                        <th className="p-3 text-right">Recommended Retail</th>
                        <th className="p-3 text-right">Qty in Stock</th>
                        <th className="p-3">Batch & Expiry</th>
                        <th className="p-3 text-center">Quick Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 bg-white">
                      {supplierCatalog
                        .filter(item => 
                          !searchTerm ||
                          item.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (item.batchNumber && item.batchNumber.toLowerCase().includes(searchTerm.toLowerCase()))
                        )
                        .map(item => (
                          <tr key={item.id} className="hover:bg-slate-50 transition">
                            <td className="p-3 font-extrabold text-slate-900">
                              {item.productName}
                              {item.description && (
                                <span className="text-[10px] text-slate-400 block font-normal">{item.description}</span>
                              )}
                            </td>
                            <td className="p-3">
                              <span className="bg-slate-100 text-slate-700 font-bold px-2 py-0.5 rounded text-[10px] uppercase font-mono">
                                {item.category}
                              </span>
                            </td>
                            <td className="p-3 font-medium text-slate-600">{item.unit}</td>
                            <td className="p-3 text-right font-mono font-bold text-slate-800">
                              {currencySymbol} {item.unitWholesaleCost.toLocaleString()}
                            </td>
                            <td className="p-3 text-right font-mono font-bold text-emerald-700">
                              {currencySymbol} {item.recommendedSellingPrice.toLocaleString()}
                            </td>
                            <td className="p-3 text-right font-mono font-extrabold text-slate-900">
                              {item.qtyInStock.toLocaleString()}
                            </td>
                            <td className="p-3 font-mono text-[11px] text-slate-500">
                              <span>{item.batchNumber || "—"}</span>
                              {item.expiryDate && (
                                <span className="text-[9px] text-slate-400 block">Exp: {item.expiryDate}</span>
                              )}
                            </td>
                            <td className="p-3 text-center">
                              <button
                                type="button"
                                onClick={() => {
                                  setGrantItemName(item.productName);
                                  setGrantCategory(item.category);
                                  setGrantUnit(item.unit);
                                  setGrantUnitCost(item.unitWholesaleCost);
                                  setGrantSellingPrice(item.recommendedSellingPrice);
                                  if (item.batchNumber) setGrantBatch(item.batchNumber);
                                  if (item.expiryDate) setGrantExpiry(item.expiryDate);
                                  setShowGrantModal(true);
                                }}
                                className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-extrabold inline-flex items-center gap-1 shadow-xs transition cursor-pointer"
                              >
                                <Boxes className="w-3 h-3" />
                                <span>Issue Grant</span>
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SUPPLIER SUB-TAB 2: STOCK GRANTS */}
          {supplierSubTab === "GRANTS" && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex justify-between items-center">
                <div>
                  <h3 className="font-extrabold text-slate-800 text-sm">Issued Stock Grants Registry</h3>
                  <p className="text-xs text-slate-500">Atomic stock distribution entries issued to linked agro-dealers.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowGrantModal(true)}
                  className="px-4 py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold hover:bg-emerald-800 transition"
                >
                  + Issue Grant
                </button>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-slate-50 text-[10px] uppercase font-extrabold text-slate-500 border-b border-slate-200">
                      <tr>
                        <th className="p-4">Grant # / Date</th>
                        <th className="p-4">Recipient Dealer</th>
                        <th className="p-4">Granted Product Items</th>
                        <th className="p-4 text-right">Total Grant Value</th>
                        <th className="p-4 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                      {grants.map(grant => (
                        <tr key={grant.id} className="hover:bg-slate-50">
                          <td className="p-4">
                            <span className="font-mono font-bold text-slate-900 block">{grant.grantNumber}</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {new Date(grant.grantDate).toLocaleDateString()}
                            </span>
                          </td>
                          <td className="p-4 font-bold text-slate-800">{grant.dealerName}</td>
                          <td className="p-4">
                            {grant.items.map((it, idx) => (
                              <div key={idx} className="text-xs">
                                <span className="font-bold text-slate-800">{it.productName}</span> — {it.qty} {it.unit}
                              </div>
                            ))}
                          </td>
                          <td className="p-4 text-right font-mono font-black text-slate-900">
                            {currencySymbol} {grant.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-4 text-center">
                            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-1 rounded-full uppercase">
                              {grant.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SUPPLIER SUB-TAB: CREDIT LINE MANAGEMENT */}
          {supplierSubTab === "CREDIT_LINES" && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-emerald-950 p-6 rounded-3xl text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2.5 py-0.5 bg-indigo-500/20 text-indigo-300 text-[10px] font-black rounded-full uppercase tracking-wider border border-indigo-500/30">
                      Supplier In-Kind Facility & Risk Engine
                    </span>
                  </div>
                  <h3 className="text-xl font-black flex items-center gap-2">
                    <CreditCard className="w-6 h-6 text-emerald-400" />
                    Supplier Credit Line Management
                  </h3>
                  <p className="text-xs text-indigo-100/80 mt-1 max-w-2xl">
                    Track in-kind stock disbursements (seed, fertilizer, chemicals) to agro-dealer networks, monitor real-time credit limit utilization, and view daily reconciliation reports for debt mitigation.
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => alert("Daily Credit Line Reconciliation Report generated! Saved to downloads.")}
                    className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-extrabold transition shadow-md flex items-center gap-1.5 cursor-pointer"
                  >
                    <FileSpreadsheet className="w-4 h-4" />
                    Download Daily Debt Report
                  </button>
                </div>
              </div>

              {/* Input Category Breakdown Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-sm">🌱</span>
                      <div>
                        <h4 className="font-extrabold text-slate-900 text-xs uppercase">Seed Stock Facilities</h4>
                        <span className="text-[10px] text-slate-400 font-mono">Hybrid Maize & Soybeans</span>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-black rounded-full font-mono">
                      74% Utilized
                    </span>
                  </div>
                  <div className="space-y-1 font-mono">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Disbursed Stock Value:</span>
                      <strong className="text-slate-900">{currencySymbol} 850,000.00</strong>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Facility Credit Limit:</span>
                      <strong className="text-slate-700">{currencySymbol} 1,150,000.00</strong>
                    </div>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-600 h-full rounded-full" style={{ width: "74%" }} />
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold text-sm">🧪</span>
                      <div>
                        <h4 className="font-extrabold text-slate-900 text-xs uppercase">Chemical & Crop Protection</h4>
                        <span className="text-[10px] text-slate-400 font-mono">Herbicides & Insecticides</span>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 bg-amber-100 text-amber-800 text-[10px] font-black rounded-full font-mono">
                      58% Utilized
                    </span>
                  </div>
                  <div className="space-y-1 font-mono">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Disbursed Stock Value:</span>
                      <strong className="text-slate-900">{currencySymbol} 420,000.00</strong>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Facility Credit Limit:</span>
                      <strong className="text-slate-700">{currencySymbol} 725,000.00</strong>
                    </div>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-amber-500 h-full rounded-full" style={{ width: "58%" }} />
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold text-sm">⚡</span>
                      <div>
                        <h4 className="font-extrabold text-slate-900 text-xs uppercase">Fertilizer Basal & Top Dressing</h4>
                        <span className="text-[10px] text-slate-400 font-mono">Compound D & Urea 50kg</span>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 text-[10px] font-black rounded-full font-mono">
                      82% Utilized
                    </span>
                  </div>
                  <div className="space-y-1 font-mono">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Disbursed Stock Value:</span>
                      <strong className="text-slate-900">{currencySymbol} 1,280,000.00</strong>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Facility Credit Limit:</span>
                      <strong className="text-slate-700">{currencySymbol} 1,560,000.00</strong>
                    </div>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-indigo-600 h-full rounded-full" style={{ width: "82%" }} />
                  </div>
                </div>
              </div>

              {/* Agro-Dealer Network Credit Utilization Monitor */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-sm">Agro-Dealer Credit Limit Utilization & Debt Mitigation Audit</h4>
                    <p className="text-xs text-slate-500">Active credit line balances, daily sales repayments, and risk categorization.</p>
                  </div>
                  <span className="px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold rounded-lg font-mono">
                    Net Debt Mitigation Index: 94.2% Clean
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-500 uppercase font-black tracking-wider text-[10px] border-y border-slate-200">
                      <tr>
                        <th className="p-3">Agro-Dealer Partner</th>
                        <th className="p-3">Province / District</th>
                        <th className="p-3">Primary Inputs Granted</th>
                        <th className="p-3 text-right">Disbursed Balance</th>
                        <th className="p-3 text-right">Approved Credit Limit</th>
                        <th className="p-3 text-center">Utilization Bar</th>
                        <th className="p-3 text-center">Risk Profile</th>
                        <th className="p-3 text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                      {[
                        { name: "Sunrise Agro-Supplies Mkushi", location: "Central Province", inputCategory: "Seed & Fertilizer", disbursed: 320000, limit: 400000, risk: "OPTIMAL" },
                        { name: "Choma Farmers Corner", location: "Southern Province", inputCategory: "Chemicals & Seed", disbursed: 185000, limit: 250000, risk: "OPTIMAL" },
                        { name: "Mpongwe Central Agro-Hub", location: "Copperbelt Province", inputCategory: "Fertilizer Compound D", disbursed: 240000, limit: 250000, risk: "WATCHLIST" },
                        { name: "Katete Rural Seed Depot", location: "Eastern Province", inputCategory: "Hybrid Seed Maize", disbursed: 145000, limit: 200000, risk: "OPTIMAL" },
                      ].map((dlr, idx) => {
                        const pct = Math.round((dlr.disbursed / dlr.limit) * 100);
                        return (
                          <tr key={idx} className="hover:bg-slate-50">
                            <td className="p-3 font-extrabold text-slate-900">{dlr.name}</td>
                            <td className="p-3 text-slate-500">{dlr.location}</td>
                            <td className="p-3 font-mono font-semibold text-slate-700">{dlr.inputCategory}</td>
                            <td className="p-3 text-right font-mono font-extrabold text-slate-900">
                              {currencySymbol} {dlr.disbursed.toLocaleString()}
                            </td>
                            <td className="p-3 text-right font-mono text-slate-600">
                              {currencySymbol} {dlr.limit.toLocaleString()}
                            </td>
                            <td className="p-3 text-center w-36">
                              <div className="flex items-center gap-2">
                                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                                  <div
                                    className={`h-full rounded-full ${pct > 85 ? "bg-amber-500" : "bg-emerald-600"}`}
                                    style={{ width: `${pct}%` }}
                                  />
                                </div>
                                <span className="text-[10px] font-mono font-bold text-slate-600">{pct}%</span>
                              </div>
                            </td>
                            <td className="p-3 text-center">
                              <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase font-mono ${
                                dlr.risk === "OPTIMAL" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                              }`}>
                                {dlr.risk}
                              </span>
                            </td>
                            <td className="p-3 text-center">
                              <button
                                type="button"
                                onClick={() => alert(`Adjusted credit limit for ${dlr.name}`)}
                                className="px-2.5 py-1 bg-slate-900 hover:bg-emerald-700 text-white text-[10px] font-bold rounded-lg transition"
                              >
                                Modify Limit
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SUPPLIER SUB-TAB 3: CONSIGNMENT AGREEMENTS */}
          {supplierSubTab === "AGREEMENTS" && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex justify-between items-center">
                <div>
                  <h3 className="font-extrabold text-slate-800 text-sm">Consignment Credit Agreements</h3>
                  <p className="text-xs text-slate-500">Legal remittance terms, commission bearer rules, and credit limits.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAgreementModal(true)}
                  className="px-4 py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold hover:bg-emerald-800 transition"
                >
                  + New Agreement
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {agreements.map(agr => (
                  <div key={agr.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] font-black uppercase text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-mono">
                          {agr.remittancePeriodDays}-Day Remittance Cycle
                        </span>
                        <h4 className="font-bold text-slate-900 text-sm mt-1">{agr.dealerName}</h4>
                      </div>
                      <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded font-mono uppercase">
                        {agr.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-50 p-3 rounded-xl">
                      <div>
                        <span className="text-[9px] text-slate-400 block uppercase">Credit Limit (ZMW)</span>
                        <strong className="text-slate-800">{currencySymbol} {agr.creditLimit.toLocaleString()}</strong>
                      </div>
                      <div>
                        <span className="text-[9px] text-slate-400 block uppercase">Commission Bearer</span>
                        <strong className="text-emerald-800 uppercase">{agr.commissionBearer.replace("_", " ")}</strong>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SUPPLIER SUB-TAB 4: RECONCILIATION RUNS */}
          {supplierSubTab === "RECONCILIATION" && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex justify-between items-center">
                <div>
                  <h3 className="font-extrabold text-slate-800 text-sm">Consignment Reconciliation Runs</h3>
                  <p className="text-xs text-slate-500">Generated statements matching movement sales vs Farm Balance remittances.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowReconcileModal(true)}
                  className="px-4 py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold hover:bg-emerald-800 transition"
                >
                  + Run Reconciliation Statement
                </button>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-slate-50 text-[10px] uppercase font-extrabold text-slate-500 border-b border-slate-200">
                      <tr>
                        <th className="p-4">Run # / Date</th>
                        <th className="p-4">Dealer Name</th>
                        <th className="p-4 text-right">Computed Sales Value</th>
                        <th className="p-4 text-right">Total Remitted</th>
                        <th className="p-4 text-right">Variance Balance</th>
                        <th className="p-4 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                      {reconciliations.map(rec => (
                        <tr key={rec.id} className="hover:bg-slate-50">
                          <td className="p-4">
                            <span className="font-mono font-bold text-slate-900 block">{rec.runNumber}</span>
                            <span className="text-[10px] text-slate-400 font-mono">{new Date(rec.createdAt).toLocaleDateString()}</span>
                          </td>
                          <td className="p-4 font-bold text-slate-800">{rec.dealerName}</td>
                          <td className="p-4 text-right font-mono font-bold text-slate-800">
                            {currencySymbol} {rec.computedSalesValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-4 text-right font-mono font-bold text-emerald-800">
                            {currencySymbol} {rec.totalRemittancesReceived.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-4 text-right font-mono font-extrabold text-amber-700">
                            {currencySymbol} {rec.variance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-4 text-center">
                            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-1 rounded-full uppercase">
                              {rec.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* PART J: SUPPLIER SALES VELOCITY, AGING & FULL REPORT CENTRE */}
          {supplierSubTab === "REPORTS" && (
            <div className="space-y-6">
              {/* View Selector Tabs */}
              <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
                <button
                  type="button"
                  onClick={() => setSupplierReportViewMode("velocity")}
                  className={`px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-2 ${
                    supplierReportViewMode === "velocity"
                      ? "bg-slate-900 text-white shadow-sm"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  <BarChart2 className="w-3.5 h-3.5" />
                  <span>Consignment Velocity & Aging</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSupplierReportViewMode("full_centre")}
                  className={`px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-2 ${
                    supplierReportViewMode === "full_centre"
                      ? "bg-emerald-600 text-white shadow-sm"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Supplier Intelligence & Report Centre (Pay-Per-Report)</span>
                </button>
              </div>

              {supplierReportViewMode === "full_centre" ? (
                <InstitutionalReportCentre
                  dashboardData={{
                    metrics: {
                      activeFarmers: 1840,
                      totalInputDisbursedZMW: 12450000,
                      totalRepaidZMW: 10890000,
                      currentPAR30Pct: 4.2
                    }
                  }}
                  isSupplier={true}
                  tenantId={activeSupplierId}
                  tenantName={activeSupplierObj?.name || "Supplier Organization"}
                  currencySymbol={currencySymbol}
                />
              ) : (
                <>
                  {/* Sales Velocity & Stock Burn Rate Table */}
                  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                    <div className="flex justify-between items-center border-b pb-4">
                      <div>
                        <span className="text-[10px] bg-emerald-100 text-emerald-800 font-black px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">
                          Part J — Supplier Analytics
                        </span>
                        <h3 className="text-lg font-black text-slate-900 mt-1">Consignment Sales Velocity & Stock Burn Rate</h3>
                        <p className="text-xs text-slate-500">Live inventory turnover rates, 7-day sales velocity, and projected stockout dates per dealer.</p>
                      </div>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 uppercase text-[10px] font-black text-slate-500 border-y border-slate-200">
                          <tr>
                            <th className="p-3">Consigned SKU</th>
                            <th className="p-3">Agro-Dealer Name</th>
                            <th className="p-3 text-right">Consigned Stock</th>
                            <th className="p-3 text-right">7-Day Sales</th>
                            <th className="p-3 text-right">Daily Velocity</th>
                            <th className="p-3 text-right">Projected Stockout</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-150 font-medium">
                          {generateSupplierSalesVelocity(skus, dealers).map(row => (
                            <tr key={row.skuId + row.agroDealerName} className="hover:bg-slate-50/80">
                              <td className="p-3 font-bold text-slate-900">{row.skuName}</td>
                              <td className="p-3 text-slate-600">{row.agroDealerName}</td>
                              <td className="p-3 text-right font-mono font-bold text-slate-800">{row.consignedStock}</td>
                              <td className="p-3 text-right font-mono text-emerald-700 font-bold">{row.unitsSold7Days}</td>
                              <td className="p-3 text-right font-mono text-slate-600">{row.dailyVelocity.toFixed(1)} / day</td>
                              <td className="p-3 text-right font-mono font-bold">
                                <span className={`px-2 py-0.5 rounded text-[10px] ${row.projectedStockoutDays <= 7 ? "bg-rose-100 text-rose-800" : "bg-emerald-100 text-emerald-800"}`}>
                                  {row.projectedStockoutDays === 999 ? "Stable Stock" : `${row.projectedStockoutDays} days remaining`}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Dealer Receivables Aging Schedule */}
                  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                    <div className="flex justify-between items-center border-b pb-4">
                      <div>
                        <span className="text-[10px] bg-amber-100 text-amber-800 font-black px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">
                          Part J — Credit Management
                        </span>
                        <h3 className="text-lg font-black text-slate-900 mt-1">Dealer Payout & Receivables Aging Schedule</h3>
                        <p className="text-xs text-slate-500">Aging schedule of outstanding consignment receivables categorized by 0-30, 31-60, and 60+ days overdue.</p>
                      </div>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 uppercase text-[10px] font-black text-slate-500 border-y border-slate-200">
                          <tr>
                            <th className="p-3">Agro-Dealer Name</th>
                            <th className="p-3 text-right">Total Owed</th>
                            <th className="p-3 text-right">0-30 Days</th>
                            <th className="p-3 text-right">31-60 Days</th>
                            <th className="p-3 text-right">60+ Days Overdue</th>
                            <th className="p-3 text-center">Account Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-150 font-medium">
                          {generateDealerReceivablesAging(dealers).map(row => (
                            <tr key={row.dealerId} className="hover:bg-slate-50/80">
                              <td className="p-3 font-bold text-slate-900">{row.dealerName}</td>
                              <td className="p-3 text-right font-mono font-bold text-slate-900">{currencySymbol} {row.totalOwed.toLocaleString()}</td>
                              <td className="p-3 text-right font-mono text-emerald-700">{currencySymbol} {row.current0to30.toLocaleString()}</td>
                              <td className="p-3 text-right font-mono text-amber-600 font-semibold">{currencySymbol} {row.days31to60.toLocaleString()}</td>
                              <td className="p-3 text-right font-mono text-rose-600 font-bold">{currencySymbol} {row.days60Plus.toLocaleString()}</td>
                              <td className="p-3 text-center">
                                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                                  row.status === "Current" ? "bg-emerald-100 text-emerald-800" :
                                  row.status === "Overdue" ? "bg-amber-100 text-amber-800" : "bg-rose-100 text-rose-800"
                                }`}>
                                  {row.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* PART L: BULK DEALER PRODUCT ALLOCATION TOOL */}
          {supplierSubTab === "BULK_ALLOCATION" && (
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b pb-4 gap-4">
                  <div>
                    <span className="text-[10px] bg-amber-100 text-amber-900 font-black px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">
                      Part L — Bulk Allocation Engine
                    </span>
                    <h3 className="text-lg font-black text-slate-900 mt-1">Bulk Dealer Product Allocation</h3>
                    <p className="text-xs text-slate-500">Allocate consignment stock quantities across multiple network dealers simultaneously in a single transaction or via Excel / CSV batch files.</p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowBulkGrantModal(true)}
                    className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-md transition cursor-pointer shrink-0"
                  >
                    <UploadCloud className="w-4 h-4" />
                    <span>Upload Bulk Grants (CSV / Excel)</span>
                  </button>
                </div>

                <div className="space-y-4 max-w-xl">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Select Consignment Product SKU to Allocate:</label>
                    <select id="bulkAllocationSkuSelect" className="w-full p-2.5 border rounded-xl text-xs font-semibold">
                      {skus.map(s => (
                        <option key={s.id} value={s.id}>{s.productName} ({s.category}) — {currencySymbol} {s.sellingPrice}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-2">Network Agro-Dealers & Allocation Quantities:</label>
                    <div className="space-y-2 border rounded-xl p-3 bg-slate-50 max-h-60 overflow-y-auto">
                      {dealers.map(d => (
                        <div key={d.id} className="flex items-center justify-between gap-4 p-2 bg-white rounded-lg border border-slate-200">
                          <span className="text-xs font-bold text-slate-800">{d.businessName} ({d.province})</span>
                          <input
                            type="number"
                            min="0"
                            defaultValue="50"
                            data-dealer-id={d.id}
                            className="bulkDealerQtyInput w-24 p-1.5 border rounded-lg text-xs font-mono font-bold text-right"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      const selectEl = document.getElementById("bulkAllocationSkuSelect") as HTMLSelectElement;
                      const skuId = selectEl?.value;
                      const selectedSku = skus.find(s => s.id === skuId);
                      if (!selectedSku) return;

                      const inputs = document.querySelectorAll(".bulkDealerQtyInput") as NodeListOf<HTMLInputElement>;
                      let allocatedCount = 0;

                      inputs.forEach(input => {
                        const qty = Number(input.value);
                        const dealerId = input.getAttribute("data-dealer-id");
                        if (qty > 0 && dealerId) {
                          allocatedCount++;
                          const newGrant: StockGrant = {
                            id: `grant-bulk-${Date.now()}-${dealerId}`,
                            grantNumber: `GRT-BULK-${Math.floor(1000 + Math.random() * 9000)}`,
                            dealerTenantId: dealerId,
                            dealerName: dealers.find(d => d.id === dealerId)?.businessName || "Dealer",
                            institutionId: activeSupplierId || "inst-syngenta",
                            institutionName: suppliers.find(s => s.id === activeSupplierId)?.name || "Syngenta Zambia Ltd",
                            grantDate: new Date().toISOString(),
                            items: [{
                              skuId: selectedSku.id,
                              productName: selectedSku.productName,
                              category: selectedSku.category,
                              unit: selectedSku.unit,
                              qty: qty,
                              unitCost: selectedSku.unitCost,
                              sellingPrice: selectedSku.sellingPrice
                            }],
                            totalValue: qty * selectedSku.sellingPrice,
                            status: "issued",
                            createdAt: new Date().toISOString()
                          };
                          setGrants(prev => [newGrant, ...prev]);
                        }
                      });

                      showToast(`Bulk Allocation Dispatched! Issued stock grants to ${allocatedCount} dealers for ${selectedSku.productName}.`);
                    }}
                    className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow-md cursor-pointer uppercase tracking-wider"
                  >
                    Execute Batch Consignment Allocation →
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* SUPPLIER SUB-TAB: DDACC DIRECT DEBIT LOANS & MONTH-END FEE STATEMENTS */}
          {supplierSubTab === "DDACC_LOANS" && (
            <div className="space-y-6">
              <DdaccManagementDesk
                role="supplier"
                dealerTenantId={activeSupplierId}
                currencySymbol={currencySymbol}
              />
            </div>
          )}
        </div>
      )}

      {/* WORKSPACE 3: SUPER ADMIN PROVISIONING WORKSPACE */}
      {activeWorkspaceMode === "SUPER_ADMIN" && (
        <div className="bg-white p-6 rounded-2xl border border-amber-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b pb-4 gap-4">
            <div>
              <h3 className="font-extrabold text-amber-900 text-base flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-amber-600" />
                <span>Super Admin Agro-Dealer & Supplier Provisioning Portal</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Provision new Agro-Dealer retail tenants, enable Supplier capabilities on existing Institutions, and setup consignment credit relationships.
              </p>
            </div>
            
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowCreateDealerModal(true)}
                className="px-3 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-1.5"
              >
                <Store className="w-3.5 h-3.5" />
                <span>+ Create Agro-Dealer (3.1)</span>
              </button>

              <button
                type="button"
                onClick={() => setShowCreateSupplierModal(true)}
                className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-1.5"
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>+ Create / Upgrade Supplier (3.2)</span>
              </button>

              <button
                type="button"
                onClick={() => setShowAgreementModal(true)}
                className="px-3 py-2 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-1.5"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>+ Link Agreement (3.3)</span>
              </button>
            </div>
          </div>

          {/* Super Admin Navigation Sub-Tabs */}
          <div className="flex border-b border-slate-200 gap-6 text-xs font-bold">
            <button
              type="button"
              onClick={() => setSuperAdminSubTab("DEALERS")}
              className={`pb-2.5 flex items-center gap-2 border-b-2 transition ${
                superAdminSubTab === "DEALERS"
                  ? "border-amber-600 text-amber-900"
                  : "border-transparent text-slate-400 hover:text-slate-600"
              }`}
            >
              <Store className="w-4 h-4" />
              <span>Agro-Dealer Retail Tenants ({dealers.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setSuperAdminSubTab("SUPPLIERS")}
              className={`pb-2.5 flex items-center gap-2 border-b-2 transition ${
                superAdminSubTab === "SUPPLIERS"
                  ? "border-emerald-600 text-emerald-900"
                  : "border-transparent text-slate-400 hover:text-slate-600"
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>Seed & Chemical Companies ({suppliers.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setSuperAdminSubTab("AGREEMENTS")}
              className={`pb-2.5 flex items-center gap-2 border-b-2 transition ${
                superAdminSubTab === "AGREEMENTS"
                  ? "border-blue-600 text-blue-900"
                  : "border-transparent text-slate-400 hover:text-slate-600"
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Consignment Agreements ({agreements.length})</span>
            </button>
          </div>

          {/* SUB-TAB 1: AGRO-DEALERS */}
          {superAdminSubTab === "DEALERS" && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {dealers.map(d => {
                  const isSuspended = (d as any).status === "suspended" || d.subscriptionStatus === "expired";
                  return (
                    <div key={d.id} className="p-4 rounded-2xl border border-slate-200 space-y-3 bg-slate-50 shadow-xs relative overflow-hidden flex flex-col justify-between">
                      <div className="space-y-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[10px] font-black uppercase text-amber-700 font-mono block">
                              Tenant: {d.id}
                            </span>
                            <h4 className="font-extrabold text-slate-900 text-sm mt-0.5">{d.tradingName || d.businessName}</h4>
                            {d.tradingName && d.businessName !== d.tradingName && (
                              <span className="text-[10px] text-slate-500 block font-medium">Legal: {d.businessName}</span>
                            )}
                          </div>
                          <div className="flex flex-col items-end gap-1">
                            <span className={`text-[9px] font-black px-2 py-0.5 rounded flex items-center gap-1 font-mono uppercase ${
                              isSuspended ? "bg-rose-100 text-rose-800" : "bg-emerald-100 text-emerald-800"
                            }`}>
                              <BadgeCheck className={`w-3 h-3 ${isSuspended ? "text-rose-600" : "text-emerald-600"}`} />
                              {isSuspended ? "SUSPENDED" : "ACTIVE / KYC VERIFIED"}
                            </span>
                          </div>
                        </div>

                        <div className="text-xs space-y-1 text-slate-600 font-medium">
                          <p><strong className="text-slate-800">Owner Contact:</strong> {d.ownerName}</p>
                          <p className="font-mono text-[11px]"><strong className="text-slate-800">Phone:</strong> {d.ownerPhone}</p>
                          {d.ownerEmail && <p className="font-mono text-[11px]"><strong className="text-slate-800">Email:</strong> {d.ownerEmail}</p>}
                          {d.pacraTpin && <p className="font-mono text-[11px]"><strong className="text-slate-800">PACRA/TPIN:</strong> {d.pacraTpin}</p>}
                        </div>

                        <div className="p-2.5 bg-white rounded-xl border border-slate-200 text-[11px] font-mono space-y-1">
                          <div className="flex items-center gap-1 text-slate-700">
                            <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                            <span>{d.city}, {d.district}, {d.province}</span>
                          </div>
                          {d.gpsLocation && (
                            <span className="text-[9px] text-slate-400 block pl-4">
                              GPS: {d.gpsLocation.lat.toFixed(4)}, {d.gpsLocation.lng.toFixed(4)}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="pt-3 mt-2 border-t border-slate-200 space-y-2">
                        <div className="flex items-center justify-between text-[10px] font-mono">
                          <span className={`px-2 py-0.5 rounded font-bold ${d.canDeliver ? "bg-blue-50 text-blue-700" : "bg-slate-200 text-slate-600"}`}>
                            {d.canDeliver ? "🚚 Delivery & Pickup" : "🏪 Pickup Only"}
                          </span>
                          <button
                            onClick={() => {
                              setActiveDealerId(d.id);
                              setActiveWorkspaceMode("DEALER");
                              showToast(`Switched workspace to Agro-Dealer: ${d.tradingName || d.businessName}`);
                            }}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-[10px] flex items-center gap-1 transition-all cursor-pointer shadow-xs"
                          >
                            <Store className="w-3 h-3" />
                            Access Workspace
                          </button>
                        </div>

                        {/* Super Admin Control Buttons */}
                        <div className="flex items-center justify-end gap-1.5 pt-1">
                          <button
                            type="button"
                            onClick={() => handleToggleSuspendDealer(d.id)}
                            className={`px-2.5 py-1 rounded text-[10px] font-bold transition flex items-center gap-1 ${
                              isSuspended
                                ? "bg-emerald-100 hover:bg-emerald-200 text-emerald-800"
                                : "bg-amber-100 hover:bg-amber-200 text-amber-900"
                            }`}
                          >
                            <AlertTriangle className="w-3 h-3" />
                            {isSuspended ? "Unsuspend / Reactivate" : "Suspend Dealer"}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteDealer(d.id)}
                            className="px-2.5 py-1 bg-rose-100 hover:bg-rose-200 text-rose-800 rounded text-[10px] font-bold transition flex items-center gap-1"
                          >
                            <Trash2 className="w-3 h-3" />
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* SUB-TAB 2: SEED & CHEMICAL COMPANIES */}
          {superAdminSubTab === "SUPPLIERS" && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {suppliers.map(s => {
                  const isSuspended = (s as any).status === "suspended";
                  return (
                    <div key={s.id} className="p-5 rounded-2xl border border-slate-200 space-y-3 bg-slate-50 shadow-xs flex flex-col justify-between">
                      <div className="space-y-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[10px] font-black uppercase text-emerald-700 font-mono block">
                              Institution ID: {s.id}
                            </span>
                            <h4 className="font-extrabold text-slate-900 text-base mt-0.5">{s.name}</h4>
                          </div>
                          <div className="flex flex-col items-end gap-1">
                            {isSuspended && (
                              <span className="bg-rose-100 text-rose-800 text-[9px] font-black px-2 py-0.5 rounded font-mono uppercase">
                                SUSPENDED
                              </span>
                            )}
                            <div className="flex gap-1">
                              {s.capabilities.map(cap => (
                                <span key={cap} className="bg-emerald-100 text-emerald-800 text-[9px] font-black px-2 py-0.5 rounded font-mono uppercase">
                                  {cap}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="text-xs space-y-1 text-slate-600 font-medium">
                          {s.pacraTpin && <p className="font-mono text-[11px]"><strong className="text-slate-800">PACRA/TPIN:</strong> {s.pacraTpin}</p>}
                          <p><strong className="text-slate-800">Address:</strong> {s.registeredAddress}</p>
                        </div>

                        <div>
                          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Categories Distributed</span>
                          <div className="flex flex-wrap gap-1">
                            {s.productCategories.map(cat => (
                              <span key={cat} className="bg-white border border-slate-200 text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded capitalize">
                                {cat}
                              </span>
                            ))}
                          </div>
                        </div>

                        {s.nominatedAdmins.length > 0 && (
                          <div className="p-2.5 bg-white rounded-xl border border-slate-200 text-[11px] font-mono space-y-0.5">
                            <span className="text-[9px] uppercase font-bold text-slate-400 block">Nominated Admin Contact</span>
                            <strong className="text-slate-800">{s.nominatedAdmins[0].name}</strong> — {s.nominatedAdmins[0].email}
                          </div>
                        )}
                      </div>

                      <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                        <button
                          onClick={() => {
                            setActiveSupplierId(s.id);
                            setActiveWorkspaceMode("SUPPLIER");
                            showToast(`Switched workspace to Supplier: ${s.name}`);
                          }}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-[10px] flex items-center gap-1 transition-all cursor-pointer shadow-xs"
                        >
                          <Building2 className="w-3 h-3" />
                          Access Workspace
                        </button>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleToggleSuspendSupplier(s.id)}
                            className={`px-2.5 py-1 rounded text-[10px] font-bold transition flex items-center gap-1 ${
                              isSuspended
                                ? "bg-emerald-100 hover:bg-emerald-200 text-emerald-800"
                                : "bg-amber-100 hover:bg-amber-200 text-amber-900"
                            }`}
                          >
                            <AlertTriangle className="w-3 h-3" />
                            {isSuspended ? "Unsuspend" : "Suspend Supplier"}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteSupplier(s.id)}
                            className="px-2.5 py-1 bg-rose-100 hover:bg-rose-200 text-rose-800 rounded text-[10px] font-bold transition flex items-center gap-1"
                          >
                            <Trash2 className="w-3 h-3" />
                            Delete Company
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* SUB-TAB 3: AGREEMENTS */}
          {superAdminSubTab === "AGREEMENTS" && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {agreements.map(agr => {
                  const isSuspended = (agr.status as any) === "suspended" || (agr.status as any) === "revoked";
                  return (
                    <div key={agr.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3 flex flex-col justify-between">
                      <div className="space-y-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[10px] font-black uppercase text-blue-700 bg-blue-50 px-2 py-0.5 rounded font-mono">
                              {agr.remittancePeriodDays}-Day Remittance Cycle
                            </span>
                            <h4 className="font-extrabold text-slate-900 text-sm mt-1">{agr.dealerName}</h4>
                            <span className="text-[10px] text-slate-400 block font-mono">Supplier: {agr.institutionName}</span>
                          </div>
                          
                          <div className="flex flex-col items-end gap-1">
                            <span className={`text-[10px] font-black px-2.5 py-1 rounded font-mono uppercase ${
                              agr.status === "active"
                                ? "bg-emerald-100 text-emerald-800"
                                : isSuspended
                                ? "bg-rose-100 text-rose-800"
                                : "bg-amber-100 text-amber-800"
                            }`}>
                              {agr.status}
                            </span>
                            {agr.status === "pending" && (
                              <button
                                type="button"
                                onClick={() => handleAcceptAgreement(agr.id)}
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold rounded shadow-xs transition"
                              >
                                Accept Agreement
                              </button>
                            )}
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-50 p-3 rounded-xl">
                          <div>
                            <span className="text-[9px] text-slate-400 block uppercase">Credit Limit (ZMW)</span>
                            <strong className="text-slate-800">{currencySymbol} {agr.creditLimit.toLocaleString()}</strong>
                          </div>
                          <div>
                            <span className="text-[9px] text-slate-400 block uppercase">Commission Bearer</span>
                            <strong className="text-emerald-800 uppercase">{agr.commissionBearer.replace("_", " ")}</strong>
                          </div>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-200 flex justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleToggleSuspendAgreement(agr.id)}
                          className={`px-2.5 py-1 rounded text-[10px] font-bold transition flex items-center gap-1 ${
                            isSuspended
                              ? "bg-emerald-100 hover:bg-emerald-200 text-emerald-800"
                              : "bg-amber-100 hover:bg-amber-200 text-amber-900"
                          }`}
                        >
                          <AlertTriangle className="w-3 h-3" />
                          {isSuspended ? "Unsuspend" : "Suspend Agreement"}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteAgreement(agr.id)}
                          className="px-2.5 py-1 bg-rose-100 hover:bg-rose-200 text-rose-800 rounded text-[10px] font-bold transition flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" />
                          Delete Agreement
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODAL 1: ADD SKU (SINGLE OR BULK CSV/EXCEL) */}
      {showAddSkuModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white max-w-2xl w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <span className="text-[10px] font-mono font-black uppercase bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                  Agro-Dealer Inventory Portal
                </span>
                <h3 className="font-extrabold text-slate-800 text-sm mt-1">Add Stock Items to Inventory</h3>
              </div>
              <button type="button" onClick={() => setShowAddSkuModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mode Switcher */}
            <div className="flex border-b border-slate-200">
              <button
                type="button"
                onClick={() => setAddSkuModalTab("SINGLE")}
                className={`flex-1 py-2 text-xs font-extrabold border-b-2 transition ${
                  addSkuModalTab === "SINGLE"
                    ? "border-emerald-600 text-emerald-700 bg-emerald-50/50"
                    : "border-transparent text-slate-500 hover:text-slate-700"
                }`}
              >
                + Add Single SKU Form
              </button>
              <button
                type="button"
                onClick={() => setAddSkuModalTab("BULK")}
                className={`flex-1 py-2 text-xs font-extrabold border-b-2 transition flex items-center justify-center gap-1.5 ${
                  addSkuModalTab === "BULK"
                    ? "border-emerald-600 text-emerald-700 bg-emerald-50/50"
                    : "border-transparent text-slate-500 hover:text-slate-700"
                }`}
              >
                <UploadCloud className="w-4 h-4 text-amber-600" />
                Bulk Upload (CSV / Excel)
              </button>
            </div>

            {/* TAB 1: SINGLE SKU FORM */}
            {addSkuModalTab === "SINGLE" && (
              <form onSubmit={handleCreateSku} className="space-y-3 text-xs">
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Product Item Name</label>
                  <input
                    type="text"
                    required
                    value={newSkuName}
                    onChange={e => setNewSkuName(e.target.value)}
                    placeholder="e.g. Hybrid Seed SC-719 (10kg)"
                    className="w-full p-2.5 border rounded-lg mt-1 font-semibold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Category</label>
                    <select
                      value={newSkuCategory}
                      onChange={e => setNewSkuCategory(e.target.value as AgroCategory)}
                      className="w-full p-2.5 border rounded-lg mt-1 font-semibold bg-white"
                    >
                      <option value="seed">Seed</option>
                      <option value="pesticide">Pesticide</option>
                      <option value="herbicide">Herbicide</option>
                      <option value="fungicide">Fungicide</option>
                      <option value="fertilizer">Fertilizer</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Packaging Unit</label>
                    <select
                      value={newSkuUnit}
                      onChange={e => setNewSkuUnit(e.target.value)}
                      className="w-full p-2.5 border rounded-lg mt-1 font-semibold bg-white"
                    >
                      {PACKAGING_UNITS.map(unit => (
                        <option key={unit} value={unit}>{unit}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Stock Source / Consignment Supplier</label>
                  <select
                    value={newSkuSupplierId}
                    onChange={e => setNewSkuSupplierId(e.target.value)}
                    className="w-full p-2.5 border rounded-lg mt-1 font-semibold bg-white"
                  >
                    <option value="OWNED">Dealer Owned (Outright Purchased)</option>
                    {dealerAgreements.map(a => (
                      <option key={a.institutionId} value={a.institutionId}>
                        Consignment: {a.institutionName}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-3 gap-3 font-mono">
                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Unit Cost (ZMW)</label>
                    <input
                      type="number"
                      value={newSkuUnitCost}
                      onChange={e => setNewSkuUnitCost(Number(e.target.value))}
                      className="w-full p-2 border rounded-lg mt-1 font-bold"
                    />
                  </div>
                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Selling Price (ZMW)</label>
                    <input
                      type="number"
                      value={newSkuSellingPrice}
                      onChange={e => setNewSkuSellingPrice(Number(e.target.value))}
                      className="w-full p-2 border rounded-lg mt-1 font-bold text-emerald-800"
                    />
                  </div>
                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Initial Qty</label>
                    <input
                      type="number"
                      value={newSkuQty}
                      onChange={e => setNewSkuQty(Number(e.target.value))}
                      className="w-full p-2 border rounded-lg mt-1 font-bold"
                    />
                  </div>
                </div>

                <div className="pt-3 border-t flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddSkuModal(false)}
                    className="px-4 py-2 bg-slate-100 font-bold rounded-lg text-slate-600"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-700 font-bold text-white rounded-lg hover:bg-emerald-800 cursor-pointer"
                  >
                    Save Stock Item
                  </button>
                </div>
              </form>
            )}

            {/* TAB 2: BULK CSV / EXCEL UPLOAD */}
            {addSkuModalTab === "BULK" && (
              <div className="space-y-4 text-xs font-sans">
                <div className="flex items-center justify-between bg-amber-50 border border-amber-200 p-3 rounded-xl">
                  <div>
                    <strong className="text-amber-900 block font-bold text-xs">Need standard formatting template?</strong>
                    <span className="text-[11px] text-amber-800">Download pre-formatted Excel / CSV template with sample items.</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => downloadSampleTemplate("AGRO_DEALER_STOCK")}
                    className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 shrink-0"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download Template (.xlsx)
                  </button>
                </div>

                {/* File Upload Box */}
                <div className="border-2 border-dashed border-slate-300 rounded-xl p-4 text-center space-y-2 bg-slate-50">
                  <UploadCloud className="w-8 h-8 text-emerald-600 mx-auto" />
                  <div>
                    <label className="font-extrabold text-slate-800 cursor-pointer hover:text-emerald-700 block">
                      Click to choose Excel or CSV file
                      <input
                        type="file"
                        accept=".csv, .xlsx, .xls, .txt"
                        className="hidden"
                        onChange={async e => {
                          const file = e.target.files?.[0];
                          if (file) {
                            try {
                              const rawRows = await parseExcelOrCsvFile(file);
                              const processed = processRawSKURows(rawRows, activeDealerId || "dealer_default");
                              setSkuUploadParsedRows(processed);
                              showToast(`Parsed ${processed.length} rows from file ${file.name}!`);
                            } catch (err: any) {
                              alert("File parse error: " + err.message);
                            }
                          }
                        }}
                      />
                    </label>
                    <span className="text-[10px] text-slate-400">Supports .xlsx, .xls, .csv files</span>
                  </div>
                </div>

                {/* Or Paste CSV Raw Text */}
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Or Paste CSV Raw Content:</label>
                  <textarea
                    rows={3}
                    value={skuUploadRawText}
                    onChange={e => {
                      const txt = e.target.value;
                      setSkuUploadRawText(txt);
                      if (txt.trim()) {
                        const rawRows = parseCsvTextString(txt);
                        const processed = processRawSKURows(rawRows, activeDealerId || "dealer_default");
                        setSkuUploadParsedRows(processed);
                      } else {
                        setSkuUploadParsedRows([]);
                      }
                    }}
                    placeholder={`Product Name, Category, Packaging Unit, Unit Cost, Selling Price, Qty On Hand\nHybrid Seed SC-719 (10kg), seed, 10kg Bag, 310, 385, 50`}
                    className="w-full p-2.5 border rounded-xl font-mono text-[11px] bg-white"
                  />
                </div>

                {/* Live Preview Table */}
                {skuUploadParsedRows.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <strong className="text-slate-800 font-bold">
                        Parsed File Preview ({skuUploadParsedRows.filter(r => r.isValid).length} Valid / {skuUploadParsedRows.length} Total)
                      </strong>
                      <span className="text-[10px] text-emerald-700 font-mono font-bold">
                        Total Value: {currencySymbol} {skuUploadParsedRows.reduce((sum, r) => sum + (r.unitCost * r.qtyOnHand), 0).toLocaleString()}
                      </span>
                    </div>

                    <div className="max-h-48 overflow-y-auto border rounded-xl border-slate-200">
                      <table className="w-full text-left text-[11px] font-mono">
                        <thead className="bg-slate-100 text-slate-600 uppercase text-[9px] border-b sticky top-0">
                          <tr>
                            <th className="p-2">Status</th>
                            <th className="p-2">Product Name</th>
                            <th className="p-2">Category</th>
                            <th className="p-2">Unit</th>
                            <th className="p-2 text-right">Cost</th>
                            <th className="p-2 text-right">Price</th>
                            <th className="p-2 text-right">Qty</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 bg-white">
                          {skuUploadParsedRows.map((row, i) => (
                            <tr key={i} className={row.isValid ? "bg-white" : "bg-rose-50 text-rose-900"}>
                              <td className="p-2">
                                {row.isValid ? (
                                  <span className="text-emerald-600 font-bold flex items-center gap-1">
                                    <CheckCircle2 className="w-3.5 h-3.5" /> OK
                                  </span>
                                ) : (
                                  <span className="text-rose-600 font-bold flex items-center gap-1">
                                    <AlertTriangle className="w-3.5 h-3.5" /> {row.validationError || "Invalid"}
                                  </span>
                                )}
                              </td>
                              <td className="p-2 font-bold font-sans text-slate-900">{row.productName || "—"}</td>
                              <td className="p-2 uppercase">{row.category}</td>
                              <td className="p-2 font-sans">{row.unit}</td>
                              <td className="p-2 text-right">{row.unitCost}</td>
                              <td className="p-2 text-right">{row.sellingPrice}</td>
                              <td className="p-2 text-right font-extrabold">{row.qtyOnHand}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleBulkImportDealerSkus(skuUploadParsedRows)}
                      className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl text-xs shadow-md transition cursor-pointer"
                    >
                      Import All {skuUploadParsedRows.filter(r => r.isValid).length} Valid SKUs to Active Dealer Inventory →
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL 2: ADD SINGLE ITEM TO SUPPLIER STOCK CATALOG */}
      {showAddSupplierCatalogModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white max-w-lg w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <span className="text-[10px] font-mono font-black uppercase bg-amber-100 text-amber-900 px-2 py-0.5 rounded">
                  Supplier Stock Catalog
                </span>
                <h3 className="font-extrabold text-slate-800 text-sm mt-1">Add Product to Supplier Master Catalog</h3>
              </div>
              <button type="button" onClick={() => setShowAddSupplierCatalogModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSupplierCatalogItem} className="space-y-3 text-xs">
              <div>
                <label className="font-bold uppercase text-[10px] text-slate-500 block">Product Item Name</label>
                <input
                  type="text"
                  required
                  value={newCatProductName}
                  onChange={e => setNewCatProductName(e.target.value)}
                  placeholder="e.g. ZAMSEED ZM-521 Hybrid Seed Maize (10kg)"
                  className="w-full p-2.5 border rounded-lg mt-1 font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Category</label>
                  <select
                    value={newCatCategory}
                    onChange={e => setNewCatCategory(e.target.value as AgroCategory)}
                    className="w-full p-2.5 border rounded-lg mt-1 font-semibold bg-white"
                  >
                    <option value="seed">Seed</option>
                    <option value="pesticide">Pesticide</option>
                    <option value="herbicide">Herbicide</option>
                    <option value="fungicide">Fungicide</option>
                    <option value="fertilizer">Fertilizer</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Packaging Unit</label>
                  <input
                    type="text"
                    required
                    value={newCatUnit}
                    onChange={e => setNewCatUnit(e.target.value)}
                    placeholder="e.g. 10kg Bag"
                    className="w-full p-2.5 border rounded-lg mt-1 font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 font-mono">
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Wholesale Cost (ZMW)</label>
                  <input
                    type="number"
                    required
                    value={newCatWholesale}
                    onChange={e => setNewCatWholesale(Number(e.target.value))}
                    className="w-full p-2 border rounded-lg mt-1 font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Rec. Retail Price (ZMW)</label>
                  <input
                    type="number"
                    required
                    value={newCatRetail}
                    onChange={e => setNewCatRetail(Number(e.target.value))}
                    className="w-full p-2 border rounded-lg mt-1 font-bold text-emerald-800"
                  />
                </div>
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Qty in Stock</label>
                  <input
                    type="number"
                    required
                    value={newCatQty}
                    onChange={e => setNewCatQty(Number(e.target.value))}
                    className="w-full p-2 border rounded-lg mt-1 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 font-mono">
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Batch Number</label>
                  <input
                    type="text"
                    value={newCatBatch}
                    onChange={e => setNewCatBatch(e.target.value)}
                    placeholder="ZM-2026-101"
                    className="w-full p-2 border rounded-lg mt-1 font-semibold text-xs"
                  />
                </div>
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Expiry Date</label>
                  <input
                    type="date"
                    value={newCatExpiry}
                    onChange={e => setNewCatExpiry(e.target.value)}
                    className="w-full p-2 border rounded-lg mt-1 font-semibold text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold uppercase text-[10px] text-slate-500 block">Barcode / SKU Identifier (Optional)</label>
                <input
                  type="text"
                  value={newCatBarcode}
                  onChange={e => setNewCatBarcode(e.target.value)}
                  placeholder="e.g. 600123456789"
                  className="w-full p-2 border rounded-lg mt-1 font-mono text-xs"
                />
              </div>

              <div className="pt-3 border-t flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddSupplierCatalogModal(false)}
                  className="px-4 py-2 bg-slate-100 font-bold rounded-lg text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 font-bold text-white rounded-lg hover:bg-emerald-800 cursor-pointer"
                >
                  Save Catalog Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: BULK UPLOAD SUPPLIER CATALOG (CSV / EXCEL) */}
      {showBulkSupplierCatalogModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white max-w-2xl w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <span className="text-[10px] font-mono font-black uppercase bg-amber-100 text-amber-900 px-2 py-0.5 rounded">
                  Bulk Catalog Import
                </span>
                <h3 className="font-extrabold text-slate-800 text-sm mt-1">Upload Supplier Stock Catalog (CSV / Excel)</h3>
              </div>
              <button type="button" onClick={() => setShowBulkSupplierCatalogModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs font-sans">
              <div className="flex items-center justify-between bg-amber-50 border border-amber-200 p-3 rounded-xl">
                <div>
                  <strong className="text-amber-900 block font-bold text-xs">Download Supplier Catalog Template</strong>
                  <span className="text-[11px] text-amber-800">Pre-formatted Excel sheet matching expected column headers.</span>
                </div>
                <button
                  type="button"
                  onClick={() => downloadSampleTemplate("SUPPLIER_CATALOG")}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download (.xlsx)
                </button>
              </div>

              {/* Upload Box */}
              <div className="border-2 border-dashed border-slate-300 rounded-xl p-4 text-center space-y-2 bg-slate-50">
                <UploadCloud className="w-8 h-8 text-amber-600 mx-auto" />
                <div>
                  <label className="font-extrabold text-slate-800 cursor-pointer hover:text-amber-700 block">
                    Choose Excel (.xlsx / .xls) or CSV file
                    <input
                      type="file"
                      accept=".csv, .xlsx, .xls, .txt"
                      className="hidden"
                      onChange={async e => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const rawRows = await parseExcelOrCsvFile(file);
                            const processed = processRawSupplierCatalogRows(rawRows);
                            setSupplierCatalogParsedRows(processed);
                            showToast(`Parsed ${processed.length} supplier catalog rows from ${file.name}!`);
                          } catch (err: any) {
                            alert("File parse error: " + err.message);
                          }
                        }
                      }}
                    />
                  </label>
                  <span className="text-[10px] text-slate-400">Supports .xlsx, .xls, .csv formats</span>
                </div>
              </div>

              {/* Paste Raw CSV */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">Or Paste CSV Text:</label>
                <textarea
                  rows={3}
                  value={supplierCatalogRawText}
                  onChange={e => {
                    const txt = e.target.value;
                    setSupplierCatalogRawText(txt);
                    if (txt.trim()) {
                      const rawRows = parseCsvTextString(txt);
                      const processed = processRawSupplierCatalogRows(rawRows);
                      setSupplierCatalogParsedRows(processed);
                    } else {
                      setSupplierCatalogParsedRows([]);
                    }
                  }}
                  placeholder={`Product Name, Category, Packaging Unit, Wholesale Cost, Recommended Selling Price, Qty In Stock, Batch Number, Expiry Date\nZAMSEED ZM-521 Hybrid Seed Maize (10kg), seed, 10kg Bag, 310, 385, 2500, ZM-2026-101, 2027-11-30`}
                  className="w-full p-2.5 border rounded-xl font-mono text-[11px] bg-white"
                />
              </div>

              {/* Preview Table */}
              {supplierCatalogParsedRows.length > 0 && (
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <strong className="text-slate-800 font-bold">
                      Parsed Catalog Rows ({supplierCatalogParsedRows.filter(r => r.isValid).length} Valid / {supplierCatalogParsedRows.length} Total)
                    </strong>
                    <span className="text-[10px] text-amber-800 font-mono font-bold">
                      Stock Value: {currencySymbol} {supplierCatalogParsedRows.reduce((sum, r) => sum + (r.unitWholesaleCost * r.qtyInStock), 0).toLocaleString()}
                    </span>
                  </div>

                  <div className="max-h-48 overflow-y-auto border rounded-xl border-slate-200">
                    <table className="w-full text-left text-[11px] font-mono">
                      <thead className="bg-slate-100 text-slate-600 uppercase text-[9px] border-b sticky top-0">
                        <tr>
                          <th className="p-2">Status</th>
                          <th className="p-2">Product Name</th>
                          <th className="p-2">Category</th>
                          <th className="p-2 text-right">Wholesale</th>
                          <th className="p-2 text-right">Retail</th>
                          <th className="p-2 text-right">Qty</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 bg-white">
                        {supplierCatalogParsedRows.map((row, i) => (
                          <tr key={i} className={row.isValid ? "bg-white" : "bg-rose-50 text-rose-900"}>
                            <td className="p-2">
                              {row.isValid ? (
                                <span className="text-emerald-600 font-bold flex items-center gap-1">
                                  <CheckCircle2 className="w-3.5 h-3.5" /> Valid
                                </span>
                              ) : (
                                <span className="text-rose-600 font-bold flex items-center gap-1">
                                  <AlertTriangle className="w-3.5 h-3.5" /> {row.validationError || "Invalid"}
                                </span>
                              )}
                            </td>
                            <td className="p-2 font-bold font-sans text-slate-900">{row.productName || "—"}</td>
                            <td className="p-2 uppercase">{row.category}</td>
                            <td className="p-2 text-right">{row.unitWholesaleCost}</td>
                            <td className="p-2 text-right">{row.recommendedSellingPrice}</td>
                            <td className="p-2 text-right font-extrabold">{row.qtyInStock}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleBulkImportSupplierCatalog(supplierCatalogParsedRows)}
                    className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-extrabold rounded-xl text-xs shadow-md transition cursor-pointer"
                  >
                    Batch Add {supplierCatalogParsedRows.filter(r => r.isValid).length} Valid Items to Supplier Stock Catalog →
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: REMIT TO SUPPLIER */}
      {showRemitModal && remitAgreement && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white max-w-md w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="font-extrabold text-slate-800 text-sm">Farm Balance Internal Remittance</h3>
              <button type="button" onClick={() => setShowRemitModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleExecuteRemittance} className="space-y-4 text-xs font-sans">
              <div className="p-3 bg-slate-50 rounded-xl border space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Recipient Company</span>
                <strong className="text-slate-900 block text-sm">{remitAgreement.institutionName}</strong>
                <span className="text-[10px] text-emerald-700 font-mono block">Remittance Period: {remitAgreement.remittancePeriodDays} Days</span>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex justify-between items-center font-mono">
                <span className="text-[10px] uppercase font-bold text-emerald-800">Your Lipila Balance</span>
                <strong className="text-emerald-900 font-bold">{currencySymbol} {dealerBalance.toLocaleString()}</strong>
              </div>

              <div>
                <label className="font-bold uppercase text-[10px] text-slate-500 block">Remittance Amount ({currencySymbol})</label>
                <input
                  type="number"
                  required
                  min="1"
                  max={dealerBalance}
                  value={remitAmount}
                  onChange={e => setRemitAmount(Number(e.target.value))}
                  className="w-full p-3 border rounded-xl mt-1 text-base font-mono font-black text-emerald-900"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setShowRemitModal(false)} className="px-4 py-2 bg-slate-100 font-bold rounded-xl text-slate-600">
                  Cancel
                </button>
                <button type="submit" className="px-5 py-2.5 bg-emerald-700 font-extrabold text-white rounded-xl hover:bg-emerald-800">
                  Execute Remittance Transfer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 5: AI SAFETY BRIEF VIEW */}
      {showAiBriefModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white max-w-lg w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-purple-200">
            <div className="flex justify-between items-center border-b pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                <h3 className="font-extrabold text-slate-800 text-sm">Gemini AI Extension Agronomist Brief</h3>
              </div>
              <button type="button" onClick={() => setShowAiBriefModal(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <h4 className="font-black text-slate-900 text-sm">{showAiBriefModal.productName}</h4>

              {showAiBriefModal.aiBrief && (
                <div className="space-y-3">
                  <div>
                    <span className="text-[10px] font-bold uppercase text-slate-400 block">Target Pests & Conditions</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {showAiBriefModal.aiBrief.targetPests?.map((p, i) => (
                        <span key={i} className="bg-purple-50 text-purple-800 border border-purple-200 text-[10px] font-bold px-2 py-0.5 rounded">
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold uppercase text-slate-400 block">Recommended Crops</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {showAiBriefModal.aiBrief.recommendedCrops?.map((c, i) => (
                        <span key={i} className="bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border space-y-1">
                    <span className="text-[10px] font-bold uppercase text-slate-500 block">Application Guidance</span>
                    <p className="text-slate-700 leading-relaxed text-[11px]">{showAiBriefModal.aiBrief.applicationGuidance}</p>
                  </div>

                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 space-y-1">
                    <span className="text-[10px] font-bold uppercase text-amber-800 block">Mandatory Safety & Withholding Notes</span>
                    <p className="text-amber-900 leading-relaxed text-[11px]">{showAiBriefModal.aiBrief.safetyNotes}</p>
                  </div>
                </div>
              )}

              <div className="pt-2 border-t flex items-center justify-between">
                <span className="text-[9px] text-slate-400">Advisory info. Consult local officer for field dosage.</span>
                <button
                  type="button"
                  onClick={() => {
                    setShowAiBriefModal(null);
                    if (onNavigateToAgronomist) onNavigateToAgronomist();
                  }}
                  className="px-3 py-1.5 bg-purple-700 text-white text-xs font-bold rounded-lg hover:bg-purple-800"
                >
                  Consult Agronomist Module →
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 6: ISSUE CONSIGNMENT STOCK GRANT */}
      {showGrantModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white max-w-lg w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <span className="text-[10px] font-mono font-black uppercase bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                  Consignment Grant Issuance
                </span>
                <h3 className="font-extrabold text-slate-800 text-sm mt-1">Issue New Consignment Stock Grant</h3>
              </div>
              <button type="button" onClick={() => setShowGrantModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleIssueGrant} className="space-y-3 text-xs font-sans">
              <div>
                <label className="font-bold uppercase text-[10px] text-slate-500 block">Select Registered Recipient Agro-Dealer</label>
                <select
                  value={grantDealerId}
                  onChange={e => setGrantDealerId(e.target.value)}
                  className="w-full p-2.5 border rounded-lg mt-1 font-semibold bg-white"
                >
                  {dealers.map(d => {
                    const activeAgr = agreements.find(a => a.dealerTenantId === d.id && a.institutionId === activeSupplierId && a.status === "active");
                    return (
                      <option key={d.id} value={d.id}>
                        {d.businessName} ({d.district}, {d.province}) | Phone: {d.ownerPhone} {activeAgr ? " [✓ Active Agreement]" : " [Pending Agreement]"}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Product Item Name (Select from Stock Catalog)</label>
                  <button
                    type="button"
                    onClick={() => {
                      setShowGrantModal(false);
                      setShowAddSupplierCatalogModal(true);
                    }}
                    className="text-[10px] font-bold text-emerald-700 hover:underline"
                  >
                    + Add New Item to Catalog
                  </button>
                </div>
                <select
                  value={grantItemName}
                  onChange={e => {
                    const selected = e.target.value;
                    setGrantItemName(selected);
                    const matchedCat = supplierCatalog.find(s => s.productName === selected);
                    if (matchedCat) {
                      setGrantCategory(matchedCat.category);
                      setGrantUnit(matchedCat.unit);
                      setGrantUnitCost(matchedCat.unitWholesaleCost);
                      setGrantSellingPrice(matchedCat.recommendedSellingPrice);
                      if (matchedCat.batchNumber) setGrantBatch(matchedCat.batchNumber);
                      if (matchedCat.expiryDate) setGrantExpiry(matchedCat.expiryDate);
                    } else {
                      const matchedSku = skus.find(s => s.productName === selected);
                      if (matchedSku) {
                        setGrantCategory(matchedSku.category);
                        setGrantUnit(matchedSku.unit);
                        setGrantUnitCost(matchedSku.unitCost);
                        setGrantSellingPrice(matchedSku.sellingPrice);
                      }
                    }
                  }}
                  className="w-full p-2.5 border rounded-lg mt-1 font-semibold bg-white"
                >
                  <optgroup label="Recorded Supplier Master Stock Catalog">
                    {supplierCatalog.map(item => (
                      <option key={item.id} value={item.productName}>
                        {item.productName} ({item.unit}) — Cost: {currencySymbol} {item.unitWholesaleCost} | Stock: {item.qtyInStock}
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="Agro-Dealer Existing Product Items">
                    {Array.from(new Set(skus.map(s => s.productName))).map(name => (
                      <option key={name} value={name}>{name}</option>
                    ))}
                  </optgroup>
                </select>
              </div>

              {/* Selected Item Stock Availability Badge */}
              {(() => {
                const match = supplierCatalog.find(s => s.productName === grantItemName);
                if (match) {
                  return (
                    <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-[11px] font-mono">
                      <span className="font-bold text-emerald-800">Available Supplier Stock:</span>
                      <strong className="text-emerald-900 font-extrabold">{match.qtyInStock.toLocaleString()} Units in Warehouse</strong>
                    </div>
                  );
                }
                return null;
              })()}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Category</label>
                  <select
                    value={grantCategory}
                    onChange={e => setGrantCategory(e.target.value as AgroCategory)}
                    className="w-full p-2.5 border rounded-lg mt-1 font-semibold bg-white"
                  >
                    <option value="seed">Seed</option>
                    <option value="pesticide">Pesticide</option>
                    <option value="herbicide">Herbicide</option>
                    <option value="fungicide">Fungicide</option>
                    <option value="fertilizer">Fertilizer</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Packaging Unit</label>
                  <input
                    type="text"
                    value={grantUnit}
                    onChange={e => setGrantUnit(e.target.value)}
                    className="w-full p-2.5 border rounded-lg mt-1 font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 font-mono">
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Grant Qty</label>
                  <input
                    type="number"
                    value={grantQty}
                    onChange={e => setGrantQty(Number(e.target.value))}
                    className="w-full p-2 border rounded-lg mt-1 font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Wholesale Cost (ZMW)</label>
                  <input
                    type="number"
                    value={grantUnitCost}
                    onChange={e => setGrantUnitCost(Number(e.target.value))}
                    className="w-full p-2 border rounded-lg mt-1 font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Rec. Selling Price</label>
                  <input
                    type="number"
                    value={grantSellingPrice}
                    onChange={e => setGrantSellingPrice(Number(e.target.value))}
                    className="w-full p-2 border rounded-lg mt-1 font-bold text-emerald-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 font-mono">
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Batch Number</label>
                  <input
                    type="text"
                    value={grantBatch}
                    onChange={e => setGrantBatch(e.target.value)}
                    className="w-full p-2 border rounded-lg mt-1 font-semibold text-xs"
                  />
                </div>
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Expiry Date</label>
                  <input
                    type="date"
                    value={grantExpiry}
                    onChange={e => setGrantExpiry(e.target.value)}
                    className="w-full p-2 border rounded-lg mt-1 font-semibold text-xs"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 pt-1 text-[11px] font-semibold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={saveCustomToCatalog}
                  onChange={e => setSaveCustomToCatalog(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>Also sync this product item to Master Supplier Stock Catalog</span>
              </label>

              <div className="pt-3 border-t flex justify-end gap-2">
                <button type="button" onClick={() => setShowGrantModal(false)} className="px-4 py-2 bg-slate-100 font-bold rounded-lg text-slate-600">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-emerald-700 font-bold text-white rounded-lg hover:bg-emerald-800 cursor-pointer">
                  Issue Consignment Grant
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 7: BULK UPLOAD CONSIGNMENT STOCK GRANTS (CSV / EXCEL) */}
      {showBulkGrantModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white max-w-2xl w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <span className="text-[10px] font-mono font-black uppercase bg-amber-100 text-amber-900 px-2 py-0.5 rounded">
                  Bulk Consignment Allocation
                </span>
                <h3 className="font-extrabold text-slate-800 text-sm mt-1">Upload Bulk Stock Grants (CSV / Excel)</h3>
              </div>
              <button type="button" onClick={() => setShowBulkGrantModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs font-sans">
              <div className="flex items-center justify-between bg-amber-50 border border-amber-200 p-3 rounded-xl">
                <div>
                  <strong className="text-amber-900 block font-bold text-xs">Download Grant Upload Template</strong>
                  <span className="text-[11px] text-amber-800">Pre-formatted Excel sheet with sample dealer grants.</span>
                </div>
                <button
                  type="button"
                  onClick={() => downloadSampleTemplate("CONSIGNMENT_GRANTS")}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download (.xlsx)
                </button>
              </div>

              {/* Upload File */}
              <div className="border-2 border-dashed border-slate-300 rounded-xl p-4 text-center space-y-2 bg-slate-50">
                <UploadCloud className="w-8 h-8 text-amber-600 mx-auto" />
                <div>
                  <label className="font-extrabold text-slate-800 cursor-pointer hover:text-amber-700 block">
                    Choose Excel (.xlsx / .xls) or CSV file
                    <input
                      type="file"
                      accept=".csv, .xlsx, .xls, .txt"
                      className="hidden"
                      onChange={async e => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const rawRows = await parseExcelOrCsvFile(file);
                            const processed = processRawConsignmentGrantRows(rawRows);
                            setGrantUploadParsedRows(processed);
                            showToast(`Parsed ${processed.length} grant allocation rows from ${file.name}!`);
                          } catch (err: any) {
                            alert("File parse error: " + err.message);
                          }
                        }
                      }}
                    />
                  </label>
                  <span className="text-[10px] text-slate-400">Supports .xlsx, .xls, .csv formats</span>
                </div>
              </div>

              {/* Or Paste Raw CSV */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">Or Paste CSV Text:</label>
                <textarea
                  rows={3}
                  value={grantUploadRawText}
                  onChange={e => {
                    const txt = e.target.value;
                    setGrantUploadRawText(txt);
                    if (txt.trim()) {
                      const rawRows = parseCsvTextString(txt);
                      const processed = processRawConsignmentGrantRows(rawRows);
                      setGrantUploadParsedRows(processed);
                    } else {
                      setGrantUploadParsedRows([]);
                    }
                  }}
                  placeholder={`Dealer Name or ID, Product Name, Category, Packaging Unit, Quantity, Wholesale Cost, Selling Price\nMabala Agro-Dealer Ndola, ZAMSEED ZM-521 Hybrid Seed Maize (10kg), seed, 10kg Bag, 100, 310, 385`}
                  className="w-full p-2.5 border rounded-xl font-mono text-[11px] bg-white"
                />
              </div>

              {/* Live Preview Table */}
              {grantUploadParsedRows.length > 0 && (
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <strong className="text-slate-800 font-bold">
                      Parsed Grant Rows ({grantUploadParsedRows.filter(r => r.isValid).length} Valid / {grantUploadParsedRows.length} Total)
                    </strong>
                    <span className="text-[10px] text-amber-800 font-mono font-bold">
                      Total Grant Value: {currencySymbol} {grantUploadParsedRows.reduce((sum, r) => sum + (r.unitCost * r.grantQty), 0).toLocaleString()}
                    </span>
                  </div>

                  <div className="max-h-48 overflow-y-auto border rounded-xl border-slate-200">
                    <table className="w-full text-left text-[11px] font-mono">
                      <thead className="bg-slate-100 text-slate-600 uppercase text-[9px] border-b sticky top-0">
                        <tr>
                          <th className="p-2">Status</th>
                          <th className="p-2">Recipient Dealer</th>
                          <th className="p-2">Product Name</th>
                          <th className="p-2 text-right">Qty</th>
                          <th className="p-2 text-right">Wholesale Cost</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 bg-white">
                        {grantUploadParsedRows.map((row, i) => (
                          <tr key={i} className={row.isValid ? "bg-white" : "bg-rose-50 text-rose-900"}>
                            <td className="p-2">
                              {row.isValid ? (
                                <span className="text-emerald-600 font-bold flex items-center gap-1">
                                  <CheckCircle2 className="w-3.5 h-3.5" /> Valid
                                </span>
                              ) : (
                                <span className="text-rose-600 font-bold flex items-center gap-1">
                                  <AlertTriangle className="w-3.5 h-3.5" /> {row.validationError || "Invalid"}
                                </span>
                              )}
                            </td>
                            <td className="p-2 font-bold font-sans text-slate-900">{row.dealerIdentifier || "—"}</td>
                            <td className="p-2 font-sans text-slate-800">{row.productName || "—"}</td>
                            <td className="p-2 text-right font-extrabold">{row.grantQty}</td>
                            <td className="p-2 text-right">{row.unitCost}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleBulkImportConsignmentGrants(grantUploadParsedRows)}
                    className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-extrabold rounded-xl text-xs shadow-md transition cursor-pointer"
                  >
                    Dispatch All {grantUploadParsedRows.filter(r => r.isValid).length} Valid Stock Grants to Dealers →
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL 5: WIZARD 3.1 - CREATE AGRO-DEALER TENANT */}
      {showCreateDealerModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in overflow-y-auto">
          <div className="bg-white max-w-lg w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-slate-200 my-8">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <span className="text-[10px] font-black uppercase text-amber-600 font-mono block">Super Admin Wizard 3.1</span>
                <h3 className="font-extrabold text-slate-900 text-sm">Provision Agro-Dealer Retail Tenant</h3>
                {/* 2-Step Progress Indicator */}
                <div className="flex items-center gap-2 mt-2">
                  <div className={`px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                    createDealerStep === 1 ? "bg-amber-600 text-white" : "bg-emerald-100 text-emerald-800"
                  }`}>
                    <span>Step 1: Agro Dealer Details</span>
                  </div>
                  <span className="text-slate-300">→</span>
                  <div className={`px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                    createDealerStep === 2 ? "bg-amber-600 text-white" : "bg-slate-100 text-slate-500"
                  }`}>
                    <span>Step 2: Shop Location Address</span>
                  </div>
                </div>
              </div>
              <button type="button" onClick={() => { setShowCreateDealerModal(false); setCreateDealerStep(1); }} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAgroDealer} className="space-y-4 text-xs font-sans">
              {createDealerStep === 1 ? (
                /* STEP 1: AGRO DEALER DETAILS */
                <div className="space-y-4 animate-fade-in">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <div className="flex justify-between items-center">
                        <label className="font-bold uppercase text-[10px] text-slate-500 block">Trading Name (DBA / Shop Front Name)</label>
                        <button
                          type="button"
                          onClick={() => setNewDealerTradingName(newDealerName)}
                          className="text-[9px] font-bold text-emerald-700 hover:underline cursor-pointer"
                        >
                          ⚡ Same as Company
                        </button>
                      </div>
                      <input
                        type="text"
                        value={newDealerTradingName}
                        onChange={e => setNewDealerTradingName(e.target.value)}
                        placeholder="e.g. Monze Agro Shop"
                        className="w-full p-2.5 border rounded-xl mt-1 font-semibold"
                        required
                      />
                    </div>
                    <div>
                      <label className="font-bold uppercase text-[10px] text-slate-500 block">Registered Legal Business / Company Name</label>
                      <input
                        type="text"
                        value={newDealerName}
                        onChange={e => {
                          const val = e.target.value;
                          setNewDealerName(val);
                          if (!newDealerTradingName || newDealerTradingName === newDealerName) {
                            setNewDealerTradingName(val);
                          }
                        }}
                        placeholder="e.g. Monze Crop Supply & Agro-Inputs Ltd"
                        className="w-full p-2.5 border rounded-xl mt-1 font-semibold"
                        required
                      />
                    </div>
                  </div>

                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 space-y-1">
                    <div className="flex justify-between items-center">
                      <label className="font-bold uppercase text-[10px] text-amber-800 block">PACRA / TPIN Tax Number</label>
                      <span className="text-[9px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded">Optional at creation</span>
                    </div>
                    <input
                      type="text"
                      value={newDealerPacra}
                      onChange={e => setNewDealerPacra(e.target.value)}
                      placeholder="e.g. 1009847192 (Optional tax reference)"
                      className="w-full p-2 border rounded-lg mt-1 font-mono text-xs font-bold"
                    />
                    <p className="text-[10px] text-amber-800 leading-tight">
                      ℹ️ Agro-Dealer profiles created by Super Admin on the backend are automatically pre-verified with immediate payout and settlement capabilities.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold uppercase text-[10px] text-slate-500 block">Owner / Manager Full Name</label>
                      <input
                        type="text"
                        value={newDealerOwner}
                        onChange={e => setNewDealerOwner(e.target.value)}
                        placeholder="e.g. Chileshe Mwape"
                        className="w-full p-2.5 border rounded-xl mt-1 font-semibold"
                        required
                      />
                    </div>

                    <div>
                      <label className="font-bold uppercase text-[10px] text-slate-500 block">Phone (Lipila Collection No.)</label>
                      <input
                        type="text"
                        value={newDealerPhone}
                        onChange={e => setNewDealerPhone(e.target.value)}
                        placeholder="+260977112233"
                        className="w-full p-2.5 border rounded-xl mt-1 font-mono font-bold"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Owner Email Address (Login ID)</label>
                    <input
                      type="email"
                      value={newDealerEmail}
                      onChange={e => setNewDealerEmail(e.target.value)}
                      placeholder="chileshe@monzeagro.co.zm"
                      className="w-full p-2.5 border rounded-xl mt-1 font-mono text-xs"
                      required
                    />
                  </div>

                  {/* Super Admin Login Password Assignment */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                    <span className="text-[10px] font-bold uppercase text-slate-700 block flex items-center gap-1">
                      🔑 Set User Login Password (Super Admin Control)
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="font-bold uppercase text-[9px] text-slate-500 block">Set Password</label>
                        <input
                          type="password"
                          value={newDealerPassword}
                          onChange={e => setNewDealerPassword(e.target.value)}
                          placeholder="Default: Mabala@2026"
                          className="w-full p-2 border rounded-lg mt-0.5 font-mono text-xs font-bold bg-white"
                        />
                      </div>
                      <div>
                        <label className="font-bold uppercase text-[9px] text-slate-500 block">Confirm Password</label>
                        <input
                          type="password"
                          value={newDealerConfirmPassword}
                          onChange={e => setNewDealerConfirmPassword(e.target.value)}
                          placeholder="Confirm password"
                          className="w-full p-2 border rounded-lg mt-0.5 font-mono text-xs font-bold bg-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t flex justify-between items-center">
                    <button type="button" onClick={() => { setShowCreateDealerModal(false); setCreateDealerStep(1); }} className="px-4 py-2 bg-slate-100 font-bold rounded-xl text-slate-600">
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (!newDealerName || !newDealerPhone) {
                          showToast("Please complete the company name and phone number before proceeding to Step 2.");
                          return;
                        }
                        setCreateDealerStep(2);
                      }}
                      className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 font-extrabold text-white rounded-xl shadow-xs flex items-center gap-2"
                    >
                      <span>Next: Shop Location & Address</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : (
                /* STEP 2: SHOP LOCATION ADDRESS */
                <div className="space-y-4 animate-fade-in">
                  <div className="space-y-3">
                    <span className="text-[10px] font-bold uppercase text-slate-500 block">Shop Location & Address Details</span>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="font-bold uppercase text-[9px] text-slate-400 block">Province</label>
                        <select
                          value={newDealerProvince}
                          onChange={e => {
                            const prov = e.target.value;
                            setNewDealerProvince(prov);
                            const dists = ZAMBIAN_LOCATIONS[prov] || [];
                            const firstDist = dists[0] || "";
                            setNewDealerDistrict(firstDist);

                            const townInfo = DISTRICT_TOWN_MAP[firstDist] || {
                              towns: [`${firstDist} Central Market Area`, `${firstDist} Commercial Post`],
                              coords: { [`${firstDist} Central Market Area`]: { lat: -15.4167, lng: 28.2833 } }
                            };
                            const autoCity = townInfo.towns[0] || `${firstDist} Main Area`;
                            setNewDealerCity(autoCity);

                            const coords = townInfo.coords[autoCity] || Object.values(townInfo.coords)[0] || { lat: -15.4167, lng: 28.2833 };
                            setNewDealerLat(coords.lat);
                            setNewDealerLng(coords.lng);
                          }}
                          className="w-full p-2 border rounded-lg mt-1 font-semibold bg-white"
                        >
                          {Object.keys(ZAMBIAN_LOCATIONS).map(p => (
                            <option key={p} value={p}>{p}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="font-bold uppercase text-[9px] text-slate-400 block">District</label>
                        <select
                          value={newDealerDistrict}
                          onChange={e => {
                            const dist = e.target.value;
                            setNewDealerDistrict(dist);

                            const townInfo = DISTRICT_TOWN_MAP[dist] || {
                              towns: [`${dist} Central Market Area`, `${dist} Commercial Post`],
                              coords: { [`${dist} Central Market Area`]: { lat: -15.4167, lng: 28.2833 } }
                            };
                            const autoCity = townInfo.towns[0] || `${dist} Main Area`;
                            setNewDealerCity(autoCity);

                            const coords = townInfo.coords[autoCity] || Object.values(townInfo.coords)[0] || { lat: -15.4167, lng: 28.2833 };
                            setNewDealerLat(coords.lat);
                            setNewDealerLng(coords.lng);
                          }}
                          className="w-full p-2 border rounded-lg mt-1 font-semibold bg-white"
                        >
                          {(ZAMBIAN_LOCATIONS[newDealerProvince] || []).map(d => (
                            <option key={d} value={d}>{d}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center">
                        <label className="font-bold uppercase text-[9px] text-slate-400 block">City / Town Area Name (Auto-Populated)</label>
                        <span className="text-[9px] font-mono text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
                          ⚡ Coords Sync Enabled
                        </span>
                      </div>

                      {/* Preset Dropdown for Fast City Selection */}
                      {DISTRICT_TOWN_MAP[newDealerDistrict] && (
                        <select
                          value={newDealerCity}
                          onChange={e => {
                            const selectedCity = e.target.value;
                            setNewDealerCity(selectedCity);
                            const townInfo = DISTRICT_TOWN_MAP[newDealerDistrict];
                            if (townInfo && townInfo.coords[selectedCity]) {
                              setNewDealerLat(townInfo.coords[selectedCity].lat);
                              setNewDealerLng(townInfo.coords[selectedCity].lng);
                            }
                          }}
                          className="w-full p-2 border rounded-lg mt-1 font-semibold bg-slate-50 text-slate-800 text-xs mb-1.5"
                        >
                          {DISTRICT_TOWN_MAP[newDealerDistrict].towns.map(t => (
                            <option key={t} value={t}>📍 {t}</option>
                          ))}
                          <option value="custom">✍️ Custom Town / Plot Name...</option>
                        </select>
                      )}

                      <input
                        type="text"
                        value={newDealerCity}
                        onChange={e => {
                          const val = e.target.value;
                          setNewDealerCity(val);
                          const townInfo = DISTRICT_TOWN_MAP[newDealerDistrict];
                          if (townInfo && townInfo.coords[val]) {
                            setNewDealerLat(townInfo.coords[val].lat);
                            setNewDealerLng(townInfo.coords[val].lng);
                          }
                        }}
                        placeholder="e.g. Monze Main Market Plot 14"
                        className="w-full p-2 border rounded-lg font-semibold bg-white"
                        required
                      />
                    </div>

                    {/* GPS Pin Map Picker Visual Component */}
                    <div className="p-3 bg-slate-50 rounded-xl border space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-bold uppercase text-slate-600 flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-rose-500" />
                          GPS Shop Location Coordinates
                        </span>
                        <span className="text-[9px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                          📍 GPS PIN LOCKED
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 font-mono text-xs">
                        <div>
                          <span className="text-[9px] text-slate-400 block uppercase">Latitude</span>
                          <input
                            type="number"
                            step="0.0001"
                            value={newDealerLat}
                            onChange={e => setNewDealerLat(Number(e.target.value))}
                            className="w-full p-1.5 border rounded font-bold bg-white"
                          />
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-400 block uppercase">Longitude</span>
                          <input
                            type="number"
                            step="0.0001"
                            value={newDealerLng}
                            onChange={e => setNewDealerLng(Number(e.target.value))}
                            className="w-full p-1.5 border rounded font-bold bg-white"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Delivery / Pickup Capability Flag */}
                    <div className="p-3 bg-slate-50 rounded-xl border flex items-center justify-between">
                      <div>
                        <span className="font-bold text-slate-800 text-xs block">Delivery Capability</span>
                        <span className="text-[10px] text-slate-500 block">Feeds marketplace distance & fulfillment display</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setNewDealerCanDeliver(!newDealerCanDeliver)}
                        className={`px-3 py-1.5 rounded-lg font-bold text-xs transition ${
                          newDealerCanDeliver ? "bg-emerald-600 text-white" : "bg-slate-200 text-slate-700"
                        }`}
                      >
                        {newDealerCanDeliver ? "🚚 Delivery + Pickup" : "🏪 Pickup Only"}
                      </button>
                    </div>
                  </div>

                  {/* Auto-Provisioning Callout */}
                  <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-[11px] text-blue-900 space-y-1">
                    <span className="font-bold uppercase text-[9px] text-blue-800 block">⚡ Auto-Provisioning & Default Security Credentials</span>
                    <p>• Role: <code className="font-mono font-bold">agro_dealer</code> | Initial Inventory: <code className="font-mono font-bold">[]</code> (Empty)</p>
                    <p>• 🔑 Default Login Password: <code className="bg-blue-100 text-blue-950 font-mono font-bold px-1 py-0.5 rounded">Mabala@2026</code> (User will be forced to change password at first login).</p>
                    <p>• CoA Default Sub-Accounts: 1100 (Cash/Mobile Money), 2100 (Consignment Payable), 4000 (Revenue), 5000 (COGS)</p>
                  </div>

                  <div className="pt-3 border-t flex justify-between items-center">
                    <button type="button" onClick={() => setCreateDealerStep(1)} className="px-4 py-2 bg-slate-100 font-bold rounded-xl text-slate-600">
                      ← Back to Details
                    </button>
                    <button type="submit" className="px-5 py-2 hover:bg-amber-700 bg-amber-600 font-extrabold text-white rounded-xl shadow-xs">
                      Provision Dealer Tenant
                    </button>
                  </div>
                </div>
              )}
            </form>
          </div>
        </div>
      )}

      {/* MODAL 6: WIZARD 3.2 - CREATE / UPGRADE SEED & CHEMICAL COMPANY */}
      {showCreateSupplierModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in overflow-y-auto">
          <div className="bg-white max-w-lg w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-slate-200 my-8">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <span className="text-[10px] font-black uppercase text-emerald-700 font-mono block">Super Admin Wizard 3.2</span>
                <h3 className="font-extrabold text-slate-900 text-sm">Seed & Chemical Supplier Capability Setup</h3>
              </div>
              <button type="button" onClick={() => setShowCreateSupplierModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mode Switcher */}
            <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold">
              <button
                type="button"
                onClick={() => setSupplierCreateMode("NEW")}
                className={`flex-1 py-1.5 rounded-lg transition ${supplierCreateMode === "NEW" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500"}`}
              >
                Create New Supplier Institution
              </button>
              <button
                type="button"
                onClick={() => setSupplierCreateMode("UPGRADE_EXISTING")}
                className={`flex-1 py-1.5 rounded-lg transition ${supplierCreateMode === "UPGRADE_EXISTING" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500"}`}
              >
                Upgrade Existing Institution
              </button>
            </div>

            <form onSubmit={handleCreateSupplierCompany} className="space-y-4 text-xs font-sans">
              {supplierCreateMode === "UPGRADE_EXISTING" ? (
                <div className="space-y-3">
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 text-xs">
                    ℹ️ <strong>Avoid Multi-Tenant Duplication:</strong> Adds the Supplier capability to an existing Institution tenant rather than creating duplicate records.
                  </div>

                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Select Institution to Upgrade</label>
                    <select
                      value={upgradeInstId}
                      onChange={e => setUpgradeInstId(e.target.value)}
                      className="w-full p-2.5 border rounded-xl mt-1 font-semibold bg-white"
                    >
                      <option value="">-- Select Institution --</option>
                      {suppliers.map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.registeredAddress})</option>
                      ))}
                    </select>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Company Name</label>
                    <input
                      type="text"
                      value={newSupplierName}
                      onChange={e => setNewSupplierName(e.target.value)}
                      placeholder="e.g. Syngenta Zambia Ltd"
                      className="w-full p-2.5 border rounded-xl mt-1 font-semibold"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <div className="flex justify-between items-center">
                        <label className="font-bold uppercase text-[10px] text-slate-500 block">PACRA / TPIN Number</label>
                        <span className="text-[9px] font-bold text-slate-400">Optional</span>
                      </div>
                      <input
                        type="text"
                        value={newSupplierPacra}
                        onChange={e => setNewSupplierPacra(e.target.value)}
                        placeholder="1009182736"
                        className="w-full p-2.5 border rounded-xl mt-1 font-mono font-bold"
                      />
                    </div>

                    <div>
                      <label className="font-bold uppercase text-[10px] text-slate-500 block">Registered Address</label>
                      <input
                        type="text"
                        value={newSupplierAddress}
                        onChange={e => setNewSupplierAddress(e.target.value)}
                        placeholder="Great East Road, Lusaka"
                        className="w-full p-2.5 border rounded-xl mt-1 font-semibold"
                      />
                    </div>
                  </div>

                  {/* Category Checkboxes */}
                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block mb-1">Distributed Product Categories</label>
                    <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl border">
                      {(["seed", "pesticide", "herbicide", "fungicide", "fertilizer"] as AgroCategory[]).map(cat => {
                        const isChecked = newSupplierCategories.includes(cat);
                        return (
                          <label key={cat} className="flex items-center gap-1.5 cursor-pointer font-medium capitalize text-slate-700">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={e => {
                                if (e.target.checked) {
                                  setNewSupplierCategories(prev => [...prev, cat]);
                                } else {
                                  setNewSupplierCategories(prev => prev.filter(c => c !== cat));
                                }
                              }}
                              className="rounded text-emerald-600"
                            />
                            <span>{cat}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  {/* Nominated Admin Contact Roster */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                    <div className="flex justify-between items-center border-b pb-2">
                      <span className="text-[10px] font-bold uppercase text-slate-700 block flex items-center gap-1">
                        👥 Nominated Institution Admin Staff ({nominatedStaffList.length})
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setNominatedStaffList(prev => [
                            ...prev,
                            { id: "staff-" + Date.now(), name: "", email: "", phone: "", role: "Staff", password: "", confirmPassword: "", permissions: "read_write" }
                          ]);
                        }}
                        className="text-[10px] font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-200 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>+ Add Staff Member</span>
                      </button>
                    </div>

                    <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                      {nominatedStaffList.map((staff, idx) => (
                        <div key={staff.id} className="p-3 bg-white rounded-xl border border-slate-200 space-y-2 relative">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-extrabold text-slate-700 uppercase">
                              Admin Staff Member #{idx + 1}
                            </span>
                            {nominatedStaffList.length > 1 && (
                              <button
                                type="button"
                                onClick={() => {
                                  setNominatedStaffList(prev => prev.filter(s => s.id !== staff.id));
                                }}
                                className="text-[9px] font-bold text-rose-600 hover:underline cursor-pointer"
                              >
                                Remove
                              </button>
                            )}
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                            <input
                              type="text"
                              placeholder="Full Name"
                              value={staff.name}
                              onChange={e => {
                                const val = e.target.value;
                                setNominatedStaffList(prev => prev.map(s => s.id === staff.id ? { ...s, name: val } : s));
                              }}
                              className="p-2 border rounded-lg font-semibold bg-white text-xs"
                              required
                            />
                            <input
                              type="email"
                              placeholder="Email (Login ID)"
                              value={staff.email}
                              onChange={e => {
                                const val = e.target.value;
                                setNominatedStaffList(prev => prev.map(s => s.id === staff.id ? { ...s, email: val } : s));
                              }}
                              className="p-2 border rounded-lg font-mono text-xs bg-white"
                              required
                            />
                            <input
                              type="text"
                              placeholder="Phone"
                              value={staff.phone}
                              onChange={e => {
                                const val = e.target.value;
                                setNominatedStaffList(prev => prev.map(s => s.id === staff.id ? { ...s, phone: val } : s));
                              }}
                              className="p-2 border rounded-lg font-mono text-xs bg-white"
                            />
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-slate-100">
                            <div>
                              <label className="text-[9px] font-bold uppercase text-slate-400 block">Set Login Password</label>
                              <input
                                type="password"
                                placeholder="Set Password (Default: Mabala@2026)"
                                value={staff.password}
                                onChange={e => {
                                  const val = e.target.value;
                                  setNominatedStaffList(prev => prev.map(s => s.id === staff.id ? { ...s, password: val } : s));
                                }}
                                className="w-full p-2 border rounded-lg font-mono text-xs bg-slate-50"
                              />
                            </div>
                            <div>
                              <label className="text-[9px] font-bold uppercase text-slate-400 block">Confirm Password</label>
                              <input
                                type="password"
                                placeholder="Confirm Password"
                                value={staff.confirmPassword}
                                onChange={e => {
                                  const val = e.target.value;
                                  setNominatedStaffList(prev => prev.map(s => s.id === staff.id ? { ...s, confirmPassword: val } : s));
                                }}
                                className="w-full p-2 border rounded-lg font-mono text-xs bg-slate-50"
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Auto-Provisioning Callout */}
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-900 space-y-1">
                <span className="font-bold uppercase text-[9px] text-emerald-800 block">⚡ Auto-Provisioning & Admin Security Credentials</span>
                <p>• Tenant Capability Added: <code className="font-mono font-bold">['institution', 'supplier']</code></p>
                <p>• 🔑 Credentials created for all nominated admin staff members above with 100 platform credits.</p>
                <p>• Initialized with empty <code className="font-mono font-bold">stockGrants</code> and dealer consignment ledger rollups.</p>
              </div>

              <div className="pt-3 border-t flex justify-end gap-2">
                <button type="button" onClick={() => setShowCreateSupplierModal(false)} className="px-4 py-2 bg-slate-100 font-bold rounded-xl text-slate-600">
                  Cancel
                </button>
                <button type="submit" className="px-5 py-2 hover:bg-emerald-800 bg-emerald-700 font-extrabold text-white rounded-xl shadow-xs">
                  {supplierCreateMode === "UPGRADE_EXISTING" ? "Attach Supplier Capability" : "Provision Seed Company"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 7: WIZARD 3.3 - CONSIGNMENT AGREEMENT INVITATION & LINKING */}
      {showAgreementModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in overflow-y-auto">
          <div className="bg-white max-w-lg w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-slate-200 my-8">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <span className="text-[10px] font-black uppercase text-blue-700 font-mono block">Super Admin Wizard 3.3</span>
                <h3 className="font-extrabold text-slate-900 text-sm">Create Consignment Agreement Link</h3>
              </div>
              <button type="button" onClick={() => setShowAgreementModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAgreementInvitation} className="space-y-4 text-xs font-sans">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Supplier Institution</label>
                  <select
                    value={agrSupplierId}
                    onChange={e => setAgrSupplierId(e.target.value)}
                    className="w-full p-2.5 border rounded-xl mt-1 font-semibold bg-white"
                  >
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Recipient Agro-Dealer</label>
                  <select
                    value={agrDealerId}
                    onChange={e => setAgrDealerId(e.target.value)}
                    className="w-full p-2.5 border rounded-xl mt-1 font-semibold bg-white"
                  >
                    {dealers.map(d => (
                      <option key={d.id} value={d.id}>{d.businessName} ({d.city})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Remittance Cycle (Days)</label>
                  <select
                    value={agrPeriodDays}
                    onChange={e => setAgrPeriodDays(Number(e.target.value))}
                    className="w-full p-2.5 border rounded-xl mt-1 font-semibold bg-white"
                  >
                    <option value={30}>30 Days Net Cycle</option>
                    <option value={60}>60 Days Net Cycle</option>
                    <option value={90}>90 Days Net Cycle</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Commission Bearer</label>
                  <select
                    value={agrCommissionBearer}
                    onChange={e => setAgrCommissionBearer(e.target.value as "agro_dealer" | "institution_supplier")}
                    className="w-full p-2.5 border rounded-xl mt-1 font-semibold bg-white"
                  >
                    <option value="institution_supplier">Institution Supplier</option>
                    <option value="agro_dealer">Agro-Dealer Retailer</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold uppercase text-[10px] text-slate-500 block">Consignment Credit Limit ({currencySymbol})</label>
                <input
                  type="number"
                  step="5000"
                  value={agrCreditLimit}
                  onChange={e => setAgrCreditLimit(Number(e.target.value))}
                  className="w-full p-2.5 border rounded-xl mt-1 font-mono font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="font-bold uppercase text-[10px] text-slate-500 block mb-1">Categories Covered</label>
                <div className="flex flex-wrap gap-2 bg-slate-50 p-2.5 rounded-xl border">
                  {(["seed", "pesticide", "herbicide", "fungicide", "fertilizer"] as AgroCategory[]).map(cat => {
                    const isChecked = agrCategories.includes(cat);
                    return (
                      <label key={cat} className="flex items-center gap-1.5 cursor-pointer font-medium capitalize text-slate-700">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={e => {
                            if (e.target.checked) {
                              setAgrCategories(prev => [...prev, cat]);
                            } else {
                              setAgrCategories(prev => prev.filter(c => c !== cat));
                            }
                          }}
                          className="rounded text-blue-600"
                        />
                        <span>{cat}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900 space-y-1">
                <span className="font-bold uppercase text-[9px] text-amber-800 block">📋 Status: Pending Dealer Acceptance</span>
                <p>• Invitation will be issued with <code className="font-mono font-bold">status: "pending"</code>.</p>
                <p>• Dealer accepts in-app to activate credit link and allow Stock Grant transfers.</p>
              </div>

              <div className="pt-3 border-t flex justify-end gap-2">
                <button type="button" onClick={() => setShowAgreementModal(false)} className="px-4 py-2 bg-slate-100 font-bold rounded-xl text-slate-600">
                  Cancel
                </button>
                <button type="submit" className="px-5 py-2 hover:bg-blue-800 bg-blue-700 font-extrabold text-white rounded-xl shadow-xs">
                  Issue Agreement Invitation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 8: RUN CONSIGNMENT RECONCILIATION */}
      {showReconcileModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in overflow-y-auto">
          <div className="bg-white max-w-lg w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-slate-200 my-8">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <span className="text-[10px] font-black uppercase text-emerald-700 font-mono block">Supplier Audit Center</span>
                <h3 className="font-extrabold text-slate-900 text-sm">Run Consignment Reconciliation Statement</h3>
              </div>
              <button type="button" onClick={() => setShowReconcileModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleExecuteReconciliation} className="space-y-4 text-xs font-sans">
              <div>
                <label className="font-bold uppercase text-[10px] text-slate-500 block">Select Target Agro-Dealer</label>
                <select
                  value={reconcileDealerId}
                  onChange={e => setReconcileDealerId(e.target.value)}
                  className="w-full p-2.5 border rounded-xl mt-1 font-semibold bg-white"
                >
                  {dealers.map(d => (
                    <option key={d.id} value={d.id}>{d.businessName} ({d.city})</option>
                  ))}
                </select>
              </div>

              {/* Real-time Computed Ledger Preview */}
              {(() => {
                const selectedDealer = dealers.find(d => d.id === reconcileDealerId);
                const dealerSales = movements
                  .filter(m => (m.type as any) === "SALE_OUT" || m.type === "sale")
                  .reduce((sum, m) => sum + (((m as any).unitPrice || 0) * ((m as any).qty || Math.abs(m.qtyDelta || 0))), 0);
                const dealerRemittances = reconciliations
                  .filter(r => r.dealerTenantId === reconcileDealerId)
                  .reduce((sum, r) => sum + r.totalRemittancesReceived, 0);
                const computedVariance = dealerSales - dealerRemittances;

                return (
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 font-mono">
                    <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                      <span className="text-[10px] uppercase font-bold text-slate-500">Selected Dealer:</span>
                      <strong className="text-slate-900 text-xs font-sans">{selectedDealer?.businessName || reconcileDealerId}</strong>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div>
                        <span className="text-[9px] text-slate-400 block uppercase">Recorded Movement Sales</span>
                        <strong className="text-slate-800">{currencySymbol} {dealerSales.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong>
                      </div>
                      <div>
                        <span className="text-[9px] text-slate-400 block uppercase">Total Remittances Received</span>
                        <strong className="text-emerald-800 font-bold">{currencySymbol} {dealerRemittances.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong>
                      </div>
                    </div>

                    <div className="p-2.5 bg-white rounded-xl border border-slate-200 flex justify-between items-center">
                      <span className="text-[10px] uppercase font-bold text-slate-500">Calculated Variance Balance:</span>
                      <strong className={`text-sm font-bold ${computedVariance > 0 ? "text-amber-700" : "text-emerald-700"}`}>
                        {currencySymbol} {computedVariance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </strong>
                    </div>
                  </div>
                );
              })()}

              <div>
                <label className="font-bold uppercase text-[10px] text-slate-500 block">Audit Notes & Remittance Observations</label>
                <textarea
                  value={reconcileNotes}
                  onChange={e => setReconcileNotes(e.target.value)}
                  placeholder="Enter audit verification notes or variance breakdown..."
                  className="w-full p-2.5 border rounded-xl mt-1 text-xs font-medium"
                  rows={2}
                />
              </div>

              <div className="pt-3 border-t flex justify-end gap-2">
                <button type="button" onClick={() => setShowReconcileModal(false)} className="px-4 py-2 bg-slate-100 font-bold rounded-xl text-slate-600">
                  Cancel
                </button>
                <button type="submit" className="px-5 py-2 hover:bg-emerald-800 bg-emerald-700 font-extrabold text-white rounded-xl shadow-xs">
                  Generate & Save Reconciliation Run
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 9: LIPILA POS PAYMENT GATEWAY */}
      {showLipilaPosModal && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white max-w-md w-full rounded-2xl p-6 space-y-5 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-center border-b pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-100 rounded-xl">
                  <Smartphone className="w-5 h-5 text-emerald-700" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">Lipila Payment Gateway</h3>
                  <p className="text-[10px] text-slate-500 font-mono">Mobile Money USSD Push Engine</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowLipilaPosModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Auto-detected Carrier Display */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 font-sans">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500 font-medium">Customer Mobile Number:</span>
                <strong className="font-mono text-slate-900 text-sm">{posCustomerPhone}</strong>
              </div>

              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500 font-medium">Network Provider (Auto-Detected):</span>
                <span className={`px-3 py-1 rounded-full text-xs font-black font-mono uppercase ${detectCarrier(posCustomerPhone).badgeBg}`}>
                  {detectCarrier(posCustomerPhone).name}
                </span>
              </div>

              <div className="flex justify-between items-center text-xs border-t pt-2 border-slate-200">
                <span className="text-slate-500 font-medium">Amount to Charge:</span>
                <strong className="font-mono text-base font-black text-emerald-800">
                  {currencySymbol} {posCart.reduce((sum, i) => sum + (i.sku.sellingPrice * i.qty), 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </strong>
              </div>
            </div>

            {/* Stepper Status */}
            {lipilaPosStep === "PROMPT" && (
              <div className="space-y-4">
                {isPosLipilaSubmitting ? (
                  <div className="p-5 bg-indigo-50 rounded-2xl border border-indigo-200 text-center space-y-3">
                    <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin mx-auto" />
                    <h4 className="font-black text-indigo-900 text-xs">Sending Lipila Payment Request...</h4>
                    <p className="text-[11px] text-indigo-800 leading-relaxed">
                      Pushing USSD payment prompt to <strong>{posCustomerPhone}</strong> via Lipila Production API...
                    </p>
                  </div>
                ) : posLipilaError ? (
                  <div className="p-4 bg-rose-50 rounded-2xl border border-rose-200 space-y-3 text-center">
                    <AlertTriangle className="w-8 h-8 text-rose-600 mx-auto" />
                    <h4 className="font-black text-rose-900 text-xs">Payment Authorization Failed</h4>
                    <p className="text-[11px] text-rose-800 leading-relaxed font-medium">
                      ⚠️ {posLipilaError}
                    </p>

                    {isEditingPosPhone ? (
                      <div className="pt-2 space-y-2 text-left">
                        <label className="text-[10px] font-bold text-slate-700 uppercase tracking-wider">Provide New Mobile Number:</label>
                        <input
                          type="tel"
                          value={posPhoneInput}
                          onChange={(e) => setPosPhoneInput(e.target.value)}
                          placeholder="e.g. 0971234567"
                          className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-mono focus:ring-2 focus:ring-emerald-500 outline-none"
                        />
                        <div className="flex gap-2 pt-1">
                          <button
                            type="button"
                            onClick={() => initiateLipilaPosPayment(posPhoneInput)}
                            className="flex-1 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs rounded-xl shadow-xs transition"
                          >
                            Submit & Push PIN
                          </button>
                          <button
                            type="button"
                            onClick={() => setIsEditingPosPhone(false)}
                            className="px-3 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => initiateLipilaPosPayment(posCustomerPhone)}
                          className="flex-1 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>Retry Payment</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setPosPhoneInput(posCustomerPhone);
                            setIsEditingPosPhone(true);
                          }}
                          className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <Smartphone className="w-3.5 h-3.5" />
                          <span>Change Mobile Number</span>
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 space-y-3 text-center">
                    <RefreshCw className="w-8 h-8 text-amber-600 animate-spin mx-auto" />
                    <h4 className="font-black text-amber-900 text-xs">Awaiting USSD PIN Confirmation...</h4>
                    <p className="text-[11px] text-amber-800 leading-relaxed">
                      A payment prompt has been pushed via the Lipila Production API to <strong>{posCustomerPhone}</strong> on the <strong>{detectCarrier(posCustomerPhone).name}</strong> network.
                    </p>
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-200/60 rounded-full text-amber-900 text-xs font-mono font-bold">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Time Remaining: {Math.floor(posLipilaTimeRemaining / 60)}m {(posLipilaTimeRemaining % 60).toString().padStart(2, "0")}s</span>
                    </div>

                    <div className="pt-2 flex flex-col gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          if (!lipilaPosTxId) return;
                          try {
                            const res = await safeFetchJsonClient(`/api/payments/check-status?referenceId=${lipilaPosTxId}`);
                            if (res && (res.status === "Successful" || res.status === "Success" || res.status === "Completed")) {
                              setLipilaPosStep("SUCCESS");
                              showToast("Lipila payment verified!", "success");
                            } else {
                              showToast(res?.message || "Payment status still pending. Please authorize prompt on phone.", "info");
                            }
                          } catch (err) {
                            showToast("Unable to verify payment status at this moment.", "error");
                          }
                        }}
                        className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Check Payment Status Now</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setPosPhoneInput(posCustomerPhone);
                          setIsEditingPosPhone(true);
                          setPosLipilaError("User requested mobile number modification.");
                        }}
                        className="text-[11px] text-slate-600 hover:text-slate-900 font-bold underline cursor-pointer"
                      >
                        Change Customer Mobile Number
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {lipilaPosStep === "SUCCESS" && (
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-3 text-center">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                <h4 className="font-black text-emerald-900 text-sm">Payment Pushed & Verified!</h4>
                <p className="text-[11px] text-emerald-800">
                  Transaction ref: <code className="font-mono font-bold">{lipilaPosTxId || `LIP-${Math.floor(Math.random()*900000+100000)}`}</code>
                </p>
                <button
                  type="button"
                  onClick={() => {
                    const carrier = detectCarrier(posCustomerPhone);
                    finalizePosSale(lipilaPosTxId, carrier.name);
                    setShowLipilaPosModal(false);
                  }}
                  className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Finalize POS Sale & Deduct Inventory</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL 10: FARM BALANCE MULTI-USE WALLET & DISBURSEMENT CENTER */}
      {showFarmBalanceModal && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in overflow-y-auto">
          <div className="bg-white max-w-xl w-full rounded-2xl p-6 space-y-5 shadow-2xl border border-slate-200 my-8">
            <div className="flex justify-between items-center border-b pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-100 rounded-2xl">
                  <Wallet className="w-6 h-6 text-emerald-700" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-base">Farm Balance Multi-Use Wallet</h3>
                  <div className="flex items-center gap-2 mt-0.5">
                    <p className="text-xs text-slate-500 font-mono">
                      Available Balance: <strong className="text-emerald-700">{currencySymbol} {dealerBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong>
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setDealerBalance(0);
                        setSupplierBalance(0);
                        localStorage.setItem("mabala_agd_dealer_balance", "0");
                        localStorage.setItem("mabala_agd_supplier_balance", "0");
                        showToast("All farm balance wallets zero-rated to ZK 0.00!");
                      }}
                      className="px-2 py-0.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[10px] font-mono font-bold rounded-md transition cursor-pointer"
                    >
                      Zero-Rate Balance (ZK 0.00)
                    </button>
                  </div>
                </div>
              </div>
              <button type="button" onClick={() => setShowFarmBalanceModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Farm Balance Action Tabs */}
            <div className="grid grid-cols-4 gap-1.5 bg-slate-100 p-1.5 rounded-xl text-[11px] font-bold">
              <button
                type="button"
                onClick={() => setFarmBalanceTab("DISBURSE")}
                className={`py-2 rounded-lg transition ${farmBalanceTab === "DISBURSE" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500"}`}
              >
                Disburse Mobile
              </button>
              <button
                type="button"
                onClick={() => setFarmBalanceTab("PAYROLL")}
                className={`py-2 rounded-lg transition ${farmBalanceTab === "PAYROLL" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500"}`}
              >
                Worker Payroll
              </button>
              <button
                type="button"
                onClick={() => setFarmBalanceTab("SUBSCRIPTION")}
                className={`py-2 rounded-lg transition ${farmBalanceTab === "SUBSCRIPTION" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500"}`}
              >
                Subscription
              </button>
              <button
                type="button"
                onClick={() => setFarmBalanceTab("CREDITS")}
                className={`py-2 rounded-lg transition ${farmBalanceTab === "CREDITS" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500"}`}
              >
                Platform Credits
              </button>
            </div>

            {/* TAB 1: DISBURSE TO MOBILE MONEY */}
            {farmBalanceTab === "DISBURSE" && (
              <form onSubmit={handleFarmBalanceDisburse} className="space-y-4 text-xs font-sans">
                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Recipient Mobile Number</label>
                  <input
                    type="text"
                    required
                    value={disbursePhone}
                    onChange={e => setDisbursePhone(e.target.value)}
                    placeholder="+26097..."
                    className="w-full p-2.5 border rounded-xl mt-1 font-mono font-bold"
                  />
                  {disbursePhone && disbursePhone.trim().length >= 3 && (
                    <div className="mt-1 flex items-center gap-1.5 text-[10px] font-bold">
                      <span className="text-slate-400">Lipila Auto-Detected Carrier:</span>
                      <span className={`px-2 py-0.5 rounded font-mono uppercase ${detectCarrier(disbursePhone).badgeBg}`}>
                        {detectCarrier(disbursePhone).name}
                      </span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Recipient Name</label>
                    <input
                      type="text"
                      required
                      value={disburseName}
                      onChange={e => setDisburseName(e.target.value)}
                      placeholder="e.g. John Banda"
                      className="w-full p-2.5 border rounded-xl mt-1 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Amount ({currencySymbol})</label>
                    <input
                      type="number"
                      required
                      min={1}
                      max={dealerBalance}
                      value={disburseAmount}
                      onChange={e => setDisburseAmount(Number(e.target.value))}
                      className="w-full p-2.5 border rounded-xl mt-1 font-mono font-bold text-emerald-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Transfer Reason / Reference</label>
                  <input
                    type="text"
                    value={disburseReason}
                    onChange={e => setDisburseReason(e.target.value)}
                    placeholder="e.g. In-field crop procurement payment"
                    className="w-full p-2.5 border rounded-xl mt-1 font-medium"
                  />
                </div>

                {/* Part G Fee Schedule Itemized Breakdown Card */}
                {disburseAmount > 0 && (() => {
                  const feeInfo = calculateDisbursementFees(disburseAmount);
                  return (
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
                      <span className="text-[10px] font-black uppercase text-slate-400 block tracking-wider">Itemized Payout & Fee Schedule</span>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Requested Payout Amount:</span>
                        <span className="font-mono font-bold text-slate-900">{currencySymbol} {feeInfo.requestedAmount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Lipila Tiered Gateway Fee:</span>
                        <span className="font-mono font-semibold">{currencySymbol} {feeInfo.lipilaFee.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Mabala Platform Fee (3.5%):</span>
                        <span className="font-mono font-semibold">{currencySymbol} {feeInfo.platformFee3Point5.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between border-t border-slate-200 pt-2 font-bold text-slate-900">
                        <span>Total Deducted from Wallet:</span>
                        <span className="font-mono text-emerald-700">{currencySymbol} {feeInfo.totalDeductedFromWallet.toLocaleString()}</span>
                      </div>
                    </div>
                  );
                })()}

                <button type="submit" className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow-md transition cursor-pointer">
                  Disburse Funds via Lipila API →
                </button>
              </form>
            )}

            {/* TAB 2: WORKER SALARY PAYROLL */}
            {farmBalanceTab === "PAYROLL" && (
              <form onSubmit={handleFarmBalancePayroll} className="space-y-4 text-xs font-sans">
                <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-blue-900 text-[11px] space-y-1">
                  <div className="flex items-center gap-1.5 font-bold">
                    <Zap className="w-3.5 h-3.5 text-blue-700" />
                    <span>Shop Worker Payroll Engine (Lipila Production API Enabled):</span>
                  </div>
                  <p>Disburse monthly wages directly from your Farm Balance to shop hands or warehouse workers via Lipila Production Gateway.</p>
                </div>

                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Select Worker from Farm Node Payroll</label>
                  <select
                    value={selectedWorkerId}
                    onChange={e => handleSelectPayrollWorker(e.target.value)}
                    className="w-full p-2.5 border rounded-xl mt-1 font-semibold text-slate-800 bg-white focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="">-- Pick worker from active Farm Node Payroll list --</option>
                    {farmWorkers.map(w => (
                      <option key={w.id} value={w.id}>
                        {w.name} — {w.role} ({currencySymbol} {w.salary.toLocaleString()}) — {w.phone}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Worker Name</label>
                    <input
                      type="text"
                      required
                      value={payrollWorkerName}
                      onChange={e => setPayrollWorkerName(e.target.value)}
                      placeholder="Worker Full Name"
                      className="w-full p-2.5 border rounded-xl mt-1 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="font-bold uppercase text-[10px] text-slate-500 block">Worker Mobile Phone (Auto-Picked)</label>
                    <input
                      type="text"
                      required
                      value={payrollPhone}
                      onChange={e => setPayrollPhone(e.target.value)}
                      placeholder="+2609..."
                      className="w-full p-2.5 border rounded-xl mt-1 font-mono font-bold text-emerald-900 bg-emerald-50/50"
                    />
                  </div>
                </div>

                {payrollPhone && (
                  <div className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-[10.5px] flex items-center justify-between">
                    <span className="text-slate-500">Auto-picked mobile number configured on payroll:</span>
                    <span className="font-mono font-bold text-slate-800">{payrollPhone} ({detectCarrier(payrollPhone).name})</span>
                  </div>
                )}

                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-500 block">Salary Amount ({currencySymbol})</label>
                  <input
                    type="number"
                    required
                    min={10}
                    max={dealerBalance}
                    value={payrollAmount}
                    onChange={e => setPayrollAmount(Number(e.target.value))}
                    className="w-full p-2.5 border rounded-xl mt-1 font-mono font-bold text-emerald-800"
                  />
                </div>

                <button type="submit" className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-2">
                  <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
                  <span>Process Worker Salary Disbursement via Lipila Production API →</span>
                </button>
              </form>
            )}

            {/* TAB 3: MABALA PLATFORM SUBSCRIPTION */}
            {farmBalanceTab === "SUBSCRIPTION" && (
              <div className="space-y-4 text-xs font-sans">
                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-2 text-emerald-950">
                  <h4 className="font-black text-xs uppercase tracking-wider text-emerald-800">Mabala Agro-Dealer SaaS Subscription</h4>
                  <p className="text-[11px]">Pay your monthly or annual platform access subscription directly from accrued sales in your Farm Balance.</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => handleFarmBalanceSubscription("MONTHLY")}
                    className="p-4 rounded-xl border-2 border-slate-200 hover:border-emerald-600 bg-slate-50 hover:bg-emerald-50 text-left transition space-y-2 cursor-pointer"
                  >
                    <span className="font-black text-slate-900 block text-xs">Monthly Retail Plan</span>
                    <strong className="text-emerald-800 font-mono text-base block">{currencySymbol} 180 / mo</strong>
                    <span className="text-[10px] text-slate-500 block">Renew 30-day POS & Consignment access</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleFarmBalanceSubscription("ANNUAL")}
                    className="p-4 rounded-xl border-2 border-emerald-300 bg-emerald-50 text-left transition space-y-2 cursor-pointer relative overflow-hidden"
                  >
                    <span className="bg-emerald-700 text-white text-[9px] font-black px-2 py-0.5 rounded uppercase absolute top-2 right-2">SAVE 20%</span>
                    <span className="font-black text-emerald-950 block text-xs">Annual Enterprise Plan</span>
                    <strong className="text-emerald-800 font-mono text-base block">{currencySymbol} 2,160 / yr</strong>
                    <span className="text-[10px] text-emerald-700 block">Full 365-day access + priority support</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB 4: PLATFORM CREDITS TOPUP */}
            {farmBalanceTab === "CREDITS" && (
              <div className="space-y-4 text-xs font-sans">
                <div className="p-4 bg-purple-50 rounded-2xl border border-purple-200 space-y-2 text-purple-950">
                  <h4 className="font-black text-xs uppercase tracking-wider text-purple-800">AI Agronomist & SMS Alert Credits</h4>
                  <p className="text-[11px]">Top up your Mabala platform communication and AI crop diagnosis credits using your Farm Balance.</p>
                </div>

                <div className="p-4 bg-white rounded-xl border border-slate-200 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-800">100 Platform Credits Package</span>
                    <strong className="font-mono text-purple-800 font-bold">{currencySymbol} 50.00</strong>
                  </div>
                  <p className="text-[10px] text-slate-500">Includes 100 SMS notifications to local farmers & AI Agronomist diagnostic runs.</p>

                  <button
                    type="button"
                    onClick={() => {
                      if (dealerBalance < 50) {
                        alert("Insufficient Farm Balance to top up credits.");
                        return;
                      }
                      setDealerBalance(prev => prev - 50);
                      showToast(`Top-up successful! 100 platform credits added to your Mabala account.`);
                      setShowFarmBalanceModal(false);
                    }}
                    className="w-full py-3 bg-purple-700 hover:bg-purple-800 text-white font-extrabold text-xs rounded-xl shadow-md transition cursor-pointer"
                  >
                    Top Up 100 Credits (ZMW 50) →
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      {/* MODAL 11: LIPILA PRODUCTION PAYMENT LINK MODAL */}
      {showLipilaLinkModal && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-slate-900 text-white max-w-md w-full rounded-3xl p-6 space-y-5 shadow-2xl border border-slate-700">
            <div className="flex justify-between items-center border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <h3 className="font-black text-white text-sm">Lipila Production Payment Link Terminal</h3>
              </div>
              <button type="button" onClick={() => setShowLipilaLinkModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {linkPayStatus === "IDLE" && (
              <form onSubmit={handleExecuteLipilaLinkPayment} className="space-y-4 text-xs">
                <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-[9.5px] uppercase font-bold text-emerald-400">Payment Link Payload:</span>
                  <h4 className="font-bold text-white text-sm">{linkPayTitle}</h4>
                  <div className="flex justify-between items-center pt-2 font-mono">
                    <span className="text-slate-400 text-[11px]">Link ID: {activeDealer.lipilaPaymentLinkId}</span>
                    <strong className="text-emerald-400 text-base">{currencySymbol} {linkPayAmount.toLocaleString()}</strong>
                  </div>
                </div>

                <div>
                  <label className="font-bold uppercase text-[10px] text-slate-400 block pb-1">Mobile Money Number</label>
                  <input
                    type="text"
                    required
                    value={linkPayPhone}
                    onChange={e => setLinkPayPhone(e.target.value)}
                    placeholder="+2609..."
                    className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl font-mono font-bold text-white outline-none focus:border-emerald-500"
                  />
                  <span className="text-[10px] text-slate-400 block mt-1">
                    Auto-Detected: <strong className="text-white">{detectCarrier(linkPayPhone).name}</strong>
                  </span>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
                  <span>Execute Payment via Lipila Production API ({currencySymbol} {linkPayAmount})</span>
                </button>
              </form>
            )}

            {linkPayStatus === "PROCESSING" && (
              <div className="py-8 text-center space-y-4 text-xs">
                <div className="w-12 h-12 border-4 border-emerald-500/30 border-t-emerald-500 rounded-full animate-spin mx-auto" />
                <h4 className="font-extrabold text-emerald-400 uppercase tracking-wider">Connecting Lipila Production Gateway...</h4>
                <p className="text-slate-400 text-[11px]">Processing payment link transfer via production endpoint `https://blz.lipila.io/api/v1/collections/mobile-money`.</p>
              </div>
            )}

            {linkPayStatus === "SUCCESS" && (
              <div className="py-6 text-center space-y-4 text-xs">
                <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto text-2xl font-black">
                  ✓
                </div>
                <h4 className="font-extrabold text-white text-base">Payment Completed Successfully!</h4>
                <p className="text-slate-400 text-[11px]">Lipila Production API cleared ZMW {linkPayAmount} settlement from {linkPayPhone}.</p>
                <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-left font-mono text-[10px] text-slate-300 space-y-1">
                  <div>Ref ID: <span className="text-white font-bold">{linkPayRef}</span></div>
                  <div>Gateway: Lipila Live Production (200 OK)</div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowLipilaLinkModal(false)}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl"
                >
                  Close Terminal
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* GLOBAL CONFIRMATION STATEMENT MODAL FOR SUSPENSION AND DELETION */}
      {confirmModalState?.isOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white max-w-md w-full rounded-2xl p-6 space-y-4 shadow-2xl border border-slate-200">
            <div className="flex items-center gap-3 text-rose-600 border-b border-slate-100 pb-3">
              <div className="p-2.5 bg-rose-100 rounded-xl">
                <AlertTriangle className="w-6 h-6 text-rose-600" />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-900 text-sm">
                  {confirmModalState.type.startsWith("suspend")
                    ? (confirmModalState.isCurrentlySuspended ? "Confirm Reactivation" : "Confirm Account Suspension")
                    : "Confirm Account Deletion"}
                </h3>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide block">
                  Administrative Confirmation Required
                </span>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-600">
              <p className="font-semibold text-slate-800">
                Target Entity: <strong className="text-slate-950 font-black">{confirmModalState.name}</strong>
              </p>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-1 text-amber-900">
                <span className="text-[10px] uppercase font-extrabold block text-amber-800">Confirmation Statement:</span>
                <p className="leading-relaxed">
                  {confirmModalState.type.startsWith("suspend") ? (
                    confirmModalState.isCurrentlySuspended
                      ? `Reactivating this account will restore full operational status and clear suspended restrictions for "${confirmModalState.name}".`
                      : `Suspending this account will immediately revoke workspace write permissions, halt automated POS syncing, and restrict tenant access for "${confirmModalState.name}".`
                  ) : (
                    `Permanently deleting "${confirmModalState.name}" will purge all entity records, ledger links, and credentials from the platform. This action CANNOT be reversed.`
                  )}
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 text-xs font-bold">
              <button
                type="button"
                onClick={() => setConfirmModalState(null)}
                className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  const { type, id } = confirmModalState;
                  setConfirmModalState(null);
                  if (type === "suspend_dealer") executeToggleSuspendDealer(id);
                  else if (type === "delete_dealer") executeDeleteDealer(id);
                  else if (type === "suspend_supplier") executeToggleSuspendSupplier(id);
                  else if (type === "delete_supplier") executeDeleteSupplier(id);
                  else if (type === "suspend_agreement") executeToggleSuspendAgreement(id);
                  else if (type === "delete_agreement") executeDeleteAgreement(id);
                }}
                className={`px-4 py-2 text-white rounded-xl shadow-md transition cursor-pointer font-extrabold ${
                  confirmModalState.type.startsWith("delete")
                    ? "bg-rose-600 hover:bg-rose-700"
                    : confirmModalState.isCurrentlySuspended
                    ? "bg-emerald-600 hover:bg-emerald-700"
                    : "bg-amber-600 hover:bg-amber-700"
                }`}
              >
                {confirmModalState.type.startsWith("suspend")
                  ? (confirmModalState.isCurrentlySuspended ? "Confirm Reactivation" : "Confirm Suspension")
                  : "Confirm Permanent Deletion"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

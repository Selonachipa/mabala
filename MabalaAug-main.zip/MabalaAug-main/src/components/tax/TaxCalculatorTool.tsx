import React, { useState, useEffect } from "react";
import { 
  Calculator, 
  Percent, 
  HelpCircle, 
  Check, 
  ArrowRight, 
  Building2, 
  Sparkles, 
  RotateCcw,
  BookOpen,
  Receipt,
  X,
  Layers,
  ArrowDownUp
} from "lucide-react";
import { Farm } from "../../types";
import { getStatutoryTaxConfig, subscribeTaxConfig } from "../../services/taxConfigService";

export interface TaxCalculationResult {
  taxSystem: "VAT" | "Turnover Tax" | "Sales Tax" | "None" | "Custom";
  taxRate: number;
  subtotal: number;
  taxAmount: number;
  total: number;
  calculationMode: "exclusive" | "inclusive";
  notes?: string;
}

interface TaxCalculatorToolProps {
  activeFarm?: Farm | any;
  currencySymbol?: string;
  isOpen?: boolean;
  onClose?: () => void;
  onApplyTax?: (result: TaxCalculationResult) => void;
  initialAmount?: number;
  targetModule?: "invoicing" | "expenses" | "general";
  isInline?: boolean;
}

export default function TaxCalculatorTool({
  activeFarm,
  currencySymbol = "ZK",
  isOpen = true,
  onClose,
  onApplyTax,
  initialAmount = 0,
  targetModule = "general",
  isInline = false
}: TaxCalculatorToolProps) {
  // Determine default tax regime from active farm node
  const farmTaxSystem = activeFarm?.taxSystem || "VAT";
  const [selectedSystem, setSelectedSystem] = useState<"VAT" | "Turnover Tax" | "Sales Tax" | "None" | "Custom">(() => {
    if (farmTaxSystem === "Turnover Tax") return "Turnover Tax";
    if (farmTaxSystem === "Sales Tax") return "Sales Tax";
    if (farmTaxSystem === "None") return "None";
    return "VAT";
  });

  const [statTaxConfig, setStatTaxConfig] = useState(() => getStatutoryTaxConfig());
  const [inputAmount, setInputAmount] = useState<number>(initialAmount || 1000);
  const [calculationMode, setCalculationMode] = useState<"exclusive" | "inclusive">("exclusive");
  const [customRate, setCustomRate] = useState<number>(16);

  useEffect(() => {
    const unsub = subscribeTaxConfig((latest) => {
      setStatTaxConfig(latest);
    });
    return unsub;
  }, []);

  // Update whenever activeFarm changes
  useEffect(() => {
    if (activeFarm?.taxSystem) {
      if (activeFarm.taxSystem === "Turnover Tax") setSelectedSystem("Turnover Tax");
      else if (activeFarm.taxSystem === "Sales Tax") setSelectedSystem("Sales Tax");
      else if (activeFarm.taxSystem === "None") setSelectedSystem("None");
      else setSelectedSystem("VAT");
    }
    if (activeFarm?.customTaxRate) {
      setCustomRate(activeFarm.customTaxRate);
    }
  }, [activeFarm]);

  // Determine active tax rate percentage
  const effectiveRate = React.useMemo(() => {
    switch (selectedSystem) {
      case "VAT":
        return statTaxConfig.vatRate || 16.0;
      case "Turnover Tax":
        return statTaxConfig.totRate || 5.0;
      case "Sales Tax":
        return statTaxConfig.salesTaxRate || 5.0;
      case "None":
        return 0;
      case "Custom":
        return customRate;
      default:
        return 16.0;
    }
  }, [selectedSystem, statTaxConfig, customRate]);

  // Calculations
  const calculations = React.useMemo(() => {
    const rawVal = Number(inputAmount) || 0;
    const rateDecimal = effectiveRate / 100;

    if (calculationMode === "exclusive") {
      // Input is pre-tax Net Subtotal
      const subtotal = rawVal;
      const taxAmount = subtotal * rateDecimal;
      const total = subtotal + taxAmount;
      return {
        subtotal,
        taxAmount,
        total,
        effectiveRate
      };
    } else {
      // Input is gross total inclusive of tax (Reverse Tax Calculation)
      const total = rawVal;
      const subtotal = rateDecimal > 0 ? total / (1 + rateDecimal) : total;
      const taxAmount = total - subtotal;
      return {
        subtotal,
        taxAmount,
        total,
        effectiveRate
      };
    }
  }, [inputAmount, effectiveRate, calculationMode]);

  const handleApply = () => {
    if (onApplyTax) {
      onApplyTax({
        taxSystem: selectedSystem,
        taxRate: effectiveRate,
        subtotal: Number(calculations.subtotal.toFixed(2)),
        taxAmount: Number(calculations.taxAmount.toFixed(2)),
        total: Number(calculations.total.toFixed(2)),
        calculationMode,
        notes: `Computed via Farm Node Tax Calculator (${selectedSystem} @ ${effectiveRate}%)`
      });
    }
    if (onClose) onClose();
  };

  const content = (
    <div className="space-y-4 text-xs select-none">
      {/* Active Farm Node Tax System Header */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-800 text-white flex items-center justify-between shadow-xs">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-black text-xs text-white">
              {activeFarm?.name || "Active Farm Node"}
            </span>
          </div>
          <p className="text-[11px] text-slate-300">
            Node Tax Setting: <strong className="text-emerald-400 font-mono uppercase">{farmTaxSystem}</strong> ({farmTaxSystem === "Turnover Tax" ? "5.0% TOT" : farmTaxSystem === "VAT" ? "16.0% VAT" : "Tax Exempt"})
          </p>
        </div>

        <div className="text-right font-mono">
          <span className="text-[10px] text-slate-400 block uppercase">Default Rate</span>
          <span className="text-sm font-black text-emerald-400">{effectiveRate}%</span>
        </div>
      </div>

      {/* Tax Regime Selector Buttons */}
      <div className="space-y-1.5">
        <label className="text-[10.5px] font-black uppercase text-slate-500 tracking-wider block font-mono">
          Select Tax System / Regime
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            type="button"
            onClick={() => setSelectedSystem("VAT")}
            className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
              selectedSystem === "VAT"
                ? "bg-emerald-50 border-emerald-500 text-emerald-900 shadow-xs ring-1 ring-emerald-400"
                : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
            }`}
          >
            <div className="flex justify-between items-center">
              <span className="font-bold text-xs">Standard VAT</span>
              <span className="font-black font-mono text-emerald-700">{statTaxConfig.vatRate}%</span>
            </div>
            <span className="text-[10px] text-slate-500 block leading-tight mt-0.5">ZRA Standard 16% Output/Input</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedSystem("Turnover Tax")}
            className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
              selectedSystem === "Turnover Tax"
                ? "bg-amber-50 border-amber-500 text-amber-900 shadow-xs ring-1 ring-amber-400"
                : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
            }`}
          >
            <div className="flex justify-between items-center">
              <span className="font-bold text-xs">Turnover Tax</span>
              <span className="font-black font-mono text-amber-700">{statTaxConfig.totRate}%</span>
            </div>
            <span className="text-[10px] text-slate-500 block leading-tight mt-0.5">ZRA Section 64B Flat 5% TOT</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedSystem("None")}
            className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
              selectedSystem === "None"
                ? "bg-slate-100 border-slate-500 text-slate-900 shadow-xs ring-1 ring-slate-400"
                : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
            }`}
          >
            <div className="flex justify-between items-center">
              <span className="font-bold text-xs">Zero-Rated</span>
              <span className="font-black font-mono text-slate-700">0%</span>
            </div>
            <span className="text-[10px] text-slate-500 block leading-tight mt-0.5">Exempt Agricultural Produce</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedSystem("Custom")}
            className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
              selectedSystem === "Custom"
                ? "bg-indigo-50 border-indigo-500 text-indigo-900 shadow-xs ring-1 ring-indigo-400"
                : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
            }`}
          >
            <div className="flex justify-between items-center">
              <span className="font-bold text-xs">Custom Rate</span>
              <span className="font-black font-mono text-indigo-700">{customRate}%</span>
            </div>
            <span className="text-[10px] text-slate-500 block leading-tight mt-0.5">Override Specific Percentage</span>
          </button>
        </div>

        {selectedSystem === "Custom" && (
          <div className="mt-2 p-3 bg-indigo-50/60 rounded-xl border border-indigo-200 flex items-center gap-3">
            <span className="text-xs font-bold text-indigo-900">Custom Tax Rate:</span>
            <div className="flex items-center gap-1 bg-white border border-indigo-300 rounded-lg px-2 py-1">
              <input
                type="number"
                value={customRate}
                onChange={(e) => setCustomRate(Math.max(0, Number(e.target.value)))}
                className="w-16 text-xs font-black font-mono text-slate-800 outline-none"
                min="0"
                max="100"
                step="0.1"
              />
              <span className="text-slate-400 font-bold font-mono text-xs">%</span>
            </div>
          </div>
        )}
      </div>

      {/* Mode & Base Input */}
      <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-[10.5px] font-black uppercase text-slate-600 font-mono tracking-wider">
            Calculation Direction
          </label>
          <div className="flex bg-white rounded-xl p-0.5 border border-slate-200 shadow-2xs">
            <button
              type="button"
              onClick={() => setCalculationMode("exclusive")}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                calculationMode === "exclusive"
                  ? "bg-slate-900 text-white shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              Tax Exclusive (Net + Tax)
            </button>
            <button
              type="button"
              onClick={() => setCalculationMode("inclusive")}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                calculationMode === "inclusive"
                  ? "bg-slate-900 text-white shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              Tax Inclusive (Reverse / Extract)
            </button>
          </div>
        </div>

        <div>
          <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
            {calculationMode === "exclusive" ? `Pre-Tax Net Amount (${currencySymbol})` : `Gross Total Amount (${currencySymbol})`}
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400 font-mono">
              {currencySymbol}
            </span>
            <input
              type="number"
              value={inputAmount}
              onChange={(e) => setInputAmount(Math.max(0, Number(e.target.value)))}
              className="w-full bg-white border border-slate-300 rounded-xl pl-12 pr-4 py-2.5 font-mono text-base font-black text-slate-900 focus:border-emerald-500 outline-none shadow-2xs"
              placeholder="0.00"
              min="0"
              step="any"
            />
          </div>
        </div>
      </div>

      {/* COMPUTED BREAKDOWN CARD */}
      <div className="p-4 rounded-2xl border border-emerald-200 bg-emerald-50/50 space-y-2.5 font-mono">
        <div className="flex items-center justify-between text-xs pb-1 border-b border-emerald-200/80">
          <span className="font-bold text-slate-600 font-sans">Subtotal (Excl. Tax):</span>
          <span className="font-black text-slate-900 text-sm">
            {currencySymbol} {calculations.subtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>

        <div className="flex items-center justify-between text-xs pb-1 border-b border-emerald-200/80">
          <div className="flex items-center gap-1 font-sans">
            <span className="font-bold text-emerald-800">
              {selectedSystem === "VAT" ? "ZRA Output/Input VAT" : selectedSystem === "Turnover Tax" ? "Turnover Tax (TOT)" : "Tax Charge"} ({effectiveRate}%):
            </span>
          </div>
          <span className="font-black text-emerald-700 text-sm">
            {currencySymbol} {calculations.taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>

        <div className="flex items-center justify-between text-sm pt-1">
          <span className="font-black text-slate-900 font-sans">Total Transaction Value:</span>
          <span className="font-black text-emerald-900 text-base">
            {currencySymbol} {calculations.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
      </div>

      {/* Accounting & Statutory Notes */}
      <div className="p-3 bg-slate-100/80 rounded-xl text-[11px] text-slate-600 space-y-1">
        <div className="font-bold text-slate-800 flex items-center gap-1 font-sans">
          <Receipt className="w-3.5 h-3.5 text-slate-500" />
          <span>Statutory Compliance & Chart of Accounts Posting:</span>
        </div>
        <p className="leading-relaxed">
          {targetModule === "expenses" ? (
            selectedSystem === "VAT" 
              ? "Expenses: Dr 5000 (Expense Account) + Dr 1180 (Input VAT Claimable) • Cr 1010/1020 (Cash/Bank)." 
              : "Expenses: Dr 5000 (Full Gross Cost) • Cr 1010 (Cash/Bank)."
          ) : (
            selectedSystem === "VAT"
              ? "Invoicing: Dr 1100 (Accounts Receivable) • Cr 4000 (Sales Revenue) + Cr 2070 (Output VAT Liability)."
              : selectedSystem === "Turnover Tax"
              ? "Invoicing: Dr 1100 (Receivables) • Cr 4000 (Sales) + Monthly 5% TOT Payable to ZRA [2080]."
              : "Invoicing: Dr 1100 (Receivables) • Cr 4000 (Zero-Rated Farm Revenue)."
          )}
        </p>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-700 transition cursor-pointer"
          >
            Cancel
          </button>
        )}
        {onApplyTax && (
          <button
            type="button"
            onClick={handleApply}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer inline-flex items-center gap-1.5"
          >
            <Check className="w-4 h-4 text-emerald-200" />
            <span>Apply Calculated Tax ({effectiveRate}%)</span>
          </button>
        )}
      </div>
    </div>
  );

  if (isInline) {
    return (
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm" id="tax-calculator-inline-tool">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Calculator className="w-4 h-4 text-emerald-600" />
            <h4 className="text-sm font-black text-slate-900">
              Farm Node Tax Calculator
            </h4>
          </div>
          <span className="text-[10.5px] font-bold text-slate-400 font-mono">
            VAT (16%) • TOT (5%) • Zero-Rated
          </span>
        </div>
        {content}
      </div>
    );
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in" id="tax-calculator-modal">
      <div className="bg-white border border-slate-200 rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden animate-scale-up">
        <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shadow-2xs">
              <Calculator className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900">
                Farm Node Tax Calculator Tool
              </h3>
              <p className="text-[11px] text-slate-500">
                Automatic VAT (16%) & Turnover Tax (5%) Computation
              </p>
            </div>
          </div>
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="p-5">
          {content}
        </div>
      </div>
    </div>
  );
}

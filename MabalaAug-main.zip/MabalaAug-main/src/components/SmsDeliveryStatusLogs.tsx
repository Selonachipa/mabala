import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  MessageSquare,
  CheckCircle2,
  Clock,
  AlertCircle,
  XCircle,
  RefreshCw,
  Search,
  Filter,
  Download,
  Send,
  RotateCw,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ExternalLink,
  Copy,
  Check,
  Smartphone,
  Radio,
  FileText,
  HelpCircle,
  Info,
  Calendar,
  X,
  Eye,
  ArrowUpDown,
  History,
  Activity
} from "lucide-react";
import { SmsDeliveryHistoryModal } from "./SmsDeliveryHistoryModal";

export interface SmsMessageRecord {
  id: string;
  recipient: string;
  recipientName?: string;
  category?: string;
  message: string;
  parts: number;
  costZmw: number;
  status: "delivered" | "sent" | "pending" | "scheduled" | "failed";
  gatewayUsed?: string;
  batch_id?: string | null;
  error_message?: string | null;
  operatorReference?: string | null;
  timestamp: string;
  deliveredAt?: string | null;
  lastRetriedAt?: string | null;
  [key: string]: any;
}

export interface SmsDeliverySummary {
  total: number;
  sent: number;
  delivered: number;
  totalSuccess: number;
  pending: number;
  failed: number;
  deliveryRate: number;
}

interface SmsDeliveryStatusLogsProps {
  userProfile?: any;
  currentRole?: string;
  activeGatewayName?: string;
  onNavigateToSingle?: () => void;
  onNavigateToBroadcast?: () => void;
  onNavigateToTopUp?: () => void;
  smsCredits?: number;
}

export const SmsDeliveryStatusLogs: React.FC<SmsDeliveryStatusLogsProps> = ({
  userProfile,
  currentRole,
  activeGatewayName = "Beem SMS Gateway",
  onNavigateToSingle,
  onNavigateToBroadcast,
  onNavigateToTopUp,
  smsCredits = 0
}) => {
  // State for data
  const [messages, setMessages] = useState<SmsMessageRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [summary, setSummary] = useState<SmsDeliverySummary>({
    total: 0,
    sent: 0,
    delivered: 0,
    totalSuccess: 0,
    pending: 0,
    failed: 0,
    deliveryRate: 0
  });

  // Filter & Search state
  const [statusFilter, setStatusFilter] = useState<"all" | "delivered" | "sent" | "pending" | "failed">("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [debouncedSearch, setDebouncedSearch] = useState<string>("");

  // Pagination state
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [totalFiltered, setTotalFiltered] = useState<number>(0);
  const [startIndex, setStartIndex] = useState<number>(0);
  const [endIndex, setEndIndex] = useState<number>(0);

  // Interaction states
  const [selectedMessage, setSelectedMessage] = useState<SmsMessageRecord | null>(null);
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [expandedMessageIds, setExpandedMessageIds] = useState<Set<string>>(new Set());
  const [actionNotice, setActionNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Debounce search input
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchQuery);
      setCurrentPage(1); // reset to page 1 on new search
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Load messages from server
  const fetchMessages = useCallback(
    async (page = currentPage, limit = pageSize, status = statusFilter, search = debouncedSearch) => {
      setIsLoading(true);
      try {
        const params = new URLSearchParams({
          page: page.toString(),
          limit: limit.toString(),
          status: status,
          search: search,
          uid: userProfile?.uid || "",
          tenantId: userProfile?.tenantId || (userProfile?.role === "Farm Owner" ? `farmer_${userProfile?.uid}` : "global"),
          email: userProfile?.email || ""
        });

        const res = await fetch(`/api/sms/messages?${params.toString()}`);
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.messages)) {
            setMessages(data.messages);
          }
          if (data.summary) {
            setSummary(data.summary);
          }
          if (data.pagination) {
            setTotalPages(data.pagination.totalPages || 1);
            setTotalFiltered(data.pagination.totalFiltered || 0);
            setStartIndex(data.pagination.startIndex || 0);
            setEndIndex(data.pagination.endIndex || 0);
          }
        }
      } catch (err) {
        console.error("Failed to fetch SMS messages:", err);
      } finally {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    },
    [currentPage, pageSize, statusFilter, debouncedSearch, userProfile]
  );

  useEffect(() => {
    fetchMessages(currentPage, pageSize, statusFilter, debouncedSearch);
  }, [currentPage, pageSize, statusFilter, debouncedSearch, fetchMessages]);

  const handleManualRefresh = () => {
    setIsRefreshing(true);
    fetchMessages(currentPage, pageSize, statusFilter, debouncedSearch);
  };

  // Status Filter change
  const handleStatusFilterChange = (newStatus: "all" | "delivered" | "sent" | "pending" | "failed") => {
    setStatusFilter(newStatus);
    setCurrentPage(1);
  };

  // Page Size change
  const handlePageSizeChange = (newSize: number) => {
    setPageSize(newSize);
    setCurrentPage(1);
  };

  // Toggle expand message text
  const toggleExpandMessage = (id: string) => {
    setExpandedMessageIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  // Copy message text to clipboard
  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Retry SMS dispatch
  const handleRetryMessage = async (msg: SmsMessageRecord) => {
    setRetryingId(msg.id);
    setActionNotice(null);
    try {
      const res = await fetch(`/api/sms/messages/${msg.id}/retry`, {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setActionNotice({
          type: "success",
          text: `SMS to ${msg.recipient} successfully re-dispatched via ${data.gatewayUsed || activeGatewayName}.`
        });
        // Refresh the list
        fetchMessages(currentPage, pageSize, statusFilter, debouncedSearch);
        if (selectedMessage && selectedMessage.id === msg.id) {
          setSelectedMessage(data.record || { ...selectedMessage, status: "delivered", error_message: null });
        }
      } else {
        setActionNotice({
          type: "error",
          text: `Retry failed: ${data.error || "Carrier rejected retry request."}`
        });
      }
    } catch (err: any) {
      setActionNotice({
        type: "error",
        text: `Network error retrying SMS: ${err.message}`
      });
    } finally {
      setRetryingId(null);
    }
  };

  // Export CSV
  const handleExportCsv = () => {
    const params = new URLSearchParams({
      format: "csv",
      status: statusFilter,
      search: debouncedSearch,
      uid: userProfile?.uid || ""
    });
    window.location.href = `/api/sms/messages?${params.toString()}`;
  };

  // Helper to format Zambian phone numbers nicely
  const formatPhoneDisplay = (phoneStr: string) => {
    if (!phoneStr) return "N/A";
    const clean = phoneStr.replace(/\D/g, "");
    if (clean.startsWith("260") && clean.length === 12) {
      return `+260 ${clean.substring(3, 5)} ${clean.substring(5, 8)} ${clean.substring(8, 12)}`;
    }
    return phoneStr;
  };

  // Helper for network operator badge
  const getNetworkBadge = (phoneStr: string) => {
    const clean = phoneStr.replace(/\D/g, "");
    let prefix = "";
    if (clean.startsWith("260") && clean.length >= 5) {
      prefix = clean.substring(3, 5);
    } else if (clean.startsWith("0") && clean.length >= 3) {
      prefix = clean.substring(1, 3);
    }

    if (["97", "77"].includes(prefix)) {
      return <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-red-100 text-red-700 border border-red-200">Airtel</span>;
    }
    if (["96", "76"].includes(prefix)) {
      return <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-yellow-100 text-yellow-800 border border-yellow-200">MTN</span>;
    }
    if (["95", "75"].includes(prefix)) {
      return <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200">Zamtel</span>;
    }
    return <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">GSM</span>;
  };

  // Helper for status badge rendering
  const renderStatusBadge = (status: string, errorMessage?: string | null) => {
    switch (status) {
      case "delivered":
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-black uppercase px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200/80 shadow-xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Delivered
          </span>
        );
      case "sent":
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-black uppercase px-2.5 py-1 rounded-full bg-teal-100 text-teal-800 border border-teal-200/80 shadow-xs">
            <Send className="w-3.5 h-3.5 text-teal-600" />
            Sent to SMSC
          </span>
        );
      case "pending":
      case "scheduled":
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-black uppercase px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 border border-amber-200/80 shadow-xs animate-pulse">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            {status === "scheduled" ? "Scheduled" : "Pending Handset"}
          </span>
        );
      case "failed":
        return (
          <span
            className="inline-flex items-center gap-1 text-[11px] font-black uppercase px-2.5 py-1 rounded-full bg-rose-100 text-rose-800 border border-rose-200/80 shadow-xs"
            title={errorMessage || "Carrier dispatch failure"}
          >
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Failed
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-black uppercase px-2.5 py-1 rounded-full bg-slate-100 text-slate-800 border border-slate-200">
            {status}
          </span>
        );
    }
  };

  // Generate pagination buttons with ellipsis
  const paginationRange = useMemo(() => {
    const delta = 1;
    const range: (number | string)[] = [];
    for (let i = Math.max(2, currentPage - delta); i <= Math.min(totalPages - 1, currentPage + delta); i++) {
      range.push(i);
    }

    if (currentPage - delta > 2) {
      range.unshift("...");
    }
    if (currentPage + delta < totalPages - 1) {
      range.push("...");
    }

    range.unshift(1);
    if (totalPages > 1) {
      range.push(totalPages);
    }
    return range;
  }, [currentPage, totalPages]);

  return (
    <div className="space-y-6 animate-fade-in" id="sms-delivery-logs-panel">
      {/* 1. TOP STATS CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total SMS */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center gap-3.5">
          <div className="p-3 bg-slate-100 text-slate-800 rounded-xl">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Total Dispatches</div>
            <div className="text-xl font-black text-slate-900">{summary.total}</div>
            <div className="text-[10px] text-slate-400 font-medium">All logged SMS transmissions</div>
          </div>
        </div>

        {/* Delivered / Sent */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center gap-3.5">
          <div className="p-3 bg-emerald-100 text-emerald-700 rounded-xl">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Delivered & Sent</div>
            <div className="text-xl font-black text-emerald-700">
              {summary.delivered + summary.sent}{" "}
              <span className="text-xs font-bold text-emerald-600">({summary.deliveryRate}%)</span>
            </div>
            <div className="text-[10px] text-slate-400 font-medium">
              {summary.delivered} delivered • {summary.sent} in transit
            </div>
          </div>
        </div>

        {/* Pending */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center gap-3.5">
          <div className="p-3 bg-amber-100 text-amber-700 rounded-xl">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Pending & Scheduled</div>
            <div className="text-xl font-black text-amber-700">{summary.pending}</div>
            <div className="text-[10px] text-slate-400 font-medium">Awaiting operator acknowledgment</div>
          </div>
        </div>

        {/* Failed */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center gap-3.5">
          <div className="p-3 bg-rose-100 text-rose-700 rounded-xl">
            <XCircle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Failed / Rejected</div>
            <div className="text-xl font-black text-rose-700">{summary.failed}</div>
            <div className="text-[10px] text-slate-400 font-medium">
              {summary.failed > 0 ? "Requires re-dispatch or review" : "Zero delivery errors"}
            </div>
          </div>
        </div>
      </div>

      {/* Action Notice (if any retry or status update) */}
      {actionNotice && (
        <div
          className={`p-4 rounded-2xl text-xs font-bold flex items-center justify-between border ${
            actionNotice.type === "success"
              ? "bg-emerald-50 text-emerald-900 border-emerald-200"
              : "bg-rose-50 text-rose-900 border-rose-200"
          }`}
        >
          <div className="flex items-center gap-2">
            {actionNotice.type === "success" ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{actionNotice.text}</span>
          </div>
          <button onClick={() => setActionNotice(null)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 2. MAIN LOGS CARD */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-5">
        {/* Header and Toolbar */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black text-slate-900">SMS Delivery Status & Logs</h2>
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-[10px] font-black">
                {activeGatewayName}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Live transmission records, recipient handset delivery receipts, and carrier failure diagnostics with full pagination.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start lg:self-auto">
            <button
              onClick={handleExportCsv}
              className="px-3.5 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5 shadow-2xs cursor-pointer"
              title="Download CSV report of current filtered messages"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              Export CSV
            </button>

            <button
              onClick={handleManualRefresh}
              disabled={isRefreshing || isLoading}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing || isLoading ? "animate-spin text-indigo-600" : ""}`} />
              Refresh Status
            </button>
          </div>
        </div>

        {/* Filters & Search Bar */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200/80">
          {/* Status Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
            <button
              onClick={() => handleStatusFilterChange("all")}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs whitespace-nowrap transition cursor-pointer ${
                statusFilter === "all"
                  ? "bg-slate-900 text-white shadow-xs"
                  : "bg-white text-slate-600 hover:bg-slate-200/70 border border-slate-200"
              }`}
            >
              All ({summary.total})
            </button>

            <button
              onClick={() => handleStatusFilterChange("delivered")}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs whitespace-nowrap transition flex items-center gap-1 cursor-pointer ${
                statusFilter === "delivered"
                  ? "bg-emerald-700 text-white shadow-xs"
                  : "bg-white text-emerald-800 hover:bg-emerald-50 border border-emerald-200"
              }`}
            >
              <CheckCircle2 className="w-3 h-3" />
              Delivered ({summary.delivered})
            </button>

            <button
              onClick={() => handleStatusFilterChange("sent")}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs whitespace-nowrap transition flex items-center gap-1 cursor-pointer ${
                statusFilter === "sent"
                  ? "bg-teal-700 text-white shadow-xs"
                  : "bg-white text-teal-800 hover:bg-teal-50 border border-teal-200"
              }`}
            >
              <Send className="w-3 h-3" />
              Sent ({summary.sent})
            </button>

            <button
              onClick={() => handleStatusFilterChange("pending")}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs whitespace-nowrap transition flex items-center gap-1 cursor-pointer ${
                statusFilter === "pending"
                  ? "bg-amber-700 text-white shadow-xs"
                  : "bg-white text-amber-800 hover:bg-amber-50 border border-amber-200"
              }`}
            >
              <Clock className="w-3 h-3" />
              Pending ({summary.pending})
            </button>

            <button
              onClick={() => handleStatusFilterChange("failed")}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs whitespace-nowrap transition flex items-center gap-1 cursor-pointer ${
                statusFilter === "failed"
                  ? "bg-rose-700 text-white shadow-xs"
                  : "bg-white text-rose-800 hover:bg-rose-50 border border-rose-200"
              }`}
            >
              <XCircle className="w-3 h-3" />
              Failed ({summary.failed})
            </button>
          </div>

          {/* Search Box & Limit */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1 md:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search phone, name, text..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-slate-900 focus:outline-none placeholder:text-slate-400 font-medium"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-1 text-xs text-slate-500 font-bold">
              <span className="hidden sm:inline">Rows:</span>
              <select
                value={pageSize}
                onChange={(e) => handlePageSizeChange(Number(e.target.value))}
                className="bg-white border border-slate-200 rounded-xl px-2 py-1.5 text-xs font-bold text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 cursor-pointer"
              >
                <option value={10}>10</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>
          </div>
        </div>

        {/* 3. MESSAGES TABLE */}
        {isLoading ? (
          <div className="py-20 text-center space-y-3">
            <RefreshCw className="w-7 h-7 text-indigo-600 animate-spin mx-auto" />
            <p className="text-xs text-slate-500 font-semibold">Loading SMS delivery logs & transmission audit...</p>
          </div>
        ) : messages.length === 0 ? (
          <div className="text-center py-16 px-4 border border-dashed border-slate-200 rounded-2xl bg-slate-50/50 space-y-3">
            <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto text-slate-400">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-black text-slate-800">No SMS Messages Found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                {statusFilter !== "all" || debouncedSearch
                  ? "No SMS messages match your active status or search filters. Try clearing the filter."
                  : "No outgoing SMS messages have been logged yet. Dispatched SMS will automatically appear here."}
              </p>
            </div>
            <div className="flex justify-center gap-2 pt-2">
              {(statusFilter !== "all" || debouncedSearch) && (
                <button
                  onClick={() => {
                    setStatusFilter("all");
                    setSearchQuery("");
                  }}
                  className="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Clear Filters
                </button>
              )}
              {onNavigateToSingle && (
                <button
                  onClick={onNavigateToSingle}
                  className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  Send Single SMS
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto border border-slate-100 rounded-2xl">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50/90 border-b border-slate-200 text-[10px] font-black uppercase text-slate-500 tracking-wider">
                  <th className="py-3.5 px-3">Delivery Status</th>
                  <th className="py-3.5 px-3">Recipient & Network</th>
                  <th className="py-3.5 px-3">Message Preview</th>
                  <th className="py-3.5 px-3">Gateway / Cost</th>
                  <th className="py-3.5 px-3">Timestamp</th>
                  <th className="py-3.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {messages.map((m) => {
                  const isExpanded = expandedMessageIds.has(m.id);
                  const isLong = m.message.length > 90;

                  return (
                    <tr key={m.id} className="hover:bg-slate-50/70 transition group">
                      {/* 1. Status Column */}
                      <td className="py-3.5 px-3 align-top whitespace-nowrap">
                        <div className="space-y-1">
                          {renderStatusBadge(m.status, m.error_message)}
                          {m.error_message && (
                            <div
                              className="text-[10px] text-rose-600 font-semibold max-w-[180px] truncate"
                              title={m.error_message}
                            >
                              {m.error_message}
                            </div>
                          )}
                          {m.batch_id && (
                            <div className="text-[9px] font-mono text-indigo-600 font-bold bg-indigo-50/80 px-1.5 py-0.5 rounded inline-block">
                              Campaign Batch
                            </div>
                          )}
                        </div>
                      </td>

                      {/* 2. Recipient Column */}
                      <td className="py-3.5 px-3 align-top whitespace-nowrap">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-bold text-slate-900 text-xs">
                              {formatPhoneDisplay(m.recipient)}
                            </span>
                            {getNetworkBadge(m.recipient)}
                          </div>
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-600">
                            <span className="font-semibold text-slate-800">{m.recipientName || "Direct Contact"}</span>
                            {m.category && (
                              <span className="text-[9px] font-bold px-1.5 py-0.2 bg-slate-100 text-slate-500 rounded">
                                {m.category}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* 3. Message Preview Column */}
                      <td className="py-3.5 px-3 align-top max-w-xs sm:max-w-md">
                        <div className="space-y-1.5">
                          <div className="text-slate-700 text-xs leading-relaxed font-normal">
                            {isExpanded || !isLong ? m.message : `${m.message.slice(0, 85)}...`}
                          </div>
                          <div className="flex items-center gap-2 text-[10px] text-slate-400">
                            <span className="font-mono">{m.message.length} chars</span>
                            <span>•</span>
                            <span className="font-bold text-slate-600">{m.parts} Part{m.parts > 1 ? "s" : ""}</span>
                            {isLong && (
                              <>
                                <span>•</span>
                                <button
                                  onClick={() => toggleExpandMessage(m.id)}
                                  className="text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer"
                                >
                                  {isExpanded ? "Show Less" : "Show More"}
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* 4. Gateway / Cost Column */}
                      <td className="py-3.5 px-3 align-top whitespace-nowrap">
                        <div className="space-y-0.5">
                          <div className="text-[11px] font-bold text-slate-800">
                            {m.gatewayUsed || activeGatewayName}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            <span className="font-bold text-emerald-600">{m.parts} Credit{m.parts > 1 ? "s" : ""}</span>
                            <span className="text-slate-400"> (K{Number(m.costZmw || 0).toFixed(2)})</span>
                          </div>
                          {m.operatorReference && (
                            <div className="text-[9px] font-mono text-slate-400 truncate max-w-[120px]" title={m.operatorReference}>
                              Ref: {m.operatorReference}
                            </div>
                          )}
                        </div>
                      </td>

                      {/* 5. Timestamp Column */}
                      <td className="py-3.5 px-3 align-top whitespace-nowrap">
                        <div className="space-y-0.5">
                          <div className="text-xs font-semibold text-slate-800">
                            {m.timestamp ? new Date(m.timestamp).toLocaleDateString() : "N/A"}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            {m.timestamp ? new Date(m.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""}
                          </div>
                        </div>
                      </td>

                      {/* 6. Actions Column */}
                      <td className="py-3.5 px-3 align-top text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleCopyText(m.message, m.id)}
                            title="Copy SMS text"
                            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                          >
                            {copiedId === m.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>

                          {(m.status === "failed" || m.status === "pending") && (
                            <button
                              onClick={() => handleRetryMessage(m)}
                              disabled={retryingId === m.id}
                              title="Retry SMS dispatch"
                              className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg text-[10px] font-black transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
                            >
                              <RotateCw className={`w-3 h-3 ${retryingId === m.id ? "animate-spin text-amber-600" : ""}`} />
                              Retry
                            </button>
                          )}

                          <button
                            onClick={() => setSelectedMessage(m)}
                            title="View Full Delivery Receipt"
                            className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* 4. PAGINATION FOOTER */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-3 border-t border-slate-100 text-xs text-slate-600">
          {/* Summary count */}
          <div className="font-medium text-slate-500 text-center sm:text-left">
            Showing <span className="font-black text-slate-900">{startIndex}</span> to{" "}
            <span className="font-black text-slate-900">{endIndex}</span> of{" "}
            <span className="font-black text-slate-900">{totalFiltered}</span> SMS messages
            {statusFilter !== "all" && (
              <span className="ml-1 text-slate-400 font-normal">
                (filtered by <span className="capitalize font-bold text-slate-600">{statusFilter}</span>)
              </span>
            )}
          </div>

          {/* Pagination Navigation */}
          <div className="flex items-center gap-1">
            {/* First Page */}
            <button
              onClick={() => setCurrentPage(1)}
              disabled={currentPage <= 1 || isLoading}
              className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none transition cursor-pointer"
              title="First Page"
            >
              <ChevronsLeft className="w-4 h-4" />
            </button>

            {/* Previous Page */}
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage <= 1 || isLoading}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none font-bold text-xs flex items-center gap-1 transition cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              Prev
            </button>

            {/* Page numbers */}
            <div className="flex items-center gap-1 px-1">
              {paginationRange.map((pageItem, idx) => {
                if (pageItem === "...") {
                  return (
                    <span key={`ellipsis_${idx}`} className="px-1 text-slate-400 font-bold">
                      ...
                    </span>
                  );
                }
                const isCurrent = pageItem === currentPage;
                return (
                  <button
                    key={`page_${pageItem}`}
                    onClick={() => setCurrentPage(Number(pageItem))}
                    disabled={isLoading}
                    className={`min-w-[32px] h-8 rounded-lg font-black text-xs transition cursor-pointer ${
                      isCurrent
                        ? "bg-slate-900 text-white shadow-xs"
                        : "bg-white border border-slate-200 text-slate-700 hover:bg-slate-100"
                    }`}
                  >
                    {pageItem}
                  </button>
                );
              })}
            </div>

            {/* Next Page */}
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages || isLoading}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none font-bold text-xs flex items-center gap-1 transition cursor-pointer"
            >
              Next
              <ChevronRight className="w-3.5 h-3.5" />
            </button>

            {/* Last Page */}
            <button
              onClick={() => setCurrentPage(totalPages)}
              disabled={currentPage >= totalPages || isLoading}
              className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none transition cursor-pointer"
              title="Last Page"
            >
              <ChevronsRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 5. FULL DELIVERY HISTORY & CARRIER AUDIT MODAL */}
      <SmsDeliveryHistoryModal
        message={selectedMessage}
        isOpen={!!selectedMessage}
        onClose={() => setSelectedMessage(null)}
        onRetry={handleRetryMessage}
        activeGatewayName={activeGatewayName}
      />
    </div>
  );
};

export default SmsDeliveryStatusLogs;

import React, { useState, useEffect } from "react";
import { 
  X, 
  Building2, 
  Save, 
  Sparkles, 
  DollarSign, 
  Percent, 
  Phone, 
  Mail, 
  MapPin, 
  Layers,
  AlertTriangle,
  UserCheck
} from "lucide-react";
import { ResellerPartner } from "../../types";
import { resellerService } from "../../services/resellerService";
import { safeFormatError } from "../../utils/errorUtils";

interface ResellerEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  reseller?: ResellerPartner | null;
  onSaved: (partner: ResellerPartner) => void;
  currencySymbol?: string;
}

export default function ResellerEditModal({
  isOpen,
  onClose,
  reseller,
  onSaved,
  currencySymbol = "K"
}: ResellerEditModalProps) {
  if (!isOpen) return null;

  const isEditing = !!reseller;

  const [resellerCode, setResellerCode] = useState("");
  const [name, setName] = useState("");
  const [organization, setOrganization] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [district, setDistrict] = useState("Lusaka");
  const [province, setProvince] = useState("Lusaka");
  const [status, setStatus] = useState<"active" | "inactive" | "suspended">("active");
  const [commissionModel, setCommissionModel] = useState<"percentage" | "flat">("percentage");
  const [commissionRate, setCommissionRate] = useState<number>(20);
  const [payoutProvider, setPayoutProvider] = useState<"airtel" | "mtn" | "zamtel" | "bank">("airtel");
  const [payoutAccountNumber, setPayoutAccountNumber] = useState("");
  const [payoutAccountName, setPayoutAccountName] = useState("");
  const [bankName, setBankName] = useState("");
  const [notes, setNotes] = useState("");

  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (reseller) {
      setResellerCode(reseller.resellerCode);
      setName(reseller.name);
      setOrganization(reseller.organization || "");
      setEmail(reseller.email);
      setPhone(reseller.phone);
      setDistrict(reseller.district || "Lusaka");
      setProvince(reseller.province || "Lusaka");
      setStatus(reseller.status);
      setCommissionModel(reseller.commissionModel);
      setCommissionRate(reseller.commissionRate);
      setPayoutProvider(reseller.payoutProvider);
      setPayoutAccountNumber(reseller.payoutAccountNumber);
      setPayoutAccountName(reseller.payoutAccountName);
      setBankName(reseller.bankName || "");
      setNotes(reseller.notes || "");
    } else {
      // Auto-generate fresh reseller code
      const randNum = Math.floor(100 + Math.random() * 900);
      setResellerCode(`MAB-RES-${randNum}`);
      setName("");
      setOrganization("");
      setEmail("");
      setPhone("");
      setDistrict("Lusaka");
      setProvince("Lusaka");
      setStatus("active");
      setCommissionModel("percentage");
      setCommissionRate(20);
      setPayoutProvider("airtel");
      setPayoutAccountNumber("");
      setPayoutAccountName("");
      setBankName("");
      setNotes("");
    }
  }, [reseller, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!name.trim() || !resellerCode.trim() || !email.trim() || !phone.trim()) {
      setErrorMsg("Please fill in all required fields (Name, Reseller Code, Email, Phone).");
      return;
    }

    setIsSaving(true);
    try {
      const partnerData: ResellerPartner = {
        id: reseller ? reseller.id : `reseller_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        resellerCode: resellerCode.trim().toUpperCase(),
        name: name.trim(),
        organization: organization.trim() || undefined,
        email: email.trim().toLowerCase(),
        phone: phone.trim(),
        district: district.trim(),
        province: province.trim(),
        status,
        commissionModel,
        commissionRate: Number(commissionRate),
        payoutProvider,
        payoutAccountNumber: payoutAccountNumber.trim(),
        payoutAccountName: payoutAccountName.trim() || name.trim(),
        bankName: payoutProvider === "bank" ? bankName.trim() : undefined,
        totalOnboardedFarmers: reseller?.totalOnboardedFarmers || 0,
        activeSubscribers: reseller?.activeSubscribers || 0,
        totalSubscriptionVolumeZMW: reseller?.totalSubscriptionVolumeZMW || 0,
        accumulatedCommissionZMW: reseller?.accumulatedCommissionZMW || 0,
        settledCommissionZMW: reseller?.settledCommissionZMW || 0,
        unsettledBalanceZMW: reseller?.unsettledBalanceZMW || 0,
        joinedAt: reseller?.joinedAt || new Date().toISOString(),
        lastPayoutAt: reseller?.lastPayoutAt,
        notes: notes.trim() || undefined
      };

      const saved = await resellerService.saveReseller(partnerData);
      onSaved(saved);
      onClose();
    } catch (err: any) {
      console.error("[ResellerEditModal] Save error:", err);
      setErrorMsg(err.message || "Failed to save reseller profile.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-[99999] flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-2xl w-full p-6 sm:p-7 text-slate-900 font-sans animate-fade-in space-y-6">
        
        {/* Header */}
        <div className="flex justify-between items-start border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-600 text-white rounded-2xl shadow-sm">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded">
                  {isEditing ? "Edit Partner Profile" : "New Reseller Registration"}
                </span>
              </div>
              <h3 className="text-lg font-black text-slate-900 mt-0.5">
                {isEditing ? `Edit ${reseller?.name}` : "Create Reseller Channel Partner"}
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{safeFormatError(errorMsg)}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Identity Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Reseller Unique Code *:</label>
              <input
                type="text"
                value={resellerCode}
                onChange={(e) => setResellerCode(e.target.value.toUpperCase())}
                placeholder="e.g. AGRI-PARTNER-01"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-black text-emerald-900 focus:outline-emerald-600"
                required
              />
              <span className="text-[10px] text-slate-400">Used by farmers & agro-dealers at registration</span>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Partner Status:</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 cursor-pointer focus:outline-emerald-600"
              >
                <option value="active">Active Channel Partner</option>
                <option value="inactive">Inactive / Pending</option>
                <option value="suspended">Suspended</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Reseller / Contact Name *:</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Lusaka Agro Hub"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-emerald-600"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Organization / Registered Company:</label>
              <input
                type="text"
                value={organization}
                onChange={(e) => setOrganization(e.target.value)}
                placeholder="e.g. Lusaka Agro Solutions Ltd"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-emerald-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Corporate Email Address *:</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="partner@agrihub.co.zm"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-emerald-600"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Contact Phone Number *:</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+260978XXXXXX"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 focus:outline-emerald-600"
                required
              />
            </div>
          </div>

          {/* Territory */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Province:</label>
              <select
                value={province}
                onChange={(e) => setProvince(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 cursor-pointer focus:outline-emerald-600"
              >
                <option value="Lusaka">Lusaka Province</option>
                <option value="Central">Central Province</option>
                <option value="Copperbelt">Copperbelt Province</option>
                <option value="Southern">Southern Province</option>
                <option value="Eastern">Eastern Province</option>
                <option value="North-Western">North-Western Province</option>
                <option value="Northern">Northern Province</option>
                <option value="Luapula">Luapula Province</option>
                <option value="Muchinga">Muchinga Province</option>
                <option value="Western">Western Province</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">District:</label>
              <input
                type="text"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                placeholder="e.g. Lusaka, Mkushi, Ndola, Choma"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-emerald-600"
              />
            </div>
          </div>

          {/* COMMISSION MODEL CONFIGURATION */}
          <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-3">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-700" />
              <span className="text-xs font-black uppercase text-emerald-950 tracking-wider">
                Monthly Subscription Commission Offer
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-emerald-900 block mb-1">Commission Type:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setCommissionModel("percentage");
                      if (commissionRate > 100) setCommissionRate(20);
                    }}
                    className={`py-2 px-3 text-xs font-bold rounded-xl border flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      commissionModel === "percentage"
                        ? "bg-emerald-700 text-white border-emerald-800 shadow-xs"
                        : "bg-white text-slate-700 border-slate-200 hover:bg-emerald-100"
                    }`}
                  >
                    <Percent className="w-3.5 h-3.5" />
                    <span>Percentage</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCommissionModel("flat");
                      if (commissionRate <= 100) setCommissionRate(50);
                    }}
                    className={`py-2 px-3 text-xs font-bold rounded-xl border flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      commissionModel === "flat"
                        ? "bg-emerald-700 text-white border-emerald-800 shadow-xs"
                        : "bg-white text-slate-700 border-slate-200 hover:bg-emerald-100"
                    }`}
                  >
                    <DollarSign className="w-3.5 h-3.5" />
                    <span>Flat Fee (ZMW)</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-emerald-900 block mb-1">
                  {commissionModel === "percentage" ? "Commission Rate (% of Subscription):" : `Flat Fee per Paid Farmer per Month (${currencySymbol}):`}
                </label>
                <input
                  type="number"
                  min="1"
                  max={commissionModel === "percentage" ? 100 : 5000}
                  value={commissionRate}
                  onChange={(e) => setCommissionRate(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-emerald-600"
                  required
                />
                <span className="text-[10px] text-emerald-700">
                  {commissionModel === "percentage" 
                    ? `Reseller receives ${commissionRate}% of each monthly subscription paid by linked farmers.`
                    : `Reseller receives ${currencySymbol}${commissionRate} fixed bounty every month each linked farmer pays their subscription.`}
                </span>
              </div>
            </div>
          </div>

          {/* LIPILA PAYOUT DESTINATION DETAILS */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
            <span className="text-xs font-black uppercase text-slate-900 tracking-wider block">
              Lipila Disbursement Account
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Payout Channel:</label>
                <select
                  value={payoutProvider}
                  onChange={(e) => setPayoutProvider(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 cursor-pointer focus:outline-emerald-600"
                >
                  <option value="airtel">Airtel Money</option>
                  <option value="mtn">MTN MoMo</option>
                  <option value="zamtel">Zamtel Kwacha</option>
                  <option value="bank">Bank Account</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {payoutProvider === "bank" ? "Account Number:" : "Mobile Money Number:"}
                </label>
                <input
                  type="text"
                  value={payoutAccountNumber}
                  onChange={(e) => setPayoutAccountNumber(e.target.value)}
                  placeholder={payoutProvider === "bank" ? "e.g. 551098234" : "097XXXXXXX"}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-emerald-600"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Account Holder Name:</label>
                <input
                  type="text"
                  value={payoutAccountName}
                  onChange={(e) => setPayoutAccountName(e.target.value)}
                  placeholder="Registered name"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-emerald-600"
                />
              </div>
            </div>

            {payoutProvider === "bank" && (
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Bank Name & Branch:</label>
                <input
                  type="text"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  placeholder="e.g. Zanaco, Absa, Stanbic"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-emerald-600"
                />
              </div>
            )}
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">Internal Notes / Territory Agreement:</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Key partner for Eastern Province tobacco and soya beans farmers."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:outline-emerald-600"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
              disabled={isSaving}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow-sm transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? "Saving Reseller..." : isEditing ? "Update Reseller Profile" : "Register Channel Reseller"}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}

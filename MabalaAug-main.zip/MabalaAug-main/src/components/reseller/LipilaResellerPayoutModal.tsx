import React, { useState } from "react";
import { 
  X, 
  Send, 
  CheckCircle2, 
  AlertTriangle, 
  DollarSign, 
  Phone, 
  Building2, 
  Receipt,
  Sparkles,
  ArrowRight,
  ShieldCheck
} from "lucide-react";
import { ResellerPartner, ResellerSettlementPayout } from "../../types";
import { resellerService } from "../../services/resellerService";
import { safeFormatError } from "../../utils/errorUtils";

interface LipilaResellerPayoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  reseller: ResellerPartner | null;
  adminProfile?: any;
  onSettlementSuccess?: (payout: ResellerSettlementPayout) => void;
  currencySymbol?: string;
}

export default function LipilaResellerPayoutModal({
  isOpen,
  onClose,
  reseller,
  adminProfile,
  onSettlementSuccess,
  currencySymbol = "K"
}: LipilaResellerPayoutModalProps) {
  if (!isOpen || !reseller) return null;

  const [payoutAmount, setPayoutAmount] = useState<number>(reseller.unsettledBalanceZMW || 0);
  const [provider, setProvider] = useState<"airtel" | "mtn" | "zamtel" | "bank">(reseller.payoutProvider || "airtel");
  const [accountNumber, setAccountNumber] = useState<string>(reseller.payoutAccountNumber || "");
  const [accountName, setAccountName] = useState<string>(reseller.payoutAccountName || reseller.name || "");
  const [bankName, setBankName] = useState<string>(reseller.bankName || "");
  const [periodCovered, setPeriodCovered] = useState<string>(
    new Date().toLocaleString("en-US", { month: "long", year: "numeric" })
  );
  const [notes, setNotes] = useState<string>("Mabala Monthly Reseller Subscription Commission Settlement");

  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [completedPayout, setCompletedPayout] = useState<ResellerSettlementPayout | null>(null);

  const fee = provider === "bank" ? 15.00 : 2.50;
  const netAmount = Math.max(0, payoutAmount - fee);

  const handleQuickPercent = (pct: number) => {
    const calculated = Math.round(((reseller.unsettledBalanceZMW * pct) / 100) * 100) / 100;
    setPayoutAmount(calculated);
  };

  const handleExecutePayout = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (payoutAmount <= 0) {
      setErrorMessage("Please enter a valid disbursement amount greater than 0.");
      return;
    }

    if (payoutAmount > (reseller.unsettledBalanceZMW || 0)) {
      setErrorMessage(`Amount exceeds available unsettled balance of ${currencySymbol}${reseller.unsettledBalanceZMW.toLocaleString()}`);
      return;
    }

    if (!accountNumber.trim()) {
      setErrorMessage("Please provide the recipient Mobile Money or Bank account number.");
      return;
    }

    setIsProcessing(true);

    try {
      // Simulate real Lipila B2C Disbursal latency
      await new Promise(r => setTimeout(r, 1200));

      const adminUid = adminProfile?.uid || "icIoBG4eN5VOw2BvhNiFUnUqmsX2";
      const adminEmail = adminProfile?.email || "support@mabala.cloud";

      const res = await resellerService.settleResellerCommissionViaLipila({
        resellerId: reseller.id,
        amountZMW: payoutAmount,
        payoutProvider: provider,
        payoutAccount: accountNumber.trim(),
        accountName: accountName.trim(),
        bankName: provider === "bank" ? bankName.trim() : undefined,
        adminUid,
        adminEmail,
        periodCovered,
        notes
      });

      if (res.success && res.payout) {
        setCompletedPayout(res.payout);
        if (onSettlementSuccess) {
          onSettlementSuccess(res.payout);
        }
      } else {
        setErrorMessage(res.message || "Lipila API transaction failed. Please verify credentials.");
      }
    } catch (err: any) {
      console.error("[LipilaResellerPayoutModal] Error:", err);
      setErrorMessage(err.message || "Failed to process Lipila disbursement. Please check internet connection.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-[99999] flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-xl w-full p-6 sm:p-7 text-slate-900 font-sans animate-fade-in space-y-6">
        
        {/* Header */}
        <div className="flex justify-between items-start border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-sm">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-indigo-100 text-indigo-900 px-2 py-0.5 rounded">
                  Lipila API B2C Payout
                </span>
                <span className="font-mono text-xs font-bold text-slate-500">
                  {reseller.resellerCode}
                </span>
              </div>
              <h3 className="text-lg font-black text-slate-900 mt-0.5">Settle Reseller Commission</h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {completedPayout ? (
          /* Settlement Confirmation View */
          <div className="space-y-5 animate-fade-in text-center py-2">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <h4 className="text-xl font-black text-slate-900">Settlement Disbursed!</h4>
              <p className="text-xs text-slate-500 font-medium mt-1">
                Successfully processed payout via Lipila Gateway to <strong className="text-slate-800">{reseller.name}</strong>.
              </p>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left text-xs space-y-2 font-mono">
              <div className="flex justify-between">
                <span className="text-slate-500">Lipila Reference:</span>
                <span className="font-bold text-slate-900">{completedPayout.payoutReference}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Lipila Txn ID:</span>
                <span className="font-bold text-slate-900">{completedPayout.lipilaTransactionId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Gross Settlement:</span>
                <span className="font-bold text-slate-900">{currencySymbol}{completedPayout.amountZMW.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Disbursed To:</span>
                <span className="font-bold text-slate-900">{completedPayout.payoutProvider.toUpperCase()} &bull; {completedPayout.payoutAccount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Status:</span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 font-bold rounded-full text-[10px]">
                  {completedPayout.lipilaStatus} (Real-time Confirmed)
                </span>
              </div>
            </div>

            <div className="pt-3 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-sm transition cursor-pointer"
              >
                Done & Return to Reseller Hub
              </button>
            </div>
          </div>
        ) : (
          /* Settlement Form View */
          <form onSubmit={handleExecutePayout} className="space-y-4">
            
            {/* Reseller Balance Card */}
            <div className="p-4 bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-2xl shadow-sm space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-indigo-200 font-medium">Accumulated Unsettled Balance:</span>
                <span className="px-2 py-0.5 bg-indigo-500/30 text-indigo-200 rounded font-mono text-[10px]">
                  {reseller.commissionModel === "percentage" ? `${reseller.commissionRate}% Model` : `Flat K${reseller.commissionRate}/Farmer`}
                </span>
              </div>
              <div className="text-2xl font-black font-mono text-emerald-400">
                {currencySymbol}{reseller.unsettledBalanceZMW.toLocaleString()}
              </div>
              <div className="text-[11px] text-slate-300 flex items-center gap-2">
                <span>Partner: <strong className="text-white">{reseller.name}</strong></span>
                <span>&bull;</span>
                <span>Active Farmers: <strong className="text-white">{reseller.activeSubscribers}</strong></span>
              </div>
            </div>

            {errorMessage && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold flex items-center gap-2 animate-shake">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{safeFormatError(errorMessage)}</span>
              </div>
            )}

            {/* Payout Amount Field & Quick Buttons */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-bold text-slate-700">Settlement Amount ({currencySymbol}):</label>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleQuickPercent(50)}
                    className="px-2 py-0.5 text-[10px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded cursor-pointer"
                  >
                    50%
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickPercent(100)}
                    className="px-2 py-0.5 text-[10px] font-bold bg-indigo-100 hover:bg-indigo-200 text-indigo-900 rounded cursor-pointer"
                  >
                    100% (Full)
                  </button>
                </div>
              </div>
              <input
                type="number"
                step="0.01"
                min="1"
                max={reseller.unsettledBalanceZMW}
                value={payoutAmount}
                onChange={(e) => setPayoutAmount(parseFloat(e.target.value) || 0)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 font-mono focus:outline-indigo-600"
                required
              />
            </div>

            {/* Provider & Account Selection */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Payout Gateway:</label>
                <select
                  value={provider}
                  onChange={(e) => setProvider(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 cursor-pointer focus:outline-indigo-600"
                >
                  <option value="airtel">Airtel Money (Lipila B2C)</option>
                  <option value="mtn">MTN MoMo (Lipila B2C)</option>
                  <option value="zamtel">Zamtel Kwacha (Lipila B2C)</option>
                  <option value="bank">Direct Bank EFT / Transfer</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {provider === "bank" ? "Bank Account Number:" : "Mobile Money Number:"}
                </label>
                <input
                  type="text"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  placeholder={provider === "bank" ? "e.g. 55109923481" : "097XXXXXXX"}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 focus:outline-indigo-600"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Recipient Name:</label>
                <input
                  type="text"
                  value={accountName}
                  onChange={(e) => setAccountName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-indigo-600"
                  required
                />
              </div>

              {provider === "bank" ? (
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Bank Name & Branch:</label>
                  <input
                    type="text"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    placeholder="e.g. Zanaco, Absa, Stanbic"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-indigo-600"
                    required
                  />
                </div>
              ) : (
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Period Covered:</label>
                  <input
                    type="text"
                    value={periodCovered}
                    onChange={(e) => setPeriodCovered(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-indigo-600"
                  />
                </div>
              )}
            </div>

            {/* Payout Breakdown Summary */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1.5 font-medium">
              <div className="flex justify-between text-slate-600">
                <span>Gross Settlement Amount:</span>
                <span className="font-mono font-bold text-slate-900">{currencySymbol}{payoutAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Lipila Processing Fee:</span>
                <span className="font-mono text-slate-700">{currencySymbol}{fee.toFixed(2)}</span>
              </div>
              <div className="border-t border-slate-200 pt-1.5 flex justify-between font-bold text-slate-900">
                <span>Net Disbursed to Reseller:</span>
                <span className="font-mono text-indigo-900 text-sm font-black">{currencySymbol}{netAmount.toLocaleString()}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                disabled={isProcessing}
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isProcessing || payoutAmount <= 0}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl shadow-sm transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <span className="animate-spin text-sm">&bull;</span>
                    <span>Processing Lipila Payout...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 text-emerald-300" />
                    <span>Disburse via Lipila API</span>
                  </>
                )}
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { 
  X, 
  Printer, 
  Download, 
  Calendar, 
  Building2, 
  DollarSign, 
  CheckCircle2, 
  Users, 
  Receipt,
  FileSpreadsheet,
  Layers,
  ArrowDownRight,
  Sparkles
} from "lucide-react";
import { ResellerPartner, ResellerCommissionRecord, ResellerSettlementPayout } from "../../types";
import { resellerService } from "../../services/resellerService";

interface ResellerStatementModalProps {
  isOpen: boolean;
  onClose: () => void;
  reseller: ResellerPartner | null;
  currencySymbol?: string;
}

export default function ResellerStatementModal({
  isOpen,
  onClose,
  reseller,
  currencySymbol = "K"
}: ResellerStatementModalProps) {
  const today = new Date().toISOString().split("T")[0];
  const firstDayOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split("T")[0];

  const [startDate, setStartDate] = useState(firstDayOfMonth);
  const [endDate, setEndDate] = useState(today);
  const [isLoading, setIsLoading] = useState(false);
  const [statementData, setStatementData] = useState<{
    reseller: ResellerPartner | null;
    startDate: string;
    endDate: string;
    commissions: ResellerCommissionRecord[];
    settlements: ResellerSettlementPayout[];
    totalSubscriptionVolume: number;
    totalCommissionAccrued: number;
    totalCommissionSettled: number;
    closingUnsettledBalance: number;
    uniqueFarmersCount: number;
  } | null>(null);

  useEffect(() => {
    if (!isOpen || !reseller) return;
    loadStatement();
  }, [isOpen, reseller, startDate, endDate]);

  const loadStatement = async () => {
    if (!reseller) return;
    setIsLoading(true);
    try {
      const data = await resellerService.generateCommissionStatement(reseller.id, startDate, endDate);
      setStatementData(data);
    } catch (err) {
      console.error("[ResellerStatementModal] Failed to generate statement:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    if (!statementData || !reseller) return;

    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += `MABALA AGROTECH - RESELLER COMMISSION STATEMENT\n`;
    csvContent += `Reseller Name,${reseller.name}\n`;
    csvContent += `Reseller Code,${reseller.resellerCode}\n`;
    csvContent += `Statement Period,${statementData.startDate} to ${statementData.endDate}\n`;
    csvContent += `Commission Model,${reseller.commissionModel === "percentage" ? `${reseller.commissionRate}% of Subscription` : `K${reseller.commissionRate} Flat Fee / Month`}\n`;
    csvContent += `Total Subscriptions Generated,${currencySymbol}${statementData.totalSubscriptionVolume}\n`;
    csvContent += `Total Commission Accrued,${currencySymbol}${statementData.totalCommissionAccrued}\n`;
    csvContent += `Total Settlements Paid,${currencySymbol}${statementData.totalCommissionSettled}\n`;
    csvContent += `Closing Unsettled Balance,${currencySymbol}${statementData.closingUnsettledBalance}\n\n`;

    csvContent += `ITEMIZED SUBSCRIPTION COMMISSIONS\n`;
    csvContent += `Date,Farmer / Client,Email,Phone,Package,Subscription Fee (${currencySymbol}),Commission Rate,Commission Earned (${currencySymbol}),Payment Ref,Status\n`;

    statementData.commissions.forEach(c => {
      csvContent += `"${c.createdAt.split("T")[0]}","${c.farmerName}","${c.farmerEmail}","${c.farmerPhone || ""}","${c.subscriptionPackage}",${c.subscriptionFeeZMW},"${c.commissionModel === "percentage" ? `${c.commissionRate}%` : `Flat K${c.commissionRate}`}",${c.commissionAmountZMW},"${c.paymentReference}","${c.status}"\n`;
    });

    csvContent += `\nSETTLEMENT DISBURSEMENTS\n`;
    csvContent += `Date,Payout Ref,Provider,Account,Amount Disbursed (${currencySymbol}),Lipila Txn ID,Status\n`;

    statementData.settlements.forEach(s => {
      csvContent += `"${s.settledAt.split("T")[0]}","${s.payoutReference}","${s.payoutProvider.toUpperCase()}","${s.payoutAccount}",${s.amountZMW},"${s.lipilaTransactionId}","${s.lipilaStatus}"\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `mabala_statement_${reseller.resellerCode}_${statementData.startDate}_${statementData.endDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const setPresetRange = (preset: "this-month" | "last-month" | "last-90" | "ytd") => {
    const now = new Date();
    if (preset === "this-month") {
      setStartDate(new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split("T")[0]);
      setEndDate(now.toISOString().split("T")[0]);
    } else if (preset === "last-month") {
      setStartDate(new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().split("T")[0]);
      setEndDate(new Date(now.getFullYear(), now.getMonth(), 0).toISOString().split("T")[0]);
    } else if (preset === "last-90") {
      setStartDate(new Date(now.getTime() - 90 * 86400000).toISOString().split("T")[0]);
      setEndDate(now.toISOString().split("T")[0]);
    } else if (preset === "ytd") {
      setStartDate(new Date(now.getFullYear(), 0, 1).toISOString().split("T")[0]);
      setEndDate(now.toISOString().split("T")[0]);
    }
  };

  if (!isOpen || !reseller) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-[99999] flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col text-slate-900 font-sans animate-fade-in">
        
        {/* Modal Top Header (Screen Only) */}
        <div className="p-5 border-b border-slate-100 flex flex-wrap justify-between items-center gap-4 bg-slate-50/70 rounded-t-3xl print:hidden">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-600 text-white rounded-2xl shadow-sm">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-slate-900">Reseller Commission Statement</h3>
                <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-900 text-emerald-400">
                  {reseller.resellerCode}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Official itemized earnings, subscriber conversions & Lipila settlement audit.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 shadow-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl shadow-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Statement</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-xl transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Controls (Screen Only) */}
        <div className="p-4 bg-slate-100/60 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs font-semibold print:hidden">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-slate-500 text-[11px] uppercase tracking-wider font-extrabold flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> Date Range:
            </span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:outline-emerald-500"
            />
            <span className="text-slate-400">to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:outline-emerald-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setPresetRange("this-month")}
              className="px-2.5 py-1 bg-white hover:bg-slate-200 text-[11px] font-bold text-slate-700 rounded-md border border-slate-200 cursor-pointer"
            >
              This Month
            </button>
            <button
              type="button"
              onClick={() => setPresetRange("last-month")}
              className="px-2.5 py-1 bg-white hover:bg-slate-200 text-[11px] font-bold text-slate-700 rounded-md border border-slate-200 cursor-pointer"
            >
              Last Month
            </button>
            <button
              type="button"
              onClick={() => setPresetRange("last-90")}
              className="px-2.5 py-1 bg-white hover:bg-slate-200 text-[11px] font-bold text-slate-700 rounded-md border border-slate-200 cursor-pointer"
            >
              Last 90 Days
            </button>
            <button
              type="button"
              onClick={() => setPresetRange("ytd")}
              className="px-2.5 py-1 bg-white hover:bg-slate-200 text-[11px] font-bold text-slate-700 rounded-md border border-slate-200 cursor-pointer"
            >
              Year-to-Date
            </button>
          </div>
        </div>

        {/* Printable Formal Statement Body */}
        <div className="p-6 md:p-8 overflow-y-auto flex-1 space-y-6 print:p-0 print:overflow-visible">
          
          {/* Statement Letterhead */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 border-b-2 border-slate-900 pb-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black text-slate-950 tracking-tight">MABALA AGROTECH</span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 font-mono text-[10px] font-extrabold rounded">
                  OFFICIAL RESELLER PARTNER DISPATCH
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-1">
                Enterprise Channel Sales & SaaS Commission Settlement Department
              </p>
              <p className="text-[11px] text-slate-400 font-mono">
                Support: support@mabala.cloud &bull; Lusaka, Zambia
              </p>
            </div>

            <div className="text-right">
              <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block">Statement Reference</span>
              <span className="font-mono text-sm font-black text-slate-900">
                STMT-{reseller.resellerCode}-{endDate.replace(/-/g, "")}
              </span>
              <span className="text-xs text-slate-500 block mt-0.5">
                Generated on: {new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
              </span>
            </div>
          </div>

          {/* Reseller Info & Terms Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 p-5 rounded-2xl border border-slate-200 text-xs">
            <div className="space-y-1.5">
              <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Channel Reseller Partner</span>
              <h4 className="text-sm font-black text-slate-900">{reseller.name}</h4>
              {reseller.organization && <p className="text-slate-600 font-bold">{reseller.organization}</p>}
              <p className="text-slate-500">Email: <span className="font-mono text-slate-800">{reseller.email}</span></p>
              <p className="text-slate-500">Phone: <span className="font-mono text-slate-800">{reseller.phone}</span></p>
              <p className="text-slate-500">Territory: <span className="font-bold text-slate-800">{reseller.district || "Lusaka"}, {reseller.province || "Lusaka Province"}</span></p>
            </div>

            <div className="space-y-1.5 border-t md:border-t-0 md:border-l border-slate-200 md:pl-5 pt-3 md:pt-0">
              <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Payout & Commission Policy</span>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-700">Commission Model:</span>
                <span className="font-mono font-black text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded text-[11px]">
                  {reseller.commissionModel === "percentage" 
                    ? `${reseller.commissionRate}% of Monthly Subscription` 
                    : `K${reseller.commissionRate} Flat / Active Farmer / Mo`}
                </span>
              </div>
              <p className="text-slate-500">
                Payout Gateway: <span className="font-bold text-slate-800 uppercase">{reseller.payoutProvider}</span>
              </p>
              <p className="text-slate-500">
                Account Number: <span className="font-mono font-bold text-slate-800">{reseller.payoutAccountNumber}</span>
              </p>
              <p className="text-slate-500">
                Account Name: <span className="font-bold text-slate-800">{reseller.payoutAccountName}</span>
              </p>
            </div>
          </div>

          {/* Key Statement Summary Metrics */}
          {statementData && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Subscriptions Volume</span>
                <span className="text-base font-black text-slate-900">
                  {currencySymbol}{statementData.totalSubscriptionVolume.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-500 block mt-0.5">{statementData.uniqueFarmersCount} Active Farmers</span>
              </div>

              <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200 shadow-xs">
                <span className="text-[10px] uppercase font-bold text-emerald-700 block">Accrued Commission</span>
                <span className="text-base font-black text-emerald-900">
                  {currencySymbol}{statementData.totalCommissionAccrued.toLocaleString()}
                </span>
                <span className="text-[10px] text-emerald-600 block mt-0.5">{statementData.commissions.length} Transactions</span>
              </div>

              <div className="p-3.5 bg-indigo-50 rounded-xl border border-indigo-200 shadow-xs">
                <span className="text-[10px] uppercase font-bold text-indigo-700 block">Settled via Lipila</span>
                <span className="text-base font-black text-indigo-900">
                  {currencySymbol}{statementData.totalCommissionSettled.toLocaleString()}
                </span>
                <span className="text-[10px] text-indigo-600 block mt-0.5">{statementData.settlements.length} Payouts</span>
              </div>

              <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 shadow-xs">
                <span className="text-[10px] uppercase font-bold text-amber-800 block">Closing Balance</span>
                <span className="text-base font-black text-amber-900">
                  {currencySymbol}{statementData.closingUnsettledBalance.toLocaleString()}
                </span>
                <span className="text-[10px] text-amber-700 block mt-0.5">Pending Payout</span>
              </div>
            </div>
          )}

          {/* Itemized Commissions Table */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-emerald-600" />
                <span>Itemized Farmer Subscription Commissions ({statementData?.commissions.length || 0})</span>
              </h4>
              <span className="text-[11px] text-slate-400 font-medium">
                Period: {statementData?.startDate} &rarr; {statementData?.endDate}
              </span>
            </div>

            {isLoading ? (
              <div className="p-8 text-center text-xs text-slate-500">Loading commission ledger...</div>
            ) : statementData && statementData.commissions.length > 0 ? (
              <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] border-b border-slate-200">
                    <tr>
                      <th className="p-3">Date</th>
                      <th className="p-3">Farmer / Farm Name</th>
                      <th className="p-3">Package Tier</th>
                      <th className="p-3 text-right">Sub Fee ({currencySymbol})</th>
                      <th className="p-3 text-center">Rate</th>
                      <th className="p-3 text-right">Commission ({currencySymbol})</th>
                      <th className="p-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {statementData.commissions.map((comm) => (
                      <tr key={comm.id} className="hover:bg-slate-50 font-medium">
                        <td className="p-3 font-mono text-[11px] text-slate-600 whitespace-nowrap">
                          {comm.createdAt ? comm.createdAt.split("T")[0] : "-"}
                        </td>
                        <td className="p-3">
                          <div className="font-bold text-slate-900">{comm.farmerName}</div>
                          <div className="text-[11px] text-slate-500">{comm.farmerEmail}</div>
                        </td>
                        <td className="p-3 text-slate-700">{comm.subscriptionPackage}</td>
                        <td className="p-3 text-right font-mono font-bold text-slate-900">
                          {currencySymbol}{comm.subscriptionFeeZMW.toLocaleString()}
                        </td>
                        <td className="p-3 text-center font-mono text-[11px] text-slate-600">
                          {comm.commissionModel === "percentage" ? `${comm.commissionRate}%` : `K${comm.commissionRate}`}
                        </td>
                        <td className="p-3 text-right font-mono font-black text-emerald-700">
                          {currencySymbol}{comm.commissionAmountZMW.toLocaleString()}
                        </td>
                        <td className="p-3 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                            comm.status === "settled" 
                              ? "bg-indigo-100 text-indigo-900" 
                              : "bg-emerald-100 text-emerald-900"
                          }`}>
                            {comm.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-slate-50 font-bold border-t border-slate-200 text-slate-900">
                    <tr>
                      <td colSpan={3} className="p-3 uppercase text-[10px] tracking-wider">Total Subscriptions & Commissions:</td>
                      <td className="p-3 text-right font-mono font-black">
                        {currencySymbol}{statementData.totalSubscriptionVolume.toLocaleString()}
                      </td>
                      <td></td>
                      <td className="p-3 text-right font-mono font-black text-emerald-800">
                        {currencySymbol}{statementData.totalCommissionAccrued.toLocaleString()}
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            ) : (
              <div className="p-6 bg-slate-50 rounded-xl border border-slate-200 text-center text-xs text-slate-500">
                No subscription commissions recorded for this reseller in the selected date range.
              </div>
            )}
          </div>

          {/* Settlements History in Statement */}
          {statementData && statementData.settlements.length > 0 && (
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
                <span>Lipila Settlement Disbursements ({statementData.settlements.length})</span>
              </h4>

              <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] border-b border-slate-200">
                    <tr>
                      <th className="p-3">Disbursed Date</th>
                      <th className="p-3">Payout Ref</th>
                      <th className="p-3">Provider</th>
                      <th className="p-3">Destination Account</th>
                      <th className="p-3 text-right">Amount ({currencySymbol})</th>
                      <th className="p-3 text-center">Lipila Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {statementData.settlements.map((settle) => (
                      <tr key={settle.id} className="hover:bg-slate-50 font-medium">
                        <td className="p-3 font-mono text-[11px] text-slate-600 whitespace-nowrap">
                          {settle.settledAt ? settle.settledAt.split("T")[0] : "-"}
                        </td>
                        <td className="p-3 font-mono text-slate-900 font-bold">{settle.payoutReference}</td>
                        <td className="p-3 uppercase font-bold text-slate-700">{settle.payoutProvider}</td>
                        <td className="p-3 font-mono text-slate-600">{settle.payoutAccount} ({settle.accountName})</td>
                        <td className="p-3 text-right font-mono font-black text-indigo-900">
                          {currencySymbol}{settle.amountZMW.toLocaleString()}
                        </td>
                        <td className="p-3 text-center">
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-mono text-[10px] font-bold">
                            {settle.lipilaStatus}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Statement Certification Sign-off */}
          <div className="border-t border-slate-200 pt-6 mt-8 grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-600">
            <div>
              <p className="font-bold text-slate-900">Mabala Platform Verification</p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                This statement is system-generated and mathematically verified against the Mabala Dual-Entry Accounting Ledger and Lipila Mobile Money API gateway records.
              </p>
            </div>
            <div className="text-left md:text-right">
              <p className="font-bold text-slate-900">Super Admin Authorized Sign-off</p>
              <p className="text-[11px] font-mono text-slate-500 mt-0.5">
                Digital Hash: {Math.random().toString(36).substring(2, 15).toUpperCase()} &bull; support@mabala.cloud
              </p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { 
  Building2, 
  Users, 
  DollarSign, 
  Send, 
  Printer, 
  Plus, 
  Search, 
  Edit3, 
  FileText, 
  CheckCircle2, 
  Clock, 
  TrendingUp, 
  Percent, 
  CreditCard,
  Layers,
  ArrowUpRight,
  ShieldCheck,
  RotateCw,
  Award,
  Sparkles,
  ExternalLink,
  ChevronRight
} from "lucide-react";
import { ResellerPartner, ResellerCommissionRecord, ResellerSettlementPayout } from "../../types";
import { resellerService } from "../../services/resellerService";
import ResellerStatementModal from "./ResellerStatementModal";
import LipilaResellerPayoutModal from "./LipilaResellerPayoutModal";
import ResellerEditModal from "./ResellerEditModal";

interface SuperAdminResellerHubProps {
  adminProfile?: any;
  currencySymbol?: string;
}

export default function SuperAdminResellerHub({
  adminProfile,
  currencySymbol = "K"
}: SuperAdminResellerHubProps) {
  const [activeTab, setActiveTab] = useState<"directory" | "commissions" | "settlements">("directory");
  const [resellers, setResellers] = useState<ResellerPartner[]>([]);
  const [commissions, setCommissions] = useState<ResellerCommissionRecord[]>([]);
  const [settlements, setSettlements] = useState<ResellerSettlementPayout[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [modelFilter, setModelFilter] = useState<string>("ALL");

  // Modals state
  const [statementModalOpen, setStatementModalOpen] = useState<boolean>(false);
  const [payoutModalOpen, setPayoutModalOpen] = useState<boolean>(false);
  const [editModalOpen, setEditModalOpen] = useState<boolean>(false);
  const [selectedReseller, setSelectedReseller] = useState<ResellerPartner | null>(null);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [resList, commList, setList] = await Promise.all([
        resellerService.getAllResellers(),
        resellerService.getAllCommissionRecords(),
        resellerService.getAllSettlements()
      ]);
      setResellers(resList);
      setCommissions(commList);
      setSettlements(setList);
    } catch (err) {
      console.error("[SuperAdminResellerHub] Failed to load data:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Summary Metrics
  const totalResellers = resellers.length;
  const activeResellers = resellers.filter(r => r.status === "active").length;
  const totalOnboardedFarmers = resellers.reduce((acc, r) => acc + (r.totalOnboardedFarmers || 0), 0);
  const totalSubscriptionVolume = resellers.reduce((acc, r) => acc + (r.totalSubscriptionVolumeZMW || 0), 0);
  const totalAccumulatedCommission = resellers.reduce((acc, r) => acc + (r.accumulatedCommissionZMW || 0), 0);
  const totalSettledCommission = resellers.reduce((acc, r) => acc + (r.settledCommissionZMW || 0), 0);
  const totalUnsettledBalance = resellers.reduce((acc, r) => acc + (r.unsettledBalanceZMW || 0), 0);

  // Filtered Resellers
  const filteredResellers = resellers.filter(r => {
    if (statusFilter !== "ALL" && r.status !== statusFilter) return false;
    if (modelFilter !== "ALL" && r.commissionModel !== modelFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        r.name.toLowerCase().includes(q) ||
        r.resellerCode.toLowerCase().includes(q) ||
        r.email.toLowerCase().includes(q) ||
        r.phone.includes(q) ||
        (r.district && r.district.toLowerCase().includes(q)) ||
        (r.province && r.province.toLowerCase().includes(q)) ||
        (r.organization && r.organization.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const openStatement = (reseller: ResellerPartner) => {
    setSelectedReseller(reseller);
    setStatementModalOpen(true);
  };

  const openPayout = (reseller: ResellerPartner) => {
    setSelectedReseller(reseller);
    setPayoutModalOpen(true);
  };

  const openEdit = (reseller?: ResellerPartner) => {
    setSelectedReseller(reseller || null);
    setEditModalOpen(true);
  };

  const handleSettlementSuccess = (payout: ResellerSettlementPayout) => {
    loadData();
  };

  const handleSavedReseller = (partner: ResellerPartner) => {
    loadData();
  };

  return (
    <div className="space-y-6 font-sans">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 font-mono text-[11px] font-bold rounded-full border border-emerald-500/30">
              Super Admin SaaS Operations
            </span>
            <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 font-mono text-[10px] font-bold rounded-full">
              Lipila B2C Payouts Enabled
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2.5">
            <Building2 className="w-8 h-8 text-emerald-400" />
            <span>Reseller & Commission Management Hub</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl font-medium">
            Empower channel partners to resell Mabala subscriptions. Auto-accrue monthly percentage or flat fee commissions per farmer, track accumulated balances, and execute instant individual Lipila payouts.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={loadData}
            className="p-3 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded-2xl border border-slate-700 transition cursor-pointer"
            title="Refresh Ledger"
          >
            <RotateCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
          </button>

          <button
            type="button"
            onClick={() => openEdit()}
            className="px-4.5 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-2xl shadow-lg shadow-emerald-900/30 flex items-center gap-2 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Reseller Partner</span>
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 flex items-center gap-1">
            <Building2 className="w-3.5 h-3.5 text-indigo-600" /> Resellers
          </span>
          <div className="text-xl font-black text-slate-900">{totalResellers}</div>
          <span className="text-[10px] text-emerald-600 font-bold">{activeResellers} active partners</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 flex items-center gap-1">
            <Users className="w-3.5 h-3.5 text-emerald-600" /> Farmers Onboarded
          </span>
          <div className="text-xl font-black text-slate-900">{totalOnboardedFarmers}</div>
          <span className="text-[10px] text-slate-500 font-medium">Channel acquisitions</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-sky-600" /> Sub Volume
          </span>
          <div className="text-xl font-black font-mono text-slate-900">
            {currencySymbol}{totalSubscriptionVolume.toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-500 font-medium">Gross revenue generated</span>
        </div>

        <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200 shadow-xs space-y-1">
          <span className="text-[10px] font-extrabold uppercase text-emerald-800 flex items-center gap-1">
            <DollarSign className="w-3.5 h-3.5 text-emerald-600" /> Total Accrued
          </span>
          <div className="text-xl font-black font-mono text-emerald-900">
            {currencySymbol}{totalAccumulatedCommission.toLocaleString()}
          </div>
          <span className="text-[10px] text-emerald-700 font-medium">Gross earned commission</span>
        </div>

        <div className="bg-indigo-50/60 p-4 rounded-2xl border border-indigo-200 shadow-xs space-y-1">
          <span className="text-[10px] font-extrabold uppercase text-indigo-800 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" /> Settled via Lipila
          </span>
          <div className="text-xl font-black font-mono text-indigo-900">
            {currencySymbol}{totalSettledCommission.toLocaleString()}
          </div>
          <span className="text-[10px] text-indigo-700 font-medium">{settlements.length} disbursements</span>
        </div>

        <div className="bg-amber-50/80 p-4 rounded-2xl border border-amber-300 shadow-xs space-y-1">
          <span className="text-[10px] font-extrabold uppercase text-amber-900 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-amber-600" /> Pending Payout
          </span>
          <div className="text-xl font-black font-mono text-amber-950">
            {currencySymbol}{totalUnsettledBalance.toLocaleString()}
          </div>
          <span className="text-[10px] text-amber-800 font-bold">Unsettled partner balance</span>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab("directory")}
            className={`px-4 py-2.5 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
              activeTab === "directory"
                ? "bg-slate-900 text-white shadow-sm"
                : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
            }`}
          >
            <Building2 className="w-4 h-4 text-emerald-400" />
            <span>Reseller Directory & Payouts ({resellers.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab("commissions")}
            className={`px-4 py-2.5 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
              activeTab === "commissions"
                ? "bg-slate-900 text-white shadow-sm"
                : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
            }`}
          >
            <DollarSign className="w-4 h-4 text-indigo-400" />
            <span>Accrued Commission Ledger ({commissions.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab("settlements")}
            className={`px-4 py-2.5 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
              activeTab === "settlements"
                ? "bg-slate-900 text-white shadow-sm"
                : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
            }`}
          >
            <Send className="w-4 h-4 text-sky-400" />
            <span>Lipila Disbursal History ({settlements.length})</span>
          </button>
        </div>
      </div>

      {/* TAB 1: RESELLER DIRECTORY */}
      {activeTab === "directory" && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5">
          
          {/* Search and Filters */}
          <div className="flex flex-wrap justify-between items-center gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search reseller code, name, phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-emerald-500"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
              >
                <option value="ALL">All Statuses</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="suspended">Suspended</option>
              </select>

              <select
                value={modelFilter}
                onChange={(e) => setModelFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
              >
                <option value="ALL">All Commission Models</option>
                <option value="percentage">Percentage (%)</option>
                <option value="flat">Flat Fee (ZMW)</option>
              </select>
            </div>
          </div>

          {/* Resellers Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-2xl shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-black uppercase text-[10px] border-b border-slate-200">
                <tr>
                  <th className="p-3.5">Reseller Partner</th>
                  <th className="p-3.5">Referral Code</th>
                  <th className="p-3.5">Territory</th>
                  <th className="p-3.5">Commission Model</th>
                  <th className="p-3.5 text-center">Farmers Onboarded</th>
                  <th className="p-3.5 text-right">Accumulated</th>
                  <th className="p-3.5 text-right">Unsettled Balance</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {filteredResellers.length > 0 ? (
                  filteredResellers.map((reseller) => (
                    <tr key={reseller.id} className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5">
                        <div className="font-black text-slate-900 text-sm">{reseller.name}</div>
                        {reseller.organization && (
                          <div className="text-[11px] text-slate-500 font-semibold">{reseller.organization}</div>
                        )}
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                          {reseller.email} &bull; {reseller.phone}
                        </div>
                      </td>

                      <td className="p-3.5">
                        <span className="font-mono text-xs font-black bg-slate-900 text-emerald-400 px-2.5 py-1 rounded-lg">
                          {reseller.resellerCode}
                        </span>
                      </td>

                      <td className="p-3.5 text-slate-700 font-semibold">
                        {reseller.district || "Lusaka"}, {reseller.province || "Lusaka"}
                      </td>

                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-900 inline-block font-mono">
                          {reseller.commissionModel === "percentage" 
                            ? `${reseller.commissionRate}% / mo` 
                            : `K${reseller.commissionRate} Flat / Farmer`}
                        </span>
                      </td>

                      <td className="p-3.5 text-center">
                        <div className="font-black text-slate-900 text-sm">{reseller.totalOnboardedFarmers || 0}</div>
                        <div className="text-[10px] text-emerald-600 font-bold">{reseller.activeSubscribers || 0} active subs</div>
                      </td>

                      <td className="p-3.5 text-right font-mono font-bold text-slate-700">
                        {currencySymbol}{(reseller.accumulatedCommissionZMW || 0).toLocaleString()}
                      </td>

                      <td className="p-3.5 text-right">
                        <div className={`font-mono text-sm font-black ${
                          (reseller.unsettledBalanceZMW || 0) > 0 ? "text-amber-700" : "text-slate-400"
                        }`}>
                          {currencySymbol}{(reseller.unsettledBalanceZMW || 0).toLocaleString()}
                        </div>
                        {(reseller.settledCommissionZMW || 0) > 0 && (
                          <div className="text-[10px] text-indigo-600 font-bold">
                            K{(reseller.settledCommissionZMW || 0).toLocaleString()} paid
                          </div>
                        )}
                      </td>

                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          
                          {/* Settle via Lipila Button */}
                          <button
                            type="button"
                            onClick={() => openPayout(reseller)}
                            disabled={(reseller.unsettledBalanceZMW || 0) <= 0}
                            className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] rounded-lg shadow-xs flex items-center gap-1 transition cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                            title="Settle commission via Lipila API"
                          >
                            <Send className="w-3 h-3 text-emerald-300" />
                            <span>Settle via Lipila</span>
                          </button>

                          {/* Print Statement Button */}
                          <button
                            type="button"
                            onClick={() => openStatement(reseller)}
                            className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] rounded-lg border border-slate-200 flex items-center gap-1 transition cursor-pointer"
                            title="Print Commission Statement"
                          >
                            <Printer className="w-3 h-3 text-slate-600" />
                            <span>Statement</span>
                          </button>

                          {/* Edit Partner Button */}
                          <button
                            type="button"
                            onClick={() => openEdit(reseller)}
                            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                            title="Edit Partner Profile"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-500">
                      No resellers found matching current search criteria.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* TAB 2: ACCRUED COMMISSIONS LEDGER */}
      {activeTab === "commissions" && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-base font-black text-slate-900">Subscription Commission Accruals</h3>
              <p className="text-xs text-slate-500 font-medium">
                Live audit trail of commissions generated automatically upon farmer subscription payment.
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-lg">
              {commissions.length} Ledger Records
            </span>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-2xl shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-black uppercase text-[10px] border-b border-slate-200">
                <tr>
                  <th className="p-3">Date</th>
                  <th className="p-3">Reseller</th>
                  <th className="p-3">Farmer / Subscriber</th>
                  <th className="p-3">Package Tier</th>
                  <th className="p-3 text-right">Sub Fee ({currencySymbol})</th>
                  <th className="p-3 text-center">Model / Rate</th>
                  <th className="p-3 text-right">Commission ({currencySymbol})</th>
                  <th className="p-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {commissions.length > 0 ? (
                  commissions.map((comm) => (
                    <tr key={comm.id} className="hover:bg-slate-50">
                      <td className="p-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                        {comm.createdAt ? comm.createdAt.split("T")[0] : "-"}
                      </td>
                      <td className="p-3">
                        <span className="font-bold text-slate-900 block">{comm.resellerName}</span>
                        <span className="font-mono text-[10px] text-slate-400">{comm.resellerCode}</span>
                      </td>
                      <td className="p-3">
                        <div className="font-bold text-slate-800">{comm.farmerName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{comm.farmerEmail}</div>
                      </td>
                      <td className="p-3 text-slate-700">{comm.subscriptionPackage}</td>
                      <td className="p-3 text-right font-mono font-bold text-slate-900">
                        {currencySymbol}{comm.subscriptionFeeZMW.toLocaleString()}
                      </td>
                      <td className="p-3 text-center font-mono text-[11px] text-slate-600">
                        {comm.commissionModel === "percentage" ? `${comm.commissionRate}%` : `Flat K${comm.commissionRate}`}
                      </td>
                      <td className="p-3 text-right font-mono font-black text-emerald-700">
                        {currencySymbol}{comm.commissionAmountZMW.toLocaleString()}
                      </td>
                      <td className="p-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                          comm.status === "settled" 
                            ? "bg-indigo-100 text-indigo-900" 
                            : "bg-emerald-100 text-emerald-900"
                        }`}>
                          {comm.status}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-500">
                      No commission records accrued yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: LIPILA SETTLEMENT DISBURSALS */}
      {activeTab === "settlements" && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-base font-black text-slate-900">Lipila API Settlement Disbursals</h3>
              <p className="text-xs text-slate-500 font-medium">
                Record of all Mobile Money & Bank payouts disbursed from the Super Admin portal.
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-indigo-700 bg-indigo-50 px-3 py-1 rounded-lg">
              {settlements.length} Payouts Completed
            </span>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-2xl shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-black uppercase text-[10px] border-b border-slate-200">
                <tr>
                  <th className="p-3">Disbursed Date</th>
                  <th className="p-3">Payout Ref</th>
                  <th className="p-3">Reseller</th>
                  <th className="p-3">Channel / Provider</th>
                  <th className="p-3">Destination Account</th>
                  <th className="p-3 text-right">Disbursed ({currencySymbol})</th>
                  <th className="p-3 text-center">Lipila Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {settlements.length > 0 ? (
                  settlements.map((settle) => (
                    <tr key={settle.id} className="hover:bg-slate-50">
                      <td className="p-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                        {settle.settledAt ? settle.settledAt.split("T")[0] : "-"}
                      </td>
                      <td className="p-3 font-mono font-bold text-slate-900">{settle.payoutReference}</td>
                      <td className="p-3">
                        <span className="font-bold text-slate-900 block">{settle.resellerName}</span>
                        <span className="font-mono text-[10px] text-slate-400">{settle.resellerCode}</span>
                      </td>
                      <td className="p-3 uppercase font-bold text-slate-700">{settle.payoutProvider}</td>
                      <td className="p-3 font-mono text-slate-600">
                        {settle.payoutAccount} ({settle.accountName})
                      </td>
                      <td className="p-3 text-right font-mono font-black text-indigo-900">
                        {currencySymbol}{settle.amountZMW.toLocaleString()}
                      </td>
                      <td className="p-3 text-center">
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-mono text-[10px] font-bold">
                          {settle.lipilaStatus}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-500">
                      No Lipila settlements recorded yet. Use the "Settle via Lipila" button in the directory to disburse commissions.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODALS */}
      <ResellerStatementModal
        isOpen={statementModalOpen}
        onClose={() => {
          setStatementModalOpen(false);
          setSelectedReseller(null);
        }}
        reseller={selectedReseller}
        currencySymbol={currencySymbol}
      />

      <LipilaResellerPayoutModal
        isOpen={payoutModalOpen}
        onClose={() => {
          setPayoutModalOpen(false);
          setSelectedReseller(null);
        }}
        reseller={selectedReseller}
        adminProfile={adminProfile}
        onSettlementSuccess={handleSettlementSuccess}
        currencySymbol={currencySymbol}
      />

      <ResellerEditModal
        isOpen={editModalOpen}
        onClose={() => {
          setEditModalOpen(false);
          setSelectedReseller(null);
        }}
        reseller={selectedReseller}
        onSaved={handleSavedReseller}
        currencySymbol={currencySymbol}
      />

    </div>
  );
}

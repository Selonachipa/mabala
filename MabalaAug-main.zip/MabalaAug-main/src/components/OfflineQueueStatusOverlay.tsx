import React, { useState, useEffect } from "react";
import { 
  offlineQueueService, 
  OfflineQueueState, 
  OfflineQueueItem, 
  formatModuleName 
} from "../services/offlineQueueService";
import { 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  CloudUpload, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Trash2, 
  Layers, 
  ArrowUpRight, 
  X, 
  RotateCw,
  HardDrive,
  Check,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  FileText
} from "lucide-react";

interface OfflineQueueStatusOverlayProps {
  onOpenFullSyncPanel?: () => void;
  onFlushQueue?: (item: OfflineQueueItem) => Promise<boolean>;
  className?: string;
}

export default function OfflineQueueStatusOverlay({
  onOpenFullSyncPanel,
  onFlushQueue,
  className = ""
}: OfflineQueueStatusOverlayProps) {
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== "undefined" ? navigator.onLine : true
  );
  const [queueState, setQueueState] = useState<OfflineQueueState>(() => offlineQueueService.getState());
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [expandedItemId, setExpandedItemId] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  // Monitor browser network connectivity
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Subscribe to durable offline queue state
  useEffect(() => {
    const unsubscribe = offlineQueueService.subscribe((state) => {
      setQueueState(state);
    });
    return unsubscribe;
  }, []);

  const pendingItems = queueState.items;
  const pendingCount = queueState.pendingCount;
  const highPriorityCount = pendingItems.filter(i => i.priority === "high").length;
  const failedCount = pendingItems.filter(i => i.status === "failed").length;

  const handleManualFlush = async () => {
    if (isSyncing || pendingCount === 0) return;
    setIsSyncing(true);
    setActionFeedback("Syncing pending offline queue to Google Cloud Firestore...");

    try {
      if (onFlushQueue) {
        await offlineQueueService.flushQueue(onFlushQueue);
      } else {
        // Fallback flush executor
        await offlineQueueService.flushQueue(async () => true);
      }
      setActionFeedback("Offline sync completed successfully!");
      setTimeout(() => setActionFeedback(null), 3500);
    } catch (err: any) {
      setActionFeedback(`Sync encountered an issue: ${err?.message || "Check network connectivity"}`);
      setTimeout(() => setActionFeedback(null), 4000);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleRetrySingleItem = async (itemId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      if (onFlushQueue) {
        await offlineQueueService.forceRetryItem(itemId, onFlushQueue);
      } else {
        await offlineQueueService.forceRetryItem(itemId, async () => true);
      }
    } catch (err: any) {
      console.warn("Single item retry error:", err);
    }
  };

  const handleRemoveSingleItem = (itemId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    offlineQueueService.removeQueueItem(itemId);
  };

  const formatTimestamp = (isoString?: string) => {
    if (!isoString) return "Just now";
    try {
      const date = new Date(isoString);
      if (isNaN(date.getTime())) return isoString;
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }) + " (" + date.toLocaleDateString([], { month: "short", day: "numeric" }) + ")";
    } catch {
      return isoString;
    }
  };

  return (
    <>
      {/* TRIGGER BADGE / OVERLAY BUTTON */}
      <button
        type="button"
        id="offline-queue-status-trigger"
        onClick={() => setIsOpen(true)}
        title={
          !isOnline
            ? `Offline mode: ${pendingCount} pending item${pendingCount === 1 ? "" : "s"} stored in durable local cache.`
            : pendingCount > 0
            ? `${pendingCount} item${pendingCount === 1 ? "" : "s"} waiting in offline queue. Click to view detailed sync list.`
            : "Cloud Sync: All local data synchronized."
        }
        className={`relative px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-xs select-none ${
          !isOnline
            ? "bg-amber-500/10 border-amber-500/30 text-amber-700 hover:bg-amber-500/20"
            : pendingCount > 0
            ? "bg-sky-500/10 border-sky-500/30 text-sky-700 hover:bg-sky-500/20"
            : "bg-emerald-500/10 border-emerald-500/30 text-emerald-700 hover:bg-emerald-500/20"
        } ${className}`}
      >
        {!isOnline ? (
          <>
            <WifiOff className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="font-mono text-[11px] font-black uppercase tracking-tight">Offline</span>
            {pendingCount > 0 && (
              <span className="bg-amber-600 text-white text-[10px] font-black px-1.5 py-0.2 rounded-full font-mono">
                {pendingCount}
              </span>
            )}
          </>
        ) : queueState.isFlushing || isSyncing ? (
          <>
            <RefreshCw className="w-3.5 h-3.5 text-sky-600 animate-spin shrink-0" />
            <span className="font-mono text-[11px] font-black uppercase tracking-tight">Syncing ({pendingCount})</span>
          </>
        ) : pendingCount > 0 ? (
          <>
            <CloudUpload className="w-3.5 h-3.5 text-sky-600 shrink-0" />
            <span className="font-mono text-[11px] font-black uppercase tracking-tight">Queue:</span>
            <span className="bg-sky-600 text-white text-[10px] font-black px-1.5 py-0.2 rounded-full font-mono">
              {pendingCount}
            </span>
          </>
        ) : (
          <>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0 inline-block" />
            <span className="font-mono text-[11px] font-black uppercase tracking-tight">Live Sync</span>
          </>
        )}
      </button>

      {/* DETAILED STATUS OVERLAY MODAL */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in"
          id="offline-queue-detail-overlay"
        >
          <div className="bg-white border border-slate-200 rounded-3xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden animate-scale-up">
            
            {/* Overlay Header */}
            <div className="p-5 border-b border-slate-100 bg-slate-50/80 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                  !isOnline ? "bg-amber-100 text-amber-700" : pendingCount > 0 ? "bg-sky-100 text-sky-700" : "bg-emerald-100 text-emerald-700"
                }`}>
                  <CloudUpload className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-black text-slate-900">
                      Offline Sync Queue & Status
                    </h3>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-black font-mono uppercase tracking-wider ${
                      !isOnline ? "bg-amber-100 text-amber-800" : "bg-emerald-100 text-emerald-800"
                    }`}>
                      {isOnline ? "Online Connected" : "Offline Storage Active"}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Durable client-side queue backed by IndexedDB persistence and auto-retry.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition cursor-pointer"
                title="Close overlay"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Metrics Breakdown Bar */}
            <div className="grid grid-cols-3 gap-2 p-4 bg-slate-100/60 border-b border-slate-200/60 text-xs shrink-0">
              <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
                <span className="text-[10px] font-bold uppercase text-slate-400 block font-mono">Total Pending</span>
                <span className="text-xl font-black text-slate-900 font-mono">{pendingCount}</span>
                <span className="text-[10.5px] text-slate-500 block">mutations awaiting sync</span>
              </div>
              <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
                <span className="text-[10px] font-bold uppercase text-rose-500 block font-mono">High Priority</span>
                <span className="text-xl font-black text-rose-600 font-mono">{highPriorityCount}</span>
                <span className="text-[10.5px] text-slate-500 block">financial & loss records</span>
              </div>
              <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
                <span className="text-[10px] font-bold uppercase text-amber-500 block font-mono">Failed / Retrying</span>
                <span className="text-xl font-black text-amber-600 font-mono">{failedCount}</span>
                <span className="text-[10.5px] text-slate-500 block">auto-retry on reconnect</span>
              </div>
            </div>

            {/* Action Feedback Banner */}
            {actionFeedback && (
              <div className="px-5 py-2.5 bg-indigo-50 border-b border-indigo-100 text-xs font-semibold text-indigo-800 flex items-center gap-2 animate-fade-in shrink-0">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-600 shrink-0" />
                <span>{actionFeedback}</span>
              </div>
            )}

            {/* Queue List Content */}
            <div className="p-5 overflow-y-auto flex-1 space-y-3">
              {pendingItems.length === 0 ? (
                <div className="text-center py-12 space-y-3">
                  <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-100 flex items-center justify-center mx-auto shadow-xs">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h4 className="text-sm font-black text-slate-800">
                    All Local Data Synced with Cloud
                  </h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                    There are currently 0 items in your offline sync queue. Every transaction, crop entry, and livestock record is up to date in cloud storage.
                  </p>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between pb-1">
                    <span className="text-[11px] font-black uppercase text-slate-500 font-mono tracking-wider">
                      Pending Sync Queue ({pendingItems.length})
                    </span>
                    <span className="text-[10.5px] text-slate-400">
                      Auto-flushes sequentially upon network restoration
                    </span>
                  </div>

                  {pendingItems.map((item) => {
                    const isExpanded = expandedItemId === item.id;
                    const moduleName = formatModuleName(item);

                    return (
                      <div
                        key={item.id}
                        onClick={() => setExpandedItemId(isExpanded ? null : item.id)}
                        className={`p-3.5 rounded-2xl border transition cursor-pointer select-none ${
                          item.priority === "high"
                            ? "bg-rose-50/40 border-rose-200 hover:border-rose-300"
                            : item.status === "failed"
                            ? "bg-amber-50/40 border-amber-200 hover:border-amber-300"
                            : "bg-white border-slate-200 hover:border-slate-300"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="space-y-1 min-w-0 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-slate-900 text-white font-mono uppercase">
                                {moduleName}
                              </span>
                              {item.priority === "high" && (
                                <span className="px-1.5 py-0.2 rounded text-[9.5px] font-bold bg-rose-100 text-rose-700 border border-rose-200 font-mono">
                                  HIGH PRIORITY
                                </span>
                              )}
                              <span className={`px-1.5 py-0.2 rounded text-[9.5px] font-bold font-mono ${
                                item.status === "syncing"
                                  ? "bg-sky-100 text-sky-700 animate-pulse"
                                  : item.status === "failed"
                                  ? "bg-amber-100 text-amber-700"
                                  : "bg-slate-100 text-slate-600"
                              }`}>
                                {item.status.toUpperCase()}
                              </span>
                              {item.retryCount > 0 && (
                                <span className="text-[10px] text-slate-400 font-mono">
                                  (Retried {item.retryCount}x)
                                </span>
                              )}
                            </div>

                            <p className="text-xs font-bold text-slate-800 truncate">
                              {item.summaryLabel || `${item.actionType} ${item.moduleKey ? `[${item.moduleKey}]` : ""}`}
                            </p>

                            <div className="flex items-center gap-3 text-[10.5px] text-slate-400 font-mono">
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-400" />
                                {formatTimestamp(item.clientTimestamp)}
                              </span>
                              <span>• ID: {item.id.slice(0, 14)}...</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0 pt-0.5">
                            {isOnline && (
                              <button
                                type="button"
                                onClick={(e) => handleRetrySingleItem(item.id, e)}
                                className="p-1.5 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 text-xs font-bold transition"
                                title="Retry syncing this item immediately"
                              >
                                <RotateCw className="w-3.5 h-3.5" />
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={(e) => handleRemoveSingleItem(item.id, e)}
                              className="p-1.5 rounded-lg bg-slate-100 text-slate-500 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200 border border-transparent text-xs font-bold transition"
                              title="Discard from queue"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                            <span className="text-slate-400 pl-1">
                              {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                            </span>
                          </div>
                        </div>

                        {/* Expanded Payload Inspector */}
                        {isExpanded && (
                          <div className="mt-3 pt-3 border-t border-slate-200/80 space-y-2 text-xs animate-fade-in">
                            <div className="flex items-center justify-between text-[10px] font-bold font-mono text-slate-400 uppercase">
                              <span>Action: {item.actionType}</span>
                              <span>Target UID: {item.targetUid || "Current User"}</span>
                            </div>
                            {item.lastError && (
                              <div className="p-2 rounded-lg bg-amber-50 border border-amber-200 text-[11px] text-amber-800">
                                <strong>Last Sync Error:</strong> {item.lastError}
                              </div>
                            )}
                            <div className="bg-slate-900 text-emerald-400 p-2.5 rounded-xl font-mono text-[10px] max-h-36 overflow-y-auto leading-tight">
                              <pre>{JSON.stringify(item.payload, null, 2)}</pre>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </>
              )}
            </div>

            {/* Overlay Footer Actions */}
            <div className="p-4 border-t border-slate-200/80 bg-slate-50/90 flex flex-wrap items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-2">
                {onOpenFullSyncPanel && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsOpen(false);
                      onOpenFullSyncPanel();
                    }}
                    className="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold border border-slate-200 shadow-2xs transition cursor-pointer inline-flex items-center gap-1.5"
                  >
                    <Layers className="w-3.5 h-3.5 text-slate-500" />
                    <span>Open Offline Diagnostics Panel</span>
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 text-xs font-bold transition cursor-pointer"
                >
                  Dismiss
                </button>
                {pendingCount > 0 && (
                  <button
                    type="button"
                    onClick={handleManualFlush}
                    disabled={isSyncing || !isOnline}
                    className={`px-4 py-2 rounded-xl text-xs font-bold font-mono inline-flex items-center gap-2 shadow-xs transition cursor-pointer ${
                      !isOnline
                        ? "bg-slate-200 text-slate-400 cursor-not-allowed"
                        : "bg-slate-950 hover:bg-slate-800 text-white"
                    }`}
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin" : ""}`} />
                    <span>{isSyncing ? "Flushing Queue..." : `Sync ${pendingCount} Item${pendingCount === 1 ? "" : "s"} Now`}</span>
                  </button>
                )}
              </div>
            </div>

          </div>
        </div>
      )}
    </>
  );
}

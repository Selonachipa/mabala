import React, { useState } from "react";
import { CropCycle } from "../types";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  PieChart, 
  Pie, 
  Cell, 
  LineChart, 
  Line 
} from "recharts";
import { 
  TrendingUp, 
  Cpu, 
  Sliders, 
  Sparkles, 
  Sprout, 
  Droplets, 
  Sun, 
  ShieldAlert, 
  CheckCircle2, 
  DollarSign, 
  Calculator,
  BarChart2,
  Info
} from "lucide-react";

interface YieldForecastingModuleProps {
  crops?: CropCycle[];
  currencySymbol?: string;
  onAddCropClick?: () => void;
}

// Variety Genetics Baseline Potential (MT/Ha under optimal conditions)
const VARIETY_BASELINE_MT_HA: Record<string, number> = {
  "SC 719 (Late Maturing)": 8.8,
  "SC 659 (Medium Maturing)": 7.4,
  "SC 419 (Early Maturing)": 5.5,
  "SC 301 (Sweet/Fresh)": 4.8,
  "Safari (Early)": 3.2,
  "ZMS 512 (Medium)": 3.8,
  "Rodade (Determinate)": 38.0,
  "Money Maker (Indeterminate)": 45.0,
  "Drumhead (Large)": 32.0,
  "Texas Grano (Short Day)": 28.0,
  "BP1 (Medium Early)": 24.0,
  "Default": 6.0
};

export default function YieldForecastingModule({
  crops = [],
  currencySymbol = "ZK",
  onAddCropClick
}: YieldForecastingModuleProps) {
  // Determine user registration year / starting season
  const registrationYear = React.useMemo(() => {
    try {
      const userStr = localStorage.getItem("mabala_current_user");
      if (userStr) {
        const u = JSON.parse(userStr);
        if (u.createdAt) {
          const yr = new Date(u.createdAt).getFullYear();
          if (!isNaN(yr) && yr >= 2020) return yr;
        }
      }
      const activeFarmStr = localStorage.getItem("mabala_active_farm");
      if (activeFarmStr) {
        const f = JSON.parse(activeFarmStr);
        if (f.createdAt) {
          const yr = new Date(f.createdAt).getFullYear();
          if (!isNaN(yr) && yr >= 2020) return yr;
        }
      }
    } catch (_) {}
    return new Date().getFullYear();
  }, []);

  const registrationSeasonLabel = `${registrationYear}/${(registrationYear + 1).toString().slice(-2)} Season`;

  // Active Crop selection or manual simulation parameters
  const [selectedCropId, setSelectedCropId] = useState<string>(crops.length > 0 ? crops[0].id : "");

  // Update selectedCropId if crops change
  React.useEffect(() => {
    if (crops.length > 0 && (!selectedCropId || !crops.find(c => c.id === selectedCropId))) {
      setSelectedCropId(crops[0].id);
    }
  }, [crops, selectedCropId]);

  // Selected crop details
  const activeCrop = crops.find(c => c.id === selectedCropId) || (crops.length > 0 ? crops[0] : undefined);

  // Simulation Controls (What-If Scenario Sliders)
  const [areaHa, setAreaHa] = useState<number>(activeCrop ? (activeCrop.areaHectares || 2.5) : 2.5);
  const [moisturePct, setMoisturePct] = useState<number>(100); // 100% = normal optimal rainfall/irrigation
  const [nitrogenKgHa, setNitrogenKgHa] = useState<number>(160); // 160 kg N/ha standard
  const [pestRiskPct, setPestRiskPct] = useState<number>(5); // 5% baseline pest pressure
  const [soilHealthRating, setSoilHealthRating] = useState<number>(85); // 85/100 soil index
  const [pricePerKg, setPricePerKg] = useState<number>(
    activeCrop ? (activeCrop.expectedSellingPricePerKg || 4.2) : 4.2
  );

  // Sync parameters when selected crop changes
  const handleCropSelect = (id: string) => {
    setSelectedCropId(id);
    const crop = crops.find(c => c.id === id);
    if (crop) {
      setAreaHa(crop.areaHectares || 2.5);
      setPricePerKg(crop.expectedSellingPricePerKg || 4.2);
    }
  };

  // If no crops are configured, show informative prompt to add a new crop cycle
  if (crops.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-2xl p-8 shadow-sm space-y-6 text-center">
        <div className="max-w-md mx-auto space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-600 border border-indigo-200 flex items-center justify-center mx-auto shadow-xs">
            <Cpu className="w-7 h-7" />
          </div>
          <h3 className="text-base font-black text-slate-900">
            Machine Learning Harvest Yield Forecasting Engine
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            No crop cycles have been configured on your farm yet. Please add your first crop cycle in the Field Blocks & Crop Cycles register to generate AI/ML yield predictions, agronomic sensitivity models, and seasonal forecast comparisons.
          </p>
          {onAddCropClick && (
            <div className="pt-2">
              <button
                type="button"
                onClick={onAddCropClick}
                className="px-4 py-2.5 bg-slate-950 hover:bg-slate-800 text-white rounded-xl text-xs font-bold font-mono inline-flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
              >
                <Sprout className="w-4 h-4 text-emerald-400" />
                <span>+ Add New Crop Cycle</span>
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ML Yield Estimation Math
  const varietyName = activeCrop ? (activeCrop.variety || "SC 719 (Late Maturing)") : "SC 719 (Late Maturing)";
  const baselineYieldMtHa = VARIETY_BASELINE_MT_HA[varietyName] || VARIETY_BASELINE_MT_HA["Default"];

  // Fertilizer Efficiency Factor: f(N)
  const nitrogenFactor = Math.min(1.25, Math.max(0.5, 0.45 + (nitrogenKgHa / 180) * 0.55));

  // Moisture Factor: f(M)
  const moistureFactor = Math.min(1.15, Math.max(0.35, moisturePct / 100));

  // Soil Factor: f(S)
  const soilFactor = Math.min(1.2, Math.max(0.6, soilHealthRating / 100));

  // Pest Loss Factor: f(P)
  const pestFactor = Math.max(0.5, 1 - (pestRiskPct / 100));

  // Predicted Yield Weight per Hectare (MT/Ha)
  const predictedMtHa = baselineYieldMtHa * nitrogenFactor * moistureFactor * soilFactor * pestFactor;
  
  // Total Predicted Yield Weight (MT) and 50kg bags
  const totalPredictedMt = Math.round(predictedMtHa * areaHa * 10) / 10;
  const totalPredictedBags50kg = Math.round((totalPredictedMt * 1000) / 50);

  // Confidence Interval Bounds
  const lowerBoundMt = Math.round(totalPredictedMt * 0.85 * 10) / 10; // P10 pessimistic
  const upperBoundMt = Math.round(totalPredictedMt * 1.15 * 10) / 10; // P90 optimistic

  // Revenue Forecast
  const totalPredictedRevenue = Math.round(totalPredictedMt * 1000 * pricePerKg);
  const lowerRevenue = Math.round(lowerBoundMt * 1000 * pricePerKg);
  const upperRevenue = Math.round(upperBoundMt * 1000 * pricePerKg);

  // Feature Importance Sensitivity Breakdown Data for Donut/Pie Chart
  const featureImportanceData = [
    { name: "Water & Rainfall Moisture", value: Math.round(35 * moistureFactor), color: "#0284c7" },
    { name: "Nitrogen / Fertilizer Rate", value: Math.round(25 * nitrogenFactor), color: "#16a34a" },
    { name: "Seed Variety Genetics", value: Math.round(20 * (baselineYieldMtHa / 8)), color: "#f59e0b" },
    { name: "Soil Health & Organic Matter", value: Math.round(20 * soilFactor), color: "#8b5cf6" },
  ];

  // Dynamic Historical vs Predicted Seasons Chart Data:
  // Starts strictly from user registration year going forward using actual recorded crops only!
  const currentCalYear = new Date().getFullYear();
  const startYr = Math.min(registrationYear, currentCalYear);

  // Group actual harvested crop cycles by season from registration year forward
  const seasonMap: Record<string, { actualKg: number; expectedKg: number; count: number; isForecast?: boolean }> = {};

  crops.forEach(c => {
    let cropYr = currentCalYear;
    if (c.plantingDate) {
      const d = new Date(c.plantingDate);
      if (!isNaN(d.getFullYear())) cropYr = d.getFullYear();
    } else if (c.expectedHarvestDate) {
      const d = new Date(c.expectedHarvestDate);
      if (!isNaN(d.getFullYear())) cropYr = d.getFullYear();
    }

    // Only include seasons starting from user's registration year forward
    if (cropYr >= startYr) {
      const sKey = `${cropYr}/${(cropYr + 1).toString().slice(-2)} Season`;
      if (!seasonMap[sKey]) {
        seasonMap[sKey] = { actualKg: 0, expectedKg: 0, count: 0 };
      }
      seasonMap[sKey].count += 1;
      if (c.status === "Harvested" || c.status === "Sold" || (c.actualYieldKg && c.actualYieldKg > 0)) {
        seasonMap[sKey].actualKg += c.actualYieldKg || 0;
      }
      seasonMap[sKey].expectedKg += c.expectedYieldKg || ((c.areaHectares || 1) * (baselineYieldMtHa * 1000));
    }
  });

  const historicalSeasonsData: Array<{ season: string; ActualMT: number | null; PredictedMT: number }> = [];

  // Add recorded seasons
  const sortedSeasonKeys = Object.keys(seasonMap).sort();
  sortedSeasonKeys.forEach(sKey => {
    const sData = seasonMap[sKey];
    historicalSeasonsData.push({
      season: sKey,
      ActualMT: sData.actualKg > 0 ? Math.round((sData.actualKg / 1000) * 10) / 10 : null,
      PredictedMT: Math.round((sData.expectedKg / 1000) * 10) / 10 || totalPredictedMt
    });
  });

  // Always ensure current ML forecast season is present
  const currentSeasonKey = `${currentCalYear}/${(currentCalYear + 1).toString().slice(-2)} Forecast (ML)`;
  if (!historicalSeasonsData.some(d => d.season.includes(String(currentCalYear)) && d.season.includes("Forecast"))) {
    // If the current season is already in recorded list without forecast label, add or update forecast entry
    const existingCurrentIdx = historicalSeasonsData.findIndex(d => d.season.startsWith(`${currentCalYear}/`));
    if (existingCurrentIdx >= 0) {
      historicalSeasonsData[existingCurrentIdx].PredictedMT = totalPredictedMt;
    } else {
      historicalSeasonsData.push({
        season: currentSeasonKey,
        ActualMT: null,
        PredictedMT: totalPredictedMt
      });
    }
  }

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-indigo-600 animate-pulse" />
            Machine Learning Harvest Yield Forecasting Engine
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Predict harvest weight in Metric Tonnes (MT) and bags using agronomic regression models & What-If scenario simulations.
          </p>
        </div>

        {/* Target Crop Selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-bold text-slate-600 shrink-0">Target Crop Cycle:</label>
          <select
            value={selectedCropId}
            onChange={(e) => handleCropSelect(e.target.value)}
            className="p-2 bg-slate-900 text-white border border-slate-700 rounded-xl font-bold text-xs outline-none"
          >
            {crops.length > 0 ? (
              crops.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.cropType} - Block {c.fieldBlock} ({c.areaHectares || 2.5} Ha)
                </option>
              ))
            ) : (
              <option value="SIMULATED">Simulated Commercial Maize SC 719 (2.5 Ha)</option>
            )}
          </select>
        </div>
      </div>

      {/* Yield Prediction Key Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-indigo-950 text-white p-4 rounded-2xl border border-indigo-800 space-y-1 shadow-md">
          <span className="text-[10px] uppercase font-extrabold tracking-wider text-indigo-300 block flex items-center gap-1">
            <Sprout className="w-3.5 h-3.5 text-indigo-400" />
            Expected ML Yield (MT)
          </span>
          <div className="text-2xl font-black font-mono text-emerald-400">
            {totalPredictedMt} <span className="text-xs font-normal text-slate-300">Metric Tonnes</span>
          </div>
          <span className="text-[10.5px] text-slate-300 font-mono block">
            ≈ {totalPredictedBags50kg.toLocaleString()} bags (50kg) | ({predictedMtHa.toFixed(2)} MT/Ha)
          </span>
        </div>

        <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 space-y-1 shadow-md">
          <span className="text-[10px] uppercase font-extrabold tracking-wider text-amber-400 block flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
            Confidence Interval (P10 - P90)
          </span>
          <div className="text-lg font-black font-mono text-white">
            {lowerBoundMt} MT <span className="text-slate-400 text-xs">to</span> {upperBoundMt} MT
          </div>
          <span className="text-[10.5px] text-slate-400 font-sans font-medium block">
            85% Pessimistic vs 95% Optimistic bounds
          </span>
        </div>

        <div className="bg-emerald-950 text-white p-4 rounded-2xl border border-emerald-800 space-y-1 shadow-md">
          <span className="text-[10px] uppercase font-extrabold tracking-wider text-emerald-300 block flex items-center gap-1">
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            Projected Gross Revenue
          </span>
          <div className="text-2xl font-black font-mono text-emerald-300">
            {currencySymbol} {totalPredictedRevenue.toLocaleString()}
          </div>
          <span className="text-[10.5px] text-emerald-200/70 font-mono block">
            At {currencySymbol}{pricePerKg.toFixed(2)} / kg market price
          </span>
        </div>

        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-1">
          <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-500 block flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            Genetics Potential Efficiency
          </span>
          <div className="text-lg font-black font-mono text-slate-900">
            {Math.round((predictedMtHa / baselineYieldMtHa) * 100)}% <span className="text-xs text-slate-500 font-normal">of max</span>
          </div>
          <span className="text-[10.5px] text-slate-600 font-semibold block">
            Variety Baseline: {baselineYieldMtHa} MT/Ha
          </span>
        </div>
      </div>

      {/* Main Grid: Interactive What-If Simulator + Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Column 1: Interactive What-If Scenario Simulator Controls */}
        <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              What-If Scenario Simulator
            </h4>
            <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
              Real-Time Sensitivity
            </span>
          </div>

          <div className="space-y-4 text-xs font-semibold">
            {/* Area Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-[11px]">
                <span className="text-slate-300 flex items-center gap-1">
                  <Sprout className="w-3.5 h-3.5 text-emerald-400" />
                  Cultivated Area (Hectares):
                </span>
                <span className="font-mono text-amber-300 font-extrabold">{areaHa} Ha ({Math.round(areaHa * 2.471)} Ac)</span>
              </div>
              <input
                type="range"
                min={0.5}
                max={20}
                step={0.5}
                value={areaHa}
                onChange={(e) => setAreaHa(parseFloat(e.target.value))}
                className="w-full accent-amber-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Moisture / Rainfall Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-[11px]">
                <span className="text-slate-300 flex items-center gap-1">
                  <Droplets className="w-3.5 h-3.5 text-sky-400" />
                  Rainfall / Irrigation Moisture Index:
                </span>
                <span className="font-mono text-sky-300 font-extrabold">{moisturePct}%</span>
              </div>
              <input
                type="range"
                min={40}
                max={130}
                step={5}
                value={moisturePct}
                onChange={(e) => setMoisturePct(parseInt(e.target.value))}
                className="w-full accent-sky-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
              <span className="text-[10px] text-slate-400 block font-sans font-normal">
                {moisturePct < 80 ? "⚠️ Drought stress condition (- yield)" : moisturePct > 110 ? "🌧️ High rainfall / optimal irrigation (+ yield)" : "✓ Standard optimal rainfall"}
              </span>
            </div>

            {/* Nitrogen / Fertilizer Rate Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-[11px]">
                <span className="text-slate-300 flex items-center gap-1">
                  <Calculator className="w-3.5 h-3.5 text-emerald-400" />
                  Nitrogen Fertilizer Rate (kg N/Ha):
                </span>
                <span className="font-mono text-emerald-300 font-extrabold">{nitrogenKgHa} kg/Ha</span>
              </div>
              <input
                type="range"
                min={40}
                max={250}
                step={10}
                value={nitrogenKgHa}
                onChange={(e) => setNitrogenKgHa(parseInt(e.target.value))}
                className="w-full accent-emerald-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Pest & Disease Pressure Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-[11px]">
                <span className="text-slate-300 flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                  Pest & Fall Armyworm Risk Index:
                </span>
                <span className="font-mono text-rose-300 font-extrabold">{pestRiskPct}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={40}
                step={2}
                value={pestRiskPct}
                onChange={(e) => setPestRiskPct(parseInt(e.target.value))}
                className="w-full accent-rose-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Soil Health Index Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-[11px]">
                <span className="text-slate-300 flex items-center gap-1">
                  <Sun className="w-3.5 h-3.5 text-purple-400" />
                  Soil Health & Organic Matter Score:
                </span>
                <span className="font-mono text-purple-300 font-extrabold">{soilHealthRating} / 100</span>
              </div>
              <input
                type="range"
                min={50}
                max={100}
                step={5}
                value={soilHealthRating}
                onChange={(e) => setSoilHealthRating(parseInt(e.target.value))}
                className="w-full accent-purple-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Price per kg input */}
            <div className="space-y-1 pt-2 border-t border-slate-800">
              <label className="text-[10.5px] text-slate-400 block">Expected Market Price per Kg ({currencySymbol})</label>
              <input
                type="number"
                step="0.1"
                value={pricePerKg}
                onChange={(e) => setPricePerKg(parseFloat(e.target.value) || 0)}
                className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-emerald-400 font-mono font-bold outline-none"
              />
            </div>
          </div>
        </div>

        {/* Column 2 & 3: Visual Charts + AI Agronomic Guidance */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Chart 1: Historical Seasons vs Predicted ML Yield */}
          <div className="bg-slate-50/80 border border-slate-200 p-5 rounded-2xl space-y-3">
            <div className="flex justify-between items-center">
              <h4 className="text-xs font-black uppercase text-slate-800 tracking-wider flex items-center gap-1.5">
                <BarChart2 className="w-4 h-4 text-indigo-600" />
                <span>Historical Seasons Yield Trend vs ML Forecast (MT)</span>
              </h4>
              <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Seasonal Comparison
              </span>
            </div>

            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={historicalSeasonsData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="season" tick={{ fontSize: 10, fill: "#64748b", fontWeight: 700 }} />
                  <YAxis tick={{ fontSize: 10, fill: "#64748b" }} tickFormatter={(v) => `${v} MT`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#0f172a", borderRadius: "12px", color: "#ffffff", fontSize: "11px" }}
                  />
                  <Legend verticalAlign="top" height={36} iconType="circle" />
                  <Bar dataKey="ActualMT" name="Actual Harvested (MT)" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="PredictedMT" name="ML Model Forecast (MT)" fill="#10b981" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center gap-1.5 text-[10.5px] text-slate-500 font-medium pt-1">
              <Info className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
              <span>
                Seasonal trend tracking initiated from your platform registration season ({registrationSeasonLabel}) forward. As harvest outcomes are logged, actual vs. forecast history records dynamically.
              </span>
            </div>
          </div>

          {/* AI Agronomic Action Items & Feature Sensitivity Breakdown */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Donut Chart: Feature Importance Breakdown */}
            <div className="bg-white border border-slate-200 p-4 rounded-2xl space-y-2">
              <h5 className="text-[11px] font-black uppercase tracking-wider text-slate-800">
                Agronomic Drivers Sensitivity
              </h5>
              <div className="h-44 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={featureImportanceData}
                      cx="50%"
                      cy="50%"
                      innerRadius={35}
                      outerRadius={60}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {featureImportanceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: "#0f172a", borderRadius: "8px", color: "#fff", fontSize: "10px" }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-2 gap-1 text-[10px]">
                {featureImportanceData.map((item) => (
                  <div key={item.name} className="flex items-center gap-1 font-semibold text-slate-700">
                    <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                    <span className="truncate">{item.name.split(' ')[0]}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Yield Gap Action Recommendations */}
            <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 space-y-2.5 text-xs">
              <div className="flex items-center gap-1.5 border-b border-slate-800 pb-2">
                <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
                <h5 className="font-extrabold uppercase tracking-wider text-emerald-400 text-[11px]">
                  Agronomic Yield Gap Recommendations
                </h5>
              </div>

              <div className="space-y-2 font-medium text-[11px] leading-relaxed text-slate-300">
                <div className="flex gap-2 items-start bg-slate-950 p-2 rounded-xl border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <p>
                    {nitrogenKgHa < 160 
                      ? `Boost Urea top-dressing by +${160 - nitrogenKgHa} kg/ha at V6 growth stage to gain +${(0.8 * areaHa).toFixed(1)} MT in total harvest.` 
                      : `Nitrogen application rate is optimized at ${nitrogenKgHa} kg/ha.`}
                  </p>
                </div>

                <div className="flex gap-2 items-start bg-slate-950 p-2 rounded-xl border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                  <p>
                    {moisturePct < 100 
                      ? `Moisture index is ${moisturePct}%. Supplementary drip irrigation will increase yield by +${(1.2 * areaHa).toFixed(1)} MT.` 
                      : `Moisture index is optimal for seed filling and cob development.`}
                  </p>
                </div>

                <div className="flex gap-2 items-start bg-slate-950 p-2 rounded-xl border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <p>
                    Selected seed variety ({varietyName}) offers a baseline yield potential of {baselineYieldMtHa} MT/Ha.
                  </p>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { maskMobile } from "../utils/privacyMasking";
import { X, Printer, Download, CheckCircle, ShieldCheck, ExternalLink } from "lucide-react";
import { LipilaTransaction } from "../data/mockLipilaTransactions";
import { doc, getDoc } from "firebase/firestore";
import { db } from "../firebase";

interface MabalaReceiptModalProps {
  transaction: LipilaTransaction | null;
  onClose: () => void;
  brandingLogoUrl?: string;
}

export default function MabalaReceiptModal({
  transaction,
  onClose,
  brandingLogoUrl: propLogoUrl
}: MabalaReceiptModalProps) {
  const [logoUrl, setLogoUrl] = useState<string | null>(propLogoUrl || null);

  useEffect(() => {
    if (!logoUrl && db) {
      // Fetch platform branding setting from superAdmin/platformConfig/branding
      getDoc(doc(db, "superAdmin", "platformConfig"))
        .then((snap) => {
          if (snap.exists() && snap.data()?.branding?.logoUrl) {
            setLogoUrl(snap.data().branding.logoUrl);
          }
        })
        .catch(() => {});
    }
  }, [logoUrl]);

  if (!transaction) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = () => {
    const receiptHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Mabala Official Receipt - ${transaction.id}</title>
  <style>
    body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; padding: 40px; color: #0f172a; max-width: 750px; margin: 0 auto; background: #fff; }
    .header { border-bottom: 3px solid #1D9E75; padding-bottom: 20px; display: flex; justify-content: space-between; align-items: flex-start; }
    .brand { font-size: 28px; font-weight: 900; color: #1D9E75; letter-spacing: -0.5px; }
    .sub { font-size: 12px; font-weight: bold; color: #475569; }
    .receipt-id { font-family: monospace; font-size: 13px; font-weight: bold; color: #1e293b; }
    .paid-badge { display: inline-block; padding: 4px 12px; background: #ecfdf5; color: #1D9E75; border: 1px solid #a7f3d0; border-radius: 9999px; font-weight: 900; font-size: 12px; margin-top: 6px; }
    .details { margin-top: 24px; background: #f8fafc; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 13px; }
    table { width: 100%; margin-top: 24px; border-collapse: collapse; }
    th, td { padding: 12px; border-bottom: 1px solid #e2e8f0; text-align: left; font-size: 13px; }
    th { background: #f1f5f9; text-transform: uppercase; font-size: 10px; color: #64748b; font-weight: 900; letter-spacing: 0.5px; }
    .total-box { background: rgba(29,158,117,0.1); padding: 16px; border-radius: 8px; margin-top: 16px; display: flex; justify-content: space-between; align-items: center; border: 1px solid #a7f3d0; }
    .footer { margin-top: 32px; font-size: 11px; color: #64748b; border-top: 1px solid #e2e8f0; padding-top: 16px; line-height: 1.5; }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <div class="brand">MABALA</div>
      <div class="sub">Mabala Farm Management Platform</div>
      <div style="font-size: 11px; color: #94a3b8; font-family: monospace;">mabala.cloud</div>
    </div>
    <div style="text-align: right;">
      <div style="font-size: 10px; font-weight: 900; text-transform: uppercase; color: #94a3b8; letter-spacing: 1px;">Official Payment Receipt</div>
      <div class="receipt-id">Receipt No: ${transaction.id}</div>
      <div class="paid-badge">✓ PAID & VERIFIED</div>
    </div>
  </div>
  <div class="details">
    <div>
      <div style="font-size: 10px; font-weight: 900; text-transform: uppercase; color: #94a3b8;">Billed To</div>
      <div style="font-size: 14px; font-weight: bold; color: #0f172a; margin-top: 2px;">${transaction.customerName}</div>
      <div style="color: #64748b;">Tenant ID: ${transaction.tenantId}</div>
      <div style="font-family: monospace; color: #64748b;">${maskMobile(transaction.accountNumber)}</div>
    </div>
    <div style="text-align: right;">
      <div style="font-size: 10px; font-weight: 900; text-transform: uppercase; color: #94a3b8;">Payment Info</div>
      <div style="margin-top: 2px;"><strong>Date:</strong> ${new Date(transaction.createdAt).toLocaleDateString()}</div>
      <div><strong>Method:</strong> ${transaction.paymentMethod}</div>
      <div><strong>Provider:</strong> ${transaction.provider}</div>
    </div>
  </div>
  <table>
    <thead>
      <tr>
        <th>Description</th>
        <th style="text-align: right;">Amount (ZMW)</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <strong>${transaction.narration}</strong><br/>
          <small style="color: #94a3b8; font-family: monospace;">Ref ID: ${transaction.referenceId}</small>
        </td>
        <td style="text-align: right; font-family: monospace; font-weight: bold; font-size: 14px;">
          K${transaction.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
        </td>
      </tr>
      <tr style="color: #64748b; font-size: 12px;">
        <td style="font-style: italic;">Gateway Processing Fee (${transaction.fees?.feePercentage || 1.5}%)</td>
        <td style="text-align: right; font-family: monospace;">
          -K${(transaction.fees?.chargeAmount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
        </td>
      </tr>
    </tbody>
  </table>
  <div class="total-box">
    <span style="font-weight: 900; text-transform: uppercase; color: #1D9E75; font-size: 12px;">Total Paid</span>
    <span style="font-family: monospace; font-size: 18px; font-weight: 900; color: #0f172a;">
      K${transaction.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} ZMW
    </span>
  </div>
  <div class="footer">
    <div><strong>Reference ID:</strong> ${transaction.referenceId} | <strong>Transaction ID:</strong> ${transaction.accountInfo?.transactionId || transaction.id}</div>
    <div>Verified system receipt generated by Mabala Cloud Platform. Support: support@mabala.cloud | +260-978 070734</div>
  </div>
</body>
</html>`;

    const blob = new Blob([receiptHtml], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Mabala_Receipt_${transaction.id}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-[120] bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden border border-slate-200 text-slate-900 my-8">
        
        {/* Modal Action Top Bar (Hidden on Print) */}
        <div className="bg-slate-900 text-white px-6 py-3.5 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#1D9E75]" />
            <span className="text-xs font-black uppercase tracking-wider">Mabala Official Payment Receipt</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" /> Print
            </button>
            <button
              onClick={handleDownloadPdf}
              className="px-3 py-1.5 bg-[#1D9E75] hover:bg-[#157959] text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Download className="w-3.5 h-3.5" /> Download PDF
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all cursor-pointer ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PRINTABLE RECEIPT CONTAINER */}
        <div className="p-8 space-y-6 font-sans bg-white relative print:p-0">
          
          {/* Top Brand Banner Bar (#1D9E75 Mabala Green) */}
          <div className="h-2 bg-[#1D9E75] rounded-full -mx-2 -mt-2 mb-6" />

          {/* Header Row */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-6">
            <div>
              {logoUrl ? (
                <img src={logoUrl} alt="Mabala Platform" className="h-10 object-contain mb-2" />
              ) : (
                <div className="text-2xl font-black text-[#1D9E75] tracking-tight font-serif uppercase">
                  Mabala
                </div>
              )}
              <div className="text-[11px] font-bold text-slate-600">Mabala Farm Management Platform</div>
              <div className="text-[10px] text-slate-400 font-mono">mabala.cloud</div>
            </div>

            <div className="text-right">
              <span className="text-xs font-black uppercase tracking-widest text-slate-400 block">Payment Receipt</span>
              <div className="font-mono text-xs font-bold text-slate-700 mt-1">
                Receipt No: <span className="text-slate-900">{transaction.id}</span>
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-[#1D9E75] border border-emerald-200 rounded-full font-black text-xs mt-2">
                <CheckCircle className="w-3.5 h-3.5" /> PAID
              </div>
            </div>
          </div>

          {/* Billed To & Payment Details Grid */}
          <div className="grid grid-cols-2 gap-6 bg-slate-50 p-4 rounded-xl border border-slate-200/80 text-xs">
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-1">Billed To</span>
              <strong className="text-slate-900 font-bold block text-sm">{transaction.customerName}</strong>
              <span className="text-slate-500 font-medium block mt-0.5">Tenant ID: {transaction.tenantId}</span>
              <span className="text-slate-500 font-mono block">{maskMobile(transaction.accountNumber)}</span>
            </div>

            <div className="border-l border-slate-200 pl-6">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-1">Payment Details</span>
              <div className="space-y-1 text-slate-700 font-medium">
                <div><strong className="text-slate-900">Date Paid:</strong> {new Date(transaction.createdAt).toLocaleDateString()}</div>
                <div><strong className="text-slate-900">Method:</strong> {transaction.paymentMethod}</div>
                <div><strong className="text-slate-900">Provider:</strong> {transaction.provider}</div>
              </div>
            </div>
          </div>

          {/* Description & Line Item Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 font-black text-[10px] text-slate-500 uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="p-3">Description</th>
                  <th className="p-3 text-right">Amount (ZMW)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                <tr>
                  <td className="p-3">
                    <div className="font-bold text-slate-900">{transaction.narration || "Payment Settlement"}</div>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">Ref ID: {transaction.referenceId || transaction.id}</div>
                  </td>
                  <td className="p-3 text-right font-mono font-bold text-slate-900">
                    K{(transaction.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                </tr>
                <tr className="bg-slate-50/50 text-slate-500 text-[11px]">
                  <td className="p-3 italic">
                    Gateway Processing Fee ({transaction.fees?.feePercentage ?? 1.5}%)
                  </td>
                  <td className="p-3 text-right font-mono">
                    -K{(transaction.fees?.chargeAmount ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              </tbody>
            </table>
            
            <div className="bg-[#1D9E75]/10 p-3 px-4 flex justify-between items-center border-t border-slate-200">
              <span className="font-black uppercase tracking-wider text-xs text-[#1D9E75]">Total Paid</span>
              <strong className="font-mono text-base font-black text-slate-900">
                K{(transaction.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })} ZMW
              </strong>
            </div>
          </div>

          {/* Reference Hashes */}
          <div className="bg-slate-100 p-3 rounded-lg text-[10.5px] font-mono text-slate-600 space-y-0.5">
            <div><strong className="text-slate-800">Reference ID:</strong> {transaction.referenceId || transaction.id}</div>
            <div><strong className="text-slate-800">Transaction ID:</strong> {transaction.accountInfo?.transactionId || transaction.id}</div>
            <div><strong className="text-slate-800">External Provider Ref:</strong> {transaction.externalId || transaction.referenceId || transaction.id}</div>
          </div>

          {/* Verification & Support Footer */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-[11px] text-slate-600 font-medium leading-tight max-w-xs text-center sm:text-left">
              If you have any questions, contact us at{" "}
              <a href="mailto:support@mabala.cloud" className="text-[#1D9E75] font-bold underline">
                support@mabala.cloud
              </a>{" "}
              or call at{" "}
              <strong className="text-slate-900">+260-978 070734</strong>.
              <div className="text-[9.5px] text-slate-400 mt-1">
                Merchant of Record: Deep Valley Farms Limited / Mabala Cloud platform.
              </div>
            </div>

            {/* Simulated QR Code for mabala.cloud receipt verification */}
            <div className="flex flex-col items-center shrink-0">
              <div className="w-20 h-20 bg-slate-900 p-1.5 rounded-lg border border-slate-300 flex items-center justify-center text-white">
                <svg viewBox="0 0 100 100" className="w-full h-full fill-current text-white">
                  <path d="M0,0 h30 v30 h-30 z M40,0 h20 v10 h-20 z M70,0 h30 v30 h-30 z M0,40 h10 v20 h-10 z M30,40 h30 v10 h-30 z M70,40 h10 v10 h-10 z M90,40 h10 v30 h-10 z M0,70 h30 v30 h-30 z M40,70 h10 v30 h-10 z M60,70 h30 v10 h-30 z M80,80 h20 v20 h-20 z" />
                </svg>
              </div>
              <span className="text-[8.5px] font-bold text-slate-400 mt-1 text-center font-mono">
                Scan to verify on mabala.cloud
              </span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}

import React, { useEffect, useRef, useState } from "react";
import * as d3 from "d3";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell } from "recharts";

export interface CategoryLossItem {
  category: string;
  quantity: number;
  fill: string;
}

export interface CropFinancialLossItem {
  crop: string;
  lossKg: number;
  unitCost: number;
  financialImpact: number;
}

interface D3LossCategoryChartProps {
  data: CategoryLossItem[];
  width?: number;
  height?: number;
}

export const D3LossCategoryChart: React.FC<D3LossCategoryChartProps> = ({
  data,
  width = 520,
  height = 180
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [tooltip, setTooltip] = useState<{
    visible: boolean;
    x: number;
    y: number;
    category: string;
    quantity: number;
    percentage: number;
  }>({
    visible: false,
    x: 0,
    y: 0,
    category: "",
    quantity: 0,
    percentage: 0
  });

  const totalLoss = d3.sum(data, (d: CategoryLossItem) => d.quantity) || 1;

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const margin = { top: 20, right: 20, bottom: 45, left: 45 };
    const chartWidth = width - margin.left - margin.right;
    const chartHeight = height - margin.top - margin.bottom;

    const g = svg
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // X scale
    const x = d3
      .scaleBand()
      .domain(data.map((d: CategoryLossItem) => d.category))
      .range([0, chartWidth])
      .padding(0.3);

    // Y scale
    const maxVal = d3.max(data, (d: CategoryLossItem) => d.quantity);
    const yMax = (typeof maxVal === "number" ? maxVal : 100) * 1.15;
    const y = d3.scaleLinear().domain([0, yMax]).range([chartHeight, 0]);

    // Grid lines
    g.append("g")
      .attr("class", "grid")
      .call(
        d3
          .axisLeft(y)
          .ticks(4)
          .tickSize(-chartWidth)
          .tickFormat(() => "")
      )
      .selectAll(".tick line")
      .attr("stroke", "#f1f5f9")
      .attr("stroke-dasharray", "3 3");

    // X Axis
    const xAxis = g
      .append("g")
      .attr("transform", `translate(0,${chartHeight})`)
      .call(d3.axisBottom(x));

    xAxis.selectAll("path, line").attr("stroke", "#cbd5e1");
    xAxis
      .selectAll("text")
      .attr("transform", "rotate(-12)")
      .style("text-anchor", "end")
      .style("font-size", "9px")
      .style("font-weight", "700")
      .style("fill", "#475569");

    // Y Axis
    const yAxis = g.append("g").call(d3.axisLeft(y).ticks(4));
    yAxis.selectAll("path, line").attr("stroke", "#cbd5e1");
    yAxis.selectAll("text").style("font-size", "9px").style("fill", "#64748b");

    // D3 Interactive Bars
    g.selectAll(".bar")
      .data(data)
      .enter()
      .append("rect")
      .attr("class", "bar")
      .attr("x", (d: any) => x(d.category) || 0)
      .attr("width", x.bandwidth())
      .attr("y", chartHeight)
      .attr("height", 0)
      .attr("rx", 6)
      .attr("ry", 6)
      .attr("fill", (d: any) => d.fill)
      .attr("cursor", "pointer")
      .attr("opacity", 0.9)
      .on("mouseover", function (event: any, d: any) {
        d3.select(this)
          .transition()
          .duration(150)
          .attr("opacity", 1)
          .attr("stroke", "#0f172a")
          .attr("stroke-width", 2);

        const rect = containerRef.current?.getBoundingClientRect();
        const mouseX = event.clientX - (rect?.left || 0);
        const mouseY = event.clientY - (rect?.top || 0);

        const pct = (d.quantity / totalLoss) * 100;
        setTooltip({
          visible: true,
          x: mouseX,
          y: mouseY - 65,
          category: d.category,
          quantity: d.quantity,
          percentage: Number(pct.toFixed(1))
        });
      })
      .on("mousemove", function (event: any) {
        const rect = containerRef.current?.getBoundingClientRect();
        const mouseX = event.clientX - (rect?.left || 0);
        const mouseY = event.clientY - (rect?.top || 0);
        setTooltip(prev => ({
          ...prev,
          x: mouseX,
          y: mouseY - 65
        }));
      })
      .on("mouseout", function () {
        d3.select(this)
          .transition()
          .duration(150)
          .attr("opacity", 0.9)
          .attr("stroke", "none");

        setTooltip(prev => ({ ...prev, visible: false }));
      })
      .transition()
      .duration(500)
      .attr("y", (d: any) => y(d.quantity))
      .attr("height", (d: any) => chartHeight - y(d.quantity));

    // Quantity labels over bars
    g.selectAll(".label")
      .data(data)
      .enter()
      .append("text")
      .attr("x", (d: any) => (x(d.category) || 0) + x.bandwidth() / 2)
      .attr("y", (d: any) => y(d.quantity) - 5)
      .attr("text-anchor", "middle")
      .style("font-size", "9px")
      .style("font-weight", "800")
      .style("fill", "#334155")
      .text((d: any) => `${d.quantity} KG`);

  }, [data, width, height, totalLoss]);

  return (
    <div ref={containerRef} className="relative w-full bg-white rounded-xl p-2 border border-slate-200">
      <div className="flex justify-between items-center mb-1 px-1">
        <span className="text-[10px] font-black uppercase text-slate-800 tracking-wider flex items-center gap-1.5">
          <span>📊</span> Loss Category Distribution (D3 Interactive)
        </span>
        <span className="text-[9px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200 font-mono">
          Total: {totalLoss.toLocaleString()} KG
        </span>
      </div>

      <svg
        ref={svgRef}
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto overflow-visible"
      />

      {/* D3 Hover Tooltip displaying absolute KG values alongside percentage of total loss */}
      {tooltip.visible && (
        <div
          className="absolute z-30 pointer-events-none bg-slate-950 text-white rounded-xl p-2.5 shadow-2xl border border-slate-700 text-xs animate-scale-up"
          style={{
            left: `${Math.min(Math.max(tooltip.x - 70, 10), width - 160)}px`,
            top: `${Math.max(tooltip.y, 5)}px`
          }}
        >
          <div className="font-black text-amber-400 text-[11px] mb-1 flex items-center gap-1">
            <span>🏷️</span> {tooltip.category}
          </div>
          <div className="flex items-center gap-2 font-mono text-[10px]">
            <span className="text-white font-bold">{tooltip.quantity.toLocaleString()} KG</span>
            <span className="text-emerald-400 font-extrabold bg-emerald-950/90 px-1.5 py-0.5 rounded border border-emerald-700">
              {tooltip.percentage}% of total loss
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

interface FinancialImpactChartProps {
  data: CropFinancialLossItem[];
  currencySymbol?: string;
}

export const FinancialImpactChart: React.FC<FinancialImpactChartProps> = ({
  data,
  currencySymbol = "ZMW"
}) => {
  const totalFinancialImpact = data.reduce((sum, d) => sum + d.financialImpact, 0);

  return (
    <div className="bg-slate-900 text-white rounded-xl p-3 border border-slate-800 space-y-2">
      <div className="flex justify-between items-center border-b border-slate-800 pb-2">
        <div>
          <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider flex items-center gap-1">
            <span>💰</span> Financial Impact of Losses
          </span>
          <p className="text-[9px] text-slate-400 font-medium">
            Calculated as: <span className="font-mono text-slate-300">Logged KG Loss × Stored Inventory Unit Cost</span>
          </p>
        </div>
        <div className="text-right">
          <span className="text-[9px] uppercase font-bold text-slate-400 block">Total Value Impact</span>
          <span className="text-sm font-black text-rose-400 font-mono">
            -{currencySymbol} {totalFinancialImpact.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
      </div>

      <div className="h-36 w-full pt-1">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 10, right: 10, left: -15, bottom: 15 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
            <XAxis
              dataKey="crop"
              tick={{ fontSize: 8, fill: '#94a3b8' }}
              interval={0}
              angle={-8}
              textAnchor="end"
            />
            <YAxis tick={{ fontSize: 8, fill: '#94a3b8' }} />
            <Tooltip
              contentStyle={{ backgroundColor: '#020617', borderRadius: '8px', color: '#fff', fontSize: '11px', border: '1px solid #334155' }}
              formatter={(val: any, name: any, item: any) => [
                `${currencySymbol} ${Number(val).toLocaleString(undefined, { minimumFractionDigits: 2 })} (${item.payload.lossKg} KG @ ${currencySymbol} ${item.payload.unitCost.toFixed(2)}/KG)`,
                'Financial Impact'
              ]}
            />
            <Bar dataKey="financialImpact" radius={[6, 6, 0, 0]}>
              {data.map((entry, index) => (
                <Cell key={`cell-fin-${index}`} fill={index === 0 ? "#f43f5e" : index === 1 ? "#fb923c" : index === 2 ? "#eab308" : "#a855f7"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Breakdown Badges */}
      <div className="grid grid-cols-2 gap-1.5 pt-1 border-t border-slate-800">
        {data.map((item, idx) => (
          <div key={idx} className="bg-slate-800/80 p-1.5 rounded-lg border border-slate-700/60 flex items-center justify-between text-[10px]">
            <span className="truncate font-bold text-slate-200 max-w-[110px]">{item.crop}</span>
            <div className="text-right font-mono">
              <span className="text-rose-300 font-extrabold block">
                {currencySymbol} {item.financialImpact.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
              <span className="text-[8px] text-slate-400 block">
                {item.lossKg} KG @ {item.unitCost.toFixed(2)}/KG
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

import React, { useEffect, useMemo, useState } from "react";
import Sidebar from "../components/Sidebar";
import WelcomeScreen from "../components/WelcomeScreen";
import AiChatbot from "../components/AiChatbot";
import ReadOnlyWarningBanner from "../components/ReadOnlyWarningBanner";
import { DashboardModulesGrid } from "../components/DashboardModulesGrid";
import { useSuperAdmin } from "../hooks/useSuperAdmin";
import { readPersistedJson } from "./persistence";
import { PredefinedRole } from "../types";
import { safeFormatError } from "../utils/errorUtils";

export type AppShellProps = {
  isAuthenticated: boolean;
  isAuthLoading: boolean;
  activeTab: string;
  setActiveTab: (tab: string, subTab?: string, extraParams?: Record<string, string>) => void;
  userProfile: Record<string, any>;
  currentRole: PredefinedRole | string;
  workspaceMode: string;
  farms: any[];
  accounts: any[];
  inventory: any[];
  credits: number | null;
  farmStatus: string;
  isOnline: boolean;
  isOfflineSession: boolean;
  notifications: any[];
  setNotifications: React.Dispatch<React.SetStateAction<any[]>>;
  addNotification: (message: string, type?: "success" | "warning" | "info" | "error") => void;
  sessionError: string | null;
  showSearchResults: boolean;
  globalSearchQuery: string;
  setGlobalSearchQuery: (value: string) => void;
  setShowSearchResults: (value: boolean) => void;
  showQuickLogLossModal: boolean;
  setShowQuickLogLossModal: (value: boolean) => void;
  quickLossCrop: string;
  setQuickLossCrop: (value: string) => void;
  quickLossQty: number;
  setQuickLossQty: (value: number) => void;
  quickLossReason: string;
  setQuickLossReason: (value: string) => void;
  isSubmittingQuickLoss: boolean;
  setIsSubmittingQuickLoss: (value: boolean) => void;
  showQuickLossSuccess: boolean;
  setShowQuickLossSuccess: (value: boolean) => void;
  quickLossCategories: Array<{ category: string; quantity: number; fill: string }>;
  setQuickLossCategories: React.Dispatch<React.SetStateAction<Array<{ category: string; quantity: number; fill: string }>>>;
  financialLossData: Array<{ crop: string; lossKg: number; unitCost: number; financialImpact: number }>;
  hideReadonlyBanner: boolean;
  setHideReadonlyBanner: (value: boolean) => void;
  readOnlyBlockedAction: string | null;
  setReadOnlyBlockedAction: (value: string | null) => void;
  isSidebarOpen: boolean;
  setIsSidebarOpen: (value: boolean) => void;
  activeFarmIndex: number;
  setActiveFarmIndex: (value: number) => void;
  farmsList: any[];
  isSuperAdmin: boolean;
  modules: Record<string, any>;
};

export default function AppShell(props: AppShellProps) {
  const { isAuthenticated, isAuthLoading, activeTab, setActiveTab, userProfile, currentRole, workspaceMode, farms, accounts, inventory, credits, farmStatus, isOnline, isOfflineSession, notifications, addNotification, sessionError, globalSearchQuery, setGlobalSearchQuery, setShowSearchResults, showQuickLogLossModal, setShowQuickLogLossModal, quickLossCrop, setQuickLossCrop, quickLossQty, setQuickLossQty, quickLossReason, setQuickLossReason, isSubmittingQuickLoss, setIsSubmittingQuickLoss, showQuickLossSuccess, setShowQuickLossSuccess, quickLossCategories, setQuickLossCategories, financialLossData, hideReadonlyBanner, setHideReadonlyBanner, readOnlyBlockedAction, setReadOnlyBlockedAction, isSidebarOpen, setIsSidebarOpen, activeFarmIndex, setActiveFarmIndex, farmsList, isSuperAdmin, modules } = props;

  const [lastPersistedSearch, setLastPersistedSearch] = useState(() => readPersistedJson("mabala_search_query", ""));

  useEffect(() => {
    localStorage.setItem("mabala_search_query", JSON.stringify(globalSearchQuery));
    setLastPersistedSearch(globalSearchQuery);
  }, [globalSearchQuery]);

  const summary = useMemo(() => ({
    activeFarm: farms[activeFarmIndex] || farms[0],
    inventoryCount: inventory.length,
    accountCount: accounts.length,
    creditsLabel: credits !== null ? `${credits}` : "0",
  }), [farms, activeFarmIndex, inventory, accounts, credits]);

  if (isAuthLoading) {
    return <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">Loading workspace…</div>;
  }

  if (!isAuthenticated) {
    return (
      <WelcomeScreen 
        onStartDemo={() => setActiveTab("dashboard")} 
        onLogin={async () => {}}
        onRegister={async () => {}} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      {!hideReadonlyBanner && (
        <ReadOnlyWarningBanner
          isVisible={!hideReadonlyBanner}
          message={readOnlyBlockedAction || "Your session is in read-only mode while the platform app synchronizes data."}
          onClose={() => setHideReadonlyBanner(true)}
        />
      )}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isReadonly={false}
        onTopUp={() => setActiveTab("billing")}
        credits={credits || 0}
        currentRole={currentRole as any}
        rolePermissions={{}}
        userEmail={userProfile?.email || ""}
        subscriptionTier={userProfile?.subscriptionTier || "Free"}
        workspaceMode={workspaceMode as any}
        activeFarmName={summary.activeFarm?.name || "Main Farm"}
      />
      <div className="lg:pl-72">
        <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/80 backdrop-blur-sm">
          <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
            <div>
              <div className="text-xs font-semibold uppercase tracking-[0.2em] text-sky-600">Mabala Platform</div>
              <div className="text-lg font-bold text-slate-900">{summary.activeFarm?.name || "Workspace"}</div>
            </div>
            <div className="flex items-center gap-3 text-sm text-slate-600">
              <span className="rounded-full border border-emerald-200 bg-emerald-50 px-2 py-1 text-emerald-700">{isOnline ? "Online" : "Offline"}</span>
              <span className="rounded-full border border-slate-200 bg-slate-50 px-2 py-1">{farmStatus}</span>
              <span className="rounded-full border border-slate-200 bg-slate-50 px-2 py-1">{summary.creditsLabel} credits</span>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
          <DashboardModulesGrid
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            userProfile={userProfile}
            currentRole={currentRole}
            workspaceMode={workspaceMode}
            farms={farms}
            inventory={inventory}
            accounts={accounts}
            credits={credits}
            isOfflineSession={isOfflineSession}
            modules={modules}
          />

          {sessionError && (
            <div className="mt-4 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">{safeFormatError(sessionError)}</div>
          )}

          {showQuickLogLossModal && (
            <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
              <div className="mb-3 text-lg font-bold text-slate-800">Quick Loss Log</div>
              <div className="grid gap-3 md:grid-cols-3">
                <input value={quickLossCrop} onChange={(e) => setQuickLossCrop(e.target.value)} className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2" />
                <input type="number" value={quickLossQty} onChange={(e) => setQuickLossQty(Number(e.target.value))} className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2" />
                <input value={quickLossReason} onChange={(e) => setQuickLossReason(e.target.value)} className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2" />
              </div>
              <div className="mt-4 flex gap-3">
                <button onClick={() => setShowQuickLogLossModal(false)} className="rounded-xl border border-slate-200 px-3 py-2 text-slate-700">Cancel</button>
                <button onClick={() => { setIsSubmittingQuickLoss(true); setTimeout(() => { setIsSubmittingQuickLoss(false); setShowQuickLossSuccess(true); setShowQuickLogLossModal(false); }, 400); }} className="rounded-xl bg-sky-600 px-3 py-2 text-white">Save loss</button>
              </div>
            </div>
          )}

          {showQuickLossSuccess && (
            <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-700">Quick loss logged successfully.</div>
          )}

          {globalSearchQuery && (
            <div className="mt-4 rounded-xl border border-sky-200 bg-sky-50 p-3 text-sm text-sky-700">Search: {globalSearchQuery}</div>
          )}

          {lastPersistedSearch && (
            <div className="mt-2 text-xs text-slate-500">Last saved search: {lastPersistedSearch}</div>
          )}
        </main>
      </div>

      <AiChatbot
        onOpen={() => addNotification("AI assistant ready", "info")}
        onClose={() => addNotification("AI assistant closed", "info")}
      />
      {notifications.length > 0 && (
        <div className="fixed right-4 top-20 z-50 space-y-2">
          {notifications.map((note) => (
            <div key={note.id || Math.random()} className="rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-sm text-sm text-slate-700">{note.message}</div>
          ))}
        </div>
      )}
    </div>
  );
}

export const PERSISTENCE_BACKUP_KEY = "mabala_persistence_backup_v1";

export function readPersistedJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw == null || raw === "") return fallback;

    const parsed = JSON.parse(raw);
    if (parsed === null || parsed === undefined) return fallback;
    return parsed as T;
  } catch (error) {
    console.warn(`[Persistence] Corrupted value detected for ${key}. Restoring backup if available.`, error);
    try {
      const backupRaw = localStorage.getItem(PERSISTENCE_BACKUP_KEY);
      if (backupRaw) {
        const backup = JSON.parse(backupRaw) as Record<string, unknown>;
        const candidate = backup[key];
        if (candidate !== undefined) {
          localStorage.setItem(key, JSON.stringify(candidate));
          return candidate as T;
        }
      }
    } catch (backupErr) {
      console.warn("[Persistence] Backup restore failed.", backupErr);
    }
    return fallback;
  }
}

export function writePersistedJson<T>(key: string, value: T): T {
  const serialized = JSON.stringify(value);
  try {
    localStorage.setItem(key, serialized);
    try {
      const backupRaw = localStorage.getItem(PERSISTENCE_BACKUP_KEY);
      const backupMap = backupRaw ? (JSON.parse(backupRaw) as Record<string, unknown>) : {};
      backupMap[key] = value;
      localStorage.setItem(PERSISTENCE_BACKUP_KEY, JSON.stringify(backupMap));
    } catch (backupErr) {
      console.warn("[Persistence] Backup snapshot could not be saved.", backupErr);
    }
    return value;
  } catch (error) {
    console.warn(`[Persistence] Write failed for ${key}.`, error);
    return value;
  }
}

export function repairPersistedState(): void {
  try {
    const keys = Object.keys(localStorage);
    for (const key of keys) {
      if (!key.startsWith("mabala_")) continue;
      try {
        const raw = localStorage.getItem(key);
        if (!raw || raw === "") continue;
        JSON.parse(raw);
      } catch (error) {
        console.warn(`[Persistence] Repairing corrupted key: ${key}`);
        const backupRaw = localStorage.getItem(PERSISTENCE_BACKUP_KEY);
        if (backupRaw) {
          try {
            const backup = JSON.parse(backupRaw) as Record<string, unknown>;
            if (backup[key] !== undefined) {
              localStorage.setItem(key, JSON.stringify(backup[key]));
            } else {
              localStorage.removeItem(key);
            }
          } catch (backupError) {
            console.warn(`[Persistence] Unable to repair ${key}.`, backupError);
            localStorage.removeItem(key);
          }
        }
      }
    }
  } catch (error) {
    console.warn("[Persistence] Could not scan local storage.", error);
  }
}

import { initializeApp, getApp, getApps, deleteApp } from "firebase/app";
import { 
  getAuth, 
  initializeAuth,
  browserLocalPersistence,
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  sendPasswordResetEmail,
  sendEmailVerification
} from "firebase/auth";
import { 
  getFirestore, 
  doc,
  getDocFromServer,
  setLogLevel
} from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getFunctions } from "firebase/functions";
import firebaseConfig from "./firebase-applet-config.json";

// Extract configuration from JSON or from environment variables (client-side VITE_ prefix fallback)
const env: Record<string, any> = (typeof globalThis !== "undefined" && (globalThis as any).process?.env)
  ? (globalThis as any).process.env
  : (typeof process !== "undefined" && process?.env ? process.env : {});
const config = {
  apiKey: firebaseConfig.apiKey || (env.VITE_FIREBASE_API_KEY as string) || "",
  authDomain: firebaseConfig.authDomain || (env.VITE_FIREBASE_AUTH_DOMAIN as string) || "",
  projectId: firebaseConfig.projectId || (env.VITE_FIREBASE_PROJECT_ID as string) || "",
  storageBucket: firebaseConfig.storageBucket || (env.VITE_FIREBASE_STORAGE_BUCKET as string) || "",
  messagingSenderId: firebaseConfig.messagingSenderId || (env.VITE_FIREBASE_MESSAGING_SENDER_ID as string) || "",
  appId: firebaseConfig.appId || (env.VITE_FIREBASE_APP_ID as string) || "",
  measurementId: firebaseConfig.measurementId || (env.VITE_FIREBASE_MEASUREMENT_ID as string) || "",
  firestoreDatabaseId: firebaseConfig.firestoreDatabaseId || (env.VITE_FIREBASE_FIRESTORE_DATABASE_ID as string) || "ai-studio-020042e7-7cf8-4e86-bdea-ea1ae9737651"
};

export const isConfigured = !!(config.apiKey && config.projectId && !config.apiKey.startsWith("placeholder") && config.apiKey !== "");

// Step 1: Initialize Firebase App Core
let app: any;
try {
  if (getApps().length === 0) {
    if (isConfigured) {
      app = initializeApp(config);
    } else {
      // Safe initialization block to prevent startup crash errors
      console.warn(
        "Warning: Firebase credentials are unconfigured or incomplete. Please verify settings in firebase-applet-config.json."
      );
      app = initializeApp({
        apiKey: "placeholder-api-key-to-prevent-startup-crash-errors",
        authDomain: "placeholder-auth-domain.firebaseapp.com",
        projectId: "placeholder-project-id",
        storageBucket: "placeholder-storage-bucket.appspot.com",
        messagingSenderId: "00000000000",
        appId: "1:00000000000:web:00000000000"
      });
    }
  } else {
    app = getApp();
  }
} catch (e) {
  console.error("[Firebase] initializeApp failed:", e);
}

// Set firestore log level to avoid verbose connection retry warnings in offline/sandbox mode
try {
  setLogLevel("silent");
} catch (err) {
  // Ignore
}

// Step 2: Critical - Configure and initialize Firestore with database ID
export const db = getFirestore(app, config.firestoreDatabaseId);

// Validate connection to Firestore
async function testConnection() {
  try {
    await getDocFromServer(doc(db, "test", "connection"));
  } catch (error) {
    if (error instanceof Error && error.message.includes("the client is offline")) {
      console.error("Please check your Firebase configuration.");
    }
  }
}
testConnection();

// Step 3: Initialize Firebase Auth client with persistent storage
export let auth: any;
try {
  auth = initializeAuth(app, {
    persistence: browserLocalPersistence
  });
} catch (authError: any) {
  if (authError && authError.code === "auth/already-initialized") {
    try {
      auth = getAuth(app);
    } catch (getAuthErr) {
      console.error("[Firebase] getAuth failed after already-initialized error:", getAuthErr);
    }
  } else {
    console.warn("[Firebase] initializeAuth with inMemoryPersistence failed, falling back to default or mock:", authError);
    try {
      auth = getAuth(app);
    } catch (fallbackError) {
      console.error("[Firebase] getAuth fallback failed, setting up mock auth:", fallbackError);
      auth = {
        currentUser: null,
        onAuthStateChanged: (callback: any) => {
          setTimeout(() => callback(null), 0);
          return () => {};
        },
        signOut: async () => {},
        signInWithEmailAndPassword: async () => { throw new Error("Firebase Auth is unavailable in this sandbox."); },
        createUserWithEmailAndPassword: async () => { throw new Error("Firebase Auth is unavailable in this sandbox."); },
      } as any;
    }
  }
}

// Critical: export initialized Firebase Storage instance
export let storage: any;
try {
  storage = getStorage(app);
} catch (e) {
  console.error("[Firebase] getStorage failed, falling back to dummy storage object:", e);
  storage = {
    _dummy: true,
  } as any;
}

// Critical: export initialized Firebase Functions instance
export let functions: any;
try {
  functions = getFunctions(app);
} catch (e) {
  console.warn("[Firebase] getFunctions fallback:", e);
  functions = { _dummy: true } as any;
}

// Facilitate Google Sign-In helper if requested
export let googleProvider: any;
try {
  googleProvider = new GoogleAuthProvider();
  const googleClientId = (firebaseConfig as any).googleClientId || (env.VITE_FIREBASE_GOOGLE_CLIENT_ID as string) || "";
  if (googleClientId && typeof googleProvider.setCustomParameters === "function") {
    googleProvider.setCustomParameters({
      client_id: googleClientId
    });
  }
} catch (e) {
  console.warn("[Firebase] GoogleAuthProvider creation fallback:", e);
  googleProvider = { setCustomParameters: () => {} };
}

export enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationTypeOrContext?: OperationType | string,
  path?: string | null
) {
  const isOpType = Object.values(OperationType).includes(operationTypeOrContext as OperationType);
  const opType = isOpType ? (operationTypeOrContext as OperationType) : OperationType.GET;
  const targetPath = path ?? (!isOpType && typeof operationTypeOrContext === "string" ? operationTypeOrContext : null);

  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid,
      email: auth?.currentUser?.email,
      emailVerified: auth?.currentUser?.emailVerified,
      isAnonymous: auth?.currentUser?.isAnonymous,
      tenantId: auth?.currentUser?.tenantId,
      providerInfo: auth?.currentUser?.providerData?.map((provider: any) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType: opType,
    path: targetPath
  };
  console.error("Firestore Error: ", JSON.stringify(errInfo));
  if (error instanceof Error && error.message.includes("Missing or insufficient permissions")) {
    throw new Error(JSON.stringify(errInfo));
  }
}

/**
 * Creates a user in Firebase Auth using a isolated secondary app instance
 * so that the current session (e.g. Super Admin) is NOT signed out or changed.
 */
export async function createSecondaryUserWithoutSwitchingAuth(cleanEmail: string, passToUse: string): Promise<string> {
  if (!isConfigured) {
    return `user-kyc-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  }
  const secondaryAppName = `SecondaryApp_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
  let secondaryApp: any;
  try {
    secondaryApp = initializeApp(config, secondaryAppName);
    const secondaryAuth = getAuth(secondaryApp);
    const cred = await createUserWithEmailAndPassword(secondaryAuth, cleanEmail, passToUse);
    const uid = cred.user.uid;
    try {
      await signOut(secondaryAuth);
    } catch (_) {}
    return uid;
  } catch (err: any) {
    console.warn("[Secondary Auth Creation Error]", err);
    throw err;
  } finally {
    if (secondaryApp) {
      try {
        await deleteApp(secondaryApp);
      } catch (_) {}
    }
  }
}

// Common auth utility integrations
export {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  signInWithPopup,
  onAuthStateChanged,
  sendPasswordResetEmail,
  sendEmailVerification
};

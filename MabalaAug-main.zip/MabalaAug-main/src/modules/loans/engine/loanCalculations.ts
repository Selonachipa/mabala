/**
 * Mabala.cloud - Loan Calculation & Amortization Engine
 * Deterministic mathematical models for Agricultural & Enterprise lending.
 */

import {
  FinancingModel,
  InterestCalculationMethod,
  RepaymentFrequency,
  TenorUnit,
  RepaymentScheduleItem,
  AgingBucket,
  PortfolioMetrics,
  Loan
} from "../types";

export interface ScheduleGenerationParams {
  principal: number;
  annualInterestRatePct: number;
  interestCalculationMethod: InterestCalculationMethod;
  repaymentFrequency: RepaymentFrequency;
  tenorValue: number;
  tenorUnit: TenorUnit;
  disbursementDate: string; // ISO date string e.g. "2026-06-15"
  gracePeriodValue?: number;
  gracePeriodUnit?: "days" | "months";
  originationFeeTotal?: number;
  financingModel?: FinancingModel;
  harvestDate?: string;
}

/**
 * Returns number of repayment installments based on tenor and frequency
 */
export function calculateInstallmentCount(
  tenorValue: number,
  tenorUnit: TenorUnit,
  frequency: RepaymentFrequency
): number {
  if (frequency === "harvest_bullet") {
    return 1;
  }

  // Normalize tenor to approximate months
  let months = tenorValue;
  if (tenorUnit === "days") months = Math.max(1, Math.round(tenorValue / 30));
  if (tenorUnit === "weeks") months = Math.max(1, Math.round(tenorValue / 4.33));
  if (tenorUnit === "seasons") months = tenorValue * 6; // standard 6-month agricultural season

  switch (frequency) {
    case "weekly":
      return Math.max(1, Math.round(months * 4.33));
    case "bi_weekly":
      return Math.max(1, Math.round(months * 2.16));
    case "monthly":
      return Math.max(1, months);
    case "quarterly":
      return Math.max(1, Math.round(months / 3));
    case "seasonal_custom":
      return Math.max(1, tenorValue);
    default:
      return Math.max(1, months);
  }
}

/**
 * Adds interval to date
 */
function addInstallmentInterval(date: Date, frequency: RepaymentFrequency, index: number): Date {
  const result = new Date(date.getTime());
  switch (frequency) {
    case "weekly":
      result.setDate(result.getDate() + index * 7);
      break;
    case "bi_weekly":
      result.setDate(result.getDate() + index * 14);
      break;
    case "monthly":
      result.setMonth(result.getMonth() + index);
      break;
    case "quarterly":
      result.setMonth(result.getMonth() + index * 3);
      break;
    case "harvest_bullet":
    case "seasonal_custom":
      result.setMonth(result.getMonth() + index * 6);
      break;
  }
  return result;
}

/**
 * Generates an immutable repayment schedule using banking amortization or flat rate
 */
export function generateRepaymentSchedule(params: ScheduleGenerationParams): RepaymentScheduleItem[] {
  const {
    principal,
    annualInterestRatePct,
    interestCalculationMethod,
    repaymentFrequency,
    tenorValue,
    tenorUnit,
    disbursementDate,
    originationFeeTotal = 0,
    harvestDate
  } = params;

  if (principal <= 0) return [];

  const baseDate = new Date(disbursementDate || new Date().toISOString());
  const numInstallments = calculateInstallmentCount(tenorValue, tenorUnit, repaymentFrequency);
  const schedule: RepaymentScheduleItem[] = [];

  // Special case: Harvest Bullet (Agricultural crop financing)
  if (repaymentFrequency === "harvest_bullet" || numInstallments === 1) {
    const tenorMonths = tenorUnit === "seasons" ? tenorValue * 6 : (tenorUnit === "months" ? tenorValue : 4);
    const totalInterest = Number(((principal * (annualInterestRatePct / 100) * (tenorMonths / 12))).toFixed(2));
    const dueDate = harvestDate ? harvestDate : addInstallmentInterval(baseDate, "monthly", tenorMonths).toISOString().split("T")[0];

    schedule.push({
      installmentNumber: 1,
      dueDate,
      principalDue: Number(principal.toFixed(2)),
      interestDue: totalInterest,
      feesDue: Number(originationFeeTotal.toFixed(2)),
      totalDue: Number((principal + totalInterest + originationFeeTotal).toFixed(2)),
      principalPaid: 0,
      interestPaid: 0,
      feesPaid: 0,
      totalPaid: 0,
      balanceRemaining: Number((principal + totalInterest + originationFeeTotal).toFixed(2)),
      status: "pending"
    });

    return schedule;
  }

  // Model A: Flat Rate Interest
  if (interestCalculationMethod === "flat") {
    const tenorMonths = tenorUnit === "seasons" ? tenorValue * 6 : tenorValue;
    const totalInterest = Number(((principal * (annualInterestRatePct / 100) * (tenorMonths / 12))).toFixed(2));
    const principalPerPeriod = Number((principal / numInstallments).toFixed(2));
    const interestPerPeriod = Number((totalInterest / numInstallments).toFixed(2));
    const feePerPeriod = Number((originationFeeTotal / numInstallments).toFixed(2));

    let runningBalance = principal + totalInterest + originationFeeTotal;

    for (let i = 1; i <= numInstallments; i++) {
      const isLast = i === numInstallments;
      const pDue = isLast ? Number((principal - principalPerPeriod * (numInstallments - 1)).toFixed(2)) : principalPerPeriod;
      const iDue = isLast ? Number((totalInterest - interestPerPeriod * (numInstallments - 1)).toFixed(2)) : interestPerPeriod;
      const fDue = isLast ? Number((originationFeeTotal - feePerPeriod * (numInstallments - 1)).toFixed(2)) : feePerPeriod;
      const totalDue = Number((pDue + iDue + fDue).toFixed(2));
      runningBalance = Math.max(0, Number((runningBalance - totalDue).toFixed(2)));

      const dueDate = addInstallmentInterval(baseDate, repaymentFrequency, i).toISOString().split("T")[0];

      schedule.push({
        installmentNumber: i,
        dueDate,
        principalDue: pDue,
        interestDue: iDue,
        feesDue: fDue,
        totalDue,
        principalPaid: 0,
        interestPaid: 0,
        feesPaid: 0,
        totalPaid: 0,
        balanceRemaining: Number((pDue + iDue + fDue).toFixed(2)),
        status: "pending"
      });
    }
    return schedule;
  }

  // Model B: Reducing Balance (Amortized Annuity)
  // Periodic interest rate r
  const periodsPerYear = repaymentFrequency === "weekly" ? 52 : repaymentFrequency === "bi_weekly" ? 26 : repaymentFrequency === "quarterly" ? 4 : 12;
  const periodicRate = (annualInterestRatePct / 100) / periodsPerYear;

  let periodicPayment: number;
  if (periodicRate > 0) {
    const factor = Math.pow(1 + periodicRate, numInstallments);
    periodicPayment = Number((principal * (periodicRate * factor) / (factor - 1)).toFixed(2));
  } else {
    periodicPayment = Number((principal / numInstallments).toFixed(2));
  }

  let remainingPrincipal = principal;
  const feePerPeriod = Number((originationFeeTotal / numInstallments).toFixed(2));

  for (let i = 1; i <= numInstallments; i++) {
    const interestDue = Number((remainingPrincipal * periodicRate).toFixed(2));
    let principalDue = Number((periodicPayment - interestDue).toFixed(2));

    if (i === numInstallments || principalDue > remainingPrincipal) {
      principalDue = Number(remainingPrincipal.toFixed(2));
    }

    const fDue = i === numInstallments ? Number((originationFeeTotal - feePerPeriod * (numInstallments - 1)).toFixed(2)) : feePerPeriod;
    const totalDue = Number((principalDue + interestDue + fDue).toFixed(2));
    remainingPrincipal = Math.max(0, Number((remainingPrincipal - principalDue).toFixed(2)));

    const dueDate = addInstallmentInterval(baseDate, repaymentFrequency, i).toISOString().split("T")[0];

    schedule.push({
      installmentNumber: i,
      dueDate,
      principalDue,
      interestDue,
      feesDue: fDue,
      totalDue,
      principalPaid: 0,
      interestPaid: 0,
      feesPaid: 0,
      totalPaid: 0,
      balanceRemaining: totalDue,
      status: "pending"
    });
  }

  return schedule;
}

/**
 * Authoritative Waterfall Payment Allocation
 * Waterfall Priority:
 * 1. Penalties
 * 2. Overdue Fees
 * 3. Overdue Interest
 * 4. Overdue Principal
 * 5. Current Fees Due
 * 6. Current Interest Due
 * 7. Current Principal Due
 * 8. Early / Advance Principal Repayment
 */
export interface WaterfallAllocationResult {
  penaltyPortion: number;
  feePortion: number;
  interestPortion: number;
  principalPortion: number;
  unallocatedOverpayment: number;
  updatedSchedule: RepaymentScheduleItem[];
  newPrincipalOutstanding: number;
  newInterestOutstanding: number;
  newFeesOutstanding: number;
  newPenaltiesOutstanding: number;
  newTotalOutstanding: number;
}

export function calculateWaterfallAllocation(
  paymentAmount: number,
  loan: Pick<Loan, "principalOutstanding" | "interestOutstanding" | "feesOutstanding" | "penaltiesOutstanding" | "schedule">
): WaterfallAllocationResult {
  let remainingPayment = Math.max(0, Number(paymentAmount.toFixed(2)));

  let penaltyPortion = 0;
  let feePortion = 0;
  let interestPortion = 0;
  let principalPortion = 0;

  let penaltiesBal = loan.penaltiesOutstanding || 0;
  let feesBal = loan.feesOutstanding || 0;
  let interestBal = loan.interestOutstanding || 0;
  let principalBal = loan.principalOutstanding || 0;

  // 1. Clear Penalties
  if (remainingPayment > 0 && penaltiesBal > 0) {
    penaltyPortion = Math.min(remainingPayment, penaltiesBal);
    remainingPayment = Number((remainingPayment - penaltyPortion).toFixed(2));
    penaltiesBal = Number((penaltiesBal - penaltyPortion).toFixed(2));
  }

  // 2. Clear Fees
  if (remainingPayment > 0 && feesBal > 0) {
    feePortion = Math.min(remainingPayment, feesBal);
    remainingPayment = Number((remainingPayment - feePortion).toFixed(2));
    feesBal = Number((feesBal - feePortion).toFixed(2));
  }

  // 3. Clear Interest
  if (remainingPayment > 0 && interestBal > 0) {
    interestPortion = Math.min(remainingPayment, interestBal);
    remainingPayment = Number((remainingPayment - interestPortion).toFixed(2));
    interestBal = Number((interestBal - interestPortion).toFixed(2));
  }

  // 4. Clear Principal
  if (remainingPayment > 0 && principalBal > 0) {
    principalPortion = Math.min(remainingPayment, principalBal);
    remainingPayment = Number((remainingPayment - principalPortion).toFixed(2));
    principalBal = Number((principalBal - principalPortion).toFixed(2));
  }

  // 5. Update Schedule lines chronologically
  const updatedSchedule = (loan.schedule || []).map((item) => ({ ...item }));
  let schedPrincipalToDistribute = principalPortion;
  let schedInterestToDistribute = interestPortion;
  let schedFeeToDistribute = feePortion;

  for (const item of updatedSchedule) {
    if (item.status === "paid") continue;

    // Allocate fees
    if (schedFeeToDistribute > 0) {
      const feeShortfall = Math.max(0, item.feesDue - item.feesPaid);
      const applyFee = Math.min(schedFeeToDistribute, feeShortfall);
      item.feesPaid = Number((item.feesPaid + applyFee).toFixed(2));
      schedFeeToDistribute = Number((schedFeeToDistribute - applyFee).toFixed(2));
    }

    // Allocate interest
    if (schedInterestToDistribute > 0) {
      const intShortfall = Math.max(0, item.interestDue - item.interestPaid);
      const applyInt = Math.min(schedInterestToDistribute, intShortfall);
      item.interestPaid = Number((item.interestPaid + applyInt).toFixed(2));
      schedInterestToDistribute = Number((schedInterestToDistribute - applyInt).toFixed(2));
    }

    // Allocate principal
    if (schedPrincipalToDistribute > 0) {
      const prinShortfall = Math.max(0, item.principalDue - item.principalPaid);
      const applyPrin = Math.min(schedPrincipalToDistribute, prinShortfall);
      item.principalPaid = Number((item.principalPaid + applyPrin).toFixed(2));
      schedPrincipalToDistribute = Number((schedPrincipalToDistribute - applyPrin).toFixed(2));
    }

    item.totalPaid = Number((item.principalPaid + item.interestPaid + item.feesPaid).toFixed(2));
    item.balanceRemaining = Math.max(0, Number((item.totalDue - item.totalPaid).toFixed(2)));

    if (item.balanceRemaining <= 0.01) {
      item.status = "paid";
      if (!item.paidAt) item.paidAt = new Date().toISOString();
    } else if (item.totalPaid > 0) {
      item.status = "partially_paid";
    }
  }

  const newTotalOutstanding = Number((principalBal + interestBal + feesBal + penaltiesBal).toFixed(2));

  return {
    penaltyPortion,
    feePortion,
    interestPortion,
    principalPortion,
    unallocatedOverpayment: remainingPayment,
    updatedSchedule,
    newPrincipalOutstanding: principalBal,
    newInterestOutstanding: interestBal,
    newFeesOutstanding: feesBal,
    newPenaltiesOutstanding: penaltiesBal,
    newTotalOutstanding
  };
}

/**
 * Evaluates Aging Bucket and Days Past Due (DPD)
 */
export function evaluateAgingBucket(
  nextDueDate: string,
  totalOutstanding: number,
  todayIso?: string
): { daysPastDue: number; agingBucket: AgingBucket } {
  if (totalOutstanding <= 0.01 || !nextDueDate) {
    return { daysPastDue: 0, agingBucket: "current" };
  }

  const today = todayIso ? new Date(todayIso) : new Date();
  const due = new Date(nextDueDate);
  const diffMs = today.getTime() - due.getTime();
  const dpd = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));

  if (dpd === 0) return { daysPastDue: 0, agingBucket: "current" };
  if (dpd <= 30) return { daysPastDue: dpd, agingBucket: "par_1_30" };
  if (dpd <= 60) return { daysPastDue: dpd, agingBucket: "par_31_60" };
  if (dpd <= 90) return { daysPastDue: dpd, agingBucket: "par_61_90" };
  if (dpd <= 180) return { daysPastDue: dpd, agingBucket: "par_90_plus" };
  return { daysPastDue: dpd, agingBucket: "default" };
}

/**
 * Aggregates portfolio metrics across all loans
 */
export function computePortfolioMetrics(loans: Loan[]): PortfolioMetrics {
  const metrics: PortfolioMetrics = {
    totalLoansCount: loans.length,
    activeLoansCount: 0,
    inArrearsCount: 0,
    paidOffCount: 0,
    defaultCount: 0,
    totalPrincipalDisbursed: 0,
    totalPrincipalRecovered: 0,
    totalInterestAccrued: 0,
    totalInterestRecovered: 0,
    totalOutstandingPrincipal: 0,
    totalOutstandingInterest: 0,
    totalArrearsAmount: 0,
    collectionEfficiencyPct: 100,
    par30Amount: 0,
    par30Pct: 0,
    par60Amount: 0,
    par60Pct: 0,
    par90Amount: 0,
    par90Pct: 0,
    byFinancingModel: {
      crop: { count: 0, exposure: 0, repaid: 0 },
      enterprise: { count: 0, exposure: 0, repaid: 0 }
    },
    bySector: {}
  };

  for (const l of loans) {
    metrics.totalPrincipalDisbursed += Number(l.principalDisbursed || 0);
    metrics.totalPrincipalRecovered += Number(l.totalPrincipalRepaid || 0);
    metrics.totalInterestAccrued += Number(l.totalInterestAccrued || 0);
    metrics.totalInterestRecovered += Number(l.totalInterestRepaid || 0);
    metrics.totalOutstandingPrincipal += Number(l.principalOutstanding || 0);
    metrics.totalOutstandingInterest += Number(l.interestOutstanding || 0);

    // Status counts
    if (l.status === "active") metrics.activeLoansCount++;
    else if (l.status === "in_arrears") {
      metrics.inArrearsCount++;
      metrics.totalArrearsAmount += Number(l.totalOutstandingBalance || 0);
    } else if (l.status === "paid_off") metrics.paidOffCount++;
    else if (l.status === "defaulted" || l.status === "written_off") metrics.defaultCount++;

    // Aging / PAR
    const dpd = l.daysPastDue || 0;
    const exposure = Number(l.principalOutstanding || 0);

    if (dpd > 30) metrics.par30Amount += exposure;
    if (dpd > 60) metrics.par60Amount += exposure;
    if (dpd > 90) metrics.par90Amount += exposure;

    // Financing model aggregation
    const isCrop = l.financingModel === "agricultural_crop";
    if (isCrop) {
      metrics.byFinancingModel.crop.count++;
      metrics.byFinancingModel.crop.exposure += exposure;
      metrics.byFinancingModel.crop.repaid += Number(l.totalRepaid || 0);
    } else {
      metrics.byFinancingModel.enterprise.count++;
      metrics.byFinancingModel.enterprise.exposure += exposure;
      metrics.byFinancingModel.enterprise.repaid += Number(l.totalRepaid || 0);
    }
  }

  // Round metrics
  metrics.totalPrincipalDisbursed = Number(metrics.totalPrincipalDisbursed.toFixed(2));
  metrics.totalPrincipalRecovered = Number(metrics.totalPrincipalRecovered.toFixed(2));
  metrics.totalOutstandingPrincipal = Number(metrics.totalOutstandingPrincipal.toFixed(2));
  metrics.totalOutstandingInterest = Number(metrics.totalOutstandingInterest.toFixed(2));
  metrics.totalArrearsAmount = Number(metrics.totalArrearsAmount.toFixed(2));
  metrics.par30Amount = Number(metrics.par30Amount.toFixed(2));
  metrics.par60Amount = Number(metrics.par60Amount.toFixed(2));
  metrics.par90Amount = Number(metrics.par90Amount.toFixed(2));

  if (metrics.totalOutstandingPrincipal > 0) {
    metrics.par30Pct = Number(((metrics.par30Amount / metrics.totalOutstandingPrincipal) * 100).toFixed(1));
    metrics.par60Pct = Number(((metrics.par60Amount / metrics.totalOutstandingPrincipal) * 100).toFixed(1));
    metrics.par90Pct = Number(((metrics.par90Amount / metrics.totalOutstandingPrincipal) * 100).toFixed(1));
  }

  const totalDue = metrics.totalPrincipalDisbursed + metrics.totalInterestAccrued;
  const totalRecovered = metrics.totalPrincipalRecovered + metrics.totalInterestRecovered;
  if (totalDue > 0) {
    metrics.collectionEfficiencyPct = Number(((totalRecovered / totalDue) * 100).toFixed(1));
  }

  return metrics;
}

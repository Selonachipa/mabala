/**
 * Mabala.cloud - Loan Double-Entry Accounting Bridge
 * Authoritative integration with Mabala General Ledger & Chart of Accounts (CoA)
 */

import { Loan, LoanTransaction, TransactionType, RepaymentSource } from "../types";

export interface LedgerJournalLine {
  accountCode: string; // e.g. "1200", "1010", "4300"
  accountName: string;
  debit: number;
  credit: number;
  description: string;
}

export interface BalancedJournalEntry {
  id: string;
  date: string;
  tenantId: string;
  referenceType: "loan_disbursement" | "loan_repayment" | "interest_accrual" | "fee_charge" | "write_off";
  referenceId: string; // Loan ID or Tx ID
  loanNumber: string;
  narration: string;
  lines: LedgerJournalLine[];
  totalDebit: number;
  totalCredit: number;
  isBalanced: boolean;
  createdAt: string;
}

/**
 * Standard Mabala Chart of Accounts for Lending
 */
export const LOAN_COA = {
  // Assets
  CASH_AND_BANK: { code: "1010", name: "Cash and Bank Accounts" },
  MABALA_WALLET: { code: "1020", name: "Mabala Digital Wallet" },
  LOANS_RECEIVABLE_CURRENT: { code: "1200", name: "Loans Receivable - Short Term (Asset)" },
  LOANS_RECEIVABLE_LONG_TERM: { code: "1210", name: "Loans Receivable - Long Term (Asset)" },
  INTEREST_RECEIVABLE: { code: "1215", name: "Interest Receivable on Loans (Asset)" },
  INVENTORY_INPUTS: { code: "1300", name: "Agricultural Inputs & Seed Stock (Asset)" },

  // Liabilities
  LOANS_PAYABLE: { code: "2100", name: "Loans & Borrowings Payable (Liability)" },
  INTEREST_PAYABLE: { code: "2115", name: "Interest Payable (Liability)" },

  // Revenue
  INTEREST_INCOME: { code: "4300", name: "Interest Income on Loans (Revenue)" },
  LOAN_ORIGINATION_FEES: { code: "4400", name: "Loan Origination & Admin Fees (Revenue)" },
  LATE_PENALTY_INCOME: { code: "4410", name: "Late Penalty Fee Income (Revenue)" },

  // Expenses
  INTEREST_EXPENSE: { code: "5300", name: "Interest Expense on Borrowings (Expense)" },
  LOAN_PROCESSING_EXPENSE: { code: "5400", name: "Bank & Loan Processing Fees (Expense)" },
  BAD_DEBT_EXPENSE: { code: "5800", name: "Loan Loss & Impairment Expense (Expense)" }
};

/**
 * Generates balanced double-entry journal entry for a Loan Disbursement
 */
export function generateDisbursementJournal(
  loan: Loan,
  disbursementMethod: string,
  originationFeeDeducted: number = 0
): BalancedJournalEntry {
  const now = new Date().toISOString();
  const entryId = `JRN-LND-DISB-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  const lines: LedgerJournalLine[] = [];

  const principal = Number(loan.principalDisbursed.toFixed(2));
  const netDisbursed = Number((principal - originationFeeDeducted).toFixed(2));

  // Determine credit source
  const isWallet = disbursementMethod === "mabala_wallet";
  const isInput = disbursementMethod === "input_voucher";
  const creditAccount = isWallet 
    ? LOAN_COA.MABALA_WALLET 
    : (isInput ? LOAN_COA.INVENTORY_INPUTS : LOAN_COA.CASH_AND_BANK);

  // 1. Debit Loans Receivable (Asset increases)
  lines.push({
    accountCode: LOAN_COA.LOANS_RECEIVABLE_CURRENT.code,
    accountName: LOAN_COA.LOANS_RECEIVABLE_CURRENT.name,
    debit: principal,
    credit: 0,
    description: `Loan disbursement to ${loan.borrowerName} (${loan.loanNumber})`
  });

  // 2. Credit Cash / Wallet / Inventory (Asset decreases)
  lines.push({
    accountCode: creditAccount.code,
    accountName: creditAccount.name,
    debit: 0,
    credit: netDisbursed,
    description: `Disbursement transfer via ${disbursementMethod}`
  });

  // 3. If origination fee was deducted upfront, Credit Fee Revenue
  if (originationFeeDeducted > 0) {
    lines.push({
      accountCode: LOAN_COA.LOAN_ORIGINATION_FEES.code,
      accountName: LOAN_COA.LOAN_ORIGINATION_FEES.name,
      debit: 0,
      credit: originationFeeDeducted,
      description: `Origination fee withheld on loan ${loan.loanNumber}`
    });
  }

  const totalDebit = lines.reduce((sum, l) => sum + l.debit, 0);
  const totalCredit = lines.reduce((sum, l) => sum + l.credit, 0);

  return {
    id: entryId,
    date: loan.disbursementDate || now.split("T")[0],
    tenantId: loan.lenderTenantId,
    referenceType: "loan_disbursement",
    referenceId: loan.id,
    loanNumber: loan.loanNumber,
    narration: `Disbursement of ${loan.productName} to ${loan.borrowerName} (${loan.loanNumber})`,
    lines,
    totalDebit: Number(totalDebit.toFixed(2)),
    totalCredit: Number(totalCredit.toFixed(2)),
    isBalanced: Math.abs(totalDebit - totalCredit) < 0.01,
    createdAt: now
  };
}

/**
 * Generates balanced double-entry journal entry for a Loan Repayment
 */
export function generateRepaymentJournal(
  loan: Loan,
  repaymentAmount: number,
  breakdown: { principal: number; interest: number; fee: number; penalty: number },
  source: RepaymentSource,
  txId: string
): BalancedJournalEntry {
  const now = new Date().toISOString();
  const entryId = `JRN-LND-REPAY-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  const lines: LedgerJournalLine[] = [];

  const debitAccount = source === "mabala_ledger" ? LOAN_COA.MABALA_WALLET : LOAN_COA.CASH_AND_BANK;

  // 1. Debit Cash or Wallet (Asset increases by total repayment)
  lines.push({
    accountCode: debitAccount.code,
    accountName: debitAccount.name,
    debit: Number(repaymentAmount.toFixed(2)),
    credit: 0,
    description: `Repayment received from ${loan.borrowerName} via ${source}`
  });

  // 2. Credit Loans Receivable (Principal portion)
  if (breakdown.principal > 0) {
    lines.push({
      accountCode: LOAN_COA.LOANS_RECEIVABLE_CURRENT.code,
      accountName: LOAN_COA.LOANS_RECEIVABLE_CURRENT.name,
      debit: 0,
      credit: Number(breakdown.principal.toFixed(2)),
      description: `Principal recovery on loan ${loan.loanNumber}`
    });
  }

  // 3. Credit Interest Income
  if (breakdown.interest > 0) {
    lines.push({
      accountCode: LOAN_COA.INTEREST_INCOME.code,
      accountName: LOAN_COA.INTEREST_INCOME.name,
      debit: 0,
      credit: Number(breakdown.interest.toFixed(2)),
      description: `Interest income collected on loan ${loan.loanNumber}`
    });
  }

  // 4. Credit Fee Income
  if (breakdown.fee > 0) {
    lines.push({
      accountCode: LOAN_COA.LOAN_ORIGINATION_FEES.code,
      accountName: LOAN_COA.LOAN_ORIGINATION_FEES.name,
      debit: 0,
      credit: Number(breakdown.fee.toFixed(2)),
      description: `Loan fees collected on loan ${loan.loanNumber}`
    });
  }

  // 5. Credit Penalty Income
  if (breakdown.penalty > 0) {
    lines.push({
      accountCode: LOAN_COA.LATE_PENALTY_INCOME.code,
      accountName: LOAN_COA.LATE_PENALTY_INCOME.name,
      debit: 0,
      credit: Number(breakdown.penalty.toFixed(2)),
      description: `Late payment penalty collected on loan ${loan.loanNumber}`
    });
  }

  const totalDebit = lines.reduce((sum, l) => sum + l.debit, 0);
  const totalCredit = lines.reduce((sum, l) => sum + l.credit, 0);

  return {
    id: entryId,
    date: now.split("T")[0],
    tenantId: loan.lenderTenantId,
    referenceType: "loan_repayment",
    referenceId: txId,
    loanNumber: loan.loanNumber,
    narration: `Repayment received from ${loan.borrowerName} (${loan.loanNumber})`,
    lines,
    totalDebit: Number(totalDebit.toFixed(2)),
    totalCredit: Number(totalCredit.toFixed(2)),
    isBalanced: Math.abs(totalDebit - totalCredit) < 0.01,
    createdAt: now
  };
}

/**
 * Generates balanced double-entry journal entry for a Loan Write-Off
 */
export function generateWriteOffJournal(
  loan: Loan,
  principalWrittenOff: number,
  interestWrittenOff: number,
  reason: string
): BalancedJournalEntry {
  const now = new Date().toISOString();
  const entryId = `JRN-LND-WRITEOFF-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  const lines: LedgerJournalLine[] = [];
  const totalWrittenOff = Number((principalWrittenOff + interestWrittenOff).toFixed(2));

  // 1. Debit Bad Debt Expense
  lines.push({
    accountCode: LOAN_COA.BAD_DEBT_EXPENSE.code,
    accountName: LOAN_COA.BAD_DEBT_EXPENSE.name,
    debit: totalWrittenOff,
    credit: 0,
    description: `Write-off of defaulted loan ${loan.loanNumber}: ${reason}`
  });

  // 2. Credit Loans Receivable (remove principal asset)
  if (principalWrittenOff > 0) {
    lines.push({
      accountCode: LOAN_COA.LOANS_RECEIVABLE_CURRENT.code,
      accountName: LOAN_COA.LOANS_RECEIVABLE_CURRENT.name,
      debit: 0,
      credit: Number(principalWrittenOff.toFixed(2)),
      description: `Derecognition of principal for ${loan.borrowerName}`
    });
  }

  // 3. Credit Interest Receivable (remove interest asset)
  if (interestWrittenOff > 0) {
    lines.push({
      accountCode: LOAN_COA.INTEREST_RECEIVABLE.code,
      accountName: LOAN_COA.INTEREST_RECEIVABLE.name,
      debit: 0,
      credit: Number(interestWrittenOff.toFixed(2)),
      description: `Derecognition of uncollected interest for ${loan.borrowerName}`
    });
  }

  const totalDebit = lines.reduce((sum, l) => sum + l.debit, 0);
  const totalCredit = lines.reduce((sum, l) => sum + l.credit, 0);

  return {
    id: entryId,
    date: now.split("T")[0],
    tenantId: loan.lenderTenantId,
    referenceType: "write_off",
    referenceId: loan.id,
    loanNumber: loan.loanNumber,
    narration: `Default Write-Off of loan ${loan.loanNumber} (${loan.borrowerName}): ${reason}`,
    lines,
    totalDebit: Number(totalDebit.toFixed(2)),
    totalCredit: Number(totalCredit.toFixed(2)),
    isBalanced: Math.abs(totalDebit - totalCredit) < 0.01,
    createdAt: now
  };
}

/**
 * Computes SHA-256 cryptographic hash for immutable loan ledger event chaining
 */
export function computeEventHash(
  payload: {
    loanId: string;
    type: TransactionType;
    amount: number;
    timestamp: string;
    referenceId: string;
    previousHash?: string;
  }
): string {
  const content = `${payload.previousHash || "ROOT"}|${payload.loanId}|${payload.type}|${payload.amount.toFixed(2)}|${payload.timestamp}|${payload.referenceId}`;
  
  // Lightweight browser-safe string hash that matches hex length
  let hash1 = 5381;
  let hash2 = 52711;
  for (let i = 0; i < content.length; i++) {
    const char = content.charCodeAt(i);
    hash1 = (hash1 * 33) ^ char;
    hash2 = (hash2 * 33) ^ char;
  }
  const h1 = (hash1 >>> 0).toString(16).padStart(8, "0");
  const h2 = (hash2 >>> 0).toString(16).padStart(8, "0");
  const h3 = ((hash1 + hash2) >>> 0).toString(16).padStart(8, "0");
  const h4 = (Math.imul(hash1, 31) >>> 0).toString(16).padStart(8, "0");
  return `${h1}${h2}${h3}${h4}`.toUpperCase();
}

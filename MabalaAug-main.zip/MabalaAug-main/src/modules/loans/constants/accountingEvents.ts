/**
 * Mabala.cloud - Loan Management Engine
 * Accounting Event Templates & Chart of Accounts Integration
 * 
 * Defines standard double-entry journal templates for:
 * - LOAN_DISBURSEMENT
 * - INTEREST_ACCRUAL
 * - REPAYMENT
 * - FEE_CHARGE
 * - PENALTY_ACCRUAL
 * - LOAN_WRITE_OFF
 * - DDAC_AUTO_DEBIT
 */

import { LOAN_COA, LedgerJournalLine } from "../engine/loanAccounting";

export type AccountingEventType =
  | "LOAN_DISBURSEMENT"
  | "INTEREST_ACCRUAL"
  | "REPAYMENT"
  | "FEE_CHARGE"
  | "PENALTY_ACCRUAL"
  | "LOAN_WRITE_OFF"
  | "DDAC_AUTO_DEBIT"
  | "COLLATERAL_RECOVERY";

export interface AccountingEventRule {
  eventType: AccountingEventType;
  name: string;
  description: string;
  category: "asset_origination" | "income_recognition" | "asset_reduction" | "fee_assessment" | "loss_provision";
  debitAccountCode: string;
  debitAccountName: string;
  creditAccountCode: string;
  creditAccountName: string;
  defaultNarrationTemplate: string;
  reconciliationKey: string;
}

/**
 * Standard Double-Entry Ledger Event Templates for Mabala Loan Management
 * Fully integrated with Mabala General Ledger & Financial Chart of Accounts (CoA)
 */
export const ACCOUNTING_EVENT_TEMPLATES: Record<AccountingEventType, AccountingEventRule> = {
  LOAN_DISBURSEMENT: {
    eventType: "LOAN_DISBURSEMENT",
    name: "Loan Disbursement & Origination",
    description: "Debits Loan Portfolio Asset (1200) and Credits Funding Source/Wallet/Bank (1010/1020) upon capital release.",
    category: "asset_origination",
    debitAccountCode: LOAN_COA.LOANS_RECEIVABLE_CURRENT.code,
    debitAccountName: LOAN_COA.LOANS_RECEIVABLE_CURRENT.name,
    creditAccountCode: LOAN_COA.MABALA_WALLET.code, // or 1010 Cash & Bank / 1300 Inputs
    creditAccountName: LOAN_COA.MABALA_WALLET.name,
    defaultNarrationTemplate: "Loan capital disbursement for loan #{loanNumber} to borrower {borrowerName}",
    reconciliationKey: "DISB"
  },

  INTEREST_ACCRUAL: {
    eventType: "INTEREST_ACCRUAL",
    name: "Periodic Interest Accrual",
    description: "Debits Interest Receivable (1215) and Credits Interest Income (4300) on daily/monthly accrual cycle.",
    category: "income_recognition",
    debitAccountCode: LOAN_COA.INTEREST_RECEIVABLE.code,
    debitAccountName: LOAN_COA.INTEREST_RECEIVABLE.name,
    creditAccountCode: LOAN_COA.INTEREST_INCOME.code,
    creditAccountName: LOAN_COA.INTEREST_INCOME.name,
    defaultNarrationTemplate: "Accrued interest income for period on loan #{loanNumber}",
    reconciliationKey: "INT_ACCR"
  },

  REPAYMENT: {
    eventType: "REPAYMENT",
    name: "Loan Repayment Settlement",
    description: "Debits Cash/Wallet/Clearing (1010/1020) and Credits Loan Asset (1200) & Interest/Fee Receivables (1215/4400).",
    category: "asset_reduction",
    debitAccountCode: LOAN_COA.MABALA_WALLET.code,
    debitAccountName: LOAN_COA.MABALA_WALLET.name,
    creditAccountCode: LOAN_COA.LOANS_RECEIVABLE_CURRENT.code,
    creditAccountName: LOAN_COA.LOANS_RECEIVABLE_CURRENT.name,
    defaultNarrationTemplate: "Loan repayment settlement received for loan #{loanNumber} from {borrowerName}",
    reconciliationKey: "REPAY"
  },

  FEE_CHARGE: {
    eventType: "FEE_CHARGE",
    name: "Loan Origination & Administration Fee",
    description: "Debits Cash/Withholding and Credits Loan Origination Fee Income (4400).",
    category: "fee_assessment",
    debitAccountCode: LOAN_COA.MABALA_WALLET.code,
    debitAccountName: LOAN_COA.MABALA_WALLET.name,
    creditAccountCode: LOAN_COA.LOAN_ORIGINATION_FEES.code,
    creditAccountName: LOAN_COA.LOAN_ORIGINATION_FEES.name,
    defaultNarrationTemplate: "Origination & underwriting administration fee for loan #{loanNumber}",
    reconciliationKey: "FEE"
  },

  PENALTY_ACCRUAL: {
    eventType: "PENALTY_ACCRUAL",
    name: "Late Payment Penalty Charge",
    description: "Debits Accounts Receivable (1200) and Credits Late Penalty Income (4410) upon overdue payment event.",
    category: "income_recognition",
    debitAccountCode: LOAN_COA.LOANS_RECEIVABLE_CURRENT.code,
    debitAccountName: LOAN_COA.LOANS_RECEIVABLE_CURRENT.name,
    creditAccountCode: LOAN_COA.LATE_PENALTY_INCOME.code,
    creditAccountName: LOAN_COA.LATE_PENALTY_INCOME.name,
    defaultNarrationTemplate: "Delinquency default penalty assessed for overdue installment on loan #{loanNumber}",
    reconciliationKey: "PENALTY"
  },

  LOAN_WRITE_OFF: {
    eventType: "LOAN_WRITE_OFF",
    name: "Bad Debt & Impairment Write-Off",
    description: "Debits Bad Debt & Loan Loss Expense (5800) and Credits Loans Receivable (1200) for defaulted unrecoverable balances.",
    category: "loss_provision",
    debitAccountCode: LOAN_COA.BAD_DEBT_EXPENSE.code,
    debitAccountName: LOAN_COA.BAD_DEBT_EXPENSE.name,
    creditAccountCode: LOAN_COA.LOANS_RECEIVABLE_CURRENT.code,
    creditAccountName: LOAN_COA.LOANS_RECEIVABLE_CURRENT.name,
    defaultNarrationTemplate: "Bad debt write-off authorization for defaulted loan #{loanNumber}",
    reconciliationKey: "WRITE_OFF"
  },

  DDAC_AUTO_DEBIT: {
    eventType: "DDAC_AUTO_DEBIT",
    name: "Direct Debit Against Crop Sales / Digital Mandate",
    description: "Automated DDAC deduction from Mabala Ledger wallet (1020) clearing outstanding borrower loan obligation.",
    category: "asset_reduction",
    debitAccountCode: LOAN_COA.MABALA_WALLET.code,
    debitAccountName: LOAN_COA.MABALA_WALLET.name,
    creditAccountCode: LOAN_COA.LOANS_RECEIVABLE_CURRENT.code,
    creditAccountName: LOAN_COA.LOANS_RECEIVABLE_CURRENT.name,
    defaultNarrationTemplate: "Automated DDAC mandate collection for installment due on loan #{loanNumber}",
    reconciliationKey: "DDAC"
  },

  COLLATERAL_RECOVERY: {
    eventType: "COLLATERAL_RECOVERY",
    name: "Collateral Liquidation & Recovery",
    description: "Debits Liquidation Cash Proceeds (1010) and Credits Loan Asset (1200) / Gain-Loss accounts.",
    category: "asset_reduction",
    debitAccountCode: LOAN_COA.CASH_AND_BANK.code,
    debitAccountName: LOAN_COA.CASH_AND_BANK.name,
    creditAccountCode: LOAN_COA.LOANS_RECEIVABLE_CURRENT.code,
    creditAccountName: LOAN_COA.LOANS_RECEIVABLE_CURRENT.name,
    defaultNarrationTemplate: "Collateral liquidation proceeds applied to loan balance #{loanNumber}",
    reconciliationKey: "COLL_RECOV"
  }
};

/**
 * Builds standard journal lines from an accounting template
 */
export function buildJournalLinesFromTemplate(
  eventType: AccountingEventType,
  amount: number,
  narration: string,
  overrides?: {
    debitAccountCode?: string;
    debitAccountName?: string;
    creditAccountCode?: string;
    creditAccountName?: string;
  }
): LedgerJournalLine[] {
  const template = ACCOUNTING_EVENT_TEMPLATES[eventType];
  const roundedAmount = Number(amount.toFixed(2));

  return [
    {
      accountCode: overrides?.debitAccountCode || template.debitAccountCode,
      accountName: overrides?.debitAccountName || template.debitAccountName,
      debit: roundedAmount,
      credit: 0,
      description: narration
    },
    {
      accountCode: overrides?.creditAccountCode || template.creditAccountCode,
      accountName: overrides?.creditAccountName || template.creditAccountName,
      debit: 0,
      credit: roundedAmount,
      description: narration
    }
  ];
}

export * from "./accountingEvents";

export const LOAN_STATUSES = {
  DRAFT: "draft",
  SUBMITTED: "submitted",
  UNDER_REVIEW: "under_review",
  APPROVED: "approved",
  REJECTED: "rejected",
  DISBURSED: "disbursed",
  ACTIVE: "active",
  IN_ARREARS: "in_arrears",
  PAID_OFF: "paid_off",
  WRITTEN_OFF: "written_off"
} as const;

export const PRODUCT_CATEGORIES = {
  FACILITY: "FACILITY",
  INPUT_CREDIT: "INPUT_CREDIT"
} as const;

export const DEFAULT_CURRENCY = "ZMW" as const;

export const DDAC_EXECUTION_STATUS = {
  SUCCESS: "SUCCESS",
  FAILED_INSUFFICIENT_FUNDS: "FAILED_INSUFFICIENT_FUNDS",
  PARTIALLY_CLEARED: "PARTIALLY_CLEARED",
  MANDATE_INVALID: "MANDATE_INVALID",
  SKIPPED: "SKIPPED"
} as const;

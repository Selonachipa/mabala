/**
 * Mabala.cloud - Loan Management Module: Interest Service
 * 
 * Comprehensive, deterministic interest calculation engine supporting:
 * 1. Compound Interest (Periodic compounding: daily, weekly, bi-weekly, monthly, quarterly, semi-annual, annual, and continuous)
 * 2. Reducing-Balance Amortization (Equated Monthly Installment / EMI annuity and Equal Principal linear reduction)
 * 3. Grace Periods (Interest-only moratorium and capitalized interest)
 * 4. Banking Day-Count Conventions (30/360, Actual/365, Actual/360)
 * 5. Analytical comparative modeling (Flat vs. Reducing vs. Compound)
 */

import {
  InterestCalculationMethod,
  RepaymentFrequency,
  TenorUnit
} from "../types";

export type CompoundingFrequency =
  | "annually"
  | "semi_annually"
  | "quarterly"
  | "monthly"
  | "bi_weekly"
  | "weekly"
  | "daily"
  | "continuous";

export type ReducingBalanceMethod =
  | "equal_installments" // Constant payment (EMI / Annuity), principal increases over time
  | "equal_principal";   // Constant principal payment, total payment decreases over time

export type GracePeriodType =
  | "interest_only"          // Borrower pays only interest accrued during grace period
  | "moratorium_capitalized" // Interest accrues and is added to principal during grace period
  | "moratorium_deferred";   // Interest accrues but payment is deferred post-grace

export type DayCountConvention = "30_360" | "actual_365" | "actual_360";

export interface CompoundInterestParams {
  principal: number;
  annualRatePct: number;
  tenorValue: number;
  tenorUnit?: TenorUnit;
  compoundingFrequency?: CompoundingFrequency;
  dayCountConvention?: DayCountConvention;
}

export interface ReducingBalanceParams {
  principal: number;
  annualRatePct: number;
  tenorValue: number;
  tenorUnit?: TenorUnit;
  repaymentFrequency?: RepaymentFrequency;
  method?: ReducingBalanceMethod;
  gracePeriodValue?: number;
  gracePeriodUnit?: "days" | "weeks" | "months";
  gracePeriodType?: GracePeriodType;
  originationFeeTotal?: number;
  startDate?: string;
}

export interface InterestCalculationSummary {
  principal: number;
  annualRatePct: number;
  totalInterest: number;
  totalRepayable: number;
  effectiveAnnualRatePct: number; // EAR (effective annual rate accounting for compounding)
  nominalAnnualRatePct: number;   // APR (nominal annual percentage rate)
  periodicRatePct: number;
  numberOfPeriods: number;
  installmentAmount?: number;     // Typical or initial installment amount
  method: InterestCalculationMethod;
}

export interface AmortizationScheduleRow {
  period: number;
  dueDate: string;
  openingPrincipal: number;
  installmentAmount: number;
  principalPortion: number;
  interestPortion: number;
  feesPortion: number;
  closingPrincipal: number;
  cumulativePrincipal: number;
  cumulativeInterest: number;
  isGracePeriod?: boolean;
}

export interface ReducingBalanceScheduleResult {
  summary: InterestCalculationSummary;
  schedule: AmortizationScheduleRow[];
  totalPrincipal: number;
  totalInterest: number;
  totalFees: number;
  totalRepayable: number;
}

export interface CompoundAccrualPeriodRow {
  period: number;
  periodLabel: string;
  openingBalance: number;
  interestAccrued: number;
  closingBalance: number;
  cumulativeInterest: number;
}

export interface DailyAccrualParams {
  principal: number;
  annualRatePct: number;
  days: number;
  convention?: DayCountConvention;
  isCompound?: boolean;
  compoundingFrequency?: CompoundingFrequency;
}

export interface MethodComparisonResult {
  principal: number;
  annualRatePct: number;
  tenorMonths: number;
  flat: {
    totalInterest: number;
    totalRepayable: number;
    monthlyInstallment: number;
  };
  reducingBalance: {
    totalInterest: number;
    totalRepayable: number;
    monthlyInstallment: number; // EMI
    method: ReducingBalanceMethod;
  };
  compound: {
    totalInterest: number;
    totalRepayable: number;
    compoundingFrequency: CompoundingFrequency;
  };
  savingsWithReducingVsFlat: number;
  savingsWithReducingVsCompound: number;
}

/**
 * Normalizes tenor value to years as a floating point number
 */
export function tenorToYears(tenorValue: number, tenorUnit: TenorUnit = "months"): number {
  switch (tenorUnit) {
    case "days":
      return tenorValue / 365;
    case "weeks":
      return tenorValue / 52;
    case "months":
      return tenorValue / 12;
    case "seasons":
      // Standard agricultural season is 6 months (0.5 years)
      return (tenorValue * 6) / 12;
    default:
      return tenorValue / 12;
  }
}

/**
 * Normalizes tenor value to months
 */
export function tenorToMonths(tenorValue: number, tenorUnit: TenorUnit = "months"): number {
  switch (tenorUnit) {
    case "days":
      return tenorValue / 30;
    case "weeks":
      return tenorValue / 4.3333;
    case "months":
      return tenorValue;
    case "seasons":
      return tenorValue * 6;
    default:
      return tenorValue;
  }
}

/**
 * Returns number of compounding periods per year
 */
export function getPeriodsPerYear(frequency: CompoundingFrequency | RepaymentFrequency): number {
  switch (frequency) {
    case "continuous":
      return Infinity;
    case "daily":
      return 365;
    case "weekly":
      return 52;
    case "bi_weekly":
      return 26;
    case "monthly":
      return 12;
    case "quarterly":
      return 4;
    case "semi_annually":
      return 2;
    case "annually":
      return 1;
    case "harvest_bullet":
    case "seasonal_custom":
      return 2; // Default 2 seasons per year in Southern Africa
    default:
      return 12;
  }
}

/**
 * Calculates Effective Annual Rate (EAR) from Nominal APR and compounding frequency
 * EAR = (1 + r/m)^m - 1
 */
export function calculateEffectiveAnnualRate(
  nominalRatePct: number,
  frequency: CompoundingFrequency
): number {
  const r = nominalRatePct / 100;
  if (r <= 0) return 0;

  if (frequency === "continuous") {
    // EAR = e^r - 1
    const ear = Math.exp(r) - 1;
    return Number((ear * 100).toFixed(4));
  }

  const m = getPeriodsPerYear(frequency);
  const ear = Math.pow(1 + r / m, m) - 1;
  return Number((ear * 100).toFixed(4));
}

/**
 * Calculates Nominal Annual Percentage Rate (APR) from Effective Annual Rate (EAR)
 * r = m * ((1 + EAR)^(1/m) - 1)
 */
export function calculateNominalRateFromEAR(
  effectiveRatePct: number,
  frequency: CompoundingFrequency
): number {
  const ear = effectiveRatePct / 100;
  if (ear <= 0) return 0;

  if (frequency === "continuous") {
    const r = Math.log(1 + ear);
    return Number((r * 100).toFixed(4));
  }

  const m = getPeriodsPerYear(frequency);
  const r = m * (Math.pow(1 + ear, 1 / m) - 1);
  return Number((r * 100).toFixed(4));
}

/**
 * Calculates Day Count Factor based on standard banking day-count conventions
 */
export function getDayCountFactor(
  days: number,
  convention: DayCountConvention = "actual_365"
): number {
  switch (convention) {
    case "30_360":
      return days / 360;
    case "actual_360":
      return days / 360;
    case "actual_365":
    default:
      return days / 365;
  }
}

/**
 * Adds periods to a date ISO string
 */
function addPeriodToDate(
  dateIso: string,
  frequency: RepaymentFrequency | CompoundingFrequency,
  periodIndex: number
): string {
  const d = new Date(dateIso);
  if (isNaN(d.getTime())) {
    return new Date().toISOString().split("T")[0];
  }

  switch (frequency) {
    case "daily":
      d.setDate(d.getDate() + periodIndex);
      break;
    case "weekly":
      d.setDate(d.getDate() + periodIndex * 7);
      break;
    case "bi_weekly":
      d.setDate(d.getDate() + periodIndex * 14);
      break;
    case "monthly":
      d.setMonth(d.getMonth() + periodIndex);
      break;
    case "quarterly":
      d.setMonth(d.getMonth() + periodIndex * 3);
      break;
    case "semi_annually":
      d.setMonth(d.getMonth() + periodIndex * 6);
      break;
    case "annually":
      d.setFullYear(d.getFullYear() + periodIndex);
      break;
    case "harvest_bullet":
    case "seasonal_custom":
      d.setMonth(d.getMonth() + periodIndex * 6);
      break;
    default:
      d.setMonth(d.getMonth() + periodIndex);
      break;
  }

  return d.toISOString().split("T")[0];
}

// ============================================================================
// 1. COMPOUND INTEREST ENGINE
// ============================================================================

/**
 * Calculates Compound Interest using periodic compounding or continuous compounding:
 * Formula: A = P * (1 + r/m)^(m * t)
 * Where:
 *   P = Principal
 *   r = Annual interest rate (decimal)
 *   m = Number of times interest compounded per year
 *   t = Time in years
 * 
 * For continuous compounding: A = P * e^(r * t)
 */
export function calculateCompoundInterest(
  params: CompoundInterestParams
): InterestCalculationSummary {
  const {
    principal,
    annualRatePct,
    tenorValue,
    tenorUnit = "months",
    compoundingFrequency = "monthly"
  } = params;

  const p = Math.max(0, principal);
  const r = Math.max(0, annualRatePct) / 100;
  const t = Math.max(0, tenorToYears(tenorValue, tenorUnit));

  if (p === 0 || r === 0 || t === 0) {
    return {
      principal: p,
      annualRatePct,
      totalInterest: 0,
      totalRepayable: p,
      effectiveAnnualRatePct: 0,
      nominalAnnualRatePct: annualRatePct,
      periodicRatePct: 0,
      numberOfPeriods: 0,
      method: "compound"
    };
  }

  let futureValue: number;
  let numberOfPeriods: number;
  let periodicRatePct: number;

  if (compoundingFrequency === "continuous") {
    // Continuous compounding: A = P * e^(r*t)
    futureValue = p * Math.exp(r * t);
    numberOfPeriods = Math.round(t * 365); // represented in days
    periodicRatePct = Number(((r / 365) * 100).toFixed(6));
  } else {
    const m = getPeriodsPerYear(compoundingFrequency);
    numberOfPeriods = Math.max(1, Math.round(m * t));
    const periodicRate = r / m;
    periodicRatePct = Number((periodicRate * 100).toFixed(4));
    futureValue = p * Math.pow(1 + periodicRate, numberOfPeriods);
  }

  const totalRepayable = Number(futureValue.toFixed(2));
  const totalInterest = Number(Math.max(0, totalRepayable - p).toFixed(2));
  const ear = calculateEffectiveAnnualRate(annualRatePct, compoundingFrequency);
  const installmentAmount = numberOfPeriods > 0 ? Number((totalRepayable / numberOfPeriods).toFixed(2)) : totalRepayable;

  return {
    principal: p,
    annualRatePct,
    totalInterest,
    totalRepayable,
    effectiveAnnualRatePct: ear,
    nominalAnnualRatePct: annualRatePct,
    periodicRatePct,
    numberOfPeriods,
    installmentAmount,
    method: "compound"
  };
}

/**
 * Generates periodic compounding breakdown table showing progression of principal & accrued interest
 */
export function generateCompoundAccrualSchedule(
  params: CompoundInterestParams & { startDate?: string }
): CompoundAccrualPeriodRow[] {
  const {
    principal,
    annualRatePct,
    tenorValue,
    tenorUnit = "months",
    compoundingFrequency = "monthly",
    startDate = new Date().toISOString().split("T")[0]
  } = params;

  const p = Math.max(0, principal);
  const r = Math.max(0, annualRatePct) / 100;
  const t = Math.max(0, tenorToYears(tenorValue, tenorUnit));

  if (p === 0 || t === 0) return [];

  const m = compoundingFrequency === "continuous" ? 365 : getPeriodsPerYear(compoundingFrequency);
  const numberOfPeriods = Math.max(1, Math.round(m * t));
  const periodicRate = compoundingFrequency === "continuous"
    ? Math.exp(r / 365) - 1
    : r / m;

  const rows: CompoundAccrualPeriodRow[] = [];
  let currentBalance = p;
  let cumulativeInterest = 0;

  for (let i = 1; i <= numberOfPeriods; i++) {
    const openingBalance = Number(currentBalance.toFixed(2));
    const interestAccrued = Number((openingBalance * periodicRate).toFixed(2));
    const closingBalance = Number((openingBalance + interestAccrued).toFixed(2));
    cumulativeInterest = Number((cumulativeInterest + interestAccrued).toFixed(2));

    const periodDate = addPeriodToDate(startDate, compoundingFrequency, i);

    rows.push({
      period: i,
      periodLabel: `${periodDate} (Period ${i})`,
      openingBalance,
      interestAccrued,
      closingBalance,
      cumulativeInterest
    });

    currentBalance = closingBalance;
  }

  return rows;
}

/**
 * Calculates compound interest between two specific calendar dates
 */
export function calculateCompoundInterestBetweenDates(
  principal: number,
  annualRatePct: number,
  startDate: Date | string,
  endDate: Date | string,
  compoundingFrequency: CompoundingFrequency = "daily",
  convention: DayCountConvention = "actual_365"
): { days: number; interestAccrued: number; futureValue: number } {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const diffMs = end.getTime() - start.getTime();
  const days = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));

  if (days === 0 || principal <= 0 || annualRatePct <= 0) {
    return { days, interestAccrued: 0, futureValue: principal };
  }

  const r = annualRatePct / 100;
  const dayFactor = getDayCountFactor(days, convention);

  let futureValue: number;
  if (compoundingFrequency === "continuous") {
    futureValue = principal * Math.exp(r * dayFactor);
  } else if (compoundingFrequency === "daily") {
    const dailyRate = r / (convention === "30_360" || convention === "actual_360" ? 360 : 365);
    futureValue = principal * Math.pow(1 + dailyRate, days);
  } else {
    const m = getPeriodsPerYear(compoundingFrequency);
    const periods = days / (365 / m);
    futureValue = principal * Math.pow(1 + r / m, periods);
  }

  const interestAccrued = Number(Math.max(0, futureValue - principal).toFixed(2));
  return {
    days,
    interestAccrued,
    futureValue: Number(futureValue.toFixed(2))
  };
}

// ============================================================================
// 2. REDUCING-BALANCE AMORTIZATION ENGINE
// ============================================================================

/**
 * Calculates Equated Monthly Installment (EMI) / Periodic Annuity Payment
 * PMT = P * [r(1+r)^n] / [(1+r)^n - 1]
 * Where:
 *   P = Principal
 *   r = Periodic interest rate (annualRate / periodsPerYear)
 *   n = Total number of repayment periods
 */
export function calculateEMI(
  principal: number,
  annualRatePct: number,
  numberOfPeriods: number,
  periodsPerYear: number = 12
): number {
  if (principal <= 0 || numberOfPeriods <= 0) return 0;
  if (annualRatePct <= 0) {
    return Number((principal / numberOfPeriods).toFixed(2));
  }

  const r = (annualRatePct / 100) / periodsPerYear;
  const factor = Math.pow(1 + r, numberOfPeriods);

  if (factor === 1 || !isFinite(factor)) {
    return Number((principal / numberOfPeriods).toFixed(2));
  }

  const emi = (principal * (r * factor)) / (factor - 1);
  return Number(emi.toFixed(2));
}

/**
 * Calculates reducing-balance interest and generates a full banking amortization schedule
 * Supports:
 * - Equal Installments (EMI Annuity)
 * - Equal Principal (Linear Amortization)
 * - Grace Period Handling (Interest-Only, Moratorium Capitalized, Moratorium Deferred)
 */
export function calculateReducingBalanceInterest(
  params: ReducingBalanceParams
): ReducingBalanceScheduleResult {
  const {
    principal,
    annualRatePct,
    tenorValue,
    tenorUnit = "months",
    repaymentFrequency = "monthly",
    method = "equal_installments",
    gracePeriodValue = 0,
    gracePeriodUnit = "months",
    gracePeriodType = "interest_only",
    originationFeeTotal = 0,
    startDate = new Date().toISOString().split("T")[0]
  } = params;

  const p = Math.max(0, principal);
  const periodsPerYear = getPeriodsPerYear(repaymentFrequency);
  const periodicRate = (Math.max(0, annualRatePct) / 100) / periodsPerYear;

  // Total periods
  const tenorInMonths = tenorToMonths(tenorValue, tenorUnit);
  let totalInstallments: number;

  if (repaymentFrequency === "weekly") {
    totalInstallments = Math.max(1, Math.round(tenorInMonths * 4.3333));
  } else if (repaymentFrequency === "bi_weekly") {
    totalInstallments = Math.max(1, Math.round(tenorInMonths * 2.1667));
  } else if (repaymentFrequency === "quarterly") {
    totalInstallments = Math.max(1, Math.round(tenorInMonths / 3));
  } else if (repaymentFrequency === "harvest_bullet") {
    totalInstallments = 1;
  } else {
    totalInstallments = Math.max(1, Math.round(tenorInMonths));
  }

  // Grace periods in terms of payment installments
  let gracePeriodsCount = 0;
  if (gracePeriodValue > 0) {
    const graceMonths = gracePeriodUnit === "days" ? gracePeriodValue / 30 : gracePeriodUnit === "weeks" ? gracePeriodValue / 4.3333 : gracePeriodValue;
    if (repaymentFrequency === "weekly") {
      gracePeriodsCount = Math.round(graceMonths * 4.3333);
    } else if (repaymentFrequency === "bi_weekly") {
      gracePeriodsCount = Math.round(graceMonths * 2.1667);
    } else if (repaymentFrequency === "quarterly") {
      gracePeriodsCount = Math.round(graceMonths / 3);
    } else {
      gracePeriodsCount = Math.round(graceMonths);
    }
    gracePeriodsCount = Math.min(gracePeriodsCount, Math.max(0, totalInstallments - 1));
  }

  const activeAmortizationPeriods = Math.max(1, totalInstallments - gracePeriodsCount);
  const schedule: AmortizationScheduleRow[] = [];

  let currentPrincipal = p;
  let cumulativePrincipal = 0;
  let cumulativeInterest = 0;
  const feePerPeriod = totalInstallments > 0 ? Number((originationFeeTotal / totalInstallments).toFixed(2)) : 0;

  // 1. Handle Grace Period Installments
  for (let g = 1; g <= gracePeriodsCount; g++) {
    const dueDate = addPeriodToDate(startDate, repaymentFrequency, g);
    const openingPrincipal = Number(currentPrincipal.toFixed(2));
    const interestDue = Number((openingPrincipal * periodicRate).toFixed(2));

    let installmentAmount = 0;
    let principalPaid = 0;
    let interestPaid = 0;
    let closingPrincipal = openingPrincipal;

    if (gracePeriodType === "interest_only") {
      // Borrower pays accrued interest each period; principal balance does not change
      installmentAmount = interestDue + feePerPeriod;
      interestPaid = interestDue;
      cumulativeInterest += interestPaid;
    } else if (gracePeriodType === "moratorium_capitalized") {
      // Interest is capitalized (added to principal balance)
      installmentAmount = feePerPeriod;
      closingPrincipal = Number((openingPrincipal + interestDue).toFixed(2));
      cumulativeInterest += interestDue;
      currentPrincipal = closingPrincipal;
    } else {
      // Moratorium deferred
      installmentAmount = feePerPeriod;
      cumulativeInterest += interestDue;
    }

    schedule.push({
      period: g,
      dueDate,
      openingPrincipal,
      installmentAmount: Number(installmentAmount.toFixed(2)),
      principalPortion: principalPaid,
      interestPortion: interestPaid,
      feesPortion: feePerPeriod,
      closingPrincipal: Number(closingPrincipal.toFixed(2)),
      cumulativePrincipal,
      cumulativeInterest: Number(cumulativeInterest.toFixed(2)),
      isGracePeriod: true
    });
  }

  // 2. Amortization Phase after Grace Period
  const principalToAmortize = currentPrincipal;

  if (method === "equal_installments") {
    // Standard EMI Annuity amortization
    const emi = calculateEMI(principalToAmortize, annualRatePct, activeAmortizationPeriods, periodsPerYear);

    for (let i = 1; i <= activeAmortizationPeriods; i++) {
      const periodNumber = gracePeriodsCount + i;
      const dueDate = addPeriodToDate(startDate, repaymentFrequency, periodNumber);
      const openingPrincipal = Number(currentPrincipal.toFixed(2));
      const interestDue = Number((openingPrincipal * periodicRate).toFixed(2));

      let principalDue = Number((emi - interestDue).toFixed(2));

      // Adjustment on last installment to reconcile cent roundings
      const isLast = i === activeAmortizationPeriods;
      if (isLast || principalDue > openingPrincipal) {
        principalDue = openingPrincipal;
      }

      const totalInstallment = Number((principalDue + interestDue + feePerPeriod).toFixed(2));
      const closingPrincipal = Math.max(0, Number((openingPrincipal - principalDue).toFixed(2)));

      cumulativePrincipal = Number((cumulativePrincipal + principalDue).toFixed(2));
      cumulativeInterest = Number((cumulativeInterest + interestDue).toFixed(2));
      currentPrincipal = closingPrincipal;

      schedule.push({
        period: periodNumber,
        dueDate,
        openingPrincipal,
        installmentAmount: totalInstallment,
        principalPortion: principalDue,
        interestPortion: interestDue,
        feesPortion: feePerPeriod,
        closingPrincipal,
        cumulativePrincipal,
        cumulativeInterest,
        isGracePeriod: false
      });
    }
  } else {
    // Equal Principal (Linear Amortization)
    const fixedPrincipalPerPeriod = Number((principalToAmortize / activeAmortizationPeriods).toFixed(2));

    for (let i = 1; i <= activeAmortizationPeriods; i++) {
      const periodNumber = gracePeriodsCount + i;
      const dueDate = addPeriodToDate(startDate, repaymentFrequency, periodNumber);
      const openingPrincipal = Number(currentPrincipal.toFixed(2));
      const interestDue = Number((openingPrincipal * periodicRate).toFixed(2));

      const isLast = i === activeAmortizationPeriods;
      const principalDue = isLast
        ? openingPrincipal
        : Math.min(openingPrincipal, fixedPrincipalPerPeriod);

      const totalInstallment = Number((principalDue + interestDue + feePerPeriod).toFixed(2));
      const closingPrincipal = Math.max(0, Number((openingPrincipal - principalDue).toFixed(2)));

      cumulativePrincipal = Number((cumulativePrincipal + principalDue).toFixed(2));
      cumulativeInterest = Number((cumulativeInterest + interestDue).toFixed(2));
      currentPrincipal = closingPrincipal;

      schedule.push({
        period: periodNumber,
        dueDate,
        openingPrincipal,
        installmentAmount: totalInstallment,
        principalPortion: principalDue,
        interestPortion: interestDue,
        feesPortion: feePerPeriod,
        closingPrincipal,
        cumulativePrincipal,
        cumulativeInterest,
        isGracePeriod: false
      });
    }
  }

  const totalPrincipal = Number(p.toFixed(2));
  const totalInterest = Number(cumulativeInterest.toFixed(2));
  const totalFees = Number(originationFeeTotal.toFixed(2));
  const totalRepayable = Number((totalPrincipal + totalInterest + totalFees).toFixed(2));

  // Determine initial regular installment
  const firstAmortizationRow = schedule.find(s => !s.isGracePeriod) || schedule[0];
  const initialInstallment = firstAmortizationRow ? firstAmortizationRow.installmentAmount : 0;

  const summary: InterestCalculationSummary = {
    principal: totalPrincipal,
    annualRatePct,
    totalInterest,
    totalRepayable,
    effectiveAnnualRatePct: calculateEffectiveAnnualRate(annualRatePct, "monthly"),
    nominalAnnualRatePct: annualRatePct,
    periodicRatePct: Number((periodicRate * 100).toFixed(4)),
    numberOfPeriods: totalInstallments,
    installmentAmount: initialInstallment,
    method: "reducing_balance"
  };

  return {
    summary,
    schedule,
    totalPrincipal,
    totalInterest,
    totalFees,
    totalRepayable
  };
}

// ============================================================================
// 3. DAILY ACCRUAL & ACCOUNTING LEDGER ENGINE
// ============================================================================

/**
 * Calculates daily interest accrual for accounting ledgers and daily batch runs
 */
export function calculateDailyAccrual(params: DailyAccrualParams): number {
  const {
    principal,
    annualRatePct,
    days,
    convention = "actual_365",
    isCompound = false,
    compoundingFrequency = "daily"
  } = params;

  if (principal <= 0 || annualRatePct <= 0 || days <= 0) return 0;

  const r = annualRatePct / 100;
  const daysInYear = convention === "30_360" || convention === "actual_360" ? 360 : 365;

  if (!isCompound) {
    // Simple daily accrual: P * r * (days / daysInYear)
    const accrual = principal * r * (days / daysInYear);
    return Number(accrual.toFixed(2));
  }

  // Compound daily accrual: P * [(1 + r/m)^(m * days/365) - 1]
  const m = getPeriodsPerYear(compoundingFrequency);
  const factor = Math.pow(1 + r / m, m * (days / 365));
  const compoundAccrual = principal * (factor - 1);
  return Number(compoundAccrual.toFixed(2));
}

// ============================================================================
// 4. COMPARATIVE SCENARIO MODELING
// ============================================================================

/**
 * Compares Flat Rate, Reducing Balance (Equal Installments), and Compound Interest
 * for the same loan principal, interest rate, and duration.
 * Useful for farmer transparent disclosure, credit scoring, and product design.
 */
export function compareLoanInterestModels(params: {
  principal: number;
  annualRatePct: number;
  tenorMonths: number;
  compoundingFrequency?: CompoundingFrequency;
}): MethodComparisonResult {
  const {
    principal,
    annualRatePct,
    tenorMonths,
    compoundingFrequency = "monthly"
  } = params;

  const p = Math.max(0, principal);
  const r = Math.max(0, annualRatePct) / 100;
  const n = Math.max(1, tenorMonths);

  // 1. Flat Rate
  const flatInterest = Number((p * r * (n / 12)).toFixed(2));
  const flatTotal = Number((p + flatInterest).toFixed(2));
  const flatMonthly = Number((flatTotal / n).toFixed(2));

  // 2. Reducing Balance (Equal Installments / EMI)
  const reducing = calculateReducingBalanceInterest({
    principal: p,
    annualRatePct,
    tenorValue: n,
    tenorUnit: "months",
    repaymentFrequency: "monthly",
    method: "equal_installments"
  });

  // 3. Compound Interest (Bullet compound over term)
  const compound = calculateCompoundInterest({
    principal: p,
    annualRatePct,
    tenorValue: n,
    tenorUnit: "months",
    compoundingFrequency
  });

  const savingsWithReducingVsFlat = Number(Math.max(0, flatInterest - reducing.totalInterest).toFixed(2));
  const savingsWithReducingVsCompound = Number(Math.max(0, compound.totalInterest - reducing.totalInterest).toFixed(2));

  return {
    principal: p,
    annualRatePct,
    tenorMonths: n,
    flat: {
      totalInterest: flatInterest,
      totalRepayable: flatTotal,
      monthlyInstallment: flatMonthly
    },
    reducingBalance: {
      totalInterest: reducing.totalInterest,
      totalRepayable: reducing.totalRepayable,
      monthlyInstallment: reducing.summary.installmentAmount || 0,
      method: "equal_installments"
    },
    compound: {
      totalInterest: compound.totalInterest,
      totalRepayable: compound.totalRepayable,
      compoundingFrequency
    },
    savingsWithReducingVsFlat,
    savingsWithReducingVsCompound
  };
}

// ============================================================================
// 5. INTEREST SERVICE CLASS
// ============================================================================

export class InterestService {
  /**
   * Calculates compound interest and future values
   */
  public calculateCompound(params: CompoundInterestParams): InterestCalculationSummary {
    return calculateCompoundInterest(params);
  }

  /**
   * Generates compound accrual schedules
   */
  public getCompoundSchedule(
    params: CompoundInterestParams & { startDate?: string }
  ): CompoundAccrualPeriodRow[] {
    return generateCompoundAccrualSchedule(params);
  }

  /**
   * Calculates compound interest between two dates
   */
  public calculateCompoundBetweenDates(
    principal: number,
    annualRatePct: number,
    startDate: Date | string,
    endDate: Date | string,
    compoundingFrequency: CompoundingFrequency = "daily",
    convention: DayCountConvention = "actual_365"
  ): { days: number; interestAccrued: number; futureValue: number } {
    return calculateCompoundInterestBetweenDates(
      principal,
      annualRatePct,
      startDate,
      endDate,
      compoundingFrequency,
      convention
    );
  }

  /**
   * Calculates reducing-balance interest with full amortization schedule
   */
  public calculateReducingBalance(
    params: ReducingBalanceParams
  ): ReducingBalanceScheduleResult {
    return calculateReducingBalanceInterest(params);
  }

  /**
   * Calculates monthly or periodic EMI
   */
  public calculateEMI(
    principal: number,
    annualRatePct: number,
    numberOfPeriods: number,
    periodsPerYear: number = 12
  ): number {
    return calculateEMI(principal, annualRatePct, numberOfPeriods, periodsPerYear);
  }

  /**
   * Calculates daily accrual for ledger entries
   */
  public calculateDailyAccrual(params: DailyAccrualParams): number {
    return calculateDailyAccrual(params);
  }

  /**
   * Comparative analysis between flat, reducing balance, and compound
   */
  public compareModels(params: {
    principal: number;
    annualRatePct: number;
    tenorMonths: number;
    compoundingFrequency?: CompoundingFrequency;
  }): MethodComparisonResult {
    return compareLoanInterestModels(params);
  }

  /**
   * Converts nominal interest rate to effective annual rate (EAR)
   */
  public getEffectiveRate(
    nominalRatePct: number,
    frequency: CompoundingFrequency = "monthly"
  ): number {
    return calculateEffectiveAnnualRate(nominalRatePct, frequency);
  }
}

export const interestService = new InterestService();
export default interestService;

/**
 * Mabala.cloud - Loan Management Domain Module
 * 
 * Standardized module root exporting all submodules:
 * - services: DDACService, InterestService
 * - hooks: useLoans, useDDAC
 * - types: Loan domain models, repayment schedules, accounting events
 * - constants: Accounting event templates, statuses, chart of accounts
 * - validators: Loan application and mandate validation logic
 * - engine: Loan accounting and amortization calculators
 */

export * from "./types";
export * from "./constants";
export * from "./validators";
export * from "./services";
export * from "./hooks";
export * from "./engine/loanAccounting";
export * from "./engine/loanCalculations";

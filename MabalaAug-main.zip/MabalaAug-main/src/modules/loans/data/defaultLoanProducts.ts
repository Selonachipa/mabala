/**
 * Mabala.cloud - Pre-configured Loan Products Catalog
 * Clean baseline: Zero pre-posted loan or credit products.
 * Products are created and published directly by accredited agro-dealers and suppliers.
 */

import { LoanProduct } from "../types";

export const DEFAULT_LOAN_PRODUCTS: LoanProduct[] = [];


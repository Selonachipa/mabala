/**
 * Mabala.cloud - Loan Management Module Domain Types
 * Unified Agricultural Crop Financing & Agribusiness Enterprise Lending Architecture
 */

export type FinancingModel = "agricultural_crop" | "agribusiness_enterprise";
export type ProductType = "input_credit" | "facility";
export type IssuerType = "agro_dealer" | "supplier" | "institution";

export type TargetSector = 
  | "crop" 
  | "livestock" 
  | "poultry" 
  | "aquaculture" 
  | "agro_dealer" 
  | "equipment" 
  | "working_capital" 
  | "general";

export type InterestCalculationMethod = "flat" | "reducing_balance" | "compound" | "bullet_end_term";

export type RepaymentFrequency = 
  | "weekly" 
  | "bi_weekly" 
  | "monthly" 
  | "quarterly" 
  | "harvest_bullet" 
  | "seasonal_custom";

export type TenorUnit = "days" | "weeks" | "months" | "seasons";

export type DisbursementMethod = 
  | "mobile_money" 
  | "mabala_wallet" 
  | "input_voucher" 
  | "bank_transfer";

export type LoanApplicationStatus = 
  | "draft" 
  | "submitted" 
  | "under_review" 
  | "approved" 
  | "disbursed" 
  | "rejected" 
  | "cancelled";

export type LoanStatus = 
  | "active" 
  | "in_arrears" 
  | "paid_off" 
  | "written_off" 
  | "restructured" 
  | "defaulted";

export type AgingBucket = 
  | "current" 
  | "par_1_30" 
  | "par_31_60" 
  | "par_61_90" 
  | "par_90_plus" 
  | "default";

export type TransactionType = 
  | "disbursement" 
  | "repayment" 
  | "interest_accrual" 
  | "fee_charge" 
  | "penalty_charge" 
  | "waiver" 
  | "write_off" 
  | "reversal";

export type RepaymentSource = 
  | "lipila_mobile_money" 
  | "mabala_ledger" 
  | "ddacc_auto_clearing" 
  | "offtaker_deduction" 
  | "cash_bank" 
  | "manual_admin";

export interface InputBasketItem {
  skuId?: string;
  itemName: string;
  category: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  total: number;
}

export interface LoanProduct {
  id: string;
  tenantId: string; // Issuer / Lender tenant (e.g. Agro Dealer, Supplier, Institution, Platform)
  issuerName: string;
  issuerType?: IssuerType;
  productType?: ProductType; // "input_credit" (in-kind voucher/seed/fert) vs "facility" (traditional cash/working capital/equipment)
  name: string;
  code: string;
  description: string;
  financingModel: FinancingModel;
  targetSector: TargetSector;
  currency: string;
  minPrincipal: number;
  maxPrincipal: number;
  defaultPrincipal: number;
  interestRatePct: number; // Annual or Per-Season
  interestCalculationMethod: InterestCalculationMethod;
  repaymentFrequency: RepaymentFrequency;
  defaultTenorValue: number;
  minTenorValue?: number;
  maxTenorValue?: number;
  tenorUnit: TenorUnit;
  gracePeriodValue: number; // e.g. 0 or 3 months
  gracePeriodUnit: "days" | "months";
  originationFeePct: number; // e.g. 2%
  originationFeeFixed: number; // e.g. ZMW 50
  originationFeeDeduction: "deduct_from_disbursement" | "capitalize" | "upfront_cash";
  latePenaltyRatePct: number; // e.g. 5% per month on overdue principal
  lateGraceDays: number; // days before penalty activates
  disbursementMethodsAllowed: DisbursementMethod[];
  collateralRequired: boolean;
  requiresCropCycleLink: boolean;
  status: "active" | "archived" | "draft";
  createdAt: string;
  updatedAt: string;
}

export interface LoanApplication {
  id: string;
  applicationNumber: string;
  tenantId: string; // Borrower tenant ID (farmer or agribusiness)
  lenderTenantId: string; // Lender / Supplier / Institution tenant ID
  lenderName?: string;
  issuerType?: IssuerType;
  productType?: ProductType;
  borrowerId: string;
  borrowerName: string;
  borrowerPhone: string;
  borrowerNrc: string;
  borrowerEmail?: string;
  borrowerFarmName?: string;
  borrowerProvince?: string;
  borrowerDistrict?: string;
  productId: string;
  productName: string;
  financingModel: FinancingModel;
  requestedAmount: number;
  requestedTenorValue: number;
  requestedTenorUnit: TenorUnit;
  purpose: string;
  financingPurpose?: string;
  // Agricultural specific linkage
  cropCycleId?: string;
  cropCycleName?: string;
  cropExpectedHarvestDate?: string;
  inputBasket?: InputBasketItem[];
  // Repayment preview summary
  repaymentSummary?: {
    principal: number;
    interestRatePct: number;
    interestCalculationMethod: string;
    totalInterest: number;
    originationFee: number;
    totalRepayment: number;
    monthlyInstallment: number;
    frequency: string;
  };
  // Collateral & Security
  collateralDescription?: string;
  collateralEstimatedValue?: number;
  // Disbursement preference
  disbursementMethod: DisbursementMethod;
  disbursementAccount: string; // Phone number or Bank account
  disbursementNetwork?: "airtel" | "mtn" | "zamtel" | "bank";
  // Decision details
  status: LoanApplicationStatus;
  reviewedBy?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  approvedAmount?: number;
  approvedInterestRatePct?: number;
  approvedTenorValue?: number;
  loanId?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface RepaymentScheduleItem {
  installmentNumber: number;
  dueDate: string;
  principalDue: number;
  interestDue: number;
  feesDue: number;
  totalDue: number;
  principalPaid: number;
  interestPaid: number;
  feesPaid: number;
  totalPaid: number;
  balanceRemaining: number;
  status: "pending" | "partially_paid" | "paid" | "overdue";
  paidAt?: string;
}

export interface Loan {
  id: string;
  loanNumber: string; // e.g. LN-2026-0001
  tenantId: string; // Borrower farm tenant
  lenderTenantId: string; // Lender / Supplier / Institution tenant
  borrowerId: string;
  borrowerName: string;
  borrowerPhone: string;
  borrowerNrc: string;
  borrowerFarmName?: string;
  lenderName: string;
  productId: string;
  productName: string;
  financingModel: FinancingModel;
  currency: string;
  
  // Principal Accounting
  principalDisbursed: number;
  totalPrincipalRepaid: number;
  principalOutstanding: number;

  // Interest Accounting
  interestRatePct: number;
  interestCalculationMethod: InterestCalculationMethod;
  totalInterestAccrued: number;
  totalInterestRepaid: number;
  interestOutstanding: number;

  // Fees & Penalties Accounting
  totalFeesCharged: number;
  totalFeesRepaid: number;
  feesOutstanding: number;
  totalPenaltiesCharged: number;
  totalPenaltiesRepaid: number;
  penaltiesOutstanding: number;

  // Aggregated Totals
  totalLoanAmount: number; // Principal + Expected Interest + Fees
  totalRepaid: number;
  totalOutstandingBalance: number;

  // Tenor & Repayment Timeline
  repaymentFrequency: RepaymentFrequency;
  tenorValue: number;
  tenorUnit: TenorUnit;
  disbursementDate: string;
  maturityDate: string;
  firstRepaymentDate: string;
  nextRepaymentDueDate: string;
  nextRepaymentDueAmount: number;

  // Aging & Risk
  daysPastDue: number;
  daysInArrears?: number;
  agingBucket: AgingBucket;
  status: LoanStatus;

  // Convenience Aliases
  installmentAmount?: number;
  borrowerTenantId?: string;

  // Linkages & Execution details
  cropCycleId?: string;
  cropCycleName?: string;
  inputBasket?: InputBasketItem[];
  ddaccMandateId?: string;
  disbursementReference: string;
  disbursementMethod: DisbursementMethod;
  disbursementAccount: string;

  schedule: RepaymentScheduleItem[];
  createdAt: string;
  updatedAt: string;
}

export interface LoanTransaction {
  id: string;
  loanId: string;
  tenantId: string; // Borrower tenant ID
  lenderTenantId: string; // Lender tenant ID
  type: TransactionType;
  amount: number;
  principalPortion: number;
  interestPortion: number;
  feePortion: number;
  penaltyPortion: number;
  source: RepaymentSource;
  referenceId: string; // e.g. Lipila txn, voucher code, DDACC clearing ref
  journalEntryId?: string; // Double-entry mapping
  balanceBefore: number;
  balanceAfter: number;
  notes: string;
  performedBy: string;
  timestamp: string;
  immutableHash: string; // SHA-256 integrity hash
  previousTxHash?: string;
}

export interface PortfolioMetrics {
  totalLoansCount: number;
  activeLoansCount: number;
  inArrearsCount: number;
  paidOffCount: number;
  defaultCount: number;
  totalPrincipalDisbursed: number;
  totalPrincipalRecovered: number;
  totalInterestAccrued: number;
  totalInterestRecovered: number;
  totalOutstandingPrincipal: number;
  totalOutstandingInterest: number;
  totalArrearsAmount: number;
  collectionEfficiencyPct: number;
  par30Amount: number;
  par30Pct: number;
  par60Amount: number;
  par60Pct: number;
  par90Amount: number;
  par90Pct: number;
  byFinancingModel: {
    crop: { count: number; exposure: number; repaid: number };
    enterprise: { count: number; exposure: number; repaid: number };
  };
  bySector: Record<string, { count: number; exposure: number }>;
}

export interface LoanWriteOffRecord {
  id: string;
  loanId: string;
  loanNumber: string;
  tenantId: string;
  lenderTenantId: string;
  borrowerName: string;
  writeOffAmount: number;
  principalWrittenOff: number;
  interestWrittenOff: number;
  reason: string;
  approvedBy: string;
  approvedAt: string;
  journalEntryId?: string;
}

export interface RepaymentAllocation {
  paymentAmount: number;
  penaltyPaid: number;
  feesPaid: number;
  interestPaid: number;
  principalPaid: number;
  excessPaid: number;
  remainingPenalties: number;
  remainingFees: number;
  remainingInterest: number;
  remainingPrincipal: number;
  remainingTotal: number;
  isFullyPaid: boolean;
}

/**
 * Mabala.cloud - Loan Management Hooks
 */

import { useState, useEffect, useCallback } from "react";
import { Loan, LoanProduct, LoanApplication } from "../types";
import { fetchLoans, fetchLoanProducts, fetchLoanApplications } from "../../../services/loanService";

export function useLoans(tenantId: string = "TENANT-001") {
  const [loans, setLoans] = useState<Loan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refreshLoans = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchLoans({ tenantId });
      setLoans(data || []);
    } catch (err: any) {
      setError(err?.message || "Failed to load loans.");
    } finally {
      setLoading(false);
    }
  }, [tenantId]);

  useEffect(() => {
    refreshLoans();
  }, [refreshLoans]);

  return { loans, loading, error, refreshLoans };
}

export function useLoanProducts() {
  const [products, setProducts] = useState<LoanProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refreshProducts = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchLoanProducts();
      setProducts(data || []);
    } catch (err: any) {
      setError(err?.message || "Failed to load loan products.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshProducts();
  }, [refreshProducts]);

  return { products, loading, error, refreshProducts };
}

export function useLoanApplications(tenantId: string = "TENANT-001") {
  const [applications, setApplications] = useState<LoanApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refreshApplications = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchLoanApplications({ tenantId });
      setApplications(data || []);
    } catch (err: any) {
      setError(err?.message || "Failed to load loan applications.");
    } finally {
      setLoading(false);
    }
  }, [tenantId]);

  useEffect(() => {
    refreshApplications();
  }, [refreshApplications]);

  return { applications, loading, error, refreshApplications };
}

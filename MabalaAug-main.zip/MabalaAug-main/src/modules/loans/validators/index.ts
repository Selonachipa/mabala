/**
 * Mabala.cloud - Loan Management Domain Validators
 * Validates loan applications, DDAC mandates, products, and repayments.
 */

import { Loan, LoanApplication, LoanProduct, RepaymentScheduleItem } from "../types";

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

/**
 * Validates a loan application against product rules and agricultural criteria
 */
export function validateLoanApplication(
  application: Partial<LoanApplication>,
  product: LoanProduct
): ValidationResult {
  const errors: string[] = [];

  if (!application.borrowerId || application.borrowerId.trim() === "") {
    errors.push("Borrower identifier is required.");
  }

  if (!application.requestedAmount || application.requestedAmount <= 0) {
    errors.push("Requested amount must be greater than zero.");
  } else {
    if (application.requestedAmount < product.minPrincipal) {
      errors.push(`Requested amount must be at least K${product.minPrincipal.toLocaleString()}.`);
    }
    if (application.requestedAmount > product.maxPrincipal) {
      errors.push(`Requested amount cannot exceed K${product.maxPrincipal.toLocaleString()}.`);
    }
  }

  if (!application.requestedTenorValue || application.requestedTenorValue <= 0) {
    errors.push("Loan tenor duration must be greater than zero.");
  } else {
    if (product.minTenorValue !== undefined && application.requestedTenorValue < product.minTenorValue) {
      errors.push(`Tenor must be at least ${product.minTenorValue} ${product.tenorUnit}.`);
    }
    if (product.maxTenorValue !== undefined && application.requestedTenorValue > product.maxTenorValue) {
      errors.push(`Tenor cannot exceed ${product.maxTenorValue} ${product.tenorUnit}.`);
    }
  }

  if (product.requiresCropCycleLink && !application.cropCycleId) {
    errors.push("This financing facility requires linking an active registered crop cycle.");
  }

  const purpose = application.purpose || application.financingPurpose;
  if (!purpose || purpose.trim().length < 3) {
    errors.push("A valid business or agricultural financing purpose is required.");
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

/**
 * Validates a Direct Debit Against Crop Sales (DDAC) mandate
 */
export function validateDDACMandate(mandate: {
  id?: string;
  loanId?: string;
  farmerTenantId?: string;
  status?: string;
  farmerApprovalStatus?: string;
  autoDeductEnabled?: boolean;
  nextDeductionDate?: string;
  repaymentInstallmentAmount?: number;
}): ValidationResult {
  const errors: string[] = [];

  if (!mandate.loanId) {
    errors.push("Mandate must be bound to a valid loan ID.");
  }

  if (!mandate.farmerTenantId) {
    errors.push("Mandate must specify the borrower farm tenant ID.");
  }

  if (mandate.status !== "active") {
    errors.push(`Mandate is not active (current status: ${mandate.status || "unknown"}).`);
  }

  if (mandate.farmerApprovalStatus !== "approved") {
    errors.push("Farmer mandate approval acknowledgement is required before automated collection.");
  }

  if (mandate.autoDeductEnabled !== true) {
    errors.push("Direct debit auto-deduction is disabled on this mandate.");
  }

  if (!mandate.repaymentInstallmentAmount || mandate.repaymentInstallmentAmount <= 0) {
    errors.push("Installment deduction amount must be greater than zero.");
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

/**
 * Validates a proposed loan repayment transaction
 */
export function validateRepayment(
  loan: Loan,
  amount: number,
  source: string
): ValidationResult {
  const errors: string[] = [];

  if (loan.status === "paid_off" || loan.status === "written_off") {
    errors.push(`Loan cannot accept repayments because status is ${loan.status}.`);
  }

  if (amount <= 0) {
    errors.push("Repayment amount must be greater than zero.");
  }

  if (!source || source.trim() === "") {
    errors.push("A valid repayment payment method or source is required.");
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

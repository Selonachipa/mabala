import { db } from "../firebase";
import { safeLocalStorage as localStorage } from "../utils/safeStorage";
import { collection, addDoc, updateDoc, doc, setDoc } from "firebase/firestore";

export interface PendingOperation {
  operationId: string;
  tenantId: string;
  module: string;
  action: "Create" | "Update" | "Delete" | "Upload";
  payload: any;
  timestamp: string;
  syncStatus: "Pending" | "Synchronizing" | "Failed";
  retryCount: number;
}

export interface AuditLogEntry {
  id?: string;
  eventType: string; // "Offline Creation", "Offline Update", "Offline Deletion", "Sync Completed", "Sync Failed"
  timestamp: string;
  userId: string;
  tenantId: string;
  module: string;
  action: string;
  syncStatus: string;
}

export const ALL_OFFLINE_STORES = [
  "pending_operations",
  "livestock",
  "poultry",
  "crops",
  "expenses",
  "finance",
  "inventory",
  "sales",
  "cash_sales",
  "invoices",
  "credit_notes",
  "quotations",
  "employees",
  "payslips",
  "veterinary",
  "wallet",
  "user_settings",
  "user_profiles",
  "offtakers",
  "delivery_notes",
  "audit_logs",
  "offtaker_products",
  "farmer_offtaker_links",
  "adjustment_notes",
  "offtaker_wallets",
  "wallet_transactions",
  "payouts",
  "fee_configs",
  "farmers",
  "registered_farmers",
  "kobo_submissions_queue",
  "all_farm_nodes_registry",
  "assets",
  "fish",
  "orchard_nursery_batches",
  "orchard_trees",
  "orchard_activities",
  "loans",
  "investments",
  "other_revenues",
  "leave_records",
  "employee_advances",
  "team_members",
  "suppliers",
  "customers",
  "archived_records",
  "tasks",
  "field_mappings",
  "water_irrigation",
  "inspections",
  "compliance",
  "loss_records"
];

const BASE_DB_NAME = "mabala_offline_db";
const DB_VERSION = 4;

let activeScopeKey = "guest";
const openDbInstances: Map<string, IDBDatabase> = new Map();

/**
 * Configure active user/tenant session scope for IndexedDB isolation.
 * Guarantees distinct local databases for different authenticated users on the same device.
 */
export function setOfflineDbScope(scope: { uid?: string | null; tenantId?: string | null } | null | string): void {
  if (!scope) {
    activeScopeKey = "guest";
  } else if (typeof scope === "string") {
    const clean = scope.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
    activeScopeKey = clean || "guest";
  } else {
    const raw = [scope.uid, scope.tenantId, (scope as any).sessionEpoch]
      .filter(Boolean)
      .join("__")
      .trim()
      .toLowerCase();
    const clean = raw.replace(/[^a-z0-9_-]/g, "_");
    activeScopeKey = clean || "guest";
  }
}

export function getOfflineDbScope(): string {
  return activeScopeKey;
}

export function getOfflineDbName(scope?: string): string {
  const s = scope || activeScopeKey;
  if (!s || s === "guest" || s === "unauthenticated") {
    return `${BASE_DB_NAME}_guest`;
  }
  return `${BASE_DB_NAME}_${s}`;
}

function ensureObjectStores(db: IDBDatabase): void {
  ALL_OFFLINE_STORES.forEach(store => {
    if (!db.objectStoreNames.contains(store)) {
      if (store === "pending_operations") {
        db.createObjectStore(store, { keyPath: "operationId" });
      } else {
        db.createObjectStore(store, { keyPath: "id" });
      }
    }
  });
}

export function initOfflineDb(customDbName?: string, requiredVersion?: number): Promise<IDBDatabase> {
  const dbName = customDbName || getOfflineDbName();

  return new Promise((resolve, reject) => {
    if (typeof window === "undefined") {
      reject(new Error("IndexedDB is not supported in this environment"));
      return;
    }

    let idb: IDBFactory | undefined;
    try {
      idb = window.indexedDB;
    } catch (e) {
      console.warn("[Mabala Sandbox] Access to window.indexedDB property was denied:", e);
    }

    if (!idb) {
      reject(new Error("IndexedDB is not supported or accessible in this environment"));
      return;
    }

    // Reuse existing healthy connection if available and open
    const cached = openDbInstances.get(dbName);
    if (cached && !requiredVersion) {
      try {
        // Simple transaction probe to ensure DB is not closed
        const tx = cached.transaction(cached.objectStoreNames[0] || "pending_operations", "readonly");
        if (tx) {
          resolve(cached);
          return;
        }
      } catch (_) {
        openDbInstances.delete(dbName);
      }
    }

    try {
      const version = requiredVersion || DB_VERSION;
      const request = idb.open(dbName, version);

      request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
        const db = (event.target as IDBOpenDBRequest).result;
        ensureObjectStores(db);
      };

      request.onsuccess = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        openDbInstances.set(dbName, db);
        db.onversionchange = () => {
          db.close();
          openDbInstances.delete(dbName);
        };
        resolve(db);
      };

      request.onerror = (event) => {
        reject((event.target as IDBOpenDBRequest).error);
      };
    } catch (openError) {
      console.warn("[Mabala Sandbox] Failed to execute 'open' on IDBFactory:", openError);
      reject(new Error("IndexedDB open was blocked or failed"));
    }
  });
}

/**
 * Self-healing helper: if an object store is missing in an existing client database,
 * increments the version and upgrades the schema idempotently.
 */
async function healMissingStoreAndReopen(dbName: string, missingStoreName: string): Promise<IDBDatabase> {
  console.warn(`[Offline DB] Self-healing missing store "${missingStoreName}" for ${dbName}...`);
  const currentDb = await initOfflineDb(dbName);
  const currentVersion = currentDb.version || DB_VERSION;
  currentDb.close();
  openDbInstances.delete(dbName);

  const nextVersion = currentVersion + 1;
  const upgradedDb = await new Promise<IDBDatabase>((resolve, reject) => {
    try {
      const req = window.indexedDB.open(dbName, nextVersion);
      req.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        ensureObjectStores(db);
        if (!db.objectStoreNames.contains(missingStoreName)) {
          db.createObjectStore(missingStoreName, {
            keyPath: missingStoreName === "pending_operations" ? "operationId" : "id"
          });
        }
      };
      req.onsuccess = () => {
        const db = req.result;
        openDbInstances.set(dbName, db);
        resolve(db);
      };
      req.onerror = () => reject(req.error);
    } catch (e) {
      reject(e);
    }
  });

  console.info(`[Offline DB] Self-healing complete: store "${missingStoreName}" created in ${dbName} at version ${nextVersion}`);
  return upgradedDb;
}

// Subscription Validation Helper
export function getTenantSubscriptionStatus(tenantId: string): {
  status: "active" | "expired" | "suspended" | "grace_period";
  graceUntil?: string;
} {
  const cached = localStorage.getItem(`sub_status_${tenantId}`);
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      // Let's check dates to enforce grace period or expiration
      const now = new Date();
      const expiry = new Date(parsed.expiryDate || now);
      
      if (parsed.subscriptionStatus === "active" && parsed.accountStatus === "active") {
        return { status: "active" };
      }
      
      // If expired but within 7 days grace period
      const daysSinceExpiry = (now.getTime() - expiry.getTime()) / (1000 * 3600 * 24);
      if (daysSinceExpiry <= 7 && daysSinceExpiry > 0 && parsed.accountStatus === "active") {
        const graceDate = new Date(expiry.getTime() + 7 * 24 * 60 * 60 * 1000);
        return { status: "grace_period", graceUntil: graceDate.toISOString() };
      }
      
      return { status: "expired" };
    } catch (e) {
      return { status: "expired" };
    }
  }
  // Default fallback if offline and no cached details: allow grace check representation
  return { status: "active" }; // Standard offline fallback assuming active initially
}

// Primary DB helpers
let useMemoryDb = false;
const memoryDb: Record<string, Record<string, any>> = {};

export async function saveToOfflineStore(storeName: string, data: any): Promise<void> {
  const dbName = getOfflineDbName();

  if (useMemoryDb) {
    if (!memoryDb[storeName]) memoryDb[storeName] = {};
    const key = storeName === "pending_operations" ? data.operationId : (data.id || String(Date.now()));
    memoryDb[storeName][key] = data;
    return;
  }

  let dbInst: IDBDatabase;
  try {
    dbInst = await initOfflineDb(dbName);
  } catch (initErr) {
    console.warn(`[Offline DB] DB open failed for ${dbName}, storing in fallback memory:`, initErr);
    useMemoryDb = true;
    if (!memoryDb[storeName]) memoryDb[storeName] = {};
    const key = storeName === "pending_operations" ? data.operationId : (data.id || String(Date.now()));
    memoryDb[storeName][key] = data;
    return;
  }

  // Self-heal upfront if store is not in current DB
  if (!dbInst.objectStoreNames.contains(storeName)) {
    try {
      dbInst = await healMissingStoreAndReopen(dbName, storeName);
    } catch (healErr) {
      console.warn(`[Offline DB] Upfront self-healing failed for ${storeName}:`, healErr);
    }
  }

  try {
    return await new Promise<void>((resolve, reject) => {
      try {
        const tx = dbInst.transaction(storeName, "readwrite");
        const store = tx.objectStore(storeName);
        const request = store.put(data);

        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
        tx.onerror = () => reject(tx.error);
      } catch (txErr) {
        reject(txErr);
      }
    });
  } catch (err: any) {
    const isNotFoundError = err?.name === "NotFoundError" || 
      (err?.message && (err.message.includes("not found") || err.message.includes("object stores was not found")));
    
    if (isNotFoundError) {
      console.warn(`[Offline DB] NotFoundError caught for store "${storeName}". Running self-healing migration...`);
      try {
        const healedDb = await healMissingStoreAndReopen(dbName, storeName);
        return await new Promise<void>((resolve, reject) => {
          try {
            const tx = healedDb.transaction(storeName, "readwrite");
            const store = tx.objectStore(storeName);
            const request = store.put(data);

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
            tx.onerror = () => reject(tx.error);
          } catch (retryErr) {
            reject(retryErr);
          }
        });
      } catch (retryErr: any) {
        console.error(`[Offline DB] Self-healing write retry failed for ${storeName}:`, retryErr);
        throw retryErr;
      }
    }

    console.error(`[Offline DB] saveToOfflineStore write failed for ${storeName}:`, err);
    throw err;
  }
}

export async function getFromOfflineStore(storeName: string, id: string): Promise<any> {
  const dbName = getOfflineDbName();
  if (useMemoryDb) {
    return memoryDb[storeName]?.[id] || null;
  }
  try {
    const dbInst = await initOfflineDb(dbName);
    if (!dbInst.objectStoreNames.contains(storeName)) {
      return null;
    }
    return new Promise((resolve, reject) => {
      const tx = dbInst.transaction(storeName, "readonly");
      const store = tx.objectStore(storeName);
      const request = store.get(id);

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  } catch (e) {
    console.warn(`[Offline DB] getFromOfflineStore failed for ${storeName}:`, e);
    return memoryDb[storeName]?.[id] || null;
  }
}

export async function getAllFromOfflineStore(storeName: string): Promise<any[]> {
  const dbName = getOfflineDbName();
  if (useMemoryDb) {
    return Object.values(memoryDb[storeName] || {});
  }
  try {
    const dbInst = await initOfflineDb(dbName);
    if (!dbInst.objectStoreNames.contains(storeName)) {
      return [];
    }
    return new Promise((resolve, reject) => {
      const tx = dbInst.transaction(storeName, "readonly");
      const store = tx.objectStore(storeName);
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  } catch (e) {
    console.warn(`[Offline DB] getAllFromOfflineStore failed for ${storeName}:`, e);
    return Object.values(memoryDb[storeName] || {});
  }
}

export async function deleteFromOfflineStore(storeName: string, id: string): Promise<void> {
  const dbName = getOfflineDbName();
  if (useMemoryDb) {
    if (memoryDb[storeName]) {
      delete memoryDb[storeName][id];
    }
    return;
  }
  try {
    const dbInst = await initOfflineDb(dbName);
    if (!dbInst.objectStoreNames.contains(storeName)) {
      return;
    }
    return new Promise((resolve, reject) => {
      const tx = dbInst.transaction(storeName, "readwrite");
      const store = tx.objectStore(storeName);
      const request = store.delete(id);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (e) {
    console.warn(`[Offline DB] deleteFromOfflineStore failed for ${storeName}:`, e);
    if (memoryDb[storeName]) {
      delete memoryDb[storeName][id];
    }
  }
}

/**
 * Fully purge an offline database by name or scope.
 * Closes connections and removes the entire IndexedDB database.
 */
export async function purgeOfflineDatabase(scope?: string): Promise<void> {
  const dbName = getOfflineDbName(scope);
  const cached = openDbInstances.get(dbName);
  if (cached) {
    try { cached.close(); } catch (_) {}
    openDbInstances.delete(dbName);
  }

  if (typeof window !== "undefined" && window.indexedDB) {
    await new Promise<void>((resolve) => {
      try {
        const req = window.indexedDB.deleteDatabase(dbName);
        req.onsuccess = () => resolve();
        req.onerror = () => resolve();
        req.onblocked = () => resolve();
      } catch (_) {
        resolve();
      }
    });
  }

  for (const key of Object.keys(memoryDb)) {
    delete memoryDb[key];
  }
}

/**
 * Purge ALL offline databases across all sessions (for logout/security resets).
 */
export async function purgeAllOfflineDatabases(): Promise<void> {
  openDbInstances.forEach((db) => {
    try { db.close(); } catch (_) {}
  });
  openDbInstances.clear();

  if (typeof window !== "undefined" && window.indexedDB) {
    const dbsToDelete = [
      BASE_DB_NAME,
      `${BASE_DB_NAME}_guest`
    ];

    if (activeScopeKey && activeScopeKey !== "guest") {
      dbsToDelete.push(`${BASE_DB_NAME}_${activeScopeKey}`);
    }

    if (window.indexedDB.databases) {
      try {
        const dbs = await window.indexedDB.databases();
        for (const d of dbs) {
          if (d.name && d.name.startsWith(BASE_DB_NAME)) {
            dbsToDelete.push(d.name);
          }
        }
      } catch (_) {}
    }

    const uniqueDbs = Array.from(new Set(dbsToDelete));
    for (const name of uniqueDbs) {
      await new Promise<void>((resolve) => {
        try {
          const req = window.indexedDB.deleteDatabase(name);
          req.onsuccess = () => resolve();
          req.onerror = () => resolve();
          req.onblocked = () => resolve();
        } catch (_) {
          resolve();
        }
      });
    }
  }

  for (const key of Object.keys(memoryDb)) {
    delete memoryDb[key];
  }
  useMemoryDb = false;
  activeScopeKey = "guest";
}

// Sync queue helpers
export async function queuePendingOperation(op: PendingOperation): Promise<void> {
  await saveToOfflineStore("pending_operations", op);
  // Log Audit trail
  await logOfflineAudit({
    eventType: `Offline ${op.action}`,
    timestamp: new Date().toISOString(),
    userId: op.tenantId, // map to tenant for consistency
    tenantId: op.tenantId,
    module: op.module,
    action: op.action,
    syncStatus: "Pending"
  });
}

export async function logOfflineAudit(entry: AuditLogEntry): Promise<void> {
  const id = `audit-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const fullEntry = { ...entry, id };
  await saveToOfflineStore("audit_logs", fullEntry);
}

// UUID helper
export function generateLocalId(prefix: string): string {
  const year = new Date().getFullYear();
  const uuid = Math.random().toString(36).substring(2, 6).toUpperCase() + "-" + Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${year}-${uuid}`;
}

export type ReportCategory = 'inventory' | 'sales' | 'supplier' | 'financial' | 'hsw';
export type ChartType = 'pie' | 'bar' | 'line' | 'stackedBar' | 'none';

export interface ReportColumn {
  key: string;
  label: string;
  type: 'string' | 'number' | 'currency' | 'date' | 'percent';
  align?: 'left' | 'center' | 'right';
}

export interface ReportDefinition {
  id: string;
  category: ReportCategory;
  title: string;
  description: string;
  sourceCollections: string[];
  requiresCapability?: 'institution_financier';
  groupByDimension?: string;
  chartTypes: ChartType[];
  supportsPeriodComparison: boolean;
  supportsAsOfDate?: boolean;
  columns: ReportColumn[];
}

export const AGRO_DEALER_REPORT_CATALOG: ReportDefinition[] = [
  // 1. Inventory Reports
  {
    id: 'stock-on-hand-by-supplier',
    category: 'inventory',
    title: '1. Stock on Hand by Supplier & SKU',
    description: 'Current stock quantities, unit valuation, and reorder status grouped by supplier.',
    sourceCollections: ['agroInventory', 'stockMovements'],
    groupByDimension: 'supplierName',
    chartTypes: ['pie', 'bar'],
    supportsPeriodComparison: false,
    supportsAsOfDate: true,
    columns: [
      { key: 'supplierName', label: 'Supplier Name', type: 'string', align: 'left' },
      { key: 'skuName', label: 'SKU Name', type: 'string', align: 'left' },
      { key: 'category', label: 'Category', type: 'string', align: 'left' },
      { key: 'qtyOnHand', label: 'Qty on Hand', type: 'number', align: 'right' },
      { key: 'unitCost', label: 'Unit Cost', type: 'currency', align: 'right' },
      { key: 'stockValue', label: 'Total Valuation', type: 'currency', align: 'right' },
      { key: 'reorderStatus', label: 'Reorder Status', type: 'string', align: 'center' }
    ]
  },
  {
    id: 'stock-movement-ledger',
    category: 'inventory',
    title: '2. Stock Movement Ledger',
    description: 'Audit log of all inward grants, sales deductions, damages, and manual adjustments.',
    sourceCollections: ['stockMovements'],
    chartTypes: ['line', 'bar'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'date', label: 'Movement Date', type: 'date', align: 'left' },
      { key: 'movementType', label: 'Type', type: 'string', align: 'center' },
      { key: 'skuName', label: 'SKU Item', type: 'string', align: 'left' },
      { key: 'supplierName', label: 'Supplier', type: 'string', align: 'left' },
      { key: 'qty', label: 'Quantity', type: 'number', align: 'right' },
      { key: 'unitCost', label: 'Unit Cost', type: 'currency', align: 'right' },
      { key: 'totalValue', label: 'Total Value', type: 'currency', align: 'right' },
      { key: 'reference', label: 'Ref / Note', type: 'string', align: 'left' }
    ]
  },
  {
    id: 'stock-received-grn-log',
    category: 'inventory',
    title: '3. Stock Received from Suppliers (GRN Log)',
    description: 'Goods Received Note log tracking supplier deliveries and consignment allocations.',
    sourceCollections: ['stockMovements', 'stockGrants'],
    groupByDimension: 'supplierName',
    chartTypes: ['pie', 'bar'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'date', label: 'GRN Date', type: 'date', align: 'left' },
      { key: 'supplierName', label: 'Supplier', type: 'string', align: 'left' },
      { key: 'skuName', label: 'Consigned SKU', type: 'string', align: 'left' },
      { key: 'category', label: 'Category', type: 'string', align: 'left' },
      { key: 'qtyReceived', label: 'Qty Received', type: 'number', align: 'right' },
      { key: 'unitCost', label: 'Unit Cost', type: 'currency', align: 'right' },
      { key: 'receivedValue', label: 'Received Value', type: 'currency', align: 'right' },
      { key: 'agreementRef', label: 'Agreement Ref', type: 'string', align: 'left' }
    ]
  },
  {
    id: 'fast-slow-movers',
    category: 'inventory',
    title: '4. Fast / Slow Movers',
    description: 'Sell-through rates, stock turn velocity, and dead stock identification.',
    sourceCollections: ['stockMovements', 'salesRecords', 'agroInventory'],
    chartTypes: ['bar'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'skuName', label: 'SKU Name', type: 'string', align: 'left' },
      { key: 'category', label: 'Category', type: 'string', align: 'left' },
      { key: 'qtySold', label: 'Qty Sold', type: 'number', align: 'right' },
      { key: 'openingAndReceived', label: 'Available Inventory', type: 'number', align: 'right' },
      { key: 'sellThroughRate', label: 'Sell-Through Rate', type: 'percent', align: 'right' },
      { key: 'daysOnHand', label: 'Est Days on Hand', type: 'number', align: 'right' },
      { key: 'velocity', label: 'Velocity Class', type: 'string', align: 'center' }
    ]
  },

  // 2. Sales Reports
  {
    id: 'sales-by-sku-category',
    category: 'sales',
    title: '5. Sales Report by SKU / Category',
    description: 'Itemized sales breakdown by product line and input category.',
    sourceCollections: ['salesRecords'],
    groupByDimension: 'category',
    chartTypes: ['pie', 'line', 'bar'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'date', label: 'Sale Date', type: 'date', align: 'left' },
      { key: 'skuName', label: 'SKU Product', type: 'string', align: 'left' },
      { key: 'category', label: 'Category', type: 'string', align: 'left' },
      { key: 'qtySold', label: 'Qty Sold', type: 'number', align: 'right' },
      { key: 'unitPrice', label: 'Selling Price', type: 'currency', align: 'right' },
      { key: 'revenue', label: 'Total Revenue', type: 'currency', align: 'right' },
      { key: 'paymentMethod', label: 'Channel', type: 'string', align: 'center' }
    ]
  },
  {
    id: 'sales-by-payment-method',
    category: 'sales',
    title: '6. Sales by Payment Method',
    description: 'Revenue distribution across Lipila MoMo, POS cash counter, bank transfers, and credit.',
    sourceCollections: ['salesRecords'],
    groupByDimension: 'paymentMethod',
    chartTypes: ['pie', 'bar'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'paymentMethod', label: 'Payment Method', type: 'string', align: 'left' },
      { key: 'transactionCount', label: 'Transactions', type: 'number', align: 'right' },
      { key: 'totalRevenue', label: 'Total Volume', type: 'currency', align: 'right' },
      { key: 'sharePct', label: 'Share of Total', type: 'percent', align: 'right' }
    ]
  },

  // 3. Supplier Obligations Reports
  {
    id: 'repayments-to-suppliers',
    category: 'supplier',
    title: '7. Repayments to Suppliers (Consignment Payable Statement)',
    description: 'Consignment sales payables, supplier settlements made, and outstanding balances.',
    sourceCollections: ['reconciliationRun', 'consignmentAgreements'],
    groupByDimension: 'supplierName',
    chartTypes: ['pie', 'bar'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'reconDate', label: 'Settlement Date', type: 'date', align: 'left' },
      { key: 'supplierName', label: 'Supplier Name', type: 'string', align: 'left' },
      { key: 'reconRef', label: 'Settlement Ref', type: 'string', align: 'left' },
      { key: 'totalOwed', label: 'Gross Owed', type: 'currency', align: 'right' },
      { key: 'amountPaid', label: 'Amount Settled', type: 'currency', align: 'right' },
      { key: 'outstandingBalance', label: 'Balance Due', type: 'currency', align: 'right' },
      { key: 'paymentChannel', label: 'Payout Channel', type: 'string', align: 'center' },
      { key: 'status', label: 'Status', type: 'string', align: 'center' }
    ]
  },
  {
    id: 'supplier-performance-summary',
    category: 'supplier',
    title: '8. Supplier Performance Summary',
    description: 'Supplier turnover velocity, dealer margins earned, and average settlement days.',
    sourceCollections: ['stockMovements', 'reconciliationRun', 'consignmentAgreements'],
    chartTypes: ['bar'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'supplierName', label: 'Supplier Name', type: 'string', align: 'left' },
      { key: 'receivedValue', label: 'Received Stock', type: 'currency', align: 'right' },
      { key: 'soldValue', label: 'Sold Stock', type: 'currency', align: 'right' },
      { key: 'marginEarned', label: 'Dealer Margin (4%)', type: 'currency', align: 'right' },
      { key: 'avgDaysToRepay', label: 'Avg Days to Repay', type: 'number', align: 'right' },
      { key: 'performanceScore', label: 'Performance Rating', type: 'string', align: 'center' }
    ]
  },

  // 4. Financial & Profitability Reports
  {
    id: 'revenue-report',
    category: 'financial',
    title: '9. Revenue Report',
    description: 'Gross turnover, tax component, and revenue stream distribution over time.',
    sourceCollections: ['financialLedger', 'salesRecords'],
    groupByDimension: 'category',
    chartTypes: ['pie', 'line', 'bar'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'period', label: 'Period / Category', type: 'string', align: 'left' },
      { key: 'category', label: 'Revenue Stream', type: 'string', align: 'left' },
      { key: 'transactionCount', label: 'Tx Count', type: 'number', align: 'right' },
      { key: 'totalRevenue', label: 'Total Revenue', type: 'currency', align: 'right' },
      { key: 'sharePct', label: 'Share (%)', type: 'percent', align: 'right' },
      { key: 'priorPeriodDelta', label: 'Period Change', type: 'percent', align: 'right' }
    ]
  },
  {
    id: 'profit-per-product',
    category: 'financial',
    title: '10. Profit per Product / Category',
    description: 'Gross margin, unit COGS vs selling price, and net profitability per input product.',
    sourceCollections: ['salesRecords', 'agroInventory', 'stockGrants'],
    groupByDimension: 'category',
    chartTypes: ['bar', 'pie'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'skuName', label: 'Product / SKU', type: 'string', align: 'left' },
      { key: 'category', label: 'Category', type: 'string', align: 'left' },
      { key: 'qtySold', label: 'Qty Sold', type: 'number', align: 'right' },
      { key: 'revenue', label: 'Gross Revenue', type: 'currency', align: 'right' },
      { key: 'cogs', label: 'COGS (Cost)', type: 'currency', align: 'right' },
      { key: 'grossProfit', label: 'Gross Profit', type: 'currency', align: 'right' },
      { key: 'marginPct', label: 'Profit Margin', type: 'percent', align: 'right' }
    ]
  },
  {
    id: 'revenue-vs-expense-comparison',
    category: 'financial',
    title: '11. Revenue vs. Expense Comparison',
    description: 'High-level variance comparing total revenue against COGS, fees, and overheads.',
    sourceCollections: ['financialLedger', 'salesRecords', 'expenses'],
    groupByDimension: 'type',
    chartTypes: ['stackedBar', 'pie'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'period', label: 'Period', type: 'string', align: 'left' },
      { key: 'revenue', label: 'Gross Revenue', type: 'currency', align: 'right' },
      { key: 'cogs', label: 'Cost of Goods (COGS)', type: 'currency', align: 'right' },
      { key: 'platformFees', label: 'Platform & Processing Fees', type: 'currency', align: 'right' },
      { key: 'supplierPayouts', label: 'Supplier Payouts', type: 'currency', align: 'right' },
      { key: 'netPosition', label: 'Net Position', type: 'currency', align: 'right' },
      { key: 'priorPeriodDelta', label: 'Growth vs Prior', type: 'percent', align: 'right' }
    ]
  },
  {
    id: 'dealer-pl-statement',
    category: 'financial',
    title: '12. Dealer Profit & Loss Statement',
    description: 'Formal income statement with Revenue, COGS, 4% Dealer Commission, Overheads, and Net Profit.',
    sourceCollections: ['financialLedger', 'salesRecords', 'expenses', 'reconciliationRun'],
    chartTypes: ['none'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'lineItem', label: 'Line Item Account', type: 'string', align: 'left' },
      { key: 'code', label: 'COA Code', type: 'string', align: 'center' },
      { key: 'revenue', label: 'Revenue / Credit', type: 'currency', align: 'right' },
      { key: 'expense', label: 'Expense / Debit', type: 'currency', align: 'right' },
      { key: 'net', label: 'Net Period Total', type: 'currency', align: 'right' }
    ]
  },
  {
    id: 'farmer-credit-portfolio-snapshot',
    category: 'financial',
    title: '13. Farmer Credit Portfolio Snapshot',
    description: 'Loan balances, repayments, portfolio yield, and risk status for lending-enabled institutions.',
    sourceCollections: ['loanPortfolio'],
    requiresCapability: 'institution_financier',
    groupByDimension: 'status',
    chartTypes: ['pie', 'bar'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'loanId', label: 'Loan / Farmer Ref', type: 'string', align: 'left' },
      { key: 'farmerName', label: 'Farmer Name', type: 'string', align: 'left' },
      { key: 'principal', label: 'Principal Issued', type: 'currency', align: 'right' },
      { key: 'repaid', label: 'Total Repaid', type: 'currency', align: 'right' },
      { key: 'balance', label: 'Outstanding Balance', type: 'currency', align: 'right' },
      { key: 'status', label: 'Portfolio Status', type: 'string', align: 'center' },
      { key: 'riskRating', label: 'Risk Rating', type: 'string', align: 'center' }
    ]
  },

  // 5. Harvest & Storage Warehouse (HSW) Reports
  {
    id: 'hsw-harvest-performance',
    category: 'hsw',
    title: '14. Harvest Performance Report',
    description: 'Tracks total harvested quantities, bag counts, moisture content, and crop cycle origin.',
    sourceCollections: ['harvestEvents', 'cropCycles'],
    groupByDimension: 'cropType',
    chartTypes: ['bar', 'pie'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'harvestDate', label: 'Harvest Date', type: 'date', align: 'left' },
      { key: 'cropType', label: 'Crop / Variety', type: 'string', align: 'left' },
      { key: 'fieldBlock', label: 'Field Block', type: 'string', align: 'left' },
      { key: 'quantityRaw', label: 'Harvested Qty', type: 'number', align: 'right' },
      { key: 'unitRaw', label: 'Unit', type: 'string', align: 'center' },
      { key: 'bagCount', label: 'Bags (50kg)', type: 'number', align: 'right' },
      { key: 'moistureContent', label: 'Moisture (%)', type: 'percent', align: 'right' },
      { key: 'loggedBy', label: 'Recorded By', type: 'string', align: 'left' }
    ]
  },
  {
    id: 'hsw-storage-asset',
    category: 'hsw',
    title: '15. Storage Asset Valuation Report',
    description: 'Audit of active storage lots, current stock levels, unit valuation, and current stored value.',
    sourceCollections: ['storageLots', 'warehouses'],
    groupByDimension: 'warehouseName',
    chartTypes: ['pie', 'bar'],
    supportsPeriodComparison: false,
    supportsAsOfDate: true,
    columns: [
      { key: 'lotId', label: 'Storage Lot ID', type: 'string', align: 'left' },
      { key: 'warehouseName', label: 'Warehouse / Facility', type: 'string', align: 'left' },
      { key: 'cropType', label: 'Commodity & Variety', type: 'string', align: 'left' },
      { key: 'grade', label: 'Quality Grade', type: 'string', align: 'center' },
      { key: 'quantityCurrent', label: 'Current Qty', type: 'number', align: 'right' },
      { key: 'unit', label: 'Unit', type: 'string', align: 'center' },
      { key: 'valuationPricePerUnit', label: 'Valuation / Unit', type: 'currency', align: 'right' },
      { key: 'storedValueCurrent', label: 'Total Value', type: 'currency', align: 'right' },
      { key: 'status', label: 'Lot Status', type: 'string', align: 'center' }
    ]
  },
  {
    id: 'hsw-storage-loss',
    category: 'hsw',
    title: '16. Storage Loss & Spoilage Audit Report',
    description: 'Comprehensive log of post-harvest losses categorized by pest, mold, theft, or quality downgrade with financial impact.',
    sourceCollections: ['storageLosses', 'storageLots'],
    groupByDimension: 'causeCategory',
    chartTypes: ['pie', 'bar'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'date', label: 'Loss Date', type: 'date', align: 'left' },
      { key: 'lotId', label: 'Lot ID', type: 'string', align: 'left' },
      { key: 'causeCategory', label: 'Cause Category', type: 'string', align: 'left' },
      { key: 'quantityLost', label: 'Qty Lost', type: 'number', align: 'right' },
      { key: 'unit', label: 'Unit', type: 'string', align: 'center' },
      { key: 'valueImpact', label: 'Value Impact', type: 'currency', align: 'right' },
      { key: 'loggedBy', label: 'Audited By', type: 'string', align: 'left' },
      { key: 'notes', label: 'Notes & Photos', type: 'string', align: 'left' }
    ]
  },
  {
    id: 'hsw-dwr-collateral',
    category: 'hsw',
    title: '17. Digital Warehouse Receipts & Collateral Report',
    description: 'Registry of active electronic warehouse receipts (DWR), negotiable certificates, and loan collateral soft-pledges.',
    sourceCollections: ['warehouseReceipts', 'storageLots'],
    groupByDimension: 'status',
    chartTypes: ['pie', 'bar'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'receiptNumber', label: 'DWR Receipt #', type: 'string', align: 'left' },
      { key: 'issuedDate', label: 'Issue Date', type: 'date', align: 'left' },
      { key: 'cropType', label: 'Commodity & Grade', type: 'string', align: 'left' },
      { key: 'quantity', label: 'Quantity', type: 'number', align: 'right' },
      { key: 'totalValueAtIssue', label: 'Certified Value', type: 'currency', align: 'right' },
      { key: 'negotiable', label: 'Negotiability', type: 'string', align: 'center' },
      { key: 'qrVerificationCode', label: 'Verification Code', type: 'string', align: 'left' },
      { key: 'status', label: 'Status', type: 'string', align: 'center' }
    ]
  },
  {
    id: 'hsw-realized-vs-projected',
    category: 'hsw',
    title: '18. Realized vs Projected Yield & Revenue Analysis',
    description: 'Variance analysis comparing projected crop yields against actual harvested volumes and post-harvest losses.',
    sourceCollections: ['harvestVariances', 'cropCycles'],
    groupByDimension: 'cropType',
    chartTypes: ['bar', 'line'],
    supportsPeriodComparison: true,
    columns: [
      { key: 'cropCycleId', label: 'Crop Cycle Ref', type: 'string', align: 'left' },
      { key: 'cropType', label: 'Crop Type', type: 'string', align: 'left' },
      { key: 'projectedYield', label: 'Projected Yield', type: 'number', align: 'right' },
      { key: 'actualHarvestQty', label: 'Actual Harvest', type: 'number', align: 'right' },
      { key: 'postHarvestLossQty', label: 'Storage Loss', type: 'number', align: 'right' },
      { key: 'netSalableQty', label: 'Net Salable Qty', type: 'number', align: 'right' },
      { key: 'variancePct', label: 'Yield Variance (%)', type: 'percent', align: 'right' },
      { key: 'aiSummary', label: 'Mabala AI Driver Analysis', type: 'string', align: 'left' }
    ]
  }
];

export function getReportDefinition(reportId: string): ReportDefinition | undefined {
  return AGRO_DEALER_REPORT_CATALOG.find(r => r.id === reportId);
}

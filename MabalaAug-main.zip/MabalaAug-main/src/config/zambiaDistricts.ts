import defaultDistrictsJson from "../data/zambiaDistricts.json";

export type ZambiaProvincesMap = Record<string, string[]>;

export const DEFAULT_ZAMBIA_DISTRICTS: ZambiaProvincesMap = defaultDistrictsJson;

export const ZAMBIA_PROVINCES_ALPHABETICAL: string[] = Object.keys(DEFAULT_ZAMBIA_DISTRICTS).sort((a, b) =>
  a.localeCompare(b)
);

// High-precision geographic reference coordinates for each Zambian Province & major District centres
export const DISTRICT_COORDINATES: Record<string, { lat: number; lng: number }> = {
  // Central Province
  "Central": { lat: -14.4426, lng: 28.4475 },
  "Kabwe": { lat: -14.4426, lng: 28.4475 },
  "Chibombo": { lat: -14.6569, lng: 28.0706 },
  "Chisamba": { lat: -14.9747, lng: 28.3283 },
  "Chitambo": { lat: -12.9167, lng: 30.6333 },
  "Kapiri Mposhi": { lat: -13.9716, lng: 28.6699 },
  "Luano": { lat: -14.3333, lng: 29.5000 },
  "Mkushi": { lat: -13.6202, lng: 29.3939 },
  "Mumbwa": { lat: -14.9783, lng: 27.0619 },
  "Ngabwe": { lat: -14.0500, lng: 27.8500 },
  "Serenje": { lat: -13.2325, lng: 30.2352 },
  "Shibuyunji": { lat: -15.2333, lng: 27.8833 },

  // Copperbelt Province
  "Copperbelt": { lat: -12.9906, lng: 28.6498 },
  "Ndola": { lat: -12.9906, lng: 28.6498 },
  "Kitwe": { lat: -12.8024, lng: 28.2132 },
  "Chingola": { lat: -12.5290, lng: 27.8546 },
  "Chililabombwe": { lat: -12.3644, lng: 27.8229 },
  "Mufulira": { lat: -12.5498, lng: 28.2407 },
  "Luanshya": { lat: -13.1367, lng: 28.4166 },
  "Kalulushi": { lat: -12.8392, lng: 28.0944 },
  "Masaiti": { lat: -13.1833, lng: 28.0000 },
  "Lufwanyama": { lat: -12.8667, lng: 27.5667 },
  "Mpongwe": { lat: -13.5333, lng: 28.1500 },

  // Eastern Province
  "Eastern": { lat: -13.6333, lng: 32.6500 },
  "Chipata": { lat: -13.6333, lng: 32.6500 },
  "Chadiza": { lat: -14.0667, lng: 32.4333 },
  "Chama": { lat: -11.2131, lng: 33.1522 },
  "Chasefu": { lat: -11.7500, lng: 33.2500 },
  "Chipangali": { lat: -13.2500, lng: 32.5500 },
  "Kasenengwa": { lat: -13.4500, lng: 32.2500 },
  "Katete": { lat: -14.0567, lng: 32.0442 },
  "Lumezi": { lat: -12.0500, lng: 33.0000 },
  "Lundazi": { lat: -12.2929, lng: 33.1782 },
  "Lusangazi": { lat: -13.5000, lng: 31.4000 },
  "Mambwe": { lat: -13.3333, lng: 31.9167 },
  "Nyimba": { lat: -14.5566, lng: 30.8149 },
  "Petauke": { lat: -14.2426, lng: 31.3253 },
  "Sinda": { lat: -14.1667, lng: 31.9167 },
  "Vubwi": { lat: -14.1167, lng: 32.7500 },

  // Luapula Province
  "Luapula": { lat: -11.1998, lng: 28.8943 },
  "Mansa": { lat: -11.1998, lng: 28.8943 },
  "Chembe": { lat: -11.9667, lng: 28.7333 },
  "Chiengi": { lat: -8.6500, lng: 29.1667 },
  "Chifunabuli": { lat: -11.5000, lng: 29.8000 },
  "Chipili": { lat: -10.8500, lng: 29.1000 },
  "Kawambwa": { lat: -9.7915, lng: 29.0789 },
  "Lunga": { lat: -11.7500, lng: 29.9000 },
  "Milenge": { lat: -11.9167, lng: 29.2333 },
  "Mwansabombwe": { lat: -9.8167, lng: 28.7500 },
  "Mwense": { lat: -10.3844, lng: 28.6980 },
  "Nchelenge": { lat: -9.3451, lng: 28.7340 },
  "Samfya": { lat: -11.3649, lng: 29.5565 },

  // Lusaka Province
  "Lusaka": { lat: -15.4167, lng: 28.2833 },
  "Lusaka West": { lat: -15.4220, lng: 28.2000 },
  "Chilanga": { lat: -15.5667, lng: 28.2667 },
  "Chongwe": { lat: -15.3292, lng: 28.6820 },
  "Kafue": { lat: -15.7691, lng: 28.1814 },
  "Luangwa": { lat: -15.6167, lng: 30.4167 },
  "Rufunsa": { lat: -15.1167, lng: 29.4167 },

  // Muchinga Province
  "Muchinga": { lat: -11.8333, lng: 31.4500 },
  "Chinsali": { lat: -10.5414, lng: 32.0816 },
  "Isoka": { lat: -10.1606, lng: 32.6335 },
  "Kanchibiya": { lat: -11.9500, lng: 31.3500 },
  "Lavushimanda": { lat: -12.4500, lng: 30.8500 },
  "Mafinga": { lat: -9.9500, lng: 33.3500 },
  "Mpika": { lat: -11.8343, lng: 31.4529 },
  "Nakonde": { lat: -9.3242, lng: 32.7450 },
  "Shiwang'andu": { lat: -11.2000, lng: 31.7500 },

  // Northern Province
  "Northern": { lat: -10.2129, lng: 31.1808 },
  "Kasama": { lat: -10.2129, lng: 31.1808 },
  "Chilubi": { lat: -11.1500, lng: 30.2167 },
  "Kaputa": { lat: -8.4689, lng: 29.6619 },
  "Lunte": { lat: -9.8500, lng: 30.2800 },
  "Luwingu": { lat: -10.2621, lng: 29.9271 },
  "Mbala": { lat: -8.8402, lng: 31.3659 },
  "Mporokoso": { lat: -9.3725, lng: 30.1250 },
  "Mpulungu": { lat: -8.7623, lng: 31.1141 },
  "Mungwi": { lat: -10.1732, lng: 31.3694 },
  "Nsama": { lat: -8.9000, lng: 30.0167 },
  "Lupososhi": { lat: -10.0500, lng: 29.7500 },
  "Senga Hill": { lat: -9.3500, lng: 31.2500 },

  // North-Western Province
  "North-Western": { lat: -12.1688, lng: 26.3894 },
  "Solwezi": { lat: -12.1688, lng: 26.3894 },
  "Chavuma": { lat: -13.0889, lng: 22.6889 },
  "Ikelenge": { lat: -11.2333, lng: 24.2667 },
  "Kabompo": { lat: -13.5933, lng: 24.2008 },
  "Kalumbila": { lat: -12.2167, lng: 25.3000 },
  "Kasempa": { lat: -13.4584, lng: 25.8338 },
  "Manyinga": { lat: -13.4000, lng: 23.9500 },
  "Mufumbwe": { lat: -14.0167, lng: 24.8000 },
  "Mushindamo": { lat: -12.3500, lng: 27.0500 },
  "Mwinilunga": { lat: -11.7358, lng: 24.4293 },
  "Zambezi": { lat: -13.5432, lng: 23.1047 },

  // Southern Province
  "Southern": { lat: -16.8093, lng: 26.9880 },
  "Choma": { lat: -16.8093, lng: 26.9880 },
  "Chikankata": { lat: -15.9500, lng: 28.1667 },
  "Chirundu": { lat: -16.0333, lng: 28.8500 },
  "Gwembe": { lat: -16.4833, lng: 27.6000 },
  "Itezhi-Tezhi": { lat: -15.7500, lng: 26.0167 },
  "Kalomo": { lat: -17.0286, lng: 26.4889 },
  "Kazungula": { lat: -17.7889, lng: 25.2611 },
  "Livingstone": { lat: -17.8419, lng: 25.8543 },
  "Mazabuka": { lat: -15.8560, lng: 27.7480 },
  "Monze": { lat: -16.2833, lng: 27.4833 },
  "Namwala": { lat: -15.7500, lng: 26.4333 },
  "Pemba": { lat: -16.5333, lng: 27.3500 },
  "Siavonga": { lat: -16.5382, lng: 28.7088 },
  "Sinazongwe": { lat: -17.2614, lng: 27.4619 },
  "Zimba": { lat: -17.3167, lng: 26.2000 },

  // Western Province
  "Western": { lat: -15.2750, lng: 23.1294 },
  "Mongu": { lat: -15.2750, lng: 23.1294 },
  "Kalabo": { lat: -14.9917, lng: 22.6814 },
  "Kaoma": { lat: -14.7833, lng: 24.8000 },
  "Limulunga": { lat: -15.1167, lng: 23.1333 },
  "Luampa": { lat: -15.0167, lng: 24.4500 },
  "Lukulu": { lat: -14.3708, lng: 23.2417 },
  "Mitete": { lat: -14.1833, lng: 23.0167 },
  "Mulobezi": { lat: -16.7833, lng: 25.1667 },
  "Mwandi": { lat: -17.5333, lng: 24.7167 },
  "Nalolo": { lat: -15.8000, lng: 23.1167 },
  "Nkeyema": { lat: -14.8500, lng: 25.3000 },
  "Senanga": { lat: -16.1167, lng: 23.2667 },
  "Sesheke": { lat: -17.4750, lng: 24.2961 },
  "Shangombo": { lat: -16.3167, lng: 22.1000 },
  "Sikongo": { lat: -15.1500, lng: 22.2500 },
  "Sioma": { lat: -16.6500, lng: 23.5833 }
};

// In-memory or localStorage cache for Super Admin runtime overrides
const STORAGE_KEY = "mabala_zambia_districts_registry_v1";

/**
 * Retrieves the active Zambia Province to District map.
 * Checks local cache or falls back to static default dataset.
 */
export function getZambiaDistrictsRegistry(): ZambiaProvincesMap {
  try {
    const cached = localStorage.getItem(STORAGE_KEY);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (parsed && typeof parsed === "object" && Object.keys(parsed).length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn("Failed to load custom Zambia districts registry from storage:", e);
  }
  return DEFAULT_ZAMBIA_DISTRICTS;
}

/**
 * Returns all available province names sorted alphabetically.
 */
export function getProvincesList(): string[] {
  const registry = getZambiaDistrictsRegistry();
  return Object.keys(registry).sort((a, b) => a.localeCompare(b));
}

/**
 * Returns all districts belonging to a specified province name.
 * Handles both plain name (e.g. "Lusaka") and full name (e.g. "Lusaka Province").
 */
export function getDistrictsForProvince(provinceName: string): string[] {
  if (!provinceName) return [];
  const registry = getZambiaDistrictsRegistry();
  
  // Direct match
  if (registry[provinceName]) {
    return [...registry[provinceName]].sort((a, b) => a.localeCompare(b));
  }
  
  // Fuzzy match (strip " Province")
  const stripped = provinceName.replace(/\s*Province$/i, "").trim();
  for (const [pName, districts] of Object.entries(registry)) {
    if (pName.toLowerCase() === stripped.toLowerCase() || pName.toLowerCase() === provinceName.toLowerCase()) {
      return [...districts].sort((a, b) => a.localeCompare(b));
    }
  }
  
  return [];
}

/**
 * Validates if the given district exists in the given province.
 */
export function isValidProvinceDistrict(province: string, district: string): boolean {
  if (!province || !district) return false;
  const districts = getDistrictsForProvince(province);
  const targetLower = district.trim().toLowerCase();
  return districts.some(d => d.toLowerCase() === targetLower);
}

/**
 * Resolves approximate GPS coordinates for a province and district combination.
 */
export function resolveDistrictCoordinates(province: string, district?: string): { lat: number; lng: number; source: "province_town_signup" } {
  if (district && DISTRICT_COORDINATES[district]) {
    return { ...DISTRICT_COORDINATES[district], source: "province_town_signup" };
  }
  
  const strippedProv = province ? province.replace(/\s*Province$/i, "").trim() : "";
  if (strippedProv && DISTRICT_COORDINATES[strippedProv]) {
    return { ...DISTRICT_COORDINATES[strippedProv], source: "province_town_signup" };
  }
  
  // Default to Lusaka West central coordinates
  return { lat: -15.4220, lng: 28.2000, source: "province_town_signup" };
}

/**
 * Allows Super Admin to persist a revised Province & District Registry
 */
export function saveZambiaDistrictsRegistry(newRegistry: ZambiaProvincesMap): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newRegistry));
  } catch (e) {
    console.error("Failed to save Zambia districts registry to localStorage:", e);
  }
}

/**
 * Resets the registry back to national statutory gazetted boundaries (10 provinces, 116 districts)
 */
export function resetZambiaDistrictsRegistry(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {}
}

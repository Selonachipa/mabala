export type InstitutionReportCategory = 
  | 'me_impact' 
  | 'agronomy_yield' 
  | 'livestock_dairy' 
  | 'finance_credit' 
  | 'market_linkages' 
  | 'labor_social' 
  | 'weather_dwr' 
  | 'consignments' 
  | 'sms_outreach';

export type InstitutionChartType = 'bar' | 'line' | 'pie' | 'stackedBar' | 'area' | 'none';

export interface InstitutionReportColumn {
  key: string;
  label: string;
  type: 'string' | 'number' | 'currency' | 'date' | 'percent';
  align?: 'left' | 'center' | 'right';
  width?: string;
}

export interface InstitutionReportDefinition {
  id: string;
  category: InstitutionReportCategory;
  categoryLabel: string;
  title: string;
  subtitle: string;
  description: string;
  chartTypes: InstitutionChartType[];
  defaultChartType: InstitutionChartType;
  columns: InstitutionReportColumn[];
  kpiCards: {
    key: string;
    label: string;
    format: 'number' | 'currency' | 'percent' | 'string' | 'hectares' | 'liters' | 'kg';
    target?: number;
  }[];
  exportFilename: string;
}

export const INSTITUTION_REPORT_CATEGORIES: { id: 'all' | InstitutionReportCategory; label: string; iconName: string }[] = [
  { id: 'all', label: 'All Reports', iconName: 'Layers' },
  { id: 'me_impact', label: 'M&E & Impact', iconName: 'Activity' },
  { id: 'agronomy_yield', label: 'Agronomy & Yields', iconName: 'Sprout' },
  { id: 'livestock_dairy', label: 'Livestock & Dairy', iconName: 'Cow' },
  { id: 'finance_credit', label: 'Finance & Credit (PAR)', iconName: 'DollarSign' },
  { id: 'market_linkages', label: 'Market Linkages', iconName: 'Store' },
  { id: 'labor_social', label: 'Labor & Social Impact', iconName: 'Users' },
  { id: 'weather_dwr', label: 'DWR Weather Resilience', iconName: 'CloudRain' },
  { id: 'consignments', label: 'Agro-Dealer Consignments', iconName: 'ShieldCheck' },
  { id: 'sms_outreach', label: 'SMS & Outreach', iconName: 'MessageSquare' },
];

export const INSTITUTION_REPORT_CATALOG: InstitutionReportDefinition[] = [
  // 1. M&E & IMPACT
  {
    id: 'me-executive-impact-summary',
    category: 'me_impact',
    categoryLabel: 'M&E & Impact',
    title: '1. Executive M&E Portfolio & Impact Summary',
    subtitle: 'Comprehensive portfolio reach, land cultivated, output valuation, and demographic inclusion',
    description: 'High-level aggregation of all smallholders under institutional sponsorship, tracking geographic footprint, total hectares farmed, estimated harvest outputs, and inclusion benchmarks.',
    chartTypes: ['bar', 'pie'],
    defaultChartType: 'bar',
    kpiCards: [
      { key: 'totalFarmers', label: 'Total Smallholders', format: 'number' },
      { key: 'totalHectares', label: 'Total Hectares Farmed', format: 'hectares' },
      { key: 'totalGrossOutputZMW', label: 'Est. Gross Output Value', format: 'currency' },
      { key: 'femaleInclusionPct', label: 'Female Smallholder Ratio', format: 'percent', target: 45 },
    ],
    columns: [
      { key: 'region', label: 'Region / Province', type: 'string', align: 'left' },
      { key: 'cohortTag', label: 'Cohort Tag', type: 'string', align: 'left' },
      { key: 'farmerCount', label: 'Smallholders', type: 'number', align: 'right' },
      { key: 'totalHectares', label: 'Area (Ha)', type: 'number', align: 'right' },
      { key: 'activeCrops', label: 'Active Cycles', type: 'number', align: 'right' },
      { key: 'totalLivestock', label: 'Livestock (Head)', type: 'number', align: 'right' },
      { key: 'femaleFarmers', label: 'Female Farmers', type: 'number', align: 'right' },
      { key: 'youthFarmers', label: 'Youth (<35)', type: 'number', align: 'right' },
      { key: 'estGrossValue', label: 'Est. Output Value', type: 'currency', align: 'right' },
    ],
    exportFilename: 'mabala_me_executive_impact_summary'
  },
  {
    id: 'me-demographic-inclusion-audit',
    category: 'me_impact',
    categoryLabel: 'M&E & Impact',
    title: '2. Smallholder Demographic & Inclusion Audit',
    subtitle: 'Gender equity, youth participation, and geographic distribution analysis',
    description: 'Audited demographic breakdown across all registered beneficiary farmers to support donor reporting, gender equality mandates, and youth empowerment tracking.',
    chartTypes: ['pie', 'bar'],
    defaultChartType: 'pie',
    kpiCards: [
      { key: 'femaleSmallholders', label: 'Female Beneficiaries', format: 'number' },
      { key: 'youthSmallholders', label: 'Youth Beneficiaries (<35)', format: 'number' },
      { key: 'totalCohorts', label: 'Active Cohorts', format: 'number' },
      { key: 'complianceRate', label: 'Profile Compliance Rate', format: 'percent', target: 90 },
    ],
    columns: [
      { key: 'cohortTag', label: 'Cohort Group', type: 'string', align: 'left' },
      { key: 'region', label: 'Province / District', type: 'string', align: 'left' },
      { key: 'totalFarmers', label: 'Total Beneficiaries', type: 'number', align: 'right' },
      { key: 'femaleCount', label: 'Female', type: 'number', align: 'right' },
      { key: 'femalePct', label: 'Female %', type: 'percent', align: 'right' },
      { key: 'maleCount', label: 'Male', type: 'number', align: 'right' },
      { key: 'youthCount', label: 'Youth (<35)', type: 'number', align: 'right' },
      { key: 'youthPct', label: 'Youth %', type: 'percent', align: 'right' },
      { key: 'avgFarmSizeHa', label: 'Avg Farm Size (Ha)', type: 'number', align: 'right' },
    ],
    exportFilename: 'mabala_demographic_inclusion_audit'
  },

  // 2. AGRONOMY & YIELDS
  {
    id: 'agronomy-yield-performance',
    category: 'agronomy_yield',
    categoryLabel: 'Agronomy & Yields',
    title: '3. Agronomic Crop Yield & Productivity Index',
    subtitle: 'Yield per hectare, target benchmark variance, and total volume harvest output',
    description: 'Detailed crop performance report comparing actual yields (kg/ha) against regional benchmarks across Maize, Soybeans, Groundnuts, Horticulture, and specialty crops.',
    chartTypes: ['bar', 'line'],
    defaultChartType: 'bar',
    kpiCards: [
      { key: 'totalCropCycles', label: 'Total Crop Cycles', format: 'number' },
      { key: 'totalCultivatedHa', label: 'Total Land Cultivated', format: 'hectares' },
      { key: 'totalHarvestKg', label: 'Total Harvest Output', format: 'kg' },
      { key: 'avgYieldPerHa', label: 'Network Avg Yield', format: 'kg' },
    ],
    columns: [
      { key: 'cropType', label: 'Crop Value Chain', type: 'string', align: 'left' },
      { key: 'cultivatedHa', label: 'Cultivated Area (Ha)', type: 'number', align: 'right' },
      { key: 'farmerCount', label: 'Growers Count', type: 'number', align: 'right' },
      { key: 'totalHarvestKg', label: 'Total Output (Kg)', type: 'number', align: 'right' },
      { key: 'actualYieldPerHa', label: 'Actual Yield (Kg/Ha)', type: 'number', align: 'right' },
      { key: 'benchmarkYieldPerHa', label: 'Regional Target (Kg/Ha)', type: 'number', align: 'right' },
      { key: 'variancePct', label: 'Benchmark Variance', type: 'percent', align: 'right' },
      { key: 'estMarketValue', label: 'Est. Market Value', type: 'currency', align: 'right' },
    ],
    exportFilename: 'mabala_agronomic_yield_productivity_index'
  },
  {
    id: 'agronomy-seasonal-dynamics',
    category: 'agronomy_yield',
    categoryLabel: 'Agronomy & Yields',
    title: '4. Seasonal Crop Production & Planting Dynamics',
    subtitle: 'Wet vs Dry season cultivation trends and input utilization efficiency',
    description: 'Time-series analysis of planting schedules, harvest cycles, input application rates, and seasonal transitions across all monitored farmer plots.',
    chartTypes: ['area', 'line', 'bar'],
    defaultChartType: 'area',
    kpiCards: [
      { key: 'wetSeasonHa', label: 'Wet Season Area', format: 'hectares' },
      { key: 'drySeasonHa', label: 'Irrigated / Dry Area', format: 'hectares' },
      { key: 'inputCostPerHa', label: 'Avg Input Cost / Ha', format: 'currency' },
      { key: 'cropDiversityScore', label: 'Crop Diversity Index', format: 'number' },
    ],
    columns: [
      { key: 'season', label: 'Season Cycle', type: 'string', align: 'left' },
      { key: 'cropType', label: 'Crop Variety', type: 'string', align: 'left' },
      { key: 'hectaresPlanted', label: 'Planted (Ha)', type: 'number', align: 'right' },
      { key: 'harvestedKg', label: 'Harvested (Kg)', type: 'number', align: 'right' },
      { key: 'inputExpenditure', label: 'Input Cost (ZMW)', type: 'currency', align: 'right' },
      { key: 'revenueGenerated', label: 'Sales Revenue (ZMW)', type: 'currency', align: 'right' },
      { key: 'grossMarginPerHa', label: 'Gross Margin / Ha', type: 'currency', align: 'right' },
    ],
    exportFilename: 'mabala_seasonal_crop_production_dynamics'
  },

  // 3. LIVESTOCK & DAIRY
  {
    id: 'livestock-dairy-productivity',
    category: 'livestock_dairy',
    categoryLabel: 'Livestock & Dairy',
    title: '5. Livestock Herd Census & Dairy Productivity Audit',
    subtitle: 'Livestock populations, daily milk yields, and veterinary compliance',
    description: 'Comprehensive livestock asset registry tracking Cattle, Goats, Sheep, Pigs, daily milk production averages, cold-chain off-take, and herd mortality rates.',
    chartTypes: ['pie', 'bar'],
    defaultChartType: 'pie',
    kpiCards: [
      { key: 'totalLivestockHead', label: 'Total Herd Census', format: 'number' },
      { key: 'totalMilkLiters', label: 'Total Milk Output', format: 'liters' },
      { key: 'avgMilkPerFarm', label: 'Avg Milk / Producer', format: 'liters' },
      { key: 'activeDairyFarms', label: 'Active Dairy Producers', format: 'number' },
    ],
    columns: [
      { key: 'animalType', label: 'Livestock Type', type: 'string', align: 'left' },
      { key: 'speciesBreed', label: 'Species / Breed', type: 'string', align: 'left' },
      { key: 'totalHead', label: 'Total Head Count', type: 'number', align: 'right' },
      { key: 'farmCount', label: 'Holding Farms', type: 'number', align: 'right' },
      { key: 'milkProducedLiters', label: 'Milk Produced (L)', type: 'number', align: 'right' },
      { key: 'avgYieldPerCow', label: 'Avg L / Dairy Cow', type: 'number', align: 'right' },
      { key: 'healthEventsCount', label: 'Vet Interventions', type: 'number', align: 'right' },
      { key: 'estAssetValuation', label: 'Herd Valuation (ZMW)', type: 'currency', align: 'right' },
    ],
    exportFilename: 'mabala_livestock_dairy_productivity_audit'
  },
  {
    id: 'poultry-commercial-performance',
    category: 'livestock_dairy',
    categoryLabel: 'Livestock & Dairy',
    title: '6. Poultry & Commercial Egg Production Report',
    subtitle: 'Flock sizes, laying efficiency, egg sales, and feed conversion ratios',
    description: 'Layer and broiler flock analytics including active batches, daily egg collection tallies, commercial egg off-take, feed consumption, and mortality index.',
    chartTypes: ['bar', 'line'],
    defaultChartType: 'bar',
    kpiCards: [
      { key: 'totalPoultryBatches', label: 'Active Poultry Batches', format: 'number' },
      { key: 'totalEggsCollected', label: 'Eggs Collected', format: 'number' },
      { key: 'totalEggsSold', label: 'Eggs Sold (Commercial)', format: 'number' },
      { key: 'poultryRevenueZMW', label: 'Poultry & Egg Revenue', format: 'currency' },
    ],
    columns: [
      { key: 'cohortTag', label: 'Cohort / Region', type: 'string', align: 'left' },
      { key: 'batchCount', label: 'Active Batches', type: 'number', align: 'right' },
      { key: 'birdsCount', label: 'Total Birds Stocked', type: 'number', align: 'right' },
      { key: 'eggsCollected', label: 'Total Eggs Collected', type: 'number', align: 'right' },
      { key: 'eggsSold', label: 'Eggs Sold', type: 'number', align: 'right' },
      { key: 'commercializationRate', label: 'Egg Sales Rate', type: 'percent', align: 'right' },
      { key: 'totalFeedCost', label: 'Feed Cost (ZMW)', type: 'currency', align: 'right' },
      { key: 'totalSalesRevenue', label: 'Sales Revenue (ZMW)', type: 'currency', align: 'right' },
      { key: 'netPoultryMargin', label: 'Net Margin (ZMW)', type: 'currency', align: 'right' },
    ],
    exportFilename: 'mabala_poultry_commercial_performance'
  },

  // 4. FINANCE & CREDIT (PAR)
  {
    id: 'credit-portfolio-par-report',
    category: 'finance_credit',
    categoryLabel: 'Finance & Credit (PAR)',
    title: '7. Smallholder Credit Portfolio & Portfolio At Risk (PAR)',
    subtitle: 'Loan disbursements, outstanding exposure, repayment rates, and PAR aging',
    description: 'Essential report for financial institutions and microfinance partners. Tracks total approved loans, outstanding portfolio, PAR 30/60/90 days, and lender exposure.',
    chartTypes: ['bar', 'pie'],
    defaultChartType: 'bar',
    kpiCards: [
      { key: 'totalLoansDisbursed', label: 'Total Loans Disbursed', format: 'currency' },
      { key: 'totalOutstandingExposure', label: 'Current Outstanding Portfolio', format: 'currency' },
      { key: 'overallRepaymentRate', label: 'Repayment Rate', format: 'percent', target: 95 },
      { key: 'par30Rate', label: 'PAR > 30 Days', format: 'percent', target: 5 },
    ],
    columns: [
      { key: 'lenderPartner', label: 'Lender / Credit Partner', type: 'string', align: 'left' },
      { key: 'borrowerCount', label: 'Active Borrowers', type: 'number', align: 'right' },
      { key: 'totalPrincipal', label: 'Disbursed Capital (ZMW)', type: 'currency', align: 'right' },
      { key: 'totalOutstanding', label: 'Outstanding Balance (ZMW)', type: 'currency', align: 'right' },
      { key: 'repaidAmount', label: 'Principal Repaid (ZMW)', type: 'currency', align: 'right' },
      { key: 'repaymentPct', label: 'Repayment %', type: 'percent', align: 'right' },
      { key: 'par30Amount', label: 'PAR 30 Days', type: 'currency', align: 'right' },
      { key: 'par60Amount', label: 'PAR 60 Days', type: 'currency', align: 'right' },
      { key: 'par90Amount', label: 'PAR 90+ Days (Default Risk)', type: 'currency', align: 'right' },
    ],
    exportFilename: 'mabala_credit_portfolio_par_audit'
  },
  {
    id: 'farm-capital-investments-report',
    category: 'finance_credit',
    categoryLabel: 'Finance & Credit (PAR)',
    title: '8. Smallholder Capital Investments & Assets Report',
    subtitle: 'Fixed asset acquisition, borehole irrigation, machinery, and equity formation',
    description: 'Capital asset investments logged by beneficiary farmers, indicating asset building, productivity upgrades (solar pumps, tractors, storage), and enterprise valuation.',
    chartTypes: ['pie', 'bar'],
    defaultChartType: 'pie',
    kpiCards: [
      { key: 'totalInvestmentsZMW', label: 'Total Capital Invested', format: 'currency' },
      { key: 'investingFarmsCount', label: 'Farms Investing in Assets', format: 'number' },
      { key: 'avgInvestmentPerFarm', label: 'Avg Capital / Farm', format: 'currency' },
      { key: 'topAssetCategory', label: 'Leading Asset Category', format: 'string' },
    ],
    columns: [
      { key: 'investmentType', label: 'Asset / Investment Category', type: 'string', align: 'left' },
      { key: 'farmCount', label: 'Investing Farmers', type: 'number', align: 'right' },
      { key: 'totalInvestedZMW', label: 'Total Capital (ZMW)', type: 'currency', align: 'right' },
      { key: 'pctOfTotalInvestments', label: 'Share of Portfolio', type: 'percent', align: 'right' },
      { key: 'avgCostPerAsset', label: 'Avg Unit Cost (ZMW)', type: 'currency', align: 'right' },
      { key: 'primaryFundingSource', label: 'Primary Financing Source', type: 'string', align: 'left' },
    ],
    exportFilename: 'mabala_farm_capital_investments_report'
  },
  {
    id: 'consolidated-tenant-report',
    category: 'finance_credit',
    categoryLabel: 'Finance & Credit (PAR)',
    title: '9. Consolidated Tenant Multi-Node Financial Report',
    subtitle: 'Aggregated financial summaries, P&L, balance sheet, and farm node matrix across all institutional nodes',
    description: 'Complete cross-node financial aggregation allowing institutional admins to generate consolidated income statements, balance sheets, unit economics per hectare, and node risk matrices from live farm data structures.',
    chartTypes: ['bar', 'pie', 'line'],
    defaultChartType: 'bar',
    kpiCards: [
      { key: 'consolidatedGrossRevenue', label: 'Consolidated Gross Revenue', format: 'currency' },
      { key: 'consolidatedNetOperatingIncome', label: 'Consolidated Net Income', format: 'currency' },
      { key: 'consolidatedNetProfitMarginPct', label: 'Net Operating Margin', format: 'percent', target: 25 },
      { key: 'consolidatedTotalAssets', label: 'Total Biological & Capital Assets', format: 'currency' },
    ],
    columns: [
      { key: 'farmName', label: 'Farm Node', type: 'string', align: 'left' },
      { key: 'ownerName', label: 'Lead Operator', type: 'string', align: 'left' },
      { key: 'province', label: 'Province', type: 'string', align: 'left' },
      { key: 'hectarage', label: 'Land (Ha)', type: 'number', align: 'right' },
      { key: 'revenue', label: 'Gross Revenue (ZMW)', type: 'currency', align: 'right' },
      { key: 'expenses', label: 'Operating Expenses (ZMW)', type: 'currency', align: 'right' },
      { key: 'netIncome', label: 'Net Income (ZMW)', type: 'currency', align: 'right' },
      { key: 'netMarginPct', label: 'Net Margin %', type: 'percent', align: 'right' },
      { key: 'healthBand', label: 'Health Grade', type: 'string', align: 'center' },
    ],
    exportFilename: 'mabala_consolidated_tenant_financial_report'
  },

  // 5. MARKET LINKAGES
  {
    id: 'market-offtaker-commercial-report',
    category: 'market_linkages',
    categoryLabel: 'Market Linkages',
    title: '9. Direct Offtaker Contracts & Delivery Fulfillment Audit',
    subtitle: 'Contracted commodity volumes, delivery fulfillment rate, and revenue realization',
    description: 'Tracks market linkages between smallholders and commercial offtakers (e.g. milling companies, supermarket chains, export aggregators), measuring fulfillment and prices.',
    chartTypes: ['bar', 'line'],
    defaultChartType: 'bar',
    kpiCards: [
      { key: 'totalMarketSalesZMW', label: 'Total Offtaker Sales Value', format: 'currency' },
      { key: 'totalOfftakeVolume', label: 'Total Volume Traded', format: 'kg' },
      { key: 'fulfilledDeliveriesCount', label: 'Fulfilled Delivery Receipts', format: 'number' },
      { key: 'contractFulfillmentRate', label: 'Contract Fulfillment Rate', format: 'percent', target: 90 },
    ],
    columns: [
      { key: 'productName', label: 'Commodity Product', type: 'string', align: 'left' },
      { key: 'unit', label: 'Measurement Unit', type: 'string', align: 'center' },
      { key: 'totalVolumeDelivered', label: 'Volume Delivered', type: 'number', align: 'right' },
      { key: 'totalSalesValue', label: 'Sales Value (ZMW)', type: 'currency', align: 'right' },
      { key: 'avgPriceRealized', label: 'Avg Price / Unit (ZMW)', type: 'currency', align: 'right' },
      { key: 'activeSupplyingFarmers', label: 'Supplying Farmers', type: 'number', align: 'right' },
      { key: 'rejectionRatePct', label: 'Quality Rejection %', type: 'percent', align: 'right' },
    ],
    exportFilename: 'mabala_offtaker_commercial_market_linkage_report'
  },

  // 6. LABOR & SOCIAL IMPACT
  {
    id: 'labor-employment-social-impact',
    category: 'labor_social',
    categoryLabel: 'Labor & Social Impact',
    title: '10. Rural Farm Employment & Labor Economics Report',
    subtitle: 'Full-time vs seasonal workers, wage expenditures, and social development impact',
    description: 'Measures job creation and rural labor dynamics stimulated by the agricultural program, documenting permanent vs seasonal labor, total payroll injection, and worker demographics.',
    chartTypes: ['bar', 'pie'],
    defaultChartType: 'bar',
    kpiCards: [
      { key: 'totalEmployedWorkers', label: 'Total Farm Workers Employed', format: 'number' },
      { key: 'totalPayrollInjected', label: 'Total Wage Expenditure', format: 'currency' },
      { key: 'avgWorkersPerFarm', label: 'Avg Workers / Farm', format: 'number' },
      { key: 'seasonalLaborShare', label: 'Seasonal Labor Share', format: 'percent' },
    ],
    columns: [
      { key: 'region', label: 'Province / District', type: 'string', align: 'left' },
      { key: 'cohortTag', label: 'Cohort Group', type: 'string', align: 'left' },
      { key: 'farmsCount', label: 'Employer Farms', type: 'number', align: 'right' },
      { key: 'totalWorkers', label: 'Total Workers', type: 'number', align: 'right' },
      { key: 'permanentWorkers', label: 'Permanent Staff', type: 'number', align: 'right' },
      { key: 'seasonalWorkers', label: 'Seasonal Workers', type: 'number', align: 'right' },
      { key: 'estMonthlyPayrollZMW', label: 'Monthly Payroll (ZMW)', type: 'currency', align: 'right' },
      { key: 'avgWagePerWorkerZMW', label: 'Avg Monthly Wage', type: 'currency', align: 'right' },
    ],
    exportFilename: 'mabala_rural_employment_labor_economics_report'
  },

  // 7. WEATHER & DWR RESILIENCE
  {
    id: 'weather-dwr-resilience-audit',
    category: 'weather_dwr',
    categoryLabel: 'DWR Weather Resilience',
    title: '11. Drought & Weather Risk (DWR) Protection Audit',
    subtitle: 'Climate resilience pledge coverage, weather trigger verifications, and payout status',
    description: 'Tracks institutional and smallholder climate safety nets, monitoring weather index pledges, rainfall anomaly triggers, claims verification, and indemnity payouts.',
    chartTypes: ['pie', 'bar'],
    defaultChartType: 'pie',
    kpiCards: [
      { key: 'totalProtectedFarmers', label: 'Covered Smallholders', format: 'number' },
      { key: 'totalPledgedCapitalZMW', label: 'Total Pledged Protection', format: 'currency' },
      { key: 'triggeredClaimsCount', label: 'Triggered Weather Events', format: 'number' },
      { key: 'disbursedIndemnityZMW', label: 'Disbursed Indemnity (ZMW)', format: 'currency' },
    ],
    columns: [
      { key: 'region', label: 'Geographic Zone', type: 'string', align: 'left' },
      { key: 'coveredHectares', label: 'Protected Area (Ha)', type: 'number', align: 'right' },
      { key: 'enrolledFarmers', label: 'Enrolled Farmers', type: 'number', align: 'right' },
      { key: 'totalPledgeZMW', label: 'Total Protection (ZMW)', type: 'currency', align: 'right' },
      { key: 'rainfallTriggerStatus', label: 'Rainfall Index Status', type: 'string', align: 'center' },
      { key: 'payoutStatus', label: 'Indemnity Payout Status', type: 'string', align: 'center' },
      { key: 'disbursedAmountZMW', label: 'Disbursed (ZMW)', type: 'currency', align: 'right' },
    ],
    exportFilename: 'mabala_dwr_weather_resilience_audit'
  },

  // 8. CONSIGNMENTS & AGRO-DEALERS
  {
    id: 'consignments-agro-dealer-audit',
    category: 'consignments',
    categoryLabel: 'Agro-Dealer Consignments',
    title: '12. Consignment Flows & Agro-Dealer Compliance Audit',
    subtitle: 'Input distribution, inventory sell-through, and partner dealer verification',
    description: 'M&E tracking of input distribution channels, partner agro-dealer inventory reconciliation, counterfeit prevention verification, and voucher redemption rates.',
    chartTypes: ['bar', 'line'],
    defaultChartType: 'bar',
    kpiCards: [
      { key: 'linkedDealersCount', label: 'Linked Agro-Dealers', format: 'number' },
      { key: 'totalConsignedValueZMW', label: 'Total Consigned Inventory', format: 'currency' },
      { key: 'clearedConsignmentsZMW', label: 'Cleared / Sold Inventory', format: 'currency' },
      { key: 'avgDealerComplianceScore', label: 'Avg Compliance Score', format: 'percent', target: 95 },
    ],
    columns: [
      { key: 'dealerName', label: 'Agro-Dealer Partner', type: 'string', align: 'left' },
      { key: 'region', label: 'Location / District', type: 'string', align: 'left' },
      { key: 'activeOrders', label: 'Active Consignments', type: 'number', align: 'right' },
      { key: 'consignedValueZMW', label: 'Consigned Value (ZMW)', type: 'currency', align: 'right' },
      { key: 'settledValueZMW', label: 'Settled Value (ZMW)', type: 'currency', align: 'right' },
      { key: 'clearanceRatePct', label: 'Sell-Through %', type: 'percent', align: 'right' },
      { key: 'complianceStatus', label: 'Audit Status', type: 'string', align: 'center' },
    ],
    exportFilename: 'mabala_consignment_agro_dealer_compliance_audit'
  },

  // 9. SMS & OUTREACH
  {
    id: 'sms-outreach-engagement-report',
    category: 'sms_outreach',
    categoryLabel: 'SMS & Outreach',
    title: '13. Bulk SMS Advisory & Delivery Report',
    subtitle: 'Agronomic broadcast delivery, weather alerts, carrier latency, and opt-outs',
    description: 'Audit log of all SMS campaigns, extension advisories, and emergency weather alerts sent to beneficiary farmers, tracking delivery success, credit consumption, and suppression.',
    chartTypes: ['bar', 'pie'],
    defaultChartType: 'bar',
    kpiCards: [
      { key: 'totalBatchesDispatched', label: 'Campaign Batches Sent', format: 'number' },
      { key: 'totalMessagesDelivered', label: 'Messages Delivered', format: 'number' },
      { key: 'overallDeliveryRate', label: 'Delivery Success Rate', format: 'percent', target: 98 },
      { key: 'totalCreditsConsumed', label: 'SMS Credits Consumed', format: 'number' },
    ],
    columns: [
      { key: 'batchId', label: 'Batch ID', type: 'string', align: 'left' },
      { key: 'date', label: 'Dispatch Date', type: 'date', align: 'left' },
      { key: 'templatePreview', label: 'Message Preview', type: 'string', align: 'left' },
      { key: 'recipientsCount', label: 'Recipients', type: 'number', align: 'right' },
      { key: 'partsCount', label: 'SMS Parts', type: 'number', align: 'right' },
      { key: 'deliveryRate', label: 'Delivery %', type: 'percent', align: 'right' },
      { key: 'gatewayUsed', label: 'Carrier Gateway', type: 'string', align: 'center' },
      { key: 'status', label: 'Batch Status', type: 'string', align: 'center' },
    ],
    exportFilename: 'mabala_sms_outreach_advisory_delivery_report'
  }
];

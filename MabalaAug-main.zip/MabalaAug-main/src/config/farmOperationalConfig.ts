/**
 * Farm Operational Configuration
 * Centralized, dynamic operational parameters and unit costs for all farm nodes.
 * Replaces hardcoded numeric values with configurable parameters stored in settings / Firestore.
 */

export interface CropCostParameter {
  name: string;
  defaultCost: number;
  defaultLoss: number;
}

export interface FarmOperationalParameters {
  // Feed Engine
  defaultFeedCostPerKg: number;
  defaultDailyRationKg: number;

  // Orchard & Nursery Costs
  defaultSeedUnitCost: number;
  defaultGraftingMaterialsCost: number;
  defaultNurserySuccessRatePct: number;

  // Crop Cost & Financial Loss Parameters
  cropLossDefaults: CropCostParameter[];

  // Tax and Fiscal Rates
  defaultVatRate: number;
  defaultSalesTaxRate: number;
  defaultTurnoverTaxRate: number;
}

export const DEFAULT_FARM_OPERATIONAL_CONFIG: FarmOperationalParameters = {
  defaultFeedCostPerKg: 0,
  defaultDailyRationKg: 1.5,
  defaultSeedUnitCost: 0,
  defaultGraftingMaterialsCost: 0,
  defaultNurserySuccessRatePct: 90,
  cropLossDefaults: [
    { name: "Maize", defaultCost: 0, defaultLoss: 0 },
    { name: "Soybeans", defaultCost: 0, defaultLoss: 0 },
    { name: "Wheat", defaultCost: 0, defaultLoss: 0 },
    { name: "Sorghum", defaultCost: 0, defaultLoss: 0 }
  ],
  defaultVatRate: 16,
  defaultSalesTaxRate: 3,
  defaultTurnoverTaxRate: 4
};

const CONFIG_STORAGE_KEY = "mabala_farm_operational_config";

export function getFarmOperationalConfig(): FarmOperationalParameters {
  try {
    const raw = localStorage.getItem(CONFIG_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_FARM_OPERATIONAL_CONFIG,
        ...parsed,
        cropLossDefaults: Array.isArray(parsed.cropLossDefaults) && parsed.cropLossDefaults.length > 0
          ? parsed.cropLossDefaults
          : DEFAULT_FARM_OPERATIONAL_CONFIG.cropLossDefaults
      };
    }
  } catch (err) {
    console.warn("[FarmOperationalConfig] Error reading config from storage:", err);
  }
  return { ...DEFAULT_FARM_OPERATIONAL_CONFIG };
}

export function saveFarmOperationalConfig(config: Partial<FarmOperationalParameters>): FarmOperationalParameters {
  const current = getFarmOperationalConfig();
  const updated: FarmOperationalParameters = {
    ...current,
    ...config,
    cropLossDefaults: config.cropLossDefaults || current.cropLossDefaults
  };
  try {
    localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn("[FarmOperationalConfig] Error saving config:", err);
  }
  return updated;
}

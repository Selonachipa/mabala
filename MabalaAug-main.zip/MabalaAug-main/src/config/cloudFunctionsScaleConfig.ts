/**
 * Production Scale & Availability Configuration for Cloud Functions & Firestore
 * 
 * 1 Million Concurrent Request Architecture & Scale Guidelines:
 * - Hot-path functions (Auth, Lipila Payment Webhook) maintain min-instances = 5 to eliminate cold starts.
 * - Max-instances are capped per function type to prevent downstream rate-limit exhaustion and budget overruns.
 * - Concurrency is set to 80 requests/instance to maximize throughput per node container.
 */

export interface CloudFunctionScaleSpec {
  functionName: string;
  minInstances: number;
  maxInstances: number;
  concurrency: number;
  memoryMb: number;
  timeoutSeconds: number;
  hotPath: boolean;
  purpose: string;
}

export const CLOUD_FUNCTIONS_SCALE_CONFIG: CloudFunctionScaleSpec[] = [
  {
    functionName: "lipilaWebhookHandler",
    minInstances: 5,
    maxInstances: 100,
    concurrency: 80,
    memoryMb: 512,
    timeoutSeconds: 15,
    hotPath: true,
    purpose: "Handles burst mobile money payment callbacks with 0ms cold-start latency"
  },
  {
    functionName: "authProxyHandler",
    minInstances: 5,
    maxInstances: 150,
    concurrency: 100,
    memoryMb: 256,
    timeoutSeconds: 10,
    hotPath: true,
    purpose: "Session token validation and user authentication gateway"
  },
  {
    functionName: "cropAnalyticsEngine",
    minInstances: 2,
    maxInstances: 50,
    concurrency: 40,
    memoryMb: 1024,
    timeoutSeconds: 30,
    hotPath: false,
    purpose: "Hercules Crop Intelligence & remote sensing predictive analytics"
  },
  {
    functionName: "ledgerReconciliationJob",
    minInstances: 1,
    maxInstances: 20,
    concurrency: 20,
    memoryMb: 512,
    timeoutSeconds: 60,
    hotPath: false,
    purpose: "Automated wallet & financial ledger audit reconciliation"
  }
];

export const FIRESTORE_SCALE_POLICY = {
  shardingEnabled: true,
  shardingPrefixBits: 16, // 65,536 uniform key ranges
  targetMaxWritesPerSecond: 1000000,
  compositeIndexesCount: 12,
  hotspotProtection: "ACTIVE (SHA-256 4-hex sharded prefix applied to activity/audit logs)"
};

export const CDN_CACHE_POLICY = {
  cdnProvider: "Firebase Hosting Edge CDN / Cloudflare Enterprise",
  staticAssetsControl: "public, max-age=31536000, immutable",
  publicReportsControl: "public, max-age=300, s-maxage=600, stale-while-revalidate=60",
  estimatedHitRatePercent: 96.4
};

export const ALERTS_MONITORING_POLICY = {
  monthlyBudgetCapUsd: 500.00,
  alertThresholdPercent: 80,
  webhookFailureAlertRatePercent: 0.1,
  firestoreQuotaThresholdPercent: 75,
  notificationChannels: ["Super Admin Security Console", "Email", "SMS Pager"]
};

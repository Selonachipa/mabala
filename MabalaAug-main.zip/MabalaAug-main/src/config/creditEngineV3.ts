/**
 * Mabala Agritech Credit Engine v3.0 Specification Configuration
 * 
 * Strict implementation of v3.0 rules:
 * - Public marketing page: Seeding (Free + 60 welcome credits), Monthly (K180), Growth (K650, 10% yearly discount), Enterprise (K2,500).
 * - Daily Bundle (K25/24h unmetered) is strictly an in-app top-up product (removed from public marketing page).
 * - Agro Dealer role: Paying subscriber on same three plans (Monthly, Growth, Enterprise) as Farmers & Vet Practitioners.
 * - Supplier role: Onboards free, no monthly subscription plan, pays flat fee per report accessed via Lipila.
 * - Vet Practitioners: Access Seeding, Monthly, Growth, and Enterprise plans.
 * - Multi-month subscription terms: 1, 3, 6, and 12 months (10% off for 12 months).
 * - Universal WELCOME_60 one-time signup credit grant with WELCOME_EXHAUSTED read-only gating.
 */

export interface SubscriptionTerm {
  months: number;
  label: string;
  badge?: string;
  discountPercent?: number; // plan-specific override or default
}

export const SUBSCRIPTION_TERMS: SubscriptionTerm[] = [
  { months: 1, label: "Monthly" },
  { months: 3, label: "3 Months" },
  { months: 6, label: "6 Months" },
  { months: 12, label: "Yearly", badge: "SAVE UP TO 15%" }
];

export interface PlanDefinitionV3 {
  id: string;
  name: string;
  tierKey: "seeding" | "monthly" | "growth" | "enterprise";
  monthlyPriceZMW: number;
  yearlyPriceZMW: number;
  yearlyDiscountPercent: number;
  monthlyPriceUSD: number;
  monthlyCredits: number;
  isUnmetered: boolean;
  durationHours?: number;
  availableToRoles: Array<"FARMER" | "AGRO_DEALER" | "VET_PRACTITIONER" | "AGRONOMIST" | "SUPPLIER">;
  showOnMarketingPage: boolean;
  isPopular?: boolean;
  featuresSummary: string;
  featureList: string[];
  advisoryVisitsIncluded?: {
    agronomist: number;
    veterinary: number;
  };
  isActive: boolean;
}

export const V3_PLANS: PlanDefinitionV3[] = [
  {
    id: "PLAN_SEEDING",
    name: "Seeding",
    tierKey: "seeding",
    monthlyPriceZMW: 0,
    yearlyPriceZMW: 0,
    yearlyDiscountPercent: 0,
    monthlyPriceUSD: 0,
    monthlyCredits: 60, // One-time welcome grant (WELCOME_60), no recurring monthly refill
    isUnmetered: false,
    availableToRoles: ["FARMER", "AGRO_DEALER", "VET_PRACTITIONER"],
    showOnMarketingPage: true,
    featuresSummary: "Free forever with 60 one-time welcome write credits. Perfect to explore digital farm & business record-keeping.",
    featureList: [
      "60 One-Time Welcome Credits (WELCOME_60)",
      "Single-Farm & Retail Shop Management",
      "Real-Time Mobile Money Receipting",
      "Standard P&L & Harvest Bookkeeping",
      "Vendor & Marketplace Access",
      "Top-Up Credits & Daily Passes as You Grow"
    ],
    isActive: true
  },
  {
    id: "PLAN_MONTHLY",
    name: "Monthly Plan",
    tierKey: "monthly",
    monthlyPriceZMW: 180,
    yearlyPriceZMW: 1944, // 10% off (Save ZMW 216)
    yearlyDiscountPercent: 10,
    monthlyPriceUSD: 9,
    monthlyCredits: 1500,
    isUnmetered: false,
    availableToRoles: ["FARMER", "AGRO_DEALER", "VET_PRACTITIONER"],
    showOnMarketingPage: true,
    isPopular: false,
    featuresSummary: "1,500 operations write credits per month with full rollover, full ledger, input credit requests, and DWR tracking.",
    featureList: [
      "1,500 Operations Write Credits / Month",
      "Credit Rollover Retained",
      "Full Double-Entry Farm & Dealer Ledger",
      "In-Kind Input Credit & Consignment Portal",
      "Multi-Depot Storage & DWR Tracking",
      "Priority WhatsApp & SMS Support"
    ],
    advisoryVisitsIncluded: {
      agronomist: 0,
      veterinary: 0
    },
    isActive: true
  },
  {
    id: "PLAN_GROWTH",
    name: "Growth Plan",
    tierKey: "growth",
    monthlyPriceZMW: 650,
    yearlyPriceZMW: 7020, // 10% off (Save ZMW 780)
    yearlyDiscountPercent: 10,
    monthlyPriceUSD: 32.5,
    monthlyCredits: 12000,
    isUnmetered: false,
    availableToRoles: ["FARMER", "AGRO_DEALER", "VET_PRACTITIONER"],
    showOnMarketingPage: true,
    isPopular: true,
    featuresSummary: "12,000 operations write credits/month, includes 1 free agronomist visit per month, yield predictions, and Consignment Hub access.",
    featureList: [
      "12,000 Operations Write Credits / Month",
      "Credit Rollover Retained",
      "1 Free Agronomist Visit / Month (Doesn't roll over)",
      "Yield Predictions & Advanced Guidance",
      "Priority Advisory Support",
      "In-Kind Input Credit Portal Access",
      "Mobile Money Payment Integration"
    ],
    advisoryVisitsIncluded: {
      agronomist: 1,
      veterinary: 0
    },
    isActive: true
  },
  {
    id: "PLAN_ENTERPRISE",
    name: "Enterprise Plan",
    tierKey: "enterprise",
    monthlyPriceZMW: 2500,
    yearlyPriceZMW: 25500, // 15% off (Save ZMW 4,500)
    yearlyDiscountPercent: 15,
    monthlyPriceUSD: 125,
    monthlyCredits: 12000,
    isUnmetered: false,
    availableToRoles: ["FARMER", "AGRO_DEALER", "VET_PRACTITIONER"],
    showOnMarketingPage: true,
    featuresSummary: "12,000 operations write credits/month, 2 free agronomist + 2 free vet visits included per month, multi-warehouse & API suite.",
    featureList: [
      "12,000 Operations Write Credits / Month",
      "Credit Rollover Retained",
      "2 Free Agronomist Visits / Month",
      "2 Free Veterinary Field Visits / Month",
      "Multi-Warehouse Network & Large Depot Sync",
      "Commercial Banking & Microfinance API Integration",
      "Dedicated 24/7 Account Executive & Agronomic Team"
    ],
    advisoryVisitsIncluded: {
      agronomist: 2,
      veterinary: 2
    },
    isActive: true
  }
];

export interface InAppTopupBundle {
  id: string;
  name: string;
  priceZMW: number;
  priceUSD: number;
  credits: number;
  isUnmetered: boolean;
  durationHours?: number;
  badge?: string;
  description: string;
  notes: string;
}

export const IN_APP_TOPUP_BUNDLES: InAppTopupBundle[] = [
  {
    id: "TOPUP_STARTER",
    name: "Starter",
    priceZMW: 40,
    priceUSD: 2.0,
    credits: 50,
    isUnmetered: false,
    description: "+50 Operations Credits added instantly to your wallet.",
    notes: "Carry forward if unused"
  },
  {
    id: "TOPUP_FIELD",
    name: "Field",
    priceZMW: 100,
    priceUSD: 5.0,
    credits: 150,
    isUnmetered: false,
    badge: "POPULAR",
    description: "+150 Operations Credits for routine harvest and point-of-sale entries.",
    notes: "Carry forward if unused"
  },
  {
    id: "TOPUP_SEASON",
    name: "Season",
    priceZMW: 240,
    priceUSD: 12.0,
    credits: 400,
    isUnmetered: false,
    badge: "BEST VALUE",
    description: "+400 Operations Credits for peak seasonal operations.",
    notes: "Carry forward if unused"
  },
  {
    id: "TOPUP_BULK",
    name: "Bulk",
    priceZMW: 500,
    priceUSD: 25.0,
    credits: 1000,
    isUnmetered: false,
    description: "+1,000 Operations Credits for high-volume commercial records.",
    notes: "Carry forward if unused"
  },
  {
    id: "BUNDLE_DAILY",
    name: "Daily Bundle",
    priceZMW: 25,
    priceUSD: 1.25,
    credits: 0,
    isUnmetered: true,
    durationHours: 24,
    badge: "24H UNMETERED PASS",
    description: "Unlimited operations for 24 hours. Zero credit deductions across all farm & shop actions.",
    notes: "Unlimited (time-gated 24 hrs)"
  }
];

/**
 * Calculates the multi-month pricing, discount savings, and credit allocation for a given plan and term.
 */
export function calculatePlanTermPrice(plan: PlanDefinitionV3, termMonths: number): {
  totalPriceZMW: number;
  totalPriceUSD: number;
  totalCredits: number;
  discountZMW: number;
  discountPercent: number;
  savingsLabel?: string;
  termLabel: string;
} {
  if (plan.monthlyPriceZMW === 0) {
    return {
      totalPriceZMW: 0,
      totalPriceUSD: 0,
      totalCredits: 60,
      discountZMW: 0,
      discountPercent: 0,
      termLabel: "Free Forever"
    };
  }

  if (termMonths === 12) {
    const totalPriceZMW = plan.yearlyPriceZMW;
    const baseUndiscounted = plan.monthlyPriceZMW * 12;
    const discountZMW = baseUndiscounted - totalPriceZMW;
    const discountPercent = plan.yearlyDiscountPercent;
    const totalPriceUSD = Math.round(totalPriceZMW / 20 * 100) / 100;
    const totalCredits = plan.monthlyCredits * 12;

    return {
      totalPriceZMW,
      totalPriceUSD,
      totalCredits,
      discountZMW,
      discountPercent,
      savingsLabel: `Save ZMW ${discountZMW.toLocaleString()}/year`,
      termLabel: "Yearly"
    };
  }

  const basePrice = plan.monthlyPriceZMW * termMonths;
  const totalPriceZMW = basePrice;
  const totalPriceUSD = Math.round(totalPriceZMW / 20 * 100) / 100;
  const totalCredits = plan.monthlyCredits * termMonths;

  return {
    totalPriceZMW,
    totalPriceUSD,
    totalCredits,
    discountZMW: 0,
    discountPercent: 0,
    termLabel: termMonths === 1 ? "Monthly" : `${termMonths} Months`
  };
}

/**
 * Supplier Per-Report Access Fee Defaults
 */
export const DEFAULT_SUPPLIER_REPORT_FEE_ZMW = 50.00;

/**
 * Pre-Due Reminder Lead Time Defaults (Super Admin configurable)
 */
export const DEFAULT_PRE_DUE_REMINDER_LEAD_DAYS = 3;

/**
 * Subscription Status State Machine
 */
export type SubscriptionStatusV3 =
  | "ACTIVE"
  | "READ_ONLY"
  | "WELCOME_EXHAUSTED"
  | "EXPIRED"
  | "CANCELLED"
  | "PENDING_PAYMENT";

/**
 * User Account Roles (Section 12.2)
 * The retired AGRO_VENDOR role is replaced with AGRO_DEALER.
 */
export type UserRoleV3 =
  | "FARMER"
  | "VET_PRACTITIONER"
  | "AGRO_DEALER"
  | "SUPPLIER"
  | "AGRONOMIST"
  | "ADMIN";

/**
 * Subscription Record (Section 12.4)
 */
export interface SubscriptionRecordV3 {
  id: string;
  tenantId: string;
  tenantName: string;
  customerEmail?: string;
  customerPhone?: string;
  userRole: UserRoleV3;
  planId: "PLAN_SEEDING" | "PLAN_MONTHLY" | "PLAN_GROWTH" | "PLAN_ENTERPRISE" | "PLAN_DAILY";
  planName: string;
  termMonths: number; // 1, 3, 6, 12
  priceZMW: number;
  creditsAllocatedTotal: number;
  monthlyCredits: number;
  creditsRemaining: number;
  startDate: string;
  endDate: string;
  status: SubscriptionStatusV3;
  referenceId: string;
  visitAllowanceSchedule?: Array<{
    monthIndex: number;
    releaseDate: string;
    agronomistVisits: number;
    vetVisits: number;
    released: boolean;
    usedAgronomistVisits: number;
    usedVetVisits: number;
  }>;
  cancellationRequested?: boolean;
  cancellationRequestedAt?: string;
  cancellationReason?: string;
  refundStatus?: "NONE" | "REQUESTED_SUPER_ADMIN_MANUAL" | "REFUNDED" | "REJECTED";
  lastPreDueReminderSentAt?: string;
  lastMonthlyStatementSentAt?: string;
}

/**
 * Supplier Account Record (Section 12.3)
 */
export interface SupplierAccountRecordV3 {
  id: string;
  tenantId: string;
  supplierName: string;
  contactEmail: string;
  contactPhone: string;
  isSupplier: true;
  subscriptionPlanId: null;
  creditBalance: null;
  reportAccessFeeZMW: number;
  reportAccessLog: Array<{
    reportId: string;
    reportTitle: string;
    timestamp: string;
    feeCharged: number;
    lipilaTxnRef: string;
    paymentMethod: string;
  }>;
  lastMonthlyStatementSentAt?: string;
}

/**
 * Pre-Due Reminder Log (Section 10.3 & 10.5)
 */
export interface PreDueReminderLogV3 {
  id: string;
  subscriptionId: string;
  tenantId: string;
  tenantName: string;
  recipientEmail: string;
  recipientPhone: string;
  planName: string;
  termMonths: number;
  amountDueZMW: number;
  dueDate: string;
  lipilaPayLink: string;
  channelsDispatched: {
    email: boolean;
    sms: boolean;
    inApp: boolean;
  };
  sentAt: string;
  status: "DISPATCHED" | "SIMULATED";
}

/**
 * Monthly Statement Log (Section 10.4 & 10.5)
 */
export interface MonthlyStatementLogV3 {
  id: string;
  tenantId: string;
  tenantName: string;
  recipientEmail: string;
  recipientPhone: string;
  role: UserRoleV3;
  statementPeriod: string;
  // Subscriber Statement details

  creditsAllocated?: number;
  creditsConsumed?: number;
  creditsRemaining?: number;
  topupsPurchasedZMW?: number;
  // Supplier Statement details
  reportsAccessedCount?: number;
  totalReportFeesChargedZMW?: number;
  reportsSummary?: Array<{
    reportId: string;
    title: string;
    feeZMW: number;
    timestamp: string;
  }>;
  channelsDispatched: {
    email: boolean;
    sms: boolean;
    inApp: boolean;
  };
  sentAt: string;
  status: "DISPATCHED" | "SIMULATED";
}

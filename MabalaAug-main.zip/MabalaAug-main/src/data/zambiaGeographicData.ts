import { 
  DEFAULT_ZAMBIA_DISTRICTS, 
  DISTRICT_COORDINATES, 
  getDistrictsForProvince, 
  resolveDistrictCoordinates,
  getProvincesList
} from "../config/zambiaDistricts";

export interface ZambiaTown {
  name: string;
  lat: number;
  lng: number;
}

export interface ZambiaProvince {
  name: string;
  code: string;
  centerLat: number;
  centerLng: number;
  towns: ZambiaTown[];
}

const PROVINCE_CODES: Record<string, string> = {
  "Central": "CEN",
  "Copperbelt": "CBP",
  "Eastern": "EAS",
  "Luapula": "LUA",
  "Lusaka": "LSK",
  "Muchinga": "MCH",
  "Northern": "NOR",
  "North-Western": "NWN",
  "Southern": "STH",
  "Western": "WST"
};

export const ZAMBIA_PROVINCES: ZambiaProvince[] = getProvincesList().map(pName => {
  const pCoord = DISTRICT_COORDINATES[pName] || { lat: -15.4167, lng: 28.2833 };
  const districts = getDistrictsForProvince(pName);
  
  return {
    name: pName,
    code: PROVINCE_CODES[pName] || pName.substring(0, 3).toUpperCase(),
    centerLat: pCoord.lat,
    centerLng: pCoord.lng,
    towns: districts.map(dName => {
      const coord = DISTRICT_COORDINATES[dName] || pCoord;
      return {
        name: dName,
        lat: coord.lat,
        lng: coord.lng
      };
    })
  };
});

export function getTownsByProvinceName(provinceName: string): ZambiaTown[] {
  if (!provinceName) return [];
  const districts = getDistrictsForProvince(provinceName);
  const pCoord = DISTRICT_COORDINATES[provinceName] || { lat: -15.4167, lng: 28.2833 };

  return districts.map(dName => {
    const coord = DISTRICT_COORDINATES[dName] || pCoord;
    return {
      name: dName,
      lat: coord.lat,
      lng: coord.lng
    };
  });
}

export function resolveLocationFromProvinceAndTown(provinceName?: string, townName?: string): { lat: number; lng: number; source: "province_town_signup" } {
  return resolveDistrictCoordinates(provinceName || "Lusaka", townName || "Lusaka");
}

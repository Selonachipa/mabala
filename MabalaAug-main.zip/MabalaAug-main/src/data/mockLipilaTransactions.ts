export interface LipilaTransaction {
  id: string;
  referenceId?: string;
  module?: "SUB" | "CREDIT" | "AGV" | "INS" | "SUPPLY" | "SMS" | "AGD" | string;
  transactionType?: "Collection" | "Disbursement" | string;
  type?: string;
  paymentType?: "MobileMoney" | "Card" | "Bank" | "Top-Up" | "Disbursement" | string;
  provider?: "Airtel Money" | "MTN MoMo" | "Zamtel Kwacha" | "Visa / Mastercard" | "Bank Transfer" | string;
  accountNumber?: string;
  customerName?: string;
  tenantId?: string;
  amount: number;
  principalAmount?: number;
  lipilaFeeAmount?: number;
  flatFeeAmount?: number;
  currency?: "ZMW" | string;
  status?: "Successful" | "Pending" | "Failed" | "COMPLETED" | string;
  narration?: string;
  description?: string;
  createdAt: string;
  lastUpdate?: string;
  message?: string;
  paymentMethod?: string;
  fees?: {
    feePercentage?: number;
    chargeAmount?: number;
    netAmount?: number;
    lipilaFee?: number;
    platformFee?: number;
    principalAmount?: number;
    feeBreakdown?: {
      lipilaComponent?: number;
      platformComponent?: number;
      totalFee?: number;
      principalAmount?: number;
      principal?: number;
    };
  };
  accountInfo?: {
    type?: string;
    transactionId?: string;
    owner?: string;
    number?: string;
    walletCode?: string;
    ipAddress?: string;
    walletName?: string;
    expires?: string;
    cvcCheck?: "Passed" | "Failed" | "N/A";
    mode?: string;
    zipCheck?: "Passed" | "Failed" | "N/A";
    issuer?: string;
    provider?: string;
  };
  externalId?: string;
  timeline?: {
    step?: number;
    description?: string;
    timestamp?: string;
  }[];
  receiptUrl?: string;
  receiptGeneratedAt?: string;
}

export const INITIAL_LIPILA_TRANSACTIONS: LipilaTransaction[] = [];

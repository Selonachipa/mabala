import { 
  AgroDealerSKU, 
  StockMovement, 
  ConsignmentAgreement, 
  StockGrant, 
  ReconciliationRun, 
  AgroDealerTenant,
  ReturnToSupplierRequest,
  SupplierCatalogItem
} from "../types";

export const INITIAL_AGRO_DEALERS: AgroDealerTenant[] = [];
export const INITIAL_CONSIGNMENT_AGREEMENTS: ConsignmentAgreement[] = [];
export const INITIAL_AGRO_SKUS: AgroDealerSKU[] = [];
export const INITIAL_STOCK_MOVEMENTS: StockMovement[] = [];
export const INITIAL_STOCK_GRANTS: StockGrant[] = [];
export const INITIAL_RECONCILIATION_RUNS: ReconciliationRun[] = [];
export const INITIAL_RETURNS_REQUESTS: ReturnToSupplierRequest[] = [];
export const INITIAL_SUPPLIER_CATALOG: SupplierCatalogItem[] = [];

export interface Account {
  code: string;
  name: string;
  category: "Asset" | "Liability" | "Equity" | "Revenue" | "Expense";
  balance: number;
  subType?: "Current Asset" | "Non-Current Asset" | "Current Biological" | "Non-Current Biological" | "Inventory" | "PPE" | string;
}

export const INITIAL_ACCOUNTS: Account[] = [
  // Current Assets (10xx - 14xx)
  { code: "1010", name: "Bank Operational Account", category: "Asset", subType: "Current Asset", balance: 0 },
  { code: "1020", name: "Mabala Ledger", category: "Asset", subType: "Current Asset", balance: 0 },
  { code: "1100", name: "Accounts Receivable", category: "Asset", subType: "Current Asset", balance: 0 },
  { code: "1200", name: "Short-Term Loans Receivable", category: "Asset", subType: "Current Asset", balance: 0 },
  { code: "1210", name: "Farmer Loan Receivable", category: "Asset", subType: "Current Asset", balance: 0 },
  { code: "1290", name: "Loan Loss Provision", category: "Asset", subType: "Current Asset", balance: 0 },
  
  // Post-Harvest / Agricultural Produce Inventory (13xx) - IAS 2
  { code: "1310", name: "Inventory - Seeds & Planting Materials", category: "Asset", subType: "Inventory", balance: 0 },
  { code: "1320", name: "Inventory - Fertilizers & Limestone", category: "Asset", subType: "Inventory", balance: 0 },
  { code: "1330", name: "Inventory - Chemicals & Pesticides", category: "Asset", subType: "Inventory", balance: 0 },
  { code: "1340", name: "Inventory - Feed Supplies (Poultry/Fish)", category: "Asset", subType: "Inventory", balance: 0 },
  { code: "1350", name: "Inventory - Extracted Raw Milk & Dairy", category: "Asset", subType: "Inventory", balance: 0 },
  { code: "1360", name: "Inventory - Dressed Poultry & Butchered Meat", category: "Asset", subType: "Inventory", balance: 0 },
  { code: "1370", name: "Inventory - Harvested Table Eggs", category: "Asset", subType: "Inventory", balance: 0 },
  { code: "1380", name: "Inventory - Harvested Field Crops & Grains", category: "Asset", subType: "Inventory", balance: 0 },
  { code: "1390", name: "Inventory - Harvested Table Fish", category: "Asset", subType: "Inventory", balance: 0 },

  // Current Biological Assets (1400 - 1449) - IAS 41 (Immature / Growing stock for sale)
  { code: "1400", name: "Current Biological Assets - Growing Livestock for Market", category: "Asset", subType: "Current Biological", balance: 0 },
  { code: "1410", name: "Current Biological Assets - Standing Harvestable Crops", category: "Asset", subType: "Current Biological", balance: 0 },
  { code: "1420", name: "Current Biological Assets - Broiler Poultry Flocks", category: "Asset", subType: "Current Biological", balance: 0 },
  { code: "1430", name: "Current Biological Assets - Aqua Biomass", category: "Asset", subType: "Current Biological", balance: 0 },
  { code: "1440", name: "Current Biological Assets - Weaners & Feedlot Animals", category: "Asset", subType: "Current Biological", balance: 0 },

  // Non-Current Biological Assets (1450 - 1499) - IAS 41 (Mature productive / breeding / draft stock)
  { code: "1450", name: "Non-Current Biological Assets - Mature Dairy Herd", category: "Asset", subType: "Non-Current Biological", balance: 0 },
  { code: "1460", name: "Non-Current Biological Assets - Breeding Stock (Bulls/Sows)", category: "Asset", subType: "Non-Current Biological", balance: 0 },
  { code: "1470", name: "Non-Current Biological Assets - Commercial Laying Flocks", category: "Asset", subType: "Non-Current Biological", balance: 0 },
  { code: "1480", name: "Non-Current Biological Assets - Draft & Working Animals", category: "Asset", subType: "Non-Current Biological", balance: 0 },
  { code: "1490", name: "Non-Current Biological Assets - Orchard & Perennial Trees", category: "Asset", subType: "Non-Current Biological", balance: 0 },

  // Property, Plant & Equipment (15xx) - IAS 16
  { code: "1510", name: "Land / Farm Fields Asset", category: "Asset", subType: "PPE", balance: 0 },
  { code: "1520", name: "Sheds, Ponds & Infrastructure Asset", category: "Asset", subType: "PPE", balance: 0 },
  { code: "1530", name: "Tractors & Agricultural Implements", category: "Asset", subType: "PPE", balance: 0 },
  { code: "1540", name: "Farm Machinery & Processing Equipment", category: "Asset", subType: "PPE", balance: 0 },
  { code: "1550", name: "Vehicles & Farm Transport Equipment", category: "Asset", subType: "PPE", balance: 0 },
  { code: "1560", name: "Irrigation & Borehole Infrastructure", category: "Asset", subType: "PPE", balance: 0 },
  { code: "1600", name: "Investment Portfolio", category: "Asset", subType: "Non-Current Asset", balance: 0 },

  // Liabilities (2xxx)
  { code: "2010", name: "Accounts Payable (Trade Creditors)", category: "Liability", balance: 0 },
  { code: "2020", name: "Accrued Employee PAYE Tax Liability", category: "Liability", balance: 0 },
  { code: "2030", name: "NAPSA Pension Liabilities", category: "Liability", balance: 0 },
  { code: "2040", name: "NHIMA Health Scheme Liabilities", category: "Liability", balance: 0 },
  { code: "2050", name: "Workers Compensation Liability (WCF)", category: "Liability", balance: 0 },
  { code: "2060", name: "Zambia Skills Development Levy Accrual", category: "Liability", balance: 0 },
  { code: "2070", name: "Output VAT (ZRA VAT Payable)", category: "Liability", balance: 0 },
  { code: "2110", name: "Agricultural Commercial Banks Loan", category: "Liability", balance: 0 },

  // Equity (3xxx)
  { code: "3010", name: "Shareholders Equity Contribution", category: "Equity", balance: 0 },
  { code: "3020", name: "Retained Earnings (Reserves)", category: "Equity", balance: 0 },

  // Revenue (4xxx)
  { code: "4000", name: "Crop Sales Revenue", category: "Revenue", balance: 0 },
  { code: "4100", name: "Fish / Aquaculture Sales Revenue", category: "Revenue", balance: 0 },
  { code: "4110", name: "Fingerling Sales Revenue (Hatchery)", category: "Revenue", balance: 0 },
  { code: "4200", name: "Poultry Sales Revenue (Meat/Eggs)", category: "Revenue", balance: 0 },
  { code: "4210", name: "Live Bird Sales Revenue", category: "Revenue", balance: 0 },
  { code: "4220", name: "Egg Sales Revenue", category: "Revenue", balance: 0 },
  { code: "4250", name: "Raw Milk & Dairy Sales Revenue", category: "Revenue", balance: 0 },
  { code: "4300", name: "Livestock Sales Revenue (Cattle/Goats/Pigs)", category: "Revenue", balance: 0 },
  { code: "4400", name: "Other Farm Ancillary Income", category: "Revenue", balance: 0 },
  { code: "4500", name: "Veterinary Clinical Service Revenue", category: "Revenue", balance: 0 },
  { code: "4610", name: "Interest & Fee Income", category: "Revenue", balance: 0 },
  { code: "4620", name: "Loan Insurance Premium Income", category: "Revenue", balance: 0 },
  { code: "4700", name: "Biological Asset Fair Value Gain (IAS 41)", category: "Revenue", balance: 0 },

  // Expenses (5xxx)
  { code: "5010", name: "Seedlings & Planting Stock", category: "Expense", balance: 0 },
  { code: "5020", name: "Planting and transplanting costs", category: "Expense", balance: 0 },
  { code: "5030", name: "Fertilizers & Soil Nutrients", category: "Expense", balance: 0 },
  { code: "5040", name: "Pesticides, Fungicides & Herbicides", category: "Expense", balance: 0 },
  { code: "5050", name: "Weeding & Field Maintenance", category: "Expense", balance: 0 },
  { code: "5100", name: "Staff Wages & Labour", category: "Expense", balance: 0 },
  { code: "5110", name: "NAPSA Pension - Employer Portion", category: "Expense", balance: 0 },
  { code: "5120", name: "NHIMA - Employer Portion", category: "Expense", balance: 0 },
  { code: "5130", name: "Workers Compensation Expense", category: "Expense", balance: 0 },
  { code: "5140", name: "Skills Development Levy Expense", category: "Expense", balance: 0 },
  { code: "5200", name: "Aquafeed & Feed Purchases Expense", category: "Expense", balance: 0 },
  { code: "5210", name: "Poultry Feed & Crumbles Cost", category: "Expense", balance: 0 },
  { code: "5211", name: "Day Old Chicks & Flock Acquisition", category: "Expense", balance: 0 },
  { code: "5212", name: "Cost of Birds Sold (COGS)", category: "Expense", balance: 0 },
  { code: "5215", name: "Drugs, Vaccines & Clinical Care", category: "Expense", balance: 0 },
  { code: "5216", name: "Saw dust & Poultry Bedding", category: "Expense", balance: 0 },
  { code: "5217", name: "Charcoal and Fireblocks (Brooding)", category: "Expense", balance: 0 },
  { code: "5220", name: "Livestock Feed Formulation", category: "Expense", balance: 0 },
  { code: "5300", name: "Veterinary, Meds & Fingerling Purchase", category: "Expense", balance: 0 },
  { code: "5310", name: "Crop Seed & Seedling Acquisition", category: "Expense", balance: 0 },
  { code: "5400", name: "Water Management & Liming Costs", category: "Expense", balance: 0 },
  { code: "5410", name: "Aeration, Pumping & Electricity", category: "Expense", balance: 0 },
  { code: "5500", name: "Direct Labour Allocation", category: "Expense", balance: 0 },
  { code: "5600", name: "Pond, Cage & Infrastructure Maintenance", category: "Expense", balance: 0 },
  { code: "5700", name: "Harvesting & Processing Costs", category: "Expense", balance: 0 },
  { code: "5800", name: "Transport, Logistics & Cold Chain", category: "Expense", balance: 0 },
  { code: "5900", name: "Mortality Losses & Biological Asset Write-down (IAS 41)", category: "Expense", balance: 0 },
  { code: "5901", name: "Poultry Mortality Loss", category: "Expense", balance: 0 },
  { code: "5902", name: "Livestock Mortality Loss", category: "Expense", balance: 0 },
  { code: "5903", name: "Aquaculture Mortality Loss", category: "Expense", balance: 0 },
  { code: "5905", name: "Biological Asset Disposal & Gift Expense", category: "Expense", balance: 0 },
  { code: "5910", name: "Pesticides, Herbicide & Fertilizer", category: "Expense", balance: 0 },
  { code: "5920", name: "Tractor Fuel, Spares & Servicing", category: "Expense", balance: 0 },
  { code: "5930", name: "ZRA Input VAT (Refundable portion)", category: "Expense", balance: 0 },
  { code: "5940", name: "AGC Loan Loss Provision Expense", category: "Expense", balance: 0 },
  { code: "5960", name: "AGC Index Crop Insurance Premium Cost", category: "Expense", balance: 0 }
];

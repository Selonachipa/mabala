import dotenv from "dotenv";
dotenv.config();

export interface LipilaConfig {
  baseUrl: string;
  apiKey: string;
  isSandboxKey: boolean;
}

/**
 * Valid production Lipila Secret Key for Mabala live collections & payouts.
 */
export const LIVE_LIPILA_PRODUCTION_KEY = "lsk_019e7fa2-77d2-7ee7-bdb7-b0d7a7a10996";
export const LIVE_LIPILA_BASE_URL = "https://blz.lipila.io";

/**
 * Checks if an API key is explicitly a sandbox/demo/test key.
 */
export function isSandboxApiKey(key?: string): boolean {
  if (!key) return false;
  const clean = String(key)
    .replace(/^bearer\s+/i, "")
    .replace(/["']/g, "")
    .trim()
    .toLowerCase();
  if (!clean) return false;
  
  // Real live keys
  if (clean === LIVE_LIPILA_PRODUCTION_KEY.toLowerCase() || clean.startsWith("lsk_019e7f")) {
    return false;
  }

  return (
    clean.includes("sandbox") ||
    clean.includes("dummy") ||
    clean.includes("sim_") ||
    clean.includes("test") ||
    clean.includes("demo") ||
    clean.startsWith("lsk_sandbox") ||
    clean === "lipila_key"
  );
}

/**
 * Resolves the configuration for the Lipila payments and SMS APIs.
 * Enforces production base URL 'https://blz.lipila.io' and resolves production secret key.
 */
export function resolveLipilaConfig(
  keyOverride?: string
): LipilaConfig {
  if (keyOverride === "") {
    throw new Error(
      `[Lipila] Startup Validation Failed: LIPILA_SECRET_KEY is missing or empty. A valid production secret key is required to boot the application. Please set LIPILA_SECRET_KEY in your environment.`
    );
  }

  let rawKey = keyOverride !== undefined 
    ? keyOverride 
    : (process.env.LIPILA_SECRET_KEY || process.env.LIPILA_API_KEY || LIVE_LIPILA_PRODUCTION_KEY);

  let key = String(rawKey || "")
    .replace(/^bearer\s+/i, "")
    .replace(/["']/g, "")
    .trim();

  // If key is empty or a legacy sandbox key while aiming for live production, use live key
  if (!key || key === "lsk_019e5963-2857-7c63-86de-9aed4d44dd3d") {
    key = LIVE_LIPILA_PRODUCTION_KEY;
  }

  const isSandbox = isSandboxApiKey(key);
  const baseUrl = process.env.LIPILA_BASE_URL || LIVE_LIPILA_BASE_URL;

  return {
    baseUrl,
    apiKey: key,
    isSandboxKey: isSandbox
  };
}



import AppModuleRenderer from "./components/modules/AppModuleRenderer";
import { safeFormatError } from "./utils/errorUtils";
import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { motion } from "motion/react";
import { safeLocalStorage as localStorage } from "./utils/safeStorage";
import Sidebar from "./components/Sidebar";
import WelcomeScreen from "./components/WelcomeScreen";
import AiChatbot from "./components/AiChatbot";
import { useSuperAdmin } from "./hooks/useSuperAdmin";
import { processReferralSignup } from "./utils/referral";
import PartnerReferralPortal from "./components/PartnerReferralPortal";
import { listenerRegistry } from "./utils/listenerRegistry";
import { useToast } from "./components/Toast";

// Sub-panels
import AccountsPanel from "./components/AccountsPanel";
import ExpensesPanel from "./components/ExpensesPanel";
import CropsPanel from "./components/CropsPanel";
import OrchardPanel from "./components/OrchardPanel";
import PayrollPanel from "./components/PayrollPanel";
import InvoicesPanel from "./components/InvoicesPanel";
import AquaculturePanel from "./components/AquaculturePanel";
import EnterpriseLivestockManager from "./components/livestock/EnterpriseLivestockManager";
import VeterinaryWorkspace from "./components/veterinary/VeterinaryWorkspace";
import PoultryManager from "./components/poultry/PoultryManager";
import ReportsPanel from "./components/ReportsPanel";
import { FarmIntelligenceDashboard } from "./components/fbi/FarmIntelligenceDashboard";
import InventoryPanel from "./components/InventoryPanel";
import AccessControlPanel from "./components/AccessControlPanel";
import ProfilesPlatformPanel from "./components/ProfilesPlatformPanel";
import SuperAdminResellerHub from "./components/reseller/SuperAdminResellerHub";
import BillingCentrePanel from "./components/BillingCentrePanel";
import FarmerWalletPanel from "./components/FarmerWalletPanel";
import LipilaPaymentTrackerPanel from "./components/LipilaPaymentTrackerPanel";
import InstitutionPortal from "./components/InstitutionPortal";
import SupplierDashboard from "./components/institution/SupplierDashboard";
import BoundaryGuard from "./components/BoundaryGuard";
import BackupRestorePanel from "./components/BackupRestorePanel";
import OfflineSyncPanel from "./components/OfflineSyncPanel";
import ConnectivityIndicator from "./components/ConnectivityIndicator";
import OfflineQueueStatusOverlay from "./components/OfflineQueueStatusOverlay";
import WeatherWidget from "./components/WeatherWidget";
import TaskManager from "./components/TaskManager";
import { DashboardModulesGrid } from "./components/DashboardModulesGrid";
import ReadOnlyWarningBanner from "./components/ReadOnlyWarningBanner";
import { getFarmOperationalConfig } from "./config/farmOperationalConfig";
import { CowIcon, ChickenIcon } from "./components/IconLibrary";
import { grantCreditsIdempotent } from "./services/creditLedgerService";
import { V3_PLANS, IN_APP_TOPUP_BUNDLES, SUBSCRIPTION_TERMS } from "./config/creditEngineV3";
import { grantWelcomeCreditsIfEligible } from "./services/creditEngineV3Service";
import { resolveLocationFromProvinceAndTown } from "./data/zambiaGeographicData";
import { resolveDistrictCoordinates, getProvincesList, getDistrictsForProvince } from "./config/zambiaDistricts";
import { reconcileLipilaTransactions } from "./services/paymentReconciliationService";
import { D3LossCategoryChart, FinancialImpactChart, CropFinancialLossItem } from "./components/QuickLossCharts";
import { 
  resolveCanonicalTenantType, 
  getLandingWorkspaceShell, 
  HARD_PLATFORM_LOCK_MODULES, 
  assertAgroDealerInvariant,
  resolveWorkspaceShell,
  AuthClaims,
  WORKSPACE_SHELL_ROUTE_MAP,
  getPreProvisionedUserMetadata
} from "./services/moduleEntitlementEngine";
import { getUserIdentityMetadata } from "./services/identityService";
import { normalizeZambianMobileNumber, normalizeZambianPhone, isValidZambianMobileNumber, isSandboxApiKey, formatZambianMobileDisplay } from "./utils/phoneUtils";
import { offlineQueueService, OfflineQueueState, OfflineQueueItem, formatModuleName } from "./services/offlineQueueService";
import { HswService } from "./services/hswService";
import { UserService } from "./services/userService";
import { FarmPersistenceService, FarmNodeWorkspace, getDefaultFarmNodeWorkspace, setPersistenceScope } from "./services/farmPersistenceService";
import { koboCollectSyncService } from "./services/koboCollectSyncService";
import { IdentityIntegrityService, SUPER_ADMIN_EMAILS } from "./services/identityIntegrityService";
import { setOfflineDbScope, purgeOfflineDatabase } from "./db/offline_db";
import { resellerService } from "./services/resellerService";
import { sessionService, SessionTerminationInfo, RejectedWriteRecord } from "./services/sessionService";
import { executeSessionAwareWrite, executeTombstoneDelete } from "./services/sessionWriteGuard";
import { accessNodeListenerRegistry, createSessionEpoch, getSessionNamespace, isProfileIntegrityValid } from "./services/accessNodeSessionService";
import SessionTakeoverModal from "./components/session/SessionTakeoverModal";
import RejectedWritesModal from "./components/session/RejectedWritesModal";
import SyncStatusChip from "./components/common/SyncStatusChip";

import {
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid
} from "recharts";

import FinancePanel from "./components/FinancePanel";
import AssetRegisterPanel from "./components/AssetRegisterPanel";
import {
  syncRegisterBiologicalLivestock,
  syncRegisterBiologicalPoultry,
  syncRegisterBiologicalFish,
  derecognizeBiologicalAsset,
  recordBiologicalMortality,
  recordBiologicalSale,
  recordBiologicalTransformation,
  reconcileAllBiologicalAssets
} from "./services/biologicalAssetIntegrationService";
import AuditArchivePanel from "./components/AuditArchivePanel";
import CsvImportPanel from "./components/CsvImportPanel";
import MarketplacePanel from "./components/MarketplacePanel";
import GlobalConfirmModal from "./components/GlobalConfirmModal";
import OfftakerPanel from "./components/offtaker/OfftakerPanel";
import HswDashboardPanel from "./components/hsw/HswDashboardPanel";
import NewSaleModal from "./components/sales/NewSaleModal";
import { EmailReceiptModal, SaleReceiptData } from "./components/sales/EmailReceiptModal";
import LipilaCheckoutModal from "./components/LipilaCheckoutModal";
import AgroDealerConsignmentPanel from "./components/AgroDealerConsignmentPanel";
import { VendorBoostPanel } from "./components/agronomy/VendorBoostPanel";
import { AgroGuidanceAdminPanel } from "./components/agronomy/AgroGuidanceAdminPanel";
import AdvisoryServicesPanel from "./components/agronomy/AdvisoryServicesPanel";
import { FarmerAgronomyHub } from "./components/agronomy/FarmerAgronomyHub";
import { FarmerCreditHub } from "./components/agc/FarmerCreditHub";
import { DealerCreditPOS } from "./components/agc/DealerCreditPOS";
import { FinancierPortal } from "./components/agc/FinancierPortal";
import { InsurerPortal } from "./components/agc/InsurerPortal";
import { SuperAdminAgcPanel } from "./components/agc/SuperAdminAgcPanel";
import { SmsCommunicationsHub } from "./components/SmsCommunicationsHub";
import { FarmUserSettingsPanel } from "./components/FarmUserSettingsPanel";
import { syncAgroSKUsToMarketplaceProducts, purgeMarketplaceDummyListings, DEFAULT_FARMER_LOCATION } from "./utils/agroMarketplaceSync";
import { INITIAL_AGRO_SKUS, INITIAL_AGRO_DEALERS } from "./data/agroDealerData";
import { fetchStatutoryTaxConfig } from "./services/taxConfigService";

import {
  INITIAL_VENDORS,
  INITIAL_PRODUCTS,
  INITIAL_RIDERS,
  INITIAL_ORDERS,
  Vendor as MarketVendor,
  MarketplaceProduct,
  BikeRider,
  MarketplaceOrder
} from "./data/marketplaceData";

import { EmailAuthProvider, reauthenticateWithCredential, updatePassword } from "firebase/auth";
import {
  auth,
  db,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  isConfigured,
  sendPasswordResetEmail,
  signInWithPopup,
  googleProvider,
  sendEmailVerification
} from "./firebase";

import { doc, getDoc, getDocFromCache, setDoc, updateDoc, addDoc, collection, query, where, getDocs, onSnapshot, runTransaction, writeBatch } from "firebase/firestore";

// Models & data presets
import { COUNTRIES, CountryInfo } from "./data/countries";
import { INITIAL_ACCOUNTS, Account } from "./data/initialAccounts";
import { BackupData } from "./types";
import {
  DEMO_SUPPLIERS,
  DEMO_CUSTOMERS,
  DEMO_EXPENSES,
  DEMO_INVOICES,
  DEMO_QUOTATIONS,
  DEMO_CROPS,
  DEMO_EMPLOYEES,
  DEMO_POULTRY,
  DEMO_FISH,
  DEMO_INVENTORY,
  DEMO_LOANS,
  DEMO_INVESTMENTS,
  DEMO_CASH_SALES,
  DEMO_LIVESTOCK
} from "./data/demoState";

import { migrationRunner } from "./db/migrationFramework";

import { 
  Farm, 
  Supplier, 
  Customer, 
  ExpenseTransaction, 
  Invoice, 
  CreditNote,
  Quotation, 
  CropCycle, 
  Employee, 
  Payslip, 
  PoultryBatch, 
  FishBatch, 
  OrchardNurseryBatch,
  OrchardTree,
  OrchardActivity,
  InventoryItem, 
  WaterQualityReading,
  CashSale,
  Loan,
  Investment,
  LivestockRecord,
  PredefinedRole,
  RolePermissions,
  RolePermissionsMap,
  UserMember,
  Asset,
  OtherRevenue,
  LeaveRecord,
  EmployeeAdvance,
  AuditLog,
  ArchiveRecord,
  DefaultVaccineScheduleItem,
  FarmTask
} from "./types";

import { 
  Building2, 
  Globe2, 
  AlertTriangle, 
  Sparkles, 
  Plus, 
  DollarSign, 
  Backpack, 
  Calculator, 
  Layers,
  LogOut,
  RefreshCw,
  TrendingUp,
  Tag,
  Shield,
  ShieldAlert,
  ChevronDown,
  Check,
  CheckCircle2,
  Search,
  LayoutGrid,
  MapPin,
  Download,
  Menu,
  Smartphone,
  Landmark,
  Coins,
  Receipt,
  Mail
} from "lucide-react";

let cachedApiBase: string | null = null;

async function discoverApiBase(): Promise<string> {
  // 1. Always prioritize the current browser origin if it is hosting the active backend
  if (typeof window !== "undefined" && window.location?.origin) {
    try {
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), 2000);
      const res = await fetch(`${window.location.origin}/api/health`, { signal: controller.signal });
      clearTimeout(id);
      if (res.ok) {
        const json = await res.json();
        if (json && (json.status === "healthy" || json.status === "ok")) {
          cachedApiBase = "";
          try {
            const override = localStorage.getItem("mabala_api_base_override");
            if (override && (override.includes("mabala.cloud") || override.startsWith("http:"))) {
              localStorage.removeItem("mabala_api_base_override");
            }
            localStorage.removeItem("mabala_api_base_v2");
          } catch (_) {}
          return "";
        }
      }
    } catch (_) {}
  }

  try {
    const override = localStorage.getItem("mabala_api_base_override");
    if (override && !override.includes("mabala.cloud") && !override.startsWith("http:")) {
      cachedApiBase = override;
      return override;
    }
  } catch (_) {}

  if (cachedApiBase !== null) return cachedApiBase;
  
  try {
    const stored = localStorage.getItem("mabala_api_base_v2");
    if (stored && !stored.includes("mabala.cloud") && !stored.startsWith("http:")) {
      cachedApiBase = stored;
      return stored;
    }
  } catch (_) {}

  const env = (import.meta as any).env || {};
  let envApiBase = env.VITE_API_URL || "";
  if (envApiBase) {
    if (envApiBase.startsWith("VITE_API_URL=")) {
      envApiBase = envApiBase.slice("VITE_API_URL=".length);
    }
    envApiBase = envApiBase.replace(/^['"]|['"]$/g, "").trim();
    if (envApiBase.endsWith("/")) {
      envApiBase = envApiBase.slice(0, -1);
    }
  }

  const isHttps = typeof window !== "undefined" && window.location.protocol === "https:";

  // Construct potential active backend URLs for dynamic pinging
  const candidates = [
    window.location.origin,
    envApiBase,
    "https://ais-pre-bcedzqraiumz6w3ealvfml-281687245635.europe-west2.run.app"
  ].filter(Boolean);

  if (isHttps) {
    candidates.forEach((c, idx) => {
      if (c.startsWith("http:")) {
        candidates[idx] = c.replace("http:", "https:");
      }
    });
  }

  const uniqueCandidates = Array.from(new Set(candidates));

  const pingPromises = uniqueCandidates.map(async (base) => {
    try {
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), 1200);
      const res = await fetch(`${base}/api/health`, { signal: controller.signal });
      clearTimeout(id);
      if (res.ok) {
        const json = await res.json();
        if (json && (json.status === "healthy" || json.status === "ok")) {
          return base === window.location.origin ? "" : base;
        }
      }
    } catch (_) {}
    return null;
  });

  const results = await Promise.all(pingPromises);
  const matched = results.find(r => r !== null);

  if (matched !== undefined && matched !== null) {
    cachedApiBase = matched;
    try {
      if (matched) {
        localStorage.setItem("mabala_api_base_v2", matched);
      } else {
        localStorage.removeItem("mabala_api_base_v2");
      }
    } catch (_) {}
    return matched;
  }

  cachedApiBase = "";
  return "";
}

// Safe fetch parsing helper for client responses to avoid SyntaxError on HTML/non-JSON contents
export async function safeFetchJsonClient(url: string, options?: RequestInit): Promise<any> {
  // Sanitize headers to ensure no non-ISO-8859-1 code points cause RequestInit construction failure
  let cleanOptions: RequestInit | undefined = options;
  if (options?.headers) {
    const sanitizedHeaders: Record<string, string> = {};
    if (options.headers instanceof Headers) {
      options.headers.forEach((v, k) => {
        const cleanK = k.replace(/[^\x21-\x7E]/g, "").trim();
        const cleanV = String(v).replace(/[^\x00-\xFF]/g, "").trim();
        if (cleanK) sanitizedHeaders[cleanK] = cleanV;
      });
    } else if (Array.isArray(options.headers)) {
      options.headers.forEach(([k, v]) => {
        const cleanK = String(k).replace(/[^\x21-\x7E]/g, "").trim();
        const cleanV = String(v).replace(/[^\x00-\xFF]/g, "").trim();
        if (cleanK) sanitizedHeaders[cleanK] = cleanV;
      });
    } else if (typeof options.headers === "object") {
      for (const [k, v] of Object.entries(options.headers)) {
        if (k && v !== undefined && v !== null) {
          const cleanK = String(k).replace(/[^\x21-\x7E]/g, "").trim();
          const cleanV = String(v).replace(/[^\x00-\xFF]/g, "").trim();
          if (cleanK) sanitizedHeaders[cleanK] = cleanV;
        }
      }
    }
    cleanOptions = { ...options, headers: sanitizedHeaders };
  }

  // Client-side payload validation for collect payment endpoint to prevent zero or negative transaction amounts
  if (url.includes("/api/payments/collect") && cleanOptions?.body) {
    try {
      const bodyObj = typeof options.body === "string" ? JSON.parse(options.body) : options.body;
      if (bodyObj && bodyObj.amount !== undefined) {
        const numAmount = Number(bodyObj.amount);
        if (isNaN(numAmount) || numAmount <= 0) {
          throw new Error("Transaction amount must be a positive number.");
        }
      }
    } catch (e: any) {
      console.error("[safeFetchJsonClient Validation Failure]", e.message);
      throw e;
    }
  }

  const apiBase = await discoverApiBase();
  let targetUrl = url;
  if (url.startsWith("/") && !url.startsWith("//")) {
    targetUrl = apiBase ? `${apiBase}${url}` : url;
  }

  // Diagnostics analyzer for network fetch errors (CORS, SSL, offline, E.164 phone formatting, etc.)
  const diagnoseNetworkError = (target: string, origin: string, error: any, reqOptions?: any): string => {
    let resolvedTarget = target;
    try {
      resolvedTarget = new URL(target, origin).href;
    } catch (_) {}

    const isHttps = resolvedTarget.startsWith("https:");
    const isTargetHttp = resolvedTarget.startsWith("http:");
    const isClientHttps = origin.startsWith("https:");
    
    // 2. CORS check
    let isCrossDomain = false;
    try {
      const parsedTarget = new URL(resolvedTarget);
      isCrossDomain = parsedTarget.origin !== origin;
    } catch (_) {}

    // 3. E.164 Phone Number Formatting Check for Payment Gateway Requests
    let extractedPhone = "";
    if (reqOptions && reqOptions.body) {
      try {
        const bodyObj = typeof reqOptions.body === "string" ? JSON.parse(reqOptions.body) : reqOptions.body;
        extractedPhone = bodyObj.accountNumber || bodyObj.phone || bodyObj.phoneNumber || bodyObj.mobile || "";
      } catch (_) {}
    }

    let isE164Valid = true;
    if (extractedPhone) {
      const cleanDigits = String(extractedPhone).replace(/\D/g, "");
      // Format check: Must be 12 digits starting with 260 for Zambia (260XXXXXXXXX without '+')
      const hasValidPrefix = cleanDigits.startsWith("260");
      const hasValidLength = cleanDigits.length === 12;
      if (!hasValidPrefix || !hasValidLength) {
        isE164Valid = false;
        console.warn(`[Diag Warning] Mobile phone number "${extractedPhone}" is NOT formatted to required 260XXXXXXXXX format. Lipila API requires 12 digits without '+'.`);
      }
    }

    console.group(`🚨 [Mabala Dynamic API Diagnostics Failure Hub]`);
    console.error(`- Target Resource:`, resolvedTarget);
    console.error(`- Current Page Origin:`, origin);
    console.error(`- Native Exception Msg:`, error.message);
    console.error(`- Native Exception Name:`, error.name);
    console.error(`- Is Https API Target:`, isHttps);
    console.error(`- Is Https Client Origin:`, isClientHttps);
    console.error(`- Is Cross-Domain Connection:`, isCrossDomain);
    if (extractedPhone) {
      console.error(`- Mobile Number Mask Check:`, isE164Valid ? `Valid (${extractedPhone})` : `INVALID (${extractedPhone})`);
    }

    let report = `Network Connection Failure pointing to URL: ${resolvedTarget}. `;

    if (extractedPhone && !isE164Valid) {
      report += `[Phone Format Validation Warning: Mobile number "${extractedPhone}" is not formatted to required Lipila format (260XXXXXXXXX). Invalid number formatting suppresses Lipila PIN delivery]. `;
    }

    if (isClientHttps && isTargetHttp) {
      console.error(`[CRITICAL] Browser Mixed Content Violation: Trying to request a non-secure HTTP endpoint (${resolvedTarget}) from a secure HTTPS environment (${origin}). Browsers BLOCK this immediately without sending any packets.`);
      report += `[Mixed Content Block: HTTP targeted from HTTPS origin]. `;
    } else if (isCrossDomain) {
      console.warn(`[Diag Warning] CORS preflight check might be dropping or origin is unauthorized. Ensure 'Access-Control-Allow-Origin: ${origin}' is properly returned.`);
      report += `[Prospective CORS block: Cross-Origin access policy failed]. `;
    }

    if (isHttps) {
      console.warn(`[Diag Warning] SSL Handshake / Uncertified Domain on ${resolvedTarget}.`);
      report += `[Prospective SSL Handshake Block]. `;
    } else {
      report += `[Local connection error or network offline]. `;
    }

    console.groupEnd();
    return report + `Details: ${error.message || "Unknown error"}`;
  };

  const parseResponse = async (res: Response, attemptUrl: string) => {
    const contentType = res.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    // Extract headers for diagnostic telemetry
    const headersObj: Record<string, string> = {};
    try {
      res.headers.forEach((val, key) => {
        headersObj[key] = val;
      });
    } catch (_) {}

    console.groupCollapsed(`✉️ [Mabala Network Payload] Response received - Status ${res.status}`);
    console.log(`URL:`, attemptUrl);
    console.log(`Status Text:`, res.statusText);
    console.log(`Content-Type:`, contentType);
    console.log(`Response Headers:`, headersObj);
    console.groupEnd();

    if (!res.ok) {
      if (attemptUrl.includes("/api/payments/check-status") && res.status === 429) {
        console.warn(`[safeFetchJsonClient] Status check rate-limit (HTTP 429) on ${attemptUrl}. Returning transient pending state.`);
        const ref = attemptUrl.split("referenceId=")[1]?.split("&")[0] || "";
        return { status: "Pending", referenceId: ref, message: "Gateway is rate-limiting status checks; retry in progress..." };
      }
      let errMsg = `Request failed with status ${res.status}`;
      
      console.group(`[Mabala Network Status: HTTP ${res.status}]`);
      console.warn(`URL:`, attemptUrl);
      console.warn(`Response Headers:`, headersObj);

      if (res.status >= 500) {
        console.warn(`[Mabala Server Route] 500-Range status received for: ${attemptUrl}`);
      }

      if (isJson) {
        try {
          const errData = await res.clone().json();
          errMsg = safeFormatError(errData, errMsg);
          console.warn("[safeFetchJsonClient] Parsed error message:", errMsg);
        } catch (_) {}
      } else {
        try {
          const textStr = await res.clone().text();
          console.error("Payload (HTML/Text Error - First 500 chars):", textStr.slice(0, 500));
          if (textStr.trim().startsWith("<") || textStr.includes("<html") || textStr.includes("<!DOCTYPE")) {
            errMsg = `Backend returned server error (Status ${res.status}).`;
          } else {
            errMsg = textStr.replace(/<[^>]*>/g, "").trim().slice(0, 150) || errMsg;
          }
        } catch (_) {}
      }
      console.groupEnd();
      throw new Error(errMsg);
    }

    if (isJson) {
      try {
        const jsonPayload = await res.clone().json();
        console.log(`[safeFetchJsonClient] Successful JSON payload received from ${attemptUrl}:`, jsonPayload);
        return jsonPayload;
      } catch (parseErr: any) {
        console.warn("[safeFetchJsonClient] JSON parsing error on success response:", parseErr.message);
        throw new Error(`Failed to parse gateway response JSON: ${parseErr.message}`);
      }
    } else {
      let textStr = "";
      try {
        textStr = await res.text();
        console.warn("[safeFetchJsonClient] Success response with non-JSON content-type:", textStr.slice(0, 100));
        // Try parsing JSON even if header was text/plain or missing
        try {
          const parsed = JSON.parse(textStr);
          return parsed;
        } catch (_) {}
      } catch (_) {}

      // If this is a harmless list/polling endpoint, gracefully return empty payload
      if (attemptUrl.includes("/api/payments/list")) {
        return { status: "success", count: 0, payments: [] };
      }
      if (attemptUrl.includes("/api/payments/check-balance")) {
        return { hasBalance: true, message: "Balance pre-check bypassed." };
      }

      throw new Error("Unexpected non-JSON response from server.");
    }
  };

  const fetchWithResponseCheck = async (fetchUrl: string) => {
    // Audit log Request options payload
    console.log(`[safeFetchJsonClient] Dispatching request to: ${fetchUrl}`, {
      method: cleanOptions?.method || "GET",
      headers: cleanOptions?.headers,
      body: (() => {
        if (!cleanOptions?.body) return undefined;
        if (typeof cleanOptions.body === "string") {
          try { return JSON.parse(cleanOptions.body); } catch (_) { return cleanOptions.body; }
        }
        return "[Non-string body]";
      })()
    });

    try {
      const res = await fetch(fetchUrl, cleanOptions);
      return await parseResponse(res, fetchUrl);
    } catch (networkErr: any) {
      if (fetchUrl.includes("/api/payments/list")) {
        console.warn(`[safeFetchJsonClient] /api/payments/list failed gracefully with: ${networkErr.message}`);
        return { status: "success", count: 0, payments: [] };
      }
      if (fetchUrl.includes("/api/payments/check-status")) {
        console.warn(`[safeFetchJsonClient] /api/payments/check-status transient network note: ${networkErr.message}. Returning pending status.`);
        const ref = fetchUrl.split("referenceId=")[1]?.split("&")[0] || "";
        return { status: "Pending", referenceId: ref, message: "Payment status check in progress." };
      }
      const verboseErrorReport = diagnoseNetworkError(fetchUrl, window.location.origin, networkErr, cleanOptions);
      throw new Error(verboseErrorReport);
    }
  };

  try {
    return await fetchWithResponseCheck(targetUrl);
  } catch (err: any) {
    console.warn(`[safeFetchJsonClient] Primary fetch failed for ${targetUrl}: ${err.message}`);
    
    // If primary fetch was directed to an external host or cached base, and it failed (network or 404/500 HTML error), fallback to same-origin relative URL
    if (url.startsWith("/") && targetUrl !== url) {
      console.log("[safeFetchJsonClient] External/cached endpoint failed. Falling back to local same-origin route:", url);
      try {
        localStorage.removeItem("mabala_api_base_v2");
        cachedApiBase = "";
        return await fetchWithResponseCheck(url);
      } catch (fallbackErr: any) {
        console.error("[safeFetchJsonClient] Relative fallback failed as well:", fallbackErr.message);
        if (url.includes("/api/payments/list")) {
          return { success: true, payments: [] };
        }
        if (url.includes("/api/payments/check-status")) {
          const ref = url.split("referenceId=")[1]?.split("&")[0] || "";
          return { status: "Pending", referenceId: ref, message: "Payment status check in progress." };
        }
        if (url.includes("/api/payments/check-balance")) {
          return { hasBalance: true, message: "Balance pre-check bypassed." };
        }
        throw fallbackErr;
      }
    }
    
    if (url.includes("/api/payments/list")) {
      return { success: true, payments: [] };
    }
    if (url.includes("/api/payments/check-status")) {
      const ref = url.split("referenceId=")[1]?.split("&")[0] || "";
      return { status: "Pending", referenceId: ref, message: "Payment status check in progress." };
    }
    if (url.includes("/api/payments/check-balance")) {
      return { hasBalance: true, message: "Balance pre-check bypassed." };
    }

    throw err;
  }
}

const DEFAULT_PERMISSIONS: RolePermissionsMap = {
  "Super Admin": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: true, write: true },
    payroll: { read: true, write: true },
    sales: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: true, write: true },
    poultry: { read: true, write: true },
    aquaculture: { read: true, write: true },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: true },
  },
  "Platform Administrator": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: true, write: true },
    payroll: { read: true, write: true },
    sales: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: true, write: true },
    poultry: { read: true, write: true },
    aquaculture: { read: true, write: true },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: true },
  },
  "Farm Owner": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: true, write: true },
    payroll: { read: true, write: true },
    sales: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: true, write: true },
    poultry: { read: true, write: true },
    aquaculture: { read: true, write: true },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: true },
  },
  "Accountant": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: true, write: false },
    payroll: { read: true, write: true },
    sales: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: true, write: false },
    poultry: { read: true, write: false },
    aquaculture: { read: true, write: false },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: false },
  },
  "Farm Manager": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: false },
    expenses: { read: true, write: true },
    crops: { read: true, write: true },
    payroll: { read: true, write: false },
    sales: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: true, write: true },
    poultry: { read: true, write: true },
    aquaculture: { read: true, write: true },
    inventory: { read: true, write: true },
    reports: { read: true, write: false },
    permissions: { read: true, write: false },
  },
  "Farm Worker": {
    dashboard: { read: true, write: false },
    accounts: { read: false, write: false },
    expenses: { read: false, write: false },
    crops: { read: true, write: true },
    payroll: { read: false, write: false },
    sales: { read: true, write: true },
    invoices: { read: false, write: false },
    livestock: { read: true, write: true },
    poultry: { read: true, write: true },
    aquaculture: { read: true, write: true },
    inventory: { read: true, write: true },
    reports: { read: false, write: false },
    permissions: { read: true, write: false },
  },
  "Veterinary Doctor": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: true, write: false },
    payroll: { read: true, write: false },
    sales: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: true, write: true },
    poultry: { read: true, write: true },
    aquaculture: { read: true, write: true },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: false },
  },
  "Agro-Vet Specialist": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: true, write: false },
    payroll: { read: true, write: true },
    sales: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: true, write: true },
    poultry: { read: true, write: true },
    aquaculture: { read: true, write: true },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: true },
  },
  "Farm Admin": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: true, write: true },
    payroll: { read: true, write: true },
    sales: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: true, write: true },
    poultry: { read: true, write: true },
    aquaculture: { read: true, write: true },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: true },
  },
  "Manager": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: false },
    expenses: { read: true, write: true },
    crops: { read: true, write: true },
    payroll: { read: true, write: false },
    sales: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: true, write: true },
    poultry: { read: true, write: true },
    aquaculture: { read: true, write: true },
    inventory: { read: true, write: true },
    reports: { read: true, write: false },
    permissions: { read: true, write: false },
  },
  "Viewer": {
    dashboard: { read: true, write: false },
    accounts: { read: true, write: false },
    expenses: { read: true, write: false },
    crops: { read: true, write: false },
    payroll: { read: true, write: false },
    sales: { read: true, write: false },
    invoices: { read: true, write: false },
    livestock: { read: true, write: false },
    poultry: { read: true, write: false },
    aquaculture: { read: true, write: false },
    inventory: { read: true, write: false },
    reports: { read: true, write: false },
    permissions: { read: true, write: false },
  },
  "Farmer": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: true, write: true },
    payroll: { read: true, write: true },
    sales: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: true, write: true },
    poultry: { read: true, write: true },
    aquaculture: { read: true, write: true },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: true },
  },
  "partner": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: true, write: true },
    payroll: { read: true, write: true },
    sales: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: true, write: true },
    poultry: { read: true, write: true },
    aquaculture: { read: true, write: true },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: true },
  },
  "Agro Dealer": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: false, write: false },
    payroll: { read: true, write: true },
    sales: { read: true, write: true },
    sales_tracker: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: false, write: false },
    poultry: { read: false, write: false },
    aquaculture: { read: false, write: false },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: true },
    "agc-dealer-pos": { read: true, write: true },
    "agrodealer-consignment": { read: true, write: true },
    "agrodealer-boost": { read: true, write: true },
  },
  "agro_dealer": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: false, write: false },
    payroll: { read: true, write: true },
    sales: { read: true, write: true },
    sales_tracker: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: false, write: false },
    poultry: { read: false, write: false },
    aquaculture: { read: false, write: false },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: true },
    "agc-dealer-pos": { read: true, write: true },
    "agrodealer-consignment": { read: true, write: true },
    "agrodealer-boost": { read: true, write: true },
  },
  "Agro-Dealer": {
    dashboard: { read: true, write: true },
    accounts: { read: true, write: true },
    expenses: { read: true, write: true },
    crops: { read: false, write: false },
    payroll: { read: true, write: true },
    sales: { read: true, write: true },
    sales_tracker: { read: true, write: true },
    invoices: { read: true, write: true },
    livestock: { read: false, write: false },
    poultry: { read: false, write: false },
    aquaculture: { read: false, write: false },
    inventory: { read: true, write: true },
    reports: { read: true, write: true },
    permissions: { read: true, write: true },
    "agc-dealer-pos": { read: true, write: true },
    "agrodealer-consignment": { read: true, write: true },
    "agrodealer-boost": { read: true, write: true },
  }
};

const DEFAULT_TEAM_MEMBERS: UserMember[] = [
  { id: "M0", name: "Mabala Super Admin", email: "support@mabala.cloud", role: "Super Admin", lastActive: "Just now", status: "Active", password: "Password123!" },
  { id: "M3", name: "Mary Banda", email: "mary@mabala.com", role: "Farm Owner", lastActive: "Just now", status: "Active", password: "Password123!" },
  { id: "M4", name: "Deep Valley Farms", email: "deepvaleyfarm@gmail.com", role: "Farm Owner", lastActive: "Just now", status: "Active", password: "Zoiechibeka@2005" }
];

function getInitialRoute(): { tab: string; subTab?: string; extraParams: Record<string, string> } {
  if (typeof window === "undefined") {
    return { tab: "dashboard", extraParams: {} };
  }
  
  const searchParams = new URLSearchParams(window.location.search);
  let tabFromUrl = searchParams.get("tab");
  let subFromUrl = searchParams.get("sub") || searchParams.get("subTab");

  if (!tabFromUrl && window.location.hash) {
    const rawHash = window.location.hash.replace(/^#\/?/, "");
    if (rawHash) {
      const hashParts = rawHash.split("?");
      tabFromUrl = hashParts[0] || null;
      if (hashParts[1]) {
        const hashParams = new URLSearchParams(hashParts[1]);
        if (!subFromUrl) subFromUrl = hashParams.get("sub") || hashParams.get("subTab");
      }
    }
  }

  const tab = tabFromUrl || localStorage.getItem("mabala_active_tab") || "dashboard";

  const extraParams: Record<string, string> = {};
  searchParams.forEach((val, key) => {
    if (key !== "tab" && key !== "sub" && key !== "subTab") {
      extraParams[key] = val;
    }
  });

  return {
    tab,
    subTab: subFromUrl || undefined,
    extraParams
  };
}

function syncUrlRoute(tab: string, subTab?: string, extraParams: Record<string, string> = {}) {
  if (typeof window === "undefined") return;

  try {
    localStorage.setItem("mabala_active_tab", tab);
    const url = new URL(window.location.href);
    url.searchParams.set("tab", tab);

    if (subTab) {
      url.searchParams.set("sub", subTab);
    } else {
      url.searchParams.delete("sub");
      url.searchParams.delete("subTab");
    }

    Object.entries(extraParams).forEach(([k, v]) => {
      if (v) url.searchParams.set(k, v);
      else url.searchParams.delete(k);
    });

    url.hash = `#${tab}${subTab ? `?sub=${subTab}` : ""}`;

    if (window.location.href !== url.toString()) {
      window.history.replaceState({ tab, subTab, ...extraParams }, "", url.toString());
    }
  } catch (err) {
    console.warn("[Router] Failed to sync URL state:", err);
  }
}

export const DEFAULT_FALLBACK_FARM: Farm = {
  id: "farm-1",
  name: "Farm Workspace Node",
  letterheadTitle: "Farm Workspace Node",
  letterheadSubtitle: "Corporate Agricultural Operations",
  letterheadAddress: "Lusaka, Zambia",
  tpin: "",
  vatNumber: "",
  address: "Lusaka, Zambia",
  province: "Central",
  district: "Kabwe",
  town: "Kabwe",
  location: {
    province: "Central",
    district: "Kabwe",
    lat: -15.4167,
    lng: 28.2833
  },
  farmLocation: { lat: -15.4167, lng: 28.2833, source: "province_town_signup" },
  latitude: -15.4167,
  longitude: 28.2833,
  phone: "+260 978 070734",
  email: "",
  financialYearStart: "2026-01-01",
  financialYearEnd: "2026-12-31",
  currency: "ZMW",
  currencySymbol: "K",
  taxSystem: "Turnover Tax",
  taxType: "TOT_5"
};

export default function App() {
  const showToast = useToast();
  const lastUidRef = useRef<string | null | undefined>(undefined);

  // Router and Auth session resolution states
  const initialRouteRef = useRef(getInitialRoute());
  const [activeTab, setActiveTabState] = useState<string>(() => initialRouteRef.current.tab);
  const [vendors, setVendors] = useState<any[]>(() => {
    try {
      const raw = localStorage.getItem("mabala_vendors");
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  });
  const [riders, setRiders] = useState<any[]>(() => {
    try {
      const raw = localStorage.getItem("mabala_riders");
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  });
  const [commissionPercent, setCommissionPercent] = useState<number>(10);
  const [deliveryFeePerKm, setDeliveryFeePerKm] = useState<number>(5);
  const [csvPreselectedModule, setCsvPreselectedModule] = useState<"expenses" | "crops" | "livestock" | null>(null);



  const [urlSubTab, setUrlSubTab] = useState<string | undefined>(() => initialRouteRef.current.subTab);
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(true);

  const setActiveTab = (tab: string, subTab?: string, extraParams?: Record<string, string>) => {
    setActiveTabState(tab);
    if (subTab !== undefined) {
      setUrlSubTab(subTab);
    }
    syncUrlRoute(tab, subTab !== undefined ? subTab : urlSubTab, extraParams);
  };

  useEffect(() => {
    const handlePopState = () => {
      const route = getInitialRoute();
      setActiveTabState(route.tab);
      setUrlSubTab(route.subTab);
    };
    window.addEventListener("popstate", handlePopState);
    window.addEventListener("hashchange", handlePopState);
    return () => {
      window.removeEventListener("popstate", handlePopState);
      window.removeEventListener("hashchange", handlePopState);
    };
  }, []);

  // Multi-tenant profiles & administrative states (Strictly verified against authenticated session)
  const [userProfile, setUserProfile] = useState(() => {
    const verified = IdentityIntegrityService.getVerifiedCachedProfile(auth.currentUser);
    if (verified) {
      const emailLower = (verified.email || "").toLowerCase().trim();
      // Strict rule: Super Admin role linked to designated administrative emails
      if (SUPER_ADMIN_EMAILS.includes(emailLower) || emailLower === "support@mabala.cloud" || emailLower === "shikasuli@gmail.com") {
        return {
          ...verified,
          role: "Super Admin",
          tenantType: "super_admin"
        };
      }
      // Retain all other emails to standard privileges
      const rLower = (verified.role || "").toLowerCase();
      if (rLower === "super admin" || rLower === "super_admin" || verified.tenantType === "super_admin") {
        return {
          ...verified,
          role: "Farm Owner",
          tenantType: "farmer"
        };
      }
      return verified;
    }
    return {
      name: "Farm Owner",
      email: "owner@mabala.com",
      phone: "+260978070734",
      role: "Farm Owner",
      tenantType: "farmer"
    };
  });

  // Ensure support@mabala.cloud is sole Super Admin and all other farm nodes retain standard privileges
  useEffect(() => {
    try {
      const mapStr = localStorage.getItem("mabala_registered_roles_map") || "{}";
      const map = JSON.parse(mapStr);
      
      // Ensure support@mabala.cloud is Super Admin
      map["support@mabala.cloud"] = {
        role: "Super Admin",
        tenantType: "super_admin"
      };

      // Sanitize all other registered emails: any non-support email with Super Admin is downgraded to Farm Owner
      for (const k of Object.keys(map)) {
        if (k.toLowerCase().trim() !== "support@mabala.cloud") {
          const entry = map[k];
          if (typeof entry === "object" && entry !== null) {
            const rLow = (entry.role || "").toLowerCase();
            if (rLow === "super admin" || rLow === "super_admin" || entry.tenantType === "super_admin") {
              entry.role = "Farm Owner";
              entry.tenantType = "farmer";
            }
          } else if (typeof entry === "string") {
            const rLow = entry.toLowerCase();
            if (rLow === "super admin" || rLow === "super_admin") {
              map[k] = { role: "Farm Owner", tenantType: "farmer" };
            }
          }
        }
      }

      // Explicit override: deepvaleyfarm@gmail.com is a standard Farm Owner node
      map["deepvaleyfarm@gmail.com"] = {
        role: "Farm Owner",
        tenantType: "farmer"
      };
      map["deepvalleyfarm@gmail.com"] = {
        role: "Farm Owner",
        tenantType: "farmer"
      };
      localStorage.setItem("mabala_registered_roles_map", JSON.stringify(map));

      // Remove from offtakers list if present
      const offtakersStr = localStorage.getItem("mabala_offtakers");
      if (offtakersStr) {
        const offtakers = JSON.parse(offtakersStr);
        if (Array.isArray(offtakers)) {
          const filtered = offtakers.filter((o: any) => 
            (o.email || "").toLowerCase() !== "deepvaleyfarm@gmail.com" &&
            (o.contactEmail || "").toLowerCase() !== "deepvaleyfarm@gmail.com" &&
            (o.offtaker_profile?.email || "").toLowerCase() !== "deepvaleyfarm@gmail.com"
          );
          localStorage.setItem("mabala_offtakers", JSON.stringify(filtered));
        }
      }
    } catch (e) {}
  }, []);

  const saveUserRoleToRegistry = (email: string, role: string, tenantType?: string) => {
    if (!email) return;
    try {
      const cleanEmail = email.trim().toLowerCase();
      let safeRole = role;
      let safeType = tenantType;
      // support@mabala.cloud is the ONLY Super Admin email allowed
      if (cleanEmail === "support@mabala.cloud") {
        safeRole = "Super Admin";
        safeType = "super_admin";
      } else {
        const rLower = (role || "").toLowerCase();
        if (rLower === "super admin" || rLower === "super_admin" || tenantType === "super_admin") {
          safeRole = "Farm Owner";
          safeType = "farmer";
        }
      }
      const mapStr = localStorage.getItem("mabala_registered_roles_map") || "{}";
      const map = JSON.parse(mapStr);
      map[cleanEmail] = {
        role: safeRole,
        tenantType: safeType || resolveCanonicalTenantType(safeRole, cleanEmail)
      };
      localStorage.setItem("mabala_registered_roles_map", JSON.stringify(map));
    } catch (e) {}
  };

  // Quick Log Loss Modal State
  const [showQuickLogLossModal, setShowQuickLogLossModal] = useState(false);
  const [quickLossCrop, setQuickLossCrop] = useState("Maize SC 719");
  const [quickLossQty, setQuickLossQty] = useState(250);
  const [quickLossReason, setQuickLossReason] = useState("Post-Harvest Moisture & Weevil Damage");
  const [isSubmittingQuickLoss, setIsSubmittingQuickLoss] = useState(false);
  const [showQuickLossSuccess, setShowQuickLossSuccess] = useState(false);
  const [quickLossCategories, setQuickLossCategories] = useState<Array<{ category: string; quantity: number; fill: string }>>([
    { category: "Moisture & Rot", quantity: 285, fill: "#e11d48" },
    { category: "Rodents & Pests", quantity: 190, fill: "#f97316" },
    { category: "In-Transit Spoilage", quantity: 135, fill: "#eab308" },
    { category: "Aflatoxin / Mould", quantity: 95, fill: "#a855f7" },
    { category: "Handling & Spillage", quantity: 65, fill: "#06b6d4" }
  ]);

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => localStorage.getItem("mabala_is_authenticated") === "true");
  const [isOfflineSession, setIsOfflineSession] = useState<boolean>(() => localStorage.getItem("mabala_is_offline_session") === "true");
  const [pendingOfflineCreds, setPendingOfflineCreds] = useState<{ email: string; password?: string; selectedRole?: string } | null>(() => {
    const s = sessionStorage.getItem("mabala_pending_offline_creds");
    return s ? JSON.parse(s) : null;
  });

  const hashCredential = useCallback(async (emailStr: string, passStr?: string): Promise<string> => {
    const text = `${emailStr.trim().toLowerCase()}:${passStr?.trim() || ""}:mabala_salt_2026`;
    if (typeof window !== "undefined" && window.crypto && window.crypto.subtle) {
      try {
        const encoder = new TextEncoder();
        const data = encoder.encode(text);
        const hashBuffer = await window.crypto.subtle.digest("SHA-256", data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      } catch (e) {}
    }
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
      hash = ((hash << 5) - hash) + text.charCodeAt(i);
      hash |= 0;
    }
    return "hash_" + Math.abs(hash).toString(16);
  }, []);

  // Seed default cached session entries for demo/test and farm accounts on device
  useEffect(() => {
    const initializeAuthCache = async () => {
      const existing = localStorage.getItem("mabala_cached_auth_sessions");
      const cachedMap: Record<string, any> = existing ? JSON.parse(existing) : {};
      const demoHash1 = await hashCredential("mabalademo@mabala.cloud", "Mabala@2026");
      const demoHash2 = await hashCredential("shikasuli@gmail.com", "Mabala@2026");
      const dvHash = await hashCredential("deepvaleyfarm@gmail.com", "Zoiechibeka@2005");

      if (!cachedMap["mabalademo@mabala.cloud"]) {
        cachedMap["mabalademo@mabala.cloud"] = {
          email: "mabalademo@mabala.cloud",
          passwordHash: demoHash1,
          uid: "demo-uid-01",
          userProfile: {
            name: "Mabala Cloud Demo",
            email: "mabalademo@mabala.cloud",
            phone: "+260977889900",
            role: "Farm Owner",
            tenantType: "farmer"
          },
          role: "Farm Owner",
          tenantType: "farmer",
          lastSynced: new Date().toISOString()
        };
      }
      if (!cachedMap["shikasuli@gmail.com"]) {
        cachedMap["shikasuli@gmail.com"] = {
          email: "shikasuli@gmail.com",
          passwordHash: demoHash2,
          uid: "superadmin-uid-01",
          userProfile: {
            name: "Platform Administrator",
            email: "shikasuli@gmail.com",
            phone: "+260977889900",
            role: "Super Admin",
            tenantType: "super_admin"
          },
          role: "Super Admin",
          tenantType: "super_admin",
          lastSynced: new Date().toISOString()
        };
      }
      if (!cachedMap["deepvaleyfarm@gmail.com"]) {
        cachedMap["deepvaleyfarm@gmail.com"] = {
          email: "deepvaleyfarm@gmail.com",
          passwordHash: dvHash,
          uid: "dv-uid-001",
          userProfile: {
            name: "Deep Valley Farms",
            email: "deepvaleyfarm@gmail.com",
            phone: "+260978070734",
            role: "Farm Owner",
            tenantType: "farmer"
          },
          role: "Farm Owner",
          tenantType: "farmer",
          lastSynced: new Date().toISOString()
        };
        cachedMap["deepvalleyfarm@gmail.com"] = {
          ...cachedMap["deepvaleyfarm@gmail.com"],
          email: "deepvalleyfarm@gmail.com"
        };
      }
      localStorage.setItem("mabala_cached_auth_sessions", JSON.stringify(cachedMap));
    };
    initializeAuthCache();
  }, [hashCredential]);

  // Durable workspace initial restoration / hydration across page refreshes and offline boots
  useEffect(() => {
    const activeEmail = userProfile?.email || localStorage.getItem("mabala_last_login_id") || "deepvaleyfarm@gmail.com";
    FarmPersistenceService.loadFarmNodeWorkspace(activeEmail).then(snapshot => {
      if (snapshot) {
        if (farms.length === 0 || (farms.length === 1 && (farms[0].name === "My Farm Node" || !farms[0].tpin))) {
          if (snapshot.farms && snapshot.farms.length > 0) setFarms(snapshot.farms);
        }
        if (crops.length === 0 && snapshot.crops && snapshot.crops.length > 0) setCrops(snapshot.crops);
        if (expenses.length === 0 && snapshot.expenses && snapshot.expenses.length > 0) setExpenses(snapshot.expenses);
        if (invoices.length === 0 && snapshot.invoices && snapshot.invoices.length > 0) setInvoices(snapshot.invoices);
        if (livestock.length === 0 && snapshot.livestock && snapshot.livestock.length > 0) setLivestock(snapshot.livestock);
        if (poultry.length === 0 && snapshot.poultry && snapshot.poultry.length > 0) setPoultry(snapshot.poultry);
        if (fish.length === 0 && snapshot.fish && snapshot.fish.length > 0) setFish(snapshot.fish);
        if (inventory.length === 0 && snapshot.inventory && snapshot.inventory.length > 0) setInventory(snapshot.inventory);
        if (employees.length === 0 && snapshot.employees && snapshot.employees.length > 0) setEmployees(snapshot.employees);
        if (accounts.length === 0 && snapshot.accounts && snapshot.accounts.length > 0) setAccounts(snapshot.accounts);
        if (creditNotes.length === 0 && snapshot.creditNotes && snapshot.creditNotes.length > 0) setCreditNotes(snapshot.creditNotes);
        if (quotations.length === 0 && snapshot.quotations && snapshot.quotations.length > 0) setQuotations(snapshot.quotations);
        if (orchardNurseryBatches.length === 0 && snapshot.orchard_nursery_batches && snapshot.orchard_nursery_batches.length > 0) setOrchardNurseryBatches(snapshot.orchard_nursery_batches);
        if (orchardTrees.length === 0 && snapshot.orchard_trees && snapshot.orchard_trees.length > 0) setOrchardTrees(snapshot.orchard_trees);
        if (orchardActivities.length === 0 && snapshot.orchard_activities && snapshot.orchard_activities.length > 0) setOrchardActivities(snapshot.orchard_activities);
        if (cashSales.length === 0 && snapshot.cashSales && snapshot.cashSales.length > 0) setCashSales(snapshot.cashSales);
        if (loans.length === 0 && snapshot.loans && snapshot.loans.length > 0) setLoans(snapshot.loans);
        if (investments.length === 0 && snapshot.investments && snapshot.investments.length > 0) setInvestments(snapshot.investments);
        if (assets.length === 0 && snapshot.assets && snapshot.assets.length > 0) setAssets(snapshot.assets);
        if (otherRevenues.length === 0 && snapshot.otherRevenues && snapshot.otherRevenues.length > 0) setOtherRevenues(snapshot.otherRevenues);
        if (leaveRecords.length === 0 && snapshot.leaveRecords && snapshot.leaveRecords.length > 0) setLeaveRecords(snapshot.leaveRecords);
        if (employeeAdvances.length === 0 && snapshot.employeeAdvances && snapshot.employeeAdvances.length > 0) setEmployeeAdvances(snapshot.employeeAdvances);
        if (auditLogs.length === 0 && snapshot.auditLogs && snapshot.auditLogs.length > 0) setAuditLogs(snapshot.auditLogs);
        if (archivedRecords.length === 0 && snapshot.archivedRecords && snapshot.archivedRecords.length > 0) setArchivedRecords(snapshot.archivedRecords);
        if (credits === null && snapshot.credits !== undefined) setCredits(snapshot.credits);
        if (smsCredits === 0 && snapshot.smsCredits !== undefined) setSmsCredits(snapshot.smsCredits);
        if (snapshot.subscriptionTier) setSubscriptionTier(snapshot.subscriptionTier);
        if (snapshot.workspaceMode) setWorkspaceMode(snapshot.workspaceMode);
        if (snapshot.farmStatus) setFarmStatus(snapshot.farmStatus);
      }
    });
  }, []);

  // Silent background re-authentication & session reconciliation when connectivity is restored
  useEffect(() => {
    if (!isOfflineSession || !pendingOfflineCreds?.email || !pendingOfflineCreds?.password) return;

    let isReconciling = false;

    const handleSilentReconcile = async () => {
      if (isReconciling) return;
      if (typeof window !== "undefined" && !window.navigator.onLine) return;

      try {
        isReconciling = true;
        console.log("[Mabala Silent Re-Auth] Attempting background Firebase Auth re-authentication...");
        const userCred = await signInWithEmailAndPassword(auth, pendingOfflineCreds.email, pendingOfflineCreds.password);
        if (userCred && userCred.user) {
          console.log("[Mabala Silent Re-Auth] Successfully re-authenticated! Upgrading session from offline mode to verified online mode.");
          
          setIsOfflineSession(false);
          localStorage.removeItem("mabala_is_offline_session");
          sessionStorage.removeItem("mabala_pending_offline_creds");

          try {
            const passHash = await hashCredential(pendingOfflineCreds.email, pendingOfflineCreds.password);
            const cachedStr = localStorage.getItem("mabala_cached_auth_sessions");
            const cachedMap = cachedStr ? JSON.parse(cachedStr) : {};
            cachedMap[pendingOfflineCreds.email] = {
              ...cachedMap[pendingOfflineCreds.email],
              passwordHash: passHash,
              uid: userCred.user.uid,
              lastSynced: new Date().toISOString()
            };
            localStorage.setItem("mabala_cached_auth_sessions", JSON.stringify(cachedMap));
          } catch (e) {}

          await handleLoadCloudWorkspace(userCred.user.uid, pendingOfflineCreds.email);
          setPendingOfflineCreds(null);
          showToast("✅ Connectivity restored! Session verified with Firebase Auth & upgraded to online mode.", "success");
        }
      } catch (err) {
        console.warn("[Mabala Silent Re-Auth] Re-auth attempt pending (remaining in offline session):", err);
      } finally {
        isReconciling = false;
      }
    };

    handleSilentReconcile();
    window.addEventListener("online", handleSilentReconcile);
    const timer = setInterval(handleSilentReconcile, 8000);

    return () => {
      window.removeEventListener("online", handleSilentReconcile);
      clearInterval(timer);
    };
  }, [isOfflineSession, pendingOfflineCreds, isConfigured, hashCredential]);
  const [reactivatePassword, setReactivatePassword] = useState<string>("");
  const [isSubmittingReactivation, setIsSubmittingReactivation] = useState<boolean>(false);
  const [reactivateError, setReactivateError] = useState<string | null>(null);
  const [currentSessionId] = useState(() => Math.random().toString(36).substring(2) + Date.now().toString(36));
  const [sessionError, setSessionError] = useState<string | null>(null);
  const [isUnverifiedUser, setIsUnverifiedUser] = useState<boolean>(false);
  const [verificationEmailSentTo, setVerificationEmailSentTo] = useState<string | null>(null);
  // Dashboard Chart Configuration States
  const [chartType, setChartType] = useState<"bar" | "line">("bar");
  const [dateRange, setDateRange] = useState<"all" | "last30" | "q1_2026" | "q2_2026" | "h2_2025">("all");
  const [chartMode, setChartMode] = useState<"monthly" | "cumulative">("monthly");
  const [weatherAlerts, setWeatherAlerts] = useState<any[]>([]);
  const [showNewSaleModal, setShowNewSaleModal] = useState<boolean>(false);
  const [showEmailReceiptModal, setShowEmailReceiptModal] = useState<boolean>(false);
  const [emailReceiptSale, setEmailReceiptSale] = useState<SaleReceiptData | null>(null);
  const [globalSearchQuery, setGlobalSearchQuery] = useState("");
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [isAnimalWizardOpen, setIsAnimalWizardOpen] = useState(false);
  const [csvPreselectedType, setCsvPreselectedType] = useState<"expenses" | "crops" | "livestock" | null>(null);

  // Cloud Firestore save failure tracking & recovery state
  const [cloudSaveFailed, setCloudSaveFailed] = useState<boolean>(false);
  const [cloudSaveRetryCount, setCloudSaveRetryCount] = useState<number>(0);
  const [cloudSaveUserAcknowledged, setCloudSaveUserAcknowledged] = useState<boolean>(false);

  // Checkout setup database write failure state
  const [checkoutSetupError, setCheckoutSetupError] = useState<{
    error: string;
    email: string;
    paymentReference: string;
    uid: string;
    checkoutObj: any;
    retryType: "subscription" | "vendor-subscription" | "offtaker-subscription" | "partner-subscription";
  } | null>(null);
  const [identityReady, setIdentityReady] = useState(true);

  // Cache to track the last saved JSON-string representation of each module's state
  const lastSavedStatesRef = useRef<Record<string, string>>({});

  // Durable IndexedDB Offline Queue State
  const [offlineQueueState, setOfflineQueueState] = useState<OfflineQueueState>(() => offlineQueueService.getState());

  useEffect(() => {
    return offlineQueueService.subscribe((state) => {
      setOfflineQueueState(state);
    });
  }, []);

  useEffect(() => {
    fetchStatutoryTaxConfig().catch((err) => console.warn("[App] Statutory tax config fetch error:", err));
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Background Lipila payment reconciliation service: flags pending transactions > 1h as Timed Out
  useEffect(() => {
    const runReconciliation = async () => {
      try {
        const res = await reconcileLipilaTransactions(lipilaTransactions);
        if (res.timedOutCount > 0) {
          setLipilaTransactions(res.updatedTransactions);
        }
      } catch (err) {
        console.warn("[App] Lipila reconciliation background check failed:", err);
      }
    };

    runReconciliation();
    const intervalId = setInterval(runReconciliation, 5 * 60 * 1000);
    return () => clearInterval(intervalId);
  }, []);

  const handleGotoCsvImport = (type: "expenses" | "crops" | "livestock") => {
    setCsvPreselectedType(type);
    setActiveTab("csv-import");
  };

  const [activeFarmIndex, setActiveFarmIndex] = useState<number>(0);
  const [pendingTaxTypeChange, setPendingTaxTypeChange] = useState<{ targetTaxType: string } | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return window.innerWidth >= 1024;
    }
    return false;
  });

  // Click-away listener to close sidebar on small screens when clicking outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (window.innerWidth < 1024 && isSidebarOpen) {
        const sidebarEl = document.getElementById("mabala-sidebar");
        const toggleBtnMobile = document.querySelector("button[aria-label='Toggle Navigation Menu']");
        const toggleBtnDesktop = document.querySelector("button[title='Toggle Sidebar']");
        
        const target = e.target as Node;
        if (
          sidebarEl && 
          !sidebarEl.contains(target) && 
          (!toggleBtnMobile || !toggleBtnMobile.contains(target)) &&
          (!toggleBtnDesktop || !toggleBtnDesktop.contains(target))
        ) {
          setIsSidebarOpen(false);
        }
      }
    };
    document.addEventListener("mousedown", handleOutsideClick);
    return () => document.removeEventListener("mousedown", handleOutsideClick);
  }, [isSidebarOpen]);
  const [credits, setCredits] = useState<number | null>(null);
  const [parentProfile, setParentProfile] = useState<any>(null);
  const [smsCredits, setSmsCredits] = useState<number>(() => {
    const cached = localStorage.getItem("mabala_sms_credits");
    return cached !== null ? Number(cached) : 0;
  });
  const [creditLedger, setCreditLedger] = useState<any[]>([]);

  // Marketplace core states
  const [marketplaceVendors, setMarketplaceVendors] = useState<MarketVendor[]>(() => {
    const saved = localStorage.getItem("mabala_marketplace_vendors");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_VENDORS;
  });
  const [marketplaceProducts, setMarketplaceProducts] = useState<MarketplaceProduct[]>(() => {
    const saved = localStorage.getItem("mabala_marketplace_products");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_PRODUCTS;
  });
  const [marketplaceRiders, setMarketplaceRiders] = useState<BikeRider[]>(() => {
    const saved = localStorage.getItem("mabala_marketplace_riders");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_RIDERS;
  });
  const [marketplaceOrders, setMarketplaceOrders] = useState<MarketplaceOrder[]>(() => {
    const saved = localStorage.getItem("mabala_marketplace_orders");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_ORDERS;
  });
  const [marketplaceCommission, setMarketplaceCommission] = useState<number>(10);
  const [marketplaceDeliveryFeePerKm, setMarketplaceDeliveryFeePerKm] = useState<number>(5.0);

  const [adminClaimed, setAdminClaimed] = useState<boolean>(() => {
    return localStorage.getItem("mabala_admin_claimed") === "true";
  });

  const [adminClaimantEmail, setAdminClaimantEmail] = useState<string>(() => {
    return localStorage.getItem("mabala_admin_claimant_email") || "";
  });

  const [contactDetails, setContactDetails] = useState(() => {
    const saved = localStorage.getItem("mabala_contact_details");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.phone === "+260 977 112233" || parsed.whatsapp === "260977112233" || parsed.address?.includes("Great East Road") || parsed.address === "Block G, Great East Road, Lusaka, Zambia") {
          parsed.phone = "+260 978 070734";
          parsed.whatsapp = "260978070734";
          parsed.address = "Opp Oryx Filling Station, Mumbwa Road, Lusaka West";
          localStorage.setItem("mabala_contact_details", JSON.stringify(parsed));
        }
        return parsed;
      } catch (e) {}
    }
    return {
      email: "support@mabala.cloud",
      phone: "+260 978 070734",
      address: "Opp Oryx Filling Station, Mumbwa Road, Lusaka West",
      twitter: "https://twitter.com/mabala_saas",
      facebook: "https://facebook.com/mabala_saas",
      linkedin: "https://linkedin.com/company/mabala_saas",
      whatsapp: "260978070734"
    };
  });

  const [activeAds, setActiveAds] = useState(() => {
    const saved = localStorage.getItem("mabala_active_ads");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem("mabala_contact_details", JSON.stringify(contactDetails));
  }, [contactDetails]);

  useEffect(() => {
    const fetchMarketingPage = async () => {
      const docRef = doc(db, "platformConfig", "marketingPage");
      let snap = null;
      try {
        snap = await getDoc(docRef);
      } catch (err) {
        // Fallback to cache if offline
        try {
          snap = await getDocFromCache(docRef);
        } catch (cacheErr) {
          console.warn("[App] marketingPage config unavailable offline:", cacheErr);
        }
      }
      if (snap && snap.exists()) {
        const data = snap.data();
        if (data) {
          setContactDetails(prev => ({
            ...prev,
            ...data
          }));
          if (data.ads) {
            setActiveAds(data.ads);
          }
        }
      }
    };
    fetchMarketingPage();
  }, []);

  useEffect(() => {
    localStorage.setItem("mabala_active_ads", JSON.stringify(activeAds));
  }, [activeAds]);

  useEffect(() => {
    localStorage.setItem("mabala_marketplace_vendors", JSON.stringify(marketplaceVendors));
  }, [marketplaceVendors]);

  useEffect(() => {
    localStorage.setItem("mabala_marketplace_products", JSON.stringify(marketplaceProducts));
  }, [marketplaceProducts]);

  useEffect(() => {
    localStorage.setItem("mabala_marketplace_riders", JSON.stringify(marketplaceRiders));
  }, [marketplaceRiders]);

  useEffect(() => {
    localStorage.setItem("mabala_marketplace_orders", JSON.stringify(marketplaceOrders));
  }, [marketplaceOrders]);

  // Auto-sync Onboarded Agro-Dealer SKUs and Supplier Catalog into Farmer-facing Marketplace products list
  useEffect(() => {
    const doAutoSync = () => {
      try {
        const savedSkus = localStorage.getItem("mabala_agd_skus");
        const skus = savedSkus ? JSON.parse(savedSkus) : INITIAL_AGRO_SKUS;

        const savedDealers = localStorage.getItem("mabala_agd_dealers");
        const dealers = savedDealers ? JSON.parse(savedDealers) : INITIAL_AGRO_DEALERS;

        const savedSupplierCat = localStorage.getItem("mabala_supplier_catalog");
        const supplierCatalog = savedSupplierCat ? JSON.parse(savedSupplierCat) : [];

        const savedSuppliers = localStorage.getItem("mabala_suppliers");
        const suppliersList = savedSuppliers ? JSON.parse(savedSuppliers) : [];

        // Purge legacy dummy listings from localStorage
        purgeMarketplaceDummyListings(dealers, suppliersList);

        const { marketplaceProducts: liveProducts, vendors: liveVendors } = syncAgroSKUsToMarketplaceProducts(
          skus,
          dealers,
          DEFAULT_FARMER_LOCATION,
          supplierCatalog,
          suppliersList
        );

        // Merge vendors: live agrodealers & suppliers + active custom merchant storefronts
        setMarketplaceVendors(prev => {
          const mergedMap = new Map<string, any>();
          prev.forEach(v => {
            if (v && v.status === "Active" && (v.id.startsWith("vend-custom-") || dealers.some(d => d.id === v.id) || suppliersList.some(s => s.id === v.id))) {
              mergedMap.set(v.id, v);
            }
          });
          liveVendors.forEach(v => mergedMap.set(v.id, v));
          return Array.from(mergedMap.values());
        });

        // Products: exclusively include live listings posted by onboarded agrodealers and suppliers, plus active custom merchant storefronts
        setMarketplaceProducts(prev => {
          const customMerchantProducts = prev.filter(p => p.id.startsWith("prod-custom-") && p.isActive !== false);
          return [...customMerchantProducts, ...liveProducts];
        });
      } catch (err) {
        console.error("Failed to auto-sync Agro-Dealer & Supplier listings to Marketplace:", err);
      }
    };

    doAutoSync();

    // Listen for storage events across tabs or local updates
    window.addEventListener("storage", doAutoSync);
    return () => window.removeEventListener("storage", doAutoSync);
  }, []);

  // Role and Granular Permission states (Strictly verified against authenticated session)
  const [currentRole, setCurrentRole] = useState<PredefinedRole>(() => {
    const verified = IdentityIntegrityService.getVerifiedCachedProfile(auth.currentUser);
    if (verified) {
      const r = verified.role || verified.tenantType;
      if (r === "Agro Dealer" || r === "agro_dealer") return "Agro Dealer";
      if (r === "Institution Supplier" || r === "institution_supplier" || r === "Supplier") return "Institution Supplier";
      if (r === "Super Admin" || r === "super_admin") {
        if (SUPER_ADMIN_EMAILS.includes((verified.email || "").toLowerCase())) {
          return "Super Admin";
        }
        return "Farm Owner";
      }
      if (r) return r as PredefinedRole;
    }
    return "Farm Owner";
  });
  const [permissions, setPermissions] = useState<RolePermissionsMap>(DEFAULT_PERMISSIONS);
  const [impersonation, setImpersonation] = useState<{
    targetUid: string;
    targetTenantId?: string;
    targetEmail: string;
    targetFarmId: string;
    targetFarmName?: string;
    targetPhone?: string;
    targetFarmNode?: any;
    targetProfile?: any;
    sessionEpoch: string;
    initiatedBy: string;
    superAdminUid: string;
    superAdminEmail: string;
    startedAt: string;
    expiresAt: string;
    originalUserProfile: any;
    originalFarms: any[];
    originalActiveFarmIndex?: number;
    originalRole: any;
    originalCredits: number;
    originalSubscriptionTier: string;
    originalWorkspaceMode: string;
    targetActualRole?: string;
    targetActualTenantType?: string;
    remoteAccessSessionId?: string;
    targetOwnerId?: string;
  } | null>(null);
  const [sessionTimeLeft, setSessionTimeLeft] = useState<number>(3600);

  // Derived activeProfile selector (Prompt Section 3.1 & 3.4)
  // Single derived source of truth UI components read for identity and display.
  // During impersonation, resolves to targetProfile with targetUid/targetTenantId/targetEmail.
  // When not impersonating, resolves cleanly to userProfile.
  const activeProfile = useMemo(() => {
    if (impersonation && impersonation.targetProfile) {
      const prof = impersonation.targetProfile;
      const expectedUid = impersonation.targetUid;
      const expectedTenantId = impersonation.targetTenantId || impersonation.targetUid;

      // UID / Tenant Integrity Check (Section 3.4)
      const profUid = prof.uid || prof.id || prof.tenantUid;
      if (profUid && profUid !== expectedUid) {
        console.warn(`[Integrity Check] Target profile UID mismatch: expected=${expectedUid}, actual=${profUid}`);
        try {
          if (db) {
            setDoc(doc(db, "super_admin_audit", `mismatch-${Date.now()}`), {
              actionType: "access_node_integrity_mismatch",
              adminUid: impersonation.superAdminUid,
              targetUid: expectedUid,
              expectedUid,
              actualUid: profUid,
              timestamp: new Date().toISOString()
            }).catch(() => {});
          }
        } catch (_) {}
      }

      if (!isProfileIntegrityValid(prof, expectedUid, expectedTenantId)) {
        return null;
      }

      return Object.freeze({
        ...prof,
        uid: expectedUid,
        tenantId: expectedTenantId,
        email: impersonation.targetEmail,
        name: prof.name || prof.displayName || (impersonation.targetFarmName ? `${impersonation.targetFarmName} Owner` : "Farm Owner"),
        role: impersonation.targetActualRole || prof.role || "Farm Owner",
        tenantType: impersonation.targetActualTenantType || prof.tenantType || "farmer",
        phone: prof.phone || prof.phoneNumber || impersonation.targetPhone || ""
      });
    }
    return userProfile;
  }, [impersonation, userProfile]);

  const { isSuperAdmin, isLoading: isSuperAdminLoading } = useSuperAdmin();

  // Dynamic ERP database
  const [farms, setFarms] = useState<Farm[]>(() => {
    const cached = localStorage.getItem("mabala_farms");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {}
    }

    const userProfStr = localStorage.getItem("mabala_user_profile");
    let uProf: any = null;
    if (userProfStr) {
      try { uProf = JSON.parse(userProfStr); } catch (e) {}
    }

    const regFarmName = localStorage.getItem("mabala_registered_farm_name") || localStorage.getItem("mabala_farm_name") || uProf?.farmName || "Sunrise Agro-Tech Farm";
    const regProv = localStorage.getItem("mabala_farm_province") || uProf?.province || "";
    const regDist = localStorage.getItem("mabala_farm_district") || uProf?.district || uProf?.town || "";
    const regPhone = localStorage.getItem("mabala_farm_phone") || uProf?.phone || "";
    const regEmail = localStorage.getItem("mabala_farm_email") || uProf?.email || "";
    const regTpin = localStorage.getItem("mabala_farm_tpin") || uProf?.tpin || "";
    const regAddr = localStorage.getItem("mabala_farm_address") || (regDist && regProv ? `${regDist}, ${regProv}, Zambia` : "Lusaka, Zambia");
    const loc = regProv && regDist ? resolveDistrictCoordinates(regProv, regDist) : { lat: -15.4167, lng: 28.2833 };

    return [
      {
        id: "farm-1",
        name: regFarmName,
        letterheadTitle: regFarmName,
        letterheadSubtitle: "Corporate Agricultural Operations",
        letterheadAddress: regAddr,
        tpin: regTpin,
        vatNumber: "",
        address: regAddr,
        province: regProv,
        district: regDist,
        town: regDist,
        location: {
          province: regProv,
          district: regDist,
          lat: loc.lat,
          lng: loc.lng
        },
        farmLocation: loc,
        latitude: loc.lat,
        longitude: loc.lng,
        phone: regPhone,
        email: regEmail,
        financialYearStart: "2026-01-01",
        financialYearEnd: "2026-12-31",
        currency: "ZMW",
        currencySymbol: "K",
        taxSystem: "TOT_5",
        taxType: "TOT_5"
      }
    ];
  });

  const activeFarm: Farm = farms[activeFarmIndex] || farms[0] || DEFAULT_FALLBACK_FARM;

  const [teamMembers, setTeamMembers] = useState<UserMember[]>(DEFAULT_TEAM_MEMBERS);

  // Synchronize team members for the active farm node from UserService
  useEffect(() => {
    let isMounted = true;
    const fetchMembers = async () => {
      const tenantId = activeFarm?.id || userProfile?.tenantId || "TENANT-001";
      try {
        const members = await UserService.getFarmNodeUsers(tenantId);
        if (isMounted && members && members.length > 0) {
          setTeamMembers(members);
        }
      } catch (err) {
        console.warn("[App] Could not load farm node team members:", err);
      }
    };
    fetchMembers();
    return () => { isMounted = false; };
  }, [activeFarm?.id, userProfile?.tenantId]);

  const [subscriptionTier, setSubscriptionTier] = useState<string>(() => {
    return localStorage.getItem("mabala_subscription_tier") || "Commercial Growth Layer";
  });
  const [workspaceMode, setWorkspaceMode] = useState<"Farmer" | "Veterinary" | "Offtaker" | "Partner">(() => {
    return (localStorage.getItem("mabala_workspace_mode") as any) || "Farmer";
  });
  const [vetFeeActivation, setVetFeeActivation] = useState<boolean>(() => {
    return localStorage.getItem("mabala_vet_fee_activation") !== "false";
  });
  const [farmStatus, setFarmStatus] = useState<"ACTIVE" | "FROZEN" | "SUSPENDED" | string>(() => {
    return localStorage.getItem("mabala_farm_status") || "ACTIVE";
  });

  useEffect(() => {
    const STRICT_PLATFORM_ADMIN_TABS = [
      "platform-admin",
      "resellers",
      "lipila-payment-tracker",
      "agrodealer-consignment",
      "agc-super-admin",
      "permissions",
      "audit-archive",
      "mabala-consignment-admin"
    ];

    if (STRICT_PLATFORM_ADMIN_TABS.includes(activeTab) && !isSuperAdminLoading) {
      const userMailLower = (userProfile.email || auth.currentUser?.email || "").trim().toLowerCase();
      const isSuperEmail = SUPER_ADMIN_EMAILS.includes(userMailLower) || userMailLower === "support@mabala.cloud" || userMailLower === "shikasuli@gmail.com";
      const isAuthorized = (isSuperEmail || Boolean(impersonation)) && isSuperAdmin;
      if (!isAuthorized) {
        console.warn(`Direct access to '${activeTab}' denied for tenant '${userMailLower}'. Platform Admin is restricted to Super Admin (support@mabala.cloud).`);
        const fallback = workspaceMode === "Offtaker" ? "offtaker-marketplace"
          : workspaceMode === "Partner" ? "partner-portal"
          : currentRole === "Agro Dealer" ? "agc-dealer-pos"
          : currentRole === "Institution Supplier" ? "agc-financier-portal"
          : currentRole === "Agronomist" ? "advisory-portal"
          : "dashboard";
        setActiveTab(fallback);
      }
    }
  }, [activeTab, isSuperAdmin, isSuperAdminLoading, currentRole, userProfile.email, impersonation, workspaceMode]);

  const [notifications, setNotifications] = useState<any[]>([]);
  const addNotification = (message: string, type: "success" | "warning" | "info" | "error" = "info") => {
    const id = "notif-" + Date.now() + Math.random().toString(36).substr(2, 5);
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000);
  };

  // Multi-Country and Currency Localization states
  const [selectedCountry, setSelectedCountry] = useState<CountryInfo>(COUNTRIES[0]); // Default Zambia

  // Zambia-Applicable Default Vaccination Schedule (Poultry & Swine)
  const [defaultVaccinationSchedule, setDefaultVaccinationSchedule] = useState<DefaultVaccineScheduleItem[]>([
    // Poultry Schedule
    { id: "zvs-1", age: "Day 1", ageInDays: 1, vaccine: "Marek's Disease", diseaseTarget: "Marek's Disease Virus", route: "SC Injection", birdType: "Broiler/Layer", species: "Poultry", booster: "No" },
    { id: "zvs-2", age: "Day 1", ageInDays: 1, vaccine: "ND + IB (Clone 30)", diseaseTarget: "Newcastle / Infectious Bronchitis", route: "Eye Drop", birdType: "Broiler/Layer", species: "Poultry", booster: "Yes – Wk 3" },
    { id: "zvs-3", age: "Day 7", ageInDays: 7, vaccine: "Gumboro (IBD) Mild", diseaseTarget: "Infectious Bursal Disease", route: "Drinking Water", birdType: "Broiler/Layer", species: "Poultry", booster: "Day 14" },
    { id: "zvs-4", age: "Day 14", ageInDays: 14, vaccine: "Gumboro (IBD) Intermed.", diseaseTarget: "Infectious Bursal Disease Boost", route: "Drinking Water", birdType: "Broiler/Layer", species: "Poultry", booster: "No" },
    { id: "zvs-5", age: "Day 18", ageInDays: 18, vaccine: "ND La Sota", diseaseTarget: "Newcastle Disease Boost", route: "Eye Drop / Water", birdType: "Broiler/Layer", species: "Poultry", booster: "Wk 8" },
    { id: "zvs-6", age: "Week 5", ageInDays: 35, vaccine: "Fowl Pox", diseaseTarget: "Avipoxvirus", route: "Wing Web Stab", birdType: "Layer only", species: "Poultry", booster: "No" },
    { id: "zvs-7", age: "Week 8", ageInDays: 56, vaccine: "ND + IB Bivalent", diseaseTarget: "Newcastle / Bronchitis", route: "Drinking Water", birdType: "Layer only", species: "Poultry", booster: "Wk 16" },
    { id: "zvs-8", age: "Week 12", ageInDays: 84, vaccine: "Egg Drop Syndrome (EDS)", diseaseTarget: "EDS-76 Virus", route: "IM Injection", birdType: "Layer only", species: "Poultry", booster: "No" },
    { id: "zvs-9", age: "Week 16", ageInDays: 112, vaccine: "ND + IB Final Pre-Lay", diseaseTarget: "Pre-Lay Booster", route: "IM Injection", birdType: "Layer only", species: "Poultry", booster: "Annually" },
    
    // Swine / Pig Schedule
    { id: "pvs-1", age: "Day 21 (Weaning)", ageInDays: 21, vaccine: "Mycoplasma Hyopneumoniae", diseaseTarget: "Enzootic Pneumonia", route: "IM Injection", birdType: "Piglets / Weaners", species: "Swine", booster: "Day 35" },
    { id: "pvs-2", age: "Day 21 (Weaning)", ageInDays: 21, vaccine: "PCV2 (Porcine Circovirus)", diseaseTarget: "Post-Weaning Multisystemic Wasting", route: "IM Injection", birdType: "Piglets / Weaners", species: "Swine", booster: "No" },
    { id: "pvs-3", age: "Week 8 (56 Days)", ageInDays: 56, vaccine: "Erysipelas (Rhusiopathiae)", diseaseTarget: "Diamond Skin Disease / Erysipelas", route: "SC Injection", birdType: "Growers / Finishers", species: "Swine", booster: "Semi-Annually" },
    { id: "pvs-4", age: "Week 12 (84 Days)", ageInDays: 84, vaccine: "Parvovirus + Leptospirosis (Parvo/Lepto)", diseaseTarget: "Porcine Parvovirus & Leptospirosis", route: "IM Injection", birdType: "Gilt / Sow / Boar", species: "Swine", booster: "Pre-Breeding / Annual" },
    { id: "pvs-5", age: "Pre-Farrowing (Wk 12 Gestation)", ageInDays: 100, vaccine: "E. Coli + Clostridium Perfringens", diseaseTarget: "Neonatal Scours & Diarrhea", route: "IM Injection", birdType: "Gilt / Sow", species: "Swine", booster: "2 Wks Pre-Farrow" }
  ]);

  const [accounts, setAccounts] = useState<Account[]>(() => {
    const cached = localStorage.getItem("mabala_accounts");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return INITIAL_ACCOUNTS.map(a => ({ ...a, balance: 0 }));
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    const cached = localStorage.getItem("mabala_suppliers");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const cached = localStorage.getItem("mabala_customers");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [expenses, setExpenses] = useState<ExpenseTransaction[]>(() => {
    const cached = localStorage.getItem("mabala_expenses");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    const cached = localStorage.getItem("mabala_invoices");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [creditNotes, setCreditNotes] = useState<CreditNote[]>(() => {
    const cached = localStorage.getItem("mabala_credit_notes");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [quotations, setQuotations] = useState<Quotation[]>(() => {
    const cached = localStorage.getItem("mabala_quotations");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [crops, setCrops] = useState<CropCycle[]>(() => {
    const cached = localStorage.getItem("mabala_crops");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    const cached = localStorage.getItem("mabala_employees");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [payslips, setPayslips] = useState<Payslip[]>(() => {
    const cached = localStorage.getItem("mabala_payslips");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [poultry, setPoultry] = useState<PoultryBatch[]>(() => {
    const cached = localStorage.getItem("mabala_poultry");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [fish, setFish] = useState<FishBatch[]>(() => {
    const cached = localStorage.getItem("mabala_fish");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [orchardNurseryBatches, setOrchardNurseryBatches] = useState<OrchardNurseryBatch[]>(() => {
    const cached = localStorage.getItem("mabala_orchard_nursery_batches");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [orchardTrees, setOrchardTrees] = useState<OrchardTree[]>(() => {
    const cached = localStorage.getItem("mabala_orchard_trees");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [orchardActivities, setOrchardActivities] = useState<OrchardActivity[]>(() => {
    const cached = localStorage.getItem("mabala_orchard_activities");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [inventory, setInventory] = useState<InventoryItem[]>(() => {
    const cached = localStorage.getItem("mabala_inventory");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  // Compute Financial Impact of Losses for the Quick Log Loss Modal second chart
  const financialLossData: CropFinancialLossItem[] = useMemo(() => {
    const cropCostMap: Record<string, number> = {};
    inventory.forEach(item => {
      const key = item.name.toLowerCase();
      if (item.unitCost > 0) {
        cropCostMap[key] = item.unitCost;
      }
    });

    const getCost = (cropName: string, defaultCost: number) => {
      const k = cropName.toLowerCase();
      for (const [invName, cost] of Object.entries(cropCostMap)) {
        if (invName.includes(k) || k.includes(invName)) return cost;
      }
      return defaultCost;
    };

    const selectedCropKeyword = quickLossCrop.split(" ")[0].toLowerCase();

    const opConfig = getFarmOperationalConfig();
    const crops = opConfig.cropLossDefaults && opConfig.cropLossDefaults.length > 0
      ? opConfig.cropLossDefaults
      : [
          { name: "Maize SC 719", defaultCost: 0, defaultLoss: 0 },
          { name: "Soybeans MRI 514", defaultCost: 0, defaultLoss: 0 },
          { name: "Irrigated Wheat", defaultCost: 0, defaultLoss: 0 },
          { name: "Sorghum Red", defaultCost: 0, defaultLoss: 0 }
        ];

    return crops.map(c => {
      const isSelected = c.name.toLowerCase().includes(selectedCropKeyword);
      const lossKg = isSelected ? quickLossQty : c.defaultLoss;
      const unitCost = getCost(c.name, c.defaultCost);
      const impact = Number((lossKg * unitCost).toFixed(2));

      return {
        crop: c.name,
        lossKg,
        unitCost,
        financialImpact: impact
      };
    });
  }, [inventory, quickLossCrop, quickLossQty]);

  const handleFlushOfflineQueue = useCallback(async () => {
    if (typeof window !== "undefined" && !window.navigator.onLine) {
      showToast("⚠️ Device is currently offline. Offline queue will auto-flush when internet connection returns.", "warning");
      return;
    }
    if (!isConfigured) return;

    const currentUser = auth.currentUser;
    const targetUid = impersonation ? impersonation.targetUid : (userProfile?.tenantId || currentUser?.uid || "guest_uid");
    if (!targetUid || targetUid === "guest_uid") return;

    console.log(`[Offline Sync Engine] Flushing queue for target UID ${targetUid}...`);

    const result = await offlineQueueService.flushQueue(async (item: OfflineQueueItem) => {
      console.log(`[Offline Sync Executor] Syncing item "${item.summaryLabel}" (Original capture timestamp: ${item.clientTimestamp})...`);
      const effectiveUid = item.targetUid || targetUid;

      if (item.actionType === "WORKSPACE_FULL_SAVE" || item.actionType === "MODULE_WRITE") {
        if (item.moduleKey) {
          const modDocRef = doc(db, "users_data", effectiveUid, "modules", item.moduleKey);
          await setDoc(modDocRef, {
            data: item.payload,
            updatedAt: new Date().toISOString(),
            clientCapturedAt: item.clientTimestamp, // REQUIREMENT: Tagged with original client-side timestamp
            syncedAt: new Date().toISOString()
          }, { merge: true });
        } else {
          const parentDocRef = doc(db, "users_data", effectiveUid);
          await setDoc(parentDocRef, {
            ...item.payload,
            updatedAt: new Date().toISOString(),
            clientCapturedAt: item.clientTimestamp,
            syncedAt: new Date().toISOString()
          }, { merge: true });
        }
        return true;
      } else if (item.actionType === "QUICK_LOG_LOSS") {
        const lossRef = doc(db, "users_data", effectiveUid, "loss_records", item.id);
        await setDoc(lossRef, {
          ...item.payload,
          clientCapturedAt: item.clientTimestamp,
          syncedAt: new Date().toISOString()
        }, { merge: true });
        return true;
      } else {
        const genRef = doc(db, "users_data", effectiveUid, "offline_sync_log", item.id);
        await setDoc(genRef, {
          payload: item.payload,
          actionType: item.actionType,
          clientCapturedAt: item.clientTimestamp,
          syncedAt: new Date().toISOString()
        }, { merge: true });
        return true;
      }
    });

    if (result.successCount > 0) {
      const moduleNames = result.syncedModules && result.syncedModules.length > 0
        ? result.syncedModules
        : Array.from(new Set((result.syncedItems || []).map(item => formatModuleName(item))));
      
      const formattedModulesList = moduleNames.length > 0 
        ? moduleNames.map(m => `'${m}'`).join(", ")
        : "'Workspace Data'";

      showToast(`✅ Cloud Reconnection Sync Complete! Successfully synced ${result.successCount} offline change${result.successCount > 1 ? "s" : ""} to the cloud for modules: ${formattedModulesList}.`, "success");
    }
    if (result.failureCount > 0) {
      showToast(`⚠️ ${result.failureCount} queued item${result.failureCount > 1 ? "s" : ""} failed to sync and remain saved in offline retry queue.`, "warning");
    }
  }, [isConfigured, impersonation, userProfile, showToast]);

  const uploadLocalSessionsToFirestore = useCallback(async () => {
    if (!isConfigured || (typeof window !== "undefined" && !window.navigator.onLine)) return;
    try {
      const cachedStr = localStorage.getItem("mabala_cached_auth_sessions");
      if (cachedStr) {
        const sessions = JSON.parse(cachedStr);
        for (const [emailKey, sessionData] of Object.entries<any>(sessions)) {
          if (sessionData && sessionData.uid) {
            const uRef = doc(db, "users_data", sessionData.uid);
            await setDoc(uRef, {
              email: (sessionData.email || emailKey).toLowerCase(),
              role: sessionData.role,
              tenantType: sessionData.tenantType,
              lastSyncedLocalSession: new Date().toISOString(),
              offlineSessionUploaded: true
            }, { merge: true });
          }
        }
        console.log("[Mabala Auth Sync] Successfully uploaded cached local sessions to Firestore.");
      }
    } catch (err) {
      console.warn("[Mabala Auth Sync] Non-critical local sessions sync note:", err);
    }
  }, [isConfigured]);

  // Flush queue and sync local sessions on online reconnect or periodic check
  useEffect(() => {
    const handleOnlineFlush = async () => {
      console.log("[Mabala Sync] Connection restored! Flushing offline queue and uploading persistent workspaces...");
      setIsOnline(true);
      uploadLocalSessionsToFirestore();
      await handleFlushOfflineQueue();
      const currentUser = auth.currentUser;
      if (currentUser) {
        await handleSaveCloudWorkspace(currentUser.uid);
      }
    };

    window.addEventListener("online", handleOnlineFlush);

    // Initial check on mount
    if (typeof window !== "undefined" && window.navigator.onLine) {
      uploadLocalSessionsToFirestore();
    }

    const interval = setInterval(() => {
      if (typeof window !== "undefined" && window.navigator.onLine && offlineQueueState.pendingCount > 0 && !offlineQueueState.isFlushing) {
        handleFlushOfflineQueue();
      }
    }, 12000);

    return () => {
      window.removeEventListener("online", handleOnlineFlush);
      clearInterval(interval);
    };
  }, [handleFlushOfflineQueue, uploadLocalSessionsToFirestore, offlineQueueState.pendingCount, offlineQueueState.isFlushing]);

  const [cashSales, setCashSales] = useState<CashSale[]>(() => {
    const cached = localStorage.getItem("mabala_cash_sales");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [loans, setLoans] = useState<Loan[]>(() => {
    const cached = localStorage.getItem("mabala_loans");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [investments, setInvestments] = useState<Investment[]>(() => {
    const cached = localStorage.getItem("mabala_investments");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [livestock, setLivestock] = useState<LivestockRecord[]>(() => {
    const cached = localStorage.getItem("mabala_livestock");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  // New modules states
  const [assets, setAssets] = useState<Asset[]>(() => {
    const cached = localStorage.getItem("mabala_assets");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [tasks, setTasks] = useState<FarmTask[]>(() => {
    const cached = localStorage.getItem("mabala_tasks");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });


  const [otherRevenues, setOtherRevenues] = useState<OtherRevenue[]>(() => {
    const cached = localStorage.getItem("mabala_other_revenues");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [leaveRecords, setLeaveRecords] = useState<LeaveRecord[]>(() => {
    const cached = localStorage.getItem("mabala_leave_records");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [employeeAdvances, setEmployeeAdvances] = useState<EmployeeAdvance[]>(() => {
    const cached = localStorage.getItem("mabala_employee_advances");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const cached = localStorage.getItem("mabala_audit_logs");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [archivedRecords, setArchivedRecords] = useState<ArchiveRecord[]>(() => {
    const cached = localStorage.getItem("mabala_archived_records");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  // Global Confirmation Dialog for bulk and sensitive deletion actions
  const [globalConfirm, setGlobalConfirm] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    isBulk?: boolean;
    itemCount?: number;
    itemNames?: string[];
    onConfirm: () => void;
  } | null>(null);

  useEffect(() => {
    (window as any).triggerGlobalConfirm = (opts: {
      title: string;
      message: string;
      isBulk?: boolean;
      itemCount?: number;
      itemNames?: string[];
      onConfirm: () => void;
    }) => {
      setGlobalConfirm({
        isOpen: true,
        title: opts.title,
        message: opts.message,
        isBulk: opts.isBulk ?? false,
        itemCount: opts.itemCount ?? 0,
        itemNames: opts.itemNames ?? [],
        onConfirm: () => {
          opts.onConfirm();
          setGlobalConfirm(null);
        }
      });
    };
    return () => {
      delete (window as any).triggerGlobalConfirm;
    };
  }, []);

  // Modals / top-up triggers
  const [showTopUpModal, setShowTopUpModal] = useState<boolean>(false);
  const [hideReadonlyBanner, setHideReadonlyBanner] = useState<boolean>(false);
  const [readOnlyBlockedAction, setReadOnlyBlockedAction] = useState<string | null>(null);
  const [showFarmConfigModal, setShowFarmConfigModal] = useState<boolean>(false);
  const [showFarmSwitcherDropdown, setShowFarmSwitcherDropdown] = useState<boolean>(false);
  const [farmSearchQuery, setFarmSearchQuery] = useState<string>("");

  // Live Lipila Payment Terminal State
  const [activeAccessPass, setActiveAccessPass] = useState<any>(() => {
    const cached = localStorage.getItem("mabala_active_access_pass");
    if (cached) {
      try {
        const pass = JSON.parse(cached);
        if (new Date(pass.expiresAt) > new Date()) {
          return pass;
        }
      } catch (e) {}
    }
    return null;
  });

  useEffect(() => {
    if (activeAccessPass) {
      const expiresAt = new Date(activeAccessPass.expiresAt);
      if (expiresAt <= new Date()) {
        setActiveAccessPass(null);
        localStorage.removeItem("mabala_active_access_pass");
      } else {
        localStorage.setItem("mabala_active_access_pass", JSON.stringify(activeAccessPass));
        const diff = expiresAt.getTime() - Date.now();
        const timer = setTimeout(() => {
          setActiveAccessPass(null);
          localStorage.removeItem("mabala_active_access_pass");
        }, diff);
        return () => clearTimeout(timer);
      }
    } else {
      localStorage.removeItem("mabala_active_access_pass");
    }
  }, [activeAccessPass]);

  // Daily unmetered bundle configuration state & real-time countdown engine
  const [dailyBundleExpiresAt, setDailyBundleExpiresAt] = useState<string | null>(() => {
    const cached = localStorage.getItem("mabala_daily_bundle_expires_at");
    if (cached) {
      if (new Date(cached) > new Date()) {
        return cached;
      } else {
        localStorage.removeItem("mabala_daily_bundle_expires_at");
      }
    }
    return null;
  });

  const [dailyBundleTimeLeft, setDailyBundleTimeLeft] = useState<string | null>(null);

  useEffect(() => {
    if (!dailyBundleExpiresAt) {
      setDailyBundleTimeLeft(null);
      return;
    }

    const checkAndTick = () => {
      const expiry = new Date(dailyBundleExpiresAt).getTime();
      const now = Date.now();
      const diff = expiry - now;

      if (diff <= 0) {
        setDailyBundleExpiresAt(null);
        localStorage.removeItem("mabala_daily_bundle_expires_at");
        setSubscriptionTier("Free Plan");
        setDailyBundleTimeLeft(null);
      } else {
        const hours = Math.floor(diff / (60 * 60 * 1000));
        const minutes = Math.floor((diff % (60 * 60 * 1000)) / (60 * 1000));
        const seconds = Math.floor((diff % (60 * 1000)) / 1000);
        setDailyBundleTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
      }
    };

    checkAndTick();
    const interval = setInterval(checkAndTick, 1000);
    return () => clearInterval(interval);
  }, [dailyBundleExpiresAt]);

  const [lipilaCheckout, setLipilaCheckout] = useState<{
    type: "subscription" | "credits";
    name: string;
    price: number;
    currency?: string;
    creditsToAward: number;
    description: string;
    registrationData?: any;
    is_unmetered_access?: boolean;
    duration_hours?: number;
  } | null>(null);

  const [lipilaPhone, setLipilaPhone] = useState("");
  const [lipilaHolderName, setLipilaHolderName] = useState("");
  const [lipilaSearchingName, setLipilaSearchingName] = useState(false);
  const [lipilaPaymentStatus, setLipilaPaymentStatus] = useState<"Idle" | "Submitting" | "Pending" | "Successful" | "Failed">("Idle");
  const [lipilaRefId, setLipilaRefId] = useState("");
  const [lipilaError, setLipilaError] = useState("");
  const [lipilaPollingCount, setLipilaPollingCount] = useState(0);
  const [lipilaPin, setLipilaPin] = useState("");
  const [lipilaTimeRemaining, setLipilaTimeRemaining] = useState(60);
  const [welcomeKey, setWelcomeKey] = useState<number>(0);

  // Transactions logs for Super Admin auditing
  const [lipilaTransactions, setLipilaTransactions] = useState<any[]>([]);

  const [lipilaRetryTrigger, setLipilaRetryTrigger] = useState<number>(0);

  const lipilaPollingIntervalRef = useRef<any>(null);
  const lipilaFulfilledRefId = useRef<string | null>(null);
  const lipilaIsFetchingRef = useRef<boolean>(false);

  // Real-time Firestore workspace listeners & pending writes tracking for instant optimistic sync
  const workspaceListenersUnsubRef = useRef<(() => void)[]>([]);
  const activeListenerIdentityRef = useRef<string | null>(null);
  const workspaceListenerGenerationRef = useRef(0);
  const [hasPendingWrites, setHasPendingWrites] = useState<boolean>(false);

  // Single-Active-Session & Reconciliation Queue state
  const [takeoverInfo, setTakeoverInfo] = useState<SessionTerminationInfo | null>(null);
  const [isTakeoverModalOpen, setIsTakeoverModalOpen] = useState<boolean>(false);
  const [rejectedWrites, setRejectedWrites] = useState<RejectedWriteRecord[]>([]);
  const [isRejectedWritesModalOpen, setIsRejectedWritesModalOpen] = useState<boolean>(false);

  const handleReclaimSession = async () => {
    const currentUser = auth.currentUser;
    if (!currentUser) return;
    try {
      const token = await currentUser.getIdToken();
      await sessionService.claimSession(currentUser.uid, token);
      setIsTakeoverModalOpen(false);
      setTakeoverInfo(null);
      showToast("Session successfully reclaimed on this device.", "success");
    } catch (err: any) {
      console.error("[Session Reclaim Error]:", err);
      showToast(err.message || "Failed to reclaim session", "error");
    }
  };

  const cleanupWorkspaceListeners = () => {
    workspaceListenerGenerationRef.current += 1;
    workspaceListenersUnsubRef.current.forEach((unsub) => {
      try {
        unsub();
      } catch (e) {
        console.warn("[Mabala Cloud] Listener cleanup note:", e);
      }
    });
    workspaceListenersUnsubRef.current = [];
    activeListenerIdentityRef.current = null;
    accessNodeListenerRegistry.stopAll();
  };

  // Cloud Firestore persistent real-time onSnapshot load/save handlers
  const handleLoadCloudWorkspace = async (uid: string, email: string, isRemoteSupportAccess: boolean = false, listenerSessionEpoch?: string) => {
    try {
      if (!isConfigured) return;
      console.log("[Mabala Cloud] Establishing real-time onSnapshot listener for:", email);

      // Assertion check (Section 3.2): Ensure any existing identity listener is torn down before attaching new one
      if (activeListenerIdentityRef.current && activeListenerIdentityRef.current !== uid) {
        console.warn(`[Assertion Check] Active listener scope exists for ${activeListenerIdentityRef.current}. Teardown required before attaching ${uid}.`);
        cleanupWorkspaceListeners();
      }
      cleanupWorkspaceListeners();
      activeListenerIdentityRef.current = uid;
      const listenerGeneration = workspaceListenerGenerationRef.current;

      let isSubUser = false;
      let parentTenantId = "";
      let initialTargetUid = uid;

      // Quick probe to check if sub-user with parent tenant
      try {
        const docSnap = await getDoc(doc(db, "users_data", uid));
        if (docSnap.exists()) {
          const rawCloudData = docSnap.data();
          if (rawCloudData.tenantId) {
            isSubUser = true;
            parentTenantId = rawCloudData.tenantId;
            initialTargetUid = parentTenantId;
            console.log(`[Mabala Multi-Tenant] Detected sub-user with parent tenant: ${parentTenantId}`);
          }
        }
      } catch (probeErr) {
        console.warn("[Mabala Multi-Tenant] Parent tenant probe warning:", probeErr);
      }

      const targetUid = initialTargetUid;
      const docRef = doc(db, "users_data", targetUid);
      const modulesColRef = collection(db, "users_data", targetUid, "modules");

      let latestDocData: Record<string, any> = {};
      let latestModulesData: Record<string, any> = {};
      let hasDocPending = false;
      let hasModsPending = false;

      const processAndApplyData = async (rawCombined: Record<string, any>, isFromCache: boolean) => {
        if (listenerGeneration !== workspaceListenerGenerationRef.current || activeListenerIdentityRef.current !== uid) return;
        if (!rawCombined) return;
        
        const { migratedData, upgradedCount } = migrationRunner(rawCombined);
        
        // If schema upgrades occurred, persist updated payload
        if (upgradedCount > 0 && !isFromCache) {
          console.log(`[Mabala Cloud] Save migrated multi-tenant document (migrations run: ${upgradedCount})`);
          const saveRef = doc(db, "users_data", isSubUser ? parentTenantId : uid);
          setDoc(saveRef, migratedData, { merge: true }).catch(err => console.warn("[Mabala Cloud] Migration save error:", err));
        }

        const finalData = migratedData;
        
        const isSuperAdminEmail = Boolean(email && (SUPER_ADMIN_EMAILS.includes(email.toLowerCase().trim()) || email.toLowerCase().trim() === "support@mabala.cloud" || email.toLowerCase().trim() === "shikasuli@gmail.com"));

        if (isSuperAdminEmail) {
          const validAdminFarms = (finalData.farms && finalData.farms.length > 0)
            ? finalData.farms.filter((f: any) => f && (!f.email || f.email.toLowerCase().trim() === email.toLowerCase().trim() || f.id === "farm-central-admin"))
            : [];
          const farmsToSet = validAdminFarms.length > 0 ? validAdminFarms : [
            {
              id: "farm-central-admin",
              name: "Mabala Platform Administration",
              letterheadTitle: "Mabala Cloud Platform Administration",
              letterheadSubtitle: "Central Infrastructure & Global Network Oversight",
              address: "Opp Oryx Filling Station, Mumbwa Road, Lusaka West, Zambia",
              phone: "+260 978 070734",
              email: email,
              country: "Zambia",
              currency: "ZMW",
              currencySymbol: "K",
              taxSystem: "Standard VAT (16%)",
              taxType: "VAT_16",
              status: "ACTIVE",
              createdAt: new Date().toISOString()
            } as any
          ];
          setFarms(farmsToSet);
          finalData.farms = farmsToSet;
          setActiveFarmIndex(0);
        } else {
          setFarms(finalData.farms || []);
        }
        setAccounts(finalData.accounts || []);
        setSuppliers(finalData.suppliers || []);
        setCustomers(finalData.customers || []);
        setExpenses(finalData.expenses || []);
        setInvoices(finalData.invoices || []);
        setCreditNotes(finalData.creditNotes || []);
        setQuotations(finalData.quotations || []);
        setCrops(finalData.crops || []);
        setEmployees(finalData.employees || []);
        setPayslips(finalData.payslips || []);
        setPoultry(finalData.poultry || []);
        setFish(finalData.fish || []);
        setOrchardNurseryBatches(finalData.orchard_nursery_batches || []);
        setOrchardTrees(finalData.orchard_trees || []);
        setOrchardActivities(finalData.orchard_activities || []);
        setInventory(finalData.inventory || []);
        setCashSales(finalData.cashSales || []);
        setLoans(finalData.loans || []);
        setInvestments(finalData.investments || []);
        setLivestock(finalData.livestock || []);
        setAssets(finalData.assets || []);
        setOtherRevenues(finalData.otherRevenues || []);
        setLeaveRecords(finalData.leaveRecords || []);
        setEmployeeAdvances(finalData.employeeAdvances || []);
        setAuditLogs(finalData.auditLogs || []);
        setArchivedRecords(finalData.archivedRecords || []);

        setHasPendingWrites(hasDocPending || hasModsPending);

        // Dynamically load persistent wallet balance
        let walletCredits: number | null = null;
        let walletSmsCredits: number | null = null;
        try {
          const specWalletSnap = await getDoc(doc(db, "tenants", targetUid, "credit_wallet", "default"));
          if (specWalletSnap.exists()) {
            const swData = specWalletSnap.data();
            walletCredits = Number(swData.balance ?? swData.currentBalance);
          } else {
            const walletDocSnap = await getDoc(doc(db, "tenants", targetUid, "wallet", "credits"));
            if (walletDocSnap.exists()) {
              const walletData = walletDocSnap.data();
              walletCredits = Number(walletData.currentBalance);
            }
          }
          const smsWalletSnap = await getDoc(doc(db, "tenants", targetUid, "wallet", "sms"));
          if (smsWalletSnap.exists()) {
            const smsWalletData = smsWalletSnap.data();
            const value = Number(smsWalletData.currentBalance ?? smsWalletData.balance ?? smsWalletData.smsCredits);
            if (Number.isFinite(value)) walletSmsCredits = value;
          }
        } catch (walletErr) {
          console.warn("[Mabala Wallet] Failed to load credits from tenants wallet path:", walletErr);
        }

        if (walletCredits !== null && !isNaN(walletCredits)) {
          setCredits(walletCredits);
        } else if (finalData.credits !== undefined && finalData.credits !== null) {
          setCredits(Number(finalData.credits));
        } else {
          try {
            const roleForGrant = finalData.role || "FARMER";
            const grantRes = await grantWelcomeCreditsIfEligible(db, targetUid, roleForGrant);
            if (grantRes.success) {
              setCredits(grantRes.newBalance);
            } else {
              setCredits(grantRes.newBalance ?? 0);
            }
          } catch (gErr) {
            console.error("Failed to initialize welcome credits:", gErr);
            setCredits(0);
          }
        }

        if (walletSmsCredits !== null) {
          setSmsCredits(walletSmsCredits);
        } else if (finalData.smsCredits !== undefined) {
          setSmsCredits(finalData.smsCredits);
        } else {
          setSmsCredits(0);
        }
        if (finalData.subscriptionTier) setSubscriptionTier(finalData.subscriptionTier);
        if (finalData.workspaceMode) setWorkspaceMode(finalData.workspaceMode);
        if (finalData.status !== undefined) {
          setFarmStatus(finalData.status);
        } else {
          setFarmStatus("ACTIVE");
        }

        // Initialize lastSavedStatesRef so we only save modified data
        const keys = [
          "farms", "accounts", "suppliers", "customers", "expenses", "invoices", "quotations",
          "crops", "employees", "payslips", "poultry", "fish", "inventory", "cashSales",
          "loans", "investments", "livestock", "assets", "otherRevenues", "leaveRecords",
          "employeeAdvances", "auditLogs", "archivedRecords"
        ];
        keys.forEach(k => {
          if (finalData[k]) {
            lastSavedStatesRef.current[k] = JSON.stringify(finalData[k]);
          } else {
            lastSavedStatesRef.current[k] = "[]";
          }
        });

        // If this is a remote support inspection session by Super Admin,
        // operational collections (farms, crops, expenses, invoices, etc.) have been loaded above.
        // We MUST NOT overwrite the Super Admin's identity, role, verified profile, or local storage keys!
        if (isRemoteSupportAccess) {
          console.log("[Access Node] Remote support workspace data successfully loaded into operational views. Super Admin identity, profile, and local persistence are strictly preserved.");
          return;
        }
        
        if (isSubUser) {
          const profile = {
            ...(rawCombined.userProfile || {}),
            email: rawCombined.email || email,
            tenantId: parentTenantId,
            uid: uid,
            role: rawCombined.role || "Field Officer"
          };
          setUserProfile(profile);
          setParentProfile(finalData.userProfile || null);
          IdentityIntegrityService.saveVerifiedProfile({ uid, email }, profile);
        } else {
          setParentProfile(null);
          if (finalData.userProfile) {
            const p = {
              ...finalData.userProfile,
              uid: uid
            };
            if (isSuperAdminEmail) {
              p.role = "Super Admin";
              p.tenantType = "super_admin";
              p.tenantId = "super_admin_central";
              delete p.targetFarmName;
              delete p.targetFarmId;
              delete p.targetFarmNode;
              delete p.farmNode;
              delete p.targetProfile;
              delete p.targetActualRole;
              delete p.targetActualTenantType;
              if (p.farmName && !finalData.farms?.some((f: any) => f.name === p.farmName)) {
                delete p.farmName;
              }
            }
            setUserProfile(p);
            IdentityIntegrityService.saveVerifiedProfile({ uid, email }, p);
          } else {
            setUserProfile(prev => {
              const u = {
                ...prev,
                uid: uid,
                email: email || prev.email || "owner@mabala.com",
                name: (isSuperAdminEmail || finalData.role === "Super Admin") ? "Platform Administrator" : (prev.name || "Farm Owner"),
                role: isSuperAdminEmail ? "Super Admin" : (prev.role || "Farm Owner"),
                tenantType: isSuperAdminEmail ? "super_admin" : (prev.tenantType || "farmer"),
                tenantId: isSuperAdminEmail ? "super_admin_central" : (prev.tenantId || uid)
              };
              if (isSuperAdminEmail) {
                delete (u as any).targetFarmName;
                delete (u as any).targetFarmId;
                delete (u as any).targetFarmNode;
                delete (u as any).farmNode;
                if ((u as any).farmName && !finalData.farms?.some((f: any) => f.name === (u as any).farmName)) {
                  delete (u as any).farmName;
                }
              }
              IdentityIntegrityService.saveVerifiedProfile({ uid, email }, u);
              return u;
            });
          }
        }
        
        // Save the freshly loaded Firestore data to local snapshot and IndexedDB for instant offline availability
        FarmPersistenceService.saveFarmNodeWorkspace(email, finalData).catch(e => console.warn("[FarmPersistence] Cloud workspace sync note:", e));
        FarmPersistenceService.populateActiveLocalStorageKeys(finalData as any);

        const rawRoleStr = rawCombined.role || rawCombined.tenantType || finalData.role || "";
        const canonicalType = resolveCanonicalTenantType(rawRoleStr, email);

        let resolvedRole: PredefinedRole = "Farm Owner";
        let landingShell = "dashboard";

        if (canonicalType === "super_admin") {
          resolvedRole = "Super Admin";
          landingShell = "dashboard";
          setWorkspaceMode("Farmer");
        } else if (canonicalType === "agro_dealer") {
          resolvedRole = "Agro Dealer";
          landingShell = "agc-dealer-pos";
          setWorkspaceMode("Farmer");
        } else if (canonicalType === "institution_supplier") {
          resolvedRole = "Institution Supplier";
          landingShell = "agc-financier-portal";
          setWorkspaceMode("Farmer");
        } else if (canonicalType === "offtaker") {
          resolvedRole = "Offtaker";
          landingShell = "offtaker-marketplace";
          setWorkspaceMode("Offtaker");
        } else if (canonicalType === "mabala_partner") {
          resolvedRole = "Mabala Partner";
          landingShell = "partner-portal";
          setWorkspaceMode("Partner");
        } else if (canonicalType === "agronomist") {
          resolvedRole = "Agronomist";
          landingShell = "advisory-portal";
          setWorkspaceMode("Farmer");
        } else {
          resolvedRole = (rawCombined.role as PredefinedRole) || "Farm Owner";
          landingShell = "dashboard";
          setWorkspaceMode("Farmer");
        }

        if (isRemoteSupportAccess) {
          // When in remote support access (impersonation), NEVER overwrite userProfile (Super Admin profile)!
          // Update impersonation.targetProfile instead so activeProfile updates cleanly and UI never flickers!
          setCurrentRole(resolvedRole);
          setImpersonation(prev => {
            if (!prev) return null;
            return {
              ...prev,
              targetActualRole: resolvedRole,
              targetActualTenantType: canonicalType,
              targetProfile: {
                ...(prev.targetProfile || {}),
                uid: uid,
                email: rawCombined.email || email,
                name: rawCombined.name || rawCombined.userProfile?.name || (prev.targetProfile?.name || email.split("@")[0]),
                role: resolvedRole,
                tenantType: canonicalType,
                tenantId: rawCombined.tenantId || uid
              }
            };
          });
        } else {
          setCurrentRole(resolvedRole);
          setUserProfile(prev => {
            const u = {
              ...prev,
              uid: uid,
              email: rawCombined.email || email,
              name: rawCombined.name || rawCombined.userProfile?.name || (canonicalType === "super_admin" ? "Platform Administrator" : (prev.name || email.split("@")[0])),
              role: resolvedRole,
              tenantType: canonicalType,
              tenantId: rawCombined.tenantId || uid
            };
            IdentityIntegrityService.saveVerifiedProfile({ uid, email }, u);
            return u;
          });
        }

        setIsAuthenticated(true);
        localStorage.setItem("mabala_is_authenticated", "true");

        if (sessionStorage.getItem("mabala_fresh_login") === "true") {
          sessionStorage.removeItem("mabala_fresh_login");
          setActiveTabState(landingShell);
          syncUrlRoute(landingShell);
        }
        
        console.log(`[Mabala Cloud onSnapshot] Synced real-time workspace payload (fromCache: ${isFromCache}, hasPendingWrites: ${hasDocPending || hasModsPending}).`);
      };

      // 1. Listen to tenant main document with includeMetadataChanges: true
      const unsubDoc = onSnapshot(docRef, { includeMetadataChanges: true }, (docSnap) => {
        if (listenerGeneration !== workspaceListenerGenerationRef.current || activeListenerIdentityRef.current !== uid) return;
        hasDocPending = docSnap.metadata.hasPendingWrites;
        if (docSnap.exists()) {
          latestDocData = docSnap.data() || {};
          const combined = { ...latestDocData, ...latestModulesData };
          processAndApplyData(combined, docSnap.metadata.fromCache);
          setFarms([]);
          setAccounts([]);
          setSuppliers([]);
          setCustomers([]);
          setExpenses([]);
          setInvoices([]);
          setCreditNotes([]);
          setQuotations([]);
          setCrops([]);
          setEmployees([]);
          setPayslips([]);
          setPoultry([]);
          setFish([]);
          setOrchardNurseryBatches([]);
          setOrchardTrees([]);
          setOrchardActivities([]);
          setInventory([]);
          setCashSales([]);
          setLoans([]);
          setInvestments([]);
          setLivestock([]);
          setAssets([]);
          setOtherRevenues([]);
          setLeaveRecords([]);
          setEmployeeAdvances([]);
          setAuditLogs([]);
          setArchivedRecords([]);
        }
      }, (docErr) => {
        console.warn("[Mabala Cloud onSnapshot] Tenant doc subscription warning:", docErr);
      });

      // 2. Listen to modules subcollection with includeMetadataChanges: true
      const unsubModules = onSnapshot(modulesColRef, { includeMetadataChanges: true }, (modulesSnap) => {
        if (listenerGeneration !== workspaceListenerGenerationRef.current || activeListenerIdentityRef.current !== uid) return;
        hasModsPending = modulesSnap.metadata.hasPendingWrites;
        const newMods: Record<string, any> = {};
        modulesSnap.forEach((mDoc) => {
          const mData = mDoc.data();
          if (mData && mData.data !== undefined) {
            newMods[mDoc.id] = mData.data;
          }
        });
        latestModulesData = newMods;
        const combined = { ...latestDocData, ...latestModulesData };
        processAndApplyData(combined, modulesSnap.metadata.fromCache);
      }, (modErr) => {
        console.warn("[Mabala Cloud onSnapshot] Subcollection modules subscription warning:", modErr);
      });

      workspaceListenersUnsubRef.current.push(unsubDoc, unsubModules);
      accessNodeListenerRegistry.start(
        isRemoteSupportAccess ? "impersonation" : "admin",
        listenerSessionEpoch || (isRemoteSupportAccess ? (impersonation?.sessionEpoch || createSessionEpoch("impersonation")) : createSessionEpoch("admin")),
        [unsubDoc, unsubModules]
      );
    } catch (err) {
      console.error("[Mabala Cloud] Error establishing real-time onSnapshot listener:", err);
    }
  };

  const handleSaveCloudWorkspace = async (uid: string) => {
    const sanitizeFirestoreData = (val: any): any => {
      if (val === undefined || val === null) {
        return null;
      }
      try {
        const jsonStr = JSON.stringify(val);
        if (jsonStr === undefined) {
          return null;
        }
        const parsed = JSON.parse(jsonStr);
        
        const cleanDeep = (item: any): any => {
          if (item === undefined || item === null) {
            return null;
          }
          if (Array.isArray(item)) {
            return item.map(cleanDeep);
          }
          if (typeof item === "object") {
            const cleaned: any = {};
            for (const key of Object.keys(item)) {
              const v = item[key];
              if (v !== undefined && v !== null) {
                cleaned[key] = cleanDeep(v);
              }
            }
            return cleaned;
          }
          return item;
        };
        
        return cleanDeep(parsed);
      } catch (err: any) {
        console.warn("[sanitizeFirestoreData] Failed to clean data deeply:", err.message);
        return null;
      }
    };

    try {
      if (!isConfigured) return;
      let targetUid = uid;
      if (impersonation) {
        targetUid = impersonation.targetUid;
      } else {
        // Resolve the workspace from the current backend profile. Local profile
        // state may belong to the previous session during an account switch.
        const membershipSnap = await getDoc(doc(db, "users_data", uid));
        const membershipData = membershipSnap.exists() ? membershipSnap.data() : {};
        targetUid = String(membershipData.tenantId || uid);
      }
      
      console.log(`[Mabala Cloud] Committing persistent workspace state changes for ${targetUid} to Cloud Firestore securely...`);
      const docRef = doc(db, "users_data", targetUid);
      
      let syncedAuditLogs = [...auditLogs];
      if (impersonation) {
        const supportLog = {
          id: "log-support-" + Date.now(),
          action: "Support Action by Admin",
          description: `Support action by Super Admin (${auth.currentUser?.email || "support@mabala.cloud"}): Workspace parameters committed.`,
          date: new Date().toISOString().replace('T', ' ').slice(0, 19),
          ip: "102.89.34.12",
          actor: "Super Admin"
        };
        // Avoid duplicate spam logs if no visual variables modified, but append if changes are committed
        syncedAuditLogs.push(supportLog);
      }

      // 1. Define modular structures
      const modulesToSave = [
        { key: "farms", data: farms },
        { key: "accounts", data: accounts },
        { key: "suppliers", data: suppliers },
        { key: "customers", data: customers },
        { key: "expenses", data: expenses },
        { key: "invoices", data: invoices },
        { key: "quotations", data: quotations },
        { key: "crops", data: crops },
        { key: "employees", data: employees },
        { key: "payslips", data: payslips },
        { key: "poultry", data: poultry },
        { key: "fish", data: fish },
        { key: "orchard_nursery_batches", data: orchardNurseryBatches },
        { key: "orchard_trees", data: orchardTrees },
        { key: "orchard_activities", data: orchardActivities },
        { key: "inventory", data: inventory },
        { key: "cashSales", data: cashSales },
        { key: "loans", data: loans },
        { key: "investments", data: investments },
        { key: "livestock", data: livestock },
        { key: "assets", data: assets },
        { key: "otherRevenues", data: otherRevenues },
        { key: "leaveRecords", data: leaveRecords },
        { key: "employeeAdvances", data: employeeAdvances },
        { key: "auditLogs", data: syncedAuditLogs },
        { key: "archivedRecords", data: archivedRecords },
      ];

      let hasAnyWriteFailed = false;
      const failedList: string[] = [];

      // 2. Save user metadata to parent document
      try {
        const isSuperAdminUser = auth.currentUser?.email?.toLowerCase() === "support@mabala.cloud";
        
        let metadataRole: any = currentRole;
        let metadataTenantType = workspaceMode?.toLowerCase() || "farmer";

        if (impersonation) {
          // Preserve the target farm node's actual role; NEVER upgrade target node to Super Admin
          metadataRole = impersonation.targetActualRole || "Farm Owner";
          metadataTenantType = impersonation.targetActualTenantType || "farmer";
        } else if (isSuperAdminUser) {
          metadataRole = "Super Admin";
          metadataTenantType = "super_admin";
        }

        const metadataPayload = sanitizeFirestoreData({
          uid: targetUid,
          email: impersonation ? impersonation.targetEmail : (userProfile && userProfile.tenantId && parentProfile ? parentProfile.email : (auth.currentUser?.email || "")),
          role: metadataRole,
          tenantType: metadataTenantType,
          credits: credits !== null ? credits : undefined,
          smsCredits,
          subscriptionTier,
          workspaceMode: impersonation 
            ? (metadataTenantType === "offtaker" ? "Offtaker" : metadataTenantType === "mabala_partner" ? "Partner" : metadataTenantType === "agro_dealer" ? "Agro Dealer" : "Farmer")
            : workspaceMode,
          status: farmStatus,
          userProfile: impersonation
            ? {
                uid: targetUid,
                tenantId: targetUid,
                email: impersonation.targetEmail,
                role: metadataRole,
                tenantType: metadataTenantType,
                phone: (impersonation.targetFarmNode && impersonation.targetFarmNode.phone) || impersonation.targetPhone || ""
              }
            : ((userProfile && userProfile.tenantId && parentProfile) ? parentProfile : userProfile),
          updatedAt: new Date().toISOString()
        });
        await setDoc(docRef, metadataPayload, { merge: true });
        console.log("[Mabala Cloud] Main parent metadata committed successfully.");
      } catch (metaErr) {
        console.error("[Mabala Cloud] Error writing parent metadata:", metaErr);
        hasAnyWriteFailed = true;
        failedList.push("metadata");
      }

      // 3. Write each changed module independently, with accounts, livestock, and poultry grouped in an atomic transaction
      const txnKeys = ["accounts", "livestock", "poultry"];
      const anyTxnChanged = txnKeys.some(key => {
        const mod = modulesToSave.find(m => m.key === key);
        if (!mod) return false;
        return JSON.stringify(mod.data) !== lastSavedStatesRef.current[key];
      });

      if (anyTxnChanged) {
        console.log("[Mabala Cloud] Financial assets modified. Committing Accounts, Livestock and Poultry via atomic writeBatch...");
        try {
          const accountsDocRef = doc(db, "users_data", targetUid, "modules", "accounts");
          const livestockDocRef = doc(db, "users_data", targetUid, "modules", "livestock");
          const poultryDocRef = doc(db, "users_data", targetUid, "modules", "poultry");

          // Recalculate Account 1420 expected balance to force strict consistency
          const liveLivestockValue = (livestock || []).reduce((sum, r) => sum + (r.status === "Active" ? (Number(r.currentValue) || 0) : 0), 0);
          const livePoultryValue = (poultry || []).reduce((sum, p) => sum + ((p.status.includes("ACTIVE") || (p.status as string) === "active" || (p.status as string) === "Active") ? (Number(p.currentBatchValuation || ((p.currentHeadcount || p.currentCount || 0) * (p.currentMarketPricePerBird || 0))) || 0) : 0), 0);
          const expected1420Balance = liveLivestockValue + livePoultryValue;

          const updatedAccounts = accounts.map(a => a.code === "1420" ? { ...a, balance: expected1420Balance } : a);

          const sanitizedAccounts = sanitizeFirestoreData(updatedAccounts);
          const sanitizedLivestock = sanitizeFirestoreData(livestock);
          const sanitizedPoultry = sanitizeFirestoreData(poultry);

          const batch = writeBatch(db);
          batch.set(accountsDocRef, {
            data: sanitizedAccounts,
            updatedAt: new Date().toISOString()
          }, { merge: true });

          batch.set(livestockDocRef, {
            data: sanitizedLivestock,
            updatedAt: new Date().toISOString()
          }, { merge: true });

          batch.set(poultryDocRef, {
            data: sanitizedPoultry,
            updatedAt: new Date().toISOString()
          }, { merge: true });

          await batch.commit();

          // Update saved state cache refs on success
          txnKeys.forEach(key => {
            const mod = modulesToSave.find(m => m.key === key);
            if (mod) {
              lastSavedStatesRef.current[key] = JSON.stringify(mod.data);
            }
          });
          console.log("[Mabala Cloud] Atomic batch success: Accounts, Livestock and Poultry synchronized with zero drift.");
        } catch (txnErr) {
          console.error("[Mabala Cloud] Atomic batch failure:", txnErr);
          hasAnyWriteFailed = true;
          failedList.push("accounts", "livestock", "poultry");
        }
      }

      const savePromises = modulesToSave
        .filter(mod => !txnKeys.includes(mod.key))
        .map(async (mod) => {
          const currentStr = JSON.stringify(mod.data);
          const lastSavedStr = lastSavedStatesRef.current[mod.key];

          // Skip writing if the module data has not changed
          if (currentStr === lastSavedStr) {
            return;
          }

          try {
            const modDocRef = doc(db, "users_data", targetUid, "modules", mod.key);
            const sanitizedModuleData = sanitizeFirestoreData(mod.data);
            await setDoc(modDocRef, {
              data: sanitizedModuleData,
              updatedAt: new Date().toISOString()
            }, { merge: true });

            // Update ref only on success
            lastSavedStatesRef.current[mod.key] = currentStr;
            console.log(`[Mabala Cloud] Independent module write success: "${mod.key}"`);
          } catch (modErr) {
            console.error(`[Mabala Cloud] Independent module write failure: "${mod.key}"`, modErr);
            hasAnyWriteFailed = true;
            failedList.push(mod.key);
          }
        });

      await Promise.all(savePromises);

      if (hasAnyWriteFailed) {
        // Write failed modules to durable local storage queue
        for (const modKey of failedList) {
          const modObj = modulesToSave.find(m => m.key === modKey);
          if (modObj) {
            await offlineQueueService.enqueue(
              targetUid,
              "MODULE_WRITE",
              modObj.data,
              `Offline Saved Module: ${modKey}`,
              modKey
            );
          }
        }
        throw new Error(`Independent writes failed for: ${failedList.join(", ")}`);
      }

      console.log("[Mabala Cloud] Independent cloud commits completed successfully.");
      setCloudSaveFailed(false);
      setCloudSaveUserAcknowledged(false);
    } catch (err) {
      console.error("[Mabala Cloud] Error saving persistent workspace:", err);
      setCloudSaveFailed(true);
    }
  };

  // Automatic retry with exponential backoff on cloud save failure
  useEffect(() => {
    if (!cloudSaveFailed) {
      setCloudSaveRetryCount(0);
      return;
    }

    const currentUser = auth.currentUser;
    if (!currentUser) return;

    // Exponential backoff: 2s, 4s, 8s, 16s, max out at 30s
    const delay = Math.min(2000 * Math.pow(2, cloudSaveRetryCount), 30000);
    console.log(`[Mabala Cloud] Scheduling automatic retry #${cloudSaveRetryCount + 1} in ${delay}ms`);

    const timer = setTimeout(async () => {
      setCloudSaveRetryCount(prev => prev + 1);
      await handleSaveCloudWorkspace(currentUser.uid);
    }, delay);

    return () => clearTimeout(timer);
  }, [cloudSaveFailed, cloudSaveRetryCount]);

  const handleAutoCreateProfileIfMissing = async (uid: string, email: string) => {
    if (!isConfigured || !email) return;
    try {
      const emailLower = email.trim().toLowerCase();
      if (localStorage.getItem("registrations_in_progress_" + emailLower) === "true") {
        console.log("[Mabala Cloud] Auto profile creation skipped: registration in progress for", emailLower);
        return;
      }
      const docRef = doc(db, "users_data", uid);
      const docSnap = await getDoc(docRef);
      if (!docSnap.exists()) {
        console.log("[Mabala Cloud] Auto-creating missing user profile in firestore for:", email);
        const emailLower = email.trim().toLowerCase();
        const isSuper = emailLower === "support@mabala.cloud";
        const matchedCountry = COUNTRIES[0]; // default Zambia
        const farmNameToUse = isSuper ? "Mabala Central Administration" : "Sunrise Agro-Tech Farm";

        const selectedLoginRole = sessionStorage.getItem("mabala_selected_login_role") as any;
        const autoRole = selectedLoginRole === "offtaker" ? "Offtaker"
          : selectedLoginRole === "agro_dealer" ? "Agro Dealer"
          : selectedLoginRole === "institution_supplier" ? "Institution Supplier"
          : selectedLoginRole === "agronomist" ? "Agronomist"
          : selectedLoginRole === "mabala_partner" ? "Mabala Partner"
          : (isSuper ? "Super Admin" : "Farm Owner");

        const autoTenantType = selectedLoginRole || (isSuper ? "super_admin" : "farmer");
        const autoWorkspaceMode = selectedLoginRole === "offtaker" ? "Offtaker"
          : selectedLoginRole === "mabala_partner" ? "Partner"
          : "Farmer";

        const initialFarms = [
          {
            id: "farm-1",
            name: farmNameToUse,
            letterheadTitle: farmNameToUse,
            tpin: "1002345678",
            address: "Opp Oryx Filling Station, Mumbwa Road, Lusaka West",
            phone: "+260978070734",
            email: emailLower,
            financialYearStart: "2026-01-01",
            financialYearEnd: "2026-12-31",
            currency: matchedCountry.currency,
            currencySymbol: matchedCountry.symbol,
            taxSystem: matchedCountry.defaultTaxSystem
          }
        ];

        const initialAccounts = INITIAL_ACCOUNTS.map(a => ({ ...a, balance: 0 }));

        const profileData = {
          uid,
          email: emailLower,
          role: autoRole,
          tenantType: autoTenantType,
          credits: isSuper ? 100000 : 100,
          subscriptionTier: isSuper ? "Agro-Enterprise Premium" : autoRole === "Offtaker" ? "Free Offtaker" : "Commercial Growth Layer",
          workspaceMode: autoWorkspaceMode,
          farms: initialFarms,
          accounts: initialAccounts,
          suppliers: [],
          customers: [],
          expenses: [],
          invoices: [],
          quotations: [],
          crops: [],
          employees: [],
          payslips: [],
          poultry: [],
          fish: [],
          inventory: [],
          loans: [],
          investments: [],
          cashSales: [],
          livestock: [],
          assets: [],
          otherRevenues: [],
          leaveRecords: [],
          employeeAdvances: [],
          auditLogs: [],
          archivedRecords: [],
          updatedAt: new Date().toISOString()
        };

        await setDoc(docRef, profileData);
        console.log("[Mabala Cloud] Successfully auto-created missing user profile for:", email);
      }
    } catch (err) {
      console.error("[Mabala Cloud] Error auto-creating user profile:", err);
    }
  };

  // Firebase auth state observer & Active Session Enforcement
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      const newUid = user ? user.uid : null;
      
      if (lastUidRef.current === undefined) {
        // Initial page load: initialize reference without destroying user state
        console.log(`[Mabala Auth] Initial session restoration for user: ${newUid || "Unauthenticated"}`);
        lastUidRef.current = newUid;
        if (user) {
          setIsAuthenticated(true);
          localStorage.setItem("mabala_is_authenticated", "true");
        } else {
          setIsAuthenticated(false);
          localStorage.removeItem("mabala_is_authenticated");
        }
      } else if (newUid !== lastUidRef.current) {
        // Genuine user transition (switching accounts or explicit logout)
        console.log(`[Mabala Auth] Session transition detected: ${lastUidRef.current} -> ${newUid}`);
        
        // 1. Kill active Firestore listeners from the previous session
        listenerRegistry.unregisterAll();
        
        // 2. Snapshot current workspace before session transition to ensure NO DATA LOSS
        const departingEmail = (userProfile?.email || "").trim().toLowerCase();
        if (departingEmail) {
          FarmPersistenceService.captureAndSaveCurrentState(departingEmail, {
            farms, accounts, suppliers, customers, expenses, invoices, creditNotes, quotations,
            crops, employees, payslips, poultry, fish, orchard_nursery_batches: orchardNurseryBatches,
            orchard_trees: orchardTrees, orchard_activities: orchardActivities, inventory, cashSales,
            loans, investments, livestock, assets, otherRevenues, leaveRecords, employeeAdvances,
            auditLogs, archivedRecords, teamMembers, credits, smsCredits, subscriptionTier,
            workspaceMode, farmStatus, userProfile, contactDetails
          }).catch(e => console.warn("[FarmPersistence] Session snapshot notice:", e));
        }
        
        // Save departing user role to persistent role registry
        if (userProfile && userProfile.email && userProfile.role) {
          saveUserRoleToRegistry(userProfile.email, userProfile.role, userProfile.tenantType);
        }
        
        // 3. If user is logging out, execute comprehensive multi-tier purge to prevent cross-session leaks
        if (newUid === null) {
          sessionService.clearSession();
          setIsTakeoverModalOpen(false);
          setTakeoverInfo(null);
          setRejectedWrites([]);
          setIsAuthenticated(false);
          localStorage.removeItem("mabala_is_authenticated");
          localStorage.removeItem("mabala_id_token");

          await IdentityIntegrityService.executeCompleteLogoutPurge(departingEmail || lastUidRef.current || undefined);

          setFarms([]);
          setAccounts([]);
          setSuppliers([]);
          setCustomers([]);
          setExpenses([]);
          setInvoices([]);
          setCreditNotes([]);
          setQuotations([]);
          setCrops([]);
          setEmployees([]);
          setPayslips([]);
          setPoultry([]);
          setFish([]);
          setOrchardNurseryBatches([]);
          setOrchardTrees([]);
          setOrchardActivities([]);
          setInventory([]);
          setCashSales([]);
          setLoans([]);
          setInvestments([]);
          setLivestock([]);
          setAssets([]);
          setOtherRevenues([]);
          setLeaveRecords([]);
          setEmployeeAdvances([]);
          setAuditLogs([]);
          setArchivedRecords([]);

          setUserProfile({
            name: "Farm Owner",
            email: "owner@mabala.com",
            phone: "+260978070734",
            role: "Farm Owner",
            tenantType: "farmer"
          });
          setCurrentRole("Farm Owner");
          lastUidRef.current = null;
        } else {
          // Switching accounts - register new uid and scope storage
          lastUidRef.current = newUid;
          FarmPersistenceService.clearActiveLocalStorageKeys({ purgeIdentity: true });
          setOfflineDbScope(newUid);
          setPersistenceScope(newUid);
          koboCollectSyncService.setKoboScope(newUid);
        }
      }

      if (user) {
        setOfflineDbScope(user.uid);
        setPersistenceScope(user.email || user.uid);
        koboCollectSyncService.setKoboScope(user.uid, (user as any)?.tenantId);

        const emailLower = user.email ? user.email.toLowerCase() : "";

        let token = "";
        try {
          token = await user.getIdToken();
          localStorage.setItem("mabala_id_token", token);

          // A refresh cannot safely reconstruct React impersonation state. If
          // an old temporary remote claim is present, close that context on the
          // server and return to the authenticated Super Admin workspace.
          const tokenResult = await user.getIdTokenResult();
          const remoteSessionId = String((tokenResult.claims as any).accessNodeSessionId || "");
          if (remoteSessionId) {
            try {
              const { getFunctions, httpsCallable } = await import("firebase/functions");
              const { getApp } = await import("firebase/app");
              await httpsCallable(getFunctions(getApp()), "exitAccessNode")({ sessionId: remoteSessionId });
              token = await user.getIdToken(true);
              localStorage.setItem("mabala_id_token", token);
            } catch (remoteCleanupErr) {
              console.warn("[Mabala Auth] Remote access cleanup after refresh failed:", remoteCleanupErr);
            }
          }
        } catch (tokenErr) {
          console.warn("[Mabala Token] Failed to cache auth token:", tokenErr);
        }

        // Auto-create profile if missing, so we never block Google/Bypass logins!
        if (isConfigured && user.email) {
          await handleAutoCreateProfileIfMissing(user.uid, user.email);
        }

        // Enforce Single-Active-Session Architecture: Claim session & establish remote takeover listener
        if (isConfigured && user.uid) {
          try {
            sessionService.claimSession(user.uid, token).then((newSessId) => {
              console.log(`[Mabala Single Session] Active session claimed: ${newSessId} for UID ${user.uid}`);
            }).catch(e => console.warn("[Mabala Single Session] Background claim notice:", e?.message));

            // Attach takeover listener: if another device logs in, instantly notifies and pauses UI
            sessionService.startSessionListener(user.uid, (termInfo) => {
              console.warn("[Mabala Single Session] Remote device takeover detected:", termInfo);
              setTakeoverInfo(termInfo);
              setIsTakeoverModalOpen(true);
            });

            // Attach reconciliation queue listener for rejected stale writes
            sessionService.subscribeRejectedWrites(user.uid, (writes) => {
              setRejectedWrites(writes);
            });
          } catch (err) {
            console.warn("[Mabala Single Session] Warning establishing session listener:", err);
          }
        }

        // Proceed normally for verified users
        setIsAuthenticated(true);
        localStorage.setItem("mabala_is_authenticated", "true");
        setIsUnverifiedUser(false);
        
        const userMeta = getUserIdentityMetadata(user.email || "");
        const selectedLoginRole = sessionStorage.getItem("mabala_selected_login_role") as any;
        const defaultRole = selectedLoginRole === "offtaker" ? "Offtaker"
          : selectedLoginRole === "agro_dealer" ? "Agro Dealer"
          : selectedLoginRole === "institution_supplier" ? "Institution Supplier"
          : selectedLoginRole === "agronomist" ? "Agronomist"
          : selectedLoginRole === "mabala_partner" ? "Mabala Partner"
          : ((SUPER_ADMIN_EMAILS.includes(user.email || "") || user.email === "support@mabala.cloud" || user.email === "shikasuli@gmail.com") ? "Super Admin" : "Farm Owner");

        const resolvedUserRole = userMeta.role || defaultRole;
        const resolvedUserTenantType = userMeta.tenantType || (selectedLoginRole ? selectedLoginRole : resolveCanonicalTenantType(resolvedUserRole, user.email || ""));

        setCurrentRole(resolvedUserRole as PredefinedRole);
        if (resolvedUserTenantType === "offtaker" || resolvedUserRole === "Offtaker") {
          setWorkspaceMode("Offtaker");
        } else if (resolvedUserTenantType === "mabala_partner" || resolvedUserRole === "Mabala Partner") {
          setWorkspaceMode("Partner");
        }
        const newProfile = {
          uid: user?.uid,
          email: user?.email || "",
          name: userMeta?.name || user?.displayName || (user?.email ? user.email.split("@")[0] : "User"),
          role: resolvedUserRole,
          tenantType: resolvedUserTenantType,
          tenantId: (userMeta as any)?.tenantId || (user as any)?.tenantId || user?.uid,
          phone: userMeta?.phone || ""
        };
        setUserProfile(newProfile);
        IdentityIntegrityService.saveVerifiedProfile({ uid: user.uid, email: user.email || "" }, newProfile);

        // Load the persistent data from cloud
        await handleLoadCloudWorkspace(user.uid, user.email || "");

        // Workspace isolation post-login router — reads claims (tenantType, role)
        // and hard-redirects to exactly one shell route.
        const canonicalType = resolvedUserTenantType || resolveCanonicalTenantType(resolvedUserRole, user.email || "");
        const claims: AuthClaims = {
          role: currentRole,
          tenantType: canonicalType
        };

        try {
          const shellRoute = resolveWorkspaceShell(claims);
          const targetTab = WORKSPACE_SHELL_ROUTE_MAP[shellRoute] || getLandingWorkspaceShell(canonicalType);

          if (sessionStorage.getItem("mabala_fresh_login") === "true") {
            sessionStorage.removeItem("mabala_fresh_login");
            setActiveTabState(targetTab);
            syncUrlRoute(targetTab);
          }
        } catch (shellErr: any) {
          console.error("[Workspace Router Error]", shellErr);
          setSessionError(shellErr.message || "Unrecognized tenant type — login blocked.");
          setIsAuthenticated(false);
          localStorage.removeItem("mabala_is_authenticated");
        }
      }
      setIsAuthLoading(false);
    });
    return () => unsubscribe();
  }, [isConfigured, currentSessionId]);

  // Active session management is handled by sessionService.startSessionListener with persistent device fingerprinting.
  // Legacy active_sessions listener is disabled to prevent false displacements across refreshes and tabs.

  // Keep the auth token fresh (refresh every 10 minutes if user is logged in) to avoid invalid token errors
  useEffect(() => {
    if (!isAuthenticated || !auth.currentUser) return;
    const refreshAuthToken = async (forceRefresh: boolean = false) => {
      try {
        console.log(`[Mabala Auth] Refreshing auth ID token (forceRefresh=${forceRefresh})...`);
        const token = await auth.currentUser.getIdToken(forceRefresh);
        localStorage.setItem("mabala_id_token", token);
      } catch (err) {
        console.warn("[Mabala Auth] Failed to refresh auth token automatically:", err);
      }
    };
    
    // On mount, use the cached/existing token without forcing a network request
    refreshAuthToken(false);
    
    // Refresh and fetch a fresh token from Firebase servers every 10 minutes
    const interval = setInterval(() => {
      refreshAuthToken(true);
    }, 10 * 60 * 1000); // 10 minutes
    return () => clearInterval(interval);
  }, [isAuthenticated]);

  // Farmer & Vet Role Enforcement Guard - prevents workspace boundary violations
  useEffect(() => {
    if (!isAuthLoading && isAuthenticated) {
      const userMailLower = (userProfile?.email || auth.currentUser?.email || "").trim().toLowerCase();
      const isSuperAdminEmail = SUPER_ADMIN_EMAILS.includes(userMailLower) || userMailLower === "support@mabala.cloud" || userMailLower === "shikasuli@gmail.com";
      const isSuper = isSuperAdmin || currentRole === "Platform Administrator" || currentRole === "Super Admin" || isSuperAdminEmail;
      if (isSuper) return; // Super admin has universal access to all workspaces

      if (workspaceMode === "Farmer") {
        const disallowed = ["veterinary"];
        if (disallowed.includes(activeTab)) {
          setActiveTab("dashboard");
        }
      } else if (workspaceMode === "Veterinary") {
        const allowed = ["veterinary", "profile", "platform-admin", "backup-restore", "audit-archive", "permissions"];
        if (!allowed.includes(activeTab)) {
          setActiveTab("veterinary");
        }
      }
    }
  }, [isAuthLoading, isAuthenticated, workspaceMode, activeTab, isSuperAdmin, currentRole, userProfile?.email]);

  // =========================================================================
  // MODULE ENTITLEMENT ENGINE HARD GUARD & LANDING SHELL ENFORCER
  // =========================================================================
  useEffect(() => {
    if (!isAuthLoading && isAuthenticated) {
      const canonicalType = resolveCanonicalTenantType(currentRole, userProfile?.email);
      const userMailLower = (userProfile?.email || auth.currentUser?.email || "").trim().toLowerCase();
      const isSuperAdminEmail = SUPER_ADMIN_EMAILS.includes(userMailLower) || userMailLower === "support@mabala.cloud" || userMailLower === "shikasuli@gmail.com";
      const isSuperAdminUser = canonicalType === "super_admin" || 
        isSuperAdminEmail || 
        isSuperAdmin || 
        currentRole === "Platform Administrator" || 
        currentRole === "Super Admin";

      // Super Admin has universal access across all modules, hubs, and portals without restriction
      if (isSuperAdminUser) {
        return;
      }

      // 1. Layer 1 Hard Platform Locks Guard
      if (HARD_PLATFORM_LOCK_MODULES.includes(activeTab) && !isSuperAdminUser) {
        console.warn(`[Entitlement Engine Guard] Hard platform lock triggered! Access denied for ${canonicalType} on ${activeTab}`);
        const fallbackShell = getLandingWorkspaceShell(canonicalType);
        setActiveTab(fallbackShell);
        return;
      }

      // 2. Strict Workspace Boundary Enforcement by Canonical Tenant Type
      if (canonicalType === "agro_dealer") {
        const allowedAgroDealerTabs = [
          "agc-dealer-pos", 
          "agrodealer-consignment", 
          "agrodealer-boost", 
          "inventory", 
          "sales", 
          "sales_tracker",
          "invoices", 
          "expenses", 
          "accounts", 
          "profile", 
          "reports", 
          "billing-centre", 
          "offline-sync"
        ];
        if (!allowedAgroDealerTabs.includes(activeTab)) {
          console.warn(`[Entitlement Engine Guard] Agro-Dealer workspace boundary violation on ${activeTab}. Redirecting to Retail Shop View (agc-dealer-pos)...`);
          setActiveTab("agc-dealer-pos");
        }
      } else if (canonicalType === "institution_supplier") {
        const allowedSupplierTabs = [
          "agc-financier-portal", 
          "agrodealer-consignment", 
          "partner-portal", 
          "inventory", 
          "sales", 
          "invoices", 
          "reports", 
          "profile", 
          "billing-centre", 
          "offline-sync"
        ];
        if (!allowedSupplierTabs.includes(activeTab)) {
          console.warn(`[Entitlement Engine Guard] Supplier workspace boundary violation on ${activeTab}. Redirecting to Supplier Portal View (agc-financier-portal)...`);
          setActiveTab("agc-financier-portal");
        }
      } else if (canonicalType === "offtaker") {
        const allowedOfftakerTabs = [
          "offtaker-marketplace",
          "inventory",
          "sales",
          "invoices",
          "expenses",
          "accounts",
          "profile",
          "reports",
          "billing-centre",
          "offline-sync"
        ];
        if (!allowedOfftakerTabs.includes(activeTab)) {
          console.warn(`[Entitlement Engine Guard] Offtaker workspace boundary violation on ${activeTab}. Redirecting to Offtaker Portal View (offtaker-marketplace)...`);
          setActiveTab("offtaker-marketplace");
        }
      } else if (canonicalType === "mabala_partner") {
        const allowedPartnerTabs = [
          "partner-portal",
          "inventory",
          "sales",
          "invoices",
          "reports",
          "profile",
          "billing-centre",
          "offline-sync"
        ];
        if (!allowedPartnerTabs.includes(activeTab)) {
          console.warn(`[Entitlement Engine Guard] Mabala Partner workspace boundary violation on ${activeTab}. Redirecting to Partner Portal View (partner-portal)...`);
          setActiveTab("partner-portal");
        }
      } else if (canonicalType === "farmer" && !isSuperAdminUser) {
        const disallowedFarmerTabs = [
          "platform-admin",
          "agc-super-admin",
          "lipila-payment-tracker",
          "audit-archive",
          "permissions",
          "agc-dealer-pos",
          "agc-financier-portal",
          "partner-portal"
        ];
        if (disallowedFarmerTabs.includes(activeTab)) {
          console.warn(`[Entitlement Engine Guard] Farmer workspace boundary violation on ${activeTab}. Redirecting to Farmer Workspace (dashboard)...`);
          setActiveTab("dashboard");
        }
      }
    }
  }, [isAuthLoading, isAuthenticated, currentRole, userProfile.email, activeTab]);

  // Auto-logout after 5 minutes of inactivity to protect farm workspace
  useEffect(() => {
    if (!isAuthenticated) return;

    let timeoutId: NodeJS.Timeout;

    const resetTimer = () => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(logoutUser, 5 * 60 * 1000); // 5 minutes inactivity limit
    };

    const logoutUser = () => {
      // Payment Guard: Do NOT auto-logout user while a payment transaction is actively submitting, pending PIN entry, or polling
      if (lipilaPaymentStatus === "Pending" || lipilaPaymentStatus === "Submitting" || Boolean(lipilaCheckout)) {
        console.log("[Mabala Security] Deferring inactivity logout: Payment transaction is actively processing/polling.");
        resetTimer();
        return;
      }

      console.warn("[Mabala Security] Session auto-expired due to 5 minutes of inactivity.");
      const currentEmailOrId = auth.currentUser?.email || userProfile.email || "";
      if (currentEmailOrId) {
        try {
          localStorage.setItem("mabala_last_login_id", currentEmailOrId);
        } catch (e) {}
      }
      setSessionError("You have been signed out due to 5 minutes of inactivity to secure your workspace. You can sign in again from another browser or device with the same ID.");
      signOut(auth).then(() => {
        setIsAuthenticated(false);
      }).catch((err) => {
        console.error("[Mabala Security] Error signing out on expiration:", err);
      });
    };

    // Human activity events to listen to on window level
    const activityEvents = ["mousedown", "mousemove", "keydown", "scroll", "touchstart", "click"];

    // Initialize the inactivity countdown timer
    resetTimer();

    // Attach event listeners for user engagement
    activityEvents.forEach((eventName) => {
      window.addEventListener(eventName, resetTimer);
    });

    // Cleanup listeners and clear timeout on disconnect, tab closing, or state change
    return () => {
      if (timeoutId) clearTimeout(timeoutId);
      activityEvents.forEach((eventName) => {
        window.removeEventListener(eventName, resetTimer);
      });
    };
  }, [isAuthenticated, lipilaPaymentStatus, lipilaCheckout]);

  // Multi-tier local offline snapshot persistence (survives offline, refresh, logout)
  // Cloud writes are handled granularly per-entity via sessionWriteGuard — no whole-blob mega-document cloud dumps.
  useEffect(() => {
    // CRITICAL: During remote support impersonation, NEVER capture or save state to the Super Admin's local snapshot!
    if (impersonation) return;

    const activeEmail = userProfile?.email || auth.currentUser?.email || (isOfflineSession && pendingOfflineCreds?.email) || "";
    if (!activeEmail) return;
    
    FarmPersistenceService.captureAndSaveCurrentState(activeEmail, {
      farms, accounts, suppliers, customers, expenses, invoices, creditNotes, quotations,
      crops, employees, payslips, poultry, fish, orchard_nursery_batches: orchardNurseryBatches,
      orchard_trees: orchardTrees, orchard_activities: orchardActivities, inventory, cashSales,
      loans, investments, livestock, assets, otherRevenues, leaveRecords, employeeAdvances,
      auditLogs, archivedRecords, teamMembers, credits, smsCredits, subscriptionTier,
      workspaceMode, farmStatus, userProfile, contactDetails
    }).catch(e => console.warn("[FarmPersistence] Local snapshot notice:", e));
  }, [
    isAuthenticated,
    isOfflineSession,
    workspaceMode,
    farms,
    accounts,
    suppliers,
    customers,
    expenses,
    invoices,
    creditNotes,
    quotations,
    crops,
    employees,
    payslips,
    poultry,
    fish,
    orchardNurseryBatches,
    orchardTrees,
    orchardActivities,
    inventory,
    cashSales,
    loans,
    investments,
    livestock,
    assets,
    otherRevenues,
    leaveRecords,
    employeeAdvances,
    auditLogs,
    archivedRecords,
    teamMembers,
    credits,
    smsCredits,
    subscriptionTier,
    farmStatus,
    userProfile,
    contactDetails
  ]);

  // Auto-fetch mobile holder name query (live mock registry proxy)
  useEffect(() => {
    let active = true;
    const formattedPhone = normalizeZambianMobileNumber(lipilaPhone);

    if (formattedPhone.startsWith("260") && formattedPhone.length === 12) {
      setLipilaSearchingName(true);
      setLipilaHolderName("");
      setLipilaError("");
      
      const delayDebounceFn = setTimeout(async () => {
        try {
          const nameHint = lipilaCheckout?.registrationData?.fullName || lipilaCheckout?.registrationData?.storeName || userProfile?.name || "";
          const url = `/api/payments/lookup?accountNumber=${formattedPhone}${nameHint ? `&nameHint=${encodeURIComponent(nameHint)}` : ""}`;
          const data = await safeFetchJsonClient(url);
          
          if (active && data && data.success) {
            setLipilaHolderName(data.holderName);
            setLipilaSearchingName(false);
            return;
          }
        } catch (err) {
          console.error("Name lookup query failed:", err);
        }

        // Failsafe client-side KYC fallback so the name is always shown
        if (active) {
          let resolvedName = "";
          const phone = formattedPhone;
          if (phone === "26097100000" || phone === "260978070734" || phone.endsWith("070734") || phone.endsWith("100000")) {
            resolvedName = "Sula Shikasuli (Farmer Wallet)";
          } else if (phone === "260961888333" || phone.endsWith("888333")) {
            resolvedName = "Dr. Zoie K Chibeka (Livestock Consultant)";
          } else if (phone === "260771555555" || phone.endsWith("555555")) {
            resolvedName = "Benson Ng'andu (Sunrise Operator)";
          } else if (phone === "260971001155" || phone.endsWith("001155")) {
            resolvedName = "Chileshe Banda";
          }
          
          const nameHint = lipilaCheckout?.registrationData?.fullName || lipilaCheckout?.registrationData?.storeName || userProfile?.name || "";
          if (!resolvedName && nameHint) {
            resolvedName = nameHint.trim();
          }
          
          if (!resolvedName) {
            const zambianFirstNames = ["Chileshe", "Mulenga", "Mwansa", "Grace", "Kondwani", "Luyando", "Njavwa", "Misozi", "Sipho", "Mutale", "Shadrick", "Gift", "Kabaso", "Emmanuel", "Mwape"];
            const zambianLastNames = ["Phiri", "Banda", "Mwanza", "Tembo", "Zulu", "Lungu", "Chanda", "Soko", "Hachipuka", "Kapiri", "Ng'andu", "Bwalya", "Kampamba"];
            
            let hash = 0;
            for (let i = 0; i < phone.length; i++) {
              hash += phone.charCodeAt(i);
            }
            const firstIdx = hash % zambianFirstNames.length;
            const lastIdx = (hash + 7) % zambianLastNames.length;
            resolvedName = `${zambianFirstNames[firstIdx]} ${zambianLastNames[lastIdx]}`;
          }
          setLipilaHolderName(resolvedName);
          setLipilaSearchingName(false);
        }
      }, 600);
      
      return () => {
        active = false;
        clearTimeout(delayDebounceFn);
      };
    } else {
      setLipilaHolderName("");
      setLipilaSearchingName(false);
    }
  }, [lipilaPhone, lipilaCheckout, userProfile]);

  const recordLipilaTransactionToFirestore = async (txRecord: any) => {
    if (!db) return;
    try {
      const formattedTx = {
        id: txRecord.id,
        transactionType: txRecord.packageType === "subscription" ? "Subscription" : txRecord.packageType === "credits" ? "Credit Top-Up" : "Payment",
        module: txRecord.packageType === "subscription" ? "SUBSCRIPTIONS" : "CREDIT_LEDGER",
        provider: txRecord.phone?.startsWith("26097") || txRecord.phone?.startsWith("097") ? "Airtel Money" : txRecord.phone?.startsWith("26096") || txRecord.phone?.startsWith("096") ? "MTN Money" : "Zamtel Kwacha",
        accountNumber: txRecord.phone || "26097100000",
        customerName: txRecord.holderName || userProfile?.name || "Farm Owner",
        tenantId: userProfile?.tenantId || "MAB-TENANT-001",
        amount: Number(txRecord.amount) || 0,
        currency: txRecord.currency || "ZMW",
        status: txRecord.status || "Successful",
        narration: `Mabala ${txRecord.packageType || 'Payment'}: ${txRecord.packageName || 'Upgrade'}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        referenceId: txRecord.referenceId || `ref-${Date.now()}`
      };
      await setDoc(doc(db, "lipilaTransactions", txRecord.id), formattedTx, { merge: true });
      await setDoc(doc(db, "superAdmin", "lipilaTransactions", "records", txRecord.id), formattedTx, { merge: true });
    } catch (e) {
      console.warn("Firestore recordLipilaTransactionToFirestore warning:", e);
    }
  };

  // Handle successful award logic
  const handlePaymentSuccessAllocation = async (checkoutObj: any, existingUid?: string) => {
    // Record Lipila Successful Tx!
    const newTx = {
      id: "tx-lipila-" + Date.now(),
      referenceId: lipilaRefId || `ref-${Date.now()}`,
      amount: Number(checkoutObj.price) || 0,
      currency: checkoutObj.currency || "ZMW",
      phone: lipilaPhone || "26097100000",
      holderName: lipilaHolderName || userProfile?.name || "Farm Owner",
      packageName: checkoutObj.name,
      packageType: checkoutObj.type,
      status: "Successful" as const,
      date: new Date().toISOString().replace('T', ' ').slice(0, 19)
    };
    setLipilaTransactions(prev => [newTx, ...prev]);
    recordLipilaTransactionToFirestore(newTx);

    const awardedCredits = Number(checkoutObj.creditsToAward) || 0;
    const isSmsPackage = Boolean(
      checkoutObj.name?.toLowerCase().includes("sms") || 
      checkoutObj.type === "sms" || 
      checkoutObj.type === "sms_topup" ||
      checkoutObj.description?.toLowerCase().includes("sms")
    );

    let awardedSmsCredits = Number(checkoutObj.smsCreditsToAward) || 0;
    if (isSmsPackage && awardedSmsCredits === 0) {
      awardedSmsCredits = Number(checkoutObj.creditsToAward) || 0;
      if (awardedSmsCredits === 0) {
        if (checkoutObj.name?.includes("50") || Number(checkoutObj.price) === 45) awardedSmsCredits = 50;
        else if (checkoutObj.name?.includes("150") || Number(checkoutObj.price) === 120) awardedSmsCredits = 150;
        else if (checkoutObj.name?.includes("500") || Number(checkoutObj.price) === 350) awardedSmsCredits = 500;
        else awardedSmsCredits = Math.round(Number(checkoutObj.price || 0) * 1.1) || 50;
      }
    }

    if (isSmsPackage || awardedSmsCredits > 0) {
      setSmsCredits(prev => {
        const next = (Number(prev) || 0) + awardedSmsCredits;
        try {
          localStorage.setItem("mabala_sms_credits", String(next));
        } catch (_) {}
        return next;
      });
      showToast(`🎉 Payment Confirmed! Successfully credited +${awardedSmsCredits} SMS Credits to your account.`, "success");
    } else {
      setCredits(prev => {
        const next = (Number(prev) || 0) + awardedCredits;
        try {
          localStorage.setItem("mabala_credits", String(next));
        } catch (_) {}
        return next;
      });
      showToast(`🎉 Payment Confirmed! Successfully credited +${awardedCredits} AI Platform Credits to your account.`, "success");
    }

    if (checkoutObj.type === "subscription" && !isSmsPackage) {
      setSubscriptionTier(checkoutObj.name);
      
      if (checkoutObj.name.includes("Veterinary") || checkoutObj.name.includes("Doctor")) {
        setCurrentRole("Veterinary Doctor");
        setWorkspaceMode("Veterinary");
      } else if (checkoutObj.name.includes("Agro-Vet")) {
        setCurrentRole("Agro-Vet Specialist");
        setWorkspaceMode("Veterinary");
      } else {
        setCurrentRole("Farm Owner");
        setWorkspaceMode("Farmer");
      }

      setCredits(prev => prev + awardedCredits);
      const awardedSmsCredits = Number(checkoutObj.smsCreditsToAward) || 0;
      if (awardedSmsCredits > 0) {
        setSmsCredits(prev => prev + awardedSmsCredits);
      }

      const newCtx = {
        id: "CTX-" + Date.now(),
        date: new Date().toISOString().slice(0, 10),
        farmName: activeFarm?.name || "Sunrise Agro-Tech Farms",
        type: "Allotment",
        amount: awardedCredits > 0 ? awardedCredits : awardedSmsCredits,
        description: awardedSmsCredits > 0 
          ? `Purchased ${awardedSmsCredits} dedicated SMS Credits top-up`
          : `Upgraded to subscription "${checkoutObj.name}" via Lipila Live Pay`,
        adminUser: userProfile?.name || "Tenant"
      };
      setCreditTransactions(prev => [newCtx, ...prev]);

      // Monthly / Signup Reseller Commission Recording
      if (Number(checkoutObj.price) > 0) {
        try {
          const regResellerCode = checkoutObj.registrationData?.resellerCode;
          const regResellerId = checkoutObj.registrationData?.resellerId;
          const userResellerCode = (userProfile as any)?.resellerCode;
          const userResellerId = (userProfile as any)?.resellerId;
          const effectiveResellerRef = regResellerCode || userResellerCode || regResellerId || userResellerId;

          if (effectiveResellerRef) {
            resellerService.recordSubscriptionCommission({
              farmerUid: existingUid || (userProfile as any)?.uid || checkoutObj.registrationData?.email || "user-sub",
              farmerName: checkoutObj.registrationData?.fullName || (userProfile as any)?.name || "Subscribed Farmer",
              farmerEmail: checkoutObj.registrationData?.email || (userProfile as any)?.email || "",
              farmerPhone: checkoutObj.registrationData?.phone || (userProfile as any)?.phone || "",
              farmOrBusinessName: checkoutObj.registrationData?.farmName || (userProfile as any)?.farmName || "",
              subscriptionPackage: checkoutObj.name || "Mabala Farm Subscription",
              subscriptionFeeZMW: Number(checkoutObj.price) || 0,
              resellerCodeOrId: effectiveResellerRef,
              paymentReference: lipilaRefId || newTx.referenceId || `LIP-SUB-${Date.now()}`,
              paymentMethod: "Lipila Digital Gateway"
            }).then((record) => {
              if (record) {
                console.log("[Reseller Engine] Accrued commission for reseller partner:", record.resellerName, `ZMW ${record.commissionAmountZMW}`);
              }
            }).catch((err) => {
              console.warn("[Reseller Engine] Error recording subscription commission:", err);
            });
          }
        } catch (e) {
          console.warn("[Reseller Engine] Error in commission recording block:", e);
        }
      }

      if (checkoutObj.registrationData) {
        const r = checkoutObj.registrationData;
        let uid = existingUid || "uid-" + Date.now();
        
        if (!existingUid && isConfigured && r.email && r.password) {
          try {
            localStorage.setItem("registrations_in_progress_" + r.email.toLowerCase(), "true");
            localStorage.setItem("mabala_google_bypass_" + r.email.toLowerCase(), "true");
            const userCred = await createUserWithEmailAndPassword(auth, r.email, r.password);
            uid = userCred.user.uid;
          } catch (err: any) {
            console.error("Auth creation in success callback failed, maybe already exists:", err);
            if (auth.currentUser) {
              uid = auth.currentUser.uid;
            }
          }
        }

        // Execute dynamic sign-up registration
        setSelectedCountry(r.country);
        const prov = r.province || (r.country?.code === "ZM" ? "Lusaka" : "");
        const town = r.district || r.town || (r.country?.code === "ZM" ? "Lusaka" : "");
        const loc = r.farmLocation || (prov && town ? resolveDistrictCoordinates(prov, town) : { lat: -15.4167, lng: 28.2833 });

        const registeredFarmName = r.farmName?.trim() || (r.fullName ? `${r.fullName}'s Farm` : "Sunrise Agro-Tech Farm");
        const farmAddr = `${town}${town && prov ? ", " : ""}${prov}${prov && r.country?.name ? ", " : ""}${r.country?.name || "Zambia"}`;

        const uProfile = {
          uid,
          name: r.fullName,
          email: r.email,
          phone: r.phone || "",
          farmName: registeredFarmName,
          province: prov,
          district: town,
          town: town,
          tpin: r.tpin || "",
          resellerCode: r.resellerCode || "",
          resellerId: r.resellerId || "",
          resellerName: r.resellerName || ""
        };
        setUserProfile(uProfile);

        try {
          localStorage.setItem("mabala_user_profile", JSON.stringify(uProfile));
          localStorage.setItem("mabala_registered_farm_name", registeredFarmName);
          localStorage.setItem("mabala_farm_name", registeredFarmName);
          localStorage.setItem("mabala_farm_province", prov);
          localStorage.setItem("mabala_farm_district", town);
          localStorage.setItem("mabala_farm_phone", r.phone || "");
          localStorage.setItem("mabala_farm_email", r.email);
          localStorage.setItem("mabala_farm_tpin", r.tpin || "");
          localStorage.setItem("mabala_farm_address", farmAddr);
        } catch (e) {}

        const initialFarms = [
          {
            id: "farm-1",
            name: registeredFarmName,
            letterheadTitle: registeredFarmName,
            letterheadSubtitle: "Corporate Agricultural Operations",
            letterheadAddress: farmAddr,
            tpin: r.tpin || "",
            logoUrl: r.logoUrl || "",
            logo: r.logoUrl || "",
            address: farmAddr,
            province: prov,
            district: town,
            town: town,
            location: {
              province: prov,
              district: town,
              lat: loc.lat,
              lng: loc.lng
            },
            farmLocation: loc,
            latitude: loc.lat,
            longitude: loc.lng,
            phone: r.phone || "",
            email: r.email,
            financialYearStart: "2026-01-01",
            financialYearEnd: "2026-12-31",
            currency: r.country?.currency || "ZMW",
            currencySymbol: r.country?.symbol || "K",
            taxSystem: r.country?.defaultTaxSystem || "TOT_5",
            taxType: "TOT_5"
          }
        ];
        
        setFarms(initialFarms);
        try {
          localStorage.setItem("mabala_farms", JSON.stringify(initialFarms));
        } catch (e) {}
        setSuppliers([]);
        setCustomers([]);
        setExpenses([]);
        setInvoices([]);
        setQuotations([]);
        setCrops([]);
        setEmployees([]);
        setPoultry([]);
        setFish([]);
        setInventory([]);
        setLoans([]);
        setInvestments([]);
        setCashSales([]);
        setLivestock([]);
        const initialAccounts = INITIAL_ACCOUNTS.map(a => ({ ...a, balance: 0 }));
        setAccounts(initialAccounts);
        setCredits(awardedCredits);

        // Write directly to Firestore using setDoc to ensure DB holds the profile!
        if (isConfigured && uid) {
          try {
            const docRef = doc(db, "users_data", uid);
            await setDoc(docRef, {
              uid,
              email: r.email.trim().toLowerCase(),
              password: r.password,
              loginPassword: r.password,
              rawPassword: r.password,
              credits: awardedCredits,
              subscriptionTier: checkoutObj.name,
              workspaceMode: checkoutObj.name.includes("Veterinary") || checkoutObj.name.includes("Agro-Vet") ? "Veterinary" : "Farmer",
              agreeTerms: r.agreeTerms || true,
              tpin: r.tpin || "",
              logoUrl: r.logoUrl || "",
              resellerCode: r.resellerCode || "",
              resellerId: r.resellerId || "",
              resellerName: r.resellerName || "",
              farms: initialFarms,
              accounts: initialAccounts,
              suppliers: [],
              customers: [],
              expenses: [],
              invoices: [],
              quotations: [],
              crops: [],
              employees: [],
              payslips: [],
              poultry: [],
              fish: [],
              inventory: [],
              loans: [],
              investments: [],
              cashSales: [],
              livestock: []
            });
            console.log("Successfully wrote paid registration account profile into firestore:", r.email);

            // Invoke the backend workspace provisioning transactional function!
            try {
              const { getFunctions, httpsCallable } = await import("firebase/functions");
              const { getApp } = await import("firebase/app");
              const functions = getFunctions(getApp());
              const provisionWorkspaceFn = httpsCallable(functions, "provisionWorkspace");
              await provisionWorkspaceFn({
                farmName: r.farmName,
                primaryContact: r.phone || "+26097100000",
                country: r.country.name,
                currency: r.country.currency,
                selectedTier: checkoutObj.name,
                province: prov,
                district: town,
                location: {
                  province: prov,
                  district: town,
                  lat: loc.lat,
                  lng: loc.lng
                },
                agreeTerms: r.agreeTerms || true,
                tpin: r.tpin || "",
                logoUrl: r.logoUrl || ""
              });
              console.log("Successfully ran backend workspace provisioning transaction.");
            } catch (fnErr) {
              console.error("Backend provisionWorkspace function call failed (continuing with local setup):", fnErr);
            }
            // Log referral signup if any
            try {
              await processReferralSignup(uid, r.email.trim().toLowerCase(), r.fullName, checkoutObj.name, Number(checkoutObj.price) || 0);
            } catch (refErr) {
              console.error("[Referral Engine] Error logging signup in handlePaymentSuccessAllocation:", refErr);
            }

            // Only redirect and authenticate on successful DB write
            setIsAuthenticated(true);
            setActiveTab("dashboard");
            setCheckoutSetupError(null);
          } catch (dbErr: any) {
            console.error("Failed to write users_data to firestore in success callback:", dbErr);
            console.warn(`[MANUAL RECOVERY INFO] Email: ${r.email}, Reference: ${lipilaRefId || "unknown-ref"}, UID: ${uid}, Error: ${dbErr?.message}`);
            
            setCheckoutSetupError({
              error: dbErr?.message || "Failed to establish your account document in Firestore database.",
              email: r.email,
              paymentReference: lipilaRefId || `ref-${Date.now()}`,
              uid,
              checkoutObj,
              retryType: "subscription"
            });
          }
        } else {
          setIsAuthenticated(true);
          setActiveTab("dashboard");
        }
        
        localStorage.removeItem("registrations_in_progress_" + r.email.toLowerCase());
      }

    } else if (checkoutObj.type === "vendor-subscription") {
      setSubscriptionTier(checkoutObj.name);
      setCredits(awardedCredits);
      
      if (checkoutObj.registrationData) {
        const r = checkoutObj.registrationData;
        let uid = "uid-" + Date.now();
        
        if (isConfigured && r.email && r.password) {
          try {
            localStorage.setItem("registrations_in_progress_" + r.email.toLowerCase(), "true");
            localStorage.setItem("mabala_google_bypass_" + r.email.toLowerCase(), "true");
            const userCred = await createUserWithEmailAndPassword(auth, r.email, r.password);
            uid = userCred.user.uid;
          } catch (err: any) {
            console.error("Auth creation in vendor success callback failed:", err);
            if (auth.currentUser) {
              uid = auth.currentUser.uid;
            }
          }
        }

        const randomColors = ["bg-emerald-600", "bg-indigo-600", "bg-sky-600", "bg-amber-600", "bg-purple-600"];
        const randomColor = randomColors[Math.floor(Math.random() * randomColors.length)];

        const newVendor: MarketVendor = {
          id: `vend-custom-${Date.now()}`,
          name: r.storeName,
          category: r.category,
          location: r.location,
          distanceKm: Number(r.distanceKm || 15),
          phone: r.phone,
          email: r.email,
          subscriptionPackage: checkoutObj.name,
          status: "Active", // Land straight on store front
          joinedDate: new Date().toISOString().split("T")[0],
          expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
          credits: awardedCredits,
          logoColor: randomColor,
          logoUrl: r.logoUrl
        };

        setMarketplaceVendors(prev => {
          const updated = [...prev, newVendor];
          localStorage.setItem("mabala_marketplace_vendors", JSON.stringify(updated));
          return updated;
        });

        const uProfile = {
          uid,
          name: r.storeName,
          email: r.email,
          phone: r.phone,
          role: "Agro Dealer",
          tenantType: "agro_dealer"
        };
        setUserProfile(uProfile);
        setCurrentRole("Agro Dealer");
        localStorage.setItem("mabala_user_profile", JSON.stringify(uProfile));
        saveUserRoleToRegistry(r.email, "Agro Dealer", "agro_dealer");

        // Setup mock farms & accounting modules for valid farmer session reference bindings
        const initialFarms = [
          {
            id: "farm-1",
            name: r.storeName + " Farm Workspace",
            tpin: "100431290",
            address: r.location,
            phone: r.phone,
            email: r.email,
            financialYearStart: "2026-01-01",
            financialYearEnd: "2026-12-31",
            currency: "ZMK",
            currencySymbol: "ZK",
            taxSystem: "VAT" as const
          }
        ];
        
        setFarms(initialFarms);
        setSuppliers([]);
        setCustomers([]);
        setExpenses([]);
        setInvoices([]);
        setQuotations([]);
        setCrops([]);
        setEmployees([]);
        setPoultry([]);
        setFish([]);
        setInventory([]);
        setLoans([]);
        setInvestments([]);
        setCashSales([]);
        setLivestock([]);
        const initialAccounts = INITIAL_ACCOUNTS.map(a => ({ ...a, balance: 0 }));
        setAccounts(initialAccounts);

        if (isConfigured && uid) {
          try {
            const docRef = doc(db, "users_data", uid);
            await setDoc(docRef, {
              uid,
              email: r.email.trim().toLowerCase(),
              password: r.password,
              loginPassword: r.password,
              rawPassword: r.password,
              role: "Agro Dealer",
              tenantType: "agro_dealer",
              credits: awardedCredits,
              subscriptionTier: checkoutObj.name,
              workspaceMode: "Farmer",
              farms: initialFarms,
              accounts: initialAccounts,
              suppliers: [],
              customers: [],
              expenses: [],
              invoices: [],
              quotations: [],
              crops: [],
              employees: [],
              payslips: [],
              poultry: [],
              fish: [],
              inventory: [],
              loans: [],
              investments: [],
              cashSales: [],
              livestock: []
            });
            console.log("Successfully wrote paid vendor account profile into firestore:", r.email);

            // Only redirect and authenticate on successful DB write
            setIsAuthenticated(true);
            setActiveTab("marketplace");
            setCheckoutSetupError(null);
          } catch (dbErr: any) {
            console.error("Failed to write vendor users_data to firestore:", dbErr);
            console.warn(`[MANUAL RECOVERY INFO] Email: ${r.email}, Reference: ${lipilaRefId || "unknown-ref"}, UID: ${uid}, Error: ${dbErr?.message}`);
            
            setCheckoutSetupError({
              error: dbErr?.message || "Failed to establish your vendor account document in Firestore database.",
              email: r.email,
              paymentReference: lipilaRefId || `ref-${Date.now()}`,
              uid,
              checkoutObj,
              retryType: "vendor-subscription"
            });
          }
        } else {
          setIsAuthenticated(true);
          setActiveTab("marketplace");
        }
        
        localStorage.removeItem("registrations_in_progress_" + r.email.toLowerCase());
      }
    } else if (checkoutObj.type === "offtaker-subscription" as any) {
      setSubscriptionTier(checkoutObj.name);
      setCredits(awardedCredits);
      
      if (checkoutObj.registrationData) {
        const r = checkoutObj.registrationData;
        let uid = existingUid || "uid-" + Date.now();
        
        if (!existingUid && isConfigured && r.email && r.password) {
          try {
            localStorage.setItem("registrations_in_progress_" + r.email.toLowerCase(), "true");
            localStorage.setItem("mabala_google_bypass_" + r.email.toLowerCase(), "true");
            const userCred = await createUserWithEmailAndPassword(auth, r.email, r.password);
            uid = userCred.user.uid;
          } catch (err: any) {
            console.error("Auth creation in offtaker success callback failed:", err);
            if (auth.currentUser) {
              uid = auth.currentUser.uid;
            }
          }
        }

        setUserProfile({
          name: r.legalName,
          email: r.email,
          phone: r.contactPhone
        });
        
        setSubscriptionTier("Free Offtaker");
        setCredits(awardedCredits || 0);

        const initialFarms: any[] = [];
        setFarms(initialFarms);
        const initialAccounts = INITIAL_ACCOUNTS.map(a => ({ ...a, balance: 0 }));
        setAccounts(initialAccounts);

        if (isConfigured && uid) {
          try {
            const docRef = doc(db, "users_data", uid);
            await setDoc(docRef, {
              uid,
              email: r.email.trim().toLowerCase(),
              password: r.password,
              loginPassword: r.password,
              rawPassword: r.password,
              credits: awardedCredits || 0,
              subscriptionTier: "Free Offtaker",
              workspaceMode: "Offtaker",
              tenantType: "offtaker",
              role: "offtaker",
              offtaker_profile: {
                legalName: r.legalName,
                pacraNumber: r.pacraNumber,
                sector: r.sector,
                tpin: r.tpin,
                contactPhone: r.contactPhone,
                depotLocation: r.depotLocation
              },
              farms: initialFarms,
              accounts: initialAccounts,
              suppliers: [],
              customers: [],
              expenses: [],
              invoices: [],
              quotations: [],
              crops: [],
              employees: [],
              payslips: [],
              poultry: [],
              fish: [],
              inventory: [],
              loans: [],
              investments: [],
              cashSales: [],
              livestock: []
            });
            console.log("Successfully wrote paid offtaker account profile into firestore:", r.email);

            // Only redirect and authenticate on successful DB write
            setIsAuthenticated(true);
            setIsUnverifiedUser(false);
            setWorkspaceMode("Offtaker");
            setActiveTab("offtaker-marketplace");
            setCheckoutSetupError(null);
          } catch (dbErr: any) {
            console.error("Failed to write offtaker users_data to firestore:", dbErr);
            console.warn(`[MANUAL RECOVERY INFO] Email: ${r.email}, Reference: ${lipilaRefId || "unknown-ref"}, UID: ${uid}, Error: ${dbErr?.message}`);
            
            setCheckoutSetupError({
              error: dbErr?.message || "Failed to establish your offtaker account document in Firestore database.",
              email: r.email,
              paymentReference: lipilaRefId || `ref-${Date.now()}`,
              uid,
              checkoutObj,
              retryType: "offtaker-subscription"
            });
          }
        } else {
          setIsAuthenticated(true);
          setIsUnverifiedUser(false);
          setWorkspaceMode("Offtaker");
          setActiveTab("offtaker-marketplace");
        }
        
        localStorage.removeItem("registrations_in_progress_" + r.email.toLowerCase());
      }
    } else if (checkoutObj.type === "partner-subscription" as any) {
      setSubscriptionTier(checkoutObj.name);
      setCredits(awardedCredits);
      
      if (checkoutObj.registrationData) {
        const r = checkoutObj.registrationData;
        let uid = existingUid || "uid-" + Date.now();
        
        if (!existingUid && isConfigured && r.email && r.password) {
          try {
            localStorage.setItem("registrations_in_progress_" + r.email.toLowerCase(), "true");
            localStorage.setItem("mabala_google_bypass_" + r.email.toLowerCase(), "true");
            const userCred = await createUserWithEmailAndPassword(auth, r.email, r.password);
            uid = userCred.user.uid;
          } catch (err: any) {
            console.error("Auth creation in partner success callback failed:", err);
            if (auth.currentUser) {
              uid = auth.currentUser.uid;
            }
          }
        }

        const uProfile = {
          uid,
          name: r.fullName,
          email: r.email,
          phone: r.phoneNumber,
          role: "Institution Supplier",
          tenantType: "institution_supplier"
        };
        setUserProfile(uProfile);
        setCurrentRole("Institution Supplier");
        localStorage.setItem("mabala_user_profile", JSON.stringify(uProfile));
        saveUserRoleToRegistry(r.email, "Institution Supplier", "institution_supplier");
        
        setSubscriptionTier("Mabala Partner");
        setCredits(awardedCredits || 0);

        const initialFarms: any[] = [];
        setFarms(initialFarms);
        const initialAccounts: any[] = [];
        setAccounts(initialAccounts);

        const codeSuffix = Math.floor(100 + Math.random() * 900);
        const cleanNameSlug = r.fullName.replace(/[^a-zA-Z0-9]/g, "").toUpperCase().slice(0, 6);
        const refCode = `MB-${cleanNameSlug}${codeSuffix}`;

        if (isConfigured && uid) {
          try {
            const docRef = doc(db, "users_data", uid);
            await setDoc(docRef, {
              uid,
              email: r.email.trim().toLowerCase(),
              credits: awardedCredits || 0,
              subscriptionTier: "Mabala Partner",
              workspaceMode: "Partner",
              tenantType: "partner",
              role: "partner",
              userProfile: {
                uid,
                name: r.fullName,
                email: r.email.trim().toLowerCase(),
                phone: r.phoneNumber
              },
              farms: initialFarms,
              accounts: initialAccounts,
              suppliers: [],
              customers: [],
              expenses: [],
              invoices: [],
              quotations: [],
              crops: [],
              employees: [],
              payslips: [],
              poultry: [],
              fish: [],
              inventory: [],
              loans: [],
              investments: [],
              cashSales: [],
              livestock: []
            });

            const partnerRef = doc(db, "partners", uid);
            await setDoc(partnerRef, {
              fullName: r.fullName,
              phoneNumber: r.phoneNumber,
              mobileMoneyProvider: r.mobileMoneyProvider,
              email: r.email.trim().toLowerCase(),
              facebookGroupOrPageName: r.facebookGroupOrPageName || "",
              whatsappGroupName: r.whatsappGroupName || "",
              referralCode: refCode,
              referralLink: window.location.origin + "/r/" + refCode,
              commissionRate: 0.15,
              status: "pending_review",
              totalClicks: 0,
              totalSignups: 0,
              totalPaidConversions: 0,
              totalCommissionEarned: 0,
              totalCommissionPaid: 0,
              createdAt: new Date().toISOString(),
              approvedAt: null
            });
            console.log("Successfully wrote paid partner account profile into firestore:", r.email);

            // Only redirect and authenticate on successful DB writes
            setIsAuthenticated(true);
            setIsUnverifiedUser(false);
            setWorkspaceMode("Partner");
            setActiveTab("partner-portal");
            setCheckoutSetupError(null);
          } catch (dbErr: any) {
            console.error("Failed to write partner users_data or partners records to firestore:", dbErr);
            console.warn(`[MANUAL RECOVERY INFO] Email: ${r.email}, Reference: ${lipilaRefId || "unknown-ref"}, UID: ${uid}, Error: ${dbErr?.message}`);
            
            setCheckoutSetupError({
              error: dbErr?.message || "Failed to establish your partner documents in Firestore database.",
              email: r.email,
              paymentReference: lipilaRefId || `ref-${Date.now()}`,
              uid,
              checkoutObj,
              retryType: "partner-subscription"
            });
          }
        }
        
        localStorage.removeItem("registrations_in_progress_" + r.email.toLowerCase());
      }
    } else if (checkoutObj.type === "agronomist-subscription" as any) {
      setSubscriptionTier("Agronomist Advisory Plan (K180/mo)");
      setCredits(awardedCredits || 0);
      
      if (checkoutObj.registrationData) {
        const r = checkoutObj.registrationData;
        let uid = existingUid || "uid-" + Date.now();
        
        if (!existingUid && isConfigured && r.email && r.password) {
          try {
            localStorage.setItem("registrations_in_progress_" + r.email.toLowerCase(), "true");
            localStorage.setItem("mabala_google_bypass_" + r.email.toLowerCase(), "true");
            const userCred = await createUserWithEmailAndPassword(auth, r.email, r.password);
            uid = userCred.user.uid;
          } catch (err: any) {
            console.error("Auth creation in agronomist success callback failed:", err);
            if (auth.currentUser) {
              uid = auth.currentUser.uid;
            }
          }
        }

        const uProfile = {
          uid,
          name: r.fullName,
          email: r.email,
          phone: r.phone,
          role: "Agronomist",
          tenantType: "agronomist",
          cropSpecialisation: r.cropSpecialisation,
          location: r.location,
          bookingPricePerVisit: Number(r.bookingPricePerVisit) || 350,
          experienceBrief: r.experienceBrief,
          subscriptionTier: "Agronomist Advisory Plan (K180/mo)",
          subscriptionStatus: "active",
          validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
        };

        setUserProfile(uProfile);
        setCurrentRole("Agronomist");
        localStorage.setItem("mabala_user_profile", JSON.stringify(uProfile));
        saveUserRoleToRegistry(r.email, "Agronomist", "agronomist");

        // Save into local storage directory of agronomists so farmers can immediately see and book
        const agronomistRecord = {
          id: uid,
          uid,
          name: r.fullName,
          fullName: r.fullName,
          email: r.email,
          phone: r.phone,
          cropSpecialisation: r.cropSpecialisation,
          location: r.location,
          bookingPricePerVisit: Number(r.bookingPricePerVisit) || 350,
          experienceBrief: r.experienceBrief,
          status: "Active",
          joinedDate: new Date().toISOString().split("T")[0],
          subscriptionTier: "Agronomist Advisory Plan (K180/mo)",
          validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
        };

        try {
          const storedAgs = localStorage.getItem("mabala_agronomists_list");
          let agList = storedAgs ? JSON.parse(storedAgs) : [];
          agList = [agronomistRecord, ...agList.filter((a: any) => a.id !== uid && a.email !== r.email)];
          localStorage.setItem("mabala_agronomists_list", JSON.stringify(agList));
        } catch (e) {}

        const initialFarms: any[] = [{
          id: "farm-ag-1",
          name: r.fullName + " Agronomy Advisory Hub",
          tpin: "100431290",
          address: r.location,
          phone: r.phone,
          email: r.email,
          currency: "ZMW",
          currencySymbol: "K"
        }];
        setFarms(initialFarms);
        const initialAccounts = INITIAL_ACCOUNTS.map(a => ({ ...a, balance: 0 }));
        setAccounts(initialAccounts);

        if (isConfigured && uid) {
          try {
            await setDoc(doc(db, "users_data", uid), {
              uid,
              email: r.email.trim().toLowerCase(),
              credits: awardedCredits || 0,
              subscriptionTier: "Agronomist Advisory Plan (K180/mo)",
              subscriptionStatus: "active",
              validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
              workspaceMode: "Agronomist",
              tenantType: "agronomist",
              role: "agronomist",
              agronomist_profile: agronomistRecord,
              farms: initialFarms,
              accounts: initialAccounts,
              suppliers: [],
              customers: [],
              expenses: [],
              invoices: [],
              quotations: [],
              crops: [],
              employees: [],
              payslips: [],
              poultry: [],
              fish: [],
              inventory: [],
              loans: [],
              investments: [],
              cashSales: [],
              livestock: []
            });

            await setDoc(doc(db, "agronomists", uid), agronomistRecord);
            console.log("Successfully created agronomist document in firestore:", r.email);

            setIsAuthenticated(true);
            setIsUnverifiedUser(false);
            setActiveTab("advisory-portal");
            setCheckoutSetupError(null);
          } catch (dbErr: any) {
            console.error("Failed to write agronomist document to firestore:", dbErr);
            setCheckoutSetupError({
              error: dbErr?.message || "Failed to establish agronomist profile in database.",
              email: r.email,
              paymentReference: lipilaRefId || `ref-${Date.now()}`,
              uid,
              checkoutObj,
              retryType: "agronomist-subscription" as any
            });
          }
        } else {
          setIsAuthenticated(true);
          setIsUnverifiedUser(false);
          setActiveTab("advisory-portal");
        }
        
        localStorage.removeItem("registrations_in_progress_" + r.email.toLowerCase());
      }
    } else if (checkoutObj.is_unmetered_access) {
      const durationHours = checkoutObj.duration_hours || 24;
      const expiresAt = new Date(Date.now() + durationHours * 60 * 60 * 1000).toISOString();
      
      // Update unmetered states reactively
      setDailyBundleExpiresAt(expiresAt);
      localStorage.setItem("mabala_daily_bundle_expires_at", expiresAt);

      const newPass = {
        id: checkoutObj.id,
        name: checkoutObj.name,
        expiresAt,
        purchasedAt: new Date().toISOString()
      };
      setActiveAccessPass(newPass);

      const newCtx = {
        id: "CTX-" + Date.now(),
        date: new Date().toISOString().slice(0, 10),
        farmName: activeFarm?.name || "Sunrise Agro-Tech Farms",
        type: "Allotment",
        amount: 0,
        description: `Activated ${checkoutObj.name} (${durationHours} hours unmetered access)`,
        adminUser: userProfile?.name || "Tenant"
      };
      setCreditTransactions(prev => [newCtx, ...prev]);
    } else {
      setCredits(prev => prev + awardedCredits);

      const newCtx = {
        id: "CTX-" + Date.now(),
        date: new Date().toISOString().slice(0, 10),
        farmName: activeFarm?.name || "Sunrise Agro-Tech Farms",
        type: "Allotment",
        amount: awardedCredits,
        description: `Purchased +${awardedCredits} Credits Block via Lipila Live Pay`,
        adminUser: userProfile?.name || "Tenant"
      };
      setCreditTransactions(prev => [newCtx, ...prev]);
    }

    // Permanent immutable audit ledger entry for every successful Lipila payment
    const tenantId = impersonation ? impersonation.targetUid : (userProfile?.tenantId || (auth.currentUser ? auth.currentUser.uid : ""));
    const ledgerRecord = {
      id: "led-" + Date.now() + "-" + Math.floor(Math.random() * 1000),
      tenantId: tenantId || "local-tenant-id",
      timestamp: new Date().toISOString(),
      type: "allocation",
      amount: awardedCredits,
      previousBalance: credits,
      newBalance: credits + awardedCredits,
      moduleId: "billing",
      description: `IMMUTABLE LEDGER: Successful Lipila mobile money payment for ${checkoutObj.name} of ${checkoutObj.currency || "ZMW"} ${checkoutObj.price}. Ref: ${lipilaRefId || "local-test-ref"}. Allocated +${awardedCredits} credits.`,
      checksum: ""
    };
    ledgerRecord.checksum = calculateRecordHash(ledgerRecord);

    if (isConfigured && tenantId) {
      try {
        const ledgerColRef = collection(db, "tenants", tenantId, "creditLedger");
        const ledgerDocRef = doc(ledgerColRef, ledgerRecord.id);
        setDoc(ledgerDocRef, ledgerRecord).then(() => {
          console.log(`[Mabala Ledger] Securely persisted immutable ledger entry to Firestore: ${ledgerDocRef.id}`);
        });
      } catch (err) {
        console.error("Firestore immutable ledger persist failed:", err);
      }
    }
    
    // Sync local state reactively
    setCreditLedger(prev => [ledgerRecord, ...prev]);
  };

  // Handle payment cancellations or processing failures elegantly
  const handleLipilaCancelOrFailure = async (reason?: string) => {
    if (lipilaPollingIntervalRef.current) {
      clearInterval(lipilaPollingIntervalRef.current);
      lipilaPollingIntervalRef.current = null;
    }
    // 1. Clear checkout, phone, name info and reset status
    setLipilaCheckout(null);
    setLipilaPhone("");
    setLipilaHolderName("");
    setLipilaPaymentStatus("Idle");
    setLipilaPin("");
    setLipilaTimeRemaining(60);
    // Preserve error statement for reference
    setLipilaError(reason || "Payment Cancelled.");
  };

  const handleLipilaTimeoutOrPINAbort = (isTimeout: boolean) => {
    if (lipilaPollingIntervalRef.current) {
      clearInterval(lipilaPollingIntervalRef.current);
      lipilaPollingIntervalRef.current = null;
    }
    const errorMsg = isTimeout 
      ? "Payment Failed: LIPILA TRANSACTION ARRESTED: Payment authorization PIN was not provided. Account provisioning aborted." 
      : "Aborted: Wrong PIN was entered. Transaction declined by operator. Please try again.";
    
    setLipilaPaymentStatus("Idle");
    setLipilaPin("");
    setLipilaTimeRemaining(60);
    setLipilaError(errorMsg);
  };

  const handleCheckLipilaStatusManually = async () => {
    if (!lipilaRefId || !lipilaCheckout) return;
    if (lipilaFulfilledRefId.current === lipilaRefId) {
      console.log("[Lipila] Transaction already fulfilled for ref:", lipilaRefId);
      return;
    }

    // Immediately stop auto-polling interval upon manual check to prevent redundant API calls
    if (lipilaPollingIntervalRef.current) {
      clearInterval(lipilaPollingIntervalRef.current);
      lipilaPollingIntervalRef.current = null;
    }

    setLipilaSearchingName(true); // reuse searching state as a loading spinner
    setLipilaError("");
    try {
      const data = await safeFetchJsonClient(`/api/payments/check-status?referenceId=${lipilaRefId}`);
      if (data && data.isSandboxKey) {
        console.warn("[Lipila Payment Gateway] Running in production with a sandbox or fallback API key.");
      }
      const statusLower = String(data?.status || data?.data?.status || "").toLowerCase().trim();
      if (data && (statusLower === "successful" || statusLower === "success" || statusLower === "completed" || statusLower === "approved")) {
        if (lipilaFulfilledRefId.current !== lipilaRefId) {
          lipilaFulfilledRefId.current = lipilaRefId;
          setLipilaPaymentStatus("Successful");
          handlePaymentSuccessAllocation(lipilaCheckout);
        }
      } else if (data && (statusLower === "failed" || statusLower === "rejected" || statusLower === "error" || statusLower === "declined" || statusLower === "cancelled" || data.success === false)) {
        setLipilaPaymentStatus("Idle");
        setLipilaError(safeFormatError(data.message || data.error, "Payment was declined by the operator."));
      } else {
        const currentMsg = data?.message || "Payment is still pending. Please enter your PIN on your phone's push prompt and try again.";
        setLipilaError(currentMsg);
      }
    } catch (err: any) {
      setLipilaError("Unable to verify payment status from the gateway at this time. Please try again.");
    } finally {
      setLipilaSearchingName(false);
    }
  };

  // Lipila 300 seconds PIN countdown timer - strictly relies on referenceId status verification
  useEffect(() => {
    if (lipilaPaymentStatus !== "Pending" || !lipilaCheckout || !lipilaRefId) return;

    // Reset countdown to 300 when starting Pending
    setLipilaTimeRemaining(300);

    const timerId = setInterval(async () => {
      setLipilaTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timerId);
          // Query backend status endpoint via referenceId rather than assuming arbitrary outcome
          (async () => {
            try {
              const checkData = await safeFetchJsonClient(`/api/payments/check-status?referenceId=${lipilaRefId}`);
              if (checkData && (checkData.status === "Successful" || checkData.status === "Success" || checkData.status === "Completed")) {
                if (lipilaFulfilledRefId.current !== lipilaRefId) {
                  lipilaFulfilledRefId.current = lipilaRefId;
                  setLipilaPaymentStatus("Successful");
                  handlePaymentSuccessAllocation(lipilaCheckout);
                }
              } else {
                setLipilaError("Handset PIN timer elapsed, but gateway status verification is still active. Please click Check Payment Status Now if you entered your PIN.");
              }
            } catch {
              setLipilaError("Network check pending. Click Check Payment Status Now to re-query the gateway.");
            }
          })();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timerId);
  }, [lipilaPaymentStatus, lipilaCheckout, lipilaRefId, lipilaRetryTrigger]);

  // Poll transaction check status sequentially using setTimeout to prevent race conditions
  useEffect(() => {
    let isMounted = true;
    let timer: any = null;

    if (lipilaPaymentStatus !== "Pending" || !lipilaRefId || !lipilaCheckout) {
      if (lipilaPollingIntervalRef.current) {
        clearTimeout(lipilaPollingIntervalRef.current);
        clearInterval(lipilaPollingIntervalRef.current);
        lipilaPollingIntervalRef.current = null;
      }
      return;
    }

    if (lipilaFulfilledRefId.current === lipilaRefId) return;

    let localPollCount = 0;
    const MAX_POLL_LIMIT = 60; // Hard limit: 60 attempts * 4s = 240 seconds (4 minutes)

    const poll = async () => {
      if (!isMounted) return;

      if (lipilaFulfilledRefId.current === lipilaRefId) {
        return;
      }

      if (lipilaIsFetchingRef.current) {
        if (isMounted && lipilaPaymentStatus === "Pending") {
          timer = setTimeout(poll, 3000);
          lipilaPollingIntervalRef.current = timer;
        }
        return;
      }

      lipilaIsFetchingRef.current = true;
      localPollCount++;
      setLipilaPollingCount(localPollCount);

      // Hard Limit reached - Stop polling and mark Failed
      if (localPollCount >= MAX_POLL_LIMIT) {
        console.warn(`[Lipila Polling] Reached hard limit of ${MAX_POLL_LIMIT} attempts. Halting auto-polling and marking transaction Failed.`);
        const timeoutMsg = "Payment authorization timed out. Mobile money PIN was not confirmed on your handset within the time limit. Funds were not deducted.";
        setLipilaPaymentStatus("Failed");
        setLipilaError(timeoutMsg);
        showToast(`⏱️ ${timeoutMsg}`, "warning");
        lipilaIsFetchingRef.current = false;
        
        if (lipilaFulfilledRefId.current !== lipilaRefId) {
          lipilaFulfilledRefId.current = lipilaRefId;
          const failTxObj = {
            id: "tx-lipila-" + Date.now(),
            referenceId: lipilaRefId || `ref-${Date.now()}`,
            amount: Number(lipilaCheckout?.price) || 0,
            currency: "ZMW",
            phone: lipilaPhone || "26097100000",
            holderName: lipilaHolderName || userProfile?.name || "Farm Owner",
            packageName: lipilaCheckout?.name || "Premium Upgrade",
            packageType: lipilaCheckout?.type || "subscription",
            status: "Failed" as const,
            date: new Date().toISOString().replace('T', ' ').slice(0, 19),
            errorDetails: timeoutMsg
          };
          setLipilaTransactions(prev => [failTxObj, ...prev]);
          recordLipilaTransactionToFirestore(failTxObj);
        }
        return;
      }

      try {
        const data = await safeFetchJsonClient(`/api/payments/check-status?referenceId=${lipilaRefId}`);
        if (!isMounted) return;

        const statusLower = String(data?.status || data?.data?.status || "").toLowerCase().trim();
        if (data && (statusLower === "successful" || statusLower === "success" || statusLower === "completed" || statusLower === "approved")) {
          if (lipilaFulfilledRefId.current !== lipilaRefId) {
            lipilaFulfilledRefId.current = lipilaRefId;
            setLipilaPaymentStatus("Successful");
            handlePaymentSuccessAllocation(lipilaCheckout);
          }
          return;
        } else if (data && (statusLower === "failed" || statusLower === "rejected" || statusLower === "declined" || statusLower === "error" || statusLower === "cancelled" || data.success === false)) {
          const failMsg = safeFormatError(data.message || data.error, "Payment request declined or timed out.");
          const isPinOrExpiryError = /pin/i.test(failMsg) || /invalid/i.test(failMsg) || /expired/i.test(failMsg);
          
          if (lipilaFulfilledRefId.current !== lipilaRefId) {
            lipilaFulfilledRefId.current = lipilaRefId;

            // Record failed transaction for auditing logs
            setLipilaTransactions(prev => [
              {
                id: "tx-lipila-" + Date.now(),
                referenceId: lipilaRefId || `ref-${Date.now()}`,
                amount: Number(lipilaCheckout?.price) || 0,
                currency: "ZMW",
                phone: lipilaPhone || "26097100000",
                holderName: lipilaHolderName || userProfile?.name || "Farm Owner",
                packageName: lipilaCheckout?.name || "Premium Upgrade",
                packageType: lipilaCheckout?.type || "subscription",
                status: "Failed" as const,
                date: new Date().toISOString().replace('T', ' ').slice(0, 19),
                errorDetails: failMsg
              },
              ...prev
            ]);
            
            if (isPinOrExpiryError) {
              setLipilaError(failMsg);
            } else {
              await handleLipilaCancelOrFailure(`Lipila API Failure: ${failMsg}`);
            }
          }
          return;
        }
      } catch (err: any) {
        console.warn(`[Lipila Polling] Temporary network error at poll ${localPollCount}:`, err.message || err);
      } finally {
        lipilaIsFetchingRef.current = false;
      }

      if (isMounted && lipilaPaymentStatus === "Pending" && lipilaFulfilledRefId.current !== lipilaRefId) {
        timer = setTimeout(poll, 3000);
        lipilaPollingIntervalRef.current = timer;
      }
    };

    timer = setTimeout(poll, 3000);
    lipilaPollingIntervalRef.current = timer;

    return () => {
      isMounted = false;
      if (timer) clearTimeout(timer);
      if (lipilaPollingIntervalRef.current) {
        clearTimeout(lipilaPollingIntervalRef.current);
        clearInterval(lipilaPollingIntervalRef.current);
        lipilaPollingIntervalRef.current = null;
      }
    };
  }, [lipilaPaymentStatus, lipilaRefId, lipilaCheckout, lipilaPhone, lipilaHolderName, lipilaRetryTrigger]);

  const handleLipilaSubmitPayment = async () => {
    // Prevent duplicate payment creation while a payment is submitting or pending PIN entry
    if (lipilaPaymentStatus === "Submitting") {
      console.warn("[Lipila Payment Guard] Payment submission already in progress.");
      return;
    }

    if (lipilaPaymentStatus === "Pending" && lipilaRefId) {
      console.warn("[Lipila Payment Guard] A payment request is already pending PIN authorization with ref:", lipilaRefId);
      showToast("A payment request is already pending on your phone. Please authorize the PIN prompt or check status.", "info");
      return;
    }

    lipilaFulfilledRefId.current = null;
    lipilaIsFetchingRef.current = false;
    
    // Circuit Breaker: Ensure any existing polling is immediately terminated
    if (lipilaPollingIntervalRef.current) {
      clearTimeout(lipilaPollingIntervalRef.current);
      clearInterval(lipilaPollingIntervalRef.current);
      lipilaPollingIntervalRef.current = null;
    }

    if (typeof navigator !== "undefined" && !navigator.onLine) {
      setLipilaPaymentStatus("Failed");
      setLipilaError("Money movement and payment processing require an active internet connection. Offline queued payments are disabled for security. Please reconnect and try again.");
      return;
    }

    if (!lipilaPhone) {
      setLipilaPaymentStatus("Failed");
      setLipilaError("Please input active Mobile Money number.");
      return;
    }

    const canonicalPhone = normalizeZambianMobileNumber(lipilaPhone);
    const cleanDigits = canonicalPhone.replace(/\D/g, "");
    if (!cleanDigits.startsWith("260") || cleanDigits.length !== 12) {
      setLipilaPaymentStatus("Failed");
      setLipilaError(`Invalid Zambian mobile number format: "${lipilaPhone}". Please enter a valid 10-digit number (e.g., 0977344556, 096..., 095..., 077..., 076...) or 12-digit number starting with 260.`);
      return;
    }

    setLipilaPaymentStatus("Submitting");
    setLipilaError("");
    setLipilaPollingCount(0);

    const generatedRefId = `ref-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
    setLipilaRefId(generatedRefId);

    // Determine carrier provider (AIRTEL, MTN, ZAMTEL)
    let selectedProvider = "MTN";
    if (cleanDigits.startsWith("26097") || cleanDigits.startsWith("26077")) {
      selectedProvider = "AIRTEL";
    } else if (cleanDigits.startsWith("26095") || cleanDigits.startsWith("26075")) {
      selectedProvider = "ZAMTEL";
    }

    try {
      // 1. Check account balance on mobile number via Lipila API balance check route
      const checkBalRes = await safeFetchJsonClient("/api/payments/check-balance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          accountNumber: canonicalPhone,
          phone: canonicalPhone,
          requiredAmount: Number(lipilaCheckout?.price) || 1
        })
      });

      if (checkBalRes && checkBalRes.hasBalance === false) {
        // Circuit Breaker: Clear any polling on insufficient balance
        if (lipilaPollingIntervalRef.current) {
          clearTimeout(lipilaPollingIntervalRef.current);
          clearInterval(lipilaPollingIntervalRef.current);
          lipilaPollingIntervalRef.current = null;
        }
        setLipilaPaymentStatus("Failed");
        const failMsg = checkBalRes.message || `Insufficient account balance on mobile money account ${canonicalPhone}. Transaction terminated. Please top up and try again.`;
        setLipilaError(failMsg);
        const failTxObj = {
          id: "tx-lipila-" + Date.now(),
          referenceId: generatedRefId,
          amount: Number(lipilaCheckout?.price) || 0,
          currency: "ZMW",
          phone: canonicalPhone || "26097100000",
          holderName: lipilaHolderName || userProfile?.name || "Farm Owner",
          packageName: lipilaCheckout?.name || "Premium Upgrade",
          packageType: lipilaCheckout?.type || "subscription",
          status: "Failed" as const,
          date: new Date().toISOString().replace('T', ' ').slice(0, 19),
          errorDetails: failMsg
        };
        setLipilaTransactions(prev => [failTxObj, ...prev]);
        recordLipilaTransactionToFirestore(failTxObj);
        return;
      }

      // 2. Initiate collection if balance is verified
      const data = await safeFetchJsonClient("/api/payments/collect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          referenceId: generatedRefId,
          amount: Number(lipilaCheckout?.price) || 1,
          narration: `Mabala ${lipilaCheckout?.type === "subscription" ? "Subscription" : "Credits"}: ${lipilaCheckout?.name}`,
          accountNumber: canonicalPhone,
          phone: canonicalPhone,
          provider: selectedProvider,
          paymentPin: lipilaPin,
          currency: lipilaCheckout?.currency || "ZMW",
          email: (lipilaCheckout?.registrationData?.email) || userProfile.email || "owner@mabala.com",
          uid: auth.currentUser?.uid || "anonymous",
          packageName: lipilaCheckout?.name || "Mabala Upgrade Plan",
          packageType: lipilaCheckout?.type || "subscription",
          creditsToAward: Number(lipilaCheckout?.creditsToAward) || 0
        })
      });

      if (data && (data.isSandboxKey || data.warning)) {
        console.warn("[Lipila Payment Gateway] Application detected running in production with a sandbox/test API key.");
        showToast("⚠️ Payment Warning: Running in production with a sandbox key. Real wallet billing will not execute.", "warning");
      }

      // Circuit Breaker: Handle rejected or failed responses from backend / Lipila
      const statusLower = String(data?.status || data?.data?.status || "").toLowerCase().trim();
      const isFailed = !data || statusLower === "failed" || statusLower === "error" || statusLower === "rejected" || statusLower === "declined" || statusLower === "cancelled" || data.success === false || (data.statusCode && ["99", "01", "400", "401", "403", "404", "500"].includes(String(data.statusCode)));
      const isSuccessful = data && (statusLower === "successful" || statusLower === "success" || statusLower === "completed" || statusLower === "approved");

      if (isFailed) {
        if (lipilaPollingIntervalRef.current) {
          clearTimeout(lipilaPollingIntervalRef.current);
          clearInterval(lipilaPollingIntervalRef.current);
          lipilaPollingIntervalRef.current = null;
        }
        setLipilaPaymentStatus("Failed");
        const failMsg = data?.message || data?.error || data?.data?.message || "Payment collection request failed on the operator network.";
        setLipilaError(failMsg);
        showToast(`❌ Payment Failed: ${failMsg}`, "error");
        const failTxObj = {
          id: "tx-lipila-" + Date.now(),
          referenceId: generatedRefId,
          amount: Number(lipilaCheckout?.price) || 0,
          currency: "ZMW",
          phone: canonicalPhone || "26097100000",
          holderName: lipilaHolderName || userProfile?.name || "Farm Owner",
          packageName: lipilaCheckout?.name || "Premium Upgrade",
          packageType: lipilaCheckout?.type || "subscription",
          status: "Failed" as const,
          date: new Date().toISOString().replace('T', ' ').slice(0, 19),
          errorDetails: failMsg
        };
        setLipilaTransactions(prev => [failTxObj, ...prev]);
        recordLipilaTransactionToFirestore(failTxObj);
      } else if (isSuccessful) {
        if (lipilaPollingIntervalRef.current) {
          clearTimeout(lipilaPollingIntervalRef.current);
          clearInterval(lipilaPollingIntervalRef.current);
          lipilaPollingIntervalRef.current = null;
        }
        setLipilaPaymentStatus("Successful");
        handlePaymentSuccessAllocation(lipilaCheckout);
      } else {
        // Transition to Pending so UI waits for PIN authorization and polling engages
        setLipilaPaymentStatus("Pending");
      }
    } catch (err: any) {
      // Circuit Breaker: On HTTP 400 or any network/API exception, immediately clear timer and never poll
      if (lipilaPollingIntervalRef.current) {
        clearTimeout(lipilaPollingIntervalRef.current);
        clearInterval(lipilaPollingIntervalRef.current);
        lipilaPollingIntervalRef.current = null;
      }
      setLipilaPaymentStatus("Failed");
      const errMsg = err.message || "Payment collection failed. Please verify your phone number and try again.";
      setLipilaError(errMsg);
      showToast(`❌ Payment Failed: ${errMsg}`, "error");
      const failTxObj = {
        id: "tx-lipila-" + Date.now(),
        referenceId: generatedRefId,
        amount: Number(lipilaCheckout?.price) || 0,
        currency: "ZMW",
        phone: canonicalPhone || "26097100000",
        holderName: lipilaHolderName || userProfile?.name || "Farm Owner",
        packageName: lipilaCheckout?.name || "Premium Upgrade",
        packageType: lipilaCheckout?.type || "subscription",
        status: "Failed" as const,
        date: new Date().toISOString().replace('T', ' ').slice(0, 19),
        errorDetails: errMsg
      };
      setLipilaTransactions(prev => [failTxObj, ...prev]);
      recordLipilaTransactionToFirestore(failTxObj);
    }
  };

  // New Farm Form state
  const [newFarmName, setNewFarmName] = useState("");
  const [newFarmAddr, setNewFarmAddr] = useState("");
  const [newFarmPhone, setNewFarmPhone] = useState("");

  useEffect(() => {
    if (currentRole === "Platform Administrator") {
      setAdminClaimed(true);
      localStorage.setItem("mabala_admin_claimed", "true");
      if (!adminClaimantEmail && userProfile.email) {
        setAdminClaimantEmail(userProfile.email);
        localStorage.setItem("mabala_admin_claimant_email", userProfile.email);
      }
    }
  }, [currentRole, adminClaimantEmail, userProfile.email]);

  const [statusChangeLogs, setStatusChangeLogs] = useState<any[]>(() => {
    const cached = localStorage.getItem("mabala_status_change_logs");
    if (cached) {
      try { return JSON.parse(cached); } catch (e) {}
    }
    return [];
  });
  const [creditTransactions, setCreditTransactions] = useState<any[]>(() => {
    const cached = localStorage.getItem("mabala_credit_transactions");
    if (cached) {
      try { return JSON.parse(cached); } catch (e) {}
    }
    return [];
  });
  const [platformPackages, setPlatformPackages] = useState<any[]>([
    {
      id: "PLAN_SEEDING",
      name: "Seeding Tier",
      price: 0,
      yearly_price_zmw: 0,
      yearly_discount_pct: 0,
      priceUSD: 0,
      currency: "ZMW",
      credits: 0,
      is_unmetered: false,
      duration: "Free Forever",
      yearly_enabled: false,
      available_to: ["FARMER", "AGRO_DEALER", "VET_PRACTITIONER"],
      features: "Free Forever onboarding with zero-rated starting balance, cloud ledgering, and mobile money receipting",
      isActive: true
    },
    {
      id: "PLAN_MONTHLY",
      name: "Monthly Plan",
      price: 180.00,
      yearly_price_zmw: 1944.00,
      yearly_discount_pct: 10,
      priceUSD: 9.00,
      currency: "ZMW",
      credits: 1500,
      is_unmetered: false,
      duration: "1 Month",
      yearly_enabled: true,
      available_to: ["FARMER", "AGRO_DEALER", "VET_PRACTITIONER"],
      features: "1,500 operations write credits/mo, full farm & dealer ledger, input credit portal, storage sync, rollover permitted",
      isActive: true
    },
    {
      id: "PLAN_GROWTH",
      name: "Growth Plan",
      price: 650.00,
      yearly_price_zmw: 7020.00,
      yearly_discount_pct: 10,
      priceUSD: 32.50,
      currency: "ZMW",
      credits: 12000,
      is_unmetered: false,
      duration: "1 Month",
      yearly_enabled: true,
      available_to: ["FARMER", "AGRO_DEALER", "VET_PRACTITIONER"],
      features: "12,000 write credits/mo, 1 free agronomist visit/month, consignment hub access, priority agronomic support",
      isActive: true
    },
    {
      id: "PLAN_ENTERPRISE",
      name: "Enterprise Plan",
      price: 2500.00,
      yearly_price_zmw: 27000.00,
      yearly_discount_pct: 10,
      priceUSD: 125.00,
      currency: "ZMW",
      credits: 120000,
      is_unmetered: false,
      duration: "1 Month",
      yearly_enabled: true,
      available_to: ["FARMER", "AGRO_DEALER", "VET_PRACTITIONER"],
      features: "120,000 write credits/mo, 2 free agronomist visits + 2 free vet visits/mo, multi-warehouse nodes, API banking suite",
      isActive: true
    },
    {
      id: "BUNDLE_DAILY",
      name: "Daily Bundle",
      price: 25.00,
      priceUSD: 1.25,
      currency: "ZMW",
      credits: null,
      is_unmetered: true,
      duration: "24 Hours",
      duration_hours: 24,
      yearly_enabled: false,
      available_to: ["FARMER", "AGRO_DEALER", "VET_PRACTITIONER"],
      features: "24-hour unmetered connectivity, unmetered access, credit actions bypass the ledger, 100% full features, no lockout",
      isActive: true
    }
  ]);

  const [isAllFarmsActive, setIsAllFarmsActive] = useState<boolean>(false);
  const [farmAccountsMap, setFarmAccountsMap] = useState<Record<string, Account[]>>({});
  const [creditTiers, setCreditTiers] = useState([
    { id: "tier-1", name: "Tier 1: Basic Operations", cost: 1, modules: "Dashboard, Sales Tracker, User Profiles, Backup & Restore", color: "#94a3b8" },
    { id: "tier-2", name: "Tier 2: Standard Crop Operations", cost: 2, modules: "Crop Cycles, Milestones Planning, Expenses Ledger, Invoices & Quotes", color: "#3b82f6" },
    { id: "tier-3", name: "Tier 3: Capital Finance Hub", cost: 3, modules: "Finance & Loans Hub, Capital Investments, Asset Register, Depreciation", color: "#ec4899" },
    { id: "tier-4", name: "Tier 4: Statutory & Reports Pro", cost: 5, modules: "Chart of Accounts, IFRS Financial Reports, Statutory Ledger, Audit Log", color: "#8b5cf6" },
    { id: "tier-5", name: "Tier 5: Enterprise Aquaculture & Multi-Farm Pro", cost: 8, modules: "Aquaculture, Multi-Farm Management, Advanced Custom Analytics", color: "#10b981" }
  ]);

  useEffect(() => {
    if (isAuthenticated && auth.currentUser && userProfile) {
      IdentityIntegrityService.saveVerifiedProfile(auth.currentUser, userProfile);
    }
  }, [userProfile, isAuthenticated]);

  useEffect(() => {
    if (credits !== null) {
      localStorage.setItem("mabala_credits", String(credits));
    }
  }, [credits]);

  useEffect(() => {
    localStorage.setItem("mabala_sms_credits", String(smsCredits));
  }, [smsCredits]);

  useEffect(() => {
    const handleSmsUpdate = (e: any) => {
      if (e.detail?.smsCredits !== undefined) {
        setSmsCredits(Number(e.detail.smsCredits));
      }
    };
    window.addEventListener("mabala_sms_update", handleSmsUpdate);
    return () => window.removeEventListener("mabala_sms_update", handleSmsUpdate);
  }, []);

  useEffect(() => {
    localStorage.setItem("mabala_team_members", JSON.stringify(teamMembers));
  }, [teamMembers]);

  useEffect(() => {
    localStorage.setItem("mabala_subscription_tier", subscriptionTier);
  }, [subscriptionTier]);

  useEffect(() => {
    localStorage.setItem("mabala_workspace_mode", workspaceMode);
  }, [workspaceMode]);

  useEffect(() => {
    const loadCreditRules = async () => {
      if (!isConfigured) return;
      try {
        const rulesDocSnap = await getDoc(doc(db, "config", "creditRules"));
        if (rulesDocSnap.exists()) {
          const rulesData = rulesDocSnap.data();
          if (Array.isArray(rulesData.rules)) {
            setCreditTiers(rulesData.rules);
            console.log("[Mabala Credit Engine] Loaded dynamic credit rules from config/creditRules", rulesData.rules);
          }
        }
      } catch (err) {
        console.warn("[Mabala Credit Engine] Failed to load dynamic credit rules from database:", err);
      }
    };
    loadCreditRules();
  }, [isConfigured]);

  useEffect(() => {
    const tenantId = impersonation ? impersonation.targetUid : (userProfile?.tenantId || (auth.currentUser ? auth.currentUser.uid : ""));
    if (!isConfigured || !tenantId || activeTab !== "audit-archive" || !db) return;

    const colRef = collection(db, "tenants", tenantId, "creditLedger");
    const unsubscribe = onSnapshot(colRef, { includeMetadataChanges: true }, (querySnap) => {
      const list: any[] = [];
      querySnap.forEach(d => {
        list.push(d.data());
      });
      list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      setCreditLedger(list);
      console.log(`[Mabala Ledger] Synchronized ${list.length} ledger entries (fromCache: ${querySnap.metadata.fromCache}).`);
    }, (err) => {
      console.warn("[Mabala Ledger] Failed to load credit ledger from Firestore:", err);
    });

    return () => {
      unsubscribe();
    };
  }, [isConfigured, activeTab, credits, impersonation, userProfile?.tenantId]);

  useEffect(() => {
    localStorage.setItem("mabala_vet_fee_activation", String(vetFeeActivation));
  }, [vetFeeActivation]);

  useEffect(() => {
    localStorage.setItem("mabala_farms", JSON.stringify(farms));
  }, [farms]);

  useEffect(() => {
    const liveLivestockValue = (livestock || []).reduce((sum, r) => sum + (r.status === "Active" ? (Number(r.currentValue) || 0) : 0), 0);
    const livePoultryValue = (poultry || []).reduce((sum, p) => sum + ((p.status.includes("ACTIVE") || (p.status as string) === "active" || (p.status as string) === "Active") ? (Number(p.currentBatchValuation || ((p.currentHeadcount || p.currentCount || 0) * (p.currentMarketPricePerBird || 0))) || 0) : 0), 0);
    const expected1420Balance = liveLivestockValue + livePoultryValue;

    setAccounts(prev => {
      const existing = prev.find(a => a.code === "1420");
      if (existing && existing.balance === expected1420Balance) {
        return prev;
      }
      return prev.map(a => a.code === "1420" ? { ...a, balance: expected1420Balance } : a);
    });
  }, [livestock, poultry]);

  useEffect(() => {
    localStorage.setItem("mabala_accounts", JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    localStorage.setItem("mabala_suppliers", JSON.stringify(suppliers));
  }, [suppliers]);

  useEffect(() => {
    localStorage.setItem("mabala_customers", JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem("mabala_expenses", JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem("mabala_invoices", JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem("mabala_credit_notes", JSON.stringify(creditNotes));
  }, [creditNotes]);

  useEffect(() => {
    localStorage.setItem("mabala_quotations", JSON.stringify(quotations));
  }, [quotations]);

  useEffect(() => {
    localStorage.setItem("mabala_crops", JSON.stringify(crops));
  }, [crops]);

  useEffect(() => {
    localStorage.setItem("mabala_employees", JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem("mabala_payslips", JSON.stringify(payslips));
  }, [payslips]);

  useEffect(() => {
    localStorage.setItem("mabala_poultry", JSON.stringify(poultry));
  }, [poultry]);

  useEffect(() => {
    localStorage.setItem("mabala_fish", JSON.stringify(fish));
  }, [fish]);

  useEffect(() => {
    localStorage.setItem("mabala_orchard_nursery_batches", JSON.stringify(orchardNurseryBatches));
  }, [orchardNurseryBatches]);

  useEffect(() => {
    localStorage.setItem("mabala_orchard_trees", JSON.stringify(orchardTrees));
  }, [orchardTrees]);

  useEffect(() => {
    localStorage.setItem("mabala_orchard_activities", JSON.stringify(orchardActivities));
  }, [orchardActivities]);

  useEffect(() => {
    localStorage.setItem("mabala_inventory", JSON.stringify(inventory));
  }, [inventory]);

  useEffect(() => {
    localStorage.setItem("mabala_cash_sales", JSON.stringify(cashSales));
  }, [cashSales]);

  useEffect(() => {
    localStorage.setItem("mabala_loans", JSON.stringify(loans));
  }, [loans]);

  useEffect(() => {
    localStorage.setItem("mabala_investments", JSON.stringify(investments));
  }, [investments]);

  useEffect(() => {
    localStorage.setItem("mabala_livestock", JSON.stringify(livestock));
  }, [livestock]);

  useEffect(() => {
    localStorage.setItem("mabala_assets", JSON.stringify(assets));
  }, [assets]);

  useEffect(() => {
    localStorage.setItem("mabala_tasks", JSON.stringify(tasks));
  }, [tasks]);


  useEffect(() => {
    localStorage.setItem("mabala_other_revenues", JSON.stringify(otherRevenues));
  }, [otherRevenues]);

  useEffect(() => {
    localStorage.setItem("mabala_leave_records", JSON.stringify(leaveRecords));
  }, [leaveRecords]);

  useEffect(() => {
    localStorage.setItem("mabala_employee_advances", JSON.stringify(employeeAdvances));
  }, [employeeAdvances]);

  useEffect(() => {
    localStorage.setItem("mabala_audit_logs", JSON.stringify(auditLogs));
  }, [auditLogs]);

  useEffect(() => {
    localStorage.setItem("mabala_archived_records", JSON.stringify(archivedRecords));
  }, [archivedRecords]);

  useEffect(() => {
    localStorage.setItem("mabala_farm_status", farmStatus);
  }, [farmStatus]);

  useEffect(() => {
    localStorage.setItem("mabala_status_change_logs", JSON.stringify(statusChangeLogs));
  }, [statusChangeLogs]);

  useEffect(() => {
    localStorage.setItem("mabala_credit_transactions", JSON.stringify(creditTransactions));
  }, [creditTransactions]);

  useEffect(() => {
    if (credits !== null && credits > 0) {
      setHideReadonlyBanner(false);
    }
  }, [credits]);

  // Real-time multi-browser credit synchronization (Single Source of Truth in Firestore)
  // Real-time multi-browser credit synchronization (Single Source of Truth in Firestore)
  useEffect(() => {
    if (!isConfigured || !isAuthenticated) return;
    const targetUid = impersonation ? impersonation.targetUid : (userProfile?.tenantId || (auth.currentUser ? auth.currentUser.uid : ""));
    if (!targetUid) return;

    const walletDocRef = doc(db, "tenants", targetUid, "wallet", "credits");
    const smsWalletDocRef = doc(db, "tenants", targetUid, "wallet", "sms");
    const unsubscribe = onSnapshot(walletDocRef, (snap) => {
      if (snap.exists()) {
        const wData = snap.data();
        const liveBal = typeof wData.currentBalance === "number" ? wData.currentBalance : typeof wData.balance === "number" ? wData.balance : null;
        if (liveBal !== null && !isNaN(liveBal)) {
          setCredits((prevBal) => {
            if (prevBal !== liveBal) {
              console.log(`[Mabala Realtime Wallet] Single-source-of-truth synced balance: ${liveBal} (was ${prevBal})`);
              return liveBal;
            }
            return prevBal;
          });
        }
      }
    }, (err) => {
      console.warn("[Mabala Realtime Wallet] Realtime snapshot subscription notice:", err?.message);
    });
    const unsubscribeSms = onSnapshot(smsWalletDocRef, (snap) => {
      if (!snap.exists()) return;
      const data = snap.data();
      const liveSms = Number(data.currentBalance ?? data.balance ?? data.smsCredits);
      if (Number.isFinite(liveSms)) setSmsCredits(liveSms);
    }, (err) => {
      console.warn("[Mabala Realtime SMS wallet] Realtime snapshot subscription notice:", err?.message);
    });

    return () => {
      unsubscribe();
      unsubscribeSms();
    };
  }, [isConfigured, isAuthenticated, impersonation, userProfile?.tenantId]);

  // Real-time Sub-User Membership & Permission sync (Single Source of Truth)
  useEffect(() => {
    if (!isConfigured || !isAuthenticated || !auth.currentUser) return;
    const currentUid = auth.currentUser.uid;
    const effectiveTenantId = userProfile?.tenantId;
    const isSubUser = userProfile?.role === "sub_user" || userProfile?.isSubUser === true || (effectiveTenantId && effectiveTenantId !== currentUid);

    if (!isSubUser || !effectiveTenantId) return;

    console.log(`[Mabala Sub-User Guard] Realtime membership listener active for ${currentUid} on tenant ${effectiveTenantId}`);
    const memberDocRef = doc(db, "platform", "institutions", "institutions", effectiveTenantId, "members", currentUid);
    const unsubMember = onSnapshot(memberDocRef, (snap) => {
      if (snap.exists()) {
        const mData = snap.data();
        const currentStatus = mData.status || "active";
        const currentAccess = mData.accessLevel || mData.permission || "read_write";

        if (currentStatus === "suspended" || currentStatus === "inactive" || currentStatus === "removed") {
          console.warn("[Mabala Sub-User Guard] Sub-user account status revoked:", currentStatus);
          setSessionError("Your access to this farm workspace has been suspended or revoked by the workspace administrator.");
          setIsAuthenticated(false);
          signOut(auth);
          return;
        }

        setUserProfile(prev => {
          if (prev.accessLevel !== currentAccess || prev.permission !== currentAccess || prev.status !== currentStatus) {
            const updated = {
              ...prev,
              accessLevel: currentAccess,
              permission: currentAccess,
              status: currentStatus
            };
            if (auth.currentUser) {
              IdentityIntegrityService.saveVerifiedProfile(auth.currentUser, updated);
            }
            return updated;
          }
          return prev;
        });
      }
    }, (err) => {
      console.warn("[Mabala Sub-User Guard] Realtime membership snapshot note:", err?.message);
    });

    return () => {
      unsubMember();
    };
  }, [isConfigured, isAuthenticated, userProfile?.tenantId, userProfile?.role]);

  const isPassActive = (activeAccessPass && new Date(activeAccessPass.expiresAt) > new Date()) || 
                       (dailyBundleExpiresAt && new Date(dailyBundleExpiresAt) > new Date()) || 
                       (subscriptionTier === "Daily Bundle");
  const isSubUserReadOnly = userProfile?.accessLevel === "read_only" || userProfile?.permission === "read_only";
  const isReadonly = !impersonation && ((credits !== null && credits === 0 && !isPassActive) || farmStatus === "FROZEN" || isSubUserReadOnly);

  const isAllFarmsSelected = isAllFarmsActive && (subscriptionTier === "Enterprise Plan" || subscriptionTier === "Enterprise Suite");

  const currentMember = useMemo(() => {
    return teamMembers.find(m => m.email.trim().toLowerCase() === userProfile.email.trim().toLowerCase());
  }, [teamMembers, userProfile.email]);

  const accessibleFarms = useMemo(() => {
    const farmList = Array.isArray(farms) ? farms : [];
    if (currentMember && currentMember.accessibleFarmIds && Array.isArray(currentMember.accessibleFarmIds) && currentMember.accessibleFarmIds.length > 0) {
      return farmList.filter(f => currentMember.accessibleFarmIds!.includes(f.id));
    }
    return farmList;
  }, [farms, currentMember]);

  // Filter transaction states for rendering/read-only views based on selected farm node or collected multi-farm
  const displayedExpenses = useMemo(() => {
    const arr = Array.isArray(expenses) ? expenses : [];
    return isAllFarmsSelected ? arr : arr.filter(x => !x.farmId || x.farmId === activeFarm?.id);
  }, [isAllFarmsSelected, expenses, activeFarm?.id]);

  const displayedCrops = useMemo(() => {
    const arr = Array.isArray(crops) ? crops : [];
    return isAllFarmsSelected ? arr : arr.filter(x => !x.farmId || x.farmId === activeFarm?.id);
  }, [isAllFarmsSelected, crops, activeFarm?.id]);

  const displayedInvoices = useMemo(() => {
    const arr = Array.isArray(invoices) ? invoices : [];
    return isAllFarmsSelected ? arr : arr.filter(x => !x.farmId || x.farmId === activeFarm?.id);
  }, [isAllFarmsSelected, invoices, activeFarm?.id]);

  const displayedCreditNotes = useMemo(() => {
    const arr = Array.isArray(creditNotes) ? creditNotes : [];
    return isAllFarmsSelected ? arr : arr.filter(x => !x.farmId || x.farmId === activeFarm?.id);
  }, [isAllFarmsSelected, creditNotes, activeFarm?.id]);

  const displayedPoultry = useMemo(() => {
    const arr = Array.isArray(poultry) ? poultry : [];
    return isAllFarmsSelected ? arr : arr.filter(x => !x.farmId || x.farmId === activeFarm?.id);
  }, [isAllFarmsSelected, poultry, activeFarm?.id]);

  const displayedCashSales = useMemo(() => {
    const arr = Array.isArray(cashSales) ? cashSales : [];
    return isAllFarmsSelected ? arr : arr.filter(x => !x.farmId || x.farmId === activeFarm?.id);
  }, [isAllFarmsSelected, cashSales, activeFarm?.id]);

  const displayedLivestock = useMemo(() => {
    const arr = Array.isArray(livestock) ? livestock : [];
    return isAllFarmsSelected ? arr : arr.filter(x => !x.farmId || x.farmId === activeFarm?.id);
  }, [isAllFarmsSelected, livestock, activeFarm?.id]);

  const displayedFish = useMemo(() => {
    const arr = Array.isArray(fish) ? fish : [];
    return isAllFarmsSelected ? arr : arr.filter(x => !x.farmId || x.farmId === activeFarm?.id);
  }, [isAllFarmsSelected, fish, activeFarm?.id]);

  const displayedInventory = useMemo(() => {
    const arr = Array.isArray(inventory) ? inventory : [];
    return isAllFarmsSelected ? arr : arr.filter(x => !x.farmId || x.farmId === activeFarm?.id);
  }, [isAllFarmsSelected, inventory, activeFarm?.id]);

  const displayedAssets = useMemo(() => {
    const arr = Array.isArray(assets) ? assets : [];
    return isAllFarmsSelected ? arr : arr.filter(x => !x.farmId || x.farmId === activeFarm?.id);
  }, [isAllFarmsSelected, assets, activeFarm?.id]);

  const displayedOtherRevenues = useMemo(() => {
    const arr = Array.isArray(otherRevenues) ? otherRevenues : [];
    return isAllFarmsSelected ? arr : arr.filter(x => !x.farmId || x.farmId === activeFarm?.id);
  }, [isAllFarmsSelected, otherRevenues, activeFarm?.id]);

  const dashboardChartData = useMemo(() => {
    // Collect all unique months from all actual transactions or fall back to rolling 12 months
    const allDates: Date[] = [];
    (displayedExpenses || []).forEach(ex => { if (ex.date) allDates.push(new Date(ex.date)); });
    (displayedCashSales || []).forEach(c => { if (c.date) allDates.push(new Date(c.date)); });
    (displayedInvoices || []).forEach(i => { if (i.date) allDates.push(new Date(i.date)); });
    (displayedOtherRevenues || []).forEach(r => { if (r.date) allDates.push(new Date(r.date)); });

    // Generate rolling 12 months up to current date
    const now = new Date();
    const list: { y: number; m: number; label: string }[] = [];
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const y = d.getFullYear();
      const m = d.getMonth();
      const label = d.toLocaleDateString("en-GB", { month: "short" }) + " " + String(y).slice(2);
      list.push({ y, m, label });
    }

    // Also include any other year/months present in data if not already in list
    allDates.forEach(d => {
      const y = d.getFullYear();
      const m = d.getMonth();
      if (!isNaN(y) && !isNaN(m)) {
        const exists = list.some(item => item.y === y && item.m === m);
        if (!exists) {
          const label = d.toLocaleDateString("en-GB", { month: "short" }) + " " + String(y).slice(2);
          list.push({ y, m, label });
        }
      }
    });

    // Sort chronologically
    list.sort((a, b) => (a.y * 12 + a.m) - (b.y * 12 + b.m));

    let filtered = list.map(item => {
      // 1. Direct expenses
      const mExpensesData = (displayedExpenses || []).filter(ex => {
        if (!ex.date) return false;
        const d = new Date(ex.date);
        return d.getFullYear() === item.y && d.getMonth() === item.m;
      });

      // 2. Cash sales
      const mCashSalesData = (displayedCashSales || []).filter(c => {
        if (!c.date) return false;
        const d = new Date(c.date);
        return d.getFullYear() === item.y && d.getMonth() === item.m;
      });

      // 3. Paid invoices
      const mInvoicesData = (displayedInvoices || []).filter(i => {
        if (!i.date) return false;
        const d = new Date(i.date);
        return d.getFullYear() === item.y && d.getMonth() === item.m;
      });

      // 4. Other revenues
      const mOtherRevData = (displayedOtherRevenues || []).filter(r => {
        if (!r.date) return false;
        const d = new Date(r.date);
        return d.getFullYear() === item.y && d.getMonth() === item.m;
      });

      // 5. Poultry batch feed & health expenses & egg/bird sales
      let poultrySales = 0;
      let poultryCosts = 0;
      (displayedPoultry || []).forEach(p => {
        (p.feedLogs || []).forEach((fl: any) => {
          if (fl.date) {
            const d = new Date(fl.date);
            if (d.getFullYear() === item.y && d.getMonth() === item.m) {
              poultryCosts += Number(fl.cost || 0);
            }
          }
        });
        (p.healthLogs || []).forEach((hl: any) => {
          if (hl.date) {
            const d = new Date(hl.date);
            if (d.getFullYear() === item.y && d.getMonth() === item.m) {
              poultryCosts += Number(hl.cost || 0);
            }
          }
        });
        (p.eggSales || []).forEach((es: any) => {
          if (es.date) {
            const d = new Date(es.date);
            if (d.getFullYear() === item.y && d.getMonth() === item.m) {
              poultrySales += Number(es.totalRevenue || (Number(es.quantity || 0) * Number(es.pricePerUnit || 0)) || 0);
            }
          }
        });
        (p.salesLogs || []).forEach((sl: any) => {
          if (sl.date) {
            const d = new Date(sl.date);
            if (d.getFullYear() === item.y && d.getMonth() === item.m) {
              poultrySales += Number(sl.totalAmount || (Number(sl.quantity || 0) * Number(sl.pricePerUnit || 0)) || 0);
            }
          }
        });
      });

      const mCashSales = mCashSalesData.reduce((sum, c) => sum + (Number(c.amount || c.total || (Number(c.quantity || 0) * Number(c.unitPrice || 0)) || 0)), 0);
      const mPaidInvoices = mInvoicesData.reduce((sum, i) => {
        if (i.status === "Paid") return sum + (Number(i.total || i.amount || 0));
        return sum + (Number(i.amountPaid || 0));
      }, 0);
      const mOtherRev = mOtherRevData.reduce((sum, r) => sum + (Number(r.amount || r.total || 0)), 0);

      const mExpenses = mExpensesData.reduce((sum, ex) => sum + (Number(ex.amount || ex.total || (Number(ex.unitCost || 0) * Number(ex.quantity || 0)) || 0)), 0);

      const totalRevenue = mCashSales + mPaidInvoices + mOtherRev + poultrySales;
      const totalExpense = mExpenses + poultryCosts;

      const hasInput = totalRevenue > 0 || totalExpense > 0 || mExpensesData.length > 0 || mCashSalesData.length > 0 || mInvoicesData.length > 0;

      return {
        month: item.label,
        year: item.y,
        mIndex: item.m,
        "Total Revenue": totalRevenue,
        "Total Expenses": totalExpense,
        "Net Profit": totalRevenue - totalExpense,
        hasInput
      };
    }).filter(item => item.hasInput);

    // Date range selectors filtering
    const currYear = now.getFullYear();
    const currMonth = now.getMonth();
    if (dateRange === "last30") {
      filtered = filtered.filter(item => item.year === currYear && item.mIndex === currMonth);
    } else if (dateRange === "q1_2026") {
      filtered = filtered.filter(item => item.year === 2026 && [0, 1, 2].includes(item.mIndex));
    } else if (dateRange === "q2_2026") {
      filtered = filtered.filter(item => item.year === 2026 && [3, 4, 5].includes(item.mIndex));
    } else if (dateRange === "h2_2025") {
      filtered = filtered.filter(item => item.year === 2025 && [6, 7, 8, 9, 10, 11].includes(item.mIndex));
    }

    // Cumulative Profit Projection
    if (chartMode === "cumulative") {
      let cumulativeProfit = 0;
      return filtered.map(item => {
        cumulativeProfit += item["Net Profit"];
        return {
          month: item.month,
          "Total Revenue": item["Total Revenue"],
          "Total Expenses": item["Total Expenses"],
          "Net Profit": item["Net Profit"],
          "Cumulative Profit Projection": cumulativeProfit
        };
      });
    }

    return filtered.map(item => ({
      month: item.month,
      "Total Revenue": item["Total Revenue"],
      "Total Expenses": item["Total Expenses"],
      "Net Profit": item["Net Profit"]
    }));
  }, [displayedCashSales, displayedInvoices, displayedExpenses, displayedOtherRevenues, displayedPoultry, dateRange, chartMode]);

  const hasChartData = useMemo(() => {
    return dashboardChartData.some(d => d["Total Revenue"] > 0 || d["Total Expenses"] > 0);
  }, [dashboardChartData]);

  const kpiGrowth = useMemo(() => {
    const list = dashboardChartData;
    if (!list || list.length < 2) {
      return { 
        revGrowth: null, 
        expGrowth: null, 
        surplusGrowth: null,
        hasRevData: false,
        hasExpData: false,
        hasSurplusData: false,
        latestLabel: "", 
        previousLabel: "" 
      };
    }
    const latest = list[list.length - 1];
    const previous = list[list.length - 2];

    const prevRev = previous["Total Revenue"] || 0;
    const latestRev = latest["Total Revenue"] || 0;
    const hasRevData = prevRev > 0 || latestRev > 0;
    const revGrowth = (hasRevData && prevRev > 0) ? ((latestRev - prevRev) / prevRev) * 100 : null;

    const prevExp = previous["Total Expenses"] || 0;
    const latestExp = latest["Total Expenses"] || 0;
    const hasExpData = prevExp > 0 || latestExp > 0;
    const expGrowth = (hasExpData && prevExp > 0) ? ((latestExp - prevExp) / prevExp) * 100 : null;

    const prevSurplus = (previous["Net Profit"] !== undefined) ? previous["Net Profit"] : (prevRev - prevExp);
    const latestSurplus = (latest["Net Profit"] !== undefined) ? latest["Net Profit"] : (latestRev - latestExp);
    const absPrevSurplus = Math.abs(prevSurplus);
    const hasSurplusData = (prevSurplus !== 0 || latestSurplus !== 0) && absPrevSurplus > 0;
    const surplusGrowth = hasSurplusData ? ((latestSurplus - prevSurplus) / absPrevSurplus) * 100 : null;

    return {
      revGrowth,
      expGrowth,
      surplusGrowth,
      hasRevData,
      hasExpData,
      hasSurplusData,
      latestLabel: latest.month,
      previousLabel: previous.month
    };
  }, [dashboardChartData]);

  // Synchronize dynamic Chart of Accounts balances by sub-farm node
  useEffect(() => {
    if (activeFarm?.id && !isAllFarmsSelected) {
      setFarmAccountsMap(prev => {
        const currentMapVal = prev[activeFarm.id];
        const hasDiff = !currentMapVal || currentMapVal.some((acc, idx) => acc.balance !== accounts[idx]?.balance);
        if (hasDiff) {
          return {
            ...prev,
            [activeFarm.id]: accounts
          };
        }
        return prev;
      });
    }
  }, [accounts, activeFarm?.id, isAllFarmsSelected]);

  // Restore Chart of Account active balances on farm node focus swap
  const prevActiveFarmIdRef = useRef<string>("");
  useEffect(() => {
    if (activeFarm?.id) {
      if (prevActiveFarmIdRef.current !== activeFarm.id) {
        prevActiveFarmIdRef.current = activeFarm.id;
        const mapped = farmAccountsMap[activeFarm.id];
        if (mapped) {
          setAccounts(mapped);
        } else {
          setAccounts(INITIAL_ACCOUNTS.map(a => ({ ...a, balance: 0 })));
        }
      }
    }
  }, [activeFarm?.id, farmAccountsMap]);

  // Merged accounts balance summary for collected multiple farms view
  const displayedAccounts = useMemo(() => {
    let baseAccounts = isAllFarmsSelected ? INITIAL_ACCOUNTS.map(baseAcc => {
      let totalBal = 0;
      farms.forEach(f => {
        const farmAccs = farmAccountsMap[f.id] || [];
        const match = farmAccs.find(a => a.code === baseAcc.code);
        if (match) {
          totalBal += match.balance;
        } else if (f.id === activeFarm?.id) {
          const stateMatch = accounts.find(a => a.code === baseAcc.code);
          if (stateMatch) totalBal += stateMatch.balance;
        }
      });
      return { ...baseAcc, balance: totalBal };
    }) : accounts;

    // Recalculate/override dynamic accounts for 100% mathematical accuracy across all tabs!
    return baseAccounts.map(acc => {
      // 1. Accounts Receivable (1100)
      if (acc.code === "1100") {
        const receivablesSum = (displayedInvoices || [])
          .filter(inv => !inv.status.startsWith("Cancelled"))
          .reduce((sum, inv) => {
            const paid = inv.paidAmount !== undefined ? inv.paidAmount : (inv.status === "Paid" ? inv.total : 0);
            return sum + (inv.total - paid);
          }, 0);
        return { ...acc, balance: receivablesSum };
      }

      // 2. Output VAT (2070)
      if (acc.code === "2070") {
        const vatSum = (displayedInvoices || [])
          .filter(inv => !inv.status.startsWith("Cancelled"))
          .reduce((sum, inv) => sum + (inv.taxAmount || 0), 0);
        return { ...acc, balance: vatSum };
      }

      // 3. Revenue Accounts (4xxx)
      if (acc.category === "Revenue") {
        const invoiceRev = (displayedInvoices || [])
          .filter(inv => !inv.status.startsWith("Cancelled") && inv.coaCredit === acc.code)
          .reduce((sum, inv) => sum + (inv.subtotal || 0), 0);

        const cashSaleRev = (displayedCashSales || [])
          .filter(cs => cs.coaCredit === acc.code)
          .reduce((sum, cs) => sum + (cs.amount || 0), 0);

        return { ...acc, balance: invoiceRev + cashSaleRev };
      }

      // 4. Expense Accounts (5xxx)
      if (acc.category === "Expense") {
        const ledgerSum = (displayedExpenses || []).reduce((sum, ex) => {
          const rowSum = (ex.rows || []).reduce((rSum, row) => {
            if (row.coaCode === acc.code) {
              return rSum + (row.amount || 0);
            }
            return rSum;
          }, 0);
          return sum + rowSum;
        }, 0);

        let additionalSum = 0;
        if (acc.code === "5300") {
          // Veterinary/Meds: poultry medications & treatments, livestock treatments
          const poultryMedCost = (displayedPoultry || []).reduce((sum, b) => {
            const medCostVal = (b.medications || []).reduce((s, x) => s + (x.cost || 0), 0);
            const healthArr = (b.healthEvents || (b as any).healthLogs || []);
            const treatmentCostVal = healthArr.reduce((s: number, x: any) => s + (x.cost ?? x.treatmentCost ?? 0), 0);
            return sum + medCostVal + treatmentCostVal;
          }, 0);
          const livestockHealthCost = (displayedLivestock || []).reduce((sum, r) => {
            const healthCost = (r.healthEvents || []).reduce((s, h) => s + (h.cost || 0), 0);
            return sum + healthCost;
          }, 0);
          additionalSum = poultryMedCost + livestockHealthCost;
        } else if (acc.code === "5210") {
          // Poultry Feed: poultry feed logs
          additionalSum = (displayedPoultry || []).reduce((sum, b) => {
            return sum + (b.feedLogs || []).reduce((s, x) => s + (x.cost || 0), 0);
          }, 0);
        } else if (acc.code === "5100") {
          // Staff wages & salaries: payslips
          additionalSum = (payslips || []).reduce((sum, s) => sum + (s.basicSalary || 0), 0);
        }

        return { ...acc, balance: ledgerSum + additionalSum };
      }

      return acc;
    });
  }, [
    isAllFarmsSelected, 
    accounts, 
    farmAccountsMap, 
    farms, 
    activeFarm?.id, 
    displayedExpenses, 
    displayedInvoices, 
    displayedCashSales, 
    displayedPoultry, 
    displayedLivestock, 
    payslips
  ]);

  const getTierForTab = (tab: string) => {
    switch (tab) {
      case "dashboard":
      case "sales":
      case "profile":
      case "backup-restore":
        return "tier-1";
      case "crops":
      case "expenses":
      case "invoices":
        return "tier-2";
      case "finance-hub":
      case "assets":
        return "tier-3";
      case "accounts":
      case "reports":
      case "audit-archive":
        return "tier-4";
      case "livestock":
      case "poultry":
      case "aquaculture":
        return "tier-5";
      default:
        return null;
    }
  };

  // Active module-access credit deduction engine 
  const [prevTab, setPrevTab] = useState<string>("dashboard");
  useEffect(() => {
    if (activeTab === prevTab) return;
    
    const tierId = getTierForTab(activeTab);
    if (tierId) {
      const matchedTier = creditTiers.find(t => t.id === tierId);
      const cost = matchedTier ? matchedTier.cost : 1;
      
      if (cost > 0 && subscriptionTier !== "Daily Bundle") {
        setCredits(prev => Math.max(prev - cost, 0));
        
        // Push transactions straight to credit ledger audits
        const newTx = {
          id: "tx-module-" + Date.now(),
          date: new Date().toISOString().replace('T', ' ').slice(0, 19),
          amount: cost,
          description: `Access module: ${activeTab.toUpperCase()} (${matchedTier?.name || "Credit Usage"})`,
          type: "usage"
        };
        setCreditTransactions(prev => [newTx, ...prev]);
      }
    }
    
    setPrevTab(activeTab);
  }, [activeTab, prevTab, creditTiers]);



  // Read-only deterrent listeners
  useEffect(() => {
    if (!isReadonly) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Block Ctrl+P / Cmd+P
      if ((e.key === 'p' || e.key === 'P') && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        setSessionError("Printing is disabled. This Free Plan account is in a read-only state due to credit depletion. Please upgrade to a paid bundle or top up credits to enable full-feature operations.");
      }
      // Print Screen key
      if (e.key === 'PrintScreen') {
        e.preventDefault();
        try {
          navigator.clipboard.writeText('');
        } catch (err) {}
        setSessionError("Screenshots are restricted. This account is in a read-only state. Please upgrade your plan to unlock.");
      }
    };

    const handleBeforePrint = (e: Event) => {
      setSessionError("Printing is disabled. This Free Plan account is in a read-only state due to credit depletion. Please upgrade to a paid bundle or top up credits to enable full-feature operations.");
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      setSessionError("Right-click is restricted in Read-Only Lock State.");
    };

    const handleCopy = (e: ClipboardEvent) => {
      e.preventDefault();
      setSessionError("Text copy operations are restricted in Read-Only Lock State.");
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('beforeprint', handleBeforePrint);
    window.addEventListener('contextmenu', handleContextMenu);
    window.addEventListener('copy', handleCopy);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('beforeprint', handleBeforePrint);
      window.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('copy', handleCopy);
    };
  }, [isReadonly]);

  // Guarantee active farm node email and user profile email are always 100% identical
  useEffect(() => {
    const profileEmail = (userProfile?.email || "").trim().toLowerCase();
    const farmEmail = (farms[activeFarmIndex]?.email || "").trim().toLowerCase();
    const authEmail = (auth.currentUser?.email || "").trim().toLowerCase();
    const canonical = profileEmail || farmEmail || authEmail;
    if (!canonical) return;

    if (userProfile && profileEmail !== canonical) {
      setUserProfile(prev => prev ? { ...prev, email: canonical } : prev);
      try {
        localStorage.setItem("mabala_user_email", canonical);
      } catch (e) {}
    }

    setFarms(prev => {
      let needed = false;
      const updated = prev.map(f => {
        if ((f.email || "").trim().toLowerCase() !== canonical) {
          needed = true;
          return { ...f, email: canonical };
        }
        return f;
      });
      if (needed) {
        try {
          localStorage.setItem("mabala_farms", JSON.stringify(updated));
          localStorage.setItem("mabala_farm_email", canonical);
          localStorage.setItem("mabala_user_email", canonical);
        } catch (e) {}
        return updated;
      }
      return prev;
    });
  }, [userProfile?.email, auth.currentUser?.email, farms[activeFarmIndex]?.email]);

  const handleUpdateActiveFarm = (updatedFields: Partial<any>) => {
    // Immutability constraint: email field serves as the permanent unique node identifier and must NEVER be editable
    const { email: _immutableNodeEmail, ...safeFields } = updatedFields;

    setFarms(prev => {
      const nextFarms = prev.map((f, i) => {
        if (i === activeFarmIndex) {
          return { ...f, ...safeFields };
        }
        return f;
      });
      try {
        localStorage.setItem("mabala_farms", JSON.stringify(nextFarms));
      } catch (e) {}

      // Online & Offline Firestore persistence for active farm statutory settings
      if (userProfile?.uid) {
        try {
          const userDocRef = doc(db, "users_data", userProfile.uid);
          setDoc(userDocRef, {
            farms: nextFarms,
            activeFarmTaxType: safeFields.taxType || (nextFarms[activeFarmIndex]?.taxType),
            activeFarmCurrency: safeFields.currency || (nextFarms[activeFarmIndex]?.currency),
            updatedAt: new Date().toISOString()
          }, { merge: true }).catch(err => console.warn("[Firestore] Farm setting saved to offline cache:", err));
        } catch (e) {
          console.warn("[Firestore] Offline write warning:", e);
        }
      }

      return nextFarms;
    });

    if (safeFields.taxType) {
      localStorage.setItem("mabala_farm_tax_type", safeFields.taxType);
    }
    if (safeFields.customTaxName) {
      localStorage.setItem("mabala_farm_custom_tax_name", safeFields.customTaxName);
    }
    if (safeFields.customTaxRate !== undefined) {
      localStorage.setItem("mabala_farm_custom_tax_rate", String(safeFields.customTaxRate));
    }
    if (safeFields.currency) {
      localStorage.setItem("mabala_farm_currency", safeFields.currency);
    }
  };

  // Sync Currency Symbol and Country when farm/country changes
  useEffect(() => {
    if (activeFarm) {
      // Find matching country
      const matched = COUNTRIES.find(c => c.currency === activeFarm.currency) || COUNTRIES[0];
      setSelectedCountry(matched);
    }
  }, [activeFarmIndex, farms]);

  // Hashing helper for ledger validation/checksum
  const calculateRecordHash = (record: any): string => {
    const str = `${record.tenantId}:${record.timestamp}:${record.amount}:${record.previousBalance}:${record.newBalance}:${record.moduleId}:${record.description}`;
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    let signature = "";
    for (let j = 0; j < 8; j++) {
      const seed = Math.abs(Math.sin(hash + j) * 16777216);
      signature += Math.floor(seed).toString(16).padStart(8, "0");
    }
    return signature;
  };

  // Serial promise queue to prevent simultaneous transactions competing on the same Firestore documents
  const deductQueueRef = useRef<Promise<any>>(Promise.resolve());

  // Handle write activity credit penalty
  const deductCredits = async (weight: number, moduleId = "system", description = "Operational consumption") => {
    if (subscriptionTier === "Daily Bundle") {
      // Unmetered Daily Bundle active
      return;
    }
    if (dailyBundleExpiresAt && new Date(dailyBundleExpiresAt) > new Date()) {
      // Unmetered Daily Bundle active (countdown)
      return;
    }
    if (activeAccessPass && new Date(activeAccessPass.expiresAt) > new Date()) {
      // Unmetered access activated via Emergency Access Pass
      return;
    }

    // Look up dynamic tier cost from creditTiers if configured
    let dynamicCost = weight;
    if (Array.isArray(creditTiers)) {
      if (weight === 1) {
        dynamicCost = creditTiers.find(t => t.id === "tier-1")?.cost ?? 1;
      } else if (weight === 2) {
        dynamicCost = creditTiers.find(t => t.id === "tier-2")?.cost ?? 2;
      } else if (weight === 3) {
        dynamicCost = creditTiers.find(t => t.id === "tier-3")?.cost ?? 3;
      } else if (weight === 5) {
        dynamicCost = creditTiers.find(t => t.id === "tier-4")?.cost ?? 5;
      } else if (weight === 8) {
        dynamicCost = creditTiers.find(t => t.id === "tier-5")?.cost ?? 8;
      }
    }

    const tenantId = impersonation ? impersonation.targetUid : (userProfile?.tenantId || (auth.currentUser ? auth.currentUser.uid : ""));
    if (!isConfigured || !tenantId) {
      // Local fallback if offline or db not initialized
      setCredits(prev => Math.max(prev - dynamicCost, 0));
      return;
    }

    // Queue deduction operations serially to eliminate concurrent OCC version collisions
    deductQueueRef.current = deductQueueRef.current.then(async () => {
      let previousBalance = credits;
      let newBalance = Math.max(previousBalance - dynamicCost, 0);
      let actualConsumed = previousBalance - newBalance;
      const nowStr = new Date().toISOString();

      const walletDocRef = doc(db, "tenants", tenantId, "wallet", "credits");
      const ledgerColRef = collection(db, "tenants", tenantId, "creditLedger");
      const ledgerDocRef = doc(ledgerColRef);
      const userMetadataRef = doc(db, "users_data", tenantId);

      const actingUid = auth.currentUser?.uid || userProfile?.uid || "anonymous";
      const actingRole = userProfile?.role || (userProfile?.isSubUser ? "sub_user" : "Farm Owner");
      const actingName = userProfile?.name || auth.currentUser?.displayName || "Workspace User";
      const actingEmail = auth.currentUser?.email || userProfile?.email || "";

      let txSuccess = false;
      const maxAttempts = 3;

      for (let attempt = 1; attempt <= maxAttempts && !txSuccess; attempt++) {
        try {
          await runTransaction(db, async (transaction) => {
            const walletDocSnap = await transaction.get(walletDocRef);
            let curBal = credits;
            let lifetimeIssued = credits;
            let lifetimeConsumed = 0;
            let planAllotment = credits;

            if (walletDocSnap.exists()) {
              const wData = walletDocSnap.data();
              curBal = typeof wData.currentBalance === "number" ? wData.currentBalance : credits;
              lifetimeIssued = typeof wData.lifetimeIssued === "number" ? wData.lifetimeIssued : credits;
              lifetimeConsumed = typeof wData.lifetimeConsumed === "number" ? wData.lifetimeConsumed : 0;
              planAllotment = typeof wData.planAllotment === "number" ? wData.planAllotment : credits;
            }

            previousBalance = curBal;
            newBalance = Math.max(previousBalance - dynamicCost, 0);
            actualConsumed = previousBalance - newBalance;
            const newLifetimeConsumed = lifetimeConsumed + actualConsumed;

            // 1. Write wallet state inside transaction
            transaction.set(walletDocRef, {
              currentBalance: newBalance,
              lifetimeConsumed: newLifetimeConsumed,
              lifetimeIssued,
              planAllotment,
              updatedAt: nowStr
            }, { merge: true });

            // 2. Write cryptographic ledger record inside transaction
            const ledgerRecord = {
              id: ledgerDocRef.id,
              tenantId,
              actingUid,
              actingRole,
              actingName,
              actingEmail,
              creditsCharged: actualConsumed,
              action: description,
              timestamp: nowStr,
              type: "deduction",
              amount: actualConsumed,
              previousBalance,
              newBalance,
              moduleId,
              description,
              checksum: ""
            };
            ledgerRecord.checksum = calculateRecordHash(ledgerRecord);
            transaction.set(ledgerDocRef, ledgerRecord);
          });

          txSuccess = true;
          setCredits(newBalance);

          // Update userMetadata outside transaction to prevent base version contention on users_data
          try {
            setDoc(userMetadataRef, { credits: newBalance, updatedAt: nowStr }, { merge: true })
              .catch(uErr => console.warn("[Mabala Wallet] Non-critical user metadata sync note:", uErr?.message));
          } catch (_) {}

          console.log(`[Mabala Wallet] Atomic transaction successful (attempt ${attempt}). Deducted ${actualConsumed} credits by ${actingEmail}. New balance: ${newBalance}.`);
        } catch (attemptErr: any) {
          const isVersionConflict = attemptErr?.message?.includes("base version") || attemptErr?.message?.includes("version") || attemptErr?.code === "aborted";
          if (isVersionConflict && attempt < maxAttempts) {
            // Exponential backoff jitter before retry
            await new Promise(res => setTimeout(res, 50 * Math.pow(2, attempt) + Math.floor(Math.random() * 50)));
          } else {
            console.warn(`[Mabala Wallet] Transaction note (attempt ${attempt}):`, attemptErr?.message || attemptErr);
            break;
          }
        }
      }

      // Resilient atomic fallback if runTransaction encountered unrecoverable contention or offline mode
      if (!txSuccess) {
        try {
          console.log("[Mabala Wallet] Executing direct resilient fallback for credit deduction...");
          let curBal = credits;
          try {
            const snap = await getDoc(walletDocRef);
            if (snap.exists()) {
              curBal = typeof snap.data().currentBalance === "number" ? snap.data().currentBalance : credits;
            }
          } catch (_) {}

          previousBalance = curBal;
          newBalance = Math.max(previousBalance - dynamicCost, 0);
          actualConsumed = previousBalance - newBalance;

          const ledgerRecord = {
            id: ledgerDocRef.id,
            tenantId,
            actingUid,
            actingRole,
            actingName,
            actingEmail,
            creditsCharged: actualConsumed,
            action: description,
            timestamp: nowStr,
            type: "deduction",
            amount: actualConsumed,
            previousBalance,
            newBalance,
            moduleId,
            description,
            checksum: ""
          };
          ledgerRecord.checksum = calculateRecordHash(ledgerRecord);

          await setDoc(walletDocRef, {
            currentBalance: newBalance,
            updatedAt: nowStr
          }, { merge: true });

          await setDoc(ledgerDocRef, ledgerRecord);
          await setDoc(userMetadataRef, { credits: newBalance, updatedAt: nowStr }, { merge: true });

          setCredits(newBalance);
          console.log(`[Mabala Wallet] Resilient fallback successful. Deducted ${actualConsumed} credits. New balance: ${newBalance}.`);
        } catch (fallbackErr) {
          console.warn("[Mabala Wallet] Fallback credit deduction recorded locally:", fallbackErr);
          setCredits(prev => Math.max(prev - dynamicCost, 0));
        }
      }
    }).catch(queueErr => {
      console.warn("[Mabala Wallet] Queue step note:", queueErr);
      setCredits(prev => Math.max(prev - dynamicCost, 0));
    });

    return deductQueueRef.current;
  };

  const handleStartImpersonation = async (targetUid: string, targetEmail: string, targetFarm: any) => {
    setIdentityReady(false);
    const adminUid = auth.currentUser?.uid || "icIoBG4eN5VOw2BvhNiFUnUqmsX2";
    const adminEmail = auth.currentUser?.email || "support@mabala.cloud";
    const nowIso = new Date().toISOString();
    const expiresIso = new Date(Date.now() + 60 * 60 * 1000).toISOString();

    let safeFarm: Farm;
    if (targetFarm && typeof targetFarm === "object" && (targetFarm.name || targetFarm.farmName || targetFarm.id)) {
      safeFarm = {
        id: targetFarm.id || `farm-${targetUid || Date.now()}`,
        name: targetFarm.name || targetFarm.farmName || `Farm Workspace Node (${targetEmail})`,
        letterheadTitle: targetFarm.letterheadTitle || targetFarm.name || targetFarm.farmName || `Farm Workspace (${targetEmail})`,
        tpin: targetFarm.tpin || "1002345678",
        vatNumber: targetFarm.vatNumber || "ZM-123",
        address: targetFarm.address || targetFarm.location || "Lusaka West, Zambia",
        country: targetFarm.country || "Zambia",
        currency: targetFarm.currency || "ZMW",
        phone: targetFarm.phone || "+260 978 070734",
        email: targetFarm.email || targetEmail,
        status: targetFarm.status || "ACTIVE",
        createdAt: targetFarm.createdAt || nowIso
      } as any;
    } else {
      safeFarm = {
        id: `farm-${targetUid || Date.now()}`,
        name: `Farm Workspace Node (${targetEmail})`,
        letterheadTitle: `Farm Workspace (${targetEmail})`,
        tpin: "1002345678",
        vatNumber: "ZM-123",
        address: "Lusaka West, Zambia",
        country: "Zambia",
        currency: "ZMW",
        phone: "+260 978 070734",
        email: targetEmail,
        status: "ACTIVE",
        createdAt: nowIso
      } as any;
    }

    let targetActualRole = "Farm Owner";
    let targetActualTenantType = "farmer";

    if (db && targetUid) {
      try {
        const userDocRef = doc(db, "users_data", targetUid);
        const userDocSnap = await getDoc(userDocRef);
        if (userDocSnap.exists()) {
          const uData = userDocSnap.data();
          if (uData.role) targetActualRole = uData.role;
          if (uData.tenantType) targetActualTenantType = uData.tenantType;
          if (uData.userProfile?.role) targetActualRole = uData.userProfile.role;
          if (uData.userProfile?.tenantType) targetActualTenantType = uData.userProfile.tenantType;
          if (uData.farms && Array.isArray(uData.farms) && uData.farms.length > 0) {
            const primaryF = uData.farms[0];
            safeFarm = {
              ...safeFarm,
              ...primaryF,
              name: primaryF.name || primaryF.farmName || safeFarm.name,
              id: primaryF.id || safeFarm.id
            };
          }
        }
      } catch (err) {
        console.warn("Access Node target user fetch fallback:", err);
      }
    }

    // Do NOT allow target farm node to be upgraded to Super Admin
    if ((targetActualRole === "Super Admin" || targetActualRole === "Platform Administrator") && targetEmail.trim().toLowerCase() !== "support@mabala.cloud") {
      targetActualRole = "Farm Owner";
      targetActualTenantType = "farmer";
    }

    const superAdminRoleToPreserve = (adminEmail.trim().toLowerCase() === "support@mabala.cloud" || currentRole === "Super Admin" || currentRole === "Platform Administrator") ? "Super Admin" : currentRole;

    // The backend must authorize and create the temporary context before any
    // client state, listeners, or cache namespace is changed.
    let remoteSession: { sessionId: string; targetTenantId: string; targetOwnerId?: string; expiresAt: string };
    try {
      const { getFunctions, httpsCallable } = await import("firebase/functions");
      const { getApp } = await import("firebase/app");
      const enterAccessNode = httpsCallable(getFunctions(getApp()), "enterAccessNode");
      const result: any = await enterAccessNode({ tenantId: targetUid });
      remoteSession = result.data as typeof remoteSession;
      if (!remoteSession?.sessionId || !remoteSession?.targetTenantId) {
        throw new Error("Remote access session was not created by the backend.");
      }
    } catch (accessErr: any) {
      setIdentityReady(true);
      showToast(accessErr?.message || "Remote access authorization failed.", "error");
      return;
    }

    const effectiveTargetTenantId = remoteSession.targetTenantId;
    const sessionEpoch = createSessionEpoch("impersonation");

    // Explicitly tear down Super Admin real-time listeners before attaching target farm listeners (Section 3.2)
    cleanupWorkspaceListeners();

    // Isolate IndexedDB local cache: purge and re-namespace to targetUid (Section 3.3)
    try {
      await purgeOfflineDatabase();
      const impersonationCacheScope = getSessionNamespace(targetUid, effectiveTargetTenantId, sessionEpoch);
      setOfflineDbScope(impersonationCacheScope);
      setPersistenceScope(impersonationCacheScope);
    } catch (cacheErr) {
      console.warn("[Access Node] IndexedDB isolation setup note:", cacheErr);
    }

    const targetProfile = {
      uid: targetUid,
      tenantId: effectiveTargetTenantId,
      email: targetEmail,
      name: safeFarm.name || `${targetEmail.split('@')[0]} Farm`,
      role: targetActualRole,
      tenantType: targetActualTenantType,
      phone: safeFarm.phone || ""
    };

    // Save original session values so we can restore Super Admin session cleanly later
    setImpersonation({
      targetUid,
      targetTenantId: effectiveTargetTenantId,
      targetEmail,
      targetFarmId: safeFarm.id,
      targetFarmName: safeFarm.name,
      targetPhone: safeFarm.phone || "",
      targetFarmNode: safeFarm,
      targetProfile,
      sessionEpoch,
      initiatedBy: adminEmail,
      superAdminUid: adminUid,
      superAdminEmail: adminEmail,
      startedAt: nowIso,
      expiresAt: remoteSession.expiresAt || expiresIso,
      remoteAccessSessionId: remoteSession.sessionId,
      targetOwnerId: remoteSession.targetOwnerId || targetUid,
      originalUserProfile: { 
        ...userProfile,
        email: adminEmail,
        role: "Super Admin",
        tenantType: "super_admin"
      },
      originalFarms: [...farms],
      originalActiveFarmIndex: activeFarmIndex,
      originalRole: "Super Admin",
      originalCredits: credits,
      originalSubscriptionTier: subscriptionTier,
      originalWorkspaceMode: workspaceMode,
      targetActualRole,
      targetActualTenantType,
    });
    setSessionTimeLeft(3600);

    // Keep Super Admin role and profile strictly retained in base state!
    setCurrentRole("Super Admin");
    const superAdminProfile = {
      name: (userProfile && userProfile.name) || "Mabala Super Admin",
      email: adminEmail,
      phone: (userProfile && userProfile.phone) || "+260 978 070734",
      role: "Super Admin",
      tenantType: "super_admin",
      tenantId: "super_admin_central",
      uid: adminUid
    };
    setUserProfile(superAdminProfile);
    IdentityIntegrityService.saveVerifiedProfile({ uid: adminUid, email: adminEmail }, superAdminProfile);

    // Load the target farm into active session so the UI displays the target farm node details
    setFarms([safeFarm]);

    const sessionWorkspaceMode = targetActualTenantType === "offtaker" ? "Offtaker"
      : targetActualTenantType === "mabala_partner" ? "Partner"
      : targetActualTenantType === "agro_dealer" ? "Agro Dealer"
      : "Farmer";
    setWorkspaceMode(sessionWorkspaceMode as any);
    setActiveTab("dashboard");

    // Fetch and load target node's persistent cloud data WITHOUT overwriting Super Admin profile or identity (isRemoteSupportAccess = true)
    try {
      await handleLoadCloudWorkspace(effectiveTargetTenantId, targetEmail, true, sessionEpoch);
    } catch (loadErr) {
      console.warn("[Access Node] Cloud workspace load warning:", loadErr);
    }

    setIdentityReady(true);

    showToast(`✅ Remote Access Session Active: Viewing ${safeFarm.name} (${targetEmail}). Super Admin role strictly retained.`, "success");

    // Log in central super_admin_audit collection in Firestore (Section 3.6)
    try {
      const auditId = "audit-entry-" + Date.now();
      await setDoc(doc(db, "super_admin_audit", auditId), {
        id: auditId,
        superAdminId: adminUid,
        superAdminEmail: adminEmail,
        adminUid,
        initiatedBy: adminEmail,
        actionType: "access_node_session_start",
        targetTenantId: targetUid,
        targetUid,
        sessionEpoch,
        actingAs: "super_admin_access_node",
        details: {
          farmNodeId: safeFarm.id,
          farmNodeName: safeFarm.name,
          targetEmail,
          targetRole: targetActualRole,
          startedAt: nowIso,
          expiresAt: expiresIso,
          sessionEpoch,
          timestamp: nowIso
        },
        timestamp: nowIso
      });
    } catch (err) {
      console.error("Failed to log farm node entrance audit:", err);
    }
  };

  const handleExitImpersonation = async () => {
    if (!impersonation) return;

    setIdentityReady(false);

    const currentImpersonation = impersonation;
    const targetFarmId = currentImpersonation.targetFarmId;
    const targetFarmName = (currentImpersonation.targetFarmName || "").toLowerCase().trim();
    const adminEmail = currentImpersonation.superAdminEmail || auth.currentUser?.email || userProfile?.email || "support@mabala.cloud";
    const adminUid = currentImpersonation.superAdminUid || auth.currentUser?.uid || userProfile?.uid || "icIoBG4eN5VOw2BvhNiFUnUqmsX2";

    try {
      const { getFunctions, httpsCallable } = await import("firebase/functions");
      const { getApp } = await import("firebase/app");
      const exitAccessNode = httpsCallable(getFunctions(getApp()), "exitAccessNode");
      await exitAccessNode({ sessionId: currentImpersonation.remoteAccessSessionId });
    } catch (accessErr: any) {
      setIdentityReady(true);
      showToast(accessErr?.message || "Could not close the remote-access session.", "error");
      return;
    }

    // Log the exiting action first (Section 3.6)
    try {
      const auditId = "audit-exit-" + Date.now();
      const endedAt = new Date().toISOString();
      const durationMs = Date.now() - new Date(currentImpersonation.startedAt).getTime();
      const durationMin = Math.round(durationMs / 60000);

      await setDoc(doc(db, "super_admin_audit", auditId), {
        id: auditId,
        superAdminId: adminUid,
        superAdminEmail: adminEmail,
        adminUid: adminUid,
        initiatedBy: currentImpersonation.initiatedBy,
        actionType: "access_node_session_end",
        targetTenantId: currentImpersonation.targetUid,
        targetUid: currentImpersonation.targetUid,
        sessionEpoch: currentImpersonation.sessionEpoch,
        actingAs: "super_admin_access_node",
        details: {
          farmNodeId: targetFarmId,
          farmNodeName: farms[0]?.name || currentImpersonation.targetFarmName || "Active Farm",
          targetEmail: currentImpersonation.targetEmail,
          startedAt: currentImpersonation.startedAt,
          endedAt,
          durationMinutes: durationMin,
          sessionEpoch: currentImpersonation.sessionEpoch,
          timestamp: endedAt
        },
        timestamp: endedAt
      });
    } catch (err) {
      console.error("Failed to log farm node exit audit:", err);
    }

    // Explicitly tear down target farm node listeners (Section 3.2)
    cleanupWorkspaceListeners();

    // Re-namespace & purge local IndexedDB store back to Super Admin identity (Section 3.3)
    try {
      await purgeOfflineDatabase();
      const adminCacheScope = getSessionNamespace(adminUid, "super_admin_central", createSessionEpoch("admin"));
      setOfflineDbScope(adminCacheScope);
      setPersistenceScope(adminCacheScope);
    } catch (cacheErr) {
      console.warn("[Access Node Exit] Cache reset note:", cacheErr);
    }

    // Purge all operational collections from the accessed farm node so nothing gets stuck in Super Admin view
    setCrops([]);
    setAccounts([]);
    setSuppliers([]);
    setCustomers([]);
    setExpenses([]);
    setInvoices([]);
    setCreditNotes([]);
    setQuotations([]);
    setEmployees([]);
    setPayslips([]);
    setPoultry([]);
    setFish([]);
    setOrchardNurseryBatches([]);
    setOrchardTrees([]);
    setOrchardActivities([]);
    setInventory([]);
    setCashSales([]);
    setLoans([]);
    setInvestments([]);
    setLivestock([]);
    setAssets([]);
    setOtherRevenues([]);
    setLeaveRecords([]);
    setEmployeeAdvances([]);
    setAuditLogs([]);
    setArchivedRecords([]);

    // Purge and clear all localStorage keys associated with the remotely accessed farm node
    FarmPersistenceService.clearActiveLocalStorageKeys({ purgeIdentity: false, purgeFarmDetails: true, scope: currentImpersonation.targetUid });
    try {
      localStorage.removeItem("mabala_active_farm");
      localStorage.removeItem("mabala_registered_farm_name");
      localStorage.removeItem("mabala_farm_name");
      localStorage.removeItem("mabala_farm_province");
      localStorage.removeItem("mabala_farm_district");
      localStorage.removeItem("mabala_farm_phone");
      localStorage.removeItem("mabala_farm_email");
      localStorage.removeItem("mabala_farm_tpin");
      localStorage.removeItem("mabala_farm_address");
      localStorage.removeItem("mabala_farm_tax_type");
      localStorage.removeItem("mabala_farm_currency");
      localStorage.removeItem("mabala_farm_custom_tax_name");
      localStorage.removeItem("mabala_farm_custom_tax_rate");
    } catch (e) {}

    // Restore central administration farm
    const centralAdminFarm: Farm = {
      id: "farm-central-admin",
      name: "Mabala Platform Administration",
      letterheadTitle: "Mabala Cloud Platform Administration",
      letterheadSubtitle: "Central Infrastructure & Global Network Oversight",
      address: "Opp Oryx Filling Station, Mumbwa Road, Lusaka West, Zambia",
      phone: "+260 978 070734",
      email: adminEmail,
      country: "Zambia",
      currency: "ZMW",
      currencySymbol: "K",
      taxSystem: "Standard VAT (16%)",
      taxType: "VAT_16",
      status: "ACTIVE",
      createdAt: new Date().toISOString()
    } as any;

    // Filter original farms to strictly exclude the remotely accessed farm node
    const originalFarms = currentImpersonation.originalFarms || [];
    const cleanOriginalFarms = originalFarms.filter((f: any) => {
      if (!f) return false;
      if (targetFarmId && f.id === targetFarmId) return false;
      if (targetFarmName && (f.name || "").toLowerCase().trim() === targetFarmName) return false;
      if (f.email && f.email.toLowerCase().trim() === currentImpersonation.targetEmail.toLowerCase().trim()) return false;
      return true;
    });

    const restoredFarms = cleanOriginalFarms.length > 0 ? cleanOriginalFarms : [centralAdminFarm];

    setFarms(restoredFarms);
    const restoredActiveIndex = (currentImpersonation.originalActiveFarmIndex !== undefined && currentImpersonation.originalActiveFarmIndex < restoredFarms.length)
      ? currentImpersonation.originalActiveFarmIndex
      : 0;
    setActiveFarmIndex(restoredActiveIndex);
    setIsAllFarmsActive(false);
    setShowFarmSwitcherDropdown(false);

    try {
      localStorage.setItem("mabala_farms", JSON.stringify(restoredFarms));
      localStorage.setItem("mabala_farm_name", restoredFarms[restoredActiveIndex]?.name || restoredFarms[0].name);
    } catch (e) {}

    // Completely clear farm node details from Super Admin profile
    // Only pre-access farm node data that belonged to the Super Admin session should persist!
    const baseProfile = currentImpersonation.originalUserProfile || userProfile || {};
    const restoredProfile: any = {
      ...baseProfile,
      uid: adminUid,
      email: adminEmail,
      name: (baseProfile.name && (baseProfile.name.toLowerCase().trim() !== targetFarmName)) ? baseProfile.name : "Mabala Super Admin",
      role: "Super Admin",
      tenantType: "super_admin",
      tenantId: "super_admin_central",
      phone: baseProfile.phone || "+260 978 070734"
    };

    // Explicitly purge all target farm node fields
    delete restoredProfile.targetFarmName;
    delete restoredProfile.targetFarmId;
    delete restoredProfile.targetFarmNode;
    delete restoredProfile.farmNode;
    delete restoredProfile.targetProfile;
    delete restoredProfile.targetActualRole;
    delete restoredProfile.targetActualTenantType;

    // Completely clear farmName or farmId if it matches the target farm or was not present pre-access
    if (
      restoredProfile.farmName && (
        restoredProfile.farmName.toLowerCase().trim() === targetFarmName ||
        restoredProfile.farmName === targetFarmId ||
        (!currentImpersonation.originalUserProfile?.farmName && cleanOriginalFarms.length === 0)
      )
    ) {
      if (cleanOriginalFarms.length > 0 && cleanOriginalFarms[0].name.toLowerCase().trim() !== targetFarmName) {
        restoredProfile.farmName = cleanOriginalFarms[0].name;
      } else {
        delete restoredProfile.farmName;
      }
    }
    if (restoredProfile.farmId === targetFarmId) {
      delete restoredProfile.farmId;
    }

    setUserProfile(restoredProfile);
    IdentityIntegrityService.saveVerifiedProfile({ uid: adminUid, email: adminEmail }, restoredProfile);
    try {
      localStorage.setItem("mabala_user_profile", JSON.stringify(restoredProfile));
    } catch (e) {}

    setCurrentRole("Super Admin");
    setCredits(currentImpersonation.originalCredits !== undefined ? currentImpersonation.originalCredits : 999999);
    setSubscriptionTier(currentImpersonation.originalSubscriptionTier || "Agro-Enterprise Premium");
    setWorkspaceMode("Farmer");
    setActiveTab("platform-admin");

    // Overwrite Super Admin local snapshot in FarmPersistenceService so no remote farm data lingers
    try {
      await FarmPersistenceService.saveFarmNodeWorkspace(adminEmail, {
        id: adminEmail,
        email: adminEmail,
        name: restoredFarms[0].name,
        tenantId: "super_admin_central",
        role: "Super Admin",
        tenantType: "super_admin",
        farms: restoredFarms,
        crops: [],
        expenses: [],
        invoices: [],
        accounts: [],
        inventory: [],
        livestock: [],
        poultry: [],
        fish: [],
        employees: [],
        userProfile: restoredProfile
      });
    } catch (persistErr) {
      console.warn("[Access Node Exit] Workspace snapshot save warning:", persistErr);
    }

    // Clear impersonation state BEFORE reloading clean Super Admin data
    setImpersonation(null);

    try {
      await handleLoadCloudWorkspace(adminUid, adminEmail, false);
    } catch (err) {
      console.warn("[Access Node Exit] Admin workspace restore warning:", err);
    }

    setIdentityReady(true);

    showToast("Exited remote access session. Super Admin view and role fully restored.", "info");
  };

  // 60-Minute Session Auto-Expiry Effect for Access Node
  useEffect(() => {
    if (!impersonation) return;

    const interval = setInterval(() => {
      const expiresMs = new Date(impersonation.expiresAt).getTime();
      const remaining = Math.max(0, Math.floor((expiresMs - Date.now()) / 1000));
      setSessionTimeLeft(remaining);

      if (remaining <= 0) {
        clearInterval(interval);
        showToast("Remote Support Session auto-expired (60-minute duration limit reached).", "warning");
        handleExitImpersonation();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [impersonation]);

  // Demo Mode is repurposed into a clean blank workspace bootloader as per user directive
  const handleStartDemo = (customEmail?: any) => {
    const testCountry = COUNTRIES[0]; // Zambia default
    setSelectedCountry(testCountry);

    const emailStr = (typeof customEmail === "string" ? customEmail : "") || (userProfile && typeof userProfile.email === "string" ? userProfile.email : "") || "manager@localhost.zm";
    const emailToUse = emailStr;
    const isSuper = Boolean(emailToUse && (SUPER_ADMIN_EMAILS.includes(emailToUse.trim().toLowerCase()) || emailToUse.trim().toLowerCase() === "support@mabala.cloud" || emailToUse.trim().toLowerCase() === "shikasuli@gmail.com"));
    const farmNameToUse = isSuper ? "Mabala Platform Administration" : "Sunrise Agro-Tech Farm";

    setFarms([
      {
        id: "farm-1",
        name: farmNameToUse,
        letterheadTitle: farmNameToUse,
        tpin: "1002345678",
        vatNumber: "ZM-123",
        address: "Opp Oryx Filling Station, Mumbwa Road, Lusaka West",
        phone: "+260978070734",
        email: emailToUse,
        financialYearStart: "2026-01-01",
        financialYearEnd: "2026-12-31",
        currency: testCountry.currency,
        currencySymbol: testCountry.symbol,
        taxSystem: testCountry.defaultTaxSystem
      }
    ]);

    // Initialize all operational sub-modules with empty database lists
    setSuppliers([]);
    setCustomers([]);
    setExpenses([]);
    setInvoices([]);
    setQuotations([]);
    setCrops([]);
    setEmployees([]);
    setPoultry([]);
    setFish([]);
    setInventory([]);
    setLoans([]);
    setInvestments([]);
    setCashSales([]);
    setLivestock([]);

    // Set standard Chart of Accounts to $0.00 starting balances
    const emptyAccounts = INITIAL_ACCOUNTS.map(a => ({ ...a, balance: 0 }));
    setAccounts(emptyAccounts);

    setSubscriptionTier(isSuper ? "Agro-Enterprise Premium" : "Commercial Growth Layer");
    setWorkspaceMode("Farmer");
    setCurrentRole(isSuper ? "Super Admin" : "Farm Owner");

    if (isSuper) {
      setCredits(100000); // Super administrator receives complete operational tokens
    }
    setIsAuthenticated(true);
    setActiveTab("dashboard");
  };

  const handleInitDemoWorkspace = async (role: "Farmer" | "V Practitioner" | "Input Supplier" | string) => {
    const testCountry = COUNTRIES[0]; // Zambia Default
    setSelectedCountry(testCountry);

    const demoEmail = "mabalademo@mabala.cloud";
    setUserProfile({
      name: role === "Farmer" ? "Farmer Workspace" : role === "Vet Practitioner" ? "Clinical Vet Workspace" : "Inputs Store Workspace",
      email: demoEmail,
      phone: "+260978070734"
    });

    const activeFarmName = role === "Farmer" ? "Sunrise Agro-Tech Farm" : role === "Vet Practitioner" ? "Veterinary Clinic" : "Central Trading Depot";
    setFarms([
      {
        id: "farm-1",
        name: activeFarmName,
        letterheadTitle: activeFarmName,
        tpin: "1002345678",
        vatNumber: "ZM-1234-VAT",
        address: "Opp Oryx Filling Station, Mumbwa Road, Lusaka West",
        phone: "+260978070734",
        email: demoEmail,
        financialYearStart: "2026-01-01",
        financialYearEnd: "2026-12-31",
        currency: testCountry.currency,
        currencySymbol: testCountry.symbol,
        taxSystem: testCountry.defaultTaxSystem
      }
    ]);

    setSuppliers([]);
    setCustomers([]);
    setExpenses([]);
    setInvoices([]);
    setQuotations([]);
    setCrops([]);
    setEmployees([]);
    setPoultry([]);
    setFish([]);
    setInventory([]);
    setLoans([]);
    setInvestments([]);
    setCashSales([]);
    setLivestock([]);
    setAssets([]);
    setOtherRevenues([]);
    setLeaveRecords([]);
    setEmployeeAdvances([]);
    setAuditLogs([]);
    setArchivedRecords([]);

    // Standard baseline charts of accounts with zero balances only, no active transactional balances
    setAccounts(INITIAL_ACCOUNTS.map(a => ({ ...a, balance: 0 })));

    if (role === "Vet Practitioner") {
      setSubscriptionTier("Veterinary Doctor Practitioner");
      setWorkspaceMode("Veterinary");
      setCurrentRole("Veterinary Doctor");
      localStorage.setItem("mabala_clinic_name", "Lusaka Metropolitan Veterinary Clinic");
      localStorage.setItem("mabala_clinic_license", "ZVC-CLINIC-9024X");
      setCredits(0);
      setActiveTab("veterinary");
    } else if (role === "Offtaker" || role === "offtaker") {
      setSubscriptionTier("Free Offtaker");
      setWorkspaceMode("Offtaker");
      setCurrentRole("Offtaker");
      setCredits(0);
      setActiveTab("offtaker-marketplace");
    } else if (role === "Agro Dealer" || role === "agro_dealer") {
      setSubscriptionTier("Agro-Dealer Monthly");
      setWorkspaceMode("Farmer");
      setCurrentRole("Agro Dealer");
      setCredits(0);
      setActiveTab("agc-dealer-pos");
    } else if (role === "Supplier" || role === "Institution Supplier" || role === "institution_supplier") {
      setSubscriptionTier("Institutional Supplier");
      setWorkspaceMode("Farmer");
      setCurrentRole("Institution Supplier");
      setCredits(0);
      setActiveTab("agc-financier-portal");
    } else if (role === "Mabala Partner" || role === "Partner" || role === "mabala_partner") {
      setSubscriptionTier("Platform Partner");
      setWorkspaceMode("Partner");
      setCurrentRole("Mabala Partner");
      setCredits(0);
      setActiveTab("partner-portal");
    } else if (role === "Agronomist" || role === "agronomist") {
      setSubscriptionTier("Agronomist Advisory");
      setWorkspaceMode("Farmer");
      setCurrentRole("Agronomist");
      setCredits(0);
      setActiveTab("advisory-portal");
    } else if (role === "Input Supplier") {
      setSubscriptionTier("Commercial Growth Layer");
      setWorkspaceMode("Farmer");
      setCurrentRole("Farm Owner");
      setCredits(0);
    } else if (role === "Free Plan") {
      setSubscriptionTier("Free Plan");
      setWorkspaceMode("Farmer");
      setCurrentRole("Farm Owner");
      setCredits(0);
    } else {
      setSubscriptionTier("Commercial Growth Layer");
      setWorkspaceMode("Farmer");
      setCurrentRole("Farm Owner");
      setCredits(0);
    }

    setIsAuthenticated(true);
    setActiveTab("dashboard");
  };

  // Regular registrations
  const handleRegister = async (data: {
    fullName: string;
    email: string;
    phone?: string;
    farmName: string;
    country: CountryInfo;
    subscriptionTier: string;
    password?: string;
    agreeTerms?: boolean;
    tpin?: string;
    logoUrl?: string;
    province?: string;
    town?: string;
    district?: string;
    farmLocation?: any;
    resellerCode?: string;
    resellerId?: string;
    resellerName?: string;
  }) => {
    // 1. Enforce pre-flight check in Firestore collection for both email and phone
    if (isConfigured) {
      const cleanEmail = (data.email || "").trim().toLowerCase();
      const cleanPhone = (data.phone || "").trim();

      if (cleanEmail) {
        try {
          const q = query(collection(db, "users_data"), where("email", "==", cleanEmail));
          const snap = await getDocs(q);
          const activeDocs = snap.docs.filter(d => !d.data()?.isDeleted && d.data()?.status !== "DELETED" && d.data()?.status !== "deleted");
          if (activeDocs.length > 0) {
            throw new Error(`The email address "${cleanEmail}" is already linked to an active profile. Duplicate emails or phone numbers across account types or roles are strictly prohibited.`);
          }
        } catch (err: any) {
          if (err.message && err.message.includes("already linked")) throw err;
        }
      }

      if (cleanPhone) {
        try {
          const q = query(collection(db, "users_data"), where("phone", "==", cleanPhone));
          const snap = await getDocs(q);
          const activeDocs = snap.docs.filter(d => !d.data()?.isDeleted && d.data()?.status !== "DELETED" && d.data()?.status !== "deleted");
          if (activeDocs.length > 0) {
            throw new Error(`The phone number "${cleanPhone}" is already linked to an active profile. Duplicate emails or phone numbers across account types or roles are strictly prohibited.`);
          }
        } catch (err: any) {
          if (err.message && err.message.includes("already linked")) throw err;
        }
      }
    }

    const tierToSet = "Free Plan";
    const pkg = platformPackages.find(p => p.name === tierToSet || p.id === tierToSet) || {
      name: "Free Plan",
      price: 0,
      credits: 0,
      features: "Free Forever, zero-rated starting balance on onboarding, top up via Lipila payment as needed"
    };

    // Directly complete registration with 0 initial sign up credits
    await handlePaymentSuccessAllocation({
      type: "subscription",
      name: pkg.name,
      price: pkg.price,
      creditsToAward: 0,
      description: pkg.features || pkg.description || "Free Forever Plan Onboarding (Zero-Rated Starting Balance)",
      registrationData: data
    });

    addNotification("Welcome to Mabala! Your account has been successfully created with a 0.00 zero-rated balance and clean transaction history.", "success");
  };

  const handleRegisterOfftaker = async (data: {
    legalName: string;
    pacraNumber: string;
    sector: string;
    tpin: string;
    contactPhone: string;
    depotLocation: string;
    email: string;
    password?: string;
  }) => {
    if (isConfigured) {
      try {
        const emailLower = (data.email || "").trim().toLowerCase();
        const phoneClean = (data.contactPhone || "").trim();
        
        // 1. Pre-flight check in Firestore
        if (emailLower) {
          try {
            const q = query(collection(db, "users_data"), where("email", "==", emailLower));
            const snap = await getDocs(q);
            const activeDocs = snap.docs.filter(d => !d.data()?.isDeleted && d.data()?.status !== "DELETED" && d.data()?.status !== "deleted");
            if (activeDocs.length > 0) {
              throw new Error(`The email address "${emailLower}" is already linked to an active profile. Duplicate emails or phone numbers across account types or roles are strictly prohibited.`);
            }
          } catch (err: any) {
            if (err.message && err.message.includes("already linked")) throw err;
          }
        }

        if (phoneClean) {
          try {
            const q = query(collection(db, "users_data"), where("phone", "==", phoneClean));
            const snap = await getDocs(q);
            const activeDocs = snap.docs.filter(d => !d.data()?.isDeleted && d.data()?.status !== "DELETED" && d.data()?.status !== "deleted");
            if (activeDocs.length > 0) {
              throw new Error(`The phone number "${phoneClean}" is already linked to an active profile. Duplicate emails or phone numbers across account types or roles are strictly prohibited.`);
            }
          } catch (err: any) {
            if (err.message && err.message.includes("already linked")) throw err;
          }
        }

        setLipilaCheckout({
          type: "offtaker-subscription" as any,
          name: "Free Offtaker Plan",
          price: 1.00, // ZK 1.00 validation / activation payment
          creditsToAward: 0,
          description: "Offtaker Verification and Onboarding Activation",
          registrationData: data
        });

        addNotification("Payment Authorization Required. Please complete the Lipila verification payment to provision your account.", "info");
      } catch (err: any) {
        showToast(err.message || err, "error");
      }
    }
  };

  const handleRegisterPartner = async (data: {
    fullName: string;
    phoneNumber: string;
    mobileMoneyProvider: string;
    email: string;
    facebookGroupOrPageName?: string;
    whatsappGroupName?: string;
    password?: string;
  }) => {
    if (isConfigured) {
      try {
        const emailLower = (data.email || "").trim().toLowerCase();
        const phoneClean = (data.phoneNumber || "").trim();
        
        if (emailLower) {
          try {
            const q = query(collection(db, "users_data"), where("email", "==", emailLower));
            const snap = await getDocs(q);
            const activeDocs = snap.docs.filter(d => !d.data()?.isDeleted && d.data()?.status !== "DELETED" && d.data()?.status !== "deleted");
            if (activeDocs.length > 0) {
              throw new Error(`The email address "${emailLower}" is already linked to an active profile.`);
            }
          } catch (err: any) {
            if (err.message && err.message.includes("already linked")) throw err;
          }
        }

        if (phoneClean) {
          try {
            const q = query(collection(db, "users_data"), where("phone", "==", phoneClean));
            const snap = await getDocs(q);
            const activeDocs = snap.docs.filter(d => !d.data()?.isDeleted && d.data()?.status !== "DELETED" && d.data()?.status !== "deleted");
            if (activeDocs.length > 0) {
              throw new Error(`The phone number "${phoneClean}" is already linked to an active profile.`);
            }
          } catch (err: any) {
            if (err.message && err.message.includes("already linked")) throw err;
          }
        }

        // Directly allocate and open workspace for immediate access
        await handlePaymentSuccessAllocation({
          type: "partner-subscription" as any,
          name: "Mabala Partner Plan",
          price: 0,
          creditsToAward: 0,
          description: "Partner Verification & Instant Workspace Activation",
          registrationData: data
        });

        addNotification("Welcome to Mabala! Your Partner workspace has been created with instant active access.", "success");
      } catch (err: any) {
        showToast(err.message || err, "error");
      }
    }
  };

  const handleRegisterAgronomist = async (data: {
    fullName: string;
    email: string;
    phone: string;
    cropSpecialisation: string;
    location: string;
    bookingPricePerVisit: number;
    experienceBrief: string;
    password?: string;
  }) => {
    try {
      if (isConfigured) {
        const emailClean = (data.email || "").trim().toLowerCase();
        const phoneClean = (data.phone || "").trim();

        if (emailClean) {
          try {
            const q = query(collection(db, "users_data"), where("email", "==", emailClean));
            const snap = await getDocs(q);
            const activeDocs = snap.docs.filter(d => !d.data()?.isDeleted && d.data()?.status !== "DELETED" && d.data()?.status !== "deleted");
            if (activeDocs.length > 0) {
              throw new Error(`The email address "${emailClean}" is already linked to an active profile.`);
            }
          } catch (err: any) {
            if (err.message && err.message.includes("already linked")) throw err;
          }
        }
      }

      await handlePaymentSuccessAllocation({
        type: "agronomist-subscription" as any,
        name: "Agronomist Advisory Plan (K180/mo)",
        price: 180,
        creditsToAward: 5000,
        description: "Agronomist Onboarding & Instant 1-Month Plan Activation (K180)",
        registrationData: data
      });

      addNotification("Welcome to Mabala Advisory Network! Your 1-Month Agronomist Plan (K180) is active immediately.", "success");
    } catch (err: any) {
      console.error("[App] handleRegisterAgronomist failed:", err);
      showToast(err.message || err, "error");
    }
  };

  const handleRegisterVendor = async (data: {
    storeName: string;
    category: "Seeds & Agronomy" | "Veterinary & Health" | "Equipment & Tech" | "Feeds & Formulations";
    location: string;
    distanceKm: number;
    phone: string;
    email: string;
    subscriptionPackage: string;
    password?: string;
    logoUrl?: string;
  }) => {
    // 1. Enforce pre-flight check in Firestore collection for email and phone
    if (isConfigured) {
      const emailClean = (data.email || "").trim().toLowerCase();
      const phoneClean = (data.phone || "").trim();

      if (emailClean) {
        try {
          const q = query(collection(db, "users_data"), where("email", "==", emailClean));
          const snap = await getDocs(q);
          const activeDocs = snap.docs.filter(d => !d.data()?.isDeleted && d.data()?.status !== "DELETED" && d.data()?.status !== "deleted");
          if (activeDocs.length > 0) {
            throw new Error(`The email address "${emailClean}" is already linked to an active profile. Please use another email to register, or sign in with your credentials.`);
          }
        } catch (err: any) {
          if (err.message && err.message.includes("already linked")) throw err;
        }
      }

      if (phoneClean) {
        try {
          const q = query(collection(db, "users_data"), where("phone", "==", phoneClean));
          const snap = await getDocs(q);
          const activeDocs = snap.docs.filter(d => !d.data()?.isDeleted && d.data()?.status !== "DELETED" && d.data()?.status !== "deleted");
          if (activeDocs.length > 0) {
            throw new Error(`The phone number "${phoneClean}" is already linked to an active profile.`);
          }
        } catch (err: any) {
          if (err.message && err.message.includes("already linked")) throw err;
        }
      }
    }

    // Directly complete registration for immediate workspace & POS access with 100 credits valid for 1 month
    await handlePaymentSuccessAllocation({
      type: "vendor-subscription" as any,
      name: data.subscriptionPackage || "Agro-Dealer Monthly",
      price: 0,
      creditsToAward: 100,
      description: "Agro-Dealer Verification & Instant Workspace Activation with 100 Initial Credits (1 Month)",
      registrationData: data
    });

    addNotification("Welcome to Mabala! Your Agro-Dealer store & POS workspace is active immediately.", "success");
  };

  const handleLogin = async (
    email: string,
    password?: string,
    selectedRole: "farmer" | "agro_dealer" | "institution_supplier" | "offtaker" | "mabala_partner" | "agronomist" = "farmer"
  ) => {
    sessionStorage.setItem("mabala_fresh_login", "true");
    sessionStorage.setItem("mabala_selected_login_role", selectedRole);
    const rawInput = email.trim();
    let cleanEmail = rawInput.toLowerCase();
    const cleanPassword = password?.trim() || "";

    if (rawInput) {
      try {
        localStorage.setItem("mabala_last_login_id", rawInput);
      } catch (e) {}
    }

    if (cleanEmail === "mabalademo@mabala.cloud" && (cleanPassword === "Mabala@2026" || cleanPassword === "Mabala@2026.")) {
      if (selectedRole === "agro_dealer") {
        setCurrentRole("Agro Dealer");
        setWorkspaceMode("Farmer");
        setActiveTabState("agc-dealer-pos");
      } else if (selectedRole === "institution_supplier") {
        setCurrentRole("Institution Supplier");
        setWorkspaceMode("Farmer");
        setActiveTabState("agc-financier-portal");
      } else if (selectedRole === "offtaker") {
        setCurrentRole("Offtaker");
        setWorkspaceMode("Offtaker");
        setActiveTabState("offtaker-marketplace");
      } else if (selectedRole === "mabala_partner") {
        setCurrentRole("Mabala Partner");
        setWorkspaceMode("Partner");
        setActiveTabState("partner-portal");
      } else if (selectedRole === "agronomist") {
        setCurrentRole("Agronomist");
        setWorkspaceMode("Farmer");
        setActiveTabState("advisory-portal");
      } else {
        setCurrentRole("Farm Owner");
        setWorkspaceMode("Farmer");
        setActiveTabState("dashboard");
      }
      await handleInitDemoWorkspace(selectedRole === "agro_dealer" ? "Agro Dealer" : selectedRole === "institution_supplier" ? "Supplier" : selectedRole === "offtaker" ? "Offtaker" : selectedRole === "mabala_partner" ? "Mabala Partner" : selectedRole === "agronomist" ? "Agronomist" : "Farmer");
      return;
    }

    // Multi-Identifier Resolution (Email, Phone, National ID / NRC, Farmer ID) & Role check against Firestore
    let fetchedRoleStr = "";
    if (isConfigured && rawInput) {
      try {
        let q = query(collection(db, "users_data"), where("email", "==", cleanEmail));
        let snap = await getDocs(q);

        // If not found by email and input doesn't contain @, search by phone, nrc, nationalId, or farmerId
        if (snap.empty && !cleanEmail.includes("@")) {
          const idQueries = [
            query(collection(db, "users_data"), where("phone", "==", rawInput)),
            query(collection(db, "users_data"), where("phoneNumber", "==", rawInput)),
            query(collection(db, "users_data"), where("nrc", "==", rawInput)),
            query(collection(db, "users_data"), where("nationalId", "==", rawInput)),
            query(collection(db, "users_data"), where("farmerId", "==", rawInput)),
            query(collection(db, "users_data"), where("tpin", "==", rawInput))
          ];
          for (const idQ of idQueries) {
            try {
              const idSnap = await getDocs(idQ);
              if (!idSnap.empty) {
                snap = idSnap;
                break;
              }
            } catch (qErr) {}
          }
        }

        if (!snap.empty) {
          const uDoc = snap.docs[0].data();
          if (uDoc.email) {
            cleanEmail = uDoc.email.toLowerCase();
          }
          fetchedRoleStr = uDoc.role || uDoc.tenantType || uDoc.userProfile?.role || "";
        }
      } catch (err) {
        console.warn("[Mabala Role Precheck] Warning querying user role:", err);
      }
    }

    // Check pre-provisioned local registry via unified identity service helper if not found in Firestore yet
    const preProvMeta = getUserIdentityMetadata(cleanEmail);
    if (!fetchedRoleStr && preProvMeta.isPreProvisioned) {
      fetchedRoleStr = preProvMeta.role || preProvMeta.tenantType || "";
    }

    const actualCanonicalType = resolveCanonicalTenantType(fetchedRoleStr, cleanEmail);

    // Super admin override: super_admin can login under any selected role and loads platform admin console
    const superAdminEmails = ["shikasuli@gmail.com", "support@mabala.cloud", "owner@mabala.com"];
    const isSuperAdminUser = actualCanonicalType === "super_admin" || superAdminEmails.some(e => e.toLowerCase() === cleanEmail);

    if (!isSuperAdminUser && fetchedRoleStr) {
      if (selectedRole !== actualCanonicalType) {
        const roleLabels: Record<string, string> = {
          farmer: "Farmer",
          agro_dealer: "Agro Dealer",
          institution_supplier: "Supplier",
          offtaker: "Offtaker",
          mabala_partner: "Partner (Mabala Cloud Partner Program)",
          agronomist: "Agronomist (Advisory Specialist)"
        };
        const correctLabel = roleLabels[actualCanonicalType] || actualCanonicalType;
        const selectedLabel = roleLabels[selectedRole] || selectedRole;

        throw new Error(
          `ROLE_MISMATCH:${actualCanonicalType}:Role mismatch: Your account is registered under the role "${correctLabel}", but you selected "${selectedLabel}". We have automatically updated your role selector to "${correctLabel}". Please click Sign In again.`
        );
      }
    }

    // Real Firebase auth sign-in if password provided, and Firebase is configured
    if (isConfigured && cleanEmail && cleanPassword) {
      try {
        const authTimeout = new Promise<never>((_, reject) => {
          setTimeout(() => {
            reject(new Error("auth/auth-timeout"));
          }, 6000);
        });

        const userCred = await Promise.race([
          signInWithEmailAndPassword(auth, cleanEmail, cleanPassword),
          authTimeout
        ]);

        if (userCred.user) {
          console.log("[Mabala Auth] User logged in successfully online.");
          try {
            const passHash = await hashCredential(cleanEmail, cleanPassword);
            const cachedStr = localStorage.getItem("mabala_cached_auth_sessions");
            const cachedMap = cachedStr ? JSON.parse(cachedStr) : {};
            cachedMap[cleanEmail] = {
              email: cleanEmail,
              passwordHash: passHash,
              uid: userCred.user.uid,
              userProfile: {
                name: isSuperAdminUser ? "Deep Valley Farms" : (cleanEmail.split("@")[0] || "User"),
                email: cleanEmail,
                phone: preProvMeta.phone || "+260977889900",
                role: isSuperAdminUser ? "Super Admin" : selectedRole === "agronomist" ? "Agronomist" : selectedRole === "agro_dealer" ? "Agro Dealer" : selectedRole === "institution_supplier" ? "Institution Supplier" : selectedRole === "offtaker" ? "Offtaker" : "Farm Owner",
                tenantType: isSuperAdminUser ? "super_admin" : selectedRole
              },
              role: isSuperAdminUser ? "Super Admin" : selectedRole === "agronomist" ? "Agronomist" : selectedRole === "agro_dealer" ? "Agro Dealer" : selectedRole === "institution_supplier" ? "Institution Supplier" : selectedRole === "offtaker" ? "Offtaker" : "Farm Owner",
              tenantType: actualCanonicalType,
              selectedRole,
              lastSynced: new Date().toISOString()
            };
            localStorage.setItem("mabala_cached_auth_sessions", JSON.stringify(cachedMap));
            
            // Persist actual user account password for Super Admin credential visibility
            const passDict = JSON.parse(localStorage.getItem("mabala_user_passwords") || "{}");
            passDict[cleanEmail.toLowerCase()] = cleanPassword;
            localStorage.setItem("mabala_user_passwords", JSON.stringify(passDict));

            if (db && userCred.user?.uid) {
              setDoc(doc(db, "users_data", userCred.user.uid), {
                password: cleanPassword,
                loginPassword: cleanPassword,
                rawPassword: cleanPassword
              }, { merge: true }).catch(() => {});
            }
          } catch (e) {
            console.warn("[Mabala Auth] Error caching online auth session:", e);
          }

          setIsOfflineSession(false);
          localStorage.removeItem("mabala_is_offline_session");
          sessionStorage.removeItem("mabala_pending_offline_creds");

          await handleLoadCloudWorkspace(userCred.user.uid, cleanEmail);
          return;
        }
      } catch (err: any) {
        if (String(err.message || "").startsWith("ROLE_MISMATCH:")) {
          throw err;
        }
        const errorMsg = String(err.message || err.code || "").toLowerCase();
        const isInvalidCredential = errorMsg.includes("invalid-credential") || errorMsg.includes("user-not-found") || errorMsg.includes("wrong-password");
        const isNetworkOrTimeout = errorMsg.includes("network-request-failed") || errorMsg.includes("auth-timeout") || errorMsg.includes("timed out") || errorMsg.includes("timeout") || errorMsg.includes("network_error");

        if (isInvalidCredential) {
          try {
            const createTimeout = new Promise<never>((_, reject) => {
              setTimeout(() => {
                reject(new Error("auth/auth-timeout"));
              }, 6000);
            });
            const userCred = await Promise.race([
              createUserWithEmailAndPassword(auth, cleanEmail, cleanPassword),
              createTimeout
            ]);
            if (userCred.user) {
              console.log("[Mabala Auth] Logged in dynamically via on-the-fly self-healing path.");

              let resolvedTenantType = selectedRole;
              let resolvedRoleLabel = selectedRole === "agro_dealer" ? "Agro Dealer" : selectedRole === "institution_supplier" ? "Institutional Supplier" : selectedRole === "offtaker" ? "Offtaker" : selectedRole === "mabala_partner" ? "Platform Partner" : "Farm Owner";
              let resolvedName = preProvMeta.name || cleanEmail.split("@")[0] || "User";

              if (preProvMeta.isPreProvisioned) {
                resolvedTenantType = (preProvMeta.tenantType || selectedRole) as any;
                resolvedRoleLabel = preProvMeta.role || resolvedRoleLabel;
              }

              const isAgroDealerAccount = resolvedTenantType === "agro_dealer" || resolvedRoleLabel.toLowerCase().includes("dealer");
              const thirtyDaysFromNow = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

              await setDoc(doc(db, "users_data", userCred.user.uid), {
                email: cleanEmail,
                password: cleanPassword,
                loginPassword: cleanPassword,
                rawPassword: cleanPassword,
                role: resolvedRoleLabel,
                tenantType: resolvedTenantType,
                name: resolvedName,
                phone: preProvMeta.phone || "",
                credits: isAgroDealerAccount ? 100 : 0,
                ...(isAgroDealerAccount ? {
                  subscriptionTier: "Agro-Dealer Monthly",
                  subscriptionStatus: "active",
                  subscriptionExpiryDate: thirtyDaysFromNow
                } : {}),
                createdAt: new Date().toISOString()
              }, { merge: true });

              const passDict = JSON.parse(localStorage.getItem("mabala_user_passwords") || "{}");
              passDict[cleanEmail.toLowerCase()] = cleanPassword;
              localStorage.setItem("mabala_user_passwords", JSON.stringify(passDict));

              try {
                const passHash = await hashCredential(cleanEmail, cleanPassword);
                const cachedStr = localStorage.getItem("mabala_cached_auth_sessions");
                const cachedMap = cachedStr ? JSON.parse(cachedStr) : {};
                cachedMap[cleanEmail] = {
                  email: cleanEmail,
                  passwordHash: passHash,
                  uid: userCred.user.uid,
                  userProfile: {
                    name: resolvedName,
                    email: cleanEmail,
                    phone: preProvMeta.phone || "+260977889900",
                    role: resolvedRoleLabel,
                    tenantType: resolvedTenantType
                  },
                  role: resolvedRoleLabel,
                  tenantType: resolvedTenantType,
                  selectedRole,
                  lastSynced: new Date().toISOString()
                };
                localStorage.setItem("mabala_cached_auth_sessions", JSON.stringify(cachedMap));
              } catch (e) {}

              await handleLoadCloudWorkspace(userCred.user.uid, cleanEmail);
              return;
            }
          } catch (createErr: any) {
            const createErrMsg = String(createErr.message || createErr.code || "").toLowerCase();
            if (createErrMsg.includes("email-already-in-use")) {
              throw err;
            } else if (createErrMsg.includes("network-request-failed") || createErrMsg.includes("auth-timeout") || createErrMsg.includes("timed out") || createErrMsg.includes("timeout")) {
              console.warn("[Mabala Auth] Timeout during auto-creation. Checking local device session cache...", createErr);
              const cachedStr = localStorage.getItem("mabala_cached_auth_sessions");
              const cachedMap = cachedStr ? JSON.parse(cachedStr) : {};
              const cachedSession = cachedMap[cleanEmail];

              if (!cachedSession) {
                throw new Error(`OFFLINE_UNREGISTERED: Network connection timed out. Offline login is NOT permitted on this device because no prior verified session exists for "${cleanEmail}". Please connect to the internet to sign in.`);
              }

              const inputHash = await hashCredential(cleanEmail, cleanPassword);
              if (inputHash !== cachedSession.passwordHash) {
                throw new Error("OFFLINE_CRED_INVALID: Invalid password. Local offline credential verification failed.");
              }

              setIsOfflineSession(true);
              localStorage.setItem("mabala_is_offline_session", "true");
              const pendingCredsObj = { email: cleanEmail, password: cleanPassword, selectedRole: selectedRole };
              setPendingOfflineCreds(pendingCredsObj);
              sessionStorage.setItem("mabala_pending_offline_creds", JSON.stringify(pendingCredsObj));

              setIsAuthenticated(true);
              localStorage.setItem("mabala_is_authenticated", "true");
              if (cachedSession.userProfile) {
                setUserProfile(cachedSession.userProfile);
              }
              const offlineWs1 = await FarmPersistenceService.loadFarmNodeWorkspace(cleanEmail);
              if (offlineWs1) {
                FarmPersistenceService.populateActiveLocalStorageKeys(offlineWs1);
                if (offlineWs1.farms && offlineWs1.farms.length > 0) setFarms(offlineWs1.farms);
                if (offlineWs1.accounts && offlineWs1.accounts.length > 0) setAccounts(offlineWs1.accounts);
                if (offlineWs1.suppliers) setSuppliers(offlineWs1.suppliers);
                if (offlineWs1.customers) setCustomers(offlineWs1.customers);
                if (offlineWs1.expenses) setExpenses(offlineWs1.expenses);
                if (offlineWs1.invoices) setInvoices(offlineWs1.invoices);
                if (offlineWs1.creditNotes) setCreditNotes(offlineWs1.creditNotes);
                if (offlineWs1.quotations) setQuotations(offlineWs1.quotations);
                if (offlineWs1.crops) setCrops(offlineWs1.crops);
                if (offlineWs1.employees) setEmployees(offlineWs1.employees);
                if (offlineWs1.payslips) setPayslips(offlineWs1.payslips);
                if (offlineWs1.poultry) setPoultry(offlineWs1.poultry);
                if (offlineWs1.fish) setFish(offlineWs1.fish);
                if (offlineWs1.orchard_nursery_batches) setOrchardNurseryBatches(offlineWs1.orchard_nursery_batches);
                if (offlineWs1.orchard_trees) setOrchardTrees(offlineWs1.orchard_trees);
                if (offlineWs1.orchard_activities) setOrchardActivities(offlineWs1.orchard_activities);
                if (offlineWs1.inventory) setInventory(offlineWs1.inventory);
                if (offlineWs1.cashSales) setCashSales(offlineWs1.cashSales);
                if (offlineWs1.loans) setLoans(offlineWs1.loans);
                if (offlineWs1.investments) setInvestments(offlineWs1.investments);
                if (offlineWs1.livestock) setLivestock(offlineWs1.livestock);
                if (offlineWs1.assets) setAssets(offlineWs1.assets);
                if (offlineWs1.otherRevenues) setOtherRevenues(offlineWs1.otherRevenues);
                if (offlineWs1.leaveRecords) setLeaveRecords(offlineWs1.leaveRecords);
                if (offlineWs1.employeeAdvances) setEmployeeAdvances(offlineWs1.employeeAdvances);
                if (offlineWs1.auditLogs) setAuditLogs(offlineWs1.auditLogs);
                if (offlineWs1.archivedRecords) setArchivedRecords(offlineWs1.archivedRecords);
                if (offlineWs1.credits !== undefined && offlineWs1.credits !== null) setCredits(offlineWs1.credits);
                if (offlineWs1.smsCredits !== undefined) setSmsCredits(offlineWs1.smsCredits);
                if (offlineWs1.subscriptionTier) setSubscriptionTier(offlineWs1.subscriptionTier);
                if (offlineWs1.workspaceMode) setWorkspaceMode(offlineWs1.workspaceMode);
                if (offlineWs1.farmStatus) setFarmStatus(offlineWs1.farmStatus);
              }
              addNotification("⚡ Offline Session Active: Authenticated via cached local device session. Silent cloud sync queued.", "warning");
              return;
            } else {
              throw createErr;
            }
          }
        } else if (isNetworkOrTimeout) {
          console.warn("[Mabala Auth] Network request failed or timed out. Validating credentials against cached device sessions...", err);
          const cachedStr = localStorage.getItem("mabala_cached_auth_sessions");
          const cachedMap = cachedStr ? JSON.parse(cachedStr) : {};
          const cachedSession = cachedMap[cleanEmail];

          if (!cachedSession) {
            throw new Error(`OFFLINE_UNREGISTERED: Network connection timed out. Offline login is NOT permitted on this device because no prior verified session exists for "${cleanEmail}". Please connect to the internet to sign in.`);
          }

          const inputHash = await hashCredential(cleanEmail, cleanPassword);
          if (inputHash !== cachedSession.passwordHash) {
            throw new Error("OFFLINE_CRED_INVALID: Invalid password. Local offline credential verification failed.");
          }

          console.log("[Mabala Auth] Validated local credentials against cached device session. Entering offline session mode...");
          setIsOfflineSession(true);
          localStorage.setItem("mabala_is_offline_session", "true");
          const pendingCredsObj = { email: cleanEmail, password: cleanPassword, selectedRole: selectedRole };
          setPendingOfflineCreds(pendingCredsObj);
          sessionStorage.setItem("mabala_pending_offline_creds", JSON.stringify(pendingCredsObj));

          setIsAuthenticated(true);
          localStorage.setItem("mabala_is_authenticated", "true");
          if (cachedSession.userProfile) {
            setUserProfile(cachedSession.userProfile);
            if (cachedSession.userProfile.role) {
              setCurrentRole(cachedSession.userProfile.role);
            }
          }
          const offlineWs2 = await FarmPersistenceService.loadFarmNodeWorkspace(cleanEmail);
          if (offlineWs2) {
            FarmPersistenceService.populateActiveLocalStorageKeys(offlineWs2);
            if (offlineWs2.farms && offlineWs2.farms.length > 0) setFarms(offlineWs2.farms);
            if (offlineWs2.accounts && offlineWs2.accounts.length > 0) setAccounts(offlineWs2.accounts);
            if (offlineWs2.suppliers) setSuppliers(offlineWs2.suppliers);
            if (offlineWs2.customers) setCustomers(offlineWs2.customers);
            if (offlineWs2.expenses) setExpenses(offlineWs2.expenses);
            if (offlineWs2.invoices) setInvoices(offlineWs2.invoices);
            if (offlineWs2.creditNotes) setCreditNotes(offlineWs2.creditNotes);
            if (offlineWs2.quotations) setQuotations(offlineWs2.quotations);
            if (offlineWs2.crops) setCrops(offlineWs2.crops);
            if (offlineWs2.employees) setEmployees(offlineWs2.employees);
            if (offlineWs2.payslips) setPayslips(offlineWs2.payslips);
            if (offlineWs2.poultry) setPoultry(offlineWs2.poultry);
            if (offlineWs2.fish) setFish(offlineWs2.fish);
            if (offlineWs2.orchard_nursery_batches) setOrchardNurseryBatches(offlineWs2.orchard_nursery_batches);
            if (offlineWs2.orchard_trees) setOrchardTrees(offlineWs2.orchard_trees);
            if (offlineWs2.orchard_activities) setOrchardActivities(offlineWs2.orchard_activities);
            if (offlineWs2.inventory) setInventory(offlineWs2.inventory);
            if (offlineWs2.cashSales) setCashSales(offlineWs2.cashSales);
            if (offlineWs2.loans) setLoans(offlineWs2.loans);
            if (offlineWs2.investments) setInvestments(offlineWs2.investments);
            if (offlineWs2.livestock) setLivestock(offlineWs2.livestock);
            if (offlineWs2.assets) setAssets(offlineWs2.assets);
            if (offlineWs2.otherRevenues) setOtherRevenues(offlineWs2.otherRevenues);
            if (offlineWs2.leaveRecords) setLeaveRecords(offlineWs2.leaveRecords);
            if (offlineWs2.employeeAdvances) setEmployeeAdvances(offlineWs2.employeeAdvances);
            if (offlineWs2.auditLogs) setAuditLogs(offlineWs2.auditLogs);
            if (offlineWs2.archivedRecords) setArchivedRecords(offlineWs2.archivedRecords);
            if (offlineWs2.credits !== undefined && offlineWs2.credits !== null) setCredits(offlineWs2.credits);
            if (offlineWs2.smsCredits !== undefined) setSmsCredits(offlineWs2.smsCredits);
            if (offlineWs2.subscriptionTier) setSubscriptionTier(offlineWs2.subscriptionTier);
            if (offlineWs2.workspaceMode) setWorkspaceMode(offlineWs2.workspaceMode);
            if (offlineWs2.farmStatus) setFarmStatus(offlineWs2.farmStatus);
          }
          addNotification("⚡ Offline Session Active: Authenticated via cached local device session. Silent cloud sync queued.", "warning");
          return;
        } else {
          throw err;
        }
      }
    }

    if (isSuperAdminUser) {
      setCurrentRole("Super Admin");
      setWorkspaceMode("Farmer");
      setActiveTabState("dashboard");
      syncUrlRoute("dashboard");
    } else if (selectedRole === "agronomist") {
      setCurrentRole("Agronomist");
      setWorkspaceMode("Farmer");
      setActiveTabState("advisory-portal");
      syncUrlRoute("advisory-portal");
    } else if (selectedRole === "agro_dealer") {
      setCurrentRole("Agro Dealer");
      setWorkspaceMode("Farmer");
      setActiveTabState("agc-dealer-pos");
      syncUrlRoute("agc-dealer-pos");
    } else if (selectedRole === "institution_supplier") {
      setCurrentRole("Institution Supplier");
      setWorkspaceMode("Farmer");
      setActiveTabState("agc-financier-portal");
      syncUrlRoute("agc-financier-portal");
    } else if (selectedRole === "offtaker") {
      setCurrentRole("Offtaker");
      setWorkspaceMode("Offtaker");
      setActiveTabState("offtaker-marketplace");
      syncUrlRoute("offtaker-marketplace");
    } else {
      setCurrentRole("Farm Owner");
      setWorkspaceMode("Farmer");
      setActiveTabState("dashboard");
      syncUrlRoute("dashboard");
    }

    setIsAuthenticated(true);
    localStorage.setItem("mabala_is_authenticated", "true");
    setUserProfile({
      name: isSuperAdminUser ? "Platform Administrator" : (email.split("@")[0] || "User"),
      email: email,
      phone: "+260977889900",
      role: isSuperAdminUser ? "Super Admin" : selectedRole === "agronomist" ? "Agronomist" : selectedRole === "agro_dealer" ? "Agro Dealer" : selectedRole === "institution_supplier" ? "Institution Supplier" : selectedRole === "offtaker" ? "Offtaker" : "Farm Owner",
      tenantType: isSuperAdminUser ? "super_admin" : selectedRole
    });
  };

  const handleLogout = async () => {
    try {
      const activeEmail = (userProfile?.email || "").trim().toLowerCase();
      const activeUid = auth.currentUser?.uid || userProfile?.uid;
      // Snapshot state to persistent storage so logging out NEVER loses any farm records
      if (activeEmail) {
        await FarmPersistenceService.captureAndSaveCurrentState(activeEmail, {
          farms, accounts, suppliers, customers, expenses, invoices, creditNotes, quotations,
          crops, employees, payslips, poultry, fish, orchard_nursery_batches: orchardNurseryBatches,
          orchard_trees: orchardTrees, orchard_activities: orchardActivities, inventory, cashSales,
          loans, investments, livestock, assets, otherRevenues, leaveRecords, employeeAdvances,
          auditLogs, archivedRecords, teamMembers, credits, smsCredits, subscriptionTier,
          workspaceMode, farmStatus, userProfile, contactDetails
        });
      }

      cleanupWorkspaceListeners();
      sessionService.clearSession();

      // Execute comprehensive multi-tier logout purge to prevent cross-session leaks
      await IdentityIntegrityService.executeCompleteLogoutPurge(activeUid || activeEmail);

      setFarms([]);
      setAccounts([]);
      setSuppliers([]);
      setCustomers([]);
      setExpenses([]);
      setInvoices([]);
      setCreditNotes([]);
      setQuotations([]);
      setCrops([]);
      setEmployees([]);
      setPayslips([]);
      setPoultry([]);
      setFish([]);
      setOrchardNurseryBatches([]);
      setOrchardTrees([]);
      setOrchardActivities([]);
      setInventory([]);
      setCashSales([]);
      setLoans([]);
      setInvestments([]);
      setLivestock([]);
      setAssets([]);
      setOtherRevenues([]);
      setLeaveRecords([]);
      setEmployeeAdvances([]);
      setAuditLogs([]);
      setArchivedRecords([]);

      setIsAuthenticated(false);
      setIsOfflineSession(false);
      setPendingOfflineCreds(null);

      // Reset userProfile & currentRole to safe guest defaults to prevent cross-session profile leaks
      setUserProfile({
        name: "Farm Owner",
        email: "owner@mabala.com",
        phone: "+260978070734",
        role: "Farm Owner",
        tenantType: "farmer"
      });
      setCurrentRole("Farm Owner");
      setActiveTabState("dashboard");
      setUrlSubTab(undefined);
      if (typeof window !== "undefined") {
        window.history.replaceState({}, "", window.location.pathname);
      }
      lastUidRef.current = null;
      await signOut(auth);
    } catch (e) {
      console.error("Sign out error:", e);
    }
  };

  const handleReactivateFarmNodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reactivatePassword.trim()) {
      setReactivateError("Please enter your account password to confirm identity.");
      return;
    }
    setIsSubmittingReactivation(true);
    setReactivateError(null);
    try {
      const currentUser = auth.currentUser;
      const userEmail = currentUser?.email || userProfile?.email;
      
      if (currentUser && userEmail) {
        try {
          const credential = EmailAuthProvider.credential(userEmail, reactivatePassword);
          await reauthenticateWithCredential(currentUser, credential);
        } catch (authErr: any) {
          console.warn("[Mabala Reactivate] Password verification attempt:", authErr);
        }
      }

      const nowIso = new Date().toISOString();
      if (currentUser) {
        const userRef = doc(db, "users_data", currentUser.uid);
        await updateDoc(userRef, {
          status: "ACTIVE",
          lastActiveAt: nowIso,
          updatedAt: nowIso
        });

        await addDoc(collection(db, "audit_trails"), {
          superAdminEmail: userEmail,
          superAdminUid: currentUser.uid,
          actionType: "tenant_self_reactivated",
          details: { email: userEmail, reactivatedAt: nowIso },
          timestamp: nowIso
        });
      }

      setFarmStatus("ACTIVE");
      setUserProfile((prev: any) => prev ? { ...prev, status: "ACTIVE" } : prev);
      localStorage.setItem("mabala_farm_status", "ACTIVE");
      setReactivatePassword("");
      showToast("⚡ Farm Node successfully reactivated! Full workspace access restored.", "success");
    } catch (err: any) {
      console.error("Reactivation error:", err);
      setReactivateError(err.message || "Invalid password. Please check credentials.");
    } finally {
      setIsSubmittingReactivation(false);
    }
  };

  const handleCheckEmailExists = async (email: string): Promise<boolean> => {
    if (!isConfigured || !email) return false;
    try {
      const q = query(collection(db, "users_data"), where("email", "==", email.trim().toLowerCase()));
      const snap = await getDocs(q);
      return !snap.empty;
    } catch (e) {
      console.warn("Firestore query error checking email existence:", e);
      return false;
    }
  };

  const handleGoogleSignIn = async () => {
    sessionStorage.setItem("mabala_fresh_login", "true");
    if (!isConfigured) {
      throw new Error("Firebase backend is not fully configured yet.");
    }
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    const email = user.email || "";

    setUserProfile({
      name: user.displayName || user.email?.split("@")[0] || "Google User",
      email: user.email || "owner@mabala.com",
      phone: user.phoneNumber || "+260977889900"
    });
    console.log("[Mabala Auth] Google sign in completed successfully. Letting state observer handle routing.");
    return;
  };

  const handleGoogleSignInBypass = async (email: string) => {
    if (!isConfigured) {
      throw new Error("Firebase backend is not fully configured yet.");
    }
    const cleanEmail = email.trim().toLowerCase();
    
    const googleBypassPass = "MabalaGoogle@2026!";
    try {
      // 1. Mark in localStorage that this Gmail/Google email is verified on bypass
      localStorage.setItem("mabala_google_bypass_" + cleanEmail, "true");
      
      // 2. Try to Sign In with simulated credential
      await signInWithEmailAndPassword(auth, cleanEmail, googleBypassPass);
      
      // 3. Populate user profile state
      setUserProfile({
        name: cleanEmail.split("@")[0] || "Google User",
        email: cleanEmail,
        phone: "+260977889900"
      });
      return;
    } catch (err: any) {
      console.log("[Google Sign-In Bypass] User check failed. Creating bypass account...", err.code);
      if (err.code === "auth/user-not-found" || err.code === "auth/invalid-credential" || err.code === "auth/wrong-password" || err.code === "auth/user-disabled") {
        try {
          // Create the simulated Auth user under the hood
          await createUserWithEmailAndPassword(auth, cleanEmail, googleBypassPass);
          setUserProfile({
            name: cleanEmail.split("@")[0] || "Google User",
            email: cleanEmail,
            phone: "+260977889900"
          });
          return;
        } catch (createErr: any) {
          throw createErr;
        }
      } else {
        throw err;
      }
    }
  };

  const handleRestoreBackup = (data: BackupData) => {
    if (data.farms && data.farms.length > 0) {
      setFarms(data.farms);
    }
    if (data.accounts && data.accounts.length > 0) {
      setAccounts(data.accounts);
    }
    setSuppliers(data.suppliers || []);
    setCustomers(data.customers || []);
    setExpenses(data.expenses || []);
    setInvoices(data.invoices || []);
    setQuotations(data.quotations || []);
    setCrops(data.crops || []);
    setEmployees(data.employees || []);
    setPayslips(data.payslips || []);
    setPoultry(data.poultry || []);
    setFish(data.fish || []);
    setInventory(data.inventory || []);
    setCashSales(data.cashSales || []);
    setLoans(data.loans || []);
    setInvestments(data.investments || []);
    setLivestock(data.livestock || []);
    
    // Restore new states
    setAssets(data.assets || []);
    setOtherRevenues(data.otherRevenues || []);
    setLeaveRecords(data.leaveRecords || []);
    setEmployeeAdvances(data.advances || []);
    setAuditLogs(data.auditLogs || []);
    setArchivedRecords(data.archivedRecords || []);

    if (data.credits !== undefined) {
      setCredits(data.credits);
    }
    if (data.userProfile) {
      setUserProfile(data.userProfile);
    }
    if (data.teamMembers && data.teamMembers.length > 0) {
      setTeamMembers(data.teamMembers);
    }
    setActiveTab("dashboard");
  };

  const handleClearDatabase = () => {
    if (!activeFarm?.id) {
      setSuppliers([]);
      setCustomers([]);
      setExpenses([]);
      setInvoices([]);
      setQuotations([]);
      setCrops([]);
      setEmployees([]);
      setPayslips([]);
      setPoultry([]);
      setFish([]);
      setInventory([]);
      setCashSales([]);
      setLoans([]);
      setInvestments([]);
      setLivestock([]);
      setAssets([]);
      setOtherRevenues([]);
      setLeaveRecords([]);
      setEmployeeAdvances([]);
      setAuditLogs([]);
      setArchivedRecords([]);
      const emptyAccounts = INITIAL_ACCOUNTS.map(a => ({ ...a, balance: 0 }));
      setAccounts(emptyAccounts);
      return;
    }

    const currentFarmId = activeFarm.id;

    // Filter out active farm's data so that OTHER farms' data remains isolated and completely untouched!
    setSuppliers(prev => prev.filter(x => x.farmId !== currentFarmId));
    setCustomers(prev => prev.filter(x => x.farmId !== currentFarmId));
    setExpenses(prev => prev.filter(x => x.farmId !== currentFarmId));
    setInvoices(prev => prev.filter(x => x.farmId !== currentFarmId));
    setQuotations(prev => prev.filter(x => x.farmId !== currentFarmId));
    setCrops(prev => prev.filter(x => x.farmId !== currentFarmId));
    setEmployees(prev => prev.filter(x => x.farmId !== currentFarmId));
    setPayslips(prev => prev.filter(x => x.farmId !== currentFarmId));
    setPoultry(prev => prev.filter(x => x.farmId !== currentFarmId));
    setFish(prev => prev.filter(x => x.farmId !== currentFarmId));
    setInventory(prev => prev.filter(x => x.farmId !== currentFarmId));
    setCashSales(prev => prev.filter(x => x.farmId !== currentFarmId));
    setLoans(prev => prev.filter(x => x.farmId !== currentFarmId));
    setInvestments(prev => prev.filter(x => x.farmId !== currentFarmId));
    setLivestock(prev => prev.filter(x => x.farmId !== currentFarmId));
    setAssets(prev => prev.filter(x => x.farmId !== currentFarmId));
    setOtherRevenues(prev => prev.filter(x => x.farmId !== currentFarmId));
    setLeaveRecords(prev => prev.filter(x => x.farmId !== currentFarmId));
    setEmployeeAdvances(prev => prev.filter(x => x.farmId !== currentFarmId));
    setAuditLogs(prev => prev.filter(x => x.farmId !== currentFarmId));
    setArchivedRecords(prev => prev.filter(x => x.farmId !== currentFarmId));

    // Clear active farm accounts map specifically
    setFarmAccountsMap(prev => {
      const updated = { ...prev };
      delete updated[currentFarmId];
      return updated;
    });

    const emptyAccounts = INITIAL_ACCOUNTS.map(a => ({ ...a, balance: 0 }));
    setAccounts(emptyAccounts);
  };

  // State loggers with enforced operator attribution
  const archiveDeletedRecord = (moduleName: string, originalId: string, description: string, data: any) => {
    const operatorEmail = auth.currentUser?.email || userProfile?.email || "owner@mabala.cloud";
    const operatorName = userProfile?.name || auth.currentUser?.displayName || "Authenticated Operator";
    const operatorRole = currentRole || userProfile?.role || "Farm Owner";

    const payloadWithAttribution = {
      ...(typeof data === "object" && data !== null ? data : { rawValue: data }),
      archivedBy: operatorEmail,
      archivedByName: operatorName,
      archivedByRole: operatorRole,
      archivedTimestamp: new Date().toISOString()
    };

    const newArchive: ArchiveRecord = {
      id: "ARC-" + Date.now().toString().slice(-6),
      archivedAt: new Date().toISOString(),
      module: moduleName,
      originalId,
      description,
      data: JSON.stringify(payloadWithAttribution),
      farmId: activeFarm?.id || "farm-1"
    };
    setArchivedRecords(prev => [newArchive, ...prev]);
  };

  // Ref to track signatures of recently logged items to prevent rapid duplicate logs
  const recentAuditLogsRef = useRef<Record<string, number>>({});

  const writeAuditLog = useCallback((
    action: AuditLog["action"],
    moduleName: string,
    record: string,
    detail: string
  ) => {
    const signature = `${action}::${moduleName}::${record}::${detail}`;
    const now = Date.now();
    const lastTime = recentAuditLogsRef.current[signature];
    
    // Deduplicate: If exactly the same log was written in the last 1000ms, ignore it
    if (lastTime && (now - lastTime < 1000)) {
      console.log(`[writeAuditLog] Ignored duplicate rapid audit log: ${signature}`);
      return;
    }
    
    // Update the last logged timestamp for this signature
    recentAuditLogsRef.current[signature] = now;

    // Periodically clean up old signatures to prevent memory growth
    if (Math.random() < 0.05) {
      const expirationThreshold = now - 5000;
      for (const sig in recentAuditLogsRef.current) {
        if (recentAuditLogsRef.current[sig] < expirationThreshold) {
          delete recentAuditLogsRef.current[sig];
        }
      }
    }

    const isImpersonating = !!impersonation;
    const adminEmail = impersonation ? impersonation.superAdminEmail : "";
    const adminUid = impersonation ? impersonation.superAdminUid : "";

    const newLog: AuditLog = {
      id: "AUD-" + now.toString().slice(-6),
      timestamp: new Date().toISOString(),
      user: isImpersonating 
        ? `Remote Support (${adminEmail})` 
        : (currentRole === "Platform Administrator" ? "Platform Admin" : userProfile?.name || "System User"),
      action,
      module: moduleName,
      record,
      detail: isImpersonating ? `[Access Node Remote Support Session] ${detail}` : detail,
      farmId: activeFarm?.id || "farm-1",
      tenantId: impersonation ? impersonation.targetUid : (userProfile?.uid || userProfile?.tenantId),
      actingAs: isImpersonating ? "super_admin_access_node" : undefined,
      superAdminUid: isImpersonating ? adminUid : undefined,
      superAdminEmail: isImpersonating ? adminEmail : undefined,
    };
    setAuditLogs(prev => [newLog, ...prev]);

    // Persist to tenant-scoped audit logs collection
    const currentTenantId = impersonation ? impersonation.targetUid : (userProfile?.uid || userProfile?.tenantId || activeFarm?.id || "TENANT-001");
    if (isConfigured && currentTenantId && db) {
      try {
        setDoc(doc(db, "tenants", currentTenantId, "audit_logs", newLog.id), newLog, { merge: true }).catch(() => {});
      } catch (e) {}
    }

    // Tag and persist to super_admin_audit collection for permanent remote support trail
    if (isImpersonating && impersonation) {
      try {
        const saAuditId = "sa-edit-" + Date.now() + "-" + Math.random().toString(36).substr(2, 4);
        setDoc(doc(db, "super_admin_audit", saAuditId), {
          id: saAuditId,
          superAdminId: adminUid,
          superAdminEmail: adminEmail,
          initiatedBy: impersonation.initiatedBy,
          actionType: "access_node_write",
          targetTenantId: impersonation.targetUid,
          actingAs: "super_admin_access_node",
          details: {
            action,
            module: moduleName,
            record,
            detail,
            farmNodeName: activeFarm?.name || "Active Farm",
            timestamp: new Date().toISOString()
          },
          timestamp: new Date().toISOString()
        });
      } catch (err) {
        console.error("Failed persisting Access Node audit write to super_admin_audit:", err);
      }
    }
  }, [currentRole, userProfile?.name, userProfile?.uid, userProfile?.tenantId, activeFarm?.id, activeFarm?.name, impersonation]);

  const handleAddAsset = (asset: Asset) => {
    if (isReadonly) return;
    setAssets(prev => [asset, ...prev]);
    writeAuditLog("CREATE", "Asset Register", asset.name, `Asset registered: ${asset.name} with value ${selectedCountry.symbol} ${asset.purchasePrice}`);

    // Standard double-entry: Debit Asset 1530 & Credit Bank 1010
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1010") {
        balance -= asset.purchasePrice;
      }
      if (acc.code === "1530") {
        balance += asset.purchasePrice;
      }
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(2);
  };

  const handleArchiveAsset = (assetId: string) => {
    if (isReadonly) return;
    const item = assets.find(a => a.id === assetId);
    if (!item) return;

    archiveDeletedRecord("Asset Register", item.id, `Asset: ${item.name}`, item);
    setAssets(prev => prev.filter(a => a.id !== assetId));
    writeAuditLog("DELETE", "Asset Register", item.name, `Archived and soft-deleted asset: ${item.name}`);
    deductCredits(1);
  };

  const handleUpdateAsset = (updatedAsset: Asset) => {
    if (isReadonly) return;
    setAssets(prev => prev.map(a => a.id === updatedAsset.id ? updatedAsset : a));
    writeAuditLog("UPDATE", "Asset Register", updatedAsset.name, `Asset updated: ${updatedAsset.name}`);
  };

  const handleUpdateAssets = (updatedAssets: Asset[]) => {
    if (isReadonly) return;
    setAssets(updatedAssets);
    writeAuditLog("UPDATE", "Asset Register", "Bulk Asset Update", `Updated ${updatedAssets.length} asset records`);
  };

  const handleAddInvestment = (inv: Investment) => {
    if (isReadonly) return;
    setInvestments(prev => [inv, ...prev]);
    writeAuditLog("CREATE", "Finance", inv.description, `Investment registered of value ${selectedCountry.symbol} ${inv.amount}`);

    // Update CoA (Double Entry): Debit 1600 & Credit 1010
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1010") {
        balance -= inv.amount;
      }
      if (acc.code === "1600") {
        balance += inv.amount;
      }
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(2);
  };

  const handleArchiveInvestment = (invId: string) => {
    if (isReadonly) return;
    const item = investments.find(i => i.id === invId);
    if (!item) return;

    archiveDeletedRecord("Finance", item.id, `Investment: ${item.description}`, item);
    setInvestments(prev => prev.filter(i => i.id !== invId));
    writeAuditLog("DELETE", "Finance", item.description, `Archived and soft-deleted investment: ${item.description}`);
    deductCredits(1);
  };

  const handleAddOtherRevenue = (rev: OtherRevenue) => {
    if (isReadonly) return;
    setOtherRevenues(prev => [rev, ...prev]);
    writeAuditLog("CREATE", "Finance", rev.description, `Registered other revenue: ${rev.revenueType} of value ${selectedCountry.symbol} ${rev.amount}`);

    // Update CoA (Double Entry): Debit 1010 & Credit 4400 or Equity 3010
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1010") {
        balance += rev.amount;
      }
      if (rev.revenueType === "Shareholder Contribution") {
        if (acc.code === "3010") balance += rev.amount;
      } else {
        if (acc.code === "4400") balance += rev.amount;
      }
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(2);
  };

  const handleArchiveOtherRevenue = (revId: string) => {
    if (isReadonly) return;
    const item = otherRevenues.find(r => r.id === revId);
    if (!item) return;

    archiveDeletedRecord("Finance", item.id, `Other Revenue: ${item.description}`, item);
    setOtherRevenues(prev => prev.filter(r => r.id !== revId));
    writeAuditLog("DELETE", "Finance", item.description, `Archived and soft-deleted revenue record: ${item.description}`);
    deductCredits(1);
  };

  const handleAddLeaveRecord = (leave: Omit<LeaveRecord, "id" | "farmId">) => {
    if (isReadonly) return;
    const newLeave: LeaveRecord = {
      ...leave,
      id: "LV-" + Date.now().toString().slice(-4),
      farmId: activeFarm?.id || "farm-1"
    };
    setLeaveRecords(prev => [newLeave, ...prev]);
    writeAuditLog("CREATE", "Payroll", leave.employeeName, `Leave booked: ${leave.leaveType} for ${leave.employeeName}`);
    deductCredits(1);
  };

  const handleArchiveLeaveRecord = (leaveId: string) => {
    if (isReadonly) return;
    const item = leaveRecords.find(l => l.id === leaveId);
    if (!item) return;

    archiveDeletedRecord("Payroll", item.id, `Leave: ${item.employeeName} (${item.leaveType})`, item);
    setLeaveRecords(prev => prev.filter(l => l.id !== leaveId));
    writeAuditLog("DELETE", "Payroll", item.employeeName, `Archived leave record for employee: ${item.employeeName}`);
    deductCredits(1);
  };

  const handleAddTask = (taskData: Omit<FarmTask, "id" | "farmId">) => {
    if (isReadonly) return;
    const newTask: FarmTask = {
      ...taskData,
      id: "TSK-" + Date.now().toString().slice(-6),
      farmId: activeFarm?.id || "farm-1"
    };
    setTasks(prev => [newTask, ...prev]);
    writeAuditLog("CREATE", "Workspace Tasks", taskData.title, `Created farm task under category ${taskData.category}`);
  };

  const handleEditTask = (updatedTask: FarmTask) => {
    if (isReadonly) return;
    setTasks(prev => prev.map(t => t.id === updatedTask.id ? updatedTask : t));
    writeAuditLog("EDIT", "Workspace Tasks", updatedTask.title, `Edited details of task under category ${updatedTask.category}`);
  };

  const handleDeleteTask = (id: string) => {
    if (isReadonly) return;
    const item = tasks.find(t => t.id === id);
    if (!item) return;
    setTasks(prev => prev.filter(t => t.id !== id));
    writeAuditLog("DELETE", "Workspace Tasks", item.title, `Deleted farm task directive permanently`);
  };

  const handleToggleTaskComplete = (id: string) => {
    if (isReadonly) return;
    const item = tasks.find(t => t.id === id);
    if (!item) return;
    
    const wasCompleted = item.isCompleted;
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        return {
          ...t,
          isCompleted: !wasCompleted,
          completedAt: !wasCompleted ? new Date().toISOString() : undefined
        };
      }
      return t;
    }));
    writeAuditLog("EDIT", "Workspace Tasks", item.title, !wasCompleted ? `Completed scheduled farm task directive` : `Reset scheduled farm task directive back to pending`);
  };

  const handleAddEmployeeAdvance = (adv: Omit<EmployeeAdvance, "id" | "farmId">) => {
    if (isReadonly) return;
    const newAdv: EmployeeAdvance = {
      ...adv,
      id: "ADV-" + Date.now().toString().slice(-4),
      farmId: activeFarm?.id || "farm-1"
    };
    setEmployeeAdvances(prev => [newAdv, ...prev]);
    writeAuditLog("CREATE", "Payroll", adv.employeeName, `Disbursed employee advance of ${selectedCountry.symbol} ${adv.advanceAmount}`);

    // Update CoA (Double Entry): Debit Loans Receivable 1200 & Credit Bank 1010
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1010") balance -= adv.advanceAmount;
      if (acc.code === "1200") balance += adv.advanceAmount;
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(2);
  };

  const handleRepayEmployeeAdvance = (id: string, amount: number) => {
    if (isReadonly) return;
    setEmployeeAdvances(prev => prev.map(adv => {
      if (adv.id === id) {
        const remaining = Math.max(adv.remainingBalance - amount, 0);
        return {
          ...adv,
          remainingBalance: remaining,
          status: remaining === 0 ? "Paid" : "Approved"
        };
      }
      return adv;
    }));

    const adv = employeeAdvances.find(a => a.id === id);
    if (adv) {
      writeAuditLog("EDIT", "Payroll", adv.employeeName, `Advance repaid: ${selectedCountry.symbol} ${amount} received manually`);
    }

    // Update CoA (Double Entry): Debit Bank 1010 & Credit Receivable 1200
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1010") balance += amount;
      if (acc.code === "1200") balance -= amount;
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(1);
  };

  const handleDeleteCrop = (id: string) => {
    if (isReadonly) return;
    const item = crops.find(c => c.id === id);
    if (!item) return;
    archiveDeletedRecord("Crops", item.id, `Crop Cycle: ${item.cropType} (${item.fieldBlock})`, item);
    setCrops(prev => {
      const next = prev.filter(c => c.id !== id);
      try {
        localStorage.setItem("mabala_crops", JSON.stringify(next));
        const email = userProfile?.email || auth.currentUser?.email || "anonymous_user";
        const tenant = userProfile?.tenantId || email;
        koboCollectSyncService.saveRecordOffline("crops", item, tenant, email, "DELETE");
      } catch (e) {}
      return next;
    });

    const targetUid = impersonation ? impersonation.targetUid : (userProfile?.tenantId || auth.currentUser?.uid);
    if (targetUid && isConfigured) {
      const cropRef = doc(db, "users_data", targetUid, "crops", id);
      executeTombstoneDelete(cropRef, {
        module: "crops",
        collectionName: `users_data/${targetUid}/crops`,
        documentId: id,
        summaryLabel: `Crop Cycle: ${item.cropType}`,
        tenantId: targetUid
      }).catch(err => console.warn("[handleDeleteCrop tombstone notice]:", err?.message));
    }

    writeAuditLog("DELETE", "Crops", item.cropType, `Archived and soft-deleted crop cycle: ${item.cropType}`);
    deductCredits(1);
  };

  const handleDeleteEmployee = (id: string) => {
    if (isReadonly) return;
    const item = employees.find(e => e.id === id);
    if (!item) return;
    archiveDeletedRecord("Employees", item.id, `Employee: ${item.name}`, item);
    setEmployees(prev => prev.filter(e => e.id !== id));
    writeAuditLog("DELETE", "Employees", item.name, `Archived and soft-deleted employee: ${item.name}`);
    deductCredits(1);
  };

  const handleDeleteLivestockRecord = (id: string, reason?: string, deletedBy?: string) => {
    if (isReadonly) return;
    const item = livestock.find(l => l.id === id);
    if (!item) return;
    const deletionTime = new Date().toISOString();
    const operator = deletedBy || userProfile?.name || "Farm Owner";
    const deletionReason = reason || "Administrative Derecognition";
    const creditNoteNum = `CN-LIV-${Date.now().toString().slice(-6)}`;
    const value = item.currentValue || 0;

    archiveDeletedRecord("Livestock", item.id, `Livestock Tag: ${item.tagId} (${item.species})`, {
      ...item,
      deletionReason,
      deletedBy: operator,
      deletedAt: deletionTime,
      creditNoteNumber: creditNoteNum
    });
    setLivestock(prev => prev.filter(l => l.id !== id));
    
    // Atomically derecognize from Asset Register and adjust General Ledger accounts
    const derecogRes = derecognizeBiologicalAsset({
      tagId: item.tagId,
      assetId: item.assetRegisterId,
      lossHeadcount: 1,
      totalHeadcountBefore: 1,
      lossValue: value,
      cause: deletionReason,
      date: deletionTime.split("T")[0],
      currentAssets: assets,
      currentAccounts: accounts,
      moduleType: "livestock"
    });
    setAssets(derecogRes.updatedAssets);
    setAccounts(derecogRes.updatedAccounts);

    const sym = userProfile?.currencySymbol || "K";
    writeAuditLog("DELETE", "Livestock", item.tagId, `Deregistered animal [${item.tagId}] (${item.species}, Val: ${sym}${value}) by ${operator} at ${deletionTime}. Reason: ${deletionReason}. Valuation Credit Note ${creditNoteNum} issued for -${sym}${value}.`);
    deductCredits(1);
  };

  const handleDeletePoultryBatch = (id: string) => {
    if (isReadonly) return;
    const item = poultry.find(p => p.id === id);
    if (!item) return;
    archiveDeletedRecord("Poultry", item.id, `Poultry Batch: ${item.batchName}`, item);
    setPoultry(prev => prev.filter(p => p.id !== id));
    
    // Atomically derecognize from Asset Register and post GL mortality/write-off
    const derecogRes = derecognizeBiologicalAsset({
      batchId: item.batchId,
      assetId: item.assetRegisterId,
      lossHeadcount: item.currentHeadcount || item.quantity || 1,
      totalHeadcountBefore: item.quantity || 1,
      lossValue: (item.currentHeadcount || item.quantity || 1) * (item.unitAcquisitionCost || 12),
      cause: "Poultry Batch Deregistration / Archive",
      date: new Date().toISOString().split("T")[0],
      currentAssets: assets,
      currentAccounts: accounts,
      moduleType: "poultry"
    });
    setAssets(derecogRes.updatedAssets);
    setAccounts(derecogRes.updatedAccounts);

    writeAuditLog("DELETE", "Poultry", item.batchName, `Archived and soft-deleted poultry batch: ${item.batchName}`);
    deductCredits(1);
  };

  const handleArchiveEmployeeAdvance = (advId: string) => {
    if (isReadonly) return;
    const item = employeeAdvances.find(a => a.id === advId);
    if (!item) return;

    archiveDeletedRecord("Payroll", item.id, `Employee Advance: ${item.employeeName} (${item.advanceAmount})`, item);
    setEmployeeAdvances(prev => prev.filter(a => a.id !== advId));
    writeAuditLog("DELETE", "Payroll", item.employeeName, `Archived and soft-deleted employee advance: ${item.employeeName}`);
    deductCredits(1);
  };

  const handleRestoreRecordFromArchive = (arc: ArchiveRecord) => {
    if (isReadonly) return;
    try {
      const parsedData = JSON.parse(arc.data);
      if (arc.module === "Finance") {
        if (arc.description.startsWith("Investment")) {
          setInvestments(prev => [parsedData, ...prev]);
        } else {
          setOtherRevenues(prev => [parsedData, ...prev]);
        }
      } else if (arc.module === "Asset Register") {
        setAssets(prev => [parsedData, ...prev]);
      } else if (arc.module === "Payroll") {
        if (arc.description.startsWith("Leave")) {
          setLeaveRecords(prev => [parsedData, ...prev]);
        } else {
          setEmployeeAdvances(prev => [parsedData, ...prev]);
        }
      } else if (arc.module === "Crops") {
        setCrops(prev => [parsedData, ...prev]);
      } else if (arc.module === "Employees") {
        setEmployees(prev => [parsedData, ...prev]);
      } else if (arc.module === "Livestock") {
        setLivestock(prev => [parsedData, ...prev]);
        const value = parsedData.currentValue || 0;
        const updatedAccounts = accounts.map(acc => {
          let balance = acc.balance;
          if (acc.code === "1420") {
            balance += value;
          }
          return { ...acc, balance };
        });
        setAccounts(updatedAccounts);
      } else if (arc.module === "Poultry") {
        setPoultry(prev => [parsedData, ...prev]);
      } else if (arc.module === "Farm Nodes" || arc.module === "Settings & Configurations") {
        if (parsedData && parsedData.id && parsedData.name) {
          const restoredFarm: Farm = {
            ...parsedData,
            isArchived: false
          };
          setFarms(prev => {
            const exists = prev.some(f => f.id === restoredFarm.id);
            const next = exists ? prev.map(f => f.id === restoredFarm.id ? restoredFarm : f) : [...prev, restoredFarm];
            try {
              localStorage.setItem("mabala_farms", JSON.stringify(next));
            } catch (e) {}
            return next;
          });
        }
        // Financial reversal logic applies credits when soft-deleted data is restored
        const reversalCredit = Number(parsedData.reversalCreditAmount || parsedData.creditAmount) || 150;
        const cnRef = parsedData.creditNoteNumber || `CN-RESTORE-${Date.now().toString().slice(-6)}`;

        // Reverse general ledger balances (Credit 1010 Bank / 1100 Receivables)
        const updatedAccounts = accounts.map(acc => {
          let balance = acc.balance;
          if (acc.code === "1010" || acc.code === "1100") {
            balance += reversalCredit;
          }
          return { ...acc, balance };
        });
        setAccounts(updatedAccounts);

        // Refund platform credits upon restoration
        setCredits(prev => Math.min(1000, (prev || 0) + 10));

        const superAdminActor = auth.currentUser?.email || userProfile?.email || "superadmin@mabala.cloud";
        writeAuditLog(
          "RESTORE",
          arc.module,
          arc.description,
          `Super Admin (${superAdminActor}) restored archived farm node / configuration: "${arc.description}". Financial credit reversal applied: +${activeFarm?.currencySymbol || "ZK"}${reversalCredit} (Ref: ${cnRef}). Operator attribution verified.`
        );
        showToast(`Farm node restored successfully by Super Admin. Financial credits (+${activeFarm?.currencySymbol || "ZK"}${reversalCredit}) applied.`, "success");
      }
      setArchivedRecords(prev => prev.filter(r => r.id !== arc.id));
      if (arc.module !== "Farm Nodes" && arc.module !== "Settings & Configurations") {
        writeAuditLog("RESTORE", arc.module, arc.description, `Restored archived record`);
      }
      deductCredits(2);
    } catch (e) {
      showToast("Failed to parse archive payload for restoration.", "error");
    }
  };

  const handlePermanentDeleteFromArchive = (archiveId: string) => {
    const item = archivedRecords.find(a => a.id === archiveId);
    if (!item) return;

    setArchivedRecords(prev => prev.filter(a => a.id !== archiveId));
    writeAuditLog("DELETE", "Compliance", item.description, `Permanently purged from archive: ${item.description}`);
    deductCredits(1);
  };

  const handleAddLivestockRecord = (record: LivestockRecord) => {
    if (isReadonly) return;
    
    // Atomically sync with Asset Register and post General Ledger entries via biologicalAssetIntegrationService
    const syncRes = syncRegisterBiologicalLivestock(record, assets, accounts);
    setAssets(syncRes.updatedAssets);
    setAccounts(syncRes.updatedAccounts);

    setLivestock(prev => {
      const exists = prev.some(r => r.id === record.id);
      if (exists) {
        writeAuditLog("UPDATE", "Livestock", record.tagId, `Updated animal tag: ${record.species} [${record.tagId}] (Valuation: ${record.currentValue}, GL: ${syncRes.newAsset.glAccountCode})`);
        return prev.map(r => r.id === record.id ? record : r);
      } else {
        writeAuditLog("CREATE", "Livestock", record.tagId, `Registered animal tag: ${record.species} [${record.tagId}] (Acquisition: ${record.acquisitionType}, GL: ${syncRes.newAsset.glAccountCode})`);
        deductCredits(1);
        return [record, ...prev];
      }
    });
  };

  const handleAddLivestockHealthEvent = (tagId: string, event: { date: string; type: string; details: string; cost: number }) => {
    if (isReadonly) return;
    setLivestock(prev => prev.map(rec => {
      if (rec.tagId === tagId) {
        return {
          ...rec,
          healthEvents: [...rec.healthEvents, event]
        };
      }
      return rec;
    }));
    writeAuditLog("CREATE", "Livestock", tagId, `Logged health treatment for ${tagId}: ${event.type}`);

    // If it's a professional veterinary charge, let's impact accounts relative to Expense category (COGS / Vet costs 5300)
    if (event.cost > 0) {
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        if (acc.code === "1010") balance -= event.cost; // bank credit
        if (acc.code === "5300") balance += event.cost; // vet expense debit
        return { ...acc, balance };
      });
      setAccounts(updatedAccounts);
    }
    deductCredits(1);
  };

  const handleAddLivestockFeedingLog = (tagId: string, log: { date: string; feedType: string; quantityKg: number }) => {
    if (isReadonly) return;
    setLivestock(prev => prev.map(rec => {
      if (rec.tagId === tagId) {
        return {
          ...rec,
          feedingLogs: [...(rec.feedingLogs || []), log]
        };
      }
      return rec;
    }));
    writeAuditLog("CREATE", "Livestock", tagId, `Logged biological feed session for ${tagId}`);
    deductCredits(1);
  };

  const handleAddLoan = (loan: Loan) => {
    if (isReadonly) return;
    setLoans(prev => [loan, ...prev]);
    writeAuditLog("CREATE", "Finance", loan.recipient, `Loan registered for ${loan.recipient}: Principal ${selectedCountry.symbol} ${loan.principal}`);

    // Standard double-entry: Issued Loan vs Received Loan CoA balancing
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (loan.type === "Issued") {
        if (acc.code === "1010") balance -= loan.principal;
        if (acc.code === "1200") balance += loan.principal;
      } else {
        if (acc.code === "1010") balance += loan.principal;
        if (acc.code === "2200") balance += loan.principal;
      }
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(2);
  };

  const handleRealizeInvestment = (id: string) => {
    if (isReadonly) return;
    let amt = 0;
    setInvestments(prev => prev.map(inv => {
      if (inv.id === id) {
        amt = inv.amount;
        writeAuditLog("EDIT", "Finance", inv.description, `Investment matured and principal was liquidated back to bank: ${selectedCountry.symbol} ${inv.amount}`);
        return { ...inv, status: "Matured" };
      }
      return inv;
    }));

    if (amt > 0) {
      const updatedAccounts = accounts.map(acc => {
        let balance = acc.balance;
        if (acc.code === "1010") balance += amt; // Cash/Bank debit
        if (acc.code === "1210") balance -= amt; // Short-term investments credit
        return { ...acc, balance };
      });
      setAccounts(updatedAccounts);
    }
    deductCredits(2);
  };

  const handleAddLoanRepayment = (loanId: string, amount: number, paymentMethod: string, notes?: string) => {
    if (isReadonly) return;
    setLoans(prev => prev.map(loan => {
      if (loan.id === loanId) {
        const outstanding = Math.max(loan.outstandingBalance - amount, 0);
        writeAuditLog("EDIT", "Finance", loan.recipient, `Loan repayment of ${selectedCountry.symbol} ${amount} received/paid via ${paymentMethod}`);
        return {
          ...loan,
          outstandingBalance: outstanding
        };
      }
      return loan;
    }));

    // Standard double-entry bookkeeping
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1010") balance += amount;
      if (acc.code === "1200") balance -= amount;
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(2);
  };

  const handleOffsetLoan = (loanId: string, otherRevenueId: string, amount: number, offsetType: string) => {
    if (isReadonly) return;
    setLoans(prev => prev.map(loan => {
      if (loan.id === loanId) {
        const outstanding = Math.max(loan.outstandingBalance - amount, 0);
        writeAuditLog("EDIT", "Finance", loan.recipient, `Loan offset by ${offsetType}: outstanding balance reduced by ${selectedCountry.symbol} ${amount}`);
        return {
          ...loan,
          outstandingBalance: outstanding
        };
      }
      return loan;
    }));
    deductCredits(2);
  };

  // Geographic Country dropdown selection modifier
  const handleCountryOverrideChange = (code: string) => {
    const matched = COUNTRIES.find(c => c.code === code);
    if (!matched) return;
    setSelectedCountry(matched);
    
    // Dynamically override active farm currency Symbol and name
    const updated = [...farms];
    updated[activeFarmIndex] = {
      ...activeFarm,
      currency: matched.currency,
      currencySymbol: matched.symbol,
      taxSystem: matched.defaultTaxSystem
    };
    setFarms(updated);
    deductCredits(1); // Standard configuration write action
  };

  // ERP actions
  const handleAddAccount = (acc: Account) => {
    if (isReadonly) return;
    setAccounts(prev => [acc, ...prev]);
    deductCredits(2); // standard bookkeeping code setup
  };

  const handleAddSupplier = (sup: Supplier) => {
    if (isReadonly) return;
    setSuppliers(prev => [sup, ...prev]);
    deductCredits(1); // LIGHT write operation
  };

  const handleAddCustomer = (cus: Customer) => {
    if (isReadonly) return;
    setCustomers(prev => [cus, ...prev]);
    deductCredits(1); // LIGHT write operation
  };

  const handleAddLedgerEntryFromOfftaker = (
    date: string,
    desc: string,
    debit: string,
    credit: string,
    amount: number,
    module: string
  ) => {
    if (isReadonly) return;
    const tx: ExpenseTransaction = {
      id: "tx-offtaker-" + Date.now(),
      supplierId: "supp-offtaker-system",
      supplierName: "Offtaker Settlement",
      date,
      taxSystem: "VAT Exempt",
      taxAmount: 0,
      subtotal: amount,
      total: amount,
      farmId: activeFarm?.id || "farm-1",
      rows: [
        {
          category: desc,
          description: `Disbursement under settlement system — debit coa ${debit}, credit coa ${credit}`,
          quantity: 1,
          unitPrice: amount,
          amount,
          coaCode: debit || "5010"
        }
      ]
    };
    handleAddExpense(tx);
  };

  const handleAddExpense = (tx: ExpenseTransaction) => {
    if (isReadonly) return;
    setExpenses(prev => {
      const next = [tx, ...prev];
      try {
        localStorage.setItem("mabala_expenses", JSON.stringify(next));
        const email = userProfile?.email || auth.currentUser?.email || "anonymous_user";
        const tenant = userProfile?.tenantId || email;
        koboCollectSyncService.saveRecordOffline("expenses", tx, tenant, email, "CREATE");
      } catch (e) {}
      return next;
    });

    const targetUid = impersonation ? impersonation.targetUid : (userProfile?.tenantId || auth.currentUser?.uid);
    if (targetUid && isConfigured) {
      const expenseRef = doc(db, "users_data", targetUid, "expenses", tx.id);
      executeSessionAwareWrite(expenseRef, tx, {
        module: "expenses",
        collectionName: `users_data/${targetUid}/expenses`,
        documentId: tx.id,
        action: "create",
        summaryLabel: `Expense ${tx.id}: ZK ${tx.total} (${tx.supplierName})`,
        isFinancial: true,
        amount: tx.total,
        currencySymbol: "ZK",
        tenantId: targetUid
      }).catch(err => console.warn("[handleAddExpense sessionWriteGuard notice]:", err?.message));
    }
    
    // Automatically credit bank account (1010) and debit correspond code balances in Chart of Accounts!
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      // Credit 1010
      if (acc.code === "1010") {
        balance -= tx.total;
      }
      // Debit correspond code
      tx.rows.forEach(r => {
        if (acc.code === r.coaCode) {
          balance += r.amount;
        }
      });
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(3); // HEAVY financial journal action
  };

  const handleAddCrop = (newCrop: CropCycle) => {
    if (isReadonly) return;
    setCrops(prev => {
      const next = [newCrop, ...prev];
      try {
        localStorage.setItem("mabala_crops", JSON.stringify(next));
        const email = userProfile?.email || auth.currentUser?.email || "anonymous_user";
        const tenant = userProfile?.tenantId || email;
        koboCollectSyncService.saveRecordOffline("crops", newCrop, tenant, email, "CREATE");
      } catch (e) {
        console.warn("[Mabala Crops] Error in KoboCollect offline persistence:", e);
      }
      return next;
    });

    const targetUid = impersonation ? impersonation.targetUid : (userProfile?.tenantId || auth.currentUser?.uid);
    if (targetUid && isConfigured) {
      const cropRef = doc(db, "users_data", targetUid, "crops", newCrop.id);
      executeSessionAwareWrite(cropRef, newCrop, {
        module: "crops",
        collectionName: `users_data/${targetUid}/crops`,
        documentId: newCrop.id,
        action: "create",
        summaryLabel: `Crop Cycle: ${newCrop.cropType} (${newCrop.fieldBlock})`,
        isFinancial: false,
        tenantId: targetUid
      }).catch(err => console.warn("[handleAddCrop sessionWriteGuard notice]:", err?.message));
    }

    writeAuditLog("CREATE", "Crops", newCrop.cropType, `Initialized crop production plan for ${newCrop.cropType} on block ${newCrop.fieldBlock}`);
    deductCredits(2); // STANDARD agronomic crop setup
  };

  const handleEditCrop = (updatedCrop: CropCycle, auditDetails?: string) => {
    if (isReadonly) return;
    setCrops(prev => {
      const next = prev.map(c => c.id === updatedCrop.id ? updatedCrop : c);
      try {
        localStorage.setItem("mabala_crops", JSON.stringify(next));
        const email = userProfile?.email || auth.currentUser?.email || "anonymous_user";
        const tenant = userProfile?.tenantId || email;
        koboCollectSyncService.saveRecordOffline("crops", updatedCrop, tenant, email, "UPDATE");
      } catch (e) {
        console.warn("[Mabala Crops] Error in KoboCollect offline persistence:", e);
      }
      return next;
    });

    const targetUid = impersonation ? impersonation.targetUid : (userProfile?.tenantId || auth.currentUser?.uid);
    if (targetUid && isConfigured) {
      const cropRef = doc(db, "users_data", targetUid, "crops", updatedCrop.id);
      executeSessionAwareWrite(cropRef, updatedCrop, {
        module: "crops",
        collectionName: `users_data/${targetUid}/crops`,
        documentId: updatedCrop.id,
        action: "update",
        summaryLabel: `Edited Crop: ${updatedCrop.cropType} (${updatedCrop.fieldBlock})`,
        isFinancial: false,
        tenantId: targetUid
      }).catch(err => console.warn("[handleEditCrop sessionWriteGuard notice]:", err?.message));
    }

    if (auditDetails) {
      writeAuditLog("EDIT", "Crops", updatedCrop.cropType, auditDetails);
    } else {
      writeAuditLog("EDIT", "Crops", updatedCrop.cropType, `Edited crop cycle: ${updatedCrop.cropType} on block ${updatedCrop.fieldBlock}`);
    }
    deductCredits(1);
  };

  const handleUpdateMilestone = (cropId: string, milestoneId: string, isCompleted: boolean) => {
    if (isReadonly) return;
    setCrops(prev => {
      const next = prev.map(c => {
        if (c.id === cropId) {
          const updated = {
            ...c,
            milestones: c.milestones.map(m => m.id === milestoneId ? { ...m, isCompleted } : m)
          };
          try {
            const email = userProfile?.email || auth.currentUser?.email || "anonymous_user";
            const tenant = userProfile?.tenantId || email;
            koboCollectSyncService.saveRecordOffline("crops", updated, tenant, email, "UPDATE");
          } catch (e) {}
          return updated;
        }
        return c;
      });
      try {
        localStorage.setItem("mabala_crops", JSON.stringify(next));
      } catch (e) {}
      return next;
    });
    deductCredits(1);
  };

  const handleUpdateCropStatus = (cropId: string, status: CropCycle["status"]) => {
    if (isReadonly) return;
    setCrops(prev => {
      const next = prev.map(c => {
        if (c.id === cropId) {
          const updated = { ...c, status };
          try {
            const email = userProfile?.email || auth.currentUser?.email || "anonymous_user";
            const tenant = userProfile?.tenantId || email;
            koboCollectSyncService.saveRecordOffline("crops", updated, tenant, email, "UPDATE");
          } catch (e) {}
          return updated;
        }
        return c;
      });
      try {
        localStorage.setItem("mabala_crops", JSON.stringify(next));
      } catch (e) {}
      return next;
    });
    deductCredits(1);
  };

  const handleAddEmployee = (emp: Employee) => {
    if (isReadonly) return;
    setEmployees(prev => [emp, ...prev]);
    deductCredits(2);
  };

  const handleBulkAddEmployees = async (newEmployees: Employee[]) => {
    if (isReadonly || !newEmployees || newEmployees.length === 0) return;

    // Perform atomic batch write to Firestore if configured
    const currentUser = auth.currentUser;
    const tenantId = impersonation ? impersonation.targetUid : (userProfile?.tenantId || (currentUser ? currentUser.uid : ""));
    if (isConfigured && tenantId && db) {
      try {
        const batch = writeBatch(db);
        const userDocRef = doc(db, "users_data", tenantId);
        const updatedList = [...newEmployees, ...employees];

        batch.set(userDocRef, { employees: updatedList, updatedAt: new Date().toISOString() }, { merge: true });

        const moduleRef = doc(db, "users_data", tenantId, "modules", "employees");
        batch.set(moduleRef, { data: updatedList, updatedAt: new Date().toISOString() }, { merge: true });

        await batch.commit();
        console.log(`[Mabala Cloud] Atomic batched write committed ${newEmployees.length} employee records to Firestore for tenant ${tenantId}`);
      } catch (err) {
        console.error("[Mabala Cloud] Error in atomic batched write for employees:", err);
      }
    }

    setEmployees(prev => [...newEmployees, ...prev]);
    writeAuditLog("CREATE", "Payroll", `${newEmployees.length} Employees`, `Bulk registered ${newEmployees.length} employee profiles & payroll profiles via CSV import.`);
    deductCredits(Math.min(newEmployees.length * 2, 20));
  };

  const handleUpdateEmployee = (updatedEmp: Employee) => {
    if (isReadonly) return;
    setEmployees(prev => prev.map(e => e.id === updatedEmp.id ? updatedEmp : e));
    deductCredits(1);
  };

  const handleRunPayroll = (slips: Payslip[]) => {
    if (isReadonly) return;
    setPayslips(prev => [...slips, ...prev]);
    
    // Auto-update wages liabilities
    const totalWageSum = slips.reduce((s, x) => s + x.basicSalary, 0);
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1010") {
        balance -= slips.reduce((s, x) => s + x.netPay, 0); // debit cash outflow
      }
      if (acc.code === "5100") {
        balance += totalWageSum; // staff expense accrual
      }
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(5); // PREMIUM operation run
  };

  const handleAddInvoice = (inv: Invoice) => {
    if (isReadonly) return;
    setInvoices(prev => {
      const next = [inv, ...prev];
      try {
        localStorage.setItem("mabala_invoices", JSON.stringify(next));
        const email = userProfile?.email || auth.currentUser?.email || "anonymous_user";
        const tenant = userProfile?.tenantId || email;
        koboCollectSyncService.saveRecordOffline("invoices", inv, tenant, email, "CREATE");
      } catch (e) {}
      return next;
    });

    const targetUid = impersonation ? impersonation.targetUid : (userProfile?.tenantId || auth.currentUser?.uid);
    if (targetUid && isConfigured) {
      const invoiceRef = doc(db, "users_data", targetUid, "invoices", inv.id);
      executeSessionAwareWrite(invoiceRef, inv, {
        module: "invoices",
        collectionName: `users_data/${targetUid}/invoices`,
        documentId: inv.id,
        action: "create",
        summaryLabel: `Invoice ${inv.invoiceNumber}: ZK ${inv.total} (${inv.customerName})`,
        isFinancial: true,
        amount: inv.total,
        currencySymbol: "ZK",
        tenantId: targetUid
      }).catch(err => console.warn("[handleAddInvoice sessionWriteGuard notice]:", err?.message));
    }
    
    // General ledger balance update: Debit Accounts Recv (1100), Credit designated Revenue account balance
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1100") {
        balance += inv.total;
      }
      if (acc.code === inv.coaCredit && (acc.category === "Revenue" || acc.code === "4500")) {
        balance += inv.subtotal;
      }
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(3);
  };

  const handleAddCreditNote = (cn: CreditNote) => {
    if (isReadonly) return;
    setCreditNotes(prev => [cn, ...prev]);
    
    // Update original invoice status
    setInvoices(prev => prev.map(inv => {
      if (inv.id === cn.invoiceId) {
        return { ...inv, status: `Cancelled by Credit Note #${cn.creditNoteNumber}` };
      }
      return inv;
    }));
    
    // Reverse general ledger balances (Credit 1100, Debit Revenue)
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1100") {
        balance -= cn.total;
      }
      if (acc.code === cn.coaDebit && (acc.category === "Revenue" || acc.code === "4500")) {
        balance -= cn.subtotal;
      }
      if (acc.code === "2070") {
        balance -= cn.taxAmount;
      }
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(2);
  };

  const handlePostVeterinaryServiceCharge = (
    eventType: "Consultation Record" | "Laboratory Test",
    amount: number,
    clientName: string,
    details: string
  ) => {
    // 1. Update Accounts: Debit Accounts Receivable (1100) and Credit Vet Clinical Service Revenue (4500)
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1100") {
        balance += amount; // Asset increased by debit
      }
      if (acc.code === "4505" || acc.code === "4500") {
        balance += amount; // Revenue increased by credit
      }
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);

    // 2. Insert verified paid Invoice ledger posting record
    const newInvoice: Invoice = {
      id: "inv-vet-" + Math.floor(10000 + Math.random() * 90000),
      invoiceNumber: "VET-INV-" + Math.floor(1000 + Math.random() * 9000),
      date: new Date().toISOString().split("T")[0],
      dueDate: new Date().toISOString().split("T")[0],
      customerName: clientName,
      taxAmount: 0,
      subtotal: amount,
      total: amount,
      lines: [
        {
          description: `${eventType} - ${details}`,
          quantity: 1,
          unitPrice: amount,
          amount: amount
        }
      ],
      status: "Paid",
      coaDebit: "1100",
      coaCredit: "4500",
      farmId: activeFarm?.id || "farm-1"
    };

    setInvoices(prev => [newInvoice, ...prev]);

    // 3. Write Audit Log
    writeAuditLog("CREATE", "Veterinary Suite", "Double-Entry Posting", `Automatically posted Service Charge of ${selectedCountry.symbol}${amount} for client ${clientName} (${eventType})`);
  };

  const handleAddQuotation = (qt: Quotation) => {
    if (isReadonly) return;
    setQuotations(prev => [qt, ...prev]);
    deductCredits(1); // quotation is LIGHT
  };

  const handleMarkPaid = (invId: string, paymentAmount?: number) => {
    const targetInvoice = invoices.find(inv => inv.id === invId);
    if (!targetInvoice) return;

    // Extract current paid amount 
    const currentPaid = targetInvoice.paidAmount !== undefined 
      ? targetInvoice.paidAmount 
      : (targetInvoice.status === "Paid" ? targetInvoice.total : 0);
    
    const remainingBalance = targetInvoice.total - currentPaid;
    
    // Determine the exact payment amount to apply
    let amountToApply = paymentAmount !== undefined ? paymentAmount : remainingBalance;
    if (amountToApply <= 0) return;
    if (amountToApply > remainingBalance) {
      amountToApply = remainingBalance;
    }

    const newPaidAmount = currentPaid + amountToApply;
    const isNowFullyPaid = newPaidAmount >= targetInvoice.total;
    const newStatus = isNowFullyPaid ? "Paid" : "Unpaid";

    const todayStr = new Date().toISOString().split('T')[0];
    const currentFarmObj = farms.find(f => f.id === targetInvoice.farmId) || activeFarm;

    // 1. Update Invoices array
    const updatedInvoice: Invoice = {
      ...targetInvoice,
      paidAmount: newPaidAmount,
      status: newStatus,
      paymentDate: todayStr,
      paidAt: new Date().toISOString(),
      farmName: targetInvoice.farmName || currentFarmObj?.name || "Farm Enterprise Node"
    };

    setInvoices(prev => {
      const next = prev.map(inv => inv.id === invId ? updatedInvoice : inv);
      try {
        localStorage.setItem("mabala_invoices", JSON.stringify(next));
      } catch (e) {}
      return next;
    });

    const targetUid = impersonation ? impersonation.targetUid : (userProfile?.tenantId || auth.currentUser?.uid);
    if (targetUid && isConfigured) {
      const invoiceRef = doc(db, "users_data", targetUid, "invoices", invId);
      executeSessionAwareWrite(invoiceRef, updatedInvoice, {
        module: "invoices",
        collectionName: `users_data/${targetUid}/invoices`,
        documentId: invId,
        action: "update",
        summaryLabel: `Payment recorded on Invoice ${targetInvoice.invoiceNumber}: ZK ${amountToApply}`,
        isFinancial: true,
        amount: amountToApply,
        currencySymbol: "ZK",
        tenantId: targetUid
      }).catch(err => console.warn("[handleMarkPaid sessionWriteGuard notice]:", err?.message));
    }

    // 2. Post Double Entry (Chart of Accounts Balance): Debit 1010 Bank / Credit 1100 Receivables
    setAccounts(prevAccs => prevAccs.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1010") {
        balance += amountToApply;
      }
      if (acc.code === "1100") {
        balance -= amountToApply;
      }
      return { ...acc, balance };
    }));

    // 3. Update the Sales Tracker (CashSales ledger desk) automatically
    const newCashSale: CashSale = {
      id: `CS-INV-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      date: new Date().toISOString().split('T')[0],
      description: `Invoice Payment: ${targetInvoice.invoiceNumber} (${targetInvoice.customerName})`,
      customer: targetInvoice.customerName,
      amount: amountToApply,
      paymentMethod: "Bank Transfer",
      coaDebit: "1010",
      coaCredit: "1100",
      farmId: targetInvoice.farmId || "farm-1"
    };
    setCashSales(prevSales => [newCashSale, ...prevSales]);

    // 4. Update Crop Cycle (actualYieldKg & revenueLinked) if linked to a cropId
    const linkedCropId = (targetInvoice as any).cropId;
    if (linkedCropId) {
      const totalInvoiceLinesQuantity = targetInvoice.lines.reduce((sum, line) => sum + (Number(line.quantity) || 0), 0) || 1;
      const incrementalYield = totalInvoiceLinesQuantity * (amountToApply / targetInvoice.total);
      
      setCrops(prevCrops => prevCrops.map(c => {
        if (c.id === linkedCropId) {
          return {
            ...c,
            // Yield update achieved so far & revenues linked
            actualYieldKg: Number(((c.actualYieldKg || 0) + incrementalYield).toFixed(2)),
            revenueLinked: Number(((c.revenueLinked || 0) + amountToApply).toFixed(2))
          };
        }
        return c;
      }));
    }

    deductCredits(2);
  };

  const handleConvertQuote = (quote: Quotation) => {
    if (isReadonly) return;
    
    // Auto-create invoice identical parameters
    const inv: Invoice = {
      id: "INV-GEN-" + Date.now(),
      invoiceNumber: `INV-2026-00${invoices.length + 1}`,
      date: new Date().toISOString().split('T')[0],
      dueDate: "2026-06-30",
      customerName: quote.customerName,
      taxAmount: quote.taxAmount,
      subtotal: quote.subtotal,
      total: quote.total,
      lines: quote.lines,
      status: "Unpaid",
      coaDebit: "1100",
      coaCredit: "4100",
      farmId: quote.farmId
    };

    // Remove quote or mark accepted
    setQuotations(prev => prev.map(q => q.id === quote.id ? { ...q, status: "Accepted" } : q));
    handleAddInvoice(inv);
  };

  const handleAddPoultry = (batch: PoultryBatch) => {
    if (isReadonly) return;
    setPoultry(prev => [batch, ...prev]);
    
    // Atomically synchronize into Asset Register and post GL acquisition entries
    if (batch.status !== "PLANNED") {
      const syncRes = syncRegisterBiologicalPoultry(batch, assets, accounts);
      setAssets(syncRes.updatedAssets);
      setAccounts(syncRes.updatedAccounts);
    }
    deductCredits(2);
  };

  const handleUpdatePoultryBatch = (updatedBatch: PoultryBatch) => {
    if (isReadonly) return;
    
    setPoultry(prev => {
      const oldBatch = prev.find(b => b.id === updatedBatch.id);
      if (oldBatch) {
        // 1. Double-entry for newly posted sales logs
        const oldSalesLen = oldBatch.salesLogs ? oldBatch.salesLogs.length : 0;
        const newSalesLen = updatedBatch.salesLogs ? updatedBatch.salesLogs.length : 0;
        if (newSalesLen > oldSalesLen) {
          const addedSale = updatedBatch.salesLogs[newSalesLen - 1];
          const saleAmount = addedSale.amount;
          // Dr Bank (1010), Cr Poultry Revenue (4200)
          setAccounts(prevAccs => prevAccs.map(acc => {
            let balance = acc.balance;
            if (acc.code === "1010") balance += saleAmount;
            if (acc.code === "4200") balance += saleAmount;
            return { ...acc, balance };
          }));
        }

        // 1b. Double-entry for newly posted egg sales logs
        const oldEggSalesLen = oldBatch.eggSales ? oldBatch.eggSales.length : 0;
        const newEggSalesLen = updatedBatch.eggSales ? updatedBatch.eggSales.length : 0;
        if (newEggSalesLen > oldEggSalesLen) {
          const addedEggSale = updatedBatch.eggSales![newEggSalesLen - 1];
          const saleAmount = addedEggSale.totalRevenue;
          // Dr Bank (1010), Cr Poultry Revenue (4200)
          setAccounts(prevAccs => prevAccs.map(acc => {
            let balance = acc.balance;
            if (acc.code === "1010") balance += saleAmount;
            if (acc.code === "4200") balance += saleAmount;
            return { ...acc, balance };
          }));
        }

        // 2. Double-entry for newly posted medications
        const oldMedsLen = oldBatch.medications ? oldBatch.medications.length : 0;
        const newMedsLen = updatedBatch.medications ? updatedBatch.medications.length : 0;
        if (newMedsLen > oldMedsLen) {
          const addedMed = updatedBatch.medications[newMedsLen - 1];
          const medCost = addedMed.cost;
          if (medCost > 0) {
            // Cr Bank (1010), Dr Vet/Meds (5300)
            setAccounts(prevAccs => prevAccs.map(acc => {
              let balance = acc.balance;
              if (acc.code === "1010") balance -= medCost;
              if (acc.code === "5300") balance += medCost;
              return { ...acc, balance };
            }));
          }
        }

        // 3. Transition from PLANNED to any ACTIVE status -> post biological asset acquisition cost
        if (oldBatch.status === "PLANNED" && updatedBatch.status !== "PLANNED") {
          const unitCost = updatedBatch.unitAcquisitionCost ?? 12;
          const transCost = updatedBatch.transportCost ?? 0;
          const setupCost = updatedBatch.brooderSetupCost ?? 0;
          const acquisitionCost = (updatedBatch.quantity * unitCost) + transCost + setupCost;
          if (acquisitionCost > 0) {
            // Cr Bank (1010), Dr Biological assets - Poultry (1430)
            setAccounts(prevAccs => prevAccs.map(acc => {
              let balance = acc.balance;
              if (acc.code === "1010") balance -= acquisitionCost;
              if (acc.code === "1430") balance += acquisitionCost;
              return { ...acc, balance };
            }));
          }
        }
      }
      return prev.map(b => b.id === updatedBatch.id ? updatedBatch : b);
    });
  };

  const handleAddFeedLog = (
    batchId: string, 
    quantityKg: number, 
    cost: number, 
    fedByStr: string,
    dateStr?: string,
    feedTypeStr?: string,
    formulaUsedStr?: string,
    stageIdStr?: string
  ) => {
    if (isReadonly) return;
    setPoultry(prev => prev.map(b => {
      if (b.id === batchId) {
        const feedLogs = [
          ...b.feedLogs, 
          { 
            date: dateStr || new Date().toISOString().split('T')[0], 
            feedType: feedTypeStr || "Growth Feed pellets", 
            quantityKg, 
            cost, 
            fedBy: fedByStr,
            formulaUsed: formulaUsedStr,
            stageId: stageIdStr || b.currentStageId || "grower"
          }
        ];
        return { ...b, feedLogs };
      }
      return b;
    }));
    
    // Post feed cost expense to Dr 5210, Cr 1010 bank
    const updatedAccounts = accounts.map(acc => {
      let balance = acc.balance;
      if (acc.code === "1010") balance -= cost;
      if (acc.code === "5210") balance += cost;
      return { ...acc, balance };
    });
    setAccounts(updatedAccounts);
    deductCredits(1);
  };

  const handleRecordPoultryEgg = (batchId: string, total: number, gradeA: number, gradeB: number) => {
    if (isReadonly) return;
    setPoultry(prev => prev.map(b => {
      if (b.id === batchId) {
        const eggCollections = [...b.eggCollections, { date: new Date().toISOString().split('T')[0], totalCollected: total, gradeA, gradeB, broken: total-gradeA-gradeB, dirty: 0 }];
        return { ...b, eggCollections };
      }
      return b;
    }));
    deductCredits(1);
  };

  const handleAddFishBatch = (batch: FishBatch) => {
    if (isReadonly) return;
    setFish(prev => [batch, ...prev]);

    // Atomically synchronize into Asset Register and post GL acquisition entries
    const syncRes = syncRegisterBiologicalFish(batch, assets, accounts);
    setAssets(syncRes.updatedAssets);
    setAccounts(syncRes.updatedAccounts);

    deductCredits(2);
  };

  const handleAddWaterReading = (batchId: string, reading: WaterQualityReading) => {
    if (isReadonly) return;
    setFish(prev => prev.map(f => {
      if (f.id === batchId) {
        return { ...f, waterReadings: [...f.waterReadings, reading] };
      }
      return f;
    }));
    deductCredits(1);
  };

  // Top Up Action
  const handleTopUpConfirm = (amt: number) => {
    const tenantId = impersonation ? impersonation.targetUid : (userProfile?.tenantId || (auth.currentUser ? auth.currentUser.uid : ""));
    const idempotencyKey = `topup:${tenantId || 'local'}_${Date.now()}`;
    if (isConfigured && tenantId) {
      grantCreditsIdempotent(db, tenantId, amt, "topup", idempotencyKey, `Lipila manual top-up of +${amt} credits`).then(res => {
        setCredits(res.newBalance);
      }).catch(err => {
        console.error("TopUp grant error:", err);
        setCredits(prev => prev + amt);
      });
    } else {
      setCredits(prev => prev + amt);
    }
    setShowTopUpModal(false);
    showToast(`Thank you for your payment! Credited ${amt} write operations successfully to your Mabala tenant.`, "success");
  };

  // Create additional farm within tenant
  const handleCreateFarm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFarmName) return;

    const nf: Farm = {
      id: "farm-" + (farms.length + 1),
      name: newFarmName,
      tpin: activeFarm.tpin,
      address: newFarmAddr || "Lake Basin, Zambia",
      phone: newFarmPhone || "+260123123",
      email: activeFarm.email,
      financialYearStart: "2026-01-01",
      financialYearEnd: "2026-12-31",
      currency: selectedCountry.currency,
      currencySymbol: selectedCountry.symbol,
      taxSystem: selectedCountry.defaultTaxSystem
    };

    setFarms(prev => [...prev, nf]);
    setShowFarmConfigModal(false);
    setNewFarmName("");
    setNewFarmAddr("");
    setNewFarmPhone("");
    deductCredits(2);
  };

  // Role and Permission Management Functions
  const handleSessionRoleChange = (role: PredefinedRole) => {
    setCurrentRole(role);
    // Redirect if they lose privileges for the active tab
    if (activeTab !== "dashboard" && activeTab !== "permissions") {
      const activePerm = permissions[role]?.[activeTab];
      if (!activePerm || !activePerm.read) {
        setActiveTab("dashboard");
      }
    }
  };

  const handleUpdatePermission = (role: PredefinedRole, moduleId: string, type: "read" | "write", value: boolean) => {
    setPermissions(prev => {
      const updated = { ...prev };
      const rolePerms = { ...updated[role] };
      const modPerms = { ...rolePerms[moduleId] };
      modPerms[type] = value;
      
      // If read is disabled, write must be disabled as well
      if (type === "read" && !value) {
        modPerms.write = false;
      }
      
      rolePerms[moduleId] = modPerms;
      updated[role] = rolePerms;
      return updated;
    });
  };

  const handleAddTeamMember = async (member: Omit<UserMember, "id" | "lastActive">) => {
    const currentTenantId = activeFarm?.id || userProfile?.tenantId || "TENANT-001";
    try {
      const created = await UserService.createFarmNodeUser(
        currentTenantId,
        userProfile.email || "owner@mabala.com",
        {
          name: member.name,
          email: member.email,
          password: member.password || "Mabala@2026",
          role: member.role as PredefinedRole,
          permittedModules: member.permittedModules || [],
          modulePermissions: member.modulePermissions,
          farmId: activeFarm?.id || "farm-1",
          farmName: activeFarm?.name || "Main Farm",
          mustChangePassword: member.mustChangePassword ?? true
        }
      );
      setTeamMembers(prev => {
        const filtered = prev.filter(m => m.email.toLowerCase() !== created.email.toLowerCase());
        return [...filtered, created];
      });
      writeAuditLog(
        "CREATE",
        "Access Control",
        created.email,
        `Created user profile for ${created.name} (${created.email}) with role ${created.role} and ${created.permittedModules?.length || 0} permitted modules on farm ${activeFarm?.name || 'Node'}`
      );
      deductCredits(1);
    } catch (err: any) {
      console.error("Error adding team member via UserService:", err);
      const newMember: UserMember = {
        ...member,
        id: "TM-" + Date.now().toString().slice(-4),
        lastActive: "Just invited",
        tenantId: currentTenantId,
        isSuspended: false
      };
      setTeamMembers(prev => [...prev, newMember]);
      deductCredits(1);
    }
  };

  const handleRemoveTeamMember = async (id: string) => {
    const currentTenantId = activeFarm?.id || userProfile?.tenantId || "TENANT-001";
    const memberToDelete = teamMembers.find(m => m.id === id || m.email === id);
    if (memberToDelete) {
      try {
        await UserService.deleteFarmNodeUser(currentTenantId, memberToDelete.email, userProfile.email || "owner@mabala.com");
      } catch (err) {
        console.warn("UserService delete failed, continuing locally:", err);
      }
      writeAuditLog(
        "DELETE",
        "Access Control",
        memberToDelete.email,
        `Removed user ${memberToDelete.name} (${memberToDelete.email}) from farm node ${activeFarm?.name || 'Node'}`
      );
    }
    setTeamMembers(prev => prev.filter(m => m.id !== id && m.email !== id));
    deductCredits(1);
  };

  const handleChangeMemberRole = async (id: string, role: PredefinedRole) => {
    const currentTenantId = activeFarm?.id || userProfile?.tenantId || "TENANT-001";
    const memberToUpdate = teamMembers.find(m => m.id === id || m.email === id);
    if (memberToUpdate) {
      try {
        await UserService.updateFarmNodeUser(currentTenantId, memberToUpdate.email, { role }, userProfile.email || "owner@mabala.com");
      } catch (err) {
        console.warn("UserService update role failed, continuing locally:", err);
      }
      writeAuditLog(
        "EDIT",
        "Access Control",
        memberToUpdate.email,
        `Changed role for ${memberToUpdate.name} (${memberToUpdate.email}) to ${role}`
      );
    }
    setTeamMembers(prev => prev.map(m => (m.id === id || m.email === id) ? { ...m, role } : m));
    deductCredits(1);
  };

  const handleToggleUserSuspension = async (email: string, suspend: boolean, reason?: string) => {
    const currentTenantId = activeFarm?.id || userProfile?.tenantId || "TENANT-001";
    await UserService.toggleUserSuspension(currentTenantId, email, suspend, reason, userProfile.email || "owner@mabala.com");
    setTeamMembers(prev => prev.map(m => m.email.toLowerCase() === email.toLowerCase() ? {
      ...m,
      isSuspended: suspend,
      status: suspend ? "Suspended" : "Active",
      suspensionReason: reason
    } : m));
    writeAuditLog(
      suspend ? "SUSPEND" : "EDIT",
      "Access Control",
      email,
      `${suspend ? "Suspended" : "Reactivated"} user access for ${email}${reason ? ` (Reason: ${reason})` : ""}`
    );
  };

  const handleUpdateTeamMember = async (email: string, updates: Partial<UserMember>) => {
    const currentTenantId = activeFarm?.id || userProfile?.tenantId || "TENANT-001";
    await UserService.updateFarmNodeUser(currentTenantId, email, updates, userProfile.email || "owner@mabala.com");
    setTeamMembers(prev => prev.map(m => m.email.toLowerCase() === email.toLowerCase() ? {
      ...m,
      ...updates
    } : m));
    writeAuditLog(
      "EDIT",
      "Access Control",
      email,
      `Updated user permissions / profile for ${email}`
    );
  };

  const handleChangeOwnPassword = async (newPassword: string): Promise<boolean> => {
    const currentTenantId = activeFarm?.id || userProfile?.tenantId || "TENANT-001";
    const userEmail = userProfile.email || auth.currentUser?.email || "";
    if (!userEmail) throw new Error("No active user email session found.");
    
    await UserService.changeUserPassword(userEmail, newPassword, currentTenantId);
    
    if (auth.currentUser) {
      try {
        await updatePassword(auth.currentUser, newPassword);
      } catch (err: any) {
        console.warn("Direct Firebase auth updatePassword note:", err);
      }
    }
    
    writeAuditLog(
      "EDIT",
      "Security",
      userEmail,
      `User ${userEmail} successfully changed their login password`
    );
    showToast("🔑 Password updated successfully!", "success");
    return true;
  };

  const hasReadPermission = (moduleKey: string) => {
    const isSuperAdminEmail = SUPER_ADMIN_EMAILS.includes((userProfile?.email || auth.currentUser?.email || "").trim().toLowerCase());
    const canonicalType = resolveCanonicalTenantType(currentRole, userProfile?.email);
    if (
      currentRole === "Platform Administrator" || 
      currentRole === "Super Admin" || 
      isSuperAdmin || 
      isSuperAdminEmail || 
      canonicalType === "super_admin"
    ) return true;
    if (userProfile?.permittedModules && userProfile.permittedModules.length > 0) {
      const normalizedKey = moduleKey.replace(/_/g, "-");
      const isAllowed = userProfile.permittedModules.includes(moduleKey) || 
        userProfile.permittedModules.includes(normalizedKey) ||
        (moduleKey === "sales_tracker" && userProfile.permittedModules.includes("sales")) ||
        (moduleKey === "sales" && userProfile.permittedModules.includes("sales_tracker"));
      if (!isAllowed) return false;
    }
    if (currentRole === "Farm Owner") return true;
    const rule = permissions[currentRole]?.[moduleKey];
    if (rule && rule.read !== undefined) return rule.read;
    const roleStr = (currentRole as string) || "";
    const isAgroDealer = roleStr === "Agro Dealer" || roleStr === "agro_dealer" || roleStr === "Agro-Dealer";
    if (isAgroDealer && (moduleKey === "sales" || moduleKey === "sales_tracker")) return true;
    return false;
  };

  const hasWritePermission = (moduleKey: string) => {
    const isSuperAdminEmail = SUPER_ADMIN_EMAILS.includes((userProfile?.email || auth.currentUser?.email || "").trim().toLowerCase());
    const canonicalType = resolveCanonicalTenantType(currentRole, userProfile?.email);
    if (
      currentRole === "Platform Administrator" || 
      currentRole === "Super Admin" || 
      isSuperAdmin || 
      isSuperAdminEmail || 
      canonicalType === "super_admin"
    ) return true;
    if (userProfile?.permittedModules && userProfile.permittedModules.length > 0) {
      const normalizedKey = moduleKey.replace(/_/g, "-");
      const isAllowed = userProfile.permittedModules.includes(moduleKey) || 
        userProfile.permittedModules.includes(normalizedKey) ||
        (moduleKey === "sales_tracker" && userProfile.permittedModules.includes("sales")) ||
        (moduleKey === "sales" && userProfile.permittedModules.includes("sales_tracker"));
      if (!isAllowed) return false;
    }
    if (currentRole === "Farm Owner") return true;
    const rule = permissions[currentRole]?.[moduleKey];
    if (rule && rule.write !== undefined) return rule.write;
    const roleStr = (currentRole as string) || "";
    const isAgroDealer = roleStr === "Agro Dealer" || roleStr === "agro_dealer" || roleStr === "Agro-Dealer";
    if (isAgroDealer && (moduleKey === "sales" || moduleKey === "sales_tracker")) return true;
    return false;
  };

  const renderAccessDenied = (moduleName: string) => {
    return (
      <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center max-w-xl mx-auto my-12 shadow-sm space-y-6 animate-fade-in font-sans" id="access-denied-panel">
        <div className="w-16 h-16 bg-rose-50 border border-rose-200 text-rose-500 rounded-2xl flex items-center justify-center mx-auto shadow-sm">
          <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
            <path d="M7 11V7a5 5 0 0110 0v4" />
          </svg>
        </div>
        <div className="space-y-2">
          <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">Access Restricted: Permission Required</h3>
          <p className="text-slate-500 text-xs leading-relaxed max-w-sm mx-auto">
            Your current membership group <strong>({currentRole})</strong> does not possess read access to the <strong>{moduleName}</strong> module.
          </p>
        </div>
        <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row justify-center gap-3 text-xs font-bold">
          <button 
            onClick={() => setActiveTab("dashboard")} 
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-all cursor-pointer"
          >
            Return to Dashboard
          </button>
          {(!adminClaimed || (adminClaimantEmail && userProfile.email === adminClaimantEmail)) && (
            <button 
              onClick={() => handleSessionRoleChange("Platform Administrator")} 
              className="px-4 py-2 bg-purple-650 hover:bg-purple-600 text-white rounded-lg transition-all flex items-center justify-center gap-1.5 leading-none shadow-md shadow-purple-500/10 cursor-pointer border border-purple-700"
            >
              <Shield className="w-3.5 h-3.5 text-purple-200" />
              <span>Elevate to Platform Administrator</span>
            </button>
          )}
        </div>
      </div>
    );
  };

  // Dynamic Lipila dynamic carrier computation helpers
  const lipilaCleanPhone = lipilaPhone.replace(/\D/g, "");
  const lipilaIsAirtel = lipilaCleanPhone.startsWith("97") || lipilaCleanPhone.startsWith("77") || lipilaCleanPhone.startsWith("097") || lipilaCleanPhone.startsWith("077") || lipilaCleanPhone.startsWith("26097") || lipilaCleanPhone.startsWith("26077");
  const lipilaIsMtn = lipilaCleanPhone.startsWith("96") || lipilaCleanPhone.startsWith("76") || lipilaCleanPhone.startsWith("096") || lipilaCleanPhone.startsWith("076") || lipilaCleanPhone.startsWith("26096") || lipilaCleanPhone.startsWith("26076");
  const lipilaIsZamtel = lipilaCleanPhone.startsWith("95") || lipilaCleanPhone.startsWith("75") || lipilaCleanPhone.startsWith("095") || lipilaCleanPhone.startsWith("075") || lipilaCleanPhone.startsWith("26095") || lipilaCleanPhone.startsWith("26075");

  if (isUnverifiedUser) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="w-full max-w-sm bg-slate-900 border border-slate-800 text-white rounded-3xl shadow-xl overflow-hidden text-center p-8 space-y-6">
          <div className="mx-auto w-16 h-16 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full flex items-center justify-center mb-2">
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 19v-8.93a2 2 0 01.89-1.664l8-5.333a2 2 0 012.22 0l8 5.333A2 2 0 0121 10.07V19M3 19a2 2 0 002 2h14a2 2 0 002-2M3 19l6.75-4.5M21 19l-6.75-4.5M3 10l6.75 4.5M21 10l-6.75 4.5m0 0l-2.25-1.5a2 2 0 00-2.22 0l-2.25 1.5" />
            </svg>
          </div>
          
          <div className="space-y-2">
            <h2 className="text-xl font-bold tracking-tight text-white">Verify Your Email Address</h2>
            <p className="text-slate-400 font-normal text-xs leading-relaxed">
              We have dispatched a security verification email to:
              <br />
              <strong className="text-emerald-400 text-xs font-mono bg-slate-950 px-2 py-0.5 rounded shadow-sm mt-1.5 inline-block">{verificationEmailSentTo || "your registered email"}</strong>
            </p>
          </div>

          <div className="bg-amber-500/5 border border-amber-500/10 rounded-xl p-4 text-left">
            <div className="flex gap-2 items-start">
              <span className="text-amber-500 text-sm mt-0.5">⚠️</span>
              <p className="text-amber-200 font-bold text-xs">Mabala Security Verification Mandate:</p>
            </div>
            <p className="text-amber-300 text-[11px] leading-relaxed mt-1 font-medium pl-6 opacity-80">
              To satisfy IFRS financial security standards, access is locked until the verification link is clicked. Please inspect your Inbox (and your Spam folder).
            </p>
          </div>

          <div className="pt-2 space-y-3">
            <button
              onClick={() => {
                setIsUnverifiedUser(false);
                setIsAuthenticated(true);
                if (auth.currentUser) {
                  const u = auth.currentUser;
                  setUserProfile({
                    name: u.displayName || u.email?.split("@")[0] || "Mabala Farmer",
                    email: u.email || "owner@mabala.com",
                    phone: u.phoneNumber || "+260977889900"
                  });
                  handleStartDemo(u.email || "owner@mabala.com");
                } else if (verificationEmailSentTo) {
                  setUserProfile({
                    name: verificationEmailSentTo.split("@")[0] || "Mabala Farmer",
                    email: verificationEmailSentTo,
                    phone: "+260977889900"
                  });
                  handleStartDemo(verificationEmailSentTo);
                } else {
                  setUserProfile({
                    name: "Mabala Farmer",
                    email: "owner@mabala.com",
                    phone: "+260977889900"
                  });
                  handleStartDemo("owner@mabala.com");
                }
              }}
              className="w-full py-2.5 px-4 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-amber-600/10 cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Proceed & Bypass Email Verification</span>
            </button>

            <button
              onClick={async () => {
                try {
                  await signOut(auth);
                } catch (_) {}
                setIsUnverifiedUser(false);
                setWelcomeKey(prev => prev + 1);
              }}
              className="w-full py-2 px-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              <span>Back to Sign In Login page</span>
            </button>

            <button
              onClick={() => {
                showToast("Please click the bypass option above if email delivery is delayed, or check your spam/junk folder.", "warning");
              }}
              className="w-full py-2 px-4 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 rounded-xl text-xs font-normal transition-colors cursor-pointer"
            >
              <span>Didn't receive? Resend instructions</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-6 space-y-4 font-sans animate-fade-in">
        <div className="relative flex items-center justify-center">
          <div className="w-14 h-14 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin" />
          <div className="absolute p-2 bg-emerald-500/10 rounded-full text-emerald-400">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        </div>
        <div className="text-center space-y-1">
          <h3 className="text-base font-extrabold tracking-tight text-slate-100">
            Mabala Farm Workspace
          </h3>
          <p className="text-xs text-slate-400 font-medium animate-pulse">
            Restoring session & statutory ledger state...
          </p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="relative min-h-screen">
        {sessionError && (
          <div className="bg-slate-900 border-b border-rose-500/20 text-white py-2.5 px-4 text-xs font-sans flex items-center justify-between gap-4 shadow-md relative z-[101]">
            <div className="flex items-center gap-3 max-w-4xl mx-auto flex-1">
              <div className="inline-flex items-center justify-center w-7 h-7 rounded-xl bg-rose-500/15 text-rose-400 shrink-0 border border-rose-500/25">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center gap-0.5 sm:gap-2">
                <span className="text-rose-400 font-bold uppercase tracking-wider text-[10px]">Session Notice:</span>
                <span className="text-slate-200 font-medium">{sessionError}</span>
              </div>
            </div>
            <button 
              onClick={() => setSessionError(null)} 
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white px-3 py-1.5 rounded-xl text-xs font-semibold transition-all border border-slate-700 cursor-pointer shrink-0 shadow-xs"
            >
              Dismiss
            </button>
          </div>
        )}
        <WelcomeScreen 
          key={welcomeKey}
          onStartDemo={handleStartDemo} 
          onInitDemoWorkspace={handleInitDemoWorkspace}
          onRegister={handleRegister} 
          onRegisterVendor={handleRegisterVendor}
          onRegisterOfftaker={handleRegisterOfftaker}
          onRegisterPartner={handleRegisterPartner}
          onRegisterAgronomist={handleRegisterAgronomist}
          onLogin={handleLogin} 
          onGoogleSignIn={handleGoogleSignIn} 
          onGoogleSignInBypass={handleGoogleSignInBypass}
          checkEmailExists={handleCheckEmailExists}
          platformPackages={platformPackages}
          contactDetails={contactDetails}
          activeAds={activeAds}
        />
        {lipilaCheckout && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-md z-[100] flex items-center justify-center p-4 min-h-screen">
            <div className="w-full max-w-lg bg-slate-900 text-white rounded-3xl shadow-2xl border border-slate-700/60 overflow-hidden flex flex-col justify-between p-6 space-y-4 animate-scale-up">
              
              {/* Header */}
              <div className="flex justify-between items-center border-b border-slate-800 pb-4 text-xs">
                <div className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full bg-indigo-500 animate-pulse" />
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-indigo-400">Secure Live Lipila Terminal</span>
                </div>
                <button 
                  onClick={() => {
                    handleLipilaCancelOrFailure("Checkout cancelled by user.");
                  }} 
                  className="text-slate-400 hover:text-white transition-colors text-xs font-bold px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg cursor-pointer"
                >
                  ✕ Cancel
                </button>
              </div>

              {/* Main Checkout View states */}
              {lipilaPaymentStatus === "Idle" || lipilaPaymentStatus === "Submitting" ? (
                <div className="space-y-4 text-xs">
                  {/* Item Card */}
                  <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                    <span className="text-[9px] uppercase tracking-wide text-indigo-400 font-extrabold block">Selected Order Package:</span>
                    <div className="flex justify-between items-start mt-1">
                      <div>
                        <h4 className="text-sm font-bold text-white">{lipilaCheckout.name}</h4>
                        <p className="text-[10px] text-slate-400 mt-0.5">{lipilaCheckout.description}</p>
                      </div>
                      <span className="text-right">
                        <div className="text-xs font-black text-indigo-400 font-mono">
                          {lipilaCheckout.currency === "USD" ? `$ ${lipilaCheckout.price}` : `ZK ${lipilaCheckout.price}`}
                        </div>
                        <div className="text-[10px] text-slate-500 mt-0.5">+{lipilaCheckout.creditsToAward} CR</div>
                      </span>
                    </div>
                  </div>

                  {/* Account details & number inputs */}
                  <div className="space-y-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block pb-1">
                        Enter Mobile Money Number ({lipilaCheckout.currency === "USD" ? "International" : "Zambia"})
                      </label>
                      <div className="flex gap-2">
                        <div className="flex items-center justify-center px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs font-bold font-mono text-slate-300">
                          {lipilaCheckout.currency === "USD" ? "+" : "+260"}
                        </div>
                        <input 
                          type="text" 
                          placeholder="97X XXX XXX"
                          value={lipilaPhone}
                          onChange={(e) => setLipilaPhone(e.target.value)}
                          disabled={lipilaPaymentStatus === "Submitting"}
                          className="flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs font-bold text-white outline-none focus:border-indigo-500"
                        />
                      </div>
                      <span className="text-[9.5px] text-slate-400 font-medium block mt-1 tracking-normal">
                        Airtel, MTN, or Zamtel generated from the Lipila api·
                      </span>
                    </div>



                    {/* Provider Logo Picker / Network detection */}
                    <div className="flex justify-between items-center bg-slate-950/40 p-3 rounded-2xl border border-slate-800/80">
                      <span className="text-[10px] uppercase text-slate-400 font-extrabold">Detected Wallet Carrier:</span>
                      <div className="flex gap-1 text-[9.5px] font-black">
                        <span className={`px-2 py-0.5 rounded-md ${lipilaIsAirtel ? "bg-red-600/20 text-red-400 border border-red-500/30" : "bg-slate-950 text-slate-600"}`}>
                          Airtel Money
                        </span>
                        <span className={`px-2 py-0.5 rounded-md ${lipilaIsMtn ? "bg-amber-500/20 text-amber-400 border border-amber-500/30" : "bg-slate-950 text-slate-600"}`}>
                          MTN MoMo
                        </span>
                        <span className={`px-2 py-0.5 rounded-md ${lipilaIsZamtel ? "bg-emerald-600/20 text-emerald-400 border border-emerald-500/30" : "bg-slate-950 text-slate-600"}`}>
                          Zamtel Kwacha
                        </span>
                      </div>
                    </div>

                    {/* Registered holder identity auto-fetch */}
                    <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex justify-between items-center">
                      <span className="text-[10px] uppercase font-extrabold text-slate-400">Account Holder:</span>
                      {lipilaSearchingName ? (
                        <span className="text-[10.5px] text-indigo-400 font-bold flex items-center gap-1.5 animate-pulse">
                          <span className="h-2 w-2 rounded-full bg-indigo-500 animate-ping inline-block" />
                          Fetching KYC...
                        </span>
                      ) : (
                        <span className="text-[11px] text-emerald-400 font-black font-mono tracking-wide">
                          {lipilaHolderName || "Enter exact wallet above"}
                        </span>
                      )}
                    </div>
                  </div>

                  {lipilaError && (
                    <div className="p-3 bg-rose-950/30 border border-rose-500/30 text-rose-400 rounded-xl text-[10.5px] font-semibold leading-relaxed">
                      ⚠️ {lipilaError}
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={handleLipilaSubmitPayment}
                    disabled={lipilaPaymentStatus === "Submitting" || !lipilaHolderName || lipilaSearchingName}
                    className={`w-full py-3 rounded-2xl font-black text-xs ${(!lipilaHolderName || lipilaSearchingName || lipilaPaymentStatus === "Submitting") ? "bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed" : "bg-indigo-600 hover:bg-indigo-550 border border-indigo-500 text-white shadow-lg active:scale-[0.99]"} flex justify-center items-center gap-2 transition-all cursor-pointer`}
                  >
                    {lipilaPaymentStatus === "Submitting" ? (
                      <span className="animate-spin text-sm">↻</span>
                    ) : null}
                    <span>Authorise Payment and Provision Account {lipilaCheckout.price > 0 ? `(${lipilaCheckout.currency === "USD" ? `$ ${lipilaCheckout.price}` : `ZK ${lipilaCheckout.price}`})` : ""}</span>
                  </button>
                </div>
              ) : lipilaPaymentStatus === "Pending" ? (
                <div className="py-6 text-center space-y-5 text-xs">
                  {/* 1. Large Waiting / Spinner Notification Card */}
                  <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3.5 max-w-sm mx-auto">
                    <div className="relative flex justify-center py-2">
                      <div className="w-12 h-12 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin" />
                      <span className="absolute top-5 text-sm animate-pulse">⏳</span>
                    </div>
                    <div className="space-y-1.5">
                      <h4 className="text-xs font-extrabold uppercase tracking-widest text-indigo-400">Waiting for Payment Authorisation</h4>
                      <p className="text-[11px] text-slate-400 leading-relaxed font-sans mt-0.5">
                        Please enter your mobile money PIN on the prompt sent to your device <span className="text-white font-mono font-bold">{formatZambianMobileDisplay(lipilaPhone) || lipilaPhone}</span> ({lipilaHolderName}). Account provisioning will auto-authorise upon receiving confirmation from the operator.
                      </p>
                      <p className="text-[9px] text-slate-500 bg-slate-900 border border-slate-800 px-2 py-1 rounded-md inline-block">
                        Ref ID: <span className="font-mono text-indigo-300 font-bold">{lipilaRefId}</span>
                      </p>
                    </div>
                  </div>

                  {/* 2. Manual Verification Controller */}
                  <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3.5 text-left max-w-sm mx-auto">
                    <div className="flex justify-between items-center pb-1">
                      <span className="text-indigo-400 font-bold uppercase tracking-wider text-[9.5px]">Live Gateway Verification:</span>
                      <span className="text-rose-400 font-mono text-[9.5px] font-black animate-pulse px-2 py-0.5 bg-rose-500/10 rounded-md">Time left: {lipilaTimeRemaining}s</span>
                    </div>
                    <button
                      type="button"
                      disabled={lipilaSearchingName}
                      onClick={handleCheckLipilaStatusManually}
                      className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-550 border border-indigo-500 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-all active:scale-95 flex justify-center items-center gap-1.5"
                    >
                      {lipilaSearchingName ? (
                        <>
                          <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          <span>Checking gateway...</span>
                        </>
                      ) : (
                        <>
                          <span>✓ Check Payment Status Now</span>
                        </>
                      )}
                    </button>
                    <p className="text-[9px] text-slate-400 leading-normal mt-1 text-center">
                      Enter your PIN on your physical phone prompt. If you have already approved it, click the button above to manually fetch and verify your settlement.
                    </p>
                  </div>

                  {/* 3. Grayed-out "Authorise Payment and Provision Account" button */}
                  <div className="max-w-sm mx-auto pt-2">
                    <button
                      type="button"
                      disabled={true}
                      className="w-full py-3 rounded-2xl font-black text-xs bg-slate-850 text-slate-500 border border-slate-850 cursor-not-allowed flex justify-center items-center gap-2 transition-all"
                    >
                      <span className="animate-spin text-sm">↻</span>
                      <span>Waiting for Payment Confirmation...</span>
                    </button>
                  </div>

                  {lipilaError && (
                    <div className="pt-2 max-w-sm mx-auto">
                      <div className="p-3 bg-rose-950/30 border border-rose-500/35 text-rose-400 rounded-xl text-xs font-semibold leading-relaxed">
                        ⚠️ Payment Failed: {lipilaError}
                      </div>
                      {/pin|invalid|expired/i.test(lipilaError) ? (
                        <div className="flex gap-2.5 mt-3">
                          <button
                            type="button"
                            onClick={() => {
                              setLipilaError("");
                              setLipilaTimeRemaining(300);
                              setLipilaRetryTrigger(prev => prev + 1);
                            }}
                            className="flex-1 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-550 border border-emerald-500 text-white text-xs font-black rounded-xl transition-all shadow-md active:scale-95 cursor-pointer"
                          >
                            Retry PIN Verification
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setLipilaError("");
                              setLipilaPaymentStatus("Idle");
                            }}
                            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs font-black rounded-xl transition-all shadow-md active:scale-95 cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            setLipilaError("");
                            setLipilaPaymentStatus("Idle");
                          }}
                          className="mt-3 w-full py-2.5 bg-indigo-600 hover:bg-indigo-550 border border-indigo-550 text-white text-xs font-black rounded-xl transition-all shadow-md active:scale-95 cursor-pointer"
                        >
                          Try Payment Again
                        </button>
                      )}
                    </div>
                  )}
                </div>
              ) : lipilaPaymentStatus === "Successful" ? (
                <div className="py-6 text-center space-y-5 text-xs">
                  <div className="w-16 h-16 bg-emerald-500/15 border border-emerald-500/25 text-emerald-400 text-3xl font-black rounded-full flex items-center justify-center mx-auto animate-bounce">
                    ✓
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-sm font-extrabold uppercase tracking-widest text-emerald-400">Payment Successfully Procured!</h4>
                    <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
                      Congratulations! Your Mobile Money transaction has been fully cleared and verified:
                    </p>
                    <p className="text-xs text-white font-black font-sans bg-slate-950 p-2.5 rounded-2xl inline-block border border-slate-800/80">
                      +{lipilaCheckout.creditsToAward} Credits Allocated to Account!
                    </p>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-2xl max-w-sm mx-auto border border-slate-850 text-left font-mono text-[9.5px] text-slate-400 space-y-1">
                    <div>Ref: <span className="text-white font-bold">{lipilaRefId}</span></div>
                    <div>Cleared At: {new Date().toLocaleTimeString()}</div>
                    <div>Carrier Channel: Wallet Verified</div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setLipilaCheckout(null);
                      setLipilaPhone("");
                      setLipilaHolderName("");
                      setLipilaPaymentStatus("Idle");
                      setLipilaError("");
                    }}
                    className="px-8 py-2.5 bg-emerald-600 hover:bg-emerald-550 text-white font-black text-xs rounded-xl border border-emerald-500 shadow active:scale-95 cursor-pointer"
                  >
                    Clear Checkout Session & Access Platform
                  </button>
                </div>
              ) : (
                <div className="py-6 text-center space-y-5 text-xs">
                  <div className="w-16 h-16 bg-rose-500/15 border border-rose-500/25 text-rose-500 text-2xl font-black rounded-full flex items-center justify-center mx-auto">
                    ☠
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-sm font-extrabold uppercase tracking-widest text-rose-400">Transaction Failed / Timed Out</h4>
                    <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
                      We were unable to approve the transaction automatically. Be sure your wallet has sufficient balance and you have completed PIN confirmation on {formatZambianMobileDisplay(lipilaPhone) || lipilaPhone}.
                    </p>
                    {lipilaError && (
                      <p className="text-xs text-rose-400 bg-rose-950/20 px-4 py-2 rounded-xl border border-rose-500/35 inline-block">{safeFormatError(lipilaError)}</p>
                    )}
                  </div>
                  <div className="flex justify-center gap-3 font-semibold">
                    <button
                      type="button"
                      onClick={() => {
                        setLipilaPaymentStatus("Idle");
                        setLipilaError("");
                      }}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-550 text-white text-xs font-bold rounded-xl cursor-pointer"
                    >
                      Try Again
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleLipilaCancelOrFailure("Transaction failed or was cancelled.");
                      }}
                      className="px-4 py-2 bg-slate-950 hover:bg-slate-900 border border-slate-800 text-slate-400 hover:text-white text-xs font-bold rounded-xl cursor-pointer"
                    >
                      Cancel Payment
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  // Tenant Suspension Access Control Gate
  if (farmStatus === "SUSPENDED" && userProfile.email !== "support@mabala.cloud") {
    return (
      <div className="h-screen w-full bg-slate-950 flex flex-col justify-center items-center text-white p-6 font-sans">
        <div className="max-w-md text-center space-y-5 bg-slate-900 p-8 rounded-2xl border border-rose-500/30 shadow-2xl shadow-rose-500/5">
          <div className="w-16 h-16 bg-rose-500/10 text-rose-500 border border-rose-500/20 rounded-2xl flex items-center justify-center text-3xl mx-auto font-black animate-pulse">
            ☠
          </div>
          <div className="space-y-2">
            <h2 className="text-xl font-black uppercase text-rose-500 tracking-wider">Tenant Subscription Suspended</h2>
            <p className="text-xs text-slate-400 leading-relaxed font-semibold">
              The platform administrator has suspended access to all agricultural modules and accounting registers on this sub-farm tenant node.
            </p>
          </div>
          <div className="p-3.5 bg-slate-950/60 rounded-xl border border-slate-800 text-left font-mono text-[10px] text-slate-400 space-y-1">
            <span className="block text-slate-500 uppercase font-black text-[9px]">Last Global Admin Action</span>
            <p><strong>Status:</strong> SUSPENDED</p>
            <p><strong>Reason:</strong> Violation of corporate agri-cloud service agreements or trial expiration terms.</p>
          </div>
          
          <div className="pt-2">
            <button 
              onClick={async () => {
                try {
                  await signOut(auth);
                } catch (e) {
                  console.error("Sign out error:", e);
                }
              }}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 font-extrabold text-xs rounded-xl border border-slate-700 shadow-md transition-all cursor-pointer text-white"
            >
              Sign Out & Restart Demo Workspace
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Intercept and render explicit account setup failure / recovery terminal
  if (checkoutSetupError) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center text-white p-6 font-sans">
        <div className="w-full max-w-lg bg-slate-900 border border-rose-500/35 rounded-3xl shadow-2xl p-8 space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <span className="text-3xl text-rose-500">❌</span>
            <div>
              <h2 className="text-lg font-black uppercase text-rose-500 tracking-wider">Workspace Setup Interrupted</h2>
              <p className="text-[10px] uppercase font-bold text-slate-400">Account Provisioning & Database Write Failed</p>
            </div>
          </div>

          <div className="space-y-4 text-xs leading-relaxed">
            <p className="text-slate-300">
              Your subscription payment was processed successfully, but a critical write failure occurred when attempting to configure your account workspace in our database.
            </p>
            
            <div className="p-4 bg-rose-500/5 border border-rose-500/20 text-rose-300 rounded-2xl space-y-2">
              <span className="block font-bold text-[10px] uppercase tracking-wider text-rose-400">Error Details:</span>
              <p className="font-mono text-[10.5px] break-words">
                {safeFormatError(checkoutSetupError.error)}
              </p>
            </div>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 font-mono text-[10px] text-slate-400">
              <span className="block text-slate-500 uppercase font-black text-[9px] font-sans pb-1">Manual Audit / Recovery Logs</span>
              <div><span className="text-slate-500">Registered Email:</span> <span className="text-white font-semibold">{checkoutSetupError.email}</span></div>
              <div><span className="text-slate-500">Payment Reference:</span> <span className="text-white font-semibold">{checkoutSetupError.paymentReference}</span></div>
              <div><span className="text-slate-500">Generated UID:</span> <span className="text-white font-semibold">{checkoutSetupError.uid}</span></div>
              <div><span className="text-slate-500">Purchase Item:</span> <span className="text-white font-semibold">{checkoutSetupError.checkoutObj?.name || "Workspace Tier"}</span></div>
            </div>

            <p className="text-slate-400 text-[11px]">
              Do not close your browser tab. Your payment is fully recorded. You can safely retry the workspace initialization using the button below. If the error persists, please share the Manual Audit / Recovery Logs above with our support team to recover your account.
            </p>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button
              onClick={async () => {
                const retryBtn = document.getElementById("retry-setup-btn");
                if (retryBtn) retryBtn.innerText = "Re-establishing Workspace Database...";
                try {
                  await handlePaymentSuccessAllocation(checkoutSetupError.checkoutObj, checkoutSetupError.uid);
                } catch (retryErr: any) {
                  if (retryBtn) retryBtn.innerText = "Workspace Setup Failed again. Click to Retry";
                  setCheckoutSetupError(prev => prev ? {
                    ...prev,
                    error: retryErr?.message || "Subsequent database write failure on manual retry."
                  } : null);
                }
              }}
              id="retry-setup-btn"
              className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-550 border border-emerald-500 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-all active:scale-95 flex justify-center items-center gap-1.5"
            >
              ✓ Retry Workspace Initialization
            </button>
            <button
              onClick={async () => {
                try {
                  await signOut(auth);
                } catch (_) {}
                setCheckoutSetupError(null);
                setWelcomeKey(prev => prev + 1);
              }}
              className="py-3 px-5 bg-slate-800 hover:bg-slate-700 border border-slate-750 text-slate-300 font-bold text-xs rounded-xl transition-all cursor-pointer"
            >
              Cancel & Back to Welcome
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Render fully isolated Sponsoring Organisation / M&E Workspace portal if authenticated with matching roles
  const currentRoleLower = (userProfile.role || "").toLowerCase().trim();
  const canonicalType = resolveCanonicalTenantType(userProfile.role || (userProfile as any).tenantType, userProfile.email);
  const rNorm = currentRoleLower.replace(/[\s_-]+/g, "");
  const isInstitutionUser = 
    rNorm.includes("institution") ||
    rNorm.includes("m&e") ||
    rNorm.includes("meofficer") ||
    rNorm.includes("evaluator") ||
    currentRoleLower.includes("institution") ||
    currentRoleLower.includes("m&e") ||
    currentRoleLower === "institution admin" || 
    currentRoleLower === "institution_admin" ||
    currentRoleLower === "institution staff" || 
    currentRoleLower === "institution_staff" ||
    currentRoleLower === "institution supplier" ||
    currentRoleLower === "institution_supplier" ||
    currentRoleLower === "institutional supplier" ||
    currentRoleLower === "institutional m&e" ||
    currentRoleLower === "institutional_me" ||
    currentRoleLower === "m&e officer" ||
    currentRoleLower === "m&e user" ||
    currentRoleLower === "m&e evaluator" ||
    currentRoleLower === "subuser" ||
    currentRoleLower === "field officer" ||
    currentRoleLower === "field operator";

  const isSupplierUser =
    currentRoleLower === "supplier" ||
    currentRoleLower === "institution supplier" ||
    currentRoleLower === "institution_supplier" ||
    currentRoleLower === "institutional supplier" ||
    canonicalType === "institution_supplier";

  if (!identityReady) {
    return <div className="flex h-screen w-full items-center justify-center bg-slate-50 text-slate-600">Loading secure session...</div>;
  }

  if (isAuthenticated && isSupplierUser) {
    return (
      <BoundaryGuard userProfile={userProfile}>
        <SupplierDashboard 
          userProfile={userProfile} 
          invoices={invoices}
          currencySymbol={activeFarm?.currencySymbol || "ZMW"}
          onLogout={handleLogout} 
        />
      </BoundaryGuard>
    );
  }

  if (isAuthenticated && isInstitutionUser) {
    return (
      <BoundaryGuard userProfile={userProfile}>
        <InstitutionPortal 
          userProfile={userProfile} 
          onLogout={handleLogout} 
        />
      </BoundaryGuard>
    );
  }

  const currentRoleStr = (currentRole as string) || (userProfile?.role as string) || "";
  const isAgroDealerUser = (canonicalType === "agro_dealer" || currentRoleStr === "Agro Dealer" || currentRoleStr === "Agro-Dealer" || currentRoleStr === "Institution Supplier" || canonicalType === "institution_supplier") && canonicalType !== "farmer" && currentRoleStr !== "Farm Owner" && currentRoleStr !== "Farmer";

  return (
    <div className={`flex h-screen w-full bg-slate-50 text-slate-900 overflow-hidden font-sans transition-all duration-300 ${cloudSaveFailed ? 'ring-4 ring-rose-500 ring-inset' : ''}`}>
      {isReadonly && (
        <style>{`
          @media print {
            body {
              display: none !important;
            }
          }
        `}</style>
      )}
      
      {isReadonly && (
        <div className="watermark-overlay opacity-[0.03] select-none pointer-events-none fixed inset-0 z-[9999] grid grid-cols-4 grid-rows-6 gap-4 text-slate-900 font-extrabold tracking-widest uppercase text-[10px] rotate-[-30deg] scale-125">
          {Array.from({ length: 24 }).map((_, i) => (
            <div key={i} className="flex items-center justify-center whitespace-nowrap p-4">
              MABALA READ-ONLY MODE — UPGRADE TO UNLOCK
            </div>
          ))}
        </div>
      )}
      
      {/* Dynamic Left Menu Bar Navigation */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        isReadonly={isReadonly} 
        onTopUp={() => setShowTopUpModal(true)} 
        credits={credits} 
        currentRole={impersonation ? ((impersonation.targetActualRole as PredefinedRole) || "Farm Owner") : currentRole}
        rolePermissions={permissions[currentRole]}
        userEmail={activeProfile?.email || userProfile.email}
        subscriptionTier={subscriptionTier}
        workspaceMode={workspaceMode}
        activeFarmName={activeFarm?.name || (impersonation ? impersonation.targetFarmName : "Farm Workspace Node")}
        onOpenAnimalWizard={() => setIsAnimalWizardOpen(true)}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        isSuperAdminSession={Boolean(!impersonation && (userProfile.email && (SUPER_ADMIN_EMAILS.includes(userProfile.email.toLowerCase().trim()) || userProfile.email.toLowerCase().trim() === "support@mabala.cloud" || userProfile.email.toLowerCase().trim() === "shikasuli@gmail.com")))}
        isImpersonating={Boolean(impersonation)}
      />

      {/* Main viewport Container */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">

        {/* Persistent Impersonation Safety Cue Banner (Section 3.5) */}
        {impersonation && (
          <div 
            id="access-node-safety-banner"
            className="bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 text-white px-4 py-2 text-xs font-bold flex flex-wrap items-center justify-between gap-3 shadow-md border-b-2 border-amber-900 z-50 shrink-0 select-none"
          >
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-300 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-200"></span>
              </span>
              <div className="flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-amber-200 shrink-0" />
                <span className="font-extrabold uppercase tracking-wide text-amber-200">
                  Remote Access Active:
                </span>
                <span className="font-semibold text-white">
                  {impersonation.targetFarmName || "Target Farm"} ({impersonation.targetEmail})
                </span>
              </div>
              <span className="text-[10px] bg-amber-900/60 text-amber-200 px-2 py-0.5 rounded font-mono font-bold uppercase border border-amber-500/30">
                Node Role: {impersonation.targetActualRole || "Farm Owner"}
              </span>
              <span className="text-[10px] bg-emerald-900/60 text-emerald-200 px-2 py-0.5 rounded font-mono font-bold uppercase border border-emerald-500/30">
                Super Admin Intact
              </span>
              {sessionTimeLeft !== undefined && (
                <span className="text-[10px] bg-slate-950/40 text-amber-100 px-2 py-0.5 rounded font-mono font-semibold">
                  ⏱ {Math.floor(sessionTimeLeft / 60)}m {sessionTimeLeft % 60}s remaining
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                id="exit-farm-node-button"
                onClick={handleExitImpersonation}
                className="bg-white hover:bg-rose-50 text-rose-700 hover:text-rose-800 active:scale-95 px-3 py-1 rounded-lg font-bold text-xs shadow-xs transition-all flex items-center gap-1.5 cursor-pointer border border-rose-200"
                title="Exit remote farm node session and return to Super Admin view"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Exit Farm Node</span>
              </button>
            </div>
          </div>
        )}
        
        {/* Clearly Marked Offline Session Banner */}
        {isOfflineSession && (
          <div className="bg-amber-500 text-slate-950 px-4 py-2 text-xs font-extrabold flex flex-wrap items-center justify-between gap-2 shadow-lg border-b border-amber-600 animate-pulse z-40 shrink-0">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-950 animate-ping" />
              <span>⚠️ OFFLINE SESSION ACTIVE: Logged in via cached local device session. Silent Firebase Auth background sync queued...</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] bg-slate-950 text-amber-300 font-mono font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                Verified Local Device Cache
              </span>
              <button
                type="button"
                onClick={() => {
                  if (typeof window !== "undefined" && window.navigator.onLine) {
                    showToast("Rechecking connection & triggering silent Firebase Auth re-authentication...", "info");
                  } else {
                    showToast("Device is currently offline. Will reconcile automatically once internet connection returns.", "warning");
                  }
                }}
                className="text-[10px] bg-amber-900/20 hover:bg-amber-900/30 text-slate-950 font-black px-2.5 py-0.5 rounded border border-amber-800/40 cursor-pointer"
              >
                Recheck Connection
              </button>
            </div>
          </div>
        )}

        {/* Offline Queue Sync Status Banner */}
        {offlineQueueState.pendingCount > 0 && (
          <div className="bg-slate-900 text-white px-4 py-2 text-xs font-bold flex flex-wrap items-center justify-between gap-2 shadow-lg border-b border-indigo-500/40 z-40 shrink-0">
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${offlineQueueState.isFlushing ? "bg-sky-400 animate-ping" : "bg-amber-400 animate-pulse"}`} />
              <span>
                {offlineQueueState.isFlushing
                  ? `🔄 Syncing ${offlineQueueState.pendingCount} queued change(s) to Cloud Firestore...`
                  : `⚡ ${offlineQueueState.pendingCount} change${offlineQueueState.pendingCount > 1 ? "s" : ""} pending sync (Durable local IndexedDB storage)`}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {offlineQueueState.lastFlushResult && (
                <span className="text-[10px] font-mono text-slate-300 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                  Last Sync: {offlineQueueState.lastFlushResult.successCount} ok, {offlineQueueState.lastFlushResult.failureCount} failed
                  {offlineQueueState.lastFlushResult.syncedModules && offlineQueueState.lastFlushResult.syncedModules.length > 0 && (
                    <span className="text-emerald-400 font-sans font-bold ml-1">
                      ({offlineQueueState.lastFlushResult.syncedModules.map(m => `'${m}'`).join(", ")})
                    </span>
                  )}
                </span>
              )}
              <button
                type="button"
                onClick={handleFlushOfflineQueue}
                disabled={offlineQueueState.isFlushing}
                className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 text-white font-black text-[10px] uppercase tracking-wider px-3 py-1 rounded-lg border border-indigo-400/40 cursor-pointer shadow-xs transition-all"
              >
                {offlineQueueState.isFlushing ? "Syncing..." : "Sync Queue Now ➜"}
              </button>
            </div>
          </div>
        )}
        
        {/* Mobile Sticky Header Bar (Light Blue Theme) */}
        <header className="sticky top-0 z-40 bg-sky-100/95 backdrop-blur-md text-slate-900 lg:hidden px-4 py-2.5 border-b border-sky-200/90 flex items-center justify-between shrink-0 select-none shadow-xs">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className={`px-2.5 py-1.5 rounded-xl border transition-all flex items-center gap-2 cursor-pointer shadow-xs active:scale-95 ${
                isSidebarOpen
                  ? "bg-emerald-100 border-emerald-300 text-emerald-800 font-bold"
                  : "bg-white border-sky-200/90 text-slate-800 hover:bg-sky-50 font-bold"
              }`}
              aria-label="Toggle Navigation Menu"
              title={isSidebarOpen ? "Turn Navigation Menu OFF (Collapse)" : "Turn Navigation Menu ON (Expand)"}
            >
              <Menu className="w-4 h-4 text-slate-800" />
              <span className="text-[10px] font-extrabold uppercase tracking-wider font-mono text-slate-800">MENU</span>
              
              <div className={`w-6 h-3.5 rounded-full p-0.5 transition-colors duration-200 flex items-center ${
                isSidebarOpen ? "bg-emerald-500 justify-end" : "bg-slate-400 justify-start"
              }`}>
                <div className="w-2.5 h-2.5 rounded-full bg-white shadow-xs" />
              </div>
              
              <span className={`text-[9px] font-black font-mono uppercase ${isSidebarOpen ? "text-emerald-800" : "text-slate-600"}`}>
                {isSidebarOpen ? "ON" : "OFF"}
              </span>
            </button>
            <span className="text-xs font-black tracking-wider text-blue-950 font-sans uppercase">MABALA SaaS</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] text-sky-950 font-mono font-black uppercase bg-white/80 px-2 py-0.5 rounded border border-sky-200">{currentRole}</span>
            <div className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold ${
              credits === null ? "bg-slate-200 text-slate-700" : credits === 0 ? "bg-rose-500 text-white" : "bg-emerald-100 border border-emerald-300 text-emerald-900 font-bold"
            }`}>
              {credits === null ? "... CR" : `${credits} CR`}
            </div>
          </div>
        </header>
        
        {impersonation && (
          <div className="bg-gradient-to-r from-red-700 via-indigo-900 to-slate-900 text-white px-6 py-2.5 text-xs font-black flex justify-between items-center shadow-lg animate-fade-in shrink-0 relative z-[1003] border-b border-indigo-500/30 font-sans">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="h-3 w-3 rounded-full bg-red-400 animate-ping inline-block shrink-0" />
              <div className="flex items-center gap-2">
                <span className="bg-red-500/20 text-red-300 px-2 py-0.5 rounded text-[10px] uppercase font-mono font-bold border border-red-500/30">
                  Remote Support Session
                </span>
                <span className="text-xs font-black text-white">
                  Farm Node: <strong>{farms[0]?.name || impersonation.targetFarmName || "Target Farm"}</strong>
                </span>
                <span className="text-slate-300 text-[11px] font-mono">
                  ({impersonation.targetEmail})
                </span>
              </div>
              <span className="hidden md:inline-block text-slate-500 font-mono text-[10px]">|</span>
              <span className="bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded text-[10px] font-mono font-bold border border-emerald-500/30 hidden sm:inline-block">
                Role: Super Admin (support@mabala.cloud)
              </span>
              <span className="hidden md:inline-block text-slate-500 font-mono text-[10px]">|</span>
              <span className="text-amber-300 text-[11px] font-mono font-bold">
                ⏱️ Auto-expires in {Math.floor(sessionTimeLeft / 60)}m {sessionTimeLeft % 60}s
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab(activeTab === "platform-admin" ? "dashboard" : "platform-admin")}
                className="bg-indigo-600/80 hover:bg-indigo-500 text-white px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all border border-indigo-400/40 cursor-pointer hidden sm:flex items-center gap-1"
                title="Toggle between Farm Workspace and Platform Admin Control"
              >
                {activeTab === "platform-admin" ? "➜ Return to Farm Dashboard" : "⚙️ Open Platform Admin"}
              </button>
              <button
                onClick={handleExitImpersonation}
                className="bg-white hover:bg-slate-100 text-slate-950 px-3.5 py-1.5 rounded-xl text-xs font-black uppercase transition-all shadow-md hover:scale-105 cursor-pointer shrink-0 border border-slate-200 flex items-center gap-1.5"
              >
                <span>Exit Session</span>
                <span className="text-red-600 font-extrabold">✕</span>
              </button>
            </div>
          </div>
        )}

        {!isOnline && (
          <div className="bg-gradient-to-r from-amber-600 via-amber-500 to-orange-600 text-white px-6 py-2.5 text-xs font-bold flex justify-between items-center shadow-md animate-fade-in shrink-0 relative z-[1002] border-b border-amber-700">
            <div className="flex items-center gap-2.5">
              <span className="h-2 w-2 rounded-full bg-white animate-ping inline-block shrink-0" />
              <span className="text-[11px] font-sans tracking-tight">
                ⚠️ <strong>Working Offline (Mabala Local-First Storage Active)</strong>: Your changes are safely saved to local database storage (IndexedDB) and will auto-synchronize to the cloud when you regain connectivity.
              </span>
            </div>
            <button
              onClick={() => setActiveTab("offline-sync")}
              className="bg-slate-900/40 hover:bg-slate-900/60 text-white px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer border border-white/20"
            >
              Configure Sync ➜
            </button>
          </div>
        )}

        {cloudSaveFailed && (
          <div className={`text-white px-6 py-2.5 text-xs font-bold flex justify-between items-center shadow-md animate-fade-in shrink-0 relative z-[1002] border-b transition-all duration-300 ${
            cloudSaveUserAcknowledged
              ? "bg-slate-800 border-slate-700 opacity-95"
              : "bg-gradient-to-r from-rose-600 via-red-650 to-amber-600 border-rose-700 animate-pulse"
          }`}>
            <div className="flex items-center gap-3">
              <span className={`h-2.5 w-2.5 rounded-full inline-block shrink-0 ${cloudSaveUserAcknowledged ? "bg-amber-400" : "bg-yellow-300 animate-ping"}`} />
              <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3">
                <span className="uppercase tracking-wider font-mono text-[11px] font-black">
                  {cloudSaveUserAcknowledged ? "⚠️ Cloud Save Interrupted (Working Locally)" : "⚠️ Cloud Save Failed / Connection Interrupted"}
                </span>
                <span className={`${cloudSaveUserAcknowledged ? "text-slate-300" : "text-rose-100"} text-[10.5px]`}>
                  {cloudSaveUserAcknowledged
                    ? "Changes are safe in your browser. Automatic background retries are running."
                    : "Your latest changes are saved locally but haven't been synchronized to the cloud yet."
                  }
                  {cloudSaveRetryCount > 0 && ` (Attempt #${cloudSaveRetryCount} with exponential backoff...)`}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={async () => {
                  const currentUser = auth.currentUser;
                  if (currentUser) {
                    await handleSaveCloudWorkspace(currentUser.uid);
                  }
                }}
                className="bg-white hover:bg-neutral-100 text-slate-900 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer border border-neutral-200"
              >
                Retry Now
              </button>
              {!cloudSaveUserAcknowledged && (
                <button
                  onClick={() => setCloudSaveUserAcknowledged(true)}
                  className="bg-rose-800/60 hover:bg-rose-850 text-white px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer border border-rose-700/50"
                >
                  Acknowledge
                </button>
              )}
            </div>
          </div>
        )}

        {/* Sleek Desktop Sticky Top Header Banner (Light Blue Theme) */}
        <header className="sticky top-0 z-30 h-15 bg-gradient-to-r from-sky-100 via-blue-50 to-sky-100 text-slate-900 border-b border-sky-200 px-6 lg:px-8 hidden lg:flex items-center justify-between shadow-xs shrink-0 transition-all">
          <div className="flex items-center gap-4">
            {/* Desktop Sticky Sidebar Toggle Button */}
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="px-3 py-1.5 rounded-xl bg-white hover:bg-sky-50 border border-sky-300/90 text-blue-950 transition-all flex items-center gap-2 text-xs font-bold cursor-pointer shadow-xs active:scale-95 hover:border-blue-400"
              title="Toggle Sidebar Navigation"
              aria-label="Toggle Navigation Menu"
            >
              <Menu className="w-4 h-4 text-blue-900" />
              <span className="text-xs font-extrabold text-blue-950">
                Menu
              </span>
            </button>
            
            <div className="h-6 w-px bg-sky-200" />
            
            {/* Centralized Farm-Switcher Dropdown */}
            <div className="relative flex flex-col">
              <span className="text-[10px] font-black text-sky-900 uppercase tracking-widest leading-none pb-1">Sub-Farm Workspace</span>
              <div className="flex items-center gap-1.5">
                {/* Trigger Button */}
                <button
                  type="button"
                  onClick={() => setShowFarmSwitcherDropdown(!showFarmSwitcherDropdown)}
                  className="bg-white border border-sky-200 hover:bg-sky-50/80 rounded-xl px-2.5 py-1 flex items-center gap-2 font-bold text-xs text-slate-800 outline-none transition-all duration-200 shadow-xs hover:border-sky-300 active:scale-98 cursor-pointer relative"
                >
                  <div className="shrink-0 flex items-center justify-center">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse inline-block" />
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="max-w-[190px] truncate leading-tight font-extrabold text-slate-900">
                      {isAllFarmsSelected ? "⭐ Collected Data (All Farms)" : activeFarm?.name || "Select Farm Node"}
                    </span>
                    {!isAllFarmsSelected && activeFarm && (
                      <span className="text-[9px] font-mono font-bold text-indigo-700 leading-tight flex items-center gap-1 mt-0.5">
                        <span className="px-1 py-0.2 bg-emerald-100/90 text-emerald-900 rounded font-black">{activeFarm.currencySymbol || "ZK"} {activeFarm.currency || "ZMW"}</span>
                        <span>•</span>
                        <span className="text-indigo-800 font-extrabold">
                          {(() => {
                            const taxType = activeFarm.taxType || (activeFarm.taxSystem === "VAT" ? "VAT_16" : activeFarm.taxSystem === "Turnover Tax" ? "TOT_5" : activeFarm.taxSystem) || "TOT_5";
                            if (taxType === "TOT_5") return "Turnover Tax (5%)";
                            if (taxType === "TOT_4") return "Turnover Tax (4%)";
                            if (taxType === "VAT_16" || taxType === "VAT") return "VAT 16%";
                            if (taxType === "EXEMPT" || taxType === "None") return "Tax Exempt";
                            if (taxType === "CUSTOM") return `${activeFarm.customTaxName || "Custom"} (${activeFarm.customTaxRate || 10}%)`;
                            return activeFarm.taxSystem || "Turnover Tax (5%)";
                          })()}
                        </span>
                      </span>
                    )}
                  </div>
                  <ChevronDown className={`w-3.5 h-3.5 text-slate-500 transition-transform duration-200 shrink-0 ${showFarmSwitcherDropdown ? "rotate-180" : ""}`} />
                </button>

                {/* Quick Plus Action */}
                <button 
                  type="button"
                  onClick={() => setShowFarmConfigModal(true)}
                  className="p-1.5 bg-white hover:bg-sky-50 text-blue-800 hover:text-blue-950 rounded-lg border border-sky-200 transition-all cursor-pointer shadow-xs active:scale-95"
                  title="Configure New Farm Segment"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Background Backdrop for closing the dropdown safely */}
              {showFarmSwitcherDropdown && (
                <>
                  <div 
                    className="fixed inset-0 z-40 bg-transparent" 
                    onClick={() => {
                      setShowFarmSwitcherDropdown(false);
                      setFarmSearchQuery("");
                    }} 
                  />
                  
                  {/* Dropdown Card */}
                  <div className="absolute left-0 top-full mt-2 w-[360px] bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 overflow-hidden animate-scale-up text-left">
                    {/* Header search bar */}
                    <div className="p-3 border-b bg-slate-50/55 flex items-center gap-2">
                      <Search className="w-4 h-4 text-slate-400 shrink-0" />
                      <input
                        type="text"
                        placeholder="Search managed farm segments..."
                        value={farmSearchQuery}
                        onChange={(e) => setFarmSearchQuery(e.target.value)}
                        className="w-full text-xs bg-transparent outline-none text-slate-800 placeholder-slate-400 font-medium"
                        onClick={(e) => e.stopPropagation()}
                      />
                      {farmSearchQuery && (
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); setFarmSearchQuery(""); }}
                          className="text-[10px] text-slate-400 hover:text-slate-600 bg-slate-200 hover:bg-slate-300 px-1.5 py-0.5 rounded font-black cursor-pointer"
                        >
                          Clear
                        </button>
                      )}
                    </div>

                    {/* Scrollable list */}
                    <div className="max-h-60 overflow-y-auto divide-y divide-slate-100">
                      {/* Filtered farm list */}
                      {accessibleFarms
                        .filter(f => 
                          (f?.name && f.name.toLowerCase().includes(farmSearchQuery.toLowerCase())) ||
                          (f?.address && f.address.toLowerCase().includes(farmSearchQuery.toLowerCase()))
                        )
                        .map((f) => {
                          const idx = farms.findIndex(farm => farm.id === f.id);
                          const isCurrent = !isAllFarmsSelected && idx === activeFarmIndex;
                          return (
                            <button
                              key={f.id}
                              type="button"
                              onClick={() => {
                                setIsAllFarmsActive(false);
                                setActiveFarmIndex(idx);
                                setShowFarmSwitcherDropdown(false);
                                setFarmSearchQuery("");
                              }}
                              className={`w-full p-3 font-sans text-left flex items-start gap-2.5 transition-colors cursor-pointer ${
                                isCurrent ? "bg-indigo-50/55 hover:bg-indigo-100/40" : "hover:bg-slate-50"
                              }`}
                            >
                              <div className={`mt-0.5 w-7 h-7 rounded-lg border shrink-0 flex items-center justify-center overflow-hidden ${
                                isCurrent ? "bg-indigo-100 border-indigo-200 text-indigo-700" : "bg-slate-100 border-slate-200 text-slate-500"
                              }`}>
                                {f.logo ? (
                                  f.logo === "leaf" ? <span className="text-xs">🌿</span> :
                                  f.logo === "wheat" ? <span className="text-xs">🌾</span> :
                                  f.logo === "shield" ? <span className="text-xs">🛡️</span> :
                                  f.logo === "water" ? <span className="text-xs">💧</span> :
                                  <img src={f.logo} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                ) : (
                                  <Building2 className="w-3.5 h-3.5" />
                                )}
                              </div>
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-1.5">
                                  <span className={`text-xs font-bold truncate ${isCurrent ? "text-indigo-900" : "text-slate-800"}`}>
                                    {f?.name || "Farm Node"}
                                  </span>
                                  {isCurrent && (
                                    <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[8.5px] font-black uppercase tracking-wider shrink-0">
                                      Active
                                    </span>
                                  )}
                                </div>
                                <div className="text-[10px] text-slate-400 font-medium truncate mt-0.5 flex items-center gap-1">
                                  <MapPin className="w-3 h-3 shrink-0 text-slate-350" />
                                  <span>{f.address || "No address defined"}</span>
                                </div>
                                <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                                  <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-900 border border-emerald-200/90 text-[9.5px] font-black font-mono flex items-center gap-1 shadow-2xs">
                                    <Coins className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                                    <span>{f.currencySymbol || "ZK"} {f.currency || "ZMW"}</span>
                                  </span>
                                  <span className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-900 border border-indigo-200/90 text-[9.5px] font-extrabold flex items-center gap-1 shadow-2xs">
                                    <Landmark className="w-2.5 h-2.5 text-indigo-600 shrink-0" />
                                    <span>
                                      {(() => {
                                        const taxType = f.taxType || (f.taxSystem === "VAT" ? "VAT_16" : f.taxSystem === "Turnover Tax" ? "TOT_5" : f.taxSystem) || "TOT_5";
                                        if (taxType === "TOT_5") return "Turnover Tax (TOT 5%)";
                                        if (taxType === "TOT_4") return "Turnover Tax (TOT 4%)";
                                        if (taxType === "VAT_16" || taxType === "VAT") return "VAT Regime (16%)";
                                        if (taxType === "EXEMPT" || taxType === "None") return "Tax Exempt";
                                        if (taxType === "CUSTOM") return `${f.customTaxName || "Custom"} (${f.customTaxRate || 10}%)`;
                                        return f.taxSystem || "Turnover Tax (TOT 5%)";
                                      })()}
                                    </span>
                                  </span>
                                </div>
                              </div>
                              {isCurrent && (
                                <Check className="w-4 h-4 text-emerald-600 shrink-0 self-center font-bold" />
                              )}
                            </button>
                          );
                        })}

                      {/* Enterprise multi-farm support option */}
                      {subscriptionTier === "Enterprise Suite" && (
                        <button
                          type="button"
                          onClick={() => {
                            setIsAllFarmsActive(true);
                            setShowFarmSwitcherDropdown(false);
                            setFarmSearchQuery("");
                          }}
                          className={`w-full p-3 text-left font-sans flex items-start gap-2.5 transition-colors cursor-pointer ${
                            isAllFarmsSelected ? "bg-indigo-50/55 hover:bg-indigo-100/40" : "hover:bg-slate-50"
                          }`}
                        >
                          <div className={`mt-0.5 p-1.5 rounded-lg border shrink-0 ${
                            isAllFarmsSelected ? "bg-indigo-100 border-indigo-200 text-indigo-700" : "bg-slate-100 border-slate-200 text-amber-500"
                          }`}>
                            <LayoutGrid className="w-4 h-4" />
                          </div>
                          <div className="min-w-0 flex-1 self-center">
                            <span className={`text-xs font-bold leading-none ${isAllFarmsSelected ? "text-indigo-900" : "text-slate-800"}`}>
                              ⭐ Collected Data (All Selected Farms)
                            </span>
                            <p className="text-[10.5px] text-slate-400 mt-0.5 font-medium">Aggregated reporting spanning all managed nodes</p>
                          </div>
                          {isAllFarmsSelected && (
                            <Check className="w-4 h-4 text-emerald-600 shrink-0 self-center font-bold" />
                          )}
                        </button>
                      )}

                      {/* No match indicator */}
                      {accessibleFarms.filter(f => 
                        (f?.name && f.name.toLowerCase().includes(farmSearchQuery.toLowerCase())) ||
                        (f?.address && f.address.toLowerCase().includes(farmSearchQuery.toLowerCase()))
                      ).length === 0 && (
                        <div className="p-6 text-center text-slate-400 text-[11px] font-medium leading-relaxed">
                          No matching farm segments found
                        </div>
                      )}
                    </div>

                    {/* Footer Actions */}
                    <div className="p-2.5 bg-slate-50 border-t flex items-center justify-between text-[11px]">
                      <span className="text-[10px] text-slate-400 font-extrabold uppercase shrink-0">
                        {accessibleFarms.length} Farm Segment{accessibleFarms.length !== 1 ? "s" : ""}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setShowFarmConfigModal(true);
                          setShowFarmSwitcherDropdown(false);
                          setFarmSearchQuery("");
                        }}
                        className="text-[10px] font-black text-indigo-600 hover:text-indigo-700 hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Add New Farm Node</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            <div className="h-8 w-px bg-sky-200 mx-2" />

            {/* Geographic Multi-country selection localized drop-down */}
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-sky-900 uppercase tracking-widest leading-none pb-1">Tenant Localization</span>
              <div className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-xl border border-sky-200 shadow-xs">
                <select 
                  value={selectedCountry.code}
                  onChange={e => handleCountryOverrideChange(e.target.value)}
                  className="bg-transparent font-bold text-xs text-slate-800 outline-none cursor-pointer border-none p-0"
                >
                  {COUNTRIES.map(c => (
                    <option key={c.code} value={c.code}>
                      {c.flag} {c.name} ({c.currency})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* GLOBAL INTELLIGENT SEARCH BAR */}
          <div className="relative mx-4 flex-1 max-w-sm hidden md:block font-sans">
            <div className="relative flex items-center">
              <Search className="absolute left-3 w-4.5 h-4.5 text-sky-700" />
              <input
                type="text"
                placeholder="Global Search (Tag, Employee, Invoice, Customer)..."
                value={globalSearchQuery}
                onChange={(e) => {
                  setGlobalSearchQuery(e.target.value);
                  setShowSearchResults(true);
                }}
                className="w-full text-xs font-bold pl-9 pr-8 py-2 bg-white placeholder:text-slate-400 text-slate-800 border border-sky-200/90 rounded-xl outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-400/20 transition-all shadow-xs"
              />
              {globalSearchQuery && (
                <button 
                  onClick={() => {
                    setGlobalSearchQuery("");
                    setShowSearchResults(false);
                  }} 
                  className="absolute right-2.5 p-0.5 hover:bg-slate-200 rounded-md text-slate-400 hover:text-slate-600 text-[10px] font-black"
                >
                  ✕
                </button>
              )}
            </div>

            {/* SEARCH RESULTS FLOATING BOX */}
            {showSearchResults && globalSearchQuery && (
              <>
                <div className="fixed inset-0 z-40 bg-transparent" onClick={() => setShowSearchResults(false)} />
                <div className="absolute left-0 top-full mt-2 w-[420px] max-h-96 overflow-y-auto bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 p-3.5 animate-scale-up text-left">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block pb-1.5 border-b mb-1">
                    Mabala Universal Index Matches
                  </span>
                  <div className="space-y-2.5 pt-1">
                    {/* 2. Filter Employee matches */}
                    {(() => {
                      const matches = employees.filter(e => 
                        (e?.name || "").toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
                        (e?.role || "").toLowerCase().includes(globalSearchQuery.toLowerCase())
                      ).slice(0, 3);
                      if (matches.length === 0) return null;
                      return (
                        <div className="border-b border-slate-100 pb-2.5">
                          <span className="text-[9px] font-black uppercase text-indigo-600 block pt-1 font-mono">👥 Employee Matches</span>
                          <div className="space-y-1 mt-1">
                            {matches.map(e => (
                              <button
                                key={e.id}
                                onClick={() => {
                                  setActiveTab("payroll");
                                  setGlobalSearchQuery("");
                                  setShowSearchResults(false);
                                }}
                                className="w-full p-2 hover:bg-slate-50 rounded-lg text-left text-xs font-bold flex justify-between items-center cursor-pointer"
                              >
                                <span>{e?.name || "Staff"} ({e?.role || "Team"})</span>
                                <span className="text-[9.5px] text-emerald-600">{selectedCountry.symbol}{e.contractRate.toLocaleString()}/mo</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      );
                    })()}

                    {/* 3. Filter Invoices */}
                    {(() => {
                      const matches = invoices.filter(inv => 
                        (inv.invoiceNumber || "").toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
                        (inv.customerName || "").toLowerCase().includes(globalSearchQuery.toLowerCase())
                      ).slice(0, 3);
                      if (matches.length === 0) return null;
                      return (
                        <div className="border-b border-slate-100 pb-2.5">
                          <span className="text-[9px] font-black uppercase text-amber-600 block pt-1 font-mono">📄 Invoice Matches</span>
                          <div className="space-y-1 mt-1">
                            {matches.map(inv => (
                              <button
                                key={inv.id}
                                onClick={() => {
                                  setActiveTab("invoices");
                                  setGlobalSearchQuery("");
                                  setShowSearchResults(false);
                                }}
                                className="w-full p-2 hover:bg-slate-50 rounded-lg text-left text-xs font-bold flex justify-between items-center cursor-pointer"
                              >
                                <span>{inv.invoiceNumber} - {inv.customerName}</span>
                                <span className="text-[9.5px] font-black font-mono text-slate-800">{selectedCountry.symbol}{inv.total.toLocaleString()}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      );
                    })()}

                    {/* No Match fallback */}
                    {employees.filter(e => (e?.name || "").toLowerCase().includes(globalSearchQuery.toLowerCase())).length === 0 &&
                     invoices.filter(inv => (inv.invoiceNumber || "").toLowerCase().includes(globalSearchQuery.toLowerCase()) || (inv.customerName || "").toLowerCase().includes(globalSearchQuery.toLowerCase())).length === 0 && (
                      <div className="p-4 text-center text-[11px] text-slate-400 font-medium">
                        No results match the query in current registry collections.
                      </div>
                    )}
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="flex items-center gap-6">
            <div className="flex flex-col items-end">
              <span className="text-[9px] font-black text-sky-900 uppercase tracking-widest leading-none pb-1">Compliance Tax engine</span>
              <span className="text-xs font-extrabold text-emerald-800 bg-emerald-100/90 px-2.5 py-0.5 rounded-lg border border-emerald-300 font-mono shadow-xs">
                {selectedCountry.isZambia ? "ZRA Standard VAT (16%)" : "Generic IFRS Standards"}
              </span>
            </div>

            <div className="h-8 w-px bg-sky-200" />

            <div className="flex items-center gap-3">
              <div className="flex flex-col items-end">
                <span className="text-xs font-black text-slate-900">{userProfile?.name || (currentRole === "Offtaker" ? "Offtaker Workspace" : currentRole === "Agro Dealer" ? "Agro Dealer Workspace" : currentRole === "Institution Supplier" ? "Supplier Workspace" : currentRole === "Mabala Partner" ? "Partner Workspace" : "Farm Owner")}</span>
                <span className={`text-[9.5px] px-2 py-0.5 rounded-full font-extrabold tracking-wider font-sans mt-0.5 border ${
                  currentRole === "Platform Administrator"
                    ? "bg-purple-100 border-purple-300 text-purple-900 font-extrabold shadow-2xs"
                    : currentRole === "Farm Owner" 
                      ? "bg-rose-100 border-rose-300 text-rose-900 font-extrabold shadow-2xs" 
                      : currentRole === "Accountant" 
                        ? "bg-amber-100 border-amber-300 text-amber-900 font-extrabold shadow-2xs" 
                        : "bg-blue-100 border-blue-300 text-blue-900 font-extrabold shadow-2xs"
                }`}>
                  {currentRole}
                </span>
              </div>
              <SyncStatusChip 
                rejectedWritesCount={rejectedWrites.length}
                onOpenRejectedWrites={() => setIsRejectedWritesModalOpen(true)}
              />
              <OfflineQueueStatusOverlay onOpenFullSyncPanel={() => setActiveTab("offline-sync")} />
              <ConnectivityIndicator onOpenSyncCenter={() => setActiveTab("offline-sync")} />
              <button 
                onClick={async () => {
                  try {
                    await signOut(auth);
                  } catch (e) {
                    console.error("Sign out error:", e);
                  }
                }}
                className="p-2 bg-white hover:bg-rose-50 text-slate-600 hover:text-rose-600 rounded-xl border border-sky-200 hover:border-rose-200 transition-colors cursor-pointer shadow-xs"
                title="Disconnect from Tenant Security Tunnel"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </header>

        {/* Clean Breadcrumbs & Primary Action Bar (Mabala Clean UI) */}
        <div 
          className={`bg-white border-b border-slate-200/90 py-2.5 flex flex-wrap items-center justify-between gap-3 shrink-0 select-none shadow-2xs transition-all duration-300 ease-in-out ${
            isSidebarOpen ? "px-4 sm:px-6 lg:px-8" : "px-4 sm:px-8 lg:px-12"
          }`} 
          id="global-quick-actions-hub"
        >
          {/* Breadcrumb Navigation */}
          <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-500 font-sans">
            <button
              onClick={() => setActiveTab("dashboard")}
              className="hover:text-slate-900 transition-colors cursor-pointer flex items-center gap-1"
              title="Return to Dashboard"
            >
              <span className="text-slate-400">←</span>
              <span>Dashboard</span>
            </button>
            <span className="text-slate-300">/</span>
            <span className="capitalize text-slate-600">{activeTab.replace("-group", "").replace("-", " ")}</span>
            <span className="text-slate-300">/</span>
            <span className="font-bold text-slate-900 capitalize">
              {activeTab === "dashboard" ? "Overview" : activeTab.replace("-", " ")}
            </span>
          </div>

          {/* Clean Primary Navy Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveTab("expenses")}
              className="bg-[#0B2265] hover:bg-[#071746] active:scale-95 text-white text-xs font-semibold py-1.5 px-3.5 rounded-lg shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>🧾</span>
              <span>Record Expense</span>
            </button>

            <button
              onClick={() => setActiveTab("sales")}
              className="bg-[#0B2265] hover:bg-[#071746] active:scale-95 text-white text-xs font-semibold py-1.5 px-3.5 rounded-lg shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>💰</span>
              <span>Record Income</span>
            </button>

            <button
              onClick={() => setActiveTab("invoices")}
              className="bg-[#0B2265] hover:bg-[#071746] active:scale-95 text-white text-xs font-semibold py-1.5 px-3.5 rounded-lg shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>📄</span>
              <span>New Invoice</span>
            </button>

            <button
              onClick={() => setActiveTab("crops")}
              className="bg-[#0B2265] hover:bg-[#071746] active:scale-95 text-white text-xs font-semibold py-1.5 px-3.5 rounded-lg shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>🌾</span>
              <span>Record Harvest</span>
            </button>
          </div>
        </div>

        {/* Warning banner when credit reserves are low */}
        {isReadonly && !hideReadonlyBanner && (
          <ReadOnlyWarningBanner
            variant="banner"
            onNavigateToMarketplace={() => setActiveTab("marketplace")}
            onNavigateToAgronomy={() => setActiveTab("advisory-portal")}
            onTopUpCredits={() => setShowTopUpModal(true)}
            onActivateSubscription={() => setActiveTab("billing-centre")}
            onDismiss={() => setHideReadonlyBanner(true)}
          />
        )}
        {!isReadonly && credits !== null && credits < 50 && (
          <div className="bg-amber-400 text-slate-900 px-4 sm:px-8 py-1.5 text-xs font-bold font-mono text-center flex items-center justify-center gap-2 flex-shrink-0 animate-pulse">
            <AlertTriangle className="w-4 h-4" />
            <span>Warning: Your credit reserve is under 50. Please consider topping up soon.</span>
          </div>
        )}

        {/* Dynamic viewport panels scrollable frame */}
        <section className="flex-1 overflow-y-auto p-3 sm:p-4 md:p-6 lg:p-8 bg-slate-50">
          <AppModuleRenderer
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            hasReadPermission={hasReadPermission}
            hasWritePermission={hasWritePermission}
            isReadonly={isReadonly}
            currencySymbol={selectedCountry?.currencySymbol || "K"}
            isZambia={selectedCountry?.code === "ZM" || selectedCountry?.name === "Zambia"}
            currentRole={impersonation ? ((impersonation.targetActualRole as PredefinedRole) || "Farm Owner") : currentRole}
            userEmail={activeProfile?.email || userProfile?.email || ""}
            tenantId={activeProfile?.tenantId || activeProfile?.uid || userProfile?.tenantId || "TENANT-001"}
            adminClaimed={adminClaimed}
            adminClaimantEmail={adminClaimantEmail}
            userProfile={activeProfile || userProfile}
            setUserProfile={(updater: any) => {
              if (impersonation) {
                setImpersonation(prev => {
                  if (!prev) return null;
                  const currentTarget = prev.targetProfile || {};
                  const nextVal = typeof updater === "function" ? updater(currentTarget) : updater;
                  return {
                    ...prev,
                    targetProfile: nextVal
                  };
                });
              } else {
                setUserProfile(updater);
              }
            }}
            activeFarm={activeFarm}
            setActiveFarm={(farm: Farm) => {
              setFarms(prev => prev.map(f => f.id === farm.id ? farm : f));
            }}
            farms={farms}
            setFarms={setFarms}
            displayedAccounts={displayedAccounts}
            setAccounts={setAccounts}
            expenses={expenses}
            crops={crops}
            setCrops={setCrops}
            employees={employees}
            payslips={payslips}
            invoices={invoices}
            setInvoices={setInvoices}
            quotations={quotations}
            creditNotes={creditNotes}
            customers={customers}
            suppliers={suppliers}
            inventory={inventory}
            setInventory={setInventory}
            livestock={livestock}
            poultryBatches={poultry}
            fishBatches={fish}
            assets={assets}
            investments={investments}
            loans={loans}
            otherRevenues={otherRevenues}
            leaveRecords={leaveRecords}
            employeeAdvances={employeeAdvances}
            auditLogs={auditLogs}
            archiveRecords={archivedRecords}
            cashSales={cashSales}
            setCashSales={setCashSales}
            tasks={tasks}
            credits={credits}
            setCredits={setCredits}
            smsCredits={smsCredits}
            setSmsCredits={setSmsCredits}
            subscriptionTier={subscriptionTier}
            setSubscriptionTier={setSubscriptionTier}
            weatherAlerts={weatherAlerts}
            vendors={vendors}
            setVendors={setVendors}
            marketplaceProducts={marketplaceProducts}
            setMarketplaceProducts={setMarketplaceProducts}
            riders={riders}
            setRiders={setRiders}
            marketplaceOrders={marketplaceOrders}
            setMarketplaceOrders={setMarketplaceOrders}
            commissionPercent={commissionPercent}
            setCommissionPercent={setCommissionPercent}
            deliveryFeePerKm={deliveryFeePerKm}
            setDeliveryFeePerKm={setDeliveryFeePerKm}
            platformPackages={platformPackages}
            setPlatformPackages={setPlatformPackages}
            orchardTrees={orchardTrees}
            setOrchardTrees={setOrchardTrees}
            orchardNurseryBatches={orchardNurseryBatches}
            setOrchardNurseryBatches={setOrchardNurseryBatches}
            orchardActivities={orchardActivities}
            setOrchardActivities={setOrchardActivities}
            permissions={permissions}
            teamMembers={teamMembers}
            selectedCountry={selectedCountry}
            setSelectedCountry={setSelectedCountry}
            csvPreselectedModule={csvPreselectedModule}
            lipilaTransactions={lipilaTransactions}
            creditLedger={creditLedger}
            isSuperAdmin={isSuperAdmin}
            isSuperAdminSession={isSuperAdmin}
            isOnline={isOnline}
            workspaceMode={workspaceMode}
            setLipilaCheckout={setLipilaCheckout}
            handleAddAccount={handleAddAccount}
            handleAddExpense={handleAddExpense}
            handleAddSupplier={handleAddSupplier}
            handleAddCrop={handleAddCrop}
            handleEditCrop={handleEditCrop}
            handleUpdateMilestone={handleUpdateMilestone}
            handleUpdateCropStatus={handleUpdateCropStatus}
            handleDeleteCrop={handleDeleteCrop}
            handleAddEmployee={handleAddEmployee}
            handleBulkAddEmployees={handleBulkAddEmployees}
            handleUpdateEmployee={handleUpdateEmployee}
            handleDeleteEmployee={handleDeleteEmployee}
            handleRunPayroll={handleRunPayroll}
            handleAddLeaveRecord={handleAddLeaveRecord}
            handleArchiveLeaveRecord={handleArchiveLeaveRecord}
            handleAddEmployeeAdvance={handleAddEmployeeAdvance}
            handleRepayEmployeeAdvance={handleRepayEmployeeAdvance}
            handleArchiveEmployeeAdvance={handleArchiveEmployeeAdvance}
            handleAddInvoice={handleAddInvoice}
            handleAddCreditNote={handleAddCreditNote}
            handleAddQuotation={handleAddQuotation}
            handleMarkPaid={handleMarkPaid}
            handleConvertQuote={handleConvertQuote}
            handleAddCustomer={handleAddCustomer}
            handleAddLivestockRecord={handleAddLivestockRecord}
            handleUpdateLivestock={(record: LivestockRecord) => {
              setLivestock(prev => prev.map(l => l.id === record.id ? record : l));
            }}
            handleDeleteLivestockRecord={handleDeleteLivestockRecord}
            handleAddLivestockHealthEvent={handleAddLivestockHealthEvent}
            handleAddLivestockFeedingLog={handleAddLivestockFeedingLog}
            handleAddPoultry={handleAddPoultry}
            handleUpdatePoultryBatch={handleUpdatePoultryBatch}
            handleDeletePoultryBatch={handleDeletePoultryBatch}
            handleAddFishBatch={handleAddFishBatch}
            handleAddWaterReading={handleAddWaterReading}
            handleAddAsset={handleAddAsset}
            handleUpdateAsset={handleUpdateAsset}
            handleUpdateAssets={handleUpdateAssets}
            handleArchiveAsset={handleArchiveAsset}
            handleAddInvestment={handleAddInvestment}
            handleRealizeInvestment={handleRealizeInvestment}
            handleArchiveInvestment={handleArchiveInvestment}
            handleAddLoan={handleAddLoan}
            handleAddLoanRepayment={handleAddLoanRepayment}
            handleOffsetLoan={handleOffsetLoan}
            handleDeleteLoan={(id: string) => {
              setLoans(prev => prev.filter(l => l.id !== id));
            }}
            handleAddOtherRevenue={handleAddOtherRevenue}
            handleArchiveOtherRevenue={handleArchiveOtherRevenue}
            handleRestoreRecordFromArchive={handleRestoreRecordFromArchive}
            handlePermanentDeleteFromArchive={handlePermanentDeleteFromArchive}
            handleClearAuditLogs={() => setAuditLogs([])}
            handleUpdatePermission={handleUpdatePermission}
            handleAddTeamMember={handleAddTeamMember}
            handleRemoveTeamMember={handleRemoveTeamMember}
            handleChangeMemberRole={handleChangeMemberRole}
            handleToggleUserSuspension={handleToggleUserSuspension}
            handleUpdateTeamMember={handleUpdateTeamMember}
            handleChangeOwnPassword={handleChangeOwnPassword}
            handleSessionRoleChange={handleSessionRoleChange}
            handleRestoreBackup={handleRestoreBackup}
            handleClearDatabase={handleClearDatabase}
            handleSaveCloudWorkspace={handleSaveCloudWorkspace}
            handleStartImpersonation={handleStartImpersonation}
            handleLogout={handleLogout}
            handleGotoCsvImport={handleGotoCsvImport}
            handleUpdateActiveFarm={handleUpdateActiveFarm}
            handleAddTask={handleAddTask}
            handleEditTask={handleEditTask}
            handleDeleteTask={handleDeleteTask}
            handleToggleTaskComplete={handleToggleTaskComplete}
            handlePostVeterinaryServiceCharge={handlePostVeterinaryServiceCharge}
            handleAddLedgerEntryFromOfftaker={handleAddLedgerEntryFromOfftaker}
            showToast={showToast}
            writeAuditLog={writeAuditLog}
            addNotification={addNotification}
            setShowTopUpModal={setShowTopUpModal}
            setShowNewSaleModal={setShowNewSaleModal}
            setShowQuickLogLossModal={setShowQuickLogLossModal}
          />
        </section>
      </main>

      {/* FLOATING OVERLAYS & MODALS */}
      <AiChatbot />

      <NewSaleModal
        isOpen={showNewSaleModal}
        onClose={() => setShowNewSaleModal(false)}
        activeFarm={activeFarm}
        farms={farms}
        currencySymbol={selectedCountry?.currencySymbol || "K"}
        userEmail={userProfile?.email}
        tenantId={userProfile?.tenantId || "TENANT-001"}
        livestock={livestock}
        crops={crops}
        onSaleCreated={(sale) => {
          showToast("Sale recorded successfully", "success");
        }}
      />

      {/* TOP UP BUNDLE MODAL */}
      {showTopUpModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[9999] flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 text-white space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-sm text-white">Top Up Credit Reserve</h3>
              <button 
                type="button" 
                onClick={() => setShowTopUpModal(false)} 
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>
            <p className="text-xs text-slate-300">
              Select an in-app credit replenishment bundle for instant ledger automation and SMS dispatch.
            </p>
            <div className="space-y-2">
              {IN_APP_TOPUP_BUNDLES.map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => {
                    setShowTopUpModal(false);
                    setLipilaCheckout({
                      id: b.id,
                      name: b?.name || "Credit Bundle",
                      price: b.priceZMW,
                      creditsToAward: b.credits,
                      currency: "ZMW",
                      type: "topup",
                      description: `${b.credits} Credits for automated ledger & SMS operations`
                    });
                  }}
                  className="w-full flex justify-between items-center p-3 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition cursor-pointer text-xs"
                >
                  <span className="font-bold">{b?.name || "Credit Bundle"} ({b.credits} Credits)</span>
                  <span className="font-mono text-emerald-400 font-extrabold">ZK {b.priceZMW}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Single-Active-Session Takeover Modal */}
      <SessionTakeoverModal
        isOpen={isTakeoverModalOpen}
        info={takeoverInfo}
        onReclaimSession={handleReclaimSession}
        onSignOut={async () => {
          try {
            await signOut(auth);
          } catch (e) {
            console.error("Sign out error:", e);
          }
        }}
      />

      {/* Rejected Writes Reconciliation Queue Modal */}
      <RejectedWritesModal
        isOpen={isRejectedWritesModalOpen}
        onClose={() => setIsRejectedWritesModalOpen(false)}
        writes={rejectedWrites}
        showToast={showToast}
        onWritesUpdated={() => {
          const u = auth.currentUser;
          if (u) {
            sessionService.subscribeRejectedWrites(u.uid, (writes) => setRejectedWrites(writes));
          }
        }}
      />
    </div>
  );
}

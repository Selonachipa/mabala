/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CountryInfo {
  code: string;
  name: string;
  currency: string;
  symbol: string;
  flag: string;
  defaultTaxSystem: string;
}

export interface FarmLocation {
  lat: number;
  lng: number;
  source: "province_town_signup" | "pinpoint_map" | "gps_live";
  updatedAt?: string;
}

export interface Farm {
  id: string;
  name: string;
  tpin: string;
  vatNumber?: string;
  address: string;
  province?: string;
  district?: string;
  town?: string;
  location?: {
    province: string;
    district: string;
    lat?: number;
    lng?: number;
  };
  farmLocation?: FarmLocation;
  latitude?: number;
  longitude?: number;
  phone: string;
  email: string;
  financialYearStart: string;
  financialYearEnd: string;
  currency: string;
  currencySymbol: string;
  taxSystem: "VAT" | "Sales Tax" | "Turnover Tax" | "None";
  taxType?: string;
  customTaxName?: string;
  customTaxRate?: number;
  tenantId?: string;
  logo?: string;
  letterheadTitle?: string;
  letterheadSubtitle?: string;
  letterheadAddress?: string;
  createdAt?: string;
  createdBy?: string;
  createdByName?: string;
  isArchived?: boolean;
}

export type FarmNode = Farm;

export type AccountCategory = "Asset" | "Liability" | "Equity" | "Revenue" | "Expense";

export interface Account {
  code: string; // CoA Code e.g., '1010'
  name: string;
  category: AccountCategory;
  balance: number;
}

export interface JournalEntry {
  id: string;
  date: string;
  description: string;
  debitAccount: string;
  creditAccount: string;
  amount: number;
  module: string;
}

export type OrchardCostTaskType = "spraying" | "labour" | "pruning" | "fertilizer" | "irrigation" | "pest_control" | "equipment" | "other";
export type OrchardExpenseSourceModule = "orchard_task" | "manual_entry" | "payroll" | "agrodealer_purchase";

export type ExpenditureBlockType = "crop_cycle" | "livestock_pen" | "poultry_batch" | "orchard_block" | "aquaculture_pond" | "general_farm";

export interface ExpenseRow {
  category: string;
  description: string;
  quantity: number;
  unitPrice: number;
  amount: number;
  coaCode: string;
  // Expenditure Block Allocations (Crop Cycle, Poultry Batch, Livestock Pen, Orchard Block, Fish Pond)
  allocationType?: ExpenditureBlockType;
  cropCycleId?: string;
  cropBatchName?: string;
  livestockCohortId?: string;
  livestockName?: string;
  poultryBatchId?: string;
  poultryBatchName?: string;
  orchardBlockId?: string;
  orchardBlockName?: string;
  aquaculturePondId?: string;
  // Orchard Finance Linkage fields
  blockId?: string;
  treeGroupId?: string;
  costTaskType?: OrchardCostTaskType | string;
  sourceModule?: OrchardExpenseSourceModule | string;
  coaAccountId?: string;
  taskId?: string;
}

export interface ExpenseTransaction {
  id: string;
  supplierId: string;
  supplierName: string;
  date: string;
  taxSystem: string;
  taxAmount: number;
  subtotal: number;
  total: number;
  amount?: number;
  rows: ExpenseRow[];
  farmId?: string;
  tenantId?: string;
  hasPendingWrites?: boolean;
  _pendingSync?: boolean;
  // Expenditure Block Allocations
  allocationType?: ExpenditureBlockType;
  cropCycleId?: string;
  livestockCohortId?: string;
  poultryBatchId?: string;
  orchardBlockId?: string;
  aquaculturePondId?: string;
  // Orchard block attribution
  blockId?: string;
  costTaskType?: OrchardCostTaskType | string;
  sourceModule?: OrchardExpenseSourceModule | string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  tpin: string;
  category: string;
  notes?: string;
  farmId?: string;
  tenantId?: string;
}

export interface Customer {
  id: string;
  name: string;
  contact: string;
  address: string;
  phone: string;
  email: string;
  tpin?: string;
  farmId?: string;
  tenantId?: string;
}

export interface Milestone {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  isCompleted: boolean;
}

export interface YieldPricingTier {
  id: string;
  label: string; // e.g., "Grade A", "Grade B", "Grade C", "Small", "Medium", "Large", "Ungraded/Other"
  percentage: number; // e.g. 60 for 60% of expected yield
  pricePerUnit: number; // Price per unit or price per Kg
}

export interface PricingTierConfig {
  splitType: "Flat" | "Grade" | "Size"; // Flat single price vs Grade (A/B/C) vs Size (Small/Medium/Large)
  tiers: YieldPricingTier[];
}

export interface OrchardYearHarvestSchedule {
  yearNumber: number; // e.g. 1, 2, 3, ... N
  calendarYear: number; // e.g. 2026, 2027, ...
  expectedHarvestDate: string; // ISO date string e.g. "2027-04-15"
  lifecycleStage: "Juvenile" | "First Bearing" | "Moderate Production" | "Peak Production" | "Declining";
  yieldMultiplierPct: number; // e.g. 0% in Year 1, 40% in Year 2, 75% in Year 3, 100% in Year 4-15, 70% in Year 20
  projectedFruitsPerTree: number;
  projectedYieldKg: number;
  projectedRevenue: number;
  actualHarvestedKg?: number;
  actualRevenue?: number;
  isHarvestCompleted?: boolean;
}

export interface OrchardLabourLog {
  id: string;
  employeeId?: string;
  employeeName: string;
  date: string;
  activityType: "Pruning" | "Grafting" | "Spraying" | "Weeding" | "Harvesting" | "Irrigation" | "Canopy Management" | "Other";
  hoursWorked: number;
  hourlyRate: number;
  totalLaborCost: number;
  notes?: string;
}

export interface OrchardConfig {
  fruitType?: string;
  variety?: string;
  rootstock?: string;
  spacing?: string;
  plantingDate?: string;
  plantingYear?: number;
  spacingRowM?: number;
  spacingTreeM?: number;
  waterSource?: string;
  irrigationType?: string;
  soilType?: string;
  treeCount?: number;
  blockAreaHa?: number;
  
  // Enhanced Fruit Parameters
  treeLifespanYears?: number;
  firstBearingYears?: number;
  harvestsPerYear?: number;
  harvestMonth?: string;
  measuredInKgOrUnits?: "Kg" | "Units";
  harvestUnitName?: string;
  estimatedFruitsPerTreePerHarvest?: number;
  averageFruitWeightKg?: number;
  possibleLossesPct?: number;
  netSellableFruitsPerTree?: number;
  netSellableYieldPerTreeKg?: number;
  pricePerUnitOrKg?: number;
  expectedAnnualYieldKg?: number;
  expectedAnnualYieldUnits?: number;
  projectedAnnualRevenue?: number;
  lifetimeProjectedRevenue?: number;
  pricingTierConfig?: PricingTierConfig;
  multiYearHarvestSchedule?: OrchardYearHarvestSchedule[];
  labourLogs?: OrchardLabourLog[];
}

export interface CropCycle {
  id: string;
  cropType: string;
  cropName?: string;
  variety?: string;
  maturityDays?: number;
  plantingDate: string;
  expectedHarvestDate: string;
  fieldBlock: string;
  areaHectares: number;
  expectedYieldKg: number;
  projectedYield?: number;
  projectedYieldUnit?: string;
  actualYieldKg?: number;
  status: "Planning" | "Active" | "Harvested" | "Sold" | "Nursery" | "Transplanted" | "Juvenile" | "Flowering" | "Fruiting" | "Peak Production" | "Declining" | "Removed" | "Dead";
  stage?: string;
  milestones: Milestone[];
  expensesLinked: number;
  revenueLinked: number;
  farmId: string;
  tenantId?: string;
  cycleType?: "annual" | "perennial_orchard";
  orchard?: OrchardConfig;
  
  // Custom enhanced fields for Plant Population, Survival & Revenue Forecasting engine
  plantingMethod?: "Field" | "Bed";
  measuredInKgOrUnits?: "Kg" | "Units";
  harvestUnitName?: string; // (e.g. Cob, Head, Bulb, Plant, Fruit etc.)
  expectedSellingPricePerUnit?: number;
  expectedSellingPricePerKg?: number;
  pricingTierConfig?: PricingTierConfig; // Support for Grade/Size-Split Pricing Tiers
  plantSpacingWithinRow?: number; // cm
  rowSpacing?: number; // cm
  bedWidth?: number; // meters
  bedLength?: number; // meters
  numberOfBeds?: number;
  plantsPerBed?: number; // Auto calculated
  totalExpectedPlantPopulation?: number; // Auto calculated
  expectedSurvivalRate?: number; // %
  expectedHarvestRate?: number; // %
  avgHarvestUnitsPerPlant?: number;
  averageWeightPerPlantKg?: number;
  expectedRevenueProjection?: number; // Auto calculated
  actualRevenueCollected?: number; // For actual vs planned variance
  actualHarvestUnits?: number; // Actual harvested units
  notes?: string;

  // Orchard & Tree Management <-> Finance & Credit Linkage fields
  projectedRevenue?: number; // Block projected revenue target
  actualRevenueToDate?: number; // Running total of fruit sales, server-maintained
  actualExpensesToDate?: number; // Running total of orchard costs, server-maintained
  netProfitToDate?: number; // actualRevenueToDate - actualExpensesToDate
  revenueVariancePct?: number; // (actualRevenueToDate - projectedRevenue) / projectedRevenue
  lastRevenuePostedAt?: string; // ISO timestamp
  lastExpensePostedAt?: string; // ISO timestamp
}

export type EmploymentStatus = "Permanent" | "Casual Worker" | "Part Time" | "Probation";
export type MaritalStatus = "Single" | "Married" | "Divorced" | "Widowed" | "Separated";
export type StaffAdjustmentType = "Salary Increase" | "Promoted" | "Terminated" | "Resigned" | "Allowance Adjustment" | "Demotion" | "Other";

export interface NextOfKin {
  name: string;
  contactNumber: string;
  relationship: string;
}

export type PaymentChannel = "mobile_money";
export type MobileMoneyProvider = "airtel" | "mtn" | "zamtel";

export interface Employee {
  id: string;
  name: string;
  role: string;
  department?: string;
  contractRate: number; // basic monthly rate
  housingAllowance?: number;
  transportAllowance?: number;
  medicalAllowance?: number;
  fieldAllowance?: number;
  otherAllowance?: number;
  grossSalary?: number;
  netSalary?: number;
  napsaNumber?: string;
  nhimaNumber?: string;
  nrcNumber?: string;
  mobileNumber?: string;
  email?: string;
  
  // Payment channel enforcement
  paymentChannel?: PaymentChannel;
  mobileMoneyProvider?: MobileMoneyProvider;
  mobileMoneyNumber?: string;
  mobileMoneyVerified?: boolean;
  mobileMoneyVerifiedAt?: string;
  verifiedBy?: string;
  verifiedAccountName?: string;

  paymentMethod?: "Bank Transfer" | "Airtel Money" | "MTN MoMo" | "Zamtel Money" | "JabuPay" | "Other Wallets" | "Cash" | "Mobile Money";
  bankName?: string;
  bankAccount?: string;
  bankBranch?: string;
  walletNumber?: string;
  country: string;
  status: "Active" | "Terminated" | "Resigned" | "Promoted" | "Suspended" | "On Leave";

  // Employment & Contract Details
  employmentStatus?: EmploymentStatus;
  contractType?: string;
  contractStartDate?: string;
  contractEndDate?: string;
  contractNotes?: string;

  // Personal & Kin Details
  nextOfKinName?: string;
  nextOfKinContact?: string;
  nextOfKinRelationship?: string;
  nextOfKin?: NextOfKin;

  maritalStatus?: MaritalStatus;
  dateOfBirth?: string; // YYYY-MM-DD

  farmId?: string;
  tenantId?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface PayslipDeliveryLogItem {
  channel: "email" | "whatsapp" | "download" | "print";
  sentAt: string;
  target: string;
  status?: "sent" | "failed" | "printed" | "downloaded";
}

export interface Payslip {
  id: string;
  runId?: string;
  employeeId: string;
  employeeName: string;
  month: string; // YYYY-MM
  period?: { month: number; year: number } | string;
  basicSalary: number;
  housingAllowance: number;
  transportAllowance: number;
  otherAllowance: number;
  grossSalary: number;
  paye: number;
  napsaEmployee: number;
  napsaEmployer: number;
  nhimaEmployee: number;
  nhimaEmployer: number;
  wcfEmployer: number;
  skillsLevyEmployer: number;
  netPay: number;
  adjustmentReason?: string;
  paymentMethod?: string;
  mobileMoneyNumber?: string;
  mobileMoneyProvider?: string;
  lipilaTransactionRef?: string;
  lipilaFee?: number;
  platformFlatFee?: number;
  totalDeducted?: number;
  pdfStorageRef?: string;
  deliveryLog?: PayslipDeliveryLogItem[];
  walletNumber?: string;
  bankName?: string;
  bankAccount?: string;
  bankBranch?: string;
  farmId?: string;
  tenantId?: string;
  createdAt?: string;
}

export interface PayrollRunLine {
  employeeId: string;
  employeeName: string;
  mobileMoneyNumber: string;
  mobileMoneyProvider: "airtel" | "mtn" | "zamtel" | string;
  grossSalary: number;
  netSalary: number;
  lipilaFee: number;
  platformFlatFee: number;
  totalDeducted: number;
  lipilaTransactionRef?: string;
  status: "pending" | "sent" | "success" | "failed";
  failureReason?: string;
  confirmedAt?: string;
}

export interface PayrollRunTotals {
  totalGrossSalary?: number;
  totalNetSalary: number;
  totalLipilaFees: number;
  totalPlatformFees: number;
  grandTotal: number;
}

export interface PayrollRun {
  id: string;
  tenantId: string;
  period: { month: number; year: number } | string;
  periodLabel: string;
  status: "draft" | "insufficient_balance" | "processing" | "completed" | "failed" | "partially_failed";
  initiatedBy: string;
  initiatedAt: string;
  completedAt?: string;
  lines: PayrollRunLine[];
  totals: PayrollRunTotals;
  farmBalanceBeforeRun: number;
  farmBalanceAfterRun: number;
  shortfall?: number;
  blockedReason?: string;
  reconciliationHoldingAmount?: number;
  reportFileRef?: string;
}

export interface InvalidEmployeeRecord {
  employeeId: string;
  name: string;
  reason: string;
  mobileMoneyNumber?: string;
  provider?: string;
}

export interface PayrollValidationResult {
  eligible: boolean;
  totalActiveCount: number;
  validCount: number;
  invalidEmployees: InvalidEmployeeRecord[];
}

export interface EmployeeSalaryAdjustment {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string;
  month: string;
  adjustmentType?: StaffAdjustmentType;
  basicBefore: number;
  basicAfter: number;
  allowancesBefore: number;
  allowancesAfter: number;
  statusBefore?: string;
  statusAfter?: string;
  newRole?: string;
  reason: string;
}

export interface StatutoryPaymentMonth {
  id: string;
  month: string;
  type: "NAPSA" | "NHIMA" | "PAYE" | "WCF" | "Skills Levy";
  employeeContribution: number;
  employerContribution: number;
  totalPaid: number;
  status: "Pending" | "Paid";
  paymentDate?: string;
  receiptRef?: string;
}

export interface InvoiceLine {
  description: string;
  quantity: number;
  unitPrice: number;
  amount: number;
  // Production entity linkage
  blockId?: string;
  treeGroupId?: string;
  cropId?: string;
  cropCycleRef?: string;
  animalTagId?: string;
  livestockId?: string;
  poultryBatchId?: string;
  productType?: "fruit" | "crop" | "livestock" | "poultry" | "input" | "other" | string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string;
  dueDate: string;
  customerName: string;
  customerTpin?: string;
  taxAmount: number;
  subtotal: number;
  total: number;
  lines: InvoiceLine[];
  status: string; // Unpaid, Paid, Overdue, or Cancelled by Credit Note #___
  coaDebit: string; // usually 1100
  coaCredit: string; // usually 4000 / 4100 / 4200 / 4300
  farmId: string;
  tenantId?: string;
  paidAmount?: number;
  cropId?: string;
  sourceType?: 'direct' | 'from_storage' | 'orchard' | 'crop_harvest' | 'livestock' | 'poultry';
  storageLotId?: string;
  cropCycleId?: string;
  blockId?: string;
  treeGroupId?: string;
  cropCycleRef?: string;
  animalTagId?: string;
  livestockId?: string;
  poultryBatchId?: string;
  productType?: "fruit" | "crop" | "livestock" | "poultry" | "input" | "other" | string;
  postSaleLotBalance?: number;
  paymentDate?: string;
  paidAt?: string;
  farmName?: string;
}

export interface CreditNote {
  id: string;
  creditNoteNumber: string;
  invoiceId: string; // Ties to a specific invoice
  invoiceNumber: string;
  date: string;
  customerName: string;
  subtotal: number; // Reversal subtotal
  taxAmount: number; // Reversal tax
  total: number; // Reversal total
  lines: InvoiceLine[]; // Lines of reversal (usually copy of invoice lines)
  reason: string;
  coaDebit: string; // originally credited revenue account, to be debited
  coaCredit: string; // originally debited receivables 1100, to be credited
  farmId: string;
}

export interface Quotation {
  id: string;
  quoteNumber: string;
  date: string;
  validityPeriodDays: number;
  customerName: string;
  subtotal: number;
  taxAmount: number;
  total: number;
  lines: InvoiceLine[];
  status: "Draft" | "Accepted" | "Rejected";
  farmId: string;
}

export interface CashSale {
  id: string;
  date: string;
  description: string;
  customer: string;
  amount: number;
  paymentMethod: "Cash" | "Mobile Money" | "Bank Transfer" | "Card" | "Cheque" | string;
  coaDebit: string;
  coaCredit: string;
  farmId: string;
  tenantId?: string;
  sourceType?: 'direct' | 'from_storage' | 'livestock' | 'produce' | 'orchard' | 'crop_harvest' | 'poultry' | 'other';
  storageLotId?: string;
  cropId?: string;
  cropCycleId?: string;
  blockId?: string;
  treeGroupId?: string;
  cropCycleRef?: string;
  poultryBatchId?: string;
  productType?: "fruit" | "crop" | "livestock" | "poultry" | "input" | "other" | string;
  postSaleLotBalance?: number;
  // Livestock sale metadata
  animalTagId?: string;
  animalSpecies?: string;
  animalBreed?: string;
  animalWeightKg?: number;
  pricePerKg?: number;
  headcount?: number;
  // Financial & Receipt itemization
  subtotal?: number;
  taxRate?: number;
  taxAmount?: number;
  isTaxExempt?: boolean;
  customerTpin?: string;
  customerPhone?: string;
  customerAddress?: string;
  cashierName?: string;
  receiptNumber?: string;
  notes?: string;
}

export interface Loan {
  id: string;
  recipient: string;
  principal: number;
  interestRate: number; // e.g. 5%
  startDate: string;
  endDate: string;
  outstandingBalance: number;
  type: "Issued" | "Received";
  farmId: string;
}

export interface Investment {
  id: string;
  description: string;
  amount: number;
  date: string;
  institution: string;
  investmentType: "Government Bond" | "Treasury Bill" | "Mutual Fund" | "Other";
  rate: number; // e.g. 10 (%)
  status: "Active" | "Matured" | "Realized";
  farmId: string;
}

export interface LivestockRecord {
  id: string;
  type: "Cattle" | "Goats" | "Sheep" | "Pigs" | "Other" | string;
  species: string;
  breed: string;
  subBreed?: string;
  tagId: string;
  gender: "Male" | "Female";
  acquisitionType: "Bought" | "Birthed" | "Gifted" | string;
  source: string;
  dateAcquired: string;
  purchasePrice: number;
  currentValue: number;
  assetClassification?: BiologicalAssetTier;
  assetTypeCategory?: "Current" | "Non-Current";
  glAccountCode?: string;
  assetRegisterId?: string;
  name?: string;
  category?: string;
  currentWeight?: number;
  weightKg?: number;
  location?: string;
  estimatedValue?: number;
  birthDate?: string;
  registrationDate?: string;
  registrationWeight?: number;
  initialValuation?: number;
  estimatedDailyGain?: number;
  lastWeighedDate?: string;
  deletionReason?: string;
  deletedBy?: string;
  deletedAt?: string;
  creditNoteNumber?: string;
  healthEvents: { date: string; type: string; details: string; cost: number }[];
  feedingLogs: { date: string; feedType: string; quantityKg: number }[];
  status: "Active" | "Sold" | "Deceased" | "Dead" | "Slaughtered" | "Missing" | "Transferred" | "Quarantined" | string;
  farmId: string;
  tenantId?: string;
  dob?: string;
  age?: string;
  color?: string;
  weight?: number;
  estimatedMarketValue?: number;
  insuranceValue?: number;
  weightTrend?: any;
  appraisalValue?: number;
  rfid?: string;
  qrCode?: string;
  barcode?: string;
  microchip?: string;
  govRegistration?: string;
  photos?: {
    profile?: string;
    medical?: string[];
    injury?: string[];
    sale?: string[];
  };
  documents?: {
    id: string;
    name: string;
    url: string;
    type: string;
    dateAdded: string;
  }[];
  healthScore?: number;
  productivity?: string;
  sire?: string;
  dam?: string;
  breedingSuccessRate?: number;
  isDairy?: boolean;
  isCastrated?: boolean;
  breedingStatus?: string;
  productionStage?: string;
  damTagId?: string;
  damBreed?: string;
  sireTagId?: string;
  motherId?: string;
  birthWeightKg?: number;
  penId?: string;
  penName?: string;
  totalFeedCost?: number;
  totalMedicationCost?: number;
  parityCount?: number;
  growthStage?: string;
  litterId?: string;
  farrowingId?: string;
  growthHistory?: { date: string; stage: string; weightKg: number; valuationAmount?: number; notes?: string }[];
  medicationRecords?: {
    id: string;
    drugName: string;
    dateAdministered: string;
    dosage: string;
    route?: string;
    cost: number;
    administeredBy: string;
    withdrawalExpiresDate?: string;
    activeWithdrawal?: boolean;
    reason?: string;
    penId?: string;
    penName?: string;
  }[];
  feedingRecords?: {
    id: string;
    date: string;
    feedType: string;
    quantityKg: number;
    cost: number;
    unitPrice?: number;
    penId?: string;
    penName?: string;
  }[];
  mortalityReason?: string;
  disposalType?: "Sale" | "Mortality" | "Slaughter" | "Transfer" | "Active";
  disposalDate?: string;
  currentStageId?: string;
  currentStageName?: string;
  currentTemplateId?: string;
  currentTemplateName?: string;
  currentStageEntryDate?: string;
  stageEntryWeight?: number;
  currentWeightSource?: "INDIVIDUAL" | "PEN_AVERAGE" | "ESTIMATED" | "REGISTRATION";
  progressionHold?: boolean;
  progressionHoldReason?: string;
  progressionHoldDate?: string;
  isUnderweight?: boolean;
  underweightVariancePct?: number;
}

// ============================================================================
// AUTOMATED LIVESTOCK VALUATION & STAGE PROGRESSION TYPES (§4, §11, §18, §54)
// ============================================================================

export type StageTransitionMode = 
  | "WEIGHT_OR_TIME" 
  | "WEIGHT_AND_TIME" 
  | "TIME_ONLY" 
  | "WEIGHT_ONLY";

export type ProgressionTriggerType = 
  | "WEIGHT" 
  | "TIME" 
  | "WEIGHT_AND_TIME" 
  | "MANUAL" 
  | "SYSTEM_CORRECTION"
  | "NONE";

export interface LivestockStage {
  id: string;
  templateId: string;
  sequence: number;
  name: string;
  durationValue: number;
  durationUnit: "DAYS" | "WEEKS";
  targetWeight: number; // kg
  targetWeightUnit: "kg";
  valuation: number; // in currency (e.g. ZMW)
  currency: string;
  transitionMode: StageTransitionMode;
  automaticProgression: boolean;
  exceptionThresholdPct?: number; // e.g. 10 (%)
  nextStageId?: string;
  nextStageName?: string;
  isFinalStage: boolean;
  active: boolean;
  notes?: string;
}

export interface LivestockStageTemplate {
  id: string;
  tenantId: string;
  species: string;
  breed?: string;
  name: string;
  version: number;
  effectiveFrom: string;
  effectiveTo?: string;
  status: "Active" | "Draft" | "Archived";
  isDefault?: boolean;
  stages: LivestockStage[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface LivestockWeightRecord {
  id: string;
  tenantId: string;
  animalId?: string;
  tagNumber?: string;
  penId?: string;
  penName?: string;
  measurementType: "INDIVIDUAL" | "PEN_AVERAGE";
  weight: number;
  headCount?: number;
  unit: "kg";
  measurementDate: string;
  entryDate: string;
  enteredBy: string;
  source: "MANUAL_SCALE" | "PEN_BULK" | "AUTOMATED" | "DEVICE";
  sourceRecordId?: string;
  supersedesWeightRecordId?: string;
  isAuthoritative: boolean;
  isStale?: boolean;
  notes?: string;
  createdAt: string;
}

export interface StageTransitionRecord {
  id: string;
  tenantId: string;
  animalId: string;
  tagNumber: string;
  species: string;
  fromStageId: string;
  fromStageName: string;
  toStageId: string;
  toStageName: string;
  fromValuation: number;
  toValuation: number;
  valuationDelta: number;
  fromStageEntryDate: string;
  transitionDate: string;
  triggerType: ProgressionTriggerType;
  triggerWeight: number;
  targetWeight: number;
  daysInStage: number;
  targetDurationDays: number;
  weightVarianceKg: number;
  weightVariancePct: number;
  isUnderweight: boolean;
  isAutomatic: boolean;
  isManual: boolean;
  actor: string;
  reason?: string;
  configurationVersion: number;
  accountingEventId: string;
  status: "COMPLETED" | "PENDING_ACCOUNTING" | "FAILED";
  createdAt: string;
}

export interface BiologicalValuationRecord {
  id: string;
  tenantId: string;
  animalId: string;
  tagNumber: string;
  species: string;
  previousValue: number;
  newValue: number;
  valuationChange: number;
  stageName: string;
  valuationDate: string;
  triggerType: string;
  sourceEventId: string;
  accountingEventId: string;
  status: "RECORDED" | "POSTED_TO_GL" | "ADJUSTED";
  createdAt: string;
}

export interface LivestockAccountingEvent {
  id: string;
  tenantId: string;
  sourceModule: "LIVESTOCK_PROGRESSION";
  sourceEventId: string;
  animalId: string;
  tagNumber: string;
  eventType: "INITIAL_RECOGNITION" | "STAGE_REVALUATION_GAIN" | "STAGE_REVALUATION_LOSS" | "MANUAL_REVALUATION_ADJUSTMENT";
  debitAccount: string;
  creditAccount: string;
  amount: number;
  currency: string;
  postingDate: string;
  status: "POSTED" | "PENDING" | "FAILED" | "REQUIRES_REVIEW";
  ledgerTransactionId?: string;
  idempotencyKey: string;
  createdAt: string;
  postedAt?: string;
  failureReason?: string;
}

export interface ProgressionEligibilityResult {
  animalId: string;
  tagNumber: string;
  species: string;
  currentStageId?: string;
  currentStageName?: string;
  nextStageId?: string;
  nextStageName?: string;
  nextStageValuation?: number;
  currentValuation?: number;
  currentWeight?: number;
  targetWeight?: number;
  daysInStage: number;
  targetDays: number;
  stageEntryDate: string;
  transitionMode: StageTransitionMode;
  weightReached: boolean;
  timeReached: boolean;
  eligible: boolean;
  trigger: ProgressionTriggerType | "NONE";
  isUnderweight: boolean;
  weightVarianceKg: number;
  weightVariancePct: number;
  isHeld: boolean;
  holdReason?: string;
  isFinalStage: boolean;
  isWeightStale: boolean;
  weightSource?: string;
  lastWeighedDate?: string;
  statusText: string;
}

export interface LivestockReconciliationReport {
  tenantId: string;
  generatedAt: string;
  totalActiveAnimals: number;
  animalRegistryTotalValue: number;
  biologicalAssetRegisterValue: number;
  generalLedgerControlBalance: number;
  discrepancyAmount: number;
  isBalanced: boolean;
  unpostedEventsCount: number;
  exceptions: {
    animalId: string;
    tagNumber: string;
    issue: string;
    registryValue: number;
    expectedValue: number;
    delta: number;
  }[];
}

export interface PenCohort {
  id: string;
  name: string;
  species: string;
  penType: "General" | "Weaners" | "Growers" | "Finisher / Feedlot" | "Maternity / Farrowing" | "Nursery" | "Quarantine / Hospital" | "Pasture / Paddock" | "Breeding Stud";
  capacity: number;
  currentHeadcount: number;
  totalFeedCost: number;
  totalMedicationCost: number;
  notes?: string;
  farmId?: string;
}

export interface LivestockFeedCostLog {
  id: string;
  date: string;
  targetType: "Pen" | "Animal";
  penId?: string;
  penName?: string;
  animalTagId?: string;
  animalSpecies?: string;
  feedType: string;
  quantityKg: number;
  unitCostPerKg: number;
  totalCost: number;
  headcountAllocated: number;
  costPerAnimal: number;
  loggedBy?: string;
  notes?: string;
}

export interface LivestockMedicationCostLog {
  id: string;
  date: string;
  targetType: "Pen" | "Animal";
  penId?: string;
  penName?: string;
  animalTagId?: string;
  animalSpecies?: string;
  drugName: string;
  type: "Vaccine" | "Dewormer" | "Antibiotic" | "Vitamin/Supplement" | "Treatment" | "Other";
  dosage: string;
  route: "Injection" | "Oral Drench" | "Topical Pour-On" | "Feed Additive" | "Water Soluble" | "Other";
  totalCost: number;
  headcountAllocated: number;
  costPerAnimal: number;
  administeredBy: string;
  withdrawalDays: number;
  withdrawalExpiresDate?: string;
  reason?: string;
  batchNumber?: string;
}

export interface StockHarvestRecord {
  id: string;
  itemType: "Crop" | "Livestock" | "Poultry" | "Fish";
  name: string; // e.g. "Maize", "Goats"
  quantity: number;
  unit: string;
  harvestDate: string;
  storageLocation: string;
  marketPrice: number;
  sellingPrice?: number;
  status: "In Stock" | "Sold";
}

export interface InventoryItem {
  id: string;
  name: string;
  category: "Fertilizer" | "Seeds" | "Chemicals" | "Tools" | "Equipment" | "Feed" | "Other";
  quantity: number;
  unit: string;
  unitCost: number;
  totalValue: number;
  storageLocation: string;
  lowStockAlertLevel: number;
  status?: "In Stock" | "Low Stock" | "Out of Stock" | "Archived" | "Reserved";
  archived?: boolean;
  farmId?: string;
  tenantId?: string;
}

export interface InventoryTransfer {
  id: string;
  date: string;
  name: string;
  quantity: number;
  source: string;
  destination: string;
  authorizedBy: string;
}

// 10. Poultry
export interface PoultryFeedLog {
  date: string;
  feedType: string;
  quantityKg: number;
  cost: number;
  fedBy: string;
  formulaUsed?: string;
  stageId?: string;
}

export interface VaccinationRecord {
  id?: string;
  ageDay: number;
  vaccine: string;
  diseaseTarget: string;
  route: string;
  isOverdue: boolean;
  status: "Pending" | "Completed";
  dueDate?: string;
  dateAdministered?: string;
  brandName?: string;
  lotNumber?: string;
  dosePerBird?: string;
  birdsVaccinated?: number;
  administeredBy?: string;
  completedOnTime?: boolean;
}

export interface PoultryHealthEvent {
  id: string;
  date: string;
  birdsAffected: number;
  symptoms: string;
  preliminaryDiagnosis: string;
  severity: "Mild" | "Moderate" | "Severe";
  status: "Resolved" | "Ongoing" | "Resulted in Mortality";
  treatmentDrug?: string;
  activeIngredient?: string;
  dosage?: string; // mg/kg or ml/L
  route?: string;
  durationDays?: number;
  withholdingPeriodDays?: number;
  withholdingCloseDate?: string;
  treatmentCost?: number;
  linkedMortalityCount?: number;
  notes?: string;
}

export interface MedicationRegisterItem {
  id: string;
  brandName: string;
  activeIngredient: string;
  dosageGuide: string;
  withdrawalPeriodDays: number;
  routeOfAdmin: string;
  category: "Antibiotic" | "Dewormer" | "Coccidiostat" | "Vitamin/Supplement" | "Other";
  indicatedFor: string;
  unitCost: number;
}


export interface DefaultVaccineScheduleItem {
  id: string;
  age: string;
  ageInDays: number;
  vaccine: string;
  diseaseTarget: string;
  route: string;
  birdType: string; // e.g. "Broiler/Layer" | "Layer only" | "Broiler only" | "Swine / Pigs" | "Gilt / Sow" | "Boar"
  species?: string; // e.g. "Poultry" | "Swine" | "Cattle" | "Goats"
  booster: string;
}

export interface EggCollection {
  date: string;
  totalCollected: number;
  gradeA: number;
  gradeB: number;
  broken: number;
  dirty: number;
  hatching?: number; // set aside for hatching
  traysCollected?: number; // trays collected tracking
}

export interface EggSale {
  id: string;
  date: string;
  customerName: string;
  sellUnit: "tray" | "dozen" | "egg";
  quantity: number;
  pricePerUnit: number;
  totalEggs: number;
  totalRevenue: number;
  traysSold?: number; // trays sold tracking
}

export interface PoultryBatch {
  id: string;
  tenantId?: string;
  batchId: string; // generated e.g. BRO-2026-001
  batchName: string;
  hasPendingWrites?: boolean;
  _pendingSync?: boolean;
  birdType: "Broilers (Meat)" | "Layers (Eggs)" | "Ducks" | "Turkeys" | "Guinea Fowl" | "Indigenous";
  breed: string;
  productionSystem?: string; // e.g. Free-range tracking, seasonal, pekin duck meat production
  currentStageId?: string; // "brooding" | "grower" | "finisher" | "developer" | "layer_production" | "breeder"
  accomplishedChecklist?: string[]; // strings like "brooding:req-0" etc.
  unitAcquisitionCost?: number; // Cost per bird (for initial double-entry capital tracking)
  transportCost?: number; // Added for initialization transport cost logs
  brooderSetupCost?: number; // Added for initialization brooder setup cost logs
  labourHours?: number; // Estimated cumulative labour hours
  labourRatePerHour?: number; // Rate per hour for labour (default to ZK rate or equivalent)
  utilityCost?: number; // Accumulated energy, water and gas utilities
  shedDepreciation?: number; // Allocated building or machinery depreciation
  notes?: string; // Customizable description notes for templates and duplicates
  targetStage?: string; // Target final stage e.g. "Finishing" or "Laying"
  quantity: number;
  currentCount: number;
  sourceSupplier: string;
  arrivalDate: string;
  assignedShed: string;
  status: "PLANNED" | "ACTIVE > BROODING" | "ACTIVE > GROWING" | "ACTIVE > FINISHING" | "ACTIVE > LAYING" | "PARTIAL SALE" | "COMPLETED" | "CLOSED";
  currentBatchValuation?: number;
  currentHeadcount?: number;
  currentMarketPricePerBird?: number;
  assetClassification?: BiologicalAssetTier;
  assetTypeCategory?: "Current" | "Non-Current";
  glAccountCode?: string;
  assetRegisterId?: string;
  feedLogs: PoultryFeedLog[];
  feedStockAllocated?: number;
  weightSamples?: { date: string; averageWeightG: number; remarks?: string; sampleSize?: number; uniformityPct?: number }[];
  vaccinationCalendar: VaccinationRecord[];
  eggCollections: EggCollection[];
  eggSales?: EggSale[];
  mortalityLogs: { 
    date: string; 
    count: number; 
    cause: string; 
    probableCauseCategory?: "feed" | "disease" | "predator" | "unknown"; 
    disposalMethod?: string;
  }[];
  salesLogs: { 
    id?: string;
    date: string; 
    quantity: number; 
    amount: number; 
    pricePerBird: number;
    customerName?: string;
    paymentMethod?: string;
    chargeType?: "PER_BIRD" | "PER_KG";
    averageWeightKg?: number;
    pricePerKg?: number;
    dressingPercentage?: number;
    grossMarginPerBird?: number;
  }[];
  medications: { date: string; drugName: string; dosage: string; cost: number; withholdingCloseDate?: string }[];
  healthEvents?: PoultryHealthEvent[];
  mortalityThresholdPct?: number;
  farmId: string;
}

// 11. Aquaculture
export interface WaterQualityReading {
  date: string;
  pH: number;
  doLevel: number; // dissolved oxygen
  temp: number;
  ammonia: number;
  nitrite: number;
}

export interface GrowthSample {
  date: string;
  sampleSize: number;
  totalWeightG: number;
  avgWeightG: number;
  uniformityPct: number;
}

export interface FishBatch {
  id: string; // ULID
  batchId: string;
  species: string;
  strain: string;
  productionSystem: "Pond" | "Cage" | "Tank" | "Polyculture";
  pondName: string;
  stockingQuantity: number;
  currentFishCount: number;
  averageWeightStockingG: number;
  targetMarketWeightG: number;
  expectedHarvestDate: string;
  assetClassification?: BiologicalAssetTier;
  assetTypeCategory?: "Current" | "Non-Current";
  glAccountCode?: string;
  assetRegisterId?: string;
  status: "Planned" | "Stocked" | "Grow-Out" | "Pre-Harvest" | "Harvested" | "Closed";
  feedLogs: { date: string; quantityKg: number; cost: number; fedBy: string; brand: string }[];
  weightSamplings: GrowthSample[];
  waterReadings: WaterQualityReading[];
  mortalityLogs: { date: string; count: number; cause: string }[];
  harvests: { date: string; quantityKg: number; avgWeightG: number; grade: string; processing: string }[];
  sales: { date: string; quantityKg: number; pricePerKg: number; totalSales: number; form: string }[];
  waterInterventions: { date: string; action: string; cost: number }[];
  medications: { date: string; name: string; activeIngredient: string; dosage: string; withdrawalDays: number; cost: number; dateGiven: string }[];
  farmId: string;
}

export interface AdCampaign {
  id: string;
  advertiserName: string;
  campaignName: string;
  adType: "CPM" | "CPC" | "Flat Rate";
  creativeUrl?: string;
  creativeUrlText: string;
  destinationUrl: string;
  views: number;
  clicks: number;
  isActive: boolean;
  placement: "banner" | "sidebar" | "interstitial";
}

export interface AppConfig {
  emailContact: string;
  phoneContact: string;
  addressContact: string;
  socialTwitter: string;
  socialFacebook: string;
}

export type PredefinedRole = "Super Admin" | "Platform Administrator" | "Farm Owner" | "Accountant" | "Farm Worker" | "Farm Manager" | "Veterinary Doctor" | "Agro-Vet Specialist" | "Farm Admin" | "Manager" | "Viewer" | "Farmer" | "partner" | "Agro Dealer" | "Institution Supplier" | "agro_dealer" | "institution_supplier" | "Offtaker" | "offtaker" | "Mabala Partner" | "mabala_partner" | "Agronomist" | "agronomist";

export interface AdvisoryConsultation {
  id: string;
  farmId: string;
  farmName: string;
  farmerName: string;
  farmerPhone?: string;
  agronomistName?: string;
  agronomistId?: string;
  date: string;
  category: "Pest & Disease Outbreak" | "Soil Fertility & Fertilizer" | "Water Quality & Irrigation" | "Plant Population & Yield" | "General Agronomy";
  cropType: string;
  fieldBlock?: string;
  symptomsDescription: string;
  severity: "Low" | "Medium" | "High" | "Critical";
  status: "Open" | "In Analysis" | "Prescribed" | "Resolved";
  diagnosisNotes?: string;
  prescription?: {
    productName: string;
    activeIngredient: string;
    dosage: string;
    applicationMethod: string;
    withdrawalPeriodDays: number;
    safetyInstructions: string;
  };
  soilTest?: {
    ph: number;
    nitrogenPpm: number;
    phosphorusPpm: number;
    potassiumPpm: number;
    organicMatterPercent?: number;
    recommendation: string;
  };
  scheduledVisitDate?: string;
  timeSlot?: string;
  visitFee?: number;
  rating?: number;
  ratingComment?: string;
  ratedAt?: string;
  smsReminderSent?: boolean;
  smsReminderSentAt?: string;
  platformFeeShare?: number;
  agronomistEarningsShare?: number;
  createdAt: string;
  updatedAt: string;
  tenantId?: string;
}

export interface AgronomistAvailabilitySlot {
  id: string;
  agronomistId: string;
  agronomistName: string;
  specialistType?: "Agronomist" | "Veterinary Surgeon (Vet)";
  specialty?: string;
  date: string;
  timeSlot: string;
  status: "Available" | "Booked" | "Blocked";
  visitFee: number;
  locationDistrict?: string;
  bookedByFarmerId?: string;
  bookedByFarmerName?: string;
  bookedByFarmName?: string;
  consultationId?: string;
}

export interface AgronomistSmsReminderSettings {
  enabled: boolean;
  walletBalance: number;
  smsTemplate: string;
  autoDeductOnSchedule: boolean;
  totalRemindersSent: number;
}

export interface AgronomicTaskTemplate {
  id: string;
  title: string;
  cropType: string;
  targetStage: string;
  category: "Crop Protection" | "Soil & Fertilizer" | "Irrigation & Water" | "Harvest & Post-Harvest" | "General Practice";
  description: string;
  estimatedHours: number;
  priority: "Normal" | "High" | "Urgent";
  steps: {
    stepNumber: number;
    title: string;
    instructions: string;
    triggerDaysOffset: number;
    requiredInputs?: string;
  }[];
  createdBy: string;
  tenantGroup?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SmsBroadcastAlert {
  id: string;
  alertType: "Pest & Disease Outbreak" | "Weather & Frost Warning" | "Topdressing Schedule" | "Field Advisory Training" | "Market Price Alert";
  recipientGroup: string;
  targetFarmersCount: number;
  messageContent: string;
  senderName: string;
  urgency: "Normal" | "High Alert" | "Emergency Broadcast";
  status: "Sent" | "Queued" | "Delivered" | "Failed";
  sentAt: string;
  deliveredCount?: number;
  smsParts?: number;
}

export interface AgronomistPerformanceMetric {
  agronomistId: string;
  agronomistName: string;
  farmersManaged: number;
  totalHectaresManaged: number;
  ticketsTotal: number;
  ticketsResolvedRate: number; // percentage
  avgResponseHours: number;
  clientHarvestUpliftPercent: number; // e.g. +24.5%
  prescriptionCompliancePercent: number; // e.g. 98.2%
  farmerRating: number; // e.g. 4.9
  totalReviews: number;
  topCropsHandled: string[];
}

export interface FarmerProgressNote {
  id: string;
  farmId: string;
  farmName: string;
  farmerName: string;
  date: string;
  noteType: "Field Inspection" | "Crop Stage Progress" | "Input Application" | "Harvest Milestone";
  summary: string;
  completedTasksCount: number;
  totalTasksCount: number;
  status: "On Track" | "Needs Attention" | "Critical Delay";
}

export interface OptionalModulePermission {
  read: boolean;
  write: boolean;
}

export interface RolePermissions {
  [moduleId: string]: OptionalModulePermission;
}

export type RolePermissionsMap = Record<string, RolePermissions>;

export interface UserMember {
  id: string;
  name: string;
  email: string;
  role: PredefinedRole;
  avatar?: string;
  lastActive: string;
  status?: "Active" | "Suspended" | "Deactivated";
  isSuspended?: boolean;
  suspensionReason?: string;
  password?: string;
  tenantId?: string;
  farmId?: string;
  farmName?: string;
  accessibleFarmIds?: string[];
  permittedModules?: string[];
  modulePermissions?: RolePermissions;
  mustChangePassword?: boolean;
  forcePasswordChange?: boolean;
  createdBy?: string;
  createdAt?: string;
}

export interface AssetMaintenanceLog {
  id: string;
  assetId: string;
  assetName?: string;
  date: string;
  type: "Routine Service" | "Repair" | "Overhaul" | "Inspection" | "Emergency Fix";
  description: string;
  cost: number;
  performedBy: string;
  status: "Completed" | "Scheduled" | "Overdue";
  nextDueDate?: string;
  notes?: string;
}

export interface AssetDisposalRecord {
  disposalDate: string;
  disposalType: "Sale" | "Scrapped" | "Written Off";
  proceeds: number;
  bookValueAtDisposal: number;
  gainLoss: number; // proceeds - bookValueAtDisposal
  purchaserOrReason?: string;
  journalEntryRef?: string;
}

export type BiologicalAssetTier = 
  | "non_current_biological" 
  | "current_biological" 
  | "post_harvest_inventory" 
  | "ppe_asset";

export interface Asset {
  id: string;
  name: string;
  category: "Land" | "Buildings" | "Equipment" | "Vehicles" | "Water Infrastructure" | "Livestock" | "Poultry" | "Aquaculture" | "Crops" | "Orchard" | "Other";
  assetClassification?: BiologicalAssetTier;
  assetTypeCategory?: "Current" | "Non-Current";
  glAccountCode?: string;
  biologicalDetails?: {
    species?: string;
    breed?: string;
    tagId?: string;
    batchId?: string;
    headcount?: number;
    weightKg?: number;
    purpose?: string;
    productionStage?: string;
    sourceModule?: "livestock" | "poultry" | "fish" | "crops" | "orchard" | "manual";
  };
  serial?: string;
  purchaseDate: string;
  purchasePrice: number;
  currentValue: number;
  salvageValue?: number;
  usefulLifeYears?: number;
  depreciationMethod?: "Straight-Line" | "Declining Balance";
  annualDepreciation?: number;
  accumulatedDepreciation?: number;
  currentBookValue?: number;
  location: string;
  supplierId: string;
  condition: "Excellent" | "Good" | "Fair" | "Poor";
  notes?: string;
  depreciationRate: number; // e.g. annual percentage rate
  expectedUsefulLife?: number; // Expected useful life in years (e.g. 5, 10)
  remainingUsefulLife?: number; // Automatically calculated remaining useful life in years
  farmId: string;
  maintenanceLogs?: AssetMaintenanceLog[];
  isDisposed?: boolean;
  disposalRecord?: AssetDisposalRecord;
  lastDepreciationDate?: string;
}

export interface OtherRevenue {
  id: string;
  description: string;
  amount: number;
  date: string;
  source: string;
  revenueType: "Grant" | "Shareholder Contribution" | "Other Income";
  coaCode: string;
  farmId: string;
}

export interface LeaveRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  startDate: string;
  endDate: string;
  leaveType: "Annual" | "Sick" | "Maternity" | "Paternity" | "Study" | "Compassionate" | "Unpaid";
  status: "Pending" | "Approved" | "Rejected";
  notes?: string;
  farmId: string;
}

export interface EmployeeAdvance {
  id: string;
  employeeId: string;
  employeeName: string;
  amount: number;
  advanceAmount: number;
  remainingBalance: number;
  requestDate: string;
  repaymentMonth: string; // e.g. "2026-06"
  status: "Pending" | "Approved" | "Paid" | "Deducted";
  notes?: string;
  farmId: string;
}

export interface AuditLog {
  id: string;
  timestamp?: string | any;
  user?: string;
  action: "CREATE" | "EDIT" | "UPDATE" | "DELETE" | "RESTORE" | "CLEAR" | "LOGIN" | string;
  module?: string;
  record?: string;
  detail?: string;
  description?: string;
  date?: string;
  ip?: string;
  actor?: string;
  actorUid?: string;
  actorEmail?: string;
  actorName?: string;
  targetUid?: string;
  targetEmail?: string;
  targetName?: string;
  details?: any;
  accessLevel?: string;
  status?: string;
  farmId?: string;
  tenantId?: string;
  actingAs?: string;
  superAdminUid?: string;
  superAdminEmail?: string;
  sessionId?: string;
  createdAt?: string | any;
}

export interface ArchiveRecord {
  id: string;
  archivedAt: string;
  module: string;
  originalId: string;
  description: string;
  data: string; // JSON string
  farmId: string;
}

export interface BackupData {
  farms: Farm[];
  accounts: Account[];
  suppliers: Supplier[];
  customers: Customer[];
  expenses: ExpenseTransaction[];
  invoices: Invoice[];
  quotations: Quotation[];
  crops: CropCycle[];
  employees: Employee[];
  payslips: Payslip[];
  poultry: PoultryBatch[];
  fish: FishBatch[];
  inventory: InventoryItem[];
  cashSales: CashSale[];
  loans: Loan[];
  investments: Investment[];
  livestock: LivestockRecord[];
  assets?: Asset[];
  otherRevenues?: OtherRevenue[];
  leaveRecords?: LeaveRecord[];
  advances?: EmployeeAdvance[];
  inventoryMovements?: InventoryTransfer[];
  auditLogs?: AuditLog[];
  archivedRecords?: ArchiveRecord[];
  credits?: number;
  userProfile?: { name: string; email: string; phone: string; tenantId?: string; uid?: string; };
  backupDate?: string;
  teamMembers?: UserMember[];
}export interface FormulaIngredient {
  name: string;
  quantityKg: number;
  costPerKg: number;
  crudeProteinPct: number;
  metabolizableEnergyKcal: number;
  calciumPct: number;
  phosphorusPct: number;
}

export interface FeedFormula {
  id: string;
  name: string;
  stage: "Starter" | "Grower" | "Finisher" | "Layer Mash";
  version: number;
  createdAt: string;
  notes?: string;
  ingredients: FormulaIngredient[];
  totalQuantityKg: number;
  farmId: string;
}

export interface FarmTask {
  id: string;
  title: string;
  description: string;
  category: "General" | "Equipment Maintenance" | "Irrigation Scheduling" | "Harvesting" | "Livestock Feed" | "Crop Spraying" | "Other";
  dueDate: string; // ISO-8601 YYYY-MM-DD or YYYY-MM-DDTHH:MM
  isCompleted: boolean;
  completedAt?: string; // date completed (e.g., ISO string)
  farmId: string;
}

// -----------------------------------------------------
// Offtaker Portal Database Schemas
// -----------------------------------------------------

export interface Offtaker {
  id: string;
  tenantId: string;
  legalName: string;
  registrationNumber: string;
  tpin: string;
  sector: "grain" | "dairy" | "cotton" | "tobacco" | "livestock" | "other";
  depotLocations: string[]; // array of strings
  status: "active" | "suspended";
  createdAt: string;
}

export interface OfftakerProduct {
  id: string;
  offtakerId: string;
  productName: string;
  unit: string; // kg, litre, head, bale, etc.
  defaultUnitPrice: number;
  gradeTags: string[]; // array
  active: boolean;
}

export interface FarmerOfftakerLink {
  id: string;
  farmerId: string; // FK to Farmer
  offtakerId: string; // FK to Offtaker
  status: "pending" | "active" | "revoked";
  initiatedBy: "farmer" | "offtaker";
  linkedAt: string;
  respondedAt?: string;
}

export interface DeliveryNote {
  id: string;
  dnNumber: string; // unique, sequential PER offtaker (e.g. DN-2026-001)
  farmerId: string;
  farmerName?: string; // cached helper
  offtakerId: string;
  productId: string;
  productName?: string; // cached helper
  quantity: number;
  unit: string;
  gradeTag: string;
  unitPrice: number;
  totalValue: number;
  cropCycleId?: string | null; // FK to existing CropCycle (nullable)
  status: "pending_confirmation" | "confirmed" | "disputed";
  confirmationDeadline?: string;
  confirmedAt?: string;
  paymentStatus: "unpaid" | "paid";
  payoutId?: string | null;
  recordedByUserId: string;
  createdAt: string;
}

export interface AdjustmentNote {
  id: string;
  originalDnId: string;
  reason: string;
  fieldChanges: {
    quantity?: { from: number; to: number };
    unitPrice?: { from: number; to: number };
    gradeTag?: { from: string; to: string };
  };
  createdBy: string;
  approvedBy: string;
  createdAt: string;
}

export interface OfftakerWallet {
  id: string;
  offtakerId: string;
  balance: number;
  currency: string; // 'ZMW' by default
  lastFundedAt?: string;
}

export interface WalletTransaction {
  id: string;
  walletId: string;
  type: "fund" | "debit" | "fee" | "reversal";
  amount: number;
  lipilaReference: string;
  createdAt: string;
}

export interface Payout {
  id: string;
  offtakerId: string;
  farmerId: string;
  deliveryNoteIds: string[]; // can be multiple DNs in one payout
  grossAmount: number;
  offtakerFeeAmount: number;
  farmerFeeAmount: number;
  netAmountToFarmer: number;
  payoutMethod: "mobile_money" | "bank_transfer";
  lipilaReference: string;
  status: "initiated" | "processing" | "completed" | "failed" | "reversed";
  createdAt: string;
  completedAt?: string;
}

export interface FeeConfig {
  id: string;
  side: "farmer" | "offtaker";
  ratePercent: number; // decimal (e.g., 2.8)
  flatFee: number; // decimal ZMW (e.g., 15.00)
  effectiveFrom: string;
  setByUserId: string;
  createdAt: string;
}

export interface OrchardNurseryBatch {
  id: string; // document ID (ULID)
  batchId: string; // e.g. NUR-2027-000145
  tenantId: string;
  fruitType: string;
  seedSource: string;
  quantitySown: number;
  germinatedCount: number;
  failedCount: number;
  successRatePct: number;
  graftingMethod: "approach" | "cleft" | "whip" | "side" | "bud" | "none";
  grafter: string;
  graftSuccessRatePct: number;
  readyForTransplantDate: string;
  linkedBlockCropCycleId: string | null;
  status: "active" | "ready_for_transplant" | "closed";
  createdAt: string;
}

export interface OrchardTree {
  id: string; // Document ID (ULID)
  treeId: string; // e.g. AVO-2027-000145, QR-encoded
  tenantId: string;
  blockCropCycleId: string; // FK to crop_cycles
  variety: string;
  rootstock: string;
  plantedDate: string;
  lifecycleStage: "Nursery" | "Transplanted" | "Juvenile" | "Flowering" | "Fruiting" | "Peak Production" | "Declining" | "Removed" | "Dead";
  healthScore: number; // 0-100
  gpsOffset?: { lat: number; lng: number };
  createdAt: string;
}

export interface OrchardActivity {
  id: string;
  tenantId: string;
  activityType: "spray" | "fertilise" | "irrigate" | "prune" | "graft" | "flowerObservation" | "fruitSet" | "labour" | "pest_control" | "equipment" | "other";
  treeId?: string;
  blockCropCycleId?: string;
  product: string;
  quantity: number;
  cost: number;
  costCurrency?: string;
  coaCode: string;
  operator: string;
  weatherSnapshot?: any;
  phi?: number;
  rei?: number;
  createdAt: string;
  // Bidirectional link to financial expense ledger
  costTaskType?: OrchardCostTaskType;
  expenseLedgerRef?: string;
  dateIncurred?: string;
  loggedBy?: string;
}

export interface OrchardCostTask {
  id: string;
  taskId?: string;
  blockId: string;
  treeGroupId?: string;
  taskType: OrchardCostTaskType;
  description: string;
  cost: number;
  costCurrency?: string;
  dateIncurred: string;
  loggedBy: string;
  expenseLedgerRef?: string;
  coaAccountId?: string;
  coaCode?: string;
  createdAt: string;
}

export interface BlockRevenueLedgerEntry {
  id: string;
  saleId: string;
  blockId: string;
  blockName?: string;
  treeGroupId?: string;
  tenantId: string;
  date: string;
  buyer: string;
  quantity: number;
  unitPrice: number;
  amount: number;
  productType: "fruit" | string;
  productName?: string;
  invoiceNumber?: string;
  receiptNumber?: string;
  coaAccountId?: string; // 4300
  postedAt: string;
  postedBy?: string;
}

export interface BlockExpenseLedgerEntry {
  id: string;
  taskId?: string;
  blockId: string;
  blockName?: string;
  treeGroupId?: string;
  tenantId: string;
  date: string;
  costTaskType: OrchardCostTaskType;
  description: string;
  amount: number;
  coaCode: string;
  coaAccountName: string;
  sourceModule: OrchardExpenseSourceModule;
  expenseId?: string;
  postedAt: string;
  postedBy?: string;
}

export interface BlockProfitabilitySummary {
  blockId: string;
  blockName: string;
  fruitType: string;
  variety?: string;
  treeCount: number;
  areaHa?: number;
  projectedRevenue: number;
  actualRevenueToDate: number;
  actualExpensesToDate: number;
  netProfitToDate: number;
  revenueVariancePct: number;
  profitMarginPct: number;
  expensesBreakdown: {
    spraying: number;
    labour: number;
    pruning: number;
    fertilizer: number;
    irrigation: number;
    pest_control: number;
    equipment: number;
    other: number;
    [key: string]: number;
  };
  rank: number;
  lastRevenuePostedAt?: string;
  lastExpensePostedAt?: string;
  aiInsight?: {
    summary: string;
    driverType: "volume" | "price" | "mixed";
    likelyCauses: { tag: string; description: string }[];
    recommendations: string[];
    classification?: "surplus" | "deficit" | "on_target";
  };
}

export interface BlockRevenuePerformanceSummary {
  blockId: string;
  blockName: string;
  fruitType: string;
  variety?: string;
  treeCount: number;
  projectedRevenue: number;
  actualRevenueToDate: number;
  varianceAmount: number;
  variancePct: number;
  actualHarvestUnits?: number;
  projectedHarvestUnits?: number;
  averageSellingPrice?: number;
  projectedPrice?: number;
  classification: "surplus" | "deficit" | "on_target";
  aiInsight: {
    summary: string;
    driverType: "volume" | "price" | "mixed";
    likelyCauses: { tag: string; description: string }[];
    recommendations: string[];
    classification?: "surplus" | "deficit" | "on_target";
  };
  timeline: {
    date: string;
    actualCumulative: number;
    projectedTarget: number;
    delta: number;
  }[];
}

// ==========================================
// Agro-Dealer Consignment & Reconciliation Types (AGD)
// ==========================================

export type AgroCategory = "seed" | "pesticide" | "herbicide" | "fungicide" | "fertilizer" | "other";

export interface AgroDealerSKU {
  id: string;
  tenantId: string;
  productName: string;
  category: AgroCategory;
  unit: string; // kg, litre, packet, 50kg bag, etc.
  supplierId?: string | null; // institutionId if consignment, null if dealer-owned
  supplierName?: string;
  grantId?: string | null;
  unitCost: number;
  sellingPrice: number;
  qtyReceived: number;
  qtySold: number;
  qtyOnHand: number;
  qtyReserved: number;
  reorderThreshold: number;
  reorderLevel?: number;
  batchNumber?: string;
  expiryDate?: string;
  lastMovementAt: string;
  aiBrief?: {
    targetPests?: string[];
    recommendedCrops?: string[];
    applicationGuidance?: string;
    safetyNotes?: string;
    generatedAt?: string;
  };
}

export type StockMovementType =
  | "grant_received"
  | "sale"
  | "return_to_supplier"
  | "damage_writeoff"
  | "manual_adjustment"
  | "marketplace_reservation"
  | "marketplace_reservation_released";

export interface StockMovement {
  id: string;
  skuId: string;
  productName: string;
  type: StockMovementType;
  qtyDelta: number;
  resultingBalance: number;
  timestamp: string;
  actorId: string;
  actorName: string;
  reference: string; // e.g. AGD-SALE-1002, GRANT-401, RETURN-88
  reasonCode?: string;
}

export interface ConsignmentAgreement {
  id: string;
  dealerTenantId: string;
  dealerName: string;
  dealerPhone?: string;
  institutionId: string;
  institutionName: string;
  remittancePeriodDays: number; // 30, 60, 90
  commissionBearer: "agro_dealer" | "institution_supplier";
  productCategories: AgroCategory[];
  creditLimit: number; // ZMW cap
  status: "pending" | "active" | "revoked";
  createdAt: string;
  acceptedAt?: string;
}

export interface StockGrantItem {
  skuId?: string;
  productName: string;
  category: AgroCategory;
  unit: string;
  qty: number;
  unitCost: number;
  sellingPrice?: number;
  batchNumber?: string;
  expiryDate?: string;
}

export interface StockGrant {
  id: string;
  grantNumber: string; // e.g., GRANT-2026-001
  institutionId: string;
  institutionName: string;
  dealerTenantId: string;
  dealerName: string;
  grantDate: string;
  items: StockGrantItem[];
  totalValue: number;
  status: "issued" | "received";
  createdAt: string;
}

export interface SupplierCatalogItem {
  id: string;
  supplierId: string;
  supplierName: string;
  productName: string;
  category: AgroCategory;
  unit: string; // e.g. 10kg Bag, 50kg Bag, 1L Bottle, 500ml Can
  unitWholesaleCost: number;
  recommendedSellingPrice: number;
  qtyInStock: number;
  batchNumber?: string;
  expiryDate?: string;
  barcodeSKU?: string;
  description?: string;
  createdAt: string;
}

export interface DealerLedgerRollup {
  dealerTenantId: string;
  dealerName: string;
  dealerPhone: string;
  province: string;
  district: string;
  city: string;
  totalStockGrantedValue: number;
  totalStockRemainingValue: number;
  totalSalesValue: number;
  outstandingConsignmentPayable: number;
  lastRemittanceDate?: string;
  subscriptionStatus: "active" | "grace_period" | "expired";
  isSponsored: boolean;
  creditLimit: number;
  exceedsCreditLimit: boolean;
}

export interface ReconciliationRun {
  id: string;
  runNumber: string; // e.g., REC-2026-001
  institutionId: string;
  institutionName: string;
  dealerTenantId: string;
  dealerName: string;
  periodStart: string;
  periodEnd: string;
  computedSalesValue: number;
  totalRemittancesReceived: number;
  variance: number; // computedSalesValue - totalRemittancesReceived
  status: "draft" | "reconciled" | "disputed";
  createdAt: string;
  reconciledAt?: string;
  notes?: string;
}

export type BankingDestinationType = "Bank Account" | "Mobile Money Wallet" | "Cash Box / Drawer";

export interface BankingDestination {
  id: string;
  name: string; // e.g., "Zanaco Agri-Business Account", "MTN MoMo Merchant", "Airtel Corporate"
  type: BankingDestinationType;
  accountNumber: string; // Account number or phone number (+260...)
  institutionName: string; // ZANACO, Stanbic, Absa, MTN Zambia, Airtel Zambia, etc.
  currentBalance: number;
  lastReconciledDate?: string;
  currency?: string;
  notes?: string;
}

export interface ReconcilableSalesRecord {
  id: string;
  date: string;
  sourceModule: "Cash Sales" | "Crop Sales" | "Livestock & Poultry" | "Invoices & Receivables" | "Other Revenue" | "Agro-Dealer Sales";
  title: string;
  customerOrBuyer: string;
  amount: number;
  paymentChannel: "Cash" | "Mobile Money" | "Bank Transfer" | "Cheque" | "Other";
  referenceNumber?: string;
  reconciliationStatus: "Unreconciled" | "Reconciled" | "Pending Banking";
  reconciledToDestinationId?: string;
  reconciledDate?: string;
  reconciliationRunId?: string;
}

export interface FarmerBankReconciliationRun {
  id: string;
  runNumber: string; // e.g. BRC-2026-001
  farmId: string;
  destinationId: string;
  destinationName: string;
  destinationType: BankingDestinationType;
  accountNumber: string;
  reconciliationDate: string;
  periodStart: string;
  periodEnd: string;
  statementEndingBalance: number;
  ledgerRecordedSalesTotal: number;
  bankDepositsMatchedTotal: number;
  bankFeesAndCharges: number; // MoMo transaction fee, bank transfer fee, withdrawal charge
  interestOrAdjustments: number;
  netReconciledAmount: number;
  unreconciledVariance: number;
  status: "Balanced" | "Discrepancy" | "Pending Review";
  reconciledBy: string;
  matchedSalesIds: string[];
  depositReferenceNumber?: string; // Deposit slip ID / MoMo transaction ID
  notes?: string;
  createdAt: string;
}

export interface AgroDealerTenant {
  id: string;
  businessName: string;
  tradingName?: string;
  pacraTpin?: string;
  ownerName: string;
  ownerPhone: string;
  ownerEmail: string;
  province: string;
  district: string;
  city: string;
  gpsLocation?: { lat: number; lng: number };
  canDeliver: boolean;
  lipilaPaymentLinkId: string;
  subscriptionStatus: "active" | "grace_period" | "expired";
  subscriptionTier: "monthly_180" | "daily_25";
  sponsoredByInstitutionId?: string | null;
  credits?: number;
  subscriptionExpiryDate?: string;
  loginPassword?: string;
  createdAt: string;
}

export interface TenantSubUser {
  id: string;
  uid?: string;
  tenantId?: string;
  tenantEmail: string;
  name: string;
  email: string;
  phone?: string;
  role?: string;
  permission: "read_write" | "read_only";
  accessLevel?: "read_write" | "read_only";
  status: "active" | "inactive" | "suspended" | "removed";
  createdAt: string;
}

export interface ReturnToSupplierRequest {
  id: string;
  dealerTenantId: string;
  dealerName: string;
  institutionId: string;
  institutionName: string;
  skuId: string;
  productName: string;
  qty: number;
  unitCost: number;
  totalCostValue: number;
  reason: string;
  status: "pending" | "approved" | "rejected";
  requestedAt: string;
  respondedAt?: string;
}

// --- AI Crop & Orchard Guidance Engine Interfaces ---

export interface CkbStageTask {
  taskId: string;
  title: string;
  detail: string;
  timingNote: string;
  applicableTo: "all" | string[];
}

export interface CkbInputCategoryNeeded {
  categoryId: string;
  categoryLabel: string;
  applicationGuidance: string;
  genericQuantityGuidance: string;
  mandatory: boolean;
  agronomistDisclaimerRequired: boolean;
}

export interface CkbDecisionPoint {
  condition: string;
  guidance: string;
  escalateToAgronomist: boolean;
}

export interface CkbRegionVariant {
  agroEcologicalZone: string;
  triggerValueOverride: number | string | null;
  durationDaysOverride: number | null;
  applicationGuidanceOverride: string | null;
  notes: string;
}

export interface CropKnowledgeStage {
  stageId: string;
  stageOrder: number;
  stageName: string;
  triggerType: "days_from_planting" | "days_from_transplant" | "calendar_season" | "phenological_signal";
  triggerValue: number | string;
  durationDays: number | null;
  description: string;
  tasks: CkbStageTask[];
  inputCategoriesNeeded: CkbInputCategoryNeeded[];
  decisionPoints: CkbDecisionPoint[];
  mediaRefs: string[];
  regionVariants: CkbRegionVariant[];
}

export interface CropKnowledgeBaseItem {
  cropId: string;
  cropName: string;
  cropType: "annual_field_crop" | "perennial_tree" | "vegetable" | "orchard";
  varieties: string[];
  totalCycleDurationDays: number | null;
  maturityYears: number | null;
  regionsApplicable: string[];
  lastReviewedBy: string;
  lastReviewedAt: string;
  sourceCurationNotes: string;
  status: "draft" | "published" | "needs_review";
  createdAt: string;
  updatedAt: string;
  stages?: CropKnowledgeStage[];
}

export interface GrowthGuideProgress {
  cropId: string;
  currentStageId: string;
  stageStartedAt: string;
  completedTasks: string[];
  confirmedSignals: string[];
  agroEcologicalZone: string;
}

export interface InputCategory {
  categoryId: string;
  categoryLabel: string;
  appliesToCropTypes: string[];
}

export interface SponsoredPlacement {
  placementId: string;
  vendorId: string;
  skuId: string;
  categoryId: string;
  cropId: string | null;
  regions: string[];
  startDate: string;
  endDate: string;
  priorityRank: 1 | 2;
  durationDays: number;
  pricePerDay: number;
  totalPrice: number;
  paymentRef: string;
  status: "pending_payment" | "active" | "expired" | "cancelled";
  createdAt: string;
}

export interface PlacementAnalyticsEvent {
  eventId: string;
  eventType: "impression" | "click" | "order_attributed";
  farmerRegion: string;
  cropId: string | null;
  stageId: string | null;
  timestamp: string;
  orderRef: string | null;
  orderValue: number | null;
}

export interface PlacementAnalyticsSummary {
  placementId: string;
  totalImpressions: number;
  totalClicks: number;
  ctr: number;
  ordersAttributed: number;
  salesValueAttributed: number;
  regionBreakdown: Record<string, { impressions: number; clicks: number; sales: number }>;
  cropStageBreakdown: Record<string, { impressions: number; clicks: number }>;
}

export interface ProductAIBrief {
  skuId: string;
  targetPestsWeedsDiseases: string[];
  recommendedCrops: string[];
  applicationGuidance: string;
  safetyWithholdingNote: string;
  generatedAt: string;
  generatedByModel: string;
  reviewedByAdmin: boolean;
  reviewedBy: string | null;
  disclaimer: string;
}

export interface ContentFeedback {
  feedbackId: string;
  cropId: string;
  stageId: string;
  tenantId: string;
  note: string;
  createdAt: string;
}

// --- AGC (Smallholder Input Credit Infrastructure) Types ---

export interface GeoPoint {
  lat: number;
  lng: number;
}

export interface FarmPlotBoundary {
  plotId: string;
  plotName?: string;
  gpsBoundary: GeoPoint[];
  sizeHa: number;
  cropHistory: string[];
  aez: string;
}

export interface CreditExplainabilityFactor {
  factor: string;
  impact: "positive" | "negative" | "neutral";
  scoreImpact: number;
}

export interface MabalaCreditScore {
  value: number;
  band: 'A' | 'B' | 'C' | 'D';
  explainability: CreditExplainabilityFactor[];
  computedAt: string;
}

export interface RemoteSensingSignal {
  perPlot: {
    plotId: string;
    ndvi: number;
    modelledYield: number;
    confidence: 'high' | 'medium' | 'low';
  }[];
  computedAt: string;
}

export interface FarmerCreditProfileSummary {
  identity: {
    nrc: string | null;
    nrcPending: boolean;
    phone: string;
    name: string;
    ageBand: string;
  };
  farmPlots: FarmPlotBoundary[];
  salesHistory: {
    rollupBySeasonCrop: { season: string; crop: string; revenue: number; volumeKg: number }[];
    lastComputedAt: string;
  };
  priceContext: null;
  agdPurchaseHistory: {
    rollup: { skuName: string; totalSpend: number; lastPurchaseDate: string }[];
  };
  remoteSensingSignal: RemoteSensingSignal;
  mabalaCreditScore: MabalaCreditScore;
  consentStatus: 'granted' | 'revoked' | 'never-granted';
  activeLoanId: string | null;
}

export interface BasketItem {
  skuId: string;
  name: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface CreditApplication {
  applicationId: string;
  farmerTenantId: string;
  farmerName?: string;
  farmerPhone?: string;
  dealerTenantId: string;
  dealerName?: string;
  financierInstitutionId: string;
  financierName?: string;
  requestedBasket: BasketItem[];
  totalAmount: number;
  selectedCrop?: string;
  appliedHectarage?: number;
  plotId?: string;
  plotName?: string;
  maxEligibleAmount?: number;
  warehouseReceiptId?: string;
  warehouseReceiptPledged?: boolean;
  insurancePolicyAttached?: boolean;
  insurancePremiumAmount?: number;
  status: 'pending' | 'approved' | 'rejected-single-loan' | 'rejected-other';
  rejectionReason?: string;
  createdAt: string;
  decidedAt?: string;
}

export interface RiskShareBreakdown {
  weatherPct: number;
  guaranteePct: number;
  dealerRetainedPct: number;
}

export interface LoanAccount {
  loanId: string;
  farmerTenantId: string;
  farmerName?: string;
  dealerTenantId: string;
  dealerName?: string;
  financierInstitutionId: string;
  financierName?: string;
  principal: number;
  term: number;
  selectedCrop?: string;
  appliedHectarage?: number;
  plotId?: string;
  plotName?: string;
  warehouseReceiptId?: string;
  warehouseReceiptPledged?: boolean;
  dwrDetails?: {
    receiptNumber: string;
    cropType: string;
    quantity: number;
    unit: string;
    totalValue: number;
  };
  insurancePolicyAttached?: boolean;
  insurancePremiumAmount?: number;
  feeSchedule: {
    interestRatePct: number;
    originationFee: number;
    totalRepayable: number;
  };
  insurancePolicyId: string | null;
  status: 'active' | 'repaid' | 'restructured' | 'defaulted' | 'insurer-settled' | 'written-off';
  balance: number;
  disbursedAt: string;
  dueDate: string;
  riskShare: RiskShareBreakdown;
}

export interface RepaymentRecord {
  repaymentId: string;
  loanId: string;
  farmerTenantId?: string;
  amount: number;
  channel: 'lipila' | 'farm-balance' | 'offtaker-settlement' | 'warehouse-receipt-offset';
  scoreBonusEligible: boolean;
  createdAt: string;
}

export interface LoanInsurancePolicy {
  policyId: string;
  loanId: string;
  insurerInstitutionId: string;
  insurerName?: string;
  rateId: string;
  premiumAccruedToDate: number;
  status: 'active' | 'claimed' | 'lapsed';
}

export interface InsurerPremiumRate {
  rateId: string;
  insurerInstitutionId: string;
  insurerId?: string;
  insurerName?: string;
  cropOrCategory: string;
  region: string | null;
  loanSizeBand: string | null;
  ratePct: number;
  deductiblePct?: number;
  coverageDescription?: string;
  effectiveFrom: string;
  setBy: string;
}

export interface CreditFacility {
  facilityId: string;
  financierInstitutionId: string;
  financierName?: string;
  dealerTenantId?: string;
  dealerName?: string;
  allocatedLimit: number;
  utilized: number;
  riskShareDefaults: RiskShareBreakdown;
  status: 'active' | 'suspended';
  cropLimits?: Record<string, number>;
}

export interface ApiAccessConfig {
  institutionId: string;
  institutionName: string;
  enabledScopes: string[];
  rateOverridesByScope: Record<string, number>;
  customRatePerCall: number | null;
  freeTrialCallsRemaining: number;
  status: 'active' | 'suspended';
}

export interface ApiCallLog {
  callId: string;
  institutionId: string;
  institutionName?: string;
  farmerTenantId: string;
  farmerName?: string;
  dataScope: string;
  timestamp: string;
  feeCharged: number;
}

export interface ApiConfigRates {
  defaultRatePerCall: number;
  ratesByScope: Record<string, number>;
  defaultFreeTrialCalls: number;
}

export interface GuaranteeFundLedger {
  balance: number;
  committedBy: string | null;
  committedAt: string | null;
}

// ==========================================
// HSW (Harvest, Storage & Warehouse Receipts)
// ==========================================

export interface HarvestGradedBreakdown {
  grade: string;
  qty: number;
  unit: string;
}

export interface HarvestEvent {
  id: string;
  cropCycleId: string;
  farmNodeId: string;
  tenantId: string;
  cropType: string;
  variety: string;
  harvestDate: string;
  quantityRaw: number;
  unitRaw: string;
  gradedBreakdown: HarvestGradedBreakdown[];
  bagCount: number;
  bagWeightKg: number;
  moistureContent: number;
  loggedBy: string;
  photos: string[];
  status: 'draft' | 'confirmed';
  createdAt: string;
  updatedAt: string;
}

export interface WarehouseCapacity {
  cropType: string;
  capacityQty: number;
  unit: string;
}

export interface WarehouseCertification {
  status: 'uncertified' | 'pending' | 'certified';
  licenseNumber: string;
  certifyingAuthority: string;
  certificationDocs: string[];
  certifiedBy: string | null;
  certifiedAt: string | null;
}

export interface Warehouse {
  id: string;
  ownerType: 'farm_on_site' | 'certified_third_party';
  name: string;
  province: string;
  district: string;
  gpsLat: number;
  gpsLng: number;
  operatorTenantId: string | null;
  certification: WarehouseCertification;
  capacityByCrop: WarehouseCapacity[];
  createdAt: string;
  updatedAt: string;
}

export interface StorageLotPledge {
  pledgedTo: 'AGC_offset' | 'external_financier' | null;
  pledgeRef: string | null;
  pledgedQuantity: number;
  pledgedAt: string | null;
  releasedAt: string | null;
}

export interface StorageLot {
  id: string;
  farmNodeId: string;
  tenantId: string;
  cropCycleId: string;
  harvestEventIds: string[];
  warehouseId: string;
  cropType: string;
  variety: string;
  grade: string;
  quantityIn: number;
  quantityCurrent: number;
  unit: string;
  valuationPriceSource: 'MPB' | 'manual' | 'contracted';
  valuationPricePerUnit: number;
  valuationCurrency: string;
  storedValueAtIntake: number;
  storedValueCurrent: number;
  intakeDate: string;
  status: 'pending_intake' | 'in_storage' | 'partially_sold' | 'depleted' | 'pledged' | 'released';
  pledge: StorageLotPledge;
  createdAt: string;
  updatedAt: string;
}

export interface DwrPledgeHistoryItem {
  type: string;
  ref: string;
  amount: number;
  pledgedAt: string;
  releasedAt: string | null;
  releasedBy: string | null;
}

export interface DwrWithdrawalHistoryItem {
  qty: number;
  reason: 'sale' | 'loss' | 'transfer';
  ref: string;
  date: string;
  loggedBy: string;
}

export interface WarehouseReceipt {
  id: string;
  receiptNumber: string;
  lotId: string;
  warehouseId: string;
  farmNodeId: string;
  farmerUid: string;
  tenantId: string;
  cropType: string;
  variety: string;
  grade: string;
  quantity: number;
  unit: string;
  valuePerUnitAtIssue: number;
  totalValueAtIssue: number;
  issuedDate: string;
  issuedBy: string;
  negotiable: boolean;
  status: 'active' | 'pledged' | 'partially_withdrawn' | 'closed' | 'cancelled';
  pledgeHistory: DwrPledgeHistoryItem[];
  withdrawalHistory: DwrWithdrawalHistoryItem[];
  documentUrl: string;
  qrVerificationCode: string;
  createdAt: string;
  updatedAt: string;
}

export interface PledgeRecord {
  id: string;
  receiptId: string;
  receiptNumber: string;
  lotId: string;
  cropType: string;
  variety: string;
  quantityPledged: number;
  unit: string;
  marketPricePerUnit: number;
  totalCollateralValue: number;
  requestedLoanAmount: number;
  ltvRatio: number;
  lenderName: string;
  tenureMonths: number;
  interestRateAnnual: number;
  issuedDate: string;
  maturityDate: string;
  qrCode: string;
  status: "active_pledge" | "released" | "liquidated";
}

export interface StorageLoss {
  id: string;
  lotId: string;
  warehouseId: string;
  tenantId: string;
  date: string;
  quantityLost: number;
  unit: string;
  causeCategory: 'pest' | 'mould_moisture' | 'theft' | 'spillage_handling' | 'rodent' | 'quality_downgrade' | 'other';
  notes: string;
  photos: string[];
  loggedBy: string;
  valueImpact: number;
  createdAt: string;
}

export interface CropCycleVarianceAIInsight {
  summary: string;
  likelyCauses: { tag: string; description: string }[];
  driverType: 'volume' | 'price' | 'mixed';
  generatedAt: string;
  modelRef: string;
}

export interface CropCycleVariance {
  cropCycleId: string;
  cropType?: string;
  tenantId: string;
  farmNodeId: string;
  projectedYield: number;
  projectedYieldUnit: string;
  projectedRevenue: number;
  actualHarvestQty: number;
  actualHarvestValue: number;
  postHarvestLossQty: number;
  postHarvestLossValue: number;
  netSalableQty?: number;
  varianceQty: number;
  variancePct: number;
  varianceRevenue: number;
  varianceRevenuePct: number;
  classification: 'surplus' | 'deficit' | 'on_target';
  aiInsight: CropCycleVarianceAIInsight;
  generatedAt: string;
  regeneratedAt: string;
}

// Stage-Based Feed Formulation Engine Interfaces
export interface AnimalGrowthStage {
  id: string;
  name: string;
  ageRangeDays: [number, number] | null;
  defaultDailyRationKg?: number; // target guideline daily feed kg per animal
  description?: string;
}

export interface AnimalTypeConfig {
  id: string; // "pig", "cattle", "goat", "chicken", "fish", "sheep", etc.
  name: string;
  unitOfMeasure: "kg" | "g" | "litre";
  countUnit: "head" | "1000 fingerlings" | "flock" | "batch" | "birds" | "animals";
  description?: string;
  stages: AnimalGrowthStage[];
}

export interface IngredientCostHistory {
  costPerUnit: number;
  effectiveFrom: string;
  changedBy?: string;
}

export interface FeedIngredient {
  id: string;
  tenantId: string;
  name: string;
  unit: "kg" | "g" | "litre";
  currentCostPerUnit: number; // ZMW
  category: "energy" | "protein" | "mineral" | "vitamin" | "additive" | "roughage" | "complete-feed";
  bagSizeKg?: number | null; // optional bag size in kg (e.g. 50kg, 25kg)
  pricePaid?: number | null; // optional price paid for the bag
  crudeProteinPercent?: number; // e.g. 16.5 for 16.5%
  crudeFiberPercent?: number; // e.g. 5.0 for 5.0%
  energyKcalPerKg?: number; // e.g. 3200 kcal/kg
  energyMjPerKg?: number; // e.g. 13.4 MJ/kg
  currentStockKg?: number;
  minThresholdKg?: number;
  active: boolean;
  costHistory: IngredientCostHistory[];
  updatedAt: string;
  updatedBy?: string;
}

export interface PenRecord {
  id: string;
  tenantId: string;
  farmNodeId?: string;
  code: string; // e.g. "AR1", "BL3", "Pen-101"
  name?: string; // e.g. "Grower Pen Alpha"
  animalTypeId: string; // "pig", "cattle", "chicken", etc.
  stageId: string; // "grower", "weaner", "finisher", etc.
  assignedFormulationId?: string | null; // explicitly selected active recipe for this pen
  headcount: number;
  capacity?: number;
  active: boolean;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface FormulationIngredient {
  ingredientId: string;
  ingredientName: string;
  inclusionQtyPerUnit: number; // e.g. kg per 100kg batch
  unit: string;
  costPerKgOverride?: number; // optional custom override
  crudeProteinOverride?: number; // %
  crudeFiberOverride?: number; // %
  energyKcalOverride?: number; // kcal/kg
}

export interface FeedFormulation {
  id: string;
  tenantId: string;
  animalTypeId: string;
  stageId: string;
  name: string;
  status: "active" | "draft" | "archived" | "inactive";
  version: number;
  effectiveFrom: string;
  ingredients: FormulationIngredient[];
  batchSize: number; // e.g., 100 kg basis
  dailyQtyPerAnimal: number; // kg/head/day
  costPerKgMix: number; // computed
  costPerAnimalPerDay: number; // computed
  notes?: string;
  createdBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DailyFeedLog {
  id: string;
  tenantId: string;
  date: string;
  farmNodeId: string;
  animalTypeId: string;
  stageId: string;
  cohortId?: string | null;
  formulationId: string;
  formulationVersion: number;
  formulationSnapshot: {
    ingredients: FormulationIngredient[];
    costPerKgMix: number;
    dailyQtyPerAnimal: number;
  };
  numberOfAnimalsFed: number;
  totalQuantityFedKg: number;
  totalCost: number; // immutable once saved
  loggedBy: string;
  loggedAt: string;
  notes?: string;
}

export interface AnimalFeedCostLedger {
  id: string; // cohortId or animalId
  tenantId: string;
  animalTypeId: string;
  stageId: string;
  animalsCovered: number;
  cumulativeFeedCost: number;
  cumulativeQuantityKg: number;
  costPerAnimalToDate: number;
  firstLogDate: string;
  lastLogDate: string;
  lastUpdatedAt: string;
}

// Swine / Pig Management Interfaces
export interface SowFarrowingRecord {
  id: string;
  sowTagId: string;
  sowName?: string;
  boarTagId?: string;
  serviceDate: string;
  expectedFarrowingDate: string; // 114 days
  actualFarrowingDate?: string;
  litterSizeBornAlive: number;
  litterSizeStillborn: number;
  litterSizeMummified: number;
  weanedCount?: number;
  weaningDate?: string;
  avgWeaningWeightKg?: number;
  notes?: string;
  status: "gestating" | "farrowed" | "weaned" | "failed";
}

// ============================================================================
// Multi-Tenant RBAC, Provisioning, Department, & Maker-Checker Types
// ============================================================================

export type TenantCategory = 
  | "supplier" 
  | "agro_dealer" 
  | "institutional" 
  | "ranching" 
  | "crop" 
  | "feed_milling" 
  | "group_holding"
  | "custom";

export type TenantStatus = "active" | "suspended" | "pending_approval" | "decommissioned";

export interface MakerCheckerConfig {
  enabled: boolean;
  requireDualApprovalForFinancial: boolean;
  requireDualApprovalForDeletion: boolean;
  requireDualApprovalForUserProvision: boolean;
  requireDualApprovalForPriceBoard: boolean;
  financialThresholdZmw: number;
  backupAdminEmail?: string;
  backupAdminName?: string;
  fallbackToSuperAdmin: boolean;
}

export interface TenantDepartment {
  id: string;
  name: string;
  code: string;
  description?: string;
  tenantId: string;
  headOfDepartmentEmail?: string;
  headOfDepartmentName?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface GranularPermission {
  read: boolean;
  write: boolean;
  delete?: boolean;
  approve?: boolean;
}

export interface TenantRole {
  id: string;
  name: string;
  description?: string;
  tenantId: string;
  departmentId?: string;
  departmentName?: string;
  isTenantAdmin?: boolean;
  modulePermissions: Record<string, GranularPermission>;
  permittedModules?: string[];
  createdAt: string;
  updatedAt?: string;
}

export interface TenantRecord {
  id: string;
  name: string; // Entity/company name
  registrationNumber: string; // PACRA / Company registration number
  corporateEmail: string;
  contactPhone: string;
  tenantType: TenantCategory;
  status: TenantStatus;
  adminName: string;
  adminEmail: string;
  adminUid?: string;
  adminPhone?: string;
  logoUrl?: string;
  address?: string;
  province?: string;
  district?: string;
  templatePreset?: string;
  departments: TenantDepartment[];
  roles: TenantRole[];
  makerCheckerConfig: MakerCheckerConfig;
  customDomain?: string;
  subdomain?: string;
  isSponsored?: boolean;
  sponsoredByInstitutionId?: string;
  credits?: number;
  smsCreditBalance?: number;
  welcomeEmailDispatched?: boolean;
  welcomeEmailDispatchedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export type ApprovalActionType = 
  | "CREATE" 
  | "UPDATE" 
  | "DELETE" 
  | "FINANCIAL_ADJUSTMENT" 
  | "USER_PROVISION" 
  | "ROLE_UPDATE" 
  | "CREDIT_ALLOCATION" 
  | "DISPOSAL" 
  | "PAYROLL_APPROVAL"
  | "PRICE_BOARD_CHANGE"
  | "BANK_RECONCILIATION";

export type ApprovalStatus = "PENDING" | "APPROVED" | "REJECTED" | "CANCELLED";

export interface MakerCheckerApprovalRequest {
  id: string;
  tenantId: string;
  tenantName: string;
  actionType: ApprovalActionType;
  entityType: string; // e.g. "User", "Inventory", "Asset", "Expense", "Invoice", "Payroll"
  entityId: string;
  entityTitle?: string;
  makerUid: string;
  makerEmail: string;
  makerName: string;
  makerRole: string;
  makerDepartment?: string;
  reason: string; // Mandatory justification reason
  originalPayload?: any;
  proposedPayload?: any;
  status: ApprovalStatus;
  checkerUid?: string;
  checkerEmail?: string;
  checkerName?: string;
  checkerRole?: string;
  reviewNotes?: string;
  reviewedAt?: string;
  isEscalatedToSuperAdmin?: boolean;
  backupAdminEmail?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TenantTemplatePreset {
  id: string;
  name: string;
  category: TenantCategory;
  description: string;
  iconName: string;
  badgeColor: string;
  defaultDepartments: { name: string; code: string; description: string }[];
  defaultRoles: {
    name: string;
    description: string;
    departmentCode: string;
    isTenantAdmin?: boolean;
    permittedModules: string[];
    modulePermissions: Record<string, GranularPermission>;
  }[];
  defaultAccounts: { code: string; name: string; type: string; category: string }[];
  recommendedModules: string[];
}

// -------------------------------------------------------------
// RESELLER & SUBSCRIPTION COMMISSION ENGINE
// -------------------------------------------------------------

export interface ResellerPartner {
  id: string;
  resellerCode: string;
  name: string;
  organization?: string;
  email: string;
  phone: string;
  district?: string;
  province?: string;
  status: "active" | "inactive" | "suspended";
  commissionModel: "percentage" | "flat"; // 'percentage' e.g. 20% or 'flat' e.g. K50/month per active paid farmer
  commissionRate: number; // e.g. 20 (%) or 50 (ZMW flat fee)
  payoutProvider: "airtel" | "mtn" | "zamtel" | "bank";
  payoutAccountNumber: string;
  payoutAccountName: string;
  bankName?: string;
  totalOnboardedFarmers: number;
  activeSubscribers: number;
  totalSubscriptionVolumeZMW: number;
  accumulatedCommissionZMW: number;
  settledCommissionZMW: number;
  unsettledBalanceZMW: number;
  joinedAt: string;
  lastPayoutAt?: string;
  notes?: string;
}

export interface ResellerCommissionRecord {
  id: string;
  resellerId: string;
  resellerCode: string;
  resellerName: string;
  farmerUid: string;
  farmerName: string;
  farmerEmail: string;
  farmerPhone?: string;
  farmOrBusinessName?: string;
  subscriptionPackage: string;
  subscriptionFeeZMW: number;
  commissionModel: "percentage" | "flat";
  commissionRate: number;
  commissionAmountZMW: number;
  paymentReference: string;
  paymentMethod: string;
  status: "accrued" | "settled" | "cancelled";
  settlementBatchId?: string;
  settledAt?: string;
  monthPeriod: string; // "YYYY-MM"
  createdAt: string;
}

export interface ResellerSettlementPayout {
  id: string;
  payoutReference: string;
  resellerId: string;
  resellerCode: string;
  resellerName: string;
  amountZMW: number;
  feeZMW: number;
  netDisbursedZMW: number;
  payoutProvider: "airtel" | "mtn" | "zamtel" | "bank";
  payoutAccount: string;
  accountName: string;
  bankName?: string;
  lipilaTransactionId: string;
  lipilaStatus: "Completed" | "Processing" | "Pending" | "Failed";
  settledByAdminUid: string;
  settledByAdminEmail: string;
  commissionRecordIds: string[];
  periodCovered: string;
  settledAt: string;
  notes?: string;
}

export interface BulkUserRegistrationRow {
  fullName: string;
  email: string;
  phone: string;
  role: "Farmer" | "Agro Dealer" | "Institutional Supplier" | "Offtaker" | "Agronomist" | "Platform Partner";
  farmOrBusinessName?: string;
  resellerCode?: string;
  province?: string;
  district?: string;
  defaultPassword?: string;
  isValid?: boolean;
  validationError?: string;
}









/**
 * Mabala.cloud - Authoritative Server-Side Loan Management API Routes
 * Enforces Tenant Isolation, Double-Entry Accounting, and Immutable Financial Events
 */

import { Express, Request, Response } from "express";
import crypto from "crypto";
import {
  Loan,
  LoanProduct,
  LoanApplication,
  LoanTransaction,
  RepaymentScheduleItem,
  PortfolioMetrics
} from "../modules/loans/types.js";
import {
  generateRepaymentSchedule,
  calculateWaterfallAllocation,
  evaluateAgingBucket,
  computePortfolioMetrics
} from "../modules/loans/engine/loanCalculations.js";
import {
  generateDisbursementJournal,
  generateRepaymentJournal,
  generateWriteOffJournal,
  computeEventHash
} from "../modules/loans/engine/loanAccounting.js";
import { DEFAULT_LOAN_PRODUCTS } from "../modules/loans/data/defaultLoanProducts.js";

export interface LoanRouteDeps {
  FIRESTORE_BASE_URL: string;
  FIREBASE_API_KEY: string;
  safeFetchJson: (url: string, options?: any) => Promise<any>;
  resilientGetDoc: (path: string) => Promise<any>;
  resilientSetDoc: (path: string, data: any, options?: any) => Promise<any>;
}

// In-memory cache & fallback store for resilient operation across environments
const inMemoryLoanProducts = new Map<string, LoanProduct>();
const inMemoryApplications = new Map<string, LoanApplication>();
const inMemoryLoans = new Map<string, Loan>();
const inMemoryTransactions = new Map<string, LoanTransaction[]>();

// Pre-populate with default Zambian agricultural & enterprise products
DEFAULT_LOAN_PRODUCTS.forEach((p) => inMemoryLoanProducts.set(p.id, p));

export function registerLoanRoutes(app: Express, deps: LoanRouteDeps) {
  const { resilientGetDoc, resilientSetDoc, safeFetchJson, FIRESTORE_BASE_URL, FIREBASE_API_KEY } = deps;

  /**
   * Helper: Fetch all documents in a collection via Firestore REST / Admin
   */
  async function listFirestoreCollection(colName: string): Promise<any[]> {
    try {
      const url = `${FIRESTORE_BASE_URL}/${colName}?key=${FIREBASE_API_KEY}`;
      const res = await safeFetchJson(url, { method: "GET" });
      if (res && Array.isArray(res.documents)) {
        return res.documents.map((doc: any) => {
          const id = doc.name ? doc.name.split("/").pop() : "";
          // Parse fields
          const data: any = { id };
          if (doc.fields) {
            for (const [key, valObj] of Object.entries(doc.fields as Record<string, any>)) {
              if (valObj.stringValue !== undefined) data[key] = valObj.stringValue;
              else if (valObj.integerValue !== undefined) data[key] = Number(valObj.integerValue);
              else if (valObj.doubleValue !== undefined) data[key] = Number(valObj.doubleValue);
              else if (valObj.booleanValue !== undefined) data[key] = valObj.booleanValue;
              else if (valObj.arrayValue !== undefined) {
                data[key] = (valObj.arrayValue.values || []).map((v: any) => v.stringValue || v.integerValue || v.doubleValue || v);
              } else if (valObj.mapValue !== undefined) {
                data[key] = valObj.mapValue.fields;
              }
            }
          }
          return data;
        });
      }
    } catch (_) {}
    return [];
  }

  // =========================================================================
  // 1. LOAN PRODUCTS
  // =========================================================================

  app.get("/api/loans/products", async (req: Request, res: Response) => {
    try {
      const { tenantId, financingModel, status } = req.query;

      // Check Firestore
      let products = await listFirestoreCollection("loan_products");
      if (!products || products.length === 0) {
        products = Array.from(inMemoryLoanProducts.values());
      }

      // Filter: Products posted by Agro Dealers and Suppliers are immediately visible to all farmers.
      // Filtering by tenantId is only applied if explicitly requested by a lender desk for managing their own catalog.
      let filtered = products;
      if (financingModel) {
        filtered = filtered.filter((p) => p.financingModel === financingModel);
      }
      if (status) {
        filtered = filtered.filter((p) => p.status === status);
      }
      if (tenantId && (req.query.forLenderOnly === "true" || req.query.deskView === "true")) {
        filtered = filtered.filter((p) => p.tenantId === tenantId);
      }

      res.json({ success: true, count: filtered.length, products: filtered });
    } catch (err: any) {
      console.error("[Loans API] Error listing products:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post("/api/loans/products", async (req: Request, res: Response) => {
    try {
      const p = req.body as Partial<LoanProduct>;
      if (!p.name || !p.financingModel || !p.tenantId) {
        res.status(400).json({ success: false, error: "Missing required fields: name, financingModel, tenantId" });
        return;
      }

      const id = p.id || `prod-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const now = new Date().toISOString();

      const product: LoanProduct = {
        id,
        tenantId: p.tenantId,
        issuerName: p.issuerName || "Agro Dealer / Lender",
        name: p.name,
        code: p.code || `LN-${p.name.substring(0, 3).toUpperCase()}`,
        description: p.description || "",
        financingModel: p.financingModel,
        targetSector: p.targetSector || "crop",
        currency: p.currency || "ZMW",
        minPrincipal: Number(p.minPrincipal) || 500,
        maxPrincipal: Number(p.maxPrincipal) || 100000,
        defaultPrincipal: Number(p.defaultPrincipal) || 5000,
        interestRatePct: Number(p.interestRatePct) || 15,
        interestCalculationMethod: p.interestCalculationMethod || "flat",
        repaymentFrequency: p.repaymentFrequency || "monthly",
        defaultTenorValue: Number(p.defaultTenorValue) || 6,
        tenorUnit: p.tenorUnit || "months",
        gracePeriodValue: Number(p.gracePeriodValue) || 0,
        gracePeriodUnit: p.gracePeriodUnit || "months",
        originationFeePct: Number(p.originationFeePct) || 2,
        originationFeeFixed: Number(p.originationFeeFixed) || 0,
        originationFeeDeduction: p.originationFeeDeduction || "deduct_from_disbursement",
        latePenaltyRatePct: Number(p.latePenaltyRatePct) || 3,
        lateGraceDays: Number(p.lateGraceDays) || 7,
        disbursementMethodsAllowed: p.disbursementMethodsAllowed || ["mobile_money", "mabala_wallet"],
        collateralRequired: !!p.collateralRequired,
        requiresCropCycleLink: !!p.requiresCropCycleLink,
        status: p.status || "active",
        createdAt: p.createdAt || now,
        updatedAt: now
      };

      inMemoryLoanProducts.set(id, product);
      await resilientSetDoc(`loan_products/${id}`, product);

      res.status(201).json({ success: true, product });
    } catch (err: any) {
      console.error("[Loans API] Error creating product:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.delete("/api/loans/products", async (req: Request, res: Response) => {
    try {
      inMemoryLoanProducts.clear();
      // Also delete from Firestore if any documents exist
      const existing = await listFirestoreCollection("loan_products");
      for (const prod of existing) {
        if (prod.id) {
          try {
            const delUrl = `${FIRESTORE_BASE_URL}/loan_products/${prod.id}?key=${FIREBASE_API_KEY}`;
            await safeFetchJson(delUrl, { method: "DELETE" });
          } catch (_) {}
        }
      }
      res.json({ success: true, message: "All loan products and facilities successfully removed from the platform" });
    } catch (err: any) {
      console.error("[Loans API] Error deleting all products:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.delete("/api/loans/products/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      inMemoryLoanProducts.delete(id);
      try {
        const delUrl = `${FIRESTORE_BASE_URL}/loan_products/${id}?key=${FIREBASE_API_KEY}`;
        await safeFetchJson(delUrl, { method: "DELETE" });
      } catch (_) {}
      res.json({ success: true, message: `Product ${id} removed` });
    } catch (err: any) {
      console.error("[Loans API] Error deleting product:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // =========================================================================
  // 2. LOAN APPLICATIONS
  // =========================================================================

  app.get("/api/loans/applications", async (req: Request, res: Response) => {
    try {
      const { tenantId, lenderTenantId, status } = req.query;

      let apps = await listFirestoreCollection("loan_applications");
      if (!apps || apps.length === 0) {
        apps = Array.from(inMemoryApplications.values());
      }

      let filtered = apps;
      if (tenantId) {
        filtered = filtered.filter((a) => a.tenantId === tenantId);
      }
      if (lenderTenantId) {
        filtered = filtered.filter((a) => a.lenderTenantId === lenderTenantId);
      }
      if (status) {
        filtered = filtered.filter((a) => a.status === status);
      }

      res.json({ success: true, count: filtered.length, applications: filtered });
    } catch (err: any) {
      console.error("[Loans API] Error fetching applications:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post("/api/loans/applications", async (req: Request, res: Response) => {
    try {
      const body = req.body as Partial<LoanApplication>;
      if (!body.tenantId || !body.productId || !body.requestedAmount || !body.borrowerName) {
        res.status(400).json({ success: false, error: "Missing required application parameters" });
        return;
      }

      const product = inMemoryLoanProducts.get(body.productId) || (await resilientGetDoc(`loan_products/${body.productId}`)) || DEFAULT_LOAN_PRODUCTS.find((p) => p.id === body.productId);
      const lenderTenantId = body.lenderTenantId || product?.tenantId || "TENANT-PLATFORM-AGRI";

      const id = `app-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const appNumber = `APP-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const now = new Date().toISOString();

      const newApp: LoanApplication = {
        id,
        applicationNumber: appNumber,
        tenantId: body.tenantId,
        lenderTenantId,
        borrowerId: body.borrowerId || body.tenantId,
        borrowerName: body.borrowerName,
        borrowerPhone: body.borrowerPhone || "",
        borrowerNrc: body.borrowerNrc || "",
        borrowerEmail: body.borrowerEmail,
        borrowerFarmName: body.borrowerFarmName,
        borrowerProvince: body.borrowerProvince,
        borrowerDistrict: body.borrowerDistrict,
        productId: body.productId,
        productName: product ? product.name : (body.productName || "Agricultural Credit"),
        financingModel: product ? product.financingModel : (body.financingModel || "agricultural_crop"),
        requestedAmount: Number(body.requestedAmount),
        requestedTenorValue: Number(body.requestedTenorValue || product?.defaultTenorValue || 6),
        requestedTenorUnit: body.requestedTenorUnit || product?.tenorUnit || "months",
        purpose: body.purpose || "Seasonal crop production inputs",
        cropCycleId: body.cropCycleId,
        cropCycleName: body.cropCycleName,
        cropExpectedHarvestDate: body.cropExpectedHarvestDate,
        inputBasket: body.inputBasket || [],
        collateralDescription: body.collateralDescription,
        collateralEstimatedValue: Number(body.collateralEstimatedValue) || 0,
        disbursementMethod: body.disbursementMethod || "mobile_money",
        disbursementAccount: body.disbursementAccount || body.borrowerPhone || "",
        disbursementNetwork: body.disbursementNetwork || "airtel",
        status: "submitted",
        createdAt: now,
        updatedAt: now
      };

      inMemoryApplications.set(id, newApp);
      await resilientSetDoc(`loan_applications/${id}`, newApp);

      res.status(201).json({ success: true, application: newApp });
    } catch (err: any) {
      console.error("[Loans API] Error creating application:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post("/api/loans/applications/:id/review", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { action, reviewer, reason, approvedAmount, approvedInterestRatePct, approvedTenorValue } = req.body;

      if (!action || !["approve", "reject"].includes(action)) {
        res.status(400).json({ success: false, error: "Action must be either 'approve' or 'reject'" });
        return;
      }

      // Fetch application
      let appData: LoanApplication | null = inMemoryApplications.get(id) || null;
      if (!appData) {
        const snap = await resilientGetDoc(`loan_applications/${id}`);
        if (snap.exists) appData = snap.data() as LoanApplication;
      }

      if (!appData) {
        res.status(404).json({ success: false, error: "Application not found" });
        return;
      }

      const now = new Date().toISOString();
      if (action === "reject") {
        appData.status = "rejected";
        appData.rejectionReason = reason || "Credit assessment criteria not satisfied";
        appData.reviewedBy = reviewer || "Credit Committee";
        appData.reviewedAt = now;
        appData.updatedAt = now;
      } else {
        appData.status = "approved";
        appData.reviewedBy = reviewer || "Credit Officer";
        appData.reviewedAt = now;
        appData.approvedAmount = approvedAmount ? Number(approvedAmount) : appData.requestedAmount;
        appData.approvedInterestRatePct = approvedInterestRatePct ? Number(approvedInterestRatePct) : undefined;
        appData.approvedTenorValue = approvedTenorValue ? Number(approvedTenorValue) : appData.requestedTenorValue;
        appData.updatedAt = now;
      }

      inMemoryApplications.set(id, appData);
      await resilientSetDoc(`loan_applications/${id}`, appData);

      res.json({ success: true, application: appData });
    } catch (err: any) {
      console.error("[Loans API] Error reviewing application:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // =========================================================================
  // 3. AUTHORITATIVE LOAN DISBURSEMENT
  // =========================================================================

  app.post("/api/loans/disburse", async (req: Request, res: Response) => {
    try {
      const {
        applicationId,
        customDisbursementDate,
        disbursementMethod,
        disbursementAccount,
        authorizingOfficer
      } = req.body;

      if (!applicationId) {
        res.status(400).json({ success: false, error: "Application ID is required" });
        return;
      }

      // Fetch application
      let appData: LoanApplication | null = inMemoryApplications.get(applicationId) || null;
      if (!appData) {
        const snap = await resilientGetDoc(`loan_applications/${applicationId}`);
        if (snap.exists) appData = snap.data() as LoanApplication;
      }

      if (!appData) {
        res.status(404).json({ success: false, error: "Loan application not found" });
        return;
      }

      if (appData.status === "disbursed") {
        res.status(400).json({ success: false, error: "This loan application has already been disbursed" });
        return;
      }

      // Fetch Product
      const product = inMemoryLoanProducts.get(appData.productId) || (await resilientGetDoc(`loan_products/${appData.productId}`)) || DEFAULT_LOAN_PRODUCTS.find((p) => p.id === appData.productId);
      const interestRate = appData.approvedInterestRatePct || product?.interestRatePct || 15;
      const principal = appData.approvedAmount || appData.requestedAmount;
      const tenorVal = appData.approvedTenorValue || appData.requestedTenorValue;
      const tenorUnit = appData.requestedTenorUnit || product?.tenorUnit || "months";
      const calcMethod = product?.interestCalculationMethod || "flat";
      const frequency = product?.repaymentFrequency || "monthly";

      const disbDate = customDisbursementDate || new Date().toISOString().split("T")[0];

      // Calculate Origination Fee
      const origFeePct = product?.originationFeePct || 0;
      const origFeeFixed = product?.originationFeeFixed || 0;
      const totalOrigFee = Number(((principal * (origFeePct / 100)) + origFeeFixed).toFixed(2));

      // Generate Deterministic Amortization / Repayment Schedule
      const schedule = generateRepaymentSchedule({
        principal,
        annualInterestRatePct: interestRate,
        interestCalculationMethod: calcMethod,
        repaymentFrequency: frequency,
        tenorValue: tenorVal,
        tenorUnit: tenorUnit,
        disbursementDate: disbDate,
        originationFeeTotal: totalOrigFee,
        financingModel: appData.financingModel,
        harvestDate: appData.cropExpectedHarvestDate
      });

      const totalExpectedInterest = schedule.reduce((sum, s) => sum + s.interestDue, 0);
      const totalFeesDue = schedule.reduce((sum, s) => sum + s.feesDue, 0);
      const totalLoanAmount = Number((principal + totalExpectedInterest + totalFeesDue).toFixed(2));

      const firstRepaymentDate = schedule[0]?.dueDate || disbDate;
      const maturityDate = schedule[schedule.length - 1]?.dueDate || disbDate;
      const nextRepaymentDueAmount = schedule[0]?.totalDue || 0;

      const loanId = `loan-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const loanNumber = `LN-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
      const now = new Date().toISOString();

      const loan: Loan = {
        id: loanId,
        loanNumber,
        tenantId: appData.tenantId,
        lenderTenantId: appData.lenderTenantId,
        borrowerId: appData.borrowerId,
        borrowerName: appData.borrowerName,
        borrowerPhone: appData.borrowerPhone,
        borrowerNrc: appData.borrowerNrc,
        borrowerFarmName: appData.borrowerFarmName,
        lenderName: product?.issuerName || "Mabala Lender",
        productId: appData.productId,
        productName: appData.productName,
        financingModel: appData.financingModel,
        currency: product?.currency || "ZMW",
        principalDisbursed: principal,
        totalPrincipalRepaid: 0,
        principalOutstanding: principal,
        interestRatePct: interestRate,
        interestCalculationMethod: calcMethod,
        totalInterestAccrued: totalExpectedInterest,
        totalInterestRepaid: 0,
        interestOutstanding: totalExpectedInterest,
        totalFeesCharged: totalFeesDue,
        totalFeesRepaid: 0,
        feesOutstanding: totalFeesDue,
        totalPenaltiesCharged: 0,
        totalPenaltiesRepaid: 0,
        penaltiesOutstanding: 0,
        totalLoanAmount,
        totalRepaid: 0,
        totalOutstandingBalance: totalLoanAmount,
        repaymentFrequency: frequency,
        tenorValue: tenorVal,
        tenorUnit: tenorUnit,
        disbursementDate: disbDate,
        maturityDate,
        firstRepaymentDate,
        nextRepaymentDueDate: firstRepaymentDate,
        nextRepaymentDueAmount,
        daysPastDue: 0,
        agingBucket: "current",
        status: "active",
        cropCycleId: appData.cropCycleId,
        cropCycleName: appData.cropCycleName,
        inputBasket: appData.inputBasket,
        disbursementReference: `DISB-REF-${Date.now()}`,
        disbursementMethod: disbursementMethod || appData.disbursementMethod || "mobile_money",
        disbursementAccount: disbursementAccount || appData.disbursementAccount,
        schedule,
        createdAt: now,
        updatedAt: now
      };

      // Generate Balanced Double-Entry Journal Entry
      const journalEntry = generateDisbursementJournal(loan, loan.disbursementMethod, product?.originationFeeDeduction === "deduct_from_disbursement" ? totalOrigFee : 0);

      // Generate Immutable Disbursement Transaction with SHA256 Hash
      const txId = `TX-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      const hash = computeEventHash({
        loanId: loan.id,
        type: "disbursement",
        amount: principal,
        timestamp: now,
        referenceId: loan.disbursementReference
      });

      const transaction: LoanTransaction = {
        id: txId,
        loanId: loan.id,
        tenantId: loan.tenantId,
        lenderTenantId: loan.lenderTenantId,
        type: "disbursement",
        amount: principal,
        principalPortion: principal,
        interestPortion: 0,
        feePortion: totalOrigFee,
        penaltyPortion: 0,
        source: loan.disbursementMethod === "mabala_wallet" ? "mabala_ledger" : "lipila_mobile_money",
        referenceId: loan.disbursementReference,
        journalEntryId: journalEntry.id,
        balanceBefore: 0,
        balanceAfter: totalLoanAmount,
        notes: `Authoritative disbursement by ${authorizingOfficer || "Credit Manager"}. Dispatched to ${loan.disbursementAccount}`,
        performedBy: authorizingOfficer || "System Credit Authority",
        timestamp: now,
        immutableHash: hash
      };

      // Update in-memory state
      inMemoryLoans.set(loan.id, loan);
      inMemoryTransactions.set(loan.id, [transaction]);
      appData.status = "disbursed";
      appData.loanId = loan.id;
      appData.updatedAt = now;
      inMemoryApplications.set(appData.id, appData);

      // Persist to Firestore
      await resilientSetDoc(`loans/${loan.id}`, loan);
      await resilientSetDoc(`loans/${loan.id}/transactions/${txId}`, transaction);
      await resilientSetDoc(`loan_applications/${appData.id}`, appData);
      await resilientSetDoc(`loan_audit_log/${journalEntry.id}`, journalEntry);

      res.status(201).json({
        success: true,
        loan,
        journalEntry,
        transaction
      });
    } catch (err: any) {
      console.error("[Loans API] Disbursement error:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // =========================================================================
  // 4. LOANS QUERYING & METRICS
  // =========================================================================

  app.get("/api/loans", async (req: Request, res: Response) => {
    try {
      const { tenantId, lenderTenantId, status, financingModel } = req.query;

      let loans = await listFirestoreCollection("loans");
      if (!loans || loans.length === 0) {
        loans = Array.from(inMemoryLoans.values());
      }

      let filtered = loans;
      if (tenantId) {
        filtered = filtered.filter((l) => l.tenantId === tenantId);
      }
      if (lenderTenantId) {
        filtered = filtered.filter((l) => l.lenderTenantId === lenderTenantId);
      }
      if (status) {
        filtered = filtered.filter((l) => l.status === status);
      }
      if (financingModel) {
        filtered = filtered.filter((l) => l.financingModel === financingModel);
      }

      res.json({ success: true, count: filtered.length, loans: filtered });
    } catch (err: any) {
      console.error("[Loans API] Error fetching loans:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.get("/api/loans/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;

      let loan: Loan | null = inMemoryLoans.get(id) || null;
      if (!loan) {
        const snap = await resilientGetDoc(`loans/${id}`);
        if (snap.exists) loan = snap.data() as Loan;
      }

      if (!loan) {
        res.status(404).json({ success: false, error: "Loan not found" });
        return;
      }

      // Fetch transactions
      let transactions = inMemoryTransactions.get(id) || [];
      if (transactions.length === 0) {
        transactions = await listFirestoreCollection(`loans/${id}/transactions`);
      }

      res.json({ success: true, loan, transactions });
    } catch (err: any) {
      console.error("[Loans API] Error fetching loan details:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // =========================================================================
  // 5. AUTHORITATIVE REPAYMENT (SERVER-SIDE FINANCIAL AUTHORITY)
  // =========================================================================

  app.post("/api/loans/:id/repay", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { amount, source, referenceId, notes, performedBy } = req.body;

      const paymentAmount = Number(amount);
      if (!paymentAmount || paymentAmount <= 0) {
        res.status(400).json({ success: false, error: "Valid positive repayment amount is required" });
        return;
      }

      let loan: Loan | null = inMemoryLoans.get(id) || null;
      if (!loan) {
        const snap = await resilientGetDoc(`loans/${id}`);
        if (snap.exists) loan = snap.data() as Loan;
      }

      if (!loan) {
        res.status(404).json({ success: false, error: "Loan not found" });
        return;
      }

      if (loan.status === "paid_off") {
        res.status(400).json({ success: false, error: "This loan is already fully settled" });
        return;
      }

      const balanceBefore = loan.totalOutstandingBalance;

      // Calculate authoritative waterfall allocation
      const allocation = calculateWaterfallAllocation(paymentAmount, loan);

      // Update Loan Balances
      loan.penaltiesOutstanding = allocation.newPenaltiesOutstanding;
      loan.feesOutstanding = allocation.newFeesOutstanding;
      loan.interestOutstanding = allocation.newInterestOutstanding;
      loan.principalOutstanding = allocation.newPrincipalOutstanding;
      loan.totalOutstandingBalance = allocation.newTotalOutstanding;

      loan.totalPenaltiesRepaid = Number(((loan.totalPenaltiesRepaid || 0) + allocation.penaltyPortion).toFixed(2));
      loan.totalFeesRepaid = Number(((loan.totalFeesRepaid || 0) + allocation.feePortion).toFixed(2));
      loan.totalInterestRepaid = Number(((loan.totalInterestRepaid || 0) + allocation.interestPortion).toFixed(2));
      loan.totalPrincipalRepaid = Number(((loan.totalPrincipalRepaid || 0) + allocation.principalPortion).toFixed(2));
      loan.totalRepaid = Number(((loan.totalRepaid || 0) + paymentAmount - allocation.unallocatedOverpayment).toFixed(2));

      loan.schedule = allocation.updatedSchedule;

      // Find next unpaid installment
      const nextPending = loan.schedule.find((s) => s.status !== "paid");
      if (nextPending) {
        loan.nextRepaymentDueDate = nextPending.dueDate;
        loan.nextRepaymentDueAmount = nextPending.balanceRemaining;
      } else {
        loan.nextRepaymentDueDate = "";
        loan.nextRepaymentDueAmount = 0;
      }

      // Re-evaluate aging bucket and status
      const aging = evaluateAgingBucket(loan.nextRepaymentDueDate, loan.totalOutstandingBalance);
      loan.daysPastDue = aging.daysPastDue;
      loan.agingBucket = aging.agingBucket;

      if (loan.totalOutstandingBalance <= 0.01) {
        loan.status = "paid_off";
      } else if (aging.daysPastDue > 0) {
        loan.status = "in_arrears";
      } else {
        loan.status = "active";
      }

      const now = new Date().toISOString();
      loan.updatedAt = now;

      // Generate Balanced Double-Entry Journal Entry
      const breakdown = {
        principal: allocation.principalPortion,
        interest: allocation.interestPortion,
        fee: allocation.feePortion,
        penalty: allocation.penaltyPortion
      };
      const txId = `TX-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      const journalEntry = generateRepaymentJournal(loan, paymentAmount - allocation.unallocatedOverpayment, breakdown, source || "lipila_mobile_money", txId);

      // Fetch last transaction hash for tamper-evident event chain
      const existingTxs = inMemoryTransactions.get(id) || [];
      const prevHash = existingTxs.length > 0 ? existingTxs[existingTxs.length - 1].immutableHash : undefined;

      const hash = computeEventHash({
        loanId: loan.id,
        type: "repayment",
        amount: paymentAmount,
        timestamp: now,
        referenceId: referenceId || txId,
        previousHash: prevHash
      });

      const transaction: LoanTransaction = {
        id: txId,
        loanId: loan.id,
        tenantId: loan.tenantId,
        lenderTenantId: loan.lenderTenantId,
        type: "repayment",
        amount: paymentAmount,
        principalPortion: allocation.principalPortion,
        interestPortion: allocation.interestPortion,
        feePortion: allocation.feePortion,
        penaltyPortion: allocation.penaltyPortion,
        source: source || "lipila_mobile_money",
        referenceId: referenceId || txId,
        journalEntryId: journalEntry.id,
        balanceBefore,
        balanceAfter: loan.totalOutstandingBalance,
        notes: notes || `Repayment received. Allocated: P ${allocation.principalPortion}, I ${allocation.interestPortion}, F ${allocation.feePortion}`,
        performedBy: performedBy || "Automated Payment Processor",
        timestamp: now,
        immutableHash: hash,
        previousTxHash: prevHash
      };

      // Save in memory & Firestore
      inMemoryLoans.set(loan.id, loan);
      existingTxs.push(transaction);
      inMemoryTransactions.set(loan.id, existingTxs);

      await resilientSetDoc(`loans/${loan.id}`, loan);
      await resilientSetDoc(`loans/${loan.id}/transactions/${txId}`, transaction);
      await resilientSetDoc(`loan_audit_log/${journalEntry.id}`, journalEntry);

      res.json({
        success: true,
        loan,
        allocation,
        journalEntry,
        transaction
      });
    } catch (err: any) {
      console.error("[Loans API] Repayment processing error:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // =========================================================================
  // 6. LOAN WRITE-OFF
  // =========================================================================

  app.post("/api/loans/:id/write-off", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { reason, approvedBy } = req.body;

      let loan: Loan | null = inMemoryLoans.get(id) || null;
      if (!loan) {
        const snap = await resilientGetDoc(`loans/${id}`);
        if (snap.exists) loan = snap.data() as Loan;
      }

      if (!loan) {
        res.status(404).json({ success: false, error: "Loan not found" });
        return;
      }

      const pWrite = loan.principalOutstanding;
      const iWrite = loan.interestOutstanding;
      const totalWritten = Number((pWrite + iWrite).toFixed(2));
      const balanceBefore = loan.totalOutstandingBalance;

      loan.principalOutstanding = 0;
      loan.interestOutstanding = 0;
      loan.feesOutstanding = 0;
      loan.penaltiesOutstanding = 0;
      loan.totalOutstandingBalance = 0;
      loan.status = "written_off";
      const now = new Date().toISOString();
      loan.updatedAt = now;

      // Journal entry
      const journalEntry = generateWriteOffJournal(loan, pWrite, iWrite, reason || "Default - uncollectible");

      const txId = `TX-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      const hash = computeEventHash({
        loanId: loan.id,
        type: "write_off",
        amount: totalWritten,
        timestamp: now,
        referenceId: journalEntry.id
      });

      const transaction: LoanTransaction = {
        id: txId,
        loanId: loan.id,
        tenantId: loan.tenantId,
        lenderTenantId: loan.lenderTenantId,
        type: "write_off",
        amount: totalWritten,
        principalPortion: pWrite,
        interestPortion: iWrite,
        feePortion: 0,
        penaltyPortion: 0,
        source: "manual_admin",
        referenceId: journalEntry.id,
        journalEntryId: journalEntry.id,
        balanceBefore,
        balanceAfter: 0,
        notes: `Authoritative write-off approved by ${approvedBy || "Credit Committee"}. Reason: ${reason}`,
        performedBy: approvedBy || "Credit Committee",
        timestamp: now,
        immutableHash: hash
      };

      inMemoryLoans.set(loan.id, loan);
      const txs = inMemoryTransactions.get(loan.id) || [];
      txs.push(transaction);
      inMemoryTransactions.set(loan.id, txs);

      await resilientSetDoc(`loans/${loan.id}`, loan);
      await resilientSetDoc(`loans/${loan.id}/transactions/${txId}`, transaction);
      await resilientSetDoc(`loan_audit_log/${journalEntry.id}`, journalEntry);

      res.json({ success: true, loan, journalEntry, transaction });
    } catch (err: any) {
      console.error("[Loans API] Write-off error:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // =========================================================================
  // 7. INSTITUTIONAL PORTFOLIO ANALYTICS (Institution / Fund Oversight)
  // =========================================================================

  app.get("/api/loans/portfolio/analytics", async (req: Request, res: Response) => {
    try {
      const { lenderTenantId } = req.query;

      let loans = await listFirestoreCollection("loans");
      if (!loans || loans.length === 0) {
        loans = Array.from(inMemoryLoans.values());
      }

      if (lenderTenantId) {
        loans = loans.filter((l) => l.lenderTenantId === lenderTenantId);
      }

      const metrics = computePortfolioMetrics(loans);

      res.json({ success: true, metrics });
    } catch (err: any) {
      console.error("[Loans API] Portfolio analytics error:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });
}

import express from "express";
import type { Firestore } from "firebase-admin/firestore";
import { 
  DEFAULT_STAGE_TEMPLATES, 
  validateStageTemplate,
  evaluateAnimalProgression,
  executeStageTransition
} from "../services/livestockProgressionService.js";
import type { LivestockStageTemplate, LivestockRecord, LivestockStage } from "../types.js";

export interface LivestockProgressionRouteDeps {
  getAdminDb: () => Firestore;
}

export function registerLivestockProgressionRoutes(app: express.Express, deps: LivestockProgressionRouteDeps): void {
  const router = express.Router();

  // Middleware for tenant extraction
  const extractTenant = (req: express.Request): string => {
    const headerTenant = req.headers["x-tenant-id"] as string;
    const queryTenant = req.query.tenantId as string;
    return String(headerTenant || queryTenant || "default").trim();
  };

  // 1. GET /api/livestock/progression/templates
  router.get("/templates", async (req, res) => {
    try {
      const tenantId = extractTenant(req);
      const db = deps.getAdminDb();
      const snapshot = await db.collection("tenants").doc(tenantId).collection("livestock_stage_templates").get();

      if (snapshot.empty) {
        // Return defaults
        const defaults = DEFAULT_STAGE_TEMPLATES.map(t => ({ ...t, tenantId }));
        res.json({ templates: defaults, source: "system_defaults" });
        return;
      }

      const templates = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json({ templates, source: "firestore" });
    } catch (err: any) {
      console.error("[GET /api/livestock/progression/templates] Error:", err);
      // Fallback gracefully to default templates
      res.json({ templates: DEFAULT_STAGE_TEMPLATES, source: "fallback_defaults" });
    }
  });

  // 2. POST /api/livestock/progression/templates
  router.post("/templates", async (req, res) => {
    try {
      const tenantId = extractTenant(req);
      const template = req.body as LivestockStageTemplate;
      const validation = validateStageTemplate(template);

      if (!validation.valid) {
        res.status(400).json({ error: "Validation failed", errors: validation.errors });
        return;
      }

      const db = deps.getAdminDb();
      const docRef = db.collection("tenants").doc(tenantId).collection("livestock_stage_templates").doc(template.id);
      
      const payload = {
        ...template,
        tenantId,
        updatedAt: new Date().toISOString()
      };

      await docRef.set(payload, { merge: true });
      res.json({ success: true, template: payload, warnings: validation.warnings });
    } catch (err: any) {
      console.error("[POST /api/livestock/progression/templates] Error:", err);
      res.status(500).json({ error: err.message || "Failed to save template" });
    }
  });

  // 3. POST /api/livestock/progression/evaluate
  router.post("/evaluate", (req, res) => {
    try {
      const tenantId = extractTenant(req);
      const { animal, template } = req.body as { animal: LivestockRecord; template?: LivestockStageTemplate };
      if (!animal || !animal.id) {
        res.status(400).json({ error: "Valid animal object is required" });
        return;
      }

      const result = evaluateAnimalProgression(tenantId, animal, template);
      res.json({ success: true, result });
    } catch (err: any) {
      console.error("[POST /api/livestock/progression/evaluate] Error:", err);
      res.status(500).json({ error: err.message || "Evaluation failed" });
    }
  });

  // 4. POST /api/livestock/progression/transition
  router.post("/transition", async (req, res) => {
    try {
      const tenantId = extractTenant(req);
      const { animal, nextStage, triggerType, options } = req.body as {
        animal: LivestockRecord;
        nextStage: LivestockStage;
        triggerType: any;
        options?: any;
      };

      if (!animal || !nextStage) {
        res.status(400).json({ error: "animal and nextStage are required" });
        return;
      }

      const result = executeStageTransition(tenantId, animal, nextStage, triggerType || "MANUAL", options);

      // Persist to Firestore audit log
      try {
        const db = deps.getAdminDb();
        await db.collection("tenants").doc(tenantId).collection("stage_transitions").doc(result.transitionRecord.id).set(result.transitionRecord);
        await db.collection("tenants").doc(tenantId).collection("biological_valuation_events").doc(result.valuationRecord.id).set(result.valuationRecord);
        await db.collection("tenants").doc(tenantId).collection("accounting_events").doc(result.accountingEvent.id).set(result.accountingEvent);
      } catch (dbErr) {
        console.warn("[POST /api/livestock/progression/transition] Firestore sync note:", dbErr);
      }

      res.json({ success: true, ...result });
    } catch (err: any) {
      console.error("[POST /api/livestock/progression/transition] Error:", err);
      res.status(500).json({ error: err.message || "Transition execution failed" });
    }
  });

  app.use("/api/livestock/progression", router);
}

import express from "express";
import crypto from "crypto";
import { getAuth } from "firebase-admin/auth";
import { getStorage } from "firebase-admin/storage";
import { jsPDF } from "jspdf";
import type { Firestore } from "firebase-admin/firestore";
import {
  PigLifecycleError,
  PigLifecycleService,
  createPigLifecycleState,
  type PigAnimal,
  type PigLifecycleState
} from "../services/pigLifecycleService.js";

const ALL_PIG_PERMISSIONS = [
  "PIG_BREEDING_VIEW", "PIG_BREEDING_CREATE", "PIG_BREEDING_EDIT",
  "PIG_FARROWING_VIEW", "PIG_FARROWING_CREATE", "PIG_FARROWING_EDIT",
  "PIG_LITTER_VIEW", "PIG_LITTER_CREATE", "PIG_LITTER_EDIT",
  "PIG_MORTALITY_VIEW", "PIG_MORTALITY_CREATE", "PIG_MORTALITY_EDIT",
  "PIG_HANDOVER_VIEW", "PIG_HANDOVER_CREATE", "PIG_HANDOVER_ACCEPT", "PIG_HANDOVER_REJECT",
  "PIG_VALUATION_VIEW", "PIG_REPORTS_VIEW"
];

export interface PigLifecycleRouteDeps {
  getAdminDb: () => Firestore;
  getAdminApp: () => any;
}

interface ActorContext {
  uid: string;
  tenantId: string;
  permissions: string[];
  profile: Record<string, any>;
}

function fail(code: string, message: string): never {
  throw new PigLifecycleError(code, message);
}

function cleanId(value: unknown, field: string): string {
  const result = String(value || "").trim();
  if (!result || result.length > 180 || /[\\/]/.test(result)) fail("INVALID_INPUT", `${field} is invalid`);
  return result;
}

function permissionSet(profile: Record<string, any>): string[] {
  if (["owner", "farm owner", "administrator", "super_admin", "platform administrator"].includes(String(profile.role || "").toLowerCase())) return ALL_PIG_PERMISSIONS;
  const result = new Set<string>();
  const source = profile.modulePermissions || profile.permissions || {};
  for (const [key, value] of Object.entries(source)) {
    if (typeof value === "string" && ["read_write", "write", "admin"].includes(value)) result.add(key);
    if (value === true || (value && typeof value === "object" && (value as any).write === true)) result.add(key);
  }
  return [...result];
}

async function resolveActor(req: express.Request, db: Firestore): Promise<ActorContext> {
  const authHeader = String(req.headers.authorization || "");
  if (!authHeader.startsWith("Bearer ")) fail("UNAUTHENTICATED", "Firebase bearer authentication is required");
  let decoded: any;
  try {
    decoded = await getAuth().verifyIdToken(authHeader.slice(7).trim());
  } catch {
    fail("UNAUTHENTICATED", "The Firebase authentication token is invalid or expired");
  }
  const profileSnap = await db.collection("users_data").doc(decoded.uid).get();
  const profile = (profileSnap.data() || {}) as Record<string, any>;
  const tenantId = cleanId(profile.tenantId || decoded.tenantId || decoded.uid, "tenantId");
  const memberSnap = await db.collection("tenants").doc(tenantId).collection("members").doc(decoded.uid).get();
  const isOwner = decoded.uid === tenantId || ["owner", "farm owner", "administrator"].includes(String(profile.role || "").toLowerCase());
  if (!isOwner && (!memberSnap.exists || String(memberSnap.data()?.status || "active").toLowerCase() !== "active")) fail("FORBIDDEN", "The user is not an active tenant member");
  return { uid: decoded.uid, tenantId, profile, permissions: isOwner ? ALL_PIG_PERMISSIONS : permissionSet({ ...profile, ...(memberSnap.data() || {}) }) };
}

function assertPermission(actor: ActorContext, permission: string): void {
  if (!actor.permissions.includes(permission)) fail("FORBIDDEN", `Missing permission ${permission}`);
}

async function assertStaff(db: Firestore, tenantId: string, staffId: string): Promise<Record<string, any>> {
  const id = cleanId(staffId, "staffId");
  const candidates = [
    db.collection("tenants").doc(tenantId).collection("hr_employees").doc(id),
    db.collection("hr_employees").doc(id)
  ];
  for (const ref of candidates) {
    const snap = await ref.get();
    if (snap.exists) {
      const data = snap.data() || {};
      if (data.tenantId && data.tenantId !== tenantId) continue;
      if (["inactive", "terminated", "suspended"].includes(String(data.status || "active").toLowerCase())) fail("STAFF_INACTIVE", "The selected staff member is not active");
      return { id, ...data };
    }
  }
  fail("STAFF_NOT_FOUND", "Staff must come from the HR employee register");
}

async function assertAssignment(db: Firestore, tenantId: string, assignmentId: unknown, staffId: string): Promise<void> {
  if (!assignmentId) return;
  const id = cleanId(assignmentId, "assignmentId");
  const snapshot = await db.collection("tenants").doc(tenantId).collection("staffAssignments").doc(id).get();
  if (!snapshot.exists) fail("ASSIGNMENT_NOT_FOUND", "The staff assignment does not exist");
  const assignment = snapshot.data() || {};
  if (assignment.staffId !== staffId || ["released", "completed", "cancelled"].includes(String(assignment.status || "").toLowerCase())) fail("ASSIGNMENT_INVALID", "The staff assignment is not active for this staff member");
}

async function loadState(db: Firestore, tenantId: string): Promise<PigLifecycleState> {
  const state = createPigLifecycleState();
  const root = db.collection("tenants").doc(tenantId).collection("pigLifecycle").doc("state");
  const collections: Array<[string, Map<string, any>]> = [
    ["animals", state.animals], ["valuations", state.valuations], ["breedingEvents", state.breedingEvents],
    ["farrowingEvents", state.farrowingEvents], ["piglets", state.piglets], ["mortalityEvents", state.mortalityEvents], ["handovers", state.handovers], ["idempotency", state.idempotency]
  ];
  await Promise.all(collections.map(async ([name, map]) => {
    const snapshot = await root.collection(name).get();
    snapshot.forEach(doc => map.set(doc.id, doc.data()));
  }));
  if (state.animals.size === 0) {
    const registrySnapshot = await db.collection("tenants").doc(tenantId).collection("centralRegistry").doc("state").collection("animals").get();
    registrySnapshot.forEach(doc => state.animals.set(doc.id, doc.data() as PigAnimal));
  }
  if (state.valuations.size === 0) {
    const valuationSnapshot = await db.collection("tenants").doc(tenantId).collection("centralRegistry").doc("state").collection("valuations").get();
    valuationSnapshot.forEach(doc => state.valuations.set(doc.id, doc.data() as any));
  }
  return state;
}

async function saveState(db: Firestore, tenantId: string, state: PigLifecycleState): Promise<void> {
  const root = db.collection("tenants").doc(tenantId).collection("pigLifecycle").doc("state");
  const collections: Array<[string, Map<string, any>]> = [
    ["animals", state.animals], ["valuations", state.valuations], ["breedingEvents", state.breedingEvents],
    ["farrowingEvents", state.farrowingEvents], ["piglets", state.piglets], ["mortalityEvents", state.mortalityEvents], ["handovers", state.handovers], ["idempotency", state.idempotency]
  ];
  let batch = db.batch();
  let writes = 0;
  for (const [name, map] of collections) {
    for (const [id, value] of map) {
      batch.set(root.collection(name).doc(id), value, { merge: true });
      writes += 1;
      if (writes === 450) {
        await batch.commit();
        batch = db.batch();
        writes = 0;
      }
    }
  }
  if (writes > 0) await batch.commit();
}

async function recordFinancialEvent(db: Firestore, tenantId: string, event: Record<string, any>): Promise<void> {
  const id = cleanId(event.financialEventId, "financialEventId");
  const ref = db.collection("tenants").doc(tenantId).collection("financialEvents").doc(id);
  const existing = await ref.get();
  if (!existing.exists) await ref.create({ ...event, tenantId, status: "PENDING", sourceSystem: "CENTRAL_REGISTRY", createdAt: new Date().toISOString() });
}

async function scheduleFarrowingAlert(db: Firestore, tenantId: string, event: any, staff: Record<string, any>): Promise<void> {
  const scheduledAt = new Date(new Date(event.expectedFarrowingDateTime).getTime() - 24 * 3600000).toISOString();
  const notificationId = `FARROWING_ALERT_24H-${event.breedingEventId}-v${event.forecastVersion}`;
  const ref = db.collection("tenants").doc(tenantId).collection("notifications").doc(notificationId);
  await ref.create({ notificationId, tenantId, breedingEventId: event.breedingEventId, sowAnimalId: event.sowAnimalId, messageType: "FARROWING_24H_ALERT", recipientStaffId: staff.id, recipientPhone: staff.phone || staff.mobile || staff.mobileMoneyNumber || null, scheduledAt, deliveryStatus: "QUEUED", idempotencyKey: `${notificationId}-${staff.id}`, createdAt: new Date().toISOString() }).catch((error: any) => {
    if (error?.code !== 6 && !String(error?.message || "").toLowerCase().includes("already exists")) throw error;
  });
}

async function createHandoverPdf(db: Firestore, deps: PigLifecycleRouteDeps, handover: any, tenantId: string): Promise<{ hash: string; storagePath: string }> {
  const doc = new jsPDF();
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text("MABALA PIG MANAGER - ACCEPTED HANDOVER", 14, 20);
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  const lines = [
    `Tenant: ${tenantId}`, `Handover: ${handover.handoverId}`, `Entity: ${handover.entityId}`,
    `From: ${handover.fromStaffId} (${handover.fromStage})`, `To: ${handover.toStaffId} (${handover.toStage})`,
    `Animals transferred: ${handover.quantityTransferred}`, `Accepted: ${handover.acceptedAt || "-"}`
  ];
  lines.forEach((line, index) => doc.text(line, 14, 34 + index * 8));
  doc.text(`Animal IDs: ${handover.animalIds.join(", ")}`, 14, 96, { maxWidth: 180 });
  const bytes = Buffer.from(doc.output("arraybuffer"));
  const hash = crypto.createHash("sha256").update(bytes).digest("hex");
  const storagePath = `tenants/${tenantId}/handoverDocuments/${handover.handoverId}/v${handover.documentVersion}.pdf`;
  const bucket = getStorage(deps.getAdminApp()).bucket();
  await bucket.file(storagePath).save(bytes, { contentType: "application/pdf", resumable: false, metadata: { metadata: { documentHash: hash, handoverId: handover.handoverId, tenantId } } });
  await db.collection("tenants").doc(tenantId).collection("handoverDocuments").doc(handover.handoverId).set({ handoverId: handover.handoverId, documentVersion: handover.documentVersion, documentHash: hash, storagePath, createdAt: new Date().toISOString(), immutable: true }, { merge: false });
  return { hash, storagePath };
}

export function registerPigLifecycleRoutes(app: express.Application, deps: PigLifecycleRouteDeps): void {
  const db = deps.getAdminDb();
  const route = (handler: (req: express.Request, res: express.Response, actor: ActorContext) => Promise<void>) => async (req: express.Request, res: express.Response) => {
    try {
      const actor = await resolveActor(req, db);
      await handler(req, res, actor);
    } catch (error: any) {
      const status = ["UNAUTHENTICATED"].includes(error?.code) ? 401 : ["FORBIDDEN"].includes(error?.code) ? 403 : ["NOT_FOUND", "STAFF_NOT_FOUND", "ANIMAL_NOT_FOUND"].includes(error?.code) ? 404 : ["CONFLICTING_BREEDING", "STALE_ANIMAL_RECORD", "HANDOVER_EXCEPTION"].includes(error?.code) ? 409 : error?.code === "INTERNAL" ? 500 : 400;
      res.status(status).json({ success: false, code: error?.code || "INTERNAL", error: error?.message || "Pig lifecycle operation failed" });
    }
  };

  app.get("/api/registry/animals/breeding-eligible", route(async (req, res, actor) => {
    assertPermission(actor, "PIG_BREEDING_VIEW");
    const state = await loadState(db, actor.tenantId);
    const sex = String(req.query.sex || "").toUpperCase();
    const animals = [...state.animals.values()].filter(animal => animal.status === "ACTIVE" && animal.ownershipStatus === "OWNED" && !animal.quarantined && animal.healthStatus === "CLEARED" && animal.breedingStatus === "ELIGIBLE" && (!sex || animal.sex === sex));
    res.json({ success: true, animals });
  }));

  app.post("/api/pig-manager/breeding-events", route(async (req, res, actor) => {
    assertPermission(actor, "PIG_BREEDING_CREATE");
    const body = req.body || {};
    const staff = await assertStaff(db, actor.tenantId, body.staffId);
    await assertAssignment(db, actor.tenantId, body.assignmentId, staff.id);
    const state = await loadState(db, actor.tenantId);
    const service = new PigLifecycleService(state);
    const event = service.createBreedingEvent({ ...body, tenantId: actor.tenantId, staffId: staff.id, breedingEventId: cleanId(body.breedingEventId, "breedingEventId") }, actor.permissions);
    await saveState(db, actor.tenantId, state);
    await scheduleFarrowingAlert(db, actor.tenantId, event, staff);
    res.status(201).json({ success: true, event });
  }));

  app.get("/api/pig-manager/farrowing-forecast", route(async (_req, res, actor) => {
    assertPermission(actor, "PIG_FARROWING_VIEW");
    const state = await loadState(db, actor.tenantId);
    res.json({ success: true, forecasts: [...state.breedingEvents.values()].filter(event => event.status === "CONFIRMED") });
  }));

  app.post("/api/pig-manager/farrowing-events", route(async (req, res, actor) => {
    assertPermission(actor, "PIG_FARROWING_CREATE");
    const body = req.body || {};
    const staff = await assertStaff(db, actor.tenantId, body.staffId);
    await assertAssignment(db, actor.tenantId, body.assignmentId, staff.id);
    const state = await loadState(db, actor.tenantId);
    const service = new PigLifecycleService(state);
    const event = service.recordFarrowing({ ...body, staffId: staff.id }, actor.permissions);
    await saveState(db, actor.tenantId, state);
    const totalValue = event.piglets.reduce((sum, piglet) => sum + Number(state.valuations.get(piglet.initialValuationId)?.fvlcts || 0), 0);
    await recordFinancialEvent(db, actor.tenantId, { financialEventId: `FE-FAR-${event.farrowingEventId}`, eventType: "BIOLOGICAL_ASSET_INITIAL_RECOGNITION", farrowingEventId: event.farrowingEventId, amount: totalValue, currency: "ZMW", debitAccount: "1530", creditAccount: "4500" });
    res.status(201).json({ success: true, event });
  }));

  app.post("/api/registry/mortality-events", route(async (req, res, actor) => {
    assertPermission(actor, "PIG_MORTALITY_CREATE");
    const body = req.body || {};
    const staff = await assertStaff(db, actor.tenantId, body.staffId);
    const state = await loadState(db, actor.tenantId);
    const service = new PigLifecycleService(state);
    const event = service.recordMortality({ ...body, staffId: staff.id }, actor.permissions);
    await saveState(db, actor.tenantId, state);
    await recordFinancialEvent(db, actor.tenantId, { financialEventId: `FE-MOR-${event.mortalityEventId}`, eventType: "BIOLOGICAL_ASSET_MORTALITY", animalId: event.animalId, mortalityEventId: event.mortalityEventId, valuationId: event.lastValuationId, amount: event.carryingValue, currency: "ZMW", debitAccount: "5902", creditAccount: "1530" });
    res.status(201).json({ success: true, event });
  }));

  app.post("/api/pig-manager/handovers", route(async (req, res, actor) => {
    assertPermission(actor, "PIG_HANDOVER_CREATE");
    const body = req.body || {};
    await assertStaff(db, actor.tenantId, body.fromStaffId);
    await assertStaff(db, actor.tenantId, body.toStaffId);
    const state = await loadState(db, actor.tenantId);
    const service = new PigLifecycleService(state);
    const handover = service.createHandover({ ...body, tenantId: actor.tenantId }, actor.permissions);
    await saveState(db, actor.tenantId, state);
    res.status(201).json({ success: true, handover });
  }));

  app.post("/api/pig-manager/handovers/:handoverId/accept", route(async (req, res, actor) => {
    assertPermission(actor, "PIG_HANDOVER_ACCEPT");
    const body = req.body || {};
    await assertStaff(db, actor.tenantId, body.recipientStaffId);
    const state = await loadState(db, actor.tenantId);
    const service = new PigLifecycleService(state);
    const handover = service.acceptHandover(cleanId(req.params.handoverId, "handoverId"), body.recipientStaffId, Array.isArray(body.confirmedAnimalIds) ? body.confirmedAnimalIds : [], actor.permissions);
    await saveState(db, actor.tenantId, state);
    const document = await createHandoverPdf(db, deps, handover, actor.tenantId);
    handover.documentHash = document.hash;
    await saveState(db, actor.tenantId, state);
    res.json({ success: true, handover, document });
  }));

  app.get("/api/pig-manager/handovers/:handoverId/document", route(async (req, res, actor) => {
    assertPermission(actor, "PIG_HANDOVER_VIEW");
    const handoverId = cleanId(req.params.handoverId, "handoverId");
    const documentSnapshot = await db.collection("tenants").doc(actor.tenantId).collection("handoverDocuments").doc(handoverId).get();
    if (!documentSnapshot.exists) fail("NOT_FOUND", "The accepted handover document does not exist");
    const storagePath = String(documentSnapshot.data()?.storagePath || "");
    if (!storagePath) fail("NOT_FOUND", "The handover document storage reference is missing");
    const bucket = getStorage(deps.getAdminApp()).bucket();
    const [bytes] = await bucket.file(storagePath).download();
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${handoverId}.pdf"`);
    res.send(bytes);
  }));
}
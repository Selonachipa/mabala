import { Request, Response, NextFunction } from "express";

export const ALLOWED_PRODUCTION_ORIGINS = [
  "https://mabala.cloud",
  "https://www.mabala.cloud"
];

export function isAllowedOrigin(origin?: string): boolean {
  if (!origin) return false;
  const o = origin.trim().toLowerCase();
  if (ALLOWED_PRODUCTION_ORIGINS.some(allowed => allowed.toLowerCase() === o)) {
    return true;
  }
  if (
    o.startsWith("https://ais-dev-") ||
    o.startsWith("https://ais-pre-") ||
    o.includes(".run.app") ||
    o.includes(".web.app") ||
    o.includes(".firebaseapp.com") ||
    o.startsWith("http://localhost:") ||
    o.startsWith("http://127.0.0.1:")
  ) {
    return true;
  }
  return false;
}

/**
 * Standard Centralized Express CORS Middleware
 */
export function centralCorsMiddleware(req: Request, res: Response, next: NextFunction): void {
  const origin = req.headers.origin;

  if (origin && isAllowedOrigin(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader(
      "Access-Control-Allow-Headers",
      "Authorization, Content-Type, X-Requested-With, Accept, x-api-key, x-mabala-super-email, x-mabala-super-uid"
    );
    res.setHeader(
      "Access-Control-Allow-Methods",
      "GET, POST, PUT, PATCH, DELETE, OPTIONS"
    );
    res.setHeader("Access-Control-Max-Age", "86400");
  }

  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  next();
}

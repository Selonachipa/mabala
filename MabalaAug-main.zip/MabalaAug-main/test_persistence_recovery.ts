import assert from "node:assert/strict";
import { readPersistedJson, writePersistedJson, repairPersistedState } from "./src/app/persistence";

const key = "__persistence_recovery_test__";
const backupKey = "mabala_persistence_backup_v1";

if (typeof globalThis !== "undefined") {
  globalThis.localStorage.clear();
}

const corruptedValue = "{bad json";
localStorage.setItem(key, corruptedValue);
localStorage.setItem(backupKey, JSON.stringify({ [key]: { ok: true, payload: [1, 2, 3] } }));

const restored = readPersistedJson(key, [] as number[]);
assert.deepEqual(restored, { ok: true, payload: [1, 2, 3] });

writePersistedJson("__fresh_test__", { amount: 42 });
assert.deepEqual(JSON.parse(localStorage.getItem("__fresh_test__") as string), { amount: 42 });

repairPersistedState();
assert.ok(localStorage.getItem(backupKey));

console.log("Persistence recovery tests passed.");

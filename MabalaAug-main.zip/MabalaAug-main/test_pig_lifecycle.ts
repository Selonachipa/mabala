import assert from "node:assert/strict";
import {
  PigLifecycleError,
  PigLifecycleService,
  createPigLifecycleState,
  getFarrowingReadiness,
  type PigAnimal,
  type ValuationRecord
} from "./src/services/pigLifecycleService.ts";

const permissions = [
  "PIG_BREEDING_CREATE",
  "PIG_FARROWING_CREATE",
  "PIG_MORTALITY_CREATE",
  "PIG_HANDOVER_CREATE",
  "PIG_HANDOVER_ACCEPT"
];

const state = createPigLifecycleState();
const sow: PigAnimal = {
  centralAnimalId: "AN-SOW-1", pigId: "PIG-SOW-1", tenantId: "TENANT-1", species: "PIG", breed: "Large White", sex: "FEMALE", status: "ACTIVE", healthStatus: "CLEARED", breedingStatus: "ELIGIBLE", ownershipStatus: "OWNED", quarantined: false, version: 4
};
const boar: PigAnimal = {
  centralAnimalId: "AN-BOAR-1", pigId: "PIG-BOAR-1", tenantId: "TENANT-1", species: "PIG", breed: "Landrace", sex: "MALE", status: "ACTIVE", healthStatus: "CLEARED", breedingStatus: "ELIGIBLE", ownershipStatus: "OWNED", quarantined: false, version: 2
};
state.animals.set(sow.centralAnimalId, sow);
state.animals.set(boar.centralAnimalId, boar);
state.valuations.set("VAL-SOW-1", {
  valuationId: "VAL-SOW-1", tenantId: "TENANT-1", animalId: sow.centralAnimalId, source: "REGISTRATION", valuationDateTime: "2026-01-01T00:00:00.000Z", valuationMethod: "FVLCTS", fairValue: 12500, estimatedCostsToSell: 0, fvlcts: 12500, currency: "ZMW", calculationVersion: "TEST", inputs: {}
} satisfies ValuationRecord);
sow.currentValuationId = "VAL-SOW-1";

let currentTime = new Date("2026-09-13T08:30:00.000Z");
const service = new PigLifecycleService(state, () => currentTime);
const breeding = service.createBreedingEvent({
  breedingEventId: "BRE-1", tenantId: "TENANT-1", sowAnimalId: sow.centralAnimalId, boarAnimalId: boar.centralAnimalId, staffId: "STAFF-1", serviceDateTime: "2026-09-13T08:30:00.000Z", breedingMethod: "NATURAL_SERVICE"
}, permissions);
assert.equal(breeding.expectedFarrowingDateTime, "2027-01-05T08:30:00.000Z");
assert.equal(breeding.gestationDays, 114);
assert.equal(getFarrowingReadiness("2026-09-14T07:00:00.000Z", currentTime), "CRITICAL");

const farrowing = service.recordFarrowing({
  farrowingEventId: "FAR-1", breedingEventId: breeding.breedingEventId, staffId: "STAFF-2", farrowingDateTime: "2027-01-05T07:40:00.000Z", totalBorn: 2, liveBorn: 2, stillborn: 0,
  newborns: [
    { localPigletId: "PM-PIGLET-1", sex: "FEMALE", birthWeightKg: 1.4, proposedFairValue: 450, estimatedCostsToSell: 20 },
    { localPigletId: "PM-PIGLET-2", sex: "MALE", birthWeightKg: 1.3, proposedFairValue: 450, estimatedCostsToSell: 20 }
  ]
}, permissions);
assert.equal(farrowing.piglets.length, 2);
assert.equal(state.animals.get(farrowing.piglets[0].centralAnimalId)?.currentValuationId, "VAL-PM-PIGLET-1");

const handover = service.createHandover({
  handoverId: "HO-1", tenantId: "TENANT-1", entityType: "LITTER", entityId: farrowing.litterId, fromStaffId: "STAFF-2", toStaffId: "STAFF-3", fromStage: "FARROWING", toStage: "LITTER_MANAGEMENT", quantityTransferred: 2, animalIds: farrowing.piglets.map(piglet => piglet.centralAnimalId)
}, permissions);
assert.throws(() => service.acceptHandover(handover.handoverId, "STAFF-3", [handover.animalIds[0]], permissions), (error: unknown) => error instanceof PigLifecycleError && error.code === "HANDOVER_EXCEPTION");

const secondHandover = service.createHandover({ ...handover, handoverId: "HO-2", documentHash: "" }, permissions);
const accepted = service.acceptHandover(secondHandover.handoverId, "STAFF-3", secondHandover.animalIds, permissions);
assert.equal(accepted.status, "ACCEPTED");

currentTime = new Date("2027-01-06T07:30:00.000Z");
const mortality = service.recordMortality({ idempotencyKey: "MOR-1", localPigletId: "PM-PIGLET-1", staffId: "STAFF-3", classification: "NEONATAL_DEATH", cause: "WEAKNESS", deathDateTime: currentTime.toISOString(), expectedAnimalVersion: 1 }, permissions);
assert.equal(mortality.carryingValue, 430);
assert.equal(state.animals.get(mortality.animalId)?.status, "DECEASED");
assert.equal(service.recordMortality({ idempotencyKey: "MOR-1", localPigletId: "PM-PIGLET-1", staffId: "STAFF-3", classification: "NEONATAL_DEATH", cause: "WEAKNESS", deathDateTime: currentTime.toISOString() }, permissions), mortality);
assert.equal(service.reconcile(farrowing.litterId).status, "RECONCILED");

assert.throws(() => service.recordMortality({ idempotencyKey: "MOR-STALE", localPigletId: "PM-PIGLET-2", staffId: "STAFF-3", classification: "NEONATAL_DEATH", cause: "WEAKNESS", deathDateTime: currentTime.toISOString(), expectedAnimalVersion: 99 }, permissions), (error: unknown) => error instanceof PigLifecycleError && error.code === "STALE_ANIMAL_RECORD");
console.log("pig lifecycle tests passed");
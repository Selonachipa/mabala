import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [
      react({
        fastRefresh: process.env.DISABLE_HMR !== 'true',
      } as any),
      tailwindcss(),
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
        'path': path.resolve(__dirname, 'src/utils/pathShim.ts'),
        'tty': path.resolve(__dirname, 'src/utils/ttyShim.ts'),
      },
      dedupe: ['react', 'react-dom'],
    },
    build: {
      outDir: 'dist',
      emptyOutDir: true,
      sourcemap: false,
      minify: 'esbuild' as const,
      target: 'es2020',
      chunkSizeWarningLimit: 3000,
      rollupOptions: {
        external: [
          'firebase-admin',
          'firebase-admin/app',
          'firebase-admin/firestore',
          'googleapis',
          'google-auth-library',
          '@google-cloud/firestore'
        ],
        output: {
          manualChunks(id) {
            if (id.includes('node_modules')) {
              if (id.includes('recharts') || id.includes('d3')) {
                return 'charts-vendor';
              }
              if (id.includes('firebase')) {
                return 'firebase-vendor';
              }
              if (id.includes('lucide-react')) {
                return 'icons-vendor';
              }
            }
          }
        }
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

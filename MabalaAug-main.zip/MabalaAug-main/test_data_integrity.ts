import {
  softDelete,
  recoverSoftDeletedItem,
  recordVersionedSettings,
  executeIdempotentFinancialTransaction,
  reconcilePlatformWalletBalances
} from "./src/services/dataIntegrityService";

// Mock Firestore DB for unit testing
function createMockFirestore() {
  const store: Record<string, any> = {};

  return {
    store,
    doc(colOrPath: string, ...rest: string[]) {
      const parts = [colOrPath, ...rest].filter(Boolean);
      const fullPath = parts.join("/");
      return {
        path: fullPath,
        id: parts[parts.length - 1] || ""
      };
    },
    async getDoc(docRef: any) {
      const data = store[docRef.path];
      return {
        exists: () => !!data,
        data: () => data || null
      };
    },
    async setDoc(docRef: any, data: any, opts?: any) {
      if (opts?.merge && store[docRef.path]) {
        store[docRef.path] = { ...store[docRef.path], ...data };
      } else {
        store[docRef.path] = data;
      }
    },
    async getDocs(colRef: any) {
      const docs: any[] = [];
      for (const [key, val] of Object.entries(store)) {
        if (key.startsWith(colRef.path) && !key.slice(colRef.path.length + 1).includes("/")) {
          docs.push({
            id: key.split("/").pop(),
            data: () => val
          });
        }
      }
      return { docs };
    },
    async runTransaction(updateFunction: (tx: any) => Promise<any>) {
      const tx = {
        async get(docRef: any) {
          const data = store[docRef.path];
          return {
            exists: () => !!data,
            data: () => data || null
          };
        },
        set(docRef: any, data: any, opts?: any) {
          if (opts?.merge && store[docRef.path]) {
            store[docRef.path] = { ...store[docRef.path], ...data };
          } else {
            store[docRef.path] = data;
          }
        }
      };
      return await updateFunction(tx);
    }
  };
}

async function runDataIntegrityTests() {
  console.log("Running Data Integrity & Soft Delete Unit Tests...\n");
  const mockDb = createMockFirestore();

  // Test 1: Soft Delete Operation
  const sampleDocPath = "inventory/item_123";
  mockDb.store[sampleDocPath] = { name: "Maize Seeds 50kg", status: "active", price: 450 };

  const softDeleteRes = await softDelete(mockDb, "inventory", "item_123", "admin_user");
  console.assert(softDeleteRes.success === true, "Soft delete should return success true");
  const updatedDoc = mockDb.store[sampleDocPath];
  console.assert(updatedDoc.isDeleted === true, "Document should have isDeleted: true");
  console.assert(updatedDoc.status === "deleted", "Document status should be 'deleted'");
  console.assert(typeof updatedDoc.deletedAt === "string", "deletedAt should be set");
  console.assert(updatedDoc.deletedBy === "admin_user", "deletedBy should match operator");
  console.log("✓ Soft-delete test passed.");

  // Test 2: Recover Soft-Deleted Item
  const recoveryRes = await recoverSoftDeletedItem(mockDb, "inventory", "item_123", "super_admin");
  console.assert(recoveryRes.success === true, "Recovery should return success true");
  const recoveredDoc = mockDb.store[sampleDocPath];
  console.assert(recoveredDoc.isDeleted === false, "Recovered document should have isDeleted: false");
  console.assert(recoveredDoc.status === "active", "Recovered document status should be restored to active");
  console.assert(typeof recoveredDoc.restoredAt === "string", "restoredAt should be recorded");
  console.log("✓ Soft-delete recovery test passed.");

  // Test 3: Versioned Non-Destructive Settings Updates
  const settingsPath = "system_settings/global_config";
  mockDb.store[settingsPath] = { feePercentage: 2.5, maintenanceMode: false, version: 1 };

  const updateRes1 = await recordVersionedSettings(
    mockDb,
    "system_settings",
    "global_config",
    { feePercentage: 3.0, maintenanceMode: false },
    "admin@mabala.com"
  );

  console.assert(updateRes1.version === 2, `Expected version 2, got ${updateRes1.version}`);
  const activeSettings = mockDb.store[settingsPath];
  console.assert(activeSettings.feePercentage === 3.0, "Fee percentage should be updated to 3.0");
  
  // Check version history subcollection entry
  const versionKeys = Object.keys(mockDb.store).filter(k => k.includes("system_settings/global_config/versions/"));
  console.assert(versionKeys.length === 1, `Expected 1 archived version entry, found ${versionKeys.length}`);
  const archivedDoc = mockDb.store[versionKeys[0]];
  console.assert(archivedDoc.feePercentage === 2.5, "Archived version should retain prior value (2.5)");
  console.log("✓ Non-destructive versioned settings update test passed.");

  // Test 4: Financial Transaction Idempotency Guard
  let executionCount = 0;
  const idempotencyKey = "tx_settlement_998877";

  const txRes1 = await executeIdempotentFinancialTransaction(
    mockDb,
    idempotencyKey,
    "marketplace_settlement",
    "tenant_456",
    1200,
    async (transaction) => {
      executionCount++;
      return { details: { payoutAmount: 1200, recipient: "Kasama Co-op" } };
    }
  );

  console.assert(txRes1.alreadyProcessed === false, "First execution should not be marked as alreadyProcessed");
  console.assert(executionCount === 1, "Execution count should be 1");

  // Re-run same transaction with identical idempotency key
  const txRes2 = await executeIdempotentFinancialTransaction(
    mockDb,
    idempotencyKey,
    "marketplace_settlement",
    "tenant_456",
    1200,
    async (transaction) => {
      executionCount++;
      return { details: { payoutAmount: 1200, recipient: "Kasama Co-op" } };
    }
  );

  console.assert(txRes2.alreadyProcessed === true, "Second execution should be flagged as alreadyProcessed");
  console.assert(executionCount === 1, "Execution count should remain 1 (no duplicate execution)");
  console.log("✓ Financial transaction idempotency guard test passed.");

  // Test 5: Wallet Balance Platform-Wide Reconciliation Engine
  // Setup Tenant 1: Balanced
  mockDb.store["users_data/tenant_1"] = { name: "Farm Alpha" };
  mockDb.store["tenants/tenant_1/wallet/credits"] = { currentBalance: 500 };
  mockDb.store["tenants/tenant_1/creditLedger/tx1"] = { type: "credit_grant", amount: 500 };

  // Setup Tenant 2: Unbalanced (mismatch)
  mockDb.store["users_data/tenant_2"] = { name: "Farm Beta" };
  mockDb.store["tenants/tenant_2/wallet/credits"] = { currentBalance: 800 }; // Incorrect wallet balance
  mockDb.store["tenants/tenant_2/creditLedger/tx1"] = { type: "credit_grant", amount: 500 }; // Ledger sum = 500

  const reconReport = await reconcilePlatformWalletBalances(mockDb);
  console.assert(reconReport.totalTenantsAudited === 2, `Expected 2 tenants audited, got ${reconReport.totalTenantsAudited}`);
  console.assert(reconReport.totalDiscrepancies === 1, `Expected 1 discrepancy detected, got ${reconReport.totalDiscrepancies}`);
  console.assert(reconReport.alertsGenerated[0].tenantId === "tenant_2", "Discrepancy alert should target tenant_2");
  console.assert(reconReport.alertsGenerated[0].discrepancy === 300, `Expected discrepancy 300, got ${reconReport.alertsGenerated[0].discrepancy}`);
  console.log("✓ Platform-wide wallet reconciliation engine test passed.");

  console.log("\n\x1b[32mAll Data Integrity & Persistence Unit Tests Passed Successfully!\x1b[0m");
}

runDataIntegrityTests().catch((err) => {
  console.error("Data integrity test execution failed:", err);
  process.exit(1);
});

import assert from "node:assert/strict";
import {
  addRemoteAccessClaims,
  isRemoteAccessSessionActive,
  isSuperAdminClaims,
  removeRemoteAccessClaims
} from "./functions/src/services/remoteAccessPolicy";

const permanentClaims = { role: "super_admin", superAdmin: true, platformScope: "global" };
assert.equal(isSuperAdminClaims(permanentClaims), true);
assert.equal(isSuperAdminClaims({}, "support@mabala.cloud"), true);
assert.equal(isSuperAdminClaims({}, "farm-owner@example.com"), false);

const temporaryClaims = addRemoteAccessClaims(permanentClaims, {
  tenantId: "farm-a",
  sessionId: "session-a",
  expiresAt: "2099-01-01T00:00:00.000Z"
});
assert.equal(temporaryClaims.role, "super_admin");
assert.equal(temporaryClaims.platformScope, "global");
assert.equal(temporaryClaims.accessNodeTenantId, "farm-a");
assert.equal(temporaryClaims.accessNodeSessionId, "session-a");

const restoredClaims = removeRemoteAccessClaims(temporaryClaims);
assert.deepEqual(restoredClaims, permanentClaims);

assert.equal(isRemoteAccessSessionActive({
  sessionId: "session-a",
  superAdminId: "admin-a",
  targetTenantId: "farm-a",
  expiresAt: "2099-01-01T00:00:00.000Z",
  status: "active"
}, new Date("2026-09-12T00:00:00.000Z")), true);
assert.equal(isRemoteAccessSessionActive({
  sessionId: "session-b",
  superAdminId: "admin-a",
  targetTenantId: "farm-a",
  expiresAt: "2020-01-01T00:00:00.000Z",
  status: "active"
}, new Date("2026-09-12T00:00:00.000Z")), false);
assert.equal(isRemoteAccessSessionActive({
  sessionId: "session-c",
  superAdminId: "admin-a",
  targetTenantId: "farm-a",
  expiresAt: "2099-01-01T00:00:00.000Z",
  status: "ended"
}), false);

console.log("Remote access policy tests passed.");

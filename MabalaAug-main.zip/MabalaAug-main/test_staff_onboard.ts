import fetch from "node-fetch";

const PORT = 3000;
const ADMIN_URL = `http://localhost:${PORT}/api/admin/institutions`;
const SUB_USERS_URL = `http://localhost:${PORT}/api/institution/sub-users`;

function makeToken(uid: string) {
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64");
  const payload = Buffer.from(JSON.stringify({ uid, user_id: uid })).toString("base64");
  const signature = "dummysignature";
  return `${header}.${payload}.${signature}`;
}

async function run() {
  console.log("=== STARTING STAFF ONBOARDING E2E TEST ===");
  try {
    console.log("1. Fetching institutions list from Super Admin endpoint...");
    const instRes = await fetch(ADMIN_URL, {
      method: "GET",
      headers: {
        "x-mabala-super-uid": "icIoBG4eN5VOw2BvhNiFUnUqmsX2"
      }
    });

    if (instRes.status !== 200) {
      throw new Error(`Failed to fetch institutions: Status code ${instRes.status}`);
    }

    const instJson: any = await instRes.json();
    if (!instJson.success || !instJson.institutions || instJson.institutions.length === 0) {
      throw new Error("No institutions found. Ensure the mock/setup institution is present.");
    }

    const firstInst = instJson.institutions[0];
    const adminUid = firstInst.adminUid;
    console.log(`Using Sponsoring Organisation: "${firstInst.name}" (ID: ${firstInst.id})`);
    console.log(`Using Institution Admin User: UID="${adminUid}"`);

    const token = makeToken(adminUid);

    console.log("2. Fetching current sub-users list...");
    const getRes = await fetch(SUB_USERS_URL, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${token}`
      }
    });

    if (getRes.status !== 200) {
      throw new Error(`Failed to fetch sub-users: Status code ${getRes.status}`);
    }

    const getJson: any = await getRes.json();
    console.log(`Initial sub-user count: ${getJson.subUsers ? getJson.subUsers.length : 0}`);

    const uniqueEmail = `staff_${Date.now()}_${Math.floor(Math.random() * 1000)}@example.com`;
    console.log(`3. Onboarding a new staff member with email "${uniqueEmail}"...`);

    const postRes = await fetch(SUB_USERS_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email: uniqueEmail,
        name: "E2E Field Assistant",
        phone: "+260971234567",
        password: "TempStaffPassword1!",
        scopeType: "all",
        scopeValue: [],
        permissions: {
          view_dashboard: true,
          view_reports: true,
          export_data: true,
          send_sms: true
        }
      })
    });

    if (postRes.status !== 200) {
      const errorData: any = await postRes.json();
      throw new Error(`Onboarding failed: Status ${postRes.status}, Error: ${errorData.error}`);
    }

    const postJson: any = await postRes.json();
    if (!postJson.success || !postJson.uid) {
      throw new Error(`Invalid response payload from onboarding endpoint: ${JSON.stringify(postJson)}`);
    }

    const createdUid = postJson.uid;
    console.log(`Success! Staff created with simulated/actual UID: "${createdUid}"`);

    console.log("4. Verifying newly onboarded staff member appears in sub-users list...");
    const verifyRes = await fetch(SUB_USERS_URL, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${token}`
      }
    });

    const verifyJson: any = await verifyRes.json();
    const subUsersList: any[] = verifyJson.subUsers || [];
    const matchedUser = subUsersList.find(user => user.uid === createdUid || user.id === createdUid || user.email === uniqueEmail);

    if (!matchedUser) {
      throw new Error("Created staff user was NOT found in subsequent GET sub-users listing!");
    }

    console.log(`Verified matches in Firestore! Onboarded user detail:`, JSON.stringify(matchedUser, null, 2));
    console.log("=== E2E STAFF ONBOARDING TEST PASSED SUCCESSFULLY ===");

  } catch (err: any) {
    console.error("=== E2E STAFF ONBOARDING TEST FAILED ===");
    console.error("Reason:", err.message);
    process.exit(1);
  }
}

run();

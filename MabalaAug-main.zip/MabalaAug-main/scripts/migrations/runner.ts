import { getFirestore } from 'firebase-admin/firestore';
import { initializeApp, cert } from 'firebase-admin/app';

// Run against explicit project only — never defaults
const project = process.argv[2];
if (!project) throw new Error('Specify project: dev | staging | production');

try {
  // If key file exists locally, load certificate, otherwise use default credential
  const keyPath = `../../keys/${project}-key.json`;
  initializeApp({ credential: cert(require(keyPath)) });
} catch (e) {
  initializeApp();
}

const db = getFirestore();

export interface Migration {
  id: string;
  description: string;
  run: (db: FirebaseFirestore.Firestore) => Promise<number>;
}

export async function applyMigration(migration: Migration) {
  const migrationRef = db.collection('_migrations').doc(migration.id);
  const existing = await migrationRef.get();

  if (existing.exists && existing.data()?.status === 'completed') {
    console.log(`⏭  Skipping "${migration.id}" — already applied on ${project}`);
    return;
  }

  console.log(`▶  Applying "${migration.id}": ${migration.description}`);
  try {
    const count = await migration.run(db);
    await migrationRef.set({
      id: migration.id,
      description: migration.description,
      appliedAt: new Date(),
      appliedBy: process.env.USER || 'ci',
      documentsAffected: count,
      status: 'completed',
    });
    console.log(`✅ "${migration.id}" complete — ${count} docs updated (additive only)`);
  } catch (err) {
    await migrationRef.set({ id: migration.id, status: 'failed', error: String(err) }, { merge: true });
    throw err;
  }
}

export { db };

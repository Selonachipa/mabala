import fs from "fs";
import path from "path";

// Load configuration
const configPath = path.resolve(process.cwd(), "firebase-applet-config.json");
if (!fs.existsSync(configPath)) {
  console.error("[Safeguard Error] firebase-applet-config.json not found.");
  process.exit(1);
}

const firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
const { projectId, firestoreDatabaseId, apiKey } = firebaseConfig;
const databaseId = firestoreDatabaseId || "(default)";

const FIRESTORE_BASE_URL = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/${databaseId}/documents`;

// Target collections to count
const TARGET_COLLECTIONS = [
  { key: "tenants", path: "platform/institutions" },
  { key: "users_data", path: "users_data" },
  { key: "super_admins", path: "platform/super_admins" }
];

const STATE_FILE_PATH = path.resolve(process.cwd(), "scripts/deploy_safeguard_state.json");

async function fetchCollectionCount(key: string, collectionPath: string): Promise<number> {
  try {
    if (key === "users_data") {
      // Use runQuery for users_data as it bypasses standard list restrictions perfectly
      const url = `${FIRESTORE_BASE_URL}:runQuery?key=${apiKey}`;
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          structuredQuery: {
            from: [{ collectionId: "users_data" }]
          }
        })
      });

      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`HTTP status ${res.status}: ${errorText}`);
      }

      const data: any = await res.json();
      if (Array.isArray(data)) {
        return data.filter((item: any) => item.document).length;
      }
      return 0;
    } else {
      // For platform/institutions and platform/super_admins, use standard GET list
      let count = 0;
      let pageToken = "";
      do {
        let url = `${FIRESTORE_BASE_URL}/${collectionPath}?key=${apiKey}`;
        if (pageToken) {
          url += `&pageToken=${pageToken}`;
        }

        const res = await fetch(url);
        if (res.status === 404) {
          // Empty collection or document path
          return 0;
        }

        if (!res.ok) {
          const errorText = await res.text();
          throw new Error(`HTTP status ${res.status}: ${errorText}`);
        }

        const data: any = await res.json();
        if (data && data.documents) {
          count += data.documents.length;
        }
        pageToken = data.nextPageToken || "";
      } while (pageToken);

      return count;
    }
  } catch (err: any) {
    console.warn(`[Safeguard Warn] Failed to fetch count for ${collectionPath}:`, err.message);
    return 0;
  }
}

async function runPreDeploy() {
  console.log("\n=======================================================");
  console.log("[SAFEGUARD] Running Pre-Deploy Data Integrity Snapshots");
  console.log("=======================================================");
  
  const counts: Record<string, number> = {};
  for (const collection of TARGET_COLLECTIONS) {
    console.log(`[SAFEGUARD] Counting documents in: ${collection.path}...`);
    const count = await fetchCollectionCount(collection.key, collection.path);
    counts[collection.key] = count;
    console.log(`[SAFEGUARD] -> Found ${count} documents.`);
  }

  fs.writeFileSync(STATE_FILE_PATH, JSON.stringify(counts, null, 2), "utf-8");
  console.log(`[SAFEGUARD] Pre-deploy snapshots written to ${STATE_FILE_PATH}`);
  console.log("=======================================================\n");
}

async function runPostDeploy() {
  console.log("\n=======================================================");
  console.log("[SAFEGUARD] Running Post-Deploy Data Integrity Check");
  console.log("=======================================================");

  if (!fs.existsSync(STATE_FILE_PATH)) {
    console.error("[SAFEGUARD ERROR] No pre-deploy state found. Please run pre-deploy first!");
    process.exit(1);
  }

  const preCounts: Record<string, number> = JSON.parse(fs.readFileSync(STATE_FILE_PATH, "utf-8"));
  const postCounts: Record<string, number> = {};

  let dataLossDetected = false;

  for (const collection of TARGET_COLLECTIONS) {
    console.log(`[SAFEGUARD] Re-counting documents in: ${collection.path}...`);
    const count = await fetchCollectionCount(collection.key, collection.path);
    postCounts[collection.key] = count;
    
    const preCount = preCounts[collection.key] || 0;
    console.log(`[SAFEGUARD] -> Found ${count} documents (Before: ${preCount}).`);

    if (count < preCount) {
      console.error(`\n[CRITICAL ERROR] DATA LOSS DETECTED on collection "${collection.path}"!`);
      console.error(`[CRITICAL ERROR] Count dropped from ${preCount} to ${count} documents!`);
      dataLossDetected = true;
    }
  }

  if (dataLossDetected) {
    console.error("\n=======================================================");
    console.error("!!! DEPLOY SAFEGUARD ALERT: TENANT DATA WAS REDUCED !!!");
    console.error("=======================================================");
    console.error("FAILING LOUDLY TO PREVENT SILENT CORRUPTION.");
    console.error("=======================================================\n");
    process.exit(1);
  } else {
    console.log("\n[SAFEGUARD SUCCESS] Data integrity checks passed! No document counts dropped.");
    console.log("=======================================================\n");
  }
}

const args = process.argv.slice(2);
if (args.includes("--pre")) {
  runPreDeploy();
} else if (args.includes("--post")) {
  runPostDeploy();
} else {
  console.log("Usage: tsx deploySafeguard.ts [--pre|--post]");
  process.exit(1);
}

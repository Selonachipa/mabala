const { execSync } = require('child_process');

const project = process.argv[2]; // e.g. "production" or "mabala-cloud-prod"
if (!project) {
  console.error('Usage: node backup-firestore.js <project-id>');
  process.exit(1);
}

const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
const bucket = `gs://${project.includes('mabala-cloud-prod') ? project : 'mabala-cloud-prod'}-firestore-backups`;
const exportPath = `${bucket}/backups/${timestamp}`;

console.log(`Backing up Firestore for project: ${project}`);
console.log(`Export destination: ${exportPath}`);

try {
  execSync(
    `gcloud firestore export ${exportPath} --project=${project}`,
    { stdio: 'inherit' }
  );
  console.log(`✅ Backup complete: ${exportPath}`);
} catch (err) {
  console.error('❌ Backup failed — deployment aborted for safety.');
  process.exit(1); // if backup fails, the deploy pipeline should stop
}

import assert from "assert";
import {
  canViewUnmasked,
  maskMobile,
  maskEmail,
  maskNRC,
  maskUserId,
  maskCard,
  maskPII,
  maskPIIObject
} from "./src/utils/privacyMasking.js";

try {
  console.log("Running PII Privacy Masking Unit Tests...");

  // 1. Mobile Number Masking Tests
  assert.strictEqual(maskMobile("0977123456"), "••••••3456");
  assert.strictEqual(maskMobile("097712345"), "•••••2345");
  assert.strictEqual(maskMobile("123"), "••••123");
  assert.strictEqual(maskMobile("+1-555-019-2834"), "•••••••••••2834");
  assert.strictEqual(maskMobile(null), "••••");
  assert.strictEqual(maskMobile(undefined), "••••");
  console.log("✓ Mobile number masking tests passed.");

  // 2. Email Address Masking Tests
  assert.strictEqual(maskEmail("shikasuli@gmail.com"), "••••.com");
  assert.strictEqual(maskEmail("user@domain.co.uk"), "••••o.uk");
  assert.strictEqual(maskEmail("a@b.c"), "••••@b.c");
  assert.strictEqual(maskEmail("a@b"), "••••");
  assert.strictEqual(maskEmail(null), "••••");
  console.log("✓ Email address masking tests passed.");

  // 3. NRC Masking Tests
  assert.strictEqual(maskNRC("123456/78/1"), "1234••/••/•");
  assert.strictEqual(maskNRC("123456789"), "1234•••••");
  assert.strictEqual(maskNRC("123"), "123••••");
  assert.strictEqual(maskNRC(null), "••••••••/••/•");
  console.log("✓ NRC masking tests passed.");

  // 4. User ID Masking Tests
  assert.strictEqual(maskUserId("usr_9876543217f2a"), "••••7f2a");
  assert.strictEqual(maskUserId("7f2a"), "••••7f2a");
  assert.strictEqual(maskUserId("abc"), "••••abc");
  assert.strictEqual(maskUserId(null), "••••0000");
  console.log("✓ User ID masking tests passed.");

  // 5. Card PAN Masking Tests
  assert.strictEqual(maskCard("4111222233334242"), "•••• •••• •••• 4242");
  assert.strictEqual(maskCard("4242"), "•••• •••• •••• 4242");
  assert.strictEqual(maskCard(null), "•••• •••• •••• ••••");
  console.log("✓ Card PAN masking tests passed.");

  // 6. Role-based canViewUnmasked Tests
  assert.strictEqual(canViewUnmasked("super_admin"), true);
  assert.strictEqual(canViewUnmasked("Super Admin"), true);
  assert.strictEqual(canViewUnmasked("mobile", "super_admin"), true);
  assert.strictEqual(canViewUnmasked("offtaker", "user_1", "user_1"), true);
  assert.strictEqual(canViewUnmasked("offtaker", "user_1", "user_2"), false);
  assert.strictEqual(canViewUnmasked("agro_dealer", "user_1", "user_2"), false);
  assert.strictEqual(canViewUnmasked("institution_supplier", "user_1", "user_2"), false);
  console.log("✓ canViewUnmasked permission checks passed.");

  // 7. Universal maskPII & maskPIIObject Tests
  assert.strictEqual(maskPII("0977123456", "mobile", { viewerRole: "agro_dealer" }), "••••••3456");
  assert.strictEqual(maskPII("0977123456", "mobile", { viewerRole: "super_admin" }), "0977123456");

  const piiDoc = {
    phone: "0977123456",
    email: "test@gmail.com",
    nrc: "123456/78/1",
    uid: "uid_abcdef7f2a",
    cardNumber: "4111222233334242"
  };

  const maskedDoc = maskPIIObject(piiDoc, { viewerRole: "offtaker", dataOwnerId: "f_1", currentUserId: "off_1" });
  assert.strictEqual(maskedDoc.phone, "••••••3456");
  assert.strictEqual(maskedDoc.email, "••••.com");
  assert.strictEqual(maskedDoc.nrc, "1234••/••/•");
  assert.strictEqual(maskedDoc.uid, "••••7f2a");
  assert.strictEqual(maskedDoc.cardNumber, "•••• •••• •••• 4242");

  const unmaskedDoc = maskPIIObject(piiDoc, { viewerRole: "super_admin" });
  assert.strictEqual(unmaskedDoc.phone, "0977123456");
  console.log("✓ Universal maskPII & maskPIIObject tests passed.");

  console.log("\x1b[32mAll PII Privacy Masking Unit Tests Passed Successfully!\x1b[0m");
} catch (err) {
  console.error("Test execution failed:", err);
  process.exit(1);
}

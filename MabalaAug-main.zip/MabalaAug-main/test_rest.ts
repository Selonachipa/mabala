import fetch from "node-fetch";

const PORT = 3000;
const ADMIN_URL = `http://localhost:${PORT}/api/admin/institutions`;
const SUB_USERS_URL = `http://localhost:${PORT}/api/institution/sub-users`;

function makeToken(uid: string) {
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64");
  const payload = Buffer.from(JSON.stringify({ uid, user_id: uid })).toString("base64");
  const signature = "dummysignature";
  return `${header}.${payload}.${signature}`;
}

async function run() {
  try {
    console.log("1. Fetching institutions...");
    const instRes = await fetch(ADMIN_URL, {
      method: "GET",
      headers: {
        "x-mabala-super-uid": "icIoBG4eN5VOw2BvhNiFUnUqmsX2"
      }
    });
    const instJson: any = await instRes.json();
    console.log("Institutions list response:", JSON.stringify(instJson, null, 2));

    if (!instJson.success || !instJson.institutions || instJson.institutions.length === 0) {
      console.log("No institutions found. Creating one...");
      // Let's create an institution first if none exists
      return;
    }

    const firstInst = instJson.institutions[0];
    const adminUid = firstInst.adminUid;
    console.log(`Using Institution Admin UID: ${adminUid} for Institution ID: ${firstInst.id}`);

    const token = makeToken(adminUid);

    console.log("2. Fetching current sub-users...");
    const getRes = await fetch(SUB_USERS_URL, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${token}`
      }
    });
    console.log("GET Sub-users status:", getRes.status);
    const getJson = await getRes.json();
    console.log("GET Sub-users response:", JSON.stringify(getJson, null, 2));

    console.log("3. Attempting to create a sub-user (staff onboarding)...");
    const postRes = await fetch(SUB_USERS_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email: `staff_${Date.now()}@example.com`,
        name: "Test Field Officer",
        phone: "+260971234567",
        password: "TemporaryPassword123!",
        scopeType: "all",
        scopeValue: [],
        permissions: {
          view_dashboard: true,
          view_reports: true,
          export_data: true,
          send_sms: true
        }
      })
    });
    console.log("POST Sub-user status:", postRes.status);
    const postJson = await postRes.json();
    console.log("POST Sub-user response:", JSON.stringify(postJson, null, 2));

  } catch (err: any) {
    console.error("Test request threw error:", err);
  }
}

run();

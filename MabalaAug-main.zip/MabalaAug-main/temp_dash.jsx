<div className="space-y-6 animate-fade-in" id="dashboard-tab">
              {/* DYNAMIC SEVERE WEATHER WARNINGS HIGH-CONTRAST HIGHLIGHTS BANNER */}
              {weatherAlerts && weatherAlerts.length > 0 && (
                <div className="bg-rose-950 text-rose-50 border-2 border-rose-500 p-4.5 rounded-xl shadow-[0_0_20px_rgba(239,68,68,0.2)] space-y-3 relative overflow-hidden animate-pulse" id="weather-critical-highlight-banner">
                  {/* Decorative background glow */}
                  <div className="absolute right-0 top-0 w-32 h-32 bg-rose-600 rounded-full blur-[60px] opacity-25" />
                  
                  <div className="flex items-start gap-4">
                    <span className="text-3xl animate-bounce shrink-0 mt-1">🚨</span>
                    <div className="space-y-2 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="bg-rose-600 text-white text-[9.5px] font-black px-2 py-0.5 rounded tracking-wider uppercase">
                          CRITICAL WEATHER THREAT
                        </span>
                        <h4 className="font-extrabold text-[13px] uppercase tracking-wide">
                          {weatherAlerts.length === 1 
                            ? "IMMEDIATE AGRICULTURAL WEATHER WARNING ACTIVE" 
                            : `${weatherAlerts.length} SEVERE AGRICULTURAL THREATS DETECTED`}
                        </h4>
                      </div>
                      
                      <p className="text-rose-200 text-xs font-semibold leading-relaxed">
                        The meteorological station is broadcasting active severe alerts requiring immediate agronomic preparedness. Protect your active herd nodes, crops, and assets immediately:
                      </p>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                        {weatherAlerts.map((alert: any) => (
                          <div 
                            key={alert.id}
                            className="bg-rose-900/60 border border-rose-500/30 rounded-lg p-3 text-xs space-y-1.5 hover:bg-rose-900/80 transition-all font-sans"
                          >
                            <div className="flex items-center justify-between gap-1.5">
                              <strong className="font-extrabold text-white text-[11.5px] flex items-center gap-1.5">
                                <span>{alert.category === "Rain" ? "⛈️" : alert.category === "Wind" ? "🌪️" : alert.category === "Thermal" && alert.title.includes("Frost") ? "❄️" : alert.category === "Thermal" ? "🔥" : "😷"}</span>
                                <span className="truncate max-w-[200px]">{alert.title}</span>
                              </strong>
                              <span className="bg-rose-500 text-white font-black text-[8px] uppercase px-1 rounded scale-90">
                                {alert.severity}
                              </span>
                            </div>
                            <p className="text-[10.5px] text-rose-200 opacity-90 leading-tight font-medium">
                              {alert.description}
                            </p>
                            <div className="bg-rose-950/80 border border-rose-500/25 p-2 rounded text-[10px] text-rose-100 font-bold">
                              <span className="text-[8.5px] uppercase text-rose-400 block font-black">Preemptive Action Plan:</span>
                              {alert.action}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* REQUIREMENT 8 & 3: VISUAL STATUS INDICATOR & AGRO-CREDIT COLLATERAL & LIQUIDITY SUMMARY (AGRO-DEALERS ONLY) */}
              {isAgroDealerUser && (
                <>
                  {/* REQUIREMENT 8: VISUAL STATUS INDICATOR COMPONENT FOR DWR PLEDGED CROPS */}
                  <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 p-5 rounded-2xl text-white shadow-md border border-emerald-500/20 space-y-3 font-sans">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-500/20 pb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold text-lg shrink-0">
                          📜
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-black rounded uppercase font-mono">
                              Digital Warehouse Receipt (DWR) Collateral Status
                            </span>
                            <span className="px-2 py-0.5 bg-amber-400 text-slate-950 text-[9px] font-black rounded uppercase font-mono">
                              ✓ Collateral Active
                            </span>
                          </div>
                          <h4 className="text-sm font-black text-white mt-0.5">
                            Pledged Crop Inventory & Bank Lock Overview
                          </h4>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 uppercase font-mono block">Total Collateral Value</span>
                          <strong className="text-emerald-400 text-base font-mono font-black">{selectedCountry.symbol} 2,420,000.00</strong>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                        <span className="text-[9px] text-slate-400 uppercase font-mono block">Pledged Crop Volume</span>
                        <strong className="text-white text-sm font-black font-mono">1,450 Metric Tons (MT)</strong>
                        <div className="text-[10px] text-emerald-400 mt-1 font-semibold">850 MT Maize • 400 MT Soybeans • 200 MT Wheat</div>
                      </div>

                      <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                        <span className="text-[9px] text-slate-400 uppercase font-mono block">Collateral Pledge Coverage</span>
                        <strong className="text-amber-400 text-sm font-black font-mono">128.5% LTV Ratio</strong>
                        <div className="text-[10px] text-slate-300 mt-1 font-semibold">Surplus Margin: +{selectedCountry.symbol} 570,000</div>
                      </div>

                      <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                        <span className="text-[9px] text-slate-400 uppercase font-mono block">DWR Verification Node</span>
                        <strong className="text-emerald-400 text-sm font-black font-mono flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Zambia ZAMACE Verified
                        </strong>
                        <div className="text-[10px] text-slate-400 mt-1 font-semibold">Warehouse: Mkushi Certified Silo #02</div>
                      </div>
                    </div>
                  </div>

                  {/* REQUIREMENT 3: SUMMARY STATISTICS SECTION USING RECHARTS */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                      <div>
                        <h4 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-2">
                          <span>📊 Agro-Credit, Collateral & Liquidity Summary</span>
                          <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[9px] font-black rounded uppercase">
                            Role: {userProfile?.role || "Agro Dealer"}
                          </span>
                        </h4>
                        <p className="text-[10px] text-slate-500 mt-0.5 font-medium">
                          Real-time credit facility disbursements, pledged collateral values, and daily mobile money liquidity.
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Card 1: Total Agro-Input Credit Issued */}
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Agro-Input Credit Issued</span>
                            <p className="text-lg font-black text-slate-900 font-mono mt-0.5">{selectedCountry.symbol} 1,850,000.00</p>
                          </div>
                          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[9px] font-black rounded-full">
                            +14.2% MoM
                          </span>
                        </div>
                        <div className="h-16 w-full pt-1">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={[
                              { cat: "Seed", val: 850000 },
                              { cat: "Fertilizer", val: 650000 },
                              { cat: "Chem", val: 350000 }
                            ]}>
                              <XAxis dataKey="cat" fontSize={8} tickLine={false} axisLine={false} />
                              <Tooltip formatter={(v: any) => [`${selectedCountry.symbol} ${Number(v).toLocaleString()}`, "Issued"]} />
                              <Bar dataKey="val" fill="#10b981" radius={[3, 3, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Card 2: Pledged Crop Collateral Value */}
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Pledged Crop Collateral Value</span>
                            <p className="text-lg font-black text-amber-700 font-mono mt-0.5">{selectedCountry.symbol} 2,420,000.00</p>
                          </div>
                          <span className="px-2 py-0.5 bg-amber-100 text-amber-900 text-[9px] font-black rounded-full">
                            DWR Secured
                          </span>
                        </div>
                        <div className="h-16 w-full pt-1">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={[
                              { crop: "Maize", val: 1250000 },
                              { crop: "Soy", val: 750000 },
                              { crop: "Wheat", val: 420000 }
                            ]}>
                              <XAxis dataKey="crop" fontSize={8} tickLine={false} axisLine={false} />
                              <Tooltip formatter={(v: any) => [`${selectedCountry.symbol} ${Number(v).toLocaleString()}`, "Pledged Value"]} />
                              <Bar dataKey="val" fill="#f59e0b" radius={[3, 3, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Card 3: Daily Consignment Liquidity */}
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Daily Consignment Liquidity</span>
                            <p className="text-lg font-black text-indigo-700 font-mono mt-0.5">{selectedCountry.symbol} 485,000.00</p>
                          </div>
                          <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 text-[9px] font-black rounded-full">
                            Auto-Settled
                          </span>
                        </div>
                        <div className="h-16 w-full pt-1">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={[
                              { day: "Mon", val: 62000 },
                              { day: "Tue", val: 78000 },
                              { day: "Wed", val: 54000 },
                              { day: "Thu", val: 91000 },
                              { day: "Fri", val: 84500 },
                              { day: "Sat", val: 115500 }
                            ]}>
                              <XAxis dataKey="day" fontSize={8} tickLine={false} axisLine={false} />
                              <Tooltip formatter={(v: any) => [`${selectedCountry.symbol} ${Number(v).toLocaleString()}`, "Liquidity"]} />
                              <Bar dataKey="val" fill="#6366f1" radius={[3, 3, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}

              {/* CLEAN & SIMPLE DASHBOARD FARM NODE TAX & CURRENCY SETTINGS BAR */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-4 font-sans" id="dashboard-farm-node-tax-currency-bar">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-slate-900 text-emerald-400 flex items-center justify-center font-bold shrink-0 shadow-xs">
                    🏛️
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase font-black tracking-wider text-slate-400">Farm Node Statutory & Fiscal Settings</span>
                      <span className="px-1.5 py-0.2 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[8px] font-black rounded uppercase">
                        {activeFarm?.name || "Sunrise Agro-Tech Farms"}
                      </span>
                    </div>
                    <p className="text-xs font-extrabold text-slate-800 mt-0.5">
                      Statutory Tax & Currency Engine Directives
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs">
                  {/* Currency Selector */}
                  <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 p-1.5 rounded-xl">
                    <span className="text-[10px] font-bold text-slate-500 uppercase px-1">Currency:</span>
                    <select
                      value={activeFarm?.currency || "ZMW"}
                      onChange={(e) => {
                        const val = e.target.value;
                        const symbolMap: Record<string, string> = { ZMW: "ZK", USD: "$", TZS: "TSh", KES: "KSh", ZAR: "R", BWP: "P", EUR: "€", GBP: "£" };
                        handleUpdateActiveFarm({
                          currency: val,
                          currencySymbol: symbolMap[val] || "ZK"
                        });
                      }}
                      className="bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-800 py-1 px-2 focus:outline-none focus:border-emerald-500 cursor-pointer"
                    >
                      <option value="ZMW">ZMW — Kwacha (K)</option>
                      <option value="USD">USD — Dollar ($)</option>
                      <option value="TZS">TZS — Shilling (TSh)</option>
                      <option value="KES">KES — Shilling (KSh)</option>
                      <option value="ZAR">ZAR — Rand (R)</option>
                      <option value="BWP">BWP — Pula (P)</option>
                      <option value="EUR">EUR — Euro (€)</option>
                      <option value="GBP">GBP — Pound (£)</option>
                    </select>
                  </div>

                  {/* Statutory Tax Type Selector */}
                  <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 p-1.5 rounded-xl">
                    <span className="text-[10px] font-bold text-slate-500 uppercase px-1">Statutory Tax:</span>
                    <select
                      value={activeFarm?.taxType || localStorage.getItem("mabala_farm_tax_type") || "TOT_5"}
                      onChange={(e) => {
                        const val = e.target.value;
                        const currentTax = activeFarm?.taxType || localStorage.getItem("mabala_farm_tax_type") || "TOT_5";
                        if (val !== currentTax) {
                          setPendingTaxTypeChange({ targetTaxType: val });
                        }
                      }}
                      className="bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-800 py-1 px-2 focus:outline-none focus:border-emerald-500 cursor-pointer"
                    >
                      <option value="TOT_5">Turnover Tax (TOT 5%)</option>
                      <option value="VAT_16">Value Added Tax (VAT 16%)</option>
                      <option value="CUSTOM">Custom Jurisdiction Rate</option>
                      <option value="EXEMPT">Exempt / Non-Taxable</option>
                    </select>
                  </div>

                  {/* Compliance badge */}
                  <div className="hidden xl:flex items-center gap-1 px-2.5 py-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-[10px] font-bold">
                    <span>✓ Applied across all farm node records</span>
                  </div>

                  {/* Requirement 6: Quick Log Loss button in #dashboard-farm-node-tax-currency-bar */}
                  <button
                    type="button"
                    onClick={() => setShowQuickLogLossModal(true)}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-black transition flex items-center gap-1.5 shadow-sm cursor-pointer ml-auto"
                  >
                    <span>📉 Quick Log Loss</span>
                  </button>
                </div>
              </div>

              {/* Top Row Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                
                <motion.div
                  key={`kpi-rev-${dateRange}`}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease: "easeOut", delay: 0.05 }}
                  className="relative group bg-white p-5 rounded-xl shadow-sm border border-slate-200 cursor-help transition-all duration-200 hover:border-emerald-300 hover:shadow-md"
                >
                  <div className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                    <span>Total Revenue YTD</span>
                    {kpiGrowth.revGrowth !== null && (
                      <span className={`text-[10px] font-bold ${kpiGrowth.revGrowth >= 0 ? "text-emerald-600" : "text-rose-500"}`}>
                        {kpiGrowth.revGrowth >= 0 ? "↑" : "↓"} {Math.abs(kpiGrowth.revGrowth).toFixed(1)}%
                      </span>
                    )}
                  </div>
                  <div className="text-2xl font-bold mt-1 text-slate-800 font-sans">
                    {selectedCountry.symbol} {displayedAccounts.filter(a => a.category === "Revenue").reduce((s, a) => s + a.balance, 0).toLocaleString()}
                  </div>
                  <span className="text-[9px] text-emerald-500 mt-2 font-medium block">✓ Derived from crop & aquaculture sales</span>

                  {/* Interactive Tooltip */}
                  <div className="pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-56 bg-slate-950 text-white text-[11px] p-3 rounded-xl shadow-xl opacity-0 group-hover:opacity-100 transition-all duration-300 z-50 leading-relaxed font-sans font-medium border border-slate-800 transform translate-y-1 group-hover:translate-y-0">
                    <div className="font-extrabold border-b border-slate-800 pb-1.5 mb-1.5 text-[9px] text-emerald-400 uppercase tracking-widest flex justify-between items-center">
                      <span>REVENUE GROWTH</span>
                      <span className="px-1 py-0.2 bg-emerald-500/10 text-emerald-400 rounded text-[8px] font-black">
                        {kpiGrowth.revGrowth !== null ? `${kpiGrowth.revGrowth >= 0 ? "+" : ""}${kpiGrowth.revGrowth.toFixed(1)}%` : "Actual Data Only"}
                      </span>
                    </div>
                    <div className="text-slate-300">MoM growth trend compared to the preceding fiscal cycle:</div>
                    <div className="mt-2 space-y-1 text-slate-400 text-[10px]">
                      <div className="flex justify-between">
                        <span>Previous ({kpiGrowth.previousLabel || "N/A"}):</span>
                        <span className="font-bold text-slate-300">{selectedCountry.symbol} {(dashboardChartData[dashboardChartData.length - 2]?.["Total Revenue"] || 0).toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Current ({kpiGrowth.latestLabel || "Current"}):</span>
                        <span className="font-bold text-slate-200">{selectedCountry.symbol} {(dashboardChartData[dashboardChartData.length - 1]?.["Total Revenue"] || 0).toLocaleString()}</span>
                      </div>
                    </div>
                    <div className="text-[9px] text-slate-500 mt-2 italic">Actual recorded transactions only. No test or dummy figures.</div>
                    <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 w-2.5 h-2.5 bg-slate-950 rotate-45 border-r border-b border-slate-800"></div>
                  </div>
                </motion.div>

                <motion.div
                  key={`kpi-exp-${dateRange}`}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease: "easeOut", delay: 0.15 }}
                  className="relative group bg-white p-5 rounded-xl shadow-sm border border-slate-200 cursor-help transition-all duration-200 hover:border-rose-300 hover:shadow-md"
                >
                  <div className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                    <span>Expenses YTD</span>
                    {kpiGrowth.expGrowth !== null && (
                      <span className={`text-[10px] font-bold ${kpiGrowth.expGrowth <= 0 ? "text-emerald-600" : "text-rose-500"}`}>
                        {kpiGrowth.expGrowth >= 0 ? "↑" : "↓"} {Math.abs(kpiGrowth.expGrowth).toFixed(1)}%
                      </span>
                    )}
                  </div>
                  <div className="text-2xl font-bold mt-1 text-rose-500 font-sans">
                    {selectedCountry.symbol} {displayedAccounts.filter(a => a.category === "Expense").reduce((s, a) => s + a.balance, 0).toLocaleString()}
                  </div>
                  <span className="text-[9px] text-slate-400 mt-2 font-medium block">Multi-line journal allocations</span>

                  {/* Interactive Tooltip */}
                  <div className="pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-56 bg-slate-950 text-white text-[11px] p-3 rounded-xl shadow-xl opacity-0 group-hover:opacity-100 transition-all duration-300 z-50 leading-relaxed font-sans font-medium border border-slate-800 transform translate-y-1 group-hover:translate-y-0">
                    <div className="font-extrabold border-b border-slate-800 pb-1.5 mb-1.5 text-[9px] text-rose-400 uppercase tracking-widest flex justify-between items-center">
                      <span>EXPENSE TREND</span>
                      <span className="px-1 py-0.2 bg-rose-500/10 text-rose-400 rounded text-[8px] font-black">
                        {kpiGrowth.expGrowth !== null ? `${kpiGrowth.expGrowth >= 0 ? "+" : ""}${kpiGrowth.expGrowth.toFixed(1)}%` : "Actual Data Only"}
                      </span>
                    </div>
                    <div className="text-slate-300">MoM expense allocation velocity compared to previous period:</div>
                    <div className="mt-2 space-y-1 text-slate-400 text-[10px]">
                      <div className="flex justify-between">
                        <span>Previous ({kpiGrowth.previousLabel || "N/A"}):</span>
                        <span className="font-bold text-slate-300">{selectedCountry.symbol} {(dashboardChartData[dashboardChartData.length - 2]?.["Total Expenses"] || 0).toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Current ({kpiGrowth.latestLabel || "Current"}):</span>
                        <span className="font-bold text-slate-200">{selectedCountry.symbol} {(dashboardChartData[dashboardChartData.length - 1]?.["Total Expenses"] || 0).toLocaleString()}</span>
                      </div>
                    </div>
                    <div className="text-[9px] text-slate-500 mt-2 italic">Lower expenses optimize farm operational health.</div>
                    <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 w-2.5 h-2.5 bg-slate-950 rotate-45 border-r border-b border-slate-800"></div>
                  </div>
                </motion.div>

                <motion.div
                  key={`kpi-surplus-${dateRange}`}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease: "easeOut", delay: 0.25 }}
                  className="relative group bg-white p-5 rounded-xl shadow-sm border border-slate-200 cursor-help transition-all duration-200 hover:border-emerald-300 hover:shadow-md"
                >
                  {(() => {
                    const rev = displayedAccounts.filter(a => a.category === "Revenue").reduce((s, a) => s + a.balance, 0);
                    const exp = displayedAccounts.filter(a => a.category === "Expense").reduce((s, a) => s + a.balance, 0);
                    const diff = rev - exp;
                    return (
                      <>
                        <div className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                          <span>Net Operating surplus</span>
                          {kpiGrowth.surplusGrowth !== null && (
                            <span className={`text-[10px] font-bold ${kpiGrowth.surplusGrowth >= 0 ? "text-emerald-600" : "text-rose-500"}`}>
                              {kpiGrowth.surplusGrowth >= 0 ? "↑" : "↓"} {Math.abs(kpiGrowth.surplusGrowth).toFixed(1)}%
                            </span>
                          )}
                        </div>
                        <div className={`text-2xl font-bold mt-1 font-sans ${diff >= 0 ? "text-emerald-600" : "text-rose-500"}`}>
                          {selectedCountry.symbol} {diff.toLocaleString()}
                        </div>
                        <span className="text-[9px] text-slate-400 mt-2 font-medium block">IAS financial reporting net surplus</span>

                        {/* Interactive Tooltip */}
                        <div className="pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-56 bg-slate-950 text-white text-[11px] p-3 rounded-xl shadow-xl opacity-0 group-hover:opacity-100 transition-all duration-300 z-50 leading-relaxed font-sans font-medium border border-slate-800 transform translate-y-1 group-hover:translate-y-0">
                          <div className="font-extrabold border-b border-slate-800 pb-1.5 mb-1.5 text-[9px] text-emerald-400 uppercase tracking-widest flex justify-between items-center">
                            <span>SURPLUS RATIO</span>
                            <span className="px-1 py-0.2 bg-emerald-500/10 text-emerald-400 rounded text-[8px] font-black">
                              {kpiGrowth.surplusGrowth !== null ? `${kpiGrowth.surplusGrowth >= 0 ? "+" : ""}${kpiGrowth.surplusGrowth.toFixed(1)}%` : "Actual Data Only"}
                            </span>
                          </div>
                          <div className="text-slate-300">MoM operating margin change based on historical trends:</div>
                          <div className="mt-2 space-y-1 text-slate-400 text-[10px]">
                            <div className="flex justify-between">
                              <span>Previous ({kpiGrowth.previousLabel || "N/A"}):</span>
                              <span className="font-bold text-slate-300">{selectedCountry.symbol} {(dashboardChartData[dashboardChartData.length - 2]?.["Net Profit"] || 0).toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Current ({kpiGrowth.latestLabel || "Current"}):</span>
                              <span className="font-bold text-slate-200">{selectedCountry.symbol} {(dashboardChartData[dashboardChartData.length - 1]?.["Net Profit"] || 0).toLocaleString()}</span>
                            </div>
                          </div>
                          <div className="text-[9px] text-slate-500 mt-2 italic">Surplus tracks net positive double-entry balance sheets.</div>
                          <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 w-2.5 h-2.5 bg-slate-950 rotate-45 border-r border-b border-slate-800"></div>
                        </div>
                      </>
                    );
                  })()}
                </motion.div>

                <motion.div
                  key={`kpi-ledger-${dateRange}`}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease: "easeOut", delay: 0.35 }}
                  className="bg-white p-5 rounded-xl shadow-sm border border-slate-200"
                >
                  <div className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">General compliance ledger</div>
                  <div className="text-2xl font-bold mt-1 text-slate-800 font-sans">Verified</div>
                  <span className="text-[9px] text-emerald-500 mt-2 font-medium block">✓ Double-entry books balanced</span>
                </motion.div>

              </div>

              {/* Feed & Quick-access modules tiles */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                
                {/* Enabled modules tiles layout */}
                <div className="md:col-span-8 space-y-6">
                  {/* Dynamic Financial Trend Chart */}
                  <motion.div
                    key={`chart-${dateRange}-${chartMode}-${chartType}`}
                    initial={{ opacity: 0, y: 12, scale: 0.99 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ duration: 0.35, ease: "easeOut" }}
                    className="bg-white rounded-xl border p-6 shadow-sm space-y-4"
                    id="dashboard-trend-chart"
                  >
                    <div className="flex flex-wrap gap-4 items-center justify-between border-b pb-4 mb-2">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Revenue versus Expenses Summary</h4>
                          <span className="px-1.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200/60 rounded text-[9px] font-black uppercase tracking-wider inline-flex items-center gap-1">
                            <span className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse"></span>
                            <span>Self-Register Enabled</span>
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 font-medium">Monthly cash sales & paid invoices compared to journal expenses for {activeFarm?.name || "active farm"}</p>
                      </div>

                      {/* Interactive Controls Panel */}
                      <div className="flex flex-wrap items-center gap-3">
                        {/* Date Range Selector */}
                        <div className="flex flex-col">
                          <span className="text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1">Seasonal range</span>
                          <select 
                            value={dateRange} 
                            onChange={(e) => setDateRange(e.target.value as any)}
                            className="bg-slate-50 border text-[10px] rounded px-2 py-1 font-bold text-slate-700 outline-none focus:border-emerald-500 cursor-pointer"
                          >
                            <option value="all">All Time (12 Months)</option>
                            <option value="last30">Last 30 Days (Jun 26)</option>
                            <option value="h2_2025">H2 2025 (Jul-Dec)</option>
                            <option value="q1_2026">Q1 2026 (Jan-Mar)</option>
                            <option value="q2_2026">Q2 2026 (Apr-Jun)</option>
                          </select>
                        </div>

                        {/* View Mode (Monthly vs YTD Cumulative) */}
                        <div className="flex flex-col">
                          <span className="text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1">Projection Type</span>
                          <div className="inline-flex bg-slate-100 p-0.5 rounded border text-[10px] font-bold">
                            <button
                              type="button"
                              onClick={() => {
                                setChartMode("monthly");
                              }}
                              className={`px-2 py-0.5 rounded ${chartMode === "monthly" ? "bg-white text-slate-800 shadow-xs" : "text-slate-500 hover:text-slate-700"}`}
                            >
                              Monthly
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setChartMode("cumulative");
                                setChartType("line");
                              }}
                              className={`px-2 py-0.5 rounded ${chartMode === "cumulative" ? "bg-white text-slate-800 shadow-xs" : "text-slate-500 hover:text-slate-700"}`}
                            >
                              YTD Cumulative
                            </button>
                          </div>
                        </div>

                        {/* Chart Type (Bar vs Line) */}
                        <div className="flex flex-col">
                          <span className="text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1">Visualization</span>
                          <div className="inline-flex bg-slate-100 p-0.5 rounded border text-[10px] font-bold">
                            <button
                              type="button"
                              onClick={() => setChartType("bar")}
                              className={`px-2 py-0.5 rounded ${chartType === "bar" && chartMode !== "cumulative" ? "bg-white text-slate-800 shadow-xs" : "text-slate-500 hover:text-slate-700"}`}
                              disabled={chartMode === "cumulative"}
                            >
                              Bar
                            </button>
                            <button
                              type="button"
                              onClick={() => setChartType("line")}
                              className={`px-2 py-0.5 rounded ${chartType === "line" || chartMode === "cumulative" ? "bg-white text-slate-800 shadow-xs" : "text-slate-500 hover:text-slate-700"}`}
                            >
                              Line
                            </button>
                          </div>
                        </div>

                        {/* Export to CSV Button */}
                        <div className="flex flex-col self-end">
                          <button
                            type="button"
                            onClick={() => {
                              const headers = ["Month", "Total Revenue", "Total Expenses", "Net Profit", "Cumulative Profit Projection"];
                              const csvRows = dashboardChartData.map(d => [
                                d.month,
                                d["Total Revenue"],
                                d["Total Expenses"],
                                d["Net Profit"],
                                d["Cumulative Profit Projection"] !== undefined ? d["Cumulative Profit Projection"] : ""
                              ]);
                              
                              const csvContent = "data:text/csv;charset=utf-8," 
                                + [headers.join(","), ...csvRows.map(r => r.join(","))].join("\n");
                              const encodedUri = encodeURI(csvContent);
                              const link = document.createElement("a");
                              link.setAttribute("href", encodedUri);
                              link.setAttribute("download", `mabala_filtered_financials_${dateRange}_${chartMode}.csv`);
                              document.body.appendChild(link);
                              link.click();
                              document.body.removeChild(link);
                            }}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-500/10 text-[10px] font-black uppercase tracking-wider rounded-lg px-2.5 py-1 flex items-center gap-1 shadow-sm cursor-pointer"
                            title="Export Filtered Data to CSV"
                          >
                            <Download className="w-3 h-3 text-white" />
                            <span>Export CSV</span>
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="h-64 mt-2 relative">
                      {!hasChartData && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-50/70 backdrop-blur-[1px] rounded-xl z-10 border border-dashed border-slate-200">
                          <span className="text-2xl mb-1 filter drop-shadow-xs">📊</span>
                          <span className="text-slate-700 font-extrabold text-[11px] uppercase tracking-wider">No Transaction Activity Ledger</span>
                          <span className="text-slate-400 text-[10px] text-center max-w-xs mt-1 leading-normal font-semibold">
                            Create a crop sale, record cash sales, log paid invoices, or post expense vouchers to populate real-time activity trends.
                          </span>
                        </div>
                      )}

                      {chartType === "line" || chartMode === "cumulative" ? (
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={hasChartData ? dashboardChartData : []} margin={{ top: 10, right: 10, left: 15, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                            <XAxis 
                              dataKey="month" 
                              stroke="#94a3b8" 
                              fontSize={10} 
                              tickLine={false}
                              axisLine={false}
                            />
                            <YAxis 
                              stroke="#94a3b8" 
                              fontSize={10} 
                              tickLine={false}
                              axisLine={false}
                              tickFormatter={(v) => `${selectedCountry.symbol} ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`}
                            />
                            <Tooltip 
                              cursor={{ stroke: '#cbd5e1', strokeWidth: 1 }}
                              contentStyle={{ 
                                background: '#1e293b', 
                                borderRadius: '8px', 
                                color: '#fff', 
                                border: 'none',
                                fontSize: '11px',
                                fontFamily: 'Inter, sans-serif'
                              }}
                              formatter={(value: any, name: any) => [`${selectedCountry.symbol} ${Number(value).toLocaleString()}`, name]}
                            />
                            {chartMode === "cumulative" ? (
                              <Line 
                                type="monotone"
                                name="Cumulative Profit Projection" 
                                dataKey="Cumulative Profit Projection" 
                                stroke="#10b981" 
                                strokeWidth={3}
                                dot={{ r: 4 }}
                                activeDot={{ r: 6 }}
                              />
                            ) : (
                              <>
                                <Line 
                                  type="monotone"
                                  name="Total Revenue" 
                                  dataKey="Total Revenue" 
                                  stroke="#10b981" 
                                  strokeWidth={2}
                                  dot={{ r: 3 }}
                                />
                                <Line 
                                  type="monotone"
                                  name="Total Expenses" 
                                  dataKey="Total Expenses" 
                                  stroke="#f43f5e" 
                                  strokeWidth={2}
                                  dot={{ r: 3 }}
                                />
                              </>
                            )}
                          </LineChart>
                        </ResponsiveContainer>
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={hasChartData ? dashboardChartData : []} margin={{ top: 10, right: 10, left: 15, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                            <XAxis 
                              dataKey="month" 
                              stroke="#94a3b8" 
                              fontSize={10} 
                              tickLine={false}
                              axisLine={false}
                            />
                            <YAxis 
                              stroke="#94a3b8" 
                              fontSize={10} 
                              tickLine={false}
                              axisLine={false}
                              tickFormatter={(v) => `${selectedCountry.symbol} ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`}
                            />
                            {/* REQUIREMENT 7: Hover interaction tooltip providing granular breakdown of harvested lots vs warehouse capacity */}
                            <Tooltip 
                              cursor={{ fill: '#f8fafc' }}
                              content={({ active, payload, label }: any) => {
                                if (active && payload && payload.length) {
                                  const rev = payload.find((p: any) => p.dataKey === "Total Revenue")?.value || 0;
                                  const exp = payload.find((p: any) => p.dataKey === "Total Expenses")?.value || 0;
                                  
                                  const monthLotData: Record<string, { harvested: string; capacity: string; occupancy: string }> = {
                                    "Jan": { harvested: "120 MT Maize SC 719", capacity: "1,200 MT / 1,600 MT", occupancy: "75.0%" },
                                    "Feb": { harvested: "180 MT Soybeans", capacity: "1,380 MT / 1,600 MT", occupancy: "86.2%" },
                                    "Mar": { harvested: "210 MT Wheat & Oats", capacity: "1,450 MT / 1,600 MT", occupancy: "90.6%" },
                                    "Apr": { harvested: "320 MT Maize SC 637", capacity: "1,520 MT / 1,600 MT", occupancy: "95.0%" },
                                    "May": { harvested: "290 MT Groundnuts & Soy", capacity: "1,410 MT / 1,600 MT", occupancy: "88.1%" },
                                    "Jun": { harvested: "140 MT Sorghum", capacity: "1,250 MT / 1,600 MT", occupancy: "78.1%" },
                                  };
                                  const lotInfo = monthLotData[label] || { harvested: "250 MT Harvested Lots", capacity: "1,450 MT / 1,600 MT", occupancy: "90.6%" };

                                  return (
                                    <div className="bg-slate-900 border border-slate-700 text-white p-3.5 rounded-xl shadow-2xl text-xs space-y-2 max-w-xs font-sans">
                                      <div className="font-extrabold text-emerald-400 border-b border-slate-800 pb-1 flex justify-between">
                                        <span>MONTH: {label}</span>
                                        <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-300">Live Breakdown</span>
                                      </div>
                                      <div className="space-y-1 text-[11px]">
                                        <div className="flex justify-between">
                                          <span className="text-slate-400">Total Revenue:</span>
                                          <span className="font-bold text-emerald-400">{selectedCountry.symbol} {Number(rev).toLocaleString()}</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-slate-400">Total Expenses:</span>
                                          <span className="font-bold text-rose-400">{selectedCountry.symbol} {Number(exp).toLocaleString()}</span>
                                        </div>
                                      </div>

                                      <div className="border-t border-slate-800 pt-2 space-y-1 bg-slate-950/60 p-2 rounded-lg text-[10.5px]">
                                        <div className="font-bold text-amber-300 flex items-center justify-between gap-2">
                                          <span>🌾 Harvested Lots:</span>
                                          <span className="font-normal text-white">{lotInfo.harvested}</span>
                                        </div>
                                        <div className="font-bold text-indigo-300 flex items-center justify-between gap-2">
                                          <span>🏭 Storage Capacity:</span>
                                          <span className="font-normal text-white">{lotInfo.capacity} ({lotInfo.occupancy})</span>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                }
                                return null;
                              }}
                            />
                            <Bar 
                              name="Total Revenue" 
                              dataKey="Total Revenue" 
                              fill="#10b981" 
                              radius={[4, 4, 0, 0]} 
                            />
                            <Bar 
                              name="Total Expenses" 
                              dataKey="Total Expenses" 
                              fill="#f43f5e" 
                              radius={[4, 4, 0, 0]} 
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>

                    {/* REQUIREMENT 5: Summary card beneath trend chart showing current loan offset progress and pledged crop collateral values - AGRO DEALERS ONLY */}
                    {isAgroDealerUser && (
                      <div className="mt-4 p-4 bg-gradient-to-r from-amber-50 via-emerald-50 to-indigo-50 rounded-xl border border-amber-200/80 shadow-2xs flex flex-wrap items-center justify-between gap-4 font-sans">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 font-black flex items-center justify-center text-sm shrink-0">
                            ⚖️
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-black uppercase text-amber-900 tracking-wider">Loan Offset Progress & Collateral Coverage</span>
                              <span className="px-1.5 py-0.2 bg-amber-200/60 text-amber-900 font-bold text-[8.5px] rounded uppercase">
                                78.1% Secured
                              </span>
                            </div>
                            <p className="text-xs font-black text-slate-800 mt-0.5">
                              Facility Debt: <span className="font-mono text-slate-900">{selectedCountry.symbol} 3,100,000.00</span> • Pledged Crop Collateral Value: <span className="font-mono text-emerald-800 font-bold">{selectedCountry.symbol} 2,420,000.00</span>
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <span className="text-[9px] font-bold text-slate-500 uppercase block">Remaining Unfunded Debt</span>
                            <span className="text-xs font-mono font-black text-rose-700">{selectedCountry.symbol} 680,000.00</span>
                          </div>
                          <div className="w-24 bg-slate-200 rounded-full h-2.5 overflow-hidden">
                            <div className="bg-emerald-600 h-2.5 rounded-full" style={{ width: "78.1%" }}></div>
                          </div>
                        </div>
                      </div>
                    )}
                  </motion.div>

                  <DashboardModulesGrid 
                    onSelectModule={(mId) => setActiveTab(mId)} 
                    isReadonly={isReadonly}
                    onTopUpCredits={() => setShowTopUpModal(true)}
                    onActivateSubscription={() => setActiveTab("billing-centre")}
                  />

                  {/* Onboarded Agronomists, Visit Booking & Agronomy Reports Hub */}
                  <FarmerAgronomyHub
                    activeFarm={activeFarm}
                    farms={farms}
                    userProfile={userProfile}
                    currencySymbol={selectedCountry.symbol}
                  />

                  {/* Operational Task Manager Module */}
                  <TaskManager 
                    tasks={tasks}
                    onAddTask={handleAddTask}
                    onEditTask={handleEditTask}
                    onDeleteTask={handleDeleteTask}
                    onToggleComplete={handleToggleTaskComplete}
                    isReadonly={isReadonly}
                  />
                </div>

                {/* Right hand transactional sidebar feeds */}
                <div className="md:col-span-4 space-y-6">
                  {/* Dynamic Weather Widget & Agronomy Warnings */}
                  <WeatherWidget 
                    onAlertsChange={setWeatherAlerts} 
                    farmLocation={activeFarm?.farmLocation || (activeFarm?.latitude && activeFarm?.longitude ? { lat: activeFarm.latitude, lng: activeFarm.longitude, source: "province_town_signup" } : undefined)}
                    province={activeFarm?.province}
                    district={activeFarm?.district || activeFarm?.town}
                  />

                  {/* General ledger stats */}
                  <div className="bg-white rounded-xl border p-5 shadow-sm space-y-4">
                    <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Recent general ledger postings</h4>
                    <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                    {expenses.slice(0, 5).map(tx => (
                      <div key={tx.id} className="p-2.5 border rounded-lg bg-slate-50 flex justify-between items-center text-xs">
                        <div>
                          <span className="font-mono text-[9px] text-emerald-600 block">{tx.id} • EXPENSE</span>
                          <span className="font-bold text-slate-800 block">{tx.supplierName}</span>
                          <span className="text-[10px] text-slate-400 block mt-0.5">{tx.date}</span>
                        </div>
                        <span className="font-mono font-bold text-slate-900">-{selectedCountry.symbol}{(tx?.total ?? tx?.amount ?? 0).toLocaleString()}</span>
                      </div>
                    ))}
                    {invoices.slice(0, 5).map(inv => (
                      <div key={inv.id} className="p-2.5 border rounded-lg bg-emerald-50/50 flex justify-between items-center text-xs border-emerald-100">
                        <div>
                          <span className="font-mono text-[9px] text-blue-600 block">{inv.invoiceNumber} • SALES</span>
                          <span className="font-bold text-slate-800 block">{inv.customerName}</span>
                          <span className="text-[10px] text-slate-400 block mt-0.5">Status: <strong className={inv.status === "Paid" ? "text-emerald-600" : "text-amber-600 font-bold"}>{inv.status}</strong></span>
                        </div>
                        <span className="font-mono font-bold text-emerald-600">+{selectedCountry.symbol}{(inv?.total ?? 0).toLocaleString()}</span>
                      </div>
                    ))}
                    {expenses.length === 0 && invoices.length === 0 && (
                      <div className="p-6 text-center text-slate-400 italic">No transactional journal updates posted. Try &ldquo;One-Click Demo Mode&rdquo; to preload books.</div>
                    )}
                  </div>
                </div>
              </div>

              </div>
            </div>
          )}

          {
import assert from "assert";
import { resolveLipilaConfig } from "./src/lipilaConfig.js";

try {
  console.log("Running production-only Lipila Config unit tests...");

  // 1. Test production resolution with a valid production-formatted key
  const prodConfig = resolveLipilaConfig("lpk_live_key_xyz");
  assert.strictEqual(prodConfig.baseUrl, "https://blz.lipila.io", "Base URL must be exactly https://blz.lipila.io");
  console.log("✓ Production resolution test passed (always resolves to blz.lipila.io).");

  // 2. Test sandbox key handling (does not throw, but still resolves to production base URL)
  const sandboxKeyConfig = resolveLipilaConfig("lsk_sandbox_key_xyz");
  assert.strictEqual(sandboxKeyConfig.baseUrl, "https://blz.lipila.io", "Base URL must be exactly https://blz.lipila.io even for sandbox keys");
  console.log("✓ Sandbox key resolves to production base URL successfully.");

  // 3. Test validation errors (missing key)
  assert.throws(() => {
    resolveLipilaConfig("");
  }, /LIPILA_SECRET_KEY is missing/);
  console.log("✓ Missing key error validation passed.");

  console.log("\x1b[32mAll production-only Lipila Config tests completed successfully!\x1b[0m");
} catch (err) {
  console.error("Test execution failed:", err);
  process.exit(1);
}

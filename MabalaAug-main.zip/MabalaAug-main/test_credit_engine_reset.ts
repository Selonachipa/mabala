import { grantCreditsIdempotent } from "./src/services/creditLedgerService";
import { reconstructAndFixTenantCreditWallet } from "./src/services/dataIntegrityService";

// In-Memory Mock Firestore for isolated regression test
function createMockFirestore() {
  const store: Record<string, any> = {};

  return {
    store,
    doc(colOrPath: string, ...rest: string[]) {
      const parts = [colOrPath, ...rest].filter(Boolean);
      const fullPath = parts.join("/");
      return {
        path: fullPath,
        id: parts[parts.length - 1] || ""
      };
    },
    async getDoc(docRef: any) {
      const data = store[docRef.path];
      return {
        exists: () => !!data,
        data: () => data || null
      };
    },
    async setDoc(docRef: any, data: any, opts?: any) {
      if (opts?.merge && store[docRef.path]) {
        store[docRef.path] = { ...store[docRef.path], ...data };
      } else {
        store[docRef.path] = data;
      }
    },
    async getDocs(colRef: any) {
      const docs: any[] = [];
      for (const [key, val] of Object.entries(store)) {
        if (key.startsWith(colRef.path) && !key.slice(colRef.path.length + 1).includes("/")) {
          docs.push({
            id: key.split("/").pop(),
            data: () => val
          });
        }
      }
      return { docs };
    },
    async runTransaction(updateFunction: (tx: any) => Promise<any>) {
      const tx = {
        async get(docRef: any) {
          const data = store[docRef.path];
          return {
            exists: () => !!data,
            data: () => data || null
          };
        },
        set(docRef: any, data: any, opts?: any) {
          if (opts?.merge && store[docRef.path]) {
            store[docRef.path] = { ...store[docRef.path], ...data };
          } else {
            store[docRef.path] = data;
          }
        }
      };
      return await updateFunction(tx);
    }
  };
}

async function runCreditEngineResetRegressionTests() {
  console.log("=================================================");
  console.log("MABALA CREDIT ENGINE RESET BUG REGRESSION TEST");
  console.log("=================================================\n");

  const mockDb = createMockFirestore();
  const testTenantId = "TENANT-FARMER-8888";
  const signupKey = `signup:${testTenantId}`;

  // STEP 1: First Signup Credit Grant
  console.log("Test 1: Executing initial signup credit grant (+300 CR)...");
  const signupRes1 = await grantCreditsIdempotent(
    mockDb,
    testTenantId,
    300,
    "signup",
    signupKey,
    "Initial free plan signup credits"
  );

  console.assert(signupRes1.success === true, "Signup grant should succeed");
  console.assert(signupRes1.newBalance === 300, `Expected balance 300, got ${signupRes1.newBalance}`);
  console.assert(signupRes1.alreadyProcessed === false, "First signup should not be marked as alreadyProcessed");
  console.log("✓ Initial signup grant verified. Wallet balance = 300 CR.\n");

  // STEP 2: Verify Idempotency Guard on Duplicate Signup Attempt
  console.log("Test 2: Simulating duplicate signup trigger call (same idempotency key)...");
  const signupRes2 = await grantCreditsIdempotent(
    mockDb,
    testTenantId,
    300,
    "signup",
    signupKey,
    "Initial free plan signup credits"
  );

  console.assert(signupRes2.alreadyProcessed === true, "Duplicate signup should be marked as alreadyProcessed");
  console.assert(signupRes2.newBalance === 300, `Expected balance to remain 300, got ${signupRes2.newBalance}`);
  console.log("✓ Idempotency guard verified. Duplicate grant blocked.\n");

  // STEP 3: Simulate Real Work & Usage (Spending 55 credits -> balance 245)
  console.log("Test 3: Simulating operational usage deduction (-55 CR)...");
  const walletPath = `tenants/${testTenantId}/credit_wallet/default`;
  const legacyPath = `tenants/${testTenantId}/wallet/credits`;
  
  mockDb.store[walletPath].balance = 245;
  mockDb.store[walletPath].currentBalance = 245;
  mockDb.store[legacyPath].currentBalance = 245;
  mockDb.store[`tenants/${testTenantId}/creditLedger/deduct_001`] = {
    id: "deduct_001",
    type: "deduction",
    amount: 55,
    previousBalance: 300,
    newBalance: 245,
    description: "Crop cycle AI analysis"
  };

  const walletAfterSpend = mockDb.store[walletPath].balance;
  console.assert(walletAfterSpend === 245, `Expected 245 after spend, got ${walletAfterSpend}`);
  console.log("✓ Usage deduction applied. Real balance = 245 CR.\n");

  // STEP 4: Simulate Logout & Re-login (Checking No Reset Occurs)
  console.log("Test 4: Simulating user logout and subsequent login...");
  // On login, code path calls grantCreditsIdempotent with signup key or fetches existing doc
  const loginGrantCheck = await grantCreditsIdempotent(
    mockDb,
    testTenantId,
    300,
    "signup",
    signupKey,
    "Login attempt signup check"
  );

  console.assert(loginGrantCheck.alreadyProcessed === true, "Login check should trigger idempotency guard");
  console.assert(loginGrantCheck.newBalance === 245, `CRITICAL BUG VERIFICATION: Expected balance 245 after login, got ${loginGrantCheck.newBalance}`);
  console.log("✓ Logout & Re-login test PASSED! Balance remained intact at 245 CR.\n");

  // STEP 5: Reconciliation & Recovery Test
  console.log("Test 5: Running ledger reconciliation pass on tenant...");
  const recon = await reconstructAndFixTenantCreditWallet(mockDb, testTenantId, false);
  console.assert(recon.reconstructedBalance === 245, `Expected reconstructed balance 245, got ${recon.reconstructedBalance}`);
  console.assert(recon.hasDiscrepancy === false, "No discrepancy should be found for healthy ledger");
  console.log("✓ Ledger reconciliation test passed.\n");

  console.log("\x1b[32m=================================================");
  console.log("ALL CREDIT ENGINE RESET REGRESSION TESTS PASSED!");
  console.log("=================================================\x1b[0m\n");
}

runCreditEngineResetRegressionTests().catch((err) => {
  console.error("Regression test failed:", err);
  process.exit(1);
});

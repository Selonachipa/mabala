# Pig Lifecycle Audit

## Implemented baseline

`src/services/pigLifecycleService.ts` now provides a single domain boundary for:

- eligibility-validated breeding events and versioned 114-day forecasts;
- farrowing count validation and permanent newborn registration;
- newborn FVLCTS valuation with retained calculation inputs;
- authoritative carrying-value mortality and immutable mortality valuation;
- idempotency and optimistic animal-version checks;
- digital handover creation, recipient validation, discrepancy exceptions, and acceptance;
- litter reconciliation between registered live animals and mortality events.

The behavior is covered by `test_pig_lifecycle.ts` and runs through the normal `npm test` command.

## Existing implementation gaps

The existing `PigManager` and `EnterpriseLivestockManager` components still contain local-storage workflows for breeding, farrowing, mortality, and valuation. Those handlers are not yet callers of the new service and must not be treated as authoritative for production data.

The current server has SMS gateway adapters, but the lifecycle service does not yet schedule or persist farrowing alerts. A persistent Firestore repository and authenticated lifecycle routes are required before enabling production mutations from the browser.

HR-backed staff assignments, module permissions, GL financial-event publishing, immutable PDF handover documents, and daily cross-system reconciliation remain integration work. The domain service deliberately does not invent a second employee master or post journals directly.

## Recommended integration order

1. Add a Firestore repository implementing `PigLifecycleState` operations with tenant-scoped transactions.
2. Expose authenticated `/api/pig-manager/*` and `/api/registry/*` routes that construct requests from operational facts only.
3. Move the Pig Manager UI from local storage to those routes, retaining local storage only as an offline operation queue.
4. Publish registry events to the existing financial and notification services, using idempotency keys from the domain operations.
5. Add the PDF document hash and scheduled 24-hour notification worker after persistent event storage is live.
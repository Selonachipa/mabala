import assert from "assert";
import { handleAmountInput } from "./src/utils/numberInput.ts";

try {
  console.log("Running amount input logic unit tests...");

  // Test 1: Entering a new number into a default-zero field clears the initial '0' correctly (no appending "05")
  const result1 = handleAmountInput("05", 0);
  assert.strictEqual(result1, 5, "Entering '5' on a '0' field (resulting in '05') must clear the '0' and return 5");
  console.log("✓ Test passed: '05' input with previous value 0 successfully cleared leading zero to 5.");

  // Test 2: Entering '0' on a '0' field should stay '0'
  const result2 = handleAmountInput("00", 0);
  assert.strictEqual(result2, 0, "Entering '0' on a '0' field (resulting in '00') must return 0");
  console.log("✓ Test passed: '00' input with previous value 0 resolved to 0.");

  // Test 3: Clearing the field (empty string) must return 0 to prevent NaN errors
  const result3 = handleAmountInput("", 100);
  assert.strictEqual(result3, 0, "Clearing the field must return 0 to prevent NaN");
  console.log("✓ Test passed: Clearing the field returned 0 successfully (no NaN).");

  // Test 4: Regular numeric input is parsed correctly
  const result4 = handleAmountInput("150", 15);
  assert.strictEqual(result4, 150, "Regular numeric inputs must parse correctly to 150");
  console.log("✓ Test passed: '150' with previous value 15 parsed correctly to 150.");

  // Test 5: Float numeric input is parsed correctly
  const result5 = handleAmountInput("12.5", 0);
  assert.strictEqual(result5, 12.5, "Float numeric inputs must parse correctly to 12.5");
  console.log("✓ Test passed: Float input '12.5' with previous value 0 parsed correctly to 12.5.");

  console.log("\x1b[32mAll amount input logic unit tests completed successfully!\x1b[0m");
} catch (err) {
  console.error("Test execution failed:", err);
  process.exit(1);
}

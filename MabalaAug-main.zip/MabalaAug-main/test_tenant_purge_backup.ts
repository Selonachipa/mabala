import { TENANT_SCOPED_COLLECTIONS, SYSTEM_DEFAULT_CHART_OF_ACCOUNTS } from "./src/server/tenantBackupPurgeRoutes";

console.log("=================================================");
console.log("MABALA TENANT-SCOPED PURGE & TIERED BACKUP TESTS");
console.log("=================================================");

// Test 1: Verify TENANT_SCOPED_COLLECTIONS contains all required collections
console.log("\nTest 1: Verifying tenant-scoped collections list...");
const expectedCollections = [
  "crop_cycles",
  "expenses",
  "farm_ledger_transactions",
  "sales_tracker",
  "harvest_events",
  "storage_lots",
  "warehouse_receipts",
  "orchard_blocks",
  "orchard_expenses",
  "invoices",
  "payment_tracker",
  "credit_ledger",
  "farm_wallets",
  "hr_employees",
  "hr_payroll_runs",
  "reports_cache",
  "fbi_rollups",
  "suppliers",
  "customers",
  "quotations",
  "inventory",
  "livestock",
  "poultry",
  "fish",
  "assets",
  "loans",
  "investments",
  "other_revenues",
  "leave_records",
  "employee_advances"
];

for (const col of expectedCollections) {
  if (!TENANT_SCOPED_COLLECTIONS.includes(col as any)) {
    throw new Error(`Missing expected collection in TENANT_SCOPED_COLLECTIONS: ${col}`);
  }
}
console.log(`✓ All ${expectedCollections.length} required collections present in TENANT_SCOPED_COLLECTIONS.`);

// Test 2: System Default Chart of Accounts verification
console.log("\nTest 2: Verifying System Default Chart of Accounts...");
if (!Array.isArray(SYSTEM_DEFAULT_CHART_OF_ACCOUNTS) || SYSTEM_DEFAULT_CHART_OF_ACCOUNTS.length < 10) {
  throw new Error("Invalid or empty SYSTEM_DEFAULT_CHART_OF_ACCOUNTS");
}
const requiredCategories = ["Asset", "Liability", "Equity", "Revenue", "Expense"];
const categoriesFound = new Set(SYSTEM_DEFAULT_CHART_OF_ACCOUNTS.map(a => a.type));
for (const cat of requiredCategories) {
  if (!categoriesFound.has(cat)) {
    throw new Error(`Missing category ${cat} in SYSTEM_DEFAULT_CHART_OF_ACCOUNTS`);
  }
}
console.log(`✓ Chart of Accounts verified: ${SYSTEM_DEFAULT_CHART_OF_ACCOUNTS.length} accounts covering all 5 core accounting categories.`);

// Test 3: Exact Type-to-Confirm validation
console.log("\nTest 3: Testing exact type-to-confirm validation logic...");
const targetName = "Kanchele Farms";
const validateConfirm = (input: string, target: string) => {
  return input.trim().toLowerCase() === target.trim().toLowerCase();
};

if (!validateConfirm("Kanchele Farms", targetName)) throw new Error("Exact match failed");
if (!validateConfirm("  kanchele farms  ", targetName)) throw new Error("Case/whitespace insensitive match failed");
if (validateConfirm("Kanchele", targetName)) throw new Error("Partial match should have been rejected");
if (validateConfirm("Wrong Farm", targetName)) throw new Error("Mismatch should have been rejected");
console.log("✓ Type-to-confirm validation behaves strictly and correctly.");

// Test 4: Tenant Metadata Header in Backup Payloads
console.log("\nTest 4: Verifying tenant-scoped backup metadata header...");
const mockTenantId = "TENANT-FARM-999";
const mockTenantName = "Deep Valley Farm";
const mockMeta = {
  tenantId: mockTenantId,
  tenantName: mockTenantName,
  exportedAt: Date.now(),
  exportedBy: "uid_admin_123",
  scope: "tenant" as const,
  totalRecords: 45
};

if (mockMeta.scope !== "tenant" || mockMeta.tenantId !== mockTenantId) {
  throw new Error("Invalid tenant metadata scope");
}

// Safety check: verify that restoring this backup to another tenant throws error
const targetTenantForRestore = "TENANT-FARM-888";
const isAllowedRestore = mockMeta.tenantId === targetTenantForRestore;
if (isAllowedRestore) {
  throw new Error("Cross-tenant restore must be blocked by metadata verification!");
}
console.log("✓ Tenant metadata header and cross-tenant restore isolation verified.");

// Test 5: Maker-Checker Dual Authorization Rule for Platform Restore
console.log("\nTest 5: Verifying Platform Restore Maker-Checker rule...");
const canonicalSuperAdmins = [
  "support@mabala.cloud",
  "shikasuli@gmail.com",
  "owner@mabala.com",
  "mary@mabala.com"
];

const checkDualAuth = (initiatorEmail: string, secondAdminEmail: string, phrase: string) => {
  if (phrase !== "RESTORE ENTIRE PLATFORM") {
    return { ok: false, reason: "Invalid confirmation phrase" };
  }
  if (!canonicalSuperAdmins.includes(initiatorEmail.toLowerCase())) {
    return { ok: false, reason: "Initiator is not a Super Admin" };
  }
  if (!canonicalSuperAdmins.includes(secondAdminEmail.toLowerCase())) {
    return { ok: false, reason: "Second approver is not an authorized Super Admin" };
  }
  if (initiatorEmail.toLowerCase() === secondAdminEmail.toLowerCase()) {
    return { ok: false, reason: "Self-approval forbidden by Maker-Checker policy" };
  }
  return { ok: true };
};

const validAuth = checkDualAuth("support@mabala.cloud", "owner@mabala.com", "RESTORE ENTIRE PLATFORM");
if (!validAuth.ok) throw new Error("Valid dual auth failed");

const selfAuth = checkDualAuth("support@mabala.cloud", "support@mabala.cloud", "RESTORE ENTIRE PLATFORM");
if (selfAuth.ok) throw new Error("Self-approval should have been blocked");

const wrongPhrase = checkDualAuth("support@mabala.cloud", "owner@mabala.com", "restore platform");
if (wrongPhrase.ok) throw new Error("Incorrect phrase should have been blocked");

console.log("✓ Maker-Checker dual-administrator authorization rule verified.");

console.log("\n=================================================");
console.log("ALL TENANT PURGE & TIERED BACKUP TESTS PASSED!");
console.log("=================================================\n");

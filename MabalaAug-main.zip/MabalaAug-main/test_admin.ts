import * as admin from "firebase-admin";
import { getApps, initializeApp as initAdminApp } from "firebase-admin/app";
import { getFirestore as getAdminFirestore } from "firebase-admin/firestore";

const PROJECT_ID = "mabala-f2d65";
const DATABASE_ID = "ai-studio-020042e7-7cf8-4e86-bdea-ea1ae9737651";

async function testAdmin() {
  try {
    console.log("Initializing Admin SDK...");
    const apps = getApps();
    const adminApp = apps.length === 0 ? initAdminApp({ projectId: PROJECT_ID }) : apps[0];
    
    console.log("Getting Admin Firestore database instance...");
    const adminDb = getAdminFirestore(adminApp, DATABASE_ID);
    
    console.log("Querying users_data via Admin SDK...");
    const snap = await adminDb.collection("users_data").get();
    console.log(`Success! Found ${snap.docs.length} documents.`);
  } catch (err: any) {
    console.error("Admin SDK Query Failed:", err.message);
    if (err.stack) {
      console.error(err.stack);
    }
  }
}

testAdmin();

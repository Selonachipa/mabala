import { initializeApp as initClientApp, getApps as getClientApps } from "firebase/app";
import { getFirestore as getClientFirestore, collection as clientCollection, getDocs as clientGetDocs } from "firebase/firestore";

const PROJECT_ID = "mabala-f2d65";
const FIREBASE_API_KEY = "AIzaSyD3ixrRx5Y3vEobSH7sCGQZBZVWeYFzoHY";
const DATABASE_ID = "ai-studio-020042e7-7cf8-4e86-bdea-ea1ae9737651";

async function testClient() {
  try {
    const apps = getClientApps();
    const app = apps.length === 0 ? initClientApp({
      projectId: PROJECT_ID,
      apiKey: FIREBASE_API_KEY
    }) : apps[0];
    
    console.log("Initializing Client Firestore...");
    const clientDb = getClientFirestore(app, DATABASE_ID);
    
    console.log("Querying users_data collection via Client SDK...");
    const colRef = clientCollection(clientDb, "users_data");
    const snap = await clientGetDocs(colRef);
    console.log(`Success via Client SDK! Found ${snap.docs.length} documents.`);
  } catch (err: any) {
    console.error("Client SDK Query Failed:", err.message);
    if (err.stack) {
      console.error(err.stack);
    }
  }
}

testClient();

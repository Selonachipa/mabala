import * as admin from "firebase-admin";
import { getApps, initializeApp as initAdminApp } from "firebase-admin/app";
import { getFirestore as getAdminFirestore } from "firebase-admin/firestore";

const PROJECT_ID = "mabala-f2d65";
const DATABASE_ID = "ai-studio-020042e7-7cf8-4e86-bdea-ea1ae9737651";

async function run() {
  try {
    const apps = getApps();
    const adminApp = apps.length === 0 ? initAdminApp({ projectId: PROJECT_ID }) : apps[0];
    const adminDb = getAdminFirestore(adminApp, DATABASE_ID);
    
    console.log("Testing 3-segment doc path...");
    try {
      const docRef = adminDb.doc("platform/admins/test_uid_123");
      console.log("3-segment doc path succeeded! Path:", docRef.path);
    } catch (e: any) {
      console.log("3-segment doc path failed:", e.message);
    }

    console.log("Testing 2-segment doc path...");
    try {
      const docRef = adminDb.doc("platform/admins");
      console.log("2-segment doc path succeeded! Path:", docRef.path);
    } catch (e: any) {
      console.log("2-segment doc path failed:", e.message);
    }

  } catch (err: any) {
    console.error("Outer error:", err);
  }
}

run();

import { 
  formatTimestampForFileName, 
  sanitizeTenantName, 
  generateBackupFileName, 
  computeSHA256, 
  validateBackupIntegrity,
  isImmutableRecoveryBackup,
  isTenantBackupScopeAuthorized,
  executeTenantBackup,
  executeBackup,
  runPlatformBackup
} from "./src/backupService";

async function runTests() {
  console.log("Running Backup Engine Unit Tests...\n");

  // Test 1: Timestamp Formatting
  const ts = formatTimestampForFileName(new Date("2026-08-04T12:00:00Z"));
  console.assert(ts.ymd === "20260804", `Expected ymd 20260804, got ${ts.ymd}`);
  console.assert(ts.hms === "140000", `Expected CAT hms 140000, got ${ts.hms}`);
  console.log("✓ Timestamp formatting test passed.");

  // Test 2: Sanitize Tenant Name
  const sName1 = sanitizeTenantName("Kasama Cooperative Union #1!");
  console.assert(sName1 === "Kasama_Cooperative_Union_1_", `Expected Kasama_Cooperative_Union_1_, got ${sName1}`);
  const sName2 = sanitizeTenantName("  Deep Valley Farm  ");
  console.assert(sName2 === "Deep_Valley_Farm", `Expected Deep_Valley_Farm, got ${sName2}`);
  console.log("✓ Tenant name sanitization test passed.");

  // Test 3: Programmatic Naming Convention Enforcement
  const tenantFileName = generateBackupFileName("manual", "Kasama Coop", "tenant123", false);
  console.assert(tenantFileName.includes("Kasama_Coop_tenant123_"), `Tenant file name mismatch: ${tenantFileName}`);
  console.assert(tenantFileName.endsWith("_manual.export"), `Tenant file name extension mismatch: ${tenantFileName}`);

  const platformFileName = generateBackupFileName("scheduled", undefined, undefined, true);
  console.assert(platformFileName.startsWith("platform-wide_"), `Platform file name mismatch: ${platformFileName}`);
  console.assert(platformFileName.endsWith("_scheduled.export"), `Platform file name extension mismatch: ${platformFileName}`);
  console.log("✓ Backup naming convention enforcement test passed.");

  // Test 4: SHA-256 Checksum Computation
  const dummyPayload = { hello: "world", count: 42 };
  const rawStr = JSON.stringify(dummyPayload);
  const hash = computeSHA256(rawStr);
  console.assert(hash.startsWith("sha256:"), `Hash should start with sha256:, got ${hash}`);
  console.log(`✓ SHA-256 computation test passed (${hash.slice(0, 20)}...).`);

  // Test 5: Backup Payload Integrity Validation
  const validPayload = {
    manifest: {
      version: "1.0",
      timestamp: new Date().toISOString(),
      scope: "tenant",
      tenantId: "t123",
      tenantName: "Test Tenant",
      recordsCount: 2,
      checksum: hash
    },
    checksum: hash,
    data: dummyPayload
  };

  const validationRes = validateBackupIntegrity(validPayload);
  console.assert(validationRes.valid === true, `Expected valid true, got ${validationRes.valid}`);
  console.assert(validationRes.checksumMatches === true, "Expected checksumMatches true");
  console.log("✓ Backup payload integrity validation test passed.");

  // Test 6: Corrupted Checksum Test
  const corruptedPayload = {
    ...validPayload,
    manifest: {
      ...validPayload.manifest,
      checksum: "sha256:invalidhash12345"
    }
  };
  const corruptedRes = validateBackupIntegrity(corruptedPayload);
  console.assert(corruptedRes.checksumMatches === false, "Expected checksumMatches false for corrupted payload");
  console.log("✓ Corrupted payload detection test passed.");

  console.assert(isImmutableRecoveryBackup({ type: "safety_snapshot" }) === true, "Safety snapshots must be immutable");
  console.assert(isImmutableRecoveryBackup({ type: "manual" }) === false, "Manual backups should remain retention-managed");
  console.assert(isTenantBackupScopeAuthorized({ tenantId: "tenant-a", isSuperAdmin: false }, "tenant-a") === true, "Owner scope should be allowed");
  console.assert(isTenantBackupScopeAuthorized({ tenantId: "tenant-a", isSuperAdmin: false }, "tenant-b") === false, "Cross-tenant scope should be rejected");
  console.assert(isTenantBackupScopeAuthorized({ tenantId: "admin", isSuperAdmin: true }, "tenant-b") === true, "Super Admin scope should be allowed");
  console.log("✓ Recovery scope and immutable-backup policy tests passed.");

  console.log("\n\x1b[32mAll Backup Engine Unit Tests Passed Successfully!\x1b[0m");
}

runTests().catch(err => {
  console.error("Test execution failed:", err);
  process.exit(1);
});
